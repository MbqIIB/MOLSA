/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.inject.Inject;

import curam.attendance.impl.ProviderAttendanceTracking;
import curam.attendance.impl.ProviderAttendanceTrackingDAO;
import curam.codetable.CASEEVIDENCE;
import curam.codetable.CONCERNROLEALTERNATEID;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.ALLEGATIONROLETYPEEntry;
import curam.codetable.impl.CASEPARTICIPANTROLETYPEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.COMMUNICATIONMETHODEntry;
import curam.codetable.impl.CURRENCYEntry;
import curam.codetable.impl.LANGUAGEEntry;
import curam.codetable.impl.PREFERREDSERVICEENQUIRYMETHODEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.codetable.impl.WAITLISTTYPEEntry;
import curam.contracts.impl.ContractVersion;
import curam.core.fact.AddressFactory;
import curam.core.fact.ConcernFactory;
import curam.core.fact.ConcernRoleAlternateIDFactory;
import curam.core.fact.MaintainConcernRoleAddressFactory;
import curam.core.fact.MaintainConcernRoleBankAcFactory;
import curam.core.fact.MaintainConcernRolePhoneFactory;
import curam.core.impl.ConcernRoleAdapter;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.Address;
import curam.core.intf.Concern;
import curam.core.intf.ConcernRoleAlternateID;
import curam.core.intf.MaintainConcernRoleAddress;
import curam.core.intf.MaintainConcernRoleBankAc;
import curam.core.intf.MaintainConcernRolePhone;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorInsertDtls;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EIEvidenceInsertDtls;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.struct.AddressDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.BankAccountDetails;
import curam.core.struct.ConcernDtls;
import curam.core.struct.ConcernRoleAlternateIDDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRolePhoneDetails;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.MaintainAddressKey;
import curam.core.struct.MaintainBankAccountKey;
import curam.core.struct.MaintainPhoneNumberKey;
import curam.cpm.facade.struct.ConcernRoleAndUserNameDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.impl.ProviderAdapter;
import curam.cpm.sl.entity.struct.PlaceByDateDetails;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderDtls;
import curam.cpm.sl.entity.struct.ProviderInvestigationDetails;
import curam.cpm.sl.entity.struct.ProviderInvestigationDetailsList;
import curam.cpm.sl.entity.struct.ProviderMembersBackgroundCheckDetails;
import curam.cpm.sl.entity.struct.ProviderMembersBackgroundCheckDetailsList;
import curam.cpm.sl.fact.ProviderNotificationFactory;
import curam.cpm.sl.intf.ProviderNotification;
import curam.cpm.sl.struct.ProviderNotificationKey;
import curam.events.PROVIDER;
import curam.financial.impl.ServiceInvoiceLineItem;
import curam.financial.impl.ServiceInvoiceLineItemDAO;
import curam.homestudy.impl.HomeStudy;
import curam.homestudy.impl.HomeStudyDAO;
import curam.message.impl.BPOMAINTAINCONCERNROLEPHONEExceptionCreator;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.GENERALCONCERNExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.message.impl.PROVIDERSECURITYExceptionCreator;
import curam.place.impl.Compartment;
import curam.place.impl.CompartmentDAO;
import curam.place.impl.Place;
import curam.place.impl.PlaceDAO;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.useradmin.impl.MaintainAdminConcernRole;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.CodetableState;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.State;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateTime;
import curam.util.type.DateTimeRange;
import curam.util.type.FrequencyPattern;
import curam.util.type.StringHelper;
import curam.workspaceservices.localization.impl.LocalizableText;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;


/**
 * {@inheritDoc}
 */
// BEGIN, CR00183213, SS
public class ProviderImpl extends ProviderOrganizationImpl<ProviderDtls>
  implements Provider {
  // END, CR00183213



  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for suspend events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderSuspendEvents> suspendEventDispatcherFactory;

  /**
   * Event dispatcher for close events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderCloseEvents> closeEventDispatcherFactory;

  /**
   * Event dispatcher for reject events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderRejectEvents> rejectEventDispatcherFactory;

  /**
   * Event dispatcher for approve events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderApproveEvents> approveEventDispatcherFactory;

  /**
   * Event dispatcher for reopen events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderReopenEvents> reopenEventDispatcherFactory;

  /**
   * Event dispatcher for enroll events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderEnrollEvents> enrollEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  // BEGIN, CR00235789, RD
  /**
   * Event dispatcher for get available places in date range events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderGetAvailablePlacesInDateRangeEvents> getAvailablePlacesInDateRangeEventDispatcherFactory;

  /**
   * Event dispatcher for get service offerings events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderGetServiceOfferingsEvents> getServiceOfferingsEventDispatcherFactory;

  /**
   * Event dispatcher for get common approved provider offerings events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderGetCommonApprovedProviderServiceOfferingsEvents> getCommonApprovedProviderServiceOfferingsEventDispatcherFactory;

  // END, CR00235789

  /**
   * concernRoleDtls instance of ConcernRoleDtls.
   */
  protected ConcernRoleDtls concernRoleDtls = null;

  // BEGIN, CR00178272, AK
  /**
   * Reference to localizable text handler DAO.
   */
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Reference to localizable text handler used for the attribute areas served
   * information.
   */
  protected LocalizableTextHandler areasServedInfoLocalizableText;

  /**
   * Reference to localizable text handler used for the attribute client
   * information.
   */
  protected LocalizableTextHandler clientInfoLocalizableText;

  // END, CR00178272

  // BEGIN, CR00197073, ASN
  /**
   * Reference to provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  // END, CR00197073

  /*
   * State Transitions
   */
  
  /**
   * A map of the states for this entity
   */
  protected final Map<ProviderStatusEntry, State<ProviderStatusEntry>> states = new HashMap<ProviderStatusEntry, State<ProviderStatusEntry>>();

  /**
   * Registered provider with the organization.
   */
  protected final State<ProviderStatusEntry> OPEN = new CodetableState<ProviderStatusEntry>(
    states, ProviderStatusEntry.OPEN, false, false) {// code table value for open.
  };

  /**
   * Approved to provide services to an organization's clients.
   */
  protected final State<ProviderStatusEntry> APPROVED = new CodetableState<ProviderStatusEntry>(
    states, ProviderStatusEntry.APPROVED, false, false) {// code table value for approved.
  };

  /**
   * Provider rejected to provide services to an organization's clients.
   */
  protected final State<ProviderStatusEntry> REJECTED = new CodetableState<ProviderStatusEntry>(
    states, ProviderStatusEntry.REJECTED, false, false) {// code table value for rejected.
  };

  /**
   * Provider suspended to provide services to an organization's clients.
   */
  protected final State<ProviderStatusEntry> SUSPENDED = new CodetableState<ProviderStatusEntry>(
    states, ProviderStatusEntry.SUSPENDED, false, false) {// code table value for suspended.
  };

  /**
   * Provider closed, no longer providing services .
   */
  protected final State<ProviderStatusEntry> CLOSED = new CodetableState<ProviderStatusEntry>(
    states, ProviderStatusEntry.CLOSED, false, false) {// code table value for closed.
  };

  /**
   * providerOfferingDAO type of ProviderOfferingDAO
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * providerSpecialtyDAO type of ProviderSpecialtyDAO
   */
  @Inject
  protected ProviderSpecialtyDAO providerSpecialtyDAO;

  /**
   * compartmentDAO type of CompartmentDAO
   */
  @Inject
  protected CompartmentDAO compartmentDAO;

  /**
   * placeDAO type of PlaceDAO
   */
  @Inject
  protected PlaceDAO placeDAO;

  /**
   * providerBackgroundCheckDAO type of ProviderBackgroundCheckDAO
   */
  @Inject
  protected ProviderBackgroundCheckDAO providerBackgroundCheckDAO;

  /**
   * providerOfferingDAO type of ProviderOfferingDAO
   */
  @Inject
  protected ProviderAccreditationDAO providerAccreditationDAO;

  /**
   * providerServiceCenterDAO type of ProviderServiceCenterDAO
   */
  @Inject
  protected ProviderServiceCenterDAO providerServiceCenterDAO;

  /**
   * providerCategoryPeriodDAO type of ProviderCategoryPeriodDAO
   */
  @Inject
  protected ProviderCategoryPeriodDAO providerCategoryPeriodDAO;

  /**
   * homeStudyDAO type of HomeStudyDAO
   */
  @Inject
  protected HomeStudyDAO homeStudyDAO;

  /**
   * providerSecurity type of ProviderSecurity
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * serviceInvoiceLineItemDAO type of ServiceInvoiceLineItemDAO
   */
  @Inject
  protected ServiceInvoiceLineItemDAO serviceInvoiceLineItemDAO;

  /**
   * providerEnquiryDAO type of ProviderEnquiryDAO
   */
  @Inject
  protected ProviderEnquiryDAO providerEnquiryDAO;

  /**
   * Data access object reference for ProviderAttendanceTracking;
   */
  @Inject
  protected ProviderAttendanceTrackingDAO providerAttendanceTrackingDAO;

  /**
   * Rejects the provider seeking approval for providing the services to an
   * organization's clients. Also notifies the provider of rejection along with
   * the reason for rejection and raises a workflow event.
   *
   * Checks the provider security to reject the provider.
   *
   * @param rejectionReason
   * The reason for rejection.
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#
   * ERR_PROVIDER_XRV_ONLY_OPEN_STATUS_CAN_BE_REJECTED}
   * - If the provider status is not Open.
   */
  public void reject(String rejectionReason, int versionNo)
    throws InformationalException, AppException {

    providerSecurity.checkProviderSecurity(this);

    // BEGIN, CR00235789, AK
    // Raise the pre reject provider event.
    rejectEventDispatcherFactory.get(ProviderRejectEvents.class).preReject(this,
      rejectionReason, versionNo);
    // END, CR00235789

    // Provider can be rejected only if its status in Open
    if (!getDtls().recordStatus.trim().equals(
      ProviderStatusEntry.OPEN.getCode())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_ONLY_OPEN_STATUS_CAN_BE_REJECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    setState(REJECTED);

    super.modify(versionNo);

    // Send Provider Rejection Notification
    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();

    ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = getID();
    providerNotificationKey.event = ProviderNotificationEventEntry.REJECTION.getCode();
    providerNotificationKey.reason = ProviderStatusRejectionReasonEntry.get(rejectionReason).toUserLocaleString();
    providerNotification.sendNotification(providerNotificationKey);

    final Event event = new Event();

    event.eventKey = PROVIDER.PROVIDER_REJECTED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    ValidationHelper.failIfErrorsExist();

    // BEGIN, CR00235789, AK
    // Raise the post reject provider event.
    rejectEventDispatcherFactory.get(ProviderRejectEvents.class).postReject(
      this, rejectionReason, versionNo);
    // END, CR00235789
  }

  // BEGIN, CR00388648, MR
  /**
   * Reopens the closed provider for the approval of providing the services to
   * an organization's clients and notifies the provider that they are re-opened
   * and raises a workflow event.
   *
   * Checks the provider security to reopen the provider.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERSECURITY#
   * ERR_PROVIDER_SECURITY_XRV_NO_ACCESS_TO_REOPEN}
   * - If the user is not owner/supervisor of the provider.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#
   * ERR_PROVIDER_XRV_ONLY_CLOSED_STATUS_CAN_BE_REOPENED}
   * - If the provider status is not Closed.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void reopen(int versionNo)
    throws InformationalException, AppException {

    if (!providerSecurity.providerSecurityCheckSucceeded(this)) {

      ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERSECURITYExceptionCreator.ERR_PROVIDER_SECURITY_XRV_NO_ACCESS_TO_REOPEN(
          TransactionInfo.getProgramUser()),
          ValidationManagerConst.kSetTwo,
          1);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00388648
	
    // BEGIN, CR00235789, AK
    // Raise the pre reopen provider event.
    reopenEventDispatcherFactory.get(ProviderReopenEvents.class).preReopen(this,
      versionNo);
    // END, CR00235789

    // if(getDtls().recordStatus)
    // Provider can be rejected only if its status in Open
    if (!getDtls().recordStatus.trim().equals(
      ProviderStatusEntry.CLOSED.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_ONLY_CLOSED_STATUS_CAN_BE_REOPENED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    ValidationHelper.failIfErrorsExist();

    setState(OPEN);
    super.modify(versionNo);
    // Send Provider Reopening Notification
    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();

    ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = getID();
    providerNotificationKey.event = ProviderNotificationEventEntry.REOPENING.getCode();
    providerNotification.sendNotification(providerNotificationKey);

    // raise the re open event
    final Event event = new Event();

    event.eventKey = PROVIDER.PROVIDER_REOPENED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post reopen provider event.
    reopenEventDispatcherFactory.get(ProviderReopenEvents.class).postReopen(
      this, versionNo);
    // END, CR00235789
  }

  // BEGIN, CR00246372, AK
  /**
   * Approves the provider for providing the services to an organization's
   * clients. Also notifies the provider of the approval and raises a workflow
   * event.
   * Performs No Security Checks before approving the provider.
   * The method should be used only when it is unavoidable to skip the security check and
   * it is sure that skipping the security check doesn't break the application's behavior.
   * In all the other cases, only the other version of the method : approveWithSecurityCheck()
   * should be used.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#
   * ERR_PROVIDER_XRV_CLOSED_PROVIDER_CANNOT_BE_APPROVED} -
   * If the provider status is Closed.
   * {@link curam.message.PROVIDER#
   * ERR_PROVIDER_XRV_USER_CANNOT_APPROVE_APPROVED_PROVIDER} -
   * If the provider is already approved.
   */
  public void approve(int versionNo) throws AppException,
      InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre approve provider event.
    approveEventDispatcherFactory.get(ProviderApproveEvents.class).preApprove(
      this, versionNo);
    // END, CR00235789

    if (getDtls().recordStatus.equals(ProviderStatusEntry.CLOSED.getCode())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_CLOSED_PROVIDER_CANNOT_BE_APPROVED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // You can not approve a approved provider
    if (getDtls().recordStatus.equals(curam.provider.ProviderStatus.APPROVED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_USER_CANNOT_APPROVE_APPROVED_PROVIDER(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    ValidationHelper.failIfErrorsExist();

    setState(APPROVED);

    super.modify(versionNo);
    // Send Provider Approval Notification
    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();
    ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = getID();
    providerNotificationKey.event = ProviderNotificationEventEntry.APPROVAL.getCode();

    providerNotification.sendNotification(providerNotificationKey);

    // raise the approve event
    final Event event = new Event();

    event.eventKey = PROVIDER.PROVIDER_APPROVED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post approve provider event.
    approveEventDispatcherFactory.get(ProviderApproveEvents.class).postApprove(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Approves the Provider if the User has the rights to do so.
   * Performs Security Checks before approving the provider.
   * This method should be used in all places wherever the provider approval is to be done,
   * except for a few exceptional scenarios such as automated processes or workflows.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_CLOSED_PROVIDER_CANNOT_BE_APPROVED} -
   * If the provider status is Closed.
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_USER_CANNOT_APPROVE_APPROVED_PROVIDER} -
   * If the provider is already approved.
   */
  public void approveWithSecurityCheck(int versionNo) throws AppException,
      InformationalException {

    providerSecurity.checkProviderSecurity(this);
    approve(versionNo);
  }

  /**
   * Sets the state codetable code field from the State object supplied.
   *
   * @param state
   * the State supplied
   */
  // BEGIN, CR00177241, PM
  protected void setState(final State<ProviderStatusEntry> state) {
    // END, CR00177241
    getDtls().recordStatus = state.getValue().getCode();
  }

  // END, CR00246372

  /**
   * Ceases the provider business with the agency and raises a workflow event.
   *
   * Checks the provider security to close the provider.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#
   * ERR_PROVIDER_XRV_USER_CANNOT_CLOSE_CLOSED_PROVIDER} -
   * If the provider status is Closed.
   */
  public void close(int versionNo) throws InformationalException, AppException {

    providerSecurity.checkProviderSecurity(this);

    // BEGIN, CR00235789, AK
    // Raise the pre close provider event.
    closeEventDispatcherFactory.get(ProviderCloseEvents.class).preClose(this,
      versionNo);
    // END, CR00235789

    // You can not close a closed provider
    if (getDtls().recordStatus.trim().equals(
      ProviderStatusEntry.CLOSED.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_USER_CANNOT_CLOSE_CLOSED_PROVIDER(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    ValidationHelper.failIfErrorsExist();

    setState(CLOSED);
    super.modify(versionNo);
    // raise the close event
    final Event event = new Event();

    event.eventKey = PROVIDER.PROVIDER_CLOSED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post close provider event.
    closeEventDispatcherFactory.get(ProviderCloseEvents.class).postClose(this,
      versionNo);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderSpecialty> getProviderSpecialties() {
    return Collections.unmodifiableSet(providerSpecialtyDAO.searchBy(this));
  }

  // BEGIN, CR00279574, MR
  /**
   * Sets the status history of a provider.
   *
   * @param value
   * Contains the status of a provider throughout the lifecycle of
   * their relationship with the organization.
   *
   * @deprecated Since Curam 6.0 SP2. This method is deprecated as it is not
   * implemented and not used anywhere. See release note:
   * CR00279574.
   */
  @Deprecated
  public void setProviderStatusHistory(final ProviderStatusHistory value) {// not implemented
  }

  // END, CR00279574
  
  /**
   * Suspends the provider from providing the services to an organization's
   * clients. Also notifies the provider of the suspension and raises a workflow
   * event.
   *
   * Checks the provider security to suspend the provider.
   *
   * Transitions the state to
   * {@linkplain curam.provider.impl.ProviderStatusEntry#SUSPENDED}, if it is
   * valid to reject.
   *
   * @param suspentionReason
   * the reason for suspension.
   * @param versionNo
   * the version number as previously retrieved.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * if the entity is not in a valid state to transition to
   * {@linkplain curam.provider.impl.ProviderStatusEntry#SUSPENDED},
   * or if any other validation errors are found.
   */
  public void suspend(String suspentionReason, int versionNo)
    throws InformationalException, AppException {

    providerSecurity.checkProviderSecurity(this);

    // BEGIN, CR00235789, AK
    // Raise the pre suspend provider event.
    suspendEventDispatcherFactory.get(ProviderSuspendEvents.class).preSuspend(
      this, suspentionReason, versionNo);
    // END, CR00235789

    // Provider can be suspended only if its status in Approved
    if (!getDtls().recordStatus.trim().equals(
      ProviderStatusEntry.APPROVED.getCode())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_ONLY_APPROVED_STATUS_CAN_BE_SUSPENDED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    ValidationHelper.failIfErrorsExist();

    setState(SUSPENDED);

    super.modify(versionNo);

    // Send Provider Suspend Notification
    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();

    ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = getID();
    providerNotificationKey.event = ProviderNotificationEventEntry.SUSPENSION.getCode();

    providerNotificationKey.reason = ProviderStatusSuspensionReasonEntry.get(suspentionReason).toUserLocaleString();
    providerNotification.sendNotification(providerNotificationKey);

    // raise the suspend event
    final Event event = new Event();

    event.eventKey = PROVIDER.PROVIDER_SUSPENDED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post suspend provider event.
    suspendEventDispatcherFactory.get(ProviderSuspendEvents.class).postSuspend(
      this, suspentionReason, versionNo);
    // END, CR00235789
  }

  /**
   * Gets the status of the Provider.
   *
   * @return The status of the Provider.
   */
  public ProviderStatusEntry getLifecycleState() {

    return ProviderStatusEntry.get(getDtls().recordStatus);
  }

  /**
   * Enrolls the provider in the organization and also, if required, to register
   * the provider as one or more person(s).
   *
   * @param concernRoleDtls
   * It contains concern role related values.
   * @param addressDetails
   * It contains address related details.
   * @param concernRolePhoneDetails
   * It contains concern role phone details.
   * @param bankAccountDetails
   * It contains bank related values.
   *
   * @throws InformationalException
   * {@link curam.message.CPMCOMMONMESSAGES#
   * ERR_CPMCOMMONMSG_XRV_PREFERRED_COMMUICATION_MUST_BE_ENTERED} -
   * If preferred communication is not selected.
   * @throws InformationalException
   * {@link curam.message.BPOMAINTAINCONCERNROLEPHONE#
   * ERR_CONCERNROLEPHONE_XFV_PHONEAREACODE_EMPTY} -
   * If phone area code is not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#
   * ERR_PROVIDER_FV_COMMENT_IS_TOO_LONG} -
   * if comments are longer than the maximum length specified for
   * comments.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.CPMCOMMONMESSAGES#
   * ERR_CPMCOMMONMSG_XRV_PREFERRED_LANGUAGE_MUST_BE_ENTERED} -
   * If preferred language is not selected.
   * @throws InformationalException
   * {@link curam.message.BPOMAINTAINCONCERNROLEPHONE#
   * ERR_CONCERNROLEPHONE_XFV_PHONENUMBER_PHONETYPE} -
   * If phone number is not specified when phone number type is
   * specified.
   * @throws InformationalException
   * {@link curam.message.BPOMAINTAINCONCERNROLEPHONE#
   * ERR_CONCERNROLEPHONE_XFV_PHONENUMBER_PHONETYPE_EMPTY} -
   * If phone details does not contain both a phone number and a phone
   * type.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#
   * ERR_PROVIDER_FV_NAME_MUST_BE_ENTERED} -
   * If provider name in not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_FV_NAME_IS_TOO_LONG} -
   * If provider name is longer than the maximum length specified for
   * provider name.
   * @throws InformationalException
   * {@link curam.message.BPOMAINTAINCONCERNROLEPHONE#
   * ERR_CONCERNROLEPHONE_XFV_PHONETYPE_PHONENUMBER} -
   * If phone type is not specified.
   */
  public void enroll(ConcernRoleDtls concernRoleDtls,
    AddressDetails addressDetails,
    ConcernRolePhoneDetails concernRolePhoneDetails,
    BankAccountDetails bankAccountDetails) throws AppException,
      InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre enroll provider event.
    enrollEventDispatcherFactory.get(ProviderEnrollEvents.class).preEnroll(this,
      concernRoleDtls, addressDetails, concernRolePhoneDetails,
      bankAccountDetails);
    // END, CR00235789

    // unique id generator class
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // check for existing concern role for this provider
    ConcernDtls concernDtls = new ConcernDtls();

    concernDtls.creationDate = TransactionInfo.getSystemDate();
    concernDtls.name = concernRoleDtls.concernRoleName;
    concernDtls.comments = "";

    concernDtls.concernID = concernRoleDtls.concernID;

    // if the concern is already registered in the system get concern ID
    // if not generate new concern ID
    if (concernRoleDtls.concernRoleID == 0) {

      concernDtls.concernID = uniqueIDObj.getNextID();
      concernRoleDtls.concernID = concernDtls.concernID;
      concernRoleDtls.concernRoleID = uniqueIDObj.getNextID();
    }

    // create concern object for concern registration
    validateConcernFields(concernDtls);
    Concern concernObj = ConcernFactory.newInstance();

    concernObj.insert(concernDtls);

    // Insert address for this provider
    AddressDtls addressDtls = new AddressDtls();

    addressDtls.addressData = addressDetails.addressData;
    addressDtls.modifiableInd = true;

    Address addressObj = AddressFactory.newInstance();

    addressObj.insert(addressDtls);

    // Insert Concern Role Details
    concernRoleDtls.primaryAddressID = addressDtls.addressID;

    // concernRoleObj.insert(concernRoleDtls);
    // save details (create record)
    // Change done in line with CR00061193
    // Call the EvidenceController object and insert evidence
    // Evidence descriptor details
    EvidenceDescriptorInsertDtls evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();

    evidenceDescriptorInsertDtls.participantID = concernRoleDtls.concernRoleID;
    evidenceDescriptorInsertDtls.evidenceType = CASEEVIDENCE.CONCERNROLE;
    evidenceDescriptorInsertDtls.receivedDate = curam.util.type.Date.getCurrentDate();

    // Evidence Interface details
    EIEvidenceInsertDtls eiEvidenceInsertDtls = new EIEvidenceInsertDtls();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.descriptor.participantID = concernRoleDtls.concernRoleID;
    eiEvidenceInsertDtls.evidenceObject = concernRoleDtls;

    // Insert the evidence
    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    evidenceControllerObj.insertEvidence(eiEvidenceInsertDtls);

    // set this provider's identifier
    getDtls().providerConcernRoleID = concernRoleDtls.concernRoleID;

    // BEGIN, CR00170625, KR
    getDtls().name = concernRoleDtls.concernRoleName;
    getDtls().nameUpper = concernRoleDtls.concernRoleName.toUpperCase();
    // END, CR00170625

    this.concernRoleDtls = concernRoleDtls;

    validateConcernRoleFields();

    // Insert concern role alternate ID
    ConcernRoleAlternateIDDtls concernRoleAlternateIDDtls = new ConcernRoleAlternateIDDtls();

    // insert concern role alternate id
    concernRoleAlternateIDDtls.concernRoleAlternateID = uniqueIDObj.getNextID();
    concernRoleAlternateIDDtls.concernRoleID = concernRoleDtls.concernRoleID;
    concernRoleAlternateIDDtls.alternateID = concernRoleDtls.primaryAlternateID;
    // BEGIN, CR00097704, RD
    concernRoleAlternateIDDtls.typeCode = CONCERNROLEALTERNATEID.REFERENCE_NUMBER;
    // END, CR00097704
    concernRoleAlternateIDDtls.startDate = concernRoleDtls.startDate;
    concernRoleAlternateIDDtls.endDate = Date.kZeroDate;
    concernRoleAlternateIDDtls.statusCode = RECORDSTATUS.NORMAL;
    concernRoleAlternateIDDtls.comments = "";

    ConcernRoleAlternateID concernRoleAlternateIDObj = ConcernRoleAlternateIDFactory.newInstance();

    concernRoleAlternateIDObj.insert(concernRoleAlternateIDDtls);

    // Insert concern role address details
    MaintainConcernRoleAddress maintainConcernRoleAddressObj = MaintainConcernRoleAddressFactory.newInstance();
    MaintainAddressKey maintainAddressKey = new MaintainAddressKey();

    maintainAddressKey.concernRoleID = concernRoleDtls.concernRoleID;
    addressDetails.concernRoleID = concernRoleDtls.concernRoleID;

    maintainConcernRoleAddressObj.createAddress(maintainAddressKey,
      addressDetails);

    // Insert phone details
    if (validatePhoneNumber(concernRolePhoneDetails)) {

      MaintainConcernRolePhone maintainConcernRolePhoneObj = MaintainConcernRolePhoneFactory.newInstance();
      MaintainPhoneNumberKey maintainPhoneNumberKey = new MaintainPhoneNumberKey();

      maintainPhoneNumberKey.concernRoleID = concernRoleDtls.concernRoleID;
      concernRolePhoneDetails.concernRoleID = concernRoleDtls.concernRoleID;

      // insert concernRolePhoneNumber
      maintainConcernRolePhoneObj.createPhoneNumber(maintainPhoneNumberKey,
        concernRolePhoneDetails);

    }
    // create provider owner and supervisor
    MaintainAdminConcernRole maintainAdminConcernRole = new MaintainAdminConcernRole();
    ConcernRoleAndUserNameDetails concernRoleAndUserNameDetails = new ConcernRoleAndUserNameDetails();

    concernRoleAndUserNameDetails.concernRoleID = concernRoleDtls.concernRoleID;
    concernRoleAndUserNameDetails.userName = TransactionInfo.getProgramUser();

    maintainAdminConcernRole.setProviderOrganisationOwnerAndSupervisor(
      concernRoleAndUserNameDetails);

    // Insert bank account details
    // BEGIN, CR00379189, SS
    if ((bankAccountDetails.name.trim().length()
      + bankAccountDetails.typeCode.trim().length()
      + bankAccountDetails.accountNumber.trim().length()
      + bankAccountDetails.bankBranchName.trim().length()
      + bankAccountDetails.bankSortCode.trim().length()
      + bankAccountDetails.ibanOpt.length()
      + bankAccountDetails.bicOpt.length())
        != 0) {
      // END, CR00379189
      // allowing the bankAccount entity to handle errors in missing
      // bank account information
      MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = MaintainConcernRoleBankAcFactory.newInstance();
      MaintainBankAccountKey maintainBankAccountKey = new MaintainBankAccountKey();

      maintainBankAccountKey.concernRoleID = concernRoleDtls.concernRoleID;
      maintainConcernRoleBankAcObj.createBankAccount(maintainBankAccountKey,
        bankAccountDetails);
    }

    // BEGIN, CR00235789, AK
    // Raise the post enroll provider event.
    enrollEventDispatcherFactory.get(ProviderEnrollEvents.class).postEnroll(
      this, concernRoleDtls, addressDetails, concernRolePhoneDetails,
      bankAccountDetails);
    // END, CR00235789
  }

  /**
   * This method validates concern details fields.
   *
   * @param concernDtls
   * contains ConcernDtls.
   *
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void validateConcernFields(ConcernDtls concernDtls)
    // END, CR00177241
    throws InformationalException {

    // Name Not Entered.
    if (StringHelper.isEmpty(concernDtls.name)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_NAME_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }

    // BEGIN, CR00313985, SK
    // Name Greater Than 56 Characters.
    if (concernDtls.name.length() > ProviderAdapter.kMaxLength_name) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_NAME_IS_TOO_LONG(
          ProviderAdapter.kMaxLength_name),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          3);
    }

    // BEGIN, CR00274149, GP
    int length = concernDtls.name.toUpperCase().length();

    if (ProviderAdapter.kMaxLength_name < length) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_NAME_EXCEEDS_MAXLIMIT(length,
        ProviderAdapter.kMaxLength_name),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
        1);
    }
    // END, CR00274149
    // END, CR00313985
    
    ValidationHelper.failIfErrorsExist();
  }

  /**
   * This method validates concern role mandatory fields.
   *
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void validateConcernRoleFields() throws InformationalException {
    // END, CR00177241
    // Preferred Language Not Entered.
    if (LANGUAGEEntry.get(concernRoleDtls.preferredLanguage).equals(
      LANGUAGEEntry.NOT_SPECIFIED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_PREFERRED_LANGUAGE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);

    }
    // Preferred Communication Not Entered.
    if (COMMUNICATIONMETHODEntry.get(concernRoleDtls.prefCommMethod).equals(
      COMMUNICATIONMETHODEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_PREFERRED_COMMUICATION_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }

    // Comments Greater Than Two Hundred Characters.
    if (concernRoleDtls.comments.length()
      > ConcernRoleAdapter.kMaxLength_comments) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_COMMENT_IS_TOO_LONG(
          ConcernRoleAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }
    ValidationHelper.failIfErrorsExist();

  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// cross entity validation.
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {
    setState(OPEN);
    // BEGIN, CR00178272, AK
    // Creating new instances for all the localized text handler class objects.
    areasServedInfoLocalizableText = localizableTextHandlerDAO.newInstance();
    clientInfoLocalizableText = localizableTextHandlerDAO.newInstance();
    // END, CR00178272
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// cross field validation
  }

  /**
   * Validates that all mandatory fields are "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.CPMCOMMONMESSAGES#
   * ERR_CPMCOMMONMSG_XRV_PAYMENT_METHOD_MUST_BE_ENTERED} -
   * If Method Of Payment not entered. </li>
   * <li>
   * {@link curam.message.CPMCOMMONMESSAGES#
   * ERR_CPMCOMMONMSG_XRV_PAYMENT_FREQUENCY_MUST_BE_ENTERED} -
   * If Payment Frequency not entered. </li>
   * <li>
   * {@link curam.message.CPMCOMMONMESSAGES#
   * ERR_CPMCOMMONMSG_XRV_CURRENCY_MUST_BE_ENTERED} -
   * If Currency Type not entered. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    // Method Of Payment Not Entered.
    if (getDtls().methodOfPayment == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_PAYMENT_METHOD_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Payment Frequency Not Entered.
    if (FrequencyPattern.kZeroFrequencyPattern.equals(
      new FrequencyPattern(getDtls().paymentFrequency))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_PAYMENT_FREQUENCY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Currency Type Not Entered.
    if (GeneralConstants.kEmpty.equals(getDtls().currencyType)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_CURRENCY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * This method validates the provider phone details.
   *
   * @param concernRolePhoneDetails
   * contains ConcernRolePhoneDetails
   * @return boolean validates the phone number and return boolean value.
   */
  // BEGIN, CR00177241, PM
  protected boolean validatePhoneNumber(
    // END, CR00177241
    ConcernRolePhoneDetails concernRolePhoneDetails) throws AppException {

    // Phone number and phone type must be entered
    if ((concernRolePhoneDetails.phoneAreaCode.length() > 0
      || concernRolePhoneDetails.phoneCountryCode.length() > 0
      || concernRolePhoneDetails.phoneExtension.length() > 0)
        && (concernRolePhoneDetails.phoneNumber.length() == 0
          && concernRolePhoneDetails.typeCode.length() == 0)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOMAINTAINCONCERNROLEPHONEExceptionCreator.ERR_CONCERNROLEPHONE_XFV_PHONENUMBER_PHONETYPE_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if ((concernRolePhoneDetails.typeCode.length() == 0)
      && (concernRolePhoneDetails.phoneNumber.length() != 0)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOMAINTAINCONCERNROLEPHONEExceptionCreator.ERR_CONCERNROLEPHONE_XFV_PHONETYPE_PHONENUMBER(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if ((concernRolePhoneDetails.phoneNumber.length() == 0)
      && (concernRolePhoneDetails.typeCode.length() != 0)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOMAINTAINCONCERNROLEPHONEExceptionCreator.ERR_CONCERNROLEPHONE_XFV_PHONENUMBER_PHONETYPE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if ((concernRolePhoneDetails.phoneNumber.length() != 0)
      && ((concernRolePhoneDetails.typeCode.length() != 0))
      && (concernRolePhoneDetails.phoneAreaCode.length() == 0)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOMAINTAINCONCERNROLEPHONEExceptionCreator.ERR_CONCERNROLEPHONE_XFV_PHONEAREACODE_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if ((concernRolePhoneDetails.typeCode.length() != 0)
      && (concernRolePhoneDetails.phoneNumber.length() != 0)) {

      return true;
    }

    return false;
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderCategoryPeriod> getProviderCategoryPeriods() {
    return Collections.unmodifiableSet(providerCategoryPeriodDAO.searchBy(this));
  }

  /**
   * {@inheritDoc}
   */
  public ProviderCategoryPeriod getPrimaryProviderCategoryPeriod() {
    return providerCategoryPeriodDAO.readPrimaryCategoryFor(this);
  }

  /**
   * Returns all the compartments for the provider
   *
   * @return Set Compartment
   */
  public Set<Compartment> getCompartments() {
    return Collections.unmodifiableSet(
      compartmentDAO.searchAllCompartments(this));
  }

  // BEGIN, CR00260960, GP
  /**
   * Returns the Places which are available at the specified date range.
   *
   * @param dateRange
   * Contains start date and end date.
   *
   * @return Set of Places matched for the date range.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since 6.0 SP1, replaced by {@link ProviderImpl#
   * getAvailablePlacesInDateTimeRange(DateTimeRange)} as part of fixing making 
   * a place that is just made available to be displayed in the search list of 
   * available places.
   * See release note : CR00260960.
   */
  @Deprecated  
  public Set<Place> getAvailablePlacesInDateRange(DateRange dateRange)
    throws AppException, InformationalException {
    // END, CR00260960

    // BEGIN, CR00235789, AK
    // Raise the pre getAvailablePlacesInDateRange provider event.
    getAvailablePlacesInDateRangeEventDispatcherFactory.get(ProviderGetAvailablePlacesInDateRangeEvents.class).preGetAvailablePlacesInDateRange(
      this, dateRange);
    // END, CR00235789

    PlaceByDateDetails placeByDateDetails = new PlaceByDateDetails();

    placeByDateDetails.providerConcernRoleID = getDtls().providerConcernRoleID;
    placeByDateDetails.startDate = dateRange.start();
    placeByDateDetails.endDate = dateRange.end();

    // BEGIN, CR00177555, NS
    placeByDateDetails.placementStartDateTime = placeByDateDetails.startDate.getDateTime();
    if (!placeByDateDetails.endDate.isZero()) {
      placeByDateDetails.placementEndDateTime = placeByDateDetails.endDate.getDateTime();
    }
    placeByDateDetails.placementStatus = RECORDSTATUS.NORMAL;
    placeByDateDetails.recordStatus = RECORDSTATUS.NORMAL;
    // END, CR00177555

    // If end Date not entered by user.
    if (!dateRange.end().isZero()) {
      placeByDateDetails.endDateEntered = true;
    }
    Set<Compartment> providerCompartments = getCompartments();
    Set<Place> allAvailablePlaces = new HashSet<Place>();

    // Get Available places for each compartment.
    for (Compartment compartment : providerCompartments) {
      placeByDateDetails.compartmentID = compartment.getID();

      // BEGIN, CR00177555, NS
      Set<Place> placeList = placeDAO.searchAvailablePlacesForCompartmentInDateTimeRange(
        placeByDateDetails);

      // END, CR00177555

      allAvailablePlaces.addAll(placeList);
    }

    // BEGIN, CR00235789, AK
    // Raise the post getAvailablePlacesInDateRange provider event.
    getAvailablePlacesInDateRangeEventDispatcherFactory.get(ProviderGetAvailablePlacesInDateRangeEvents.class).postGetAvailablePlacesInDateRange(
      this, dateRange, allAvailablePlaces);
    // END, CR00235789

    return Collections.unmodifiableSet(allAvailablePlaces);
  }

  // BEGIN, CR00260960, GP
  /**
   * Returns the places which are available at the specified date time range.
   *
   * @param dateTimeRange
   * Contains start date time and end date time.
   *
   * @return Set of places matched for the date time range.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public Set<Place> getAvailablePlacesInDateTimeRange(DateTimeRange dateTimeRange)
    throws AppException, InformationalException {

    PlaceByDateDetails placeByDateDetails = new PlaceByDateDetails();
    DateRange dateRange = new DateRange(new Date(dateTimeRange.start()),
      new Date(dateTimeRange.end()));
   
    // Raise the pre getAvailablePlacesInDateRange provider event.
    getAvailablePlacesInDateRangeEventDispatcherFactory.get(ProviderGetAvailablePlacesInDateRangeEvents.class).preGetAvailablePlacesInDateRange(
      this, dateRange);

    placeByDateDetails.providerConcernRoleID = getDtls().providerConcernRoleID;
    placeByDateDetails.startDate = new Date(dateTimeRange.start());
    placeByDateDetails.endDate = new Date(dateTimeRange.end());

    placeByDateDetails.placementStartDateTime = dateTimeRange.start();
    
    // If end Date not entered by user.
    if (!placeByDateDetails.endDate.isZero()) {
      placeByDateDetails.placementEndDateTime = dateTimeRange.end();
      placeByDateDetails.endDateEntered = true;
    }
    placeByDateDetails.placementStatus = RECORDSTATUS.NORMAL;
    placeByDateDetails.recordStatus = RECORDSTATUS.NORMAL;

    Set<Compartment> providerCompartments = getCompartments();
    Set<Place> allAvailablePlaces = new HashSet<Place>();

    // Get Available places for each compartment.
    for (Compartment compartment : providerCompartments) {
      placeByDateDetails.compartmentID = compartment.getID();

      Set<Place> placeList = placeDAO.searchAvailablePlacesForCompartmentInDateTimeRange(
        placeByDateDetails);

      allAvailablePlaces.addAll(placeList);
    }

    // Raise the post getAvailablePlacesInDateRange provider event.
    getAvailablePlacesInDateRangeEventDispatcherFactory.get(ProviderGetAvailablePlacesInDateRangeEvents.class).postGetAvailablePlacesInDateRange(
      this, dateRange, allAvailablePlaces);

    return Collections.unmodifiableSet(allAvailablePlaces);
  }

  // END, CR00260960
  
  /**
   * Gets the payment frequency for the Provider.
   *
   * @return The payment frequency for the Provider.
   */
  public String getPaymentFrequency() {
    return getDtls().paymentFrequency;
  }

  /**
   * Gets the method of payment for the Provider.
   *
   * @return The method of payment for the Provider.
   */
  public long getMethodOfPayment() {
    return getDtls().methodOfPayment;
  }

  /**
   * Gets the currency type.
   *
   * @return The currency type.
   */
  public CURRENCYEntry getCurrencyType() {
    return CURRENCYEntry.get(getDtls().currencyType);
  }

  /**
   * {@inheritDoc}
   */
  public void setPhysicalCapacity(int value) {
    getDtls().physicalCapacity = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setPaymentFrequency(String value) {
    getDtls().paymentFrequency = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setMethodOfPayment(long value) {
    getDtls().methodOfPayment = value;

  }

  /**
   * {@inheritDoc}
   */
  public void setCurrencyType(CURRENCYEntry value) {
    getDtls().currencyType = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderEnquiry(ProviderEnquiry value) {
    getDtls().providerEnquiryID = value.getID();
  }

  /**
   * {@inheritDoc}
   */
  public Set<ServiceOffering> getServiceOfferings() {

    // BEGIN, CR00235789, AK
    // Raise the pre getServiceOfferings provider event.
    getServiceOfferingsEventDispatcherFactory.get(ProviderGetServiceOfferingsEvents.class).preGetServiceOfferings(
      this);
    // END, CR00235789

    final Set<ProviderOffering> providerOfferings = getProviderOfferings();

    final Set<ServiceOffering> serviceOfferings = new HashSet<ServiceOffering>(
      providerOfferings.size());

    for (final ProviderOffering providerOffering : providerOfferings) {
      serviceOfferings.add(providerOffering.getServiceOffering());
    }

    // BEGIN, CR00235789, AK
    // Raise the post getServiceOfferings provider event.
    // END, CR00235789
    getServiceOfferingsEventDispatcherFactory.get(ProviderGetServiceOfferingsEvents.class).postGetServiceOfferings(
      this, serviceOfferings);

    return Collections.unmodifiableSet(serviceOfferings);
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderOffering> getProviderOfferings() {
    return Collections.unmodifiableSet(providerOfferingDAO.searchBy(this));
  }

  /**
   * Gets the physical capacity. Defines the actual capacity of the provider
   *
   * @return The actual capacity of the provider.
   */
  public int getPhysicalCapacity() {
    return getDtls().physicalCapacity;
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderBackgroundCheck> getProviderBackgroundChecks() {
    return Collections.unmodifiableSet(
      providerBackgroundCheckDAO.searchBy(this));
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderAccreditation> getAccreditations() {
    return Collections.unmodifiableSet(providerAccreditationDAO.searchBy(this));
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderServiceCenter> getProviderServiceCenters() {
    return Collections.unmodifiableSet(providerServiceCenterDAO.searchBy(this));
  }

  /**
   * {@inheritDoc}
   */
  public Set<HomeStudy> getHomeStudies() {
    return Collections.unmodifiableSet(homeStudyDAO.searchByProvider(this));
  }

  /**
   * {@inheritDoc}
   */
  public Set<ServiceOffering> getCommonApprovedProviderServiceOfferings(
    final ContractVersion contractVersion) {

    // BEGIN, CR00235789, AK
    // Raise the pre getCommonApprovedProviderServiceOfferings provider event.
    getCommonApprovedProviderServiceOfferingsEventDispatcherFactory.get(ProviderGetCommonApprovedProviderServiceOfferingsEvents.class).preGetCommonApprovedProviderServiceOfferings(
      this, contractVersion);
    // END, CR00235789

    /*
     * For a provider, the approved offerings are those which are linked
     * directly to the contract
     */
    final Set<ServiceOffering> commonApprovedProviderServiceOfferings = new HashSet<ServiceOffering>();

    for (final ProviderOffering providerOffering : contractVersion.getProviderOfferings()) {

      if (providerOffering.getLifecycleState().equals(
        ProviderOfferingStatusEntry.APPROVED)) {
        commonApprovedProviderServiceOfferings.add(
          providerOffering.getServiceOffering());
      }
    }

    // BEGIN, CR00235789, AK
    // Raise the post getCommonApprovedProviderServiceOfferings provider event.
    getCommonApprovedProviderServiceOfferingsEventDispatcherFactory.get(ProviderGetCommonApprovedProviderServiceOfferingsEvents.class).postGetCommonApprovedProviderServiceOfferings(
      this, contractVersion, commonApprovedProviderServiceOfferings);
    // END, CR00235789

    return Collections.unmodifiableSet(commonApprovedProviderServiceOfferings);
  }

  /**
   * Validates and modify the Provider details.
   *
   * @throws InformationalException
   * {@link
   * curam.message.CPMCOMMONMESSAGES#
   * ERR_CPMCOMMONMSG_XRV_RECORD_CANNOT_MODIFY_THIS_RECORD_ALREADY_BEEN_DELETED}
   * - If the Provider record is already deleted.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#
   * ERR_PROVIDER_FV_NAME_MUST_BE_ENTERED}
   * - If the Provider name is not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_FV_NAME_IS_TOO_LONG} -
   * If the length of the Provider name is greater than the maximum
   * length.
   */
  @Override
  public void modify() throws InformationalException {

    validateModifyDetails();
    super.modify();
  }

  /**
   * This method validates the provider details for modification.
   */
  // BEGIN, CR00177241, PM
  protected void validateModifyDetails() throws InformationalException {
    // END, CR00177241
    // Cannot modify Closed provider
    if (ProviderStatusEntry.CLOSED.getCode().equals(
      getRowManager().getOriginalDtls().recordStatus)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_RECORD_CANNOT_MODIFY_THIS_RECORD_ALREADY_BEEN_DELETED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }

    if (concernRoleDtls == null) {
      concernRoleDtls = concernRoleAdapter.read(getDtls().providerConcernRoleID,
        false);
    }

    // Name Not Entered.
    if (StringHelper.isEmpty(concernRoleDtls.concernRoleName)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_NAME_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
    }

    // Name Greater Than 56 Characters.
    if (concernRoleDtls.concernRoleName.length()
      > ConcernRoleAdapter.kMaxLength_concernRoleName) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_NAME_IS_TOO_LONG(
          ConcernRoleAdapter.kMaxLength_concernRoleName),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }
    validateConcernRoleFields();

    // validateProviderCategoryDetails();

    ValidationHelper.failIfErrorsExist();
  }

  /**
   * Modifies the provider with the updated information. Also raises a workflow
   * event.
   *
   * Checks the provider security to modify the provider.
   *
   * @param versionNo
   * Contains the version.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#
   * ERR_PROVIDER_FV_NAME_MUST_BE_ENTERED} -
   * If the Provider name is not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_FV_NAME_IS_TOO_LONG} -
   * If the length of the Provider name is greater than the maximum
   * length.
   * @throws InformationalException
   * {@link curam.message.CPMCOMMONMESSAGES#
   * ERR_CPMCOMMONMSG_XRV_RECORD_CANNOT_MODIFY_THIS_RECORD_ALREADY_BEEN_DELETED} -
   * If the Provider record is already deleted.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(this);

    // BEGIN, CR00235789, AK
    // Raise the pre modify provider event.
    modifyEventDispatcherFactory.get(ProviderModifyEvents.class).preModify(this,
      versionNo);
    // END, CR00235789

    validateModifyDetails();

    // BEGIN, CR00178272, AK
    // Store any localized text changes before updating the parent.
    storeLocalizableText();
    // END, CR00178272
    
    // BEGIN, CR00274149, GP    
    getDtls().name = concernRoleDtls.concernRoleName;
    getDtls().nameUpper = concernRoleDtls.concernRoleName.toUpperCase();
    // END, CR00274149

    super.modify(versionNo);

    // raise the modify event.
    final Event event = new Event();

    event.eventKey = PROVIDER.PROVIDER_MODIFIED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post modify provider event.
    modifyEventDispatcherFactory.get(ProviderModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre insert provider event.
    insertEventDispatcherFactory.get(ProviderInsertEvents.class).preInsert(this);
    // END, CR00235789

    // BEGIN, CR00178272, AK
    // Store the localized text before storing the parent.
    storeLocalizableText();
    // END, CR00178272

    super.insert();

    // raise the insert event
    final Event event = new Event();

    event.eventKey = PROVIDER.PROVIDER_INSERTED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post insert provider event.
    insertEventDispatcherFactory.get(ProviderInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected ConcernRoleDtls getConcernRoleDtls() {
    return concernRoleAdapter.read(getDtls().providerConcernRoleID, false);
  }

  /**
   * {@inheritDoc}
   */
  public Set<ServiceInvoiceLineItem> getServiceInvoiceLineItems() {
    return Collections.unmodifiableSet(
      serviceInvoiceLineItemDAO.searchByProvider(this));
  }

  /**
   * {@inheritDoc}
   */
  public SENSITIVITYEntry getSensitivity() {
    return SENSITIVITYEntry.get(getConcernRoleDtls().sensitivity);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderEnquiry getProviderEnquiry() {
    return getDtls().providerEnquiryID == 0
      ? null
      : providerEnquiryDAO.get(getDtls().providerEnquiryID);
  }

  // BEGIN, CR00106630, JSP
  /**
   * {@inheritDoc}
   */
  public short getReservationGracePeriod() {
    return getDtls().reservationGracePeriod;
  }

  /**
   * {@inheritDoc}
   */
  public void setReservationGracePeriod(short value) {

    getDtls().reservationGracePeriod = value;

  }

  // END, CR00106630

  // BEGIN, CR00115516, SG
  /**
   * {@inheritDoc}
   */
  public boolean isAttendanceTrackingEnabled() {

    Set<ProviderAttendanceTracking> providerAttendanceTracking = providerAttendanceTrackingDAO.searchByProvider(
      this);

    // If attendance tracking record exists then attendance tracking is enabled
    // for the provider.
    if (providerAttendanceTracking.size() > 0) {
      return true;
    }
    return false;
  }

  /**
   * {@inheritDoc}
   */
  public boolean isPaperRosterRequired() {
    Set<ProviderAttendanceTracking> providerAttendanceTracking = providerAttendanceTrackingDAO.searchByProvider(
      this);

    // There can be only one configuration for a provider, if it exists return
    // the same.
    for (final ProviderAttendanceTracking
      attendanceTrackingConfig : providerAttendanceTracking) {
      return attendanceTrackingConfig.isPaperRosterRequired();
    }
    return false;
  }

  // END, CR00115516

  // BEGIN, CR00115506, END
  /**
   * {@inheritDoc}
   */
  public boolean isProviderApproved() {
    return getLifecycleState().equals(ProviderStatusEntry.APPROVED)
      ? true
      : false;
  }

  // END, CR00115506

  // BEGIN, CR00123437, RPB
  /**
   * {@inheritDoc}
   */
  public long getResourceID() {
    return getDtls().providerConcernRoleID;
  }

  /**
   * {@inheritDoc}
   */
  public WAITLISTTYPEEntry getResourceType() {
    return WAITLISTTYPEEntry.PROVIDER;
  }

  // END, CR00123437

  // BEGIN, CR00123182, GP
  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00132242, GP
  public boolean isOverrideMDR() {
    return getDtls().overrideMDRInd;
  }

  // END, CR00132242

  /**
   * {@inheritDoc}
   */
  public void setOverrideMDRInd(boolean overrideMDRInd) {
    getDtls().overrideMDRInd = overrideMDRInd;
  }

  // END, CR00123182

  // BEGIN, CR00178272
  /**
   * {@inheritDoc}
   */
  public PREFERREDSERVICEENQUIRYMETHODEntry getPreferredServiceEnquiryMethod() {
    return PREFERREDSERVICEENQUIRYMETHODEntry.get(getDtls().preferredSEMethod);
  }

  /**
   * {@inheritDoc}
   */
  public void setPreferredServiceEnquiryMethod(
    PREFERREDSERVICEENQUIRYMETHODEntry value) {
    getDtls().preferredSEMethod = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public LocalizableText getAreasServedInfo() {
    if (null == areasServedInfoLocalizableText) {
      areasServedInfoLocalizableText = localizableTextHandlerDAO.get(
        getDtls().areasSvdInfoTxtID);
    }
    return areasServedInfoLocalizableText;
  }

  /**
   * {@inheritDoc}
   */
  public LocalizableText getClientInfo() {
    if (null == clientInfoLocalizableText) {
      clientInfoLocalizableText = localizableTextHandlerDAO.get(
        getDtls().clientInfoTextID);
    }
    return clientInfoLocalizableText;
  }

  /**
   * {@inheritDoc}
   */
  public long getAreasServedInfoTextID() {
    return getDtls().areasSvdInfoTxtID;
  }

  /**
   * {@inheritDoc}
   */
  public long getClientInfoTextID() {
    return getDtls().clientInfoTextID;
  }

  /**
   * {@inheritDoc}
   */
  public void setAreasServedInfoTextID(long value) {
    getDtls().areasSvdInfoTxtID = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setClientInfoTextID(long value) {
    getDtls().clientInfoTextID = value;
  }

  /**
   * Stores any LocalizableText records associated with the provider.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void storeLocalizableText() throws InformationalException {
    // END, CR00177241
    // Only store the details if there are changes waiting to be written.
    if (areasServedInfoLocalizableText != null) {
      getDtls().areasSvdInfoTxtID = areasServedInfoLocalizableText.store();
    }

    if (clientInfoLocalizableText != null) {
      getDtls().clientInfoTextID = clientInfoLocalizableText.store();
    }
  }

  // END, CR00178272

  // BEGIN, CR00197073, ASN
  // BEGIN, CR00199682, ASN
  /**
   * {@inheritDoc}
   */
  public List<ProviderMembersBackgroundCheckDetails> readProviderMembersBackGroundCheckDetails() throws AppException,
      InformationalException {

    Map<Long, ProviderMembersBackgroundCheckDetails> checkDuplicateMap = new HashMap<Long, ProviderMembersBackgroundCheckDetails>();
    // END, CR00199682
    ProviderMembersBackgroundCheckDetailsList providerMembersBackgroundCheckDetailsList = providerDAO.searchProviderMembersBackgroundCheckDetails(
      this);
    // BEGIN, CR00199682, ASN
    List<ProviderMembersBackgroundCheckDetails> providerMemberDetailsList = new ArrayList<ProviderMembersBackgroundCheckDetails>();

    // END, CR00199682
    if (0 == providerMembersBackgroundCheckDetailsList.dtls.size()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_NO_PROVIDER_MEMBER_FOUND(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }
    // BEGIN, CR00199682, ASN
    for (final ProviderMembersBackgroundCheckDetails providerMembersBackgroundCheckDetails : providerMembersBackgroundCheckDetailsList.dtls.items()) {

      if (!checkDuplicateMap.containsKey(
        providerMembersBackgroundCheckDetails.concernRoleID)) {

        checkDuplicateMap.put(
          providerMembersBackgroundCheckDetails.concernRoleID,
          providerMembersBackgroundCheckDetails);

        if (StringHelper.isEmpty(providerMembersBackgroundCheckDetails.result)) {

          providerMembersBackgroundCheckDetails.backgroundCheckInd = false;

        } else {

          providerMembersBackgroundCheckDetails.backgroundCheckInd = true;
        }

        providerMemberDetailsList.add(providerMembersBackgroundCheckDetails);
        // END, CR00199682
      }

    }
    return providerMemberDetailsList;
  }

  // END, CR00197073

  // BEGIN, CR00197964, RPB
  // BEGIN, CR00198774, RPB
  // BEGIN, CR00200254, RPB
  /**
   * {@inheritDoc}
   */
  public DateTimeRange getDateTimeRange() {

    DateTimeRange value = null;

    // Check if value exists for the new columns.If not, read from the old
    // columns i.e startDate and endDate.

    DateTime startDateTime;
    DateTime endDateTime;

    if (getDtls().enrollmentDateTime.equals(DateTime.kZeroDateTime)
      && getDtls().endDateTime.equals(DateTime.kZeroDateTime)) {
      startDateTime = super.getStartDate().getDateTime();
      endDateTime = super.getEndDate().getDateTime();
    } else {
      startDateTime = getDtls().enrollmentDateTime;
      endDateTime = getDtls().endDateTime;
    }
    value = new DateTimeRange(startDateTime, endDateTime);

    return value;
  }

  // END, CR00200254

  /**
   * Converts the given calendar to a client time zone equivalent calendar. The
   * client time zone is obtained from the transaction info.
   *
   * @param inputDateTime
   * Input calendar to be converted to the client time zone calendar.
   *
   * @return The Calendar representing the client time zone equivalent of the
   * input calendar.
   */

  protected Calendar convertToClientTimeZone(final Calendar inputDateTime) {
    Calendar outPutDateTime = new GregorianCalendar(
      TransactionInfo.getUserTimeZone());

    outPutDateTime.setTimeInMillis(inputDateTime.getTimeInMillis());
    return outPutDateTime;
  }

  // BEGIN, CR00200254, RPB
  /**
   * {@inheritDoc}
   */
  public void setDateTimeRange(final DateTimeRange value) {

    // Validate date range.
    value.validateRange();
    value.validateStarted();

    // Recording the enrollment date as a date time on the database using the
    // time zone of the user and defaulting to the midnight on the day of
    // enrollment in that time zone.
    Calendar clientTimeZoneCalendarStart = new GregorianCalendar(
      TransactionInfo.getUserTimeZone());

    Calendar clientCalendarStart = value.start().getCalendar();

    clientTimeZoneCalendarStart.setTimeInMillis(
      clientCalendarStart.getTimeInMillis());

    clientTimeZoneCalendarStart.set(Calendar.HOUR_OF_DAY, 00);
    clientTimeZoneCalendarStart.set(Calendar.MINUTE, 00);
    clientTimeZoneCalendarStart.set(Calendar.SECOND, 00);

    // Converting the enrollment date to server time zone before storing.
    DateTime startDateTime = new DateTime(
      clientTimeZoneCalendarStart.getTimeInMillis());

    DateTime endDateTime = value.end();

    if (!DateTime.kZeroDateTime.equals(value.end())) {
      // Recording the provider end date as a date time on the database using
      // the
      // time zone of the user and defaulting to the last minute of the day of
      // provider end.
      Calendar clientTimeZoneCalendarEnd = new GregorianCalendar(
        TransactionInfo.getUserTimeZone());

      Calendar clientCalendarEnd = value.end().getCalendar();

      clientTimeZoneCalendarEnd.setTimeInMillis(
        clientCalendarEnd.getTimeInMillis());

      clientTimeZoneCalendarEnd.set(Calendar.HOUR_OF_DAY,
        CPMConstants.kLastHourOfDay);
      clientTimeZoneCalendarEnd.set(Calendar.MINUTE,
        CPMConstants.kLastMinuteOfHour);
      clientTimeZoneCalendarEnd.set(Calendar.SECOND,
        CPMConstants.kLastSecondOfMinute);

      // Converting the enrollment date to server time zone before storing.
      endDateTime = new DateTime(clientTimeZoneCalendarEnd.getTimeInMillis());
    }

    getDtls().enrollmentDateTime = startDateTime;
    getDtls().endDateTime = endDateTime;
  }

  /**
   * Returns the registration date of the provider.This method on ConcernRole
   * Accessor is overridden to point to the new columns of start date time and
   * end date time.
   *
   * @return The Registration date of the Provider.
   */
  @Override
  public Date getRegistrationDate() {
    return getDateRange().start();
  }

  /**
   * Returns the start date of the provider.This method on ConcernRole
   * Accessor is overridden to point to the new columns of start date time and
   * end date time.
   *
   * @return The start date of the Provider.
   */
  @Override
  public Date getStartDate() {
    return new Date(getDateTimeRange().start());
  }

  /**
   * Returns the end date of the provider.This method on ConcernRole
   * Accessor is overridden to point to the new columns of start date time and
   * end date time.
   *
   * @return The end date of the Provider.
   */
  @Override
  public Date getEndDate() {
    return getDateRange().end();
  }

  // END, CR00197964
  // END, CR00198774

  /**
   * Gets the start date and the end date of the Provider.
   *
   * @return The start date and the end date of the Provider in the client time
   * zone.
   */
  protected DateRange getDateRange() {

    // If values do not exist for the newly introduced columns, get the values
    // from the old column.
    if (getDtls().enrollmentDateTime.equals(DateTime.kZeroDateTime)
      && getDtls().endDateTime.equals(DateTime.kZeroDateTime)) {
      return new DateRange(getConcernRoleDtls().registrationDate,
        getConcernRoleDtls().endDate);
    }

    Calendar clientStartDateTime = convertToClientTimeZone(
      getDtls().enrollmentDateTime.getCalendar());
    Calendar clientEndDateTime = getDtls().endDateTime.getCalendar();

    if (!DateTime.kZeroDateTime.equals(getDtls().endDateTime)) {
      clientEndDateTime = convertToClientTimeZone(
        getDtls().endDateTime.getCalendar());
    }
    return new DateRange(new Date(clientStartDateTime),
      new Date(clientEndDateTime));
  }

  // END, CR00200254

  // BEGIN, CR00228236, SK
  /**
   * {@inheritDoc}
   */
  public void checkSecurity() throws InformationalException {

    try {
      DataBasedSecurityResult dataBasedSecurityResult = checkConcernRoleSecurity();

      validateConcernRoleSecurityResult(dataBasedSecurityResult);
    } catch (AppException e) {
      ValidationHelper.addValidationError(e);
      ValidationHelper.failIfErrorsExist();
    }
  }

  /**
   * Validates the result of the concern role security and location check
   * ensuring the user has access rights for viewing this concern role.
   * <p>
   * If the result of the security check is false then the user does not have
   * access rights to view this concern role and an exception is thrown.
   * </p>
   *
   * @param dataBasedSecurityResult
   * the object containing the results from the security check
   * @throws InformationalException
   * {@link GENERALCONCERNExceptionCreator#ERR_CONCERNROLE_FV_SENSITIVE()}
   * if the user does not have access rights to view this concern role
   */
  protected void validateConcernRoleSecurityResult(
    final DataBasedSecurityResult dataBasedSecurityResult)
    throws InformationalException {

    if (!dataBasedSecurityResult.result) {
      ValidationHelper.addValidationError(
        GENERALCONCERNExceptionCreator.ERR_CONCERNROLE_FV_SENSITIVE());
      ValidationHelper.failIfErrorsExist();
    }
  }

  /**
   * Performs the security check for this concern role.
   *
   * @return An object containing the result of the security check
   * @throws AppException
   * Generic Application Exception
   * @throws InformationalException
   * Generic Informational Exception
   */
  protected DataBasedSecurityResult checkConcernRoleSecurity()
    throws AppException, InformationalException {
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    ParticipantSecurityCheckKey key = new ParticipantSecurityCheckKey();

    key.participantID = getID();
    key.type = LOCATIONACCESSTYPE.READ;

    return dataBasedSecurity.checkParticipantSecurity(key);
  }

  // END, CR00228236

  /**
   * {@inheritDoc}
   */
  public boolean getAcceptsCWReferral() {
    return getDtls().acceptCWReferral;
  }

  /**
   * {@inheritDoc}
   */
  public void setAcceptsCWReferral(boolean acceptReferral) {
    getDtls().acceptCWReferral = acceptReferral;

  }

  // BEGIN, CR00291801, ASN

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDetailsList listInvestigationsForProvider(
    final ProviderConcernRoleKey providerConcernRoleKey) throws AppException,
      InformationalException {

    Map<Long, ProviderInvestigationDetails> checkDuplicateCase = new HashMap<Long, ProviderInvestigationDetails>();

    ProviderInvestigationDetailsList providerInvestigationDetailsList = providerDAO.readProviderInvestigations(
      providerConcernRoleKey.providerConcernRoleID,
      CASETYPECODEEntry.INVESTIGATIONCASE, RECORDSTATUSEntry.NORMAL,
      CASEPARTICIPANTROLETYPEEntry.ALLEGATIONREPORTER);

    ProviderInvestigationDetailsList providerInvestigationDetailsReturnList = new ProviderInvestigationDetailsList();

    for (final ProviderInvestigationDetails providerInvestigationDetails : providerInvestigationDetailsList.dtls.items()) {
      if (providerInvestigationDetails.participantRoleType.startsWith(
        CPMConstants.KAllegationRoleType)) {

        providerInvestigationDetails.participantRoleType = ALLEGATIONROLETYPEEntry.get(providerInvestigationDetails.participantRoleType).toUserLocaleString();

      } else {

        providerInvestigationDetails.participantRoleType = CASEPARTICIPANTROLETYPEEntry.get(providerInvestigationDetails.participantRoleType).toUserLocaleString();
      }

      if (!checkDuplicateCase.containsKey(providerInvestigationDetails.caseID)) {

        checkDuplicateCase.put(providerInvestigationDetails.caseID,
          providerInvestigationDetails);

        ProviderInvestigationDetails providerInvestigation = new ProviderInvestigationDetails();

        providerInvestigation.assign(providerInvestigationDetails);
        providerInvestigationDetailsReturnList.dtls.add(
          providerInvestigationDetails);

      } else {

        ProviderInvestigationDetails ProviderInvestigationForMultipleRoles = new ProviderInvestigationDetails();

        ProviderInvestigationForMultipleRoles = checkDuplicateCase.get(
          providerInvestigationDetails.caseID);
        ProviderInvestigationForMultipleRoles.participantRoleType += CuramConst.gkSemiColon
          + CuramConst.gkSpace
          + providerInvestigationDetails.participantRoleType;

        checkDuplicateCase.put(providerInvestigationDetails.caseID,
          ProviderInvestigationForMultipleRoles);
      }

    }
    return providerInvestigationDetailsReturnList;
  }
  // END, CR00291801
}
