/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.Singleton;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.entity.impl.ProviderGroupAssociateAdapter;
import curam.cpm.sl.entity.struct.ProviderGroupAssociateDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ProviderGroupAssociateDAO}.
 */

@Singleton
// BEGIN, CR00183213, SS
public class ProviderGroupAssociateDAOImpl extends StandardDAOImpl<ProviderGroupAssociate, ProviderGroupAssociateDtls>
  implements ProviderGroupAssociateDAO {
  // END, CR00183213
  /**
   * adapter instance of ProviderGroupAssociateAdapter
   */
  protected static final ProviderGroupAssociateAdapter adapter = new ProviderGroupAssociateAdapter();

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderGroupAssociateDAOImpl() {
    // END, CR00183213
    super(adapter, ProviderGroupAssociate.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<ProviderGroupAssociate> searchProviderGroupsForProvider(
    Provider provider) {

    return newSet(adapter.searchProviderGroupsForProvider(provider.getID()));

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<ProviderGroupAssociate> searchByProviderAndProviderGroup(
    ProviderGroup providerGroup, Provider provider) {

    return newSet(
      adapter.searchByProviderGroupAndProvider(providerGroup.getID(),
      provider.getID(), RECORDSTATUSEntry.NORMAL.getCode()));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<ProviderGroupAssociate> searchByProviderGroup(
    ProviderGroup providerGroup) {
    return newSet(adapter.searchByProviderGroup(providerGroup.getID()));
  }
}
