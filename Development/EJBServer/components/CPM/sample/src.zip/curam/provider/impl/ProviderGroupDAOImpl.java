/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.HashSet;
import java.util.Set;

import com.google.inject.Singleton;

import curam.codetable.ADDRESSELEMENTTYPE;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.cpm.sl.entity.impl.ProviderGroupAdapter;
import curam.cpm.sl.entity.struct.ProviderGroupDtls;
import curam.cpm.sl.entity.struct.SearchProviderGroupKey;
import curam.util.dataaccess.CuramValueList;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import curam.util.resources.Configuration;


/**
 * Standard implementation of {@linkplain curam.provider.impl.ProviderGroupDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ProviderGroupDAOImpl extends StandardDAOImpl<ProviderGroup, ProviderGroupDtls> implements
  ProviderGroupDAO {
  // END, CR00183213
  /**
   * adapter instance of ProviderGroupAdapter.
   */
  protected static final ProviderGroupAdapter adapter = new ProviderGroupAdapter();

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderGroupDAOImpl() {
    // END, CR00183213
    super(adapter, ProviderGroup.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<ProviderGroup> searchProviderGroupsForResourceManager(
    String userName) {
    final String addressLine1 = ADDRESSELEMENTTYPE.LINE1;

    return newSet(
      adapter.searchProviderGroupByUser(addressLine1, userName, false));

  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderGroup> searchBy(String name, String referenceNumber,
    String street1, String city) {
    // Manipulation variable
    final String referenceNumberTrim = referenceNumber.trim();
    final String nameTrim = name.trim();
    final String street1Trim = street1.trim();
    String cityTrim = city.trim();

    // Initialize the search Criteria
    final boolean searchByReferenceNumberTerm = referenceNumberTrim.length()
      > 0;
    final boolean searchByNameTerm = nameTrim.length() > 0;
    final boolean searchByStreet1Term = street1Trim.length() > 0;
    final boolean searchByCityTerm = cityTrim.length() > 0;
    final String addressLine1TypeTerm = ADDRESSELEMENTTYPE.LINE1;
    final String cityTypeCodeTerm = ADDRESSELEMENTTYPE.CITY;

    final String nameTerm = CuramConst.gkSqlWildcard + nameTrim.toUpperCase()
      + CuramConst.gkSqlWildcard;

    final String street1Term = CuramConst.gkSqlWildcard
      + street1Trim.toUpperCase() + CuramConst.gkSqlWildcard;

    final String cityTerm = CuramConst.gkSqlWildcard + cityTrim.toUpperCase()
      + CuramConst.gkSqlWildcard;

    // BEGIN, CR00170625, KR
    Set<ProviderGroup> providerGroupSet = new HashSet<ProviderGroup>();

    if (Configuration.getBooleanProperty(EnvVars.ENV_DYNAMIC_SQL_ENABLED)) {
      try {
        providerGroupSet = searchByDynamicSql(nameTerm, referenceNumberTrim,
          street1Term, cityTerm, searchByNameTerm, searchByReferenceNumberTerm,
          searchByStreet1Term, searchByCityTerm, addressLine1TypeTerm,
          cityTypeCodeTerm);
      } catch (AppException appException) {
        throw new AppRuntimeException(appException);
      } catch (InformationalException infExp) {
        throw new AppRuntimeException(infExp);
      }
    } else {

      providerGroupSet = newSet(
        adapter.searchBy(nameTerm, referenceNumberTrim, street1Term, cityTerm,
        searchByNameTerm, searchByReferenceNumberTerm, searchByStreet1Term,
        searchByCityTerm, addressLine1TypeTerm, cityTypeCodeTerm, ""));
    }
    return providerGroupSet;
    // END, CR00170625
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<ProviderGroup> readAll() {
    return newSet(adapter.readAll());
  }

  // BEGIN, CR00170625, KR
  protected Set<ProviderGroup> searchByDynamicSql(String name,
    String referenceNumber, String street1, String city,
    boolean searchByName, boolean searchByReferenceNumber,
    boolean searchByStreet1, boolean searchByCity, String addressLine1Type,
    String cityTypeCode) throws AppException, InformationalException {

    ProviderGroupDtls[] providerGroupDtlsList = new ProviderGroupDtls[0];

    if (isAnyProviderGroupSearchCriteriaEntered(searchByName,
      searchByReferenceNumber, searchByStreet1, searchByCity)) {

      StringBuilder providerGroupSearchQuery = new StringBuilder();
      StringBuilder selectBuilder = new StringBuilder();
      StringBuilder intoBuilder = new StringBuilder();
      StringBuilder fromBuilder = new StringBuilder();
      StringBuilder whereBuilder = new StringBuilder();

      SearchProviderGroupKey searchProviderGroupKey = new SearchProviderGroupKey();

      populateProviderGroupSearchKey(name, referenceNumber, street1, city,
        addressLine1Type, cityTypeCode, searchProviderGroupKey);

      selectProviderGroup(selectBuilder, intoBuilder);

      fromBuilder.append(" FROM ProviderGroup, ConcernRole");
      whereBuilder.append(" WHERE");

      whereBuilder.append(
        " ConcernRole.concernRoleID = ProviderGroup.providerGroupConcernRoleID");

      searchByReferenceNumber(searchByReferenceNumber, whereBuilder);
      searchByName(searchByName, whereBuilder);
      searchByStreet1(searchByStreet1, fromBuilder, whereBuilder);
      searchByCity(searchByCity, fromBuilder, whereBuilder);
      whereBuilder.append(" ORDER BY ConcernRole.primaryAlternateID");

      buildFinalQuery(providerGroupSearchQuery, selectBuilder, intoBuilder,
        fromBuilder, whereBuilder);

      CuramValueList curamValueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
        ProviderGroupDtls.class, searchProviderGroupKey, false,
        providerGroupSearchQuery.toString());

      providerGroupDtlsList = new ProviderGroupDtls[curamValueList.size()];

      for (int i = 0; i < curamValueList.size(); i++) {
        providerGroupDtlsList[i] = (ProviderGroupDtls) curamValueList.get(i);
      }
    }
    return newSet(providerGroupDtlsList);
  }

  protected void buildFinalQuery(StringBuilder providerSearchQuery,
    StringBuilder selectBuilder, StringBuilder intoBuilder,
    StringBuilder fromBuilder, StringBuilder whereBuilder) {
    providerSearchQuery.append(selectBuilder);
    providerSearchQuery.append(intoBuilder);
    providerSearchQuery.append(fromBuilder);
    providerSearchQuery.append(whereBuilder);
  }

  protected void searchByName(Boolean searchByName, StringBuilder whereBuilder) {
    if (searchByName) {
      whereBuilder.append(" AND ProviderGroup.nameUpper like :name ");
    }
  }

  protected void searchByReferenceNumber(Boolean searchByReferenceNumber,
    StringBuilder whereBuilder) {
    if (searchByReferenceNumber) {
      whereBuilder.append(
        " AND ConcernRole.primaryAlternateID = :referenceNumber ");
    }
  }

  protected void searchByCity(Boolean searchByCity, StringBuilder fromBuilder,
    StringBuilder whereBuilder) {
    if (searchByCity) {
      fromBuilder.append(" ,AddressElement city ");
      whereBuilder.append(" AND city.upperElementValue like :city ");
      whereBuilder.append(" AND city.addressID = ConcernRole.primaryAddressID");
      whereBuilder.append(" AND city.elementType = :cityTypeCode ");
    }
  }

  protected void searchByStreet1(Boolean searchByStreet1,
    StringBuilder fromBuilder, StringBuilder whereBuilder) {
    if (searchByStreet1) {
      fromBuilder.append("  ,AddressElement addressLine1 ");
      whereBuilder.append(" AND addressLine1.upperElementValue like :street1 ");
      whereBuilder.append(
        " AND addressLine1.addressID = ConcernRole.primaryAddressID");
      whereBuilder.append(" AND addressLine1.elementType = :addressLine1Type ");
    }
  }

  protected void populateProviderGroupSearchKey(String name,
    String referenceNumber, String street1, String city,
    String addressLine1Type, String cityTypeCode,
    SearchProviderGroupKey searchProviderGroupKey) {
    searchProviderGroupKey.name = name;
    searchProviderGroupKey.addressLine1Type = addressLine1Type;
    searchProviderGroupKey.referenceNumber = referenceNumber;
    searchProviderGroupKey.city = city;
    searchProviderGroupKey.cityTypeCode = cityTypeCode;
    searchProviderGroupKey.street1 = street1;
  }

  protected boolean isAnyProviderGroupSearchCriteriaEntered(boolean searchByName,
    boolean searchByReferenceNumber, boolean searchByStreet1,
    boolean searchByCity) {
    return searchByName || searchByReferenceNumber || searchByStreet1
      || searchByCity;
  }

  protected void selectProviderGroup(StringBuilder selectBuilder,
    StringBuilder intoBuilder) {
    selectBuilder.append(" SELECT");
    selectBuilder.append(" ProviderGroup.providerGroupConcernRoleID,");
    selectBuilder.append(" ProviderGroup.paymentFrequency,");
    selectBuilder.append(" ProviderGroup.methodOfPayment,");
    selectBuilder.append(" ProviderGroup.currencyType,");
    selectBuilder.append(" ProviderGroup.recordStatus,");
    selectBuilder.append(" ProviderGroup.name,");
    selectBuilder.append(" ProviderGroup.nameUpper,");
    selectBuilder.append(" ProviderGroup.versionNo");
    intoBuilder.append(" INTO ");
    intoBuilder.append(" :providerGroupConcernRoleID,");
    intoBuilder.append(" :paymentFrequency,");
    intoBuilder.append(" :methodOfPayment,");
    intoBuilder.append(" :currencyType,");
    intoBuilder.append(" :recordStatus,");
    intoBuilder.append(" :name,");
    intoBuilder.append(" :nameUpper,");
    intoBuilder.append(" :versionNo");
  }
  // END, CR00170625
}
