/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.util.persistence.StandardEntity;


/**
 * Accessor interface for LicenseStatusHistory
 * {@linkplain curam.provider.impl.LicenseStatusHistory}.
 *
 */
public interface LicenseStatusHistoryAccessor extends StandardEntity {

  /**
   * Gets the status of the license.
   *
   * @return the status of the license.
   */
  public LicenseStatusEntry getLicenseStatus();

  /**
   * Gets the user who modified the license.
   *
   * @return the user who modified the license.
   */
  public String getUser();

  /**
   * Gets the reason the license was suspended.
   *
   * @return the reason the license was suspended.
   */
  public LicenseSuspensionReasonEntry getSuspensionReason();

  /**
   * Gets the reason the license was rejected.
   *
   * @return the reason the license was rejected.
   */
  public LicenseRejectionReasonEntry getRejectionReason();

}
