/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.List;

import com.google.inject.ImplementedBy;

import curam.util.persistence.ReaderDAO;


/**
 * Data access for
 * {@linkplain curam.provider.impl.LicenseStatusHistory}.
 */
@ImplementedBy(LicenseStatusHistoryDAOImpl.class)
// BEGIN, CR00274320, AC
public interface LicenseStatusHistoryDAO extends ReaderDAO<Long, LicenseStatusHistory> {
  // END, CR00274320

  // ___________________________________________________________________________
  /**
   * Returns a list of status history records for a license, returned in descending
   * date/time order (i.e. latest first).
   *
   * @param license   the license for which history records are required
   * @return list of status history records for a license.
   */
  public List<LicenseStatusHistory> searchBy(final License license);

}
