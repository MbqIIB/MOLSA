/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.List;

import com.google.inject.ImplementedBy;

import curam.approvalcheck.entity.struct.ApprovalCheckDtls;
import curam.cpm.facade.struct.ApprovalCheckKey;
import curam.approvalcheck.impl.ApprovalCheck;
import curam.cpm.facade.struct.ViewApprovalCheckKey;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * The approval check class for the provider which gives the option for
 * specifying percentage of service deliveries which requires manual approval
 * from the supervisor.
 *
 * For Example: The provider approval check can be set up for a user such that
 * 40% of service deliveries created by a user involving a particular provider
 * will require manual approval; the other 60% will be automatically approved.
 */
@ImplementedBy(ProviderApprovalCheckImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ProviderApprovalCheck extends ApprovalCheck {
  
  /**
   * Lists approval checks for the provider.
   *
   * @param relatedID
   * Contains the provider id.
   *
   * @return The list of approval checks.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderApprovalCheckImpl#listProviderApprovalChecks(long)
   * The default implementation -
   * curam.provider.impl.ProviderApprovalCheckImpl#listProviderApprovalChecks(long).
   */
  public List<ApprovalCheck> listProviderApprovalChecks(long relatedID)
    throws InformationalException;

  /**
   * Creates the approval check for the provider.
   *
   * @param approvalCheckDtls
   * Approval check details for the provider.
   *
   * @return The approval check id of the created approval check.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderApprovalCheckImpl#createProviderApprovalCheck(ApprovalCheckDtls)
   * The default implementation -
   * curam.provider.impl.ProviderApprovalCheckImpl#createProviderApprovalCheck(ApprovalCheckDtls).
   */
  public ApprovalCheckKey createProviderApprovalCheck(
    ApprovalCheckDtls approvalCheckDtls) throws InformationalException;
  
  /**
   * Reads the approval check details for the provider.
   *
   * @param viewApprovalCheckKey
   * Contains the approval check ID for the provider.
   *
   * @return The approval check ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderApprovalCheckImpl#viewProviderApprovalCheck(ViewApprovalCheckKey) 
   * The default implementation -
   * curam.provider.impl.ProviderApprovalCheckImpl#viewProviderApprovalCheck(ViewApprovalCheckKey).             
   */
  public ApprovalCheckDtls viewProviderApprovalCheck(
    ViewApprovalCheckKey viewApprovalCheckKey) throws InformationalException;
  
  /**
   * Modifies the approval check details for the provider.
   *
   * @param approvalCheckDtls
   * The approval check details for the provider.
   *
   * @return The approval check ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderApprovalCheckImpl#modifyProviderApprovalCheck(ApprovalCheckDtls) 
   * The default implementation -
   * curam.provider.impl.ProviderApprovalCheckImpl#modifyProviderApprovalCheck(ApprovalCheckDtls).            
   */
  public ApprovalCheckKey modifyProviderApprovalCheck(
    ApprovalCheckDtls approvalCheckDtls) throws InformationalException;
  
  /**
   * Cancels the provider approval check for the provider.
   *
   * @param viewApprovalCheckKey
   * Contains the approval check ID for the provider.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderApprovalCheckImpl#cancelProviderApprovalCheck(ViewApprovalCheckKey)
   * The default implementation -
   * curam.provider.impl.ProviderApprovalCheckImpl#cancelProviderApprovalCheck(ViewApprovalCheckKey).
   */
  public void cancelProviderApprovalCheck(
    ViewApprovalCheckKey viewApprovalCheckKey) throws InformationalException;
  
  /**
   * Informs whether for the given provider, service offering and
   * user combination approval check is required or not. 
   *
   * @param provider
   * Contains provider information.
   * @param service
   * Contains service offering information.
   * @param userName
   * User name.
   *
   * @return Indicates if service delivery for the combination needs approval or not.
   *
   * @throws AppException
   * Generic exception signature.
   * @throws InformationalException
   * Generic exception signature.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public boolean getApprovalCheckInformation(Provider provider, ServiceOffering service,
    String userName) throws InformationalException, AppException;  
  
  // BEGIN, CR00305191, ASN
  /**
   * Interface to the ProviderApprovalCheck API events functionality surrounding
   * the createProviderApprovalCheck method.
   */
  public interface ProviderApprovalCheckCreateProviderApprovalCheckEvents {

    /**
     * Event interface invoked before the main body of the
     * createProviderApprovalCheck method.
     * {@linkplain ProviderApprovalCheck#createProviderApprovalCheck}
     *
     * @param providerApprovalCheck
     * The object instance as it was before the main body of the
     * createProviderApprovalCheck method.
     * @param approvalCheckDtls
     * Approval check details for the provider.
     *
     * @return The approval check id of the created approval check.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     *
     * @see curam.provider.impl.ProviderApprovalCheckImpl#createProviderApprovalCheck(ApprovalCheckDtls)
     * The default implementation -
     * curam.provider.impl.ProviderApprovalCheckImpl
     * #createProviderApprovalCheck(ApprovalCheckDtls).
     */
    public ApprovalCheckKey preCreateProviderApprovalCheck(
      final ProviderApprovalCheck providerApprovalCheck,
      ApprovalCheckDtls approvalCheckDtls) throws InformationalException;

    /**
     * Event interface invoked after the main body of the
     * createProviderApprovalCheck method.
     * {@linkplain ProviderApprovalCheck#createProviderApprovalCheck}
     *
     * @param providerApprovalCheck
     * The object instance as it was after the main body of the
     * createProviderApprovalCheck method.
     * @param approvalCheckDtls
     * Approval check details for the provider.
     *
     * @return The approval check id of the created approval check.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     *
     * @see curam.provider.impl.ProviderApprovalCheckImpl#createProviderApprovalCheck(ApprovalCheckDtls)
     * The default implementation -
     * curam.provider.impl.ProviderApprovalCheckImpl
     * #createProviderApprovalCheck(ApprovalCheckDtls).
     */
    public ApprovalCheckKey postCreateProviderApprovalCheck(
      final ProviderApprovalCheck providerApprovalCheck,
      ApprovalCheckDtls approvalCheckDtls) throws InformationalException;
  }


  /**
   * Interface to the ProviderApprovalCheck API events functionality surrounding
   * the modifyProviderApprovalCheck method.
   */
  public interface ProviderApprovalCheckModifyProviderApprovalCheckEvents {

    /**
     * Event interface invoked before the main body of the
     * modifyProviderApprovalCheck method.
     * {@linkplain ProviderApprovalCheck#modifyProviderApprovalCheck}
     *
     * @param providerApprovalCheck
     * The object instance as it was before the main body of the
     * modifyProviderApprovalCheck method.
     * @param approvalCheckDtls
     * The approval check details for the provider.
     *
     * @return The approval check ID.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     *
     * @see curam.provider.impl.ProviderApprovalCheckImpl#modifyProviderApprovalCheck(ApprovalCheckDtls)
     * The default implementation -
     * curam.provider.impl.ProviderApprovalCheckImpl
     * #modifyProviderApprovalCheck(ApprovalCheckDtls).
     */
    public ApprovalCheckKey preModifyProviderApprovalCheck(
      final ProviderApprovalCheck providerApprovalCheck,
      ApprovalCheckDtls approvalCheckDtls) throws InformationalException;

    /**
     * Event interface invoked after the main body of the
     * modifyProviderApprovalCheck method.
     * {@linkplain ProviderApprovalCheck#modifyProviderApprovalCheck}
     *
     * @param providerApprovalCheck
     * The object instance as it was after the main body of the
     * modifyProviderApprovalCheck method.
     * @param approvalCheckDtls
     * The approval check details for the provider.
     *
     * @return The approval check ID.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     *
     * @see curam.provider.impl.ProviderApprovalCheckImpl#modifyProviderApprovalCheck(ApprovalCheckDtls)
     * The default implementation -
     * curam.provider.impl.ProviderApprovalCheckImpl
     * #modifyProviderApprovalCheck(ApprovalCheckDtls).
     */
    public ApprovalCheckKey postModifyProviderApprovalCheck(
      final ProviderApprovalCheck providerApprovalCheck,
      ApprovalCheckDtls approvalCheckDtls) throws InformationalException;

  }


  /**
   * Interface to the ProviderApprovalCheck API events functionality surrounding
   * the cancelProviderApprovalCheck method.
   */
  public interface ProviderApprovalCheckCancelProviderApprovalCheckEvents {

    /**
     * Event interface invoked before the main body of the
     * cancelProviderApprovalCheck method.
     * {@linkplain ProviderApprovalCheck#cancelProviderApprovalCheck}
     *
     * @param providerApprovalCheck
     * The object instance as it was before the main body of the
     * cancelProviderApprovalCheck method.
     * @param viewApprovalCheckKey
     * Contains the approval check ID for the provider.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     *
     * @see curam.provider.impl.ProviderApprovalCheckImpl#cancelProviderApprovalCheck(ViewApprovalCheckKey)
     * The default implementation -
     * curam.provider.impl.ProviderApprovalCheckImpl
     * #cancelProviderApprovalCheck(ViewApprovalCheckKey).
     */
    public void preCancelProviderApprovalCheck(
      final ProviderApprovalCheck providerApprovalCheck,
      ViewApprovalCheckKey viewApprovalCheckKey)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the
     * cancelProviderApprovalCheck method.
     * {@linkplain ProviderApprovalCheck#cancelProviderApprovalCheck}
     *
     * @param providerApprovalCheck
     * The object instance as it was after the main body of the
     * cancelProviderApprovalCheck method.
     * @param viewApprovalCheckKey
     * Contains the approval check ID for the provider.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     *
     * @see curam.provider.impl.ProviderApprovalCheckImpl#cancelProviderApprovalCheck(ViewApprovalCheckKey)
     * The default implementation -
     * curam.provider.impl.ProviderApprovalCheckImpl
     * #cancelProviderApprovalCheck(ViewApprovalCheckKey).
     */
    public void postCancelProviderApprovalCheck(
      final ProviderApprovalCheck providerApprovalCheck,
      ViewApprovalCheckKey viewApprovalCheckKey)
      throws InformationalException;

  }
  // END, CR00305191
}
