/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.TRAININGPROGRAMPARTYSTATUSEntry;
import curam.cpm.sl.entity.struct.ProviderMemberOfferingDtls;
import curam.message.impl.PROVIDERMEMBEROFFERINGExceptionCreator;
import curam.participant.person.impl.Person;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.SOTrainingRequirement;
import curam.serviceoffering.impl.SOTrainingRequirementDAO;
import curam.training.impl.TrainingProgramMember;
import curam.training.impl.TrainingProgramMemberDAO;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ProviderMemberOffering}.
 */
// BEGIN, CR00183213, SS
public class ProviderMemberOfferingImpl extends SingleTableLogicallyDeleteableEntityImpl<ProviderMemberOfferingDtls>
  implements ProviderMemberOffering {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderMemberOfferingInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderMemberOfferingModifyEvents> modifyEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderMemberOfferingCancelEvents> cancelEventDispatcherFactory;

  // END, CR00235789

  // BEGIN, CR00145043, CPM
  /**
   * Event dispatcher for setDateRangeAndAdjustForValidRange events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderMemberOfferingSetDateRangeAndAdjustForValidRangeEvents> setDateRangeAndAdjustForValidRangeEventDispatcherFactory;

  // END, CR00145043

  /**
   * A reference to Provider Offering.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * A reference to Provider Party.
   */
  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  /**
   * A reference to Provider Member Offering.
   */
  @Inject
  protected ProviderMemberOfferingDAO providerMemberOfferingDAO;

  /**
   * A reference to service offering training requirement.
   */
  @Inject
  protected SOTrainingRequirementDAO soTrainingRequirementDAO;

  /**
   * A reference to training program member.
   */
  @Inject
  protected TrainingProgramMemberDAO trainingProgramMemberDAO;

  /**
   * Bootstrap dependency injection for this class
   */
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderMemberOfferingImpl() {
    // END, CR00183213
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {
    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderOffering getProviderOffering() {
    return providerOfferingDAO.get(getDtls().providerOfferingID);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderParty getProviderParty() {
    return providerPartyDAO.get(getDtls().providerPartyID);
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  /**
   * {@inheritDoc}
   */
  public void setDateRangeAndAdjustForValidRange(DateRange value) {

    // BEGIN, CR00145043, CPM
    // Raise the pre setDateRangeAndAdjustForValidRange provider member offering
    // event.
    setDateRangeAndAdjustForValidRangeEventDispatcherFactory.get(ProviderMemberOfferingSetDateRangeAndAdjustForValidRangeEvents.class).preSetDateRangeAndAdjustForValidRange(
      this, value);
    // END, CR00145043

    Date startDate;
    Date endDate = Date.kZeroDate;

    if (getProviderOffering().getDateRange().startsBefore(value.start())) {
      startDate = value.start();
    } else {
      startDate = getProviderOffering().getDateRange().start();
    }

    if (value.isEnded() && getProviderOffering().getDateRange().isEnded()) {

      if (getProviderOffering().getDateRange().endsAfter(value.end())) {
        endDate = value.end();
      } else {
        endDate = getProviderOffering().getDateRange().end();
      }

    } else if (value.isEnded()) {
      endDate = value.end();

    } else if (getProviderOffering().getDateRange().isEnded()) {
      endDate = getProviderOffering().getDateRange().end();
    }

    getDtls().startDate = startDate;
    getDtls().endDate = endDate;

    // BEGIN, CR00145043, CPM
    // Raise the post setDateRangeAndAdjustForValidRange provider member offering
    // event.
    setDateRangeAndAdjustForValidRangeEventDispatcherFactory.get(ProviderMemberOfferingSetDateRangeAndAdjustForValidRangeEvents.class).postSetDateRangeAndAdjustForValidRange(
      this, value);
    // END, CR00145043


  }

  /**
   * {@inheritDoc}
   */
  public void setDateRange(DateRange value) {

    // BEGIN CR00122476, MST
    /*
     * field validation */
    value.validateRange();
    value.validateStarted();
    // END CR00122476

    getDtls().startDate = value.start();
    getDtls().endDate = value.end();
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderOffering(ProviderOffering value) {
    getDtls().providerOfferingID = value.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderParty(ProviderParty value) {
    getDtls().providerPartyID = value.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void setComments(String value) {
    getDtls().comments = value;
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// None required
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// None required
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// None required
  }

  /**
   * Modifies the details of provider member offering details. If the provider
   * membership date range is modified in a way that provider member offering
   * date range is not within the scope of membership then the provider member
   * offering record is canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre modify provider member offering event.
    modifyEventDispatcherFactory.get(ProviderMemberOfferingModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    DateRange modifiedDateRange = getDateRange();
    DateRange originalDateRange = new DateRange(
      getRowManager().getOriginalDtls().startDate,
      getRowManager().getOriginalDtls().endDate);

    validateProviderMemberOffering();

    if (modifiedDateRange.overlapsWith(originalDateRange)) {

      super.modify(versionNo);
    } else {
      // Provider membership date range is modified in a way that this
      // provider member offering date range is not within that scope.
      // So this provider member offering is canceled.

      // Before cancellation setting back the dtls with original data so that
      // it is not dirty.
      getDtls().startDate = getRowManager().getOriginalDtls().startDate;
      getDtls().endDate = getRowManager().getOriginalDtls().endDate;

      cancel();
    }

    // BEGIN, CR00235789, AK
    // Raise the post modify provider member offering event.
    modifyEventDispatcherFactory.get(ProviderMemberOfferingModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Creates provider member offering after validation of the details against
   * provider member and provider offering. Raises an event if training
   * required for the service offering is not satisfied by the provider
   * member.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERMEMBEROFFERING#ERR_PROVIDERMEMBEROFFERING_XRV_ALREADY_ACTIVE_PROVIDERMEMBEROFFERING_EXIST} -
   * If an 'Active' provider member offering already exists for
   * the provider member.
   */
  @Override
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre insert provider member offering event.
    insertEventDispatcherFactory.get(ProviderMemberOfferingInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    validateProviderMemberOffering();

    validateDuplicates();

    super.insert();

    // Raise the event to inform that required training(s) for the
    // service offering are not met by the provider member.
    if (!isTrainingRequirementsMet()) {

      Event event = new Event();

      event.eventKey = curam.events.PROVIDERPARTY.REQUIRED_TRAININGS_ARE_NOT_MET;

      raiseEvent(event);
    }

    // BEGIN, CR00235789, AK
    // Raise the post insert provider member offering event.
    insertEventDispatcherFactory.get(ProviderMemberOfferingInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancel(final int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre cancel provider member offering event.
    cancelEventDispatcherFactory.get(ProviderMemberOfferingCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    super.cancel(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post cancel provider member offering event.
    cancelEventDispatcherFactory.get(ProviderMemberOfferingCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Raise the workflow event.
   *
   * @param event
   * The Event details.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void raiseEvent(final Event event) throws InformationalException {
    // END, CR00177241
    event.primaryEventData = getID();
    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
  }

  /**
   * This method is used to check if the trainings that are required for
   * associating the service offering is completed or waived for the provider
   * member.
   *
   * @return Indicator that holds the result.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected boolean isTrainingRequirementsMet() throws InformationalException {
    // END, CR00177241

    boolean trainingRequirementsMet = true;

    // Loop through all the training requirements for the service offering and
    // check whether the provider member has member training program of status
    // COMPLETE or WAIVED.
    for (SOTrainingRequirement soTrainingRequirement : soTrainingRequirementDAO.searchBy(
      getProviderOffering().getServiceOffering())) {

      Set<TrainingProgramMember> trainingProgramMembers = trainingProgramMemberDAO.getTrainingProgramsForParty(
        soTrainingRequirement.getTraining().getID(),
        getProviderParty().getParty().getID());

      if (trainingProgramMembers.isEmpty()) {
        trainingRequirementsMet = false;
      }

      for (TrainingProgramMember trainingProgramMember : trainingProgramMembers) {

        if (!(trainingProgramMember.getLifecycleState().equals(
          TRAININGPROGRAMPARTYSTATUSEntry.COMPLETE)
            || trainingProgramMember.getLifecycleState().equals(
              TRAININGPROGRAMPARTYSTATUSEntry.WAIVED))) {
          trainingRequirementsMet = false;
          break;
        }
      }
    }

    return trainingRequirementsMet;
  }

  /**
   * Validates the provider party details if the provider party is a person.
   * The method also validates if provider offering status is valid.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERMEMBEROFFERING#ERR_PROVIDERMEMBEROFFERING_XRV_ONLY_ACTIVE_PROVIDERMEMBER_CAN_BE_ASSOCIATED} -
   * If the provider member is not active. </li>
   * </ul>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERMEMBEROFFERING#ERR_PROVIDERMEMBEROFFERING_XRV_PROVIDEROFFERING_STATUS} -
   * If the provider offering is not active. </li>
   * </ul>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERMEMBEROFFERING#ERR_PROVIDERMEMBEROFFERING_XRV_STARTDATE_BEFORE_PROVIDEROFFERING_STARTDATE} -
   * If provider member offering start date is earlier than start date of
   * provider offering. </li>
   * </ul>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERMEMBEROFFERING#ERR_PROVIDERMEMBEROFFERING_XRV_STARTDATE_BEFORE_PROVIDERMEMBER_STARTDATE} -
   * If provider member offering start date is earlier than start date of
   * provider member. </li>
   * </ul>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERMEMBEROFFERING#ERR_PROVIDERMEMBEROFFERING_XRV_STARTDATE_AFTER_PROVIDEROFFERING_ENDDATE} -
   * If provider member offering start date is after the end date of provider
   * offering. </li>
   * </ul>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERMEMBEROFFERING#ERR_PROVIDERMEMBEROFFERING_XRV_STARTDATE_AFTER_PROVIDERMEMBER_ENDDATE} -
   * If provider member offering start date is after the end date of provider
   * member. </li>
   * </ul>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERMEMBEROFFERING#ERR_PROVIDERMEMBEROFFERING_XRV_ENDDATE_AFTER_PROVIDEROFFERING_ENDDATE} -
   * If provider member offering end date is after the end date of provider
   * offering. </li>
   * </ul>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERMEMBEROFFERING#ERR_PROVIDERMEMBEROFFERING_XRV_ENDDATE_AFTER_PROVIDERMEMBER_ENDDATE} -
   * If provider member offering end date is after the end date of provider
   * member. </li>
   * </ul>
   *
   */
  public void validateProviderMemberOffering() {

    // Validate the party details if the party is a person.
    // BEGIN, CR00121367
    if (getProviderParty().getParty().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PERSON)) {
      // END, CR00121367
      // Check if the provider member is active
      // BEGIN CR00121853, KR
      final curam.participant.person.impl.Person person = (Person) getProviderParty().getParty();

      if (!person.getDateOfDeath().isZero()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERMEMBEROFFERINGExceptionCreator.ERR_PROVIDERMEMBEROFFERING_XRV_ONLY_ACTIVE_PROVIDERMEMBER_CAN_BE_ASSOCIATED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }
    // END CR00121853

    if (!(getProviderOffering().getLifecycleState().equals(
      ProviderOfferingStatusEntry.PENDINGAPPROVAL)
        || getProviderOffering().getLifecycleState().equals(
          ProviderOfferingStatusEntry.APPROVED))) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERMEMBEROFFERINGExceptionCreator.ERR_PROVIDERMEMBEROFFERING_XRV_PROVIDEROFFERING_STATUS(
          getProviderOffering().getServiceOffering().getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    validateDateRangeForProviderMemberOffering();

  }

  /**
   * This method is used to check if there is any active association for the
   * provider member with the provider offering.
   */
  // BEGIN, CR00177241, PM
  protected void validateDuplicates() {
    // END, CR00177241
    // Check if provider offering that is to be associated with the
    // provider member is already associated.
    for (ProviderMemberOffering providerMemberOffering : providerMemberOfferingDAO.searchByProviderParty(
      getDtls().providerPartyID)) {

      if (providerMemberOffering.getLifecycleState().equals(
        RECORDSTATUSEntry.NORMAL)
          && providerMemberOffering.getProviderOffering().getID().equals(
            getDtls().providerOfferingID)
            && providerMemberOffering.getProviderParty().getID().equals(
              getDtls().providerPartyID)
              && !providerMemberOffering.getID().equals(
                getDtls().providerMemberOfferingID)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERMEMBEROFFERINGExceptionCreator.ERR_PROVIDERMEMBEROFFERING_XRV_ALREADY_ACTIVE_PROVIDERMEMBEROFFERING_EXIST(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }
  }

  /**
   * This method is used to validate the date range of provider member offering
   * against provider membership and provider offering.
   */
  // BEGIN, CR00177241, PM
  protected void validateDateRangeForProviderMemberOffering() {
    // END, CR00177241

    if (getProviderOffering().getDateRange().startsAfter(getDtls().startDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERMEMBEROFFERINGExceptionCreator.ERR_PROVIDERMEMBEROFFERING_XRV_STARTDATE_BEFORE_PROVIDEROFFERING_STARTDATE(
          getDtls().startDate, getProviderOffering().getDateRange().start()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (getProviderParty().getDateRange().startsAfter(getDtls().startDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERMEMBEROFFERINGExceptionCreator.ERR_PROVIDERMEMBEROFFERING_XRV_STARTDATE_BEFORE_PROVIDERMEMBER_STARTDATE(
          getDtls().startDate, getProviderParty().getDateRange().start()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // BEGIN CR00122476, MST

    if (getProviderOffering().getDateRange().endsBefore(getDtls().startDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERMEMBEROFFERINGExceptionCreator.ERR_PROVIDERMEMBEROFFERING_XRV_STARTDATE_AFTER_PROVIDEROFFERING_ENDDATE(
          getDtls().startDate, getProviderOffering().getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (getProviderParty().getDateRange().endsBefore(getDtls().startDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERMEMBEROFFERINGExceptionCreator.ERR_PROVIDERMEMBEROFFERING_XRV_STARTDATE_AFTER_PROVIDERMEMBER_ENDDATE(
          getDtls().startDate, getProviderParty().getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // If the end date is entered then validate it against the provider member
    // end date and provider offering end date.
    if (!getDtls().endDate.isZero()) {
      if (getProviderOffering().getDateRange().endsBefore(getDtls().endDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERMEMBEROFFERINGExceptionCreator.ERR_PROVIDERMEMBEROFFERING_XRV_ENDDATE_AFTER_PROVIDEROFFERING_ENDDATE(
            getDtls().endDate, getProviderOffering().getDateRange().end()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      if (getProviderParty().getDateRange().endsBefore(getDtls().endDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERMEMBEROFFERINGExceptionCreator.ERR_PROVIDERMEMBEROFFERING_XRV_ENDDATE_AFTER_PROVIDERMEMBER_ENDDATE(
            getDtls().endDate, getProviderParty().getDateRange().end()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    } else {

      // If end date is not entered then set it to to the end date of
      // provider member or end date of provider offering whichever is earliest.
      if (getProviderParty().getDateRange().isEnded()
        && getProviderOffering().getDateRange().isEnded()) {

        if (getProviderOffering().getDateRange().endsAfter(
          getProviderParty().getDateRange().end())) {

          getDtls().endDate = getProviderParty().getDateRange().end();
        } else {
          getDtls().endDate = getProviderOffering().getDateRange().end();
        }

      } else if (getProviderParty().getDateRange().isEnded()) {
        getDtls().endDate = getProviderParty().getDateRange().end();

      } else if (getProviderOffering().getDateRange().isEnded()) {
        getDtls().endDate = getProviderOffering().getDateRange().end();
      }

    }
    // END CR00122476
  }

}
