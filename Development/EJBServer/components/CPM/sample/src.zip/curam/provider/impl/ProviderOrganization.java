/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import curam.codetable.impl.CURRENCYEntry;
import curam.contracts.impl.ContractVersion;
import curam.participant.impl.ConcernRole;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;

import java.util.List;
import java.util.Set;


/**
 * The common interface to {@linkplain Provider} and {@linkplain ProviderGroup}.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ProviderOrganization extends ConcernRole,
    ProviderOrganizationAccessor {

  /**
   * Gets the immutable set of contracts for this provider organization. A
   * formal agreement between the organization and a provider/provider group to
   * provide service(s).
   *
   * @return The immutable set of contracts for this provider organization.
   */
  Set<ContractVersion> getContracts();

  /**
   * Sets the currency type for this provider organization. The frequency at
   * which the organization will calculate and make payments to the provider.
   *
   * @param value
   * the currency type for this provider organization.
   */
  void setCurrencyType(final CURRENCYEntry value);

  /**
   * Sets the method of payment for this provider organization. The mechanism
   * used to make payments to the provider.
   *
   * @param value
   * the method of payment for this provider organization.
   */
  void setMethodOfPayment(final long value);

  /**
   * Sets the payment frequency for this provider organization.
   *
   * @param value
   * the payment frequency for this provider organization.
   */
  void setPaymentFrequency(final String value);

  /**
   * Gets the immutable set of provider participants for this provider
   * organization.
   *
   * @return Immutable set of provider participants.
   */
  Set<ProviderParticipant> getProviderParticipants();

  /**
   * Gets the immutable set of provider members for this provider organization.
   *
   * @return Immutable set of provider members.
   */
  Set<ProviderMember> getProviderMembers();

  /**
   * Gets the immutable set of provider parties for this provider organization.
   *
   * @return The immutable set of provider members and provider participants.
   */
  Set<ProviderParty> getProviderParties();

  /**
   * Adds a new member to this provider organization(if it is not already a
   * member).
   *
   * @param providerMember
   * the instance of provider member.
   * @return boolean indicating if a new member is added to this provider
   * organization.
   */
  boolean addProviderMember(final ProviderMember providerMember);

  /**
   * Gets the immutable set of service offerings which are approved to be
   * provided by <i>all</i> the providers on the contract version specified.
   *
   * @param contractVersion
   * The version of the contract for which common approved service
   * offerings are sought.
   *
   * @return The immutable set of service offerings which are approved to be
   * provided by <i>all</i> the providers on the contract version
   * specified.
   */
  Set<ServiceOffering> getCommonApprovedProviderServiceOfferings(
    final ContractVersion contractVersion);

  /**
   * Gets the immutable list of Incidents for the provider organization.
   *
   * @return The immutable list of Incidents for a provider organization.
   */
  List<ProviderIncident> getIncidents();

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider organization events functionality surrounding the
   * addProviderMember method.
   */
  public interface ProviderOrganizationAddProviderMemberEvents {

    /**
     * Event interface invoked before the main body of the addProviderMember
     * method.
     * {@linkplain curam.provider.impl.ProviderOrganization#addProviderMember}
     *
     * @param providerOrganization
     * The object instance as it was before the main body of the
     * addProviderMember method.
     * @param providerMember
     * The parameter as passed to the addProviderMember method.
     */
    public void preAddProviderMember(
      ProviderOrganizationAccessor providerOrganization,
      ProviderMember providerMember);

    /**
     * Event interface invoked after the main body of the addProviderMember
     * method.
     * {@linkplain curam.provider.impl.ProviderOrganization#addProviderMember}
     *
     * @param providerOrganization
     * The object instance as it was after the main body of the
     * addProviderMember method.
     * @param providerMember
     * The parameter as passed to the addProviderMember method.
     * @param returnValue
     * The return value updated by the Event Handler.
     */
    public void postAddProviderMember(
      ProviderOrganizationAccessor providerOrganization,
      ProviderMember providerMember, boolean returnValue);
  }
  // END, CR00144381
}
