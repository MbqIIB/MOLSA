/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Collections;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.impl.ProviderCategoryPeriodAdapter;
import curam.cpm.sl.entity.struct.ProviderCategoryPeriodDtls;
import curam.events.PROVIDERCATEGORY;
import curam.message.impl.PROVIDERCATEGORYExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.resources.GeneralConstants;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.DateRange;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ProviderCategoryPeriod}.
 */
// BEGIN, CR00183213, SS
public class ProviderCategoryPeriodImpl extends SingleTableLogicallyDeleteableEntityImpl<ProviderCategoryPeriodDtls>
  implements ProviderCategoryPeriod {
  // END, CR00183213

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insertProviderCategoryPeriod events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderCategoryPeriodInsertProviderCategoryPeriodEvents> insertProviderCategoryPeriodEventDispatcherFactory;

  /**
   * Event dispatcher for modifyProviderCategoryPeriod events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderCategoryPeriodModifyProviderCategoryPeriodEvents> modifyProviderCategoryPeriodEventDispatcherFactory;

  /**
   * Event dispatcher for removeAsPrimaryProviderCategory events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderCategoryPeriodRemoveAsPrimaryProviderCategoryEvents> removeAsPrimaryProviderCategoryEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderCategoryPeriodInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderCategoryPeriodCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderCategoryPeriodModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  /**
   * Constant for maximum comments length
   */
  static final int kCommentsLength = 200;

  /**
   * Inject ProviderDAO
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Inject ProviderTypeDAO
   */
  @Inject
  protected ProviderTypeDAO providerTypeDAO;

  /**
   * Inject ProviderSecurity
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderCategoryPeriodImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213
  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {

    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// none required
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// none required
  }

  /**
   * Validates that mandatory field are provided for the Provider Category
   * Period.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_CATEGORY_MUST_EXIST} -
   * If the contract with the entered category already exists. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    // Begin CR00096779, ABS
    // Category Not Entered.
    if (ProviderCategoryNameEntry.NOT_SPECIFIED.equals(getCategory())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XRV_CATEGORY_MUST_EXIST(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

    getDateRange().validateStarted();

  }

  /**
   * Cancels the provider category period after performing the security check.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}
   * - If the provider is closed.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDERCATEGORY_XRV_CANNOT_DELETE_IF_PROVIDER_CATEGORY_IS_PRIMARY}
   * - If the provider is primary.
   */
  public void cancel(final int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    cancelEventDispatcherFactory.get(ProviderCategoryPeriodCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    // Perform a security check.

    // BEGIN, CR00187731, DRS
    // If the call is from provider enquiry rather than provider,
    // security check has to be skipped as checkProviderSecurity
    // expects provider details.
    if (getProvider().getID() != CPMConstants.kZeroLong) {

      providerSecurity.checkProviderSecurity(getProvider());
    }
    // END, CR00187731

    if (getProvider() != null) {

      if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 47);
        ValidationHelper.failIfErrorsExist();
      }
    }
    if (isPrimary()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XRV_CANNOT_DELETE_IF_PROVIDER_CATEGORY_IS_PRIMARY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    super.cancel(versionNo);

    // BEGIN, CR00097018, GP
    final Event event = new Event();

    event.eventKey = PROVIDERCATEGORY.PROVIDERCATEGORYPERIOD_CANCELED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
    // END CR00097018, GP

    // BEGIN, CR00235789, AK
    cancelEventDispatcherFactory.get(ProviderCategoryPeriodCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * Insert the provider category period after performing the security check. 
   * Also raises the pre and post insert events.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    insertEventDispatcherFactory.get(ProviderCategoryPeriodInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    // Perform a security check.

    // BEGIN, CR00187731, DRS
    // If the call is from provider enquiry rather than provider,
    // security check has to be skipped as checkProviderSecurity
    // expects provider details.
    if (getProvider().getID() != CPMConstants.kZeroLong) {
      providerSecurity.checkProviderSecurity(getProvider());
    }
    // END, CR00187731

    super.insert();

    // BEGIN, CR00097018, GP
    final Event event = new Event();

    event.eventKey = curam.events.PROVIDERCATEGORY.PROVIDERCATEGORYPERIOD_INSERTED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
    // END, CR00097018, GP

    // BEGIN, CR00235789, AK
    insertEventDispatcherFactory.get(ProviderCategoryPeriodInsertEvents.class).postInsert(
      this);
    // END, CR00235789

  }

  /**
   * Modifies the provider category period after performing the security check.
   * Also raises the pre and post modify events.
   *
   * @param versionNo
   * Contains the version.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modify(final Integer versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    modifyEventDispatcherFactory.get(ProviderCategoryPeriodModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // Perform a security check.

    // BEGIN, CR00187731, DRS
    // If the call is from provider enquiry rather than provider,
    // security check has to be skipped as checkProviderSecurity
    // expects provider details.
    if (getProvider().getID() != CPMConstants.kZeroLong) {
      providerSecurity.checkProviderSecurity(getProvider());
    }
    // END, CR00187731

    super.modify(versionNo);

    // BEGIN CR00097018, GP
    final Event event = new Event();

    event.eventKey = curam.events.PROVIDERCATEGORY.PROVIDERCATEGORYPERIOD_MODIFIED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
    // END CR00097018, GP

    // BEGIN, CR00235789, AK
    modifyEventDispatcherFactory.get(ProviderCategoryPeriodModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {

    return getDtls().comments;
  }

  /**
   * Sets the Comments for the provider category period.
   *
   * @param value
   * The comments for provider category period.
   */
  public void setComments(final String value) {

    // Comments Greater Than Two Hundred Characters.
    if (value.length() > ProviderCategoryPeriodAdapter.kMaxLength_comments) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XF_COMMENTS_ENTERED_TOO_LONG(
          value.length(), ProviderCategoryPeriodAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    getDtls().comments = value;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderCategoryNameEntry getCategory() {

    return ProviderCategoryNameEntry.get(getDtls().category);
  }

  /**
   * {@inheritDoc}
   */
  public String getEndReason() {

    return getDtls().endReason;
  }

  /**
   * {@inheritDoc}
   */
  public boolean isPrimary() {

    return getDtls().primaryInd;
  }

  /**
   * {@inheritDoc}
   */
  public Provider getProvider() {

    final long providerConcernRoleID = getDtls().providerConcernRoleID;

    return providerDAO.get(providerConcernRoleID);

  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderType> getProviderTypes() {

    return Collections.unmodifiableSet(providerTypeDAO.searchBy(this));
  }

  /**
   * Sets the start and end date for this provider category period.
   *
   * @param value
   * The "lifetime" of the provider category period. This category
   * cannot be offered to clients outside of the date range.
   */
  public void setDateRange(final DateRange value) {

    if (value.start().isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XRV_START_DATE_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if (!value.end().isZero()) {
      if (value.start().after(value.end())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XFV_ENDDATE_MUST_NOT_BE_EARLIER_THAN_STARTDATE(
            value.end(), value.start()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
    getDtls().startDate = value.start();
    getDtls().endDate = value.end();

    value.validateStarted();
  }

  /**
   * {@inheritDoc}
   */
  public void setCategory(final ProviderCategoryNameEntry value) {

    getDtls().category = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setEndReason(final String value) {

    getDtls().endReason = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setPrimary(final boolean value) {

    getDtls().primaryInd = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setProvider(final Provider provider) {
    getDtls().providerConcernRoleID = provider.getID();
  }

  /**
   * Validates the Provider Category details.
   *
   * @param providerCategoryDetails
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void validateProviderCategory() throws AppException,
      // END, CR00177241
      InformationalException {

    // if the status of the provider is closed
    if (getProvider() != null) {
      if (getProvider().getLifecycleState().getCode().equals(
        ProviderStatusEntry.CLOSED.getCode())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 46);
        ValidationHelper.failIfErrorsExist();
      }
    }

    final Provider provider = getProvider();

    // Provider Category Start Date Earlier Than Provider Start Date.
    if (getDateRange().startsBefore(provider.getStartDate())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XRV_STARTDATE_IS_LATER_THAN_ENROLLMENT_DATE(
          getDateRange().start(), provider.getStartDate()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Provider Category Start Date Later Than Provider End Date.
    if (!provider.getEndDate().isZero()
      && getDateRange().startsAfter(provider.getEndDate())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XRV_STARTDATE_MUST_NOT_BE_LATER_THAN_ENDDATE_OF_PROVIDER(
          getDateRange().start(), provider.getEndDate()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Provider Category End Date Earlier Than Provider Start Date.
    if (!getDateRange().end().isZero()
      && getDateRange().endsBefore(provider.getStartDate())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XRV_ENDDATE_MUST_NOT_BE_EARLIER_THAN_ENROLLMENTDATE_OF_PROVIDER(
          getDateRange().end(), provider.getStartDate()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Provider Category End Date Later Than Provider End Date.
    if (!getDateRange().end().isZero() && !provider.getEndDate().isZero()
      && getDateRange().endsAfter(provider.getEndDate())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XRV_ENDDATE_MUST_NOT_BE_LATER_THAN_ENDDATE_OF_PROVIDER(
          getDateRange().end(), provider.getEndDate()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // End Date entered, End Reason Not Entered.
    if (!getDateRange().end().isZero()
      && GeneralConstants.kEmpty.equals(getEndReason())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XFV_END_REASON_MUST_BE_SPECIFIED_IF_ENDDATE_IS_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // End Date not entered, End Reason entered
    if (getDateRange().end().isZero()
      && !GeneralConstants.kEmpty.equals(getEndReason())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XFV_END_REASON_MUST_NOT_SPECIFIED_IF_ENDDATE_IS_NOT_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

    // Same Category More Than Once In Same Period.
    final Set<ProviderCategoryPeriod> providerCategoryPeriods = getProvider().getProviderCategoryPeriods();

    // Checking for the provider category in the already exist list
    for (ProviderCategoryPeriod providerCategoryPeriod : providerCategoryPeriods) {

      if (providerCategoryPeriod.getID().equals(getID())) {
        continue;
      }

      if (providerCategoryPeriod.getCategory().equals(getCategory())
        && RECORDSTATUSEntry.NORMAL.equals(
          providerCategoryPeriod.getLifecycleState())) {
        if (getDateRange().overlapsWith(providerCategoryPeriod.getDateRange())) {
          if (!providerCategoryPeriod.getDateRange().end().isZero()) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XRV_CATAGORY_ALREADY_EXISTS(
                new CodeTableItemIdentifier(ProviderCategoryNameEntry.TABLENAME,
                getCategory().getCode()),
                providerCategoryPeriod.getDateRange().start(),
                providerCategoryPeriod.getDateRange().end()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
          } else {

            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XRV_CATAGORY_ALREADY_EXISTS_AND_EXIST_CATAGORY_NOT_HAVE_ENDDATE(
                new CodeTableItemIdentifier(ProviderCategoryNameEntry.TABLENAME,
                getCategory().getCode()),
                providerCategoryPeriod.getDateRange().start()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
          }

        }

      }

    }

  }

  /**
   * Inserts the Provider Category Period after validating the entered details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_ENDDATE_MUST_NOT_BE_EARLIER_THAN_ENROLLMENTDATE_OF_PROVIDER} -
   * If Provider Category End Date Earlier Than Provider Start Date.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_CATAGORY_ALREADY_EXISTS_AND_EXIST_CATAGORY_NOT_HAVE_ENDDATE} -
   * If ProviderCategoryPeriod end date is null.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_ENDDATE_MUST_NOT_BE_LATER_THAN_ENDDATE_OF_PROVIDER} -
   * If Provider Category End Date Later Than Provider End Date.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_PRIMARY_CATEGORY_CANNOT_MODIFY_IT_IS_NO_LONGER_PRIMARY} -
   * If ProviderCategoryPeriod is not primary.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_STARTDATE_MUST_NOT_BE_LATER_THAN_ENDDATE_OF_PROVIDER} -
   * If Provider Category Start Date Later Than Provider End Date.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_CATAGORY_ALREADY_EXISTS} -
   * If ProviderCategory already exists.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XFV_END_REASON_MUST_BE_SPECIFIED_IF_ENDDATE_IS_SPECIFIED} -
   * If End reason not entered but end date entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_STARTDATE_IS_LATER_THAN_ENROLLMENT_DATE} -
   * If Provider Category Start Date Earlier Than Provider Start Date.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XFV_END_REASON_MUST_NOT_SPECIFIED_IF_ENDDATE_IS_NOT_SPECIFIED} -
   * If ProviderCategoryPeriod end date is null but the end reason
   * entered.
   */
  public void insertProviderCategoryPeriod() throws AppException,
      InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre insertProviderCategoryPeriod provider category period
    // event.
    insertProviderCategoryPeriodEventDispatcherFactory.get(ProviderCategoryPeriodInsertProviderCategoryPeriodEvents.class).preInsertProviderCategoryPeriod(
      this);
    // END, CR00235789

    validateProviderCategory();

    insert();
    // BEGIN, CR00235789, AK
    // Raise the post insertProviderCategoryPeriod provider category period
    // event.
    insertProviderCategoryPeriodEventDispatcherFactory.get(ProviderCategoryPeriodInsertProviderCategoryPeriodEvents.class).postInsertProviderCategoryPeriod(
      this);
    // END, CR00235789

  }

  /**
   * Modifies the ProviderCategoryPeriod after validating for the modification.
   *
   * @param providerCategoryPeriod
   * The system generated identifier for the ProviderCategoryPeriod.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_ENDDATE_MUST_NOT_BE_EARLIER_THAN_ENROLLMENTDATE_OF_PROVIDER} -
   * If Provider Category End Date Earlier Than Provider Start Date.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_CATAGORY_ALREADY_EXISTS_AND_EXIST_CATAGORY_NOT_HAVE_ENDDATE} -
   * If ProviderCategoryPeriod end date is null.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_STARTDATE_MUST_NOT_BE_LATER_THAN_ENDDATE_OF_PROVIDER} -
   * If Provider Category Start Date Later Than Provider End Date.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_ENDDATE_MUST_NOT_BE_LATER_THAN_ENDDATE_OF_PROVIDER} -
   * If Provider Category End Date Later Than Provider End Date.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_CATAGORY_ALREADY_EXISTS} -
   * If ProviderCategory already exists.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_STARTDATE_IS_LATER_THAN_ENROLLMENT_DATE} -
   * If Provider Category Start Date Earlier Than Provider Start Date.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XRV_PRIMARY_CATEGORY_CANNOT_MODIFY_IT_IS_NO_LONGER_PRIMARY} -
   * If ProviderCategoryPeriod is not primary.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XFV_END_REASON_MUST_BE_SPECIFIED_IF_ENDDATE_IS_SPECIFIED} -
   * If End reason not entered but end date entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDERCATEGORY_XFV_END_REASON_MUST_NOT_SPECIFIED_IF_ENDDATE_IS_NOT_SPECIFIED} -
   * If ProviderCategoryPeriod end date is null but the end reason
   * entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERCATEGORY#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   */
  public void modifyProviderCategoryPeriod(
    final ProviderCategoryPeriod providerCategoryPeriod) throws AppException,
      InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre modifyProviderCategoryPeriod provider category period
    // event.
    modifyProviderCategoryPeriodEventDispatcherFactory.get(ProviderCategoryPeriodModifyProviderCategoryPeriodEvents.class).preModifyProviderCategoryPeriod(
      this);
    // END, CR00235789

    if (providerCategoryPeriod.getID().equals(getID())) {
      if (!isPrimary()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XRV_PRIMARY_CATEGORY_CANNOT_MODIFY_IT_IS_NO_LONGER_PRIMARY(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }

    validateProviderCategory();

    // modify(versionNo);
    // BEGIN, CR00235789, AK
    // Raise the post modifyProviderCategoryPeriod provider category period
    // event.
    modifyProviderCategoryPeriodEventDispatcherFactory.get(ProviderCategoryPeriodModifyProviderCategoryPeriodEvents.class).postModifyProviderCategoryPeriod(
      this);
    // END, CR00235789

  }

  /**
   * {@inheritDoc}
   */
  public void setProviderEnquiry(final ProviderEnquiry value) {

    getDtls().providerConcernRoleID = value.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void removeAsPrimaryProviderCategory() throws AppException,
      InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre removeAsPrimaryProviderCategory provider category period
    // event.
    removeAsPrimaryProviderCategoryEventDispatcherFactory.get(ProviderCategoryPeriodRemoveAsPrimaryProviderCategoryEvents.class).preRemoveAsPrimaryProviderCategory(
      this);
    // END, CR00235789

    // Set the primary category as false
    setPrimary(false);

    // Update the changes
    modify(getVersionNo());
    // BEGIN, CR00235789, AK
    // Raise the post removeAsPrimaryProviderCategory provider category period
    // event.
    removeAsPrimaryProviderCategoryEventDispatcherFactory.get(ProviderCategoryPeriodRemoveAsPrimaryProviderCategoryEvents.class).postRemoveAsPrimaryProviderCategory(
      this);
    // END, CR00235789

  }
}
