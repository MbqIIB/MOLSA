/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.ContractVersionDAO;
import curam.contracts.impl.ContractVersionProviderGroupAssociate;
import curam.contracts.impl.ContractVersionProviderGroupAssociateDAO;
import curam.contracts.impl.ContractVersionProviderOffering;
import curam.contracts.impl.ContractVersionProviderOfferingDAO;
import curam.cpm.sl.entity.impl.ProviderGroupAssociateAdapter;
import curam.cpm.sl.entity.struct.ProviderGroupAssociateDtls;
import curam.message.PROVIDERGROUPASSOCIATE;
import curam.message.impl.PROVIDERGROUPASSOCIATEExceptionCreator;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.LifecycleHelper;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ProviderGroupAssociate}.
 */
// BEGIN, CR00183213, SS
public class ProviderGroupAssociateImpl extends SingleTableLogicallyDeleteableEntityImpl<ProviderGroupAssociateDtls>
  implements ProviderGroupAssociate {
  // END, CR00183213

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for removeProviderFromProviderGroup events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderGroupAssociateRemoveProviderFromProviderGroupEvents> removeProviderFromProviderGroupEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderGroupAssociateInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderGroupAssociateCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderGroupAssociateModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  /**
   * Reference to Provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to Provider Group DAO.
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /**
   * Reference to Provider Group Associate DAO.
   */
  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;

  /**
   * Reference to Provider Security.
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00168459, SG
  /**
   * Reference to Provider Group Associate Payment Configuration DAO.
   */
  @Inject
  protected ProviderGroupAssociatePaymentConfigurationDAO pgAssociatePaymentConfigurationDAO;

  // END, CR00168459

  /**
   * Reference to Contract Version.
   */
  @Inject
  protected ContractVersionDAO contractVersionDAO;
 
  // BEGIN, CR00187814, DRS
  /**
   * Reference to Contract Version Provider Group Associate DAO.
   */
  @Inject
  protected ContractVersionProviderGroupAssociateDAO contractVersionProviderGroupAssociateDAO;

  /**
   * Reference to Provider Offering DAO.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Reference to Contract Version Provider Offering DAO.
   */
  @Inject
  protected ContractVersionProviderOfferingDAO contractVersionProviderOfferingDAO;

  // END, CR00187814

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderGroupAssociateImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213
  /**
   * {@inheritDoc}
   */
  public void setProvider(Provider provider) {
    getDtls().providerConcernRoleID = provider.getID();
  }

  /**
   * {@inheritDoc}
   */
  public Provider getProvider() {
    final long providerConcernRoleID = getDtls().providerConcernRoleID;

    return providerConcernRoleID == 0
      ? null
      : providerDAO.get(providerConcernRoleID);
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderGroup(ProviderGroup providerGroup) {
    getDtls().providerGroupConcernRoleID = providerGroup.getID();
  }

  /**
   * {@inheritDoc}
   */
  public ProviderGroup getProviderGroup() {
    final long providerGroupConcernRoleID = getDtls().providerGroupConcernRoleID;

    return providerGroupConcernRoleID == 0
      ? null
      : providerGroupDAO.get(providerGroupConcernRoleID);
  }

  /**
   * {@inheritDoc}
   */
  public void setPartOfContract(boolean value) {
    getDtls().contractedAssociateInd = value;
  }

  /**
   * {@inheritDoc}
   */
  public boolean isPartOfContract() {
    return getDtls().contractedAssociateInd;
  }

  // BEGIN, CR00178886, ASN

  /**
   * Sets an indicator telling whether the provider group should be accepting
   * the payments on behalf of the corresponding provider.
   *
   * @param value
   * An indicator telling whether the provider group should be
   * accepting the payments on behalf of the corresponding provider.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link curam.provider.impl.ProviderGroupAssociatePaymentConfiguration }
   * . To maintain the history for this indicator, it has been
   * reintroduced with effective date in
   * ProviderGroupAssociatePaymentConfiguration entity.See release
   * note: CR00178886.
   */
  @Deprecated
  public void setGroupToReceivePayments(boolean value) {
    getDtls().groupToReceivePayments = value;
  }

  /**
   * Indicates whether the provider group should be accepting the payments on
   * behalf of the corresponding provider.
   *
   * @return An indicator telling whether the provider group should be accepting
   * the payments on behalf of the corresponding provider.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link ProviderGroupAssociate#isProviderGroupToRecievePayments (Date paymentDate)}
   * . To decide the payee using the provider group association
   * payment configuration for any given date, method
   * isProviderGroupToRecievePayments with a date parameter has been
   * introduced in the class ProviderGroupAssociate. See release
   * note: CR00178886.
   */
  @Deprecated
  public boolean isGroupToReceivePayments() {
    return getDtls().groupToReceivePayments;
  }

  // END, CR00178886

  /**
   * Sets the date range for Provider Group Associate.
   *
   * @param value
   * Provider group association date range.
   *
   * <p>
   * It adds the following informational exceptions to the validation
   * helper when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_FV_START_DATE_EMPTY}
   * If start date is empty.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XFV_END_DATE_EARLIER_THAN_START_DATE}
   * If end date is earlier than start date.</li>
   * </ul>
   */
  public void setDateRange(DateRange value) {

    if (value.start().isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_FV_START_DATE_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if (!value.end().isZero()) {
      if (value.start().after(value.end())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XFV_END_DATE_EARLIER_THAN_START_DATE(
            value.end(), value.start()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
    getDtls().startDate = value.start();
    getDtls().endDate = value.end();

  }

  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {
    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  /**
   * Sets the comments.
   *
   * @param value
   * Comments.
   *
   * <p>
   * It adds the following informational exceptions to the validation
   * helper when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_FV_COMMENT_IS_TOO_LONG}
   * If the length of the comments exceeds the limit.</li>
   * </ul>
   */
  public void setComments(String value) {

    if (value.length() > ProviderGroupAssociateAdapter.kMaxLength_comments) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_FV_COMMENT_IS_TOO_LONG(
          ProviderGroupAssociateAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    getDtls().comments = value;

  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {

    getDateRange().validateStarted();

  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No Implementation required.
  }

  /**
   * Validates that changes made to provider group association entity on the
   * database are consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_EARLIER_THAN_ENROLLMENT_DATE_OF_PROVIDERGROUP}
   * If start date of association is earlier than Provider Group start date.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_LATER_THAN_END_DATE_OF_PROVIDERGROUP}
   * If start date of association is later than Provider Group end date.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_EARLIER_THAN_ENROLLMENT_DATE_OF_PROVIDERGROUP}
   * If end date of association is later than the enrollment date of the
   * Provider Group.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_LATER_THAN_END_DATE_OF_PROVIDERGROUP}
   * If end date of association is later than the end date of the Provider
   * Group.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_EARLIER_THAN_ENROLLMENT_DATE_OF_PROVIDER}
   * If association start date earlier than the enrollment date of the Provider.
   * </li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_LATER_THAN_END_DATE_OF_PROVIDER}
   * If association start date later than the end date of the Provider.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_EARLIER_THAN_ENROLLMENT_DATE_OF_PROVIDER}
   * If association end date later than the enrollment date of the Provider.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_LATER_THAN_END_DATE_OF_PROVIDER}
   * If end date later than the end date of the Provider.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_WITH_SAME_PERIORD_EXISTS}
   * Association already exists with end date.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_WITH_SAME_PERIORD_EXISTS_ASSOCIATE_NOT_HAVE_END_DATE}
   * Association already exists without end date.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_LATER_THAN_CONTRACT_START_DATE}
   * Association start date is after start date of Contract.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_BEFORE_THAN_CONTRACT_END_DATE}
   * Association end date is before end date of Contract.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_ACTIVE_MEMBER_FROM_TO}
   * If an end dated active association exists.</li>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_ACTIVE_MEMBER_FROM}
   * If a non end dated active association exists.</li>
   * </ul>
   * <li>
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XFV_END_DATE_EMPTY_AND_END_DATE_OF_PROVIDER_PRESENT}
   * If provider has end date and associates end date is empty.</li>
   * </ul>
   */
  public void crossEntityValidation() {
    validateProviderGroupAssociate();
  }

  // BEGIN, CR00093345, GD
  /**
   * Removes a Provider from a Provider Group association.
   *
   * Checks the provider security to remove the provider from provider group
   * association.
   *
   * @param versionNo
   * Version number.
   *
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_INCLUDED_LIVE_CONTRACT_CANNOT_REMOVED}
   * If the provider group associate is named in a Live contract with
   * an end date in future
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_CANNOT_CANCEL_CANCELLED_PROVIDERGROUPASSOCIATE}
   * If provider group association is canceled already.
   */
  public void removeProviderFromProviderGroup(Integer versionNo)
    throws InformationalException {

    providerSecurity.checkProviderGroupSecurity(getProviderGroup());

    // BEGIN, CR00235789, AK
    removeProviderFromProviderGroupEventDispatcherFactory.get(ProviderGroupAssociateRemoveProviderFromProviderGroupEvents.class).preRemoveProviderFromProviderGroup(
      this, versionNo);
    // END, CR00235789

    // BEGIN, CR00103371, KR
    if (getDtls().recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_CANNOT_CANCEL_CANCELLED_PROVIDERGROUPASSOCIATE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // END, CR00103371

    for (ContractVersion contractVersion : contractVersionDAO.searchBy(
      this.getProviderGroup())) {
      if (contractVersion.getLifecycleState().equals(CONTRACTSTATUSEntry.LIVE)
        && contractVersion.getDateRange().endsInFuture()) {

        for (Provider provider : contractVersion.getProviders()) {
          if (provider.equals(this.getProvider())) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_INCLUDED_LIVE_CONTRACT_CANNOT_REMOVED(
                this.getProvider().getName()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                1);
            break;
          }
        }
      }
    }

    ValidationHelper.failIfErrorsExist();

    // Business Rule: when a provider is removed from the provider group
    // the end date should be set to today.
    DateRange dateRange = getDateRange();

    dateRange = dateRange.newEndDate(Date.getCurrentDate());
    setDateRange(dateRange);

    // BEGIN, CR00103371, KR
    setRecordStatus(RECORDSTATUSEntry.CANCELLED);
    getEntityManager().modify(versionNo);
    // END, CR00103371

    // BEGIN, CR00168459, SG
    // BEGIN, CR00178886, ASN
    try {
      for (final ProviderGroupAssociatePaymentConfiguration pgAssociatePaymentConfiguration : pgAssociatePaymentConfigurationDAO.searchByProviderGroupAssociate(
        this)) {
        if (pgAssociatePaymentConfiguration.getLifecycleState().getCode().equals(
          RECORDSTATUSEntry.NORMAL.getCode())) {
          pgAssociatePaymentConfiguration.cancel(
            pgAssociatePaymentConfiguration.getVersionNo());
        }
      }

      // END, CR00168459

      // BEGIN, CR00187814, DRS

      // Business Rule: When user tries to remove the provider associate from
      // provider group which has a contract, system notifies the user that the provider
      // would be removed from the contract and confirms if user wants to continue.
      // User selects to continue. System removes the provider from the contract for provider group.

      // BEGIN, CR00188202, DRS
      final Set<ContractVersionProviderGroupAssociate> contractVersionProviderGroupAssociates = contractVersionProviderGroupAssociateDAO.searchBy(
        this);

      // Remove the association between contract and provider group associates
      if (contractVersionProviderGroupAssociates != null) {

        for (final ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : contractVersionProviderGroupAssociates) {

          contractVersionProviderGroupAssociate.remove();
        }
      }

      final Set<ProviderOffering> providerOfferings = providerOfferingDAO.searchBy(
        getProvider());

      // Remove the links between contract and provider offerings of the
      // provider associate being removed
      if (providerOfferings != null) {

        for (final ProviderOffering providerOffering : providerOfferings) {

          final Set<ContractVersionProviderOffering> contractVersionProviderOfferings = contractVersionProviderOfferingDAO.searchBy(
            providerOffering);

          if (contractVersionProviderOfferings != null) {

            for (final ContractVersionProviderOffering contractVersionProviderOffering : contractVersionProviderOfferings) {

              contractVersionProviderOffering.remove();
            }
          }
        }
      }
      // END, CR00188202
      // END, CR00187814

      // BEGIN, CR00235789, AK
      removeProviderFromProviderGroupEventDispatcherFactory.get(ProviderGroupAssociateRemoveProviderFromProviderGroupEvents.class).postRemoveProviderFromProviderGroup(
        this, versionNo);
      // END, CR00235789
    } catch (AppException appException) {
      ValidationHelper.addValidationError(appException);
    }
    // END, CR00178886
  }

  // END, CR00093345

  /**
   * Cancels the Provider Group Association.
   *
   * @param versionNo
   * Contains the group association version number.
   *
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_INCLUDED_LIVE_CONTRACT_CANNOT_REMOVED}
   * If association included in a live Contract.
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_CANNOT_CANCEL_CANCELLED_PROVIDERGROUPASSOCIATE}
   * If association is already canceled.
   */
  @Override
  public void cancel(int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    cancelEventDispatcherFactory.get(ProviderGroupAssociateCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    providerSecurity.checkProviderGroupSecurity(getProviderGroup());

    // BEGIN, CR00089551, SK
    for (ContractVersion contractVersion : contractVersionDAO.searchBy(
      this.getProviderGroup())) {
      if (contractVersion.getLifecycleState().equals(CONTRACTSTATUSEntry.LIVE)
        && contractVersion.getDateRange().endsInFuture()) {

        for (Provider provider : contractVersion.getProviders()) {
          if (provider.equals(this.getProvider())) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_INCLUDED_LIVE_CONTRACT_CANNOT_REMOVED(
                this.getProvider().getName()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
            break;
          }
        }
      }
    }
    // END, CR00089551
    if (getDtls().recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_CANNOT_CANCEL_CANCELLED_PROVIDERGROUPASSOCIATE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    ValidationHelper.failIfErrorsExist();
    super.cancel(versionNo);

    // BEGIN, CR00168459, SG
    // BEGIN, CR00178886, ASN
    try {
      for (final ProviderGroupAssociatePaymentConfiguration pgAssociatePaymentConfiguration : pgAssociatePaymentConfigurationDAO.searchByProviderGroupAssociate(
        this)) {
        if (pgAssociatePaymentConfiguration.getLifecycleState().getCode().equals(
          RECORDSTATUSEntry.NORMAL.getCode())) {
          pgAssociatePaymentConfiguration.cancel(
            pgAssociatePaymentConfiguration.getVersionNo());
        }
      }
      // END, CR00168459

      // BEGIN, CR00235789, AK

      cancelEventDispatcherFactory.get(ProviderGroupAssociateCancelEvents.class).postCancel(
        this, versionNo);
      // END, CR00235789

    } catch (AppException appException) {
      ValidationHelper.addValidationError(appException);
      // END, CR00178886
    }
  }

  /**
   * Creates the Provider Group Association.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    insertEventDispatcherFactory.get(ProviderGroupAssociateInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    providerSecurity.checkProviderGroupSecurity(getProviderGroup());

    super.insert();

    // BEGIN, CR00235789, AK
    insertEventDispatcherFactory.get(ProviderGroupAssociateInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {
    this.setPartOfContract(false);
    super.setNewInstanceDefaults();
  }

  /**
   * Modifies the Provider Group Association.
   *
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_CANNOT_UPDATE_CANCELLED_PROVIDERGROUPASSOCIATE}
   * If record is already canceled.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    modifyEventDispatcherFactory.get(ProviderGroupAssociateModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789
    providerSecurity.checkProviderGroupSecurity(getProviderGroup());
    if (getDtls().recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_CANNOT_UPDATE_CANCELLED_PROVIDERGROUPASSOCIATE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();

    // BEGIN, CR00196855, RPB
    try {
      super.modify(versionNo);
    } catch (InformationalException informationalException) {      
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00196855

    // BEGIN, CR00235789, AK
    modifyEventDispatcherFactory.get(ProviderGroupAssociateModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  // BEGIN, CR00103371, KR
  /**
   * Sets the record status of the provider group association.
   *
   * @param status
   * Contains the record status of the provider group association.
   */
  // BEGIN, CR00177241, PM
  protected void setRecordStatus(RECORDSTATUSEntry status) { 
    // END, CR00177241
    getDtls().recordStatus = status.getCode();
  }

  // END, CR00103371

  /**
   * Validates multiple Provider Group association with Provider.
   *
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_ACTIVE_MEMBER_FROM_TO}
   * If an end dated active association exists.
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_ACTIVE_MEMBER_FROM}
   * If a non end dated active association exists.
   */
  // BEGIN, CR00177241, PM
  protected void validateMultipleAssociations() {
    // END, CR00177241
    Set<ProviderGroupAssociate> providerGroupAssociates = LifecycleHelper.filter(
      providerGroupAssociateDAO.searchProviderGroupsForProvider(getProvider()),
      RECORDSTATUSEntry.NORMAL);

    for (final ProviderGroupAssociate providerGroupAssociate : providerGroupAssociates) {
      if ((getDateRange().overlapsWith(providerGroupAssociate.getDateRange()))
        && getProviderGroup().getID()
          != providerGroupAssociate.getProviderGroup().getID()) {
        if (providerGroupAssociate.getDateRange().isEnded()) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_ACTIVE_MEMBER_FROM_TO(
              providerGroupAssociate.getProvider().getName(),
              providerGroupAssociate.getProviderGroup().getName(),
              providerGroupAssociate.getDateRange().start(),
              providerGroupAssociate.getDateRange().end()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        } else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_ACTIVE_MEMBER_FROM(
              providerGroupAssociate.getProvider().getName(),
              providerGroupAssociate.getProviderGroup().getName(),
              providerGroupAssociate.getDateRange().start()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }
      }
    }
  }

  /**
   * Validates details of Provider Group Associate.
   */
  // BEGIN, CR00177241, PM
  protected void validateProviderGroupAssociate() {
    // END, CR00177241
    validateDateWithProviderGroup();

    validateDateWithProvider();

    validateProviderGroupAssociateDateRangeOverlap();

    // BEGIN, CR00089543, JM
    validateDateWithContract();
    // END, CR00089543

    // BEGIN, CR00098154, SG
    validateMultipleAssociations();
    // END, CR00098154

  }

  /**
   * Validates the Provider Group Associate details with Concern Role Provider
   * Group.
   *
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_EARLIER_THAN_ENROLLMENT_DATE_OF_PROVIDERGROUP}
   * If start date of association is earlier than Provider Group start
   * date.
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_LATER_THAN_END_DATE_OF_PROVIDERGROUP}
   * If end date of association is later than the end date of the
   * Provider Group.
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_LATER_THAN_END_DATE_OF_PROVIDERGROUP}
   * If start date of association is later than Provider Group end
   * date.
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_EARLIER_THAN_ENROLLMENT_DATE_OF_PROVIDERGROUP}
   * If end date of association is later than the enrollment date of
   * the Provider Group.
   */
  // BEGIN, CR00177241, PM
  protected void validateDateWithProviderGroup() {
    // END, CR00177241
    final ProviderGroup providerGroup = getProviderGroup();

    if (!this.getDateRange().start().isZero()
      && this.getDateRange().start().before(providerGroup.getRegistrationDate())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_EARLIER_THAN_ENROLLMENT_DATE_OF_PROVIDERGROUP(
          this.getDateRange().start(), providerGroup.getRegistrationDate()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (!this.getDateRange().end().isZero()) {
      if ((!this.getDateRange().end().isZero())
        && this.getDateRange().end().before(providerGroup.getRegistrationDate())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_EARLIER_THAN_ENROLLMENT_DATE_OF_PROVIDERGROUP(
            this.getDateRange().end(), providerGroup.getRegistrationDate()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
      if ((!this.getDateRange().end().isZero())
        && !providerGroup.getEndDate().isZero()
        && this.getDateRange().end().after(providerGroup.getEndDate())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_LATER_THAN_END_DATE_OF_PROVIDERGROUP(
            this.getDateRange().end(), providerGroup.getEndDate()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
    // BEGIN, CR00184935, SSK
    if (!getProviderGroup().getEndDate().isZero()
      && this.getDateRange().start().after(providerGroup.getEndDate())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_LATER_THAN_END_DATE_OF_PROVIDERGROUP(
          this.getDateRange().start(), providerGroup.getEndDate()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END, CR00184935
  }

  /**
   * Validates the Provider Group Associate details with Concern Role Provider.
   *
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_EARLIER_THAN_ENROLLMENT_DATE_OF_PROVIDER}
   * If association start date earlier than the enrollment date of the
   * Provider.
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XFV_END_DATE_EMPTY_AND_END_DATE_OF_PROVIDER_PRESENT}
   * If provider has end date and associates end date is empty.
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_LATER_THAN_END_DATE_OF_PROVIDER}
   * If association start date later than the end date of the
   * Provider.
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_LATER_THAN_END_DATE_OF_PROVIDER}
   * If end date later than the end date of the Provider.
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_EARLIER_THAN_ENROLLMENT_DATE_OF_PROVIDER}
   * If association end date later than the enrollment date of the
   * Provider.
   */
  // BEGIN, CR00177241, PM
  protected void validateDateWithProvider() {
    // END, CR00177241

    final Provider provider = getProvider();

    if (!this.getDateRange().start().isZero()
      && this.getDateRange().start().before(provider.getRegistrationDate())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_EARLIER_THAN_ENROLLMENT_DATE_OF_PROVIDER(
          this.getDateRange().start(), provider.getRegistrationDate()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (!provider.getEndDate().isZero()) {
      if (this.getDateRange().start().after(provider.getEndDate())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_LATER_THAN_END_DATE_OF_PROVIDER(
            this.getDateRange().start(), provider.getEndDate()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
      if ((!this.getDateRange().end().isZero())
        && this.getDateRange().end().before(provider.getRegistrationDate())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_EARLIER_THAN_ENROLLMENT_DATE_OF_PROVIDER(
            this.getDateRange().end(), provider.getRegistrationDate()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
      // BEGIN, CR00184935, SSK
      if ((!this.getDateRange().end().isZero())) {
        // END, CR00184935
        if (this.getDateRange().end().after(provider.getEndDate())) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_LATER_THAN_END_DATE_OF_PROVIDER(
              this.getDateRange().end(), provider.getEndDate()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }
        // BEGIN, CR00184935, SSK
      } else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XFV_END_DATE_EMPTY_AND_END_DATE_OF_PROVIDER_PRESENT(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
      // END, CR00184935
    }
  }

  /**
   * Validates the provider group associate date range overlap for current
   * Provider and Provider Group association.
   *
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_WITH_SAME_PERIORD_EXISTS}
   * Association already exists with end date.
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_WITH_SAME_PERIORD_EXISTS_ASSOCIATE_NOT_HAVE_END_DATE}
   * Association already exists without end date.
   */
  // BEGIN, CR000177241, PM
  protected void validateProviderGroupAssociateDateRangeOverlap() {
    // END, CR00177241
    Set<ProviderGroupAssociate> providerGroupAssociates = providerGroupAssociateDAO.searchByProviderAndProviderGroup(
      this.getProviderGroup(), this.getProvider());

    for (final ProviderGroupAssociate providerGroupAssociate : providerGroupAssociates) {

      if (providerGroupAssociate.getDateRange().overlapsWith(getDateRange())) {

        if (providerGroupAssociate.getID().equals(getID())) {
          continue;
        }

        if (!providerGroupAssociate.getDateRange().end().isZero()) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_WITH_SAME_PERIORD_EXISTS(
              providerGroupAssociate.getProvider().getName(),
              providerGroupAssociate.getDateRange().start(),
              providerGroupAssociate.getDateRange().end()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        } else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_WITH_SAME_PERIORD_EXISTS_ASSOCIATE_NOT_HAVE_END_DATE(
              providerGroupAssociate.getProvider().getName(),
              providerGroupAssociate.getDateRange().start()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }
      }
    }
  }

  // BEGIN, CR00089543, JM
  /**
   * Validates the Provider Group Associate details with Contract Version.
   *
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_LATER_THAN_CONTRACT_START_DATE}
   * Association start date is after start date of Contract.
   * @throws InformationalException
   * {@link PROVIDERGROUPASSOCIATE#ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_BEFORE_THAN_CONTRACT_END_DATE}
   * Association end date is before end date of Contract.
   */
  // BEGIN, CR00177241, PM
  protected void validateDateWithContract() {
    // END, CR00177241

    for (ContractVersion contractVersion : contractVersionDAO.searchBy(
      this.getProviderGroup())) {

      if (contractVersion.getLifecycleState().equals(CONTRACTSTATUSEntry.LIVE)) {

        if (this.getDateRange().start().after(
          contractVersion.getDateRange().start())) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_START_DATE_LATER_THAN_CONTRACT_START_DATE(
              this.getDateRange().start(),
              contractVersion.getDateRange().start()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);

        }
        if (!this.getDateRange().end().isZero()
          && this.getDateRange().end().before(
            contractVersion.getDateRange().end())) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_END_DATE_BEFORE_THAN_CONTRACT_END_DATE(
              this.getDateRange().end(), contractVersion.getDateRange().end()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);

        }

      }
    }
  }

  // END, CR00089543

  // BEGIN, CR00178886, ASN

  /**
   * {@inheritDoc}
   */
  public boolean isProviderGroupToRecievePayments(Date paymentDate)
    throws AppException, InformationalException {

    List<ProviderGroupAssociatePaymentConfiguration> providerGroupAssociatePaymentConfigList = pgAssociatePaymentConfigurationDAO.searchByProviderGroupAssociate(
      this, RECORDSTATUSEntry.NORMAL);

    // Sorts all active payment configuration list based on effective date.
    Collections.sort(providerGroupAssociatePaymentConfigList,
      new Comparator<ProviderGroupAssociatePaymentConfiguration>() {
      public int compare(
        final ProviderGroupAssociatePaymentConfiguration lhs,
        final ProviderGroupAssociatePaymentConfiguration rhs) {
        return lhs.getEffectiveDate().compareTo(rhs.getEffectiveDate());
      }

    });

    DateRange paymentConfigDateRange = new DateRange(Date.getCurrentDate(),
      Date.kZeroDate);

    for (int i = 0; i < providerGroupAssociatePaymentConfigList.size(); i++) {
      if (i == providerGroupAssociatePaymentConfigList.size() - 1) {
        // For the last date range the end date is not set.
        paymentConfigDateRange = new DateRange(
          providerGroupAssociatePaymentConfigList.get(i).getEffectiveDate(),
          Date.kZeroDate);
      } else {
        // Forms continuous date range objects setting effective date as start
        // date and end date of present date range is one day earlier than the
        // start date of next date range.
        paymentConfigDateRange = new DateRange(
          providerGroupAssociatePaymentConfigList.get(i).getEffectiveDate(),
          providerGroupAssociatePaymentConfigList.get(i + 1).getEffectiveDate().addDays(
            -1));
      }

      // Checks payment date falls within which date range and
      // in that payment configuration the
      // value of GroupToReceivePayments indicator.
      if (paymentConfigDateRange.contains(paymentDate)
        && providerGroupAssociatePaymentConfigList.get(i).getGroupToReceivePaymentsInd()) {
        return true;
      }
    }

    return false;
  }

  // END, CR00178886
}
