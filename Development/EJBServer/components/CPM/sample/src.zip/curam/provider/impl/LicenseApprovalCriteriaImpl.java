/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.TRAININGPROGRAMPARTYSTATUSEntry;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.LicenseProviderAndVersionNumberKey;
import curam.message.TRAININGPROGRAM;
import curam.training.impl.TrainingProgram;
import curam.training.impl.TrainingProgramDAO;
import curam.training.impl.TrainingProgramMember;
import curam.training.impl.TrainingProgramMemberDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.LicenseApprovalCriteria}.
 */
// BEGIN, CR00183213, SS
public class LicenseApprovalCriteriaImpl implements LicenseApprovalCriteria {
  // END, CR00183213
  /**
   * LicenseTrainingRequirement DAO Object
   */
  @Inject
  protected LicenseTrainingRequirementDAO licenseTrainingRequirementDAO;

  /**
   * TrainingProgram DAO Object
   */
  @Inject
  protected TrainingProgramDAO trainingProgramDAO;

  /**
   * TrainingProgramMember DAO Object
   */
  @Inject
  protected TrainingProgramMemberDAO trainingProgramMemberDAO;

  /**
   * License DAO Object
   */
  @Inject
  protected LicenseDAO licenseDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  // END, CR00183213
  public LicenseApprovalCriteriaImpl() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * If training requirements are specified for the license type, then all
   * trainings marked as 'Required' must be 'Completed' or 'Waived' for all
   * active provider members. Only those provider members that don't have an End
   * Date or an End Date in the future are considered. If this rule is not
   * satisfied, the user is to be notified and allowed to continue.
   *
   * @param licenseProviderAndVersionNumberKey
   * the key which identifies the license.
   * @return List of Informational messages.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_LICENSE_CANNOT_BE_APPROVED}
   * If the training requirement for provider member is not 'Completed'
   * or 'Waived', the license cannot be approved.
   */
  public InformationalMessageList checkLicenseApprovalCriteria(
    LicenseProviderAndVersionNumberKey licenseProviderAndVersionNumberKey)
    throws InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    InformationalMessageList informationalMessageList = new InformationalMessageList();

    boolean validationFailureInd = false;

    curam.provider.impl.License license = licenseDAO.get(
      licenseProviderAndVersionNumberKey.licenseID);

    Set<LicenseTrainingRequirement> licenseTrainingRequirementSet = licenseTrainingRequirementDAO.searchByLicenseType(
      license.getLicenseType().getCode());

    Set<ProviderMember> providerMemberSet = license.getProvider().getProviderMembers();

    ArrayList<TrainingProgram> trainingProgramList = new ArrayList<TrainingProgram>();

    HashMap<Long, ProviderMember> providerMemberHashMap = new HashMap<Long, ProviderMember>();

    // Get all the managed and non managed training programs for all the
    // provider members of the provider.
    for (ProviderMember providerMember : providerMemberSet) {
      providerMemberHashMap.put(providerMember.getParty().getID(),
        providerMember);

      Set<TrainingProgram> trainingProgramManagedSet = trainingProgramDAO.searchBy(
        providerMember.getParty().getID(), true, RECORDSTATUSEntry.NORMAL);

      for (TrainingProgram trainingProgram : trainingProgramManagedSet) {
        trainingProgramList.add(trainingProgram);
      }

      Set<TrainingProgram> trainingProgramNotManagedSet = trainingProgramDAO.searchBy(
        providerMember.getParty().getID(), false, RECORDSTATUSEntry.NORMAL);

      for (TrainingProgram trainingProgram : trainingProgramNotManagedSet) {
        trainingProgramList.add(trainingProgram);
      }
    }

    // Get all the training programs for the provider which are managed and
    // non-managed through agency.
    Set<TrainingProgram> trainingProgramManagedProviderSet = trainingProgramDAO.searchBy(
      license.getProvider().getID(), true, RECORDSTATUSEntry.NORMAL);

    for (TrainingProgram trainingProgram : trainingProgramManagedProviderSet) {
      trainingProgramList.add(trainingProgram);
    }

    Set<TrainingProgram> trainingProgramNotManagedProviderSet = trainingProgramDAO.searchBy(
      license.getProvider().getID(), false, RECORDSTATUSEntry.NORMAL);

    for (TrainingProgram trainingProgram : trainingProgramNotManagedProviderSet) {
      trainingProgramList.add(trainingProgram);
    }

    // Get all the training program members for which there is license training
    // requirement marked as Required.
    for (LicenseTrainingRequirement licenseTrainingRequirement : licenseTrainingRequirementSet) {

      if (validationFailureInd) {
        break;
      }
      if (TrainingCompletionEntry.REQUIRED.equals(
        licenseTrainingRequirement.getCompletion())) {

        // BEGIN, CR00121596, RPB
        // If there are no training programs, informational should be thrown that
        // license cannot be approved.
        if (trainingProgramList.size() == 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            new AppException(
              TRAININGPROGRAM.ERR_TRAININGPROGRAM_XRV_LICENSE_CANNOT_BE_APPROVED),
              curam.core.impl.CuramConst.gkEmpty,
              InformationalElement.InformationalType.kWarning,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
          validationFailureInd = true;
        }
        // END, CR00121596

        for (TrainingProgram trainingProgram : trainingProgramList) {
          if (validationFailureInd) {
            break;
          }
          if (trainingProgram.getTraining() != null
            && trainingProgram.getTraining().getID().equals(
              licenseTrainingRequirement.getTraining().getID())) {
            Set<TrainingProgramMember> trainingProgramMemberSet = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
              trainingProgram.getID());

            // Check if the training program members are active and are marked
            // Complete or Waived and the corresponding provider member has no
            // end date set or end date is in future.
            for (TrainingProgramMember trainingProgramMember : trainingProgramMemberSet) {

              // BEGIN CR00129970, RD
              ProviderMember providerMember = providerMemberHashMap.get(
                trainingProgramMember.getPartyConcernRole().getID());

              // END CR00129970

              if (!TRAININGPROGRAMPARTYSTATUSEntry.CANCELED.equals(
                trainingProgramMember.getLifecycleState())
                  && !TRAININGPROGRAMPARTYSTATUSEntry.COMPLETE.equals(
                    trainingProgramMember.getLifecycleState())
                    && !TRAININGPROGRAMPARTYSTATUSEntry.WAIVED.equals(
                      trainingProgramMember.getLifecycleState())
                      && (RECORDSTATUSEntry.NORMAL.equals(
                        providerMember.getLifecycleState())
                          && (providerMember.getDateRange().end().isZero()
                            || providerMember.getDateRange().endsInFuture()))) {
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
                  new AppException(
                    TRAININGPROGRAM.ERR_TRAININGPROGRAM_XRV_LICENSE_CANNOT_BE_APPROVED),
                    curam.core.impl.CuramConst.gkEmpty,
                    InformationalElement.InformationalType.kWarning,
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                    1);
                validationFailureInd = true;
                break;
              }
            }
          }
        }
      }
    }

    // Assign informational messages to return struct
    String warnings[] = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMessage infoMessage = new InformationalMessage();

      infoMessage.messageTest = warnings[i];
      informationalMessageList.dtls.addRef(infoMessage);
    }

    return informationalMessageList;
  }
}
