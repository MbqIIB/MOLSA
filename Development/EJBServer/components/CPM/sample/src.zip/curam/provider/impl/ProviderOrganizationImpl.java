/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Collections;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.CASEPARTICIPANTROLETYPEEntry;
import curam.codetable.impl.COMMUNICATIONMETHODEntry;
import curam.codetable.impl.CONCERNROLESTATUSEntry;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.LANGUAGEEntry;
import curam.codetable.impl.MEETINGATTENDEETYPEEntry;
import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.ContractVersionDAO;
import curam.core.impl.ConcernRoleAdapter;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.struct.ConcernRoleDtls;
import curam.cpm.impl.CPMConstants;
import curam.participant.impl.PhoneNumber;
import curam.participant.impl.PhoneNumberDAO;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.impl.Address;
import curam.piwrapper.impl.AddressDAO;
import curam.piwrapper.impl.EmailAddress;
import curam.piwrapper.impl.EmailAddressDAO;
import curam.piwrapper.impl.MeetingAttendeeInfo;
import curam.piwrapper.participantmanager.impl.ConcernRoleRelationship;
import curam.piwrapper.participantmanager.impl.ConcernRoleRelationshipDAO;
import curam.piwrapper.webaddress.impl.WebAddress;
import curam.piwrapper.webaddress.impl.WebAddressDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.Date;
import curam.util.type.DeepCloneable;


/**
 * Common processing between Providers and Provider Groups.
 *
 * @param <CONCRETE_DTLS>
 * the concrete generated Dtls struct
 */
public abstract class ProviderOrganizationImpl<CONCRETE_DTLS extends DeepCloneable> extends SingleTableEntityImpl<CONCRETE_DTLS> implements
  ProviderOrganization {

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for addProviderMember events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderOrganizationAddProviderMemberEvents> addProviderMemberEventDispatcherFactory;

  // END, CR00235789

  /**
   * concernRoleAdapter instance of ConcernRoleAdapter.
   */
  protected static final ConcernRoleAdapter concernRoleAdapter = new ConcernRoleAdapter();

  /**
   * contractVersion DAO object.
   */
  @Inject
  protected ContractVersionDAO contractVersionDAO;

  /**
   * providerMember DAO object.
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  /**
   * providerParticipant DAO object.
   */
  @Inject
  protected ProviderParticipantDAO providerParticipantDAO;

  /**
   * phoneNumber DAO object.
   */
  @Inject
  protected PhoneNumberDAO phoneNumberDAO;

  /**
   * phoneNumber DAO object.
   */
  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  /**
   * Data access object reference for ProviderIncidentDAO
   */
  @Inject
  protected ProviderIncidentDAO providerIncidentDAO;

  @Inject
  protected EmailAddressDAO emailAddressDAO;

  @Inject
  protected MeetingAttendeeInfo attendeeInfo;

  // BEGIN, CR00236083, GP
  /**
   * Reference to Web Address DAO.
   */
  @Inject
  protected WebAddressDAO webAddressDAO;
  // END, CR00236083

  /**
   * Reference to Address DAO.
   */
  @Inject
  protected AddressDAO addressDAO;
  
  /**
   * Reference to concern Role Relationship DAO.
   */
  @Inject
  protected ConcernRoleRelationshipDAO concernRoleRelationshipDAO;
  
  /**
   * {@inheritDoc}
   */
  public Set<ProviderParticipant> getProviderParticipants() {
    return Collections.unmodifiableSet(providerParticipantDAO.searchBy(this));
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// none required
  }

  /**
   * {@inheritDoc}
   */
  public boolean addProviderMember(
    @SuppressWarnings(CPMConstants.kUnused) ProviderMember providerMember) {

    // BEGIN, CR00235789, AK
    // Raise the pre addProviderMember provider organization event.
    addProviderMemberEventDispatcherFactory.get(ProviderOrganizationAddProviderMemberEvents.class).preAddProviderMember(
      this, providerMember);
    // END, CR00235789

    // BEGIN, CR00235789, AK
    // Raise the post addProviderMember provider organization event.
    addProviderMemberEventDispatcherFactory.get(ProviderOrganizationAddProviderMemberEvents.class).postAddProviderMember(
      this, providerMember, false);
    // END, CR00235789

    return false;
  }

  /**
   * {@inheritDoc}
   */
  public Set<ContractVersion> getContracts() {
    return Collections.unmodifiableSet(contractVersionDAO.searchBy(this));
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderMember> getProviderMembers() {
    return Collections.unmodifiableSet(providerMemberDAO.searchBy(this));
  }

  /**
   * Gets the name of the Provider.
   *
   * @return The name of the Provider.
   */
  public String getName() {
    return getConcernRoleDtls().concernRoleName;
  }

  /**
   * Gets the primary address id of the Provider.
   *
   * @return the primary address id of the Provider.
   */
  public Long getPrimaryAddressID() {
    return getConcernRoleDtls().primaryAddressID;
  }

  /**
   * method to read concern role details for a provider/provider group
   *
   * @return ConcernRoleDtls
   */
  protected abstract ConcernRoleDtls getConcernRoleDtls();

  /**
   * Gets the registration Date of the Provider.
   *
   * @return The registration Date of the Provider.
   */
  public Date getRegistrationDate() {
    return getConcernRoleDtls().registrationDate;
  }

  /**
   * Gets the start Date of the Provider.
   *
   * @return The start Date of the Provider.
   */
  public Date getStartDate() {
    return getConcernRoleDtls().startDate;
  }

  /**
   * Gets the end Date of the Provider.
   *
   * @return The end Date of the Provider.
   */
  public Date getEndDate() {
    return getConcernRoleDtls().endDate;
  }

  /**
   * Gets the ConcernRoleType of the Provider.
   *
   * @return The ConcernRoleType of the Provider.
   */
  public CONCERNROLETYPEEntry getConcernRoleType() {
    return CONCERNROLETYPEEntry.get(getConcernRoleDtls().concernRoleType);
  }

  /**
   * Gets the comments for the Provider.
   *
   * @return The comments for the Provider.
   */
  public String getComments() {
    return getConcernRoleDtls().comments;
  }

  /**
   * Gets the preferred communication method for the Provider.
   *
   * @return The preferred communication method for the Provider.
   */
  public COMMUNICATIONMETHODEntry getPreferredCommunicationMethod() {
    return COMMUNICATIONMETHODEntry.get(getConcernRoleDtls().prefCommMethod);
  }

  /**
   * Gets the preferred language for the Provider.
   *
   * @return The preferred language for the Provider.
   */
  public LANGUAGEEntry getPreferredLanguage() {
    return LANGUAGEEntry.get(getConcernRoleDtls().preferredLanguage);
  }

  /**
   * Gets the creation date.
   *
   * @return The creation date.
   */
  public Date getCreationDate() {
    return getConcernRoleDtls().creationDate;
  }

  /**
   * Gets the primary phone number of the Provider.
   *
   * @return The primary phone number of the Provider.
   */
  public PhoneNumber getPrimaryPhoneNumber() {
    final long primaryPhoneNumberID = getConcernRoleDtls().primaryPhoneNumberID;

    return primaryPhoneNumberID == 0
      ? null
      : phoneNumberDAO.get(primaryPhoneNumberID);
  }

  /**
   * Gets the primary alternate id of the Provider.
   *
   * @return The primary alternate id of the Provider.
   */
  public String getPrimaryAlternateID() {
    return getConcernRoleDtls().primaryAlternateID;
  }

  /**
   * Gets the primary email address id of the Provider.
   *
   * @return The primary email address id of the Provider.
   */
  public Long getPrimaryEmailAddressID() {
    return getConcernRoleDtls().primaryEmailAddressID;
  }

  /**
   * Gets the status of the Provider.
   *
   * @return The status of the Provider.
   */
  public curam.codetable.impl.CONCERNROLESTATUSEntry getStatusCode() {
    return CONCERNROLESTATUSEntry.get(getConcernRoleDtls().statusCode);
  }

  /**
   * Gets the registered name of the Provider.
   *
   * @return The registered name of the Provider.
   */
  public String getRegisteredUserName() {
    return getConcernRoleDtls().regUserName;
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderParty> getProviderParties() {
    return Collections.unmodifiableSet(providerPartyDAO.searchBy(this));
  }

  /**
   * {@inheritDoc}
   */
  public List<ProviderIncident> getIncidents() {
    return Collections.unmodifiableList(
      providerIncidentDAO.searchByParticipant(getID()));
  }

  // BEGIN, CR00236083, GP
  /**
   * Gets the web address of the provider or provider group. Returns null if
   * there is no web address.
   *
   * @return Web address of the provider or provider group.
   */
  public WebAddress getWebAddress() {

    long primaryWebAddressID = getConcernRoleDtls().primaryWebAddressID;

    if (0 != primaryWebAddressID) {

      WebAddress webAddress = webAddressDAO.get(primaryWebAddressID);

      if (null != webAddress) {
        return webAddress;
      }

    }

    return null;
  }

  // END, CR00236083

  public EmailAddress getEmailAddress() {

    EmailAddress retVal = null;

    String primaryEmailAddressID = String.valueOf(getPrimaryEmailAddressID());

    if (!(getPrimaryEmailAddressID() == 0)) {

      EmailAddress emailAddressObj = emailAddressDAO.getEmailAddress(
        primaryEmailAddressID);

      if (emailAddressObj != null) {
        retVal = emailAddressObj;
      }

    }

    return retVal;

  }

  public String getCaseRole(CaseHeader caseHeader) throws InformationalException {

    CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();

    try {

      CaseIDParticipantRoleKey key = new CaseIDParticipantRoleKey();

      key.participantRoleID = getID();
      key.caseID = caseHeader.getID();

      CaseParticipantRoleDtlsList roleDetailsList = caseParticipantRoleObj.searchByParticipantRoleAndCase(
        key);

      if (roleDetailsList.dtls.size() > 0) {
        String roleType = curam.util.type.CodeTable.getOneItem(
          CASEPARTICIPANTROLETYPEEntry.TABLENAME,
          roleDetailsList.dtls.item(0).typeCode);

        return roleType;
      }

    } catch (AppException e) {

      ValidationHelper.addValidationError(e);

    }

    return CuramConst.gkEmpty;
  }

  public MeetingAttendeeInfo getMeetingAttendeeInfo() {

    attendeeInfo.setAttendeeName(getName());
    attendeeInfo.setAttendeeType(MEETINGATTENDEETYPEEntry.PARTICIPANT);
    attendeeInfo.setConcernRoleID(getID());
    attendeeInfo.setEmailAddress(getEmailAddress());
    attendeeInfo.setRelatedIDString(getID().toString());
    attendeeInfo.setUserName(CuramConst.gkEmpty);

    return attendeeInfo;
  }

  /**
   * Gets the primary address of the concern role.
   *
   * @return The address of the concern role
   */
  public Address getPrimaryAddress() {
    return addressDAO.get(getConcernRoleDtls().primaryAddressID);
  }
  
  /**
   * {@inheritDoc}
   */
  public List<ConcernRoleRelationship> listRelationships() {

    return concernRoleRelationshipDAO.listActiveByConcernRole(this);

  }
}
