/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.util.persistence.StandardEntity;
import java.util.List;


/**
 * Accessor interface for {@linkplain License}.
 */
public interface LicenseAccessor extends StandardEntity {

  /**
   * Returns the issuer of the license.
   *
   * @return The issuer of the license.
   */
  public LicenseIssuerEntry getIssuer();

  /**
   * Returns the number of the license.
   *
   * @return The number of the license.
   */
  public String getLicenseNumber();

  /**
   * Returns the type of the license.
   *
   * @return The type of the license.
   */
  public LicenseTypeEntry getLicenseType();

  /**
   * Returns the user who entered the license.
   *
   * @return The user who entered the license.
   */
  public String getUser();

  /**
   * Returns the maximum places on the license.
   *
   * @return The maximum places on the license.
   */
  public int getMaximumPlaces();

  /**
   * Returns true if this license has been renewed, otherwise false.
   *
   * @return Whether this license has been renewed.
   */
  public boolean isRenewed();

  /**
   * Gets the immutable list of history of changes to the state of this license,
   * returned in ascending date/time order (i.e. earliest first).
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable list of history of changes to the state of this
   * license.
   */
  public List<? extends LicenseStatusHistoryAccessor> getStatusHistory();

  /**
   * Returns the reason why the license is currently rejected.
   * <p>
   * Returns
   * {@linkplain curam.provider.impl.LicenseRejectionReasonEntry#NOT_SPECIFIED}
   * if the license is not currently rejected.
   *
   * @return The reason why the license is currently rejected.
   */
  public LicenseRejectionReasonEntry getRejectionReason();

  /**
   * Returns the reason why the license is currently suspended.
   * <p>
   * Returns
   * {@linkplain curam.provider.impl.LicenseSuspensionReasonEntry#NOT_SPECIFIED}
   * if the license is not currently suspended.
   *
   * @return The reason why the license is currently suspended.
   */
  public LicenseSuspensionReasonEntry getSuspensionReason();

  /**
   * Return the immutable provider on the license.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable provider on the license.
   */
  public ProviderAccessor getProvider();
}
