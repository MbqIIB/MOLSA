/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.Inject;
import curam.cpm.sl.entity.impl.ProviderBackgroundCheckAdapter;
import curam.cpm.sl.entity.impl.ProviderSpecialtyAdapter;
import curam.cpm.sl.entity.struct.ProviderBackgroundCheckDtls;
import curam.events.BACKGROUNDCHECK;
import curam.events.PROVIDERMANAGEMENT;
import curam.message.impl.BACKGROUNDCHECKExceptionCreator;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.util.events.impl.EventService;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.persistence.ValidationHelper;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.StringHelper;


// BEGIN, CR00183213, SS
public class BackgroundCheckImpl extends SingleTableLogicallyDeleteableEntityImpl<ProviderBackgroundCheckDtls>
  implements BackgroundCheck {
  // END, CR00183213

  /**
   * Injecting the Data Access Object for Provider Member
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected BackgroundCheckImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213
  /**
   * {@inheritDoc}
   */
  public BackgroundCheckTypeEntry getType() {
    return BackgroundCheckTypeEntry.get(getDtls().type);
  }

  /**
   * {@inheritDoc}
   */
  public BackgroundCheckResultEntry getResult() {
    return BackgroundCheckResultEntry.get(getDtls().result);

  }

  /**
   * {@inheritDoc}
   */
  public void setType(final BackgroundCheckTypeEntry type) {
    getDtls().type = type.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setResult(final BackgroundCheckResultEntry result) {

    getDtls().result = result.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public ProviderMember getProviderMember() {
    final long id = getDtls().providerPartyID;

    return id == 0 ? null : providerMemberDAO.get(id);
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  /**
   * Sets the daterange(request date and receipt date) of the provider
   * Background Check.
   *
   * @param value
   * Comment entered.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_COMMENTS_ABOVE_MAXIMUM_LENGTH} -
   * If the comment is more than the maximum length allowed. </li>
   * </ul>
   */

  public void setComments(String value) {
    // trim the input value
    value = StringHelper.trim(value);

    // if comments is greater than maximum allowed length, throw validation
    // error
    if (value.length() > ProviderSpecialtyAdapter.kMaxLength_comments) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_COMMENTS_ABOVE_MAXIMUM_LENGTH(
          ProviderBackgroundCheckAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          3);
    }

    getDtls().comments = value;
  }

  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_FV_PROVIDER_MEMBER_EMPTY} -
   * If the provider member is not entered. </li>
   * <li>
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_FV_TYPE_EMPTY} -
   * If the type is not entered. </li>
   * <li>
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_FV_RESULT_EMPTY} -
   * If the result is not entered. </li>
   * <li>
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_FV_REQUEST_DATE_EMPTY} -
   * If the request date is not entered. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {
    // if provider member is empty
    if (getDtls().providerPartyID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_FV_PROVIDER_MEMBER_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // if type is empty.
    if (this.getType().equals(BackgroundCheckTypeEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_FV_TYPE_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // if result is empty
    if (this.getResult().equals(BackgroundCheckResultEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_FV_RESULT_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // if request date is empty
    if (getDateRange().start().isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_FV_REQUEST_DATE_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * Validates that all the field values held are valid with respect to each
   * other.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECKFAILUREREASON_XRV_RECEIPTDATE_SPECIFIED_IF_RESULT_PASS_FAIL} -
   * If the receipt date not entered with result specified as pass or fail.
   * </li>
   * <li>
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECKFAILUREREASON_XRV_RECEIPTDATE_SPECIFIED_IF_RESULT_UNDER_INVESTIGATION} -
   * If the receipt date entered with result specified as under investigation.
   * </li>
   * <li>
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_XRV_EXPIRYDATE_MUST_NOT_BE_ENTERED_WHEN_RESULT_UNDERINVESTIGATION} -
   * If the expiry date entered with result specified as under investigation.
   * </li>
   * </ul>
   */
  public void crossFieldValidation() {

    if ((getResult().equals(BackgroundCheckResultEntry.PASS)
      || getResult().equals(BackgroundCheckResultEntry.FAIL))
        && !getDateRange().isEnded()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECKFAILUREREASON_XRV_RECEIPTDATE_SPECIFIED_IF_RESULT_PASS_FAIL(
          BackgroundCheckResultEntry.get(getDtls().result).getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (getResult().equals(BackgroundCheckResultEntry.UNDERINVESTIGATION)
      && getDateRange().isEnded()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECKFAILUREREASON_XRV_RECEIPTDATE_SPECIFIED_IF_RESULT_UNDER_INVESTIGATION(
          BackgroundCheckResultEntry.get(getDtls().result).getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    if (getResult().equals(BackgroundCheckResultEntry.UNDERINVESTIGATION)
      && !getExpiryDate().isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_XRV_EXPIRYDATE_MUST_NOT_BE_ENTERED_WHEN_RESULT_UNDERINVESTIGATION(
          BackgroundCheckResultEntry.get(getDtls().result).getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * Validates that changes made to background check are
   * consistent with other entities.
   *
   * <p>
   * It adds the following informational exceptions to the validation
   * helper when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_XRV_REQUESTDATE_CANNOT_EARLIER_PROVIDERMEMBER_FROM_DATE} -
   * If the request date is before the provider member from date.</li>
   * <li>
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_XRV_REQUESTDATE_CANNOT_EARLIER_PROVIDERMEMBER_DATE_RANGE} -
   * If the request date is not within the provider member association
   * period. </li>
   * </ul>
   */

  public void crossEntityValidation() {

    DateRange providerMemberDateRange = new DateRange(
      getProviderMember().getDateRange().start(),
      getProviderMember().getDateRange().end());

    // if the request date earlier than the from date the provider member
    if (getDateRange().startsBefore(providerMemberDateRange.start())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_XRV_REQUESTDATE_CANNOT_EARLIER_PROVIDERMEMBER_FROM_DATE(
          providerMemberDateRange.start()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // if the request date earlier than the from date the provider
    // member,having
    // an end date or
    // request date starts after the provider member date range
    if ((getDateRange().startsBefore(providerMemberDateRange.start())
      && providerMemberDateRange.isEnded())
        || getDateRange().startsAfterEndOf(providerMemberDateRange)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_XRV_REQUESTDATE_CANNOT_EARLIER_PROVIDERMEMBER_DATE_RANGE(
          providerMemberDateRange.start(), providerMemberDateRange.end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  /**
   * Sets the daterange(request date and receipt date) of the provider
   * Background Check.
   *
   * @param value
   * The daterange of the background check to be set.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_XFV_REQUESTDATE_LATER_THAN_RECEIPTDATE} -
   * If the request date is later than the receipt date. </li>
   * </ul>
   */
  public void setDateRange(DateRange value) {

    getDtls().requestDate = value.start();
    getDtls().receiptDate = value.end();

    if (getDateRange().isEnded()
      && getDateRange().start().after(getDateRange().end())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_XFV_REQUESTDATE_LATER_THAN_RECEIPTDATE(
          getDateRange().start(), getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {
    return new DateRange(getDtls().requestDate, getDtls().receiptDate);
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {
    getDtls().recordStatus = curam.codetable.impl.RECORDSTATUSEntry.NORMAL.getCode();
  }

  /**
   * Creates a back ground check record and raises a workflow event.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void insert() throws InformationalException {

    super.insert();

    // Raise an event for background check creation,
    // which would be caught by the workflow and process the activity
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = PROVIDERMANAGEMENT.BACKGROUNDCHECKCREATED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
      ValidationHelper.failIfErrorsExist();
    }

    // raise event if result is under investigation
    if (getResult().equals(BackgroundCheckResultEntry.UNDERINVESTIGATION)) {
      final curam.util.events.struct.Event resultEvent = new curam.util.events.struct.Event();

      resultEvent.eventKey = BACKGROUNDCHECK.BACKGROUNDCHECK_RESULT_AS_UNDER_INVESTIGATION;
      resultEvent.primaryEventData = getID();

      try {
        EventService.raiseEvent(resultEvent);
      } catch (AppException ex) {
        ValidationHelper.addValidationError(ex);
      }
    }
  }

  /**
   * Modifies the back ground check and raises a workflow event.
   *
   * @param versionNo
   * The version number of the record to be modified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modify(final Integer versionNo) throws InformationalException {
    super.modify(versionNo);

    // Raise an event for background check update,
    // which would be caught by the workflow and process the activity
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = PROVIDERMANAGEMENT.BACKGROUNDCHECKUPDATED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
      ValidationHelper.failIfErrorsExist();
    }

    // raise event if result is under investigation
    if (getResult().equals(BackgroundCheckResultEntry.UNDERINVESTIGATION)) {
      final curam.util.events.struct.Event resultEvent = new curam.util.events.struct.Event();

      resultEvent.eventKey = BACKGROUNDCHECK.BACKGROUNDCHECK_RESULT_AS_UNDER_INVESTIGATION;
      resultEvent.primaryEventData = getID();

      try {
        EventService.raiseEvent(resultEvent);
      } catch (AppException ex) {
        ValidationHelper.addValidationError(ex);
      }
    }
  }

  /**
   * Cancels the back ground check and raises a workflow event.
   *
   * @param versionNo
   * The version number of the record to be canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void cancel(final int versionNo) throws InformationalException {

    super.cancel(versionNo);

    // raise post-cancel event
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = BACKGROUNDCHECK.BACKGROUNDCHECK_CANCELED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
  }

  /**
   * Sets the expiry date of the provider Background Check.
   *
   * @param value
   * The expiry date of the background check to be set.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_FV_EXPIRY_MUST_BE_ON_OR_AFTER_RECEIPT_DATE} -
   * If the expiry date is before the receipt date. </li>
   * </ul>
   */
  public void setExpiryDate(Date value) {

    getDtls().expiryDate = value;

    if (!getExpiryDate().isZero()
      && getExpiryDate().before(getDateRange().end())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_FV_EXPIRY_MUST_BE_ON_OR_AFTER_RECEIPT_DATE(
          getExpiryDate(), getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  /**
   * {@inheritDoc}
   */
  public Date getExpiryDate() {
    return getDtls().expiryDate;
  }

}
