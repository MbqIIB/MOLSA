/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.OptimisticLockRemovable;
import curam.util.persistence.helper.LogicallyDeleteable;


/**
 * The provider types for the provider.
 *
 * The type will be a sub-categorization of the provider category. For example a
 * provider in a provider category of Foster Care may have provider types for
 * this category of Traditional Foster Care Home, Treatment Foster Care Home or
 * Emergency Care Home.
 */
@ImplementedBy(ProviderTypeImpl.class)
public interface ProviderType extends Insertable, LogicallyDeleteable,
    OptimisticLockModifiable, OptimisticLockRemovable, ProviderTypeAccessor {

  /**
   * Sets the provider type. The type will be a sub-categorization of the
   * provider category.
   *
   * @param value
   * The provider type.
   */
  void setType(String value);

  /**
   * Gets the immutable provider category period associated with this provider
   * type.
   *
   * @return The immutable provider category period associated with this
   * provider type.
   */
  ProviderCategoryPeriod getProviderCategoryPeriod();

  /**
   * Sets the provider category period associated with this provider type.
   *
   * @param value
   * The provider category period.
   */
  void setProviderCategoryPeriod(final ProviderCategoryPeriod value);

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider type events functionality surrounding the insert
   * method.
   */
  public interface ProviderTypeInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderType#insert}
     *
     * @param providerType
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ProviderTypeAccessor providerType)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderType#insert}
     *
     * @param providerType
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ProviderTypeAccessor providerType)
      throws InformationalException;
  }


  /**
   * Interface to the provider type events functionality surrounding the cancel
   * method.
   */
  public interface ProviderTypeCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderType#cancel}
     *
     * @param providerType
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(ProviderTypeAccessor providerType, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderType#cancel}
     *
     * @param providerType
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(ProviderTypeAccessor providerType, int versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the provider type events functionality surrounding the modify
   * method.
   */
  public interface ProviderTypeModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderType#modify}
     *
     * @param providerType
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(ProviderTypeAccessor providerType, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderType#modify}
     *
     * @param providerType
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(ProviderTypeAccessor providerType, Integer versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the provider type events functionality surrounding the remove
   * method.
   */
  public interface ProviderTypeRemoveEvents {

    /**
     * Event interface invoked before the main body of the remove method.
     * {@linkplain curam.provider.impl.ProviderType#remove}
     *
     * @param providerType
     * The object instance as it was before the main body of the remove
     * method.
     * @param versionNo
     * The parameter as passed to the remove method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preRemove(ProviderTypeAccessor providerType, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the remove method.
     * {@linkplain curam.provider.impl.ProviderType#remove}
     *
     * @param providerType
     * The object instance as it was after the main body of the remove
     * method.
     * @param versionNo
     * The parameter as passed to the remove method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postRemove(ProviderTypeAccessor providerType, Integer versionNo)
      throws InformationalException;
  }
  // END, CR00144381
}
