/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;
import curam.participant.impl.PhoneNumberAccessor;
import curam.util.persistence.StandardEntity;
import curam.workspaceservices.localization.impl.LocalizableTextAccessor;


/**
 * Accessor interface for {@linkplain ProviderServiceCenter}.
 *
 */
public interface ProviderServiceCenterAccessor extends StandardEntity {

  /**
   * Gets the address of the Service Center.
   *
   * @return long the address id to be set to the service center.
   */
  long getAddressID();

  // BEGIN, CR00178272, AK
  /**
   * Gets the immutable localized text object for the attribute areas served
   * information.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable localized text object.
   */
  LocalizableTextAccessor getAreasServedInfo();
  
  /**
   * Returns the localized text ID of the provider service center attribute,
   * areas served information.
   *
   * @return The areas served information text ID.
   */
  long getAreasServedInfoTextID();

  /**
   * Gets the immutable localized text object for the attribute, client
   * information.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable localized text object.
   */
  LocalizableTextAccessor getClientInfo();  
  
  /**
   * Returns the localized text ID of the provider service center attribute,
   * client information.
   *
   * @return The client information text ID.
   */  
  long getClientInfoTextID();
  // END, CR00178272

  /**
   * Gets the email address of the Service Center.
   *
   * @return long containing the email address id of the service center.
   */
  long getEmailAddressID();

  /**
   * Gets the name of the Service Center.
   *
   * @return String containing the name of the service center.
   */
  String getName();

  /**
   * Gets the accessor for phone number of the Service Center.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return PhoneNumber of the service center.
   */
  PhoneNumberAccessor getPhoneNumber();

  /**
   * Gets the accessor of the provider for the Service Center.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return Provider for the service center.
   */
  ProviderAccessor getProvider();

  /**
   * Gets the accessor of current Provider Service Center.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return ProviderServiceCenter service center for the Provider.
   */
  ProviderServiceCenterAccessor getProviderServiceCenter();
  
  /**
   * Gets the accessors of provider offering for the Service Center.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return Set<ServiceCenterProviderOffering> the set of provider offerings
   * for the service center.
   */
  Set<? extends ServiceCenterProviderOfferingAccessor> getServiceCenterProviderOffering();
  
  /**
   * Gets the web address of the Service Center.
   *
   * @return long containing the web address id of the service center.
   */
  long getWebAddressID();
  
}
