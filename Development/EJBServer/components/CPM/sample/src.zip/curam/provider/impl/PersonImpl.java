/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import curam.message.PERSON;
import curam.message.impl.PERSONExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.CodeTableEntry;
import curam.util.type.DateTimeRange;


/**
 * Standard implementation of {@linkplain curam.provider.impl.Person} entity.
 */
// BEGIN, CR00183213, SS
public class PersonImpl extends ProviderPartyImpl implements Person {

  /**
   * Constructor for the class.
   */
  protected PersonImpl() {
    // END, CR00183213
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {
    super.setNewInstanceDefaults();
    setCategory(ProviderPartyCategoryEntry.UNASSIGNED);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public CodeTableEntry getTypeCode() {
    return ProviderParticipantTypeEntry.NOT_SPECIFIED;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();
  }

  // ___________________________________________________________________________
  /**
   * Cross entity validations while creating a person.
   *
   * @throws InformationalException
   * {@link PERSON#ERR_PERSON_XRV_FROM_DATE_LATER_THAN_DATE_OF_BIRTH} -
   * If from date is later than the date of birth.
   * {@link PERSON#ERR_PERSON_XRV_PERSON_WITH_DATE_OF_DEATH} -
   * If date of death is present.
   */
  public void crossEntityValidation() {

    if (getParty() instanceof curam.participant.person.impl.Person) {
      curam.participant.person.impl.Person person = (curam.participant.person.impl.Person) getParty();

      // Check if person date of birth is later than from date
      if (person.getDateOfBirth().after(getDateRange().start())) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PERSONExceptionCreator.ERR_PERSON_XRV_FROM_DATE_LATER_THAN_DATE_OF_BIRTH(
            getDateRange().start(), person.getName()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
      // Check if person date of death is present
      if (!person.getDateOfDeath().isZero()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PERSONExceptionCreator.ERR_PERSON_XRV_PERSON_WITH_DATE_OF_DEATH(
            person.getName(), person.getDateOfDeath()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

    }
  }

  // BEIN, CR00320064, SSK
  public void setDateTimeRange(final DateTimeRange dateTimeRange) {
    
    getDtls().startDateTime = dateTimeRange.start();
    getDtls().endDateTime = dateTimeRange.end();
     
  }
  
  // END, CR00320064
}
