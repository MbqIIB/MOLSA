/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.fact.ProviderPartyFactory;
import curam.cpm.sl.entity.struct.PartyConcernRoleDetails;
import curam.cpm.sl.entity.struct.PartyConcernRoleDetailsList;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ProviderPartyDtls;
import curam.cpm.util.impl.TimeZoneUtil;
import curam.message.PROVIDER;
import curam.message.PROVIDERPARTY;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.GENERALExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.message.impl.PROVIDERPARTYExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.participant.person.impl.Person;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.CodeTableEntry;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateTime;


/**
 * Standard implementation of {@linkplain curam.provider.impl.ProviderParty}.
 */
// BEGIN, CR00183213, SS
public abstract class ProviderPartyImpl extends SingleTableLogicallyDeleteableEntityImpl<ProviderPartyDtls> implements
  ProviderParty {
  // END, CR00183213

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderPartyInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderPartyModifyEvents> modifyEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderPartyCancelEvents> cancelEventDispatcherFactory;

  // END, CR00235789

  /**
   * */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * */
  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  /**
   * */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /**
   * */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  // BEGIN, CR00205270, ASN
  /**
   * Reference to Provider Member DAO.
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  // END, CR00205270

  /**
   * Sets the "lifetime" of the provider party.
   *
   * @param value
   * The "lifetime" of the provider party.
   *
   * <p>
   * It adds the following informational exceptions to the validation
   * helper when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_XRV_TO_DATE_EARLIER_THAN_FROM_DATE}
   * - If the to date is earlier than the from date.</li>
   * </ul>
   */
  public void setDateRange(DateRange value) {

    /*
     * field validation
     */

    if (!value.isValidRange()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_TO_DATE_EARLIER_THAN_FROM_DATE(
          value.end(), value.start()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    getDtls().startDate = value.start();
    getDtls().endDate = value.end();
    // BEGIN, CR00320064, SSK
    getDtls().startDateTime = new DateTime(
      TimeZoneUtil.getEquivalentServerCalendar(value.start()));
    getDtls().endDateTime = new DateTime(
      TimeZoneUtil.getEquivalentServerCalendar(value.end()));
    // END, CR00320064
    
  }

  /**
   * {@inheritDoc}
   */
  public ProviderOrganization getProviderOrganization() {
    final long id = getDtls().providerConcernRoleID;

    return id == 0 ? null : providerOrganizationDAO.get(id);
  }

  /**
   * {@inheritDoc}
   */
  public ConcernRole getParty() {
    final Long partyConcernRoleID = getDtls().partyConcernRoleID;

    return partyConcernRoleID == 0
      ? null
      : concernRoleDAO.get(partyConcernRoleID);
  }

  /**
   * {@inheritDoc}
   */
  public void setParty(ConcernRole value) {
    getDtls().partyConcernRoleID = value.getID();
  }

  /**
   * Sets the provider organization of the party.
   *
   * @param value
   * the provider organization.
   */
  public void setProviderOrganization(ProviderOrganization value) {
    getDtls().providerConcernRoleID = value == null ? 0 : value.getID();
    if (getRowManager().isOnDatabase()) {
      AppException appException = new AppException(
        curam.message.PROVIDERPARTY.NOT_ALLOWED_TO_MODIFY_PROVIDER_ORG);

      appException.arg(
        getProviderOrganization().getConcernRoleType().getCodeTableItemIdentifier());
      appException.arg(getProviderOrganization().getName());
      throw new RuntimeException(appException.getLocalizedMessage());

    }

  }

  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {
    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * Validates that all mandatory fields are "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.GENERAL#ERR_GENERAL_FV_FROM_DATE_EMPTY} - If the
   * from date is empty.</li>
   *
   */
  public void mandatoryFieldValidation() {
    // From date must not be empty
    
    // BEGIN, CR00320064, SSK
    DateRange providerPartyDateRange = new DateRange(getDtls().startDate,
      getDtls().endDate);

    if (!providerPartyDateRange.isStarted()) {
      // END, CR00320064
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        GENERALExceptionCreator.ERR_GENERAL_FV_FROM_DATE_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// none required
  }

  /**
   * Validates that changes made to provider party entity on the database are
   * consistent with other entities.
   *
   * It adds the following informational exceptions to the validation helper
   * when validation fails. </p>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERPARTY#ERR_PROVIDERPARTICIPANT_XRV_PARTY_ALREADY_EXISTS_OPEN_ENDED}
   * - If the provider party already exists as open ended.</li>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERPARTY#ERR_PROVIDERPARTICIPANT_XRV_PARTY_ALREADY_EXISTS}
   * - If the provider party already exists.</li>
   *
   * <ul>
   * <li>
   * {@link curam.message.CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_XRV_DATE_OF_BIRTH_LATER_THAN_FROM_DATE}
   * - If the from date is after the date of birth.</li>
   *
   * <ul>
   * <li>
   * {@link curam.message.CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_XRV_DATE_OF_DEATH_EARLIER_THAN_TO_DATE}
   * - If the date of death is after today.</li>
   *
   *
   *
   */
  public void crossEntityValidation() {

    // validate dates
    validateToFromDate();
    // BEGIN, CR00205270, ASN
    if (ProviderPartyCategoryEntry.MEMBER.getCode().equals(
      getCategory().getCode())) {

      validatePeriodOverlap();
    }
    // END, CR00205270
  }

  /**
   * @param value
   * Type
   */
  public void setType(final String value) {
    getDtls().type = value;
  }

  /**
   * {@inheritDoc}
   */
  public String getType() {
    return getDtls().type;
  }

  /**
   * This method validates the toDate and fromDate of the provider party
   */
  public void validateToFromDate() {

    final ConcernRole party = getParty();

    if (party != null) {

      // If the concern role type is person then retrieve details
      if (party instanceof Person) {
        final Person person = (Person) party;

        // Check fromDate against date of birth
        if (person.getDateOfBirth().after(getDateRange().start())) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_DATE_OF_BIRTH_LATER_THAN_FROM_DATE(
              getDateRange().start(),
              getProviderOrganization().getConcernRoleType().getCodeTableItemIdentifier(),
              getCategory().getCodeTableItemIdentifier(),
              person.getDateOfBirth()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }

        // Check toDate against the date of death if exist
        if (!person.getDateOfDeath().isZero() && !getDateRange().end().isZero()
          && person.getDateOfDeath().before(getDateRange().end())) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_DATE_OF_DEATH_EARLIER_THAN_TO_DATE(
              person.getName(), person.getDateOfDeath(),
              getProviderOrganization().getConcernRoleType().getCodeTableItemIdentifier(),
              getCategory().getCodeTableItemIdentifier()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);

        }
      }
    }
  }

  /**
   * This method returns the provider party role or type.
   */
  // BEGIN, CR00177241, PM
  protected String getPartyRoleOrType() {
    // END, CR00177241
    if (getCategory().getCode().equals(
      ProviderPartyCategoryEntry.PROVIDERPARTICIPANT.getCode())) {
      return CPMConstants.kOfType;
    } else {
      return CPMConstants.kWithRole;
    }
  }

  /**
   * Stores a new provider party in the database.
   *
   * @throws InformationalException
   * {@link PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}
   * - If the provider is closed.
   * @throws InformationalException
   * {@link PROVIDERPARTY#ERR_PROVIDERPARTY_XRV_ACTIVE_PROVIDERMEMBER_CANNOT_BE_UNASSIGNED}
   * - If an active provider membership already exists, unassigned
   * provider membership can not be created for the same or
   * overlapping period.
   * @throws InformationalException
   * {@link PROVIDERPARTY#ERR_PROVIDERPARTICIPANT_XRV_PARTICIPANT_WITH_DATE_OF_DEATH}
   * - If the provider party is deceased.
   * @throws InformationalException
   * {@link PROVIDERPARTY#ERR_PROVIDERPARTY_XRV_ACTIVE_PROVIDERMEMBER_FOR_PERIOD_CANNOT_BE_UNASSIGNED}
   * - If an active provider membership already exists for a period,
   * unassigned provider membership can not be created for the same or
   * overlapping period.
   * @throws InformationalException
   * {@link PROVIDERPARTY#ERR_PROVIDERPARTICIPANT_XRV_PARTY_ALREADY_EXISTS_OPEN_ENDED}
   * - If the provider party already exists as open ended.
   * @throws InformationalException
   * {@link PROVIDERPARTY#ERR_PROVIDERPARTY_XRV_UNASSIGNED_ACTIVE_PROVIDERMEMBER_EXISTS}
   * - If an active unassigned provider membership already exists,
   * provider membership can not be created for the same or
   * overlapping period.
   * @throws InformationalException
   * {@link PROVIDERPARTY#ERR_PROVIDERPARTICIPANT_XRV_PARTY_ALREADY_EXISTS}
   * - If the provider party already exists.
   * @throws InformationalException
   * {@link PROVIDERPARTY#ERR_PROVIDERPARTY_XRV_UNASSIGNED_ACTIVE_PROVIDERMEMBER_FOR_PERIOD_EXISTS}
   * - If an active unassigned provider membership already exists for
   * a period, provider membership can not be created for the same or
   * overlapping period.
   * @throws InformationalException
   * {@link PROVIDERPARTY#ERR_PROVIDERPARTY_XRV_ACTIVE_PROVIDERMEMBERSHIP_ALREADY_EXISTS}
   * - If an active provider membership already exists.
   */
  public void insert() throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre insert provider party event.
    insertEventDispatcherFactory.get(ProviderPartyInsertEvents.class).preInsert(
      this);
    // END, CR00235789
    // BEGIN, CR00205270, ASN
    // BEGIN, CR00205844, ASN
    valildateMembershipCriteria();
    // END, CR00205844
    // END, CR00205270
    // Check provider security only for provider member and provider participant
    if (getProviderOrganization() != null) {
      if (getParty() instanceof Provider) {
        // perform a security check for a provider

        providerSecurity.checkProviderSecurity(
          providerDAO.get(getProviderOrganization().getID()));
      } else {
        // perform a security check for a provider group
        providerSecurity.checkProviderGroupSecurity(
          providerGroupDAO.get(getProviderOrganization().getID()));
      }

      // checking whether the person is already existing as a participant for
      // this
      // provider.
      checkPartyExisting();
      if (getProviderOrganization().getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDER)) {
        curam.provider.impl.Provider provider = providerDAO.get(
          getProviderOrganization().getID());

        if (provider.getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            64);
        }
      }
    }

    final ConcernRole party = getParty();

    if (party != null) {

      // If the concern role type is person then retrieve details
      if (party instanceof Person) {

        final Person person = (Person) party;

        // Check toDate against the date of death if exist
        if (!person.getDateOfDeath().isZero() && getID() == null
          && getProviderOrganization() != null) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERPARTYExceptionCreator.ERR_PROVIDERPARTICIPANT_XRV_PARTICIPANT_WITH_DATE_OF_DEATH(
              person.getName(), person.getDateOfDeath(),
              getProviderOrganization().getConcernRoleType().getCodeTableItemIdentifier(),
              getCategory().getCodeTableItemIdentifier()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }
      }
    }
    super.insert();
    // BEGIN, CR00235789, AK
    // Raise the post insert provider party event.
    insertEventDispatcherFactory.get(ProviderPartyInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * Modifies a provider party in the database.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}
   * - If the provider is closed.
   * {@link curam.message.CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_XRV_RECORD_CANNOT_MODIFY_THIS_RECORD_ALREADY_BEEN_DELETED}
   * - If the record has already been deleted.
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre modify provider party event.
    modifyEventDispatcherFactory.get(ProviderPartyModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789
    // BEGIN, CR00205844, ASN
    valildateMembershipCriteria();
    // END, CR00205844
    if (getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_RECORD_CANNOT_MODIFY_THIS_RECORD_ALREADY_BEEN_DELETED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      ValidationHelper.failIfErrorsExist();
    }

    // BEGIN, CR00205270, ASN
    if (ProviderPartyCategoryEntry.MEMBER.getCode().equals(
      getCategory().getCode())) {
      // END, CR00205270

      if (getParty() instanceof Provider) {
        // perform a security check for a provider
        providerSecurity.checkProviderSecurity(
          providerDAO.get(getProviderOrganization().getID()));
      } else {
        // perform a security check for a provider group
        providerSecurity.checkProviderGroupSecurity(
          providerGroupDAO.get(getProviderOrganization().getID()));
      }

      if (getProviderOrganization().getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDER)) {
        curam.provider.impl.Provider provider = providerDAO.get(
          getProviderOrganization().getID());

        if (provider.getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            65);
        }
      }
      // BEGIN, CR00205270, ASN
    }
    if (ProviderPartyCategoryEntry.UNASSIGNED.getCode().equals(
      getCategory().getCode())) {

      setType(this.getType());
    }
    // END, CR00205270
    super.modify(versionNo);
    // BEGIN, CR00235789, AK
    // Raise the post modify provider party event.
    modifyEventDispatcherFactory.get(ProviderPartyModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * Cancels a provider party in the database.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}
   * - If the provider is closed.
   */
  @Override
  public void cancel(final int versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre cancel provider party event.
    cancelEventDispatcherFactory.get(ProviderPartyCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    // Check provider security only for provider member and provider participant
    if (getProviderOrganization() != null) {
      if (getParty() instanceof Provider) {
        // perform a security check for a provider
        providerSecurity.checkProviderSecurity(
          providerDAO.get(getProviderOrganization().getID()));
      } else {
        // perform a security check for a provider group
        providerSecurity.checkProviderGroupSecurity(
          providerGroupDAO.get(getProviderOrganization().getID()));
      }

      if (CONCERNROLETYPEEntry.PROVIDER.equals(
        getProviderOrganization().getConcernRoleType())) {
        curam.provider.impl.Provider provider = providerDAO.get(
          getProviderOrganization().getID());

        if (provider.getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            63);
        }
      }
    }
    super.cancel(versionNo);
    // BEGIN, CR00235789, AK
    // Raise the post cancel provider party event.
    cancelEventDispatcherFactory.get(ProviderPartyCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789
  }

  // BEGIN, CR00279574, MR
  /**
   * Validates provider party duplicate records.
   *
   * @deprecated Since Curam 6.0 SP2. This method is deprecated as it is not
   * implemented and not used anywhere. See release note:
   * CR00279574.
   */
  // BEGIN, CR00177241, PM
  @Deprecated
  protected void validateDuplicates() {// END, CR00177241
    // Not implemented
  }

  // END, CR00279574

  /**
   * */
  // BEGIN, CR00177241, PM
  protected void validatePeriodOverlap() {
    // END, CR00177241

    // BEGIN, CR00306333, SS
    try {
      final ProviderKey providerKey = new ProviderKey();

      providerKey.providerConcernRoleID = getDtls().providerConcernRoleID;
      final curam.cpm.sl.entity.intf.ProviderParty providerPartyObj = ProviderPartyFactory.newInstance();

      final PartyConcernRoleDetailsList partyConcernRoleDetailsList = providerPartyObj.searchPartyConcernRoleDetailsByProvider(
        providerKey);

      for (final PartyConcernRoleDetails partyConcernRoleDetails : partyConcernRoleDetailsList.dtls.items()) {
        if (partyConcernRoleDetails.memberConcernRoleID
          == getParty().getID().longValue()
            && partyConcernRoleDetails.concernRoleType.equals(getType())
            && RECORDSTATUSEntry.NORMAL.equals(
              partyConcernRoleDetails.recordStatus)
              && (partyConcernRoleDetails.providerPartyID
                != this.getID().longValue())) {
          final DateRange dateRange = new DateRange(
            partyConcernRoleDetails.fromDate, partyConcernRoleDetails.toDate);

          if (dateRange.overlapsWith(getDateRange())) {
            if (!dateRange.isEnded()) {

              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                PROVIDERPARTYExceptionCreator.ERR_PROVIDERPARTICIPANT_XRV_PARTY_ALREADY_EXISTS_OPEN_ENDED(
                  partyConcernRoleDetails.name,
                  getProviderOrganization().getConcernRoleType().getCodeTableItemIdentifier(),
                  getCategory().getCodeTableItemIdentifier(),
                  getPartyRoleOrType(),
                  getTypeCode().getCodeTableItemIdentifier(), dateRange.start()),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                  1);
            } else {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                PROVIDERPARTYExceptionCreator.ERR_PROVIDERPARTICIPANT_XRV_PARTY_ALREADY_EXISTS(
                  partyConcernRoleDetails.name,
                  getProviderOrganization().getConcernRoleType().getCodeTableItemIdentifier(),
                  getCategory().getCodeTableItemIdentifier(),
                  getPartyRoleOrType(),
                  getTypeCode().getCodeTableItemIdentifier(), dateRange.start(),
                  dateRange.end()),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                  1);
            }
          }
        }
      }
    } catch (AppException appException) {
      ValidationHelper.addValidationError(appException);
    } catch (InformationalException informationalException) {
      new RuntimeException(informationalException);
    }
    // END, CR00306333
  }

  /**
   * This method returns the code table value for party type code.
   *
   * @return Code Table Entry
   */
  protected abstract CodeTableEntry getTypeCode();

  /**
   * This method sets the code table value for party type code.
   *
   * @param value
   * Provider Category
   */
  protected void setCategory(final ProviderPartyCategoryEntry value) {
    getDtls().category = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public ProviderPartyCategoryEntry getCategory() {
    return ProviderPartyCategoryEntry.get(getDtls().category);
  }

  /**
   * This method checks for the participant already associated with the provider
   * and also checks if the date range overlaps with the user entered date
   * range.
   *
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void checkPartyExisting() throws InformationalException {
    // END, CR00177241
    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      getDtls().providerConcernRoleID);
    Set<ProviderParty> providerParties = providerPartyDAO.searchBy(
      providerOrganization);

    for (final ProviderParty providerParty : providerParties) {

      if (providerParty.getCategory().getCode().equals(
        ProviderPartyCategoryEntry.PROVIDERPARTICIPANT.getCode())
          && providerParty.getParty().getID().equals(getParty().getID())
          && !providerParty.getLifecycleState().getCode().equals(
            RECORDSTATUSEntry.CANCELLED.getCode())) {
        // checking for overlapping periods
        if (providerParty.getDateRange().overlapsWith(
          new DateRange(getDtls().startDate, getDtls().endDate))) {
          if (!providerParty.getDateRange().isEnded()) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERPARTYExceptionCreator.ERR_PROVIDERPARTICIPANT_XRV_PARTY_ALREADY_EXISTS_OPEN_ENDED(
                providerParty.getParty().getName(),
                getProviderOrganization().getConcernRoleType().getCodeTableItemIdentifier(),
                getCategory().getCodeTableItemIdentifier(),
                getPartyRoleOrType(),
                ProviderParticipantTypeEntry.get(providerParty.getType()).getCodeTableItemIdentifier(),
                providerParty.getDateRange().start()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERPARTYExceptionCreator.ERR_PROVIDERPARTICIPANT_XRV_PARTY_ALREADY_EXISTS(
                providerParty.getParty().getName(),
                providerOrganization.getConcernRoleType().getCodeTableItemIdentifier(),
                providerParty.getCategory().getCodeTableItemIdentifier(),
                getPartyRoleOrType(),
                ProviderParticipantTypeEntry.get(providerParty.getType()).getCodeTableItemIdentifier(),
                providerParty.getDateRange().start(),
                providerParty.getDateRange().end()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
          }
        }
        // BEGIN CR00118010, MST
      } else if (providerParty.getCategory().getCode().equals(
        ProviderPartyCategoryEntry.MEMBER.getCode())
          && providerParty.getParty().getID().equals(getParty().getID())
          && providerParty.getLifecycleState().getCode().equals(
            RECORDSTATUSEntry.NORMAL.getCode())) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERPARTYExceptionCreator.ERR_PROVIDERPARTY_XRV_ACTIVE_PROVIDERMEMBERSHIP_ALREADY_EXISTS(
            providerParty.getParty().getName(),
            getProviderOrganization().getName()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
      // END CR00118010

    }
  }

  // BEGIN, CR00205270, ASN
  /**
   * Validates provider member or unassigned provider member relationship based
   * on business rules specified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00205844, ASN
  protected void valildateMembershipCriteria() throws InformationalException {
    // END, CR00205844
    Set<ProviderMember> unAssignedProviderMembers = providerMemberDAO.listPersonMembershipHistory(
      getParty().getID(), ProviderPartyCategoryEntry.UNASSIGNED,
      RECORDSTATUSEntry.NORMAL);

    for (final ProviderMember unAssignedProviderMember : unAssignedProviderMembers) {

      // BEGIN, CR00205844, ASN
      if ((null != getID() && unAssignedProviderMember.getID() != getID())
        || null == getID()) {

        if (getDateRange().overlapsWith(unAssignedProviderMember.getDateRange())) {

          if (getDateRange().end().equals(Date.kZeroDate)) {

            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERPARTYExceptionCreator.ERR_PROVIDERPARTY_XRV_UNASSIGNED_ACTIVE_PROVIDERMEMBER_EXISTS(
                getParty().getName(), getDateRange().start()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
            ValidationHelper.failIfErrorsExist();

          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERPARTYExceptionCreator.ERR_PROVIDERPARTY_XRV_UNASSIGNED_ACTIVE_PROVIDERMEMBER_FOR_PERIOD_EXISTS(
                getParty().getName(),
                unAssignedProviderMember.getDateRange().start(),
                unAssignedProviderMember.getDateRange().end()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
            ValidationHelper.failIfErrorsExist();
          }
        }
      }
      // END, CR00205844

    }
    Set<ProviderMember> providerMembers = providerMemberDAO.listPersonMembershipHistory(
      getParty().getID(), ProviderPartyCategoryEntry.MEMBER,
      RECORDSTATUSEntry.NORMAL);

    for (final ProviderMember providerMember : providerMembers) {

      if (getDateRange().overlapsWith(providerMember.getDateRange())
        && ProviderPartyCategoryEntry.UNASSIGNED.getCode().equals(
          getCategory().getCode())) {

        if (getDateRange().end().equals(Date.kZeroDate)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERPARTYExceptionCreator.ERR_PROVIDERPARTY_XRV_ACTIVE_PROVIDERMEMBER_CANNOT_BE_UNASSIGNED(
              getParty().getName(), providerMember.getDateRange().start()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
          ValidationHelper.failIfErrorsExist();

        } else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERPARTYExceptionCreator.ERR_PROVIDERPARTY_XRV_ACTIVE_PROVIDERMEMBER_FOR_PERIOD_CANNOT_BE_UNASSIGNED(
              getParty().getName(), providerMember.getDateRange().start(),
              providerMember.getDateRange().end()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
          ValidationHelper.failIfErrorsExist();
        }
      }
    }
  }

  // END, CR00205270

}
