/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.LogicallyDeleteable;
import java.util.Set;


/**
 * Accreditations from third party organizations achieved by the provider.
 *
 * For example, National Association of Child Care Professionals is a third
 * party giving accreditation to child care providers for their early care
 * programs. The accreditation may be considered as a criterion to approve the
 * provider to provide service offerings.
 */
@ImplementedBy(ProviderAccreditationImpl.class)
public interface ProviderAccreditation extends ProviderAccreditationAccessor,
    Insertable, LogicallyDeleteable, OptimisticLockModifiable {

  /**
   * Gets the immutable provider for the accreditation.
   *
   * @return Immutable provider the accreditation is associated with.
   */
  Provider getProvider();

  /**
   * Gets the immutable set of Accreditation Periods for the Provider
   * Accreditation.
   *
   * @return The immutable set of provider accreditation periods for a provider
   * accreditation.
   */
  Set<AccreditationPeriod> getAccreditationPeriods();

  /**
   * Sets the description for the Provider Accreditation.
   *
   * @param description
   * The description for the provider accreditation to be set.
   */
  void setDescription(final String description);

  /**
   * Sets the type for the Provider Accreditation.
   *
   * @param type
   * The type for the provider accreditation to be set.
   */
  void setType(final String type);

  /**
   * Sets the provider for the accreditation.
   *
   * @param value
   * The Provider to be set for the accreditation.
   */
  void setProvider(final Provider value);

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider accreditation events functionality surrounding
   * the insert method.
   */
  public interface ProviderAccreditationInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderAccreditation#insert}
     *
     * @param providerAccreditation
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ProviderAccreditationAccessor providerAccreditation)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderAccreditation#insert}
     *
     * @param providerAccreditation
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ProviderAccreditationAccessor providerAccreditation)
      throws InformationalException;
  }


  /**
   * Interface to the provider accreditation events functionality surrounding
   * the cancel method.
   */
  public interface ProviderAccreditationCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderAccreditation#cancel}
     *
     * @param providerAccreditation
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(ProviderAccreditationAccessor providerAccreditation,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderAccreditation#cancel}
     *
     * @param providerAccreditation
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(ProviderAccreditationAccessor providerAccreditation,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the provider accreditation events functionality surrounding
   * the modify method.
   */
  public interface ProviderAccreditationModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderAccreditation#modify}
     *
     * @param providerAccreditation
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(ProviderAccreditationAccessor providerAccreditation,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderAccreditation#modify}
     *
     * @param providerAccreditation
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(ProviderAccreditationAccessor providerAccreditation,
      Integer versionNo) throws InformationalException;
  }
  // END, CR00144381
}
