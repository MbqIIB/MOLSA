/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.List;
import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.PREFERREDSERVICEENQUIRYMETHODEntry;
import curam.contracts.impl.ContractVersion;
import curam.core.struct.AddressDetails;
import curam.core.struct.BankAccountDetails;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRolePhoneDetails;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderInvestigationDetailsList;
import curam.cpm.sl.entity.struct.ProviderMembersBackgroundCheckDetails;
import curam.financial.impl.ServiceInvoiceLineItem;
import curam.homestudy.impl.HomeStudy;
import curam.place.impl.Compartment;
import curam.place.impl.Place;
import curam.providerservice.impl.ProviderOffering;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Lifecycle;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.DateRange;
import curam.util.type.DateTimeRange;
import curam.util.type.DateTimeRanged;
import curam.waitlist.impl.Resource;
import curam.workspaceservices.localization.impl.LocalizableText;


/**
 * A person or company that provides services to an organization's clients on
 * the organization's behalf. For example John's Day Care is a provider who
 * delivers Day Care Services on behalf of the organization.
 */

@ImplementedBy(ProviderImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
// BEGIN, CR00197964, RPB
// BEGIN, CR00123437, RPB
public interface Provider extends ProviderOrganization, Insertable,
    OptimisticLockModifiable, Lifecycle<ProviderStatusEntry>, DateTimeRanged, Resource,
    ProviderAccessor {
  // END, CR00123437
  // END, CR00197964

  /**
   * Sets the physical capacity. Defines the actual capacity of the provider
   *
   * @param value
   * the actual capacity of the provider.
   */
  void setPhysicalCapacity(int value);

  /**
   * Sets the provider enquiry already created for this provider.
   *
   * @param value
   * the provider enquiry created for this provider.
   */
  void setProviderEnquiry(final ProviderEnquiry value);

  // BEGIN, CR00144284, SK
  /**
   * Rejects the provider seeking approval for providing the services to an
   * organization's clients.
   *
   * @param rejectionReason
   * The reason for rejection.
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @see curam.provider.impl.ProviderImpl#reject(String, int) The default
   * implementation - curam.provider.impl.ProviderImpl#reject(String,
   * int).
   */
  // END, CR00144284
  void reject(final String rejectionReason, final int versionNo)
    throws InformationalException, AppException;

  // BEGIN, CR00246372, AK
  // BEGIN, CR00144284, SK
  /**
   * Approves the provider for providing the services to an organization's
   * clients. Also notifies the provider of the approval and raises a workflow
   * event. Performs no security checks before approving the provider.
   * The method should be used only when it is unavoidable to skip the security check and
   * it is sure that skipping the security check doesn't break the application's behavior.
   * In all the other cases, only the other version of the method : approveWithSecurityCheck()
   * should be used.
   *
   * Transitions the state to
   * {@linkplain curam.provider.impl.ProviderStatusEntry#APPROVED}, if it is
   * valid to approved.
   *
   * @param versionNo
   * the version number as previously retrieved.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderImpl#approve(int) The default
   * implementation - {@link curam.provider.impl.ProviderImpl#approve(int)}.
   */
  // END, CR00144284
  void approve(final int versionNo) throws AppException, InformationalException;

  /**
   * Approves the Provider for providing the services to an organization's
   * clients on the organization behalf, if the User has the rights to do so.
   * Performs Security Checks before approving the provider.
   * This method should be used in all places wherever the provider approval is to be done,
   * except for a few exceptional scenarios such as automated processes or workflows.
   *
   * @param versionNo
   * the version number as previously retrieved.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderImpl#approveWithSecurityCheck(int) The default
   * implementation - {@link curam.provider.impl.ProviderImpl#approveWithSecurityCheck(int)}.
   */
  void approveWithSecurityCheck(int versionNo) throws AppException,
      InformationalException;
  // END, CR00246372

  // BEGIN, CR00144284, SK
  /**
   * Suspends the provider from providing the services to an organization's
   * clients. Also notifies the provider of the suspension and raises a workflow
   * event.
   *
   * Transitions the state to
   * {@linkplain curam.provider.impl.ProviderStatusEntry#SUSPENDED}, if it is
   * valid to reject.
   *
   * @param suspensionReason
   * the reason for suspension.
   * @param versionNo
   * the version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @see curam.provider.impl.ProviderImpl#suspend(String, int) The default
   * implementation -
   * {@link curam.provider.impl.ProviderImpl#suspend(String, int)}.
   */
  // END, CR00144284
  void suspend(final String suspensionReason, final int versionNo)
    throws InformationalException, AppException;

  // BEGIN, CR00144284, SK
  /**
   * Ceases the provider business with the agency and raises a workflow
   * event.
   *
   * Transitions the state to
   * {@linkplain curam.provider.impl.ProviderStatusEntry#CLOSED}, if it is
   * valid to cease conducting business.
   *
   * @param versionNo
   * the version number as previously retrieved.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderImpl#close(int) The default
   * implementation -
   * {@link curam.provider.impl.ProviderImpl#close(int)}.
   */
  // END, CR00144284
  void close(final int versionNo) throws InformationalException, AppException;

  // BEGIN, CR00144284, SK
  /**
   * Reopens the closed provider for the approval of providing the services to
   * an organization's clients and notifies the provider that they are re-opened
   * and raises a workflow event.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderImpl#reopen(int) The default
   * implementation -
   * {@link curam.provider.impl.ProviderImpl#reopen(int)}.
   */
  // END, CR00144284
  void reopen(final int versionNo) throws InformationalException, AppException;

  /**
   * Enrolls the provider in the organization and also, if required, to register
   * the provider as one or more person(s).
   *
   * @param concernRoleDtls
   * it contains concern role related values.
   * @param addressDetails
   * it contains address related details.
   * @param concernRolePhoneDetails
   * it contains concern role phone details.
   * @param bankAccountDetails
   * it contains bank related values.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @see curam.provider.impl.ProviderImpl#enroll(ConcernRoleDtls,
   * AddressDetails, ConcernRolePhoneDetails, BankAccountDetails) The
   * default implementation -
   * {@link curam.provider.impl.ProviderImpl#enroll(ConcernRoleDtls, AddressDetails, ConcernRolePhoneDetails, BankAccountDetails)}.
   */
  void enroll(ConcernRoleDtls concernRoleDtls, AddressDetails addressDetails,
    ConcernRolePhoneDetails concernRolePhoneDetails,
    BankAccountDetails bankAccountDetails) throws AppException,
      InformationalException;

  /**
   * Gets the immutable set of service offerings for the provider. An offering
   * from a Provider that a client can be authorized by the organization to
   * receive.
   *
   * @return The immutable set of service offerings for the provider.
   */
  Set<ServiceOffering> getServiceOfferings();

  /**
   * Gets the immutable set of provider offerings for the provider. The Provider
   * Offering defines the period during which a provider offers a service to the
   * organization's clients.
   *
   * @return The immutable set of provider offerings for the provider.
   */
  Set<ProviderOffering> getProviderOfferings();

  /**
   * Gets the immutable set of provider specialties for the provider. Areas in
   * which a provider has particular experience or expertise.
   *
   * @return The immutable set of provider specialties for the provider.
   */
  Set<ProviderSpecialty> getProviderSpecialties();

  /**
   * Gets the immutable primary category periods for the provider.
   *
   * @return The immutable primary category period for the provider.
   */
  ProviderCategoryPeriod getPrimaryProviderCategoryPeriod();

  /**
   * Gets the immutable set of provider category periods associated to the
   * provider.
   *
   * @return The immutable set of category periods for the provider.
   */
  Set<ProviderCategoryPeriod> getProviderCategoryPeriods();

  /**
   * Gets the immutable set of compartments for the provider.
   *
   * @return The immutable set of compartments for the provider.
   */
  Set<Compartment> getCompartments();

  // BEGIN, CR00260960, GP
  /**
   * Gets the immutable set of available places for a provider in the given date
   * range.
   *
   * @param dateRange
   * Date range to be searched for.
   *
   * @return immutable set of Places which are available in the specified date
   * range.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since 6.0 SP1, replaced by {@link Provider#
   * getAvailablePlacesInDateTimeRange(DateTimeRange)} as part of fixing making 
   * a place that is just made available to be displayed in the search list of 
   * available places. See release note : CR00260960.
   */
  @Deprecated
  Set<Place> getAvailablePlacesInDateRange(final DateRange dateRange)
    throws AppException, InformationalException;
  
  /**
   * Gets the immutable set of available places for a provider in the given date
   * time range.
   *
   * @param dateTimeRange
   * Date time range to be searched for.
   *
   * @return immutable set of Places which are available in the specified date 
   * time range.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  Set<Place> getAvailablePlacesInDateTimeRange(final DateTimeRange dateTimeRange)
    throws AppException, InformationalException;
  // END, CR00260960

  /**
   * Gets the immutable set of accreditations for the provider. Accreditations
   * from third party organizations achieved by the provider.
   *
   * @return The immutable set of accreditations for the provider.
   */
  Set<ProviderAccreditation> getAccreditations();

  /**
   * Gets the immutable set of BackgroundChecks for the provider. Background
   * checks undertaken on employees or household members of a provider.
   *
   * @return The immutable set of BackgroundChecks for the provider.
   */
  Set<ProviderBackgroundCheck> getProviderBackgroundChecks();

  /**
   * Gets the immutable set of service centers for the provider. Locations from
   * where a provider can deliver services.
   *
   * @return The immutable set of service centers for the provider.
   */
  Set<ProviderServiceCenter> getProviderServiceCenters();

  /**
   * Gets the immutable set of home studies for provider. A study conducted on a
   * provider to ascertain that the living conditions and environment of the
   * home are suitable for the care of the agency's clients.
   *
   * @return The immutable set of Home Studies for the provider.
   */
  Set<HomeStudy> getHomeStudies();

  /**
   * Gets the immutable set of service invoice line items for the provider. A
   * service invoice line item contains information entered by a user about one
   * specific line item on a service invoice.
   *
   * @return The immutable set of service invoice line items for the provider.
   */
  Set<ServiceInvoiceLineItem> getServiceInvoiceLineItems();

  /**
   * Gets the immutable Provider Enquiry if the Provider is enrolled from an
   * enquiry otherwise it returns a null.
   *
   * @return The immutable Provider Enquiry from which this Provider is
   * enrolled.
   */
  ProviderEnquiry getProviderEnquiry();

  // BEGIN, CR00106630, JSP
  /**
   * Sets the reservation grace period for the provider.
   *
   * @param value
   * The reservation grace period in days.
   */
  void setReservationGracePeriod(short value);

  // END, CR00106630

  /**
   * Sets the override maximum deduction rate indicator value to be used in all
   * the product deliveries of the provider.
   *
   * @param overrideMDRInd
   * Override maximum deduction rate indicator.
   */
  void setOverrideMDRInd(final boolean overrideMDRInd);

  // END, CR00123182

  // BEGIN, CR00178272, AK
  /**
   * Gets the immutable localized text object for the attribute, areas served
   * information.
   *
   * @return The immutable localized text object.
   */
  LocalizableText getAreasServedInfo();

  /**
   * Gets the immutable localized text object for the attribute, client
   * information.
   *
   * @return The immutable localized text object.
   */
  LocalizableText getClientInfo();

  /**
   * Gets the indicator that determines whether a provider will
   * accept a referral generated by CitizenWorkspace.
   *
   * @return <code>true</code> if the provider accepts referrals
   * from CitizenWorkspace.
   */
  boolean getAcceptsCWReferral();

  /**
   * Sets the localized text ID of the provider attribute areas served
   * information.
   *
   * @param value
   * The localized text ID of the areas served information.
   */
  void setAreasServedInfoTextID(long value);

  /**
   * Sets the localized text ID of the provider attribute client information
   *
   * @param value
   * The localized text ID of the client information.
   */
  void setClientInfoTextID(long value);

  /**
   * Sets the indicator that determines whether a Provider will
   * accept a referral generated by CitizenWorkspace.
   *
   * @param acceptReferral
   * True if the Provider will accept a referral generated
   * by CitizenWorkspace.
   */
  void setAcceptsCWReferral(boolean acceptReferral);

  /**
   * Sets the preferred service enquiry method for the provider.
   *
   * @param value
   * The preferred service enquiry method entry.
   */
  void setPreferredServiceEnquiryMethod(
    final PREFERREDSERVICEENQUIRYMETHODEntry value);
  // END, CR00178272

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider events functionality surrounding the suspend
   * method.
   */
  public interface ProviderSuspendEvents {

    /**
     * Event interface invoked before the main body of the suspend method.
     * {@linkplain curam.provider.impl.Provider#suspend}
     *
     * @param provider
     * The object instance as it was before the main body of the
     * suspend method.
     * @param suspentionReason
     * The parameter as passed to the suspend method.
     * @param versionNo
     * The parameter as passed to the suspend method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preSuspend(ProviderAccessor provider, String suspentionReason,
      int versionNo) throws InformationalException, AppException;

    /**
     * Event interface invoked after the main body of the suspend method.
     * {@linkplain curam.provider.impl.Provider#suspend}
     *
     * @param provider
     * The object instance as it was after the main body of the suspend
     * method.
     * @param suspentionReason
     * The parameter as passed to the suspend method.
     * @param versionNo
     * The parameter as passed to the suspend method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postSuspend(ProviderAccessor provider, String suspentionReason,
      int versionNo) throws InformationalException, AppException;
  }


  /**
   * Interface to the provider events functionality surrounding the close
   * method.
   */
  public interface ProviderCloseEvents {

    /**
     * Event interface invoked before the main body of the close method.
     * {@linkplain curam.provider.impl.Provider#close}
     *
     * @param provider
     * The object instance as it was before the main body of the close
     * method.
     * @param versionNo
     * The parameter as passed to the close method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preClose(ProviderAccessor provider, int versionNo)
      throws InformationalException, AppException;

    /**
     * Event interface invoked after the main body of the close method.
     * {@linkplain curam.provider.impl.Provider#close}
     *
     * @param provider
     * The object instance as it was after the main body of the close
     * method.
     * @param versionNo
     * The parameter as passed to the close method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postClose(ProviderAccessor provider, int versionNo)
      throws InformationalException, AppException;
  }


  /**
   * Interface to the provider events functionality surrounding the reject
   * method.
   */
  public interface ProviderRejectEvents {

    /**
     * Event interface invoked before the main body of the reject method.
     * {@linkplain curam.provider.impl.Provider#reject}
     *
     * @param provider
     * The object instance as it was before the main body of the reject
     * method.
     * @param rejectionReason
     * The parameter as passed to the reject method.
     * @param versionNo
     * The parameter as passed to the reject method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preReject(ProviderAccessor provider, String rejectionReason,
      int versionNo) throws InformationalException, AppException;

    /**
     * Event interface invoked after the main body of the reject method.
     * {@linkplain curam.provider.impl.Provider#reject}
     *
     * @param provider
     * The object instance as it was after the main body of the reject
     * method.
     * @param rejectionReason
     * The parameter as passed to the reject method.
     * @param versionNo
     * The parameter as passed to the reject method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postReject(ProviderAccessor provider, String rejectionReason,
      int versionNo) throws InformationalException, AppException;
  }


  /**
   * Interface to the provider events functionality surrounding the approve
   * method.
   */
  public interface ProviderApproveEvents {

    /**
     * Event interface invoked before the main body of the approve method.
     * {@linkplain curam.provider.impl.Provider#approve}
     *
     * @param provider
     * The object instance as it was before the main body of the
     * approve method.
     * @param versionNo
     * The parameter as passed to the approve method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void preApprove(ProviderAccessor provider, int versionNo)
      throws AppException, InformationalException;

    /**
     * Event interface invoked after the main body of the approve method.
     * {@linkplain curam.provider.impl.Provider#approve}
     *
     * @param provider
     * The object instance as it was after the main body of the approve
     * method.
     * @param versionNo
     * The parameter as passed to the approve method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void postApprove(ProviderAccessor provider, int versionNo)
      throws AppException, InformationalException;
  }


  /**
   * Interface to the provider events functionality surrounding the reopen
   * method.
   */
  public interface ProviderReopenEvents {

    /**
     * Event interface invoked before the main body of the reopen method.
     * {@linkplain curam.provider.impl.Provider#reopen}
     *
     * @param provider
     * The object instance as it was before the main body of the reopen
     * method.
     * @param versionNo
     * The parameter as passed to the reopen method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preReopen(ProviderAccessor provider, int versionNo)
      throws InformationalException, AppException;

    /**
     * Event interface invoked after the main body of the reopen method.
     * {@linkplain curam.provider.impl.Provider#reopen}
     *
     * @param provider
     * The object instance as it was after the main body of the reopen
     * method.
     * @param versionNo
     * The parameter as passed to the reopen method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postReopen(ProviderAccessor provider, int versionNo)
      throws InformationalException, AppException;
  }


  /**
   * Interface to the provider events functionality surrounding the enroll
   * method.
   */
  public interface ProviderEnrollEvents {

    /**
     * Event interface invoked before the main body of the enroll method.
     * {@linkplain curam.provider.impl.Provider#enroll}
     *
     * @param provider
     * The object instance as it was before the main body of the enroll
     * method.
     * @param concernRoleDtls
     * The parameter as passed to the enroll method.
     * @param addressDetails
     * The parameter as passed to the enroll method.
     * @param concernRolePhoneDetails
     * The parameter as passed to the enroll method.
     * @param bankAccountDetails
     * The parameter as passed to the enroll method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void preEnroll(ProviderAccessor provider,
      ConcernRoleDtls concernRoleDtls, AddressDetails addressDetails,
      ConcernRolePhoneDetails concernRolePhoneDetails,
      BankAccountDetails bankAccountDetails) throws AppException,
        InformationalException;

    /**
     * Event interface invoked after the main body of the enroll method.
     * {@linkplain curam.provider.impl.Provider#enroll}
     *
     * @param provider
     * The object instance as it was after the main body of the enroll
     * method.
     * @param concernRoleDtls
     * The parameter as passed to the enroll method.
     * @param addressDetails
     * The parameter as passed to the enroll method.
     * @param concernRolePhoneDetails
     * The parameter as passed to the enroll method.
     * @param bankAccountDetails
     * The parameter as passed to the enroll method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void postEnroll(ProviderAccessor provider,
      ConcernRoleDtls concernRoleDtls, AddressDetails addressDetails,
      ConcernRolePhoneDetails concernRolePhoneDetails,
      BankAccountDetails bankAccountDetails) throws AppException,
        InformationalException;
  }


  /**
   * Interface to the provider events functionality surrounding the insert
   * method.
   */
  public interface ProviderInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.Provider#insert}
     *
     * @param provider
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ProviderAccessor provider)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.Provider#insert}
     *
     * @param provider
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ProviderAccessor provider)
      throws InformationalException;
  }


  /**
   * Interface to the provider events functionality surrounding the modify
   * method.
   */
  public interface ProviderModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.Provider#modify}
     *
     * @param provider
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(ProviderAccessor provider, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.Provider#modify}
     *
     * @param provider
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(ProviderAccessor provider, Integer versionNo)
      throws InformationalException;
  }


  // END, CR00144381

  // BEGIN, CR00145043, RD
  /**
   * Interface to the provider events functionality surrounding the get
   * available places in date range method.
   */
  public interface ProviderGetAvailablePlacesInDateRangeEvents {

    /**
     * Event interface invoked before the main body of the get available places
     * in date range method.
     * {@linkplain curam.provider.impl.Provider#getAvailablePlacesInDateRange}
     *
     * @param provider
     * The object instance as it was before the main body of the get
     * available places in date range method.
     * @param dateRange
     * The date range as passed to the get available places in date
     * range method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preGetAvailablePlacesInDateRange(ProviderAccessor provider,
      DateRange dateRange) throws InformationalException;

    /**
     * Event interface invoked after the main body of the get available places
     * in date range method.
     * {@linkplain curam.provider.impl.Provider#getAvailablePlacesInDateRange}
     *
     * @param provider
     * The object instance as it was after the main body of the get
     * available places in date range method.
     * @param dateRange
     * The date range as passed to the get available places in date
     * range method.
     * @param places
     * The set of places returned from the get available places in date
     * range method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postGetAvailablePlacesInDateRange(ProviderAccessor provider,
      DateRange dateRange, Set<Place> places) throws InformationalException;
  }


  /**
   * Interface to the provider events functionality surrounding the get service
   * offerings method.
   */
  public interface ProviderGetServiceOfferingsEvents {

    /**
     * Event interface invoked before the main body of the get service offerings
     * method. {@linkplain curam.provider.impl.Provider#getServiceOfferings}
     *
     * @param provider
     * The object instance as it was before the main body of the get
     * service offerings.
     */
    public void preGetServiceOfferings(ProviderAccessor provider);

    /**
     * Event interface invoked after the main body of the get service offerings
     * method. {@linkplain curam.provider.impl.Provider#getServiceOfferings}
     *
     * @param provider
     * The object instance as it was after the main body of the get
     * service offerings method.
     * @param serviceOfferings
     * The set of service offerings returned from the get service
     * offerings method.
     */
    public void postGetServiceOfferings(ProviderAccessor provider,
      Set<ServiceOffering> serviceOfferings);
  }


  /**
   * Interface to the provider events functionality surrounding the get common
   * approved provider service offerings.
   */
  public interface ProviderGetCommonApprovedProviderServiceOfferingsEvents {

    /**
     * Event interface invoked before the main body of the get common approved
     * provider service offerings method.
     * {@linkplain curam.provider.impl.ProviderOrganization#getCommonApprovedProviderServiceOfferings}
     *
     * @param provider
     * The object instance as it was before the main body of the get
     * common approved provider service offerings.
     * @param contractVersion
     * The contract version as passed to the get common approved
     * provider service offerings.
     */
    public void preGetCommonApprovedProviderServiceOfferings(
      ProviderAccessor provider, ContractVersion contractVersion);

    /**
     * Event interface invoked after the main body of the get common approved
     * provider service offerings method.
     * {@linkplain curam.provider.impl.ProviderOrganization#getCommonApprovedProviderServiceOfferings}
     *
     * @param provider
     * The object instance as it was after the main body of the get
     * common approved provider service offerings method.
     * @param contractVersion
     * The contract version as passed to the get common approved
     * provider service offerings.
     * @param serviceOfferings
     * The set of service offerings returned from the get common
     * approved provider service offerings method.
     */
    public void postGetCommonApprovedProviderServiceOfferings(
      ProviderAccessor provider, ContractVersion contractVersion,
      Set<ServiceOffering> serviceOfferings);
  }
  // END, CR00145043

  // BEGIN, CR00197073, ASN
  // BEGIN, CR00199682, ASN
  /**
   * Gets details of members of a provider with background check information.
   *
   * @param provider
   * Provider for which member's background check details will be
   * retrieved.
   *
   * @return The list of provider members details with background check
   * information.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see ProviderImpl#getProviderMembersBackGroundCheckDetails(Provider) The
   * default implementation -
   * ProviderImpl#getProviderMembersBackGroundCheckDetails(Provider).
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  List<ProviderMembersBackgroundCheckDetails> readProviderMembersBackGroundCheckDetails() throws AppException, InformationalException;

  // END, CR00199682
  // END, CR00197073
  // BEGIN, CR00198774, RPB

  /**
   * Sets the start date time and the end date time of the provider.
   *
   * The start date time is obtained by taking the start date of the input date
   * time range in the user time zone and defaulting the time part to midnight
   * of that day(i.e 00:00). The end date time is obtained by taking the end
   * date of the input date time range in the user time zone and defaulting the
   * time part to the last minute of that day(i.e 23:59).
   *
   * The start date time and end date time derived in the client time zone as
   * described above will be converted in to equivalent date time in server time
   * zone and stored in the database.
   *
   * @param clientDateTimeRange
   * The "lifetime" of the provider in the client time zone.
   */
  void setDateTimeRange(final DateTimeRange clientDateTimeRange);

  // END, CR00198774

  // BEGIN, CR00291801, ASN
  /**
   * Lists all the investigations the provider is part of and displays multiple
   * roles against each case if exists.
   *
   * @param providerConcernRoleKey
   * The Concern Role ID for the Provider for whom the related
   * investigations are to be retrieved.
   *
   * @return The investigations list for a given provider.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  ProviderInvestigationDetailsList listInvestigationsForProvider(
    final ProviderConcernRoleKey providerConcernRoleKey) throws AppException,
      InformationalException;
  // END, CR00291801

}
