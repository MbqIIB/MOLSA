/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.Inject;

import curam.cpm.sl.entity.struct.ProviderStatusHistoryDtls;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.DateTime;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ProviderStatusHistory}.
 */
// BEGIN, CR00183213, SS
public class ProviderStatusHistoryImpl extends SingleTableLogicallyDeleteableEntityImpl<ProviderStatusHistoryDtls>
  implements ProviderStatusHistory {

  /**
   * Constructor for the class.
   */
  protected ProviderStatusHistoryImpl() {// The no-arg constructor for use only by Guice.
  }
  // END, CR00183213

  /**
   * ProviderDAO Object
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * {@inheritDoc}
   */
  public DateTime getEffectiveDateTime() {
    return getDtls().effectiveDateTime;
  }

  /**
   * {@inheritDoc}
   */
  public String getReason() {
    return getDtls().reason;
  }

  /**
   * {@inheritDoc}
   */
  public String getUserName() {
    return getDtls().userName;
  }

  /**
   * {@inheritDoc}
   */
  public void setEffectiveDateTime(DateTime dateTime) {
    getDtls().effectiveDateTime = dateTime;
  }

  /**
   * {@inheritDoc}
   */
  public void setReason(String reason) {
    getDtls().reason = reason;
  }

  /**
   * {@inheritDoc}
   */
  public void setUserName(String userName) {
    getDtls().userName = userName;
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// none required
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// none required
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// none required
  }

  /**
   * {@inheritDoc}
   */
  public void setProvider(Provider provider) {
    getDtls().providerConcernRoleID = provider.getID();
  }

  /**
   * {@inheritDoc}
   */
  public Provider getProvider() {
    final long providerConcernRoleID = getDtls().providerConcernRoleID;

    return providerConcernRoleID == 0
      ? null
      : providerDAO.get(providerConcernRoleID);
  }

  /**
   * {@inheritDoc}
   */
  public String getProviderRecordStatus() {
    return getDtls().recordStatus;
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderRecordStatus(String recordStatus) {
    getDtls().recordStatus = recordStatus;
  }

}
