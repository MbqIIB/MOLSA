/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.StandardDAO;


/**
 * Data access for
 * {@linkplain curam.provider.impl.BackgroundCheckFailureReason}.
 */
@ImplementedBy(BackgroundCheckFailureReasonDAOImpl.class)
public interface BackgroundCheckFailureReasonDAO extends
    StandardDAO<BackgroundCheckFailureReason> {

  /**
   * Searches for background check failure reasons based on the background check
   * specified.
   *
   * @param providerBackgroundCheck
   * Provider Background Check.
   * @return Set<BackgroundCheckFailureReason> The background check failure
   * reasons for the background check specified.
   */
  Set<BackgroundCheckFailureReason> searchBy(
    final ProviderBackgroundCheck providerBackgroundCheck);
}
