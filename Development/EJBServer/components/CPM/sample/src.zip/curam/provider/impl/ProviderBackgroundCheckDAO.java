/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;


/**
 * Data access for
 * {@linkplain ProviderBackgroundCheck}.
 */
@ImplementedBy(ProviderBackgroundCheckDAOImpl.class)
public interface ProviderBackgroundCheckDAO extends StandardDAO<ProviderBackgroundCheck> {
  
  /**
   * Searches for the provider background checks associated with the provider.
   *
   * @param provider
   * for which the background checks have to be searched for.
   *
   * @return Set<ProviderBackgroundCheck> Set of provider Background check
   * associated with the provider.
   */
  Set<ProviderBackgroundCheck> searchBy
    (Provider provider);

  // BEGIN, CR00197240, ASN

  /**
   * Searches for all background checks associated with the provider member.
   *
   * @param providerParty
   * The provider member for whom the background checks are to be retrieved.
   *
   * @return Set Of background checks associated with the provider member.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  Set<ProviderBackgroundCheck> searchByProviderMember(
    final ProviderParty providerParty) throws AppException,
      InformationalException;
  // END, CR00197240
}
