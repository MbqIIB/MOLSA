/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008, 2014. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.google.inject.Singleton;

import curam.codetable.ADDRESSELEMENTTYPE;
import curam.codetable.TRAININGPROGRAMPARTYSTATUS;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.cpm.sl.entity.fact.ProviderPartyFactory;
import curam.cpm.sl.entity.impl.ProviderPartyAdapter;
import curam.cpm.sl.entity.struct.ProviderPartyDtls;
import curam.cpm.sl.entity.struct.SearchMembershipHistoryKey;
import curam.cpm.sl.entity.struct.SearchPersonDetails1;
import curam.cpm.sl.entity.struct.SearchPersonDetails1List;
import curam.cpm.sl.entity.struct.SearchPersonDetailsList;
import curam.cpm.sl.entity.struct.SearchPersonKey;
import curam.cpm.sl.entity.struct.SearchPersonKey1;
import curam.cpm.sl.entity.struct.SearchUnassignedProviderMemberDetails;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import curam.util.resources.Configuration;


/**
 * Standard implementation of {@linkplain curam.provider.impl.PersonDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class PersonDAOImpl extends StandardDAOImpl<Person, ProviderPartyDtls>
  implements PersonDAO {

  // END, CR00183213
  /**
   * Single instance of the entity adapter shared across all DAO
   * implementations.
   */
  protected static final ProviderPartyAdapter adapter = new ProviderPartyAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected PersonDAOImpl() {
    // END, CR00183213
    super(adapter, Person.class);
  }

  /**
   * Searches person by name and address details. * The search can be performed
   * in two ways - Either by executing the modeled query or by executing the
   * dynamically constructed query. To execute the dynamically constructed query
   * enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param referenceNo
   * Reference number of person.
   * @param addressLine1
   * Address line details.
   * @param firstName
   * First name of the person.
   * @param lastName
   * Last name of the person.
   * @param personWithTraining
   * Search persons having training.
   * @param personWithProviderMembership
   * Search persons who are active active members.
   *
   * @return SearchPersonDetailsList List of person details that matches the
   * search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, this method has been replaced by
   * {@link #searchPersonByNameAndAddress1()}.
   */
  @Deprecated
  public SearchPersonDetailsList searchPersonByNameAndAddress(
    String referenceNo,
    String addressLine1,
    String firstName,
    String lastName,
    boolean personWithTraining,
    boolean personWithProviderMembership
    ) throws AppException, InformationalException {

    // Create provider party instance
    curam.cpm.sl.entity.intf.ProviderParty providerParty = ProviderPartyFactory.newInstance();

    // Assign the search key details to SearchpersonKey struct
    SearchPersonKey searchPersonKey = new SearchPersonKey();

    // Change the address line to upper case and concatenate
    // with wild character
    searchPersonKey.addressLine1 = CuramConst.gkSqlWildcard
      + addressLine1.toUpperCase() + CuramConst.gkSqlWildcard;

    // Change the first name to upper case and concatenate
    // with wild character
    searchPersonKey.firstName = CuramConst.gkSqlWildcard
      + firstName.toUpperCase() + CuramConst.gkSqlWildcard;

    // Change the last name to upper case and concatenate
    // with wild character
    searchPersonKey.lastName = CuramConst.gkSqlWildcard
      + lastName.toUpperCase() + CuramConst.gkSqlWildcard;

    searchPersonKey.personWithProviderMembership = personWithProviderMembership;

    searchPersonKey.personWithTraining = personWithTraining;

    searchPersonKey.providerMembershipPresent = personWithProviderMembership;

    searchPersonKey.referenceNo = referenceNo;

    // Check if different search criteria are entered
    searchPersonKey.searchByAddrLine = addressLine1.length() > 0;

    searchPersonKey.searchByFirstName = firstName.trim().length() > 0;

    searchPersonKey.searchByLastName = lastName.trim().length() > 0;

    searchPersonKey.searchByReferenceNo = referenceNo.trim().length() > 0;

    searchPersonKey.providerPartyCategory = ProviderPartyCategoryEntry.MEMBER.getCode();

    // Set the concern role type as person
    searchPersonKey.concernRoleType = CONCERNROLETYPEEntry.PERSON.getCode();

    searchPersonKey.providerPartyStatus = RECORDSTATUSEntry.NORMAL.getCode();

    searchPersonKey.trainingProgramStatus = TRAININGPROGRAMPARTYSTATUS.CANCELED;

    // BEGIN, CR00170625, KR
    SearchPersonDetailsList personDetailsList = new SearchPersonDetailsList();

    if (!Configuration.getBooleanProperty(EnvVars.ENV_DYNAMIC_SQL_ENABLED)) {
      personDetailsList = providerParty.searchPersonDetails(searchPersonKey);
    }

    return personDetailsList;
    // END, CR00170625
    

  }

  /**
   * Searches representative by name and address details.
   *
   * The search can be performed in two ways - Either by executing the modeled
   * query or by executing the dynamically constructed query. To execute the
   * dynamically constructed query enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param referenceNo
   * Reference number of person.
   * @param addressLine1
   * Address line details.
   * @param firstName
   * First name of the person.
   * @param lastName
   * Last name of the person.
   * @param personWithTraining
   * Search persons having training.
   * @param personWithProviderMembership
   * Search persons who are active active members.
   *
   * @return SearchPersonDetailsList List of person details that matches the
   * search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, this method has been replaced by
   * {@link #searchRepresentativeByNameAndAddress1()}.
   */
  @Deprecated
  public SearchPersonDetailsList searchRepresentativeByNameAndAddress(
    String referenceNo,
    String addressLine1,
    String firstName,
    String lastName,
    boolean personWithTraining,
    boolean personWithProviderMembership
    ) throws AppException,
      InformationalException {

    // Create provider party instance
    curam.cpm.sl.entity.intf.ProviderParty providerParty = ProviderPartyFactory.newInstance();

    // Assign the search key details to SearchpersonKey struct
    SearchPersonKey searchPersonKey = new SearchPersonKey();

    // Change the address line to upper case and concatenate
    // with wild character
    searchPersonKey.addressLine1 = CuramConst.gkSqlWildcard
      + addressLine1.toUpperCase() + CuramConst.gkSqlWildcard;

    // Concatenate first name and last name
    // with wild character
    searchPersonKey.firstName = CuramConst.gkSqlWildcard
      + firstName.toUpperCase() + CuramConst.gkSqlWildcard
      + lastName.toUpperCase() + CuramConst.gkSqlWildcard;

    searchPersonKey.personWithProviderMembership = personWithProviderMembership;

    searchPersonKey.personWithTraining = personWithTraining;

    searchPersonKey.providerMembershipPresent = personWithProviderMembership;

    searchPersonKey.referenceNo = referenceNo;

    searchPersonKey.searchByAddrLine = addressLine1.length() > 0;

    if (firstName.trim().length() > 0 || lastName.trim().length() > 0) {
      searchPersonKey.searchByFirstName = true;
    } else {
      searchPersonKey.searchByFirstName = false;
    }

    searchPersonKey.searchByReferenceNo = referenceNo.trim().length() > 0;

    searchPersonKey.providerPartyCategory = ProviderPartyCategoryEntry.MEMBER.getCode();

    // Set the concern role type as representative
    searchPersonKey.concernRoleType = CONCERNROLETYPEEntry.REPRESENTATIVE.getCode();

    searchPersonKey.providerPartyStatus = RECORDSTATUSEntry.NORMAL.getCode();

    searchPersonKey.trainingProgramStatus = TRAININGPROGRAMPARTYSTATUS.CANCELED;

    // BEGIN, CR00170625, KR
    SearchPersonDetailsList personDetailsList = new SearchPersonDetailsList();

    if (!Configuration.getBooleanProperty(EnvVars.ENV_DYNAMIC_SQL_ENABLED)) {
      personDetailsList = providerParty.searchRepresentativeDetails(
        searchPersonKey);
    }
    return personDetailsList;
    // END, CR00170625
  }

  public SearchPersonDetails1List searchRepresentativeByNameAndAddress1(
    String referenceNo, String addressLine1, String firstName,
    String lastName, boolean personWithTraining,
    boolean personWithProviderMembership) throws AppException,
      InformationalException {

    // Create provider party instance
    curam.cpm.sl.entity.intf.ProviderParty providerParty = ProviderPartyFactory.newInstance();

    // Assign the search key details to SearchpersonKey struct
    SearchPersonKey1 searchPersonKey = new SearchPersonKey1();

    // Change the address line to upper case and concatenate
    // with wild character
    searchPersonKey.addressLine1 = CuramConst.gkSqlWildcard
      + addressLine1.toUpperCase() + CuramConst.gkSqlWildcard;

    // Concatenate first name and last name
    // with wild character
    searchPersonKey.firstName = CuramConst.gkSqlWildcard
      + firstName.toUpperCase() + CuramConst.gkSqlWildcard
      + lastName.toUpperCase() + CuramConst.gkSqlWildcard;

    searchPersonKey.personWithProviderMembership = personWithProviderMembership;

    searchPersonKey.personWithTraining = personWithTraining;

    searchPersonKey.providerMembershipPresent = personWithProviderMembership;

    searchPersonKey.referenceNo = referenceNo;

    searchPersonKey.searchByAddrLine = addressLine1.length() > 0;

    if (firstName.trim().length() > 0 || lastName.trim().length() > 0) {
      searchPersonKey.searchByFirstName = true;
    } else {
      searchPersonKey.searchByFirstName = false;
    }

    searchPersonKey.searchByReferenceNo = referenceNo.trim().length() > 0;

    searchPersonKey.providerPartyCategory = ProviderPartyCategoryEntry.MEMBER.getCode();

    // Set the concern role type as representative
    searchPersonKey.concernRoleType = CONCERNROLETYPEEntry.REPRESENTATIVE.getCode();

    searchPersonKey.providerPartyStatus = RECORDSTATUSEntry.NORMAL.getCode();

    searchPersonKey.trainingProgramStatus = TRAININGPROGRAMPARTYSTATUS.CANCELED;

    // BEGIN, CR00131081, ASN
    searchPersonKey.addressLine1Type = ADDRESSELEMENTTYPE.LINE1;
    searchPersonKey.cityType = ADDRESSELEMENTTYPE.CITY;
    // END, CR00131081

    // BEGIN, CR00170625, KR
    SearchPersonDetails1List personDetailsList = new SearchPersonDetails1List();

    if (Configuration.getBooleanProperty(EnvVars.ENV_DYNAMIC_SQL_ENABLED)) {
      personDetailsList = searchRepresentativeByNameAndAddressDynamicSql(
        searchPersonKey);
    } else {
      personDetailsList = providerParty.searchRepresentativeDetails1(
        searchPersonKey);
    }
    return personDetailsList;
    // END, CR00170625
  }

  /**
   * {@inheritDoc}
   */
  public Set<Person> listPersonMembershipHistory
    (Long partyConcernRoleID, ProviderPartyCategoryEntry category,
    RECORDSTATUSEntry status) {
    boolean searchByStatus = true;

    // Check if the records status is set
    if (status.equals(RECORDSTATUSEntry.NOT_SPECIFIED)
      || "".equals(status.getCode())) {
      searchByStatus = false;
    }

    // BEGIN, CR00170625, KR
    Set<Person> personSet = new HashSet<Person>();

    if (Configuration.getBooleanProperty(EnvVars.ENV_DYNAMIC_SQL_ENABLED)) {
      try {
        personSet = searchForPersonMembershipHistoryDynamicSql(
          partyConcernRoleID, category, status, searchByStatus);
      } catch (AppException appException) {
        throw new AppRuntimeException(appException);
      } catch (InformationalException infExp) {
        throw new AppRuntimeException(infExp);
      }
    } else {
      personSet = newSet(
        adapter.searchForPersonMembershipHistory(partyConcernRoleID,
        category.getCode(), status.getCode(), searchByStatus));
    }
    return personSet;
    // END, CR00170625
  }

  // BEGIN, CR00205270, ASN
  /**
   * {@inheritDoc}
   */
  public Set<SearchUnassignedProviderMemberDetails> searchUnassignedProviderMember(
    final String referenceNo, final String firstName, final String lastName,
    final boolean personWithTraining) throws AppException,
      InformationalException {

    SearchPersonKey1 searchPersonKey = new SearchPersonKey1();

    searchPersonKey.firstName = CuramConst.gkSqlWildcard
      + firstName.toUpperCase() + CuramConst.gkSqlWildcard
      + lastName.toUpperCase() + CuramConst.gkSqlWildcard;

    searchPersonKey.personWithTraining = personWithTraining;

    searchPersonKey.referenceNo = referenceNo;

    if (firstName.trim().length() > 0 || lastName.trim().length() > 0) {
      searchPersonKey.searchByFirstName = true;
    } else {
      searchPersonKey.searchByFirstName = false;
    }

    searchPersonKey.searchByReferenceNo = referenceNo.trim().length() > 0;

    searchPersonKey.providerPartyCategory = ProviderPartyCategoryEntry.UNASSIGNED.getCode();

    searchPersonKey.providerPartyStatus = RECORDSTATUSEntry.NORMAL.getCode();

    searchPersonKey.trainingProgramStatus = TRAININGPROGRAMPARTYSTATUS.CANCELED;

    Set<SearchUnassignedProviderMemberDetails> persons = new HashSet<SearchUnassignedProviderMemberDetails>();

    persons = searchUnassignedProviderMemberSQL(searchPersonKey);

    return persons;

  }

  // END, CR00205270
  
  // BEGIN, CR00170625, KR
  protected Set<Person> searchForPersonMembershipHistoryDynamicSql(
    Long partyConcernRoleID, ProviderPartyCategoryEntry category,
    RECORDSTATUSEntry status, boolean searchByStatus) throws AppException,
      InformationalException {

    ProviderPartyDtls[] providerPartyDtlsList = new ProviderPartyDtls[0];

    if (isAnyProviderPartyCriteriaEntered(partyConcernRoleID, category,
      searchByStatus)) {
      StringBuilder providerPartySearchQuery = new StringBuilder();
      StringBuilder selectBuilder = new StringBuilder();
      StringBuilder intoBuilder = new StringBuilder();
      StringBuilder fromBuilder = new StringBuilder();
      StringBuilder whereBuilder = new StringBuilder();

      selectFromProviderParty(selectBuilder, intoBuilder);
      fromBuilder.append(" FROM ProviderParty ");
      whereBuilder.append(" WHERE");
      SearchMembershipHistoryKey searchMembershipHistoryKey = new SearchMembershipHistoryKey();

      searchMembershipHistoryKey.category = category.getCode();
      searchMembershipHistoryKey.recordStatus = status.getCode();
      searchMembershipHistoryKey.partyConcernRoleID = partyConcernRoleID;
      providerPartyWhereCondition(searchByStatus, whereBuilder);

      buildFinalQuery(providerPartySearchQuery, selectBuilder, intoBuilder,
        fromBuilder, whereBuilder);

      // BEGIN, CR00292696, IBM
      CuramValueList curamValueList = DynamicDataAccess.executeNsMulti(
        ProviderPartyDtls.class, searchMembershipHistoryKey, false, true, 
        providerPartySearchQuery.toString());

      // END, CR00292696
      
      providerPartyDtlsList = new ProviderPartyDtls[curamValueList.size()];

      for (int i = 0; i < curamValueList.size(); i++) {
        providerPartyDtlsList[i] = (ProviderPartyDtls) curamValueList.get(i);
      }
    }
    return newSet(providerPartyDtlsList);
  }

  protected void buildFinalQuery(StringBuilder providerPartySearchQuery,
    StringBuilder selectBuilder, StringBuilder intoBuilder,
    StringBuilder fromBuilder, StringBuilder whereBuilder) {
    providerPartySearchQuery.append(selectBuilder);
    providerPartySearchQuery.append(intoBuilder);
    providerPartySearchQuery.append(fromBuilder);
    providerPartySearchQuery.append(whereBuilder);
  }

  protected void providerPartyWhereCondition(boolean searchByStatus,
    StringBuilder whereBuilder) {
    whereBuilder.append(
      " ProviderParty.partyConcernRoleID = :partyConcernRoleID");
    whereBuilder.append(" AND ProviderParty.category = :category");
    if (searchByStatus) {
      whereBuilder.append(" AND ProviderParty.recordStatus = :recordStatus");
    }
    whereBuilder.append(" ORDER BY ProviderParty.category");
  }

  protected boolean isAnyProviderPartyCriteriaEntered(Long partyConcernRoleID,
    ProviderPartyCategoryEntry category, boolean searchByStatus) {
    return partyConcernRoleID > 0 || searchByStatus
      || category.getCode().length() > 0;
  }

  protected void selectFromProviderParty(StringBuilder selectBuilder,
    StringBuilder intoBuilder) {
    selectBuilder.append(" SELECT");
    selectBuilder.append(" ProviderParty.providerPartyID,");
    selectBuilder.append(" ProviderParty.providerConcernRoleID,");
    selectBuilder.append(" ProviderParty.partyConcernRoleID,");
    selectBuilder.append(" ProviderParty.startDate,");
    // BEGIN, CR00320064, SSK
    selectBuilder.append(" ProviderParty.startDateTime,");
    selectBuilder.append(" ProviderParty.endDateTime,");
    // END, CR00320064
    selectBuilder.append(" ProviderParty.endDate,");
    selectBuilder.append(" ProviderParty.category,");
    selectBuilder.append(" ProviderParty.type,");
    selectBuilder.append(" ProviderParty.position,");
    selectBuilder.append(" ProviderParty.versionNo,");
    selectBuilder.append(" ProviderParty.recordStatus");
    
    intoBuilder.append(" INTO ");
    intoBuilder.append(" :providerPartyID,");
    intoBuilder.append(" :providerConcernRoleID,");
    intoBuilder.append(" :partyConcernRoleID,");
    intoBuilder.append(" :startDate,");
    // BEGIN, CR00320064, SSK
    intoBuilder.append(" :startDateTime,");
    intoBuilder.append(" :endDateTime,");
    // END, CR00320064
    intoBuilder.append(" :endDate,");
    intoBuilder.append(" :category,");
    intoBuilder.append(" :type,");
    intoBuilder.append(" :position,");
    intoBuilder.append(" :versionNo,");
    intoBuilder.append(" :recordStatus");
  }

  protected SearchPersonDetails1List searchRepresentativeByNameAndAddressDynamicSql(
    SearchPersonKey1 searchPersonKey) throws AppException,
      InformationalException {

    SearchPersonDetails1List searchPersonDetailsList = new SearchPersonDetails1List();

    if (isAnyPersonNameAndAddressCriteriaEntered(searchPersonKey)) {

      StringBuilder providerPartySearchQuery = new StringBuilder();
      StringBuilder selectBuilder = new StringBuilder();
      StringBuilder intoBuilder = new StringBuilder();
      StringBuilder fromBuilder = new StringBuilder();
      StringBuilder whereBuilder = new StringBuilder();

      selectFromConcernRole(selectBuilder, intoBuilder);
      // BEGIN, CR00417548, SS
      selectBuilder.append(" ,Representative.dateofBirth");

      fromBuilder.append(" FROM Representative, Address, ConcernRole ");
      // END, CR00417548
      whereBuilder.append(" WHERE");
      searchPersonOrRepresentativeWhereCondition(searchPersonKey, whereBuilder,
        fromBuilder);
      // BEGIN, CR00417548, SS
      whereBuilder.append(
        " AND Address.addressID = ConcernRole.primaryAddressID");
      // END, CR00417548
      fromBuilder.append(
        ", AddressElement city, AddressElement addressLine1, AlternateName ");

      searchByRepresentativeName(searchPersonKey, whereBuilder);

      searchByAddressLine(whereBuilder);

      buildFinalQuery(providerPartySearchQuery, selectBuilder, intoBuilder,
        fromBuilder, whereBuilder);

      // BEGIN, CR00292696, IBM
      // BEGIN, CR00417548, SS
      final CuramValueList<SearchPersonDetails1> curamValueList = DynamicDataAccess.executeNsMulti(
        SearchPersonDetails1.class, searchPersonKey, false, true,
        providerPartySearchQuery.toString());

      searchPersonDetailsList.dtls.addAll(curamValueList);
      // END, CR00417548
      // END, CR00292696      
    }
    return searchPersonDetailsList;
  }

  protected void searchByRepresentativeName(SearchPersonKey1 searchPersonKey,
    StringBuilder providerPartySearchQuery) {
    if (searchPersonKey.searchByFirstName) {

      providerPartySearchQuery.append(
        " AND Representative.concernRoleID = ConcernRole.concernRoleID");
      // BEGIN, CR00199527, ASN
      providerPartySearchQuery.append(
        " AND Representative.upperRepresentativeName LIKE :firstName ");
      // END, CR00199527
    }
  }

  protected SearchPersonDetails1List searchPersonByNameAndAddressDynamicSql(
    SearchPersonKey1 searchPersonKey) throws AppException,
      InformationalException {

    SearchPersonDetails1List searchPersonDetailsList = new SearchPersonDetails1List();

    if (isAnyPersonNameAndAddressCriteriaEntered(searchPersonKey)) {

      StringBuilder providerPartySearchQuery = new StringBuilder();
      StringBuilder selectBuilder = new StringBuilder();
      StringBuilder intoBuilder = new StringBuilder();
      StringBuilder fromBuilder = new StringBuilder();
      StringBuilder whereBuilder = new StringBuilder();

      selectFromConcernRole(selectBuilder, intoBuilder);
      // BEGIN, CR00417548, SS
      selectBuilder.append(" ,Person.dateofBirth");

      fromBuilder.append(" FROM Address, ConcernRole ");
      // END, CR00417548

      whereBuilder.append(" WHERE");

      searchPersonOrRepresentativeWhereCondition(searchPersonKey, whereBuilder,
        fromBuilder);  
      // BEGIN, CR00417548, SS
      whereBuilder.append(
        " AND Person.concernRoleID = ConcernRole.concernRoleID");
      whereBuilder.append(
        " AND Address.addressID = ConcernRole.primaryAddressID");
      fromBuilder.append(
        ", AddressElement city, AddressElement addressLine1, AlternateName, Person ");
      // END, CR00417548
      searchPersonByName(searchPersonKey, whereBuilder);
      searchByAddressLine(whereBuilder);

      buildFinalQuery(providerPartySearchQuery, selectBuilder, intoBuilder,
        fromBuilder, whereBuilder);

      // BEGIN, CR00292696, IBM
      // BEGIN, CR00417548, SS
      final CuramValueList<SearchPersonDetails1> curamValueList = DynamicDataAccess.executeNsMulti(
        SearchPersonDetails1.class, searchPersonKey, false, true,
        providerPartySearchQuery.toString());

      searchPersonDetailsList.dtls.addAll(curamValueList);
      // END, CR00417548
      // END, CR00292696
    }

    return searchPersonDetailsList;
  }

  protected void searchPersonByName(SearchPersonKey1 searchPersonKey,
    StringBuilder providerPartySearchQuery) {
    if (searchPersonKey.searchByFirstName) {

      providerPartySearchQuery.append(
        " AND AlternateName.concernRoleID = ConcernRole.concernRoleID");
      providerPartySearchQuery.append(
        " AND AlternateName.upperFirstForename LIKE :firstName ");
    }
    if (searchPersonKey.searchByLastName) {

      providerPartySearchQuery.append(
        " AND AlternateName.concernRoleID = ConcernRole.concernRoleID");
      providerPartySearchQuery.append(
        " AND AlternateName.upperSurname LIKE :lastName ");
    }
  }

  protected void searchPersonOrRepresentativeWhereCondition(
    SearchPersonKey1 searchPersonKey, StringBuilder whereBuilder,
    StringBuilder fromBuilder) {
    whereBuilder.append(" ConcernRole.concernRoleType = :concernRoleType");    
   
    if (searchPersonKey.searchByReferenceNo) {

      whereBuilder.append(" AND ConcernRole.primaryAlternateID = :referenceNo ");
    }
    if (searchPersonKey.searchByAddrLine) {
      whereBuilder.append(
        " AND addressLine1.upperElementValue like :addressLine1 ");
    }
    if (searchPersonKey.providerMembershipPresent) {
      fromBuilder.append(" LEFT OUTER JOIN ProviderParty ON");
      fromBuilder.append(
        " ConcernRole.concernRoleID = ProviderParty.partyConcernRoleID ");
      whereBuilder.append(
        " AND ProviderParty.category = :providerPartyCategory ");
      whereBuilder.append(
        " AND ProviderParty.recordStatus = :providerPartyStatus ");
    }
    if (searchPersonKey.personWithTraining) {
      fromBuilder.append(" LEFT OUTER JOIN TrainingProgramMember ON");
      fromBuilder.append(
        " ConcernRole.concernRoleID = TrainingProgramMember.partyConcernRoleID ");
      whereBuilder.append(
        " AND TrainingProgramMember.partyConcernRoleID = ConcernRole.concernRoleID");
      whereBuilder.append(
        " AND TrainingProgramMember.status <> :trainingProgramStatus ");
    }
  }

  protected void searchByAddressLine(StringBuilder whereBuilder) {
    whereBuilder.append(
      " AND addressLine1.addressID = ConcernRole.primaryAddressID");
    whereBuilder.append(" AND addressLine1.elementType = :addressLine1Type ");
    whereBuilder.append(" AND city.addressID = ConcernRole.primaryAddressID");
    whereBuilder.append(" AND city.elementType = :cityType ");
  }

  protected boolean isAnyPersonNameAndAddressCriteriaEntered(
    SearchPersonKey1 searchPersonKey) {
    return searchPersonKey.searchByReferenceNo
      || searchPersonKey.searchByAddrLine || searchPersonKey.searchByFirstName
      || searchPersonKey.searchByLastName
      || searchPersonKey.providerMembershipPresent
      || searchPersonKey.personWithTraining;
  }

  protected void selectFromConcernRole(StringBuilder selectBuilder,
    StringBuilder intoBuilder) {
    selectBuilder.append(" SELECT");
    selectBuilder.append(" DISTINCT(ConcernRole.concernRoleID),");
    selectBuilder.append(" ConcernRole.concernRoleName,");
    selectBuilder.append(" ConcernRole.registrationDate,");
    selectBuilder.append(" ConcernRole.statusCode,");
    selectBuilder.append(" ConcernRole.primaryAlternateID,");
    selectBuilder.append(" city.elementValue,");
    selectBuilder.append(" addressLine1.elementValue,"); 
    // BEGIN, CR00417548, SS
    selectBuilder.append(" Address.addressData");
    // END, CR00417548
    intoBuilder.append(" INTO ");
    intoBuilder.append(" :concernRoleID,");
    intoBuilder.append(" :concernRoleName,");
    intoBuilder.append(" :startDate,");
    intoBuilder.append(" :status,");
    intoBuilder.append(" :referenceNo,");
    intoBuilder.append(" :city,");
    intoBuilder.append(" :addressLine1,");
    // BEGIN, CR00417548, SS
    intoBuilder.append(" :addressOpt,");
    intoBuilder.append(" :dateOfBirthOpt");
    // END, CR00417548
  }

  // END, CR00170625

  // BEGIN, CR00205270, ASN
  /**
   * Searches using name or training criteria.
   *
   * @param SearchPersonKey
   * The search criteria of a unassigned provider member.
   *
   * @return an indicator based on which dynamic query will be formed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected boolean isAnyNameAndTrainingCriteriaEntered(
    final SearchPersonKey1 searchPersonKey) {
    return searchPersonKey.searchByReferenceNo
      || searchPersonKey.searchByFirstName || searchPersonKey.searchByLastName
      || searchPersonKey.personWithTraining;
  }
  
  /**
   * Builds the partial query which has select and into clauses of the query for
   * searching unassigned provider member.
   *
   * @param selectBuilder
   * The select clause of the query.
   * @param intoBuilder
   * The into clause of the query.
   */
  protected void UnassignedProviderMemberSelectQuery(final StringBuilder selectBuilder,
    final StringBuilder intoBuilder) {
    selectBuilder.append(" SELECT");
    selectBuilder.append(" ConcernRole.concernRoleID,");
    selectBuilder.append(" ConcernRole.concernRoleName,");
    selectBuilder.append(" ProviderParty.endDate,");
    selectBuilder.append(" ProviderParty.providerPartyID, ");
    selectBuilder.append(" ConcernRole.primaryAlternateID, ");
    selectBuilder.append(" ConcernRole.registrationDate, ");
    selectBuilder.append(" ProviderParty.startDate, ");
    // BEGIN, CR00205844, ASN
    selectBuilder.append(" ProviderParty.recordStatus, ");
    // END, CR00205844
    selectBuilder.append(" TrainingProgramMember.trainingProgramMemberID, ");
    selectBuilder.append(" ProviderParty.versionNo");

    intoBuilder.append(" INTO ");
    intoBuilder.append(" :concernRoleID, ");
    intoBuilder.append(" :concernRoleName, ");
    intoBuilder.append(" :endDate, ");
    intoBuilder.append(" :providerPartyID, ");
    intoBuilder.append(" :referenceNo, ");
    intoBuilder.append(" :registrationDate, ");
    intoBuilder.append(" :startDate, ");
    intoBuilder.append(" :status, ");
    intoBuilder.append(" :trainingProgramMemberID, ");
    intoBuilder.append(" :versionNo ");

  }

  /**
   * Builds the partial query which has where and form clauses of the query used
   * for searching unassigned provider member.
   *
   * @param searchPersonKey
   * Key having the search criteria specified.
   * @param whereBuilder
   * The where clause of the query.
   * @param fromBuilder
   * The from clause of the query.
   */
  protected void searchUnassignedProviderMemberWhereCondition(
    final SearchPersonKey1 searchPersonKey, final StringBuilder whereBuilder,
    final StringBuilder fromBuilder) {

    if (searchPersonKey.searchByReferenceNo) {
      // BEGIN, CR00205844, ASN
      whereBuilder.append(" ConcernRole.primaryAlternateID = :referenceNo ");
      whereBuilder.append(
        " AND  ProviderParty.category = :providerPartyCategory ");
    } else {
      whereBuilder.append(" ProviderParty.category = :providerPartyCategory ");
    }
    // END, CR00205844
    
    fromBuilder.append(" LEFT OUTER JOIN ProviderParty ON");
    fromBuilder.append(
      " ConcernRole.concernRoleID = ProviderParty.partyConcernRoleID ");
   
    // BEGIN, CR00205844, ASN
    whereBuilder.append(
      " AND Upper(ConcernRole.concernRoleName) like :firstName ");
    // END, CR00205844
    
    fromBuilder.append(" LEFT OUTER JOIN TrainingProgramMember ON");
    fromBuilder.append(
      " ConcernRole.concernRoleID = TrainingProgramMember.partyConcernRoleID ");
    
    if (searchPersonKey.personWithTraining) {

      whereBuilder.append(
        " AND TrainingProgramMember.status <> :trainingProgramStatus ");
    }
  }

  /**
   * Searches the unassigned provider members using dynamic query.
   *
   * @param searchPersonKey
   * The criteria based on which unassigned provider member can be
   * searched.
   *
   * @return The unassigned provider members which match the specified criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Set<SearchUnassignedProviderMemberDetails> searchUnassignedProviderMemberSQL(
    final SearchPersonKey1 searchPersonKey) throws AppException,
      InformationalException {

    Set<SearchUnassignedProviderMemberDetails> persons = new HashSet<SearchUnassignedProviderMemberDetails>();

    SearchUnassignedProviderMemberDetails person = new SearchUnassignedProviderMemberDetails();

    if (isAnyNameAndTrainingCriteriaEntered(searchPersonKey)) {

      StringBuilder providerPartySearchQuery = new StringBuilder();
      StringBuilder selectBuilder = new StringBuilder();
      StringBuilder intoBuilder = new StringBuilder();
      StringBuilder fromBuilder = new StringBuilder();
      StringBuilder whereBuilder = new StringBuilder();

      UnassignedProviderMemberSelectQuery(selectBuilder, intoBuilder);
      // BEGIN, CR00205844, ASN
      fromBuilder.append(" FROM ConcernRole ");
      // END, CR00205844
      whereBuilder.append(" WHERE");
      searchUnassignedProviderMemberWhereCondition(searchPersonKey,
        whereBuilder, fromBuilder);

      buildFinalQuery(providerPartySearchQuery, selectBuilder, intoBuilder,
        fromBuilder, whereBuilder);

      // BEGIN, CR00292696, IBM
      CuramValueList curamValueList = DynamicDataAccess.executeNsMulti(
        SearchUnassignedProviderMemberDetails.class, searchPersonKey, false,
        true, providerPartySearchQuery.toString());
      // END, CR00292696

      Map<Long, SearchUnassignedProviderMemberDetails> checkDuplicateMap = new HashMap<Long, SearchUnassignedProviderMemberDetails>();

      for (int i = 0; i < curamValueList.size(); i++) {

        person = (SearchUnassignedProviderMemberDetails) curamValueList.get(i);

        if (!checkDuplicateMap.containsKey(person.concernRoleID)) {
          
          checkDuplicateMap.put(person.concernRoleID, person);
          persons.add(person);
        }
        if (checkDuplicateMap.containsKey(person.concernRoleID)) {
          
          SearchUnassignedProviderMemberDetails duplicatePerson = new SearchUnassignedProviderMemberDetails();
          
          duplicatePerson = checkDuplicateMap.get(person.concernRoleID);
          
          if (!duplicatePerson.startDate.equals(person.startDate)
            && !duplicatePerson.endDate.equals(person.endDate)) {
            
            persons.add(person);
          }

        }

      }
    }
    return persons;
  }

  // END, CR00205270
  
  public SearchPersonDetails1List searchPersonByNameAndAddress1(
    String referenceNo, String addressLine1, String firstName,
    String lastName, boolean personWithTraining,
    boolean personWithProviderMembership) throws AppException,
      InformationalException {

    // Create provider party instance
    curam.cpm.sl.entity.intf.ProviderParty providerParty = ProviderPartyFactory.newInstance();

    // Assign the search key details to SearchpersonKey struct
    SearchPersonKey1 searchPersonKey = new SearchPersonKey1();

    // Change the address line to upper case and concatenate
    // with wild character
    searchPersonKey.addressLine1 = CuramConst.gkSqlWildcard
      + addressLine1.toUpperCase() + CuramConst.gkSqlWildcard;

    // Change the first name to upper case and concatenate
    // with wild character
    searchPersonKey.firstName = CuramConst.gkSqlWildcard
      + firstName.toUpperCase() + CuramConst.gkSqlWildcard;

    // Change the last name to upper case and concatenate
    // with wild character
    searchPersonKey.lastName = CuramConst.gkSqlWildcard
      + lastName.toUpperCase() + CuramConst.gkSqlWildcard;

    searchPersonKey.personWithProviderMembership = personWithProviderMembership;

    searchPersonKey.personWithTraining = personWithTraining;

    searchPersonKey.providerMembershipPresent = personWithProviderMembership;

    searchPersonKey.referenceNo = referenceNo;

    // Check if different search criteria are entered
    searchPersonKey.searchByAddrLine = addressLine1.length() > 0;

    searchPersonKey.searchByFirstName = firstName.trim().length() > 0;

    searchPersonKey.searchByLastName = lastName.trim().length() > 0;

    searchPersonKey.searchByReferenceNo = referenceNo.trim().length() > 0;

    searchPersonKey.providerPartyCategory = ProviderPartyCategoryEntry.MEMBER.getCode();

    // Set the concern role type as person
    searchPersonKey.concernRoleType = CONCERNROLETYPEEntry.PERSON.getCode();

    searchPersonKey.providerPartyStatus = RECORDSTATUSEntry.NORMAL.getCode();

    searchPersonKey.trainingProgramStatus = TRAININGPROGRAMPARTYSTATUS.CANCELED;
    // BEGIN, CR00131081, ASN
    searchPersonKey.addressLine1Type = ADDRESSELEMENTTYPE.LINE1;

    searchPersonKey.cityType = ADDRESSELEMENTTYPE.CITY;
    // END, CR00131081

    // BEGIN, CR00170625, KR
    SearchPersonDetails1List personDetailsList = new SearchPersonDetails1List();

    if (Configuration.getBooleanProperty(EnvVars.ENV_DYNAMIC_SQL_ENABLED)) {
      personDetailsList = searchPersonByNameAndAddressDynamicSql(
        searchPersonKey);
    } else {
      personDetailsList = providerParty.searchPersonDetails1(searchPersonKey);
    }    

    return personDetailsList;
    // END, CR00170625
  }
}
