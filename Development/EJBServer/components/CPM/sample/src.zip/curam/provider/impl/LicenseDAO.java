/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.List;
import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.StandardDAO;
import curam.util.type.Date;


/**
 * Data access for
 * {@linkplain curam.provider.impl.License}.
 */
@ImplementedBy(LicenseDAOImpl.class)
public interface LicenseDAO extends StandardDAO<License> {

  // ___________________________________________________________________________
  /**
   * Returns a set of licenses based on specified search criteria.
   *
   * @param number                the license number
   * @param licenseType           the license type
   * @param licenseStatus         the license status
   * @param dateIssued            the date the license was issued
   * @param expirationDate        the expiration date of the license
   * @param renewedInd            the license renewed indicator
   * @param providerConcernRoleID the concern role ID of the provider
   *
   * @return set of licenses based on specified search criteria.
   */
  public Set<License> searchByLicenseNumberAndType(
    final String number, final String licenseType,
    final String licenseStatus, final Date dateIssued, final Date expirationDate,
    final boolean renewedInd, final long providerConcernRoleID);

  // ___________________________________________________________________________
  /**
   * Returns a set of licenses for a provider.
   *
   * @param provider  the provider
   * @return set of licenses for a provider.
   * @see Provider
   */
  public Set<License> searchLicensesByProvider(final Provider provider);

  // ___________________________________________________________________________
  /**
   * Returns a set of licenses based on specified search criteria.
   *
   * @param issuer                the issuer
   * @param licenseType           the license type
   * @param dateIssued            the date the license was issued
   * @param expirationDate        the expiration date of the license
   * @param licenseStatus         the license status
   * @param renewedInd            the license renewed indicator
   * @param providerConcernRoleID the concern role ID of the provider
   *
   * @return set of licenses based on specified search criteria.
   */
  public Set<License> searchActiveLicenseByIssuerTypeAndExpirationDate(
    final String issuer, final String licenseType, final Date dateIssued,
    final Date expirationDate, final String licenseStatus,
    final boolean renewedInd, final long providerConcernRoleID);

  // ___________________________________________________________________________
  /**
   * Returns a set of all licenses.
   *
   * @return set of all licenses
   */
  public Set<License> readAll();

  // ___________________________________________________________________________
  /**
   * Returns a list of approved licenses based on specified search criteria.
   *
   * @param providerConcernRoleID   the concern role ID of the provider
   * @param licenseType             the license type
   * @return list of approved licenses based on specified search criteria.
   */
  public List<License> searchApprovedLicencesByProviderAndType(
    final long providerConcernRoleID, final String licenseType);

}
