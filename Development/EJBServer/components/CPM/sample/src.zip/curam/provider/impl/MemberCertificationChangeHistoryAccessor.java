/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.certification.impl.CertificationAccessor;
import curam.codetable.impl.MEMBERCERTIFICATIONSTATUSEntry;
import curam.util.persistence.StandardEntity;
import curam.util.type.Date;
import curam.util.type.DateTime;


/**
 * Accessor interface for {@linkplain MemberCertificationChangeHistory}.
 *
 */
public interface MemberCertificationChangeHistoryAccessor extends
    StandardEntity {

  /**
   * Gets the user name for the member certification
   *
   * @return contains the user name
   */
  String getUserName();

  /**
   * Gets the member certificationID
   *
   * @return contains system generated identifier for the member certification
   */
  long getMemberCertificationID();

  /**
   * Gets the date time when the record was created
   * @return contains the date time when the member certification was created.
   */
  DateTime getDateTime();

  /**
   * Gets the date of issue
   *
   * @return contains the date the certification is issued
   */
  Date getDateOfIssue();

  /**
   * Gets the date of expiry
   *
   * @return contains the date the certification is expired.
   */
  Date getDateOfExpiry();

  /**
   * The returned objects are intentionally accessor-only.
   * Calling code must not attempt to cast any of these objects
   * to its mutator interface, nor use the object's ID to
   * re-retrieve a mutable instance from the database.
   *
   *
   * @return Contains the instance of certification
   */
  CertificationAccessor getCertification();

  // BEGIN CR00128529, KK
  /**
   * This method is to get the derived status for the member certification
   * <p>
   * The returned objects are intentionally accessor-only.
   * Calling code must not attempt to cast any of these objects
   * to its mutator interface, nor use the object's ID to
   * re-retrieve a mutable instance from the database.
   *
   *
   * @return contains the derived status.
   */
  MEMBERCERTIFICATIONSTATUSEntry getDerivedStatus();
  // END CR00128529
}
