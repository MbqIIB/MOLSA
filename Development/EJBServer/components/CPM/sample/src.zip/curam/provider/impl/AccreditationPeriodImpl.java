/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.HashSet;
import java.util.Set;

import com.google.inject.Inject;

import curam.cpm.sl.entity.struct.AccreditationPeriodDtls;
import curam.message.impl.PROVIDERACCREDITATIONExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.Date;
import curam.util.type.DateRange;


// BEGIN, CR00183213, SS
public class AccreditationPeriodImpl extends SingleTableEntityImpl<AccreditationPeriodDtls> implements
  AccreditationPeriod {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<AccreditationPeriodInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<AccreditationPeriodModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  /**
   * Provider Accreditation
   */
  @Inject
  protected ProviderAccreditationDAO providerAccreditationDAO;

  /**
   * Provider Security
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected AccreditationPeriodImpl() {// Constructor for the class.
    // END, CR00183213
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {
    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ProviderAccreditation getProviderAccreditation() {
    final long id = getDtls().providerAccreditationID;

    return id == 0 ? null : providerAccreditationDAO.get(id);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setProviderAccreditation(ProviderAccreditation value) {
    getDtls().providerAccreditationID = value.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setDateRange(DateRange value) {
    getDtls().startDate = value.start();
    getDtls().endDate = value.end();
  }

  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERACCREDITATION#ERR_PROVIDERACCREDITATION_FV_STARTDATE_MUST_BE_ENTERED} -
   * If the start date is not entered. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    if (getDateRange().start().isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERACCREDITATIONExceptionCreator.ERR_PROVIDERACCREDITATION_FV_STARTDATE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERACCREDITATION#ERR_PROVIDERACCREDITATION_XFV_STARTDATE_LATER_THAN_EXPIRATIONDATE} -
   * if the start date is later than the expiry date. </li>
   * </ul>
   */
  public void crossFieldValidation() {

    // Check if start date is later than expiry date
    if (getDtls().startDate.after(getDtls().endDate)
      && getDateRange().isEnded()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERACCREDITATIONExceptionCreator.ERR_PROVIDERACCREDITATION_XFV_STARTDATE_LATER_THAN_EXPIRATIONDATE(
          getDtls().endDate, getDtls().startDate),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates that changes made to incident entity on the database are
   * consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERACCREDITATION#ERR_PROVIDERACCREDITATION_XRV_PERIOD_ALREADY_EXISTS_FROM_TO} -
   * If overlapping date range with end date set. </li>
   * <li>
   * {@link curam.message.PROVIDERACCREDITATION#ERR_PROVIDERACCREDITATION_XRV_PERIOD_ALREADY_EXISTS_FROM} -
   * If overlapping date range with same start date. </li>
   * </ul>
   *
   */
  public void crossEntityValidation() {

    Set<AccreditationPeriod> unModifiableAccreditationPeriods = providerAccreditationDAO.get(getDtls().providerAccreditationID).getAccreditationPeriods();
    Set<AccreditationPeriod> accreditionPeriods = new HashSet<AccreditationPeriod>();

    accreditionPeriods.addAll(unModifiableAccreditationPeriods);

    for (curam.provider.impl.AccreditationPeriod accreditationPeriod : accreditionPeriods) {

      if (!accreditationPeriod.getID().equals(this.getID())) {
        // Check for overlapping date range with end date set
        if (accreditationPeriod.getDateRange().overlapsWith(getDateRange())) {
          if (accreditationPeriod.getDateRange().isEnded()) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERACCREDITATIONExceptionCreator.ERR_PROVIDERACCREDITATION_XRV_PERIOD_ALREADY_EXISTS_FROM_TO(
                ProviderAccreditationTypeEntry.get(accreditationPeriod.getProviderAccreditation().getType()).toUserLocaleString(),
                accreditationPeriod.getDateRange().start(),
                accreditationPeriod.getDateRange().end()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
          } else if (accreditationPeriod.getDateRange().start().before(
            getDateRange().start())) {

            final DateRange dateRange = new DateRange(
              accreditationPeriod.getDateRange().start(),
              getDateRange().start().addDays(-1));

            accreditationPeriod.setDateRange(dateRange);
            // Set the end date for overlapping date range
            try {
              accreditationPeriod.modify(accreditationPeriod.getVersionNo());
            } catch (Exception e) {// Do nothing
            }

          } else {
            // Check for overlapping date range with same start date
            ValidationHelper.addValidationError(
              ValidationHelper.addValidationError(
                PROVIDERACCREDITATIONExceptionCreator.ERR_PROVIDERACCREDITATION_XRV_PERIOD_ALREADY_EXISTS_FROM(
                  ProviderAccreditationTypeEntry.get(accreditationPeriod.getProviderAccreditation().getType()).toUserLocaleString(),
                  accreditationPeriod.getDateRange().start())));
          }
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {
    getDtls().startDate = Date.kZeroDate;
    getDtls().endDate = Date.kZeroDate;
  }

  // ___________________________________________________________________________
  /**
   * Inserts the accreditation period.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERACCREDITATION#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * if the status of the provider is closed.
   */
  @Override
  public void insert() throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(
      getProviderAccreditation().getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre insert accreditation period event.
    insertEventDispatcherFactory.get(AccreditationPeriodInsertEvents.class).preInsert(
      this);
    // END CR00235789
    // if the status of the provider is closed
    if (getProviderAccreditation().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 41);
      ValidationHelper.failIfErrorsExist();
    }

    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert accreditation period event.
    insertEventDispatcherFactory.get(AccreditationPeriodInsertEvents.class).postInsert(
      this);
    // END CR00235789
  }

  // ___________________________________________________________________________
  /**
   * Modifies the accreditation period.
   *
   * @param versionNo
   * The version number.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERACCREDITATION#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * if the status of the provider is closed.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(
      getProviderAccreditation().getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre modify accreditation period event.
    modifyEventDispatcherFactory.get(AccreditationPeriodModifyEvents.class).preModify(
      this);
    // END CR00235789

    // if the status of the provider is closed
    if (getProviderAccreditation().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 42);
      ValidationHelper.failIfErrorsExist();
    }

    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify accreditation period event.
    modifyEventDispatcherFactory.get(AccreditationPeriodModifyEvents.class).postModify(
      this);
    // END CR00235789

  }
}
