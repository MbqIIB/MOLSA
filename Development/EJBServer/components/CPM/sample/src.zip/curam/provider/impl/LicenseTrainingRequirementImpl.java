/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.Inject;

import curam.core.sl.struct.RecordCount;
import curam.cpm.sl.entity.struct.LicenseTrainingRequirementDtls;
import curam.cpm.sl.entity.struct.SearchByTrainingLicenseTypeKey;
import curam.message.impl.LICENSETRAININGREQUIREMENTExceptionCreator;
import curam.training.impl.Training;
import curam.training.impl.TrainingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.LicenseTrainingRequirement}.
 */
// BEGIN, CR00183213, SS
public class LicenseTrainingRequirementImpl extends SingleTableEntityImpl<LicenseTrainingRequirementDtls> implements
  LicenseTrainingRequirement {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for remove events.
   */
  @Inject
  protected EventDispatcherFactory<LicenseTrainingRequirementRemoveEvents> removeEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<LicenseTrainingRequirementInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<LicenseTrainingRequirementModifyEvents> modifyEventDispatcherFactory;
  // END, CR00235789

  /**
   * Reference to Training DAO
   */
  @Inject
  protected TrainingDAO trainingDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  // END, CR00183213
  public LicenseTrainingRequirementImpl() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Sets the Training as the Training Requirement for a License Type.
   *
   * @param value
   * The Training which is added as Training Requirement to a License
   * Type.
   * @throws InformationalException
   * {@link curam.message.LICENSETRAININGREQUIREMENT#ERR_LICENSETRAININGREQUIREMENT_FV_TRAINING_EMPTY} -
   * If Training is empty.
   */
  public void setTraining(Training value) {
    // Training not entered.
    if (value.getID() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSETRAININGREQUIREMENTExceptionCreator.ERR_LICENSETRAININGREQUIREMENT_FV_TRAINING_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    getDtls().trainingID = value.getID();
  }

  /**
   * {@inheritDoc}
   */
  public Training getTraining() {
    final long id = getDtls().trainingID;

    return id == 0 ? null : trainingDAO.get(id);
  }

  /**
   * Sets the Completion code on Training Requirement record, as 'required' or
   * 'recommended'.This indicates that the provider has to complete the
   * Trainings marked as 'Required'in order to be licensed .
   *
   * @param value
   * the Completion code on Training Requirement as required or
   * recommended.
   * @throws InformationalException
   * {@link curam.message.LICENSETRAININGREQUIREMENT#ERR_LICENSETRAININGREQUIREMENT_FV_TRAINING_COMPLETION_EMPTY} -
   * If Training completion is empty.
   */
  public void setCompletion(TrainingCompletionEntry value)
    throws InformationalException {

    // Training completion not entered.
    if (value.equals(TrainingCompletionEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSETRAININGREQUIREMENTExceptionCreator.ERR_LICENSETRAININGREQUIREMENT_FV_TRAINING_COMPLETION_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    getDtls().completion = value.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public TrainingCompletionEntry getCompletion() {
    return TrainingCompletionEntry.get(getDtls().completion);
  }

  /**
   * Sets the removal reason for removing the Training Requirement from a
   * License Type.
   *
   * @param value
   * The removal reason for removing the Training Requirement from a
   * License Type.
   * @throws InformationalException
   * {@link curam.message.LICENSETRAININGREQUIREMENT#ERR_LICENSETRAININGREQUIREMENT_FV_REMOVAL_REASON_EMPTY} -
   * If Removal Reason is empty.
   */
  public void setRemovalReason(TrainingRemovalReasonEntry value)
    throws InformationalException {
    if (value.equals(TrainingRemovalReasonEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSETRAININGREQUIREMENTExceptionCreator.ERR_LICENSETRAININGREQUIREMENT_FV_REMOVAL_REASON_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    getDtls().removalReason = value.getCode();

  }

  /**
   * Gets the removal reason of the training requirement from the license type.
   *
   * @return The removal reason of the training requirement.
   */
  public TrainingRemovalReasonEntry getRemovalReason() {
    return TrainingRemovalReasonEntry.get(getDtls().removalReason);
  }

  /**
   * Sets the License Type.
   *
   * @param value
   * The code value of a License Type.
   * @throws InformationalException
   * {@link curam.message.LICENSETRAININGREQUIREMENT#ERR_LICENSETRAININGREQUIREMENT_FV_LICENSE_TYPE_EMPTY} -
   * If License Type is empty.
   */
  public void setLicenseType(final LicenseTypeEntry value) {
    if (value.equals(LicenseTypeEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSETRAININGREQUIREMENTExceptionCreator.ERR_LICENSETRAININGREQUIREMENT_FV_LICENSE_TYPE_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    getDtls().licenseType = value.getCode();
  }

  /**
   * Gets the License Type.
   *
   * @return The License Type.
   */
  public LicenseTypeEntry getLicenseType() {
    return LicenseTypeEntry.get(getDtls().licenseType);
  }

  /**
   * {@inheritDoc}
   */
  public void setRecordStatus(TrainingRequirementStatusEntry value) {
    getDtls().status = value.getCode();
  }

  /**
   * Gets the license training requirement id.
   *
   * @return the license training requirement id.
   */
  public Long getID() {
    return getDtls().licenseTrainingRequirementID;
  }

  /**
   * Validates and inserts the license training requirement record.
   *
   * @throws InformationalException
   * {@link curam.message.LICENSETRAININGREQUIREMENT#ERR_LICENSETRAININGREQUIREMENT_XRV_TRAINING_REQUIREMENT_ALL_READY_EXIST}
   * -If the Training Requirement already exists for a License Type.
   */
  @Override
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre insert license training requirement event.
    insertEventDispatcherFactory.get(LicenseTrainingRequirementInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    try {
      validateTrainingRequirementDetails();
    } catch (AppException appException) {
      ValidationHelper.addValidationError(appException);
      ValidationHelper.failIfErrorsExist();
    }

    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert license training requirement event.
    insertEventDispatcherFactory.get(LicenseTrainingRequirementInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * Gets the version number of the training requirement record.
   *
   * @return The version number of the training requirement record.
   */
  public int getVersionNo() {
    return getDtls().versionNo;
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No cross entity validations
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No cross field validations
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// mandatory field validation is done at setters
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {

    // Sets the record status to 'Active'.
    getDtls().status = TrainingRequirementStatusEntry.ACTIVE.getCode();

  }

  /**
   * Modifies the Training Requirement details.
   *
   * @param versionNo
   * The version number of the Training Requirement record to be
   * modified.
   *
   * @throws InformationalException
   * {@link curam.message.LICENSETRAININGREQUIREMENT#ERR_LICENSETRAININGREQUIREMENT_XRV_TRAINING_REQUIREMENT_REMOVED_CANNOT_MODIFY}
   * -If Training Requirement record in the 'Removed' state is
   * modified.
   * @throws InformationalException
   * {@link curam.message.LICENSETRAININGREQUIREMENT#ERR_LICENSETRAININGREQUIREMENT_XRV_TRAINING_REQUIREMENT_ALL_READY_EXIST}
   * -If the Training Requirement already exists for a License Type.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre modify license training requirement event.
    modifyEventDispatcherFactory.get(LicenseTrainingRequirementModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // If Training Requirement record in the 'Removed' state is modified.
    if (getLifecycleState().equals(TrainingRequirementStatusEntry.REMOVED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSETRAININGREQUIREMENTExceptionCreator.ERR_LICENSETRAININGREQUIREMENT_XRV_TRAINING_REQUIREMENT_REMOVED_CANNOT_MODIFY(
          trainingDAO.get(getDtls().trainingID).getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    ValidationHelper.failIfErrorsExist();
    try {
      // validates the Training Requirement details.
      validateTrainingRequirementDetails();
    } catch (AppException appException) {
      ValidationHelper.addValidationError(appException);
      ValidationHelper.failIfErrorsExist();
    }
    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify license training requirement event.
    modifyEventDispatcherFactory.get(LicenseTrainingRequirementModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Removes the Training Requirement from a License Type.The status is set to
   * 'Removed'.
   *
   * @param versionNo
   * The version number of the Training Requirement record to be
   * removed.
   *
   * @throws InformationalException
   * {@link curam.message.LICENSETRAININGREQUIREMENT#ERR_LICENSETRAININGREQUIREMENT_XRV_TRAINING_REQUIREMENT_ALREADY_REMOVED} -
   * If the Training Requirement is already removed from a License
   * Type.
   */
  public void remove(Integer versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre remove license training requirement event.
    removeEventDispatcherFactory.get(LicenseTrainingRequirementRemoveEvents.class).preRemove(
      this, versionNo);
    // END, CR00235789

    // If the Training Requirement is already removed.
    if (getLifecycleState().equals(TrainingRequirementStatusEntry.REMOVED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSETRAININGREQUIREMENTExceptionCreator.ERR_LICENSETRAININGREQUIREMENT_XRV_TRAINING_REQUIREMENT_ALREADY_REMOVED(
          trainingDAO.get(getDtls().trainingID).getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Set the record status to 'Removed'.
    setRecordStatus(TrainingRequirementStatusEntry.REMOVED);
    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post remove license training requirement event.
    removeEventDispatcherFactory.get(LicenseTrainingRequirementRemoveEvents.class).postRemove(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Gets the training requirement status.
   *
   * @return The training requirement status.
   */
  public TrainingRequirementStatusEntry getLifecycleState() {
    return TrainingRequirementStatusEntry.get(getDtls().status);
  }

  /**
   * Checks for the duplicate Training Requirement for a License Type.
   *
   * @throws AppException
   * Generic Exception Signature.
   *
   * @throws InformationalException
   * {@link curam.message.LICENSETRAININGREQUIREMENT#ERR_LICENSETRAININGREQUIREMENT_XRV_TRAINING_REQUIREMENT_ALL_READY_EXIST}
   * -If the Training Requirement already exists for a License Type.
   */
  // BEGIN, CR00177241, PM
  protected void validateTrainingRequirementDetails() throws AppException,
      // END, CR00177241
      InformationalException {

    if (getTraining().getID() != getRowManager().getOriginalDtls().trainingID) {

      // License Training Requirement object
      curam.cpm.sl.entity.intf.LicenseTrainingRequirement licenseTrainingRequirement = curam.cpm.sl.entity.fact.LicenseTrainingRequirementFactory.newInstance();

      // search key
      curam.cpm.sl.entity.struct.SearchByTrainingLicenseTypeKey key = new SearchByTrainingLicenseTypeKey();

      key.trainingID = getTraining().getID();
      key.licenseType = getLicenseType().getCode();
      key.status = TrainingRequirementStatusEntry.ACTIVE.getCode();

      RecordCount recordCount = new RecordCount();

      // Gets the count of active Training Requirements for a License Type and
      // Training.
      recordCount = licenseTrainingRequirement.countTrainingRequirementByTrainingLicenseType(
        key);

      // If Training Requirement already exists for a License Type.
      if (recordCount.count > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          LICENSETRAININGREQUIREMENTExceptionCreator.ERR_LICENSETRAININGREQUIREMENT_XRV_TRAINING_REQUIREMENT_ALL_READY_EXIST(
            getTraining().getName()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  }

}
