/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;


// _____________________________________________________________________________
/**
 * Duration for which the provider is accredited by the accrediting
 * organization.
 *
 * Accreditations are given for a definite period of time. The providers get
 * re-accredited after expiry of the accreditation.
 */
@ImplementedBy(AccreditationPeriodImpl.class)
public interface AccreditationPeriod extends AccreditationPeriodAccessor, Insertable,
    DateRanged, OptimisticLockModifiable {

  // ___________________________________________________________________________
  /**
   * Gets the ProviderAccreditation associated with the AccreditationPeriod.
   *
   * @return ProviderAccreditation for the AccreditationPeriod.
   */
  ProviderAccreditation getProviderAccreditation();

  // ___________________________________________________________________________
  /**
   * Sets the ProviderAccreditation for the AccreditationPeriod.
   *
   * @param value
   * The ProviderAccreditation to be set.
   */
  void setProviderAccreditation(final ProviderAccreditation value);

  // ___________________________________________________________________________
  /**
   * Sets the date range for the AccreditationPeriod.
   *
   * @param value
   * The DateRange to be set.
   */
  void setDateRange(final DateRange value);

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the accreditation period events functionality surrounding the
   * insert method.
   */
  public interface AccreditationPeriodInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.AccreditationPeriod#insert}
     *
     * @param accreditationPeriod
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(AccreditationPeriodAccessor accreditationPeriod)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.AccreditationPeriod#insert}
     *
     * @param accreditationPeriod
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(AccreditationPeriodAccessor accreditationPeriod)
      throws InformationalException;
  }


  /**
   * Interface to the accreditation period events functionality surrounding the
   * modify method.
   */
  public interface AccreditationPeriodModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.AccreditationPeriod#modify}
     *
     * @param accreditationPeriod
     * The object instance as it was before the main body of the modify
     * method.
     *
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(AccreditationPeriodAccessor accreditationPeriod)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.AccreditationPeriod#modify}
     *
     * @param accreditationPeriod
     * The object instance as it was after the main body of the modify
     * method.
     *
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(AccreditationPeriodAccessor accreditationPeriod)
      throws InformationalException;
  }
  // END, CR00144381

}
