/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.serviceoffering.impl.ServiceOffering;
import curam.util.persistence.Insertable;


/**
 * Interface for associating a concern role communication to provider offering.
 *
 */
@ImplementedBy(CommunicationPOLinkImpl.class)
public interface CommunicationPOLink extends Insertable,
    CommunicationPOLinkAccessor {

  /**
   * Gets the service offering associated with communication.
   *
   * @return The service offering associated with communication.
   */
  ServiceOffering getServiceOffering();

  /**
   * Sets the service offering associated with communication
   *
   * @param serviceOffering
   * Service offering associated with communication.
   */
  void setServiceOffering(final ServiceOffering serviceOffering);

  /**
   * Sets the communication.
   *
   * @param communictionID
   */
  void setCommunicationID(final long communictionID);
}
