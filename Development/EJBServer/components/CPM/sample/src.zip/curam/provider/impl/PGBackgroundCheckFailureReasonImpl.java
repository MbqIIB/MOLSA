/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.Inject;
import curam.message.impl.BACKGROUNDCHECKExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.provider.BackgroundCheckResult;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.type.CodeTableItemIdentifier;


// BEGIN, CR00183213, SS
public class PGBackgroundCheckFailureReasonImpl extends BaseBackgroundCheckFailureReasonImpl implements
  PGBackgroundCheckFailureReason {
  // END, CR00183213

  @Inject
  protected ProviderGroupBackgroundCheckDAO providerGroupBackgroundCheckDAO;

  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected PGBackgroundCheckFailureReasonImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213


  /**
   * {@inheritDoc}
   */
  public ProviderGroupBackgroundCheck getProviderGroupBackgroundCheck() {
    final long providerGroupBackgroundCheckID = getDtls().providerBackgroundCheckID;

    return providerGroupBackgroundCheckID == 0
      ? null
      : providerGroupBackgroundCheckDAO.get(providerGroupBackgroundCheckID);
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {
    // get the Background check record
    final ProviderGroupBackgroundCheck providerGroupBackgroundCheck = providerGroupBackgroundCheckDAO.get(
      getDtls().providerBackgroundCheckID);

    // checking if the occurrence date is before the receipt date
    if (getDtls().occurrenceDate.after(
      providerGroupBackgroundCheck.getDateRange().end())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECKFAILUREREASON_FV_DATE_BEFORE_RECEIPT_DATE(
          getDtls().occurrenceDate,
          providerGroupBackgroundCheck.getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void modify(final Integer versionNo) throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderGroupSecurity(
      providerGroupBackgroundCheckDAO.get(getDtls().providerBackgroundCheckID).getProviderGroup());

    // if the status of the provider is closed
    if (providerGroupBackgroundCheckDAO.get(getDtls().providerBackgroundCheckID).getProviderGroup().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 60);
      ValidationHelper.failIfErrorsExist();
    }

    super.modify(versionNo);

  }

  /**
   * {@inheritDoc}
   */
  public void cancel(final int versionNo) throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderGroupSecurity(
      providerGroupBackgroundCheckDAO.get(getDtls().providerBackgroundCheckID).getProviderGroup());

    // if the status of the provider is closed
    if (providerGroupBackgroundCheckDAO.get(getDtls().providerBackgroundCheckID).getProviderGroup().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 62);
      ValidationHelper.failIfErrorsExist();
    }

    super.cancel(versionNo);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void insert() throws InformationalException {
    // perform a security check
    providerSecurity.checkProviderGroupSecurity(
      providerGroupBackgroundCheckDAO.get(getDtls().providerBackgroundCheckID).getProviderGroup());

    // if the status of the provider is closed
    if (providerGroupBackgroundCheckDAO.get(getDtls().providerBackgroundCheckID).getProviderGroup().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 61);
      ValidationHelper.failIfErrorsExist();
    }

    // get the Background check record
    final ProviderGroupBackgroundCheck providerGroupBackgroundCheck = providerGroupBackgroundCheckDAO.get(
      getDtls().providerBackgroundCheckID);

    if ((curam.provider.impl.BackgroundCheckResultEntry.PASS.getCode().equals(
      providerGroupBackgroundCheck.getResult().getCode()))
        || (curam.provider.impl.BackgroundCheckResultEntry.UNDERINVESTIGATION.getCode().equals(
          providerGroupBackgroundCheck.getResult().getCode()))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECKFAILUREREASON_XRV_FAILURE_REASON_CANNOT_ADDED_IF_RESULT_PASS_UNDER_INVESTIGATION(
          new CodeTableItemIdentifier(BackgroundCheckResult.TABLENAME,
          providerGroupBackgroundCheck.getResult().getCode())),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }
    super.insert();
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderGroupBackgroundCheck(
    ProviderGroupBackgroundCheck providerGroupBackgroundCheck) {
    getDtls().providerBackgroundCheckID = (providerGroupBackgroundCheck == null
      ? 0
      : providerGroupBackgroundCheck.getID());
  }
}
