/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.Inject;
import curam.codetable.CONCERNROLETYPE;
import curam.participant.impl.ConcernRoleDAO;


/**
 * This class handles the event raised for adding the concern role types.
 */
public class ConcernRoleGetConcreteReaderDAOsEventListener implements
  ConcernRoleDAO.ConcernRoleGetConcreteReaderDAOsEvent {

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /**
   * Event handler invoked in the main body of the getConcreteReaderDAOs method.
   * {@linkplain curam.participant.impl.ConcernRoleDAOImpl#get}
   *
   * @param concernRoleDAO
   * The object instance as it was before the main body of the get
   * method.
   */
  public void addConcreteReaderDAO(ConcernRoleDAO concernRoleDAO) {

    concernRoleDAO.addConcernRoleType(CONCERNROLETYPE.PROVIDER, providerDAO);
    concernRoleDAO.addConcernRoleType(CONCERNROLETYPE.PROVIDERGROUP,
      providerGroupDAO);
  }
}
