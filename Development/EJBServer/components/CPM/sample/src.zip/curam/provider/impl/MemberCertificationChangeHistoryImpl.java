/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.Inject;

import curam.certification.impl.Certification;
import curam.certification.impl.CertificationDAO;
import curam.codetable.impl.MEMBERCERTIFICATIONSTATUSEntry;
import curam.cpm.sl.struct.MemberCertChangeHistoryDtls;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.Date;
import curam.util.type.DateTime;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.MemberCertificationChangeHistory}.
 */
// BEGIN, CR00183213, SS
public class MemberCertificationChangeHistoryImpl extends SingleTableLogicallyDeleteableEntityImpl<MemberCertChangeHistoryDtls>
  implements MemberCertificationChangeHistory {
  // END, CR00183213
  /**
   * Certification DAO
   */
  @Inject
  CertificationDAO certificationDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected MemberCertificationChangeHistoryImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213
  /**
   * {@inheritDoc}
   */
  public Certification getCertification() {

    final long certificationID = getDtls().certificationID;

    return certificationID == 0 ? null : certificationDAO.get(certificationID);
  }

  /**
   * {@inheritDoc}
   */
  public Date getDateOfExpiry() {

    return getDtls().dateOfExpiry;
  }

  /**
   * {@inheritDoc}
   */
  public Date getDateOfIssue() {

    return getDtls().dateOfIssue;
  }

  /**
   * {@inheritDoc}
   */
  public DateTime getDateTime() {

    return getDtls().dateTime;
  }

  /**
   * {@inheritDoc}
   */
  public String getUserName() {

    return getDtls().userName;
  }

  /**
   * {@inheritDoc}
   */
  public void setCertification(final Certification certification) {

    if (certification != null) {
      getDtls().certificationID = certification.getID();
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setDateOfExpiry(Date dateOfExpiry) {

    getDtls().dateOfExpiry = dateOfExpiry;
  }

  /**
   * {@inheritDoc}
   */
  public void setDateOfIssue(Date dateOfIssue) {

    getDtls().dateOfIssue = dateOfIssue;
  }

  /**
   * {@inheritDoc}
   */
  public void setDateTime(DateTime dateTime) {

    getDtls().dateTime = dateTime;
  }

  /**
   * {@inheritDoc}
   */
  public void setPartyconcernRoleID(long partyconcernRoleID) {

    getDtls().partyConcernRoleID = partyconcernRoleID;

  }

  /**
   * {@inheritDoc}
   */
  public void setUserName(final String userName) {

    getDtls().userName = userName;
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No such validations required currently
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No such validations required currently
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// No such validations required currently
  }

  /**
   * {@inheritDoc}
   */
  public long getMemberCertificationID() {

    return getDtls().memberCertificationID;
  }

  /**
   * {@inheritDoc}
   */

  public void setMemberCertificationID(long memberCertificationID) {

    getDtls().memberCertificationID = memberCertificationID;
  }

  // BEGIN CR00128529, KK
  /**
   * {@inheritDoc}
   */
  public MEMBERCERTIFICATIONSTATUSEntry getDerivedStatus() {

    if (Date.getCurrentDate().after(getDateOfExpiry())) {
      return MEMBERCERTIFICATIONSTATUSEntry.EXPIRED;
    } else {
      return MEMBERCERTIFICATIONSTATUSEntry.ACTIVE;
    }
  }
  // END CR00128529
}
