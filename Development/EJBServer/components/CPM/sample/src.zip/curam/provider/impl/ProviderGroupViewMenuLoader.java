/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Map;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ConcernRoleKey;
import curam.util.persistence.GuiceWrapper;
import curam.util.tab.impl.DynamicMenuStateLoader;
import curam.util.tab.impl.MenuState;


/**
 * Loader class responsible for dynamically enabling action on provider group
 * view menu.
 */
public class ProviderGroupViewMenuLoader implements DynamicMenuStateLoader {

  /**
   * Reference to provider group DAO.
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /**
   * Constructor.
   */
  public ProviderGroupViewMenuLoader() {
    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public MenuState loadMenuState(MenuState menuState,
    Map<String, String> pageParameters, String[] idsToUpdate) {
    // configure menuState
    MenuState returnState = menuState;

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = new Long(
      pageParameters.get(CPMConstants.kParamProviderConcernRoleID));

    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      concernRoleKey.concernRoleID);

    Set<ProviderMember> providerGroupMemberSet = providerGroup.getProviderMembers();

    int countOfActiveProviderMembers = 0;

    for (ProviderMember providerMember : providerGroupMemberSet) {
      if (RECORDSTATUSEntry.NORMAL.equals(providerMember.getLifecycleState())
        && (providerMember.getDateRange().end().isZero()
          || providerMember.getDateRange().endsInFuture())) {
        countOfActiveProviderMembers++;
      }
    }

    if (0 == countOfActiveProviderMembers) {
      returnState.setVisible(true, CPMConstants.kNewManagedTrainingMenuID);
      returnState.setEnabled(false, CPMConstants.kNewManagedTrainingMenuID);

      returnState.setVisible(true, CPMConstants.kNonManagedTrainingMenuID);
      returnState.setEnabled(false, CPMConstants.kNonManagedTrainingMenuID);

    } else {
      returnState.setVisible(true, CPMConstants.kNewManagedTrainingMenuID);
      returnState.setEnabled(true, CPMConstants.kNewManagedTrainingMenuID);

      returnState.setVisible(true, CPMConstants.kNonManagedTrainingMenuID);
      returnState.setEnabled(true, CPMConstants.kNonManagedTrainingMenuID);

    }

    return returnState;

  }
}
