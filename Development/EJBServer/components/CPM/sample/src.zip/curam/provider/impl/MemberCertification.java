/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.certification.impl.Certification;
import curam.codetable.impl.MEMBERCERTIFICATIONSTATUSEntry;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.Date;


/**
 * The member certification manages the certification which are provided to the
 * provider, provider group and the unassigned user.
 */
@ImplementedBy(MemberCertificationImpl.class)
public interface MemberCertification extends MemberCertificationAccessor,
    Insertable, OptimisticLockModifiable, LogicallyDeleteable {

  // ___________________________________________________________________________
  /**
   * Gets the certification details for the member certification
   *
   * @return The certification details
   */
  Certification getCertification();

  // ___________________________________________________________________________
  /**
   * Sets the certificationID for the member certification.
   *
   * @param certification
   * contains instance of certification.
   */
  void setCertification(final Certification certification);

  // ___________________________________________________________________________
  /**
   * Sets the partyConcernRoleID for the member certification issued to
   * provider, provider member or unassigned provider member.
   *
   * @param partyconcernRoleID
   * contains the system identifier for the provider, provider member
   * or unassigned provider member.
   */
  void setPartyconcernRoleID(final long partyconcernRoleID);

  /**
   * Sets the date of expiry for the member certification based on the
   * certification validity period and date of issue.
   *
   * @param dateOfExpiry
   * contains the date of expiry.
   *
   * @see curam.provider.impl.MemberCertificationImpl#setDateOfExpiry(Date) The
   * default implementation -
   * curam.provider.impl.MemberCertificationImpl#setDateOfExpiry(Date)
   */
  void setDateOfExpiry(final Date dateOfExpiry);

  /**
   * Sets the date of issue for the member certification
   *
   * @param dateOfIssue
   * contains date of issue
   */
  void setDateOfIssue(final Date dateOfIssue);

  // ___________________________________________________________________________
  /**
   * Sets the comments for the member certification
   *
   * @param comments
   * contains comments
   */
  void setComments(final String comments);

  // BEGIN, CR00127684, NK
  // ___________________________________________________________________________
  /**
   * Checks Where a member certification date of issue has been modified & the
   * date of expiry is not updated, an informational message should display to
   * advise the user to consider updating the date of expiry.
   *
   * @param versionNo
   * Contains the versionNo of the record.
   *
   * @return List of informational message.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.MemberCertificationImpl#modifyCertification(Integer)
   * The default implementation -
   * curam.provider.impl.MemberCertificationImpl#modifyCertification(Integer)
   */
  InformationalMessageList modifyCertification(Integer versionNo)
    throws InformationalException;

  // END, CR00127684

  // BEGIN, CR00144381, CPM
  // ___________________________________________________________________________
  /**
   * Interface to the member certification events functionality surrounding the
   * modifyCertification method.
   */
  public interface MemberCertificationModifyCertificationEvents {

    /**
     * Event interface invoked before the main body of the modifyCertification
     * method.
     * {@linkplain curam.provider.impl.MemberCertification#modifyCertification}
     *
     * @param memberCertification
     * The object instance as it was before the main body of the
     * modifyCertification method.
     * @param versionNo
     * The parameter as passed to the modifyCertification method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModifyCertification(MemberCertificationAccessor memberCertification,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modifyCertification
     * method.
     * {@linkplain curam.provider.impl.MemberCertification#modifyCertification}
     *
     * @param memberCertification
     * The object instance as it was after the main body of the
     * modifyCertification method.
     * @param versionNo
     * The parameter as passed to the modifyCertification method.
     * @param returnValue
     * The return value updated by the Event Handler.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModifyCertification(
      MemberCertificationAccessor memberCertification, Integer versionNo,
      InformationalMessageList returnValue) throws InformationalException;
  }


  // ___________________________________________________________________________
  /**
   * Interface to the member certification events functionality surrounding the
   * insert method.
   */
  public interface MemberCertificationInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.MemberCertification#insert}
     *
     * @param memberCertification
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(MemberCertificationAccessor memberCertification)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.MemberCertification#insert}
     *
     * @param memberCertification
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(MemberCertificationAccessor memberCertification)
      throws InformationalException;
  }


  // ___________________________________________________________________________
  /**
   * Interface to the member certification events functionality surrounding the
   * modify method.
   */
  public interface MemberCertificationModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.MemberCertification#modify}
     *
     * @param memberCertification
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(MemberCertificationAccessor memberCertification,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.MemberCertification#modify}
     *
     * @param memberCertification
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(MemberCertificationAccessor memberCertification,
      Integer versionNo) throws InformationalException;
  }


  // ___________________________________________________________________________
  /**
   * Interface to the member certification events functionality surrounding the
   * cancel method.
   */
  public interface MemberCertificationCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.provider.impl.MemberCertification#cancel}
     *
     * @param memberCertification
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(MemberCertificationAccessor memberCertification, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.provider.impl.MemberCertification#cancel}
     *
     * @param memberCertification
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(MemberCertificationAccessor memberCertification,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the member certification events functionality surrounding the
   * get derived status method.
   */
  public interface MemberCertificationGetDerivedStstusEvents {

    /**
     * Event interface invoked before the main body of the get derived status
     * method.
     * {@linkplain curam.provider.impl.MemberCertification#getDerivedStstus}
     *
     * @param memberCertification
     * The object instance as it was before the main body of the get
     * derived status method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preGetDerivedStstus(MemberCertificationAccessor memberCertification);

    /**
     * Event interface invoked after the main body of the get derived status
     * method.
     * {@linkplain curam.provider.impl.MemberCertification#getDerivedStstus}
     *
     * @param memberCertification
     * The object instance as it was after the main body of the get
     * derived status method.
     * @param returnValue
     * The return value updated by the Event Handler.
     */
    public void postGetDerivedStstus(MemberCertificationAccessor memberCertification,
      MEMBERCERTIFICATIONSTATUSEntry returnValue);
  }
  // END, CR00144381
}
