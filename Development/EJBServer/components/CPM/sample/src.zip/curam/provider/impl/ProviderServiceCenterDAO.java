/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.taxonomy.sl.search.struct.POServiceKey;
import curam.taxonomy.sl.search.struct.ServiceCenterDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;


/**
 * Data access for
 * {@linkplain curam.provider.impl.ProviderServiceCenter}.
 */
@ImplementedBy(ProviderServiceCenterDAOImpl.class)
public interface ProviderServiceCenterDAO extends
    StandardDAO<ProviderServiceCenter> {

  // ___________________________________________________________________________
  /**
   * Searches for all the Service Centers for a specific Provider.
   *
   * @param provider
   * for whom the service centers are to be searched for.
   * @return Set<ProviderServiceCenter> the service centers for the provider
   * specified.
   */
  Set<ProviderServiceCenter> searchBy(final Provider provider);

  // BEGIN, CR00208260, VR
  /**
   * Retrieves Service center details for a provider offering.
   *
   * @param poServiceKey
   * search criteria for fetching provider details along with provider
   * service details.
   *
   * @return List of the service center details.
   *
   * @throws InformationalException
   * - Generic Informational Exception
   * @throws AppException
   * - Generic Application Exception
   */
  
  ServiceCenterDetailsList searchByProviderOffering(
    final POServiceKey poServiceKey) throws AppException,
      InformationalException;
  // END, CR00208260
}
