/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.Inject;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.message.impl.BACKGROUNDCHECKExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.LifecycleHelper;
import curam.util.persistence.ValidationHelper;
import java.util.Set;


// BEGIN, CR00183213, SS
public class ProviderGroupBackgroundCheckImpl extends BackgroundCheckImpl
  implements ProviderGroupBackgroundCheck {
  // END, CR00183213

  /**
   * Injecting the Data Access Object for Provider Group
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /**
   * Injecting the Data Access Object for Provider Security
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * Injecting the Data Access Object for Background Check Failure Reason
   */
  @Inject
  protected PGBackgroundCheckFailureReasonDAO pgBackgroundCheckFailureReasonDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderGroupBackgroundCheckImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213

  /**
   * {@inheritDoc}
   */
  public ProviderGroup getProviderGroup() {
    final long id = getDtls().providerConcernRoleID;

    return id == 0 ? null : providerGroupDAO.get(id);
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderGroup(ProviderGroup value) {
    getDtls().providerConcernRoleID = value.getID();

  }

  /**
   * {@inheritDoc}
   */
  public Set<PGBackgroundCheckFailureReason> getProviderGroupBackgroundCheckFailureReasons() {

    return pgBackgroundCheckFailureReasonDAO.searchBy(this);
  }

  /**
   * Validates and inserts provider group background check.
   *
   * @throws InformationalException
   * {@link PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   */
  @Override
  public void insert() throws InformationalException {
    // perform a security check
    providerSecurity.checkProviderGroupSecurity(getProviderGroup());

    // if the status of the provider is closed
    if (getProviderGroup().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 58);
      ValidationHelper.failIfErrorsExist();
    }
    super.insert();
  }

  /**
   * Validates and modifies provider group background check.
   *
   * @throws InformationalException
   * {@link PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   */
  @Override
  public void modify() throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderGroupSecurity(getProviderGroup());

    // if the status of the provider group is closed
    if (getProviderGroup().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 59);
      ValidationHelper.failIfErrorsExist();
    }

    super.modify();
  }

  /**
   * Cancels the Provider Group Background check record and all associated
   * 'Active' Provider Group Background check failure reason record.
   *
   * @param versionNo
   * Version number of Background check record.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void cancel(final int versionNo) throws InformationalException {
    // perform a security check
    providerSecurity.checkProviderGroupSecurity(getProviderGroup());

    // if the status of the provider is closed
    if (getProviderGroup().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 57);
      ValidationHelper.failIfErrorsExist();
    }

    super.cancel(versionNo);

    // BEGIN CR00121844, MST
    for (PGBackgroundCheckFailureReason pgBackgroundCheckFailureReason :
      getProviderGroupBackgroundCheckFailureReasons()) {

      // Delete all background check failure reasons associated with the
      // deleted background check, which have a status of 'Active'.
      if (pgBackgroundCheckFailureReason.getLifecycleState().equals(
        RECORDSTATUSEntry.NORMAL)) {

        pgBackgroundCheckFailureReason.cancel(
          pgBackgroundCheckFailureReason.getVersionNo());
      }
    }
    // END CR00121844

  }

  /**
   * {@inheritDoc}
   */
  public void setProviderMember(ProviderMember value) throws AppException,
      InformationalException {

    if (value.getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_XRV_PROVIDERMEMBER_NOT_ACTIVELY_ASSOCIATED_WITH_PROVIDER(
          value.getParty().getName(), getProviderGroup().getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }
    getDtls().providerPartyID = value.getID();

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void crossEntityValidation() {
    super.crossEntityValidation();

    // The Receipt Date may not be earlier than the Date of the active
    // background check failure reasons.
    if (getDateRange().isEnded()) {
      for (final PGBackgroundCheckFailureReason pgBackgroundCheckFailureReason : LifecycleHelper.filter(
        getProviderGroupBackgroundCheckFailureReasons(),
        RECORDSTATUSEntry.NORMAL)) {

        if (getDateRange().end().before(
          pgBackgroundCheckFailureReason.getOccurrenceDate())) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_XRV_RECEIPTDATE_CANNOT_EARLIER_ACTIVE_FILURE_REASON_DATE_EXIST(
              getDateRange().end(),
              pgBackgroundCheckFailureReason.getOccurrenceDate()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              1);

        }
      }
    }

    // Result Cannot be specified as 'Pass' if active background check
    // failure
    // reasons exist.
    if (this.getResult().equals(BackgroundCheckResultEntry.PASS)) {
      if (LifecycleHelper.filter(getProviderGroupBackgroundCheckFailureReasons(), RECORDSTATUSEntry.NORMAL).size()
        > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_XRV_RESULT_CANNOT_PASS_IF_ACTIVE_FILURE_REASON_EXISTS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      }
    }
  }

}
