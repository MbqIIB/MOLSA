/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.Singleton;

import curam.cpm.sl.entity.impl.ProviderCategoryPeriodAdapter;
import curam.cpm.sl.entity.struct.ProviderCategoryPeriodDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ProviderCategoryPeriodDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ProviderCategoryPeriodDAOImpl extends StandardDAOImpl<ProviderCategoryPeriod, ProviderCategoryPeriodDtls>
  implements ProviderCategoryPeriodDAO {
  // END, CR00183213
  /**
   * Adapter for Provider category period
   */
  protected static final ProviderCategoryPeriodAdapter adapter = new ProviderCategoryPeriodAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderCategoryPeriodDAOImpl() {
    // END, CR00183213
    super(adapter, ProviderCategoryPeriod.class);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderCategoryPeriod readPrimaryCategoryFor(Provider provider) {

    return getEntity(adapter.readByProviderAndPrimary(provider.getID(), true));

  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderCategoryPeriod> searchBy(Provider provider) {
    return newSet(adapter.searchByProvider(provider.getID()));
  }

  // BEGIN, CR00157611, SG
  /**
   * {@inheritDoc}
   */
  public Set<ProviderCategoryPeriod> searchByCategory(
    final ProviderCategoryNameEntry providerCategory) {

    return newSet(adapter.searchByCategory(providerCategory.getCode()));
  }
  // END, CR00157611
}
