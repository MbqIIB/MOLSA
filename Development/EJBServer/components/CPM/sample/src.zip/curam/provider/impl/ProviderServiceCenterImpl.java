/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.entity.impl.ProviderOfferingPlaceLimitAdapter;
import curam.cpm.sl.entity.impl.ProviderServiceCenterAdapter;
import curam.cpm.sl.entity.struct.ProviderServiceCenterDtls;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.message.impl.PROVIDERSERVICECENTERExceptionCreator;
import curam.message.impl.SERVICECENTERPROVIDEROFFERINGExceptionCreator;
import curam.participant.impl.PhoneNumber;
import curam.participant.impl.PhoneNumberDAO;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.LifecycleHelper;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.DateRange;
import curam.util.type.StringHelper;
import curam.workspaceservices.localization.impl.LocalizableText;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;


// BEGIN, CR00183213, SS
public class ProviderServiceCenterImpl extends SingleTableLogicallyDeleteableEntityImpl<ProviderServiceCenterDtls>
  implements ProviderServiceCenter {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderServiceCenterInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderServiceCenterCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderServiceCenterModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  @Inject
  protected ServiceCenterProviderOfferingDAO serviceCenterProviderOfferingDAO;

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected ProviderSecurity providerSecurity;

  @Inject
  protected PhoneNumberDAO phoneNumberDAO;

  // BEGIN, CR00178272, AK
  /**
   * Reference to localizable text handler DAO.
   */
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Reference to localizable text handler used for the attribute areas served
   * information.
   */
  protected LocalizableTextHandler areasServedInfoLocalizableText;

  /**
   * Reference to localizable text handler used for the attribute client
   * information.
   */
  protected LocalizableTextHandler clientInfoLocalizableText;
  // END, CR00178272


  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderServiceCenterImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public ProviderServiceCenter getProviderServiceCenter() {
    return this;
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  /**
   * Sets the comments for the provider service center.
   *
   * @param value
   * the comments for the provider service center.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_COMMENTS_ABOVE_MAXIMUM_LENGTH} -
   * If the comments exceed the limit for maximum number of characters
   * allowed. </li>
   * </ul>
   */
  public void setComments(String value) {
    getDtls().comments = StringHelper.trim(value);

    if (getComments().length()
      > ProviderOfferingPlaceLimitAdapter.kMaxLength_comments) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_COMMENTS_ABOVE_MAXIMUM_LENGTH(
          ProviderOfferingPlaceLimitAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }
  }

  /**
   * {@inheritDoc}
   */
  public String getName() {
    return getDtls().name;
  }

  /**
   * Sets the name of the Service Center.
   *
   * @param value
   * the name to be set for the service center.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERSERVICECENTER#ERR_PROVIDERSERVICECENTER_FV_NAME_ABOVE_MAXIMUM_LENGTH} -
   * If the name entered is too long. </li>
   * </ul>
   */
  public void setName(String value) {
    getDtls().name = value;

    if (getName().length() > ProviderServiceCenterAdapter.kMaxLength_name) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERSERVICECENTERExceptionCreator.ERR_PROVIDERSERVICECENTER_FV_NAME_ABOVE_MAXIMUM_LENGTH(
          ProviderServiceCenterAdapter.kMaxLength_name),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {
    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * {@inheritDoc}
   */
  public void setDateRange(DateRange value) {
    getDtls().startDate = value.start();
    getDtls().endDate = value.end();

    /*
     * field validation
     */
    value.validateRange();
    value.validateStarted();
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// none required
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// none required
  }

  /**
   * Validates that changes made to provider service center entity on the
   * database are consistent with other entities.
   *
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.SERVICECENTERPROVIDEROFFERING#ERR_SERVICECENTERPROVIDEROFFERING_XRV_SERVICE_CENTER_OFFERING_END_DATE_MUST_BE_ON_OR_BEFORE_SERVICE_CENTER_END_DATE} -
   * If the service center provider service end date is after the service
   * center end date. </li>
   * <ul>
   * <li>
   * {@link curam.message.SERVICECENTERPROVIDEROFFERING#ERR_SERVICECENTERPROVIDEROFFERING_XRV_SERVICE_CENTER_OFFERING_START_DATE_MUST_BE_ON_OR_AFTER_SERVICE_CENTER_START_DATE} -
   * If the service center provider service start date, is before the provider
   * service start date. </li>
   *
   */
  public void crossEntityValidation() {
    // retrieve all child service center provider offering records to
    // validate changes against
    Set<ServiceCenterProviderOffering> unModifiableServiceCenterProviderOfferings = getServiceCenterProviderOffering();
    Set<ServiceCenterProviderOffering> serviceCenterProviderOfferings = new HashSet<ServiceCenterProviderOffering>();

    serviceCenterProviderOfferings.addAll(
      unModifiableServiceCenterProviderOfferings);

    // only want to validate against active children
    Set<ServiceCenterProviderOffering> activeServiceCenterProviderOfferings = LifecycleHelper.filter(
      serviceCenterProviderOfferings, RECORDSTATUSEntry.NORMAL);

    for (ServiceCenterProviderOffering serviceCenterProviderOffering:
      activeServiceCenterProviderOfferings) {
      // validate changes to service center against each service center
      // provider offering record
      if (!getDtls().endDate.isZero()) {
        // child cannot end after service center end date
        if (getDtls().endDate.before(
          serviceCenterProviderOffering.getDateRange().end())) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            SERVICECENTERPROVIDEROFFERINGExceptionCreator.ERR_SERVICECENTERPROVIDEROFFERING_XRV_SERVICE_CENTER_OFFERING_END_DATE_MUST_BE_ON_OR_BEFORE_SERVICE_CENTER_END_DATE(
              serviceCenterProviderOffering.getDateRange().end(),
              getDtls().endDate),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }
      }

      // child cannot start before service center start date
      if (getDtls().startDate.after(
        serviceCenterProviderOffering.getDateRange().start())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          SERVICECENTERPROVIDEROFFERINGExceptionCreator.ERR_SERVICECENTERPROVIDEROFFERING_XRV_SERVICE_CENTER_OFFERING_START_DATE_MUST_BE_ON_OR_AFTER_SERVICE_CENTER_START_DATE(
            serviceCenterProviderOffering.getDateRange().start(),
            getDtls().startDate),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

    }
  }

  /**
   * {@inheritDoc}
   */
  public Provider getProvider() {
    final long id = getDtls().providerConcernRoleID;

    return id == 0 ? null : providerDAO.get(id);
  }

  /**
   * Sets the provider for the Service Center.
   *
   * @param provider
   * the provider to be set for the service center.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERSERVICECENTER#ERR_PROVIDERSERVICECENTER_FV_MODIFY_PROVIDER_ID} -
   * If the provider for the provider service center cannot be modified. </li>
   * </ul>
   */
  public void setProvider(Provider provider) {
    getDtls().providerConcernRoleID = provider.getID();

    if (getRowManager().isOnDatabase()
      && getDtls().providerConcernRoleID
        != getRowManager().getOriginalDtls().providerConcernRoleID) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERSERVICECENTERExceptionCreator.ERR_PROVIDERSERVICECENTER_FV_MODIFY_PROVIDER_ID(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    /*
     * lock the service center whilst the service center offering being
     * manipulated
     */
    getTransactionHelper().lock(provider);

  }

  /**
   * {@inheritDoc}
   */
  public Set<ServiceCenterProviderOffering> getServiceCenterProviderOffering() {

    return Collections.unmodifiableSet(
      serviceCenterProviderOfferingDAO.searchByProviderServiceCenter(this));
  }

  /**
   * {@inheritDoc}
   */
  public long getWebAddressID() {
    return getDtls().webAddressID;
  }

  /**
   * {@inheritDoc}
   */
  public void setWebAddressID(long id) {
    getDtls().webAddressID = id;
  }

  /**
   * {@inheritDoc}
   */
  public long getEmailAddressID() {
    return getDtls().emailAddressID;
  }

  /**
   * {@inheritDoc}
   */
  public void setEmailAddressID(long id) {
    getDtls().emailAddressID = id;
  }

  /**
   * {@inheritDoc}
   */
  public long getAddressID() {
    return getDtls().addressID;
  }

  /**
   * {@inheritDoc}
   */
  public void setAddressID(long id) {
    getDtls().addressID = id;
  }

  /**
   * {@inheritDoc}
   */
  public PhoneNumber getPhoneNumber() {
    final long phoneNumberID = getDtls().phoneNumberID;

    return phoneNumberID == 0 ? null : phoneNumberDAO.get(phoneNumberID);
  }

  /**
   * {@inheritDoc}
   */
  public void setPhoneNumber(PhoneNumber value) {
    getDtls().phoneNumberID = value == null ? 0 : value.getID();
  }

  /*
   * Overridden methods -Insert -Modify -Cancel
   */

  /**
   * Overrides the insert method. Performs security checks.
   *
   * @throws InformationalException
   *
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   *
   * <ul>
   * <li>
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. </li>
   */
  @Override
  public void insert() throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre insert provider service center event.
    insertEventDispatcherFactory.get(ProviderServiceCenterInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 26);
      ValidationHelper.failIfErrorsExist();
    }

    // BEGIN, CR00178272, AK
    // Store any localizable text changes before updating the parent.
    storeLocalizableText();
    // END, CR00178272

    // Call insert
    super.insert();
    // BEGIN, CR00235789, AK
    // Raise the post insert provider service center event.
    insertEventDispatcherFactory.get(ProviderServiceCenterInsertEvents.class).postInsert(
      this);
    // END, CR00235789

  }

  /**
   * Overrides the modify method. Performs security checks.
   *
   * @param versionNo
   * version number
   * @throws InformationalException
   *
   * It adds the following informational exceptions to the
   * validation helper when validation fails.
   *
   * <ul>
   * <li>
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. </li>
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre modify provider service center event.
    modifyEventDispatcherFactory.get(ProviderServiceCenterModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 27);
      ValidationHelper.failIfErrorsExist();
    }

    // BEGIN, CR00178272, AK
    // Store any localizable text changes before updating the parent.
    storeLocalizableText();
    // END, CR00178272

    // call modify
    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify provider service center event.
    modifyEventDispatcherFactory.get(ProviderServiceCenterModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Overrides the cancel method. Performs security checks.
   *
   * @param versionNo
   * version number
   * @throws InformationalException
   *
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   *
   * <ul>
   * <li>
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. </li>
   */
  @Override
  public void cancel(int versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre cancel provider service center event.
    cancelEventDispatcherFactory.get(ProviderServiceCenterCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 28);
      ValidationHelper.failIfErrorsExist();
    }

    // call cancel
    super.cancel(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post cancel provider service center event.
    cancelEventDispatcherFactory.get(ProviderServiceCenterCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789

  }

  // BEGIN, CR00178272, AK
  /**
   * {@inheritDoc}
   */
  public LocalizableText getAreasServedInfo() {
    if (null == areasServedInfoLocalizableText) {
      areasServedInfoLocalizableText = localizableTextHandlerDAO.get(
        getDtls().areasSvdInfoTxtID);
    }
    return areasServedInfoLocalizableText;
  }

  /**
   * {@inheritDoc}
   */
  public LocalizableText getClientInfo() {
    if (null == clientInfoLocalizableText) {
      clientInfoLocalizableText = localizableTextHandlerDAO.get(
        getDtls().clientInfoTextID);
    }
    return clientInfoLocalizableText;
  }

  /**
   * {@inheritDoc}
   */
  public long getAreasServedInfoTextID() {
    return getDtls().areasSvdInfoTxtID;
  }

  /**
   * {@inheritDoc}
   */
  public long getClientInfoTextID() {
    return getDtls().clientInfoTextID;
  }

  /**
   * {@inheritDoc}
   */
  public void setAreasServedInfoTextID(long value) {
    getDtls().areasSvdInfoTxtID = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setClientInfoTextID(long value) {
    getDtls().clientInfoTextID = value;
  }

  /**
   * Stores any LocalizableText records associated with the provider service
   * center.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void storeLocalizableText() throws InformationalException {
    // Only store the details if there are changes waiting to be written.
    if (areasServedInfoLocalizableText != null) {
      getDtls().areasSvdInfoTxtID = areasServedInfoLocalizableText.store();
    }

    if (clientInfoLocalizableText != null) {
      getDtls().clientInfoTextID = clientInfoLocalizableText.store();
    }
  }
  // END, CR00178272

}
