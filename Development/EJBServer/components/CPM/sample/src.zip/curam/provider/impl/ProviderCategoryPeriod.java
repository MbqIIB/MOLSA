/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;

import java.util.Set;


/**
 * The general classification for that provider.
 *
 * For example, a provider who provides a foster care service may have a
 * provider category of Foster Care.
 */

@ImplementedBy(ProviderCategoryPeriodImpl.class)
public interface ProviderCategoryPeriod extends ProviderCategoryPeriodAccessor,
    Insertable, LogicallyDeleteable, DateRanged, Commented,
    OptimisticLockModifiable {

  /**
   * Gets the provider associated with this category period.
   *
   * @return The provider associated with this category period.
   */
  Provider getProvider();

  /**
   * Sets the provider associated with this category period.
   *
   * @param value
   * The provider associated with the category period.
   */
  void setProvider(final Provider value);

  /**
   * Gets the provider types for this provider category period.
   *
   * @return The provider types for this provider category period.
   */
  Set<ProviderType> getProviderTypes();

  /**
   * Sets the start and end date for this provider category period.
   *
   * @param value
   * The "lifetime" of the provider category period. This category
   * cannot be offered to clients outside of the date range.
   *
   * @see curam.provider.impl.ProviderCategoryPeriodImpl#setDateRange(DateRange)
   * The default implementation -
   * curam.provider.impl.ProviderCategoryPeriodImpl#setDateRange(DateRange)
   */
  void setDateRange(final DateRange value);

  /**
   * Sets the general classification for this provider e.g. Housing Facility,
   * Child Care Facility, Medical Practitioner, Kinship Care.
   *
   * @param value
   * The general classification for this provider e.g. Housing
   * Facility, Child Care Facility, Medical Practitioner, Kinship Care.
   */
  void setCategory(final ProviderCategoryNameEntry value);

  /**
   * Sets the primary category indicator which indicates whether this category
   * is the primary category for the provider or not.
   *
   * @param value
   * The primary category indicator.
   */
  void setPrimary(final boolean value);

  /**
   * Sets the reason why this category has been ended for the provider.
   *
   * @param value
   * The reason why this category has been ended.
   */
  void setEndReason(final String value);

  /**
   * Creates a new Provider Category Period after validating the entered details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderCategoryPeriodImpl#insertProviderCategoryPeriod()
   * The default implementation -
   * curam.provider.impl.ProviderCategoryPeriodImpl#insertProviderCategoryPeriod()
   */
  void insertProviderCategoryPeriod() throws AppException,
      InformationalException;

  /**
   * Modifies the existing Provider Category Period after validating the entered details.
   *
   * @param providerCategoryPeriod
   * The primary ProviderCategoryPeriod.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderCategoryPeriodImpl#modifyProviderCategoryPeriod(ProviderCategoryPeriod)
   * The default implementation -
   * curam.provider.impl.ProviderCategoryPeriodImpl#modifyProviderCategoryPeriod(ProviderCategoryPeriod)
   */
  void modifyProviderCategoryPeriod(
    ProviderCategoryPeriod providerCategoryPeriod) throws AppException,
      InformationalException;

  /**
   * Sets the provider enquiry for this category period.
   *
   * @param value
   * The provider enquiry to be set.
   */
  void setProviderEnquiry(final ProviderEnquiry value);

  /**
   * Removes the existing primary Provider Category for a provider.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  void removeAsPrimaryProviderCategory() throws AppException,
      InformationalException;

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider category period events functionality surrounding
   * the insertProviderCategoryPeriod method.
   */
  public interface ProviderCategoryPeriodInsertProviderCategoryPeriodEvents {

    /**
     * Event interface invoked before the main body of the
     * insertProviderCategoryPeriod method.
     * {@linkplain curam.provider.impl.ProviderCategoryPeriod#insertProviderCategoryPeriod}
     *
     * @param providerCategoryPeriod
     * The object instance as it was before the main body of the
     * insertProviderCategoryPeriod method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void preInsertProviderCategoryPeriod(
      ProviderCategoryPeriodAccessor providerCategoryPeriod)
      throws AppException, InformationalException;

    /**
     * Event interface invoked after the main body of the
     * insertProviderCategoryPeriod method.
     * {@linkplain curam.provider.impl.ProviderCategoryPeriod#insertProviderCategoryPeriod}
     *
     * @param providerCategoryPeriod
     * The object instance as it was after the main body of the
     * insertProviderCategoryPeriod method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void postInsertProviderCategoryPeriod(
      ProviderCategoryPeriodAccessor providerCategoryPeriod)
      throws AppException, InformationalException;
  }


  /**
   * Interface to the provider category period events functionality surrounding
   * the modifyProviderCategoryPeriod method.
   */
  public interface ProviderCategoryPeriodModifyProviderCategoryPeriodEvents {

    /**
     * Event interface invoked before the main body of the
     * modifyProviderCategoryPeriod method.
     * {@linkplain curam.provider.impl.ProviderCategoryPeriod#modifyProviderCategoryPeriod}
     *
     * @param providerCategoryPeriod
     * The object instance as it was before the main body of the
     * modifyProviderCategoryPeriod method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void preModifyProviderCategoryPeriod(
      ProviderCategoryPeriodAccessor providerCategoryPeriod)
      throws AppException, InformationalException;

    /**
     * Event interface invoked after the main body of the
     * modifyProviderCategoryPeriod method.
     * {@linkplain curam.provider.impl.ProviderCategoryPeriod#modifyProviderCategoryPeriod}
     *
     * @param providerCategoryPeriod
     * The object instance as it was after the main body of the
     * modifyProviderCategoryPeriod method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void postModifyProviderCategoryPeriod(
      ProviderCategoryPeriodAccessor providerCategoryPeriod)
      throws AppException, InformationalException;
  }


  /**
   * Interface to the provider category period events functionality surrounding
   * the removeAsPrimaryProviderCategory method.
   */
  public interface ProviderCategoryPeriodRemoveAsPrimaryProviderCategoryEvents {

    /**
     * Event interface invoked before the main body of the
     * removeAsPrimaryProviderCategory method.
     * {@linkplain curam.provider.impl.ProviderCategoryPeriod#removeAsPrimaryProviderCategory}
     *
     * @param providerCategoryPeriod
     * The object instance as it was before the main body of the
     * removeAsPrimaryProviderCategory method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void preRemoveAsPrimaryProviderCategory(
      ProviderCategoryPeriodAccessor providerCategoryPeriod)
      throws AppException, InformationalException;

    /**
     * Event interface invoked after the main body of the
     * removeAsPrimaryProviderCategory method.
     * {@linkplain curam.provider.impl.ProviderCategoryPeriod#removeAsPrimaryProviderCategory}
     *
     * @param providerCategoryPeriod
     * The object instance as it was after the main body of the
     * removeAsPrimaryProviderCategory method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void postRemoveAsPrimaryProviderCategory(
      ProviderCategoryPeriodAccessor providerCategoryPeriod)
      throws AppException, InformationalException;
  }


  /**
   * Interface to the provider category period events functionality surrounding
   * the insert method.
   */
  public interface ProviderCategoryPeriodInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderCategoryPeriod#insert}
     *
     * @param providerCategoryPeriod
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ProviderCategoryPeriodAccessor providerCategoryPeriod)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderCategoryPeriod#insert}
     *
     * @param providerCategoryPeriod
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ProviderCategoryPeriodAccessor providerCategoryPeriod)
      throws InformationalException;
  }


  /**
   * Interface to the provider category period events functionality surrounding
   * the cancel method.
   */
  public interface ProviderCategoryPeriodCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderCategoryPeriod#cancel}
     *
     * @param providerCategoryPeriod
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(
      ProviderCategoryPeriodAccessor providerCategoryPeriod, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderCategoryPeriod#cancel}
     *
     * @param providerCategoryPeriod
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(
      ProviderCategoryPeriodAccessor providerCategoryPeriod, int versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the provider category period events functionality surrounding
   * the modify method.
   */
  public interface ProviderCategoryPeriodModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderCategoryPeriod#modify}
     *
     * @param providerCategoryPeriod
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(
      ProviderCategoryPeriodAccessor providerCategoryPeriod, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderCategoryPeriod#modify}
     *
     * @param providerCategoryPeriod
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(
      ProviderCategoryPeriodAccessor providerCategoryPeriod, Integer versionNo)
      throws InformationalException;
  }
  // END, CR00144381
}
