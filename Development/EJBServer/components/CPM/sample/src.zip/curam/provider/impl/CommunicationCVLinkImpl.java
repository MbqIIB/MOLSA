/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.Inject;

import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.ContractVersionDAO;
import curam.cpm.sl.struct.CommunicationCVLinkDtls;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.CommunicationCVLink}.
 */
public class CommunicationCVLinkImpl extends SingleTableEntityImpl<CommunicationCVLinkDtls> implements
  CommunicationCVLink {

  /**
   * Reference to contract version DAO.
   */
  @Inject
  protected ContractVersionDAO contractVersionDAO;

  /**
   * Constructor for the class.
   */
  protected CommunicationCVLinkImpl() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public ContractVersion getContractVersion() {
    if (0 != getDtls().contractVersionID) {
      return contractVersionDAO.get(getDtls().contractVersionID);
    }
    return null;
  }

  /**
   * {@inheritDoc}
   */
  public void setContractVersion(final ContractVersion contractVersion) {
    getDtls().contractVersionID = contractVersion.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void setCommunicationID(final long communictionID) {
    getDtls().communicationID = communictionID;
  }
	
  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No validation required.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No validation required.
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// No validation required.
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// No new instance defaults.
  }
}
