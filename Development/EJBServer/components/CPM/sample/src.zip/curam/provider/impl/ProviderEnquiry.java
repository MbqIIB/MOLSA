/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.COMMUNICATIONMETHODEntry;
import curam.codetable.impl.LANGUAGEEntry;
import curam.core.struct.AddressDtls;
import curam.core.struct.PhoneNumberDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Named;
import curam.util.type.DateTime;


/**
 * Details of an enquiry made by a potential provider requesting information
 * about providing services on behalf of the organization.
 *
 * For example John's Day Care asks for some further information on what being a
 * provider for the organization entails, the resource manager records the
 * enquiry and sends him the information requested.
 */

@ImplementedBy(ProviderEnquiryImpl.class)
public interface ProviderEnquiry extends ProviderEnquiryAccessor, Insertable,
    Named, OptimisticLockModifiable {

  /**
   * Sets the additional name for this provider enquiry. Where the interested
   * party is a couple the name of the other person in the couple.
   *
   * @param name
   * the additional name for this provider enquiry.
   *
   * @see curam.provider.impl.ProviderEnquiryImpl#setAdditionalName(String) The default
   * implementation -
   * {@link curam.provider.impl.ProviderEnquiryImpl#setAdditionalName(String)}.          
   */
  void setAdditionalName(String name);

  /**
   * Sets the preferred information or training session that this provider
   * enquiry would like to attend.
   *
   * @param prefSession
   * the preferred information or training session.
   *
   * @see curam.provider.impl.ProviderEnquiryImpl#setPreferredSession(String) The default
   * implementation -
   * {@link curam.provider.impl.ProviderEnquiryImpl#setPreferredSession(String)}.          
   */
  void setPreferredSession(String prefSession);

  /**
   * Sets the reason that the provider made this enquiry to the organization
   * about becoming a provider.
   *
   * @param reason
   * the reason that the provider made this enquiry to the organization
   * about becoming a provider.
   */          
  void setReasonForEnquiry(String reason);

  /**
   * Sets whether the details of the scheduled meeting have been confirmed with
   * this enquiry about becoming a provider.
   *
   * @param value
   * whether the details of the scheduled meeting have been confirmed
   * with this enquiry about becoming a provider.
   */
  void setConfirmedMeetingDetails(boolean value);

  /**
   * Sets whether a meeting has been attended by the person for of this enquiry.
   *
   * @param value
   * whether a meeting has been attended.
   */
  void setAttendedMeeting(boolean value);

  /**
   * Sets the indicator whether the person of this enquiry has obtained an
   * application form when they attended the scheduled meeting.
   *
   * @param value
   * the indicator whether the person of this enquiry has obtained an
   * application form.
   */
  void setObtainedApplicationForm(boolean value);

  /**
   * Sets date and time of the meeting that this enquiry has been scheduled to
   * attend.
   *
   * @param value
   * date and time of the meeting that this enquiry has been scheduled
   * to attend.
   *
   * @see curam.provider.impl.ProviderEnquiryImpl#setScheduledMeeting(String) The default
   * implementation -
   * {@link curam.provider.impl.ProviderEnquiryImpl#setScheduledMeeting(String)}.          
   */
  void setScheduledMeeting(String value);

  /**
   * Sets the number of children currently in the household of the person of
   * this enquiry.
   *
   * @param value
   * the number of children currently in the household of the person of
   * this enquiry.
   *
   * @see curam.provider.impl.ProviderEnquiryImpl#setNumberOfChildren(short) The default
   * implementation -
   * {@link curam.provider.impl.ProviderEnquiryImpl#setNumberOfChildren(short)}.          
   */
  void setNumberOfChildren(short value);

  /**
   * Sets the details of when the organization can contact this provider.
   *
   * @param value
   * the details of when the organization can contact this provider.
   *
   * @see curam.provider.impl.ProviderEnquiryImpl#setAvailabilityForContact(String) The default
   * implementation -
   * {@link curam.provider.impl.ProviderEnquiryImpl#setAvailabilityForContact(String)}.          
   */
  void setAvailabilityForContact(String value);

  /**
   * Sets the additional information about this provider enquiry.
   *
   * @param value
   * the additional information about this provider enquiry.
   *
   * @see curam.provider.impl.ProviderEnquiryImpl#setAdditionalInformation(String) The default
   * implementation -
   * {@link curam.provider.impl.ProviderEnquiryImpl#setAdditionalInformation(String)}.
   */
  void setAdditionalInformation(String value);

  /**
   * Sets the additional information about this provider enquiry.
   *
   * @param value
   * the additional information about this provider enquiry.          
   */          
  void setReferenceNumber(String value);

  /**
   * Sets the additional information about this provider enquiry.
   *
   * @param value
   * the additional information about this provider enquiry.
   */
  void setOwnerName(String value);

  /**
   * Sets the home phone number for this provider enquiry.
   *
   * @param value
   * the home phone number for this provider enquiry.
   */
  void setHomePhoneNumberID(final long value);

  /**
   * Sets the work phone number for this provider enquiry.
   *
   * @param value
   * the work phone number for this provider enquiry.
   */
  void setWorkPhoneNumberID(final long value);

  /**
   * Sets the mobile phone number for this provider enquiry.
   *
   * @param value
   * the mobile phone number for this provider enquiry.
   */
  void setMobilePhoneNumberID(final long value);

  /**
   * Sets the work address for this provider enquiry.
   *
   * @param value
   * the work address for this provider enquiry.
   */
  void setWorkAddressID(final long value);

  /**
   * Sets the home address for this provider enquiry.
   *
   * @param value
   * the home address for this provider enquiry.
   */
  void setHomeAddressID(final long value);

  /**
   * Gets the immutable provider category period for this provider enquiry.
   *
   * @return The immutable provider category period.
   */
  ProviderCategoryPeriod getProviderCategoryPeriod();

  /**
   * Sets the provider category period for this provider enquiry.
   *
   * @param providerCategoryPeriod
   * the provider category period.
   */
  void setProviderCategoryPeriod(ProviderCategoryPeriod providerCategoryPeriod);

  /**
   * Sets the phone numbers and address details for this provider enquiry at the
   * time of provider enquiry creation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderEnquiryImpl#setProviderEnquiryDetails() The default
   * implementation -
   * {@link curam.provider.impl.ProviderEnquiryImpl#setProviderEnquiryDetails()}.
   */
  void setProviderEnquiryDetails() throws AppException, InformationalException;

  /**
   * Sets the phone numbers and address details for this provider enquiry at the
   * time of provider enquiry modification.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderEnquiryImpl#setProviderEnquiryUpdateDetails()
   * The default implementation -
   * {@link curam.provider.impl.ProviderEnquiryImpl#setProviderEnquiryUpdateDetails()}.
   */
  void setProviderEnquiryUpdateDetails() throws AppException,
      InformationalException;

  /**
   * Closes the enquiry by setting its End Date to the current business date and
   * updates the enquiry status.
   *
   * @param versionNo
   * version number to be closed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderEnquiryImpl#close(int)
   * The default implementation -
   * {@link curam.provider.impl.ProviderEnquiryImpl#close(int)}.
   */
  void close(int versionNo) throws InformationalException, AppException;

  /**
   * Sets the enquiry date for this provider enquiry.
   *
   * @param value
   * the provider enquiry date.
   *
   * @see curam.provider.impl.ProviderEnquiryImpl#setEnquiryDate(DateTime)
   * The default implementation -
   * {@link curam.provider.impl.ProviderEnquiryImpl#setEnquiryDate(DateTime)}.         
   */
  void setEnquiryDate(DateTime value);

  /**
   * Sets the home phone number details for this provider enquiry.
   *
   * @param value
   * the home phone number details for this provider enquiry.
   */
  void setHomePhoneNumberDtls(final PhoneNumberDtls value);

  /**
   * Sets the work phone number details for this provider enquiry.
   *
   * @param value
   * the work phone number details for this provider enquiry.
   */
  void setWorkPhoneNumberDtls(final PhoneNumberDtls value);

  /**
   * Sets the mobile phone number details for this provider enquiry.
   *
   * @param value
   * the mobile phone number details for this provider enquiry.
   */
  void setMobilePhoneNumberDtls(final PhoneNumberDtls value);

  /**
   * Sets the work address details for this provider enquiry.
   *
   * @param value
   * the work address details for this provider enquiry.
   */
  void setWorkAddressDtls(final AddressDtls value);

  /**
   * Sets the home address details for this provider enquiry.
   *
   * @param value
   * the home address details for this provider enquiry.
   */
  void setHomeAddressDtls(final AddressDtls value);

  // BEGIN, CR00100280, GYH

  /**
   * Sets the preferred language for provider enquiry.
   *
   * @param value
   * The preferred language of the provider enquiry.
   */
  void setPreferredLanguage(final LANGUAGEEntry value);

  /**
   * Sets the method of preferred communication for the provider enquiry.
   *
   *
   * @param value
   * The method of preferred communication for the provider enquiry.
   */
  void setPreferredCommunication(final COMMUNICATIONMETHODEntry value);
  
  // BEGIN, CR00095292, RPB
  /**
   * Sets the organization object link id. The organization object link id is
   * linked to an organization object (user,position,organization unit or work
   * queue) through the OrgObjectLink entity. The id provided here should
   * correspond to a valid entry in the OrgObjectLink entity. This would allow a
   * provider enquiry to be owned not only by users but also by other
   * organization objects such as work queue, position and organization unit.
   *
   * @param orgObjectLinkID
   * The organization object link id which corresponds to an
   * organization object in the OrgObjectLink entity.
   * @see ProviderEnquiryAccessor#getOwnerOrgObjectName() 
   * @see ProviderEnquiryAccessor#getOrgObjectLinkID()
   */
  void setOrgObjectLink(final long orgObjectLinkID);  
  
  // END, CR00095292

  // END, CR00100280

  // BEGIN, CR00097355, NRV

  /**
   * Closes the enquiry by setting its End Date to the current business date and
   * updates the enquiry status.
   *
   * @param versionNo
   * version number to be closed
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderEnquiryImpl#transferEnquiryToProvider(int)
   * The default implementation -
   * {@link curam.provider.impl.ProviderEnquiryImpl#transferEnquiryToProvider(int)}.         
   */
  void transferEnquiryToProvider(int versionNo) throws InformationalException,
      AppException;

  // END, CR00097355

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider enquiry events functionality surrounding the
   * close method.
   */
  public interface ProviderEnquiryCloseEvents {

    /**
     * Event interface invoked before the main body of the close method.
     * {@linkplain curam.provider.impl.ProviderEnquiry#close}
     *
     * @param providerEnquiry
     * The object instance as it was before the main body of the close
     * method.
     * @param versionNo
     * The parameter as passed to the close method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preClose(ProviderEnquiryAccessor providerEnquiry, int versionNo)
      throws InformationalException, AppException;

    /**
     * Event interface invoked after the main body of the close method.
     * {@linkplain curam.provider.impl.ProviderEnquiry#close}
     *
     * @param providerEnquiry
     * The object instance as it was after the main body of the close
     * method.
     * @param versionNo
     * The parameter as passed to the close method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postClose(ProviderEnquiryAccessor providerEnquiry, int versionNo)
      throws InformationalException, AppException;
  }


  /**
   * Interface to the provider enquiry events functionality surrounding the
   * transferEnquiryToProvider method.
   */
  public interface ProviderEnquiryTransferEnquiryToProviderEvents {

    /**
     * Event interface invoked before the main body of the
     * transferEnquiryToProvider method.
     * {@linkplain curam.provider.impl.ProviderEnquiry#transferEnquiryToProvider}
     *
     * @param providerEnquiry
     * The object instance as it was before the main body of the
     * transferEnquiryToProvider method.
     * @param versionNo
     * The parameter as passed to the transferEnquiryToProvider method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preTransferEnquiryToProvider(
      ProviderEnquiryAccessor providerEnquiry, int versionNo)
      throws InformationalException, AppException;

    /**
     * Event interface invoked after the main body of the
     * transferEnquiryToProvider method.
     * {@linkplain curam.provider.impl.ProviderEnquiry#transferEnquiryToProvider}
     *
     * @param providerEnquiry
     * The object instance as it was after the main body of the
     * transferEnquiryToProvider method.
     * @param versionNo
     * The parameter as passed to the transferEnquiryToProvider method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postTransferEnquiryToProvider(
      ProviderEnquiryAccessor providerEnquiry, int versionNo)
      throws InformationalException, AppException;
  }


  /**
   * Interface to the provider enquiry events functionality surrounding the
   * insert method.
   */
  public interface ProviderEnquiryInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderEnquiry#insert}
     *
     * @param providerEnquiry
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ProviderEnquiryAccessor providerEnquiry)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderEnquiry#insert}
     *
     * @param providerEnquiry
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ProviderEnquiryAccessor providerEnquiry)
      throws InformationalException;
  }


  /**
   * Interface to the provider enquiry events functionality surrounding the
   * modify method.
   */
  public interface ProviderEnquiryModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderEnquiry#modify}
     *
     * @param providerEnquiry
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(ProviderEnquiryAccessor providerEnquiry,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderEnquiry#modify}
     *
     * @param providerEnquiry
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(ProviderEnquiryAccessor providerEnquiry,
      Integer versionNo) throws InformationalException;
  }


  // END, CR00144381

  // BEGIN, CR00145043, CPM
  /**
   * Interface to the provider enquiry events functionality surrounding the set
   * provider enquiry details method.
   */
  public interface ProviderEnquirySetProviderEnquiryDetailsEvents {

    /**
     * Event interface invoked before the main body of the set provider enquiry
     * details method.
     * {@linkplain curam.provider.impl.ProviderEnquiry#setProviderEnquiryDetails}
     *
     * @param providerEnquiry
     * The object instance as it was before the set provider enquiry
     * details method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preSetProviderEnquiryDetails(
      ProviderEnquiryAccessor providerEnquiry) throws InformationalException;

    /**
     * Event interface invoked after the main body of the set provider enquiry
     * details method.
     * {@linkplain curam.provider.impl.ProviderEnquiry#setProviderEnquiryDetails}
     *
     * @param providerEnquiry
     * The object instance as it was after the main body of the set
     * provider enquiry details method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postSetProviderEnquiryDetails(
      ProviderEnquiryAccessor providerEnquiry) throws InformationalException;
  }


  /**
   * Interface to the provider enquiry events functionality surrounding the set
   * provider enquiry update details method.
   */
  public interface ProviderEnquirySetProviderEnquiryUpdateDetailsEvents {

    /**
     * Event interface invoked before the main body of the set provider enquiry
     * update details method.
     * {@linkplain curam.provider.impl.ProviderEnquiry#setProviderEnquiryUpdateDetails}
     *
     * @param providerEnquiry
     * The object instance as it was before the set provider enquiry
     * update details method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preSetProviderEnquiryUpdateDetails(
      ProviderEnquiryAccessor providerEnquiry) throws InformationalException;

    /**
     * Event interface invoked after the main body of the set provider enquiry
     * update details method.
     * {@linkplain curam.provider.impl.ProviderEnquiry#setProviderEnquiryUpdateDetails}
     *
     * @param providerEnquiry
     * The object instance as it was after the main body of the set
     * provider enquiry update details method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postSetProviderEnquiryUpdateDetails(
      ProviderEnquiryAccessor providerEnquiry) throws InformationalException;
  }


  /**
   * Interface to the provider enquiry events functionality surrounding the
   * external user check method.
   */
  public interface ProviderEnquiryIsExternalUserEvents {

    /**
     * Event interface invoked before the main body of the external user check
     * method. {@linkplain curam.provider.impl.ProviderEnquiry#isExternalUser}
     *
     * @param providerEnquiry
     * The object instance as it was before the external user check
     * method.
     * @param userName
     * The parameter as passed to the external user check method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preIsExternalUser(ProviderEnquiryAccessor providerEnquiry,
      String userName) throws InformationalException;

    /**
     * Event interface invoked after the main body of the external user check
     * method. {@linkplain curam.provider.impl.ProviderEnquiry#isExternalUser}
     *
     * @param providerEnquiry
     * The object instance as it was after the main body of the
     * external user check method.
     * @param userName
     * The parameter as passed to the external user check method.
     * @param isExternalUser
     * The parameter as passed to the external user check method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postIsExternalUser(ProviderEnquiryAccessor providerEnquiry,
      String userName, boolean isExternalUser) throws InformationalException;
  }
  // END, CR00145043
}
