/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;

import com.google.inject.Singleton;

import curam.cpm.sl.impl.LicenseRenewalAdapter;
import curam.cpm.sl.struct.LicenseRenewalDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.LicenseRenewalDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class LicenseRenewalDAOImpl extends StandardDAOImpl<LicenseRenewal, LicenseRenewalDtls> implements
  LicenseRenewalDAO {
  // END, CR00183213

  protected static final LicenseRenewalAdapter adapter = new LicenseRenewalAdapter();

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected LicenseRenewalDAOImpl() {
    // END, CR00183213
    super(adapter, LicenseRenewal.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<LicenseRenewal> searchByLicense(License license) {

    return newSet(adapter.searchByLicenseID(license.getID()));
  }
}
