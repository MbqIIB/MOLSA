/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.HashSet;
import java.util.Set;

import com.google.inject.Singleton;

import curam.cpm.sl.entity.impl.ProviderTypeAdapter;
import curam.cpm.sl.entity.struct.ProviderTypeDtls;
import curam.cpm.sl.entity.struct.ProviderTypeSearchResultsList;
import curam.cpm.sl.entity.struct.providerTypeSearchKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of {@linkplain curam.provider.impl.ProviderTypeDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ProviderTypeDAOImpl extends StandardDAOImpl<ProviderType, ProviderTypeDtls> implements ProviderTypeDAO {
  // END, CR00183213
  /**
   * Adapter for Provider type
   */
  protected static final ProviderTypeAdapter adapter = new ProviderTypeAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderTypeDAOImpl() {
    // END, CR00183213
    super(adapter, ProviderType.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderType> searchBy(
    ProviderCategoryPeriod providerCategoryPeriod) {

    // Change the operation name on model to searchByCategoryPeriod
    return newSet(
      adapter.searchProviderTypesByCategory(providerCategoryPeriod.getID()));
  }

  // BEGIN, CR00157611, SG
  /**
   * {@inheritDoc}
   */
  public Set<ProviderType> searchByType(ProviderTypeNameEntry providerType)
    throws AppException, InformationalException {

    curam.cpm.sl.entity.intf.ProviderType providerTypeObj = curam.cpm.sl.entity.fact.ProviderTypeFactory.newInstance();
    providerTypeSearchKey providerTypeSearchKey = new providerTypeSearchKey();

    providerTypeSearchKey.providerCategoryType = providerType.getCode();
    ProviderTypeSearchResultsList providerTypeSearchResultsList = providerTypeObj.searchProviderTypes(
      providerTypeSearchKey);

    Set<ProviderType> providerTypes = new HashSet<ProviderType>();

    for (int i = 0; i < providerTypeSearchResultsList.dtls.size(); i++) {
      providerTypes.add(
        get(providerTypeSearchResultsList.dtls.item(i).providerTypeID));
    }

    return providerTypes;
  }
  // END, CR00157611
}
