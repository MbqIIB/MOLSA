/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.List;

import com.google.inject.ImplementedBy;

import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.Lifecycle;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;


/**
 * A permit that a provider may be required to have in order to operate or to
 * deliver a certain service.
 * <p>
 * For example, a provider of foster care services may be required to have a
 * "State Foster Care License". A license may or may not be issued by the
 * organization itself.
 */
@ImplementedBy(LicenseImpl.class)
public interface License extends LicenseAccessor, Insertable,
    Lifecycle<LicenseStatusEntry>, Commented, DateRanged,
    OptimisticLockModifiable {

  /**
   * Gets the immutable provider on the license.
   *
   * @return Provider The immutable provider on the license.
   */
  public Provider getProvider();

  /**
   * Sets the issuer of the license.
   *
   * @param value
   * The issuer of the license.
   * @see curam.provider.impl.LicenseImpl#setIssuer(LicenseIssuerEntry) The
   * default implementation -
   * curam.provider.impl.LicenseImpl#setIssuer(LicenseIssuerEntry)
   */
  public void setIssuer(final LicenseIssuerEntry value);

  /**
   * Sets the number of the license for the provider.
   *
   * @param value
   * Contains the number of the license for the provider.
   * @see curam.provider.impl.LicenseImpl#setNumber(String) The default
   * implementation - curam.provider.impl.LicenseImpl#setNumber(String)
   */
  public void setNumber(final String value);

  /**
   * Sets the type of the license for the provider.
   *
   * @param value
   * Contains the type of the license for the provider.
   */
  public void setLicenseType(final LicenseTypeEntry value);

  /**
   * Sets the provider concern role ID on the license.
   *
   * @param value
   * The provider concern role ID on the license.
   */
  public void setProvider(final Provider value);

  /**
   * Sets the maximum places on the license.
   *
   * @param value
   * The maximum places on the license.
   *
   * @see curam.provider.impl.LicenseImpl#setMaximumPlaces(int) The default
   * implementation - curam.provider.impl.LicenseImpl#setMaximumPlaces(int)
   */
  public void setMaximumPlaces(final int value);

  /**
   * Sets whether this license has been renewed. Renewal indicator is
   * set to yes if the license is renewed and a new approved license
   * created. Otherwise the renewal indicator is set to no.
   *
   * @param value
   * Whether this license has been renewed.
   */
  public void setRenewed(final boolean value);

  /**
   * Sets the user who entered the license.
   *
   * @param value
   * Contains the user who entered the license
   */
  public void setUser(final String value);

  /**
   * Sets the "lifetime" of the license. This license cannot be used by clients
   * outside of the date range.
   *
   * @param value
   * Contains the "lifetime" of the license.
   * @see curam.provider.impl.LicenseImpl#setDateRange(DateRange) The default
   * implementation -
   * curam.provider.impl.LicenseImpl#setDateRange(DateRange)
   */
  public void setDateRange(final DateRange value);

  // BEGIN, CR00144284, SK
  /**
   * Suspends license of the provider.
   *
   * @param suspensionReason
   * The reason for suspension.
   * @param comments
   * The suspension comments.
   * @param versionNo
   * The version number as previously retrieved
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.LicenseImpl#suspend(LicenseSuspensionReasonEntry, String, int)
   * The default implementation -
   * curam.provider.impl.LicenseImpl#suspend(LicenseSuspensionReasonEntry, String, int)          
   */
  // END, CR00144284
  public void suspend(final LicenseSuspensionReasonEntry suspensionReason,
    final String comments, final int versionNo) throws InformationalException;

  // BEGIN, CR00144284, SK
  /**
   * Rejects license of the provider if the provider has failed
   * the background check.
   *
   * @param rejectionReason
   * The reason for rejection.
   * @param comments
   * The rejection comments.
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.LicenseImpl#reject(LicenseRejectionReasonEntry, String, int)
   * The default implementation -
   * curam.provider.impl.LicenseImpl#reject(LicenseRejectionReasonEntry, String, int)          
   */
  // END, CR00144284
  public void reject(final LicenseRejectionReasonEntry rejectionReason,
    final String comments, final int versionNo) throws InformationalException;

  // BEGIN, CR00144284, SK
  /**
   * Logically deletes the license for the provider.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.LicenseImpl#cancel(int)
   * The default implementation -
   * curam.provider.impl.LicenseImpl#cancel(int)          
   */
  // END, CR00144284
  public void cancel(final int versionNo) throws InformationalException;

  // BEGIN, CR00144284, SK
  /**
   * Approves license for the provider if the provider has passed
   * the background check.
   *
   * @param comments
   * The approval comments.
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.LicenseImpl#approve(String, int)
   * The default implementation -
   * curam.provider.impl.LicenseImpl#approve(String, int) 
   */
  // END, CR00144284
  public void approve(final String comments, final int versionNo)
    throws InformationalException;

  /**
   * Gets the immutable list of history of changes to the state of this
   * license, returned in ascending date/time order (i.e. earliest first).
   *
   * @return The immutable list of history of changes to the state of this
   * license.
   */
  public List<LicenseStatusHistory> getStatusHistory();

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the license events functionality surrounding the suspend
   * method.
   */
  public interface LicenseSuspendEvents {

    /**
     * Event interface invoked before the main body of the suspend method.
     * {@linkplain curam.provider.impl.License#suspend}
     *
     * @param license
     * The object instance as it was before the main body of the
     * suspend method.
     * @param suspensionReason
     * The parameter as passed to the suspend method.
     * @param comments
     * The parameter as passed to the suspend method.
     * @param versionNo
     * The parameter as passed to the suspend method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preSuspend(LicenseAccessor license,
      LicenseSuspensionReasonEntry suspensionReason, String comments,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the suspend method.
     * {@linkplain curam.provider.impl.License#suspend}
     *
     * @param license
     * The object instance as it was after the main body of the suspend
     * method.
     * @param suspensionReason
     * The parameter as passed to the suspend method.
     * @param comments
     * The parameter as passed to the suspend method.
     * @param versionNo
     * The parameter as passed to the suspend method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postSuspend(LicenseAccessor license,
      LicenseSuspensionReasonEntry suspensionReason, String comments,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the license events functionality surrounding the reject
   * method.
   */
  public interface LicenseRejectEvents {

    /**
     * Event interface invoked before the main body of the reject method.
     * {@linkplain curam.provider.impl.License#reject}
     *
     * @param license
     * The object instance as it was before the main body of the reject
     * method.
     * @param rejectionReason
     * The parameter as passed to the reject method.
     * @param comments
     * The parameter as passed to the reject method.
     * @param versionNo
     * The parameter as passed to the reject method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preReject(LicenseAccessor license,
      LicenseRejectionReasonEntry rejectionReason, String comments,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the reject method.
     * {@linkplain curam.provider.impl.License#reject}
     *
     * @param license
     * The object instance as it was after the main body of the reject
     * method.
     * @param rejectionReason
     * The parameter as passed to the reject method.
     * @param comments
     * The parameter as passed to the reject method.
     * @param versionNo
     * The parameter as passed to the reject method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postReject(LicenseAccessor license,
      LicenseRejectionReasonEntry rejectionReason, String comments,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the license events functionality surrounding the cancel
   * method.
   */
  public interface LicenseCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.provider.impl.License#cancel}
     *
     * @param license
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(LicenseAccessor license, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.provider.impl.License#cancel}
     *
     * @param license
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(LicenseAccessor license, int versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the license events functionality surrounding the approve
   * method.
   */
  public interface LicenseApproveEvents {

    /**
     * Event interface invoked before the main body of the approve method.
     * {@linkplain curam.provider.impl.License#approve}
     *
     * @param license
     * The object instance as it was before the main body of the
     * approve method.
     * @param comments
     * The parameter as passed to the approve method.
     * @param versionNo
     * The parameter as passed to the approve method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preApprove(LicenseAccessor license, String comments,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the approve method.
     * {@linkplain curam.provider.impl.License#approve}
     *
     * @param license
     * The object instance as it was after the main body of the
     * approve method.
     * @param comments
     * The parameter as passed to the approve method.
     * @param versionNo
     * The parameter as passed to the approve method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postApprove(LicenseAccessor license, String comments,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the license events functionality surrounding the insert
   * method.
   */
  public interface LicenseInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.License#insert}
     *
     * @param license
     * The object instance as it was before the main body of the
     * insert method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(LicenseAccessor license)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.License#insert}
     *
     * @param license
     * The object instance as it was after the main body of the
     * insert method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(LicenseAccessor license)
      throws InformationalException;
  }


  /**
   * Interface to the license events functionality surrounding the modify
   * method.
   */
  public interface LicenseModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.License#modify}
     *
     * @param license
     * The object instance as it was before the main body of the
     * modify method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(LicenseAccessor license, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.License#modify}
     *
     * @param license
     * The object instance as it was after the main body of the
     * modify method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(LicenseAccessor license, Integer versionNo)
      throws InformationalException;
  }
  // END, CR00144381
}
