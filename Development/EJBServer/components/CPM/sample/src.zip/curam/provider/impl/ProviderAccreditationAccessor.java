/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.util.persistence.StandardEntity;
import java.util.Set;


/**
 * Accessor interface for {@linkplain ProviderAccreditation}.
 */
public interface ProviderAccreditationAccessor extends StandardEntity {

  /**
   * Gets the type for the Provider Accreditation.
   *
   * @return The type for the provider accreditation.
   */
  String getType();

  /**
   * Gets the description for the Provider Accreditation.
   *
   * @return The description for the provider accreditation.
   */
  String getDescription();

  /**
   * Gets the immutable set of Accreditation Periods for the Provider
   * Accreditation.
   * <P>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of provider accreditation periods for a provider
   * accreditation.
   */
  Set<? extends AccreditationPeriodAccessor> getAccreditationPeriods();

  /**
   * Gets the immutable provider for the accreditation.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return Immutable provider the accreditation is associated with.
   */
  ProviderAccessor getProvider();
}
