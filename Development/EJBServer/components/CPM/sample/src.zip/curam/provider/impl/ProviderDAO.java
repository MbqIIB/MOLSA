/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.List;
import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.CASEPARTICIPANTROLETYPEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.entity.struct.FinancialInstructionDetailList;
import curam.cpm.sl.entity.struct.ProviderAndServiceSearchResultList;
import curam.cpm.sl.entity.struct.ProviderFinancialDetailList;
import curam.cpm.sl.entity.struct.ProviderInvestigationDetailsList;
import curam.cpm.sl.entity.struct.ProviderMembersBackgroundCheckDetailsList;
import curam.cpm.sl.entity.struct.ProviderSearchDetailsList;
import curam.cpm.sl.entity.struct.SearchByFIAndILITypeKey;
import curam.cpm.sl.struct.RetrieveFacilityInformationKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Date;


/**
 * Data access for {@linkplain curam.provider.impl.Provider}.
 */
@ImplementedBy(ProviderDAOImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ProviderDAO extends StandardDAO<Provider> {

  /**
   * Searches all providers that are assigned to the resource manager.
   *
   * @param userName
   * the userName to search for.
   * @return Set<Provider> the Provider which have the name specified.
   */
  Set<Provider> searchProvidersByUserName(final String userName);

  // BEGIN, CR00170625, KR
  /**
   * Searches all Providers that match the criteria entered.
   *
   * The search can be performed in two ways - Either by executing the modeled
   * query or by executing the dynamically constructed query. To execute the
   * dynamically constructed query enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param name
   * provider name.
   * @param referenceNumber
   * provider reference number.
   * @param searchByName
   * indicator to search by name.
   * @param searchByReferenceNumber
   * indicator to search by reference number.
   * @param category
   * category of the provider.
   * @param providerCategoryType
   * type of the provider category.
   * @param searchByCategory
   * indicator to search by category.
   * @param searchByType
   * indicator to search by type.
   * @param primaryCategoryInd
   * primary category index of provider.
   *
   * @return Set<Provider> the Provider matching the criteria specified.
   */
  // END, CR00170625
  Set<Provider> searchBy(final java.lang.String name,
    final java.lang.String referenceNumber,
    final java.lang.Boolean searchByName,
    final java.lang.Boolean searchByReferenceNumber,
    final java.lang.String category,
    final java.lang.String providerCategoryType,
    final java.lang.Boolean searchByCategory,
    final java.lang.Boolean searchByType,
    final java.lang.Boolean primaryCategoryInd);

  // BEGIN, CR00170625, KR
  /**
   * Searches all Providers that match the criteria entered.
   *
   * The search can be performed in two ways - Either by executing the modeled
   * query or by executing the dynamically constructed query. To execute the
   * dynamically constructed query enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param name
   * provider name.
   * @param referenceNumber
   * provider reference number.
   * @param searchByName
   * indicator to search by name.
   * @param searchByReferenceNumber
   * indicator to search by reference number.
   * @param street1
   * street of the provider.
   * @param city
   * city of the provider.
   * @param searchByStreet1
   * indicator to search by street.
   * @param searchByCity
   * indicator to search by city.
   * @param addressTypeCode
   * address type code of the provider.
   *
   * @param cityTypeCode
   * city type code of the provider.
   * @return Set<Provider> the Provider matching the criteria specified.
   */
  // END, CR00170625
  Set<Provider> searchByProviderEnrollment(final java.lang.String name,
    final java.lang.String referenceNumber,
    final java.lang.Boolean searchByName,
    final java.lang.Boolean searchByReferenceNumber,
    final java.lang.String street1, final java.lang.String city,
    final java.lang.Boolean searchByStreet1,
    final java.lang.Boolean searchByCity,
    final java.lang.String addressTypeCode,
    final java.lang.String cityTypeCode);

  /**
   * Reads all the providers registered in the system.
   *
   * @return Set<Provider> All providers registered with the organization.
   */
  Set<Provider> readAll();

  /**
   * Reads a Provider based on Enquiry. If a Provider is registered from an
   * Enquiry, then the Provider is returned for an input Enquiry otherwise a
   * null is returned.
   *
   * @param enquiryID
   * Contains Enquiry ID.
   * @return Provider Contains Provider details.
   */
  Provider readByEnquiry(final long enquiryID);

  // BEGIN, CR00170625, KR
  /**
   * Searches all Providers that match the criteria entered.
   *
   * The search can be performed in two ways - Either by executing the modeled
   * query or by executing the dynamically constructed query. To execute the
   * dynamically constructed query enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param providerName
   * Name of the Provider.
   * @param referenceNumber
   * Reference number of the Provider.
   * @param providerCategoryType
   * Category Type of the Provider.
   * @param ownerName
   * Owner's name.
   *
   * @return ProviderSearchDetailsList Contains list of Providers that match
   * search criteria.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00170625
  public ProviderSearchDetailsList searchProvider(String providerName,
    String referenceNumber, String providerCategoryType, String ownerName)
    throws AppException, InformationalException;
  
  // BEGIN, CR00304588, GA
  /**
   * Searches Provider details that match the criteria entered.
   *
   * The search can be performed in two ways - Either by executing the modeled
   * query or by executing the dynamically constructed query. To execute the
   * dynamically constructed query enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' 
   * to false.
   *
   * @param name
   * Contains the name of the Provider.
   * @param street1
   * Contains the street1 in the address of the Provider.
   * @param city
   * Contains the city in the address of the Provider.
   * @param serviceID
   * Contains the service ID.
   * @param fromDate
   * Contains the fromDate to start the search.
   * @param toDate
   * Contains the toDate to end the search..
   *
   * @return Contains list of Provider details that match search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderAndServiceSearchResultList searchProvider(final String name,
    final String street1, final String city,
    final long serviceID,
    final Date fromDate,
    final Date toDate
    )throws AppException, InformationalException;
  // END, CR00304588

  // BEGIN, CR00158121, JSP
  /**
   * Search for the list of providers matching the input search criteria.
   *
   * @param retrieveFacilityInformationKey
   * The input search criteria.
   *
   * @return The list of providers for the input search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  List<Provider> searchProvidersForFacilityInformation(
    RetrieveFacilityInformationKey retrieveFacilityInformationKey)
    throws AppException, InformationalException;

  // END, CR00158121

  // BEGIN, CR00197073, ASN
  /**
   * Searches details for all members of a provider with back ground check
   * information.
   *
   * @param provider
   * Contains concern Role ID of a provider.
   *
   * @return The list of provider members with back ground check information for
   * the input search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  ProviderMembersBackgroundCheckDetailsList searchProviderMembersBackgroundCheckDetails(
    final Provider provider) throws AppException, InformationalException;

  // END, CR00197073

  // BEGIN, CR00229264, VR
  /**
   * Retrieves the financial instruction details based on financial instruction ID and ILIType.
   *
   * @param searchByFIAndILITypeKey
   * financial instruction ID and ILIType.
   *
   * @return List of financial instruction details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  FinancialInstructionDetailList searchByFinancialInstructionAndILIType(
    final SearchByFIAndILITypeKey searchByFIAndILITypeKey)
    throws AppException, InformationalException;

  /**
   * Retrieves the list of payments associated with concern role and case nominee.
   *
   * @param concernRoleID
   * Concern Role ID of the CaseNominee.
   *
   * @return List of payment details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  ProviderFinancialDetailList searchFinancialsByConcernRole(
    final long concernRoleID) throws AppException, InformationalException;
  
  /**
   * Retrieves the list of liabilities associated with concern role and case nominee.
   *
   * @param concernRoleID
   * Concern Role ID of the CaseNominee.
   *
   * @return List of liabilities details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  ProviderFinancialDetailList searchLiabilitiesByConcernRole(
    final long concernRoleID) throws AppException, InformationalException;
  
  // END, CR00229264
  
  // BEGIN, CR00291801, ASN
  /**
   * Reads all the investigation cases where provider plays either direct or
   * indirect role.
   *
   * @param concernRoleID
   * Concern Role ID of the provider for which investigation cases will
   * be retrieved.
   * @param caseTypeCode
   * Type code for investigation case need to be retrieve.
   * @param recordStatus
   * Status of the record need to be retrieved.
   * @param caseParticipantRole
   * Role type for the case participant.
   *
   * @return List of investigation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  ProviderInvestigationDetailsList readProviderInvestigations(
    final long concernRoleID, final CASETYPECODEEntry caseTypeCode,
    final RECORDSTATUSEntry recordStatus,
    final CASEPARTICIPANTROLETYPEEntry caseParticipantRole)
    throws AppException, InformationalException;
  // END, CR00291801

}
