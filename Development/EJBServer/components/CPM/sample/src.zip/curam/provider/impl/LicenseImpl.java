/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.inject.Inject;

import curam.core.fact.SystemUserFactory;
import curam.core.intf.SystemUser;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.impl.LicenseAdapter;
import curam.cpm.sl.entity.struct.LicenseDtls;
import curam.events.LICENSE;
import curam.message.PROVIDER;
import curam.message.impl.LICENSEExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.provider.LicenseIssuer;
import curam.provider.LicenseStatus;
import curam.provider.LicenseType;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.CodetableState;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.persistence.helper.State;
import curam.util.persistence.helper.Transition;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.DateRange;
import curam.util.type.HistoricalEventHelper;
import curam.util.type.StringHelper;


/**
 * Standard implementation of {@linkplain curam.provider.impl.License}.
 */
// BEGIN, CR00183213, SS
public class LicenseImpl extends SingleTableEntityImpl<LicenseDtls> implements
  License {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for suspend events.
   */
  @Inject
  protected EventDispatcherFactory<LicenseSuspendEvents> suspendEventDispatcherFactory;

  /**
   * Event dispatcher for reject events.
   */
  @Inject
  protected EventDispatcherFactory<LicenseRejectEvents> rejectEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<LicenseCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for approve events.
   */
  @Inject
  protected EventDispatcherFactory<LicenseApproveEvents> approveEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<LicenseInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<LicenseModifyEvents> modifyEventDispatcherFactory;
  // END, CR00235789

  @Inject
  protected LicenseDAO licenseDAO;

  @Inject
  protected LicenseStatusHistoryCreatorDAO licenseStatusHistoryCreatorDAO;

  @Inject
  protected LicenseStatusHistoryDAO licenseStatusHistoryDAO;

  @Inject
  protected ProviderSecurity providerSecurity;

  @Inject
  protected ProviderDAO providerDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected LicenseImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * Get the comments for the Provider.
   *
   * @return The comments for the Provider.
   */
  public String getComments() {
    return getDtls().comments;
  }

  /**
   * Gets the Issuer entry for the license of the Provider.
   *
   * @return The Issuer entry for the license of the Provider.
   */
  public LicenseIssuerEntry getIssuer() {
    return LicenseIssuerEntry.get(getDtls().issuer);
  }

  /**
   * Gets the user who created the license.
   *
   * @return The user who created the license.
   */
  public String getUser() {
    return getDtls().createdBy;
  }

  /**
   * Gets the license number of the Provider.
   *
   * @return The license number of the Provider.
   */
  public String getLicenseNumber() {
    return getDtls().licenseNumber;
  }

  /**
   * {@inheritDoc}
   */
  public int getMaximumPlaces() {
    return getDtls().maximumPlaces;
  }

  /**
   * Gets the license type of the Provider.
   *
   * @return The license type of the Provider.
   */
  public LicenseTypeEntry getLicenseType() {
    return LicenseTypeEntry.get(getDtls().licenseType);
  }

  /**
   * Gets the "lifetime" of the license.
   *
   * @return The "lifetime" of the license.
   */
  public DateRange getDateRange() {
    return new DateRange(getDtls().dateIssued, getDtls().expirationDate);
  }

  /**
   * {@inheritDoc}
   */
  public Provider getProvider() {
    final long id = getDtls().providerConcernRoleID;

    return id == 0 ? null : providerDAO.get(id);

  }

  /**
   * Gets the renewal indicator of the license of the Provider.
   *
   * @return The renewal indicator of the license of the Provider.
   */
  public boolean isRenewed() {
    return getDtls().renewedInd;

  }

  /**
   * Gets the status of the license.
   *
   * @return The status of the license.
   */
  public LicenseStatusEntry getLifecycleState() {

    return LicenseStatusEntry.get(getDtls().licenseStatus);
  }

  /**
   * Gets the non-renewed active licenses for a provider which have the same
   * number and type as this license.
   *
   * @return The non-renewed active licenses for a provider which have the same
   * number and type as this license. This license will be returned in
   * the set.
   */
  // BEGIN, CR00177241, PM
  protected Set<License> getLicenseNumberDuplicates() {
    // END, CR00177241
    return licenseDAO.searchByLicenseNumberAndType(
      getLicenseNumber().toUpperCase(), getLicenseType().getCode(),
      LicenseStatus.CANCELED, getDateRange().start(), getDateRange().end(),
      false, getProvider().getID());
  }

  /**
   * Gets the non-renewed active licenses for a provider which have the same
   * issuer and type and expiration date later than the business date as this
   * license.
   *
   * @return The non-renewed active licenses for a provider which have the same
   * issuer and type and expiration date later than the business date as
   * this license. This license will be returned in the set.
   */
  // BEGIN, CR00177241, PM
  protected Set<License> getLicenseIssuerDuplicates() {
    // END, CR00177241
    return licenseDAO.searchActiveLicenseByIssuerTypeAndExpirationDate(
      getIssuer().getCode(), getLicenseType().getCode(), getDateRange().start(),
      getDateRange().end(), LicenseStatus.CANCELED, false,
      getProvider().getID());
  }

  /**
   * {@inheritDoc}
   */
  public List<LicenseStatusHistory> getStatusHistory() {
    return Collections.unmodifiableList(licenseStatusHistoryDAO.searchBy(this));
  }

  /**
   * Gets the rejection reason of the license for the Provider.
   *
   * @return The rejection reason of the license for the Provider.
   */
  public LicenseRejectionReasonEntry getRejectionReason() {
    return getLatestStatusHistory().getRejectionReason();
  }

  /**
   * Gets the suspension reason of the license for the Provider.
   *
   * @return The suspension reason of the license for the Provider.
   */
  public LicenseSuspensionReasonEntry getSuspensionReason() {
    return getLatestStatusHistory().getSuspensionReason();
  }

  /**
   * Gets the latest status history of the license for the Provider.
   *
   * @return The latest status history of the license for the Provider.
   */
  // BEGIN, CR00177241, PM
  protected LicenseStatusHistory getLatestStatusHistory() {
    // END, CR00177241
    return HistoricalEventHelper.latest(getStatusHistory());
  }

  // BEGIN, CR00158573, MR
  /**
   * Sets the "lifetime" of the license. This license cannot be used by clients
   * outside of the date range.
   *
   * @param value
   * Contains the "lifetime" of the license.
   *
   * <p>
   * It adds the following informational exception to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.LICENSE#
   * ERR_LICENSE_XFV_EXPIRATION_DATE_ON_OR_AFTER_DATE_ISSUED} -
   * If license expiration date is before issued date. </li>
   * </ul>
   */
  // END, CR00158573
  public void setDateRange(final DateRange value) {
    getDtls().dateIssued = value.start();
    getDtls().expirationDate = value.end();

    // field validation
    if (!value.isValidRange()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XFV_EXPIRATION_DATE_ON_OR_AFTER_DATE_ISSUED(
          getDtls().dateIssued),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  // BEGIN, CR00158573, MR
  /**
   * Sets the issuer of the license.
   *
   * @param value
   * The issuer of the license.
   *
   * <p>
   * It adds the following informational exception to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.LICENSE#
   * ERR_LICENSE_XFV_LICENSE_MORE_THAN_ONE_ACTIVE_LICENSE_FOR_SAME_TYPE_AND_ISSUER} -
   * If an active license from given License Issuer and License Type already
   * exists. </li>
   * </ul>
   */
  // END, CR00158573
  public void setIssuer(final LicenseIssuerEntry value) {
    getDtls().issuer = value.getCode();

    if ((!getDtls().issuer.equals(getRowManager().getOriginalDtls().issuer))
      || (!getDtls().licenseType.equals(
        getRowManager().getOriginalDtls().licenseType))
        || (!getDtls().dateIssued.equals(
          getRowManager().getOriginalDtls().dateIssued))
          || (!getDtls().expirationDate.equals(
            getRowManager().getOriginalDtls().expirationDate))) {

      final Set<License> licenseIssuerDuplicates = getLicenseIssuerDuplicates();

      // if the same record is returned by the search it's not a duplicate
      // and is removed from the duplicate list
      for (final Iterator<License> i = licenseIssuerDuplicates.iterator(); i.hasNext();) {

        final License license = i.next();

        if (getDtls().licenseID == license.getID()) {
          i.remove();
        }
      }

      if (licenseIssuerDuplicates.size() >= 1) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          LICENSEExceptionCreator.ERR_LICENSE_XFV_LICENSE_MORE_THAN_ONE_ACTIVE_LICENSE_FOR_SAME_TYPE_AND_ISSUER(
            new CodeTableItemIdentifier(LicenseIssuer.TABLENAME,
            getDtls().issuer),
            new CodeTableItemIdentifier(LicenseType.TABLENAME,
            getDtls().licenseType)),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);

      }
    }
  }

  // BEGIN, CR00158573, MR
  /**
   * Sets the number of the license for the provider.
   *
   * @param value
   * Contains the number of the license for the provider.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.LICENSE#
   * ERR_LICENSE_FV_FIELD_SIZE_MUST_BE_LT_OR_EQ} -
   * If the License Number exceed maximum length. </li>
   * <li> {@link curam.message.LICENSE#
   * ERR_LICENSE_XFV_LICENSE_WITH_LICENSE_NUMBER_AND_LICENSE_TYPE_EXISTS} -
   * If license with the given License Number and License Type already
   * exists. </li>
   * </ul>
   */
  // END, CR00158573
  public void setNumber(final String value) {
    getDtls().licenseNumber = StringHelper.trim(value);

    if (getLicenseNumber().length() > LicenseAdapter.kMaxLength_licenseNumber) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_FV_FIELD_SIZE_MUST_BE_LT_OR_EQ(
          LicenseAdapter.kMaxLength_licenseNumber),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }

    if ((!getDtls().licenseNumber.equals(
      getRowManager().getOriginalDtls().licenseNumber))
        || (!getDtls().licenseType.equals(
          getRowManager().getOriginalDtls().licenseType))
          || (!getDtls().dateIssued.equals(
            getRowManager().getOriginalDtls().dateIssued))
            || (!getDtls().expirationDate.equals(
              getRowManager().getOriginalDtls().expirationDate))) {

      final Set<License> licenseNumberDuplicates = getLicenseNumberDuplicates();

      // if the same record is returned by the search it's not a duplicate
      // and is removed from the duplicate list
      for (final Iterator<License> i = licenseNumberDuplicates.iterator(); i.hasNext();) {

        final License license = i.next();

        if (getDtls().licenseID == license.getID()) {
          i.remove();
        }
      }

      if (licenseNumberDuplicates.size() >= 1) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          LICENSEExceptionCreator.ERR_LICENSE_XFV_LICENSE_WITH_LICENSE_NUMBER_AND_LICENSE_TYPE_EXISTS(
            getDtls().licenseNumber,
            new CodeTableItemIdentifier(LicenseType.TABLENAME,
            getDtls().licenseType)),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

    // The licenseNumberUpper is set to upper case value of the licenseNumber
    // entered by the user. The licenseNumberUpper field is used for searching
    // for duplicate license numbers
    // The licenseNumberUpper is set to upper case value of the licenseNumber
    // entered by the user. The licenseNumberUpper field is used for searching
    // for duplicate license numbers
    getDtls().licenseNumberUpper = getDtls().licenseNumber.toUpperCase();
  }

  /**
   * {@inheritDoc}
   */
  public void setLicenseType(final LicenseTypeEntry value) {
    getDtls().licenseType = value.getCode();
  }

  /**
   * {@inheritDoc}
   */

  // BEGIN, CR00158573, MR
  public void setProvider(final Provider value) {
    // END, CR00158573
    getDtls().providerConcernRoleID = value.getID();
  }

  // BEGIN, CR00158573, MR
  /**
   * Sets the maximum places on the license.
   *
   * @param value
   * The maximum places on the license.
   *
   * <p>
   * It adds the following informational exception to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.LICENSE#
   * ERR_LICENSE_FV_MAXIMUM_PLACES_MUST_BE_GREATER_THAN_ZERO} -
   * If the maximum places is less then zero. </li>
   * </ul>
   */
  // END, CR00158573
  public void setMaximumPlaces(final int value) {
    getDtls().maximumPlaces = value;

    if (getMaximumPlaces() < 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_FV_MAXIMUM_PLACES_MUST_BE_GREATER_THAN_ZERO(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setUser(final String value) {

    // BEGIN, CR00158573, MR
    if (0 == getDtls().licenseID) {
      // END, CR00158573

      getDtls().createdBy = value;

      // BEGIN, CR00158573, MR
    }
    // END, CR00158573
  }

  // BEGIN, CR00158573, MR
  /**
   * Sets the Comments for the license of the provider.
   *
   * @param value
   * The comments for license of the provider.
   *
   * <p>
   * It adds the following informational exception to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.LICENSE#
   * ERR_LICENSE_FV_FIELD_SIZE_MUST_BE_LT_OR_EQ} -
   * If comments exceed maximum length. </li>
   * </ul>
   */
  public void setComments(final String value) {
    getDtls().comments = StringHelper.trim(value);
    // END, CR00158573
    if (getComments().length() > LicenseAdapter.kMaxLength_comments) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_FV_FIELD_SIZE_MUST_BE_LT_OR_EQ(
          LicenseAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

  }

  /**
   * {@inheritDoc}
   */

  // BEGIN, CR00158573, MR
  public void setRenewed(final boolean value) {
    // END, CR00158573
    getDtls().renewedInd = value;
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// None required
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// None required
  }

  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.LICENSE#ERR_LICENSE_FV_ISSUER_EMPTY} - If the
   * license issuer is not entered. </li>
   * <li> {@link curam.message.LICENSE#ERR_LICENSE_FV_NUMBER_EMPTY} - If the
   * license number is not entered. </li>
   * <li> {@link curam.message.LICENSE#ERR_LICENSE_FV_TYPE_EMPTY} - If the
   * license type is not entered. </li>
   * <li> {@link curam.message.LICENSE#ERR_LICENSE_FV_DATE_ISSUED_EMPTY} - If
   * the license issued date is not entered. </li>
   * <li>
   * {@link curam.message.LICENSE#ERR_LICENSE_FV_DATE_OF_EXPIRATION_EMPTY} -
   * If the license expiration date is not entered. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    if (getIssuer().equals(LicenseIssuerEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_FV_ISSUER_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (StringHelper.isEmpty(getLicenseNumber())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_FV_NUMBER_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (getLicenseType().equals(LicenseTypeEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_FV_TYPE_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (!getDateRange().isStarted()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_FV_DATE_ISSUED_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (!getDateRange().isEnded()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_FV_DATE_OF_EXPIRATION_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * Suspends license of the provider.
   *
   * @param suspensionReason
   * The reason for suspension.
   * @param comments
   * The suspension comments.
   * @param versionNo
   * The version number as previously retrieved
   *
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_APPROVE_DELETED_LICENSE}-
   * If the license is already deleted, it cannot be approved.
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_REJECT_DELETED_LICENSE}-
   * If the license is already deleted, it cannot be rejected.
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_SET_LICENSE_TO_CURRENT_STATE}-
   * If the license state can not be set to current state.
   * @throws InformationalException
   * {@link PROVIDER#
   * ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}-
   * If the provider is closed. Provider Details cannot be updated.
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_SUSPEND_DELETED_LICENSE}-
   * If the license is already deleted, it cannot be suspended.
   */

  // BEGIN, CR00158573, MR
  public void suspend(final LicenseSuspensionReasonEntry suspensionReason,
    final String comments, final int versionNo) throws InformationalException {
    // END, CR00158573

    // BEGIN, CR00235789, AK
    // Raise the pre suspend license event.
    suspendEventDispatcherFactory.get(LicenseSuspendEvents.class).preSuspend(
      this, suspensionReason, comments, versionNo);
    // END, CR00235789

    providerSecurity.checkProviderSecurity(getProvider());

    transitionTo(suspended, versionNo);

    // create a status history entry
    final LicenseStatusHistoryCreator licenseStatusHistory = createHistoryEntry();

    licenseStatusHistory.setSuspensionReason(suspensionReason);
    licenseStatusHistory.setComments(comments);
    licenseStatusHistory.insert();

    // raise post-suspend event
    final Event event = new Event();

    event.eventKey = LICENSE.LICENSE_SUSPENDED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post suspend license event.
    suspendEventDispatcherFactory.get(LicenseSuspendEvents.class).postSuspend(
      this, suspensionReason, comments, versionNo);
    // END, CR00235789
  }

  // BEGIN, CR00158573, MR
  /**
   * Change the the lifecycle state of the current record.
   *
   * @param newState The lifecycle state to transition to.
   * @param versionNo The version number of the record to be updated.
   *
   * @throws InformationalException Generic Exception Signature.
   */
  // END, CR00158573
  // BEGIN, CR00177241, PM
  protected void transitionTo(final State<LicenseStatusEntry> newState,
    final Integer versionNo) throws InformationalException {
    // END, CR00177241

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 29);
      ValidationHelper.failIfErrorsExist();
    }

    // get the state for the current license status
    final State<LicenseStatusEntry> oldState = states.get(getLifecycleState());

    // set the field which stores the status
    getDtls().licenseStatus = newState.getValue().getCode();

    // validate that the state cannot be changed to the current state
    if (newState.equals(oldState)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_CANNOT_SET_LICENSE_TO_CURRENT_STATE(
          oldState.getValue().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    } else if (newState.getValue().getCode().equals(LicenseStatus.APPROVED)
      && oldState.getValue().getCode().equals(LicenseStatus.CANCELED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_CANNOT_APPROVE_DELETED_LICENSE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if (newState.getValue().getCode().equals(LicenseStatus.SUSPENDED)
      && oldState.getValue().getCode().equals(LicenseStatus.CANCELED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_CANNOT_SUSPEND_DELETED_LICENSE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if (newState.getValue().getCode().equals(LicenseStatus.REJECTED)
      && oldState.getValue().getCode().equals(LicenseStatus.CANCELED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_CANNOT_REJECT_DELETED_LICENSE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else {

      // do the state transition
      oldState.transitionTo(newState);
    }

    // update the database
    super.modify(versionNo);
  }

  // BEGIN, CR00158573, MR
  /**
   * This method is used to create entry in the license status history entity.
   *
   * @return LicenseStatusHistoryCreator License Status History creation
   * details.
   */
  // END, CR00158573
  // BEGIN, CR00177241, PM
  protected LicenseStatusHistoryCreator createHistoryEntry() {
    // END, CR00177241
    final LicenseStatusHistoryCreator licenseStatusHistory = licenseStatusHistoryCreatorDAO.newInstance();

    licenseStatusHistory.setLicense(this);

    return licenseStatusHistory;
  }

  /**
   * Rejects license of the provider if the provider has failed the background
   * check.
   *
   * @param rejectionReason
   * The reason for rejection.
   * @param comments
   * The rejection comments.
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_APPROVE_DELETED_LICENSE}-
   * If the license is already deleted, it cannot be approved.
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_REJECT_DELETED_LICENSE}-
   * If the license is already deleted, it cannot be rejected.
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_SET_LICENSE_TO_CURRENT_STATE}-
   * If the license state can not be set to current state.
   * @throws InformationalException
   * {@link PROVIDER#
   * ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}-
   * If the provider is closed. Provider Details cannot be updated.
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_SUSPEND_DELETED_LICENSE}-
   * If the license is already deleted, it cannot be suspended.
   */
  public void reject(final LicenseRejectionReasonEntry rejectionReason,
    final String comments, final int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre reject license event.
    rejectEventDispatcherFactory.get(LicenseRejectEvents.class).preReject(this,
      rejectionReason, comments, versionNo);
    // END, CR00235789

    providerSecurity.checkProviderSecurity(getProvider());

    transitionTo(rejected, versionNo);

    // create a status history entry
    final LicenseStatusHistoryCreator licenseStatusHistory = createHistoryEntry();

    licenseStatusHistory.setRejectionReason(rejectionReason);
    licenseStatusHistory.setComments(comments);
    licenseStatusHistory.insert();

    // raise post-reject event
    final Event event = new Event();

    event.eventKey = LICENSE.LICENSE_REJECTED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post reject license event.
    rejectEventDispatcherFactory.get(LicenseRejectEvents.class).postReject(this,
      rejectionReason, comments, versionNo);
    // END, CR00235789
  }

  /**
   * Logically deletes the license for the provider.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_APPROVE_DELETED_LICENSE}-
   * If the license is already deleted, it cannot be approved.
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_REJECT_DELETED_LICENSE}-
   * If the license is already deleted, it cannot be rejected.
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_SET_LICENSE_TO_CURRENT_STATE}-
   * If the license state can not be set to current state.
   * @throws InformationalException
   * {@link PROVIDER#
   * ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}-
   * If the provider is closed. Provider Details cannot be updated.
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_SUSPEND_DELETED_LICENSE}-
   * If the license is already deleted, it cannot be suspended.
   */
  public void cancel(final int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre cancel license event.
    cancelEventDispatcherFactory.get(LicenseCancelEvents.class).preCancel(this,
      versionNo);
    // END, CR00235789

    providerSecurity.checkProviderSecurity(getProvider());

    transitionTo(canceled, versionNo);

    // create a status history entry
    final LicenseStatusHistoryCreator licenseStatusHistory = createHistoryEntry();

    licenseStatusHistory.insert();

    // BEGIN, CR00235789, AK
    // Raise the post cancel license event.
    cancelEventDispatcherFactory.get(LicenseCancelEvents.class).postCancel(this,
      versionNo);
    // END, CR00235789
  }

  /**
   * Approves license for the provider if the provider has passed the background
   * check.
   *
   * @param comments
   * The approval comments.
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_APPROVE_DELETED_LICENSE}-
   * If the license is already deleted, it cannot be approved.
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_REJECT_DELETED_LICENSE}-
   * If the license is already deleted, it cannot be rejected.
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_SET_LICENSE_TO_CURRENT_STATE} -
   * If the license state can not be set to current state.
   * @throws InformationalException
   * {@link PROVIDER#
   * ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.
   * @throws InformationalException
   * {@link curam.message.LICENSE#
   * ERR_LICENSE_XRV_CANNOT_SUSPEND_DELETED_LICENSE}-
   * If the license is already deleted, it cannot be suspended.
   */

  // BEGIN, CR00158573, MR
  public void approve(final String comments, final int versionNo)
    throws InformationalException {
    // END, CR00158573

    // BEGIN, CR00235789, AK
    // Raise the pre approve license event.
    approveEventDispatcherFactory.get(LicenseApproveEvents.class).preApprove(
      this, comments, versionNo);
    // END, CR00235789

    providerSecurity.checkProviderSecurity(getProvider());

    transitionTo(approved, versionNo);

    // create a status history entry
    final LicenseStatusHistoryCreator licenseStatusHistory = createHistoryEntry();

    licenseStatusHistory.setComments(comments);
    licenseStatusHistory.insert();

    // BEGIN, CR00235789, AK
    // Raise the post approve license event.
    approveEventDispatcherFactory.get(LicenseApproveEvents.class).postApprove(
      this, comments, versionNo);
    // END, CR00235789
  }

  /**
   * Validates and insert an license details for the Provider.
   *
   * @throws InformationalException
   * {@link PROVIDER#
   * ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}-
   * If the status of the provider is closed.
   */
  @Override
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre insert license event.
    insertEventDispatcherFactory.get(LicenseInsertEvents.class).preInsert(this);
    // END, CR00235789

    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 30);
      ValidationHelper.failIfErrorsExist();
    }

    super.insert();

    // create a history record for the initial status

    final LicenseStatusHistoryCreator licenseStatusHistory = createHistoryEntry();

    licenseStatusHistory.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert license event.
    insertEventDispatcherFactory.get(LicenseInsertEvents.class).postInsert(this);
    // END, CR00235789
  }

  /**
   * Validates and modify the license details for the Provider.
   *
   * @throws InformationalException
   * {@link PROVIDER#
   * ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}-
   * If the status of the provider is closed.
   */
  @Override

  // BEGIN, CR00158573, MR
  public void modify(final Integer versionNo) throws InformationalException {
    // END, CR00158573
    // BEGIN, CR00235789, AK
    // Raise the pre modify license event.
    modifyEventDispatcherFactory.get(LicenseModifyEvents.class).preModify(this,
      versionNo);
    // END, CR00235789

    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 31);
      ValidationHelper.failIfErrorsExist();
    }

    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify license event.
    modifyEventDispatcherFactory.get(LicenseModifyEvents.class).postModify(this,
      versionNo);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {

    SystemUser systemUserObj = SystemUserFactory.newInstance();

    // on creation the licenseStatus is set to In Progress
    getDtls().licenseStatus = LicenseStatus.INPROGRESS;

    try {
      setUser(systemUserObj.getUserDetails().userName);

    } catch (final Exception e) {

      // translate any exceptions to a runtime exception
      throw new AppRuntimeException(e);
    }
  }

  // BEGIN, CR00158573, MR
  /**
   * A map of the states for this entity.
   */
  protected final Map<LicenseStatusEntry, State<LicenseStatusEntry>> states = new HashMap<LicenseStatusEntry, State<LicenseStatusEntry>>();

  /**
   * State in progress.
   */
  protected final State<LicenseStatusEntry> inProgress = new CodetableState<LicenseStatusEntry>(
    states, LicenseStatusEntry.INPROGRESS, true, false) {// Uses default
    // implementation
  };

  /**
   * State suspended.
   * <ul>
   * <li> InformationalException
   * {@link curam.message.LICENSE#ERR_LICENSE_XRV_CANNOT_SUSPEND_LICENSE}- If
   * the license cannot be suspended.</li>
   * </ul>
   */
  protected final State<LicenseStatusEntry> suspended = new CodetableState<LicenseStatusEntry>(
    states, LicenseStatusEntry.SUSPENDED, false, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      final State<LicenseStatusEntry> oldState) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_CANNOT_SUSPEND_LICENSE(
          oldState.getValue().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  };

  /**
   * State approved.
   *
   * <ul>
   * <li> {@link curam.message.LICENSE#ERR_LICENSE_XRV_CANNOT_APPROVE_LICENSE}-
   * If the license cannot be approved.</li>
   * </ul>
   */
  protected final State<LicenseStatusEntry> approved = new CodetableState<LicenseStatusEntry>(
    states, LicenseStatusEntry.APPROVED, false, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      final State<LicenseStatusEntry> oldState) {
      ValidationHelper.addValidationError(
        ValidationHelper.addValidationError(
          LICENSEExceptionCreator.ERR_LICENSE_XRV_CANNOT_APPROVE_LICENSE(
            oldState.getValue().getCodeTableItemIdentifier())));
    }
  };

  /**
   * State rejected.
   *
   * <ul>
   * <li> {@link curam.message.LICENSE#ERR_LICENSE_XRV_CANNOT_REJECT_LICENSE}-
   * If the license cannot be rejected. </li>
   * </ul>
   */
  protected final State<LicenseStatusEntry> rejected = new CodetableState<LicenseStatusEntry>(
    states, LicenseStatusEntry.REJECTED, false, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      final State<LicenseStatusEntry> oldState) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_CANNOT_REJECT_LICENSE(
          oldState.getValue().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  };

  /**
   * State canceled.
   *
   * <ul>
   * <li> {@link curam.message.LICENSE#ERR_LICENSE_XRV_CANNOT_DELETE_LICENSE}-
   * If the license cannot be canceled. </li>
   * </ul>
   */
  protected final State<LicenseStatusEntry> canceled = new CodetableState<LicenseStatusEntry>(
    states, LicenseStatusEntry.CANCELED, false, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      final State<LicenseStatusEntry> oldState) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_CANNOT_DELETE_LICENSE(
          oldState.getValue().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  };
  // END, CR00158573

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<LicenseStatusEntry> inprogress2Approved = new Transition<LicenseStatusEntry>(
    inProgress, approved) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<LicenseStatusEntry> inprogress2Rejected = new Transition<LicenseStatusEntry>(
    inProgress, rejected) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<LicenseStatusEntry> inprogress2Canceled = new Transition<LicenseStatusEntry>(
    inProgress, canceled) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<LicenseStatusEntry> rejected2Approved = new Transition<LicenseStatusEntry>(
    rejected, approved) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<LicenseStatusEntry> approved2Suspended = new Transition<LicenseStatusEntry>(
    approved, suspended) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<LicenseStatusEntry> suspended2Approved = new Transition<LicenseStatusEntry>(
    suspended, approved) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<LicenseStatusEntry> suspended2Rejected = new Transition<LicenseStatusEntry>(
    suspended, rejected) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<LicenseStatusEntry> approved2Approved = new Transition<LicenseStatusEntry>(
    approved, approved) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<LicenseStatusEntry> suspended2Suspended = new Transition<LicenseStatusEntry>(
    suspended, suspended) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<LicenseStatusEntry> rejected2Rejected = new Transition<LicenseStatusEntry>(
    rejected, rejected) {// Uses default implementation
  };
}
