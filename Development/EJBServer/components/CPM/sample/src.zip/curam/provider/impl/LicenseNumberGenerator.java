/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2010, 2102 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Implementable;


// BEGIN, CR00185107, GP
/**
 * This class is used to generate a unique reference number.
 *
 * Clients may replace the default implementation of this interface to override
 * the default number generator. This is optional.
 */
@ImplementedBy(LicenseNumberGeneratorImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface LicenseNumberGenerator {

  /**
   * Generates a unique reference number. The unique alphanumeric number with
   * maximum length of eighteen digit used to identify the license and unique
   * among licenses of the same type at any given time.
   *
   * @return The generated unique reference number.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00185107
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  String generateReferenceNumber() throws AppException, InformationalException;

}
