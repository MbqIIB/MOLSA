/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.List;

import com.google.inject.ImplementedBy;

import curam.contracts.impl.ContractVersion;
import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain curam.provider.impl.CommunicationCVLink}.
 */
@ImplementedBy(CommunicationCVLinkDAOImpl.class)
public interface CommunicationCVLinkDAO extends
    StandardDAO<CommunicationCVLink> {

  /**
   * Searches for all the communication contract version link records related
   * to a specific contract version.
   *
   * @param contractVersion
   * Contains contract version ID used to search.
   * @param contractDocumentType
   * Contains contract document type ex: provider flat rate
   * contract, provider utilization contract etc.
   *
   * @return List of communication contract version link records which are
   * related to a specific contract version.
   */
  List<CommunicationCVLink> searchByContractVersion(
    final ContractVersion contractVersion,
    final String contractDocumentType);
}
