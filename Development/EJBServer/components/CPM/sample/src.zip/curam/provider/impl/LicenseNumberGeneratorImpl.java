/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.core.fact.UniqueIDFactory;
import curam.core.intf.UniqueID;
import curam.core.struct.UniqueIDKeySet;
import curam.cpm.impl.CPMConstants;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


// BEGIN, CR00185107, GP
/**
 * This class generates a unique reference number. The unique alphanumeric
 * number with maximum length of eighteen digit used to identify the license and
 * unique among licenses of the same type at any given time.
 *
 */
// BEGIN, CR00183213, SS
public class LicenseNumberGeneratorImpl implements LicenseNumberGenerator {

  /**
   * Constructor for the class.
   */
  // END, CR00183213
  public LicenseNumberGeneratorImpl() {// BEGIN, CR00183213, SS
    // The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public String generateReferenceNumber() throws AppException,
      InformationalException {

    UniqueID uniqueIDObj = UniqueIDFactory.newInstance();
    UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    uniqueIDKeySet.keySetName = CPMConstants.kLicenseKeySetName;

    return String.valueOf(uniqueIDObj.getNextIDFromKeySet(uniqueIDKeySet));
  }
  // END, CR00185107
}
