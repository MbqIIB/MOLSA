/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.List;

import com.google.inject.Inject;

import curam.approvalcheck.impl.ApprovalCheck;
import curam.approvalcheck.impl.ApprovalCheckAccessor;
import curam.approvalcheck.impl.ApprovalCheckDAO;
import curam.approvalcheck.impl.ApprovalCheck.ApprovalCheckCreateEvent;
import curam.codetable.impl.APPROVALCHECKTYPEEntry;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.fact.UsersFactory;
import curam.core.intf.Users;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.ViewOrganisationUnitDtls;
import curam.core.struct.StatusCodeKeyStruct;
import curam.core.struct.UserNameKey;
import curam.cpm.impl.CPMConstants;
import curam.message.impl.PROVIDERAPPROVALCHECKExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;


/**
 * This class handles the events raised on the creation of the approval check
 * for a provider.
 */
public class ProviderApprovalCheckCreateEventListener implements
  ApprovalCheckCreateEvent {
  
  /**
   * Reference to approval check DAO.
   */
  @Inject
  protected ApprovalCheckDAO approvalCheckDAO;
  
  /**
   * Reference to provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * {@inheritDoc}
   */
  public void postCreateApprovalCheck(@SuppressWarnings(CPMConstants.kUnused)
  ApprovalCheckAccessor approvalCheck) throws InformationalException {// Implementation is not required
  }

  /**
   * Validates the approval check details before inserting a record.
   *
   * @param approvalCheck
   * Approval Check Accessor.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECK#ERR_PROVIDER_APPROVALCHECK_XRV_ACTIVE_APPROVALCHECK_EXISTS_FOR_ALL_PROVIDERS_AND_ORGANISATION_UNIT} -
   * If an active approval check already exists for all providers, for
   * the organization unit.
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECK#ERR_PROVIDER_APPROVALCHECK_XRV_ACTIVE_APPROVALCHECK_EXISTS_FOR_ALL_PROVIDERS_AND_USER} -
   * If an active approval check already exists for all providers, for
   * the user.
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECK#ERR_PROVIDER_APPROVALCHECK_XRV_USER_NOT_ACTIVE_APPROVALCHECK_CANNOT_BE_CREATED} -
   * If the user is not active.
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECK#ERR_PROVIDER_APPROVALCHECK_XRV_ORGANISATION_UNIT_NOT_ACTIVE_APPROVALCHECK_CANNOT_BE_CREATED} -
   * If the organization unit is not active.
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECK#ERR_PROVIDER_APPROVALCHECK_XRV_ACTIVE_APPROVALCHECK_EXISTS_FOR_PROVIDER_AND_ORGANISATION_UNIT} -
   * If an active provider approval check already exists for the
   * organization unit.
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECK#ERR_PROVIDER_APPROVALCHECK_XRV_ACTIVE_APPROVALCHECK_EXISTS_FOR_PROVIDER_AND_USER} -
   * If an active provider approval check already exists for the user.
   */
  public void preCreateApprovalCheck(ApprovalCheckAccessor approvalCheck)
    throws InformationalException {
    
    boolean activeApprovalCheckExists = false;
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();
    ViewOrganisationUnitDtls organisationUnitDetails = new ViewOrganisationUnitDtls();
    String providerName = null;
    
    if (APPROVALRELATEDTYPEEntry.PROVIDER.getCode().equals(
      approvalCheck.getRelatedType().getCode())) {
      
      if (approvalCheck.getRelatedID() != 0) {
        providerName = providerDAO.get(approvalCheck.getRelatedID()).getName();
      }
    
      if (APPROVALCHECKTYPEEntry.ORGANISATIONUNIT.getCode().equals(
        approvalCheck.getType().getCode())) {
      
        organisationUnitKey.organisationUnitID = approvalCheck.getOrganisationUnitID();
    
        try {
          organisationUnitDetails = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance().readOrganisationUnitDetails(
            organisationUnitKey);
        } catch (AppException appException) {
          ValidationHelper.addValidationError(appException);
        }
    
        // Validate that the approval check can only be specified for the
        // organization unit with the status of active.
        if (!RECORDSTATUSEntry.NORMAL.getCode().equals(
          organisationUnitDetails.recordStatus)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERAPPROVALCHECKExceptionCreator.ERR_PROVIDER_APPROVALCHECK_XRV_ORGANISATION_UNIT_NOT_ACTIVE_APPROVALCHECK_CANNOT_BE_CREATED(
              organisationUnitDetails.organisationUnitName,
              RECORDSTATUSEntry.NORMAL.getCodeTableItemIdentifier()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }
    
        List<ApprovalCheck> activeApprovalChecks = approvalCheckDAO.searchByTypeOrganisationUnitAndStatus(
          APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
          APPROVALRELATEDTYPEEntry.PROVIDER,
          approvalCheck.getOrganisationUnitID(), RECORDSTATUSEntry.NORMAL);
      
        for (ApprovalCheck activeApprovalCheck : activeApprovalChecks) {
          if (approvalCheck.getRelatedID()
            == activeApprovalCheck.getRelatedID()) {
            activeApprovalCheckExists = true;
            break;
          }
        }
      
        // Validate that more than one active approval check cannot exist for
        // the same provider and the organization unit.
        if (activeApprovalCheckExists) {
          if (approvalCheck.getRelatedID() != 0) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERAPPROVALCHECKExceptionCreator.ERR_PROVIDER_APPROVALCHECK_XRV_ACTIVE_APPROVALCHECK_EXISTS_FOR_PROVIDER_AND_ORGANISATION_UNIT(
                RECORDSTATUSEntry.NORMAL.getCodeTableItemIdentifier(),
                providerName, organisationUnitDetails.organisationUnitName),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERAPPROVALCHECKExceptionCreator.ERR_PROVIDER_APPROVALCHECK_XRV_ACTIVE_APPROVALCHECK_EXISTS_FOR_ALL_PROVIDERS_AND_ORGANISATION_UNIT(
                RECORDSTATUSEntry.NORMAL.getCodeTableItemIdentifier(),
                organisationUnitDetails.organisationUnitName),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);            
          }
        }
      } else if (APPROVALCHECKTYPEEntry.USER.getCode().equals(
        approvalCheck.getType().getCode())) {

        UserNameKey userNameKey = new UserNameKey();

        userNameKey.userName = approvalCheck.getUsername();
        Users usersObj = UsersFactory.newInstance();
        StatusCodeKeyStruct statusCodeKeyStruct = new StatusCodeKeyStruct();

        try {
          statusCodeKeyStruct = usersObj.readStatus(userNameKey);
        } catch (AppException appException) {
          ValidationHelper.addValidationError(appException);
        }

        // Validate that the approval check can only be specified for the user
        // with the status of active.
        if (!RECORDSTATUSEntry.NORMAL.getCode().equals(
          statusCodeKeyStruct.statusCode)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERAPPROVALCHECKExceptionCreator.ERR_PROVIDER_APPROVALCHECK_XRV_USER_NOT_ACTIVE_APPROVALCHECK_CANNOT_BE_CREATED(
              approvalCheck.getUsername(),
              RECORDSTATUSEntry.NORMAL.getCodeTableItemIdentifier()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }

        List<ApprovalCheck> activeApprovalChecks = approvalCheckDAO.searchByTypeUsernameAndStatus(
          APPROVALCHECKTYPEEntry.USER, APPROVALRELATEDTYPEEntry.PROVIDER,
          approvalCheck.getUsername(), RECORDSTATUSEntry.NORMAL);

        for (ApprovalCheck activeApprovalCheck : activeApprovalChecks) {
          if (approvalCheck.getRelatedID()
            == activeApprovalCheck.getRelatedID()) {
            activeApprovalCheckExists = true;
            break;
          }
        }

        // Validate that more than one active approval check cannot exist for
        // the same provider and the user.
        if (activeApprovalCheckExists) {
          if (approvalCheck.getRelatedID() != 0) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERAPPROVALCHECKExceptionCreator.ERR_PROVIDER_APPROVALCHECK_XRV_ACTIVE_APPROVALCHECK_EXISTS_FOR_PROVIDER_AND_USER(
                RECORDSTATUSEntry.NORMAL.getCodeTableItemIdentifier(),
                providerName, userNameKey.userName),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              PROVIDERAPPROVALCHECKExceptionCreator.ERR_PROVIDER_APPROVALCHECK_XRV_ACTIVE_APPROVALCHECK_EXISTS_FOR_ALL_PROVIDERS_AND_USER(
                RECORDSTATUSEntry.NORMAL.getCodeTableItemIdentifier(),
                userNameKey.userName),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
          }
        }
      }
    }
  }
}
