/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.StandardDAO;


/**
 * Data access for
 * {@linkplain curam.provider.impl.ProviderGroupAssociate}.
 */
@ImplementedBy(ProviderGroupAssociateDAOImpl.class)
public interface ProviderGroupAssociateDAO extends
    StandardDAO<ProviderGroupAssociate> {

  // ___________________________________________________________________________
  /**
   * Searches for all provider group associates for a given Provider Group.
   *
   * @param providerGroup
   * the provider group for which the Provider Group Associates will be
   * listed.
   * @return The Provider Group Associates been associated with the provider
   * group.
   */
  Set<ProviderGroupAssociate> searchByProviderGroup(
    final ProviderGroup providerGroup);

  // ___________________________________________________________________________
  /**
   * Searches for provider group associates based on provider and Provider
   * Group.
   *
   * @param providerGroup
   * contains the provider group.
   * @param provider
   * contains the provider.
   * @return The Provider Group Associates for the Provider Group and Provider.
   */
  Set<ProviderGroupAssociate> searchByProviderAndProviderGroup(
    ProviderGroup providerGroup, Provider provider);

  // ___________________________________________________________________________
  /**
   * Searches for provider groups based on provider.
   *
   * @param provider
   * the provider for whom the ProviderGroups will be listed.
   * @return The service offerings which have been associated with the provider.
   */
  Set<ProviderGroupAssociate> searchProviderGroupsForProvider(
    final Provider provider);

}
