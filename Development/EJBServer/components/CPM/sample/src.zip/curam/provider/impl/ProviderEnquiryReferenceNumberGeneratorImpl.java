/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2009, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.fact.ProviderEnquiryFactory;
import curam.cpm.sl.entity.struct.ProviderEnquiryReferenceNumberKey;
import curam.cpm.util.impl.ReferenceNumberUtility;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.MultipleRecordException;
import curam.util.exception.RecordNotFoundException;


/**
 * Standard implementation of
 * {@linkplain ProviderEnquiryReferenceNumberGenerator}.
 */
@Singleton
public class ProviderEnquiryReferenceNumberGeneratorImpl implements
  ProviderEnquiryReferenceNumberGenerator {

  // BEGIN, CR00314817, GYH
  /**
   * Reference to reference number generation utility class.
   */
  @Inject
  protected ReferenceNumberUtility referenceNumberUtility;

  // END, CR00314817

  /**
   * Constructor for the class.
   */
  protected ProviderEnquiryReferenceNumberGeneratorImpl() {// The no-arg constructor for use only by Guice.
  }

  /**
   * {@inheritDoc}
   */
  public String generateReferenceNumber() throws AppException,
      InformationalException {

    String referenceNumber = null;
    boolean referenceNumberExist = true;
    ProviderEnquiryReferenceNumberKey providerEnquiryReferenceNumberKey = new ProviderEnquiryReferenceNumberKey();
    curam.cpm.sl.entity.intf.ProviderEnquiry providerEnquiryObj = ProviderEnquiryFactory.newInstance();

    while (referenceNumberExist) {

      referenceNumber = referenceNumberUtility.generateReferenceNumber(
        CPMConstants.kProviderEnquiryKeySetName);

      providerEnquiryReferenceNumberKey.referenceNumber = referenceNumber;

      try {

        providerEnquiryObj.readByReferenceNumber(
          providerEnquiryReferenceNumberKey);

      } catch (MultipleRecordException multipleRecordException) {// In this case, we are making sure that the system generated alternate
        // ID is unique. There could be an existing identical alternate ID
        // record, if
        // any then we are continuing until we get a unique one generated.
      } catch (RecordNotFoundException recordNotFoundException) {
        referenceNumberExist = false;
      }

    }

    return referenceNumber;
  }

}
