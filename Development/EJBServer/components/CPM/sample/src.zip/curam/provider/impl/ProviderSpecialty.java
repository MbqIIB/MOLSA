/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;


/**
 * Areas in which a provider has particular experience or expertise.
 *
 * These are not directly linked to services but may include things like
 * Languages Spoken, Method of Payment Accepted etc. These can be used in
 * conjunction with the services desired to match to an appropriate provider.
 */
@ImplementedBy(ProviderSpecialtyImpl.class)
public interface ProviderSpecialty extends ProviderSpecialtyAccessor, Insertable,
    Commented, LogicallyDeleteable, DateRanged, OptimisticLockModifiable {

  /**
   * Gets the provider having a specialty.
   *
   * @return Provider associated with the provider specialty.
   */
  Provider getProvider();

  /**
   * Sets the specialty for a provider.
   *
   * @param specialty
   * The specialty to be set for the provider specialty.
   */
  void setSpecialty(final ProviderSpecialtyTypeEntry specialty);

  /**
   * Sets the provider for a provider specialty.
   *
   * @param provider
   * The provider to be set for the provider specialty.
   */
  void setProvider(final Provider provider);

  /**
   * Sets the start date and end date duration, during which the provider has
   * the specialty.
   *
   * @param value
   * The "lifetime" of the provider specialty.
   * @see curam.provider.impl.ProviderSpecialtyImpl#setDateRange(DateRange)
   * The default implementation -
   * curam.provider.impl.ProviderSpecialtyImpl#setDateRange(DateRange).
   */
  void setDateRange(final DateRange value);

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider specialty events functionality surrounding the
   * insert method.
   */
  public interface ProviderSpecialtyInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderSpecialty#insert}
     *
     * @param providerSpecialty
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ProviderSpecialty providerSpecialty)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderSpecialty#insert}
     *
     * @param providerSpecialty
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ProviderSpecialty providerSpecialty)
      throws InformationalException;
  }


  /**
   * Interface to the provider specialty events functionality surrounding the
   * cancel method.
   */
  public interface ProviderSpecialtyCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderSpecialty#cancel}
     *
     * @param providerSpecialty
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(ProviderSpecialty providerSpecialty, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderSpecialty#cancel}
     *
     * @param providerSpecialty
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(ProviderSpecialty providerSpecialty, int versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the provider specialty events functionality surrounding the
   * modify method.
   */
  public interface ProviderSpecialtyModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderSpecialty#modify}
     *
     * @param providerSpecialty
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(ProviderSpecialty providerSpecialty, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderSpecialty#modify}
     *
     * @param providerSpecialty
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(ProviderSpecialty providerSpecialty,
      Integer versionNo) throws InformationalException;
  }
  // END, CR00144381
}
