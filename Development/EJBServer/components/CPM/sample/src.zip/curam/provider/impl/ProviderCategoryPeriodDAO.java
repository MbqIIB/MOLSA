/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain curam.provider.impl.ProviderCategoryPeriod}.
 */
@ImplementedBy(ProviderCategoryPeriodDAOImpl.class)
public interface ProviderCategoryPeriodDAO extends
    StandardDAO<ProviderCategoryPeriod> {

  /**
   * Reads the Primary Category for the the Provider.
   *
   * @param provider
   * Provider for whom primary category is to be returned.
   * @return The primary provider category period for the specified provider.
   */
  ProviderCategoryPeriod readPrimaryCategoryFor(final Provider provider);

  /**
   * Searches for all the categories for the provider.
   *
   * @param provider
   * Provider for whom categories is to be returned.
   * @return Provider category period for the specified provider.
   */
  Set<ProviderCategoryPeriod> searchBy(final Provider provider);

  // BEGIN, CR00157611, SG
  /**
   * Searches for category periods for a provider category.
   *
   * @param providerCategory
   * Provider category code.
   *
   * @return The set of category periods matching the category.
   */
  Set<ProviderCategoryPeriod> searchByCategory(
    final ProviderCategoryNameEntry providerCategory);

  // END, CR00157611

}
