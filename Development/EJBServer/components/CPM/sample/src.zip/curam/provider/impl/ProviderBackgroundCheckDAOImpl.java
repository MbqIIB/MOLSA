/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import curam.cpm.sl.entity.impl.ProviderBackgroundCheckAdapter;
import curam.cpm.sl.entity.struct.ProviderBackgroundCheckDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;


// BEGIN, CR00183213, SS
// BEGIN, CR00197240, ASN
/**
 * Data access for {@linkplain ProviderBackgroundCheck}.
 */
// END, CR00197240
public class ProviderBackgroundCheckDAOImpl extends StandardDAOImpl<ProviderBackgroundCheck, ProviderBackgroundCheckDtls>
  implements ProviderBackgroundCheckDAO {
  // END, CR00183213
  /**
   * Creating an instance of the adapter
   */
  protected static final ProviderBackgroundCheckAdapter adapter = new ProviderBackgroundCheckAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderBackgroundCheckDAOImpl() {
    // END, CR00183213
    super(adapter, ProviderBackgroundCheck.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderBackgroundCheck> searchBy(Provider provider) {
    return newSet(adapter.searchBy(provider.getID()));
  }

  // BEGIN, CR00197240, ASN
  /**
   * {@inheritDoc}
   */
  public Set<ProviderBackgroundCheck> searchByProviderMember(
    final ProviderParty providerParty) throws AppException,
      InformationalException {

    return newSet(adapter.searchByProviderMember(providerParty.getID()));
  }
  // END, CR00197240
}
