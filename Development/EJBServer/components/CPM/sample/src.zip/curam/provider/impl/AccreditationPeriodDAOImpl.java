/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import curam.cpm.sl.entity.impl.AccreditationPeriodAdapter;
import curam.cpm.sl.entity.struct.AccreditationPeriodDtls;
import curam.util.persistence.StandardDAOImpl;


// _____________________________________________________________________________
/**
 * Data retrieval operations for provider accreditation.
 */
// BEGIN, CR00183213, SS
public class AccreditationPeriodDAOImpl extends StandardDAOImpl<AccreditationPeriod, AccreditationPeriodDtls> implements
  AccreditationPeriodDAO {
  // END, CR00183213
  /**
   * Declare adapter and initialize it.
   */
  protected static final AccreditationPeriodAdapter adapter = new AccreditationPeriodAdapter();

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected AccreditationPeriodDAOImpl() {
    // END, CR00183213
    super(adapter, AccreditationPeriod.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<AccreditationPeriod> searchBy(
    ProviderAccreditation providerAccreditation) {
    return newSet(adapter.searchBy(providerAccreditation.getID()));

  }
}
