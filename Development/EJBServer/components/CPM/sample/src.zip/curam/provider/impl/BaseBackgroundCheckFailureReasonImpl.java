/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import curam.cpm.sl.entity.struct.BackgroundCheckFailureReasonDtls;
import curam.message.impl.BACKGROUNDCHECKExceptionCreator;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.Date;


// BEGIN, CR00183213, SS
public class BaseBackgroundCheckFailureReasonImpl extends SingleTableLogicallyDeleteableEntityImpl<BackgroundCheckFailureReasonDtls>
  implements BaseBackgroundCheckFailureReason {

  /**
   * Constructor for the class.
   */
  protected BaseBackgroundCheckFailureReasonImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213
  /**
   * {@inheritDoc}
   */
  public Date getOccurrenceDate() {
    return getDtls().occurrenceDate;
  }

  /**
   * {@inheritDoc}
   */
  public String getFailureReason() {
    return getDtls().failureReason;

  }

  /**
   * {@inheritDoc}
   */
  public void setOccurrenceDate(Date date) {
    getDtls().occurrenceDate = date;
    if (getDtls().occurrenceDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECKFAILUREREASON_FV_DATE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setFailureReason(
    final BackgroundCheckFailureReasonTypeEntry failureReason) {
    if (failureReason.equals(
      BackgroundCheckFailureReasonTypeEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECKFAILUREREASON_FV_FAILURE_REASON_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    getDtls().failureReason = failureReason.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {
    if (getDtls().occurrenceDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECKFAILUREREASON_FV_DATE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    if (getDtls().failureReason.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECKFAILUREREASON_FV_FAILURE_REASON_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// none required
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// none required
  }
}
