/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.codetable.impl.COMMUNICATIONMETHODEntry;
import curam.codetable.impl.LANGUAGEEntry;
import curam.core.struct.AddressDtls;
import curam.core.struct.PhoneNumberDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;
import curam.util.type.Date;
import curam.util.type.DateTime;


/**
 * Accessor interface for {@linkplain  ProviderEnquiry}.
 */
public interface ProviderEnquiryAccessor extends StandardEntity {

  /**
   * Gets a reference number assigned by the organization to this provider
   * enquiry to uniquely identify the enquiry.
   *
   * @return A reference number assigned by the organization to this provider.
   */
  String getReferenceNumber();

  /**
   * Gets the additional name for this provider enquiry. Where the interested
   * party is a couple the name of the other person in the couple.
   *
   * @return The additional name for this provider enquiry.
   */
  String getAdditionalName();

  /**
   * Gets the preferred information or training session that this provider
   * enquiry would like to attend.
   *
   * @return The preferred information or training session.
   */
  String getPreferredSession();

  /**
   * Gets the reason that the provider made this enquiry to the organization
   * about becoming a provider.
   *
   * @return The reason that the provider made this enquiry to the organization
   * about becoming a provider.
   */
  ReasonForEnquiryEntry getReasonForEnquiry();

  /**
   * Whether the details of the scheduled meeting have been confirmed with this
   * enquiry about becoming a provider.
   *
   * @return The indicator whether the details of the scheduled meeting have
   * been confirmed with this enquiry about becoming a provider.
   */
  boolean isMeetingConfirmed();

  /**
   * Whether a meeting has been attended by the person for of this enquiry.
   *
   * @return The indicator whether a meeting has been attended.
   */
  boolean hasAttendedMeeting();

  /**
   * Gets the indicator whether the person of this enquiry has obtained an
   * application form when they attended the scheduled meeting.
   *
   * @return The indicator whether the person of this enquiry has obtained an
   * application form.
   */
  boolean hasObtainedApplicationForm();

  /**
   * Gets date and time of the meeting that this enquiry has been scheduled to
   * attend.
   *
   * @return Date and time of the meeting that this enquiry has been scheduled
   * to attend.
   */
  String getScheduledMeeting();

  /**
   * Gets the number of children currently in the household of the person of
   * this enquiry.
   *
   * @return The number of children currently in the household of the person of
   * this enquiry.
   */
  short getNumberOfChildren();

  /**
   * Gets the details of when the organization can contact this provider.
   *
   * @return The details of when the organization can contact this provider.
   */
  String getAvailabilityForContact();

  /**
   * Gets the status for this provider enquiry.
   *
   * @return The status for this provider enquiry.
   */
  EnquiryStatusEntry getRecordStatus();

  /**
   * Gets the owner name for this provider enquiry.
   *
   * @return The owner name for this provider enquiry.
   */
  String getOwnerName();

  /**
   * Gets the additional information about this provider enquiry.
   *
   * @return The additional information about this provider enquiry.
   */
  String getAdditionalInformation();

  /**
   * Gets the home phone number of this provider enquiry.
   *
   * @return The home phone number.
   */
  long getHomePhoneNumberID();

  /**
   * Gets the work phone number for this provider enquiry.
   *
   * @return The work phone number.
   */
  long getWorkPhoneNumberID();

  /**
   * Gets the mobile phone number for this provider enquiry.
   *
   * @return The mobile phone number.
   */
  long getMobilePhoneNumberID();

  /**
   * Gets the work address for this provider enquiry.
   *
   * @return The work address.
   */
  long getWorkAddressID();

  /**
   * Gets the home address for this provider enquiry.
   *
   * @return The home address.
   */
  long getHomeAddressID();

  /**
   * Gets the immutable provider category period for this provider enquiry.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable provider category period.
   */
  ProviderCategoryPeriodAccessor getProviderCategoryPeriod();

  /**
   * Gets the enquiry end date for this provider enquiry.
   *
   * @return The provider enquiry end date.
   */
  Date getEndDate();

  /**
   * Gets the enquiry date for this provider enquiry.
   *
   * @return The provider enquiry date.
   */
  DateTime getEnquiryDate();

  /**
   * Gets the home phone number details of this provider enquiry.
   *
   * @return The home phone number details.
   */
  PhoneNumberDtls getHomePhoneNumberDtls();

  /**
   * Gets the work phone number details for this provider enquiry.
   *
   * @return The work phone number details.
   */
  PhoneNumberDtls getWorkPhoneNumberDtls();

  /**
   * Gets the mobile phone number for this provider enquiry.
   *
   * @return The mobile phone number.
   */
  PhoneNumberDtls getMobilePhoneNumberDtls();

  /**
   * Gets the work address details for this provider enquiry.
   *
   * @return The work address details.
   */
  AddressDtls getWorkAddressDtls();

  /**
   * Gets the home address for this provider enquiry.
   *
   * @return The home address.
   */
  AddressDtls getHomeAddressDtls();

  /**
   * Gets the preferred language of the provider enquiry..
   *
   * @return The preferred language of the provider enquiry.
   */
  LANGUAGEEntry getPreferredLanguage();

  /**
   * Gets the method of preferred communication for the provider enquiry.
   *
   * @return The method of preferred communication for the provider enquiry.
   */
  COMMUNICATIONMETHODEntry getPreferredCommunication();

  /**
   * This method to get the provider enquiry is raised by an internal user or an
   * external user
   *
   * @param userName
   * Contains the name of the user.
   * @return It it is an external user.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  boolean isExternalUser(String userName) throws InformationalException,
      AppException;
  
  // BEGIN, CR00095292, RPB
  /**
   * Gets the organization object link id.
   *
   * @return The organization object link id.
   * @see ProviderEnquiryAccessor#getOwnerOrgObjectName()
   * @see ProviderEnquiry#setOrgObjectLink(long)
   */
  long getOrgObjectLinkID();

  /**
   * Gets the name of the organization object which is the owner for the
   * provider enquiry. This facilitates the provider enquiry to be owned not
   * only by the user but by other organization objects such as
   * position,organization unit and work queue.
   *
   * @return The name of the owner organization object.
   * @see ProviderEnquiryAccessor#getOrgObjectLinkID()
   * @see ProviderEnquiry#setOrgObjectLink(long)
   */
  String getOwnerOrgObjectName() throws InformationalException;

  // END, CR00095292
}
