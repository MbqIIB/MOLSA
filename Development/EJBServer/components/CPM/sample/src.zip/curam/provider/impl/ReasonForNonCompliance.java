/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;


/**
 * Reason why the license is non-compliant and can therefore not be renewed.
 */
@ImplementedBy(ReasonForNonComplianceImpl.class)
public interface ReasonForNonCompliance extends Insertable,
    ReasonForNonComplianceAccessor {

  /**
   * Gets the immutable License.
   *
   * @return The immutable license which is non-compliant.
   */
  License getLicense();

  /**
   * Sets the License.
   *
   * @param value
   * The license ID to be set.
   */
  void setLicense(final License value);

  /**
   * Sets the non compliance reasons.
   *
   * @param value
   * The list of non compliance reasons.
   */
  void setNonComplianceReasons(final String value);

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the reason for non compliance events functionality surrounding
   * the insert method.
   */
  public interface ReasonForNonComplianceInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.ReasonForNonCompliance#insert}
     *
     * @param reasonForNonCompliance
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ReasonForNonComplianceAccessor reasonForNonCompliance)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.ReasonForNonCompliance#insert}
     *
     * @param reasonForNonCompliance
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ReasonForNonComplianceAccessor reasonForNonCompliance)
      throws InformationalException;
  }
  // END, CR00144381
}
