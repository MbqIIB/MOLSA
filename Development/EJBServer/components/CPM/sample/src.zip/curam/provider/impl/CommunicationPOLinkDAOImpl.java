/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.Singleton;

import curam.cpm.sl.impl.CommunicationPOLinkAdapter;
import curam.cpm.sl.struct.CommunicationPOLinkDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.CommunicationPOLinkDAO}.
 */
@Singleton
public class CommunicationPOLinkDAOImpl extends StandardDAOImpl<CommunicationPOLink, CommunicationPOLinkDtls> implements
  CommunicationPOLinkDAO {

  /**
   * Instance of communication provider offering link adapter.
   */
  protected static final CommunicationPOLinkAdapter adapter = new CommunicationPOLinkAdapter();

  /**
   * Constructor for the class.
   */
  protected CommunicationPOLinkDAOImpl() {

    super(adapter, CommunicationPOLink.class);

  }

}
