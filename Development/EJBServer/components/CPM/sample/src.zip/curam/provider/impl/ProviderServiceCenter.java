/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.participant.impl.PhoneNumber;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.persistence.helper.Named;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;
import curam.workspaceservices.localization.impl.LocalizableText;


/**
 * Locations from where a provider can deliver services.
 *
 * For example a physiotherapist may deliver the service at several clinics.
 * Service centers can only deliver non-placement services.
 */
@ImplementedBy(ProviderServiceCenterImpl.class)
public interface ProviderServiceCenter extends ProviderServiceCenterAccessor, Insertable,
    Commented, Named, LogicallyDeleteable, DateRanged, OptimisticLockModifiable {

  /**
   * Gets the current Provider Service Center.
   *
   * @return ProviderServiceCenter service center for the Provider.
   */
  ProviderServiceCenter getProviderServiceCenter();

  /**
   * Sets the daterange of the provider Service Center.
   *
   * @param value
   * the "lifetime" of the provider service center.
   */
  void setDateRange(final DateRange value);

  /**
   * Gets the provider for the Service Center.
   *
   * @return Provider for the service center.
   */
  Provider getProvider();

  /**
   * Sets the provider for the Service Center.
   *
   * @param provider
   * the provider to be set for the service center.
   *
   * @see curam.provider.impl.ProviderServiceCenter#setProvider(Provider) The default
   * implementation -
   * curam.provider.impl.ProviderServiceCenterImpl#setProvider(Provider).
   */
  void setProvider(final Provider provider);

  /**
   * Gets the provider offerings for the Service Center.
   *
   * @return Set<ServiceCenterProviderOffering> the set of provider offerings
   * for the service center.
   */
  Set<ServiceCenterProviderOffering> getServiceCenterProviderOffering();

  /**
   * Sets the name of the Service Center.
   *
   * @param name
   * the name to be set for the service center.
   *
   * @see curam.provider.impl.ProviderServiceCenter#setName(String) The default
   * implementation -
   * curam.provider.impl.ProviderServiceCenterImpl#setName(String).
   */
  void setName(String name);

  /**
   * Sets the web address of the Service Center.
   *
   * @param id
   * the web address id to be set to the service center.
   */
  void setWebAddressID(long id);

  /**
   * Sets the email address of the Service Center.
   *
   * @param id
   * the email address id to be set to the service center.
   */
  void setEmailAddressID(long id);

  /**
   * Sets the address of the Service Center.
   *
   * @param id
   * the Address Id to be set to the service center.
   */
  void setAddressID(long id);

  /**
   * Gets the phone number of the Service Center.
   *
   * @return PhoneNumber of the service center.
   */
  PhoneNumber getPhoneNumber();

  /**
   * Sets the phone number of the Service Center.
   *
   * @param value
   * the phone number to be set to the service center.
   */
  void setPhoneNumber(PhoneNumber value);

  // BEGIN, CR00178272, AK
  /**
   * Gets the immutable localized text object for the attribute, areas served
   * information.
   *
   * @return The immutable localized text object.
   */
  LocalizableText getAreasServedInfo();

  /**
   * Gets the immutable localized text object for the attribute, client
   * information.
   *
   * @return The immutable localized text object.
   */
  LocalizableText getClientInfo();

  /**
   * Sets the localized text ID of the provider service center attribute, areas
   * served information.
   *
   * @param value
   * The localized text ID of the areas served information.
   */
  void setAreasServedInfoTextID(long value);

  /**
   * Sets the localized text ID of the provider service center attribute, client
   * information.
   *
   * @param value
   * The localized text ID of the client information.
   */
  void setClientInfoTextID(long value);
  // END, CR00178272

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider service center events functionality surrounding
   * the insert method.
   */
  public interface ProviderServiceCenterInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderServiceCenter#insert}
     *
     * @param providerServiceCenter
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ProviderServiceCenter providerServiceCenter)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderServiceCenter#insert}
     *
     * @param providerServiceCenter
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ProviderServiceCenter providerServiceCenter)
      throws InformationalException;
  }


  /**
   * Interface to the provider service center events functionality surrounding
   * the cancel method.
   */
  public interface ProviderServiceCenterCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderServiceCenter#cancel}
     *
     * @param providerServiceCenter
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(ProviderServiceCenter providerServiceCenter, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderServiceCenter#cancel}
     *
     * @param providerServiceCenter
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(ProviderServiceCenter providerServiceCenter, int versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the provider service center events functionality surrounding
   * the modify method.
   */
  public interface ProviderServiceCenterModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderServiceCenter#modify}
     *
     * @param providerServiceCenter
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(ProviderServiceCenter providerServiceCenter, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderServiceCenter#modify}
     *
     * @param providerServiceCenter
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(ProviderServiceCenter providerServiceCenter, Integer versionNo)
      throws InformationalException;
  }
  // END, CR00144381

}
