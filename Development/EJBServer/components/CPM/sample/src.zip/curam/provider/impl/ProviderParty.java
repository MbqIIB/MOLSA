/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.participant.impl.ConcernRole;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;
import curam.util.type.DateTimeRange;


/**
 * Provider parties are the individuals associated to the provider.
 *
 * Provider parties break down into two classifications:
 * <ul>
 * <li>{@linkplain curam.provider.impl.ProviderParticipant}s; and</li>
 * <li>{@linkplain curam.provider.impl.ProviderMember}s; and</li>
 * </ul>
 */
@ImplementedBy(ProviderPartyImpl.class)
public interface ProviderParty extends ProviderPartyAccessor, Insertable, DateRanged,
    OptimisticLockModifiable, LogicallyDeleteable {

  /**
   * Sets the "lifetime" of the provider party.
   *
   * @param value
   * The "lifetime" of the provider party.
   *
   * @see curam.provider.impl.ProviderParty#setDateRange(DateRange) The default
   * implementation -
   * curam.provider.impl.ProviderPartyImpl#setDateRange(DateRange).
   */
  void setDateRange(final DateRange value);

  /**
   * Gets the provider organization of the party.
   *
   * @return ProviderOrganization associated with the Party.
   */
  ProviderOrganization getProviderOrganization();

  /**
   * Sets the provider organization of the party.
   *
   * @param value
   * the provider organization.
   */
  void setProviderOrganization(final ProviderOrganization value);

  /**
   * Sets the party related to the provider organization.
   *
   * @param value
   * the party related to the provider organization.
   */
  void setParty(final ConcernRole value);

  /**
   * Gets the party related to the provider organization.
   *
   * @return ConcernRole of the the party related to the provider organization.
   */
  ConcernRole getParty();

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider party events functionality surrounding the insert
   * method.
   */
  public interface ProviderPartyInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderParty#insert}
     *
     * @param providerParty
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ProviderPartyAccessor providerParty)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderParty#insert}
     *
     * @param providerParty
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ProviderPartyAccessor providerParty)
      throws InformationalException;
  }


  /**
   * Interface to the provider party events functionality surrounding the modify
   * method.
   */
  public interface ProviderPartyModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderParty#modify}
     *
     * @param providerParty
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(ProviderPartyAccessor providerParty, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderParty#modify}
     *
     * @param providerParty
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(ProviderPartyAccessor providerParty, Integer versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the provider party events functionality surrounding the cancel
   * method.
   */
  public interface ProviderPartyCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderParty#cancel}
     *
     * @param providerParty
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(ProviderPartyAccessor providerParty, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderParty#cancel}
     *
     * @param providerParty
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(ProviderPartyAccessor providerParty, int versionNo)
      throws InformationalException;
  }
  // END, CR00144381
  
  // BEGIN, CR00320064, SSK
  /**
   * Sets the start date time and the end date time of the provider party.
   *
   * The start date time is obtained by taking the start date of the input
   * date time range in the user time zone and defaulting the time part to
   * midnight of that day(i.e 00:00). The end date time is obtained by taking
   * the end date of the input date time range in the user time zone and
   * defaulting the time part to the last minute of that day(i.e 23:59).
   *
   * The start date time and end date time derived in the client time zone as
   * described above will be converted in to equivalent date time in server time
   * zone and stored in the database.
   *
   * @param dateTimeRange
   * The "lifetime" of the person in the client time zone.
   */
  void setDateTimeRange(final DateTimeRange dateTimeRange);
  // END, CR00320064
 
}

