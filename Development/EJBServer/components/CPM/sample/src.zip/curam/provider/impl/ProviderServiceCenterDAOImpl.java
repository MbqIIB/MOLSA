/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;

import curam.core.impl.CuramConst;
import curam.cpm.sl.entity.impl.ProviderServiceCenterAdapter;
import curam.cpm.sl.entity.struct.ProviderServiceCenterDtls;
import curam.taxonomy.sl.search.struct.POServiceKey;
import curam.taxonomy.sl.search.struct.ServiceCenterDetails;
import curam.taxonomy.sl.search.struct.ServiceCenterDetailsList;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;


/**
 * Data access for {@linkplain curam.provider.impl.ProviderServiceCenter}.
 */
// BEGIN, CR00183213, SS
public class ProviderServiceCenterDAOImpl extends StandardDAOImpl<ProviderServiceCenter, ProviderServiceCenterDtls> implements
  ProviderServiceCenterDAO {
  // END, CR00183213
  /**
   * Instantiate the adapter.
   */
  protected static final ProviderServiceCenterAdapter adapter = new ProviderServiceCenterAdapter();

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderServiceCenterDAOImpl() {
    // END, CR00183213
    super(adapter, ProviderServiceCenter.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<ProviderServiceCenter> searchBy(final Provider provider) {
    return newSet(adapter.searchBy(provider.getID()));
  }

  // BEGIN, CR00208260, VR
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ServiceCenterDetailsList searchByProviderOffering(
    final POServiceKey poServiceKey) throws AppException,
      InformationalException {
   
    StringBuilder serviceCenterQuery = new StringBuilder();
    StringBuilder selectQuery = new StringBuilder();
    StringBuilder intoQuery = new StringBuilder();
    StringBuilder fromQuery = new StringBuilder();
    StringBuilder whereQuery = new StringBuilder();

    selectQuery.append("SELECT PSC.PROVIDERSERVICECENTERID,PSC.NAME,SO.NAME,");
    selectQuery.append(
      "(SELECT SHORTTEXT FROM LOCALIZABLETEXT LT, TEXTTRANSLATION TTR ");
    selectQuery.append("WHERE SO.NAMETEXTID = LT.LOCALIZABLETEXTID  ");
    selectQuery.append(
      "AND LT.LOCALIZABLETEXTID = TTR.LOCALIZABLETEXTID) LOCALIZEDNAME,");
    selectQuery.append(
      "(SELECT ADDRESS.ADDRESSDATA FROM ADDRESS, PROVIDERSERVICECENTER ");
    selectQuery.append(
      "WHERE ADDRESS.ADDRESSID = PROVIDERSERVICECENTER.ADDRESSID ");
    selectQuery.append(
      "AND  PROVIDERSERVICECENTER.PROVIDERSERVICECENTERID = PSC.PROVIDERSERVICECENTERID) ADDRESSID,");
    selectQuery.append(
      "(SELECT EMAILADDRESS.EMAILADDRESS FROM EMAILADDRESS,PROVIDERSERVICECENTER ");
    selectQuery.append(
      "WHERE EMAILADDRESS.EMAILADDRESSID = PROVIDERSERVICECENTER.EMAILADDRESSID ");
    selectQuery.append(
      "AND PROVIDERSERVICECENTER.PROVIDERSERVICECENTERID = PSC.PROVIDERSERVICECENTERID) EMAILID,");
    selectQuery.append(
      "(SELECT WEBADDRESS.WEBADDRESS FROM WEBADDRESS,PROVIDERSERVICECENTER ");
    selectQuery.append(
      "WHERE WEBADDRESS.WEBADDRESSID = PROVIDERSERVICECENTER.WEBADDRESSID  ");
    selectQuery.append(
      "AND PROVIDERSERVICECENTER.PROVIDERSERVICECENTERID = PSC.PROVIDERSERVICECENTERID) WEBID,");
    selectQuery.append(
      "(SELECT PHONENUMBER.PHONENUMBER FROM PHONENUMBER, PROVIDERSERVICECENTER WHERE ");
    selectQuery.append(
      "PHONENUMBER.PHONENUMBERID = PROVIDERSERVICECENTER.PHONENUMBERID ");
    selectQuery.append(
      " AND PROVIDERSERVICECENTER.PROVIDERSERVICECENTERID = PSC.PROVIDERSERVICECENTERID) PHONENUMBERID ");

    intoQuery.append(
      " INTO :providerServiceCenterID, :name, :poName, :poLocaleName, :address, :emailAddress, :webAddress, :phoneNumber ");

    fromQuery.append(
      "  FROM PROVIDERSERVICECENTER PSC,PROVIDER PR,PROVIDEROFFERING PO ,SERVICEOFFERING SO ");

    whereQuery.append(
      " WHERE PSC.PROVIDERCONCERNROLEID = PR.PROVIDERCONCERNROLEID ");
    whereQuery.append(
      " AND PR.PROVIDERCONCERNROLEID = PO.PROVIDERCONCERNROLEID ");
    whereQuery.append(" AND SO.SERVICEOFFERINGID = PO.SERVICEOFFERINGID ");
    whereQuery.append(" AND PO.PROVIDEROFFERINGID = :providerOfferingID ");
    whereQuery.append(" AND PO.RECORDSTATUS = :poStatus ");
    whereQuery.append(" AND PR.RECORDSTATUS = :prStatus ");
    whereQuery.append(" AND PSC.RECORDSTATUS = :pscStatus ");   
    
    serviceCenterQuery.append(selectQuery);
    serviceCenterQuery.append(intoQuery);
    serviceCenterQuery.append(fromQuery);
    serviceCenterQuery.append(whereQuery);
    
    CuramValueList<ServiceCenterDetails> valueList = DynamicDataAccess.executeNsMulti(
      ServiceCenterDetails.class, poServiceKey, false,
      serviceCenterQuery.toString());
    ServiceCenterDetailsList detailsList = new ServiceCenterDetailsList();

    for (ServiceCenterDetails details : valueList) {
      if (details.poLocaleName != null
        || !details.poLocaleName.equals(CuramConst.gkEmpty)) {
        details.poName = details.poLocaleName;
        detailsList.scDetails.addRef(details);
      }
    }
   
    return detailsList;
  }
  // END, CR00208260
}
