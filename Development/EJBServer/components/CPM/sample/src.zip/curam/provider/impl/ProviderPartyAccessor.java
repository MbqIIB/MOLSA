/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.participant.impl.ConcernRoleAccessor;
import curam.util.persistence.StandardEntity;


/**
 * Accessor interface for {@linkplain ProviderParty}.
 *
 */
public interface ProviderPartyAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * Gets the provider organization of the party.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return ProviderOrganization associated with the Party.
   */
  ProviderOrganizationAccessor getProviderOrganization();

  // ___________________________________________________________________________
  /**
   * Gets the party related to the provider organization.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return ConcernRole of the the party related to the provider organization.
   */
  ConcernRoleAccessor getParty();

  // ___________________________________________________________________________
  /**
   * Gets the category of the provider organization.
   *
   * @return ProviderPartyCategoryEntry the category of the party.
   */
  ProviderPartyCategoryEntry getCategory();

  // ___________________________________________________________________________
  /**
   * Gets the code for the type of the party's relationship with the provider
   * organization.
   *
   * @return String containing the code for the type of the party's relationship
   * with the provider organization
   */

  String getType();
}
