/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.Singleton;
import curam.cpm.sl.entity.impl.ProviderMemberOfferingAdapter;
import curam.cpm.sl.entity.struct.ProviderMemberOfferingDtls;
import curam.util.persistence.StandardDAOImpl;
import java.util.Set;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ProviderMemberOfferingDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ProviderMemberOfferingDAOImpl extends StandardDAOImpl<ProviderMemberOffering, ProviderMemberOfferingDtls>
  implements ProviderMemberOfferingDAO {
  // END, CR00183213
  /**
   * Adapter
   */
  protected static final ProviderMemberOfferingAdapter adapter = new ProviderMemberOfferingAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  // END, CR00183213
  protected ProviderMemberOfferingDAOImpl() {
    super(adapter, ProviderMemberOffering.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderMemberOffering> searchByProviderParty(
    final long providerPartyID) {

    return newSet(adapter.searchByProviderParty(providerPartyID));
  }
}
