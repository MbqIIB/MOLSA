/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.HashSet;
import java.util.Set;

import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.impl.EnvVars;
import curam.cpm.sl.entity.impl.ProviderPartyAdapter;
import curam.cpm.sl.entity.struct.ProviderPartyDtls;
import curam.cpm.sl.entity.struct.SearchMembershipHistoryKey;
import curam.cpm.sl.entity.struct.SearchPartyByRefNoTypeName;
import curam.cpm.sl.entity.struct.SearchRefNumDetails;
import curam.util.dataaccess.CuramValueList;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import curam.util.resources.Configuration;


/**
 * Standard implementation of {@linkplain curam.provider.impl.ProviderMemberDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ProviderMemberDAOImpl extends StandardDAOImpl<ProviderMember, ProviderPartyDtls> implements
  ProviderMemberDAO {
  // END, CR00183213
  /**
   * Initializing the adapter
   */
  protected static final ProviderPartyAdapter adapter = new ProviderPartyAdapter();

  /**
   * Provider DAO class
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderMemberDAOImpl() {
    // END, CR00183213
    super(adapter, ProviderMember.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<ProviderMember> searchBy(final ProviderOrganization providerOrganization) {
    return newSet(
      adapter.searchByProviderOrganizationAndCategory(
        providerOrganization.getID(),
        ProviderPartyCategoryEntry.MEMBER.getCode()));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ProviderMember searchByReferenceNumber(SearchRefNumDetails searchRefNumDetails) {

    ProviderPartyDtls providerPartyDtls = adapter.readByCategoryRefNumber(
      searchRefNumDetails.category, searchRefNumDetails.currentDate,
      searchRefNumDetails.referenceNumber);

    return providerMemberDAO.get(providerPartyDtls.providerPartyID);

  }

  /**
   * {@inheritDoc}
   */
  public ProviderMember searchByTypeNameAndProviderRefNo(SearchPartyByRefNoTypeName searchDetails) {

    // BEGIN, CR00167045, SK
    searchDetails.name = searchDetails.name.toUpperCase();
    // END, CR00167045
    ProviderPartyDtls providerPartyDtls = adapter.readByTypeNameProvRefNo(
      searchDetails.providerConcernRoleID, searchDetails.partyConcernRoleID,
      searchDetails.name, searchDetails.currentDate, searchDetails.type,
      searchDetails.category);

    return providerMemberDAO.get(providerPartyDtls.providerPartyID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<ProviderMember> listPersonMembershipHistory
    (Long partyConcernRoleID, ProviderPartyCategoryEntry category, RECORDSTATUSEntry status) {

    boolean searchByStatus = true;

    // Check if the record status is set
    if (status.equals(RECORDSTATUSEntry.NOT_SPECIFIED)
      || "".equals(status.getCode())) {
      searchByStatus = false;
    }

    // BEGIN, CR00170625, KR
    Set<ProviderMember> providerMemberSet = new HashSet<ProviderMember>();

    if (Configuration.getBooleanProperty(EnvVars.ENV_DYNAMIC_SQL_ENABLED)) {

      try {

        providerMemberSet = searchForPersonMembershipHistoryDynamicSql(
          partyConcernRoleID, category, status, searchByStatus);
      } catch (AppException appException) {
        throw new AppRuntimeException(appException);
      } catch (InformationalException infExp) {
        throw new AppRuntimeException(infExp);
      }
    } else {

      providerMemberSet = newSet(
        adapter.searchForPersonMembershipHistory(partyConcernRoleID,
        category.getCode(), status.getCode(), searchByStatus));
    }

    return providerMemberSet;
    // END, CR00170625
  }

  // BEGIN, CR00170625, KR
  /**
   * Builds and executes the dynamic query to search provider member based on
   * category and status.
   */
  protected Set<ProviderMember> searchForPersonMembershipHistoryDynamicSql(
    Long partyConcernRoleID, ProviderPartyCategoryEntry category,
    RECORDSTATUSEntry status, boolean searchByStatus) throws AppException,
      InformationalException {

    ProviderPartyDtls[] providerPartyDtlsList = new ProviderPartyDtls[0];

    if (isAnyProviderPartyCriteriaEntered(partyConcernRoleID, category,
      searchByStatus)) {

      StringBuilder providerPartySearchQuery = new StringBuilder();
      StringBuilder selectBuilder = new StringBuilder();
      StringBuilder intoBuilder = new StringBuilder();
      StringBuilder fromBuilder = new StringBuilder();
      StringBuilder whereBuilder = new StringBuilder();

      selectFromProviderParty(selectBuilder, intoBuilder);
      fromBuilder.append(" FROM ProviderParty ");
      whereBuilder.append(" WHERE");

      SearchMembershipHistoryKey searchMembershipHistoryKey = new SearchMembershipHistoryKey();

      searchMembershipHistoryKey.category = category.getCode();
      searchMembershipHistoryKey.recordStatus = status.getCode();
      searchMembershipHistoryKey.partyConcernRoleID = partyConcernRoleID;

      providerPartyWhereCondition(searchByStatus, whereBuilder);

      buildFinalQuery(providerPartySearchQuery, selectBuilder, intoBuilder,
        fromBuilder, whereBuilder);

      CuramValueList curamValueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
        curam.cpm.sl.entity.struct.ProviderPartyDtls.class,
        searchMembershipHistoryKey, false, providerPartySearchQuery.toString());

      providerPartyDtlsList = new ProviderPartyDtls[curamValueList.size()];

      for (int i = 0; i < curamValueList.size(); i++) {
        providerPartyDtlsList[i] = (ProviderPartyDtls) curamValueList.get(i);
      }
    }
    return newSet(providerPartyDtlsList);
  }

  protected void buildFinalQuery(StringBuilder providerPartySearchQuery,
    StringBuilder selectBuilder, StringBuilder intoBuilder,
    StringBuilder fromBuilder, StringBuilder whereBuilder) {
    providerPartySearchQuery.append(selectBuilder);
    providerPartySearchQuery.append(intoBuilder);
    providerPartySearchQuery.append(fromBuilder);
    providerPartySearchQuery.append(whereBuilder);
  }

  protected void providerPartyWhereCondition(boolean searchByStatus,
    StringBuilder whereBuilder) {
    whereBuilder.append(
      " ProviderParty.partyConcernRoleID = :partyConcernRoleID");
    whereBuilder.append(" AND ProviderParty.category = :category");

    if (searchByStatus) {
      whereBuilder.append(" AND ProviderParty.recordStatus = :recordStatus");
    }
    whereBuilder.append(" ORDER BY ProviderParty.category");
  }

  protected boolean isAnyProviderPartyCriteriaEntered(Long partyConcernRoleID,
    ProviderPartyCategoryEntry category, boolean searchByStatus) {
    return partyConcernRoleID > 0 || searchByStatus
      || category.getCode().length() > 0;
  }

  protected void selectFromProviderParty(StringBuilder selectBuilder,
    StringBuilder intoBuilder) {
    selectBuilder.append(" SELECT");
    selectBuilder.append(" ProviderParty.providerPartyID,");
    selectBuilder.append(" ProviderParty.providerConcernRoleID,");
    selectBuilder.append(" ProviderParty.partyConcernRoleID,");
    selectBuilder.append(" ProviderParty.startDate,");
    // BEGIN, CR00320064, SSK
    selectBuilder.append(" ProviderParty.startDateTime,");
    selectBuilder.append(" ProviderParty.endDateTime,");
    // END, CR00320064
    selectBuilder.append(" ProviderParty.endDate,");
    selectBuilder.append(" ProviderParty.category,");
    selectBuilder.append(" ProviderParty.type,");
    selectBuilder.append(" ProviderParty.position,");
    selectBuilder.append(" ProviderParty.versionNo,");
    selectBuilder.append(" ProviderParty.recordStatus");
    intoBuilder.append(" INTO ");
    intoBuilder.append(" :providerPartyID,");
    intoBuilder.append(" :providerConcernRoleID,");
    intoBuilder.append(" :partyConcernRoleID,");
    intoBuilder.append(" :startDate,");
    intoBuilder.append(" :startDateTime,");
    intoBuilder.append(" :endDateTime,");
    intoBuilder.append(" :endDate,");
    intoBuilder.append(" :category,");
    intoBuilder.append(" :type,");
    intoBuilder.append(" :position,");
    intoBuilder.append(" :versionNo,");
    intoBuilder.append(" :recordStatus");
  }
  // END, CR00170625
}
