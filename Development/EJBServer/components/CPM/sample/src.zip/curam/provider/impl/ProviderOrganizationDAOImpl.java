/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.HashMap;
import java.util.Map;

import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.codetable.CONCERNROLETYPE;
import curam.core.impl.ConcernRoleAdapter;
import curam.core.struct.ConcernRoleDtls;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.util.exception.AppRuntimeException;
import curam.util.persistence.ReaderDAO;
import curam.util.type.CodeTableItemIdentifier;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ProviderOrganizationDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ProviderOrganizationDAOImpl implements ProviderOrganizationDAO {
  // END, CR00183213
  /**
   * concernRoleAdapter instance of ConcernRoleAdapter.
   */
  protected static final ConcernRoleAdapter concernRoleAdapter = new ConcernRoleAdapter();

  /**
   * Provider DAO object.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Provider group DAO object.
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /**
   * map of reader DAO
   */
  protected Map<String, ReaderDAO<Long, ? extends ProviderOrganization>> concreteReaderDAOs = null;

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderOrganizationDAOImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  // ___________________________________________________________________________
  /**
   * Lazily populates the map of concrete DAOs.
   *
   * Note that this map initialization cannot be done during construction,
   * because at that point the DAO variables have not yet been injected (and are
   * thus null).
   * @return returns the synchronized map of Reader DAO.
   */
  // BEGIN, CR00177241, PM
  protected synchronized Map<String, ReaderDAO<Long, ? extends ProviderOrganization>> getConcreteReaderDAOs() {
    // END, CR00177241
    if (concreteReaderDAOs == null) {

      concreteReaderDAOs = new HashMap<String, ReaderDAO<Long, ? extends ProviderOrganization>>();

      // create a map of the DAOs for the concrete types, keyed by
      // discriminator
      concreteReaderDAOs.put(CONCERNROLETYPE.PROVIDER, providerDAO);
      concreteReaderDAOs.put(CONCERNROLETYPE.PROVIDERGROUP, providerGroupDAO);
    }
    return concreteReaderDAOs;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ProviderOrganization get(final Long id) {

    // read the concern role entity to get the concern role type
    final ConcernRoleDtls concernRoleDtls = concernRoleAdapter.read(id, false);

    final String concernRoleType = concernRoleDtls.concernRoleType;

    // look up the concrete DAO in the map
    final ReaderDAO<Long, ? extends ProviderOrganization> concreteReaderDAO = getConcreteReaderDAOs().get(
      concernRoleType);

    if (concreteReaderDAO == null) {
      throw new AppRuntimeException(
        PROVIDERExceptionCreator.ERR_UNIMPLEMENTED_CONCERN_ROLE_TYPE(
          new CodeTableItemIdentifier(CONCERNROLETYPE.TABLENAME,
          concernRoleType)));
    }

    /*
     * delegate the retrieval of the provider organization to the appropriate
     * concrete DAO
     */
    return concreteReaderDAO.get(id);
  }
}
