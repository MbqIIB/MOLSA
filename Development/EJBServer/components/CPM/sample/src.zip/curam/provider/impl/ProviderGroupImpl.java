/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.impl.CURRENCYEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.contracts.impl.ContractVersion;
import curam.core.impl.ConcernRoleAdapter;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.ConcernRole;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorInsertDtls;
import curam.core.sl.infrastructure.impl.EIEvidenceInsertDtls;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.BankAccountDetails;
import curam.core.struct.ConcernDtls;
import curam.core.struct.ConcernRoleAddressDtls;
import curam.core.struct.ConcernRoleAlternateIDDtls;
import curam.core.struct.ConcernRoleContactDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRolePhoneNumberDtls;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.MaintainBankAccountKey;
import curam.core.struct.PhoneNumberDtls;
import curam.cpm.facade.struct.ConcernRoleAndUserNameDetails;
import curam.cpm.sl.entity.impl.ProviderGroupAdapter;
import curam.cpm.sl.entity.struct.ProviderGroupDtls;
import curam.cpm.sl.entity.struct.ProviderGroupEnrollmentReferenceKey;
import curam.cpm.sl.entity.struct.ProviderGroupKey;
import curam.cpm.sl.fact.ProviderNotificationFactory;
import curam.cpm.sl.intf.ProviderNotification;
import curam.cpm.sl.struct.ProviderNotificationKey;
import curam.events.PROVIDERGROUP;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.GENERALCONCERNExceptionCreator;
import curam.message.impl.PROVIDERGROUPExceptionCreator;
import curam.message.impl.PROVIDERSECURITYExceptionCreator;
import curam.provider.ProviderNotificationEvent;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.FrequencyPattern;
import curam.util.type.StringHelper;


/**
 * Standard implementation of {@linkplain curam.provider.impl.ProviderGroup}.
 */
// BEGIN, CR00183213, SS
public class ProviderGroupImpl extends ProviderOrganizationImpl<ProviderGroupDtls> implements ProviderGroup {
  // END, CR00183213

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for close events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderGroupCloseEvents> closeEventDispatcherFactory;

  /**
   * Event dispatcher for enroll events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderGroupEnrollEvents> enrollEventDispatcherFactory;

  /**
   * Event dispatcher for reopen events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderGroupReopenEvents> reopenEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderGroupModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  // BEGIN, CR00145043, CPM
  /**
   * Event dispatcher for getCommonApprovedProviderServiceOfferings events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderGroupGetCommonApprovedProviderServiceOfferingsEvents> getCommonApprovedProviderServiceOfferingsEventDispatcherFactory;

  // END, CR00145043

  /**
   * providerSecurity of type ProviderSecurity
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderGroupImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * instance of providerReferenceNumberStrategy;
   */
  @Inject
  ProviderReferenceNumberStrategy providerReferenceNumberStrategy;

  // BEGIN, CR00170638, GP
  /**
   * Reference to Provider Group Reference Number Generator.
   */
  @Inject
  ProviderGroupReferenceNumberGenerator providerGroupReferenceNumberGenerator;
  // END, CR00170638

  /**
   * Gets the status of the Provider Group.
   *
   * @return The status of the Provider Group.
   */
  public ProviderGroupStatusEntry getLifecycleState() {
    return ProviderGroupStatusEntry.get(getDtls().recordStatus);
  }

  /**
   * Inserts provider group enrollment details. Also adds the concern role
   * details, phone number details, concern role address details, concern role
   * contact details and concern role bank details.
   *
   * @param addressDtls
   * Contains address related values.
   * @param phoneNumberDtls
   * Contains phone number related values.
   * @param concernRolePhoneNumberDtls
   * Contains concern role phone details.
   * @param concernRoleDtls
   * Contains concern role details values.
   * @param concernRoleAddressDtls
   * Contains concern role address related values.
   * @param bankAccountDetails
   * Contains bank account related values.
   * @param representativeRegistrationDetails
   * Contains representative registration related values.
   * @param concernRoleContactDtls
   * Contains concern role contact related values.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_PROVIDERGROUP_XFV_CONTACT_TYPE_NOT_SELECTED} -
   * If contact type is not selected and name is entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_CONCERNROLEPHONE_XFV_PHONENUMBER_PHONETYPE_EMPTY} -
   * If phone area code is entered and phone number, phone type not
   * entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_PROVIDERGROUP_FV_NAME_MUST_BE_ENTERED} -
   * If provider group name is not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_CPMCOMMONMSG_XRV_PREFERRED_COMMUICATION_MUST_BE_ENTERED} -
   * If provider group preferred communication is not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_CONCERNROLEPHONE_XFV_PHONENUMBER_PHONETYPE} -
   * If phone number is not entered and phone type entered.
   * {@link curam.message.PROVIDERGROUP#ERR_CONCERNROLEPHONE_XFV_PHONEAREACODE_EMPTY} -
   * If phone number, phone type entered and phone area code is not
   * entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_CPMCOMMONMSG_XRV_PREFERRED_LANGUAGE_MUST_BE_ENTERED} -
   * If provider group preferred language is not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_PROVIDERGROUP_FV_NAME_IS_TOO_LONG} -
   * if If provider group name length exceeds the maximum length.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_CONCERNROLEPHONE_XFV_PHONETYPE_PHONENUMBER} -
   * If phone number is entered and phone type not entered.
   * {@link curam.message.PROVIDERGROUP#ERR_CONCERNROLEPHONE_XFV_PHONENUMBER_PHONETYPE} -
   * If phone number is not entered and phone type entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_PROVIDERGROUP_XFV_CONTACT_TYPE_AND_NAME_EMPTY} -
   * If both contact type and name is not entered.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_PROVIDERGROUP_XFV_CONTACT_TYPE_NOT_SELECTED} -
   * If contact type selected and name is not entered.
   */
  public void enroll(AddressDtls addressDtls, PhoneNumberDtls phoneNumberDtls,
    ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls,
    ConcernRoleDtls concernRoleDtls,
    ConcernRoleAddressDtls concernRoleAddressDtls,
    BankAccountDetails bankAccountDetails,
    RepresentativeRegistrationDetails representativeRegistrationDetails,
    ConcernRoleContactDtls concernRoleContactDtls) throws AppException,
      InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre enroll provider group event.
    enrollEventDispatcherFactory.get(ProviderGroupEnrollEvents.class).preEnroll(
      this, addressDtls, phoneNumberDtls, concernRolePhoneNumberDtls,
      concernRoleDtls, concernRoleAddressDtls, bankAccountDetails,
      representativeRegistrationDetails, concernRoleContactDtls);
    // END, CR00235789

    /*
     * Constant value for comments used in CONCERN table */
    final String kConcernComments = "";
    // unique id generator class
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // obtain current date
    Date currentDate = Date.getCurrentDate();

    // validate the input ProviderGroupEnrollmentDetails struct
    validateEnrollProviderGroupDetails(concernRoleDtls, phoneNumberDtls,
      representativeRegistrationDetails, concernRoleContactDtls,
      concernRolePhoneNumberDtls);

    /*
     * create concern obj */
    // variables for concern registration
    curam.core.intf.Concern concernObj = curam.core.fact.ConcernFactory.newInstance();
    ConcernDtls concernDtls = new ConcernDtls();
    long concernID = uniqueIDObj.getNextID();

    /*
     * insert into Concern table */
    concernDtls.concernID = concernID;
    concernDtls.creationDate = currentDate;
    concernDtls.name = concernRoleDtls.concernRoleName;
    concernDtls.comments = kConcernComments;

    // insert concern record
    concernObj.insert(concernDtls);

    long concernRoleID = uniqueIDObj.getNextID();
    // Concern role ID
    // (local)

    // generate unique positive number for reference number (less than or
    // equal
    // to 18-digits)

    // BEGIN, CR00170638, GP
    String alternateID = providerGroupReferenceNumberGenerator.generateReferenceNumber();
    // END, CR00170638

    /*
     * create instance of Address obj */
    // variables for address registration
    curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    long addressID = 0;

    /*
     * insert into Address table */
    addressObj.insert(addressDtls);
    addressID = addressDtls.addressID;

    /*
     * create instance of PhoneNumber obj if entered */
    // variables for phone number manipulation
    long phoneNumberID = 0;

    /*
     * insert into PhoneNumber table */
    if ((phoneNumberDtls.phoneNumber != null)
      && (phoneNumberDtls.phoneNumber.length() > 0)) {
      // run time object creation
      // variables for creating home phone number
      curam.core.intf.PhoneNumber phoneNumberObj = curam.core.fact.PhoneNumberFactory.newInstance();

      phoneNumberObj.insert(phoneNumberDtls);
      phoneNumberID = phoneNumberDtls.phoneNumberID;
    }

    /*
     * insert into ConcernRole */
    concernRoleDtls.concernID = concernID;
    concernRoleDtls.concernRoleID = concernRoleID;
    concernRoleDtls.primaryAddressID = addressID;
    concernRoleDtls.primaryAlternateID = alternateID;

    if (phoneNumberID != 0) {
      concernRoleDtls.primaryPhoneNumberID = phoneNumberID;
    }
    // concernRoleObj.insert(concernRoleDtls);
    // save details (create record)
    // Call the EvidenceController object and insert evidence
    // Evidence descriptor details
    EvidenceDescriptorInsertDtls evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();

    evidenceDescriptorInsertDtls.participantID = concernRoleDtls.concernRoleID;
    evidenceDescriptorInsertDtls.evidenceType = CASEEVIDENCE.CONCERNROLE;
    evidenceDescriptorInsertDtls.receivedDate = curam.util.type.Date.getCurrentDate();

    // Evidence Interface details
    EIEvidenceInsertDtls eiEvidenceInsertDtls = new EIEvidenceInsertDtls();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.descriptor.participantID = concernRoleDtls.concernRoleID;
    eiEvidenceInsertDtls.evidenceObject = concernRoleDtls;

    // Insert the evidence
    curam.core.sl.infrastructure.impl.EvidenceControllerInterface evidenceControllerObj = (curam.core.sl.infrastructure.impl.EvidenceControllerInterface) curam.core.sl.infrastructure.fact.EvidenceControllerFactory.newInstance();

    evidenceControllerObj.insertEvidence(eiEvidenceInsertDtls);

    /*
     * create instance of ProviderGroup Obj */
    // variables for product provider registration
    ProviderGroupEnrollmentReferenceKey providerGroupEnrollmentReferenceKey = new ProviderGroupEnrollmentReferenceKey();

    // insert into ProviderGroup table with ConcernRoleID created

    this.setID(concernRoleID);
    // this.setReferenceNumber(alternateID);
    // insert into ProviderGroup table

    // BEGIN, CR00170625, KR
    getDtls().name = concernRoleDtls.concernRoleName;
    getDtls().nameUpper = concernRoleDtls.concernRoleName.toUpperCase();
    // END, CR00170625

    super.insert();

    // construct the return value
    providerGroupEnrollmentReferenceKey.concernRoleID = concernRoleID;
    providerGroupEnrollmentReferenceKey.referenceNumber = alternateID;
    providerGroupEnrollmentReferenceKey.msg = "";

    /*
     * insert into ConcernRoleAlternateID */
    // variables for concern role alternate id manipulation
    curam.core.intf.ConcernRoleAlternateID concernRoleAlternateIDObj = curam.core.fact.ConcernRoleAlternateIDFactory.newInstance();
    ConcernRoleAlternateIDDtls concernRoleAlternateIDDtls = new ConcernRoleAlternateIDDtls();

    concernRoleAlternateIDDtls.concernRoleAlternateID = uniqueIDObj.getNextID();
    concernRoleAlternateIDDtls.concernRoleID = concernRoleID;
    concernRoleAlternateIDDtls.alternateID = alternateID; // positive
    // number
    // less than or equal
    // to 18-digits
    concernRoleAlternateIDDtls.typeCode = curam.codetable.CONCERNROLEALTERNATEID.REFERENCE_NUMBER;
    concernRoleAlternateIDDtls.startDate = currentDate;
    concernRoleAlternateIDDtls.endDate = Date.kZeroDate;
    concernRoleAlternateIDDtls.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

    // insert concern role alternate id record
    concernRoleAlternateIDObj.insert(concernRoleAlternateIDDtls);

    /*
     * create instance of concernRoleAddress obj */
    // variables for concern role address manipulation
    curam.core.intf.ConcernRoleAddress concernRoleAddressObj = curam.core.fact.ConcernRoleAddressFactory.newInstance();

    // insert into concernRoleAddress
    concernRoleAddressDtls.concernRoleAddressID = uniqueIDObj.getNextID();
    concernRoleAddressDtls.concernRoleID = concernRoleID;
    concernRoleAddressDtls.addressID = addressID;
    // insert concern role address
    concernRoleAddressObj.insert(concernRoleAddressDtls);

    /*
     * create instance of ConcernRolePhoneNumber obj */

    // insert only if row is entered into PhoneNumber table
    if (phoneNumberID != 0) {

      // variables for concern role phone number manipulation
      curam.core.intf.ConcernRolePhoneNumber concernRolePhoneNumberObj = curam.core.fact.ConcernRolePhoneNumberFactory.newInstance();

      // fill in the data structure
      concernRolePhoneNumberDtls.concernRoleID = concernRoleID;
      concernRolePhoneNumberDtls.phoneNumberID = phoneNumberID;
      // insert concernRolePhoneNumber
      concernRolePhoneNumberObj.insert(concernRolePhoneNumberDtls);
    }

    /*
     * create instance of concernRoleBankAccount obj and insert into
     * concernRoleBankAccount
     */
    curam.core.intf.MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = curam.core.fact.MaintainConcernRoleBankAcFactory.newInstance();
    MaintainBankAccountKey maintainBankAccountKey = new MaintainBankAccountKey();

    /*
     * insert into ConcernRoleBankAccount table */
    if ((bankAccountDetails.name.length()
      + bankAccountDetails.bankSortCode.length()
      + bankAccountDetails.typeCode.length()
      + bankAccountDetails.accountNumber.length())
        != 0) {
      // allowing the bankAccount entity to handle errors in missing
      // bank account information
      maintainBankAccountKey.concernRoleID = concernRoleID;
      maintainConcernRoleBankAcObj.createBankAccount(maintainBankAccountKey,
        bankAccountDetails);

    } /*
     * End of ConcernRoleBankAccount Creation */

    /*
     * create instance of ConcernRoleContact and insert into tables. The below
     * code takes care of creating a new concern, concernRole, alternateID and
     * insert into ConcernRoleContact table
     */
    // if the contact name is not blank you can register a contact
    if ((concernRoleContactDtls.name.length() > 0)
      || (concernRoleContactDtls.contactTypeCode.length() != 0)
      || (representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode.length()
        != 0)
        || (representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode.length()
          != 0)
          || (representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber.length()
            != 0)
            || (representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension.length()
              != 0)) {

      if (concernRoleContactDtls.contactTypeCode.length() == 0
        || concernRoleContactDtls.contactTypeCode.length() == 0) {

        throw curam.message.impl.BPOMAINTAINCONTACTSExceptionCreator.ERR_CONTACTS_XFV_NAME_TYPE_EMPTY();

      }

      // ConcernRoleContact manipulation variables
      curam.core.intf.ConcernRoleContact concernRoleContactObj = curam.core.fact.ConcernRoleContactFactory.newInstance();
      // Representative maintenance object
      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      // Call registerRepresentative
      representativeObj.registerRepresentative(
        representativeRegistrationDetails);

      // generate unique ID for contact details
      concernRoleContactDtls.contactID = uniqueIDObj.getNextID();

      // insert concern role information
      concernRoleContactDtls.contactConRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
      concernRoleContactDtls.concernRoleID = concernRoleID;
      // insert concernRoleContact
      concernRoleContactObj.insert(concernRoleContactDtls);
    } /*
     * End of ConcernRoleContactDetails creation */

    // create provider owner and supervisor
    curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();
    ConcernRoleAndUserNameDetails concernRoleAndUserNameDetails = new ConcernRoleAndUserNameDetails();

    concernRoleAndUserNameDetails.concernRoleID = concernRoleID;
    concernRoleAndUserNameDetails.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    maintainAdminConcernRole.setProviderOrganisationOwnerAndSupervisor(
      concernRoleAndUserNameDetails);

    // Send Provider Group Enrollment Notification
    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();

    ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = providerGroupEnrollmentReferenceKey.concernRoleID;
    providerNotificationKey.event = ProviderNotificationEventEntry.GROUP_REGISTRATION.getCode();
    providerNotificationKey.providerGroupID = providerGroupEnrollmentReferenceKey.concernRoleID;

    providerNotification.sendNotification(providerNotificationKey);

    // raise the insert event
    final Event event = new Event();

    event.eventKey = PROVIDERGROUP.PROVIDERGROUP_INSERTED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post enroll provider group event.
    enrollEventDispatcherFactory.get(ProviderGroupEnrollEvents.class).postEnroll(
      this, addressDtls, phoneNumberDtls, concernRolePhoneNumberDtls,
      concernRoleDtls, concernRoleAddressDtls, bankAccountDetails,
      representativeRegistrationDetails, concernRoleContactDtls);
    // END, CR00235789
  }

  /**
   * Modifies the provider group details. Validates and updates the provider
   * Group details. Also modifies the concern role details.
   *
   * @param concernRoleObj
   * it is of type ConcernRole
   * @param concernRoleDtls
   * it contains concern role related values.
   * @param versionNo
   * versionNo for modify the Provider group.
   *
   * @return ProviderGroupKey the provider group key.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_PROVIDERGROUP_FV_COMMENT_IS_TOO_LONG} -
   * if If comments length exceeds the maximum length.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_CPMCOMMONMSG_XRV_PREFERRED_COMMUICATION_MUST_BE_ENTERED} -
   * if If provider group preferred communication is not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_PROVIDERGROUP_FV_NAME_MUST_BE_ENTERED} -
   * if If provider group name is not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_CPMCOMMONMSG_XRV_PREFERRED_LANGUAGE_MUST_BE_ENTERED} -
   * if If provider group preferred language is not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_PROVIDERGROUP_FV_NAME_IS_TOO_LONG} -
   * if If provider group name length exceeds the maximum length.
   */
  public ProviderGroupKey modify(ConcernRole concernRoleObj,
    ConcernRoleDtls concernRoleDtls, int versionNo) throws AppException,
      InformationalException {

    // Calling validation
    validateProviderGroupDetails(concernRoleDtls);

    // Check if the provider group is already closed
    // Cannot modify Closed provider group
    if (this.getLifecycleState().equals(ProviderGroupStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_XRV_CANNOT_UPDATE_CLOSED_PROVIDERGROUP(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = concernRoleDtls.concernRoleID;
    ProviderGroupKey providerGroupKey = new ProviderGroupKey();

    providerGroupKey.providerGroupConcernRoleID = concernRoleDtls.concernRoleID;

    // BEGIN, CR00274149, GP
    getDtls().name = concernRoleDtls.concernRoleName;
    getDtls().nameUpper = concernRoleDtls.concernRoleName.toUpperCase();
    // END, CR00274149
    
    // Calling modify on provider group
    modify(versionNo);

    // Reading the ConcernRoleDtls from database and setting the modified
    // values

    // Calling the method modify on concern role
    concernRoleObj.modify(concernRoleKey, concernRoleDtls);

    // raise the modify event
    final Event event = new Event();

    event.eventKey = PROVIDERGROUP.PROVIDERGROUP_MODIFIED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    return providerGroupKey;
  }

  /**
   * {@inheritDoc}
   */
  public CURRENCYEntry getCurrencyType() {
    return CURRENCYEntry.get(getDtls().currencyType);
  }

  /**
   * {@inheritDoc}
   */
  public long getMethodOfPayment() {
    return getDtls().methodOfPayment;
  }

  /**
   * Gets the payment frequency for the Provider.
   *
   * @return The payment frequency for the Provider.
   */
  public String getPaymentFrequency() {
    return getDtls().paymentFrequency;
  }

  /**
   * Gets the currency type.
   *
   * @param value The currency type.
   */
  public void setCurrencyType(CURRENCYEntry value) {
    getDtls().currencyType = value.getCode();
  }

  /**
   * Gets the method of payment for the Provider.
   *
   * @param value The method of payment for the Provider.
   */
  public void setMethodOfPayment(long value) {
    getDtls().methodOfPayment = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setPaymentFrequency(String value) {
    getDtls().paymentFrequency = value;
  }

  /**
   * Sets the provider group concern role id.
   *
   * @param value
   * sets the provider group concern role id.
   */
  // BEGIN, CR00177241, PM
  protected void setID(final long value) {
    // END, CR00177241
    getDtls().providerGroupConcernRoleID = value;
  }

  /**
   * Sets the record status.
   *
   * @param value
   * contains record status of provider group.
   */
  // BEGIN, CR00177241, PM
  protected void setRecordStatus(ProviderGroupStatusEntry value) {
    // END, CR00177241
    getDtls().recordStatus = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {
    setRecordStatus(ProviderGroupStatusEntry.ACTIVE);
  }

  /**
   * Validates that all mandatory fields are "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>{@link curam.message.PROVIDERGROUP#ERR_CPMCOMMONMSG_XRV_PAYMENT_METHOD_MUST_BE_ENTERED} -
   * If method of payment is not entered.</li>
   * <li>{@link curam.message.PROVIDERGROUP#ERR_CPMCOMMONMSG_XRV_PAYMENT_FREQUENCY_MUST_BE_ENTERED} -
   * If payment frequency is not entered.</li>
   * <li>{@link curam.message.PROVIDERGROUP#ERR_CPMCOMMONMSG_XRV_CURRENCY_MUST_BE_ENTERED} -
   * If currency type is not entered. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    // if method of payment is empty
    if (this.getMethodOfPayment() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_PAYMENT_METHOD_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    // if payment frequency is empty
    if (FrequencyPattern.kZeroFrequencyPattern.equals(
      new FrequencyPattern(getDtls().paymentFrequency))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_PAYMENT_FREQUENCY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    // if currency type is empty
    if (this.getCurrencyType().equals(CURRENCYEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_CURRENCY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No Cross Field Validation
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No Cross Entity Validation
  }

  /**
   * This method validates the input fields for enrolling a provider group
   *
   * @param concernRoleDtls
   * it contains concern role related values
   * @param phoneNumberDtls
   * it contains phone number related values.
   * @param representativeRegistrationDetails
   * it contains representative registration Details.
   * @param concernRoleContactDtls
   * it contains concern role contact details.
   * @param concernRolePhoneNumberDtls
   * it contains concern role phone number details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void validateEnrollProviderGroupDetails(
    // END, CR00177241
    ConcernRoleDtls concernRoleDtls, PhoneNumberDtls phoneNumberDtls,
    RepresentativeRegistrationDetails representativeRegistrationDetails,
    ConcernRoleContactDtls concernRoleContactDtls,
    ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls)
    throws AppException, InformationalException {

    // validate name
    validateName(concernRoleDtls.concernRoleName.trim());

    // validate phone details
    validatePhoneDetails(concernRolePhoneNumberDtls.typeCode,
      phoneNumberDtls.phoneAreaCode, phoneNumberDtls.phoneNumber);

    // Preferred Language Not Entered.
    validatePreferredLanguage(concernRoleDtls.preferredLanguage);

    // Preferred Communication Not Entered.
    validatePreferredCommunication(concernRoleDtls.prefCommMethod);

    // validate contact details
    validateContactDetails(concernRoleContactDtls.contactTypeCode,
      concernRoleContactDtls.name,
      representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode,
      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode,
      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber,
      representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension);

    ValidationHelper.failIfErrorsExist();
  }

  /**
   * This method has the common validation done during creation and update
   *
   * @param concernRoleDtls -
   * ConcernRoleDtls
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void validateProviderGroupDetails(ConcernRoleDtls concernRoleDtls)
    // END, CR00177241
    throws AppException, InformationalException {

    // validate name
    validateName(concernRoleDtls.concernRoleName.trim());

    // Preferred Language Not Entered.
    validatePreferredLanguage(concernRoleDtls.preferredLanguage);

    // Preferred Communication Not Entered.
    validatePreferredCommunication(concernRoleDtls.prefCommMethod);

    // Comments Greater Than Two Hundred Characters.
    validateComments(concernRoleDtls.comments.trim());

  }

  /**
   * This method validates the name by checking 1. That the name is not empty 2.
   * The name is less than the maximum allowed size of 100 chars
   *
   * @param name
   * string
   * @throws InformationException
   * @throws AppException
   */
  // BEGIN, CR00177241, PM
  protected void validateName(String name) throws AppException,
      // END, CR00177241
      InformationalException {

    // validate that the name is not empty
    validateNameNotEmpty(name);

    // validate that the name is not greater than maximum length
    validateNameNotGreaterThanMaxLength(name);

  }

  /**
   * This method validates the provider group's name is not empty
   *
   * @param name
   * provider group name.
   */
  // BEGIN, CR00177241, PM
  protected void validateNameNotEmpty(String name) {
    // END, CR00177241

    if (StringHelper.isEmpty(name)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_FV_NAME_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * This method validates the provider group's name is not greater than maximum
   * allowed size of 56 chars
   *
   * @param name
   * provider group name.
   */
  // BEGIN, CR00177241, PM
  protected void validateNameNotGreaterThanMaxLength(String name) {
    // END, CR00177241

    if (name.length() > ProviderGroupAdapter.kMaxLength_name) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_FV_NAME_IS_TOO_LONG(
          ProviderGroupAdapter.kMaxLength_name),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    
    // BEGIN, CR00274149, GP
    int length = name.toUpperCase().length();

    if (ProviderGroupAdapter.kMaxLength_name < length) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_FV_NAME_EXCEEDS_MAXLIMIT(
          length, ProviderGroupAdapter.kMaxLength_name),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END, CR00274149
  }

  /**
   * This method validates whether provider group preferred language is entered.
   *
   * @param prefLanguage
   * provider group preferred language.
   */
  // BEGIN, CR00177241, PM
  protected void validatePreferredLanguage(String prefLanguage) {
    // END, CR00177241

    if (StringHelper.isEmpty(prefLanguage)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_PREFERRED_LANGUAGE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
    }

  }

  /**
   * This method validates whether provider group preferred communication method
   * is entered.
   *
   * @param prefCommMethod
   * provider group preferred communication.
   */
  // BEGIN, CR00177241, PM
  protected void validatePreferredCommunication(String prefCommMethod) {
    // END, CR00177241
    if (StringHelper.isEmpty(prefCommMethod)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_PREFERRED_COMMUICATION_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
    }

  }

  /**
   * This method validates the string comments is not greater than maximum
   * allowed size of 200 chars.
   *
   * @param comments
   * contains comments provided by the user.
   */
  // BEGIN, CR00177241, PM
  protected void validateComments(String comments) {
    // END, CR00177241

    if (comments.length() > ConcernRoleAdapter.kMaxLength_comments) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_FV_COMMENT_IS_TOO_LONG(
          ConcernRoleAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  /**
   * This method validates the phone details entered by the user.
   *
   * @param phoneType
   * contains the phone type
   * @param phoneAreaCode
   * contains the area code
   * @param phoneNumber
   * contains the phone number
   */
  // BEGIN, CR00177241, PM
  protected void validatePhoneDetails(String phoneType, String phoneAreaCode,
    // END, CR00177241
    String phoneNumber) {

    if ((phoneAreaCode.length() > 0)
      && (phoneNumber.length() == 0 && phoneType.length() == 0)) {

      ValidationHelper.addValidationError(
        curam.message.impl.BPOMAINTAINCONCERNROLEPHONEExceptionCreator.ERR_CONCERNROLEPHONE_XFV_PHONENUMBER_PHONETYPE_EMPTY());
    }

    if ((phoneType.length() == 0) && (phoneNumber.length() != 0)) {

      ValidationHelper.addValidationError(
        curam.message.impl.BPOMAINTAINCONCERNROLEPHONEExceptionCreator.ERR_CONCERNROLEPHONE_XFV_PHONETYPE_PHONENUMBER());
    }

    if ((phoneNumber.length() == 0) && (phoneType.length() != 0)) {

      ValidationHelper.addValidationError(
        curam.message.impl.BPOMAINTAINCONCERNROLEPHONEExceptionCreator.ERR_CONCERNROLEPHONE_XFV_PHONENUMBER_PHONETYPE());
    }

    // Phone area code must be entered
    if ((phoneNumber.length() != 0) && ((phoneType.length() != 0))
      && (phoneAreaCode.length() == 0)) {

      ValidationHelper.addValidationError(
        curam.message.impl.BPOMAINTAINCONCERNROLEPHONEExceptionCreator.ERR_CONCERNROLEPHONE_XFV_PHONEAREACODE_EMPTY());
    }

  }

  /**
   * This method validates the contact phone details entered
   *
   * @param contactType
   * contains the contact type
   * @param contactName
   * contains the contact name
   * @param contactPhoneCountryCode
   * contains the phone country code
   * @param contactPhoneAreaCode
   * contains the contact phone areaCode.
   * @param contactPhoneNumber
   * contains the contact phone number.
   * @param contactPhoneExtension
   * contains the contact phone extension.
   * @throws AppException
   * and InformationException
   */
  // BEGIN, CR00177241, PM
  protected void validateContactDetails(String contactType, String contactName,
    // END, CR00177241
    String contactPhoneCountryCode, String contactPhoneAreaCode,
    String contactPhoneNumber, String contactPhoneExtension)
    throws AppException, InformationalException {

    if ((contactPhoneCountryCode.length() != 0
      || contactPhoneAreaCode.length() != 0 || contactPhoneNumber.length() != 0
      || contactPhoneExtension.length() != 0)
        && (contactType.length() == 0 && contactName.length() == 0)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_XFV_CONTACT_TYPE_AND_NAME_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (contactType.length() == 0 && contactName.length() != 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_XFV_CONTACT_TYPE_NOT_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (contactName.length() == 0 && contactType.length() != 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_XFV_CONTACT_NAME_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  /**
   * {@inheritDoc}
   */
  public Set<ServiceOffering> getCommonApprovedProviderServiceOfferings(
    final ContractVersion contractVersion) {

    // BEGIN, CR00145043, CPM
    // Raise the pre getCommonApprovedProviderServiceOfferings provider group
    // events.
    getCommonApprovedProviderServiceOfferingsEventDispatcherFactory.get(ProviderGroupGetCommonApprovedProviderServiceOfferingsEvents.class).preGetCommonApprovedProviderServiceOfferings(
      this, contractVersion);
    // END, CR00145043

    final Set<ServiceOffering> commonApprovedProviderServiceOfferings = new HashSet<ServiceOffering>();

    // track whether this is the first provider being processed
    boolean firstProvider = true;

    for (final Provider provider : contractVersion.getProviders()) {
      // variable to hold the services approved to be offered by this
      // provider
      final Set<ServiceOffering> approvedServicesForProvider = new HashSet<ServiceOffering>();

      // get the provider offerings for this provider
      final Set<ProviderOffering> providerOfferings = provider.getProviderOfferings();

      // get the services for all APPROVED provider offerings
      for (final ProviderOffering providerOffering : providerOfferings) {
        if (providerOffering.getLifecycleState().equals(
          ProviderOfferingStatusEntry.APPROVED)) {
          approvedServicesForProvider.add(providerOffering.getServiceOffering());
        }
      }

      /**
       * To identify the common services, we proceed as follows:
       * <ul>
       * <li>for the first provider processed: initialize the set of common
       * services to be all the services approved to be offered by this first
       * provider; and</li>
       * <li>for subsequent providers: remove from the set any service not
       * approved to be offered by any subsequent provider.</li>
       * </ul>
       */

      if (firstProvider) {
        commonApprovedProviderServiceOfferings.addAll(
          approvedServicesForProvider);

        firstProvider = false;
      } else {

        /*
         * We use an explicit iterator so that we can remove entries from the
         * set whilst iterating through it.
         */
        for (final Iterator<ServiceOffering> i = commonApprovedProviderServiceOfferings.iterator(); i.hasNext();) {
          final ServiceOffering serviceOffering = i.next();

          if (!approvedServicesForProvider.contains(serviceOffering)) {
            i.remove();
          }
        }
      }

    }

    // BEGIN, CR00145043, CPM
    // Raise the post getCommonApprovedProviderServiceOfferings provider group
    // events.
    getCommonApprovedProviderServiceOfferingsEventDispatcherFactory.get(ProviderGroupGetCommonApprovedProviderServiceOfferingsEvents.class).postGetCommonApprovedProviderServiceOfferings(
      this, contractVersion, commonApprovedProviderServiceOfferings);
    // END, CR00145043

    return Collections.unmodifiableSet(commonApprovedProviderServiceOfferings);
  }

  // BEGIN, CR00388648, MR
  /**
   * Reopen the provider Group for the providing the services to an
   * organization's clients. Also notifies the provider group reopen and raises
   * a workflow event. Checks the provider group security to reopen the provider
   * group.
   *
   * Transitions the state to
   * {@linkplain curam.provider.impl.ProviderGroupStatusEntry#ACTIVE}, if it is
   * valid to reopen the provider Group.
   *
   * @param versionNo
   * the version number as previously retrieved.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_PROVIDERGROUP_XRV_ONLY_CLOSED_STATUS_CAN_BE_REOPENED}
   * -If Status of the provider group is not closed.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PROVIDERSECURITY#
   * ERR_PROVIDER_SECURITY_XRV_NO_ACCESS_TO_REOPEN}
   * - If the user is not owner/supervisor of the provider group.
   */
  // END, CR00388648
  public void reopen(int versionNo) throws InformationalException, AppException {

    // BEGIN, CR00235789, AK
    // Raise the pre reopen provider group event.
    reopenEventDispatcherFactory.get(ProviderGroupReopenEvents.class).preReopen(
      this, versionNo);
    // END, CR00235789

    // perform a security check
    
    // BEGIN, CR00388648, MR
    if (!providerSecurity.providerGroupSecurityCheckSucceeded(this)) {

      ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERSECURITYExceptionCreator.ERR_PROVIDER_SECURITY_XRV_NO_ACCESS_TO_REOPEN(
          TransactionInfo.getProgramUser()),
          ValidationManagerConst.kSetTwo,
          2);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00388648
	
    // variables for concern role manipulation
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // Read Concern role
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = getDtls().providerGroupConcernRoleID;
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Closed provider group can not be closed again
    if (!getLifecycleState().equals(ProviderGroupStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_XRV_ONLY_CLOSED_STATUS_CAN_BE_REOPENED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    setRecordStatus(ProviderGroupStatusEntry.ACTIVE);
    super.modify(versionNo);
    // Remove the end date and status to open and modify ConcernRole
    concernRoleDtls.endDate = curam.util.type.Date.kZeroDate;
    concernRoleDtls.statusCode = curam.codetable.CONCERNROLESTATUS.CURRENT;
    concernRoleObj.modify(concernRoleKey, concernRoleDtls);

    // Send Provider Group Closure Notification
    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();

    ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = getDtls().providerGroupConcernRoleID;
    providerNotificationKey.event = ProviderNotificationEvent.GROUP_REOPENING;
    providerNotificationKey.providerGroupID = getDtls().providerGroupConcernRoleID;

    providerNotification.sendNotification(providerNotificationKey);

    // raise the re open event.
    final Event event = new Event();

    event.eventKey = PROVIDERGROUP.PROVIDERGROUP_REOPENED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post reopen provider group event.
    reopenEventDispatcherFactory.get(ProviderGroupReopenEvents.class).postReopen(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Ceases the provider group business with the agency and raises a workflow
   * event. Checks the provider group security to ceases the provider group.
   *
   * Transitions the state to
   * {@linkplain curam.provider.impl.ProviderGroupStatusEntry#CLOSED}, if it is
   * valid to cease conducting business.
   *
   * @param versionNo
   * the version number as previously retrieved.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUP#ERR_PROVIDERGROUP_XRV_USER_CANNOT_CLOSE_CLOSED_PROVIDERGROUP}
   * -If Status of the provider group is already closed.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void close(int versionNo) throws InformationalException, AppException {

    // perform a security check
    providerSecurity.checkProviderGroupSecurity(this);

    // BEGIN, CR00235789, AK
    // Raise the pre close provider group event.
    closeEventDispatcherFactory.get(ProviderGroupCloseEvents.class).preClose(
      this, versionNo);
    // END, CR00235789

    // variables for concern role manipulation

    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // Read Concern role
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = getDtls().providerGroupConcernRoleID;
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Closed provider group can not be closed again
    if (getLifecycleState().getCode().equals(
      ProviderGroupStatusEntry.CLOSED.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_XRV_USER_CANNOT_CLOSE_CLOSED_PROVIDERGROUP(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    setRecordStatus(ProviderGroupStatusEntry.CLOSED);

    super.modify(versionNo);

    // Set the end date and status to closed and modify ConcernRole
    concernRoleDtls.endDate = Date.getCurrentDate();
    concernRoleDtls.statusCode = curam.codetable.CONCERNROLESTATUS.CLOSED;
    concernRoleObj.modify(concernRoleKey, concernRoleDtls);

    // Send Provider Group Closure Notification
    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();

    ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = getDtls().providerGroupConcernRoleID;
    providerNotificationKey.event = ProviderNotificationEventEntry.GROUP_CLOSURE.getCode();
    providerNotificationKey.providerGroupID = getDtls().providerGroupConcernRoleID;
    providerNotification.sendNotification(providerNotificationKey);

    // raise the close event
    final Event event = new Event();

    event.eventKey = PROVIDERGROUP.PROVIDERGROUP_CLOSED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post close provider group event.
    closeEventDispatcherFactory.get(ProviderGroupCloseEvents.class).postClose(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Modifies the provider group with the updated information.
   *
   * Checks the provider group security to modify the provider group.
   *
   * @param versionNo
   * Contains the version.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderGroupSecurity(this);

    // BEGIN, CR00235789, AK
    // Raise the pre modify provider group event.
    modifyEventDispatcherFactory.get(ProviderGroupModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify provider group event.
    modifyEventDispatcherFactory.get(ProviderGroupModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected ConcernRoleDtls getConcernRoleDtls() {
    return concernRoleAdapter.read(getDtls().providerGroupConcernRoleID, false);
  }

  /**
   * {@inheritDoc}
   */
  public SENSITIVITYEntry getSensitivity() {
    return SENSITIVITYEntry.get(getConcernRoleDtls().sensitivity);
  }

  // BEGIN, CR00228236, SK
  /**
   * {@inheritDoc}
   */
  public void checkSecurity() throws InformationalException {

    try {
      DataBasedSecurityResult dataBasedSecurityResult = checkConcernRoleSecurity();

      validateConcernRoleSecurityResult(dataBasedSecurityResult);
    } catch (AppException e) {
      ValidationHelper.addValidationError(e);
      ValidationHelper.failIfErrorsExist();
    }
  }

  /**
   * Validates the result of the concern role security and location check
   * ensuring the user has access rights for viewing this concern role.
   * <p>
   * If the result of the security check is false then the user does not have
   * access rights to view this concern role and an exception is thrown.
   * </p>
   *
   * @param dataBasedSecurityResult
   * the object containing the results from the security check
   * @throws InformationalException
   * {@link GENERALCONCERNExceptionCreator#ERR_CONCERNROLE_FV_SENSITIVE()}
   * if the user does not have access rights to view this concern role
   */
  protected void validateConcernRoleSecurityResult(
    final DataBasedSecurityResult dataBasedSecurityResult)
    throws InformationalException {

    if (!dataBasedSecurityResult.result) {
      ValidationHelper.addValidationError(
        GENERALCONCERNExceptionCreator.ERR_CONCERNROLE_FV_SENSITIVE());
      ValidationHelper.failIfErrorsExist();
    }
  }

  /**
   * Performs the security check for this concern role.
   *
   * @return An object containing the result of the security check
   * @throws InformationalException
   * Generic Informational Exception
   * @throws AppException
   * Generic Application Exception
   */
  protected DataBasedSecurityResult checkConcernRoleSecurity()
    throws AppException, InformationalException {
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    ParticipantSecurityCheckKey key = new ParticipantSecurityCheckKey();

    key.participantID = getID();
    key.type = LOCATIONACCESSTYPE.READ;

    return dataBasedSecurity.checkParticipantSecurity(key);
  }
  // END, CR00228236
}
