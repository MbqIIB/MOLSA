/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2009, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Date;


/**
 * Accessor interface for {@linkplain ProviderGroupAssociate}.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ProviderGroupAssociateAccessor extends StandardEntity {

  /**
   * Gets the immutable provider associated with the Provider Group.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return Immutable provider associated with the Provider Group.
   */
  ProviderAccessor getProvider();

  /**
   * Gets the immutable Provider Group associated.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return Immutable Provider Group associated.
   */
  ProviderGroupAccessor getProviderGroup();

  // BEGIN, CR00178886, ASN
  /**
   * Indicates whether the provider group should be accepting the payments on
   * behalf of the corresponding provider.
   *
   * @return An indicator telling whether the provider group should be accepting
   * the payments on behalf of the corresponding provider.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link ProviderGroupAssociate#isProviderGroupToRecievePayments(Date paymentDate)}
   * . To decide the payee using the provider group association
   * payment configuration for any given date, method
   * isProviderGroupToRecievePayments with a date parameter has been
   * introduced in the class ProviderGroupAssociate. See release
   * note: CR00178886.
   */
  @Deprecated
  boolean isGroupToReceivePayments();

  // END, CR00178886
  /**
   * Indicates whether this provider group associate is part of a contract.
   *
   * @return Whether this provider group associate is part of a contract.
   */
  boolean isPartOfContract();

  // BEGIN, CR00178886, ASN
  /**
   * Indicates whether the provider group should be receiving the payments on
   * behalf of the provider on a given date.
   *
   * @param paymentDate
   * The payment date based on which the provider group associate
   * payment configuration on a given date can be retrieved.
   *
   * @return An indicator telling whether the provider group should be receiving
   * the payments on behalf of the provider on a given date.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  boolean isProviderGroupToRecievePayments(Date paymentDate)
    throws AppException, InformationalException;

  // END, CR00178886
}
