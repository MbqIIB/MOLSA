/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Calendar;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.TRAININGPROGRAMPARTYSTATUSEntry;
import curam.core.impl.CuramConst;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.sl.entity.struct.ProviderBackgroundCheckDtls;
import curam.cpm.sl.entity.struct.ProviderBackgroundCheckList;
import curam.cpm.util.impl.TimeZoneUtil;
import curam.events.PROVIDERPARTY;
import curam.message.BACKGROUNDCHECK;
import curam.message.TRAININGPROGRAM;
import curam.message.impl.BACKGROUNDCHECKExceptionCreator;
import curam.message.impl.PROVIDERGROUPMEMBERExceptionCreator;
import curam.message.impl.TRAININGPROGRAMExceptionCreator;
import curam.training.impl.TrainingProgramMember;
import curam.training.impl.TrainingProgramMemberDAO;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.LifecycleHelper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTableEntry;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateTime;
import curam.util.type.DateTimeRange;
import curam.util.type.StringHelper;


/**
 * Standard implementation of {@linkplain curam.provider.impl.ProviderMember}.
 */
// BEGIN, CR00183213, SS
public class ProviderMemberImpl extends ProviderPartyImpl implements
  ProviderMember {
  // END, CR00183213

  // BEGIN, CR00122678, RPB
  /**
   * Provider Member Offering DAO Object
   */
  @Inject
  protected ProviderMemberOfferingDAO providerMemberOfferingDAO;

  // END, CR00122678

  // BEGIN CR00125418, MST
  // BEGIN CR00125992, MST
  @Inject
  protected ProviderMemberOfferingTrainingCriteria providerMemberOfferingTrainingCriteria;

  // END CR00125992
  // END CR00125418

  // BEGIN CR00127212, RD
  /**
   * Reference to Training Program Member DAO.
   */
  @Inject
  protected TrainingProgramMemberDAO trainingProgramMemberDAO;
  // END CR00127212

  // BEGIN, CR00197240, ASN
  /**
   * Reference to Provider Background Check DAO.
   */
  @Inject
  protected ProviderBackgroundCheckDAO providerBackgroundCheckDAO;

  /**
   * Reference to BackgroundCheck Failure Reason DAO.
   */
  @Inject
  protected BackgroundCheckFailureReasonDAO backgroundCheckFailureReasonDAO;

  // END, CR00197240

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderMemberImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213
  /**
   * {@inheritDoc}
   */
  public void setRole(ProviderMemberRoleEntry value) {
    setType(value.getCode());
  }

  /**
   * {@inheritDoc}
   */
  public ProviderMemberRoleEntry getRole() {
    return ProviderMemberRoleEntry.get(getType());
  }

  // BEGIN CR00117581, MST
  /**
   * {@inheritDoc}
   */
  public PROVIDERMEMBERPOSITIONEntry getPosition() {
    return PROVIDERMEMBERPOSITIONEntry.get(getDtls().position);
  }

  /**
   * {@inheritDoc}
   */
  public void setPosition(PROVIDERMEMBERPOSITIONEntry value) {
    getDtls().position = value.getCode();
  }

  // END CR00117581

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {
    super.setNewInstanceDefaults();
    setCategory(ProviderPartyCategoryEntry.MEMBER);
  }

  /**
   * Validates that all mandatory fields are "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.PROVIDERMEMBER#ERR_FV_ROLE_NOT_SELECTED} - If the provider
   * member is not selected. </li>
   *
   */
  @Override
  public void mandatoryFieldValidation() {
    super.mandatoryFieldValidation();

    // BEGIN, CR00205270, ASN
    if (ProviderPartyCategoryEntry.MEMBER.getCode().equals(
      getCategory().getCode())) {
      // Role must not be empty
      if (StringHelper.isEmpty(getType())) {
        ValidationHelper.addValidationError(
          curam.message.impl.PROVIDERMEMBERExceptionCreator.ERR_FV_ROLE_NOT_SELECTED());
      }
    }
    // END, CR00205270
  }

  /**
   * Validates that changes made to provider party entity on the database are
   * consistent with other entities.
   *
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.PROVIDERPARTY#ERR_XRV_FROM_DATE_EARLIER_THAN_REGISTRATION_DATE_OF_PROVIDER_ORGANIZATION}
   * - If the from date is before the enrollment date of the provider.  </li>
   *
   */
  @Override
  public void crossEntityValidation() {
    super.crossEntityValidation();
    // Validate from date if the party role is provider
    validateProviderPartyRole();
  }

  /**
   * This method validates fromDate if the party role is provider.
   *
   */
  // BEGIN, CR00177241, PM
  protected void validateProviderPartyRole() {
    // END, CR00177241

    // Check if the provider party role is provider
    if (getRole().equals(ProviderMemberRoleEntry.PROVIDER)) {

      // BEGIN, CR00320064, SSK
      Date providerRegisterationDate = new Date(
        TimeZoneUtil.getEquivalentServerCalendar(
          getProviderOrganization().getRegistrationDate())); 

      if (getDtls().startDate.before(providerRegisterationDate)) {

        // END, CR00320064
        ValidationHelper.addValidationError(
          curam.message.impl.PROVIDERPARTYExceptionCreator.ERR_XRV_FROM_DATE_EARLIER_THAN_REGISTRATION_DATE_OF_PROVIDER_ORGANIZATION(
            getDateRange().start(),
            getProviderOrganization().getRegistrationDate()));
      }
    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected CodeTableEntry getTypeCode() {
    return getRole();
  }

  /**
   * Stores a new provider member in the database. Raises a workflow event.
   *
   * @throws InformationalException
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();

    // raise the insert event.
    final Event event = new Event();

    event.eventKey = PROVIDERPARTY.PROVIDERPARTY_MEMBER_INSERTED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
  }

  /**
   * Modifies a provider member in the database.
   *
   * @param versionNo
   * Version Number.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERGROUPMEMBER#ERR_PROVIDER_GROUP_MEMBER_XRV_CANNOT_UPDATE_CANCELLED_PROVIDER_GROUP_MEMBER} -
   * If the provider member has been deleted and cannot be
   * updated.
   * {@link curam.message.TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_PROVIDERMEMBER_TO_DATE_ON_OR_AFTER_AUTHORIZED_DATE}
   * The provider member to date must be on or after the
   * authorized date of the training program.
   * {@link curam.message.TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_PROVIDERMEMBER_FROM_DATE_ON_OR_BEFORE_AUTHORIZED_DATE}
   * The provider member from date must be on or before the
   * authorized date of the training program.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // BEGIN, CR00205270, ASN
    if (ProviderPartyCategoryEntry.MEMBER.getCode().equals(
      getCategory().getCode())) {
      // Check if provider member is already canceled.
      if (getProviderOrganization().getConcernRoleType().getCode().equals(
        CONCERNROLETYPEEntry.PROVIDER.getCode())) {
        if (getDtls().recordStatus.equals(RECORDSTATUS.CANCELLED)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERGROUPMEMBERExceptionCreator.ERR_PROVIDER_GROUP_MEMBER_XRV_CANNOT_UPDATE_CANCELLED_PROVIDER_GROUP_MEMBER(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        }
        ValidationHelper.failIfErrorsExist();
      }
    }
    // END, CR00205270
    // BEGIN CR00127212, RD
    validateTrainingProgramDetails();
    // END CR00127212
    super.modify(versionNo);
  }

  // BEGIN, CR00122678, RPB

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancel(int versionNo) throws InformationalException {

    // Get provider member offerings for the provider party.
    for (ProviderMemberOffering providerMemberOffering : providerMemberOfferingDAO.searchByProviderParty(
      getID())) {
      // Cancel all the active provider member offerings for this provider member.
      // BEGIN, CR00278672, KRK
      if (!RECORDSTATUSEntry.CANCELLED.equals(
        providerMemberOffering.getLifecycleState())) {
        providerMemberOffering.cancel(providerMemberOffering.getVersionNo());
      }
      // END, CR00278672
    }
    super.cancel(versionNo);
  }

  // END, CR00122678


  // BEGIN CR00118010, MST
  // BEGIN CR00125418, MST
  /**
   * {@inheritDoc}
   */
  public InformationalMessageList validateTrainingProgramsForProviderMember(
    final String providerOfferings) throws InformationalException {
    // BEGIN CR00125992, MST
    InformationalMessageList informationalMessageList = providerMemberOfferingTrainingCriteria.checkProviderMemberTrainingProgram(
      providerOfferings, this);

    // END CR00125992
    // END CR00125418

    return informationalMessageList;
  }

  // END CR00118010

  // BEGIN CR00127212, RD
  /**
   * Validates if a provider member has associated training program with a
   * status of open or approved, the provider member from date must be on or
   * before the authorized date of the training program and the provider member
   * to date must be on or after the authorized date of the training program.
   *
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_PROVIDERMEMBER_TO_DATE_ON_OR_AFTER_AUTHORIZED_DATE}
   * The provider member to date must be on or after the authorized
   * date of the training program.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_PROVIDERMEMBER_FROM_DATE_ON_OR_BEFORE_AUTHORIZED_DATE}
   * The provider member from date must be on or before the authorized
   * date of the training program.
   */
  // BEGIN, CR00177241, PM
  protected void validateTrainingProgramDetails() throws InformationalException {
    // END, CR00177241

    Set<TrainingProgramMember> trainingProgramMemberSet = trainingProgramMemberDAO.retrieveMemberTrainingPrograms(
      RECORDSTATUSEntry.NORMAL.getCode(), getParty().getID());

    for (TrainingProgramMember trainingProgramMember : trainingProgramMemberSet) {

      // If a provider member has associated training program with a status
      // of open or approved, the provider member from date must be on or
      // before the authorized date of the training program and the provider
      // member to date must be on or after the authorized date of the training
      // program.
      if (trainingProgramMember.getLifecycleState().equals(
        TRAININGPROGRAMPARTYSTATUSEntry.OPEN)
          || trainingProgramMember.getLifecycleState().equals(
            TRAININGPROGRAMPARTYSTATUSEntry.APPROVED)) {

        if (!getDateRange().end().isZero()
          && getDateRange().end().before(
            trainingProgramMember.getTrainingProgram().getDateRange().start())) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_PROVIDERMEMBER_TO_DATE_ON_OR_AFTER_AUTHORIZED_DATE(
              getDateRange().end(),
              trainingProgramMember.getTrainingProgram().getDateRange().start()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
          ValidationHelper.failIfErrorsExist();
          break;
        }

        if (!getDateRange().start().isZero()
          && getDateRange().start().after(
            trainingProgramMember.getTrainingProgram().getDateRange().start())) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_PROVIDERMEMBER_FROM_DATE_ON_OR_BEFORE_AUTHORIZED_DATE(
              getDateRange().start(),
              trainingProgramMember.getTrainingProgram().getDateRange().start()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
          ValidationHelper.failIfErrorsExist();
          break;
        }
      }
    }
  }

  // END CR00127212

  // BEGIN, CR00197240, ASN
  // BEGIN, CR00197808, ASN
  /**
   * Gets all active background checks associated with a provider member.
   *
   * @param providerParty
   * Contains provider party object.
   *
   * @return List of background check details associated with a provider member.
   *
   * @throws InformationalException
   * {@link BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_XRV_NO_BACKGROUND_CHECK_FOUND}
   * -If no background check exists for the provider member.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderBackgroundCheckList getProviderMemberBackGroundCheck(
    final ProviderParty providerParty) throws AppException,
      InformationalException {
    ProviderBackgroundCheckList providerBackgroundCheckList = new ProviderBackgroundCheckList();

    InformationalMessageList infoMsgList = new InformationalMessageList();

    providerBackgroundCheckList.informationalMessageList = infoMsgList;

    Set<ProviderBackgroundCheck> providerMemberBackgroundChecks = LifecycleHelper.filter(
      providerBackgroundCheckDAO.searchByProviderMember(providerParty),
      RECORDSTATUSEntry.NORMAL);

    if (providerMemberBackgroundChecks.isEmpty()) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();
      AppException appException = BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_XRV_NO_BACKGROUND_CHECK_FOUND();

      informationalManager.addInformationalMsg(appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning);

      String[] warnings = informationalManager.obtainInformationalAsString();

      for (String warning : warnings) {
        InformationalMessage infoMessage = new InformationalMessage();

        infoMessage.messageTest = warning;
        infoMsgList.dtls.addRef(infoMessage);
      }

      return providerBackgroundCheckList;

    } else {

      for (ProviderBackgroundCheck providerMemberBackgroundCheck : providerMemberBackgroundChecks) {

        ProviderBackgroundCheckDtls providerBackgroundCheckDtls = new ProviderBackgroundCheckDtls();

        providerBackgroundCheckDtls.type = providerMemberBackgroundCheck.getType().getCode();
        providerBackgroundCheckDtls.result = providerMemberBackgroundCheck.getResult().getCode();
        providerBackgroundCheckDtls.requestDate = providerMemberBackgroundCheck.getDateRange().start();
        providerBackgroundCheckDtls.receiptDate = providerMemberBackgroundCheck.getDateRange().end();
        providerBackgroundCheckDtls.providerBackgroundCheckID = providerMemberBackgroundCheck.getID();
        providerBackgroundCheckDtls.recordStatus = providerMemberBackgroundCheck.getLifecycleState().getCode();
        // BEGIN, CR00205270, ASN
        providerBackgroundCheckList.providerBackgroundCheckDetails.addRef(
          providerBackgroundCheckDtls);
        // END, CR00205270
      }
    }
    return providerBackgroundCheckList;
  }

  // END CR00197808


  /**
   * {@inheritDoc}
   */
  public Set<BackgroundCheckFailureReason> getBackgroundCheckFailureReasons(
    final ProviderBackgroundCheck providerBackgroundCheck)
    throws AppException, InformationalException {

    return LifecycleHelper.filter(
      backgroundCheckFailureReasonDAO.searchBy(providerBackgroundCheck),
      RECORDSTATUSEntry.NORMAL);

  }

  // END CR00197240

  // BEGIN, CR00205270, ASN
  /**
   * {@inheritDoc}
   */
  public void setCategory(ProviderPartyCategoryEntry category) {
    getDtls().category = category.getCode();
  }

  // END, CR00205270
  
  
  
  // BEGIN, CR00320064, SSK
  /**
   * Gets the start date and the end date of the provider member.
   *
   * @return The start date and the end date of the provider member.
   */
  public DateRange getDateRange() {

    if (getDtls().startDateTime.equals(DateTime.kZeroDateTime)
      && getDtls().endDateTime.equals(DateTime.kZeroDateTime)) {
      return new DateRange(getDtls().startDate, getDtls().endDate);
    }

    final Calendar clientStartDateTime = TimeZoneUtil.convertToClientTimeZone(
      getDtls().startDateTime.getCalendar());
    Calendar clientEndDateTime = getDtls().endDateTime.getCalendar();

    if (!DateTime.kZeroDateTime.equals(getDtls().endDateTime)) {
      clientEndDateTime = TimeZoneUtil.convertToClientTimeZone(
        getDtls().endDateTime.getCalendar());
    }
    return new DateRange(new Date(clientStartDateTime),
      new Date(clientEndDateTime));
  }

  /**
   * {@inheritDoc}
   */
  public void setDateTimeRange(final DateTimeRange dateTimeRange) {

    getDtls().startDateTime = dateTimeRange.start();
    getDtls().endDateTime = dateTimeRange.end();

  }

  // END, CR00320064
}
