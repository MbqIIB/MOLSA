/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.core.fact.SystemUserFactory;
import curam.core.intf.SystemUser;
import curam.cpm.sl.impl.LicenseStatusHistoryAdapter;
import curam.cpm.sl.struct.LicenseStatusHistoryDtls;
import curam.message.impl.LICENSEExceptionCreator;
import curam.util.exception.AppRuntimeException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.DateTime;
import curam.util.type.StringHelper;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.LicenseStatusHistory}.
 */
// BEGIN, CR00183213, SS
public class LicenseStatusHistoryImpl extends SingleTableEntityImpl<LicenseStatusHistoryDtls> implements
  LicenseStatusHistory, LicenseStatusHistoryCreator {

  /**
   * Constructor for the class.
   */
  protected LicenseStatusHistoryImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public DateTime getEventDateTime() {
    return getDtls().effectiveDateTime;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public LicenseStatusEntry getLicenseStatus() {
    return LicenseStatusEntry.get(getDtls().licenseStatus);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public LicenseRejectionReasonEntry getRejectionReason() {
    return LicenseRejectionReasonEntry.get(getDtls().rejectionReason);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public LicenseSuspensionReasonEntry getSuspensionReason() {
    return LicenseSuspensionReasonEntry.get(getDtls().suspensionReason);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getUser() {
    return getDtls().createdBy;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setLicense(final License license) {
    getDtls().licenseID = license == null ? 0 : license.getID();
    // Begin CR00096779, ABS
    if (license != null) {
      getDtls().licenseStatus = license.getLifecycleState().getCode();
    }
    // End CR00096779
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setRejectionReason(LicenseRejectionReasonEntry value) {
    getDtls().rejectionReason = value.getCode();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setSuspensionReason(LicenseSuspensionReasonEntry value) {
    getDtls().suspensionReason = value.getCode();
  }

  // ___________________________________________________________________________
  /**
   * Sets the comments.
   *
   * @param value The comments.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p> *
   * {@link curam.message.LICENSE#ERR_LICENSE_FV_FIELD_SIZE_MUST_BE_LT_OR_EQ} -
   * If the comments length is more than 200 characters.
   */
  public void setComments(String value) {
    getDtls().comments = StringHelper.trim(value);

    if (getComments().length()
      > LicenseStatusHistoryAdapter.kMaxLength_comments) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_FV_FIELD_SIZE_MUST_BE_LT_OR_EQ(
          LicenseStatusHistoryAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          3);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// None required
  }

  /**
   * Validates that all the field values held are valid with respect to each
   * other.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.LICENSE#ERR_LICENSE_FV_REASON_EMPTY} -If
   * license is rejected or suspended, the reason must be entered. </li>
   * </ul>
   */

  public void crossFieldValidation() {

    // rejection reason must be specified if and only if the status is rejected
    // suspension reason must be specified if and only if the status is
    // suspended
    if ((getLicenseStatus().equals(LicenseStatusEntry.REJECTED)
      && getRejectionReason().equals(LicenseRejectionReasonEntry.NOT_SPECIFIED))
        || (getLicenseStatus().equals(LicenseStatusEntry.SUSPENDED)
          && getSuspensionReason().equals(
            LicenseSuspensionReasonEntry.NOT_SPECIFIED))) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_FV_REASON_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// None required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {

    getDtls().effectiveDateTime = DateTime.getCurrentDateTime();

    // Create instance of System User
    final SystemUser user = SystemUserFactory.newInstance();

    try {
      getDtls().createdBy = user.getUserDetails().userName;
    } catch (final Exception e) {
      throw new AppRuntimeException(e);
    }

  }
}
