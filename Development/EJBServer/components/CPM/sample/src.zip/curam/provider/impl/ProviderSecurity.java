/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Implementable;


/**
 * ProviderSecurity describes user access checks to Provider and Provider Group
 * information.
 *
 * This is achieved by checking whether the user is active and has the
 * privileges of an Admin Concern Role for the specified provider or provider
 * group. Such users are authorized to access the Provider or Provider Group
 * Information.
 *
 */
@ImplementedBy(ProviderSecurityImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ProviderSecurity {

  /**
   * Verifies that currently working user has access rights to the provider
   * specified. If user does not have appropriate access right then a
   * standard error message is thrown.
   *
   * This is achieved by checking whether the user is active and has the
   * privileges of an Admin Concern Role for the specified provider.
   *
   * @param provider
   * The Provider for whom the security check has to be performed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderSecurityImpl#checkProviderSecurity(Provider)
   * The default implementation -
   * curam.provider.impl.ProviderSecurityImpl#checkProviderSecurity(Provider).
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  void checkProviderSecurity(final Provider provider)
    throws InformationalException;

  /**
   * Verifies that currently working user has access rights to the provider
   * specified.
   *
   * This is achieved by checking whether the user is active and has the
   * privileges of an Admin Concern Role for the specified provider.
   *
   * @param provider 
   * The Provider for whom the security check has to be performed.
   *
   * @return True if currently working user has access rights for the provider
   * specified. False, if user has no access rights.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  boolean providerSecurityCheckSucceeded(final Provider provider)
    throws InformationalException;

  /**
   * Verifies that currently working user has access rights to the
   * Facility Manager specified.
   *
   * @param provider
   * The Provider for whom the security check has to be performed.
   *
   * @return True if currently working user has access rights for the
   * provider specified. false, if user has no access rights.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  boolean facilityManagerSecurityCheckSucceeded(final Provider provider)
    throws InformationalException;

  /**
   * Verifies that currently working user has access rights to the provider
   * group specified. If user does not have appropriate access a standard
   * error message is thrown.
   *
   * This is achieved by checking whether the user is active and has the
   * privileges of an Admin Concern Role for the specified provider group.
   *
   * @param providerGroup
   * The Provider Group for whom the security check has to be performed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderSecurityImpl#checkProviderGroupSecurity(ProviderGroup)
   * The default implementation -
   * curam.provider.impl.ProviderSecurityImpl#checkProviderGroupSecurity(ProviderGroup).
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  void checkProviderGroupSecurity(final ProviderGroup providerGroup)
    throws InformationalException;

  /**
   * Verifies that currently working user has access rights to the provider
   * group specified.
   *
   * This is achieved by checking whether the user is active and has the
   * privileges of an Admin Concern Role for the specified provider group.
   *
   * @param providerGroup
   * The Provider Group for whom the security check has to be performed.
   *
   * @return True if currently working user has access rights for the provider
   * specified. False, if user has no access rights.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  boolean providerGroupSecurityCheckSucceeded(final ProviderGroup providerGroup)
    throws InformationalException;

  /**
   * Verifies that currently working user has access rights to the provider
   * organization specified. If user does not have appropriate access a
   * standard error message is thrown.
   *
   * This is achieved by checking whether the user is active and has the
   * privileges of an Admin Concern Role for the specified provider
   * organization.
   *
   * @param providerOrganization
   * The Provider Organization for whom the security check has to be performed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderSecurityImpl#checkProviderOrganizationSecurity(ProviderOrganization)
   * The default implementation -
   * curam.provider.impl.ProviderSecurityImpl#checkProviderOrganizationSecurity(ProviderOrganization).
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  void checkProviderOrganizationSecurity(
    final ProviderOrganization providerOrganization)
    throws InformationalException;

  /**
   * Verifies that currently working user has access rights to the provider
   * organization specified.
   *
   * This is achieved by checking whether the user is active and has the
   * privileges of an Admin Concern Role for the specified provider
   * organization.
   *
   * @param providerOrganization
   * The Provider Organization for whom the security check has to be performed.
   *
   * @return True if currently working user has access rights for the provider
   * specified. False, if user has no access rights.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  boolean providerOrganizationSecurityCheckSucceeded(
    final ProviderOrganization providerOrganization)
    throws InformationalException;

  /**
   * Verifies that the user specified is currently a supervisor for the provider
   * specified.
   *
   * Checks the Admin Roles for the Provider specified, the list returned will
   * contain the owners and supervisors of that Provider. If our user is in this
   * list, the concern role type is supervisor, and the dates match then they
   * are currently a supervisor for this Provider.
   *
   * @param provider
   * The Provider for whom the security check has to be performed.
   * @param userName
   * The user we are checking for.
   *
   * @return True if the user specified is currently a supervisor for the
   * provider specified. False, if user is not.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  boolean isUserProviderSupervisor(Provider provider, String userName)
    throws InformationalException;

  // BEGIN, CR00118611, JSP
  
  /**
   * Verifies that currently working user has access rights to the provider
   * specified. The user has the access rights to modify a provider details, if
   * the user is actual provider for the passed provider details or if the user
   * is the owner or supervisor for the provider.
   *
   * @param provider
   * The Provider for whom the security check has to be performed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  void checkUserSecurityForProvider(final Provider provider)
    throws AppException, InformationalException;
  // END, CR00118611

}
