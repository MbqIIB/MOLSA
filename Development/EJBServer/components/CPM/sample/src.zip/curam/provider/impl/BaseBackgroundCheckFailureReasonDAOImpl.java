/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import curam.cpm.sl.entity.impl.BackgroundCheckFailureReasonAdapter;
import curam.cpm.sl.entity.struct.BackgroundCheckFailureReasonDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Implementation for interface BaseBackgroundCheckFailureReasonDAO
 */
// BEGIN, CR00183213, SS
public class BaseBackgroundCheckFailureReasonDAOImpl extends StandardDAOImpl<BaseBackgroundCheckFailureReason, BackgroundCheckFailureReasonDtls>
  implements BaseBackgroundCheckFailureReasonDAO {
  // END, CR00183213
  /**
   * Initializing the adapter for Background Check Failure Reason
   */
  protected static final BackgroundCheckFailureReasonAdapter adapter = new BackgroundCheckFailureReasonAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected BaseBackgroundCheckFailureReasonDAOImpl() {
    // END, CR00183213
    super(adapter, BaseBackgroundCheckFailureReason.class);
  }

}
