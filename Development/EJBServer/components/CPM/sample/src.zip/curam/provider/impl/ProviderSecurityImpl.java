/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.core.sl.entity.fact.ExternalUserParticipantLinkFactory;
import curam.core.sl.entity.intf.ExternalUserParticipantLink;
import curam.core.sl.entity.struct.ExternalUserKey;
import curam.core.sl.entity.struct.ExternalUserParticipantLinkDtlsList;
import curam.core.struct.AdminConcernRoleDetails;
import curam.core.struct.AdminConcernRoleDetailsList;
import curam.core.struct.MaintainAdminConcernRoleKey;
import curam.message.PROVIDERSECURITY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * ProviderSecurityImpl - Default implementation for ProviderSecurity interface.
 * Checks user access rights for Provider and Provider Group information.
 *
 */
// BEGIN, CR00183213, SS
public class ProviderSecurityImpl implements ProviderSecurity {
  // END, CR00183213

  /**
   * Verifies that currently working user has access rights to the provider
   * specified. If user does not have appropriate access rights then a standard
   * error message is thrown.
   *
   * This is achieved by checking whether the user is active and has the
   * privileges of an Admin Concern Role for the specified provider.
   *
   * @param provider
   * The Provider for whom the security check has to be performed.
   *
   * @throws InformationalException
   * {@link PROVIDERSECURITY#ERR_PROVIDER_SECURITY_XRV_NO_ACCESS}- If
   * the user logged in does not have access rights.
   */
  public void checkProviderSecurity(final Provider provider)
    throws InformationalException {

    if (!providerSecurityCheckSucceeded(provider)) {

      AppException appEx = new AppException(
        PROVIDERSECURITY.ERR_PROVIDER_SECURITY_XRV_NO_ACCESS);

      // get current working user
      String userName = curam.util.transaction.TransactionInfo.getProgramUser();

      appEx.arg(userName);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        appEx, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
        2);
      ValidationHelper.failIfErrorsExist();
    }
  }

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderSecurityImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213

  /**
   * {@inheritDoc}
   */
  public boolean providerSecurityCheckSucceeded(final Provider provider)
    throws InformationalException {

    // get current working user
    String userName = curam.util.transaction.TransactionInfo.getProgramUser();

    boolean accessInd = false;

    accessInd = isUserOwnerOrSupervisor(provider.getID(), userName);

    return accessInd;

  }

  /**
   * {@inheritDoc}
   */
  public boolean facilityManagerSecurityCheckSucceeded(final Provider provider)
    throws InformationalException {

    String userName = curam.util.transaction.TransactionInfo.getProgramUser();

    boolean accessInd = false;

    accessInd = isUserOwnerOrSupervisor(provider.getID(), userName);

    return accessInd;

  }

  /**
   * Verifies that currently working user has access rights to the provider
   * group specified. If user does not have appropriate access a standard
   * error message is thrown.
   *
   * This is achieved by checking whether the user is active and has the
   * privileges of an Admin Concern Role for the specified provider group.
   *
   * @param providerGroup
   * The Provider Group for whom the security check has to be performed.
   *
   * @throws InformationalException
   * {@link PROVIDERSECURITY#ERR_PROVIDER_SECURITY_XRV_NO_ACCESS}-
   * If the user logged in is not the owner or supervisor.
   */
  public void checkProviderGroupSecurity(ProviderGroup providerGroup)
    throws InformationalException {

    if (!providerGroupSecurityCheckSucceeded(providerGroup)) {

      AppException appEx = new AppException(
        PROVIDERSECURITY.ERR_PROVIDER_SECURITY_XRV_NO_ACCESS);

      // get current working user
      String userName = curam.util.transaction.TransactionInfo.getProgramUser();

      appEx.arg(userName);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        appEx, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
        0);
      ValidationHelper.failIfErrorsExist();

    }
  }

  /**
   * {@inheritDoc}
   */
  public boolean providerGroupSecurityCheckSucceeded(ProviderGroup providerGroup)
    throws InformationalException {

    // get current working user
    String userName = curam.util.transaction.TransactionInfo.getProgramUser();

    boolean accessInd = false;

    accessInd = isUserOwnerOrSupervisor(providerGroup.getID(), userName);

    return accessInd;
  }

  /**
   * Verifies that currently working user has access rights to the provider
   * organization specified. If user does not have appropriate access a standard
   * error message is thrown.
   *
   * This is achieved by checking whether the user is active and has the
   * privileges of an Admin Concern Role for the specified provider
   * organization.
   *
   * @param providerOrganization
   * The Provider Organization for whom the security check has to be
   * performed.
   *
   * @throws InformationalException
   * {@link PROVIDERSECURITY#ERR_PROVIDER_SECURITY_XRV_NO_ACCESS}- If
   * the user logged in is not the owner or supervisor.
   */
  public void checkProviderOrganizationSecurity(
    final ProviderOrganization providerOrganization)
    throws InformationalException {

    if (!providerOrganizationSecurityCheckSucceeded(providerOrganization)) {

      AppException appEx = new AppException(
        PROVIDERSECURITY.ERR_PROVIDER_SECURITY_XRV_NO_ACCESS);

      // get current working user
      String userName = curam.util.transaction.TransactionInfo.getProgramUser();

      appEx.arg(userName);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        appEx, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
        1);
      ValidationHelper.failIfErrorsExist();

    }
  }

  /**
   * {@inheritDoc}
   */
  public boolean providerOrganizationSecurityCheckSucceeded(
    final ProviderOrganization providerOrganization)
    throws InformationalException {
    // get current working user
    String userName = curam.util.transaction.TransactionInfo.getProgramUser();

    boolean accessInd = false;

    accessInd = isUserOwnerOrSupervisor(providerOrganization.getID(), userName);

    return accessInd;
  }

  /**
   * Verifies that currently working user has access rights to the provider or
   * provider group specified.
   *
   * This is achieved by checking whether the user is active and has the
   * privileges of an Admin Concern Role for the specified provider or provider
   * group.
   *
   * @param concernRoleID
   * The concern role id of the Provider or Provider Group for whom the
   * security check has to be performed.
   * @param userName
   * The user we are checking for.
   *
   * @return True if currently working user is the owner or supervisor for the
   * provider or provider group specified. false, if user is neither.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected boolean isUserOwnerOrSupervisor(long concernRoleID, String userName)
    throws InformationalException {
    boolean userIsOwnerOrSupervisor = false;

    // AdminRole maintenance object and key
    curam.core.intf.MaintainAdminConcernRole maintainAdminConcernRole = curam.core.fact.MaintainAdminConcernRoleFactory.newInstance();

    // Read list of AdminRoles for this concern role ID
    // BEGIN, CR00235789, AK
    MaintainAdminConcernRoleKey maintainAdminConcernRoleKey = new MaintainAdminConcernRoleKey();
    Date today = Date.getCurrentDate();

    maintainAdminConcernRoleKey.concernRoleID = concernRoleID;
    AdminConcernRoleDetailsList adminConcernRoleDetailsList;

    try {
      adminConcernRoleDetailsList = maintainAdminConcernRole.readAdministratorsForConcernRole(
        maintainAdminConcernRoleKey);

      AdminConcernRoleDetails currentUser;
      DateRange currentDateRange;

      for (int i = 0; i < adminConcernRoleDetailsList.details.size(); i++) {
        currentUser = adminConcernRoleDetailsList.details.item(i);
        // END, CR00235789

        // if our user is on the list, check the dates match
        if (currentUser.userName.equals(userName)) {
          currentDateRange = new DateRange(currentUser.startDate,
            currentUser.endDate);
          // if user is still in date, return true
          if (currentDateRange.contains(today)) {
            userIsOwnerOrSupervisor = true;
            break;
          }
        }
      }
    } catch (AppException ex) {
      // add to validation helper and fail
      ValidationHelper.addValidationError(ex);
      ValidationHelper.failIfErrorsExist();
    }

    return userIsOwnerOrSupervisor;
  }

  /**
   * {@inheritDoc}
   */
  public boolean isUserProviderSupervisor(Provider provider, String userName)
    throws InformationalException {
    boolean userIsSupervisor = false;

    // AdminRole maintenance object and key
    curam.core.intf.MaintainAdminConcernRole maintainAdminConcernRole = curam.core.fact.MaintainAdminConcernRoleFactory.newInstance();

    // Read list of AdminRoles for this concern role ID
    // BEGIN, CR00235789, AK
    MaintainAdminConcernRoleKey maintainAdminConcernRoleKey = new MaintainAdminConcernRoleKey();
    Date today = Date.getCurrentDate();

    maintainAdminConcernRoleKey.concernRoleID = provider.getID();
    AdminConcernRoleDetailsList adminConcernRoleDetailsList;

    try {
      adminConcernRoleDetailsList = maintainAdminConcernRole.readAdministratorsForConcernRole(
        maintainAdminConcernRoleKey);

      AdminConcernRoleDetails currentUser;
      DateRange currentSupervisorDateRange;

      for (int i = 0; i < adminConcernRoleDetailsList.details.size(); i++) {
        currentUser = adminConcernRoleDetailsList.details.item(i);
        // END, CR00235789
        
        // if our user is on the list and is a supervisor
        // check the dates match
        if (currentUser.userName.equals(userName)
          && currentUser.typeCode.equals(
            curam.codetable.ADMINCONCERNROLETYPE.SUPERVISOR)) {
          currentSupervisorDateRange = new DateRange(currentUser.startDate,
            currentUser.endDate);
          // if still in date, return true
          if (currentSupervisorDateRange.contains(today)) {
            userIsSupervisor = true;
            break;
          }
        }
      }
    } catch (AppException ex) {
      // add to validation helper and fail
      ValidationHelper.addValidationError(ex);
      ValidationHelper.failIfErrorsExist();
    }
    return userIsSupervisor;
  }

  // BEGIN, CR00118611, JSP


  /**
   * {@inheritDoc}
   */
  public void checkUserSecurityForProvider(final Provider provider)
    throws AppException, InformationalException {

    boolean accessInd = false;

    // Check if the current user is actually a provider. If so, check if the
    // user can modify the passed provider details.
    ExternalUserParticipantLink externalUserParticipantLinkObj = ExternalUserParticipantLinkFactory.newInstance();
    ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();
    ExternalUserParticipantLinkDtlsList userList = externalUserParticipantLinkObj.searchByUsername(
      externalUserKey);

    for (int i = 0; i < userList.dtls.size(); i++) {
      if (userList.dtls.item(i).participantRoleID == provider.getID()) {
        accessInd = true;
      }
    }

    // Else, if user does not match to the passed provider, invoke provider
    // security check for the provider.
    if (!accessInd) {
      checkProviderSecurity(provider);
    }

  }
  // END, CR00118611

}
