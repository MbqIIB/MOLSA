/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain curam.provider.impl.ProviderType}.
 */
@ImplementedBy(ProviderTypeDAOImpl.class)
public interface ProviderTypeDAO extends StandardDAO<ProviderType> {

  /**
   * Searches the provider types for the provider category period specified.
   *
   * @param providerCategoryPeriod
   * the provider category period for which provider types are required
   * to be retrieved.
   * @return Set<ProviderType> the provider types for provider category period
   * specified.
   */
  Set<ProviderType> searchBy(final ProviderCategoryPeriod providerCategoryPeriod);

  // BEGIN, CR00157611, SG
  /**
   * Searches the provider types by provider type code.
   *
   * @param providerType
   * The provider type code.
   *
   * @return List of provider types matching the search criteria.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  Set<ProviderType> searchByType(final ProviderTypeNameEntry providerType)
    throws AppException, InformationalException;
  // END, CR00157611
}
