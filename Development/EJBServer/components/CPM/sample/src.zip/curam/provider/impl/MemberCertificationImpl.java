/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.Inject;

import curam.certification.impl.Certification;
import curam.certification.impl.CertificationDAO;
import curam.codetable.CERTIFICATIONCATEGORY;
import curam.codetable.CERTIFICATIONTYPE;
import curam.codetable.EXTERNALISSUER;
import curam.codetable.impl.MEMBERCERTIFICATIONSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.VALIDITYPERIODUNITSEntry;
import curam.core.fact.OrganisationFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.Organisation;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.struct.OrganisationDtls;
import curam.core.struct.OrganisationID;
import curam.core.struct.OrganisationKey;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.struct.MemberCertificationDtls;
import curam.message.impl.MEMBERCERTIFICATIONExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement.InformationalType;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.MemberCertification}.
 */
// BEGIN, CR00183213, SS
public class MemberCertificationImpl extends SingleTableLogicallyDeleteableEntityImpl<MemberCertificationDtls> implements
  MemberCertification {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for modifyCertification events.
   */
  @Inject
  protected EventDispatcherFactory<MemberCertificationModifyCertificationEvents> modifyCertificationEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<MemberCertificationInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<MemberCertificationModifyEvents> modifyEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<MemberCertificationCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for get derived status events.
   */
  @Inject
  protected EventDispatcherFactory<MemberCertificationGetDerivedStstusEvents> getDerivedStatusEventDispatcherFactory;

  // END, CR00235789

  /**
   * Certification DAO
   */
  @Inject
  protected CertificationDAO certificationDAO;

  /**
   * Certification DAO
   */
  @Inject
  protected MemberCertificationDAO memberCertificationDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected MemberCertificationImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213

  /**
   * {@inheritDoc}
   */
  public Certification getCertification() {

    final long certificationID = getDtls().certificationID;

    return certificationID == 0 ? null : certificationDAO.get(certificationID);
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {

    return getDtls().comments;
  }

  /**
   * {@inheritDoc}
   */
  public Date getDateOfExpiry() {

    return getDtls().dateOfExpiry;
  }

  /**
   * {@inheritDoc}
   */
  public Date getDateOfIssue() {

    return getDtls().dateOfIssue;
  }

  /**
   * {@inheritDoc}
   */
  public void setCertification(Certification certification) {

    if (certification != null) {
      getDtls().certificationID = certification.getID();
    }
  }

  /**
   * @param certificationID
   */
  public void setCertificationID(final long certificationID) {

    getDtls().certificationID = certificationID;
  }

  /**
   * {@inheritDoc}
   */
  public void setComments(final String comments) {

    getDtls().comments = comments;
  }

  /**
   * Sets the date of expiry for the member certification based on the
   * certification validity period and date of issue.
   *
   * @param dateOfExpiry
   * contains the date of expiry.
   */
  public void setDateOfExpiry(final Date dateOfExpiry) {

    int validityPeriod;

    // BEGIN, CR00137968, AK
    if (getDtls().certificationID != 0) {
      validityPeriod = certificationDAO.get(getDtls().certificationID).getValidityPeriod();
    } else {
      validityPeriod = 0;
    }
    // END, CR00137968

    // BEGIN CR00121516 KR
    if (dateOfExpiry.equals(Date.kZeroDate) && validityPeriod == 0) {

      getDtls().dateOfExpiry = Date.kZeroDate;

    } else if (dateOfExpiry.equals(Date.kZeroDate)) {

      // BEGIN CR00127283 KR
      VALIDITYPERIODUNITSEntry validatyPeriodUnits = certificationDAO.get(getDtls().certificationID).getValidityPeriodUnits();

      // BEGIN CR00128280 KR
      if (VALIDITYPERIODUNITSEntry.YEAR.equals(validatyPeriodUnits)) {
        getDtls().dateOfExpiry = getDateOfIssue().addDays(validityPeriod * 365);
      } else if (VALIDITYPERIODUNITSEntry.MONTH.equals(validatyPeriodUnits)) {
        getDtls().dateOfExpiry = getDateOfIssue().addDays(validityPeriod * 30);
      } else if (VALIDITYPERIODUNITSEntry.WEEK.equals(validatyPeriodUnits)) {
        getDtls().dateOfExpiry = getDateOfIssue().addDays(validityPeriod * 7);
      }
      // END CR00128280
      // END CR00127283

    } else {

      getDtls().dateOfExpiry = dateOfExpiry;
    }
    // END CR00121516
  }

  /**
   * {@inheritDoc}
   */
  public void setDateOfIssue(final Date dateOfIssue) {

    getDtls().dateOfIssue = dateOfIssue;
  }

  /**
   * {@inheritDoc}
   */
  public void setPartyconcernRoleID(final long partyconcernRoleID) {

    getDtls().partyConcernRoleID = partyconcernRoleID;
  }

  /**
   * {@inheritDoc}
   */
  public long getPartyConcernRoleID() {
    return getDtls().partyConcernRoleID;
  }

  /**
   * {@inheritDoc}
   */
  public RECORDSTATUSEntry getLifecycleState() {

    return RECORDSTATUSEntry.get(getDtls().recordStatus);
  }

  /**
   * Gets the derived status for the member certification record based on date
   * of expiry.
   *
   * @return The status of the member certification.
   */
  public MEMBERCERTIFICATIONSTATUSEntry getDerivedStstus() {

    // BEGIN, CR00235789, AK
    // Raise the pre get derived status member certification event.
    getDerivedStatusEventDispatcherFactory.get(MemberCertificationGetDerivedStstusEvents.class).preGetDerivedStstus(
      this);

    MEMBERCERTIFICATIONSTATUSEntry memberCertificationStatusEntry = MEMBERCERTIFICATIONSTATUSEntry.NOT_SPECIFIED;

    if (RECORDSTATUSEntry.NORMAL.equals(getLifecycleState())) {

      // BEGIN, CR00130667, ABS
      // BEGIN, CR00130651, ABS
      // Member certification status is Expired if a date of expiry
      // is on or before todays date.
      if (!Date.kZeroDate.equals(getDateOfExpiry())
        && (Date.getCurrentDate().after(getDateOfExpiry())
          || Date.getCurrentDate().equals(getDateOfExpiry()))) {
        // END, CR00130651
        // END, CR00130667
        memberCertificationStatusEntry = MEMBERCERTIFICATIONSTATUSEntry.EXPIRED;

      } else {
        memberCertificationStatusEntry = MEMBERCERTIFICATIONSTATUSEntry.ACTIVE;
      }
    } else {
      memberCertificationStatusEntry = MEMBERCERTIFICATIONSTATUSEntry.CANCELLED;
    }

    // Raise the post get derived status member certification event.
    getDerivedStatusEventDispatcherFactory.get(MemberCertificationGetDerivedStstusEvents.class).postGetDerivedStstus(
      this, memberCertificationStatusEntry);

    return memberCertificationStatusEntry;
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No implementation now
  }

  /**
   * Validates that all the field values held are valid with respect to each
   * other.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.MEMBERCERTIFICATION#ERR_MEMBERCERTFICATION_ISSUE_DATE_MUST_BEFORE_CURRENT_DATE}
   * - If the Date of Issue is after the current business date.</li>
   * <li>
   * {@link curam.message.MEMBERCERTIFICATION#ERR_MEMBERCERTFICATION_ISSUE_DATE_MUST_BEFORE_CURRENT}
   * - If the Date of Expiry is before the Date of Issue.</li>
   * </ul>
   */
  public void crossFieldValidation() {

    // BEGIN, CR00130662, AK
    if (getDtls().dateOfIssue.after(Date.getCurrentDate())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        MEMBERCERTIFICATIONExceptionCreator.ERR_MEMBERCERTFICATION_ISSUE_DATE_MUST_BEFORE_CURRENT_DATE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // END, CR00130662
    // BEGIN, CR00122407, ABS
    if (!getDateOfExpiry().equals(Date.kZeroDate)
      && getDateOfIssue().after(getDateOfExpiry())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        MEMBERCERTIFICATIONExceptionCreator.ERR_MEMBERCERTFICATION_FV_ISSUE_DATE_MUST_BEFORE_EXPIRY_DATE(
          getDateOfIssue(), getDateOfExpiry()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END, CR00122407
  }

  /**
   * Validates that all mandatory fields are populated.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.MEMBERCERTIFICATION#ERR_MEMBERCERTFICATION_FV_CERTIFICATION_TYPE_MUST_BE_ENTERED}
   * - If the certification type is not entered.</li>
   * <li>
   * {@link curam.message.MEMBERCERTIFICATION#ERR_MEMBERCERTFICATION_FV_DATE_OF_ISSUE_MUST_BE_ENTERED}
   * - If Date of Issue is not entered.</li>
   * </ul>
   *
   */
  public void mandatoryFieldValidation() {

    if (getDtls().certificationID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        MEMBERCERTIFICATIONExceptionCreator.ERR_MEMBERCERTFICATION_FV_CERTIFICATION_TYPE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if (getDtls().dateOfIssue.equals(Date.kZeroDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        MEMBERCERTIFICATIONExceptionCreator.ERR_MEMBERCERTFICATION_FV_DATE_OF_ISSUE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  /**
   * {@inheritDoc}
   */
  // BEGIN CR00121516 KR
  /**
   * Inserts the member certification record.
   *
   * @throws InformationalException
   * {@link curam.message.MEMBERCERTIFICATION#ERR_MEMBERCERTFICATION_ALREADY_EXIST}
   * - If an active member certification record exists with the same
   * certification type & issuer which has no date of expiry recorded
   * or has a date of expiry recorded that is after the date of issue.
   */
  @Override
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre insert member certification event.
    insertEventDispatcherFactory.get(MemberCertificationInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    // BEGIN CR00121512 KR
    for (MemberCertification memberCertification : memberCertificationDAO.searchActiveMemberCertificationByCertification(
      getDtls().certificationID)) {

      if (memberCertification.getPartyConcernRoleID()
        == getDtls().partyConcernRoleID) {

        try {
          String certificationType = CodeTable.getOneItem(
            CERTIFICATIONTYPE.TABLENAME,
            getCertification().getCertificationType().getCode());

          String certificationCategory = CodeTable.getOneItem(
            CERTIFICATIONCATEGORY.TABLENAME,
            getCertification().getCategory().getCode());

          String issuer = CodeTable.getOneItem(EXTERNALISSUER.TABLENAME,
            getCertification().getExternalIssuer().getCode());

          if (getCertification().isIssuedByAgency()) {
            Organisation organisationObj = OrganisationFactory.newInstance();
            OrganisationKey organisationKey = new OrganisationKey();
            OrganisationID organisationID = new OrganisationID();

            organisationID = organisationObj.readOrganisationID();
            organisationKey.organisationID = organisationID.organisationID;
            OrganisationDtls organisationDtls = new OrganisationDtls();

            organisationDtls = organisationObj.read(organisationKey);
            issuer = organisationDtls.name;

          } else if (!(getCertification().getOrganisationUnitId()
            == CPMConstants.kZeroLong)) {
            OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

            OrganisationUnitKey key = new OrganisationUnitKey();

            key.organisationUnitID = getCertification().getOrganisationUnitId();

            issuer = organisationUnitObj.read(key).name;

          }

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            MEMBERCERTIFICATIONExceptionCreator.ERR_MEMBERCERTFICATION_ALREADY_EXIST(
              certificationType, certificationCategory, issuer),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);

        } catch (AppException ex) {
          ValidationHelper.addValidationError(ex);
        }
      }
    }
    // END CR00121512
    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert member certification event.
    insertEventDispatcherFactory.get(MemberCertificationInsertEvents.class).postInsert(
      this);
    // END, CR00235789

  }

  // END CR00121516

  // BEGIN, CR00127684, NK
  /**
   * Checks Where a member certification date of issue has been modified & the
   * date of expiry is not updated, an informational message should display to
   * advise the user to consider updating the date of expiry.
   *
   * @param versionNo
   * Contains the versionNo of the record.
   *
   * @return List of informational messages.
   * {@link curam.message.MEMBERCERTIFICATION#ERR_MEMBERCERTFICATION_ISSUE_DATE_UPDATED_CONSIDER_UPDATE_EXPIRY_DATE}
   * -If Date of Issue has been updated, the Date of Expiry also need to
   * be updated.
   *
   * @throws InformationalException
   * {@link curam.message.MEMBERCERTIFICATION#ERR_MEMBERCERTFICATION_FV_DELTETED_CERT_CANNOT_BE_MODIFIED}
   * - The member certification cannot be modified if has already been
   * deleted.
   * @throws InformationalException
   * {@link curam.message.MEMBERCERTIFICATION#ERR_MEMBERCERTFICATION_ALREADY_EXIST}
   * - If an active member certification record exists with the same
   * certification type & issuer which has no date of expiry recorded
   * or has a date of expiry recorded that is after the date of issue.
   */
  public InformationalMessageList modifyCertification(Integer versionNo)
    throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre modifyCertification member certification event.
    modifyCertificationEventDispatcherFactory.get(MemberCertificationModifyCertificationEvents.class).preModifyCertification(
      this, versionNo);
    // END, CR00235789

    InformationalMessageList informationalMessageList = new InformationalMessageList();

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // BEGIN, CR00128761, KR
    if (getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        MEMBERCERTIFICATIONExceptionCreator.ERR_MEMBERCERTFICATION_FV_DELTETED_CERT_CANNOT_BE_MODIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00128761

    // BEGIN, CR00138839,AK
    for (MemberCertification memberCertification : memberCertificationDAO.searchActiveMemberCertificationByCertification(
      getDtls().certificationID)) {

      if (memberCertification.getID() != getDtls().memberCertificationID) {

        if (memberCertification.getPartyConcernRoleID()
          == getDtls().partyConcernRoleID) {

          try {
            String certificationType = CodeTable.getOneItem(
              CERTIFICATIONTYPE.TABLENAME,
              getCertification().getCertificationType().getCode());

            String certificationCategory = CodeTable.getOneItem(
              CERTIFICATIONCATEGORY.TABLENAME,
              getCertification().getCategory().getCode());

            String issuer = CodeTable.getOneItem(EXTERNALISSUER.TABLENAME,
              getCertification().getExternalIssuer().getCode());

            if (getCertification().isIssuedByAgency()) {
              Organisation organisationObj = OrganisationFactory.newInstance();
              OrganisationKey organisationKey = new OrganisationKey();
              OrganisationID organisationID = new OrganisationID();

              organisationID = organisationObj.readOrganisationID();
              organisationKey.organisationID = organisationID.organisationID;
              OrganisationDtls organisationDtls = new OrganisationDtls();

              organisationDtls = organisationObj.read(organisationKey);
              issuer = organisationDtls.name;

            } else if (!(getCertification().getOrganisationUnitId()
              == CPMConstants.kZeroLong)) {
              OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

              OrganisationUnitKey key = new OrganisationUnitKey();

              key.organisationUnitID = getCertification().getOrganisationUnitId();

              issuer = organisationUnitObj.read(key).name;

            }

            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              MEMBERCERTIFICATIONExceptionCreator.ERR_MEMBERCERTFICATION_ALREADY_EXIST(
                certificationType, certificationCategory, issuer),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                1);

          } catch (AppException ex) {
            ValidationHelper.addValidationError(ex);
          }
        }
      }
    }
    // END, CR00138839

    if (!getRowManager().getOriginalDtls().dateOfIssue.equals(
      getDtls().dateOfIssue)
        && getRowManager().getOriginalDtls().dateOfExpiry.equals(
          getDtls().dateOfExpiry)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        MEMBERCERTIFICATIONExceptionCreator.ERR_MEMBERCERTFICATION_ISSUE_DATE_UPDATED_CONSIDER_UPDATE_EXPIRY_DATE(
          getDtls().dateOfIssue, getDtls().dateOfExpiry),
          CuramConst.gkEmpty,
          InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Assign informational messages to return struct
    String warnings[] = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMessage infoMessage = new InformationalMessage();

      infoMessage.messageTest = warnings[i];
      informationalMessageList.dtls.addRef(infoMessage);
    }

    super.modify(versionNo);
    // BEGIN, CR00235789, AK
    // Raise the post modifyCertification member certification event.
    modifyCertificationEventDispatcherFactory.get(MemberCertificationModifyCertificationEvents.class).postModifyCertification(
      this, versionNo, informationalMessageList);
    // END, CR00235789

    return informationalMessageList;
  }

  // END, CR00127684

  // BEGIN, CR00235789, AK
  /**
   * {@inheritDoc}
   */
  @Override
  public void cancel(int versionNo) throws InformationalException {

    // Raise the pre cancel member certification event.
    cancelEventDispatcherFactory.get(MemberCertificationCancelEvents.class).preCancel(
      this, versionNo);

    super.cancel(versionNo);

    // Raise the post cancel member certification event.
    cancelEventDispatcherFactory.get(MemberCertificationCancelEvents.class).postCancel(
      this, versionNo);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // Raise the pre modify member certification event.
    modifyEventDispatcherFactory.get(MemberCertificationModifyEvents.class).preModify(
      this, versionNo);

    super.modify(versionNo);

    // Raise the post modify member certification event.
    modifyEventDispatcherFactory.get(MemberCertificationModifyEvents.class).postModify(
      this, versionNo);

  }

  // END, CR00235789
}
