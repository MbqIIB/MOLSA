/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.training.impl.TrainingAccessor;
import curam.util.persistence.StandardEntity;


/**
 * Accessor interface for {@linkplain LicenseTrainingRequirement}.
 */
public interface LicenseTrainingRequirementAccessor extends StandardEntity {

  /**
   * Gets the training completion.Indicates whether completion of the training
   * is required in order to get licensed.
   *
   * @return The training completion code.
   */
  TrainingCompletionEntry getCompletion();

  /**
   * Gets the removal reason for removing the training requirement from a
   * license type.
   *
   * @return The training removal reason.
   */
  TrainingRemovalReasonEntry getRemovalReason();

  /**
   * Gets the type of the license.
   *
   * @return The type of the license.
   */
  public LicenseTypeEntry getLicenseType();

  /**
   * Gets the immutable training details associated with license type.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The associated immutable training details.
   */
  TrainingAccessor getTraining();

}
