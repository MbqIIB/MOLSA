/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.StandardDAO;


/**
 * Data access for
 * {@linkplain curam.provider.impl.ReasonForNonCompliance}.
 */
@ImplementedBy(ReasonForNonComplianceDAOImpl.class)
public interface ReasonForNonComplianceDAO extends StandardDAO<ReasonForNonCompliance> {

  // ___________________________________________________________________________
  /**
   * Searches the non compliance reasons for the License specified.
   *
   * @param license
   * for which the non compliance reasons are to be retrieved.
   *
   * @return Set<ReasonForNonCompliance> the reasons for non compliance for the
   * license specified.
   */
  Set<ReasonForNonCompliance> searchByLicense(final License license);

}
