/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import curam.core.struct.SecurityResult;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.cpm.facade.struct.UserNameDetailsList;
import curam.message.PROVIDERENQUIRYSECURITY;
import curam.useradmin.impl.MaintainAdminConcernRole;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.transaction.TransactionInfo;


/**
 * ProviderEnquirySecurityCheckImpl - Default implementation for ProviderEnquirySecurityCheck
 * interface. Checks user access rights for Provider Enquiry information.
 *
 */
// BEGIN, CR00183213, SS
public class ProviderEnquirySecurityCheckImpl implements
  ProviderEnquirySecurityCheck {

  /**
   * Constructor for the class.
   */
  protected ProviderEnquirySecurityCheckImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws AppException
   */
  public void checkEnquirySecurity(ProviderEnquiry providerEnquiry)
    throws  InformationalException, AppException {

    // result object
    SecurityResult securityResult = new SecurityResult();

    // variables to read user details
    UsersKey usersKey = new UsersKey();

    usersKey.userName = TransactionInfo.getProgramUser();

    curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    UsersDtls programUserDtls = usersObj.read(usersKey);

    MaintainAdminConcernRole maintainAdminConcernRoleObj = new MaintainAdminConcernRole();
    UserNameDetailsList userNameDetailsList = new UserNameDetailsList();

    // if the enquiry owner is same program user,then program user is the owner,has access to enquiry details.
    if (providerEnquiry.getOwnerName().equals(programUserDtls.userName)) {
      securityResult.result = true;
    } else {

      // get the supervisor for the program user and check whether the program user is his supervisor,
      // if yes has access to enquiry details.
      usersKey.userName = providerEnquiry.getOwnerName();
      userNameDetailsList = maintainAdminConcernRoleObj.listSupervisorUser(
        usersKey);
      if (userNameDetailsList.detailsList.size() > 0) {
        for (int i = 0; i < userNameDetailsList.detailsList.size(); i++) {
          if (programUserDtls.userName.equals(
            userNameDetailsList.detailsList.item(i).userName)) {
            securityResult.result = true;
            break;
          }

        }

      }
    }

    if (!securityResult.result) {
      AppException appEx = new AppException(
        PROVIDERENQUIRYSECURITY.ERR_PROVIDER_ENQUIRY_SECURITY_XRV_NO_ACCESS);

      // get current working user
      String userName = curam.util.transaction.TransactionInfo.getProgramUser();

      appEx.arg(userName);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        appEx, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
        0);
      ValidationHelper.failIfErrorsExist();
    }

  }

}
