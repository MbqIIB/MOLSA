/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.util.persistence.StandardEntity;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * Accessor interface for {@linkplain  BackgroundCheck}.
 */
public interface BackgroundCheckAccessor extends StandardEntity {

  /**
   * Gets the type of Background Check being conducted.
   *
   * @return BackgroundCheckTypeEntry the type of the provider background check.
   */
  BackgroundCheckTypeEntry getType();

  /**
   * Gets the result of the Background Check.
   *
   * @return BackgroundCheckResultEntry the result of the provider background
   * check.
   */
  BackgroundCheckResultEntry getResult();

  /**
   * Gets the daterange(request date and receipt date) of the provider
   * Background Check.
   *
   * @return DateRange of the background check.
   */
  DateRange getDateRange();

  /**
   * Gets the expiry date of the provider Background Check.
   *
   * @return Date the expiry date of the background check.
   */
  Date getExpiryDate();

  /**
   * Gets the immutable provider member for whom Background Check to be done.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return Immutable Provider Member for whom background check to be done.
   */
  ProviderMemberAccessor getProviderMember();
}
