/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.cpm.sl.struct.ReasonForNonComplianceDtls;
import curam.message.impl.LICENSEExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ReasonForNonCompliance}.
 */
// BEGIN, CR00183213, SS
public class ReasonForNonComplianceImpl extends SingleTableEntityImpl<ReasonForNonComplianceDtls> implements
  // END, CR00183213
  ReasonForNonCompliance {

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ReasonForNonComplianceInsertEvents> insertEventDispatcherFactory;

  // END, CR00235789

  /**
   * Inject LicenseDAO
   */
  @Inject
  protected LicenseDAO licenseDAO;

  /**
   * Inject ReasonForNonComplianceDAO
   */
  @Inject
  protected ReasonForNonComplianceDAO reasonForNonComplianceDAO;

  /**
   * Inject ProviderSecurity
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * Inject ProviderDAO
   */
  @Inject
  protected ProviderDAO providerDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ReasonForNonComplianceImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /*
   * Field getters
   */

  /**
   * {@inheritDoc}
   */
  public String getNonComplianceReasons() {

    return getDtls().nonComplianceReasons;

  }

  /*
   * Field setters
   */
  
  /**
   * {@inheritDoc}
   */
  public void setLicense(License value) {

    getDtls().licenseID = value.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void setNonComplianceReasons(String value) {

    getDtls().nonComplianceReasons = value.trim();
  }

  /*
   * Related-entity getters
   */
  
  /**
   * {@inheritDoc}
   */
  public License getLicense() {
    final long licenseID = getDtls().licenseID;

    return licenseID == 0 ? null : licenseDAO.get(licenseID);
  }

  /**
   * Returns Provider
   *
   * @return Provider
   */
  public Provider getProvider() {
    final long licenseID = getDtls().licenseID;

    final curam.provider.impl.License license = licenseDAO.get(licenseID);

    final long id = license.getProvider().getID();

    return id == 0 ? null : providerDAO.get(id);
  }

  /**
   * @return the reason for non compliance records that exist a license
   */
  // BEGIN, CR00177241, PM
  protected Set<ReasonForNonCompliance> getReasonForNonComplianceRecords() {
    // END, CR00177241
    return reasonForNonComplianceDAO.searchByLicense(getLicense());
  }

  /**
   * Validates that changes made to reason for non compliance entity on the
   * database are consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.LICENSE#ERR_LICENSE_XRV_CANNOT_RENEW_LICENSE} -
   * If the license which is submitted for renewal is not in
   * "Approval" status. </li>
   * <li>
   * {@link curam.message.LICENSE#ERR_LICENSE_XRV_LICENSE_RENEWED_ALREADY} -
   * If the license has already been renewed. </li>
   * </ul>
   */

  public void crossEntityValidation() {

    final License license = getLicense();

    getTransactionHelper().lock(license);

    if (!license.getLifecycleState().equals(LicenseStatusEntry.APPROVED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_CANNOT_RENEW_LICENSE(
          LicenseStatusEntry.APPROVED.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    final Set<ReasonForNonCompliance> licenseReasonForNonComplianceRecords = getReasonForNonComplianceRecords();

    if (license.isRenewed() || licenseReasonForNonComplianceRecords.size() > 1) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_LICENSE_RENEWED_ALREADY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);

    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void insert() throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre insert reason for non compliance event.
    insertEventDispatcherFactory.get(ReasonForNonComplianceInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    providerSecurity.checkProviderSecurity(getProvider());

    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert reason for non compliance event.
    insertEventDispatcherFactory.get(ReasonForNonComplianceInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// None required
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// None required
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// None required
  }
}
