/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.entity.struct.SearchPartyByRefNoTypeName;
import curam.cpm.sl.entity.struct.SearchRefNumDetails;
import curam.util.persistence.StandardDAO;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * Data access for {@linkplain curam.provider.impl.ProviderMember}.
 */
@ImplementedBy(ProviderMemberDAOImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ProviderMemberDAO extends StandardDAO<ProviderMember> {

  // ___________________________________________________________________________
  /**
   * Searches for the members associated with provider or provider group.
   *
   * @param providerOrganization
   * the provider organization for whom the provider members are
   * listed.
   *
   * @return Set<ProviderMember> The provider members which have been
   * associated with the provider organization.
   */
  Set<ProviderMember> searchBy(final ProviderOrganization providerOrganization);

  // ___________________________________________________________________________
  /**
   * Searches for the members based on the organization reference number.
   *
   * @param searchRefNumDetails
   * the provider organization for whom the provider members are
   * listed.
   * @return ProviderMember The provider members which have been associated with
   * the provider organization.
   */
  ProviderMember searchByReferenceNumber(SearchRefNumDetails searchRefNumDetails);

  /**
   * Searches for the members based on the organization reference number and
   * type name.
   *
   * @param searchDetails
   * criteria to be searched for.
   * @return ProviderMember with the reference number and type specified.
   */
  ProviderMember searchByTypeNameAndProviderRefNo(
    SearchPartyByRefNoTypeName searchDetails);

  // BEGIN, CR00170625, KR
  /**
   * Retrieves the list of provider member details related to the person.
   *
   * The search can be performed in two ways - Either by executing the modeled
   * query or by executing the dynamically constructed query. To execute the
   * dynamically constructed query enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param partyConcernRoleID
   * Person concern role ID.
   * @param category
   * Category of relationship between provider party and provider.
   * @param status
   * Provider member status.
   *
   * @return Set<ProviderMember> Set of provider member that matches the search
   * criteria.
   */
  // END, CR00170625
  public Set<ProviderMember> listPersonMembershipHistory
    (Long partyConcernRoleID, ProviderPartyCategoryEntry category, RECORDSTATUSEntry status);
}
