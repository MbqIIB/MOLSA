/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.List;

import com.google.inject.ImplementedBy;
import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain MemberCertification}.
 */
@ImplementedBy(MemberCertificationDAOImpl.class)
public interface MemberCertificationDAO extends StandardDAO<MemberCertification> {
  // BEGIN, CR00121578, NRV
  /**
   * This method searches all the active member certification for an party.
   *
   * @param providerConcernRoleID
   * COntains the unique identifier of provider concern role
   * id.
   * @return contains list of active member certification details
   */
  List<MemberCertification> searchActiveMemberCertificationByParty(final long providerConcernRoleID);
  // END, CR00121578
  /**
   * This method searches all the active member certifications for a
   * certification.
   * @param certificationId
   * contains the unique identifier of certification id.
   * @return contains list of active member certification details
   */
  List<MemberCertification> searchActiveMemberCertificationByCertification(
    final long certificationId);
}
