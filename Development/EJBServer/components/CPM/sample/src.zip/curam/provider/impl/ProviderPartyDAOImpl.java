/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.cpm.sl.entity.impl.ProviderPartyAdapter;
import curam.cpm.sl.entity.struct.ProviderPartyDtls;
import curam.provider.ProviderPartyCategory;
import curam.util.persistence.BaseDAOImpl;
import curam.util.persistence.ReaderDAO;
import curam.util.persistence.RowManager;


/**
 * Standard implementation of {@linkplain curam.provider.impl.ProviderPartyDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ProviderPartyDAOImpl extends BaseDAOImpl<Long, ProviderParty, ProviderPartyDtls> implements
  ProviderPartyDAO {
  // END, CR00183213
  /**
   * Provider Party adapter
   */
  protected static final ProviderPartyAdapter adapter = new ProviderPartyAdapter();

  /**
   * Injecting the DAO class for Provider Participant.
   */
  @Inject
  protected ProviderParticipantDAO providerParticipantDAO;

  /**
   * Injecting the DAO class for Provider Member.
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderPartyDAOImpl() {
    // END, CR00183213
    super(adapter, ProviderParty.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<ProviderParty> searchBy(
    final ProviderOrganization providerOrganization) {

    return newSet(
      adapter.searchByProviderOrganization(providerOrganization.getID()));
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected Map<String, ReaderDAO<Long, ? extends ProviderParty>> getConcreteReaderDAOs() {
    final Map<String, ReaderDAO<Long, ? extends ProviderParty>> concreteReaderDAOs = new HashMap<String, ReaderDAO<Long, ? extends ProviderParty>>();

    concreteReaderDAOs.put(ProviderPartyCategory.PROVIDERPARTICIPANT,
      providerParticipantDAO);
    concreteReaderDAOs.put(ProviderPartyCategory.MEMBER, providerMemberDAO);
    return concreteReaderDAOs;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected String getDiscriminator(
    RowManager<Long, ProviderPartyDtls> rowManager) {
    return rowManager.getDtls().category;
  }

}
