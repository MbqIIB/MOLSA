/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.message.BACKGROUNDCHECK;
import curam.message.PROVIDER;
import curam.message.impl.BACKGROUNDCHECKExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.LifecycleHelper;


// BEGIN, CR00183213, SS
public class ProviderBackgroundCheckImpl extends BackgroundCheckImpl implements
  ProviderBackgroundCheck {
  // END, CR00183213

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderBackgroundCheckInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderBackgroundCheckCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderBackgroundCheckModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  /**
   * Injecting the Data Access Object for Provider
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Injecting the Data Access Object for Provider Security
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * Injecting the Data Access Object for Background Check Failure Reason
   */
  @Inject
  protected BackgroundCheckFailureReasonDAO backgroundCheckFailureReasonDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderBackgroundCheckImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213
  /**
   * {@inheritDoc}
   */
  public Provider getProvider() {
    final long id = getDtls().providerConcernRoleID;

    return id == 0 ? null : providerDAO.get(id);
  }

  /**
   * {@inheritDoc}
   */
  public void setProvider(Provider value) {
    getDtls().providerConcernRoleID = value.getID();

  }

  /**
   * {@inheritDoc}
   */
  public Set<BackgroundCheckFailureReason> getProviderBackgroundCheckFailureReasons() {
    return Collections.unmodifiableSet(
      backgroundCheckFailureReasonDAO.searchBy(this));
  }

  /**
   * Validates and inserts provider background check record for the provider.
   *
   * @throws InformationalException
   * {@link PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   */
  @Override
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre insert provider background check event.
    insertEventDispatcherFactory.get(ProviderBackgroundCheckInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 34);
      ValidationHelper.failIfErrorsExist();
    }
    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert provider background check event.
    insertEventDispatcherFactory.get(ProviderBackgroundCheckInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * Validates and modifies provider background check record of the Provider.
   *
   * @throws InformationalException
   * {@link PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   */
  @Override
  public void modify() throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 35);
      ValidationHelper.failIfErrorsExist();
    }

    super.modify();
  }

  /**
   * Cancels the Provider Background check record and all associated 'Active'
   * Background check failure reason record.
   *
   * @param versionNo
   * Version number of Background check record.
   *
   * @throws InformationalException
   * {@link PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}-
   * If the status of the provider is closed.
   */
  @Override
  public void cancel(final int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre cancel provider background check event.
    cancelEventDispatcherFactory.get(ProviderBackgroundCheckCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 33);
      ValidationHelper.failIfErrorsExist();
    }

    super.cancel(versionNo);

    // BEGIN CR00121844, MST
    Set<BackgroundCheckFailureReason> unModifiableBackgroundCheckFailureReasons = getProviderBackgroundCheckFailureReasons();
    Set<BackgroundCheckFailureReason> backgroundCheckFailureReasons = new HashSet<BackgroundCheckFailureReason>();

    backgroundCheckFailureReasons.addAll(
      unModifiableBackgroundCheckFailureReasons);

    for (BackgroundCheckFailureReason backgroundCheckFailureReason : backgroundCheckFailureReasons) {
      // Delete all background check failure reasons associated with the
      // deleted background check, which have a status of 'Active'.
      if (backgroundCheckFailureReason.getLifecycleState().equals(
        RECORDSTATUSEntry.NORMAL)) {

        backgroundCheckFailureReason.cancel(
          backgroundCheckFailureReason.getVersionNo());
      }
    }
    // END CR00121844

    // BEGIN, CR00235789, AK
    // Raise the post cancel provider background check event.
    cancelEventDispatcherFactory.get(ProviderBackgroundCheckCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Sets the provider member for whom background check is to be done.
   *
   * @param value
   * The Provider member for whom background check is to be done.
   *
   * @throws InformationalException
   * {@link BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_XRV_PROVIDERMEMBER_NOT_ACTIVELY_ASSOCIATED_WITH_PROVIDER} -
   * If provider member is not associated to the provider.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void setProviderMember(ProviderMember value) throws AppException,
      InformationalException {

    if (value.getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_XRV_PROVIDERMEMBER_NOT_ACTIVELY_ASSOCIATED_WITH_PROVIDER(
          value.getParty().getName(), getProvider().getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    getDtls().providerPartyID = value.getID();

  }

  /**
   * Validates that changes made to ProviderBackgroundCheck entity on the
   * database are consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_XRV_RECEIPTDATE_CANNOT_EARLIER_ACTIVE_FILURE_REASON_DATE_EXIST} -
   * If the receipt date is before background check failure reason date. </li>
   * <li>
   * {@link BACKGROUNDCHECK#ERR_BACKGROUNDCHECK_XRV_RESULT_CANNOT_PASS_IF_ACTIVE_FILURE_REASON_EXISTS} -
   * If the active background check failure reason exits. </li>
   * </ul>
   *
   */

  @Override
  public void crossEntityValidation() {
    super.crossEntityValidation();

    // The Receipt Date may not be earlier than the Date of the active
    // background check failure reasons.
    Set<BackgroundCheckFailureReason> unModifiableBackgroundCheckFailureReasons = getProviderBackgroundCheckFailureReasons();
    Set<BackgroundCheckFailureReason> backgroundCheckFailureReasons = new HashSet<BackgroundCheckFailureReason>();

    backgroundCheckFailureReasons.addAll(
      unModifiableBackgroundCheckFailureReasons);

    if (getDateRange().isEnded()) {
      for (final BackgroundCheckFailureReason backgroundCheckFailureReason : LifecycleHelper.filter(
        backgroundCheckFailureReasons, RECORDSTATUSEntry.NORMAL)) {

        if (getDateRange().end().before(
          backgroundCheckFailureReason.getOccurrenceDate())) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_XRV_RECEIPTDATE_CANNOT_EARLIER_ACTIVE_FILURE_REASON_DATE_EXIST(
              getDateRange().end(),
              backgroundCheckFailureReason.getOccurrenceDate()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);

        }
      }
    }

    // Result Cannot be specified as 'Pass' if active background check
    // failure
    // reasons exist.
    if (this.getResult().equals(BackgroundCheckResultEntry.PASS)) {
      if (LifecycleHelper.filter(getProviderBackgroundCheckFailureReasons(), RECORDSTATUSEntry.NORMAL).size()
        > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECK_XRV_RESULT_CANNOT_PASS_IF_ACTIVE_FILURE_REASON_EXISTS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }
  }

  // BEGIN, CR00235789, AK
  /**
   * Validates and modifies provider background check.
   *
   * @param versionNo
   * Version number.
   *
   * @throws InformationalException
   * {@link PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // Raise the pre modify provider background check event.
    modifyEventDispatcherFactory.get(ProviderBackgroundCheckModifyEvents.class).preModify(
      this, versionNo);

    providerSecurity.checkProviderSecurity(getProvider());

    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 32);
      ValidationHelper.failIfErrorsExist();
    }

    super.modify(versionNo);

    // Raise the post modify provider background check event.
    modifyEventDispatcherFactory.get(ProviderBackgroundCheckModifyEvents.class).postModify(
      this, versionNo);
  }
  // END, CR00235789
}
