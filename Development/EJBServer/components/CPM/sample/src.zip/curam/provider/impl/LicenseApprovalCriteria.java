/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.LicenseProviderAndVersionNumberKey;
import curam.message.TRAININGPROGRAM;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Implementable;


/**
 * An agency may have a specific way in which they will want to use training
 * information to approve a license for a provider.The solution will support the
 * notification to a user where training requirements for one or more services
 * are neither 'Complete' nor 'Waived' for provider members. However other
 * solutions may wish to prevent license approval if this validation is not
 * satisfied, therefore they should override this business rule to support the
 * ability to inhibit approval, if required.
 *
 */
@ImplementedBy(LicenseApprovalCriteriaImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface LicenseApprovalCriteria {

  /**
   * If training requirements are specified for the license type, then all
   * trainings marked as 'Required' must be 'Completed' or 'Waived' for all
   * active provider members. Only those provider members that don't have an End
   * Date or an End Date in the future are considered. If this rule is not
   * satisfied, the user is to be notified and allowed to continue.
   *
   * @param licenseProviderAndVersionNumberKey
   * the key which identifies the license.
   * @return List of Informational messages.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_LICENSE_CANNOT_BE_APPROVED}
   * The training requirement for provider member is not 'Completed'
   * or 'Waived', the license cannot be approved.
   * @see curam.provider.impl.LicenseApprovalCriteriaImpl#checkLicenseApprovalCriteria(LicenseProviderAndVersionNumberKey)
   * The default implementation -
   * curam.provider.impl.LicenseApprovalCriteriaImpl#checkLicenseApprovalCriteria(LicenseProviderAndVersionNumberKey)
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  InformationalMessageList checkLicenseApprovalCriteria(
    LicenseProviderAndVersionNumberKey licenseProviderAndVersionNumberKey)
    throws InformationalException;
}
