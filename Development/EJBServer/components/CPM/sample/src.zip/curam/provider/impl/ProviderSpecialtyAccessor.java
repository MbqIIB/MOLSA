/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.util.persistence.StandardEntity;


/**
 * Accessor interface for {@linkplain ProviderSpecialty}.
 *
 */
public interface ProviderSpecialtyAccessor extends StandardEntity {
  // ___________________________________________________________________________
  /**
   * Gets the specialty for a provider.
   *
   * @return ProviderSpecialtyTypeEntry the specialty for the provider.
   */
  ProviderSpecialtyTypeEntry getSpecialty();
  // ___________________________________________________________________________
  /**
   * Gets the accessor for the provider having a specialty.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return Provider associated with the provider specialty.
   */
  ProviderAccessor getProvider();

}
