/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;

import com.google.inject.Singleton;

import curam.cpm.sl.impl.MemberCertChangeHistoryAdapter;
import curam.cpm.sl.struct.MemberCertChangeHistoryDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of {@linkplain curam.provider.impl.MemberCertificationChangeHistoryDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class MemberCertificationChangeHistoryDAOImpl extends StandardDAOImpl<MemberCertificationChangeHistory, MemberCertChangeHistoryDtls>
  implements MemberCertificationChangeHistoryDAO {
  // END, CR00183213
  /**
   * Adapter initialization
   */
  protected static final MemberCertChangeHistoryAdapter adapter = new MemberCertChangeHistoryAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  // END, CR00183213
  protected MemberCertificationChangeHistoryDAOImpl() {
    super(adapter, MemberCertificationChangeHistory.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<MemberCertificationChangeHistory> SearchByMemberCertification(
    final long memberCertificationID) {

    return newSet(adapter.searchByMemberCertificationID(memberCertificationID));
  }
}
