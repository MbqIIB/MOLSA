/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.Inject;

import curam.cpm.sl.entity.struct.ProviderTypeDtls;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;


/**
 * Standard implementation of {@linkplain curam.provider.impl.ProviderType}.
 */
// BEGIN, CR00183213, SS
public class ProviderTypeImpl extends SingleTableLogicallyDeleteableEntityImpl<ProviderTypeDtls> implements
  ProviderType {
  // END, CR00183213

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderTypeInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderTypeCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderTypeModifyEvents> modifyEventDispatcherFactory;

  /**
   * Event dispatcher for remove events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderTypeRemoveEvents> removeEventDispatcherFactory;

  // END, CR00235789

  /**
   * Inject ProviderCategoryPeriodDAO
   */
  @Inject
  protected ProviderCategoryPeriodDAO providerCategoryPeriodDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderTypeImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213

  /**
   * Modifies the provider category period and also raises the pre and post
   * modify event.
   *
   * @param versionNo
   * The version number of provider category period.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modify(Integer versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre modify provider type event.
    modifyEventDispatcherFactory.get(ProviderTypeModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    super.modify(versionNo);

    // BEGIN CR00097018, GP
    // Raise an Event
    final Event event = new Event();

    event.eventKey = curam.events.PROVIDERTYPE.PROVIDERTYPE_MODIFIED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
    // END CR00097018, GP

    // BEGIN, CR00235789, AK
    // Raise the post modify provider type event.
    modifyEventDispatcherFactory.get(ProviderTypeModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  public ProviderCategoryPeriod getProviderCategoryPeriod() {

    final long providerCategoryPeriodID = getDtls().providerCategoryID;

    // providerCategoryPeriodID == 0 ? null :
    // providerCategoryPeriodDAO(providerCategoryPeriodID);
    return providerCategoryPeriodDAO.get(providerCategoryPeriodID);
  }

  /**
   * {@inheritDoc}
   */
  public String getType() {
    return getDtls().type;
  }

  /**
   * {@inheritDoc}
   */
  public void setType(String value) {
    getDtls().type = value;
  }

  /**
   * {@inheritDoc}
   */
  public void cancel(int versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre cancel provider type event.
    cancelEventDispatcherFactory.get(ProviderTypeCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    super.cancel(versionNo);

    // BEGIN CR00097018, GP
    // Raise an Event
    final Event event = new Event();

    event.eventKey = curam.events.PROVIDERTYPE.PROVIDERTYPE_CANCELED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
    // END CR00097018, GP

    // BEGIN, CR00235789, AK
    // Raise the post cancel provider type event.
    cancelEventDispatcherFactory.get(ProviderTypeCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * {@inheritDoc}
   */
  public void setProviderCategoryPeriod(final ProviderCategoryPeriod value) {
    getDtls().providerCategoryID = value.getID();

  }

  /**
   * {@inheritDoc}
   */
  public void insert() throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre insert provider type event.
    insertEventDispatcherFactory.get(ProviderTypeInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    super.insert();

    // BEGIN CR00097018, GP
    // Create a post event
    final Event event = new Event();

    event.eventKey = curam.events.PROVIDERTYPE.PROVIDERTYPE_INSERTED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
    // END CR00097018, GP

    // BEGIN, CR00235789, AK
    // Raise the post insert provider type event.
    insertEventDispatcherFactory.get(ProviderTypeInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// none required
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// none required
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// none required
  }

  // BEGIN, CR00235789, AK
  /**
   * {@inheritDoc}
   */
  @Override
  public void remove(final Integer versionNo) throws InformationalException {

    // Raise the pre remove provider type event.
    removeEventDispatcherFactory.get(ProviderTypeRemoveEvents.class).preRemove(
      this, versionNo);

    super.remove(versionNo);

    // Raise the post remove provider type event.
    removeEventDispatcherFactory.get(ProviderTypeRemoveEvents.class).postRemove(
      this, versionNo);

  }
  // END, CR00235789
}
