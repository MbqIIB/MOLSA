/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.util.Set;


/**
 * Background checks undertaken on employees or household members of a provider.
 *
 * For example, an SEM agency may wish to conduct both a Criminal Investigation
 * check and a Child Protective Service check on all employees of each of their
 * Day Care Centers. The actual background check may be conducted by the agency
 * itself (e.g. in the case of a Child Protective Service check) or may be
 * conducted by an outside body.
 */
@ImplementedBy(ProviderBackgroundCheckImpl.class)
public interface ProviderBackgroundCheck extends BackgroundCheck,
    ProviderBackgroundCheckAccessor {

  /**
   * Gets the immutable provider associated with the Background Check.
   *
   * @return Immutable provider associated with the background check.
   */
  public Provider getProvider();

  /**
   * Sets the provider associated with the Background Check.
   *
   * @param value
   * The Provider to be set for the background check.
   */
  public void setProvider(final Provider value);

  /**
   * Sets the provider member for whom background check is to be done.
   *
   * @param value
   * The Provider member for whom background check is to be done.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderBackgroundCheckImpl#setProviderMember(ProviderMember)
   * The default implementation -
   * curam.provider.impl.ProviderBackgroundCheckImpl#setProviderMember(ProviderMember)
   */
  public void setProviderMember(final ProviderMember value)
    throws AppException, InformationalException;

  /**
   * Gets the immutable set of Background Check Failure Reasons for a provider
   * Background Check.
   *
   * @return The immutable set of Background Check Failure Reasons for a
   * provider Background Check.
   */
  public Set<BackgroundCheckFailureReason> getProviderBackgroundCheckFailureReasons();

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider background check events functionality surrounding
   * the insert method.
   */
  public interface ProviderBackgroundCheckInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderBackgroundCheck#insert}
     *
     * @param providerBackgroundCheck
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(
      ProviderBackgroundCheckAccessor providerBackgroundCheck)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderBackgroundCheck#insert}
     *
     * @param providerBackgroundCheck
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(
      ProviderBackgroundCheckAccessor providerBackgroundCheck)
      throws InformationalException;
  }


  /**
   * Interface to the provider background check events functionality surrounding
   * the cancel method.
   */
  public interface ProviderBackgroundCheckCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderBackgroundCheck#cancel}
     *
     * @param providerBackgroundCheck
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(
      ProviderBackgroundCheckAccessor providerBackgroundCheck, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderBackgroundCheck#cancel}
     *
     * @param providerBackgroundCheck
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(
      ProviderBackgroundCheckAccessor providerBackgroundCheck, int versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the provider background check events functionality surrounding
   * the modify method.
   */
  public interface ProviderBackgroundCheckModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderBackgroundCheck#modify}
     *
     * @param providerBackgroundCheck
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(
      ProviderBackgroundCheckAccessor providerBackgroundCheck,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderBackgroundCheck#modify}
     *
     * @param providerBackgroundCheck
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(
      ProviderBackgroundCheckAccessor providerBackgroundCheck,
      Integer versionNo) throws InformationalException;
  }
  // END, CR00144381

}
