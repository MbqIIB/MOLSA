/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Singleton;

import curam.codetable.ADDRESSELEMENTTYPE;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.impl.ProviderEnquiryAdapter;
import curam.cpm.sl.entity.struct.ProviderEnquiryDtls;
import curam.cpm.sl.entity.struct.SearchProviderEnquiryKey;
import curam.provider.EnquiryStatus;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import curam.util.resources.Configuration;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringHelper;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ProviderEnquiryDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ProviderEnquiryDAOImpl extends StandardDAOImpl<ProviderEnquiry, ProviderEnquiryDtls> implements
  ProviderEnquiryDAO {
  // END, CR00183213
  /**
   * Constant for empty string
   */
  static final String kEmptyString = "";

  /**
   * adapter instance of ProviderEnquiryAdapter.
   */
  protected static final ProviderEnquiryAdapter adapter = new ProviderEnquiryAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderEnquiryDAOImpl() {
    // END, CR00183213
    super(adapter, ProviderEnquiry.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderEnquiry> searchBy(String userName) {
    final String userNameKey = StringHelper.trim(userName);

    return newSet(adapter.searchByUserName(userNameKey));
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderEnquiry> searchBy(String name,
    String referenceNumber, String street1, String city,
    @SuppressWarnings(CPMConstants.kUnused)
  Boolean searchByName, @SuppressWarnings(CPMConstants.kUnused)
  Boolean searchByReferenceNumber,
    @SuppressWarnings(CPMConstants.kUnused)
  Boolean searchByStreet1, @SuppressWarnings(CPMConstants.kUnused)
  Boolean searchByCity,
    @SuppressWarnings(CPMConstants.kUnused)
  String addressLine1Type, @SuppressWarnings(CPMConstants.kUnused)
  String cityTypeCode, String enquiryStatus) {

    // Manipulation variable
    final String referenceNumberTrim = referenceNumber.trim();
    final String nameTrim = name.trim();
    final String street1Trim = street1.trim();
    String cityTrim = city.trim();
    String enquiryStatusTrim = enquiryStatus.trim();
    // Initialize the search Criteria
    final boolean searchByReferenceNumberTerm = referenceNumberTrim.length()
      > 0;
    final boolean searchByNameTerm = nameTrim.length() > 0;
    final boolean searchByStreet1Term = street1Trim.length() > 0;
    final boolean searchByCityTerm = cityTrim.length() > 0;
    String enquiryStatusTerm = "";

    if (enquiryStatusTrim.length() > 0) {
      // BEGIN, CR00097355, NRV
      enquiryStatusTerm = EnquiryStatus.OPEN;
      // END, CR00097355
    }

    final String addressLine1TypeTerm = ADDRESSELEMENTTYPE.LINE1;
    final String cityTypeCodeTerm = ADDRESSELEMENTTYPE.CITY;

    final String nameTerm = CuramConst.gkSqlWildcard + nameTrim.toUpperCase()
      + CuramConst.gkSqlWildcard;

    final String street1Term = CuramConst.gkSqlWildcard
      + street1Trim.toUpperCase() + CuramConst.gkSqlWildcard;

    final String cityTerm = CuramConst.gkSqlWildcard + cityTrim.toUpperCase()
      + CuramConst.gkSqlWildcard;

    // BEGIN, CR00170625, KR
    Set<ProviderEnquiry> providerEnquirySet = new HashSet<ProviderEnquiry>();

    if (Configuration.getBooleanProperty(EnvVars.ENV_DYNAMIC_SQL_ENABLED)) {
      try {
        providerEnquirySet = searchByDynamicSql(nameTerm, referenceNumberTrim,
          street1Term, cityTerm, searchByNameTerm, searchByReferenceNumberTerm,
          searchByStreet1Term, searchByCityTerm, addressLine1TypeTerm,
          cityTypeCodeTerm, enquiryStatusTerm);
      } catch (AppException appException) {
        throw new AppRuntimeException(appException);
      } catch (InformationalException infExp) {
        throw new AppRuntimeException(infExp);
      }
    } else {
      if (enquiryStatusTrim.length() > 0) {
        providerEnquirySet = newSet(
          adapter.searchOpenEnquiriesBy(nameTerm, referenceNumberTrim,
          street1Term, cityTerm, searchByNameTerm, searchByReferenceNumberTerm,
          searchByStreet1Term, searchByCityTerm, addressLine1TypeTerm,
          cityTypeCodeTerm, enquiryStatusTerm));

      } else {
        providerEnquirySet = newSet(
          adapter.searchBy(nameTerm, referenceNumberTrim, street1Term, cityTerm,
          searchByNameTerm, searchByReferenceNumberTerm, searchByStreet1Term,
          searchByCityTerm, addressLine1TypeTerm, cityTypeCodeTerm,
          enquiryStatusTerm));
      }
    }
    return providerEnquirySet;
    // END, CR00170625
  }
  
  // BEGIN, CR00216313, RD
  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00225866, GP
  public Set<ProviderEnquiry> searchByDateRangeOwnerAndEnquiryStatus(
    String ownerName, String recordStatus, Date startDate, DateTime endDateTime) {
    return newSet(
      adapter.searchByDateRangeOwnerAndEnquiryStatus(startDate, endDateTime,
      recordStatus, ownerName));
  }

  // END, CR00225866
  // END, CR00216313

  // BEGIN, CR00260608, GP
  /**
   * {@inheritDoc}
   */
  public List<ProviderEnquiry> searchByDateRangeAndEnquiryStatus(
    final EnquiryStatusEntry enquiryStatus, final DateTime startDateTime,
    final DateTime endDateTime) {

    return newList(
      adapter.searchByDateRangeAndEnquiryStatus(startDateTime, endDateTime,
      enquiryStatus.getCode()));
  }

  // END, CR00260608

  // BEGIN, CR00170625, KR
  protected Set<ProviderEnquiry> searchByDynamicSql(String name,
    String referenceNumber, String street1, String city,
    Boolean searchByName, Boolean searchByReferenceNumber,
    Boolean searchByStreet1, Boolean searchByCity, String addressLine1Type,
    String cityTypeCode, String enquiryStatus) throws AppException,
      InformationalException {

    ProviderEnquiryDtls[] providerEnquiryDtlsList = new ProviderEnquiryDtls[0];

    if (isAnyProviderEnquirySearchCriteriaEntered(searchByName,
      searchByReferenceNumber, searchByStreet1, searchByCity)) {

      StringBuilder providerEnquirySearchQuery = new StringBuilder();
      StringBuilder selectBuilder = new StringBuilder();
      StringBuilder intoBuilder = new StringBuilder();
      StringBuilder fromBuilder = new StringBuilder();
      StringBuilder whereBuilder = new StringBuilder();
      SearchProviderEnquiryKey searchProviderEnquiryKey = new SearchProviderEnquiryKey();

      populateSearchProviderEnquiryKey(name, referenceNumber, street1, city,
        addressLine1Type, cityTypeCode, enquiryStatus, searchProviderEnquiryKey);

      selectEnquiry(selectBuilder, intoBuilder);

      fromBuilder.append(" FROM ProviderEnquiry");
      whereBuilder.append(" WHERE");
      searchEnquiryWhereCondition(searchByName, searchByReferenceNumber,
        searchByStreet1, searchByCity, fromBuilder, whereBuilder);
      if (enquiryStatus.length() > 0) {
        whereBuilder.append(
          " AND ProviderEnquiry.recordStatus = :enquiryStatus ");
      }
      whereBuilder.append(" ORDER BY ProviderEnquiry.name");
      buildFinalQuery(providerEnquirySearchQuery, selectBuilder, intoBuilder,
        fromBuilder, whereBuilder);
      
      // BEGIN, CR00292696, IBM
      CuramValueList curamValueList = DynamicDataAccess.executeNsMulti(
        ProviderEnquiryDtls.class, searchProviderEnquiryKey, false, true, 
        providerEnquirySearchQuery.toString());

      // END, CR00292696

      providerEnquiryDtlsList = new ProviderEnquiryDtls[curamValueList.size()];
      for (int i = 0; i < curamValueList.size(); i++) {
        providerEnquiryDtlsList[i] = (ProviderEnquiryDtls) curamValueList.get(i);
      }
    }
    return newSet(providerEnquiryDtlsList);
  }

  protected void searchEnquiryWhereCondition(Boolean searchByName,
    Boolean searchByReferenceNumber, Boolean searchByStreet1,
    Boolean searchByCity, StringBuilder fromBuilder,
    StringBuilder whereBuilder) {

    if (searchByReferenceNumber && searchByName && searchByStreet1
      && searchByCity) {
      searchByAllCriteria(fromBuilder, whereBuilder);
    } else if (searchByReferenceNumber && searchByName && searchByStreet1) {
      searchByRefNoNameAndStreet1(fromBuilder, whereBuilder);
    } else if (searchByReferenceNumber && searchByName && searchByCity) {
      searchByRefNoNameAndCity(fromBuilder, whereBuilder);
    } else if (searchByReferenceNumber && searchByStreet1 && searchByCity) {
      searchByRefNoStreet1AndCity(fromBuilder, whereBuilder);
    } else if (searchByName && searchByStreet1 && searchByCity) {
      searchByNameStreet1AndCity(fromBuilder, whereBuilder);
    } else if (searchByReferenceNumber && searchByName) {
      whereBuilder.append(
        " ProviderEnquiry.referenceNumber = :referenceNumber ");
      whereBuilder.append(" AND ProviderEnquiry.nameUpper like :name ");
    } else if (searchByReferenceNumber && searchByStreet1) {
      whereBuilder.append(
        " ProviderEnquiry.referenceNumber = :referenceNumber ");
      whereBuilder.append(" AND ");
      searchByStreet1(fromBuilder, whereBuilder);
    } else if (searchByReferenceNumber && searchByCity) {
      whereBuilder.append(
        " ProviderEnquiry.referenceNumber = :referenceNumber ");
      whereBuilder.append(" AND ");
      searchByCity(fromBuilder, whereBuilder);
    } else if (searchByName && searchByStreet1) {
      whereBuilder.append(" ProviderEnquiry.nameUpper like :name ");
      whereBuilder.append(" AND ");
      searchByStreet1(fromBuilder, whereBuilder);
    } else if (searchByName && searchByCity) {
      whereBuilder.append(" ProviderEnquiry.nameUpper like :name ");
      whereBuilder.append(" AND ");
      searchByCity(fromBuilder, whereBuilder);
    } else if (searchByStreet1 && searchByCity) {
      searchByStreet1(fromBuilder, whereBuilder);
      whereBuilder.append(" AND ");
      searchByCity(fromBuilder, whereBuilder);
    } else if (searchByName) {
      whereBuilder.append(" ProviderEnquiry.nameUpper like :name ");
    } else if (searchByReferenceNumber) {
      whereBuilder.append(
        " ProviderEnquiry.referenceNumber = :referenceNumber ");
    } else if (searchByStreet1) {
      searchByStreet1(fromBuilder, whereBuilder);
    } else if (searchByCity) {
      searchByCity(fromBuilder, whereBuilder);
    }
  }

  protected void searchByNameStreet1AndCity(StringBuilder fromBuilder,
    StringBuilder whereBuilder) {
    whereBuilder.append(" ProviderEnquiry.nameUpper like :name ");
    whereBuilder.append(" AND ");
    searchByStreet1(fromBuilder, whereBuilder);
    whereBuilder.append(" AND ");
    searchByCity(fromBuilder, whereBuilder);
  }

  protected void searchByRefNoStreet1AndCity(StringBuilder fromBuilder,
    StringBuilder whereBuilder) {
    whereBuilder.append(" ProviderEnquiry.referenceNumber = :referenceNumber ");
    whereBuilder.append(" AND ");
    searchByStreet1(fromBuilder, whereBuilder);
    whereBuilder.append(" AND ");
    searchByCity(fromBuilder, whereBuilder);
  }

  protected void searchByRefNoNameAndCity(StringBuilder fromBuilder,
    StringBuilder whereBuilder) {
    whereBuilder.append(" ProviderEnquiry.referenceNumber = :referenceNumber ");
    whereBuilder.append(" AND ProviderEnquiry.nameUpper like :name ");
    whereBuilder.append(" AND ");
    searchByCity(fromBuilder, whereBuilder);
  }

  protected void searchByRefNoNameAndStreet1(StringBuilder fromBuilder,
    StringBuilder whereBuilder) {
    whereBuilder.append(" ProviderEnquiry.referenceNumber = :referenceNumber ");
    whereBuilder.append(" AND ProviderEnquiry.nameUpper like :name ");
    whereBuilder.append(" AND ");
    searchByStreet1(fromBuilder, whereBuilder);
  }

  protected void searchByAllCriteria(StringBuilder fromBuilder,
    StringBuilder whereBuilder) {
    whereBuilder.append(" ProviderEnquiry.referenceNumber = :referenceNumber ");
    whereBuilder.append(" AND ProviderEnquiry.nameUpper like :name ");
    whereBuilder.append(" AND ");
    searchByStreet1(fromBuilder, whereBuilder);
    whereBuilder.append(" AND ");
    searchByCity(fromBuilder, whereBuilder);
  }

  protected void searchByCity(StringBuilder fromBuilder,
    StringBuilder whereBuilder) {
    fromBuilder.append(" , AddressElement city ");
    whereBuilder.append(" city.upperElementValue like :city ");
    whereBuilder.append(" AND ProviderEnquiry.homeAddressID = city.addressID");
    whereBuilder.append(" AND city.elementType = :cityTypeCode ");
  }

  protected void searchByStreet1(StringBuilder fromBuilder,
    StringBuilder whereBuilder) {
    fromBuilder.append(" , AddressElement addressLine1 ");
    whereBuilder.append(" addressLine1.upperElementValue like :street1 ");
    whereBuilder.append(
      " AND ProviderEnquiry.homeAddressID = addressline1.addressID");
    whereBuilder.append(" AND addressLine1.elementType = :addressLine1Type ");
  }

  protected void buildFinalQuery(StringBuilder providerEnquirySearchQuery,
    StringBuilder selectBuilder, StringBuilder intoBuilder,
    StringBuilder fromBuilder, StringBuilder whereBuilder) {
    providerEnquirySearchQuery.append(selectBuilder);
    providerEnquirySearchQuery.append(intoBuilder);
    providerEnquirySearchQuery.append(fromBuilder);
    providerEnquirySearchQuery.append(whereBuilder);
  }

  protected void populateSearchProviderEnquiryKey(String name,
    String referenceNumber, String street1, String city,
    String addressLine1Type, String cityTypeCode, String enquiryStatus,
    SearchProviderEnquiryKey searchProviderEnquiryKey) {

    searchProviderEnquiryKey.name = name;
    searchProviderEnquiryKey.street1 = street1;
    searchProviderEnquiryKey.city = city;
    searchProviderEnquiryKey.referenceNumber = referenceNumber;
    searchProviderEnquiryKey.cityTypeCode = cityTypeCode;
    searchProviderEnquiryKey.addressLine1Type = addressLine1Type;
    searchProviderEnquiryKey.enquiryStatus = enquiryStatus;
  }

  protected boolean isAnyProviderEnquirySearchCriteriaEntered(
    Boolean searchByName, Boolean searchByReferenceNumber,
    Boolean searchByStreet1, Boolean searchByCity) {
    return searchByName || searchByReferenceNumber || searchByStreet1
      || searchByCity;
  }

  protected void selectEnquiry(StringBuilder selectBuilder,
    StringBuilder intoBuilder) {
    selectBuilder.append(" SELECT");
    selectBuilder.append(" ProviderEnquiry.providerEnquiryID,");
    selectBuilder.append(" ProviderEnquiry.referenceNumber,");
    selectBuilder.append(" ProviderEnquiry.name,");
    selectBuilder.append(" ProviderEnquiry.nameUpper,");
    selectBuilder.append(" ProviderEnquiry.homeAddressID,");
    selectBuilder.append(" ProviderEnquiry.workAddressID,");
    selectBuilder.append(" ProviderEnquiry.homePhoneNumberID,");
    selectBuilder.append(" ProviderEnquiry.workPhoneNumberID,");
    selectBuilder.append(" ProviderEnquiry.mobilePhoneNumberID,");
    selectBuilder.append(" ProviderEnquiry.providerCategoryPeriodID,");
    selectBuilder.append(" ProviderEnquiry.additionalName,");
    selectBuilder.append(" ProviderEnquiry.preferredSession,");
    selectBuilder.append(" ProviderEnquiry.reasonForEnquiry,");
    selectBuilder.append(" ProviderEnquiry.confirmedMeetingDetails,");
    selectBuilder.append(" ProviderEnquiry.attendedMeeting,");
    selectBuilder.append(" ProviderEnquiry.obtainedApplicationForm,");
    selectBuilder.append(" ProviderEnquiry.scheduledMeeting,");
    selectBuilder.append(" ProviderEnquiry.noOfChildren,");
    selectBuilder.append(" ProviderEnquiry.availabilityForContact,");
    selectBuilder.append(" ProviderEnquiry.additionalInformation,");
    selectBuilder.append(" ProviderEnquiry.enquiryDate,");
    selectBuilder.append(" ProviderEnquiry.endDate,");
    selectBuilder.append(" ProviderEnquiry.ownerName,");
    selectBuilder.append(" ProviderEnquiry.recordStatus,");
    selectBuilder.append(" ProviderEnquiry.preferredLanguage,");
    selectBuilder.append(" ProviderEnquiry.preferredCommunication,");
    selectBuilder.append(" ProviderEnquiry.versionNo");
    intoBuilder.append(" INTO ");
    intoBuilder.append(" :providerEnquiryID,");
    intoBuilder.append(" :referenceNumber,");
    intoBuilder.append(" :name,");
    intoBuilder.append(" :nameUpper,");
    intoBuilder.append(" :homeAddressID,");
    intoBuilder.append(" :workAddressID,");
    intoBuilder.append(" :homePhoneNumberID,");
    intoBuilder.append(" :workPhoneNumberID,");
    intoBuilder.append(" :mobilePhoneNumberID,");
    intoBuilder.append(" :providerCategoryPeriodID,");
    intoBuilder.append(" :additionalName,");
    intoBuilder.append(" :preferredSession,");
    intoBuilder.append(" :reasonForEnquiry,");
    intoBuilder.append(" :confirmedMeetingDetails,");
    intoBuilder.append(" :attendedMeeting,");
    intoBuilder.append(" :obtainedApplicationForm,");
    intoBuilder.append(" :scheduledMeeting,");
    intoBuilder.append(" :noOfChildren,");
    intoBuilder.append(" :availabilityForContact,");
    intoBuilder.append(" :additionalInformation,");
    intoBuilder.append(" :enquiryDate,");
    intoBuilder.append(" :endDate,");
    intoBuilder.append(" :ownerName,");
    intoBuilder.append(" :recordStatus,");
    intoBuilder.append(" :preferredLanguage,");
    intoBuilder.append(" :preferredCommunication,");
    intoBuilder.append(" :versionNo,");
  }
  // END, CR00170625
}
