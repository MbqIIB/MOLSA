/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2009-2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;

import com.google.inject.Inject;

import curam.approvalcheck.entity.struct.ApprovalCheckDtls;
import curam.approvalcheck.impl.ApprovalCheck;
import curam.approvalcheck.impl.ApprovalCheckDAO;
import curam.codetable.impl.APPROVALCHECKTYPEEntry;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.codetable.impl.ORGSTRUCTURESTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.fact.AdminUserFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.fact.OrganisationStructureFactory;
import curam.core.sl.entity.intf.OrganisationStructure;
import curam.core.sl.entity.struct.OrganisationStructureID;
import curam.core.sl.entity.struct.OrganisationStructureStatus;
import curam.core.struct.SearchByOrgUnitStatusKey;
import curam.core.struct.UserForOrgUnitDetails;
import curam.core.struct.UserForOrgUnitDetailsList;
import curam.core.struct.UserSearchCriteria;
import curam.core.struct.UserSearchDetailsReference;
import curam.core.struct.UserSearchResultsDetails;
import curam.cpm.facade.struct.ApprovalCheckKey;
import curam.cpm.facade.struct.ViewApprovalCheckKey;
import curam.message.impl.PROVIDERAPPROVALCHECKExceptionCreator;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.Date;
import curam.util.type.Money;
import curam.piwrapper.user.impl.UserDAO;
import curam.piwrapper.user.impl.User;


/**
 * {@inheritDoc}
 */
public class ProviderApprovalCheckImpl extends SingleTableLogicallyDeleteableEntityImpl<ApprovalCheckDtls> implements
  ProviderApprovalCheck {

  /**
   * Reference to approval check DAO.
   */
  @Inject
  protected ApprovalCheckDAO approvalCheckDAO;

  /**
   * Reference to approval check.
   */
  @Inject
  protected ApprovalCheck approvalCheck;

  /**
   * Reference to provider security.
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * Reference to provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to provider offering DAO.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  // BEGIN, CR00305045, MR
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;
  
  // END, CR00305045

  // BEGIN, CR00305191, ASN
  /**
   * Event dispatcher for createProviderApprovalCheck events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderApprovalCheckCreateProviderApprovalCheckEvents> createProviderApprovalCheckEventsDispatcherFactory;

  /**
   * Event dispatcher for modifyProviderApprovalCheck events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderApprovalCheckModifyProviderApprovalCheckEvents> modifyProviderApprovalCheckEventsDispatcherFactory;

  /**
   * Event dispatcher for cancelProviderApprovalCheck events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderApprovalCheckCancelProviderApprovalCheckEvents> cancelProviderApprovalCheckEventsDispatcherFactory;

  // END, CR00305191

  /**
   * Constructor for the class.
   */
  public ProviderApprovalCheckImpl() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public void createApprovalCheck(APPROVALRELATEDTYPEEntry relatedType,
    long relatedID, APPROVALCHECKTYPEEntry approvalCheckType)
    throws InformationalException {

    approvalCheck = approvalCheckDAO.newInstance();

    approvalCheck.createApprovalCheck(relatedType, relatedID, approvalCheckType);
  }

  /**
   * Creates the approval check for the provider. Also performs the security
   * check for the provider.
   *
   * @param approvalCheckDtls
   * Approval check details for the provider.
   *
   * @return The approval check key.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECK#ERR_PROVIDERAPPROVALCHECK_XRV_ACTIVE_APPROVALCHECK_EXISTS_FOR_PROVIDER}} -
   * If there is an active approval check already exists for the
   * provider.
   */
  public ApprovalCheckKey createProviderApprovalCheck(
    ApprovalCheckDtls approvalCheckDtls) throws InformationalException {
    
    // BEGIN, CR00305191, ASN
    // Raise the pre createProviderApprovalCheck API event.
    createProviderApprovalCheckEventsDispatcherFactory.get(ProviderApprovalCheckCreateProviderApprovalCheckEvents.class).preCreateProviderApprovalCheck(
      this, approvalCheckDtls);
    // END, CR00305191

    providerSecurity.checkProviderSecurity(
      providerDAO.get(approvalCheckDtls.relatedID));

    approvalCheck = approvalCheckDAO.newInstance();

    List<ApprovalCheck> activeApprovalChecks = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.RELATEDTYPE, APPROVALRELATEDTYPEEntry.PROVIDER,
      approvalCheckDtls.relatedID, RECORDSTATUSEntry.NORMAL);

    if (activeApprovalChecks.size() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERAPPROVALCHECKExceptionCreator.ERR_PROVIDERAPPROVALCHECK_XRV_ACTIVE_APPROVALCHECK_EXISTS_FOR_PROVIDER(
          RECORDSTATUSEntry.NORMAL.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    approvalCheck.setComments(approvalCheckDtls.comments);
    approvalCheck.setPercentage(approvalCheckDtls.percentage);
    approvalCheck.createApprovalCheck(APPROVALRELATEDTYPEEntry.PROVIDER,
      approvalCheckDtls.relatedID, APPROVALCHECKTYPEEntry.RELATEDTYPE);

    ApprovalCheckKey approvalCheckKey = new ApprovalCheckKey();

    approvalCheckKey.approvalCheckID = approvalCheck.getID();

    // BEGIN, CR00305191, ASN
    // Raise the post createProviderApprovalCheck API event.
    createProviderApprovalCheckEventsDispatcherFactory.get(ProviderApprovalCheckCreateProviderApprovalCheckEvents.class).postCreateProviderApprovalCheck(
      this, approvalCheckDtls);
    // END, CR00305191
    
    return approvalCheckKey;
  }

  /**
   * {@inheritDoc}
   */
  public List<ApprovalCheck> listProviderApprovalChecks(
    long relatedID) throws InformationalException {

    List<ApprovalCheck> approvalChecks = new ArrayList<ApprovalCheck>();

    List<ApprovalCheck> activeApprovalChecks = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.RELATEDTYPE, APPROVALRELATEDTYPEEntry.PROVIDER,
      relatedID, RECORDSTATUSEntry.NORMAL);

    List<ApprovalCheck> canceledApprovalChecks = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.RELATEDTYPE, APPROVALRELATEDTYPEEntry.PROVIDER,
      relatedID, RECORDSTATUSEntry.CANCELLED);

    approvalChecks.addAll(activeApprovalChecks);

    List<ApprovalCheck> sortedCanceledApprovalChecks = new ArrayList<ApprovalCheck>();

    // Sort the list canceled approval checks into reverse order as the list
    // of approval checks should be sorted by latest created first.
    for (int i = canceledApprovalChecks.size() - 1; i >= 0; i--) {
      sortedCanceledApprovalChecks.add(canceledApprovalChecks.get(i));
    }
    approvalChecks.addAll(sortedCanceledApprovalChecks);

    return approvalChecks;
  }

  /**
   * {@inheritDoc}
   */
  public ApprovalCheckDtls viewProviderApprovalCheck(
    ViewApprovalCheckKey viewApprovalCheckKey) throws InformationalException {

    approvalCheck = approvalCheckDAO.get(viewApprovalCheckKey.approvalCheckID);
    ApprovalCheckDtls approvalCheckDtls = new ApprovalCheckDtls();

    approvalCheckDtls.comments = approvalCheck.getComments();
    approvalCheckDtls.percentage = approvalCheck.getPercentage();
    approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
    approvalCheckDtls.approvalCheckID = approvalCheck.getID();
    approvalCheckDtls.versionNo = approvalCheck.getVersionNo();

    return approvalCheckDtls;
  }

  /**
   * Modifies the approval check details for the provider. Also performs the
   * security check for the provider.
   *
   * @param approvalCheckDtls
   * Approval check details for the provider.
   *
   * @return The approval check ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ApprovalCheckKey modifyProviderApprovalCheck(
    ApprovalCheckDtls approvalCheckDtls) throws InformationalException {
    
    // BEGIN, CR00305191, ASN
    // Raise the pre modifyProviderApprovalCheck API event.
    modifyProviderApprovalCheckEventsDispatcherFactory.get(ProviderApprovalCheckModifyProviderApprovalCheckEvents.class).preModifyProviderApprovalCheck(
      this, approvalCheckDtls);
    // END, CR00305191

    providerSecurity.checkProviderSecurity(
      providerDAO.get(approvalCheckDtls.relatedID));

    approvalCheck = approvalCheckDAO.get(approvalCheckDtls.approvalCheckID);

    approvalCheck.setComments(approvalCheckDtls.comments);
    approvalCheck.setPercentage(approvalCheckDtls.percentage);

    approvalCheck.modifyApprovalCheck(approvalCheckDtls.versionNo);

    ApprovalCheckKey approvalCheckKey = new ApprovalCheckKey();

    approvalCheckKey.approvalCheckID = approvalCheckDtls.approvalCheckID;
    
    // BEGIN, CR00305191, ASN
    // Raise the post modifyProviderApprovalCheck API event.
    modifyProviderApprovalCheckEventsDispatcherFactory.get(ProviderApprovalCheckModifyProviderApprovalCheckEvents.class).postModifyProviderApprovalCheck(
      this, approvalCheckDtls);
    // END, CR00305191

    return approvalCheckKey;
  }

  /**
   * Cancels the approval check for the provider. Also performs the security
   * check for the provider.
   *
   * @param viewApprovalCheckKey
   * Contains the approval check ID for the provider.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelProviderApprovalCheck(
    ViewApprovalCheckKey viewApprovalCheckKey) throws InformationalException {
 
    // BEGIN, CR00305191, ASN
    // Raise the pre cancelProviderApprovalCheck API event.
    cancelProviderApprovalCheckEventsDispatcherFactory.get(ProviderApprovalCheckCancelProviderApprovalCheckEvents.class).preCancelProviderApprovalCheck(
      this, viewApprovalCheckKey);
    // END, CR00305191
    providerSecurity.checkProviderSecurity(
      providerDAO.get(viewApprovalCheckKey.providerID));

    approvalCheck = approvalCheckDAO.get(viewApprovalCheckKey.approvalCheckID);
    approvalCheck.cancel(viewApprovalCheckKey.versionNo);
    
    // BEGIN, CR00305191, ASN
    // Raise the post cancelProviderApprovalCheck API event.
    cancelProviderApprovalCheckEventsDispatcherFactory.get(ProviderApprovalCheckCancelProviderApprovalCheckEvents.class).postCancelProviderApprovalCheck(
      this, viewApprovalCheckKey);
    // END, CR00305191
  }

  /**
   * {@inheritDoc}
   */
  public void modifyApprovalCheck(int versionNo) throws InformationalException {// TODO Auto-generated method stub
  }

  /**
   * {@inheritDoc}
   */
  public void setComments(String comments) {// TODO Auto-generated method stub
  }

  /**
   * {@inheritDoc}
   */
  public void setCost(Money cost) {// TODO Auto-generated method stub
  }

  /**
   * {@inheritDoc}
   */
  public void setOrganisationUnitID(long organisationUnitID) {// TODO Auto-generated method stub
  }

  /**
   * {@inheritDoc}
   */
  public void setPercentage(short percent) {// TODO Auto-generated method stub
  }

  /**
   * {@inheritDoc}
   */
  public void setUsername(String username) {// TODO Auto-generated method stub
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    // TODO Auto-generated method stub
    return null;
  }

  /**
   * {@inheritDoc}
   */
  public Money getCost() {
    // TODO Auto-generated method stub
    return null;
  }

  /**
   * {@inheritDoc}
   */
  public long getOrganisationUnitID() {
    // TODO Auto-generated method stub
    return 0;
  }

  /**
   * {@inheritDoc}
   */
  public short getPercentage() {
    // TODO Auto-generated method stub
    return 0;
  }

  /**
   * {@inheritDoc}
   */
  public long getRelatedID() {
    // TODO Auto-generated method stub
    return 0;
  }

  /**
   * {@inheritDoc}
   */
  public APPROVALRELATEDTYPEEntry getRelatedType() {
    // TODO Auto-generated method stub
    return null;
  }

  /**
   * {@inheritDoc}
   */
  public APPROVALCHECKTYPEEntry getType() {
    // TODO Auto-generated method stub
    return null;
  }

  /**
   * {@inheritDoc}
   */
  public String getUsername() {
    // TODO Auto-generated method stub
    return null;
  }

  /**
   * {@inheritDoc}
   */
  public Long getID() {
    return getDtls().approvalCheckID;
  }

  /**
   * {@inheritDoc}
   */
  public int getVersionNo() {
    // TODO Auto-generated method stub
    return 0;
  }

  /**
   * {@inheritDoc}
   */
  public RECORDSTATUSEntry getLifecycleState() {
    // TODO Auto-generated method stub
    return null;
  }

  /**
   * {@inheritDoc}
   */
  public void cancel(int versionNo) throws InformationalException {// TODO Auto-generated method stub
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// TODO Auto-generated method stub
  }

  public void crossFieldValidation() {}

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {}

  /**
   * {@inheritDoc}
   */
  public boolean getApprovalCheckInformation(Provider provider, ServiceOffering service,
    String userName) throws InformationalException,
      AppException {

    boolean isApprovalRequired = false;

    // If Provider is not specified, check the approval requirement for service
    // offering and user name combination.
    if (provider == null) {
      isApprovalRequired = checkApprovalRequiredForServiceOffering(
        service.getID(), userName);
    } else {

      ProviderOffering providerOffering = getProviderOffering(provider.getID(),
        service.getID());

      long providerOfferingId = 0;

      if (null != providerOffering && providerOffering.getID() != null) {
        providerOfferingId = providerOffering.getID();
      }

      isApprovalRequired = checkApprovalRequiredForProviderOffering(
        providerOfferingId, service.getID(), provider.getID(), userName);
    }

    return isApprovalRequired;
  }

  /**
   * Checks if approval is required for service offering and user combination.
   *
   * @param serviceOfferingID
   * Service Offering ID.
   * @param userName
   * Name of the user.
   *
   * @return Indicates if service delivery for the combination needs approval or
   * not.
   */
  protected boolean checkApprovalRequiredForServiceOffering(final long serviceOfferingID,
    final String userName)
    throws InformationalException, AppException {

    // CASE 1:
    // First check for approval checks for service offering recorded against the
    // user.
    List<ApprovalCheck> approvalCheckList = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.USER, APPROVALRELATEDTYPEEntry.SERVICEOFFERING,
      serviceOfferingID, RECORDSTATUSEntry.NORMAL);

    if (approvalCheckList.size() > 0) {
      List<ApprovalCheck> matchedList = checkForApprovalOnUser(
        approvalCheckList, userName);

      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // Check if there is an approval check configuration for all
    // services at user level. If it exists, consider that.

    List<ApprovalCheck> activeApprovalChecks = approvalCheckDAO.searchByTypeUsernameAndStatus(
      APPROVALCHECKTYPEEntry.USER, APPROVALRELATEDTYPEEntry.SERVICEOFFERING,
      userName, RECORDSTATUSEntry.NORMAL);

    if (activeApprovalChecks.size() > 0) {
      ListIterator<ApprovalCheck> approvalChecksIterator = activeApprovalChecks.listIterator();
      List<ApprovalCheck> matchedList = new ArrayList<ApprovalCheck>();

      while (approvalChecksIterator.hasNext()) {
        approvalCheck = approvalChecksIterator.next();
        if (0 == approvalCheck.getRelatedID()) {
          matchedList.add(approvalCheck);
        }
      }
      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // CASE 2:
    // If no approval checks recorded against the user then
    // search for approval checks against the organization unit that the user
    // belongs to.
    approvalCheckList = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.SERVICEOFFERING, serviceOfferingID,
      RECORDSTATUSEntry.NORMAL);
    if (approvalCheckList.size() > 0) {
      List<ApprovalCheck> matchedList = checkForApprovalOnOrgUnit(
        approvalCheckList, userName);

      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // Check if there is an approval check configuration for all
    // services at organization level to which the user belongs to. If it
    // exists, consider that.

    long orgUnitID = getUserOrganiation(userName);

    activeApprovalChecks = approvalCheckDAO.searchByTypeOrganisationUnitAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.SERVICEOFFERING, orgUnitID,
      RECORDSTATUSEntry.NORMAL);

    if (activeApprovalChecks.size() > 0) {
      ListIterator<ApprovalCheck> approvalChecksIterator = activeApprovalChecks.listIterator();
      List<ApprovalCheck> matchedList = new ArrayList<ApprovalCheck>();

      while (approvalChecksIterator.hasNext()) {
        approvalCheck = approvalChecksIterator.next();
        if (0 == approvalCheck.getRelatedID()) {
          matchedList.add(approvalCheck);
        }
      }
      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // CASE 3:
    // If no approval checks found for the users organization units then
    // search for approval checks on the related type and related identifier.
    approvalCheckList = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.RELATEDTYPE,
      APPROVALRELATEDTYPEEntry.SERVICEOFFERING, serviceOfferingID,
      RECORDSTATUSEntry.NORMAL);
    if (approvalCheckList.size() > 0) {
      return checkForApproval(approvalCheckList);
    }
    // No approval checks found matching for any of the above cases.
    return false;
  }

  /**
   * Checks if approval is required for provider offering, service offering and
   * user combination.
   *
   * @param providerOfferingID
   * Provider Offering ID.
   * @param serviceOfferingID
   * Service Offering ID.
   * @param userName
   * Name of the user.
   *
   * @return Indicates if service delivery for the combination needs approval or
   * not.
   */

  protected boolean checkApprovalRequiredForProviderOffering(
    final long providerOfferingID, long serviceOfferingID, long providerID,
    final String userName) throws InformationalException, AppException {

    // CASE 1:
    // First check for approval checks for provider offering recorded against
    // the user.
    List<ApprovalCheck> approvalCheckList = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.USER, APPROVALRELATEDTYPEEntry.PROVIDEROFFERING,
      providerOfferingID, RECORDSTATUSEntry.NORMAL);

    if (approvalCheckList.size() > 0) {
      List<ApprovalCheck> matchedList = checkForApprovalOnUser(
        approvalCheckList, userName);

      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // Check if there is an approval check configuration for all
    // provider services at user level for that provider. If it exists, consider
    // that.


    List<ApprovalCheck> activeApprovalChecks = approvalCheckDAO.searchByTypeUsernameAndStatus(
      APPROVALCHECKTYPEEntry.USER,
      APPROVALRELATEDTYPEEntry.ALLPROVIDEROFFERINGSFORPROVIDER, userName,
      RECORDSTATUSEntry.NORMAL);

    if (activeApprovalChecks.size() > 0) {
      ListIterator<ApprovalCheck> approvalChecksIterator = activeApprovalChecks.listIterator();
      List<ApprovalCheck> matchedList = new ArrayList<ApprovalCheck>();

      while (approvalChecksIterator.hasNext()) {
        approvalCheck = approvalChecksIterator.next();
        if (approvalCheck.getRelatedID() == providerID) {
          matchedList.add(approvalCheck);
        }
      }
      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // CASE 2:
    // If no approval checks for provider offering recorded against the user,
    // then search for approval
    // checks for the service offering against the user.
    approvalCheckList = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.USER, APPROVALRELATEDTYPEEntry.SERVICEOFFERING,
      serviceOfferingID, RECORDSTATUSEntry.NORMAL);

    if (approvalCheckList.size() > 0) {
      List<ApprovalCheck> matchedList = checkForApprovalOnUser(
        approvalCheckList, userName);

      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // Check if there is an approval check configuration for all
    // services at user level. If it exists, consider that.

    activeApprovalChecks = approvalCheckDAO.searchByTypeUsernameAndStatus(
      APPROVALCHECKTYPEEntry.USER, APPROVALRELATEDTYPEEntry.SERVICEOFFERING,
      userName, RECORDSTATUSEntry.NORMAL);

    if (activeApprovalChecks.size() > 0) {
      ListIterator<ApprovalCheck> approvalChecksIterator = activeApprovalChecks.listIterator();
      List<ApprovalCheck> matchedList = new ArrayList<ApprovalCheck>();

      while (approvalChecksIterator.hasNext()) {
        approvalCheck = approvalChecksIterator.next();
        if (0 == approvalCheck.getRelatedID()) {
          matchedList.add(approvalCheck);
        }
      }
      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // CASE 3:
    // If no approval checks for service offering recorded against the user,
    // then search for approval
    // checks for the provider against the user.
    approvalCheckList = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.USER, APPROVALRELATEDTYPEEntry.PROVIDER,
      providerID, RECORDSTATUSEntry.NORMAL);

    if (approvalCheckList.size() > 0) {
      List<ApprovalCheck> matchedList = checkForApprovalOnUser(
        approvalCheckList, userName);

      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // Check if there is an approval check configuration for all
    // services at user level. If it exists, consider that.

    activeApprovalChecks = approvalCheckDAO.searchByTypeUsernameAndStatus(
      APPROVALCHECKTYPEEntry.USER, APPROVALRELATEDTYPEEntry.PROVIDER, userName,
      RECORDSTATUSEntry.NORMAL);

    if (activeApprovalChecks.size() > 0) {
      ListIterator<ApprovalCheck> approvalChecksIterator = activeApprovalChecks.listIterator();
      List<ApprovalCheck> matchedList = new ArrayList<ApprovalCheck>();

      while (approvalChecksIterator.hasNext()) {
        approvalCheck = approvalChecksIterator.next();
        if (0 == approvalCheck.getRelatedID()) {
          matchedList.add(approvalCheck);
        }
      }
      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // CASE 4:
    // If no approval checks for provider offering, service offering, provider
    // recorded against the user then
    // search for approval checks for provider offering against the organization
    // unit that the user belongs to.
    approvalCheckList = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.PROVIDEROFFERING, providerOfferingID,
      RECORDSTATUSEntry.NORMAL);
    if (approvalCheckList.size() > 0) {
      List<ApprovalCheck> matchedList = checkForApprovalOnOrgUnit(
        approvalCheckList, userName);

      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // Check if there is an approval check configuration for all
    // provider offerings at user level for that provider. If it exists, consider
    // that.
    long orgUnitID = getUserOrganiation(userName);

    activeApprovalChecks = approvalCheckDAO.searchByTypeOrganisationUnitAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.ALLPROVIDEROFFERINGSFORPROVIDER, orgUnitID,
      RECORDSTATUSEntry.NORMAL);

    if (activeApprovalChecks.size() > 0) {
      ListIterator<ApprovalCheck> approvalChecksIterator = activeApprovalChecks.listIterator();
      List<ApprovalCheck> matchedList = new ArrayList<ApprovalCheck>();

      while (approvalChecksIterator.hasNext()) {
        approvalCheck = approvalChecksIterator.next();
        if (approvalCheck.getRelatedID() == providerID) {
          matchedList.add(approvalCheck);
        }
      }
      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // CASE 5:
    // If no approval checks for provider offering recorded for the users
    // organization units then
    // search for approval checks for service offering against the organization
    // unit that the user belongs to.
    approvalCheckList = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.SERVICEOFFERING, serviceOfferingID,
      RECORDSTATUSEntry.NORMAL);
    if (approvalCheckList.size() > 0) {
      List<ApprovalCheck> matchedList = checkForApprovalOnOrgUnit(
        approvalCheckList, userName);

      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // Check if there is an approval check configuration for all
    // provider services at organization level to which the user belongs to. If
    // it exists, consider that.

    activeApprovalChecks = approvalCheckDAO.searchByTypeOrganisationUnitAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.SERVICEOFFERING, orgUnitID,
      RECORDSTATUSEntry.NORMAL);

    if (activeApprovalChecks.size() > 0) {
      ListIterator<ApprovalCheck> approvalChecksIterator = activeApprovalChecks.listIterator();
      List<ApprovalCheck> matchedList = new ArrayList<ApprovalCheck>();

      while (approvalChecksIterator.hasNext()) {
        approvalCheck = approvalChecksIterator.next();
        if (0 == approvalCheck.getRelatedID()) {
          matchedList.add(approvalCheck);
        }
      }
      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // CASE 6:
    // If no approval checks for service offering recorded for the users
    // organization units then
    // search for approval checks for provider against the organization unit
    // that the user belongs to.
    approvalCheckList = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.PROVIDER, providerID, RECORDSTATUSEntry.NORMAL);
    if (approvalCheckList.size() > 0) {
      List<ApprovalCheck> matchedList = checkForApprovalOnOrgUnit(
        approvalCheckList, userName);

      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // Check if there is an approval check configuration for all
    // services at organization level to which the user belongs to. If it
    // exists, consider that.

    activeApprovalChecks = approvalCheckDAO.searchByTypeOrganisationUnitAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.PROVIDER, orgUnitID, RECORDSTATUSEntry.NORMAL);

    if (activeApprovalChecks.size() > 0) {
      ListIterator<ApprovalCheck> approvalChecksIterator = activeApprovalChecks.listIterator();
      List<ApprovalCheck> matchedList = new ArrayList<ApprovalCheck>();

      while (approvalChecksIterator.hasNext()) {
        approvalCheck = approvalChecksIterator.next();
        if (0 == approvalCheck.getRelatedID()) {
          matchedList.add(approvalCheck);
        }
      }
      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }

    // CASE 7:
    // if no approval checks found for provider offering, service offering,
    // provider for the users organization units then search for approval checks
    // on the related type of provider offering.
    approvalCheckList = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.RELATEDTYPE,
      APPROVALRELATEDTYPEEntry.PROVIDEROFFERING, providerOfferingID,
      RECORDSTATUSEntry.NORMAL);
    if (approvalCheckList.size() > 0) {
      return checkForApproval(approvalCheckList);
    }

    // CASE 8:
    // if no approval checks found for provider offering then search for
    // approval checks
    // on the related type of service offering.
    approvalCheckList = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.RELATEDTYPE,
      APPROVALRELATEDTYPEEntry.SERVICEOFFERING, serviceOfferingID,
      RECORDSTATUSEntry.NORMAL);
    if (approvalCheckList.size() > 0) {
      return checkForApproval(approvalCheckList);
    }

    // CASE 9:
    // If no approval checks found for service offering then search for approval
    // checks
    // on the related type of provider.
    approvalCheckList = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.RELATEDTYPE, APPROVALRELATEDTYPEEntry.PROVIDER,
      providerID, RECORDSTATUSEntry.NORMAL);
    if (approvalCheckList.size() > 0) {
      return checkForApproval(approvalCheckList);
    }

    // No approval checks found matching for any of the above cases.
    return false;

  }

  /**
   * Returns a list of approval check objects for the user provided.
   *
   * @param approvalCheckList
   * List of user approval check objects.
   * @param userName
   * The user that the returned approval check list relates to.
   *
   * @return List of approval check objects for the user provided.
   */
  protected List<ApprovalCheck> checkForApprovalOnUser(
    final List<ApprovalCheck> approvalCheckList, final String userName) {

    List<ApprovalCheck> userMatchList = new ArrayList<ApprovalCheck>();

    // Add objects that match this user.
    for (ApprovalCheck matchingApprovalCheck : approvalCheckList) {
      if (matchingApprovalCheck.getUsername().equals(userName)) {
        userMatchList.add(matchingApprovalCheck);
      }
    }
    return userMatchList;
  }

  /**
   * Returns a list of approval check objects for organization units that the
   * user provided belongs to.
   *
   * @param approvalCheckList
   * List of organization unit approval check objects.
   * @param userName
   * The user that must belong to the organization unit recorded on the
   * approval check.
   *
   * @return List of approval check objects for organization units that the user
   * provided belongs to.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected List<ApprovalCheck> checkForApprovalOnOrgUnit(
    final List<ApprovalCheck> approvalCheckList, final String userName)
    throws InformationalException, AppException {

    List<ApprovalCheck> userMatchList = new ArrayList<ApprovalCheck>();
    // Only add objects for org units that this user belongs to.
    SearchByOrgUnitStatusKey searchByOrgUnitStatusKey = new SearchByOrgUnitStatusKey();

    searchByOrgUnitStatusKey.recordStatus = curam.codetable.RECORDSTATUS.NORMAL;
    searchByOrgUnitStatusKey.effectiveDate = curam.util.type.Date.getCurrentDate();
    searchByOrgUnitStatusKey.organisationStructureID = getActiveOrgStructure();
    for (ApprovalCheck matchingApprovalCheck : approvalCheckList) {
      // Check if current user is part of the org unit.
      searchByOrgUnitStatusKey.organisationUnitID = matchingApprovalCheck.getOrganisationUnitID();

      UserForOrgUnitDetailsList userList = UsersFactory.newInstance().searchByOrgUnit(
        searchByOrgUnitStatusKey);

      for (UserForOrgUnitDetails user : userList.dtls.items()) {
        if (user.userName.equals(userName)) {
          userMatchList.add(matchingApprovalCheck);
        }
      }
    }
    return userMatchList;
  }

  /**
   * Retrieves the active organization structure.
   *
   * @return The active organization structure identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  Long getActiveOrgStructure() throws InformationalException, AppException {

    OrganisationStructure organisationStructure = OrganisationStructureFactory.newInstance();
    OrganisationStructureStatus organisationStructureStatus = new OrganisationStructureStatus();

    organisationStructureStatus.statusCode = ORGSTRUCTURESTATUSEntry.ACTIVE.getCode();
    OrganisationStructureID organisationStructureID = organisationStructure.readActiveOrganisationStructureID(
      organisationStructureStatus);

    return organisationStructureID.organisationStructureID;
  }

  /**
   * Finds approval check with the greatest percentage value from the approval
   * check list provided. Uses the approval check object found to determine
   * whether approval is required.
   *
   * @param approvalCheckList
   * The list of approval check object, where one object will be used
   * to determine whether approval is required.
   *
   * @return True if the percentage is greater than a random number between 0
   * and 100. False if the percentage is less than a random number
   * between 0 and 100.
   */
  protected Boolean checkForApproval(final List<ApprovalCheck> approvalCheckList) {

    if (0 == approvalCheckList.size()) {
      return false;
    }
    TreeSet<Integer> sortedSet = new TreeSet<Integer>();

    // Add the approval check records into a set, sorted ascending by approval
    // check percentage.
    for (ApprovalCheck sortedApprovalCheckByPercentage : approvalCheckList) {
      sortedSet.add(
        new Integer(sortedApprovalCheckByPercentage.getPercentage()));
    }

    // Get the value of the maximum percentage in the approval check list.
    int maxPercentageFromList = sortedSet.last().intValue();

    // If the percentage is 0 then return false.
    if (maxPercentageFromList == 0) {
      return false;
    }

    // Get a random number.
    int randNum = new Double(Math.random() * CuramConst.gkOneHundredPercent).intValue();

    // If the percentage recorded against the approval check is greater than or
    // equal to the random number then
    // return true. If the percentage is less than the random number then return
    // false.
    return maxPercentageFromList >= randNum;

  }

  /**
   * Gets the provider offering for the given service offering id and provider id.
   *
   * @param providerId
   * The provider id.
   * @param serviceId
   * The service offering id.
   *
   * @return Provider offering.
   */
  protected ProviderOffering getProviderOffering(long providerId, long serviceId) {

    // Get the provider offering id for the given provider id and service id.(if
    // there is a provider offering)
    Set<ProviderOffering> providerOfferings = providerOfferingDAO.searchProviderOffering(
      providerId, serviceId);
    ProviderOffering providerOffering = providerOfferingDAO.newInstance();

    for (ProviderOffering provdOffering : providerOfferings) {
      if (provdOffering.getDateRange().contains(Date.getCurrentDate())
        && provdOffering.getLifecycleState().equals(
          ProviderOfferingStatusEntry.APPROVED)) {
        providerOffering = provdOffering;
      }
    }
    return providerOffering;
  }

  /**
   * Gets the organization unit to which the user belongs to.
   *
   * @param username
   * The user name.
   *
   * @return The id of the organization unit to which the user belongs to.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  private long getUserOrganiation(String username) throws AppException,
      InformationalException {

    // Details to be returned.
    UserSearchResultsDetails userSearchResults = new UserSearchResultsDetails();
    UserSearchCriteria userSearchCriteria = new UserSearchCriteria();
		
    // BEGIN, CR00305045, MR
    final User user = userDAO.get(username);

    userSearchCriteria.criteria.firstname = user.getFirstName();
		
    // END, CR00305045
    userSearchResults = AdminUserFactory.newInstance().searchUserDetails(
      userSearchCriteria);
    long organizationUnitID = 0;

    for (UserSearchDetailsReference userSearchDetailsRef : userSearchResults.dtls.userSearchDetailsReferenceList.items()) {
      if (username.equalsIgnoreCase(userSearchDetailsRef.username)) {
        organizationUnitID = userSearchDetailsRef.organisationUnitID;
      }
    }
    return organizationUnitID;
  }

}
