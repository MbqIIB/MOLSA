/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.financial.impl.FinancialNotificationEventEntry;
import curam.financial.impl.ServiceInvoiceLineItem;
import curam.util.persistence.Insertable;
import curam.util.type.Money;


/**
 * Interface for associating a concern role communication to service invoice
 * line item.
 *
 */
@ImplementedBy(CommunicationSILILinkImpl.class)
public interface CommunicationSILILink extends Insertable,
    CommunicationSILILinkAccessor {

  /**
   * Gets the service invoice line item associated with communication.
   *
   * @return The service invoice line item associated with communication.
   */
  ServiceInvoiceLineItem getServiceInvoiceLineItem();

  /**
   * Sets the service invoice line item associated with communication.
   *
   * @param serviceInvoiceLineItem
   * Contains service invoice line item associated with
   * communication.
   */
  void setServiceInvoiceLineItem(
    final ServiceInvoiceLineItem serviceInvoiceLineItem);

  /**
   * Sets the communication.
   *
   * @param communictionID
   * The unique system generated identifier for the communication
   * record.
   */
  void setCommunicationID(final long communictionID);

  /**
   * Sets an overpayment or under payment amount generated as part of service
   * invoice line item correction.
   *
   * @param value
   * An overpayment or under payment amount generated as part of
   * service invoice line item correction.
   */
  public void setAmount(final Money value);
  
  // BEGIN, CR00304493, MR
  /**
   * Sets the financial notification event.
   *
   * @param event
   * Contains financial notification event.
   */
  public void setEvent(final FinancialNotificationEventEntry event);
  
  // END, CR00304493
}
