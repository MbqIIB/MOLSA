/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.util.exception.InformationalException;


/**
 * A reason why a background check has failed.
 */
@ImplementedBy(BackgroundCheckFailureReasonImpl.class)
public interface BackgroundCheckFailureReason extends
    BaseBackgroundCheckFailureReason, BackgroundCheckFailureReasonAccessor {
 
  /**
   * Sets the Background Check associated with the BackgroundCheckFailureReason.
   *
   * @param providerBackgroundCheck
   * The background check associated with the
   * BackgroundCheckFailureReason.
   */
  void setProviderBackgroundCheck(
    final ProviderBackgroundCheck providerBackgroundCheck);

  /**
   * Gets the Background Check associated with the BackgroundCheckFailureReason.
   *
   * @return ProviderBackgroundCheck associated with the
   * BackgroundCheckFailureReason.
   */
  ProviderBackgroundCheck getProviderBackgroundCheck();

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the background check failure reason events functionality
   * surrounding the cancel method.
   */
  public interface BackgroundCheckFailureReasonCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.provider.impl.BackgroundCheckFailureReason#cancel}
     *
     * @param backgroundCheckFailureReason
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(
      BackgroundCheckFailureReasonAccessor backgroundCheckFailureReason,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.provider.impl.BackgroundCheckFailureReason#cancel}
     *
     * @param backgroundCheckFailureReason
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(
      BackgroundCheckFailureReasonAccessor backgroundCheckFailureReason,
      Integer versionNo) throws InformationalException;
  }


  /**
   * Interface to the background check failure reason events functionality
   * surrounding the modify method.
   */
  public interface BackgroundCheckFailureReasonModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.BackgroundCheckFailureReason#modify}
     *
     * @param backgroundCheckFailureReason
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(
      BackgroundCheckFailureReasonAccessor backgroundCheckFailureReason,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.BackgroundCheckFailureReason#modify}
     *
     * @param backgroundCheckFailureReason
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(
      BackgroundCheckFailureReasonAccessor backgroundCheckFailureReason,
      Integer versionNo) throws InformationalException;
  }


  /**
   * Interface to the background check failure reason events functionality
   * surrounding the insert method.
   */
  public interface BackgroundCheckFailureReasonInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.BackgroundCheckFailureReason#insert}
     *
     * @param backgroundCheckFailureReason
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(
      BackgroundCheckFailureReasonAccessor backgroundCheckFailureReason)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.BackgroundCheckFailureReason#insert}
     *
     * @param backgroundCheckFailureReason
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(
      BackgroundCheckFailureReasonAccessor backgroundCheckFailureReason)
      throws InformationalException;
  }
  // END, CR00144381
}
