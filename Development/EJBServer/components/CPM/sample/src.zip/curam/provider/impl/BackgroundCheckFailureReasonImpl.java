/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.Inject;

import curam.message.impl.BACKGROUNDCHECKExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.provider.BackgroundCheckResult;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.type.CodeTableItemIdentifier;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.BackgroundCheckFailureReason}.
 */
// BEGIN, CR00183213, SS
public class BackgroundCheckFailureReasonImpl extends BaseBackgroundCheckFailureReasonImpl implements
  BackgroundCheckFailureReason {
  // END, CR00183213

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<BackgroundCheckFailureReasonCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<BackgroundCheckFailureReasonModifyEvents> modifyEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<BackgroundCheckFailureReasonInsertEvents> insertEventDispatcherFactory;

  // END, CR00235789

  /**
   * Reference to ProviderBackgroundCheckDAO
   */
  @Inject
  protected ProviderBackgroundCheckDAO providerBackgroundCheckDAO;

  /**
   * Reference to ProviderSecurity
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected BackgroundCheckFailureReasonImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213

  /**
   * {@inheritDoc}
   */
  public ProviderBackgroundCheck getProviderBackgroundCheck() {
    final long providerBackgroundCheckID = getDtls().providerBackgroundCheckID;

    return providerBackgroundCheckID == 0
      ? null
      : providerBackgroundCheckDAO.get(providerBackgroundCheckID);
  }

  /**
   * Validates that changes made to Background Check Failure Reason entity on
   * the database are consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECKFAILUREREASON_FV_DATE_BEFORE_RECEIPT_DATE} -
   * If the occurrence date is after the receipt date of the Background Check.</li>
   * </ul>
   */
  public void crossEntityValidation() {
    // get the Background check record
    final ProviderBackgroundCheck providerBackgroundCheck = providerBackgroundCheckDAO.get(
      getDtls().providerBackgroundCheckID);

    // checking if the occurrence date is before the receipt date
    if (getDtls().occurrenceDate.after(
      providerBackgroundCheck.getDateRange().end())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECKFAILUREREASON_FV_DATE_BEFORE_RECEIPT_DATE(
          getDtls().occurrenceDate,
          providerBackgroundCheck.getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * Modifies a background check failure reason record after checking for the
   * provider security.
   *
   * @param versionNo
   * Version number of the record.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If provider status is closed.
   */
  public void modify(final Integer versionNo) throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(
      providerBackgroundCheckDAO.get(getDtls().providerBackgroundCheckID).getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre modify background check failure reason event.
    modifyEventDispatcherFactory.get(BackgroundCheckFailureReasonModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // if the status of the provider is closed
    if (providerBackgroundCheckDAO.get(getDtls().providerBackgroundCheckID).getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 52);
      ValidationHelper.failIfErrorsExist();
    }

    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify background check failure reason event.
    modifyEventDispatcherFactory.get(BackgroundCheckFailureReasonModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * Cancels a background check failure reason record after checking for the
   * provider security.
   *
   * @param versionNo
   * Version Number of the record.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If provider status is closed.
   */
  public void cancel(final int versionNo) throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(
      providerBackgroundCheckDAO.get(getDtls().providerBackgroundCheckID).getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre cancel background check failure reason event.
    cancelEventDispatcherFactory.get(BackgroundCheckFailureReasonCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    // if the status of the provider is closed
    if (providerBackgroundCheckDAO.get(getDtls().providerBackgroundCheckID).getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 51);
      ValidationHelper.failIfErrorsExist();
    }

    super.cancel(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post cancel background check failure reason event.
    cancelEventDispatcherFactory.get(BackgroundCheckFailureReasonCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Inserts a background check failure reason after checking for the provider
   * security.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider status is closed.
   * @throws InformationalException
   * {@link curam.message.BACKGROUNDCHECK#ERR_BACKGROUNDCHECKFAILUREREASON_XRV_FAILURE_REASON_CANNOT_ADDED_IF_RESULT_PASS_UNDER_INVESTIGATION} -
   * If failure reason is added when the background check result is
   * passed or under investigation.
   */
  @Override
  public void insert() throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(
      providerBackgroundCheckDAO.get(getDtls().providerBackgroundCheckID).getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre insert background check failure reason event.
    insertEventDispatcherFactory.get(BackgroundCheckFailureReasonInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    // if the status of the provider is closed
    if (providerBackgroundCheckDAO.get(getDtls().providerBackgroundCheckID).getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 53);
      ValidationHelper.failIfErrorsExist();
    }

    // get the Background check record
    final ProviderBackgroundCheck providerBackgroundCheck = providerBackgroundCheckDAO.get(
      getDtls().providerBackgroundCheckID);

    if ((curam.provider.impl.BackgroundCheckResultEntry.PASS.getCode().equals(
      providerBackgroundCheck.getResult().getCode()))
        || (curam.provider.impl.BackgroundCheckResultEntry.UNDERINVESTIGATION.getCode().equals(
          providerBackgroundCheck.getResult().getCode()))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BACKGROUNDCHECKExceptionCreator.ERR_BACKGROUNDCHECKFAILUREREASON_XRV_FAILURE_REASON_CANNOT_ADDED_IF_RESULT_PASS_UNDER_INVESTIGATION(
          new CodeTableItemIdentifier(BackgroundCheckResult.TABLENAME,
          providerBackgroundCheck.getResult().getCode())),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert background check failure reason event.
    insertEventDispatcherFactory.get(BackgroundCheckFailureReasonInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderBackgroundCheck(
    ProviderBackgroundCheck providerBackgroundCheck) {
    getDtls().providerBackgroundCheckID = (providerBackgroundCheck == null
      ? 0
      : providerBackgroundCheck.getID());
  }
}
