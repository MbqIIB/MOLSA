/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.codetable.impl.CURRENCYEntry;
import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.ContractVersionAccessor;
import curam.serviceoffering.impl.ServiceOfferingAccessor;
import curam.util.persistence.StandardEntity;
import java.util.List;
import java.util.Set;


/**
 * Accessor interface for {@linkplain  ProviderOrganization}.
 */
public interface ProviderOrganizationAccessor extends StandardEntity {

  /**
   * Gets the immutable set of contracts for this provider organization. A
   * formal agreement between the organization and a provider/provider group to
   * provide service(s).
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of contracts for this provider organization.
   */
  Set<? extends ContractVersionAccessor> getContracts();

  /**
   * Gets the currency type for this provider organization. The type of currency
   * that the provider organization will be paid in.
   *
   * @return CURRENCYEntry the currency type for this provider organization.
   */
  CURRENCYEntry getCurrencyType();

  /**
   * Gets the method of payment for this provider organization. The mechanism
   * used to make payments to the provider.
   *
   * @return long the method of payment for this provider organization.
   */
  long getMethodOfPayment();

  /**
   * Gets the payment frequency for this provider organization. The frequency at
   * which the organization will calculate and make payments to the provider.
   *
   * @return String the payment frequency for this provider organization.
   */
  String getPaymentFrequency();

  /**
   * Gets the immutable set of provider participants for this provider
   * organization.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return Immutable set of provider participants.
   */
  Set<? extends ProviderParticipantAccessor> getProviderParticipants();

  /**
   * Gets the immutable set of provider members for this provider organization.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return Immutable set of provider members.
   */
  Set<? extends ProviderMemberAccessor> getProviderMembers();

  /**
   * Gets the immutable set of provider parties for this provider organization.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of provider members and provider participants.
   */
  Set<? extends ProviderPartyAccessor> getProviderParties();

  /**
   * Gets the immutable set of service offerings which are approved to be
   * provided by <i>all</i> the providers on the contract version specified.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @param contractVersion
   * The version of the contract for which common approved service
   * offerings are sought.
   *
   * @return The immutable set of service offerings which are approved to be
   * provided by <i>all</i> the providers on the contract version
   * specified.
   */
  Set<? extends ServiceOfferingAccessor> getCommonApprovedProviderServiceOfferings(
    final ContractVersion contractVersion);

  /**
   * Gets the immutable list of Incidents for the provider organization.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable list of Incidents for a provider organization.
   */
  List<? extends ProviderIncidentAccessor> getIncidents();

}
