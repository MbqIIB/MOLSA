/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.StandardDAO;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * Data access for {@linkplain curam.provider.impl.ProviderGroup}.
 */
@ImplementedBy(ProviderGroupDAOImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ProviderGroupDAO extends StandardDAO<ProviderGroup> {

  // ___________________________________________________________________________
  /**
   * Searches all provider groups for which the user is the assigned Resource
   * Manager.
   *
   * @param userName
   * UserNameKey of the user to be searched.
   *
   * @return Set<ProviderGroup> set of provider groups that belong to resource
   * manager.
   */
  Set<ProviderGroup> searchProviderGroupsForResourceManager(
    String userName);

  // BEGIN, CR00170625, KR
  /**
   * Searches all Provider Groups that match the criteria entered.
   *
   * The search can be performed in two ways - Either by executing the modeled
   * query or by executing the dynamically constructed query. To execute the
   * dynamically constructed query enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param name
   * query parameter name of the provider group.
   * @param referenceNumber
   * reference of the provider group.
   * @param street1
   * query parameter street1 of the provider group.
   * @param city
   * query parameter city of the provider group.
   *
   * @return Set<ProviderGroup> set of provider groups that belong to resource
   * manager.
   */
  // END, CR00170625
  Set<ProviderGroup> searchBy(final String name,
    final String referenceNumber, final String street1, final String city);

  // ___________________________________________________________________________
  /**
   * Reads all provider groups enrolled with the organization.
   *
   * @return Set<ProviderGroup> all provider groups enrolled with the
   * organization.
   */
  Set<ProviderGroup> readAll();

}
