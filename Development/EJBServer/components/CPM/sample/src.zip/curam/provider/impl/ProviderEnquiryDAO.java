/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.List;
import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.StandardDAO;
import curam.util.type.Date;
import curam.util.type.DateTime;


/**
 * Data access for
 * {@linkplain curam.provider.impl.ProviderEnquiry}.
 */
@ImplementedBy(ProviderEnquiryDAOImpl.class)
public interface ProviderEnquiryDAO extends StandardDAO<ProviderEnquiry> {

  /**
   * Searches for all provider enquiries that are assigned to a specific user.
   *
   * @param userName
   * the userName to search for.
   * @return Set<ProviderEnquiry> The Provider Enquiries which have the name
   * specified.
   */
  Set<ProviderEnquiry> searchBy(final String userName);

  // BEGIN, CR00170625, KR
  /**
   * Searches for all Provider Enquiries that match the criteria entered,
   * ordered by Name.
   *
   * The search can be performed in two ways - Either by executing the modeled
   * query or by executing the dynamically constructed query. To execute the
   * dynamically constructed query enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param name
   * query parameter.
   * @param referenceNumber
   * query parameter.
   * @param street1
   * query parameter.
   * @param city
   * query parameter.
   * @param searchByName
   * query parameter.
   * @param searchByReferenceNumber
   * query parameter.
   * @param searchByStreet1
   * query parameter.
   * @param searchByCity
   * query parameter.
   * @param addressLine1Type
   * query parameter.
   * @param cityTypeCode
   * query parameter.
   * @param enquiryStatus
   * query parameter.
   *
   * @return Set<ProviderEnquiry> The set of Provider Enquiries matching the
   * criteria specified.
   */
  // END, CR00170625
  Set<ProviderEnquiry> searchBy(final java.lang.String name,
    final java.lang.String referenceNumber, final java.lang.String street1,
    final java.lang.String city, final java.lang.Boolean searchByName,
    final java.lang.Boolean searchByReferenceNumber, final java.lang.Boolean searchByStreet1,
    final java.lang.Boolean searchByCity, final java.lang.String addressLine1Type,
    final java.lang.String cityTypeCode, final java.lang.String enquiryStatus);
  
  // BEGIN, CR00216313, RD
  // BEGIN, CR00225866, GP
  /**
   * Searches all the Provider Enquiry for the search criteria specified.
   *
   * @param ownerName
   * The owner of the Provider Enquiry.
   * @param recordStatus
   * The enquiry status.
   * @param startDate
   * The start date of the duration during which we have to search for
   * an enquiry.
   * @param endDateTime
   * The end date time of the duration during which we have to search
   * for an enquiry.
   *
   * @return The set of Provider Enquiries matching the search criteria.
   */
  Set<ProviderEnquiry> searchByDateRangeOwnerAndEnquiryStatus(
    final String ownerName, final String recordStatus, Date startDate,
    DateTime endDateTime);
  // END, CR00225866
  // END, CR00216313

  // BEGIN, CR00260608, GP
  /**
   * Searches all provider enquiries for the search criteria specified.
   *
   * @param enquiryStatus
   * The enquiry status.
   * @param startDateTime
   * The start date time of the duration during which we have to search
   * for an enquiry.
   * @param endDateTime
   * The end date time of the duration during which we have to search
   * for an enquiry.
   *
   * @return The set of Provider Enquiries matching the search criteria.
   */
  List<ProviderEnquiry> searchByDateRangeAndEnquiryStatus(
    final EnquiryStatusEntry enquiryStatus, final DateTime startDateTime,
    final DateTime endDateTime);
  // END, CR00260608
}
