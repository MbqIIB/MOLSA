/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.ReaderDAO;


/**
 * Data access for  {@linkplain curam.provider.impl.ProviderParty}.
 */
@ImplementedBy(ProviderPartyDAOImpl.class)
public interface ProviderPartyDAO extends ReaderDAO<Long, ProviderParty> {
  // ___________________________________________________________________________
  /**
   * Searches for the provider parties that belong to the provider organization.
   *
   * @param providerOrganization
   * the provider organization for whom the parties are listed.
   * @return Set<ProviderParty> the provider parties which have been associated
   * with the provider organization.
   */
  Set<ProviderParty> searchBy(
    final ProviderOrganization providerOrganization);
}
