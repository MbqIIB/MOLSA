/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2009, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;

import curam.codetable.impl.PREFERREDSERVICEENQUIRYMETHODEntry;
import curam.financial.impl.ServiceInvoiceLineItemAccessor;
import curam.homestudy.impl.HomeStudyAccessor;
import curam.place.impl.CompartmentAccessor;
import curam.place.impl.PlaceAccessor;
import curam.providerservice.impl.ProviderOfferingAccessor;
import curam.serviceoffering.impl.ServiceOfferingAccessor;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.DateRange;
import curam.util.type.DateTimeRange;
import curam.workspaceservices.localization.impl.LocalizableTextAccessor;


/**
 * Accessor interface for {@linkplain  Provider}.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ProviderAccessor extends StandardEntity {

  /**
   * Gets the physical capacity. Defines the actual capacity of the provider.
   *
   * @return int the actual capacity of the provider.
   */
  int getPhysicalCapacity();

  /**
   * Gets the immutable set of service offerings for the provider. An offering
   * from a Provider that a client can be authorized by the organization to
   * receive.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of service offerings for the provider.
   */
  Set<? extends ServiceOfferingAccessor> getServiceOfferings();

  /**
   * Gets the immutable set of provider offerings for the provider. The Provider
   * Offering defines the period during which a provider offers a service to the
   * organization's clients.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of provider offerings for the provider.
   */
  Set<? extends ProviderOfferingAccessor> getProviderOfferings();

  /**
   * Gets the immutable set of provider specialties for the provider. Areas in
   * which a provider has particular experience or expertise.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of provider specialties for the provider.
   */
  Set<? extends ProviderSpecialtyAccessor> getProviderSpecialties();

  /**
   * Gets the immutable primary category periods for the provider.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable primary category period for the provider.
   */
  ProviderCategoryPeriodAccessor getPrimaryProviderCategoryPeriod();

  /**
   * Gets the immutable set of provider category periods associated to the
   * provider.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of category periods for the provider.
   */
  Set<? extends ProviderCategoryPeriodAccessor> getProviderCategoryPeriods();

  /**
   * Gets the immutable set of compartments for the provider.
   *
   * @return The immutable set of compartments for the provider.
   */
  Set<? extends CompartmentAccessor> getCompartments();

  /**
   * Gets the immutable set of available places for a provider in the given date
   * range.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @param dateRange
   * Date range to be searched for.
   *
   * @return immutable set of Places which are available in the specified date
   * range.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  Set<? extends PlaceAccessor> getAvailablePlacesInDateRange(
    final DateRange dateRange) throws AppException, InformationalException;

  /**
   * Gets the immutable set of accreditations for the provider. Accreditations
   * from third party organizations achieved by the provider.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of accreditations for the provider.
   */
  Set<? extends ProviderAccreditationAccessor> getAccreditations();

  /**
   * Gets the immutable set of BackgroundChecks for the provider. Background
   * checks undertaken on employees or household members of a provider.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of BackgroundChecks for the provider.
   */
  Set<? extends ProviderBackgroundCheckAccessor> getProviderBackgroundChecks();

  /**
   * Gets the immutable set of service centers for the provider. Locations from
   * where a provider can deliver services.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of service centers for the provider.
   */
  Set<? extends ProviderServiceCenterAccessor> getProviderServiceCenters();

  /**
   * Gets the immutable set of home studies for provider. A study conducted on a
   * provider to ascertain that the living conditions and environment of the
   * home are suitable for the care of the agency's clients.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of Home Studies for the provider.
   */
  Set<? extends HomeStudyAccessor> getHomeStudies();

  /**
   * Gets the immutable set of service invoice line items for the provider. A
   * service invoice line item contains information entered by a user about one
   * specific line item on a service invoice.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of service invoice line items for the provider.
   */
  Set<? extends ServiceInvoiceLineItemAccessor> getServiceInvoiceLineItems();

  /**
   * Gets the immutable Provider Enquiry if the Provider is enrolled from an
   * enquiry otherwise it returns a null.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable Provider Enquiry from which this Provider is
   * enrolled.
   */
  ProviderEnquiryAccessor getProviderEnquiry();

  /**
   * Gets the reservation grace period for the provider.
   *
   * @return int The reservation grace period in days.
   */
  short getReservationGracePeriod();

  /**
   * Checks if attendance tracking is enabled for the provider.
   *
   * @return Returns true is attendance tracking is enabled, else returns false.
   */
  boolean isAttendanceTrackingEnabled();

  /**
   * Checks if paper roster is required for the provider.
   *
   * @return Returns true if paper roster is required, else returns false.
   */
  boolean isPaperRosterRequired();

  /**
   * Method to check if provider is 'Approved'.
   *
   * @return Returns True if provider is approved, else returns false.
   */
  boolean isProviderApproved();

  /**
   * Gets the override maximum deduction rate indicator value used in all the
   * product deliveries of the provider.
   *
   * @return Override maximum deduction rate indicator.
   */
  boolean isOverrideMDR();
  
  // BEGIN, CR00178272, AK
  /**
   * Gets the immutable localized text object for the attribute areas served
   * information.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable localized text object.
   */
  LocalizableTextAccessor getAreasServedInfo();
  
  /**
   * Gets the localized text ID of the provider attribute, areas served
   * information.
   *
   * @return The areas served information text ID.
   */
  long getAreasServedInfoTextID();

  /**
   * Gets the immutable localized text object for the attribute, client
   * information.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable localized text object.
   */
  LocalizableTextAccessor getClientInfo();
  
  /**
   * Gets the localized text ID of the provider attribute, client information.
   *
   * @return The client information text ID.
   */
  long getClientInfoTextID();

  /**
   * Gets the preferred service enquiry method for the provider offering.
   *
   * @return The preferred service enquiry method entry.
   */
  PREFERREDSERVICEENQUIRYMETHODEntry getPreferredServiceEnquiryMethod();
  // END, CR00178272
   
  // BEGIN, CR00198774, RPB
  /**
   * Gets the start date time and the end date time of the provider. The date
   * time range returned will be in the client specific time zone. Client
   * specific time zone is obtained from the transaction information.
   *
   * * @return The "lifetime" of the provider in the client time zone.
   */
  DateTimeRange getDateTimeRange();
  // END, CR00198774
}
