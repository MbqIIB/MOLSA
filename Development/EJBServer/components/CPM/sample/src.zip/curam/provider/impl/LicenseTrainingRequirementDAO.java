/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.cpm.sl.entity.struct.LicenseTrainingRequirementSearchDetailsList;
import curam.cpm.sl.entity.struct.LicenseTrainingRequirementSearchKey;
import curam.training.impl.Training;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain curam.provider.impl.LicenseTrainingRequirement}.
 */
@ImplementedBy(LicenseTrainingRequirementDAOImpl.class)
public interface LicenseTrainingRequirementDAO extends
    StandardDAO<LicenseTrainingRequirement> {

  // ___________________________________________________________________________
  /**
   * Searches all the training requirement of a license type.
   *
   * @param licenseType
   * The code of the license type.
   * @return Set<LicenseTrainingRequirement> The training requirement of a
   * license type.
   */
  Set<LicenseTrainingRequirement> searchByLicenseType(final String licenseType);

  // ___________________________________________________________________________
  /**
   * Searches the License Training Requirements for a specified Training.
   *
   * @param training
   * The Training reference.
   * @return Set<LicenseTrainingRequirement> The list of License Training
   * Requirements for a specified Training.
   */
  Set<LicenseTrainingRequirement> searchByTraining(final Training training);

  // ___________________________________________________________________________
  /**
   * Gets the Active License Training Requirements for a specified Training.
   *
   * @param training
   * The Training reference.
   *
   * @return Set<LicenseTrainingRequirement> The list of License Training
   * Requirements for a specified Training.
   */
  Set<LicenseTrainingRequirement> getActiveLicenseTrainingRequirementsByTraining(
    final Training training);

  // ___________________________________________________________________________
  /**
   * Retrieves all the trainings that are listed as training requirement of
   * any license types currently held by a provider.
   *
   * @param key
   * LicenseTrainingRequirementSearchKey containing provider ID.
   * @return List of Training Requirements.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  LicenseTrainingRequirementSearchDetailsList retrieveForProvider(
    LicenseTrainingRequirementSearchKey key) throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Retrieves all the trainings that are listed as training requirement of
   * any license types currently held by a provider group.
   *
   * @param key
   * LicenseTrainingRequirementSearchKey containing provider group ID.
   * @return List of Training Requirements.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  LicenseTrainingRequirementSearchDetailsList retrieveForProviderGroup(
    LicenseTrainingRequirementSearchKey key) throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Retrieves all the trainings that are listed as training requirement of
   * any license types currently held by a provider group member.
   *
   * @param key
   * LicenseTrainingRequirementSearchKey containing provider group member ID.
   * @return List of Training Requirements.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  LicenseTrainingRequirementSearchDetailsList retrieveForProviderGroupMember(
    LicenseTrainingRequirementSearchKey key) throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Retrieves all the trainings that are listed as training requirement of
   * any license types currently held by a provider member.
   *
   * @param key
   * LicenseTrainingRequirementSearchKey containing provider member ID.
   * @return List of Training Requirements.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  LicenseTrainingRequirementSearchDetailsList retrieveForProviderMember(
    LicenseTrainingRequirementSearchKey key) throws AppException,
      InformationalException;

}
