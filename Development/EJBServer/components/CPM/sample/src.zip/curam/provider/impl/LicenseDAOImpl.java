/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.google.inject.Singleton;

import curam.cpm.sl.entity.impl.LicenseAdapter;
import curam.cpm.sl.entity.struct.LicenseDtls;
import curam.util.persistence.StandardDAOImpl;
import curam.util.type.Date;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.LicenseDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class LicenseDAOImpl extends StandardDAOImpl<License, LicenseDtls>
  implements LicenseDAO {
  // END, CR00183213

  protected static final LicenseAdapter adapter = new LicenseAdapter();

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected LicenseDAOImpl() {
    // END, CR00183213
    super(adapter, License.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<License> searchByLicenseNumberAndType(
    final String number, final String licenseType, final String licenseStatus,
    final Date dateIssued, final Date expirationDate,
    final boolean renewedInd, long providerConcernRoleID) {

    return newSet(
      adapter.searchByLicenseNumberAndType(number, licenseType, licenseStatus,
      dateIssued, expirationDate, renewedInd, providerConcernRoleID));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<License> searchActiveLicenseByIssuerTypeAndExpirationDate(
    final String issuer, final String licenseType, final Date dateIssued,
    final Date expirationDate, final String licenseStatus,
    final boolean renewedInd, long providerConcernRoleID) {

    return newSet(
      adapter.searchActiveLicenseByIssuerTypeAndExpirationDate(issuer,
      licenseType, dateIssued, expirationDate, licenseStatus, renewedInd,
      providerConcernRoleID));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<License> searchLicensesByProvider(Provider provider) {

    return newSet(adapter.searchLicensesByProvider(provider.getID()));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<License> readAll() {

    return newSet(adapter.readAll());
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<License> searchApprovedLicencesByProviderAndType(
    long providerConcernRoleID, String licenseType) {

    final List<curam.provider.impl.License> licenses = new ArrayList<curam.provider.impl.License>(
      newSet(
        adapter.searchLicencesByProviderAndType(providerConcernRoleID,
        licenseType)));

    Iterator<License> i = licenses.iterator();

    while (i.hasNext()) {

      License license = i.next();

      if (!license.getLifecycleState().equals(LicenseStatusEntry.APPROVED)) {

        i.remove();
      }
    }

    return licenses;

  }
}
