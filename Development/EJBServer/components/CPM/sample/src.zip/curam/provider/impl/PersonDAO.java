/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.entity.struct.SearchPersonDetails1List;
import curam.cpm.sl.entity.struct.SearchPersonDetailsList;
import curam.cpm.sl.entity.struct.SearchUnassignedProviderMemberDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;

import java.util.Set;


/**
 * Data access for {@linkplain curam.provider.impl.Person}.
 */
@ImplementedBy(PersonDAOImpl.class)
public interface PersonDAO extends StandardDAO<Person> {

  // BEGIN, CR00170625, KR
  /**
   * Searches person by name and address details. * The search can be performed
   * in two ways - Either by executing the modeled query or by executing the
   * dynamically constructed query. To execute the dynamically constructed query
   * enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param referenceNo
   * Reference number of person.
   * @param addressLine1
   * Address line details.
   * @param firstName
   * First name of the person.
   * @param lastName
   * Last name of the person.
   * @param personWithTraining
   * Search persons having training.
   * @param personWithProviderMembership
   * Search persons who are active active members.
   *
   * @return SearchPersonDetailsList List of person details that matches the
   * search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, this method has been replaced by
   * {@link #searchPersonByNameAndAddress1()}.
   */
  // END, CR00170625
  @Deprecated
  public SearchPersonDetailsList searchPersonByNameAndAddress(
    String referenceNo, String addressLine1, String firstName,
    String lastName, boolean personWithTraining,
    boolean personWithProviderMembership) throws AppException,
      InformationalException;

  /**
   * Searches person by name and address details.
   *
   * The search can be performed in two ways - Either by executing the modeled
   * query or by executing the dynamically constructed query. To execute the
   * dynamically constructed query enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param referenceNo
   * Reference number of person.
   * @param addressLine1
   * Address line details.
   * @param firstName
   * First name of the person.
   * @param lastName
   * Last name of the person.
   * @param personWithTraining
   * Search persons having training.
   * @param personWithProviderMembership
   * Search persons who are active active members.
   *
   * @return SearchPersonDetailsList List of person details that matches the
   * search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchPersonDetails1List searchPersonByNameAndAddress1(
    String referenceNo, String addressLine1, String firstName,
    String lastName, boolean personWithTraining,
    boolean personWithProviderMembership) throws AppException,
      InformationalException;

  // BEGIN, CR00170625, KR
  /**
   * Searches representative by name and address details.
   *
   * The search can be performed in two ways - Either by executing the modeled
   * query or by executing the dynamically constructed query. To execute the
   * dynamically constructed query enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param referenceNo
   * Reference number of person.
   * @param addressLine1
   * Address line details.
   * @param firstName
   * First name of the person.
   * @param lastName
   * Last name of the person.
   * @param personWithTraining
   * Search persons having training.
   * @param personWithProviderMembership
   * Search persons who are active active members.
   *
   * @return SearchPersonDetailsList List of person details that matches the
   * search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, this method has been replaced by
   * {@link #searchRepresentativeByNameAndAddress1()}.
   */
  // END, CR00170625
  @Deprecated
  public SearchPersonDetailsList searchRepresentativeByNameAndAddress(
    String referenceNo, String addressLine1, String firstName,
    String lastName, boolean personWithTraining,
    boolean personWithProviderMembership) throws AppException,
      InformationalException;

  /**
   * Searches representative by name and address details.
   *
   * The search can be performed in two ways - Either by executing the modeled
   * query or by executing the dynamically constructed query. To execute the
   * dynamically constructed query enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param referenceNo
   * Reference number of person.
   * @param addressLine1
   * Address line details.
   * @param firstName
   * First name of the person.
   * @param lastName
   * Last name of the person.
   * @param personWithTraining
   * Search persons having training.
   * @param personWithProviderMembership
   * Search persons who are active active members.
   *
   * @return SearchPersonDetailsList List of person details that matches the
   * search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00170625
  public SearchPersonDetails1List searchRepresentativeByNameAndAddress1(
    String referenceNo, String addressLine1, String firstName,
    String lastName, boolean personWithTraining,
    boolean personWithProviderMembership) throws AppException,
      InformationalException;

  // BEGIN, CR00170625, KR
  /**
   * Retrieves the list provider member details associated with the person.
   *
   * The search can be performed in two ways - Either by executing the modeled
   * query or by executing the dynamically constructed query. To execute the
   * dynamically constructed query enable the environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' by setting the value to
   * true. Dynamically constructed query resolves the optionality and predicate
   * problems. To execute the modeled query either don't configure or set the
   * value of environment configuration
   * 'curam.cpm.dynamicsql.ENV_DYNAMIC_SQL_ENABLED' to false.
   *
   * @param partyConcernRoleID
   * Person concern role ID.
   * @param category
   * Category of relationship between provider party and provider
   * @param status
   * Status of the provider member.
   *
   * @return Set<Person> Set of person that matches the search criteria.
   */
  // END, CR00170625
  public Set<Person> listPersonMembershipHistory(Long partyConcernRoleID,
    ProviderPartyCategoryEntry category, RECORDSTATUSEntry status);

  // BEGIN, CR00205270, ASN
  /**
   * Searches unassigned provider member.
   *
   * @param referenceNo
   * Reference number of person.
   * @param firstName
   * First name of the person.
   * @param lastName
   * Last name of the person.
   * @param personWithTraining
   * Search persons having training.
   *
   * @return SearchPersonDetailsList List of person details that matches the
   * search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public Set<SearchUnassignedProviderMemberDetails> searchUnassignedProviderMember(
    final String referenceNo, final String firstName, final String lastName,
    final boolean personWithTraining) throws AppException,
      InformationalException;
  // END, CR00205270
}
