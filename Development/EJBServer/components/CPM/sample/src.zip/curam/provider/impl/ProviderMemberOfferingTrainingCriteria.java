/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.cpm.facade.struct.InformationalMessageList;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Implementable;


/**
 * An agency may have a specific way in which they want to use training
 * information to link provider offering and provider member. The solution will 
 * support the notification to a user where training requirements for one or 
 * more services are neither 'Complete' nor 'Waived' for a provider member. 
 * However other solutions may wish to prevent the creation of a Provider Member 
 * record if this validation is not satisfied.
 */
@ImplementedBy(ProviderMemberOfferingTrainingCriteriaImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ProviderMemberOfferingTrainingCriteria {

  /**
   * If training requirements are specified for the Provider Offering, then all
   * trainings marked as 'Required' must be 'Completed' or 'Waived' for the 
   * provider members. 
   *
   * @param providerOfferings
   * Provider Offerings that is to be linked with the Provider Member.
   * @param providerMember
   * Provider Member entity.
   *
   * @return List of informational message.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderMemberOfferingTrainingCriteria#checkProviderMemberTrainingProgram(String, ProviderMember)
   * The default implementation -
   * curam.provider.impl.ProviderMemberOfferingTrainingCriteriaImpl#checkProviderMemberTrainingProgram(String, ProviderMember).
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  InformationalMessageList checkProviderMemberTrainingProgram(
    final String providerOfferings, final ProviderMember providerMember)
    throws InformationalException;
  
}
