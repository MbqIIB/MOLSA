/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;

import com.google.inject.Singleton;

import curam.cpm.sl.impl.ReasonForNonComplianceAdapter;
import curam.cpm.sl.struct.ReasonForNonComplianceDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ReasonForNonComplianceDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ReasonForNonComplianceDAOImpl extends StandardDAOImpl<ReasonForNonCompliance, ReasonForNonComplianceDtls>
  implements ReasonForNonComplianceDAO {
  // END, CR00183213
  /**
   * Adapter for ReasonForNonCompliance
   */
  protected static final ReasonForNonComplianceAdapter adapter = new ReasonForNonComplianceAdapter();

  // ___________________________________________________________________________

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ReasonForNonComplianceDAOImpl() {
    // END, CR00183213
    super(adapter, ReasonForNonCompliance.class);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<ReasonForNonCompliance> searchByLicense(License license) {

    return newSet(adapter.searchByLicenseID(license.getID()));
  }
}
