/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import curam.message.impl.GENERALExceptionCreator;
import curam.util.type.CodeTableEntry;
import curam.util.type.DateTimeRange;
import curam.util.type.StringHelper;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ProviderParticipant} entity.
 */
// BEGIN, CR00183213, SS
public class ProviderParticipantImpl extends ProviderPartyImpl implements
  ProviderParticipant {

  /**
   * Constructor for the class.
   */
  protected ProviderParticipantImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213

  /**
   * {@inheritDoc}
   */
  public ProviderParticipantTypeEntry getParticipantType() {
    return ProviderParticipantTypeEntry.get(getDtls().type);
  }

  /**
   * {@inheritDoc}
   */
  public void setParticipantType(ProviderParticipantTypeEntry value) {
    setType(value.getCode());
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected CodeTableEntry getTypeCode() {
    return getParticipantType();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {
    super.setNewInstanceDefaults();
    setCategory(ProviderPartyCategoryEntry.PROVIDERPARTICIPANT);
  }

  /**
   * Validates that all mandatory fields are "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.GENERAL#ERR_GENERAL_FV_TYPE_MUST_BE_ENTERED} - If
   * the type is not entered.</li>
   *
   */
  @Override
  public void mandatoryFieldValidation() {
    super.mandatoryFieldValidation();

    // Type must not be empty
    if (StringHelper.isEmpty(getType())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        GENERALExceptionCreator.ERR_GENERAL_FV_TYPE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }
  
  // BEGIN, CR00320064, SSK
  /**
   * {@inheritDoc}
   */
  @Override
  public void setDateTimeRange(final DateTimeRange dateTimeRange) {
   
    getDtls().startDateTime = dateTimeRange.start();
    getDtls().endDateTime = dateTimeRange.end();
    
  }
  
  // END, CR00320064
}
