/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import curam.attendance.impl.ProviderRosterLineItemAccessor;
import curam.financial.impl.FinancialNotificationEventEntry;
import curam.util.persistence.StandardEntity;
import curam.util.type.Money;


/**
 * Accessor interface for {@linkplain curam.provider.impl.CommunicationPRLILink}
 * .
 */
public interface CommunicationPRLILinkAccessor extends StandardEntity {

  /**
   * Gets an overpayment or under payment amount generated as part of provider
   * roster line item correction.
   *
   * @return An overpayment or under payment amount generated as part of
   * provider roster line item correction.
   */
  public Money getAmount();

  /**
   * Gets the financial notification event.
   *
   * @return The financial notification event.
   */
  public FinancialNotificationEventEntry getFinancialEvent();

  /**
   * Gets the immutable provider roster line item associated with communication.
   *
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable provider roster line item associated with
   * communication.
   */
  public ProviderRosterLineItemAccessor getProviderRosterLineItem();

  /**
   * Gets the roster notification event.
   *
   * @return The roster notification event.
   */
  public RosterNotificationEventEntry getRosterEvent();
}
