/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.HashSet;
import java.util.Set;

import com.google.inject.Inject;
import curam.util.persistence.helper.EventDispatcherFactory;

import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.entity.impl.ProviderSpecialtyAdapter;
import curam.cpm.sl.entity.struct.ProviderSpecialtyDtls;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.message.impl.PROVIDERSPECIALTYExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.LifecycleHelper;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.DateRange;
import curam.util.type.StringHelper;


/**
 * Standard implementation of {@linkplain curam.provider.impl.ProviderSpecialty}.
 */
// BEGIN, CR00183213, SS
public class ProviderSpecialtyImpl extends SingleTableLogicallyDeleteableEntityImpl<ProviderSpecialtyDtls> implements
  ProviderSpecialty {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderSpecialtyInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderSpecialtyCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderSpecialtyModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  /**
   * Injecting the Data Access Object for Provider
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Injecting the Data Access Object for Provider Security
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderSpecialtyImpl() {// Empty Constructor of Provider Specialty.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public ProviderSpecialtyTypeEntry getSpecialty() {

    return ProviderSpecialtyTypeEntry.get(getDtls().specialty);
  }

  /**
   * {@inheritDoc}
   */
  public Provider getProvider() {
    final long id = getDtls().providerConcernRoleID;

    return id == 0 ? null : providerDAO.get(id);
  }

  /**
   * {@inheritDoc}
   */
  public void setSpecialty(final ProviderSpecialtyTypeEntry specialty) {
    getDtls().specialty = specialty.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setProvider(Provider provider) {
    getDtls().providerConcernRoleID = provider.getID();

  }

  /**
   * {@inheritDoc}
   */
  public void setDateRange(DateRange value) {

    getDtls().startDate = value.start();
    getDtls().endDate = value.end();

    // if end date is entered and start date is after end date, throw validation
    // error
    value.validateRange();

  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  /**
   * {@inheritDoc}
   */
  public void setComments(String value) {

    // trim the input value
    value = StringHelper.trim(value);

    // if comments is greater than maximum allowed length, throw validation
    // error
    if (value.length() > ProviderSpecialtyAdapter.kMaxLength_comments) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_COMMENTS_ABOVE_MAXIMUM_LENGTH(
          ProviderSpecialtyAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          4);
    }

    getDtls().comments = value;

  }

  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {
    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * Validates and creates provider specialty event.
   *
   * @throws InformationalException
   * {@link PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   */
  public void insert() throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre insert provider specialty event.
    insertEventDispatcherFactory.get(ProviderSpecialtyInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    // if the status of the provider is closed
    if (getProvider() != null) {
      if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 56);
        ValidationHelper.failIfErrorsExist();
      }
    }
    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    super.insert();
    // BEGIN, CR00235789, AK
    // Raise the post insert provider specialty event.
    insertEventDispatcherFactory.get(ProviderSpecialtyInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * Modifies provider specialty event after validating the newly entered details.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * {@link PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   * {@link PROVIDER#ERR_PROVIDERSPECIALTY_XRV_SPECIALTY_DELETED_CANNOT_BE_MODIFIED} -
   * If the status of the provider is canceled.
   */
  public void modify(final Integer versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre modify provider specialty event.
    modifyEventDispatcherFactory.get(ProviderSpecialtyModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider() != null) {
      if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 54);
        ValidationHelper.failIfErrorsExist();
      }
    }
    if (getDtls().recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERSPECIALTYExceptionCreator.ERR_PROVIDERSPECIALTY_XRV_SPECIALTY_DELETED_CANNOT_BE_MODIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();

    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify provider specialty event.
    modifyEventDispatcherFactory.get(ProviderSpecialtyModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * Cancels provider specialty event after validating the newly entered details.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * {@link PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   * {@link PROVIDER#ERR_PROVIDERSPECIALTY_XRV_SPECIALTY_ALREADY_DELETED} -
   * If the status of the provider is canceled.
   */
  public void cancel(final int versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre cancel provider specialty event.
    cancelEventDispatcherFactory.get(ProviderSpecialtyCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider() != null) {
      if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 55);
        ValidationHelper.failIfErrorsExist();
      }
    }

    if (getDtls().recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERSPECIALTYExceptionCreator.ERR_PROVIDERSPECIALTY_XRV_SPECIALTY_ALREADY_DELETED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();
    super.cancel(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post cancel provider specialty event.
    cancelEventDispatcherFactory.get(ProviderSpecialtyCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * This method checks if the specialty is already active for that provider. If
   * so, then it throws an validation error.
   */
  // BEGIN, CR00177241, PM
  protected void validateForDuplicateSpecialty() {
    // END, CR00177241

    // check that the date range of this specialty does not overlap with any
    // other active specialty of the same type for the same provider
    final curam.provider.impl.Provider provider = getProvider();

    // filter for active only
    Set<curam.provider.impl.ProviderSpecialty> unModifiableProviderSpecialties = provider.getProviderSpecialties();
    Set<curam.provider.impl.ProviderSpecialty> providerSpecialties = new HashSet<curam.provider.impl.ProviderSpecialty>();

    providerSpecialties.addAll(unModifiableProviderSpecialties);

    for (final curam.provider.impl.ProviderSpecialty providerSpecialty : LifecycleHelper.filter(
      providerSpecialties, RECORDSTATUSEntry.NORMAL)) {

      // if there exists a specialty with same name and 'Active' status
      // and not the same record, then throw validation error
      if ((!providerSpecialty.getID().equals(this.getID()))
        && (providerSpecialty.getSpecialty().equals(this.getSpecialty()))
        && (providerSpecialty.getDateRange().overlapsWith(this.getDateRange()))) {

        final DateRange overlappingDateRange = providerSpecialty.getDateRange();

        CodeTableItemIdentifier criterion = providerSpecialty.getSpecialty().getCodeTableItemIdentifier();

        if (overlappingDateRange.isEnded()) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERSPECIALTYExceptionCreator.ERR_PROVIDERSPECIALTY_XRV_CANNOT_CREATE_SPECIALTY_ALREADY_EXISTS_WITH_STARTDATE_AND_ENDDATE(
              criterion, overlappingDateRange.start(),
              overlappingDateRange.end()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        } else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PROVIDERSPECIALTYExceptionCreator.ERR_PROVIDERSPECIALTY_XRV_CANNOT_CREATE_SPECIALTY_READY_EXISTS_WITH_STARTDATE(
              criterion, overlappingDateRange.start()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }

      }
    }

  }

  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERSPECIALTY#ERR_PROVIDERSPECIALTY_FV_SPECIALTY_MUST_BE_ENTERED} -
   * If the specialty is not entered, throw validation error. </li>
   * <li>
   * {@link curam.message.PROVIDERSPECIALTY#ERR_CPMCOMMONMSG_FV_START_DATE_MUST_BE_ENTERED} -
   * If the start date is entered. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    // if specialty is not entered, throw validation error
    if (this.getSpecialty().equals(ProviderSpecialtyTypeEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERSPECIALTYExceptionCreator.ERR_PROVIDERSPECIALTY_FV_SPECIALTY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // validate if start date is entered
    if (this.getDateRange().start().isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_START_DATE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    getDateRange().validateStarted();

  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No cross fields to validate
  }

  /**
   * Validates that changes made to provider specialty entity on the database
   * are consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.impl.PROVIDERSPECIALTY#ERR_PROVIDERSPECIALTY_XRV_CANNOT_CREATE_SPECIALTY_ALREADY_EXISTS_WITH_STARTDATE_AND_ENDDATE} -
   * If there exists a specialty with same name and 'Active' status and not the
   * same record, then throw validation error</li>
   * <li>
   * {@link curam.message.impl.PROVIDERSPECIALTY#ERR_PROVIDERSPECIALTY_XRV_CANNOT_CREATE_SPECIALTY_READY_EXISTS_WITH_STARTDATE} -
   * If a specialty case cannot be created as an specialty case same date
   * already exists</li>
   * </ul>
   */
  public void crossEntityValidation() {

    // check if the same specialty already active for the provider
    validateForDuplicateSpecialty();

  }

}
