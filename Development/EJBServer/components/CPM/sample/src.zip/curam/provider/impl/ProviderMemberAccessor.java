/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;

import curam.cpm.sl.entity.struct.ProviderBackgroundCheckList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;


/**
 * Accessor interface for Provider Member 
 * {@linkplain curam.provider.impl.ProviderMember}.
 *
 */
public interface ProviderMemberAccessor extends StandardEntity {
  
  /**
   * Gets the role of the member with respect to the provider or provider group. 
   *
   * @return ProviderMemberRoleEntry the member role.
   */
  ProviderMemberRoleEntry getRole();
  
  /**
   * Gets the position of the member in the provider or 
   * provider group organization.
   *
   * @return Position of the member.
   */
  PROVIDERMEMBERPOSITIONEntry getPosition();

  // BEGIN, CR00197240, ASN
  // BEGIN, CR00197808, ASN
  /**
   * Gets all active background checks associated with a provider member.
   *
   * @param providerParty
   * Contains provider party object.
   *
   * @return List of background check details associated with a provider member.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  ProviderBackgroundCheckList getProviderMemberBackGroundCheck(
    final ProviderParty providerParty) throws AppException,
      InformationalException;

  // END, CR00197808
  /**
   * Gets all active failure reasons for a background check.
   *
   * @param providerBackgroundCheck
   * Contains provider background check object.
   *
   * @return The immutable set of failure reasons for a background check.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  Set<? extends BackgroundCheckFailureReasonAccessor> getBackgroundCheckFailureReasons(
    final ProviderBackgroundCheck providerBackgroundCheck)
    throws AppException, InformationalException;
  // END, CR00197240
}
