/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.util.persistence.Insertable;


/**
 * Internal interface to create history records.
 */
@ImplementedBy(LicenseStatusHistoryImpl.class)
// BEGIN, CR00274320, AC
public interface LicenseStatusHistoryCreator extends LicenseStatusHistory, Insertable {
  // END, CR00274320

  // ___________________________________________________________________________
  /**
   * Sets the license that this status history record relates to.
   *
   * @param value   the License that this Status History record relates to
   *
   * @see License
   */
  public void setLicense(final License value);

  // ___________________________________________________________________________
  /**
   * Sets the reason the license was suspended.
   *
   * @param value   the reason the license was suspended
   */
  public void setSuspensionReason(final LicenseSuspensionReasonEntry value);

  // ___________________________________________________________________________
  /**
   * Sets the reason the license was rejected.
   *
   * @param value   the reason the license was rejected
   */
  public void setRejectionReason(final LicenseRejectionReasonEntry value);

}
