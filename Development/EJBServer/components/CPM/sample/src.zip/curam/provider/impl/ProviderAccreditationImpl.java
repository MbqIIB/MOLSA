/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Collections;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.entity.struct.ProviderAccreditationDtls;
import curam.events.ACCREDITATION;
import curam.message.impl.PROVIDERACCREDITATIONExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.resources.GeneralConstants;
import curam.util.type.StringHelper;


// BEGIN, CR00183213, SS
public class ProviderAccreditationImpl extends SingleTableLogicallyDeleteableEntityImpl<ProviderAccreditationDtls>
  implements ProviderAccreditation {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderAccreditationInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderAccreditationCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderAccreditationModifyEvents> modifyEventDispatcherFactory;
  // END, CR00235789

  /**
   * Injecting the Data Access Object for Provider class
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Injecting the Data Access Object for Accreditation Period class
   */
  @Inject
  protected AccreditationPeriodDAO accreditationPeriodDAO;

  /**
   * Injecting the Data Access Object for Provider Security
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderAccreditationImpl() {// END, CR00183213
    // Empty Constructor of Provider Accreditation
  }

  /**
   * Gets the type for the Provider Accreditation.
   *
   * @return The type for the Provider Accreditation.
   */
  public String getType() {
    return getDtls().type;
  }

  /**
   * Gets the description for the Provider Accreditation.
   *
   * @return The description for the Provider Accreditation.
   */
  public String getDescription() {
    return getDtls().description;
  }

  /**
   * Gets the version number accreditation period record of the provider.
   *
   * @return The version number accreditation period record of the provider.
   */
  public int getVersionNo() {
    return getDtls().versionNo;
  }

  /**
   * {@inheritDoc}
   */
  public Provider getProvider() {
    final long id = getDtls().providerConcernRoleID;

    return id == 0 ? null : providerDAO.get(id);
  }

  /**
   * {@inheritDoc}
   */
  public Set<AccreditationPeriod> getAccreditationPeriods() {
    return Collections.unmodifiableSet(accreditationPeriodDAO.searchBy(this));
  }

  /**
   * {@inheritDoc}
   */
  public void setProvider(Provider value) {
    if (value != null) {
      getDtls().providerConcernRoleID = value.getID();
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setDescription(String description) {
    getDtls().description = StringHelper.trim(description);
  }

  /**
   * {@inheritDoc}
   */
  public void setType(String type) {
    getDtls().type = StringHelper.trim(type);
  }

  /**
   * Logically deletes the accreditation periods of the Provider.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}-
   * If the status of the provider is closed.
   */
  public void cancel(final int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre cancel provider accreditation event.
    cancelEventDispatcherFactory.get(ProviderAccreditationCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 45);
      ValidationHelper.failIfErrorsExist();
    }

    super.cancel(versionNo);

    // raise post-cancel event
    final Event event = new Event();

    event.eventKey = ACCREDITATION.ACCREDITATION_CANCELED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post cancel provider accreditation event.
    cancelEventDispatcherFactory.get(ProviderAccreditationCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Modify the accreditation periods of the Provider.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}-
   * If the status of the provider is closed.
   */
  public void modify(final Integer versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre modify provider accreditation event.
    modifyEventDispatcherFactory.get(ProviderAccreditationModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 43);
      ValidationHelper.failIfErrorsExist();
    }

    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify provider accreditation event.
    modifyEventDispatcherFactory.get(ProviderAccreditationModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Validates and insert the accreditation period record for the Provider.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}-
   * If the status of the provider is closed.
   */
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre insert provider accreditation event.
    insertEventDispatcherFactory.get(ProviderAccreditationInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 44);
      ValidationHelper.failIfErrorsExist();
    }

    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert provider accreditation event.
    insertEventDispatcherFactory.get(ProviderAccreditationInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERACCREDITATION#ERR_PROVIDERACCREDITATION_FV_TYPE_MUST_BE_ENTERED()}-
   * If the Provider accreditation type is not entered. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    if (getDtls().type.equals(GeneralConstants.kEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERACCREDITATIONExceptionCreator.ERR_PROVIDERACCREDITATION_FV_TYPE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// cross field validations goes here
  }

  /**
   * Validates that changes made to ProviderAccreditation entity on the database
   * are consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERACCREDITATION#ERR_PROVIDERACCREDITATION_XRV_TYPE_ALREADY_EXISTS}-
   * If an 'Active' accreditation of the same type already exists for this
   * provider. </li>
   * </ul>
   *
   */

  public void crossEntityValidation() {

    final curam.provider.impl.Provider provider = providerDAO.get(
      getDtls().providerConcernRoleID);

    for (final ProviderAccreditation providerAccreditation: provider.getAccreditations()) {
      // Check for active accreditations of same type for the provider
      if (!providerAccreditation.getID().equals(this.getID())
        && providerAccreditation.getType().equals(getDtls().type)
        && providerAccreditation.getLifecycleState().getCode().equals(
          RECORDSTATUSEntry.get(curam.codetable.RECORDSTATUS.NORMAL).getCode())) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERACCREDITATIONExceptionCreator.ERR_PROVIDERACCREDITATION_XRV_TYPE_ALREADY_EXISTS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        break;
      }
    }
  }
}
