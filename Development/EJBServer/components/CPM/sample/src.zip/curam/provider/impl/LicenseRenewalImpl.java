/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.cpm.sl.impl.LicenseRenewalAdapter;
import curam.cpm.sl.struct.LicenseRenewalDtls;
import curam.message.impl.LICENSEExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.Date;


/**
 * Standard implementation of {@linkplain curam.provider.impl.LicenseRenewal}.
 */
// BEGIN, CR00183213, SS
public class LicenseRenewalImpl extends SingleTableEntityImpl<LicenseRenewalDtls> implements LicenseRenewal {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<LicenseRenewalInsertEvents> insertEventDispatcherFactory;

  // END, CR00235789

  @Inject
  protected ReasonForNonComplianceDAO reasonForNonComplianceDAO;

  @Inject
  protected LicenseDAO licenseDAO;

  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected LicenseRenewalImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /*
   * Field getters
   */


  /**
   * {@inheritDoc}
   */
  public boolean isRenewalCompliant() {

    return getDtls().renewalCompliantInd;
  }

  /**
   * {@inheritDoc}
   */
  public Date getRenewalDate() {

    return getDtls().renewalDate;
  }

  /**
   * Gets the comments for the license renewal.
   *
   * @return The comments for the license renewal.
   */
  public String getComments() {

    return getDtls().comments;
  }

  /*
   * Field setters
   */

  /**
   * {@inheritDoc}
   */
  public void setLicense(License value) {

    getDtls().licenseID = value.getID();

  }

  /**
   * {@inheritDoc}
   */
  public void setRenewalCompliant(boolean value) {

    getDtls().renewalCompliantInd = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setRenewalDate(Date value) {

    getDtls().renewalDate = value;

  }

  /**
   * Sets the comment for the license renewal.
   *
   * @param value
   * The comment for the license renewal.
   *
   * @throws InformationalException
   * {@link curam.message.LICENSE#ERR_LICENSE_FV_FIELD_SIZE_MUST_BE_LT_OR_EQ}-
   * If the comment exceed the maximum length.
   */
  public void setComments(String value) {

    getDtls().comments = value;

    // Comments must be less than or equals to 200 characters
    if (getComments().length() > LicenseRenewalAdapter.kMaxLength_comments) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_FV_FIELD_SIZE_MUST_BE_LT_OR_EQ(
          LicenseRenewalAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * @return the reason for non compliance records that exist a license
   */
  // BEGIN, CR00177241, PM
  protected Set<ReasonForNonCompliance> getReasonForNonComplianceRecords() {
    // END, CR00177241
    return reasonForNonComplianceDAO.searchByLicense(getLicense());
  }

  /*
   * Related-entity getters
   */

  /**
   * {@inheritDoc}
   */
  public License getLicense() {
    final long licenseID = getDtls().licenseID;

    return licenseID == 0 ? null : licenseDAO.get(licenseID);
  }

  /**
   * Validates that changes made to license-renewal entity on the database are
   * consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.LICENSE#ERR_LICENSE_XRV_CANNOT_RENEW_CANCELED_LICENSE} -
   * If the license is canceled. </li>
   * {@link curam.message.LICENSE#ERR_LICENSE_XRV_CANNOT_RENEW_LICENSE} - If the
   * license is approved. </li>
   * </ul>
   *
   */
  public void crossEntityValidation() {

    final License license = getLicense();

    getTransactionHelper().lock(license);

    if (license.getLifecycleState().equals(LicenseStatusEntry.CANCELED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_CANNOT_RENEW_CANCELED_LICENSE(
          LicenseStatusEntry.CANCELED.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

    } else if (!license.getLifecycleState().equals(LicenseStatusEntry.APPROVED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_CANNOT_RENEW_LICENSE(
          LicenseStatusEntry.APPROVED.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

    }

    final Set<ReasonForNonCompliance> licenseReasonForNonComplianceRecords = getReasonForNonComplianceRecords();

    if (licenseReasonForNonComplianceRecords.size() == 1) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_LICENSE_RENEWED_ALREADY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre insert license renewal event.
    insertEventDispatcherFactory.get(LicenseRenewalInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    providerSecurity.checkProviderSecurity(getLicense().getProvider());

    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert license renewal event.
    insertEventDispatcherFactory.get(LicenseRenewalInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// None required
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// None required
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// None required
  }
}
