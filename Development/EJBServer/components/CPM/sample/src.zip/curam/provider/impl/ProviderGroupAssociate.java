/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;


/**
 * Defines the providers that are associates of a particular group.
 *
 * Details of the association between the provider and the group are recorded
 * including the period that the provider is included in the group and whether
 * the group receives payments on behalf of that provider. E.g. Catholic
 * Charities is a provider group, Carry's Day Care join the provider group from
 * 1/1/2006 and want the group to receive payments on their behalf.
 */
@ImplementedBy(ProviderGroupAssociateImpl.class)
public interface ProviderGroupAssociate extends ProviderGroupAssociateAccessor,
    Insertable, LogicallyDeleteable, DateRanged, Commented,
    OptimisticLockModifiable {

  /**
   * Sets the Provider associated with the Provider Group.
   *
   * @param value
   * the provider.
   */
  void setProvider(final Provider value);

  /**
   * Gets the immutable provider associated with the Provider Group.
   *
   * @return Immutable provider associated with the Provider Group.
   */
  Provider getProvider();

  /**
   * Sets the Provider Group associated.
   *
   * @param value
   * The provider group.
   */
  void setProviderGroup(final ProviderGroup value);

  /**
   * Gets the immutable Provider Group associated.
   *
   * @return Immutable Provider Group associated.
   */
  ProviderGroup getProviderGroup();

  /**
   * Sets whether this provider group associate is part of a contract.
   *
   * @param value
   * Whether this provider group associate is part of a contract.
   */
  void setPartOfContract(boolean value);
  
  // BEGIN, CR00178886, ASN

  /**
   * Sets an indicator telling whether the provider group should be accepting
   * the payments on behalf of the corresponding provider.
   *
   * @param value
   * An indicator telling whether the provider group should be
   * accepting the payments on behalf of the corresponding provider.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link curam.provider.impl.ProviderGroupAssociatePaymentConfiguration }
   * . To maintain the history for this indicator, it has been
   * reintroduced with effective date in
   * ProviderGroupAssociatePaymentConfiguration entity.See release
   * note: CR00178886.
   */
  @Deprecated
  void setGroupToReceivePayments(boolean value);

  // END, CR00178886
  /**
   * Sets the "lifetime" of the provider group associate record.
   *
   * @param value
   * The "lifetime" of the provider group associate record.
   *
   * @see curam.provider.impl.ProviderGroupAssociateImpl#setDateRange(DateRange)
   * The default implementation -
   * {@link curam.provider.impl.ProviderGroupAssociateImpl#setDateRange(DateRange)}
   * .
   */
  void setDateRange(DateRange value);

  /**
   * Removes the provider from the provider group association.
   *
   * @param versionNo
   * The version number as held by the client code.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderGroupAssociateImpl#removeProviderFromProviderGroup(Integer)
   * The default implementation -
   * {@link curam.provider.impl.ProviderGroupAssociateImpl#removeProviderFromProviderGroup(Integer)}.
   */
  void removeProviderFromProviderGroup(Integer versionNo)
    throws InformationalException;

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider group associate events functionality surrounding
   * the removeProviderFromProviderGroup method.
   */
  public interface ProviderGroupAssociateRemoveProviderFromProviderGroupEvents {

    /**
     * Event interface invoked before the main body of the
     * removeProviderFromProviderGroup method.
     * {@linkplain curam.provider.impl.ProviderGroupAssociate#removeProviderFromProviderGroup}
     *
     * @param providerGroupAssociate
     * The object instance as it was before the main body of the
     * removeProviderFromProviderGroup method.
     * @param versionNo
     * The parameter as passed to the removeProviderFromProviderGroup
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preRemoveProviderFromProviderGroup(
      ProviderGroupAssociateAccessor providerGroupAssociate, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the
     * removeProviderFromProviderGroup method.
     * {@linkplain curam.provider.impl.ProviderGroupAssociate#removeProviderFromProviderGroup}
     *
     * @param providerGroupAssociate
     * The object instance as it was after the main body of the
     * removeProviderFromProviderGroup method.
     * @param versionNo
     * The parameter as passed to the removeProviderFromProviderGroup
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postRemoveProviderFromProviderGroup(
      ProviderGroupAssociateAccessor providerGroupAssociate, Integer versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the provider group associate events functionality surrounding
   * the insert method.
   */
  public interface ProviderGroupAssociateInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderGroupAssociate#insert}
     *
     * @param providerGroupAssociate
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ProviderGroupAssociateAccessor providerGroupAssociate)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderGroupAssociate#insert}
     *
     * @param providerGroupAssociate
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ProviderGroupAssociateAccessor providerGroupAssociate)
      throws InformationalException;
  }


  /**
   * Interface to the provider group associate events functionality surrounding
   * the cancel method.
   */
  public interface ProviderGroupAssociateCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderGroupAssociate#cancel}
     *
     * @param providerGroupAssociate
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(
      ProviderGroupAssociateAccessor providerGroupAssociate, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderGroupAssociate#cancel}
     *
     * @param providerGroupAssociate
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(
      ProviderGroupAssociateAccessor providerGroupAssociate, int versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the provider group associate events functionality surrounding
   * the modify method.
   */
  public interface ProviderGroupAssociateModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderGroupAssociate#modify}
     *
     * @param providerGroupAssociate
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(
      ProviderGroupAssociateAccessor providerGroupAssociate, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderGroupAssociate#modify}
     *
     * @param providerGroupAssociate
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(
      ProviderGroupAssociateAccessor providerGroupAssociate, Integer versionNo)
      throws InformationalException;
  }
  // END, CR00144381
}
