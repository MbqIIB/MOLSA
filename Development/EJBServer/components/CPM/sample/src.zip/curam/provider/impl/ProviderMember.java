/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * Provider members are the individuals associated to the provider that have a
 * significant internal relationship to the provider.
 *
 * For example, employees and family members associated with the provider who
 * might be involved in providing services to the agency's clients. The SEM
 * agency may conduct background checks on the people associated to a provider
 * before approving the provider to provide service offerings to the agency's
 * clients.
 */
@ImplementedBy(ProviderMemberImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ProviderMember extends ProviderParty, ProviderMemberAccessor {

  /**
   * Sets role of the member with respect to the provider or provider group. 
   *
   * @param value the member role.
   */
  void setRole(final ProviderMemberRoleEntry value);
  
  // BEGIN CR00117581, MST  
  /**
   * Sets the position of the member in the provider or 
   * provider group organization. 
   *
   * @param value 
   * Position of the member.
   */
  void setPosition(final PROVIDERMEMBERPOSITIONEntry value);
  // END CR00117581

  // BEGIN CR00118010, MST
  /**
   * Method used to check if the training required for associating 
   * the provider offering with provider member is completed or waived.
   *
   * @param providerOfferings
   * Provider Offerings that is to be associated.
   *
   * @return List of informational message.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMessageList validateTrainingProgramsForProviderMember(
    final String providerOfferings) throws InformationalException;
  // END CR00118010  

  // BEGIN, CR00197240, ASN
  /**
   * Gets all active failure reasons for a background check.
   *
   * @param providerBackgroundCheck
   * Contains provider background check object.
   *
   * @return Set of failure reasons for a background check.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  Set<BackgroundCheckFailureReason> getBackgroundCheckFailureReasons(
    final ProviderBackgroundCheck providerBackgroundCheck)
    throws AppException, InformationalException;
  // END, CR00197240

  // BEGIN, CR00205270, ASN
  /**
   * Sets the category of the member in the provider or provider group
   * organization.
   *
   * @param category
   * Category of the member.
   */
  void setCategory(final ProviderPartyCategoryEntry category);
  // END, CR00205270
}
