/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.util.persistence.Insertable;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.DateTime;


/**
 * The status history of a provider. The status of a provider throughout the
 * lifecycle of their relationship with the organization.
 *
 */
@ImplementedBy(ProviderStatusHistoryImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ProviderStatusHistory extends ProviderStatusHistoryAccessor, Insertable {

  /**
   * Sets the user who changes the provider status.
   *
   * @param userName
   * The user who changes the provider status.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  void setUserName(String userName);

  /**
   * Sets the reason for the change in provider status. A reason can be added on
   * rejection or suspension of the provider.
   *
   * @param reason
   * The reason for the change in provider status.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  void setReason(String reason);

  /**
   * Sets the date and time that this provider status is effective from.
   *
   * @param dateTime
   * The date and time that this provider status is effective from.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  void setEffectiveDateTime(DateTime dateTime);

  /**
   * Sets the provider for this provider status history.
   *
   * @param provider
   * The provider for this provider status history.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  void setProvider(Provider provider);

  /**
   * Gets the provider for this provider status history.
   *
   * @return The Provider for the provider status history.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  Provider getProvider();

  /**
   * Sets the record status of the provider
   *
   * @param recordStatus
   * The recordStatus of the Provider
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  void setProviderRecordStatus(String recordStatus);

}
