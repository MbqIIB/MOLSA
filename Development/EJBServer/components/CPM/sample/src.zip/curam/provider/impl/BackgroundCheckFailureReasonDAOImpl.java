/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import curam.cpm.sl.entity.impl.BackgroundCheckFailureReasonAdapter;
import curam.cpm.sl.entity.struct.BackgroundCheckFailureReasonDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Implementation for interface BackgroundCheckFailureReasonDAO
 */
// BEGIN, CR00183213, SS
public class BackgroundCheckFailureReasonDAOImpl extends StandardDAOImpl<BackgroundCheckFailureReason, BackgroundCheckFailureReasonDtls>
  implements BackgroundCheckFailureReasonDAO {
  // END, CR00183213
  /**
   * Initializing the adapter for Background Check Failure Reason
   */
  protected static final BackgroundCheckFailureReasonAdapter adapter = new BackgroundCheckFailureReasonAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected BackgroundCheckFailureReasonDAOImpl() {
    // END, CR00183213
    super(adapter, BackgroundCheckFailureReason.class);
  }

  /**
   * @param providerBackgroundCheck provider Background Check
   * @return Set set of Background Check Failure Reason
   * @see curam.provider.impl.BackgroundCheckFailureReasonDAO#searchBy(
   * curam.provider.impl.ProviderBackgroundCheck)
   */
  public Set<BackgroundCheckFailureReason> searchBy(
    ProviderBackgroundCheck providerBackgroundCheck) {
    return newSet(adapter.searchBy(providerBackgroundCheck.getID()));
  }

}
