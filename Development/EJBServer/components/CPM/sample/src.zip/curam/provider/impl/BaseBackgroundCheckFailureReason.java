/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.StandardEntity;
import curam.util.type.Date;


/**
 * A reason why a background check has failed.
 */
@ImplementedBy(BaseBackgroundCheckFailureReasonImpl.class)
public interface BaseBackgroundCheckFailureReason extends StandardEntity,
    LogicallyDeleteable, OptimisticLockModifiable, Insertable {

  // ___________________________________________________________________________
  /**
   * Gets the date of the occurrence that led to failure of a background check.
   *
   * @return Date The occurrence date of the failure.
   */
  Date getOccurrenceDate();

  // ___________________________________________________________________________
  /**
   * Gets the occurrence that led to failure of a background check.
   *
   * @return String with the reason of failure.
   */
  String getFailureReason();

  // ___________________________________________________________________________
  /**
   * Sets the date of the occurrence that led to failure of a background check.
   *
   * @param date
   * Occurrence date to be set.
   */
  void setOccurrenceDate(final Date date);

  // ___________________________________________________________________________
  /**
   * Sets the occurrence that led to failure of a background check.
   *
   * @param failureReason
   * The failure reason to be set.
   */
  void setFailureReason(
    final BackgroundCheckFailureReasonTypeEntry failureReason);

}
