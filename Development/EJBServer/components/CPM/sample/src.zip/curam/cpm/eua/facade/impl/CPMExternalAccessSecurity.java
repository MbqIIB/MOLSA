/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import curam.codetable.EXTERNALUSERTYPE;
import curam.codetable.impl.APPLICATION_CODEEntry;
import curam.codetable.impl.EXTERNALUSERTYPEEntry;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.entity.fact.ExternalUserFactory;
import curam.core.sl.entity.intf.ExternalUser;
import curam.core.sl.entity.struct.ExternalUserDtls;
import curam.core.sl.entity.struct.ExternalUserDtlsList;
import curam.core.sl.entity.struct.ExternalUserKey;
import curam.core.sl.entity.struct.UpperUserNameKey;
import curam.cpm.impl.CPMConstants;
import curam.util.codetable.SECURITYSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.Configuration;
import curam.util.security.PublicAccessUser;
import curam.util.security.UserLoginDetails;


/**
 * Process class which performs the authentication of external Curam users.
 */
public class CPMExternalAccessSecurity extends PublicAccessUser {

  /**
   * This method checks for any restrictions on the External User Account, i.e.
   * if any login restrictions are in place or if the account is disabled.
   *
   * @param externalUserDtls - this contains all of the details for the
   * external user account
   *
   * @return This contains the relevant security status for the user account,
   * i.e. if the account is disabled.
   */
  // BEGIN, CR00177241, PM
  protected String internalAuthenticate(ExternalUserDtls externalUserDtls) {
    // END, CR00177241

    // If the account is disabled return the appropriate status
    if (!externalUserDtls.accountEnabled) {
      return curam.util.codetable.SECURITYSTATUS.ACCDISABLE;
    }

    final curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // If the account expiry date has passed or is the current date return
    // the appropriate status
    if (!externalUserDtls.passwordExpiryDate.isZero()
      && (externalUserDtls.passwordExpiryDate.before(currentDate)
        || externalUserDtls.passwordExpiryDate.equals(currentDate))) {
      return curam.util.codetable.SECURITYSTATUS.PWDEXPIRED;
    }

    // If the password change days has expired return the appropriate status
    if (externalUserDtls.pwdChangeEveryXDay != 0) {
      final curam.util.type.Date expDate = externalUserDtls.passwordChanged.addDays(
        externalUserDtls.pwdChangeEveryXDay);

      if (expDate.before(currentDate) || expDate.equals(currentDate)) {
        return curam.util.codetable.SECURITYSTATUS.PWDEXPIRED;
      }
    }
    // If the number of logins has expired return the appropriate status
    if (externalUserDtls.pwdChangeAfterXLog != 0
      && externalUserDtls.logsSincePWDChange
        > externalUserDtls.pwdChangeAfterXLog) {
      return curam.util.codetable.SECURITYSTATUS.LOGEXPR;
    }

    // If login restrictions are in place
    if (externalUserDtls.loginRestrictions) {
      final curam.util.type.DateTime currentDateTime = curam.util.type.DateTime.getCurrentDateTime();
      final int dayOfWeek = currentDateTime.getCalendar().get(
        java.util.Calendar.DAY_OF_WEEK);
      boolean accessPermited = false;

      switch (dayOfWeek) {
      case 1: // 001
        accessPermited = externalUserDtls.loginDaySun;
        break;

      case 2: // 002
        accessPermited = externalUserDtls.loginDayMon;
        break;

      case 3: // 003
        accessPermited = externalUserDtls.loginDayTues;
        break;

      case 4: // 004
        accessPermited = externalUserDtls.loginDayWed;
        break;

      case 5: // 005
        accessPermited = externalUserDtls.loginDayThurs;
        break;

      case 6: // 006
        accessPermited = externalUserDtls.loginDayFri;
        break;

      case 7: // 007
        accessPermited = externalUserDtls.loginDaySat;
        break;

      default:
        accessPermited = false;
        break;
      }
      // Get the login time restrictions
      curam.util.type.DateTime loginTimeFrom = externalUserDtls.loginTimeFrom;
      curam.util.type.DateTime loginTimeTo = externalUserDtls.loginTimeTo;

      // Create temporary calendar objects to use in calculating the login
      // restrictions
      java.util.Calendar temp = loginTimeFrom.getCalendar();
      final java.util.Calendar currTemp = curam.util.type.DateTime.getCurrentDateTime().getCalendar();

      // Since the time is only stored on the database without the date
      // portion, we need to built up the date portion of the
      // loginTimeFrom variable
      // We will use the current year, method and date along with the time
      // to complete the loginTimeFrom variable
      temp.set(currTemp.get(java.util.Calendar.YEAR),
        currTemp.get(java.util.Calendar.MONTH),
        currTemp.get(java.util.Calendar.DATE));
      loginTimeFrom = new curam.util.type.DateTime(temp);

      // Apply the same login for the loginTimeTo variable
      temp = loginTimeTo.getCalendar();
      temp.set(currTemp.get(java.util.Calendar.YEAR),
        currTemp.get(java.util.Calendar.MONTH),
        currTemp.get(java.util.Calendar.DATE));
      loginTimeTo = new curam.util.type.DateTime(temp);

      // If access is permitted on this day and the user's login time from
      // is before the current time
      if (accessPermited && !loginTimeFrom.isZero()) {

        accessPermited = loginTimeFrom.before(currentDateTime)
          || loginTimeFrom.equals(currentDateTime);

        // If access is permitted on this day and the user's login time to
        // is after the current time
        if (accessPermited && !loginTimeTo.isZero()) {
          accessPermited = loginTimeTo.after(currentDateTime);
        }

      }

      // If access is not permitted return the appropriate status
      if (!accessPermited) {
        return SECURITYSTATUS.RESTRICTED;
      }

    }
    return null;
  }

  // ___________________________________________________________________________
  /**
   * This method compares the password entered with the password on the
   * system to ensure that they match.
   *
   * @param enteredPassword - The password entered by the user
   * @param knownPassword - The password that exists on the system
   *
   * @return A boolean value indicating true if the passwords match, false
   * otherwise.
   */
  // BEGIN, CR00177241, PM
  protected boolean comparePassword(String enteredPassword, String knownPassword) {
    // END, CR00177241
    // If the entered password is blank check that the known password is
    // also blank
    if (enteredPassword == null) {
      return knownPassword == null;
    } else {
      // Check if the encrypted passwords match
      return enteredPassword.equals(knownPassword);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method retrieves the details of the user required to redirect them
   * to the correct application page. This information includes the name of
   * the application home page for the user, the default locale for the user
   * and a list of warnings/messages for the user.
   *
   * @param identifier
   * The identifier of the external user.
   * @return The user details, including the application home page.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public UserLoginDetails getLoginDetails(String identifier)
    throws AppException, InformationalException {

    // The return value object
    final UserLoginDetails userLoginDetails = new UserLoginDetails();

    // The ExternalUser value objects
    final curam.core.sl.entity.intf.ExternalUser externalUserObj = ExternalUserFactory.newInstance();
    final ExternalUserKey externalUserKey = new ExternalUserKey();
    ExternalUserDtls externalUserDtls = new ExternalUserDtls();

    externalUserKey.userName = identifier;

    // Read the external users table
    externalUserDtls = externalUserObj.read(externalUserKey);

    // Set the application code and locale for the user
    userLoginDetails.setApplicationCode(externalUserDtls.applicationCode);
    userLoginDetails.setDefaultLocale(externalUserDtls.defaultLocale);
    // Return any warning messages to the user
    userLoginDetails.addInformationals(getLogonMessages(externalUserDtls));

    return userLoginDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method retrieves the relevant informationals for the user, e.g.
   * an informational warning may be returned if the users password is about
   * to expire.
   *
   * @param externalUserDtls - This contains the details for the external user
   * @return This contains all of the informational warnings
   *
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected InformationalManager getLogonMessages(ExternalUserDtls externalUserDtls)
    throws InformationalException {
    // END, CR00177241

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    if (externalUserDtls.pwdChangeEveryXDay != 0) {
      // Calculate the date the password must be changed by
      final java.util.Calendar currentDate = curam.util.type.Date.getCurrentDate().getCalendar();
      final java.util.Calendar dateToChangePassword = externalUserDtls.passwordChanged.getCalendar();

      dateToChangePassword.add(java.util.Calendar.DATE,
        externalUserDtls.pwdChangeEveryXDay);

      // Retrieve the number of days warning given to an external user before a password expires
      final Integer prop = curam.util.resources.Configuration.getIntProperty(
        EnvVars.ENV_EXTERNAL_USER_PASSWORD_EXPIRY_WARNING_DAYS);

      // Set the password expiry period
      int passwordExpiryWarningPeriod;

      if (prop == null) {
        passwordExpiryWarningPeriod = Integer.parseInt(
          EnvVars.ENV_EXTERNAL_USER_PASSWORD_EXPIRY_WARNING_DAYS_DEFAULT);
      } else {
        passwordExpiryWarningPeriod = prop.intValue();
      }

      // Calculate the warning limit date
      final java.util.Calendar outerWarningLimitDate = curam.util.type.Date.getCurrentDate().getCalendar();

      outerWarningLimitDate.add(java.util.Calendar.DATE,
        passwordExpiryWarningPeriod);

      // If the warning limit date is after the date the password must be changed by
      if (outerWarningLimitDate.after(dateToChangePassword)) {
        // Calculate the number of days before the password expires
        int daysToExpire;

        for (daysToExpire = 0; daysToExpire < passwordExpiryWarningPeriod
          && dateToChangePassword.after(currentDate); daysToExpire++) {
          currentDate.add(java.util.Calendar.DATE, 1);
        }

        // Add the message to the return list
        final curam.util.exception.LocalisableString info = new curam.util.exception.LocalisableString(
          curam.message.EXTERNALSECURITYACCESS.WARN_PASSWORD_EXPIRING_DAYS);

        info.arg(String.valueOf(daysToExpire));
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          info, "",
          curam.util.exception.InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }

    // Retrieve the number of remaining logins before a warning is displayed to the user
    final Integer prop = curam.util.resources.Configuration.getIntProperty(
      EnvVars.ENV_EXTERNAL_USER_LOGINS_REMAINING_WARNING_NUM);

    // Set the number of logins remaining
    int loginsRemainingWarningNumber;

    if (prop == null) {
      loginsRemainingWarningNumber = Integer.parseInt(
        EnvVars.ENV_EXTERNAL_USER_LOGINS_REMAINING_WARNING_NUM_DEFAULT);
    } else {
      loginsRemainingWarningNumber = prop.intValue();
    }

    // If number of login restrictions exist and the number remaining is within the warning period
    if (externalUserDtls.pwdChangeAfterXLog != 0
      && (externalUserDtls.logsSincePWDChange + loginsRemainingWarningNumber
        >= externalUserDtls.pwdChangeAfterXLog)) {
      // Add the warning to the list returned
      final curam.util.exception.LocalisableString info = new curam.util.exception.LocalisableString(
        curam.message.EXTERNALSECURITYACCESS.WARN_LOG_ATTEMPTS_EXPIRING_NUM);

      info.arg(
        String.valueOf(
          externalUserDtls.pwdChangeAfterXLog
            - externalUserDtls.logsSincePWDChange));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        info, "",
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    return informationalManager;
  }

  /**
   * This method returns the security role associated with the external user
   * for authorization purposes. If the user does not exist null is returned.
   *
   * @param identifier
   * The identifier of the external user.
   * @return The security role for authorization.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public String getSecurityRole(String identifier) throws AppException,
      InformationalException {

    String roleName;

    final ExternalUser externalUserObj = ExternalUserFactory.newInstance();
    final ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.userName = identifier;
    try {

      // BEGIN, CR00304153, AKr
      if (Configuration.getBooleanProperty(
        EnvVars.ENV_EXTERNAL_USERNAMES_CASE_SENSITIVE)) {

        externalUserKey.userName = identifier;
      } else {

        final UpperUserNameKey upperUserNameKey = new UpperUserNameKey();

        upperUserNameKey.upperUserName = identifier.toUpperCase();
        externalUserKey.userName = externalUserObj.searchByUpperUserName(upperUserNameKey).dtls.item(0).userName;
      }

      // END, CR00304153
      roleName = externalUserObj.readUserRole(externalUserKey).roleName;

    } catch (final curam.util.exception.RecordNotFoundException ex) {
      roleName = null;
    }
    return roleName;
  }

  // ___________________________________________________________________________
  /**
   * Returns the type of the user. This is to allow support for different
   * types of external user. If there is only one type of external user,
   * "EXTERNAL" is returned.
   *
   * @param identifier
   * The identifier of the external user.
   * @return The type of the external user.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public String getUserType(String identifier) throws AppException,
      InformationalException {
    return CuramConst.gkExternalUser;
  }

  // ___________________________________________________________________________
  /**
   * Return the number of users using a particular role. This method is used
   * to ensure that a role cannot be deleted when it is in use by an external
   * user.
   *
   * @param role
   * The security role name.
   * @return The number of users currently using the specified role.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public int getRoleUsageCount(String role) throws AppException,
      InformationalException {
    return 0;
  }

  // BEGIN, CR00304153, AKr
  /**
   * Returns the user name of the registered user.
   *
   * @param identifier
   * The identifier of the user.
   * @return The registered user name.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public String getRegisteredUserName(final String identifier)
    throws AppException,
      InformationalException {

    if (Configuration.getBooleanProperty(
      EnvVars.ENV_EXTERNAL_USERNAMES_CASE_SENSITIVE)) {
      return identifier;
    } else {
      final UpperUserNameKey upperUserNameKey = new UpperUserNameKey();

      upperUserNameKey.upperUserName = identifier.toUpperCase();
      return ExternalUserFactory.newInstance().searchByUpperUserName(upperUserNameKey).dtls.item(0).userName;
    }
    // END, CR00304153
  }

  // ___________________________________________________________________________
  /**
   * Returns the user preferences of the logged in user.
   *
   * @param identifier
   * The identifier of the user.
   * @return user preference
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public String getUserPreferenceSetID(String identifier) throws AppException, InformationalException {
    final ExternalUserKey externalUserKey = new ExternalUserKey();

    // BEGIN, CR00304153, AKr
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_EXTERNAL_USERNAMES_CASE_SENSITIVE)) {

      externalUserKey.userName = identifier;
    } else {
      final UpperUserNameKey upperUserNameKey = new UpperUserNameKey();

      upperUserNameKey.upperUserName = identifier.toUpperCase();
      externalUserKey.userName = ExternalUserFactory.newInstance().searchByUpperUserName(upperUserNameKey).dtls.item(0).userName;
    }
    // END, CR00304153

    // get the userPrefSetID from the external users table.
    final String userPreferenceSetID = ExternalUserFactory.newInstance().readUserPrefSetID(externalUserKey).userPrefSetID;

    return userPreferenceSetID;
  }

  // ___________________________________________________________________________
  /**
   * modifies the user preferences of the logged in user.
   *
   * @param userPreferenceSetID
   * user Preference eSet ID
   * @param username
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyUserPreferenceSetID(String userPreferenceSetID, String username)
    throws AppException, InformationalException {

    final ExternalUserKey externalUserKey = new ExternalUserKey();

    // set the key
    externalUserKey.userName = username;

    // read the external user details.
    final ExternalUserDtls externalUserDtls = ExternalUserFactory.newInstance().read(
      externalUserKey);

    // update the external user details userPrefSetID
    externalUserDtls.userPrefSetID = userPreferenceSetID;

    // update the users table with the new details
    ExternalUserFactory.newInstance().modify(externalUserKey, externalUserDtls);

  }

  // BEGIN, CR00
  /**
   * Validates the identifier and password and returns the result of the
   * validation. If the information is valid, the code table code
   * <code>SecurityStatus.LOGIN</code> is returned. If the property
   * curam.security.externalusers.casesensitive is set to "NO" and if there are
   * two user names but in different alphabetical case forms, the code table
   * code <code>SecurityStatus.AMBIGUOUS</code> is returned.
   *
   * @param identifier
   * The identifier of the external user.
   * @param password
   * The password of the external user.
   * @param userType
   * The type of external user.
   * @return The status of the authentication in the form of a code table code.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public String authenticate(String identifier, char[] password, String userType)
    throws AppException, InformationalException {
    String status = null;

    final ExternalUser externalUserObj = ExternalUserFactory.newInstance();
    final ExternalUserKey externalUserKey = new ExternalUserKey();
    ExternalUserDtls externalUserDtls = null;
    final UpperUserNameKey upperUserNameKey = new UpperUserNameKey();
    ExternalUserDtlsList externalUsersDtlsList;

    externalUserKey.userName = identifier;

    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_EXTERNAL_USERNAMES_CASE_SENSITIVE)) {

      upperUserNameKey.upperUserName = identifier.toUpperCase();
      externalUsersDtlsList = externalUserObj.searchByUpperUserName(
        upperUserNameKey);

      if (1 == externalUsersDtlsList.dtls.size()) {
        externalUserDtls = externalUsersDtlsList.dtls.item(0);
        externalUserKey.userName = externalUserDtls.userName;
        status = SECURITYSTATUS.AUTHONLY;
      } else if (externalUsersDtlsList.dtls.size() > 1) {
        status = SECURITYSTATUS.AMBIGUOUS;
      } else {
        status = SECURITYSTATUS.BADUSER;
      }
    } else {

      try {
        externalUserDtls = ExternalUserFactory.newInstance().read(
          externalUserKey);
      } catch (final RecordNotFoundException e) {
        status = SECURITYSTATUS.BADUSER;
      }
    }

    if (!(SECURITYSTATUS.AMBIGUOUS.equals(status)
      || SECURITYSTATUS.BADUSER.equals(status))) {

      status = internalAuthenticate(externalUserDtls);

      // BEGIN, CR00124475, KR
      if (userType.equals(CPMConstants.kCPMEXTERNALSECURE)
        && (!(externalUserDtls.applicationCode.equals(
          APPLICATION_CODEEntry.CPM_EXTERNAL_PROVIDER_HOME.getCode()))
            && (!externalUserDtls.applicationCode.equals(
              APPLICATION_CODEEntry.CPM_EXTERNAL_PROVIDER_GROUP_HOME.getCode())))) {
        status = curam.util.codetable.SECURITYSTATUS.BADUSER;
      }

      if (userType.equals(CPMConstants.kCPMEXTERNALNONSECURE)
        && (!externalUserDtls.applicationCode.equals(
          APPLICATION_CODEEntry.CPM_EXTERNAL_NON_SECURE_HOME.getCode()))) {
        status = curam.util.codetable.SECURITYSTATUS.BADUSER;
      }
      // END, CR00124475

      if (status == null
        && upgradeSafePasswordValidation(identifier, externalUserDtls.password,
        new String(password))) {

        // Reset the number of login failures
        if (externalUserDtls.loginFailures > 0) {
          externalUserDtls.loginFailures = 0;
        }
        // Reset the last successful login date
        externalUserDtls.lastSuccessLogin = curam.util.type.DateTime.getCurrentDateTime();
        // Set the login status to successful
        status = curam.util.codetable.SECURITYSTATUS.LOGIN;

        // Increase the number of successful logins since the password
        // was changed if
        // password change restrictions apply
        if (externalUserDtls.pwdChangeAfterXLog != 0) {
          externalUserDtls.logsSincePWDChange = externalUserDtls.logsSincePWDChange
            + 1;
        }

      } else {
        // Increase the number of login failures
        externalUserDtls.loginFailures++;

        // BEGIN, CR00377167, NNM
        // The following if condition is added, to prevent user accounts of type 'CPM External Non Secure' from getting locked.
        // This will prevent malicious users from forcing the non secure accounts, 
        // associated with this type, from getting locked by breaking login failure threshold. 
        // Users of Secure group are not affected and these accounts will get locked, if login failure threshold is crossed.
        if (!externalUserDtls.type.equals(EXTERNALUSERTYPE.NONSECURE)) {
          
          // Retrieve the break in threshold from the property file
          final Integer prop = curam.util.resources.Configuration.getIntProperty(
            EnvVars.ENV_EXTERNAL_USER_BREAKIN_THRESHOLD);

          int breakinThreshold;

          if (prop == null) {
            breakinThreshold = Integer.parseInt(
              EnvVars.ENV_EXTERNAL_USER_BREAKIN_THRESHOLD_DEFAULT);
          } else {
            breakinThreshold = prop.intValue();
          }

          // If the user has login attempts remaining set the status to
          // BADPWD
          if (breakinThreshold > externalUserDtls.loginFailures) {
            if (status == null) {
              status = curam.util.codetable.SECURITYSTATUS.BADPWD;
            }
          } else { // The user has exceeded the number of incorrect
            // password allowed
            // A break in will be recorded and the account disabled
            externalUserDtls.accountEnabled = false;
            status = curam.util.codetable.SECURITYSTATUS.BREAKIN;
          }
        } else {
          if (status == null) {
            status = curam.util.codetable.SECURITYSTATUS.BADPWD;
          }
        } // END, CR00377167
      }
      // Modify the ExternalUser table with the login details
      externalUserObj.modify(externalUserKey, externalUserDtls);
    }
    // Return the login status
    return status;
  }

  /**
   * {@inheritDoc}
   */
  public void setPassword(String username, String hashedPassword)
    throws AppException, InformationalException {

    final boolean casesensitive = Configuration.getBooleanProperty(
      EnvVars.ENV_EXTERNAL_USERNAMES_CASE_SENSITIVE);

    // The ExternalUser value objects
    final ExternalUser externalUserObj = ExternalUserFactory.newInstance();
    final ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.userName = username;
    ExternalUserDtls externalUserDtls = null;
    final UpperUserNameKey upperUserNameKey = new UpperUserNameKey();
    final ExternalUserDtlsList externalUsers;

    if (!casesensitive) {
      upperUserNameKey.upperUserName = username.toUpperCase();
      externalUsers = externalUserObj.searchByUpperUserName(upperUserNameKey);

      if (1 == externalUsers.dtls.size()) {
        externalUserDtls = externalUsers.dtls.item(0);
        externalUserKey.userName = externalUserDtls.userName;
      }
    } else {
      externalUserDtls = externalUserObj.read(externalUserKey);
    }

    if (hashedPassword != null) {
      externalUserKey.userName = username;
      externalUserDtls.password = hashedPassword;
      externalUserObj.modify(externalUserKey, externalUserDtls);
    }
  }
  // END, CR00
}
