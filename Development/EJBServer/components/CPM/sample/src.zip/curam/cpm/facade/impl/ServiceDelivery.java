/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2009, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.approvalrequest.impl.ApprovalRequest;
import curam.approvalrequest.impl.ApprovalRequestAccessor;
import curam.approvalrequest.impl.ApprovalRequestDAO;
import curam.attachmentlink.impl.AttachmentLink;
import curam.attachmentlink.impl.AttachmentLinkDAO;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.ListAttachmentLinkDetails;
import curam.attendance.impl.DailyAttendance;
import curam.attendance.impl.DailyAttendanceDAO;
import curam.attendance.impl.ProviderRosterLineItem;
import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.StackContainerBuilder;
import curam.codetable.CASERELATIONSHIPREASONCODE;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.codetable.impl.APPROVALREQUESTSTATUSEntry;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.FEDALLOWCOMPRELATEDTYPEEntry;
import curam.codetable.impl.PROXIMITYDISTANCEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.REJECTIONREASONEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.codetable.impl.SERVICEDELIVERYSTATUSEntry;
import curam.core.facade.fact.ProductDeliveryFactory;
import curam.core.facade.intf.ProductDelivery;
import curam.core.facade.struct.ListCaseFinancialsKey;
import curam.core.facade.struct.UnprocessedILIDetailsList;
import curam.core.facade.struct.ViewCaseFinancialInstructionList;
import curam.core.fact.CaseRelationshipFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.struct.CaseNomineeKey;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.struct.ApprovalRequestKey;
import curam.core.sl.struct.RejectionDetails;
import curam.core.struct.CaseID;
import curam.core.struct.CaseRelationshipDtls;
import curam.core.struct.CaseRelationshipDtlsList;
import curam.core.struct.CaseRelationshipRelatedCaseIDKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.SearchUnprocessedByCaseIDKey;
import curam.cpm.facade.struct.ApprovalRequestTaskDetail;
import curam.cpm.facade.struct.ContextPanelDetails;
import curam.cpm.facade.struct.EvaluationCriteriaData;
import curam.cpm.facade.struct.FederalAllowableComponentDetails;
import curam.cpm.facade.struct.ListProviderDetailsKey;
import curam.cpm.facade.struct.NoteHistoryDetails;
import curam.cpm.facade.struct.ParticipantsCaseRolesServiceConfigurationsList;
import curam.cpm.facade.struct.PaymentInformationDetails;
import curam.cpm.facade.struct.PaymentInformationDetailsList;
import curam.cpm.facade.struct.ProviderContactDetails;
import curam.cpm.facade.struct.ProviderSearchCriteriaDetails;
import curam.cpm.facade.struct.ProviderTypeSelectionDetails;
import curam.cpm.facade.struct.ReassessmentResultsList;
import curam.cpm.facade.struct.ServiceConfigurations;
import curam.cpm.facade.struct.ServiceCriterionEvaluationSummary;
import curam.cpm.facade.struct.ServiceDeliveryApprovalRequestDetails;
import curam.cpm.facade.struct.ServiceDeliveryApprovalRequestDetailsList;
import curam.cpm.facade.struct.ServiceDeliveryApprovalRequestViewDetails;
import curam.cpm.facade.struct.ServiceDeliveryAttendanceDetails;
import curam.cpm.facade.struct.ServiceDeliveryAttendanceDetailsList;
import curam.cpm.facade.struct.ServiceDeliveryCompleteDetails;
import curam.cpm.facade.struct.ServiceDeliveryCreateKey;
import curam.cpm.facade.struct.ServiceDeliveryDetailsForModify;
import curam.cpm.facade.struct.ServiceDeliveryListDetails;
import curam.cpm.facade.struct.ServiceDeliveryListDetailsList;
import curam.cpm.facade.struct.ServiceDeliveryModifyDetails;
import curam.cpm.facade.struct.ServiceDeliveryNoteDetails;
import curam.cpm.facade.struct.ServiceDeliveryTypeAndNomineeType;
import curam.cpm.facade.struct.ServiceDeliveryVersionKey;
import curam.cpm.facade.struct.ServiceEvaluationDetails;
import curam.cpm.facade.struct.ServiceEvaluationDetailsForModify;
import curam.cpm.facade.struct.ServiceEvaluationOverviewDetails;
import curam.cpm.facade.struct.ServiceEvaluationVersionNoKey;
import curam.cpm.facade.struct.ServiceInvoiceLineItemDetails;
import curam.cpm.facade.struct.ServiceInvoiceLineItemsDetailsList;
import curam.cpm.facade.struct.ServiceOfferingKey;
import curam.cpm.facade.struct.VersionNoKey;
import curam.cpm.facade.struct.ViewServiceDeliveryDetails;
import curam.cpm.facade.struct.ViewServiceDeliveryStatusHistoryDetails;
import curam.cpm.facade.struct.ViewServiceDeliveryStatusHistoryDetailsList;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.struct.ServiceDeliveryKey;
import curam.cpm.util.impl.FrequencyPatternUtil;
import curam.cpm.util.impl.FrequencyPatternUtilImpl;
import curam.cpm.util.impl.ServiceAndReferralContextPanelHelper;
import curam.cpm.util.impl.ServiceDeliveryFacadeHelper;
import curam.cpm.util.impl.ServiceProviderSearchHelper;
import curam.federalallowablecomponent.impl.FederalAllowableComponent;
import curam.federalallowablecomponent.impl.FederalAllowableComponentDAO;
import curam.financial.impl.FinancialAPI;
import curam.financial.impl.PaymentInformation;
import curam.financial.impl.ServiceInvoiceLineItem;
import curam.financial.impl.ServiceInvoiceLineItemDAO;
import curam.message.GENERALCASE;
import curam.message.SERVICEDELIVERY;
import curam.message.impl.SERVICEDELIVERYEVALUATIONExceptionCreator;
import curam.message.impl.SERVICEDELIVERYExceptionCreator;
import curam.participant.impl.ConcernRoleDAO;
import curam.participant.impl.PhoneNumber;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.financialmanager.impl.FinancialInstruction;
import curam.piwrapper.financialmanager.impl.FinancialInstructionDAO;
import curam.piwrapper.impl.AddressDAO;
import curam.piwrapper.impl.Attachment;
import curam.piwrapper.impl.AttachmentDAO;
import curam.piwrapper.impl.Note;
import curam.piwrapper.outcomeplan.codetable.impl.ACTIVITYOUTCOMEACHIEVEDEntry;
import curam.piwrapper.outcomeplan.codetable.impl.ACTIVITYOUTCOMEREASONEntry;
import curam.piwrapper.user.impl.User;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderSpecialtyTypeEntry;
import curam.provider.impl.ProviderTypeNameEntry;
import curam.serviceauthorization.impl.ServiceAuthorization;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItem;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItemDAO;
import curam.servicedelivery.impl.CuramConst;
import curam.servicedelivery.impl.ServiceDeliveryDAO;
import curam.servicedelivery.impl.ServiceDeliveryStatusHistory;
import curam.servicedelivery.impl.ServiceDeliveryStatusHistoryDAO;
import curam.servicedeliveryevaluation.impl.ServiceDeliveryEvaluation;
import curam.servicedeliveryevaluation.impl.ServiceDeliveryEvaluationDAO;
import curam.serviceevaluationcriterion.impl.SECRESPONSEVALUEEntry;
import curam.serviceoffering.impl.PROVIDERANDTYPESELECTIONEntry;
import curam.serviceoffering.impl.SERVICEDELIVERYOWNEREntry;
import curam.serviceoffering.impl.SOEvaluationCriterion;
import curam.serviceoffering.impl.SOEvaluationCriterionDAO;
import curam.serviceoffering.impl.ServiceDeliveryConfigurationAccessor;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.serviceoffering.impl.ServiceOfferingSecurity;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement.InformationalType;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.FrequencyPattern;
import curam.util.type.StringHelper;


/**
 * {@inheritDoc}
 */
public abstract class ServiceDelivery extends curam.cpm.facade.base.ServiceDelivery {

  /**
   * Reference to Service Delivery DAO.
   */
  @Inject
  protected ServiceDeliveryDAO serviceDeliveryDAO;

  /**
   * Reference to Concern Role DAO.
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Reference to Service Authorization Line Item DAO.
   */
  @Inject
  protected ServiceAuthorizationLineItemDAO serviceAuthorizationLineItemDAO;

  /**
   * Reference to Daily Attendance DAO.
   */
  @Inject
  protected DailyAttendanceDAO dailyAttendanceDAO;

  /**
   * Reference to Attachment Link DAO.
   */
  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;

  /**
   * Reference to Case Header DAO.
   */
  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  /**
   * Reference to Attachment DAO.
   */
  @Inject
  protected AttachmentDAO attachmentDAO;

  /**
   * Reference to Address DAO.
   */
  @Inject
  protected AddressDAO addressDAO;

  /**
   * Reference to Service Invoice Line Item DAO.
   */
  @Inject
  protected ServiceInvoiceLineItemDAO serviceInvoiceLineItemDAO;

  /**
   * Reference to Service Offering DAO.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Reference to Service Delivery Evaluation DAO.
   */
  @Inject
  protected ServiceDeliveryEvaluationDAO serviceDeliveryEvaluationDAO;

  /**
   * Reference to Provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to Service Delivery Facade Helper provider instance.
   */
  @Inject
  protected Provider<ServiceDeliveryFacadeHelper> serviceDeliveryFacadeHelperProvider;

  /**
   * Reference to Service Provider Search Helper provider instance.
   */
  @Inject
  protected Provider<ServiceProviderSearchHelper> serviceProviderSearchHelperProvider;

  /**
   * Reference to Service Offering Security instance.
   */
  @Inject
  protected ServiceOfferingSecurity serviceOfferingSecurity;

  /**
   * Reference to Financial API instance.
   */
  @Inject
  protected FinancialAPI financialAPI;

  /**
   * Reference to Financial Instruction DAO.
   */
  @Inject
  protected FinancialInstructionDAO financialInstructionDAO;

  /**
   * Reference to Approval Request DAO.
   */
  @Inject
  protected ApprovalRequestDAO approvalRequestDAO;

  /**
   * Reference to Federal Allowable Component DAO.
   */
  @Inject
  protected FederalAllowableComponentDAO federalAllowableComponentDAO;

  /**
   * Reference to Service Offering Evaluation Criterion DAO.
   */
  @Inject
  protected SOEvaluationCriterionDAO soEvaluationCriterionDAO;

  /**
   * Reference to Service Delivery Status History DAO.
   */
  @Inject
  protected ServiceDeliveryStatusHistoryDAO serviceDeliveryStatusHistoryDAO;

  /**
   * Reference to the context panel helper class.
   */
  @Inject
  protected Provider<ServiceAndReferralContextPanelHelper> serviceReferralContextPanelHelperProvider;

  // BEGIN, CR00360398, CD
  @Inject
  private Provider<CMSMetadataInterface> cmsMetadataProvider;

  // END, CR00360398

  /**
   * Constructor.
   */
  protected ServiceDelivery() {
    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public void cancelServiceDelivery(final ServiceDeliveryVersionKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00407985, SG
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = key.caseIDOpt;

    checkMaintainCaseSecurity(caseSecurityCheckKey);
    // END, CR00407985

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.key.serviceDeliveryID);

    // maintain service security check
    serviceOfferingSecurity.checkMaintainRights(
      serviceDelivery.getServiceOffering());

    serviceDelivery.cancel(key.versionNoKey.versionNo);

  }

  /**
   * {@inheritDoc}
   */
  public ServiceDeliveryCreateKey editServiceDelivery(
    final ServiceDeliveryModifyDetails editDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00407985, SG
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = editDetails.details.serviceDeliveryDtls.caseID;

    checkMaintainCaseSecurity(caseSecurityCheckKey);
    // END, CR00407985

    ServiceDeliveryCreateKey serviceDeliverycreateKey = new ServiceDeliveryCreateKey();

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      editDetails.details.serviceDeliveryDtls.serviceDeliveryID);

    // maintain service security check
    final ServiceOffering serviceOffering = serviceDelivery.getServiceOffering();

    serviceOfferingSecurity.checkMaintainRights(serviceOffering);

    if (SERVICEDELIVERYOWNEREntry.get(editDetails.details.soConfigurations.serviceDeliveryConfigurations.ownerToBeSpecified).equals(
      SERVICEDELIVERYOWNEREntry.ANYUSER)) {
      serviceDeliveryFacadeHelperProvider.get().validateOwnerFields(
        editDetails.details.loggedOnUserOwnerInd,
        editDetails.details.systemOwnerUsername,
        editDetails.details.caseRoleOwnerUsername);
    }
    if (editDetails.details.soConfigurations.serviceDeliveryConfigurations.numberOfUnitsInd
      && (0 == editDetails.details.serviceDeliveryDtls.unitsAuthorized)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEDELIVERYExceptionCreator.ERR_CREATESERVICEDELIVERY_FV_NUMBER_OF_UNITS_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if (!editDetails.details.soConfigurations.serviceDeliveryConfigurations.numberOfUnitsInd) {
      editDetails.details.serviceDeliveryDtls.unitsAuthorized = 1;
    }

    serviceDeliveryFacadeHelperProvider.get().validateServiceRecipientSelected(
      editDetails.details.recipientIDString,
      editDetails.details.singleCaseParticipantRoleID,
      editDetails.serviceRecipientsModifiable);

    serviceDeliveryFacadeHelperProvider.get().validateDateRange(
      editDetails.details.serviceDeliveryDtls.coverPeriodStartDate,
      editDetails.details.serviceDeliveryDtls.coverPeriodEndDate);

    serviceDeliveryFacadeHelperProvider.get().validateScheduleDetails(
      editDetails.hoursDuration, editDetails.minsDuration,
      editDetails.details.serviceDeliveryDtls.participationFrequency,
      serviceDelivery.getServiceOffering());

    ValidationHelper.failIfErrorsExist();

    // populate the owner identifier and type fields.
    editDetails.details.serviceDeliveryDtls.ownerUsername = serviceDeliveryFacadeHelperProvider.get().populateOwnerField(
      SERVICEDELIVERYOWNEREntry.get(
        editDetails.details.soConfigurations.serviceDeliveryConfigurations.ownerToBeSpecified),
        editDetails.details.loggedOnUserOwnerInd,
        editDetails.details.systemOwnerUsername,
        editDetails.details.caseRoleOwnerUsername);

    // set optional fields
    serviceDelivery.setAuthorizedRate(
      editDetails.details.serviceDeliveryDtls.authorizedRate);

    /*
     * If the frequency value passed in is blank and the original value is
     * not blank, use the original value.
     */
    if (StringHelper.isEmpty(editDetails.details.serviceDeliveryDtls.frequency)
      && !StringHelper.isEmpty(
        serviceDelivery.getServiceFrequencyPattern().toString())) {
      serviceDelivery.setFrequencyPattern(
        serviceDelivery.getServiceFrequencyPattern().toString());
    } else {
      serviceDelivery.setFrequencyPattern(
        editDetails.details.serviceDeliveryDtls.frequency);
    }

    serviceDelivery.setParticipationFrequencyPattern(
      editDetails.details.serviceDeliveryDtls.participationFrequency);
    serviceDelivery.setFederalAllowableComponent(
      federalAllowableComponentDAO.get(
        editDetails.details.serviceDeliveryDtls.federalAllowableComponentID));
    serviceDelivery.setDuration(editDetails.hoursDuration,
      editDetails.minsDuration);
    // BEGIN, CR00296412, CSH
    if (0 != editDetails.details.serviceDeliveryDtls.nomineeConcernRoleID) {
      serviceDelivery.setNomimeeConcernRole(
        concernRoleDAO.get(
          editDetails.details.serviceDeliveryDtls.nomineeConcernRoleID));
    } else if (0
      == editDetails.details.serviceDeliveryDtls.nomineeConcernRoleID) {

      // set to null to remove a nominee from the service delivery
      serviceDelivery.setNomimeeConcernRole(null);
    }
    // END, CR00296412

    serviceDelivery.setCoverPeriodStartDate(
      editDetails.details.serviceDeliveryDtls.coverPeriodStartDate);
    serviceDelivery.setCoverPeriodEndDate(
      editDetails.details.serviceDeliveryDtls.coverPeriodEndDate);
    serviceDelivery.setUnitsAuthorized(
      editDetails.details.serviceDeliveryDtls.unitsAuthorized);
    serviceDelivery.setSensitivity(
      SENSITIVITYEntry.get(editDetails.details.serviceDeliveryDtls.sensitivity));
    serviceDelivery.setOwner(
      editDetails.details.serviceDeliveryDtls.ownerUsername);
    serviceDelivery.setServiceOffering(
      serviceOfferingDAO.get(
        editDetails.details.serviceDeliveryDtls.serviceOfferingID));
    serviceDelivery.setReason(editDetails.details.serviceDeliveryDtls.reason);

    if (0 != editDetails.details.singleCaseParticipantRoleID) {
      editDetails.details.recipientIDString = String.valueOf(
        editDetails.details.singleCaseParticipantRoleID);
    }

    if (editDetails.serviceRecipientsModifiable) {
      // BEGIN, CR00313834, GA
      serviceDelivery.modifyParticipants(
        serviceDeliveryFacadeHelperProvider.get().getSelectedClients(
          editDetails.details.recipientIDString),
          editDetails.details.serviceDeliveryDtls.versionNo);
      // END, CR00313834
    } else {
      serviceDelivery.modify(editDetails.details.serviceDeliveryDtls.versionNo);
    }

    serviceDeliverycreateKey.key.serviceDeliveryID = serviceDelivery.getID();

    String[] informationals = TransactionInfo.getInformationalManager().obtainInformationalAsString();

    for (String message : informationals) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;
      serviceDeliverycreateKey.informationals.dtls.addRef(informationalMsgDtls);
    }
    return serviceDeliverycreateKey;
  }

  /**
   * {@inheritDoc}
   */
  public ViewServiceDeliveryDetails viewServiceDelivery(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    ViewServiceDeliveryDetails viewServiceDeliveryDetails = new ViewServiceDeliveryDetails();

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    // view service security check
    serviceOfferingSecurity.checkViewRights(
      serviceDelivery.getServiceOffering());

    viewServiceDeliveryDetails.serviceDeliveryDtls.serviceDeliveryID = serviceDelivery.getID();

    if (null != serviceDelivery.getRelatedCase()) {
      viewServiceDeliveryDetails.serviceDeliveryDtls.caseID = serviceDelivery.getRelatedCase().getID();
    }
    viewServiceDeliveryDetails.serviceOfferingName = serviceDelivery.getServiceOffering().getName();
    viewServiceDeliveryDetails.serviceDeliveryDtls.serviceOfferingID = serviceDelivery.getServiceOffering().getID();

    // Calculate the number of occurrences, if no frequency is specified
    // only
    // one occurrence is assumed
    int numOccurances = 1;

    if (serviceDelivery.getServiceFrequencyPattern() != null
      && !serviceDelivery.getServiceFrequencyPattern().isZeroPattern()) {
      // BEGIN, CR00279362, SSK
      // BEGIN, CR00280114, SSK
      FrequencyPatternUtil frequencyPatternUtil = new FrequencyPatternUtilImpl();
      // END, CR00280114
      // BEGIN, CR00280918, SSK
      Date anchorDate = frequencyPatternUtil.getAnchorDateAfterReferenceDate(
        serviceDelivery.getCoverPeriodStartDate(),
        serviceDelivery.getServiceFrequencyPattern());

      // END, CR00280918

      DateRange coverPeriod = new DateRange(
        serviceDelivery.getCoverPeriodStartDate(),
        serviceDelivery.getCoverPeriodEndDate());
      List<Date> frequencyOccurrences = frequencyPatternUtil.getFrequencyOccurrencesWithinPeriod(
        serviceDelivery.getServiceFrequencyPattern(), coverPeriod, anchorDate);

      // END, CR00279362

      numOccurances = frequencyOccurrences.size();
    }

    viewServiceDeliveryDetails.unitsDelivered = new LocalisableString(SERVICEDELIVERY.INF_UNITS_DELIVERED_DESCRIPTION).arg(serviceDelivery.getUnitsConsumed()).arg(serviceDelivery.getUnitsAuthorized() * numOccurances).getMessage();

    viewServiceDeliveryDetails.actualCost = serviceDelivery.getActualCost();

    viewServiceDeliveryDetails.serviceDeliveryDtls.sensitivity = serviceDelivery.getSensitivity().getCode();
    viewServiceDeliveryDetails.serviceDeliveryDtls.coverPeriodStartDate = serviceDelivery.getCoverPeriodStartDate();
    viewServiceDeliveryDetails.serviceDeliveryDtls.coverPeriodEndDate = serviceDelivery.getCoverPeriodEndDate();

    final LocalisableString addedByDateString = new LocalisableString(
      SERVICEDELIVERY.INF_ACTION_BY_STRING);

    addedByDateString.arg(serviceDelivery.getCreationDate());
    viewServiceDeliveryDetails.createdByDate = addedByDateString.toClientFormattedText();
    viewServiceDeliveryDetails.serviceDeliveryDtls.createdBy = serviceDelivery.getCreatedBy().getID();
    viewServiceDeliveryDetails.createByFullname = serviceDelivery.getCreatedBy().getFullName();
    if (serviceDelivery.getLifecycleState().equals(
      SERVICEDELIVERYSTATUSEntry.COMPLETED)) {
      viewServiceDeliveryDetails.serviceDeliveryDtls.outcomeAchieved = serviceDelivery.getOutcomeAchieved().getCode();
      viewServiceDeliveryDetails.serviceDeliveryDtls.outcomeReason = serviceDelivery.getOutcomeReason().getCode();
      viewServiceDeliveryDetails.serviceDeliveryDtls.completionComments = serviceDelivery.getCompletionComments();
      final LocalisableString completedByDateString = new LocalisableString(
        SERVICEDELIVERY.INF_ACTION_BY_STRING);

      completedByDateString.arg(serviceDelivery.getCompletionDate());

      viewServiceDeliveryDetails.completedByDate = completedByDateString.toClientFormattedText();
      viewServiceDeliveryDetails.serviceDeliveryDtls.completedBy = serviceDelivery.getCompletedBy().getID();
      viewServiceDeliveryDetails.completedByUserFullname = serviceDelivery.getCompletedBy().getFullName();
      viewServiceDeliveryDetails.completedInd = true;
    }
    viewServiceDeliveryDetails.serviceDeliveryDtls.status = serviceDelivery.getLifecycleState().getCode();
    if (serviceDelivery.getLifecycleState().equals(
      SERVICEDELIVERYSTATUSEntry.OPEN)) {
      viewServiceDeliveryDetails.statusOpenInd = true;
    }
    User owner = serviceDelivery.getOwner();

    viewServiceDeliveryDetails.serviceDeliveryDtls.ownerUsername = owner.getID();
    viewServiceDeliveryDetails.ownerFullname = owner.getFullName();
    User supervisor = serviceDelivery.getSupervisor();

    if (supervisor != null) {
      viewServiceDeliveryDetails.serviceDeliveryDtls.supervisorUsername = supervisor.getID();
      viewServiceDeliveryDetails.supervisorFullname = supervisor.getFullName();
    }
    viewServiceDeliveryDetails.serviceDeliveryDtls.authorizedRate = serviceDelivery.getAuthorizedRate();
    viewServiceDeliveryDetails.serviceDeliveryDtls.unitsAuthorized = serviceDelivery.getUnitsAuthorized();
    if (!serviceDelivery.getServiceFrequencyPattern().equals(
      FrequencyPattern.kZeroFrequencyPattern)) {
      viewServiceDeliveryDetails.serviceDeliveryDtls.frequency = serviceDelivery.getServiceFrequencyPattern().toString();
    }
    if (serviceDelivery.getNote() != null) {
      viewServiceDeliveryDetails.comments = serviceDelivery.getNote().getLastNote();
      viewServiceDeliveryDetails.commentsInd = true;
    }
    viewServiceDeliveryDetails.serviceDeliveryDtls.reason = serviceDelivery.getReason();
    if (null != serviceDelivery.getNomineeConcernRole()) {
      viewServiceDeliveryDetails.serviceDeliveryDtls.nomineeConcernRoleID = serviceDelivery.getNomineeConcernRole().getID();
      viewServiceDeliveryDetails.nomineeConcernName = serviceDelivery.getNomineeConcernRole().getName();
      // BEGIN, CR00322904, SS
      viewServiceDeliveryDetails.nomineeTypeOpt = serviceDelivery.getNomineeConcernRole().getConcernRoleType().getCode();
      // END, CR00322904
    }
    viewServiceDeliveryDetails.serviceDeliveryDtls.versionNo = serviceDelivery.getVersionNo();
    if (null != serviceDelivery.getServiceAuthorization()) {
      viewServiceDeliveryDetails.serviceDeliveryDtls.serviceAuthorizationID = serviceDelivery.getServiceAuthorization().getID();
    }
    viewServiceDeliveryDetails.serviceRecipientNames = serviceDeliveryFacadeHelperProvider.get().listServiceRecipientNames(
      serviceDelivery);
    ServiceOfferingKey serviceOfferingKey = new ServiceOfferingKey();

    serviceOfferingKey.key.key.serviceOfferingID = serviceDelivery.getServiceOffering().getID();
    viewServiceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations = getServiceConfigurations(
      serviceDelivery.getServiceOffering());
    viewServiceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations.serviceUnitsLabelDisplayString = CuramConst.gkRoundOpeningBracket
      + serviceDelivery.getServiceOffering().getUnitOfMeasure().toUserLocaleString()
      + CuramConst.gkRoundClosingBracket;
    ;
    if (serviceDelivery.getProvider() != null) {
      viewServiceDeliveryDetails.serviceDeliveryDtls.providerID = serviceDelivery.getProvider().getID();
      viewServiceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations.displayProviderInd = true;
      viewServiceDeliveryDetails.providerDetails = assignProviderDetails(
        serviceDelivery.getProvider());
    }

    // if frequency was modifiable on the service delivery, display the
    // frequency. If it was not modifiable and
    // a frequency existed on the service offering, the display frequency
    // would
    // be set to true before this.
    // if the display frequency was set to false, and the frequency
    // modifiable
    // indicator was set to false, no
    // frequency should be displayed on the service delivery as its not
    // applicable
    if (viewServiceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations.serviceDeliveryConfigurations.freqModificationInd) {
      viewServiceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations.displayFrequencyInd = true;
    }
    if (!StringHelper.isEmpty(serviceDelivery.getProviderType().getCode())) {
      viewServiceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations.displayProviderTypeInd = true;
      viewServiceDeliveryDetails.serviceDeliveryDtls.providerType = serviceDelivery.getProviderType().getCode();
    }
    // BEGIN, CR00279362, SSK
    // BEGIN, CR00280918, SSK
    viewServiceDeliveryDetails.serviceDeliveryDtls.estimatedCost = serviceDelivery.getEstimatedCost();
    // END, CR00280918
    // END, CR00279362

    if (serviceDelivery.getFederalAllowableComponent() != null) {
      viewServiceDeliveryDetails.federalAllowableComponentName = serviceDelivery.getFederalAllowableComponent().getName();
      viewServiceDeliveryDetails.linkedFedComponentInd = true;
    }
    if (viewServiceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations.serviceDeliveryConfigurations.servDelParticipationInd) {
      viewServiceDeliveryDetails.participationFrequencyAndDuration = serviceDelivery.getFrequencyAndDuration();
    }
    return viewServiceDeliveryDetails;

  }

  /**
   * Assigns the provider contact information, including name, address and
   * phone number.
   *
   * @param provider
   * instance of the provider object we are assigning the details
   * for.
   * @return name, address and phone number details for the provider.
   * @throws InformationalException
   * @throws AppException
   */
  protected ProviderContactDetails assignProviderDetails(
    final curam.provider.impl.Provider provider)
    throws InformationalException, AppException {

    ProviderContactDetails providerContactDetails = new ProviderContactDetails();

    providerContactDetails.providerName = provider.getName();

    PhoneNumber phoneNumber = provider.getPrimaryPhoneNumber();

    if (null != phoneNumber) {
      providerContactDetails.phoneNumber = provider.getPrimaryPhoneNumber().getNumber();
      providerContactDetails.phoneAreaCode = provider.getPrimaryPhoneNumber().getAreaCode();
      providerContactDetails.phoneCountryCode = provider.getPrimaryPhoneNumber().getCountryCode();
    }
    if (0 != provider.getPrimaryAddressID()) {
      providerContactDetails.address = addressDAO.get(provider.getPrimaryAddressID()).getFormattedAddressData();
    }
    return providerContactDetails;
  }

  /**
   * Reads the various service offering configuration data, the case
   * participants and case user roles on a case for a specified service
   * offering. This method is used for creation/modification of a service
   * delivery on a case.
   *
   * @param caseID
   * unique identifier of the case, on which to create/modify a
   * service delivery
   * @param serviceOfferingKey
   * unique identifier of the service offering to read the
   * configuration data for
   */
  public ParticipantsCaseRolesServiceConfigurationsList getParticipantsCaseRolesAndServiceConfigurations(
    final CaseID caseID, final ServiceOfferingKey serviceOfferingKey)
    throws AppException, InformationalException {

    ParticipantsCaseRolesServiceConfigurationsList participantsCaseRolesServiceConfigurationsList = new ParticipantsCaseRolesServiceConfigurationsList();

    participantsCaseRolesServiceConfigurationsList.participantsList = serviceDeliveryFacadeHelperProvider.get().listPotentialRecipientsForCase(
      caseID);
    if (1
      == participantsCaseRolesServiceConfigurationsList.participantsList.list.size()) {
      participantsCaseRolesServiceConfigurationsList.participantsList.singleParticipantID = participantsCaseRolesServiceConfigurationsList.participantsList.list.item(0).caseParticipantRoleID;
      participantsCaseRolesServiceConfigurationsList.participantsList.singleParticipantInd = true;
      participantsCaseRolesServiceConfigurationsList.participantsList.singleParticipantName = participantsCaseRolesServiceConfigurationsList.participantsList.list.item(0).participantDescription;
    }

    participantsCaseRolesServiceConfigurationsList.soConfigurations = getServiceConfigurations(
      serviceOfferingDAO.get(serviceOfferingKey.key.key.serviceOfferingID));

    participantsCaseRolesServiceConfigurationsList.soConfigurations.displayProviderInd = determineProviderSelectable(
      PROVIDERANDTYPESELECTIONEntry.get(
        participantsCaseRolesServiceConfigurationsList.soConfigurations.serviceDeliveryConfigurations.providerAndTypeSel));
    participantsCaseRolesServiceConfigurationsList.soConfigurations.displayProviderTypeInd = determineProviderTypeSelectable(
      PROVIDERANDTYPESELECTIONEntry.get(
        participantsCaseRolesServiceConfigurationsList.soConfigurations.serviceDeliveryConfigurations.providerAndTypeSel));

    if (SERVICEDELIVERYOWNEREntry.get(participantsCaseRolesServiceConfigurationsList.soConfigurations.serviceDeliveryConfigurations.ownerToBeSpecified).equals(
      SERVICEDELIVERYOWNEREntry.ANYUSER)) {
      participantsCaseRolesServiceConfigurationsList.caseUserRoleDetailsList = serviceDeliveryFacadeHelperProvider.get().getCaseUserRoles(
        caseID);
    }
    participantsCaseRolesServiceConfigurationsList.soConfigurations.serviceUnitsLabelDisplayString = CuramConst.gkRoundOpeningBracket
      + serviceOfferingDAO.get(serviceOfferingKey.key.key.serviceOfferingID).getUnitOfMeasure().toUserLocaleString()
      + CuramConst.gkRoundClosingBracket;
    return participantsCaseRolesServiceConfigurationsList;
  }

  /**
   * Determines whether or not a provider can be selected for the particular
   * service.
   *
   * @param providerSelection
   * code indicating if a provider, provider type, both or none
   * should be selected.
   * @return indicates if a provider can be selected
   */
  protected boolean determineProviderSelectable(
    final PROVIDERANDTYPESELECTIONEntry providerSelection) {

    if ((providerSelection.getCode().equals(
      PROVIDERANDTYPESELECTIONEntry.PROVIDERMANDATORY))
        || (providerSelection.getCode().equals(
          PROVIDERANDTYPESELECTIONEntry.ROVIDERORPROVIDERTYPEMANDATORY))) {
      return true;
    }

    return false;
  }

  /**
   * Determines whether or not a provider type can be selected for the
   * particular service.
   *
   * @param providerSelection
   * code indicating if a provider, provider type, both or none
   * should be selected.
   * @return indicates if a provider type can be selected
   */
  protected boolean determineProviderTypeSelectable(
    final PROVIDERANDTYPESELECTIONEntry providerSelection) {

    if ((providerSelection.getCode().equals(
      PROVIDERANDTYPESELECTIONEntry.PROVIDERTYPEMANDATORY))
        || (providerSelection.getCode().equals(
          PROVIDERANDTYPESELECTIONEntry.ROVIDERORPROVIDERTYPEMANDATORY))) {
      return true;
    }

    return false;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceDeliveryListDetailsList listServiceDeliveries(
    final CaseID caseID) throws AppException, InformationalException {

    ServiceDeliveryListDetailsList serviceDeliveryListDetailsList = new ServiceDeliveryListDetailsList();

    List<curam.servicedelivery.impl.ServiceDelivery> serviceDeliveries = new ArrayList<curam.servicedelivery.impl.ServiceDelivery>();

    CaseHeader caseHeader = caseHeaderDAO.get(caseID.caseID);

    if (null != caseHeader) {
      serviceDeliveries = serviceDeliveryDAO.searchByCase(caseHeader);
    }
    ServiceDeliveryListDetails serviceDeliveryListDetails;

    for (curam.servicedelivery.impl.ServiceDelivery serviceDelivery : serviceDeliveries) {

      serviceDeliveryListDetails = new ServiceDeliveryListDetails();
      serviceDeliveryListDetails.serviceDeliveryID = serviceDelivery.getID();
      serviceDeliveryListDetails.serviceOfferingName = serviceDelivery.getServiceOffering().getName();
      serviceDeliveryListDetails.startDate = serviceDelivery.getCoverPeriodStartDate();
      serviceDeliveryListDetails.status = serviceDelivery.getLifecycleState().getCode();
      serviceDeliveryListDetails.tabPageID = serviceDelivery.getTabURI().getURI();
      serviceDeliveryListDetails.listSummaryPageURI = serviceDelivery.getListSummaryURI().getURI();
      // populate the service recipient list
      serviceDeliveryListDetails.serviceRecipientList = serviceDeliveryFacadeHelperProvider.get().listServiceRecipientNames(
        serviceDelivery);

      serviceDeliveryListDetailsList.listDetails.addRef(
        serviceDeliveryListDetails);
    }
    return serviceDeliveryListDetailsList;
  }

  /**
   * Reads the details of a service delivery, required for editing the record.
   *
   * @param key
   * unique identifier of the service delivery to edit
   * @return the details of the service delivery to display for modification
   */
  public ServiceDeliveryDetailsForModify readServiceDeliveryDetailsForEdit(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    ServiceDeliveryDetailsForModify serviceDeliveryDetailsForModify = new ServiceDeliveryDetailsForModify();

    serviceDeliveryDetailsForModify.serviceDeliveryDetails = viewServiceDelivery(
      key);

    // populate one of the two user owner fields depending on whether or not
    // the owner is the currently logged on user
    if (serviceDeliveryDetailsForModify.serviceDeliveryDetails.serviceDeliveryDtls.ownerUsername.equals(
      TransactionInfo.getProgramUser())) {
      serviceDeliveryDetailsForModify.loggedOnUserOwnerInd = true;
    } else {
      serviceDeliveryDetailsForModify.caseRoleOwnerUsername = serviceDeliveryDetailsForModify.serviceDeliveryDetails.serviceDeliveryDtls.ownerUsername;
    }

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    serviceDeliveryDetailsForModify.serviceDeliveryDetails.hoursDuration = serviceDelivery.getDurationHours();
    serviceDeliveryDetailsForModify.serviceDeliveryDetails.minsDuration = serviceDelivery.getDurationMinutes();
    if (serviceDelivery.getFrequencyPattern() != null) {
      serviceDeliveryDetailsForModify.serviceDeliveryDetails.serviceDeliveryDtls.participationFrequency = serviceDelivery.getFrequencyPattern().toString();
    }

    ServiceOfferingKey serviceOfferingKey = new ServiceOfferingKey();

    serviceOfferingKey.key.key.serviceOfferingID = serviceDeliveryDetailsForModify.serviceDeliveryDetails.serviceDeliveryDtls.serviceOfferingID;

    CaseID caseID = new CaseID();

    if (serviceDelivery.getRelatedCase() != null) {
      caseID.caseID = serviceDelivery.getRelatedCase().getID();
    }
    serviceDeliveryDetailsForModify.serviceDeliveryDetails.participantsCaseRolesServiceConfigs = getParticipantsCaseRolesAndServiceConfigurations(
      caseID, serviceOfferingKey);

    setClusterLayoutIndicatorFields(serviceDeliveryDetailsForModify);
    // cannot modify the service recipients if the service delivery
    // is in one of the following states: 'NOTSTARTED', 'INPROGRESS'
    // or 'COMPLETED'.
    if (!serviceAuthorizationGenerated(serviceDelivery)) {
      serviceDeliveryDetailsForModify.serviceRecipientsModifiableInd = false;
      serviceDeliveryDetailsForModify.serviceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations.serviceDeliveryConfigurations.freqModificationInd = false;
    } else {
      // recipients can be modified, set the desired indicator depending
      // on
      // whether or not multiple client selection should be enabled.
      serviceDeliveryDetailsForModify.serviceRecipientsModifiableInd = true;
      serviceDeliveryDetailsForModify.recipientIDString = serviceDeliveryFacadeHelperProvider.get().listServiceRecipientIDs(
        serviceDelivery);
      if (serviceDeliveryDetailsForModify.serviceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations.multipleClientsInd) {
        serviceDeliveryDetailsForModify.serviceRecipientsModifiableMultipleClientsAllowedInd = true;
      } else {
        serviceDeliveryDetailsForModify.serviceRecipientsModifiableSingleClientAllowedInd = true;
      }
    }
    // get the federal allowable components which can be linked to the
    // service
    List<FederalAllowableComponent> federalAllowableComponents = federalAllowableComponentDAO.listActiveByRelatedRecord(
      serviceDelivery.getServiceOffering().getID(),
      FEDALLOWCOMPRELATEDTYPEEntry.SERVICEOFFERING);

    // BEGIN, CR00423624, CC
    if (federalAllowableComponents.size() > 1) {
      if (serviceDelivery.getLifecycleState().equals(
        SERVICEDELIVERYSTATUSEntry.INPROGRESS)
          || serviceDelivery.getLifecycleState().equals(
            SERVICEDELIVERYSTATUSEntry.COMPLETED)) {
        serviceDeliveryDetailsForModify.displayFederalAllowableComponentsInd = false;
      } else {
        serviceDeliveryDetailsForModify.displayFederalAllowableComponentsInd = true;
      }
      // END, CR00423624, CC

      FederalAllowableComponentDetails federalAllowableComponentDetails;

      for (FederalAllowableComponent federalAllowableComponent : federalAllowableComponents) {
        federalAllowableComponentDetails = new FederalAllowableComponentDetails();
        federalAllowableComponentDetails.federalAllowableComponentID = federalAllowableComponent.getID();
        federalAllowableComponentDetails.name = federalAllowableComponent.getName();

        serviceDeliveryDetailsForModify.federalAllowableComponents.addRef(
          federalAllowableComponentDetails);
      }
      if (null != serviceDelivery.getFederalAllowableComponent()) {
        serviceDeliveryDetailsForModify.serviceDeliveryDetails.serviceDeliveryDtls.federalAllowableComponentID = serviceDelivery.getFederalAllowableComponent().getID();
      }
    }
    return serviceDeliveryDetailsForModify;
  }

  /**
   * Sets indicators to determine the cluster layout for display.
   *
   * @param serviceDeliveryDetailsForModify
   * details to set indicators for the client
   */
  protected void setClusterLayoutIndicatorFields(
    final ServiceDeliveryDetailsForModify serviceDeliveryDetailsForModify) {
    if ((serviceDeliveryDetailsForModify.serviceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations.multipleClientsInd)
      && (SERVICEDELIVERYOWNEREntry.get(serviceDeliveryDetailsForModify.serviceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations.serviceDeliveryConfigurations.ownerToBeSpecified).equals(
        SERVICEDELIVERYOWNEREntry.ANYUSER))) {
      serviceDeliveryDetailsForModify.multipleClientsSelectableOwnerSelectableInd = true;
    } else if ((serviceDeliveryDetailsForModify.serviceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations.multipleClientsInd)
      && (SERVICEDELIVERYOWNEREntry.get(serviceDeliveryDetailsForModify.serviceDeliveryDetails.participantsCaseRolesServiceConfigs.soConfigurations.serviceDeliveryConfigurations.ownerToBeSpecified).equals(
        SERVICEDELIVERYOWNEREntry.USERCREATINGSERVICE))) {
      serviceDeliveryDetailsForModify.multipleClientsSelectableOwnerNotSelectableInd = true;
    }
  }

  /**
   * Determines if the service authorization has already been generated for
   * the service, i.e. if the service is in one of the following states {Not
   * Started, In progress, Completed}.
   *
   * @param serviceDelivery
   * service delivery instance
   * @return indicates if they can be modified
   */
  protected boolean serviceAuthorizationGenerated(
    final curam.servicedelivery.impl.ServiceDelivery serviceDelivery) {
    if (serviceDelivery.getLifecycleState().equals(
      SERVICEDELIVERYSTATUSEntry.NOTSTARTED)
        || serviceDelivery.getLifecycleState().equals(
          SERVICEDELIVERYSTATUSEntry.INPROGRESS)
          || serviceDelivery.getLifecycleState().equals(
            SERVICEDELIVERYSTATUSEntry.COMPLETED)) {
      return false;
    }
    return true;
  }

  /**
   * {@inheritDoc}
   */
  public ListAttachmentLinkDetails listAttachments(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    ListAttachmentLinkDetails listAttachmentLinkDetails = new ListAttachmentLinkDetails();
    AttachmentLinkDetails attachmentLinkDetails;

    List<AttachmentLink> attachmentLinks = attachmentLinkDAO.searchByRelatedIDAndType(
      key.serviceDeliveryID, ATTACHMENTOBJECTLINKTYPEEntry.SERVICEDELIVERY);

    for (AttachmentLink link : attachmentLinks) {
      attachmentLinkDetails = new AttachmentLinkDetails();

      Attachment attachment = attachmentDAO.get(link.getAttachmentID());

      attachmentLinkDetails.attachmentDtls.receiptDate = attachment.getAttachmentReceiptDate();
      attachmentLinkDetails.attachmentLinkDtls.attachmentLinkID = link.getID();
      attachmentLinkDetails.attachmentLinkDtls.description = link.getDescription();

      listAttachmentLinkDetails.attachmentLinkDetails.addRef(
        attachmentLinkDetails);
    }

    return listAttachmentLinkDetails;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceDeliveryAttendanceDetailsList listAttendance(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    ServiceDeliveryAttendanceDetailsList serviceDeliveryAttendanceDetailsList = new ServiceDeliveryAttendanceDetailsList();

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    ServiceAuthorization serviceAuthorization = serviceDelivery.getServiceAuthorization();

    if (null != serviceDelivery.getProvider()) {
      serviceDeliveryAttendanceDetailsList.providerConcernRoleID = serviceDelivery.getProvider().getID();

      if (null != serviceDelivery.getServiceAuthorization()) {

        Set<ServiceAuthorizationLineItem> serviceAuthorizationLineItems = serviceAuthorizationLineItemDAO.searchByServiceAuthorization(
          serviceAuthorization);

        for (ServiceAuthorizationLineItem lineItem : serviceAuthorizationLineItems) {

          Set<ProviderRosterLineItem> providerRosterLineItems = lineItem.getRelatedRosterLineItem();

          for (ProviderRosterLineItem providerRosterLineItem : providerRosterLineItems) {

            Set<curam.attendance.impl.DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
              providerRosterLineItem.getRosterLineItemID());

            ServiceDeliveryAttendanceDetails serviceDeliveryAttendanceDetails;

            for (DailyAttendance dailyAttendance : serviceDeliveryFacadeHelperProvider.get().sortDailyAttendanceByServiceDate(
              dailyAttendanceList)) {

              if (RECORDSTATUSEntry.NORMAL.equals(dailyAttendance.getStatus())) {

                serviceDeliveryAttendanceDetails = serviceDeliveryFacadeHelperProvider.get().getDailyAttendanceDetails(
                  dailyAttendance);
                serviceDeliveryAttendanceDetails.providerRosterLineItemID = providerRosterLineItem.getID();
                serviceDeliveryAttendanceDetails.rosterLineItemVersionNo = providerRosterLineItem.getRLIVersionNo();
                serviceDeliveryAttendanceDetailsList.attendanceDetails.addRef(
                  serviceDeliveryAttendanceDetails);
              }
            }

          }
        }
      }
    }
    return serviceDeliveryAttendanceDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceInvoiceLineItemsDetailsList listInvoices(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    ServiceInvoiceLineItemsDetailsList serviceInvoiceLineItemsDetailsList = new ServiceInvoiceLineItemsDetailsList();
    ServiceInvoiceLineItemDetails serviceInvoiceLineItemDetails;

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    ServiceAuthorization serviceAuthorization = serviceDelivery.getServiceAuthorization();

    if (null != serviceDelivery.getServiceAuthorization()) {
      Set<ServiceAuthorizationLineItem> serviceAuthorizationLineItems = serviceAuthorizationLineItemDAO.searchByServiceAuthorization(
        serviceAuthorization);

      for (ServiceAuthorizationLineItem lineItem : serviceAuthorizationLineItems) {

        Set<ServiceInvoiceLineItem> serviceInvoiceLineItems = serviceInvoiceLineItemDAO.searchByServiceAuthorizationLineItem(
          lineItem);

        for (ServiceInvoiceLineItem invoiceLineItem : serviceInvoiceLineItems) {

          serviceInvoiceLineItemDetails = new ServiceInvoiceLineItemDetails();
          serviceInvoiceLineItemDetails.details.amountInvoiced = invoiceLineItem.getAmountInvoiced();
          serviceInvoiceLineItemDetails.details.referenceNo = invoiceLineItem.getReferenceNumber();
          serviceInvoiceLineItemDetails.details.noOfUnits = invoiceLineItem.getNumberOfUnits();
          serviceInvoiceLineItemDetails.details.serviceDateFrom = invoiceLineItem.getServiceDateFrom();
          serviceInvoiceLineItemDetails.details.serviceInvoiceLineItemID = invoiceLineItem.getID();
          serviceInvoiceLineItemsDetailsList.dtlsList.addRef(
            serviceInvoiceLineItemDetails);
        }
      }
    }
    return serviceInvoiceLineItemsDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public void createAttachment(final AttachmentLinkDetails details)
    throws AppException, InformationalException {

    AttachmentLink attachmentLink = attachmentLinkDAO.newInstance();

    details.attachmentLinkDtls.relatedObjectType = ATTACHMENTOBJECTLINKTYPEEntry.SERVICEDELIVERY.getCode();

    // BEGIN, CR00360398, CD
    // set up some meta data for the attachment
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      details.attachmentLinkDtls.relatedObjectID);
    CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

    cmsMetadata.add(CMSMetadataConst.kCaseID,
      Long.toString(serviceDelivery.getCase().getID()));
    // END, CR00360398

    attachmentLink.insert(details);

  }

  /**
   * {@inheritDoc}
   */
  public ServiceDeliveryApprovalRequestDetailsList listApprovalRequests(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    ServiceDeliveryApprovalRequestDetailsList serviceDeliveryApprovalRequestDetailsList = new ServiceDeliveryApprovalRequestDetailsList();
    ServiceDeliveryApprovalRequestDetails serviceDeliveryApprovalRequestDetails;

    List<? extends ApprovalRequestAccessor> approvalRequests = approvalRequestDAO.searchByRelatedIDAndRelatedType(
      key.serviceDeliveryID, APPROVALRELATEDTYPEEntry.SERVICEDELIVERY);

    for (ApprovalRequestAccessor approvalRequest : approvalRequests) {
      serviceDeliveryApprovalRequestDetails = assignApprovalRequestDetails(
        approvalRequest);
      serviceDeliveryApprovalRequestDetailsList.details.addRef(
        serviceDeliveryApprovalRequestDetails);
    }
    return serviceDeliveryApprovalRequestDetailsList;
  }

  /**
   * Assigns the approval request list detail.
   *
   * @param approvalRequest
   * the approval request instance.
   * @return populated list data object
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  protected ServiceDeliveryApprovalRequestDetails assignApprovalRequestDetails(
    final ApprovalRequestAccessor approvalRequest)
    throws InformationalException, AppException {
    ServiceDeliveryApprovalRequestDetails serviceDeliveryApprovalRequestDetails;

    serviceDeliveryApprovalRequestDetails = new ServiceDeliveryApprovalRequestDetails();
    serviceDeliveryApprovalRequestDetails.approvalRequestID = approvalRequest.getID();
    serviceDeliveryApprovalRequestDetails.decision = approvalRequest.getDecision();
    serviceDeliveryApprovalRequestDetails.decisionByFullname = approvalRequest.getDecisionUserFullName();
    serviceDeliveryApprovalRequestDetails.decisionByUsername = approvalRequest.getDecisionByUserName();
    serviceDeliveryApprovalRequestDetails.decisionDate = approvalRequest.getDecisionDate();
    serviceDeliveryApprovalRequestDetails.requestDate = approvalRequest.getRequestDate();
    serviceDeliveryApprovalRequestDetails.requestedByFullname = approvalRequest.getRequestedByFullname();
    serviceDeliveryApprovalRequestDetails.requestedByUsername = approvalRequest.getRequestedByUsername();
    return serviceDeliveryApprovalRequestDetails;
  }

  /**
   * {@inheritDoc}
   */
  public void addComment(final ServiceDeliveryNoteDetails noteDetails)
    throws AppException, InformationalException {
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      noteDetails.key.serviceDeliveryID);

    serviceDelivery.addComment(noteDetails.notesText,
      noteDetails.versionNoKey.versionNoKey.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void complete(final ServiceDeliveryCompleteDetails completeDetails)
    throws AppException, InformationalException {

    validateCompletionDetails(
      ACTIVITYOUTCOMEACHIEVEDEntry.get(completeDetails.outcome),
      ACTIVITYOUTCOMEREASONEntry.get(completeDetails.outcomeReason));

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      completeDetails.key.serviceDeliveryID);

    // maintain service security check
    serviceOfferingSecurity.checkMaintainRights(
      serviceDelivery.getServiceOffering());

    serviceDelivery.setOutcomeAchieved(
      ACTIVITYOUTCOMEACHIEVEDEntry.get(completeDetails.outcome));
    serviceDelivery.setOutcomeReason(
      ACTIVITYOUTCOMEREASONEntry.get(completeDetails.outcomeReason));
    serviceDelivery.setCompletionComments(completeDetails.comments);
    serviceDelivery.complete(completeDetails.versionNoKey.versionNo);
  }

  /**
   * Validates the service delivery completion outcome and outcome reason.
   *
   * @param outcomeAchieved
   * the outcome achieved for the service
   * @param outcomeReason
   * reason specified for the outcome achieved
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * {@link SERVICEDELIVERY#ERR_OUTCOME_REASON_MANDATORY} - if the
   * Outcome Achieved is set to 'Not Successful' and the Outcome
   * Reason is not specified.
   * @throws AppException
   * {@link SERVICEDELIVERY#ERR_OUTCOME_REASON_NOT_APPLICABLE_OUTCOME_SUCCESSFUL}
   * - if the Outcome Achieved is set to 'Successful' and the
   * Outcome Reason is specified.
   */
  protected void validateCompletionDetails(
    final ACTIVITYOUTCOMEACHIEVEDEntry outcomeAchieved,
    final ACTIVITYOUTCOMEREASONEntry outcomeReason)
    throws InformationalException {

    if (outcomeAchieved.equals(ACTIVITYOUTCOMEACHIEVEDEntry.NOTSUCCESSFUL)
      && outcomeReason.equals(ACTIVITYOUTCOMEACHIEVEDEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEDELIVERYExceptionCreator.ERR_OUTCOME_REASON_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if (outcomeAchieved.equals(ACTIVITYOUTCOMEACHIEVEDEntry.SUCCESSFUL)
      && (!(outcomeReason.equals(ACTIVITYOUTCOMEREASONEntry.NOT_SPECIFIED)))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEDELIVERYExceptionCreator.ERR_OUTCOME_REASON_NOT_APPLICABLE_OUTCOME_SUCCESSFUL(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();
  }

  /**
   * {@inheritDoc}
   */
  public void editCompletionDetails(
    final ServiceDeliveryCompleteDetails completionDetails)
    throws AppException, InformationalException {

    validateCompletionDetails(
      ACTIVITYOUTCOMEACHIEVEDEntry.get(completionDetails.outcome),
      ACTIVITYOUTCOMEREASONEntry.get(completionDetails.outcomeReason));
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      completionDetails.key.serviceDeliveryID);

    // maintain service security check
    serviceOfferingSecurity.checkMaintainRights(
      serviceDelivery.getServiceOffering());

    serviceDelivery.setOutcomeAchieved(
      ACTIVITYOUTCOMEACHIEVEDEntry.get(completionDetails.outcome));
    serviceDelivery.setOutcomeReason(
      ACTIVITYOUTCOMEREASONEntry.get(completionDetails.outcomeReason));
    serviceDelivery.setCompletionComments(completionDetails.comments);
    serviceDelivery.modify(completionDetails.versionNoKey.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public ServiceDeliveryCompleteDetails readCompletionDetails(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {
    ServiceDeliveryCompleteDetails completionDetails = new ServiceDeliveryCompleteDetails();
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    // view service security check
    serviceOfferingSecurity.checkViewRights(
      serviceDelivery.getServiceOffering());

    completionDetails.comments = serviceDelivery.getCompletionComments();
    completionDetails.outcome = serviceDelivery.getOutcomeAchieved().getCode();
    completionDetails.outcomeReason = serviceDelivery.getOutcomeReason().getCode();
    completionDetails.key.serviceDeliveryID = serviceDelivery.getID();
    completionDetails.versionNoKey.versionNo = serviceDelivery.getVersionNo();
    return completionDetails;
  }

  /**
   * {@inheritDoc}
   */
  public void submit(final ServiceDeliveryKey key,
    final VersionNoKey versionNoKey) throws AppException,
      InformationalException {
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    serviceDelivery.submit(versionNoKey.versionNo);

  }

  /**
   * {@inheritDoc}
   */
  public void approve(final ServiceDeliveryVersionKey key)
    throws AppException, InformationalException {
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.key.serviceDeliveryID);

    serviceDelivery.approve(key.versionNoKey.versionNo);
    // update the approval request
    approvalRequestDAO.newInstance().approve(TransactionInfo.getProgramUser(),
      key.key.serviceDeliveryID, APPROVALRELATEDTYPEEntry.SERVICEDELIVERY);
  }

  /**
   * {@inheritDoc}
   */
  public void reject(final RejectionDetails rejectionDetails,
    final ServiceDeliveryVersionKey key) throws AppException,
      InformationalException {
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.key.serviceDeliveryID);

    serviceDelivery.reject(key.versionNoKey.versionNo);

    ApprovalRequest approvalRequest = approvalRequestDAO.getApprovalRequest(
      key.key.serviceDeliveryID, APPROVALRELATEDTYPEEntry.SERVICEDELIVERY);

    // update the approval request
    approvalRequest.reject(TransactionInfo.getProgramUser(),
      key.key.serviceDeliveryID, APPROVALRELATEDTYPEEntry.SERVICEDELIVERY,
      REJECTIONREASONEntry.get(
      rejectionDetails.rejectionReasonAndCommentsDetails.rejectionReasonAndCommentsDetails.rejectionReason),
      rejectionDetails.rejectionReasonAndCommentsDetails.rejectionReasonAndCommentsDetails.rejectionComments);

  }

  /**
   * {@inheritDoc}
   */
  public PaymentInformationDetailsList listPayments(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    PaymentInformationDetailsList paymentInformationDetailsList = new PaymentInformationDetailsList();
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    if (null != serviceDelivery.getServiceAuthorization()) {

      Set<PaymentInformation> paymentInformationSet = financialAPI.retrievePaymentInformation(
        serviceDelivery.getServiceAuthorization());

      for (PaymentInformation paymentInformation : paymentInformationSet) {
        FinancialInstruction financialInstruction = financialInstructionDAO.get(
          paymentInformation.getFinancialInstructionID());

        if (financialInstruction.getID() != 0) {
          PaymentInformationDetails paymentInformationDetails = new PaymentInformationDetails();

          paymentInformationDetails.amountInvoiced = paymentInformation.getAmountInvoiced();

          paymentInformationDetails.amountPaid = paymentInformation.getAmountPaid();
          paymentInformationDetails.numberOfUnits = new Long(paymentInformation.getNumberOfUnits()).intValue();
          paymentInformationDetails.paymentFromDate = paymentInformation.getPaymentPeriod().start();
          paymentInformationDetails.paymentToDate = paymentInformation.getPaymentPeriod().end();
          paymentInformationDetails.paymentDate = financialInstruction.getEffectiveDate();
          if (paymentInformation.getProviderID() != 0) {
            paymentInformationDetails.providerName = providerDAO.get(paymentInformation.getProviderID()).getName();
          }
          if (paymentInformation.getClientID() != 0) {
            paymentInformationDetails.clientName = concernRoleDAO.get(paymentInformation.getClientID()).getName();
          }

          // BEGIN, CR00281495, GYH
          // BEGIN, CR00282549, GYH
          // BEGIN, CR00291762, GYH
          paymentInformationDetails.deliveryMethodTypeOpt = paymentInformation.getDeliveryMethodType();
          paymentInformationDetails.dueDateOpt = paymentInformation.getDueDate();
          paymentInformationDetails.typeCodeOpt = paymentInformation.getInstructionLineItemCategory();
          paymentInformationDetails.caseNomineeIDOpt = paymentInformation.getCaseNomineeID();

          CaseNomineeKey caseNomineeKey = new CaseNomineeKey();

          caseNomineeKey.caseNomineeID = paymentInformation.getCaseNomineeID();
          paymentInformationDetails.caseNomineeNameOpt = ConcernRoleFactory.newInstance().readNameByCaseNomineeID(caseNomineeKey).concernRoleName;
          // END, CR00291762
          // END, CR00282549
          // END, CR00281495

          paymentInformationDetailsList.payments.addRef(
            paymentInformationDetails);
        }
      }
    }
    Collections.sort(paymentInformationDetailsList.payments,
      new Comparator<PaymentInformationDetails>() {
      public int compare(final PaymentInformationDetails lhs,
        final PaymentInformationDetails rhs) {
        return lhs.paymentDate.compareTo(rhs.paymentDate);
      }
    });
    return paymentInformationDetailsList;
  }

  /**
   * Gets the service configuration data for the specified
   * {@link ServiceOffering}.
   *
   * @param serviceOffering
   * service offering object instance
   * @return the service configuration data
   */
  protected ServiceConfigurations getServiceConfigurations(
    final ServiceOffering serviceOffering) {

    return serviceDeliveryFacadeHelperProvider.get().getServiceConfigurationData(
      serviceOffering);

  }

  /**
   * {@inheritDoc}
   */
  public ServiceDeliveryApprovalRequestViewDetails viewApprovalRequest(
    final ApprovalRequestKey key) throws AppException,
      InformationalException {

    ApprovalRequestAccessor approvalRequestAccessor = approvalRequestDAO.get(
      key.key.approvalRequestID);

    ServiceDeliveryApprovalRequestViewDetails serviceDeliveryApprovalRequestViewDetails = new ServiceDeliveryApprovalRequestViewDetails();

    serviceDeliveryApprovalRequestViewDetails.details = assignApprovalRequestDetails(
      approvalRequestAccessor);
    if (approvalRequestAccessor.getStatus().equals(
      APPROVALREQUESTSTATUSEntry.REJECTED)) {
      serviceDeliveryApprovalRequestViewDetails.rejectedStatusInd = true;
      serviceDeliveryApprovalRequestViewDetails.rejectionReason = approvalRequestAccessor.getApprovalRejectionReason().getCode();
      serviceDeliveryApprovalRequestViewDetails.rejectionComments = approvalRequestAccessor.getApprovalRejectionComments();
    }
    serviceDeliveryApprovalRequestViewDetails.status = approvalRequestAccessor.getStatus().getCode();
    return serviceDeliveryApprovalRequestViewDetails;

  }

  /**
   * Populates the service context description.
   *
   * @param serviceDelivery
   * service delivery object instance
   * @return the context description string
   */
  protected String getContext(
    final curam.servicedelivery.impl.ServiceDelivery serviceDelivery) {
    return new StringBuffer(serviceDelivery.getServiceOffering().getName()).append(CuramConst.gkSpace).append(CuramConst.gkRoundOpeningBracket).append(serviceDeliveryFacadeHelperProvider.get().listServiceRecipientNames(serviceDelivery)).append(CuramConst.gkRoundClosingBracket).toString();
  }

  /**
   * Reads the details required to view an approval task for a service
   * delivery.
   *
   * @param key
   * unique identifier for the service delivery for approval
   * @return the details required for viewing an approval task for a service
   * delivery
   */
  public ApprovalRequestTaskDetail readApprovalTaskDetails(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    ApprovalRequestTaskDetail approvalRequestTaskDetail = new ApprovalRequestTaskDetail();
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    approvalRequestTaskDetail.contextDescription = serviceDelivery.getServiceOffering().getName();
    approvalRequestTaskDetail.versionNumber = serviceDelivery.getVersionNo();
    approvalRequestTaskDetail.serviceDeliveryID = serviceDelivery.getID();
    return approvalRequestTaskDetail;
  }

  /**
   * Reads the version number for a service delivery.
   *
   * @param key
   * unique identifier for the service delivery
   * @return the version number of the record
   */
  public VersionNoKey getVersionNo(final ServiceDeliveryKey key)
    throws AppException, InformationalException {
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);
    VersionNoKey versionNoKey = new VersionNoKey();

    versionNoKey.versionNo = serviceDelivery.getVersionNo();
    return versionNoKey;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderSearchCriteriaDetails getProviderSearchCriteriaAndProvidersList(
    final ServiceDeliveryKey key,
    final ListProviderDetailsKey providerSearchKey)
    throws AppException, InformationalException {

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    ProviderSearchCriteriaDetails providerSearchCriteriaDetails = new ProviderSearchCriteriaDetails();

    providerSearchCriteriaDetails.serviceOfferingID = serviceDelivery.getServiceOffering().getID();

    providerSearchCriteriaDetails.caseClients.assign(
      serviceProviderSearchHelperProvider.get().getCaseClientsNameList(
        serviceDelivery.listCaseParticipantRoles()));

    providerSearchCriteriaDetails.proximityDistanceLabelDisplayString = CuramConst.gkRoundOpeningBracket
      + serviceProviderSearchHelperProvider.get().getMeasurementDistance().toUserLocaleString()
      + CuramConst.gkRoundClosingBracket;
    providerSearchCriteriaDetails.specialties = serviceProviderSearchHelperProvider.get().getProviderSpecialityCodesAsList();

    if ((providerSearchKey.addressID != 0)
      || (!StringHelper.isEmpty(
        providerSearchKey.providerSpecialtiesTabbedString))
        || (!StringHelper.isEmpty(providerSearchKey.providerName))) {
      List<ProviderSpecialtyTypeEntry> specialties = new ArrayList<ProviderSpecialtyTypeEntry>();

      if (!StringHelper.isEmpty(
        providerSearchKey.providerSpecialtiesTabbedString)) {
        String[] specialtyCodes = providerSearchKey.providerSpecialtiesTabbedString.split(
          CuramConst.gkTabDelimiter);

        for (String specialtyCode : specialtyCodes) {
          specialties.add(ProviderSpecialtyTypeEntry.get(specialtyCode));
        }
      }
      providerSearchCriteriaDetails.providers = serviceProviderSearchHelperProvider.get().listProvidersForServiceOffering(
        serviceDelivery.getServiceOffering(),
        addressDAO.get(providerSearchKey.addressID), specialties,
        PROXIMITYDISTANCEEntry.get(providerSearchKey.proximityDistance),
        providerSearchKey.providerName);
      providerSearchCriteriaDetails.providers.providerCriteriaInd = true;
      providerSearchCriteriaDetails.providerSelectableInd = determineIfproviderSelectable(
        serviceDelivery);
    }

    providerSearchCriteriaDetails.providers.providerSearchCriteria.addressID = providerSearchKey.addressID;
    providerSearchCriteriaDetails.providers.providerSearchCriteria.caseParticipantRoleID = providerSearchKey.caseParticipantRoleID;
    providerSearchCriteriaDetails.providers.providerSearchCriteria.providerSpecialtiesTabbedString = providerSearchKey.providerSpecialtiesTabbedString;
    providerSearchCriteriaDetails.providers.providerSearchCriteria.proximityDistance = providerSearchKey.proximityDistance;
    providerSearchCriteriaDetails.serviceOfferingID = serviceDelivery.getServiceOffering().getID();
    providerSearchCriteriaDetails.providers.providerSearchCriteria.providerName = providerSearchKey.providerName;

    return providerSearchCriteriaDetails;
  }

  /**
   * Determines if a provider can be selected for a Service Delivery. This is
   * determined by a consideration of service delivery configurations and the
   * status of the service delivery.
   *
   * @param serviceDelivery
   * the service delivery instance to determine if a provider can
   * be selected for
   * @return true if a provider can be selected, false if not
   */
  protected boolean determineIfproviderSelectable(
    final curam.servicedelivery.impl.ServiceDelivery serviceDelivery) {

    ServiceDeliveryConfigurationAccessor serviceDeliveryConfiguration = serviceDelivery.getServiceOffering().getServiceDeliveryConfiguration();

    if (serviceDelivery.getLifecycleState().equals(
      SERVICEDELIVERYSTATUSEntry.COMPLETED)
        || serviceDelivery.getLifecycleState().equals(
          SERVICEDELIVERYSTATUSEntry.INPROGRESS)
          || serviceDelivery.getLifecycleState().equals(
            SERVICEDELIVERYSTATUSEntry.NOTSTARTED)) {

      return false;
    }

    if (serviceDeliveryConfiguration == null) {
      if (!(serviceDelivery.getProvider() == null
        && (serviceDelivery.getProviderType().equals(
          ProviderTypeNameEntry.NOT_SPECIFIED)))) {
        return false;
      }
    } else if ((serviceDeliveryConfiguration.getProviderAndProviderTypeSelection().equals(
      PROVIDERANDTYPESELECTIONEntry.PROVIDERTYPEMANDATORY))
        || (serviceDeliveryConfiguration.getProviderAndProviderTypeSelection().equals(
          PROVIDERANDTYPESELECTIONEntry.PROVIDERANDPROVIDERTYPENOTREQUIRED))) {
      return false;
    }
    return true;
  }

  /**
   * {@inheritDoc}
   */
  public void addProvider(final ProviderKey providerKey,
    final ServiceDeliveryVersionKey serviceDeliveryVersionNoKey)
    throws AppException, InformationalException {

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      serviceDeliveryVersionNoKey.key.serviceDeliveryID);

    serviceDelivery.updateProvider(
      providerDAO.get(providerKey.providerConcernRoleID),
      serviceDeliveryVersionNoKey.versionNoKey.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void addProviderType(
    final ProviderTypeSelectionDetails providerType,
    final ServiceDeliveryVersionKey serviceDeliveryVersionNoKey)
    throws AppException, InformationalException {

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      serviceDeliveryVersionNoKey.key.serviceDeliveryID);

    serviceDelivery.updateProviderType(
      ProviderTypeNameEntry.get(providerType.providerType),
      serviceDeliveryVersionNoKey.versionNoKey.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void removeProvider(
    final ServiceDeliveryVersionKey serviceDeliveryVersionNoKey)
    throws AppException, InformationalException {
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      serviceDeliveryVersionNoKey.key.serviceDeliveryID);

    serviceDelivery.updateProvider(null,
      serviceDeliveryVersionNoKey.versionNoKey.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void removeProviderTypeSelection(
    final ServiceDeliveryVersionKey serviceDeliveryVersionNoKey)
    throws AppException, InformationalException {
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      serviceDeliveryVersionNoKey.key.serviceDeliveryID);

    serviceDelivery.updateProviderType(ProviderTypeNameEntry.NOT_SPECIFIED,
      serviceDeliveryVersionNoKey.versionNoKey.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void evaluateService(final ServiceEvaluationDetails details,
    final ServiceDeliveryVersionKey serviceDeliveryVersionKey)
    throws AppException, InformationalException {

    curam.servicedeliveryevaluation.impl.ServiceDeliveryEvaluation serviceDeliveryEvaluation = serviceDeliveryEvaluationDAO.newInstance();
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      serviceDeliveryVersionKey.key.serviceDeliveryID);

    serviceDeliveryEvaluation.setComments(details.dtls.comments);

    if (null != serviceDelivery.getProvider()) {
      serviceDeliveryEvaluation.setProvider(serviceDelivery.getProvider());
    }
    serviceDeliveryEvaluation.setServiceOffering(
      serviceDelivery.getServiceOffering());

    String[] criterionAndScoresList = details.widget.split(CuramConst.gkComma);
    Map<SOEvaluationCriterion, SECRESPONSEVALUEEntry> scoresMap = new HashMap<SOEvaluationCriterion, SECRESPONSEVALUEEntry>(
      criterionAndScoresList.length);

    for (String criterionScore : criterionAndScoresList) {
      String[] criterionAndScoreDelimited = criterionScore.split(
        CuramConst.gkTabDelimiter);

      if (criterionAndScoreDelimited.length == 2) {
        scoresMap.put(
          soEvaluationCriterionDAO.get(
            Long.valueOf(criterionAndScoreDelimited[0])),
            SECRESPONSEVALUEEntry.get(criterionAndScoreDelimited[1]));
      }
    }
    if (0 == scoresMap.size()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEDELIVERYEVALUATIONExceptionCreator.ERR_NO_EVALUATION_DATA_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }
    serviceDeliveryEvaluation.insert(scoresMap);

    serviceDelivery.setServiceDeliveryEvaluation(serviceDeliveryEvaluation);
    serviceDelivery.modify(serviceDeliveryVersionKey.versionNoKey.versionNo);
    serviceDeliveryEvaluation.calculateOutcomeForServiceDeliveryEvaluation();

  }

  /**
   * {@inheritDoc}
   */
  public EvaluationCriteriaData listEvaluationCriteriaAndScores(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {
    EvaluationCriteriaData evaluationCriteriaData = new EvaluationCriteriaData();
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    Set<SOEvaluationCriterion> soEvaluationCriterions = soEvaluationCriterionDAO.searchByServiceOffering(
      serviceDelivery.getServiceOffering());
    List<SOEvaluationCriterion> soEvaluationCriterionList = convertSOEvaluationCriterionToSortedList(
      soEvaluationCriterions);

    if (0 == soEvaluationCriterionList.size()) {
      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        SERVICEDELIVERYEVALUATIONExceptionCreator.INF_CANNOT_EVALUATE_SERVICE_NO_CRITERIA_SPECIFIED(
          serviceDelivery.getServiceOffering().getName()),
          CuramConst.gkEmpty,
          InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

      String[] informationals = informationalManager.obtainInformationalAsString();

      for (String message : informationals) {
        InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = message;
        evaluationCriteriaData.infoMsgList.dtls.addRef(informationalMsgDtls);
      }

    } else {
      evaluationCriteriaData.evaluationCriteriaExist = true;
      evaluationCriteriaData.evaluationCriteriaAndScoresXML = serviceDeliveryFacadeHelperProvider.get().getEvaluationCriteriaAndScoresXml(
        soEvaluationCriterionList);
      evaluationCriteriaData.serviceDeliveryVersionNo = serviceDelivery.getVersionNo();
    }
    return evaluationCriteriaData;
  }

  /**
   * Converts the set of {@link SOEvaluationCriterion} records into a list,
   * sorted in alphabetical order, based on the criterion name.
   *
   * @param soEvaluationCriterions
   * set of {@link SOEvaluationCriterion} records for the service
   * @return sorted list of {@link SOEvaluationCriterion}
   */
  protected List<SOEvaluationCriterion> convertSOEvaluationCriterionToSortedList(
    final Set<SOEvaluationCriterion> soEvaluationCriterions) {
    // Convert to a list, to enable a sort.
    List<SOEvaluationCriterion> soEvaluationCriterionList = new ArrayList<SOEvaluationCriterion>(
      soEvaluationCriterions);

    Collections.sort(soEvaluationCriterionList,
      new Comparator<SOEvaluationCriterion>() {
      public int compare(final SOEvaluationCriterion lhs,
        final SOEvaluationCriterion rhs) {
        return lhs.getServiceEvaluationCriterion().getCriterion().compareTo(
          rhs.getServiceEvaluationCriterion().getCriterion());
      }
    });

    return soEvaluationCriterionList;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEvaluationOverviewDetails viewServiceEvaluationOverview(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    ServiceEvaluationOverviewDetails summaryList = new ServiceEvaluationOverviewDetails();

    ServiceDeliveryEvaluation serviceDeliveryEvaluation = serviceDelivery.getServiceDeliveryEvaluation();

    if (null != serviceDeliveryEvaluation
      && (!serviceDeliveryEvaluation.getLifecycleState().equals(
        RECORDSTATUSEntry.CANCELLED))) {
      summaryList.createdByFullName = serviceDeliveryEvaluation.getCreatedBy().getFullName();
      summaryList.dtls.createdBy = serviceDeliveryEvaluation.getCreatedBy().getID();
      summaryList.dtls.creationDate = serviceDeliveryEvaluation.getCreationDate();
      summaryList.dtls.comments = serviceDeliveryEvaluation.getComments();
      Map<SOEvaluationCriterion, SECRESPONSEVALUEEntry> ratingsMap = serviceDeliveryEvaluation.listCriterionEvaluationsForServiceDeliveryEvaluation();
      ServiceCriterionEvaluationSummary serviceCriterionEvaluationSummary;

      for (SOEvaluationCriterion soEvaluationCriterion : ratingsMap.keySet()) {
        serviceCriterionEvaluationSummary = new ServiceCriterionEvaluationSummary();
        serviceCriterionEvaluationSummary.soCriterionName = soEvaluationCriterion.getServiceEvaluationCriterion().getCriterion();
        serviceCriterionEvaluationSummary.soCriterionDescription = soEvaluationCriterion.getServiceEvaluationCriterion().getComments();
        serviceCriterionEvaluationSummary.rating = ratingsMap.get(soEvaluationCriterion).getCode();
        summaryList.criterionSummaryList.summaryDtls.addRef(
          serviceCriterionEvaluationSummary);
      }
    }

    return summaryList;
  }

  /**
   * Reads the evaluation details required for modifying a service delivery
   * evaluation.
   *
   * @param serviceDeliveryKey
   * unique identifier of the service delivery
   * @return the evaluation details required in order to perform a
   * modification of the evaluation
   */
  public ServiceEvaluationDetailsForModify readServiceEvaluationForModify(
    final ServiceDeliveryKey serviceDeliveryKey) throws AppException,
      InformationalException {

    ServiceEvaluationDetailsForModify serviceEvaluationDetailsForModify = new ServiceEvaluationDetailsForModify();
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      serviceDeliveryKey.serviceDeliveryID);
    ServiceDeliveryEvaluation serviceDeliveryEvaluation = serviceDelivery.getServiceDeliveryEvaluation();

    serviceEvaluationDetailsForModify.dtls.comments = serviceDeliveryEvaluation.getComments();
    serviceEvaluationDetailsForModify.dtls.versionNo = serviceDeliveryEvaluation.getVersionNo();
    serviceEvaluationDetailsForModify.dtls.serviceDeliveryEvaluationID = serviceDeliveryEvaluation.getID();
    Set<SOEvaluationCriterion> soEvaluationCriteria = soEvaluationCriterionDAO.searchByServiceOffering(
      serviceDelivery.getServiceOffering());
    List<SOEvaluationCriterion> soEvaluationCriterionList = convertSOEvaluationCriterionToSortedList(
      soEvaluationCriteria);

    serviceEvaluationDetailsForModify.criteriaResponsesList.evaluationCriteriaAndScoresXML = serviceDeliveryFacadeHelperProvider.get().getEvaluationCriteriaResponsesForExistingEvaluationXml(
      soEvaluationCriterionList, serviceDeliveryEvaluation);
    return serviceEvaluationDetailsForModify;
  }

  /**
   * {@inheritDoc}
   */
  public void updateServiceEvaluation(
    final ServiceEvaluationDetails modifyDetails) throws AppException,
      InformationalException {

    ServiceDeliveryEvaluation serviceDeliveryEvaluation = serviceDeliveryEvaluationDAO.get(
      modifyDetails.dtls.serviceDeliveryEvaluationID);

    serviceDeliveryEvaluation.setComments(modifyDetails.dtls.comments);
    String[] criterionAndScoresList = modifyDetails.widget.split(
      CuramConst.gkComma);
    Map<SOEvaluationCriterion, SECRESPONSEVALUEEntry> scoresMap = new HashMap<SOEvaluationCriterion, SECRESPONSEVALUEEntry>(
      criterionAndScoresList.length);
    List<SOEvaluationCriterion> blankScores = new ArrayList<SOEvaluationCriterion>();

    for (String criterionScore : criterionAndScoresList) {
      String[] criterionAndScoreDelimited = criterionScore.split(
        CuramConst.gkTabDelimiter);

      if (criterionAndScoreDelimited.length == 2) {
        scoresMap.put(
          soEvaluationCriterionDAO.get(
            Long.valueOf(criterionAndScoreDelimited[0])),
            SECRESPONSEVALUEEntry.get(criterionAndScoreDelimited[1]));
      } else if (criterionAndScoreDelimited.length == 1) {
        blankScores.add(
          soEvaluationCriterionDAO.get(
            Long.valueOf(criterionAndScoreDelimited[0])));
      }
    }
    if (0 == scoresMap.size()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEDELIVERYEVALUATIONExceptionCreator.ERR_NO_EVALUATION_DATA_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      ValidationHelper.failIfErrorsExist();
    }
    serviceDeliveryEvaluation.modify(scoresMap, blankScores,
      modifyDetails.dtls.versionNo);

    serviceDeliveryEvaluation.calculateOutcomeForServiceDeliveryEvaluation();

  }

  /**
   * {@inheritDoc}
   */
  public void cancelServiceEvaluation(final ServiceEvaluationVersionNoKey key)
    throws AppException, InformationalException {

    ServiceDeliveryEvaluation serviceDeliveryEvaluation = serviceDeliveryEvaluationDAO.get(
      key.serviceDeliveryEvaluationID);

    serviceDeliveryEvaluation.cancel(key.versionNo);
  }

  /**
   * Reads the service evaluation data required for canceling an evaluation
   * provided for a service delivery.
   *
   * @param key
   * unique identifier of the service delivery
   * @return the unique service delivery evaluation identifier and its version
   * number
   */
  public ServiceEvaluationVersionNoKey readServiceEvaluationForDelete(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);
    ServiceDeliveryEvaluation serviceDeliveryEvaluation = serviceDelivery.getServiceDeliveryEvaluation();

    ServiceEvaluationVersionNoKey versionNoKey = new ServiceEvaluationVersionNoKey();

    versionNoKey.serviceDeliveryEvaluationID = serviceDeliveryEvaluation.getID();
    versionNoKey.versionNo = serviceDeliveryEvaluation.getVersionNo();
    return versionNoKey;
  }

  /**
   * {@inheritDoc}
   */
  public ViewServiceDeliveryStatusHistoryDetailsList viewServiceDeliveryStatusHistory(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {
    ViewServiceDeliveryStatusHistoryDetailsList viewServiceDeliveryStatusHistoryDetailsList = new ViewServiceDeliveryStatusHistoryDetailsList();
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    // view service security check
    serviceOfferingSecurity.checkViewRights(
      serviceDelivery.getServiceOffering());

    ViewServiceDeliveryStatusHistoryDetails viewServiceDeliveryStatusHistoryDetails;

    List<ServiceDeliveryStatusHistory> serviceDeliveryStatusHistoryLinks = serviceDeliveryStatusHistoryDAO.listByServiceDelivery(
      serviceDelivery);

    for (ServiceDeliveryStatusHistory serviceDeliveryStatusHistory : serviceDeliveryStatusHistoryLinks) {
      viewServiceDeliveryStatusHistoryDetails = new ViewServiceDeliveryStatusHistoryDetails();
      User createdByUser = serviceDeliveryStatusHistory.getCreatedBy();

      if (createdByUser != null) {
        viewServiceDeliveryStatusHistoryDetails.dtls.createdBy = createdByUser.getID();
        viewServiceDeliveryStatusHistoryDetails.createdByFullName = createdByUser.getFullName();
      }
      viewServiceDeliveryStatusHistoryDetails.effectiveDate = serviceDeliveryStatusHistory.getEffectiveDate();
      viewServiceDeliveryStatusHistoryDetails.dtls.status = serviceDeliveryStatusHistory.getStatus().getCode();
      viewServiceDeliveryStatusHistoryDetailsList.details.addRef(
        viewServiceDeliveryStatusHistoryDetails);
    }
    return viewServiceDeliveryStatusHistoryDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public NoteHistoryDetails viewNoteHistoryDetails(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    NoteHistoryDetails noteHistoryDetails = new NoteHistoryDetails();
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);
    Note note = serviceDelivery.getNote();

    if (null != note) {
      noteHistoryDetails.noteHistory = note.getNotesText();
    }
    return noteHistoryDetails;
  }

  /**
   * Reads the context panel overview detail for a service delivery.
   *
   * @param key
   * unique identifier of a service delivery to view notes for
   * @return the details to display on the service delivery context panel
   */
  public ContextPanelDetails readContextPanelDetails(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {
    ContextPanelDetails contextPanelDetails = new ContextPanelDetails();
    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    // Security check
    serviceOfferingSecurity.checkViewRights(
      serviceDelivery.getServiceOffering());

    contextPanelDetails.name = serviceDelivery.getName();
    contextPanelDetails.clients = serviceDeliveryFacadeHelperProvider.get().listServiceRecipientNames(
      serviceDelivery);

    List<CaseParticipantRole> serviceClients = serviceDelivery.listCaseParticipantRoles();

    // Create a container content panel
    ContentPanelBuilder containerPanel = ContentPanelBuilder.createPanel(
      curam.cpm.util.impl.ContextPanelConst.kStyleContainerPanelServiceOrReferral);

    ServiceAndReferralContextPanelHelper contextPanelHelper = serviceReferralContextPanelHelperProvider.get();

    if (serviceClients.size() > 1) { // multiple clients
      // Build and add left panel
      StackContainerBuilder stackContainerBuilder = contextPanelHelper.getCaseMemberThumbnailDetails(
        serviceClients);

      containerPanel.addWidgetItem(stackContainerBuilder, CuramConst.gkStyle,
        CuramConst.gkStyleStackContainer);

      // build and add right panel
      // BEGIN, CR00279362, SSK
      // BEGIN, CR00280918, SSK
      ContentPanelBuilder serviceRightPanel = contextPanelHelper.getContextPanelDetails(
        serviceDelivery);

      // END, CR00280918
      // END, CR00279362

      containerPanel.addWidgetItem(serviceRightPanel, CuramConst.gkStyle,
        CuramConst.gkContentPanel,
        curam.cpm.util.impl.ContextPanelConst.kStyleContentPanelDetailServiceOrReferralContentPanelBlueFooter);
    } else { // single client
      // Build and add left panel
      ContentPanelBuilder contentPanelBuilder = contextPanelHelper.getCaseMemberThumbnailDetails(
        serviceClients.get(0));

      // Add the left panel to the container panel
      containerPanel.addWidgetItem(contentPanelBuilder, CuramConst.gkStyle,
        CuramConst.gkContentPanel, CuramConst.gkCaseParticipantPanel);

      // build and add right panel
      // BEGIN, CR00279362, SSK
      // BEGIN, CR00280918, SSK
      ContentPanelBuilder rightPanel = contextPanelHelper.getContextPanelDetails(
        serviceDelivery);

      // END, CR00280918
      // END, CR00279362

      containerPanel.addWidgetItem(rightPanel, CuramConst.gkStyle,
        CuramConst.gkContentPanel,
        curam.cpm.util.impl.ContextPanelConst.kStyleContentPanelDetailServiceOrReferralContentPanelMediumBlueFooter);
    }

    contextPanelDetails.xmlPanelData = containerPanel.toString();

    return contextPanelDetails;
  }

  // BEGIN, CR00282019, GYH
  /**
   * {@inheritDoc}
   */
  public ServiceDeliveryTypeAndNomineeType getServiceDeliveryTypeAndNomineeType(
    final ServiceDeliveryKey serviceDeliveryKey) throws AppException,
      InformationalException {

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      serviceDeliveryKey.serviceDeliveryID);
    ServiceOffering serviceOffering = serviceDelivery.getServiceOffering();

    ServiceDeliveryTypeAndNomineeType serviceDeliveryTypeAndNomineeType = new ServiceDeliveryTypeAndNomineeType();

    serviceDeliveryTypeAndNomineeType.serviceDeliveryType = serviceOffering.getDeliveryType().getCode();
    serviceDeliveryTypeAndNomineeType.nomineeType = serviceOffering.getServiceDeliveryConfiguration().getNomineeType().getCode();

    return serviceDeliveryTypeAndNomineeType;
  }

  // END, CR00282019

  // BEGIN, CR00292625, GYH
  /**
   * {@inheritDoc}
   */
  public ReassessmentResultsList listReassessmentResults(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    ReassessmentResultsList reassessmentResultsList = new ReassessmentResultsList();

    ServiceAuthorization serviceAuthorization = serviceDeliveryDAO.get(key.serviceDeliveryID).getServiceAuthorization();

    if (null != serviceAuthorization) {

      reassessmentResultsList = financialAPI.listReassessmentResults(
        serviceAuthorization);
    }

    return reassessmentResultsList;
  }

  // END, CR00292625

  // BEGIN, CR00297010, KH
  /**
   * {@inheritDoc}
   */
  public ViewCaseFinancialInstructionList listTransactions(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    ViewCaseFinancialInstructionList transactionsList = new ViewCaseFinancialInstructionList();

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    if (null != serviceDelivery) {

      final ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();

      ListCaseFinancialsKey financialsKey = new ListCaseFinancialsKey();

      financialsKey.caseID = serviceDelivery.getDeliveryTypeRelatedID();

      // Get the transactions for the associated PD case
      ViewCaseFinancialInstructionList pdFinancials = productDeliveryObj.listCaseFinancialInstruction(
        financialsKey);

      transactionsList.assign(pdFinancials);

      // Find all related correction cases
      ArrayList<Long> caseIDs = getRelatedCorrectionCases(
        serviceDelivery.getDeliveryTypeRelatedID());

      /*
       * Get the transactions for the associated over payment, under
       * payment and payment correction cases.
       */
      for (Long caseID : caseIDs) {

        financialsKey.caseID = caseID;

        ViewCaseFinancialInstructionList correctionFinancials = productDeliveryObj.listCaseFinancialInstruction(
          financialsKey);

        transactionsList.dtls.dtlsList.addAll(
          correctionFinancials.dtls.dtlsList);

        // If any associated case has unprocessed ILIs display that page
        if (correctionFinancials.unprocessedILIsInd) {
          transactionsList.unprocessedILIsInd = true;
        }
      } // end for
    }

    return transactionsList;
  }

  /**
   * {@inheritDoc}
   */
  public UnprocessedILIDetailsList listUnprocessedILIs(
    final ServiceDeliveryKey key) throws AppException,
      InformationalException {

    UnprocessedILIDetailsList transactionsList = new UnprocessedILIDetailsList();

    curam.servicedelivery.impl.ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);

    if (null != serviceDelivery) {

      final ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();

      SearchUnprocessedByCaseIDKey financialsKey = new SearchUnprocessedByCaseIDKey();

      financialsKey.caseID = serviceDelivery.getDeliveryTypeRelatedID();

      // Get the unprocessed ILIs for the associated PD case
      UnprocessedILIDetailsList pdFinancials = productDeliveryObj.listUnprocessedILIs(
        financialsKey);

      transactionsList.assign(pdFinancials);

      // Find all related correction cases
      ArrayList<Long> caseIDs = getRelatedCorrectionCases(
        serviceDelivery.getDeliveryTypeRelatedID());

      /*
       * Get the unprocessed ILIs for the associated over payment, under
       * payment and payment correction cases.
       */
      for (Long caseID : caseIDs) {

        financialsKey.caseID = caseID;

        UnprocessedILIDetailsList correctionFinancials = productDeliveryObj.listUnprocessedILIs(
          financialsKey);

        transactionsList.dtlsList.addAll(correctionFinancials.dtlsList);

        // If any associated case has unprocessed ILIs set this to true
        if (correctionFinancials.unprocessedILIsInd) {
          transactionsList.unprocessedILIsInd = true;
        }
      } // end for
    }

    return transactionsList;
  }

  /**
   * Finds the case IDs for any related correction cases (payment corrections,
   * over payments and underpayments).
   *
   * @param serviceDeliveryKey
   * Contains the identifier of service delivery.
   *
   * @return List of case IDs for any related correction cases (payment
   * corrections, over payments and underpayments).
   *
   * @throws InformationalException
   * Generic Application Exception
   * @throws AppException
   * Generic Application Exception.
   */
  protected ArrayList<Long> getRelatedCorrectionCases(final Long pdCaseID)
    throws AppException, InformationalException {

    ArrayList<Long> caseIDs = new ArrayList<Long>();

    CaseRelationshipRelatedCaseIDKey key = new CaseRelationshipRelatedCaseIDKey();

    key.relatedCaseID = pdCaseID;

    CaseRelationshipDtlsList relationships = CaseRelationshipFactory.newInstance().searchByRelatedCaseID(
      key);

    for (CaseRelationshipDtls relationship : relationships.dtls) {
      if (relationship.reasonCode.equals(
        CASERELATIONSHIPREASONCODE.PAYMENTCORRECTIONCASE)
          || relationship.reasonCode.equals(
            CASERELATIONSHIPREASONCODE.OVERPAYMENTCASE)
            || relationship.reasonCode.equals(
              CASERELATIONSHIPREASONCODE.UNDERPAYMENTCASE)) {
        caseIDs.add(relationship.caseID);
      }
    }

    return caseIDs;
  }

  // END, CR00297010

  // BEGIN, CR00407985, SG
  /**
   * Checks if the user has maintain rights on the case.
   *
   * @param key
   * ID of the case that is being checked.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * (GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS) if the
   * user does not have any privilege.
   * @throws AppException
   * (GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS) if the user has
   * restricted privilege.
   * @throws AppException
   * (GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS) if the
   * user has read only privilege.
   */
  public void checkMaintainCaseSecurity(final CaseSecurityCheckKey key)
    throws AppException, InformationalException {

    if (0 != key.caseID) {

      final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();

      key.type = DataBasedSecurity.kMaintainSecurityCheck;

      final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
        key);

      if (!dataBasedSecurityResult.result) {
        if (dataBasedSecurityResult.readOnly) {
          ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS),
            ValidationManagerConst.kSetOne, 0);
        } else if (dataBasedSecurityResult.restricted) {
          ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS),
            ValidationManagerConst.kSetOne, 0);
        } else {
          ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS),
            ValidationManagerConst.kSetOne, 0);
        }
      }

    }

  }
  // END, CR00407985

}
