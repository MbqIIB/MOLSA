/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.sl.impl;


import curam.codetable.LOCATIONACCESSTYPE;
import curam.core.fact.AlternateNameFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.LocationBasedSecurityFactory;
import curam.core.fact.PersonFactory;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.AlternateName;
import curam.core.intf.ConcernRole;
import curam.core.intf.Person;
import curam.core.sl.fact.ExternalUserParticipantLinkFactory;
import curam.core.sl.intf.ExternalUserParticipantLink;
import curam.core.sl.struct.ExternalUserParticipantLinkKey;
import curam.core.sl.struct.ParticipantKeyStruct;
import curam.core.struct.AlternateNameKey;
import curam.core.struct.CaseClientSecurityResult;
import curam.core.struct.ClientSecurityKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.PersonKey;
import curam.core.struct.SecurityResult;
import curam.cpm.sl.struct.ReadPersonPageDetails;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Service Layer class used to read / maintain data for an External Person User
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is no longer used. See release note:
 * CR00226000.
 */
@Deprecated
public abstract class CPMExternalLinkedPerson extends curam.cpm.sl.base.CPMExternalLinkedPerson {

  // ___________________________________________________________________________
  /**
   * Method to read the home page details for a person based on the participant
   * role identifier.
   *
   * @param key Contains an External User Participant Link Key entity key
   *
   * @return The person home page details
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam V6.0.
   * This method is deprecated as it is no longer used. See release note:
   * CR00226000.
   */
  @Deprecated
  public ReadPersonPageDetails readHomePage(ExternalUserParticipantLinkKey key)
    throws AppException, InformationalException {

    // Return object
    ReadPersonPageDetails readPersonPageDetails = new ReadPersonPageDetails();

    // Get the participantRoleID and rel type from the external users
    // participant link table
    ExternalUserParticipantLink externalUserParticipantLink = ExternalUserParticipantLinkFactory.newInstance();

    readPersonPageDetails.roleAndRelTypeDetails = externalUserParticipantLink.readParticipantRoleID(
      key);

    // set the participantRoleID
    long participantRoleID = readPersonPageDetails.roleAndRelTypeDetails.participantRoleID;

    // ConcernRole value objects
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Person Entity value objects
    Person personObj = PersonFactory.newInstance();
    PersonKey personKey = new PersonKey();

    // AlternateName Entity value objects
    AlternateName alternateNameObj = AlternateNameFactory.newInstance();
    AlternateNameKey alternateNameKey = new AlternateNameKey();

    // ExternalLinkedParticipant value objects
    // BEGIN, CR00236076, AK
    curam.cpm.sl.intf.CPMExternalLinkedParticipant externalLinkedParticipantObj = curam.cpm.sl.fact.CPMExternalLinkedParticipantFactory.newInstance();
    // END, CR00236076
    curam.cpm.sl.struct.ReadLinkedParticipantDetailsKey readPrimaryParticipantDetailsKey = new curam.cpm.sl.struct.ReadLinkedParticipantDetailsKey();
    curam.cpm.sl.struct.ReadLinkedParticipantDetails readPrimaryParticipantDetails = new curam.cpm.sl.struct.ReadLinkedParticipantDetails();

    // Security value objects
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();

    // Check for security restrictions
    ParticipantKeyStruct participantKey = new ParticipantKeyStruct();

    participantKey.participantID = participantRoleID;

    // Case Client Security Variables
    curam.core.intf.LocationBasedSecurity locationBasedSecurity = LocationBasedSecurityFactory.newInstance();
    CaseClientSecurityResult caseClientSecurityResult = new CaseClientSecurityResult();
    ClientSecurityKey clientSecurityKey = new ClientSecurityKey();

    // Concern Role Variables
    curam.core.intf.ConcernRole concernRole = ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    concernRoleKey = new ConcernRoleKey();

    // Read concern role details
    concernRoleKey.concernRoleID = participantRoleID;
    concernRoleDtls = concernRole.read(concernRoleKey);

    // map values to internal struct
    clientSecurityKey.locationID = concernRoleDtls.prefPublicOfficeID;
    clientSecurityKey.type = LOCATIONACCESSTYPE.READ;

    // check if the user is allowed to access this data
    caseClientSecurityResult = locationBasedSecurity.checkClientSecurity(
      clientSecurityKey);

    if (!caseClientSecurityResult.result) {

      if (caseClientSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }

    SecurityResult securityResult = dataBasedSecurity.checkParticipantSecurity(
      participantKey);

    if (!securityResult.result) {
      throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
    }

    // // Read the ConcernRole Details
    concernRoleKey.concernRoleID = participantRoleID;
    readPersonPageDetails.concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Read the person details
    personKey.concernRoleID = participantRoleID;
    readPersonPageDetails.personDtls = personObj.read(personKey);

    // Assign the key value for the alternateName read
    alternateNameKey.alternateNameID = readPersonPageDetails.personDtls.primaryAlternateNameID;
    readPersonPageDetails.alternateNameDtls = alternateNameObj.read(
      alternateNameKey);

    // Assign the key value for the PrimaryParticipantDetails read
    readPrimaryParticipantDetailsKey.participantRoleID = participantRoleID;
    readPrimaryParticipantDetailsKey.primaryAddressID = readPersonPageDetails.concernRoleDtls.primaryAddressID;
    readPrimaryParticipantDetailsKey.primaryPhoneNumberID = readPersonPageDetails.concernRoleDtls.primaryPhoneNumberID;
    readPrimaryParticipantDetailsKey.primaryBankAccountID = readPersonPageDetails.concernRoleDtls.primaryBankAccountID;
    readPrimaryParticipantDetailsKey.prefPublicOfficeID = readPersonPageDetails.concernRoleDtls.prefPublicOfficeID;
    readPrimaryParticipantDetailsKey.primaryEmailAddressID = readPersonPageDetails.concernRoleDtls.primaryEmailAddressID;

    // Read the AlternateName details
    readPrimaryParticipantDetails = externalLinkedParticipantObj.readParticipantDetails(
      readPrimaryParticipantDetailsKey);

    // Assign the AlternateNameDtls to the return object
    readPersonPageDetails.participantDtls.assign(readPrimaryParticipantDetails);

    // Assign codetable attributes their underlying code descriptions
    readPersonPageDetails.gender = readPersonPageDetails.personDtls.gender;
    readPersonPageDetails.title = readPersonPageDetails.alternateNameDtls.title;
    readPersonPageDetails.nameSuffix = readPersonPageDetails.alternateNameDtls.nameSuffix;

    return readPersonPageDetails;
  }

}
