/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.TRAININGPROGRAMPARTYSTATUSEntry;
import curam.core.impl.CuramConst;
import curam.cpm.facade.struct.ConcernRoleMemberDetails;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.TrainingAndConcernRolekey;
import curam.cpm.facade.struct.TrainingMemberStatusHistoryDetailsList;
import curam.cpm.facade.struct.TrainingPartyCreateDetails;
import curam.cpm.facade.struct.TrainingPartyCreateDetailsList;
import curam.cpm.facade.struct.TrainingPartyDetails;
import curam.cpm.facade.struct.TrainingProgram;
import curam.cpm.facade.struct.TrainingProgramAndConcernRoleKey;
import curam.cpm.facade.struct.TrainingProgramAndPartyCompletedDetails;
import curam.cpm.facade.struct.TrainingProgramAndPartyDetails;
import curam.cpm.facade.struct.TrainingProgramCompleteDetails;
import curam.cpm.facade.struct.TrainingProgramCompletedDetails;
import curam.cpm.facade.struct.TrainingProgramConcernRoleVersionKey;
import curam.cpm.facade.struct.TrainingProgramList;
import curam.cpm.facade.struct.TrainingProgramMemberAddDetails;
import curam.cpm.facade.struct.TrainingProgramMemberUpdateDetails;
import curam.cpm.facade.struct.TrainingProgramPartyCompletedDetails;
import curam.cpm.facade.struct.TrainingProgramPartyDetails;
import curam.cpm.facade.struct.TrainingProgramPartyDetailsList;
import curam.cpm.facade.struct.TrainingProgramPartyWaiverDetails;
import curam.cpm.facade.struct.TrainingProgramSummaryDetails;
import curam.cpm.facade.struct.TrainingProgramSummaryDetailsList;
import curam.cpm.facade.struct.TrainingProgramUpdateDetails;
import curam.cpm.facade.struct.TrainingProviderDetails;
import curam.cpm.facade.struct.TrainingRequirementSummaryDetails;
import curam.cpm.facade.struct.TrainingStatusHistoryDetails;
import curam.cpm.facade.struct.TrainingSummaryDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderPartyKey;
import curam.cpm.sl.entity.struct.TrainingKey;
import curam.cpm.sl.entity.struct.TrainingProgramKey;
import curam.cpm.sl.entity.struct.TrainingProgramMemberKey;
import curam.cpm.sl.entity.struct.TrainingServiceOfferingDtls;
import curam.cpm.util.impl.WidgetHelper;
import curam.message.TRAININGPROGRAM;
import curam.message.impl.TRAININGPROGRAMExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.LicenseTrainingRequirement;
import curam.provider.impl.LicenseTrainingRequirementDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderGroupDAO;
import curam.provider.impl.ProviderGroupStatusEntry;
import curam.provider.impl.ProviderMember;
import curam.provider.impl.ProviderMemberDAO;
import curam.provider.impl.ProviderMemberRoleEntry;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.provider.impl.ProviderSecurity;
import curam.provider.impl.TrainingCompletionEntry;
import curam.serviceoffering.impl.SOTrainingRequirement;
import curam.serviceoffering.impl.SOTrainingRequirementDAO;
import curam.serviceoffering.impl.TrainingServiceOfferingDAO;
import curam.training.impl.ProviderGroupMemberTrainingProgram;
import curam.training.impl.Training;
import curam.training.impl.TrainingCredit;
import curam.training.impl.TrainingCreditDAO;
import curam.training.impl.TrainingDAO;
import curam.training.impl.TrainingProgramDAO;
import curam.training.impl.TrainingProgramMember;
import curam.training.impl.TrainingProgramMemberDAO;
import curam.training.impl.TrainingStatusHistory;
import curam.training.impl.TrainingStatusHistoryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.StringHelper;
import curam.util.type.StringList;


/**
 * Facade layer class having API for managing Provider group training program.
 *
 */
public abstract class MaintainProviderGroupTrainingProgram extends curam.cpm.facade.base.MaintainProviderGroupTrainingProgram {

  /**
   * Training Program DAO object.
   */
  @Inject
  protected TrainingProgramDAO trainingProgramDAO;

  /**
   * Training Program MemberDAO object.
   */
  @Inject
  protected TrainingProgramMemberDAO trainingProgramMemberDAO;

  /**
   * providerSecurity type of ProviderSecurity
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * Reference to Provider DAO
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to ProviderGroup DAO
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /**
   * Reference to Provider Member DAO
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  /**
   * Reference to Training DAO
   */
  @Inject
  protected TrainingDAO trainingDAO;

  /**
   * Reference to Training Status History DAO
   */
  @Inject
  protected TrainingStatusHistoryDAO trainingStatusHistoryDAO;

  /**
   * Reference to Provider Organization DAO
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Reference to Concern Role DAO
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Reference to Training Service Offering DAO
   */
  @Inject
  protected TrainingServiceOfferingDAO trainingServiceOfferingDAO;

  /**
   * Reference to Service Offering Training Requirement DAO
   */
  @Inject
  protected SOTrainingRequirementDAO soTrainingRequirementDAO;

  /**
   * Reference to License Training Requirement DAO
   */
  @Inject
  protected LicenseTrainingRequirementDAO licenseTrainingRequirementDAO;

  /**
   * Reference to Approve Provider Group Member Training Program Strategy
   */
  @Inject
  protected ProviderGroupMemberTrainingProgram providerGroupMemberTrainingProgram;

  /**
   * Reference to Training Credit DAO.
   */
  @Inject
  protected TrainingCreditDAO trainingCreditDAO;

  /**
   * Default constructor
   */
  public MaintainProviderGroupTrainingProgram() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Adds a new provider group member to a training program.
   *
   * @param details
   * New training program member details.
   * @return Training program key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramKey addProviderGroupMemberToTrainingProgram(
    TrainingProgramMemberAddDetails details) throws AppException,
      InformationalException {

    TrainingProgramKey trainingProgramKey = new TrainingProgramKey();

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProgramID);

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.providerOrganizationID);

    // Check for provider group security and check if provider group is closed
    trainingProgram.validateProviderOrganization(providerOrganization);

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();
    ConcernRole concernRole = concernRoleDAO.get(details.partyConcernRoleID);

    trainingProgramMember.setPartyConcernRole(concernRole);
    trainingProgramMember.setCompletion(
      TrainingCompletionEntry.get(details.completion));
    trainingProgramMember.setTrainingProgram(trainingProgram);
    trainingProgramMember.setUnitsRequired(details.unitsRequired);
    // BEGIN, CR00113582, AK
    trainingProgramMember.setMemberType(CPMConstants.kProviderGroupMember);
    // END, CR00113582

    // Create training program member record.
    trainingProgramMember.insert();

    return trainingProgramKey;
  }

  /**
   * Creates training program for a Provider Group. Training Program Member
   * details are inserted for each Provider Group Member under the Provider
   * Group.
   *
   * @param trainingProgram
   * Contains training details, training provider and party details.
   * @return Training program key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_PROVIDER_IS_CLOSED_TRAINING_CANNOT_BE_CREATED_FOR_PROVIDER_MEMBER} -
   * if the provider is closed.
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_ATLEAST_ONE_PROVIDERGROUPMEMBER_MUST_BE_SELECTED_FOR_TRAINING_PROGRAM} -
   * if there are no provider group members selected for the training.
   */
  public TrainingProgramKey createTrainingProgramForProviderGroup(
    TrainingProgram trainingProgram) throws AppException,
      InformationalException {

    TrainingProgramKey trainingProgramKey = new TrainingProgramKey();

    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      trainingProgram.concernRoleID);

    // check appropriate security privileges
    providerSecurity.checkProviderGroupSecurity(providerGroup);

    // Validate if the Provider is closed.
    if ((providerGroup.getLifecycleState().equals(
      ProviderGroupStatusEntry.CLOSED))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_PROVIDER_IS_CLOSED_TRAINING_CANNOT_BE_CREATED_FOR_PROVIDER_MEMBER(
          providerGroup.getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Convert the xml to Training Program Party List
    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList = WidgetHelper.convertXmlToConcernMemberTrainingProgram(
      trainingProgram);

    // Validate that at least one member is selected for the training program.
    if (trainingProgramPartyDetailsList.partyDetails.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_ATLEAST_ONE_PROVIDERGROUPMEMBER_MUST_BE_SELECTED_FOR_TRAINING_PROGRAM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    ConcernRoleMemberDetails concernRoleMemberDetails = new ConcernRoleMemberDetails();

    concernRoleMemberDetails.memberTrainingWidget = trainingProgram.trainingDetails;

    TrainingPartyCreateDetailsList trainingPartyCreateDetailsList = WidgetHelper.convertXmlToMemberTrainingProgram(
      concernRoleMemberDetails);

    // BEGIN CR00113213, MST
    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      trainingProgram.concernRoleID);

    // Validate the provider group members selected for the training program
    validateMembers(trainingPartyCreateDetailsList,
      sortPartyDetailsList(trainingProgramPartyDetailsList),
      providerOrganization);

    for (TrainingPartyCreateDetails trainingPartyCreateDetails : trainingPartyCreateDetailsList.detailsList.items()) {

      curam.training.impl.TrainingProgram trainingProgramImpl = setTrainingProgram(
        trainingPartyCreateDetails, trainingProgram.providerID,
        trainingProgram.concernRoleID);

      // END CR00113213

      // Security check for Provider Group.
      trainingProgramImpl.validateProviderOrganization(providerOrganization);

      // Create training program record.
      trainingProgramImpl.insert();

      trainingProgramKey.trainingProgramID = trainingProgramImpl.getID();

      for (TrainingProgramPartyDetails trainingProgramPartyDetails : trainingProgramPartyDetailsList.partyDetails.items()) {

        TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();
        ConcernRole concernRole = concernRoleDAO.get(
          trainingProgramPartyDetails.partyConcernRoleID);

        trainingProgramMember.setPartyConcernRole(concernRole);
        trainingProgramMember.setCompletion(
          TrainingCompletionEntry.get(trainingProgramPartyDetails.completion));
        trainingProgramMember.setTrainingProgram(trainingProgramImpl);
        trainingProgramMember.setUnitsRequired(
          trainingProgramPartyDetails.unitsRequired);
        trainingProgramMember.setMemberType(CPMConstants.kProviderGroup);

        // Create training program member record.
        trainingProgramMember.insert();
      }
    }

    return trainingProgramKey;
  }

  /**
   * Creates training program for a provider group member.
   *
   * @param details
   * Contains training program details and training provider.
   * @return Training program member key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramMemberKey createTrainingProgramForProviderGroupMember(
    TrainingPartyCreateDetails details) throws AppException,
      InformationalException {

    TrainingProgramMemberKey trainingProgramMemberKey = new TrainingProgramMemberKey();

    curam.training.impl.TrainingProgram trainingProgram = setTrainingProgram(
      details);

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.providerOrganizationID);

    // Check for provider/provider group security and check if provider/provider
    // group is closed
    trainingProgram.validateProviderOrganization(providerOrganization);

    // Create training program record.
    trainingProgram.insert();

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();
    ConcernRole concernRole = concernRoleDAO.get(details.concernRoleID);

    trainingProgramMember.setPartyConcernRole(concernRole);
    trainingProgramMember.setCompletion(
      TrainingCompletionEntry.get(details.completion));
    trainingProgramMember.setTrainingProgram(trainingProgram);
    trainingProgramMember.setUnitsRequired(details.unitsRequired);
    trainingProgramMember.setMemberType(CPMConstants.kProviderGroupMember);

    // Create training program member record.
    trainingProgramMember.insert();

    // set the training program member id in the return struct
    trainingProgramMemberKey.trainingProgramMemberID = trainingProgramMember.getID();

    return trainingProgramMemberKey;
  }

  /**
   * Deletes the specified Provider Group Member Training Program.
   *
   * @param trainingProgramConcernRoleVersionKey
   * Contains Training Program Member ID, Provider Concern Role ID,
   * version number
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_TRAININGPROGRAM_IS_NOT_ACTIVE_CANNOT_BE_CANCELED} -
   * If training program for provider group member is already deleted.
   */
  public void deleteProviderGroupMemberTrainingProgram(
    TrainingProgramConcernRoleVersionKey trainingProgramConcernRoleVersionKey)
    throws AppException, InformationalException {

    boolean hasActiveMembers = false;

    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      trainingProgramConcernRoleVersionKey.trainingProgramMemberID);

    // check appropriate security privileges
    curam.provider.impl.Provider provider = providerDAO.get(
      trainingProgramConcernRoleVersionKey.concernRoleID);

    providerSecurity.checkProviderSecurity(provider);

    if (trainingProgramMember.getLifecycleState().equals(
      TRAININGPROGRAMPARTYSTATUSEntry.CANCELED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_TRAININGPROGRAM_IS_NOT_ACTIVE_CANNOT_BE_CANCELED(
          trainingProgramMember.getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Cancel the Training Program Member.
    trainingProgramMember.cancel(
      trainingProgramConcernRoleVersionKey.trainingProgramMemberVersionNo);

    // now retrieve all the training program members and check if all are
    // canceled.
    // if yes, cancel the training program also
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramMember.getTrainingProgram();

    Set<TrainingProgramMember> trainingProgramMemberList = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
      trainingProgram.getID());

    for (TrainingProgramMember trainingProgMember : trainingProgramMemberList) {
      // if one of the members is not in canceled state
      // set the boolean flag
      if (!trainingProgMember.getLifecycleState().equals(
        TRAININGPROGRAMPARTYSTATUSEntry.CANCELED)) {
        hasActiveMembers = true;
      }
    }

    if (!hasActiveMembers) {
      trainingProgram.cancel(
        trainingProgramConcernRoleVersionKey.trainingProgramVersionNo);
    }

  }

  /**
   * Deletes the specified Provider Group Training Program.
   *
   * @param trainingProgramAndConcernRoleKey
   * Contains Training Program ID, Provider Concern Role ID,version
   * number
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_TRAININGPROGRAM_IS_NOT_ACTIVE_CANNOT_BE_CANCELED} -
   * If training program for provider group is already deleted.
   */
  public void deleteProviderGroupTrainingProgram(
    TrainingProgramAndConcernRoleKey trainingProgramAndConcernRoleKey)
    throws AppException, InformationalException {

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      trainingProgramAndConcernRoleKey.trainingProgramID);

    // check appropriate security privileges
    curam.provider.impl.Provider provider = providerDAO.get(
      trainingProgramAndConcernRoleKey.concernRoleID);

    providerSecurity.checkProviderSecurity(provider);

    if (trainingProgram.getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_TRAININGPROGRAM_IS_NOT_ACTIVE_CANNOT_BE_CANCELED(
          trainingProgram.getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    // Fetch all the Member Training Programs for the Training program
    Set<curam.training.impl.TrainingProgramMember> trainingProgramMembers = trainingProgramMemberDAO.getTrainingProgramMembersForConcernRole(
      trainingProgramAndConcernRoleKey.trainingProgramID,
      trainingProgram.getTrainingProgramOwner().getID());

    // Cancel all the member training programs for the training program
    for (final curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMembers) {
      trainingProgramMember.cancel(trainingProgramMember.getVersionNo());
    }

    // Cancel the Training Program
    trainingProgram.cancel(trainingProgram.getVersionNo());

  }

  /**
   * Lists the member based on concern role id.
   *
   * @param key
   * Contains the concern role id.
   * @return ConcernRoleMemberDetails Contains the member details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ConcernRoleMemberDetails listProviderGroupMembers(ConcernRoleKey key)
    throws AppException, InformationalException {
    ConcernRoleMemberDetails concernRoleMemberDetails = new ConcernRoleMemberDetails();

    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      key.concernRoleID);

    Set<curam.provider.impl.ProviderMember> providerGroupMembers = providerGroup.getProviderMembers();

    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList = new TrainingProgramPartyDetailsList();

    // get the all active provider members
    for (curam.provider.impl.ProviderMember providerGroupMember : providerGroupMembers) {

      if (providerGroupMember.getLifecycleState().getCode().equals(
        RECORDSTATUSEntry.NORMAL.getCode())) {
        TrainingProgramPartyDetails trainingProgramPartyDetails = new TrainingProgramPartyDetails();

        trainingProgramPartyDetails.partyConcernRoleID = providerGroupMember.getParty().getID();
        trainingProgramPartyDetails.partyName = providerGroupMember.getParty().getName();
        trainingProgramPartyDetails.role = ProviderMemberRoleEntry.get(providerGroupMember.getRole().getCode()).toUserLocaleString();
        trainingProgramPartyDetailsList.partyDetails.addRef(
          trainingProgramPartyDetails);
      }
    }

    if (trainingProgramPartyDetailsList.partyDetails.size() > 0) {
      String strMemberDetails = WidgetHelper.convertRecordCompletedTrainingToXml(
        sortPartyDetailsList(trainingProgramPartyDetailsList));

      concernRoleMemberDetails.memberTrainingWidget = strMemberDetails;
    }
    concernRoleMemberDetails.providerOrganizationID = key.concernRoleID;

    return concernRoleMemberDetails;
  }

  /**
   * Marks the provider member training program to complete.
   *
   * @param details
   * Contains the training program complete details.
   * TrainingProgramMemberKey Returns the training program member key.
   * @return TrainingProgramMemberKey returns the training program member key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramMemberKey markProviderGroupMemberTrainingProgramComplete(
    TrainingProgramCompleteDetails details) throws AppException,
      InformationalException {

    TrainingProgramMemberKey trainingProgramMemberKey = new TrainingProgramMemberKey();

    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    // set the training member data
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setCreditsAchieved(details.creditsAchieved);
    trainingProgramMember.setUnitsCompleted(details.unitsCompleted);
    // call the interface method to mark
    trainingProgramMember.markTrainingMemberProgramComplete(
      details.partyVersionNo);

    return trainingProgramMemberKey;
  }

  /**
   * Records a training program for a provider group member that was completed
   * outside the agency.
   *
   * @param details
   * Contains the training program completed details for recording.
   * @return TrainingProgramMemberKey Contains the training program member key
   * which is recorded.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramMemberKey recordCompletedProviderGroupMemberTrainingProgram(
    TrainingProgramCompletedDetails details) throws AppException,
      InformationalException {

    // training program instance
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.newInstance();
    // training program member instance
    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();

    // Provider Organization instance
    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.providerOrganizationID);

    // set the provider program details
    setRecordCompletedProviderGroupProgramDetails(details, trainingProgram);
    trainingProgram.recordCompletedTrainingProgram(providerOrganization);

    details.trainingProviderDetails.trainingProgramID = trainingProgram.getID();
    // set the provider program member details
    setRecordCompletedProviderGroupProgramMemberDetails(details,
      trainingProgramMember);
    trainingProgramMember.recordCompletedTrainingMemberProgram();

    TrainingProgramMemberKey trainingProgramMemberKey = new TrainingProgramMemberKey();

    trainingProgramMemberKey.trainingProgramMemberID = trainingProgramMember.getID();
    return trainingProgramMemberKey;
  }

  /**
   * Records a training program for a provider group that was completed outside
   * the agency.
   *
   * @param details
   * Contains the training program completed details for recording.
   * @return TrainingProgramKey Contains the training program key which is
   * recorded.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramKey recordCompletedTrainingProgramForProviderGroup(
    TrainingProgramAndPartyCompletedDetails details) throws AppException,
      InformationalException {

    TrainingProgramKey trainingProgramKey = new TrainingProgramKey();

    // training program instance
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.newInstance();

    // Provider Organization instance
    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.providerOrganizationID);

    // set the provider group program details
    setRecordCompletedTrainingProgramDetails(details, trainingProgram);
    trainingProgram.recordCompletedTrainingProgram(providerOrganization);

    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList = WidgetHelper.convertXmlToRecordCompletedTraining(
      details.trainingDetails);

    // Validate that at least one member is selected for the training
    // program.
    if (trainingProgramPartyDetailsList.partyDetails.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_ATLEAST_ONE_PROVIDERMEMBER_MUST_BE_SELECTED_FOR_TRAINING_PROGRAM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }
    ValidationHelper.failIfErrorsExist();

    if (trainingProgramPartyDetailsList.partyDetails.size() > 0) {
      validateRecordCompleted(
        sortPartyDetailsList(trainingProgramPartyDetailsList));

      for (TrainingProgramPartyDetails trainingProgramPartyDetails : trainingProgramPartyDetailsList.partyDetails.items()) {
        // training program group member instance
        curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();

        setRecordCompletedProgramMemberDetails(trainingProgramPartyDetails,
          trainingProgramMember, trainingProgram);
        trainingProgramMember.recordCompletedTrainingMemberProgram();
      }
    }
    trainingProgramKey.trainingProgramID = trainingProgram.getID();
    return trainingProgramKey;
  }

  /**
   * Retrieves the training program details for provider group member.
   *
   * @param key
   * Training key.
   * @return Training program party details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingPartyCreateDetails retrieveProviderGroupMemberTrainingProgram(
    TrainingKey key) throws AppException, InformationalException {

    TrainingPartyCreateDetails trainingPartyCreateDetails = new TrainingPartyCreateDetails();

    Training training = trainingDAO.get(key.trainingID);

    trainingPartyCreateDetails.trainingID = training.getID();
    trainingPartyCreateDetails.trainingName = training.getName();
    trainingPartyCreateDetails.authorizedFrom = Date.getCurrentDate();

    TrainingKey trainingKey = new TrainingKey();

    trainingKey.trainingID = key.trainingID;

    TrainingServiceOfferingDtls trainingServiceOfferingDtls = trainingServiceOfferingDAO.readByTraining(
      trainingKey);

    if (trainingServiceOfferingDtls != null
      && trainingServiceOfferingDtls.trainingServiceOfferingID != 0) {
      trainingPartyCreateDetails.unitsRequired = trainingServiceOfferingDtls.unitsRequired;
    }

    return trainingPartyCreateDetails;
  }

  /**
   * Retrieves the training programs for the provider group members under a
   * Provider Group.
   *
   * @param trainingAndConcernRolekey
   * Contains service offering trainings and concern role ID of
   * Provider.
   * @return Training program party widget details in xml format.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgram retrieveProviderGroupTrainingProgram(
    TrainingAndConcernRolekey trainingAndConcernRolekey) throws AppException,
      InformationalException {
    TrainingProgram trainingProgram = new TrainingProgram();

    // Create StringList from training IDs List
    StringList trainingIDList = StringUtil.delimitedText2StringList(
      trainingAndConcernRolekey.training, '\t');

    ArrayList<TrainingServiceOfferingDtls> unitsRequiredList = new ArrayList<TrainingServiceOfferingDtls>();

    for (String trainingIDString : trainingIDList.items()) {

      StringList completionList = StringUtil.delimitedText2StringList(
        trainingIDString, '|');

      TrainingKey trainingKey = new TrainingKey();

      trainingKey.trainingID = Long.parseLong(completionList.item(0));

      TrainingServiceOfferingDtls trainingServiceOfferingDtls = trainingServiceOfferingDAO.readByTraining(
        trainingKey);

      unitsRequiredList.add(trainingServiceOfferingDtls);
    }

    int unitsRequiredCounter = 0;
    int unitsRequired = 0;

    Iterator<TrainingServiceOfferingDtls> unitsRequiredItr = unitsRequiredList.iterator();

    while (unitsRequiredItr.hasNext()) {
      if (unitsRequiredCounter == 0) {
        unitsRequired = unitsRequiredItr.next().unitsRequired;
        unitsRequiredCounter++;
      } else {
        if (unitsRequiredItr.next().unitsRequired == unitsRequired) {
          unitsRequiredCounter++;
        }
      }
    }

    TrainingPartyCreateDetailsList trainingPartyCreateDetailsList = new TrainingPartyCreateDetailsList();

    // Populate the training details into a list
    for (String trainingIDString : trainingIDList.items()) {

      TrainingPartyCreateDetails trainingPartyCreateDetails = new TrainingPartyCreateDetails();

      StringList completionList = StringUtil.delimitedText2StringList(
        trainingIDString, '|');

      curam.training.impl.Training training = null;

      // If the size of the completion list is 1 then only element is training
      // ID,
      // if it is more than 1 then first element is training id and second
      // element
      // is completion value.
      if (completionList.size() > 1) {
        training = trainingDAO.get(Long.valueOf(completionList.item(0)));
        trainingPartyCreateDetails.completion = completionList.item(1);
      } else {
        training = trainingDAO.get(Long.valueOf(completionList.item(0)));
      }

      trainingPartyCreateDetails.trainingID = training.getID();
      trainingPartyCreateDetails.trainingName = training.getName();
      trainingPartyCreateDetails.authorizedFrom = Date.getCurrentDate();

      trainingPartyCreateDetailsList.detailsList.addRef(
        trainingPartyCreateDetails);
    }

    // Convert the training details to an xml.
    String strTrainingDetails = WidgetHelper.convertMemberTrainingProgramToXml(
      trainingPartyCreateDetailsList);

    trainingProgram.trainingDetails = strTrainingDetails;

    // Populate the Active Provider Group members under a provider group
    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      trainingAndConcernRolekey.concernRoleID);

    Set<ProviderMember> providerGroupMembers = providerGroup.getProviderMembers();

    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList = new TrainingProgramPartyDetailsList();

    for (ProviderMember providerGroupMember : providerGroupMembers) {

      if (providerGroupMember.getLifecycleState().getCode().equals(
        RECORDSTATUSEntry.NORMAL.getCode())) {
        TrainingProgramPartyDetails trainingProgramPartyDetails = new TrainingProgramPartyDetails();

        trainingProgramPartyDetails.partyConcernRoleID = providerGroupMember.getParty().getID();
        trainingProgramPartyDetails.partyName = providerGroupMember.getParty().getName();
        trainingProgramPartyDetails.role = ProviderMemberRoleEntry.get(providerGroupMember.getRole().getCode()).toUserLocaleString();

        if (unitsRequiredList.size() == unitsRequiredCounter) {
          trainingProgramPartyDetails.unitsRequired = unitsRequired;
        }

        trainingProgramPartyDetailsList.partyDetails.addRef(
          trainingProgramPartyDetails);
      }
    }

    // Convert the active provider group members list to an xml.
    String strMemberDetails = WidgetHelper.convertConcernMemberTrainingProgramToXml(
      sortPartyDetailsList(trainingProgramPartyDetailsList));

    trainingProgram.memberDetails = strMemberDetails;

    return trainingProgram;
  }

  /**
   * Updates the completed training program for provider group member.
   *
   * @param details
   * Training program details to be updated.
   * @return Training program member key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramMemberKey updateCompletedProviderGroupMemberTrainingProgram(
    TrainingProgramCompleteDetails details) throws AppException,
      InformationalException {

    // Check appropriate security privileges
    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      details.providerOrganizationID);

    providerSecurity.checkProviderGroupSecurity(providerGroup);

    // Update the training program member
    TrainingProgramMemberKey trainingProgramMemberKey = new TrainingProgramMemberKey();

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    trainingProgramMember.setCreditsAchieved(details.creditsAchieved);
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setUnitsCompleted(details.unitsCompleted);

    trainingProgramMember.modify(details.partyVersionNo);

    trainingProgramMemberKey.trainingProgramMemberID = details.trainingProgramMemberID;

    return trainingProgramMemberKey;
  }

  /**
   * Updates the completed training program details for a provider group.
   *
   * @param details
   * Training program details to be updated.
   * @return Training program key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramKey updateCompletedProviderGroupTrainingProgram(
    TrainingProviderDetails details) throws AppException,
      InformationalException {

    TrainingProgramKey trainingProgramKey = new TrainingProgramKey();

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProgramID);

    // Check appropriate security privileges
    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      details.concernRoleID);

    providerSecurity.checkProviderGroupSecurity(providerGroup);

    if (details.trainingID == 0) {
      trainingProgram.setTraining(null);
    } else {
      Training training = trainingDAO.get(details.trainingID);

      trainingProgram.setTraining(training);
    }
    trainingProgram.setTrainingName(details.trainingName);

    if (details.trainingProviderID == 0) {
      trainingProgram.setTrainingProvider(null);
    } else {
      Provider trainingProvider = providerDAO.get(details.trainingProviderID);

      trainingProgram.setTrainingProvider(trainingProvider);
    }
    trainingProgram.setTrainingProviderDetails(details.trainingProviderDetails);

    trainingProgram.updateCompletedTrainingProgram(details.versionNo);

    return trainingProgramKey;
  }

  /**
   * Updates Provider Group Training program.
   *
   * @param trainingProgramUpdateDetails
   * Contains Training Program details for update.
   * @return TrainingProgramKey Contains Training Program ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramKey updateProviderGroupTrainingProgram(
    TrainingProgramUpdateDetails trainingProgramUpdateDetails)
    throws AppException, InformationalException {

    // Return key struct.
    TrainingProgramKey trainingProgramKey = new TrainingProgramKey();

    // Get the instance of the Training Program to be modified.
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      trainingProgramUpdateDetails.trainingProgramID);

    // Check appropriate security privileges.
    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      trainingProgram.getTrainingProgramOwner().getID());

    providerSecurity.checkProviderGroupSecurity(providerGroup);

    // Set the updated details for Training Program.
    trainingProgram.setDateRange(
      new DateRange(trainingProgramUpdateDetails.authorizedFrom,
      trainingProgramUpdateDetails.toBeCompletedBy));
    trainingProgram.setUnitAmount(trainingProgramUpdateDetails.unitAmount);

    // Modify the Training Program.
    trainingProgram.modify(trainingProgramUpdateDetails.versionNo);

    // Assign value to the return key.
    trainingProgramKey.trainingProgramID = trainingProgram.getID();
    return trainingProgramKey;
  }

  /**
   * Reads the Training Program details for update.
   *
   * @param trainingProgramKey
   * Contains Training Program ID.
   * @return TrainingProgramUpdateDetails Contains Training Program details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramUpdateDetails readTrainingProgramForUpdate(
    TrainingProgramKey trainingProgramKey) throws AppException,
      InformationalException {

    // Return struct.
    TrainingProgramUpdateDetails trainingProgramUpdateDetails = new TrainingProgramUpdateDetails();

    // Get the instance of the Training Program.
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      trainingProgramKey.trainingProgramID);

    // Assign the details to return struct.
    trainingProgramUpdateDetails.trainingProgramID = trainingProgram.getID();
    if (trainingProgram.getTraining() == null) {
      trainingProgramUpdateDetails.trainingName = trainingProgram.getTrainingName();
    } else {
      trainingProgramUpdateDetails.trainingName = trainingProgram.getTraining().getName();
    }
    trainingProgramUpdateDetails.unitAmount = trainingProgram.getUnitAmount();
    trainingProgramUpdateDetails.authorizedFrom = trainingProgram.getDateRange().start();
    trainingProgramUpdateDetails.toBeCompletedBy = trainingProgram.getDateRange().end();
    trainingProgramUpdateDetails.versionNo = trainingProgram.getVersionNo();

    return trainingProgramUpdateDetails;
  }

  /**
   * Retrieves the training details for a provider group member.
   *
   * @param key
   * Training program member key.
   * @return Training details for a provider group member.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingPartyDetails viewCompletedProviderGroupMemberTrainingProgram(
    TrainingProgramMemberKey key) throws AppException, InformationalException {

    TrainingPartyDetails trainingPartyDetails = new TrainingPartyDetails();

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      key.trainingProgramMemberID);

    // Get the name of the program member based on his concern role id.
    Long concernRoleID = new Long(
      trainingProgramMember.getPartyConcernRole().getID());
    ConcernRole concernRole = concernRoleDAO.get(concernRoleID);

    trainingPartyDetails.partyName = concernRole.getName();
    trainingPartyDetails.status = trainingProgramMember.getLifecycleState().getCode();
    trainingPartyDetails.dateCompleted = trainingProgramMember.getDateCompleted();
    trainingPartyDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
    trainingPartyDetails.trainingProgramMemberID = trainingProgramMember.getID();
    trainingPartyDetails.partyVersionNo = trainingProgramMember.getVersionNo();
    trainingPartyDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
    trainingPartyDetails.trainingProgramID = trainingProgramMember.getTrainingProgram().getID();
    trainingPartyDetails.partyConcernRoleID = trainingProgramMember.getPartyConcernRole().getID();
    trainingPartyDetails.trainingProgramDetails.versionNo = trainingProgramMember.getTrainingProgram().getVersionNo();

    return trainingPartyDetails;
  }

  /**
   * Retrieves training program details not managed through agency for a
   * provider group.
   *
   * @param key
   * Training program key.
   * @return Training program details for a provider group.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramAndPartyDetails viewCompletedTrainingNotManagedByAgency(
    TrainingProgramKey key) throws AppException, InformationalException {

    TrainingProgramAndPartyDetails trainingProgramAndPartyDetails = new TrainingProgramAndPartyDetails();

    // Get the training program for the given training program id.
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      key.trainingProgramID);

    trainingProgramAndPartyDetails.trainingProgramDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();
    if (trainingProgram.getTraining() == null) {
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingName = trainingProgram.getTrainingName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingNameDisplayString = trainingProgram.getTrainingName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingRegisteredInd = false;
    } else {
      trainingProgramAndPartyDetails.trainingProgramDetails.registeredTrainingName = trainingProgram.getTraining().getName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingNameDisplayString = trainingProgram.getTraining().getName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingID = trainingProgram.getTraining().getID();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingRegisteredInd = true;
    }
    trainingProgramAndPartyDetails.trainingProgramDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();
    trainingProgramAndPartyDetails.trainingProgramDetails.versionNo = trainingProgram.getVersionNo();

    if (trainingProgram.getTrainingProvider() != null) {
      trainingProgramAndPartyDetails.trainingProgramDetails.registeredTrainingProviderName = trainingProgram.getTrainingProvider().getName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingProviderID = trainingProgram.getTrainingProvider().getID();
    } else {
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
    }

    Set<curam.training.impl.TrainingProgramMember> trainingProgramMembers = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
      key.trainingProgramID);

    // Set the provider member training program details.
    for (curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMembers) {

      TrainingProgramPartyDetails trainingProgramPartyDetails = new TrainingProgramPartyDetails();

      trainingProgramPartyDetails.status = trainingProgramMember.getLifecycleState().getCode();
      trainingProgramPartyDetails.trainingProgramMemberID = trainingProgramMember.getID();
      trainingProgramPartyDetails.versionNo = trainingProgramMember.getVersionNo();
      trainingProgramPartyDetails.partyConcernRoleID = trainingProgramMember.getPartyConcernRole().getID();

      // Get the name of the program member based on his concern role id.
      Long concernRoleID = new Long(
        trainingProgramMember.getPartyConcernRole().getID());
      ConcernRole concernRole = concernRoleDAO.get(concernRoleID);

      trainingProgramPartyDetails.partyName = concernRole.getName();

      trainingProgramAndPartyDetails.partyDetailsList.partyDetails.addRef(
        trainingProgramPartyDetails);
    }

    return trainingProgramAndPartyDetails;
  }

  /**
   * Retrieves training program details not managed through agency for a
   * provider group member.
   *
   * @param key
   * Training program key.
   * @return Training program details for a provider group member.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramPartyCompletedDetails viewMemberCompletedTrainingNotManagedByAgency(
    TrainingProgramKey key) throws AppException, InformationalException {

    TrainingProgramPartyCompletedDetails trainingProgramPartyCompletedDetails = new TrainingProgramPartyCompletedDetails();

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      key.trainingProgramID);

    Set<curam.training.impl.TrainingProgramMember> trainingProgramMembers = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
      key.trainingProgramID);

    // Set the provider member training program details.
    for (curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMembers) {
      trainingProgramPartyCompletedDetails.status = trainingProgramMember.getLifecycleState().getCode();
      trainingProgramPartyCompletedDetails.dateCompleted = trainingProgramMember.getDateCompleted();
      trainingProgramPartyCompletedDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
      trainingProgramPartyCompletedDetails.trainingProgramMemberID = trainingProgramMember.getID();
      trainingProgramPartyCompletedDetails.trainingProgramMemberVersionNo = trainingProgramMember.getVersionNo();
      trainingProgramPartyCompletedDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
    }

    trainingProgramPartyCompletedDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();

    if (trainingProgram.getTraining() == null) {
      trainingProgramPartyCompletedDetails.trainingName = trainingProgram.getTrainingName();
      trainingProgramPartyCompletedDetails.trainingRegisteredInd = false;
    } else {
      trainingProgramPartyCompletedDetails.trainingName = trainingProgram.getTraining().getName();
      trainingProgramPartyCompletedDetails.trainingID = trainingProgram.getTraining().getID();
      trainingProgramPartyCompletedDetails.trainingRegisteredInd = true;
    }
    trainingProgramPartyCompletedDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();

    if (trainingProgram.getTrainingProvider() != null) {
      trainingProgramPartyCompletedDetails.trainingProviderName = trainingProgram.getTrainingProvider().getName();
    } else {
      trainingProgramPartyCompletedDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
    }
    trainingProgramPartyCompletedDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();

    return trainingProgramPartyCompletedDetails;
  }

  /**
   * Retrieves training program details for a provider group member.
   *
   * @param trainingProgramKey
   * contains training program ID.
   *
   * @return contains training program details for a
   * provider member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00137832, ASN
  public TrainingPartyDetails viewProviderGroupMemberTrainingProgram(
    TrainingProgramKey trainingProgramKey) throws AppException,
      InformationalException {
    TrainingPartyDetails partyDetails = new TrainingPartyDetails();

    curam.training.impl.TrainingProgram trainingProgram = null;

    Set<curam.training.impl.TrainingProgramMember> trainingProgramMemberDetails = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
      trainingProgramKey.trainingProgramID);

    // END, CR00137832

    for (curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMemberDetails) {
      partyDetails.completion = trainingProgramMember.getCompletion().toString();
      partyDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
      if (trainingProgramMember.getCreditsAchieved() > 0) {
        partyDetails.creditsAchievedString = String.valueOf(
          trainingProgramMember.getCreditsAchieved());
      }
      Date completedDate = trainingProgramMember.getDateCompleted();

      partyDetails.dateCompleted = completedDate;
      partyDetails.partyConcernRoleID = trainingProgramMember.getPartyConcernRole().getID();
      partyDetails.partyVersionNo = trainingProgramMember.getVersionNo();
      partyDetails.status = trainingProgramMember.getLifecycleState().toString();
      partyDetails.trainingProgramID = trainingProgramMember.getTrainingProgram().getID();
      partyDetails.trainingProgramMemberID = trainingProgramMember.getID();
      partyDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
      if (trainingProgramMember.getUnitsCompleted() > 0) {
        partyDetails.unitsCompletedString = String.valueOf(
          trainingProgramMember.getUnitsCompleted());
      }
      partyDetails.unitsRemaining = trainingProgramMember.getUnitsRequired()
        - trainingProgramMember.getUnitsCompleted();
      partyDetails.unitsRequired = trainingProgramMember.getUnitsRequired();

      trainingProgram = trainingProgramMember.getTrainingProgram();

      // BEGIN, CR00137832, ASN
      if (TRAININGPROGRAMPARTYSTATUSEntry.COMPLETE.equals(
        trainingProgramMember.getLifecycleState())) {
        // END, CR00137832
        // BEGIN CR00112382, NK
        List<TrainingCredit> trainingCredits = trainingCreditDAO.searchBy(
          trainingProgramMember.getTrainingProgram().getTraining());

        // END CR00112382
        if (trainingCredits.size() > 0) {
          int days = trainingProgram.getTrainingValidDays();

          if (days > 0) {
            partyDetails.validTill = completedDate.addDays(days);
          }
        }
      }
      partyDetails.waiverExpiryDate = trainingProgramMember.getWaiverExpiryDate();

    }

    partyDetails.trainingProgramDetails.authorizedFrom = trainingProgram.getDateRange().start();
    partyDetails.trainingProgramDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();
    partyDetails.trainingProgramDetails.toBeCompletedBy = trainingProgram.getDateRange().end();
    if (trainingProgram.getTraining() == null) {
      partyDetails.trainingProgramDetails.trainingName = trainingProgram.getTrainingName();
      partyDetails.trainingProgramDetails.trainingRegisteredInd = false;
    } else {
      partyDetails.trainingProgramDetails.trainingName = trainingProgram.getTraining().getName();
      partyDetails.trainingProgramDetails.trainingID = trainingProgram.getTraining().getID();
      partyDetails.trainingProgramDetails.trainingRegisteredInd = true;
    }
    partyDetails.trainingProgramDetails.trainingProgramID = trainingProgram.getID();
    partyDetails.trainingProgramDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();

    if (trainingProgram.getTrainingProvider() != null) {
      partyDetails.trainingProgramDetails.trainingProvider = trainingProgram.getTrainingProvider().getName();
    }

    partyDetails.trainingProgramDetails.unitAmount = trainingProgram.getUnitAmount();
    partyDetails.trainingProgramDetails.versionNo = trainingProgram.getVersionNo();

    return partyDetails;
  }

  /**
   * Retrieves training program details and list of members for a training
   * program.
   *
   * @param key
   * contains training program ID.
   *
   * @return TrainingProgramAndPartyDetails contains training program details
   * and the list of members for the training program.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public TrainingProgramAndPartyDetails viewProviderGroupTrainingProgram(
    TrainingProgramKey key) throws AppException, InformationalException {
    TrainingProgramAndPartyDetails trainingProgramAndPartyDetails = new TrainingProgramAndPartyDetails();

    // get the training program for the given training program id.
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      key.trainingProgramID);

    // set all the training program details in the return struct.
    trainingProgramAndPartyDetails.trainingProgramDetails.authorizedFrom = trainingProgram.getDateRange().start();
    trainingProgramAndPartyDetails.trainingProgramDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();
    trainingProgramAndPartyDetails.trainingProgramDetails.toBeCompletedBy = trainingProgram.getDateRange().end();
    if (trainingProgram.getTraining() == null) {
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingName = trainingProgram.getTrainingName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingRegisteredInd = false;
    } else {
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingName = trainingProgram.getTraining().getName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingID = trainingProgram.getTraining().getID();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingRegisteredInd = true;
    }
    trainingProgramAndPartyDetails.trainingProgramDetails.trainingProgramID = trainingProgram.getID();
    trainingProgramAndPartyDetails.trainingProgramDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();
    if (trainingProgram.getTrainingProvider() != null) {
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingProvider = trainingProgram.getTrainingProvider().getName();
    }
    trainingProgramAndPartyDetails.trainingProgramDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
    trainingProgramAndPartyDetails.trainingProgramDetails.unitAmount = trainingProgram.getUnitAmount();
    trainingProgramAndPartyDetails.trainingProgramDetails.versionNo = trainingProgram.getVersionNo();

    // get the members for the given training program id
    Set<TrainingProgramMember> trainingProgramMembers = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
      key.trainingProgramID);

    // set the training member details in the return struct
    for (TrainingProgramMember trainingProgramMember : trainingProgramMembers) {

      TrainingProgramPartyDetails trainingProgramPartyDetails = new TrainingProgramPartyDetails();

      trainingProgramPartyDetails.completion = trainingProgramMember.getCompletion().getCode();
      trainingProgramPartyDetails.dateCompleted = trainingProgramMember.getDateCompleted();
      trainingProgramPartyDetails.partyConcernRoleID = trainingProgramMember.getPartyConcernRole().getID();
      trainingProgramPartyDetails.partyName = concernRoleDAO.get(trainingProgramMember.getPartyConcernRole().getID()).getName();
      trainingProgramPartyDetails.status = trainingProgramMember.getLifecycleState().getCode();
      trainingProgramPartyDetails.trainingProgramMemberID = trainingProgramMember.getID();
      trainingProgramPartyDetails.unitsCompleted = Short.parseShort(
        (String.valueOf(trainingProgramMember.getUnitsCompleted())));
      trainingProgramPartyDetails.unitsRequired = trainingProgramMember.getUnitsRequired();
      trainingProgramPartyDetails.versionNo = trainingProgramMember.getVersionNo();

      trainingProgramAndPartyDetails.partyDetailsList.partyDetails.addRef(
        trainingProgramPartyDetails);
    }

    return trainingProgramAndPartyDetails;
  }

  // BEGIN, CR00237197, GP
  /**
   * Retrieves status history of training program for a member.
   *
   * @param key
   * contains the training program ID of Provider Member/Provider Group
   * Member/ Person
   *
   * @return Status history of training program for a member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link MaintainProviderTrainingProgram#viewTrainingProgramMemberStatusHistory(TrainingProgramMemberKey)}
   * . This method is not useful for displaying user full name.
   * Hence this method is deprecated. The newly added method will
   * give the option to the user to display the user full name. See
   * release note: CR00237197.
   */
  @Deprecated
  // END, CR00237197
  public TrainingMemberStatusHistoryDetailsList viewTrainingProgramMemberStatusHistory(
    TrainingProgramMemberKey key) throws AppException, InformationalException {

    TrainingMemberStatusHistoryDetailsList trainingMemberStatusHistory = new TrainingMemberStatusHistoryDetailsList();
    Set<TrainingStatusHistory> trainingStatusHistoryList = trainingStatusHistoryDAO.getTrainingStatusHistory(
      key.trainingProgramMemberID);

    // iterate through individual status of training program for member
    for (final curam.training.impl.TrainingStatusHistory trainingStatusHistory : trainingStatusHistoryList) {
      TrainingStatusHistoryDetails details = new TrainingStatusHistoryDetails();

      details.dateTime = trainingStatusHistory.getStatusDateTime();
      details.status = trainingStatusHistory.getStatus().toString();
      details.userName = trainingStatusHistory.getUserName();

      trainingMemberStatusHistory.historyDetails.addRef(details);
    }

    return sortListTrainingProgramHistory(trainingMemberStatusHistory);
  }

  /**
   * Retrieves the list of Completed Training Programs for a ProviderGroup.
   *
   * @param concernRoleKey
   * Contains the ConcernRole ID of the Provider Group.
   * @return List of Completed Training Programs.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_NO_PROVIDERGROUPMEMBERS_FOR_PROVIDER_GROUP_TRAINING_PROGRAM_CANNOT_BE_CREATED}
   * if there are no active provider group members under the provider
   * group then training program cannot be created.
   */
  public TrainingProgramList listCompletedTrainingProgramForProviderGroup(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    TrainingProgramList trainingProgramList = new TrainingProgramList();

    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      concernRoleKey.concernRoleID);

    int countOfActiveProviderMembers = 0;

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    Set<curam.training.impl.TrainingProgram> trainingPrograms = trainingProgramDAO.searchBy(
      concernRoleKey.concernRoleID, Boolean.FALSE, RECORDSTATUSEntry.NORMAL);

    // Populate the list of Completed Training Programs
    for (final curam.training.impl.TrainingProgram trainingProgram : trainingPrograms) {
      TrainingSummaryDetails trainingSummaryDetails = new TrainingSummaryDetails();

      trainingSummaryDetails.referenceNumber = trainingProgram.getReferenceNumber();

      trainingSummaryDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();

      trainingSummaryDetails.trainingProgramID = trainingProgram.getID();

      if (trainingProgram.getTraining() == null) {
        trainingSummaryDetails.trainingName = trainingProgram.getTrainingName();
        trainingSummaryDetails.trainingRegisteredInd = false;
      } else {
        trainingSummaryDetails.trainingName = trainingProgram.getTraining().getName();
        trainingSummaryDetails.trainingID = trainingProgram.getTraining().getID();
        trainingSummaryDetails.trainingRegisteredInd = true;
      }

      // Training is not registered on system.
      if (trainingSummaryDetails.trainingID != 0) {
        trainingSummaryDetails.trainingRegisteredInd = true;
      }

      trainingProgramList.trainingSummaryList.addRef(trainingSummaryDetails);

    }

    trainingProgramList = sortListTrainingPrograms(trainingProgramList);

    // Get the count of the active provider group members for the provider
    // group.
    Set<ProviderMember> providerGroupMemberSet = providerGroup.getProviderMembers();

    for (ProviderMember providerMember : providerGroupMemberSet) {
      if (RECORDSTATUSEntry.NORMAL.equals(providerMember.getLifecycleState())
        && (providerMember.getDateRange().end().isZero()
          || providerMember.getDateRange().endsInFuture())) {
        countOfActiveProviderMembers++;
      }
    }

    // No training program can be created if there are no provider members under
    // the provider.
    if ((countOfActiveProviderMembers == 0)) {
      trainingProgramList.createTrainingProgramInd = true;

    } else {
      trainingProgramList.createTrainingProgramInd = false;
    }
    return trainingProgramList;

  }

  /**
   * Retrieves the list of Completed Training Programs for a Provider Group
   * Member.
   *
   * @param providerPartyKey
   * Contains the party ID of the Provider Group Member.
   * @return List of Completed Training Programs.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramList listCompletedTrainingProgramForProviderGroupMember(
    ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerPartyKey.providerPartyID);

    TrainingProgramList trainingProgramList = new TrainingProgramList();

    curam.training.impl.TrainingProgram trainingProgram = null;

    TrainingSummaryDetails trainingSummaryDetails;
    String status = TRAININGPROGRAMPARTYSTATUSEntry.CANCELED.toString();
    Set<curam.training.impl.TrainingProgramMember> trainingProgramMemberDetails = trainingProgramMemberDAO.retrieveMemberTrainingPrograms(
      status, providerMember.getParty().getID());

    // Populate the list of Completed Training Programs for a member
    for (final curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMemberDetails) {
      trainingProgram = trainingProgramMember.getTrainingProgram();
      if (trainingProgram.isManagedThroughAgency() == false) {

        trainingSummaryDetails = new TrainingSummaryDetails();

        trainingSummaryDetails.trainingProgramMemberID = trainingProgramMember.getID();
        trainingSummaryDetails.trainingProgramMemberVersionNo = trainingProgramMember.getVersionNo();
        trainingSummaryDetails.referenceNumber = trainingProgram.getReferenceNumber();
        trainingSummaryDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();
        trainingSummaryDetails.trainingProgramID = trainingProgram.getID();

        // BEGIN CR00113139, PDN
        trainingSummaryDetails.trainingProgramDateCompleted = trainingProgramMember.getDateCompleted();
        // END CR00113139

        if (trainingProgram.getTraining() == null) {
          trainingSummaryDetails.trainingName = trainingProgram.getTrainingName();
          trainingSummaryDetails.trainingRegisteredInd = false;
        } else {
          trainingSummaryDetails.trainingName = trainingProgram.getTraining().getName();
          trainingSummaryDetails.trainingID = trainingProgram.getTraining().getID();
        }

        // Training is not registered on system.
        if (trainingSummaryDetails.trainingID != 0) {
          trainingSummaryDetails.trainingRegisteredInd = true;
        }
        trainingProgramList.trainingSummaryList.addRef(trainingSummaryDetails);
      }
    }
    trainingProgramList = sortListTrainingPrograms(trainingProgramList);

    ConcernRole concernRole = concernRoleDAO.get(
      providerMember.getParty().getID());

    trainingProgramList.pageContextDescription = concernRole.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + concernRole.getPrimaryAlternateID();

    trainingProgramList.memberConcernRoleID = providerMember.getParty().getID();

    return trainingProgramList;
  }

  /**
   * Retrieves the list of Managed Training Programs for a ProviderGroup.
   *
   * @param concernRoleKey
   * Contains the ConcernRole ID of the Provider Group.
   * @return List of Managed Training Programs.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public TrainingProgramList listManagedTrainingProgramForProviderGroup(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    TrainingProgramList trainingProgramList = new TrainingProgramList();

    Set<curam.training.impl.TrainingProgram> trainingPrograms = trainingProgramDAO.searchBy(
      concernRoleKey.concernRoleID, Boolean.TRUE, RECORDSTATUSEntry.NORMAL);

    // Populate the list of Managed Training Programs
    for (final curam.training.impl.TrainingProgram trainingProgram : trainingPrograms) {

      TrainingSummaryDetails trainingSummaryDetails = new TrainingSummaryDetails();

      trainingSummaryDetails.referenceNumber = trainingProgram.getReferenceNumber();

      trainingSummaryDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();

      trainingSummaryDetails.trainingProgramID = trainingProgram.getID();

      // BEGIN CR00113139, PDN
      trainingSummaryDetails.trainingProgramStatus = trainingProgram.getLifecycleState().getCode();
      // END CR00113139

      if (trainingProgram.getTraining() == null) {
        trainingSummaryDetails.trainingName = trainingProgram.getTrainingName();
      } else {
        trainingSummaryDetails.trainingName = trainingProgram.getTraining().getName();
        trainingSummaryDetails.trainingID = trainingProgram.getTraining().getID();
      }

      // Training is not registered on system.
      if (trainingSummaryDetails.trainingID != 0) {
        trainingSummaryDetails.trainingRegisteredInd = true;
      }

      trainingProgramList.trainingSummaryList.addRef(trainingSummaryDetails);

    }

    return sortListTrainingPrograms(trainingProgramList);
  }

  /**
   * Retrieves the list of Managed Training Programs for a Provider Group
   * Member.
   *
   * @param providerPartyKey
   * Contains the party ID of the Provider Group Member.
   * @return List of Managed Training Programs.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public TrainingProgramList listManagedTrainingProgramForProviderGroupMember(
    ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerPartyKey.providerPartyID);

    TrainingProgramList trainingProgramList = new TrainingProgramList();

    curam.training.impl.TrainingProgram trainingProgram = null;

    String status = TRAININGPROGRAMPARTYSTATUSEntry.CANCELED.toString();
    Set<curam.training.impl.TrainingProgramMember> trainingProgramMemberDetails = trainingProgramMemberDAO.retrieveMemberTrainingPrograms(
      status, providerMember.getParty().getID());

    // Populate the list of Managed Training Programs for a member
    for (final curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMemberDetails) {
      trainingProgram = trainingProgramMember.getTrainingProgram();
      if (trainingProgram.isManagedThroughAgency() == true) {

        TrainingSummaryDetails trainingSummaryDetails = new TrainingSummaryDetails();

        trainingSummaryDetails.trainingProgramMemberID = trainingProgramMember.getID();
        trainingSummaryDetails.trainingProgramMemberVersionNo = trainingProgramMember.getVersionNo();
        trainingSummaryDetails.referenceNumber = trainingProgram.getReferenceNumber();
        trainingSummaryDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();
        trainingSummaryDetails.trainingProgramID = trainingProgram.getID();

        // BEGIN CR00113139, PDN
        trainingSummaryDetails.trainingProgramDateCompleted = trainingProgramMember.getDateCompleted();
        trainingSummaryDetails.trainingProgramStatus = trainingProgram.getLifecycleState().getCode();
        // END CR00113139

        if (trainingProgram.getTraining() == null) {
          trainingSummaryDetails.trainingName = trainingProgram.getTrainingName();
        } else {
          trainingSummaryDetails.trainingName = trainingProgram.getTraining().getName();
          trainingSummaryDetails.trainingID = trainingProgram.getTraining().getID();
        }

        // Training is not registered on system.
        if (trainingSummaryDetails.trainingID != 0) {
          trainingSummaryDetails.trainingRegisteredInd = true;
        }

        // Set the training program owner type.
        trainingSummaryDetails.trainingProgramOwnerType = trainingProgramMember.getTrainingProgramOwnerType();

        if (trainingSummaryDetails.trainingProgramOwnerType.equals(
          CPMConstants.kProvider)) {
          trainingSummaryDetails.trainingProgramOwnerIsProvider = true;
          // BEGIN, CR00154962, ASN
          trainingSummaryDetails.trainingProgramOwnerID = trainingProgram.getTrainingProgramOwner().getID();
          // END, CR00154962
        } else if (trainingSummaryDetails.trainingProgramOwnerType.equals(
          CPMConstants.kProviderGroup)) {
          trainingSummaryDetails.trainingProgramOwnerIsProviderGroup = true;
          // BEGIN, CR00154962, ASN
          trainingSummaryDetails.trainingProgramOwnerID = trainingProgram.getTrainingProgramOwner().getID();
          // END, CR00154962
        } else {
          trainingSummaryDetails.trainingProgramOwnerIsMember = true;
          // BEGIN, CR00154962, ASN
          trainingSummaryDetails.trainingProgramOwnerID = trainingProgram.getTrainingProgramOwner().getID();
          // END, CR00154962
        }
        trainingProgramList.trainingSummaryList.addRef(trainingSummaryDetails);
      }
    }
    trainingProgramList = sortListTrainingPrograms(trainingProgramList);

    ConcernRole concernRole = concernRoleDAO.get(
      providerMember.getParty().getID());

    trainingProgramList.pageContextDescription = concernRole.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + concernRole.getPrimaryAlternateID();

    trainingProgramList.memberConcernRoleID = providerMember.getParty().getID();

    return trainingProgramList;
  }

  // BEGIN, CR00234644, GP
  /**
   * Retrieves the list of Completed Training Programs for a ProviderGroup.
   *
   * @param concernRoleKey
   * Provider group for which training programs are to be retrieved.
   *
   * @return List of training programs for a provider.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_NO_PROVIDERGROUPMEMBERS_FOR_PROVIDER_GROUP_TRAINING_PROGRAM_CANNOT_BE_CREATED}
   * if there are no active provider group members under the provider
   * group then training program cannot be created.
   */
  public TrainingProgramSummaryDetailsList listTrainingProgramForProviderGroup(
    final ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    TrainingProgramSummaryDetailsList trainingProgramSummaryDetailsList = new TrainingProgramSummaryDetailsList();

    TrainingProgramList completedTrainingProgramList = listCompletedTrainingProgramForProviderGroup(
      concernRoleKey);
    TrainingProgramList managedTrainingProgramList = listManagedTrainingProgramForProviderGroup(
      concernRoleKey);
    
    setTrainingProgramDetails(completedTrainingProgramList,
      trainingProgramSummaryDetailsList, Boolean.FALSE);
    
    setTrainingProgramDetails(managedTrainingProgramList,
      trainingProgramSummaryDetailsList, Boolean.TRUE);
    
    sortTrainingPrograms(trainingProgramSummaryDetailsList);
    
    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      concernRoleKey.concernRoleID);

    int countOfActiveProviderMembers = 0;

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    Set<ProviderMember> providerGroupMemberSet = providerGroup.getProviderMembers();

    for (ProviderMember providerMember : providerGroupMemberSet) {
      if (RECORDSTATUSEntry.NORMAL.equals(providerMember.getLifecycleState())
        && (providerMember.getDateRange().end().isZero()
          || providerMember.getDateRange().endsInFuture())) {
        countOfActiveProviderMembers++;
      }
    }

    // No training program can be created if there are no provider members under
    // the provider.
    if (0 == countOfActiveProviderMembers) {
      
      trainingProgramSummaryDetailsList.createTrainingProgramInd = true;

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          TRAININGPROGRAM.ERR_TRAININGPROGRAM_FV_NO_PROVIDERGROUPMEMBERS_FOR_PROVIDER_GROUP_TRAINING_PROGRAM_CANNOT_BE_CREATED),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

      // Assign informational messages to return struct
      String warnings[] = informationalManager.obtainInformationalAsString();

      for (final String messageText : warnings) {
        InformationalMessage informationalMessage = new InformationalMessage();

        informationalMessage.messageTest = messageText;
        trainingProgramSummaryDetailsList.informationalMessageList.dtls.add(
          informationalMessage);
      }

    } else {
      trainingProgramSummaryDetailsList.createTrainingProgramInd = false;
    }
    
    return trainingProgramSummaryDetailsList;
  }

  /**
   * Retrieves the list of training programs for a provider group member.
   *
   * @param providerPartyKey
   * Provider group member for which training program list has to be
   * retrieved.
   *
   * @return List of training programs for provider group member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramSummaryDetailsList listTrainingProgramForProviderGroupMember(
    final ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    TrainingProgramSummaryDetailsList trainingProgramSummaryDetailsList = new TrainingProgramSummaryDetailsList();

    TrainingProgramList completedTrainingProgramList = listCompletedTrainingProgramForProviderGroupMember(
      providerPartyKey);
    TrainingProgramList managedTrainingProgramList = listManagedTrainingProgramForProviderGroupMember(
      providerPartyKey);

    setTrainingProgramList(completedTrainingProgramList,
      trainingProgramSummaryDetailsList);
    setTrainingProgramList(managedTrainingProgramList,
      trainingProgramSummaryDetailsList);

    sortTrainingPrograms(trainingProgramSummaryDetailsList);
    
    trainingProgramSummaryDetailsList.memberConcernRoleID = managedTrainingProgramList.memberConcernRoleID;
    trainingProgramSummaryDetailsList.createTrainingProgramInd = completedTrainingProgramList.createTrainingProgramInd;
    
    return trainingProgramSummaryDetailsList;
  }

  // END, CR00234644

  /**
   * Waive a provider group member training program.
   *
   * @param details
   * Contains the Training Program Waiver details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void waiveProviderGroupPartyTrainingProgram(
    TrainingProgramPartyWaiverDetails details) throws AppException,
      InformationalException {

    // Read the Training Program Member record.
    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.concernRoleID);

    // Perform the Provider Group security check.
    trainingProgramMember.validateProviderOrganization(providerOrganization);

    // Sets the waiver expiry date
    trainingProgramMember.setWaiverExpiryDate(details.waiverExpiryDate);

    // waive of the training program.
    trainingProgramMember.waiveTrainingMemberProgram(details.partyVersionNo);

  }

  // BEGIN, CR00112653, SK
  /**
   * Method used by Resource Manager and Resource Manager Supervisor to update
   * the details of a training program for a provider group member.
   *
   * @param details
   * Contains details of Training Program Member to be updated.
   * @return The list of informational messages.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMessageList updateProviderGroupMemberTrainingProgram(
    TrainingProgramMemberUpdateDetails details) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();

    setTrainingProgram(details);
    setTrainingProgramMember(details);

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProgramID);

    // Check appropriate security privileges
    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      details.providerOrganizationID);

    providerSecurity.checkProviderGroupSecurity(providerGroup);

    trainingProgram.modify(details.trainingProgramVersionNo);

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    if (!details.dateCompleted.equals(Date.kZeroDate)
      || details.creditsAchieved != 0 || details.unitsCompleted != 0) {

      // mark training program complete
      informationalMessageList = trainingProgramMember.markTrainingMemberProgramComplete(
        trainingProgramMember.getVersionNo());
    } else {
      trainingProgramMember.modify(details.trainingProgramMemberVersionNo);
    }

    return informationalMessageList;

  }

  /**
   * Method used by Resource Manager and Resource Manager Supervisor to update
   * the details of a training program for a member of a Provider Group.
   *
   * @param details
   * Contains the details of the Training Program and Training Program
   * Member.
   * @return The list of informational messages.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMessageList updateMemberTrainingProgramForProviderGroup(
    TrainingProgramMemberUpdateDetails details) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();

    setTrainingProgramMember(details);

    // Check appropriate security privileges
    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      details.providerOrganizationID);

    providerSecurity.checkProviderGroupSecurity(providerGroup);

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    if (!details.dateCompleted.equals(Date.kZeroDate)
      || details.creditsAchieved != 0 || details.unitsCompleted != 0) {

      // mark training program complete
      informationalMessageList = trainingProgramMember.markTrainingMemberProgramComplete(
        trainingProgramMember.getVersionNo());
    } else {
      trainingProgramMember.modify(details.trainingProgramMemberVersionNo);
    }

    return informationalMessageList;

  }

  // END, CR00112653

  /**
   * Retrieves the provider group member details based on service offering
   * training requirement.
   *
   * @param key
   * Contains service offering training requirement ID or license
   * training requirement ID.
   * @return Training party details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingPartyCreateDetails retrieveProviderGroupMemberTrainingProgramBasedOnTrainingReq(
    TrainingRequirementSummaryDetails key) throws AppException,
      InformationalException {

    TrainingPartyCreateDetails trainingPartyCreateDetails = new TrainingPartyCreateDetails();

    if (key.licenseTrainingRequirementID == 0) {
      SOTrainingRequirement soTrainingRequirement = soTrainingRequirementDAO.get(
        key.serviceOfferingTrainingRequirementID);

      trainingPartyCreateDetails.trainingID = soTrainingRequirement.getTraining().getID();
      trainingPartyCreateDetails.trainingName = soTrainingRequirement.getTraining().getName();
      trainingPartyCreateDetails.completion = soTrainingRequirement.getCompletion().getCode();
    } else {

      LicenseTrainingRequirement licenseTrainingRequirement = licenseTrainingRequirementDAO.get(
        key.licenseTrainingRequirementID);

      trainingPartyCreateDetails.trainingID = licenseTrainingRequirement.getTraining().getID();
      trainingPartyCreateDetails.trainingName = licenseTrainingRequirement.getTraining().getName();
      trainingPartyCreateDetails.completion = licenseTrainingRequirement.getCompletion().getCode();
    }

    trainingPartyCreateDetails.authorizedFrom = Date.getCurrentDate();

    TrainingKey trainingKey = new TrainingKey();

    trainingKey.trainingID = trainingPartyCreateDetails.trainingID;

    TrainingServiceOfferingDtls trainingServiceOfferingDtls = trainingServiceOfferingDAO.readByTraining(
      trainingKey);

    if (trainingServiceOfferingDtls != null
      && trainingServiceOfferingDtls.trainingServiceOfferingID != 0) {
      trainingPartyCreateDetails.unitsRequired = trainingServiceOfferingDtls.unitsRequired;
    }

    return trainingPartyCreateDetails;
  }

  /**
   * Approves the Provider Group Member Training Program.
   *
   * @param trainingProgramConcernRoleVersionKey
   * Contains the details to approve the training program for a
   * provider group member.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public void approveProviderGroupMemberTrainingProgram(
    TrainingProgramConcernRoleVersionKey trainingProgramConcernRoleVersionKey)
    throws AppException, InformationalException {

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      trainingProgramConcernRoleVersionKey.trainingProgramMemberID);

    KeyVersionDetails keyVersionDetails = new KeyVersionDetails();

    keyVersionDetails.id = trainingProgramConcernRoleVersionKey.concernRoleID;
    keyVersionDetails.version = trainingProgramConcernRoleVersionKey.trainingProgramMemberVersionNo;

    providerGroupMemberTrainingProgram.approveProviderGroupMemberTrainingProgram(
      keyVersionDetails, trainingProgramMember);
  }

  // BEGIN CR00113213, MST
  /**
   * Validates the members for the Provider Group.
   *
   * @param trainingPartyCreateDetailsList
   * Contains Training details which is got from the widget.
   * @param trainingProgramPartyDetailsList
   * Contains Training Program Party Details which is got from the
   * widget.
   * @param providerOrganization
   * Contains the details of the provider group.
   *
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_TRAINING_PROGRAM_WITH_STATUS_OPEN_OR_APPROVED_ALREADY_EXISTS_FOR_PROVIDER_GROUP_MEMBERS} -
   * if the training program already exists with the training and
   * provider group member combination.
   * {@linkplain TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_UNITSREQUIRED_GR_THAN_ZERO_FOR_PROVIDERGROUPMEMBERS} -
   * if the units required entered for the provider group members are
   * invalid.
   */
  protected void validateMembers(
    TrainingPartyCreateDetailsList trainingPartyCreateDetailsList,
    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList,
    ProviderOrganization providerOrganization) {
    // END CR00113213

    String openPartyNames = "";
    String approvedPartyNames = "";
    String invalidUnitsRequired = "";
    int openPartyNamesCounter = 0;
    int approvedPartyNamesCounter = 0;
    int invalidUnitsRequiredCounter = 0;

    for (TrainingPartyCreateDetails trainingPartyCreateDetails : trainingPartyCreateDetailsList.detailsList.items()) {

      for (TrainingProgramPartyDetails trainingProgramPartyDetails : trainingProgramPartyDetailsList.partyDetails.items()) {

        for (curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMemberDAO.getTrainingProgramsForParty(
          trainingPartyCreateDetails.trainingID,
          trainingProgramPartyDetails.partyConcernRoleID)) {

          if (trainingProgramMember.getLifecycleState().equals(
            TRAININGPROGRAMPARTYSTATUSEntry.OPEN)) {

            if (openPartyNamesCounter == 0) {
              openPartyNames = trainingPartyCreateDetails.trainingName
                + GeneralConstants.kColon
                + trainingProgramPartyDetails.partyName;
              openPartyNamesCounter++;
            } else {
              openPartyNames += GeneralConstants.kComma
                + GeneralConstants.kSpace
                + trainingPartyCreateDetails.trainingName
                + GeneralConstants.kColon
                + trainingProgramPartyDetails.partyName;
            }
          } else if (trainingProgramMember.getLifecycleState().equals(
            TRAININGPROGRAMPARTYSTATUSEntry.APPROVED)) {
            if (approvedPartyNamesCounter == 0) {
              approvedPartyNames = trainingPartyCreateDetails.trainingName
                + GeneralConstants.kColon
                + trainingProgramPartyDetails.partyName;
              approvedPartyNamesCounter++;
            } else {
              approvedPartyNames += GeneralConstants.kComma
                + GeneralConstants.kSpace
                + trainingPartyCreateDetails.trainingName
                + GeneralConstants.kColon
                + trainingProgramPartyDetails.partyName;
            }
          }

          break;
        }

        // BEGIN CR00113213, MST
        Set<ProviderMember> providerMembers = providerMemberDAO.searchBy(
          providerOrganization);

        for (ProviderMember providerMember : providerMembers) {
          if (providerMember.getParty().getID()
            == trainingProgramPartyDetails.partyConcernRoleID) {

            if (providerMember.getDateRange().startsAfter(
              trainingPartyCreateDetails.authorizedFrom)) {

              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_PROVIDERMEMBER_FROM_DATE_ON_OR_BEFORE_AUTHORIZED_DATE(
                  trainingPartyCreateDetails.authorizedFrom,
                  providerMember.getDateRange().start(),
                  trainingProgramPartyDetails.partyName),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                  0);
            }
            if (!trainingPartyCreateDetails.toBeCompletedBy.isZero()
              && providerMember.getDateRange().isEnded()
              && providerMember.getDateRange().endsBefore(
                trainingPartyCreateDetails.toBeCompletedBy)) {

              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_PROVIDERMEMBER_TO_DATE_ON_OR_AFTER_TO_BE_COMPLETED_BY_DATE(
                  trainingPartyCreateDetails.toBeCompletedBy,
                  providerMember.getDateRange().end(),
                  trainingProgramPartyDetails.partyName),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                  0);
            }
            if (trainingPartyCreateDetails.toBeCompletedBy.isZero()
              && providerMember.getDateRange().isEnded()) {

              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_PROVIDERMEMBER_TO_DATE_ON_OR_AFTER_TO_BE_COMPLETED_BY_DATE_OPEN_ENDED(
                  providerMember.getDateRange().end(),
                  trainingProgramPartyDetails.partyName),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                  0);
            }
          }
        }
        // END CR00113213
      }
    }

    if (openPartyNames.length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_TRAINING_PROGRAM_WITH_STATUS_OPEN_OR_APPROVED_ALREADY_EXISTS_FOR_PROVIDER_GROUP_MEMBERS(
          TRAININGPROGRAMPARTYSTATUSEntry.OPEN.getCodeTableItemIdentifier(),
          openPartyNames),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (approvedPartyNames.length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_TRAINING_PROGRAM_WITH_STATUS_OPEN_OR_APPROVED_ALREADY_EXISTS_FOR_PROVIDER_GROUP_MEMBERS(
          TRAININGPROGRAMPARTYSTATUSEntry.APPROVED.getCodeTableItemIdentifier(),
          approvedPartyNames),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    for (TrainingProgramPartyDetails trainingProgramPartyDetails : trainingProgramPartyDetailsList.partyDetails.items()) {
      if (trainingProgramPartyDetails.unitsRequired <= 0) {
        if (invalidUnitsRequiredCounter == 0) {
          invalidUnitsRequired = trainingProgramPartyDetails.partyName;
          invalidUnitsRequiredCounter++;
        } else {
          invalidUnitsRequired += GeneralConstants.kComma
            + GeneralConstants.kSpace + trainingProgramPartyDetails.partyName;

        }
      }
    }

    if (invalidUnitsRequired.length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_UNITSREQUIRED_GR_THAN_ZERO_FOR_PROVIDERGROUPMEMBERS(
          invalidUnitsRequired),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  /**
   * Sorts a set of Training Programs by Training Name
   *
   * @param unsortedTrainingPrograms
   * The set of unsorted Training Programs
   * @return Contains a list of Training Programs sorted by Training Name.
   */
  protected TrainingProgramList sortListTrainingPrograms(
    TrainingProgramList unsortedTrainingPrograms) {

    List<TrainingSummaryDetails> trainingSummaryDetailsList = new ArrayList<TrainingSummaryDetails>();

    for (int i = 0; i < unsortedTrainingPrograms.trainingSummaryList.size(); i++) {
      trainingSummaryDetailsList.add(
        unsortedTrainingPrograms.trainingSummaryList.item(i));
    }

    // Sort the unsorted training programs
    Collections.sort(trainingSummaryDetailsList,
      new Comparator<TrainingSummaryDetails>() {
      public int compare(final TrainingSummaryDetails lhs,
        TrainingSummaryDetails rhs) {
        return lhs.trainingName.compareTo(rhs.trainingName);
      }
    });

    TrainingProgramList trainingProgramList = new TrainingProgramList();

    for (TrainingSummaryDetails trainingProgram : trainingSummaryDetailsList) {
      trainingProgramList.trainingSummaryList.addRef(trainingProgram);
    }

    return trainingProgramList;
  }

  /**
   * Sorts a set of Party Details by Party Name.
   *
   * @param unsortedPartyDetails
   * The set of unsorted Party Details.
   * @return Contains a list of Party Details sorted by Party Name.
   */
  protected TrainingProgramPartyDetailsList sortPartyDetailsList(
    TrainingProgramPartyDetailsList unsortedPartyDetails) {

    List<TrainingProgramPartyDetails> trainingPartyDetailsList = new ArrayList<TrainingProgramPartyDetails>();

    for (int i = 0; i < unsortedPartyDetails.partyDetails.size(); i++) {
      trainingPartyDetailsList.add(unsortedPartyDetails.partyDetails.item(i));
    }

    // Sort the unsorted training programs
    Collections.sort(trainingPartyDetailsList,
      new Comparator<TrainingProgramPartyDetails>() {
      public int compare(final TrainingProgramPartyDetails lhs,
        TrainingProgramPartyDetails rhs) {
        return lhs.partyName.compareTo(rhs.partyName);
      }
    });

    TrainingProgramPartyDetailsList trainingProgramList = new TrainingProgramPartyDetailsList();

    for (TrainingProgramPartyDetails trainingProgram : trainingPartyDetailsList) {
      trainingProgramList.partyDetails.addRef(trainingProgram);
    }

    return trainingProgramList;
  }

  /**
   * Sets the training program details.
   *
   * @param trainingPartyCreateDetails
   * Contains training program details.
   * @return Training program to be created.
   */
  protected curam.training.impl.TrainingProgram setTrainingProgram(
    TrainingPartyCreateDetails trainingPartyCreateDetails) {

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.newInstance();

    trainingProgram.setTraining(
      trainingDAO.get(trainingPartyCreateDetails.trainingID));
    trainingProgram.setUnitAmount(trainingPartyCreateDetails.unitAmount);

    trainingProgram.setDateRange(
      new DateRange(trainingPartyCreateDetails.authorizedFrom,
      trainingPartyCreateDetails.toBeCompletedBy));
    ConcernRole concernRole = concernRoleDAO.get(
      trainingPartyCreateDetails.concernRoleID);

    trainingProgram.setTrainingProgramOwner(concernRole);
    trainingProgram.setManagedThroughAgency(true);

    trainingProgram.setTrainingProvider(
      providerDAO.get(trainingPartyCreateDetails.trainingProviderID));

    return trainingProgram;
  }

  /**
   * Sets the training program details.
   *
   * @param trainingPartyCreateDetails
   * Contains training program details.
   * @param trainingProviderID
   * Training Provider ID.
   * @param providerConcernRoleID
   * Provider Concern Role ID.
   * @return Training program to be created.
   */
  protected curam.training.impl.TrainingProgram setTrainingProgram(
    TrainingPartyCreateDetails trainingPartyCreateDetails,
    long trainingProviderID, long providerConcernRoleID) {

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.newInstance();

    trainingProgram.setTraining(
      trainingDAO.get(trainingPartyCreateDetails.trainingID));
    trainingProgram.setUnitAmount(trainingPartyCreateDetails.unitAmount);

    trainingProgram.setDateRange(
      new DateRange(trainingPartyCreateDetails.authorizedFrom,
      trainingPartyCreateDetails.toBeCompletedBy));
    ConcernRole concernRole = concernRoleDAO.get(providerConcernRoleID);

    trainingProgram.setTrainingProgramOwner(concernRole);
    trainingProgram.setManagedThroughAgency(true);

    trainingProgram.setTrainingProvider(providerDAO.get(trainingProviderID));

    return trainingProgram;
  }

  /**
   * Sets the completed provider training program entity details.
   *
   * @param details
   * Contains the training program completed details.
   * @param trainingProgram
   * Instance of an training program.
   */
  protected void setRecordCompletedProviderGroupProgramDetails(
    TrainingProgramCompletedDetails details,
    curam.training.impl.TrainingProgram trainingProgram) {

    // check is search training is found
    if (0 != details.trainingProviderDetails.trainingID) {
      // get the training instance
      Training training = trainingDAO.get(
        details.trainingProviderDetails.trainingID);

      trainingProgram.setTraining(training);
    }
    trainingProgram.setTrainingName(
      details.trainingProviderDetails.trainingName);
    // check search training provider is found
    if (0 != details.trainingProviderDetails.trainingProviderID) {
      curam.provider.impl.Provider provider = providerDAO.get(
        details.trainingProviderDetails.trainingProviderID);

      trainingProgram.setTrainingProvider(provider);

    }
    trainingProgram.setTrainingProviderDetails(
      details.trainingProviderDetails.trainingProviderDetails);
    ConcernRole concernRole = concernRoleDAO.get(details.partyConcernRoleID);

    trainingProgram.setTrainingProgramOwner(concernRole);
    trainingProgram.setManagedThroughAgency(false);

  }

  /**
   * Sets the completed provider group member training entity details.
   *
   * @param trainingProgram
   * Instance of an training program member.
   * @param details
   * Contains the training program completed details.
   */
  protected void setRecordCompletedProviderGroupProgramMemberDetails(
    TrainingProgramCompletedDetails details,
    TrainingProgramMember trainingProgramMember) {

    // get the training program instance
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProviderDetails.trainingProgramID);

    // set the training program data
    trainingProgramMember.setTrainingProgram(trainingProgram);
    ConcernRole concernRole = concernRoleDAO.get(details.partyConcernRoleID);

    trainingProgramMember.setPartyConcernRole(concernRole);
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setUnitsCompleted(details.unitsCompleted);
  }

  /**
   * Validates the record completed provider training.
   *
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_PROVIDER_MEMBER_UNITSCOMPLETED_GR_THAN_ZERO} -
   * If the units completed less than or equal to zero.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_PROVIDER_MEMBER_DATE_COMPLETED_LATER_THAN_CURRENT_BUSINESS_DATE} -
   * If date completed is later than the current business date.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_PROVIDER_MEMBER_UNITSCOMPLETED_MANDATORY_IF_DATE_COMPLETED_IS_ENTERED} -
   * If date completed is entered and units completed is not entered.
   */
  protected void validateRecordCompleted(
    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList)
    throws AppException, InformationalException {
    Date currentDate = Date.getCurrentDate();
    String invalidUnitsCompletedMembers = CPMConstants.kEmptyString;
    String invalidDateCompltedMembers = CPMConstants.kEmptyString;
    String invalidUnitsAnddateMembers = CPMConstants.kEmptyString;
    int invalidDateCounter = 0;
    int invalidUnitsCounter = 0;
    int invalidDateAndUnitsCounter = 0;

    for (TrainingProgramPartyDetails trainingProgramPartyDetails : trainingProgramPartyDetailsList.partyDetails.items()) {

      // check if units completed is less than or equal to zero
      if (trainingProgramPartyDetails.unitsCompleted <= 0) {
        if (invalidUnitsCounter == 0) {
          invalidUnitsCompletedMembers = trainingProgramPartyDetails.partyName;
        } else {
          invalidUnitsCompletedMembers = invalidUnitsCompletedMembers
            + GeneralConstants.kComma + trainingProgramPartyDetails.partyName;
        }
        invalidUnitsCounter++;
      }
      // check if date completed greater than current business date
      if (trainingProgramPartyDetails.dateCompleted.after(currentDate)) {
        if (invalidDateCounter == 0) {
          invalidDateCompltedMembers = trainingProgramPartyDetails.partyName;
        } else {
          invalidDateCompltedMembers = invalidDateCompltedMembers
            + GeneralConstants.kComma + trainingProgramPartyDetails.partyName;
        }
        invalidDateCounter++;
      }
      // check if units completed is not entered when date completed is entered
      if (!Date.kZeroDate.equals(trainingProgramPartyDetails.dateCompleted)
        && trainingProgramPartyDetails.unitsCompleted == 0) {

        if (invalidDateAndUnitsCounter == 0) {
          invalidUnitsAnddateMembers = trainingProgramPartyDetails.partyName;
        } else {
          invalidUnitsAnddateMembers = invalidUnitsAnddateMembers
            + GeneralConstants.kComma + trainingProgramPartyDetails.partyName;
        }
        invalidDateAndUnitsCounter++;
      }
    }
    // form the consolidated messages
    if (StringHelper.trim(invalidUnitsCompletedMembers).length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_PROVIDER_MEMBER_UNITSCOMPLETED_GR_THAN_ZERO(
          invalidUnitsCompletedMembers),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    if (StringHelper.trim(invalidDateCompltedMembers).length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_PROVIDER_MEMBER_DATE_COMPLETED_LATER_THAN_CURRENT_BUSINESS_DATE(
          invalidDateCompltedMembers),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    if (StringHelper.trim(invalidUnitsAnddateMembers).length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_PROVIDER_MEMBER_UNITSCOMPLETED_MANDATORY_IF_DATE_COMPLETED_IS_ENTERED(
          invalidUnitsAnddateMembers),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    ValidationHelper.failIfErrorsExist();
  }

  /**
   * Sets the completed provider training program entity details.
   *
   * @param details
   * Contains the training provider party details.
   * @param trainingProgram
   * Instance of an training program.
   */
  protected void setRecordCompletedTrainingProgramDetails(
    TrainingProgramAndPartyCompletedDetails details,
    curam.training.impl.TrainingProgram trainingProgram) {

    if (0 != details.trainingProviderDetails.trainingID) {
      // get the training instance
      Training training = trainingDAO.get(
        details.trainingProviderDetails.trainingID);

      trainingProgram.setTraining(training);
    }
    trainingProgram.setTrainingName(
      details.trainingProviderDetails.trainingName);

    if (0 != details.trainingProviderDetails.trainingProviderID) {
      curam.provider.impl.Provider provider = providerDAO.get(
        details.trainingProviderDetails.trainingProviderID);

      trainingProgram.setTrainingProvider(provider);

    }
    trainingProgram.setTrainingProviderDetails(
      details.trainingProviderDetails.trainingProviderDetails);
    ConcernRole concernRole = concernRoleDAO.get(
      details.trainingProviderDetails.concernRoleID);

    trainingProgram.setTrainingProgramOwner(concernRole);
    trainingProgram.setManagedThroughAgency(false);

  }

  /**
   * Sets the completed provider member training entity details.
   *
   * @param details
   * Contains the training provider party details.
   * @param trainingProgramMember
   * Instance of an training program member.
   * @param trainingProgram
   * Instance of an training program.
   */
  protected void setRecordCompletedProgramMemberDetails(
    TrainingProgramPartyDetails details,
    TrainingProgramMember trainingProgramMember,
    curam.training.impl.TrainingProgram trainingProgram) {
    // set the training member data
    trainingProgramMember.setTrainingProgram(trainingProgram);
    ConcernRole concernRole = concernRoleDAO.get(details.partyConcernRoleID);

    trainingProgramMember.setPartyConcernRole(concernRole);
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setUnitsCompleted(details.unitsCompleted);
  }

  /**
   * Sets the training program details.
   *
   * @param details
   * Training program update details.
   */
  protected void setTrainingProgram(TrainingProgramMemberUpdateDetails details) {

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProgramID);

    trainingProgram.setDateRange(
      new DateRange(details.authorizedFrom, details.toBeCompletedBy));
    trainingProgram.setUnitAmount(details.unitAmount);

  }

  /**
   * Sets the training program details.
   *
   * @param details
   * Training program update details.
   */
  protected void setTrainingProgramMember(
    TrainingProgramMemberUpdateDetails details) {

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    trainingProgramMember.setCompletion(
      TrainingCompletionEntry.get(details.completion));
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setUnitsRequired(details.unitsRequired);

    if (details.creditsAchievedString.length() > 0) {
      try {
        // convert credits achieved string to int
        details.creditsAchieved = Integer.parseInt(
          details.creditsAchievedString);
      } catch (NumberFormatException exception) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_CREDITS_ACHIEVED_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }

      if (details.creditsAchieved <= 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_CREDITS_ACHIEVED_GR_THAN_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }

      trainingProgramMember.setCreditsAchieved(details.creditsAchieved);
    }

    if (details.unitsCompletedString.length() > 0) {
      try {
        // convert credits achieved string to int
        details.unitsCompleted = Integer.parseInt(details.unitsCompletedString);
      } catch (NumberFormatException exception) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_UNITSCOMPLETED_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
      trainingProgramMember.setUnitsCompleted(details.unitsCompleted);
    }

  }

  /**
   * Sorts a set of Training Program Status History by Date time.
   *
   * @param unsortedTrainingMemberStatusHistoryDetailsList
   * The set of unsorted Training Program status history.
   * @return Contains a list of Training Program Status History sorted by Date
   * Time.
   */
  protected TrainingMemberStatusHistoryDetailsList sortListTrainingProgramHistory(
    TrainingMemberStatusHistoryDetailsList unsortedTrainingMemberStatusHistoryDetailsList) {

    List<TrainingStatusHistoryDetails> trainingMemberStatusHistoryDetailsList = new ArrayList<TrainingStatusHistoryDetails>();

    for (int i = 0; i
      < unsortedTrainingMemberStatusHistoryDetailsList.historyDetails.size(); i++) {
      trainingMemberStatusHistoryDetailsList.add(
        unsortedTrainingMemberStatusHistoryDetailsList.historyDetails.item(i));
    }

    // Sort the unsorted training status history.
    Collections.sort(trainingMemberStatusHistoryDetailsList,
      new Comparator<TrainingStatusHistoryDetails>() {
      public int compare(final TrainingStatusHistoryDetails lhs,
        TrainingStatusHistoryDetails rhs) {
        return rhs.dateTime.compareTo(lhs.dateTime);
      }
    });

    TrainingMemberStatusHistoryDetailsList sortedTrainingMemberStatusHistoryDetailsList = new TrainingMemberStatusHistoryDetailsList();

    for (TrainingStatusHistoryDetails trainingStatusHistoryDetails : trainingMemberStatusHistoryDetailsList) {
      sortedTrainingMemberStatusHistoryDetailsList.historyDetails.addRef(
        trainingStatusHistoryDetails);
    }

    return sortedTrainingMemberStatusHistoryDetailsList;
  }
  
  // BEGIN, CR00137832, ASN
  
  /**
   * Retrieves training program details for a provider group member.
   *
   * @param trainingProgramMemberKey
   * Contains training program member ID.
   *
   * @return Contains training program details for a
   * provider member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingPartyDetails viewProviderGroupMemberTrainingProgramDetails(
    TrainingProgramMemberKey trainingProgramMemberKey) throws AppException, InformationalException {
    TrainingPartyDetails partyDetails = new TrainingPartyDetails();

    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      trainingProgramMemberKey.trainingProgramMemberID);
  
    partyDetails.completion = trainingProgramMember.getCompletion().toString();
    partyDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
    if (trainingProgramMember.getCreditsAchieved() > 0) {
      partyDetails.creditsAchievedString = String.valueOf(
        trainingProgramMember.getCreditsAchieved());
    }
    Date completedDate = trainingProgramMember.getDateCompleted();

    partyDetails.dateCompleted = completedDate;
    partyDetails.partyConcernRoleID = trainingProgramMember.getPartyConcernRole().getID();
    partyDetails.partyVersionNo = trainingProgramMember.getVersionNo();
    partyDetails.status = trainingProgramMember.getLifecycleState().toString();
    partyDetails.trainingProgramID = trainingProgramMember.getTrainingProgram().getID();
    partyDetails.trainingProgramMemberID = trainingProgramMember.getID();
    partyDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
    if (trainingProgramMember.getUnitsCompleted() > 0) {
      partyDetails.unitsCompletedString = String.valueOf(
        trainingProgramMember.getUnitsCompleted());
    }
    partyDetails.unitsRemaining = trainingProgramMember.getUnitsRequired()
      - trainingProgramMember.getUnitsCompleted();
    partyDetails.unitsRequired = trainingProgramMember.getUnitsRequired();

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramMember.getTrainingProgram();

    if (trainingProgramMember.getLifecycleState().equals(
      TRAININGPROGRAMPARTYSTATUSEntry.COMPLETE)) {

      List<TrainingCredit> trainingCredits = trainingCreditDAO.searchBy(
        trainingProgramMember.getTrainingProgram().getTraining());
       
      if (trainingCredits.size() > 0) {
        int days = trainingProgram.getTrainingValidDays();

        if (days > 0) {
          partyDetails.validTill = completedDate.addDays(days);
        }
      }
    }
    partyDetails.waiverExpiryDate = trainingProgramMember.getWaiverExpiryDate();

    partyDetails.trainingProgramDetails.authorizedFrom = trainingProgram.getDateRange().start();
    partyDetails.trainingProgramDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();
    partyDetails.trainingProgramDetails.toBeCompletedBy = trainingProgram.getDateRange().end();
    if (trainingProgram.getTraining() == null) {
      partyDetails.trainingProgramDetails.trainingName = trainingProgram.getTrainingName();
      partyDetails.trainingProgramDetails.trainingRegisteredInd = false;
    } else {
      partyDetails.trainingProgramDetails.trainingName = trainingProgram.getTraining().getName();
      partyDetails.trainingProgramDetails.trainingID = trainingProgram.getTraining().getID();
      partyDetails.trainingProgramDetails.trainingRegisteredInd = true;
    }
    partyDetails.trainingProgramDetails.trainingProgramID = trainingProgram.getID();
    partyDetails.trainingProgramDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();

    if (trainingProgram.getTrainingProvider() != null) {
      partyDetails.trainingProgramDetails.trainingProvider = trainingProgram.getTrainingProvider().getName();
    }

    partyDetails.trainingProgramDetails.unitAmount = trainingProgram.getUnitAmount();
    partyDetails.trainingProgramDetails.versionNo = trainingProgram.getVersionNo();

    return partyDetails;
  }
  
  /**
   * Retrieves training program details not managed through agency for a
   * provider group member.
   *
   * @param trainingProgramMemberKey
   * Training program member key.
   *
   * @return Training program details for a provider group member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramPartyCompletedDetails viewMemberCompletedTrainingDetailsNotManagedByAgency(
    TrainingProgramMemberKey trainingProgramMemberKey) throws AppException, InformationalException {

    TrainingProgramPartyCompletedDetails trainingProgramPartyCompletedDetails = new TrainingProgramPartyCompletedDetails();

    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      trainingProgramMemberKey.trainingProgramMemberID);
   
    trainingProgramPartyCompletedDetails.status = trainingProgramMember.getLifecycleState().getCode();
    trainingProgramPartyCompletedDetails.dateCompleted = trainingProgramMember.getDateCompleted();
    trainingProgramPartyCompletedDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
    trainingProgramPartyCompletedDetails.trainingProgramMemberID = trainingProgramMember.getID();
    trainingProgramPartyCompletedDetails.trainingProgramMemberVersionNo = trainingProgramMember.getVersionNo();
    trainingProgramPartyCompletedDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
    
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramMember.getTrainingProgram();

    trainingProgramPartyCompletedDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();

    if (trainingProgram.getTraining() == null) {
      trainingProgramPartyCompletedDetails.trainingName = trainingProgram.getTrainingName();
      trainingProgramPartyCompletedDetails.trainingRegisteredInd = false;
    } else {
      trainingProgramPartyCompletedDetails.trainingName = trainingProgram.getTraining().getName();
      trainingProgramPartyCompletedDetails.trainingID = trainingProgram.getTraining().getID();
      trainingProgramPartyCompletedDetails.trainingRegisteredInd = true;
    }
    trainingProgramPartyCompletedDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();

    if (trainingProgram.getTrainingProvider() != null) {
      trainingProgramPartyCompletedDetails.trainingProviderName = trainingProgram.getTrainingProvider().getName();
    } else {
      trainingProgramPartyCompletedDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
    }
    trainingProgramPartyCompletedDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();

    return trainingProgramPartyCompletedDetails;
  }

  // END, CR00137832
 
  // BEGIN, CR00234644, GP
  /**
   * Sets the training program details.
   *
   * @param trainingProgramList
   * Completed or managed training program list which needs to be set.
   * @param trainingProgramSummaryDetailsList
   * Struct to which values are to be set.
   * @param booleanValue
   * Indicates whether training program is a completed training program
   * or managed training program.
   */
  protected void setTrainingProgramDetails(
    final TrainingProgramList trainingProgramList,
    final TrainingProgramSummaryDetailsList trainingProgramSummaryDetailsList,
    final Boolean booleanValue) {

    for (final TrainingSummaryDetails trainingSummaryDetails : trainingProgramList.trainingSummaryList.items()) {
      TrainingProgramSummaryDetails trainingProgramSummaryDetails = new TrainingProgramSummaryDetails();

      curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
        trainingSummaryDetails.trainingProgramID);
      
      trainingProgramSummaryDetails.managedThroughAgency = booleanValue.booleanValue();
      trainingProgramSummaryDetails.referenceNumber = trainingSummaryDetails.referenceNumber;
      trainingProgramSummaryDetails.trainingName = trainingSummaryDetails.trainingName;
      trainingProgramSummaryDetails.trainingProgramID = trainingSummaryDetails.trainingProgramID;
      trainingProgramSummaryDetails.trainingProgramMemberID = trainingSummaryDetails.trainingProgramMemberID;
      trainingProgramSummaryDetails.trainingProgramMemberVersionNo = trainingSummaryDetails.trainingProgramMemberVersionNo;
      trainingProgramSummaryDetails.trainingProgramVersionNo = trainingSummaryDetails.trainingProgramVersionNo;
      trainingProgramSummaryDetails.trainingRegisteredInd = trainingSummaryDetails.trainingRegisteredInd;
      trainingProgramSummaryDetails.trainingID = trainingSummaryDetails.trainingID;
      trainingProgramSummaryDetails.trainingProgramStatus = trainingSummaryDetails.trainingProgramStatus;

      // BEGIN, CR00246961, GP
      if (null != trainingProgram.getTrainingProvider()) {
        trainingProgramSummaryDetails.trainingProviderDetails = trainingProgram.getTrainingProvider().getName();
      } else {
        trainingProgramSummaryDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
      }
      // END, CR00246961
      
      // BEGIN, CR00306259, MR
      if (trainingProgramSummaryDetails.managedThroughAgency) {
        trainingProgramSummaryDetails.editActionURL = CPMConstants.kModifyTrainingProgramForProviderGroupPage;
      } else {
        trainingProgramSummaryDetails.editActionURL = CPMConstants.kUpdateCompletedTrainingForProviderGroupPage;
      }

      // END, CR00306259
      
      trainingProgramSummaryDetailsList.trainingProgramSummaryDetails.addRef(
        trainingProgramSummaryDetails);
    }
  }

  /**
   * Sorts a set of Training Programs by Training Name.
   *
   * @param unsortedTrainingProgramSummaryDetailsList
   * The set of unsorted Training Programs.
   *
   * @return A list of Training Programs sorted by Training Name.
   */
  protected TrainingProgramSummaryDetailsList sortTrainingPrograms(
    final TrainingProgramSummaryDetailsList unsortedTrainingProgramSummaryDetailsList) {

    List<TrainingProgramSummaryDetails> trainingProgramSummaryDetailsList = new ArrayList<TrainingProgramSummaryDetails>();

    for (final TrainingProgramSummaryDetails trainingProgramSummaryDetails : 
      unsortedTrainingProgramSummaryDetailsList.trainingProgramSummaryDetails.items()) {
      trainingProgramSummaryDetailsList.add(trainingProgramSummaryDetails);
    }

    Collections.sort(trainingProgramSummaryDetailsList,
      new Comparator<TrainingProgramSummaryDetails>() {
      public int compare(final TrainingProgramSummaryDetails lhs,
        TrainingProgramSummaryDetails rhs) {
        return lhs.trainingName.compareTo(rhs.trainingName);
      }
    });

    TrainingProgramSummaryDetailsList sortedTrainingProgramSummaryDetailsList = new TrainingProgramSummaryDetailsList();

    for (final TrainingProgramSummaryDetails trainingProgramSummaryDetails : trainingProgramSummaryDetailsList) {
      sortedTrainingProgramSummaryDetailsList.trainingProgramSummaryDetails.addRef(
        trainingProgramSummaryDetails);
    }
    return sortedTrainingProgramSummaryDetailsList;
  }
  
  /**
   * Sets the training program details of provider group member.
   *
   * @param trainingProgramList
   * Training program group member details which needs to be set.
   * @param trainingProgramSummaryDetailsList
   * Struct to which training program details are to be set.
   */
  protected void setTrainingProgramList(
    final TrainingProgramList trainingProgramList,
    final TrainingProgramSummaryDetailsList trainingProgramSummaryDetailsList) {

    for (final TrainingSummaryDetails trainingSummaryDetails : trainingProgramList.trainingSummaryList.items()) {

      TrainingProgramSummaryDetails trainingProgramSummaryDetails = new TrainingProgramSummaryDetails();
      curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
        trainingSummaryDetails.trainingProgramID);

      trainingProgramSummaryDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();

      trainingProgramSummaryDetails.referenceNumber = trainingSummaryDetails.referenceNumber;
      trainingProgramSummaryDetails.trainingProgramVersionNo = trainingSummaryDetails.trainingProgramVersionNo;
      trainingProgramSummaryDetails.trainingProgramID = trainingSummaryDetails.trainingProgramID;
      trainingProgramSummaryDetails.trainingName = trainingSummaryDetails.trainingName;
      trainingProgramSummaryDetails.trainingRegisteredInd = trainingSummaryDetails.trainingRegisteredInd;
      trainingProgramSummaryDetails.trainingID = trainingSummaryDetails.trainingID;
      trainingProgramSummaryDetails.trainingProgramStatus = trainingProgram.getLifecycleState().getCode();
      trainingProgramSummaryDetails.trainingProgramMemberID = trainingSummaryDetails.trainingProgramMemberID;
      trainingProgramSummaryDetails.trainingProgramMemberVersionNo = trainingSummaryDetails.trainingProgramMemberVersionNo;
      trainingProgramSummaryDetails.trainingProgramDateCompleted = trainingSummaryDetails.trainingProgramDateCompleted;
      trainingProgramSummaryDetails.trainingProgramOwnerType = trainingSummaryDetails.trainingProgramOwnerType;
      trainingProgramSummaryDetails.trainingProgramOwnerID = trainingSummaryDetails.trainingProgramOwnerID;
      trainingProgramSummaryDetails.trainingProgramOwnerIsProvider = trainingSummaryDetails.trainingProgramOwnerIsProvider;
      trainingProgramSummaryDetails.trainingProgramOwnerIsProviderGroup = trainingSummaryDetails.trainingProgramOwnerIsProviderGroup;
      trainingProgramSummaryDetails.trainingProgramOwnerIsMember = trainingSummaryDetails.trainingProgramOwnerIsMember;
      
      // BEGIN, CR00246961, GP
      if (null != trainingProgram.getTrainingProvider()) {
        trainingProgramSummaryDetails.trainingProviderDetails = trainingProgram.getTrainingProvider().getName();
      } else {
        trainingProgramSummaryDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
      }

      if (trainingProgramSummaryDetails.managedThroughAgency) {
        trainingProgramSummaryDetails.editActionURL = CPMConstants.kEditProviderGroupMemberTrainingProgram;
        trainingProgramSummaryDetails.deleteActionURL = CPMConstants.kDeleteProviderGroupMemberTrainingProgram;
        trainingProgramSummaryDetails.viewActionURL = CPMConstants.kViewProviderGroupMemberTrainingProgram;
      } else {
        trainingProgramSummaryDetails.editActionURL = CPMConstants.kEditCompletedProviderGroupMemberTrainingProgram;
        trainingProgramSummaryDetails.deleteActionURL = CPMConstants.kDeleteProviderGroupMemberTrainingProgram;
        trainingProgramSummaryDetails.viewActionURL = CPMConstants.kViewCompletedProviderGroupMemberTrainingProgram;
      }
      // END, CR00246961
      
      trainingProgramSummaryDetailsList.trainingProgramSummaryDetails.addRef(
        trainingProgramSummaryDetails);
    }
  }
  // END, CR00234644
}
