/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.google.inject.Inject;

import curam.certification.impl.Certification;
import curam.certification.impl.CertificationChangeHistory;
import curam.certification.impl.CertificationChangeHistoryDAO;
import curam.certification.impl.CertificationDAO;
import curam.codetable.CREDITTYPE;
import curam.codetable.EXTERNALISSUER;
import curam.codetable.VALIDITYPERIODUNITS;
import curam.codetable.impl.CERTIFICATIONCATEGORYEntry;
import curam.codetable.impl.CERTIFICATIONTYPEEntry;
import curam.codetable.impl.CREDITTYPEEntry;
import curam.codetable.impl.EXTERNALISSUEREntry;
import curam.codetable.impl.VALIDITYPERIODUNITSEntry;
import curam.core.fact.OrganisationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.intf.Organisation;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.struct.OrganisationUnitDtls;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.struct.OrganisationDtls;
import curam.core.struct.OrganisationID;
import curam.core.struct.OrganisationKey;
import curam.cpm.facade.struct.CertificationDetails;
import curam.cpm.facade.struct.CertificationDetailsList;
import curam.cpm.facade.struct.CertificationHistoryDetails;
import curam.cpm.facade.struct.CertificationHistoryDetailsList;
import curam.cpm.facade.struct.CertificationHistoryVersionDetails;
import curam.cpm.facade.struct.CertificationHistoryVersionDetailsList;
import curam.cpm.facade.struct.VersionNo;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.CertificationKey;
import curam.message.impl.CERTIFICATIONExceptionCreator;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.type.CodeTable;


/**
 * Facade layer class having API for Maintain Certifications.
 */
public abstract class MaintainCertifications extends curam.cpm.facade.base.MaintainCertifications {

  /*
   * Certification DAO
   */
  @Inject
  protected CertificationDAO certificationDAO;

  /*
   * Certification Change History DAO
   */
  @Inject
  protected CertificationChangeHistoryDAO certificationChangeHistoryDAO;

  // BEGIN, CR00237067, GP
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;
  // END, CR00237067

  /**
   * Bootstrap dependency injection for this class
   */
  public MaintainCertifications() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a new Certification record.
   *
   * @param certificationDetails
   * Contains the certification details
   *
   * @return Contains the unique identifier of the newly created certification
   * record.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public CertificationKey createCertification(
    CertificationDetails certificationDetails) throws AppException,
      InformationalException {

    CertificationKey certificationKey = new CertificationKey();

    SystemUser systemUserObj = SystemUserFactory.newInstance();

    if (certificationDetails.creditsRequiredString.trim().length()
      > CPMConstants.kZeroLong) {
      try {
        // Convert credits required to short
        certificationDetails.creditsRequired = Short.parseShort(
          certificationDetails.creditsRequiredString);

      } catch (NumberFormatException exception) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_CREDITS_REQUIRED_IS_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }

      if (certificationDetails.creditsRequired <= CPMConstants.kZeroLong) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_CREDITS_REQUIRED_MUST_BE_GREATER_THAN_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

        ValidationHelper.failIfErrorsExist();
      }
    }
    if (certificationDetails.validityPeriodString.trim().length()
      > CPMConstants.kZeroLong) {
      try {
        // Convert Validity Period to short
        certificationDetails.validityPeriod = Short.parseShort(
          certificationDetails.validityPeriodString);

      } catch (NumberFormatException exception) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_VALIDITY_PERIOD_IS_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      }
    }

    final Certification certification = certificationDAO.newInstance();

    certification.setCertificationType(
      CERTIFICATIONTYPEEntry.get(certificationDetails.certificationType));

    certification.setCategory(
      CERTIFICATIONCATEGORYEntry.get(certificationDetails.category));
    certification.setCreditsRequired(certificationDetails.creditsRequired);
    certification.setCreditType(
      CREDITTYPEEntry.get(certificationDetails.creditType));
    certification.setIssuedByAgency(certificationDetails.issuedByAgency);
    certification.setExternalIssuer(
      EXTERNALISSUEREntry.get(certificationDetails.externalIssuer));
    certification.setOrganisationUnitId(certificationDetails.organisationUnitID);
    certification.setValidityPeriod(certificationDetails.validityPeriod);
    certification.setValidityPeriodUnits(
      VALIDITYPERIODUNITSEntry.get(certificationDetails.validityPeriodUnit));

    certification.setUser(systemUserObj.getUserDetails().userName);
    certification.insert();

    certificationKey.certificationID = certification.getID();

    ValidationHelper.failIfErrorsExist();
    return certificationKey;
  }

  /**
   * Deletes a certification record logically.
   *
   * @param certificationKey
   * Contains the certification id.
   * @param versionNo
   * Version number.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @SuppressWarnings(CPMConstants.kUnused)
  public void deleteCertification(CertificationKey certificationKey,
    VersionNo versionNo) throws AppException, InformationalException {

    final Certification certification = certificationDAO.get(
      certificationKey.certificationID);

    certification.cancel(certification.getVersionNo());

  }

  /**
   * Lists certification records.
   *
   * @return CertificationDetailsList Contains a list of active certification
   * records
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CertificationDetailsList listCertification() throws AppException,
      InformationalException {

    CertificationDetailsList certificationDetailsList = new CertificationDetailsList();

    // BEGIN CR00121855, SSH
    List<Certification> certification = certificationDAO.getCertifications();

    // Sort the certification records by category code
    certification = sortCertifications(certification);

    Certification[] certificationArray = new Certification[certification.size()];

    certificationArray = certification.toArray(certificationArray);
    int size = certification.size();

    for (int index = 0; index < size; index++) {

      CertificationDetails certificationDetails = new CertificationDetails();

      certificationDetails.certificationType = certificationArray[index].getCertificationType().getCode();
      certificationDetails.category = certificationArray[index].getCategory().getCode();
      certificationDetails.creditsRequired = certificationArray[index].getCreditsRequired();
      if (certificationArray[index].getCreditsRequired()
        > CPMConstants.kZeroLong) {
        certificationDetails.creditsRequiredString = CPMConstants.kEmptyString
          + certificationArray[index].getCreditsRequired();
      }
      certificationDetails.creditType = certificationArray[index].getCreditType().getCode();

      certificationDetails.validityPeriod = certificationArray[index].getValidityPeriod();
      if (certificationArray[index].getValidityPeriod()
        > CPMConstants.kZeroLong) {
        certificationDetails.validityPeriodString = CPMConstants.kEmptyString
          + certificationArray[index].getValidityPeriod();
      }
      certificationDetails.validityPeriodUnit = certificationArray[index].getValidityPeriodUnits().getCode();

      certificationDetails.certificationId = certificationArray[index].getID();
      certificationDetails.recordStatus = certificationArray[index].getLifecycleState().getCode();
      if (certificationArray[index].isIssuedByAgency()) {
        Organisation organisationObj = OrganisationFactory.newInstance();
        OrganisationKey organisationKey = new OrganisationKey();
        OrganisationID organisationID = new OrganisationID();

        organisationID = organisationObj.readOrganisationID();
        organisationKey.organisationID = organisationID.organisationID;
        OrganisationDtls organisationDtls = new OrganisationDtls();

        organisationDtls = organisationObj.read(organisationKey);
        certificationDetails.certificationIssuer = organisationDtls.name;

      } else if (!(certificationArray[index].getOrganisationUnitId()
        == CPMConstants.kZeroLong)) {
        OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

        OrganisationUnitKey key = new OrganisationUnitKey();

        key.organisationUnitID = certificationArray[index].getOrganisationUnitId();

        certificationDetails.certificationIssuer = organisationUnitObj.read(key).name;

      } else {

        certificationDetails.certificationIssuer = CodeTable.getOneItem(
          EXTERNALISSUER.TABLENAME,
          certificationArray[index].getExternalIssuer().getCode());

      }

      certificationDetailsList.dtls.addRef(certificationDetails);
    }
    return certificationDetailsList;

  }

  /**
   * Sorts the certification records on the basis of the certification category.
   *
   * @param certification
   * The certification records
   * @return Sorted list of certification records.
   */
  // BEGIN, CR00177241, PM
  protected List<Certification> sortCertifications(
    // END. CR00177241
    List<Certification> certification) throws InformationalException {

    final List<Certification> certificationDetails = new ArrayList<Certification>(
      certification);

    Collections.sort(certificationDetails,
      new Comparator<Certification>() {
      public int compare(final Certification lhs, Certification rhs) {

        return lhs.getCategory().toUserLocaleString().compareTo(
          rhs.getCategory().toUserLocaleString());
      }
    });

    return certificationDetails;
  }

  // END CR00121855
  /**
   * To update the certification record.
   *
   * @param certificationDetails
   * Contains the new certification details
   *
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public void updateCertification(CertificationDetails certificationDetails)
    throws AppException, InformationalException {

    SystemUser systemUserObj = SystemUserFactory.newInstance();

    if (certificationDetails.creditsRequiredString.trim().length()
      > CPMConstants.kZeroLong) {
      try {
        // Convert credits required to short
        certificationDetails.creditsRequired = Short.parseShort(
          certificationDetails.creditsRequiredString);

      } catch (NumberFormatException exception) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_CREDITS_REQUIRED_IS_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      }

      if (certificationDetails.creditsRequired <= CPMConstants.kZeroLong) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_CREDITS_REQUIRED_MUST_BE_GREATER_THAN_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

        ValidationHelper.failIfErrorsExist();
      }
    }
    if (certificationDetails.validityPeriodString.trim().length()
      > CPMConstants.kZeroLong) {
      try {
        // Convert validity period to short
        certificationDetails.validityPeriod = Short.parseShort(
          certificationDetails.validityPeriodString);

      } catch (NumberFormatException exception) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_VALIDITY_PERIOD_IS_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }
    final Certification certification = certificationDAO.get(
      certificationDetails.certificationId);

    certification.setCertificationType(
      CERTIFICATIONTYPEEntry.get(certificationDetails.certificationType));
    certification.setCategory(
      CERTIFICATIONCATEGORYEntry.get(certificationDetails.category));
    certification.setCreditsRequired(certificationDetails.creditsRequired);
    certification.setCreditType(
      CREDITTYPEEntry.get(certificationDetails.creditType));
    certification.setIssuedByAgency(certificationDetails.issuedByAgency);
    certification.setExternalIssuer(
      EXTERNALISSUEREntry.get(certificationDetails.externalIssuer));
    certification.setOrganisationUnitId(certificationDetails.organisationUnitID);
    certification.setValidityPeriod(certificationDetails.validityPeriod);
    certification.setValidityPeriodUnits(
      VALIDITYPERIODUNITSEntry.get(certificationDetails.validityPeriodUnit));
    certification.setUser(systemUserObj.getUserDetails().userName);
    ValidationHelper.failIfErrorsExist();
    certification.modify(certification.getVersionNo());

  }

  /**
   * To view a certification record.
   *
   * @param certificationKey
   * Contains the certification id of the certification record which
   * needs to be viewed.
   *
   * @return Contains the certification details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public CertificationDetails viewCertification(
    CertificationKey certificationKey) throws AppException,
      InformationalException {

    CertificationDetails certificationDetails = new CertificationDetails();

    if (certificationKey.certificationID != 0) {
      final Certification certification = certificationDAO.get(
        certificationKey.certificationID);

      certificationDetails.certificationType = certification.getCertificationType().getCode();
      certificationDetails.category = certification.getCategory().getCode();
      if (certification.getCreditsRequired() > CPMConstants.kZeroLong) {
        certificationDetails.creditsRequiredString = CPMConstants.kEmptyString
          + certification.getCreditsRequired();
      }
      certificationDetails.creditsRequired = certification.getCreditsRequired();
      certificationDetails.creditType = certification.getCreditType().getCode();
      if (certification.getValidityPeriod() > CPMConstants.kZeroLong) {
        certificationDetails.validityPeriodString = CPMConstants.kEmptyString
          + certification.getValidityPeriod();
      }
      certificationDetails.validityPeriod = certification.getValidityPeriod();
      certificationDetails.validityPeriodUnit = certification.getValidityPeriodUnits().getCode();
      certificationDetails.certificationId = certification.getID();
      certificationDetails.recordStatus = certification.getLifecycleState().getCode();
      certificationDetails.certificationId = certification.getID();
      certificationDetails.versionNo = certification.getVersionNo();
      certificationDetails.issuedByAgency = certification.isIssuedByAgency();
      if (certification.isIssuedByAgency()) {
        Organisation organisationObj = OrganisationFactory.newInstance();
        OrganisationKey organisationKey = new OrganisationKey();
        OrganisationID organisationID = new OrganisationID();

        organisationID = organisationObj.readOrganisationID();
        organisationKey.organisationID = organisationID.organisationID;
        OrganisationDtls organisationDtls = new OrganisationDtls();

        organisationDtls = organisationObj.read(organisationKey);
        certificationDetails.certificationIssuer = organisationDtls.name;

      } else if (certification.getOrganisationUnitId() != 0) {
        OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();
        OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID = certification.getOrganisationUnitId();
        OrganisationUnitDtls organisationUnitDtls = new OrganisationUnitDtls();

        organisationUnitDtls = organisationUnitObj.read(organisationUnitKey);

        // BEGIN CR00121470, NRV
        certificationDetails.organisationUnitName = organisationUnitDtls.name;
        // END CR00121470

        // BEGIN CR00131599 KR
        certificationDetails.certificationIssuer = organisationUnitDtls.name;
        // END CR00131599

        // BEGIN, CR00200754, GP
        certificationDetails.organisationUnitID = certification.getOrganisationUnitId();
        // END, CR00200754
      } else {
        certificationDetails.certificationIssuer = CodeTable.getOneItem(
          EXTERNALISSUER.TABLENAME, certification.getExternalIssuer().getCode());
        // BEGIN, CR00137968, AK
        certificationDetails.externalIssuer = certification.getExternalIssuer().getCode();
        // END, CR00137968
      }
    }
    return certificationDetails;
  }

  // BEGIN, CR00237067, GP
  /**
   * Lists certification change history records .
   *
   * @param certificationKey
   * Contains the unique identifier of the certification record.
   *
   * @return CertificationDetailsList Contains a list of certification change
   * history records
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listCertificationHistory(CertificationKey)}. This
   * method is not useful for displaying user full name in list of
   * certification histories. Hence this method is deprecated. The
   * newly added method will give the option to the user to display
   * the user full name. See release note: CR00237067.
   */
  @Deprecated
  // END, CR00237067
  public CertificationHistoryDetailsList listCertificationChangeHistory(
    CertificationKey certificationKey) throws AppException,
      InformationalException {
    CertificationHistoryDetailsList certificationHistoryDetailsList = new CertificationHistoryDetailsList();

    for (final CertificationChangeHistory certificationChangeHistory :

      certificationChangeHistoryDAO.getCertificationHistory(certificationKey)) {

      CertificationHistoryDetails certificationHistoryDetails = new CertificationHistoryDetails();

      certificationHistoryDetails.certificationType = certificationChangeHistory.getCertificationType().getCode();
      certificationHistoryDetails.category = certificationChangeHistory.getCategory().getCode();
      certificationHistoryDetails.validityPeriod = certificationChangeHistory.getValidityPeriod();
      certificationHistoryDetails.dateTime = certificationChangeHistory.getDateTime();
      certificationHistoryDetails.userName = certificationChangeHistory.getUser();
      certificationHistoryDetails.recordStatus = certificationChangeHistory.getLifecycleState().getCode();
      if (certificationChangeHistory.getValidityPeriod()
        > CPMConstants.kZeroLong) {
        certificationHistoryDetails.validityPeriodString = CPMConstants.kEmptyString
          + certificationChangeHistory.getValidityPeriod();
      }
      certificationHistoryDetails.validityPeriodUnit = certificationChangeHistory.getValidityPeriodUnits().getCode();

      if (certificationChangeHistory.isIssuedByAgency()) {
        Organisation organisationObj = OrganisationFactory.newInstance();
        OrganisationKey organisationKey = new OrganisationKey();
        OrganisationID organisationID = new OrganisationID();

        organisationID = organisationObj.readOrganisationID();
        organisationKey.organisationID = organisationID.organisationID;
        OrganisationDtls organisationDtls = new OrganisationDtls();

        organisationDtls = organisationObj.read(organisationKey);
        certificationHistoryDetails.certificationIssuer = organisationDtls.name;

      } else if (!(certificationChangeHistory.getOrganisationUnitId()
        == CPMConstants.kZeroLong)) {
        OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

        OrganisationUnitKey key = new OrganisationUnitKey();

        key.organisationUnitID = certificationChangeHistory.getOrganisationUnitId();

        certificationHistoryDetails.certificationIssuer = organisationUnitObj.read(key).name;
      } else {
        // BEGIN, CR00137968, AK
        certificationHistoryDetails.certificationIssuer = CodeTable.getOneItem(
          EXTERNALISSUER.TABLENAME,
          certificationChangeHistory.getExternalIssuer().getCode());
        // END, CR00137968
      }

      certificationHistoryDetailsList.details.addRef(
        certificationHistoryDetails);
    }
    return certificationHistoryDetailsList;

  }

  // BEGIN, CR00237067, GP
  /**
   * Lists the certification history for a given certification.
   *
   * @param certificationKey
   *
   * @return A list of certification histories for a given certification.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CertificationHistoryVersionDetailsList listCertificationHistory(
    final CertificationKey certificationKey) throws AppException,
      InformationalException {

    CertificationHistoryVersionDetailsList certificationHistoryVersionDetailsList = new CertificationHistoryVersionDetailsList();

    for (final CertificationChangeHistory certificationChangeHistory :
      certificationChangeHistoryDAO.getCertificationHistory(certificationKey)) {

      CertificationHistoryVersionDetails certificationHistoryVersionDetails = new CertificationHistoryVersionDetails();

      certificationHistoryVersionDetails.certificationType = certificationChangeHistory.getCertificationType().getCode();
      certificationHistoryVersionDetails.category = certificationChangeHistory.getCategory().getCode();
      certificationHistoryVersionDetails.validityPeriod = certificationChangeHistory.getValidityPeriod();
      certificationHistoryVersionDetails.dateTime = certificationChangeHistory.getDateTime();
      certificationHistoryVersionDetails.userName = certificationChangeHistory.getUser();

      User user = userDAO.get(certificationChangeHistory.getUser());

      certificationHistoryVersionDetails.userFullName = user.getFullName();

      certificationHistoryVersionDetails.recordStatus = certificationChangeHistory.getLifecycleState().getCode();

      if (certificationChangeHistory.getValidityPeriod()
        > CPMConstants.kZeroLong) {

        certificationHistoryVersionDetails.validityPeriodString = CPMConstants.kEmptyString
          + certificationChangeHistory.getValidityPeriod();
      }

      certificationHistoryVersionDetails.validityPeriodUnit = certificationChangeHistory.getValidityPeriodUnits().getCode();

      if (certificationChangeHistory.isIssuedByAgency()) {
        Organisation organisationObj = OrganisationFactory.newInstance();
        OrganisationKey organisationKey = new OrganisationKey();
        OrganisationID organisationID = new OrganisationID();

        organisationID = organisationObj.readOrganisationID();
        organisationKey.organisationID = organisationID.organisationID;
        OrganisationDtls organisationDtls = new OrganisationDtls();

        organisationDtls = organisationObj.read(organisationKey);
        certificationHistoryVersionDetails.certificationIssuer = organisationDtls.name;

      } else if (0 != certificationChangeHistory.getOrganisationUnitId()) {

        OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

        OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID = certificationChangeHistory.getOrganisationUnitId();

        certificationHistoryVersionDetails.certificationIssuer = organisationUnitObj.read(organisationUnitKey).name;
      } else {

        certificationHistoryVersionDetails.certificationIssuer = CodeTable.getOneItem(
          EXTERNALISSUER.TABLENAME,
          certificationChangeHistory.getExternalIssuer().getCode());
      }

      certificationHistoryVersionDetailsList.certificationHistoryVersionDetails.addRef(
        certificationHistoryVersionDetails);
    }

    return certificationHistoryVersionDetailsList;
  }

  // END, CR00237067

  // BEGIN CR00121465 KR
  /**
   * Lists certification records.
   *
   * @return CertificationDetailsList Contains a list of active certification
   * records
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CertificationDetailsList listActiveCertification()
    throws AppException, InformationalException {

    CertificationDetailsList certificationDetailsList = new CertificationDetailsList();

    for (final Certification certification : certificationDAO.getActiveCertifications()) {

      CertificationDetails certificationDetails = new CertificationDetails();

      certificationDetails.certificationType = certification.getCertificationType().getCode();
      certificationDetails.category = certification.getCategory().getCode();
      certificationDetails.creditsRequired = certification.getCreditsRequired();

      /*
       * if(certification.getCreditsRequired() > CPMConstants.kZeroLong) {
       * certificationDetails.creditsRequiredString=
       * CPMConstants.kEmptyString+certification.getCreditsRequired(); }
       */
      certificationDetails.creditType = certification.getCreditType().getCode();

      certificationDetails.validityPeriod = certification.getValidityPeriod();

      /*
       * if(certification.getValidityPeriod() > CPMConstants.kZeroLong) {
       * certificationDetails.validityPeriodString =
       * CPMConstants.kEmptyString+certification.getValidityPeriod(); }
       */
      certificationDetails.validityPeriodUnit = certification.getValidityPeriodUnits().getCode();

      certificationDetails.certificationId = certification.getID();
      certificationDetails.recordStatus = certification.getLifecycleState().getCode();
      if (certification.isIssuedByAgency()) {
        Organisation organisationObj = OrganisationFactory.newInstance();
        OrganisationKey organisationKey = new OrganisationKey();
        OrganisationID organisationID = new OrganisationID();

        organisationID = organisationObj.readOrganisationID();
        organisationKey.organisationID = organisationID.organisationID;
        OrganisationDtls organisationDtls = new OrganisationDtls();

        organisationDtls = organisationObj.read(organisationKey);
        certificationDetails.certificationIssuer = organisationDtls.name;

      } else if (!(certification.getOrganisationUnitId()
        == CPMConstants.kZeroLong)) {
        OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

        OrganisationUnitKey key = new OrganisationUnitKey();

        key.organisationUnitID = certification.getOrganisationUnitId();

        certificationDetails.certificationIssuer = organisationUnitObj.read(key).name;

      } else {

        certificationDetails.certificationIssuer = CodeTable.getOneItem(
          EXTERNALISSUER.TABLENAME, certification.getExternalIssuer().getCode());

      }

      // BEGIN CR00127289 KR
      certificationDetails.creditsRequiredString = certificationDetails.creditsRequired
        + CPMConstants.kSpace
        + CodeTable.getOneItem(CREDITTYPE.TABLENAME,
        certificationDetails.creditType);

      certificationDetails.validityPeriodString = certificationDetails.validityPeriod
        + CPMConstants.kSpace
        + CodeTable.getOneItem(VALIDITYPERIODUNITS.TABLENAME,
        certificationDetails.validityPeriodUnit);

      if (certificationDetails.creditsRequired == 0
        && certificationDetails.creditType.equals(CPMConstants.kEmptyString)) {
        certificationDetails.creditsRequiredString = CPMConstants.kEmptyString;
      }

      if (certificationDetails.validityPeriod == 0
        && certificationDetails.validityPeriodUnit.equals(
          CPMConstants.kEmptyString)) {
        certificationDetails.validityPeriodString = CPMConstants.kEmptyString;
      }
      // END CR00127289
      certificationDetailsList.dtls.addRef(certificationDetails);
    }
    return certificationDetailsList;

  }
  // END CR00121465
}
