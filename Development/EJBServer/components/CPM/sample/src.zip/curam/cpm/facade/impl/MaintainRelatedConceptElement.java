/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.core.sl.struct.WizardStateID;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.RelatedConceptDetails;
import curam.cpm.facade.struct.RelatedConceptDetailsList;
import curam.cpm.facade.struct.RelatedConceptWizMenuDetails;
import curam.cpm.facade.struct.RemoveInEditTermDetails;
import curam.cpm.facade.struct.SearchTaxonomyTermsWizForRelatedConcept;
import curam.cpm.facade.struct.TaxonomyTermDetails;
import curam.cpm.facade.struct.TaxonomyTermRelatedConceptDetails;
import curam.cpm.facade.struct.TaxonomyTermWizDetailsList;
import curam.cpm.facade.struct.ViewRelatedConceptDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.RelatedConceptKey;
import curam.message.TAXONOMYTERM;
import curam.message.impl.TAXONOMYTERMExceptionCreator;
import curam.taxonomy.impl.RelatedConceptElement;
import curam.taxonomy.impl.RelatedConceptElementDAO;
import curam.taxonomy.impl.RelatedConceptWizState;
import curam.taxonomy.impl.RelatedConceptWizStateImpl;
import curam.taxonomy.impl.TAXONOMY_VERSION_STATUSEntry;
import curam.taxonomy.impl.TaxonomyConstants;
import curam.taxonomy.impl.TaxonomyInEditData;
import curam.taxonomy.impl.TaxonomyInEditDataConverter;
import curam.taxonomy.impl.TaxonomyInEditDataDAO;
import curam.taxonomy.impl.TaxonomyVersion;
import curam.taxonomy.impl.TaxonomyVersionDAO;
import curam.taxonomy.util.impl.RelatedConceptData;
import curam.taxonomy.util.impl.TextTranslation;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.StringHelper;


/**
 * Facade class having API's for maintaining the in edit related concepts for
 * taxonomy.
 */
public abstract class MaintainRelatedConceptElement extends curam.cpm.facade.base.MaintainRelatedConceptElement {

  /**
   * The related concept wizard state object.
   */
  protected RelatedConceptWizState relatedConceptWizState = new RelatedConceptWizStateImpl();

  /**
   * Reference to related concept element DAO.
   */
  @Inject
  protected RelatedConceptElementDAO relatedConceptElementDAO;

  /**
   * Reference to taxonomy in edit data converter.
   */
  @Inject
  protected TaxonomyInEditDataConverter taxonomyInEditDataConverter;

  /**
   * Reference to taxonomy in edit data DAO.
   */
  @Inject
  protected TaxonomyInEditDataDAO taxonomyInEditDataDAO;

  /**
   * Reference to taxonomy version DAO.
   */
  @Inject
  protected TaxonomyVersionDAO taxonomyVersionDAO;

  /**
   * Constructor for the class.
   */
  public MaintainRelatedConceptElement() {

    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a in edit related concept.
   *
   * @param relatedConceptDetails
   * Contains the in edit related concept details.
   *
   * @return The in edit related concept ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RelatedConceptKey createRelatedConceptElement(
    final RelatedConceptDetails relatedConceptDetails) throws AppException,
      InformationalException {

    RelatedConceptKey relatedConceptKey = new RelatedConceptKey();
    WizardStateID wizardStateID = new WizardStateID();

    for (final TaxonomyVersion taxonomyVersion : taxonomyVersionDAO.readAll()) {

      if (taxonomyVersion.getDerivedStatus().equals(
        TAXONOMY_VERSION_STATUSEntry.IN_EDIT)) {

        relatedConceptDetails.taxonomyVersionID = taxonomyVersion.getID();
        break;
      }
    }

    if (relatedConceptDetails.customInd) {
      
      relatedConceptDetails.dtls.customConceptInd = relatedConceptDetails.customInd;
    }

    if (relatedConceptDetails.actionString.equals(
      TaxonomyConstants.kStoreAction)) {
      wizardStateID = relatedConceptWizState.storeRelatedConcept(
        relatedConceptDetails);
      relatedConceptKey.relatedConceptID = wizardStateID.wizardStateID;
    } else {

      RelatedConceptElement relatedConceptElement = relatedConceptElementDAO.newInstance();

      setRelatedConceptElementDetails(relatedConceptDetails,
        relatedConceptElement, true);
      relatedConceptElement.insert();
      relatedConceptKey.relatedConceptID = relatedConceptElement.getID();
    }

    return relatedConceptKey;
  }

  /**
   * Retrieves all the in edit related concepts.
   *
   * @return The list of in edit related concepts.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RelatedConceptDetailsList listRelatedConceptElements()
    throws AppException, InformationalException {

    RelatedConceptDetailsList relatedConceptDetailsList = new RelatedConceptDetailsList();
    Set<RelatedConceptElement> relatedConceptElements = relatedConceptElementDAO.readAll();

    for (final RelatedConceptElement relatedConceptElement : relatedConceptElements) {

      relatedConceptDetailsList.details.addRef(
        getInEditRelatedConceptDetails(relatedConceptElement));
    }

    return sortRelatedConceptElements(relatedConceptDetailsList);
  }

  /**
   * Modifies the in edit related concept.
   *
   * @param relatedConceptDetails
   * Contains the in edit related concept details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyRelatedConceptElement(
    final RelatedConceptDetails relatedConceptDetails) throws AppException,
      InformationalException {

    RelatedConceptElement relatedConceptElement = relatedConceptElementDAO.get(
      relatedConceptDetails.dtls.relatedConceptID);

    setRelatedConceptElementDetails(relatedConceptDetails,
      relatedConceptElement, false);
    relatedConceptElement.modify(relatedConceptDetails.dtls.versionNo);
  }

  /**
   * Retrieves the taxonomy terms associated with in edit related concept from
   * the data store.
   *
   * @param wizardStateID
   * Contains the data store entity ID.
   *
   * @return The taxonomy terms list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TaxonomyTermWizDetailsList previewInEditTerms(
    final WizardStateID wizardStateID) throws AppException,
      InformationalException {

    TaxonomyTermWizDetailsList existingInEditTermWizDetailsList = relatedConceptWizState.readTaxonomyTerms(
      wizardStateID);

    TaxonomyTermWizDetailsList taxonomyTermWizDetailsList = new TaxonomyTermWizDetailsList();

    taxonomyTermWizDetailsList.searchDetails.wizDetails.taxonomyTermTabList = existingInEditTermWizDetailsList.searchDetails.wizDetails.taxonomyTermTabList;

    Set<TaxonomyInEditData> selectedTerms = getInEditTermsFromTabList(
      existingInEditTermWizDetailsList.searchDetails.wizDetails.taxonomyTermTabList);

    for (final TaxonomyInEditData taxonomyInEditData : selectedTerms) {
      taxonomyTermWizDetailsList.searchResultsList.dtls.addRef(
        getInEditTermDetails(taxonomyInEditData));
    }

    if (selectedTerms.size() > 0) {
      taxonomyTermWizDetailsList.searchDetails.termsSelectedInd = true;
    }

    taxonomyTermWizDetailsList.searchDetails.wizardMenu = TaxonomyConstants.kCreateRelatedConceptElementWizard2;

    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(taxonomyTermWizDetailsList.informationalMsgDtlsOpt);
    // END, CR00292696
    
    return taxonomyTermWizDetailsList;
  }

  /**
   * Retrieves the in edit related concept details from the data store.
   *
   * @param wizardStateID
   * Contains the wizard state ID.
   *
   * @return The in edit related concept details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RelatedConceptDetails previewRelatedConceptElement(
    final WizardStateID wizardStateID) throws AppException,
      InformationalException {

    RelatedConceptDetails relatedConceptDetails = new RelatedConceptDetails();

    if (wizardStateID.wizardStateID != 0) {

      relatedConceptDetails = relatedConceptWizState.readRelatedConcept(
        wizardStateID);
    }

    relatedConceptDetails.wizardMenu = TaxonomyConstants.kCreateRelatedConceptElementWizard2;
    return relatedConceptDetails;
  }

  /**
   * Returns the create related concept wizard menu details.
   *
   * @return The name of the properties file having create related concept
   * wizard menu details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RelatedConceptWizMenuDetails readWizardMenu() throws AppException,
      InformationalException {

    RelatedConceptWizMenuDetails relatedConceptWizMenuDetails = new RelatedConceptWizMenuDetails();

    relatedConceptWizMenuDetails.wizardMenu = TaxonomyConstants.kCreateRelatedConceptElementWizard1;

    return relatedConceptWizMenuDetails;
  }

  /**
   * Removes the taxonomy term from the in edit related concept wizard.
   *
   * @param searchTaxonomyTermsWizForRelatedConcept
   * Contains the taxonomy term and in edit related concept details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void removeInEditTerm(
    final SearchTaxonomyTermsWizForRelatedConcept searchTaxonomyTermsWizForRelatedConcept)
    throws AppException, InformationalException {

    relatedConceptWizState.removeInEditTerm(
      searchTaxonomyTermsWizForRelatedConcept);

  }

  /**
   * Removes the taxonomy term from the in edit related concept.
   *
   * @param removeInEditTermDetails
   * Contains taxonomy term term code and in edit related concept code.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void removeInEditTermFromRelatedConceptElement(
    final RemoveInEditTermDetails removeInEditTermDetails)
    throws AppException, InformationalException {

    TaxonomyInEditData taxonomyInEditData = taxonomyInEditDataDAO.readByCode(
      removeInEditTermDetails.taxonomyTermCode);
    RelatedConceptElement relatedConceptElement = relatedConceptElementDAO.readByCode(
      removeInEditTermDetails.relatedConceptCode);

    taxonomyInEditData.removeRelatedConceptAssociation(relatedConceptElement);
  }

  /**
   * Removes the in edit related concept.
   *
   * @param keyVersionDetails
   * Contains the in edit related concept ID and version number.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void removeRelatedConceptElement(KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    RelatedConceptElement relatedConceptElement = relatedConceptElementDAO.get(
      keyVersionDetails.id);
    Set<TaxonomyInEditData> inEditTerms = taxonomyInEditDataDAO.searchByRelatedConcept(
      relatedConceptElement);

    for (final TaxonomyInEditData inEditTerm : inEditTerms) {

      inEditTerm.removeRelatedConceptAssociation(relatedConceptElement);
    }

    relatedConceptElement.remove(keyVersionDetails.version);
  }

  /**
   * Searches the taxonomy terms and adds the selected the taxonomy terms to the
   * in edit related concept.
   *
   * @param searchTaxonomyTermsByNameAndCode
   * Contains the taxonomy term name and code.
   *
   * @return The list of taxonomy terms matching the search criteria.
   *
   * @throws InformationalException
   * {@link TAXONOMYTERM#ERR_TAXONOMYTERM_XFV_MUST_SPECIFY_SEARCH_CRITERIA}
   * -If the search criteria is not entered.
   * @throws InformationalException
   * {@link TAXONOMYTERM#ERR_TAXONOMYTERM_XRV_MUST_SELECT_ATLEAST_ONE_TERM}
   * -If taxonomy term is not selected.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TaxonomyTermWizDetailsList searchAddInEditTermsToRelatedConceptElement(
    SearchTaxonomyTermsWizForRelatedConcept searchTaxonomyTermsByNameAndCode)
    throws AppException, InformationalException {

    TaxonomyTermWizDetailsList taxonomyTermWizDetailsList = new TaxonomyTermWizDetailsList();
    final RelatedConceptElement relatedConceptElement = relatedConceptElementDAO.get(
      searchTaxonomyTermsByNameAndCode.wizDetails.relatedConceptID);

    if (CPMConstants.kSearchActionStr.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)) {

      if (StringHelper.isEmpty(
        searchTaxonomyTermsByNameAndCode.wizDetails.details.name)
          && StringHelper.isEmpty(
            searchTaxonomyTermsByNameAndCode.wizDetails.details.code)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TAXONOMYTERMExceptionCreator.ERR_TAXONOMYTERM_XFV_MUST_SPECIFY_SEARCH_CRITERIA(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
        ValidationHelper.failIfErrorsExist();
      }

      Set<TaxonomyInEditData> taxonomyInEditTerms = taxonomyInEditDataDAO.searchBy(
        getLocale(), searchTaxonomyTermsByNameAndCode.wizDetails.details.name,
        searchTaxonomyTermsByNameAndCode.wizDetails.details.code);

      // Check if the term is being added through wizard.
      if (0 != searchTaxonomyTermsByNameAndCode.wizardStateID) {

        WizardStateID wizardStateID = new WizardStateID();

        wizardStateID.wizardStateID = searchTaxonomyTermsByNameAndCode.wizardStateID;

        taxonomyTermWizDetailsList.searchDetails.wizDetails.taxonomyTermTabList = relatedConceptWizState.readTaxonomyTerms(wizardStateID).searchDetails.wizDetails.taxonomyTermTabList;

      }

      // Filter out the already added taxonomy terms.
      for (final TaxonomyInEditData taxonomyInEditTerm : taxonomyInEditTerms) {

        if (0 != searchTaxonomyTermsByNameAndCode.wizDetails.relatedConceptID) {

          if (taxonomyInEditTerm.getRelatedConcepts().indexOf(
            relatedConceptElement.getCode())
              < 0) {

            taxonomyTermWizDetailsList.searchResultsList.dtls.addRef(
              getTaxonomyTermSummaryDetails(taxonomyInEditTerm));
          }
        } else {

          taxonomyTermWizDetailsList.searchResultsList.dtls.addRef(
            getTaxonomyTermSummaryDetails(taxonomyInEditTerm));
        }
      }

      return taxonomyTermWizDetailsList;

    } else if (TaxonomyConstants.kAddAction.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)) {

      relatedConceptWizState.storeTaxonomyTerm(searchTaxonomyTermsByNameAndCode);

    } else if (TaxonomyConstants.kSaveAction.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)) {

      String[] selectedTerms = searchTaxonomyTermsByNameAndCode.wizDetails.taxonomyTermTabList.split(
        CuramConst.gkTabDelimiter);

      if (0 == selectedTerms.length) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TAXONOMYTERMExceptionCreator.ERR_TAXONOMYTERM_XRV_MUST_SELECT_ATLEAST_ONE_TERM(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
        ValidationHelper.failIfErrorsExist();
      }

      TaxonomyInEditData taxonomyInEditData = null;

      for (final String selectedTerm : selectedTerms) {

        taxonomyInEditData = taxonomyInEditDataDAO.readByCode(
          selectedTerm.trim());
        taxonomyInEditData.setRelatedConcepts(relatedConceptElement.getCode());
        taxonomyInEditData.modify(taxonomyInEditData.getVersionNo());
      }

    } else if (TaxonomyConstants.kStoreAction.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)) {
      relatedConceptWizState.storeTaxonomyTerm(searchTaxonomyTermsByNameAndCode);

    } else if (TaxonomyConstants.kSaveFromWizardAction.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)) {
      relatedConceptWizState.storeTaxonomyTerm(searchTaxonomyTermsByNameAndCode);
      WizardStateID wizardStateID = new WizardStateID();

      wizardStateID.wizardStateID = searchTaxonomyTermsByNameAndCode.wizardStateID;
      relatedConceptWizState.saveRelatedConceptElement(wizardStateID);
    } else if (TaxonomyConstants.kResetSearchAction.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)
        && searchTaxonomyTermsByNameAndCode.wizardStateID != 0) {
      relatedConceptWizState.resetSearch(searchTaxonomyTermsByNameAndCode);

    } else if (TaxonomyConstants.kSaveFromWizardAction.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)) {

      relatedConceptWizState.storeTaxonomyTerm(searchTaxonomyTermsByNameAndCode);
      WizardStateID wizardStateID = new WizardStateID();

      wizardStateID.wizardStateID = searchTaxonomyTermsByNameAndCode.wizardStateID;
      relatedConceptWizState.saveRelatedConceptElement(wizardStateID);
    } else if (TaxonomyConstants.kResetSearchAction.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)
        && searchTaxonomyTermsByNameAndCode.wizardStateID != 0) {

      relatedConceptWizState.resetSearch(searchTaxonomyTermsByNameAndCode);
    }

    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(taxonomyTermWizDetailsList.informationalMsgDtlsOpt);
    // END, CR00292696
    
    return taxonomyTermWizDetailsList;
  }

  /**
   * Reads the in edit related concept details and its associated taxonomy
   * terms.
   *
   * @param relatedConceptKey
   * Contains the related concept ID.
   *
   * @return The in edit related concept details and its associated taxonomy
   * terms.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewRelatedConceptDetails viewRelatedConceptElement(
    final RelatedConceptKey relatedConceptKey) throws AppException,
      InformationalException {

    ViewRelatedConceptDetails viewRelatedConceptDetails = new ViewRelatedConceptDetails();
    RelatedConceptElement relatedConceptElement = relatedConceptElementDAO.get(
      relatedConceptKey.relatedConceptID);

    viewRelatedConceptDetails.conceptDetails = getInEditRelatedConceptDetails(
      relatedConceptElement);

    Set<TaxonomyInEditData> inEditTerms = taxonomyInEditDataDAO.searchByRelatedConcept(
      relatedConceptElement);

    TaxonomyTermRelatedConceptDetails taxonomyTermRelatedConceptDetails = null;

    for (final TaxonomyInEditData inEditTerm : inEditTerms) {

      taxonomyTermRelatedConceptDetails = new TaxonomyTermRelatedConceptDetails();
      taxonomyTermRelatedConceptDetails.dtls.taxonomyTermID = inEditTerm.getID();
      taxonomyTermRelatedConceptDetails.taxonomyTermName = inEditTerm.getTermName();
      taxonomyTermRelatedConceptDetails.taxonomyTermCode = inEditTerm.getCode();
      taxonomyTermRelatedConceptDetails.taxonomyTermStatus = inEditTerm.getStatus().getCode();

      viewRelatedConceptDetails.termRelConceptList.details.addRef(
        taxonomyTermRelatedConceptDetails);
    }

    Collections.sort(viewRelatedConceptDetails.termRelConceptList.details,
      new Comparator<TaxonomyTermRelatedConceptDetails>() {
      public int compare(final TaxonomyTermRelatedConceptDetails lhs,
        TaxonomyTermRelatedConceptDetails rhs) {
        return lhs.taxonomyTermName.compareTo(rhs.taxonomyTermName);
      }
    });

    return viewRelatedConceptDetails;
  }

  /**
   * Gets the related concept details from the in edit related concept.
   *
   * @param relatedConceptElement
   * In edit related concept object.
   *
   * @return The in edit related concept details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected RelatedConceptDetails getInEditRelatedConceptDetails(
    final RelatedConceptElement relatedConceptElement) throws AppException,
      InformationalException {

    RelatedConceptDetails relatedConceptDetails = new RelatedConceptDetails();
    RelatedConceptData relatedConceptData = taxonomyInEditDataConverter.convertXMLToRelatedConcept(
      relatedConceptElement.getRelatedConceptXML());

    relatedConceptDetails.dtls.relatedConceptID = relatedConceptElement.getID();
    relatedConceptDetails.name = getLocalizedText(relatedConceptData.getName());
    relatedConceptDetails.dtls.code = relatedConceptData.getCode();
    relatedConceptDetails.dtls.customConceptInd = relatedConceptElement.isCustomConcept();
    relatedConceptDetails.dtls.versionNo = relatedConceptElement.getVersionNo();
    relatedConceptDetails.noOfAssociatedTaxonomyTerms = taxonomyInEditDataDAO.searchByRelatedConcept(relatedConceptElement).size();

    return relatedConceptDetails;
  }

  /**
   * Gets the in edit term details from the in edit term object.
   *
   * @param taxonomyInEditData
   * The in edit taxonomy term object.
   *
   * @return The in edit term details struct.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected TaxonomyTermDetails getInEditTermDetails(
    final TaxonomyInEditData taxonomyInEditData) throws AppException,
      InformationalException {

    TaxonomyTermDetails taxonomyTermDetails = new TaxonomyTermDetails();

    taxonomyTermDetails.dtls.taxonomyTermID = taxonomyInEditData.getID();
    taxonomyTermDetails.name = taxonomyInEditData.getTermName();
    taxonomyTermDetails.dtls.code = taxonomyInEditData.getCode();
    taxonomyTermDetails.dtls.status = taxonomyInEditData.getStatus().getCode();

    return taxonomyTermDetails;
  }

  /**
   * Retrieves the taxonomy terms from the tabbed list.
   *
   * @param inEditTermTabList
   * The tabbed list of taxonomy terms.
   *
   * @return The set of taxonomy terms selected.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Set<TaxonomyInEditData> getInEditTermsFromTabList(
    final String inEditTermTabList) throws InformationalException {

    Set<TaxonomyInEditData> taxonomyInEditDataSet = new HashSet<TaxonomyInEditData>();

    for (final String inEditTermIDString : inEditTermTabList.split(
      CuramConst.gkTabDelimiter)) {
      if (!StringUtil.isNullOrEmpty(inEditTermIDString)) {

        taxonomyInEditDataSet.add(
          taxonomyInEditDataDAO.get(Long.parseLong(inEditTermIDString)));
      }
    }

    return taxonomyInEditDataSet;
  }

  /**
   * Gets the locale of the taxonomy.
   *
   * @return Locale of taxonomy.
   */
  protected LOCALEEntry getLocale() {
    LOCALEEntry locale = LOCALEEntry.get(TransactionInfo.getProgramLocale());

    if (LOCALEEntry.ENGLISH_GB.equals(locale)
      || LOCALEEntry.ENGLISH_US.equals(locale)
      || LOCALEEntry.ENGLISH.equals(locale)) {
      return LOCALEEntry.ENGLISH;
    }

    return locale;
  }

  /**
   * Gets the text for the current locale from the list of translations.
   *
   * @param textTranslations
   * List of text translations.
   *
   * @return Text belonging to the user locale.
   */
  protected String getLocalizedText(List<TextTranslation> textTranslations) {

    for (final TextTranslation textTranslation : textTranslations) {

      if (textTranslation.getLocale().equalsIgnoreCase(getLocale().getCode())) {

        return textTranslation.getText();
      }
    }
    return CuramConst.gkEmpty;
  }

  /**
   * Gets the taxonomy term summary details from the in edit taxonomy term
   * object.
   *
   * @param taxonomyInEditData
   * The in edit taxonomy term object.
   *
   * @return The taxonomy term details struct.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected TaxonomyTermDetails getTaxonomyTermSummaryDetails(
    final TaxonomyInEditData taxonomyInEditData) throws AppException,
      InformationalException {

    TaxonomyTermDetails taxonomyTermDetails = new TaxonomyTermDetails();

    taxonomyTermDetails.dtls.taxonomyTermID = taxonomyInEditData.getID();
    taxonomyTermDetails.name = taxonomyInEditData.getTermName();
    taxonomyTermDetails.dtls.code = taxonomyInEditData.getCode();
    taxonomyTermDetails.dtls.status = taxonomyInEditData.getStatus().getCode();

    return taxonomyTermDetails;
  }

  /**
   * Sets the in edit related concept data from details struct.
   *
   * @param relatedConceptDetails
   * The in edit related concept details.
   * @param relatedConceptElement
   * In edit related concept object.
   * @param isNewRelatedConcept
   * True if new related concept value is set, false otherwise.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void setRelatedConceptElementDetails(
    final RelatedConceptDetails relatedConceptDetails,
    final RelatedConceptElement relatedConceptElement, boolean isNewRelatedConcept) throws AppException,
      InformationalException {

    if (relatedConceptDetails.taxonomyVersionID != 0) {

      relatedConceptElement.setTaxonomyVersion(
        taxonomyVersionDAO.get(relatedConceptDetails.taxonomyVersionID));

    }
    relatedConceptElement.setCode(relatedConceptDetails.dtls.code);
    relatedConceptElement.setTaxonomyVersion(
      taxonomyVersionDAO.get(relatedConceptDetails.taxonomyVersionID));
    relatedConceptElement.setCustomConcept(relatedConceptDetails.customInd);

    RelatedConceptData relatedConceptData = new RelatedConceptData();
    TextTranslation nameText = new TextTranslation();
    List<TextTranslation> textTranslations = new ArrayList<TextTranslation>();

    nameText.setText(relatedConceptDetails.name);
    nameText.setLocale(getLocale().getCode());
    textTranslations.add(nameText);

    if (isNewRelatedConcept) {
      relatedConceptData.setCode(relatedConceptDetails.dtls.code);
    } else {
      if (relatedConceptDetails.dtls.customConceptInd) {
        relatedConceptData.setCode(relatedConceptDetails.dtls.code);
      } else {
        relatedConceptData.setCode(relatedConceptElement.getCode());
      }
    }
    relatedConceptData.setName(textTranslations);

    relatedConceptElement.setRelatedConceptXML(
      taxonomyInEditDataConverter.convertRelatedConceptToXML(relatedConceptData));
  }

  /**
   * Sorts a set of in edit related concepts.
   *
   * @param unsortedRelatedConceptElements
   * The set of in edit related concepts.
   *
   * @return The sorted list of in edit related concepts.
   */
  protected RelatedConceptDetailsList sortRelatedConceptElements(
    final RelatedConceptDetailsList unsortedRelatedConceptElements) {

    final RelatedConceptDetailsList relatedConceptElements = unsortedRelatedConceptElements;

    Collections.sort(relatedConceptElements.details,
      new Comparator<RelatedConceptDetails>() {
      public int compare(final RelatedConceptDetails lhs,
        RelatedConceptDetails rhs) {
        return lhs.name.compareTo(rhs.name);
      }
    });
    return relatedConceptElements;
  }

  // BEGIN, CR00292696, IBM
  /**
   * Collects the list of informations from the informational manager and adds
   * them to the list parameter passed in.
   *
   * @param informationalMsgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList informationalMsgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }
  // END, CR00292696
}
