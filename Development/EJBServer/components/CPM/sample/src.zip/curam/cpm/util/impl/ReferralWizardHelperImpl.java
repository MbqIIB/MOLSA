/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.codetable.impl.PHONETYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.REFERRALRELATEDLINKTYPEEntry;
import curam.codetable.impl.REFERRALRELATEDROLETYPEEntry;
import curam.codetable.impl.REPRESENTATIVETYPEEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.codetable.impl.SOSINGLEORMULTIPLECLIENTSEntry;
import curam.core.fact.ConcernRoleEmailAddressFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.EmailAddressFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRoleEmailAddress;
import curam.core.intf.EmailAddress;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleEmailAddressDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EmailAddressDtls;
import curam.cpm.facade.struct.AddReferralContextDetails;
import curam.cpm.facade.struct.AddReferralWizardData;
import curam.datastore.impl.Datastore;
import curam.datastore.impl.Entity;
import curam.message.impl.REFERRALExceptionCreator;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.casemanager.impl.CaseParticipantRoleDAO;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.impl.ProviderDAO;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.referral.impl.Referral;
import curam.referral.impl.ReferralDAO;
import curam.referral.impl.ReferralRoleData;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.StringHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


/**
 * Helper class for the {@link Referral} creation wizard.
 *
 * @since 6.0
 */
class ReferralWizardHelperImpl implements ReferralWizardHelper {

  /**
   * Reference to Case Header DAO instance.
   */
  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  /**
   * Reference to Referral DAO instance.
   */
  @Inject
  protected ReferralDAO referralDAO;

  /**
   * Reference to User DAO instance.
   */
  @Inject
  protected UserDAO userDAO;

  /**
   * Reference to Provider Offering DAO instance.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Reference to Service Offering DAO instance.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Reference to Provider DAO instance.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Provider instance of Referral Role Data object.
   */
  @Inject
  protected Provider<ReferralRoleData> referralRoleData;

  /**
   * Reference to Case Header DAO instance.
   */
  @Inject
  protected CaseParticipantRoleDAO caseParticipantRoleDAO;

  /**
   * Reference to event dispatcher for Referral Wizard Helper event.
   */
  @Inject
  protected EventDispatcherFactory<ReferralWizardHelperEvent> dispatcher;

  /**
   * {@inheritDoc}
   */
  public Referral createReferral(final Entity referralEntity,
    final Long relatedID,
    final REFERRALRELATEDLINKTYPEEntry referralRelatedLinkType)
    throws AppException, InformationalException {

    Referral referral = referralDAO.newInstance();

    // set referral the referral details
    setReferralDetails(referral, referralEntity);

    referral.setRelatedObjectID(relatedID);
    referral.setRelatedObjectType(referralRelatedLinkType);

    referral.insert(getReferralRoleDataList(referralEntity));

    return referral;
  }

  /**
   * Retrieves the referral role data.
   *
   * @param referralEntity
   * the referral entity to retrieve the referral role data from
   * @return the referral role data
   * @throws InformationalException
   * Generic Information Exception
   * @throws AppException
   * Generic Application Exception
   */
  protected List<ReferralRoleData> getReferralRoleDataList(
    final Entity referralEntity) throws AppException, InformationalException {

    List<ReferralRoleData> referralRoleDataList = new ArrayList<ReferralRoleData>();

    // set the service details
    referralRoleDataList.add(getServiceReferralRoleDetails(referralEntity));

    // set the referral clients
    referralRoleDataList.addAll(
      getClientsReferralRoleDetails(
        (String) referralEntity.getTypedAttributeWithDefault(
          ReferralWizardConstants.kSELECTED_CLIENTS)));

    // set the provider details if a provider was entered
    if (providerDetailsEntered(referralEntity)) {
      referralRoleDataList.add(getProviderReferralRoleDetails(referralEntity));
    }

    return referralRoleDataList;
  }

  /**
   * Determines if provider details have been entered.
   *
   * @param referralEntity
   * the {@link curam.datastore.impl.Datastore} containing the provider details, if entered
   * @return true if provider details have been entered, otherwise false
   */
  protected boolean providerDetailsEntered(final Entity referralEntity) {

    if (!StringHelper.isEmpty(
      (String) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_NAME))) {
      return true;
    }

    if ((Long) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_ID)
        != CuramConst.gkZero) {
      return true;
    }

    return false;
  }

  /**
   * Sets the details of the {@link Referral} using the data contained within
   * the {@link curam.datastore.impl.Datastore}.
   *
   * @param referral
   * the referral the data on the data store is to populated
   * @param referralEntity
   * the data store entity containing the data for the referral
   */
  protected void setReferralDetails(final Referral referral,
    final Entity referralEntity) {

    // set the general referral details
    referral.setReferralDate(
      (Date) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kREFERRAL_DATE));
    referral.setReferredBy(getReferredBy(referralEntity));
    referral.setFollowUpRequired(
      (Boolean) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kFOLLOW_UP_REQUIRED_IND));
    referral.setFollowUpWarningDays(
      (String) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kFOLLOW_UP_WARNING_DAYS));
    referral.setSensitivityCode(
      SENSITIVITYEntry.get(
        referralEntity.getAttribute(ReferralWizardConstants.kSENSITIVITY)));
    referral.setReason(
      referralEntity.getAttribute(ReferralWizardConstants.kREASON));

    // set the notification details
    referral.setNotifyClientAutomatically(
      (Boolean) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kNOTIFIY_CLIENT_AUTOMATICALLY));
    referral.setNotifyProviderAutomatically(
      (Boolean) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kNOTIFIY_PROVIDER_AUTOMATICALLY));
    referral.setClientNotificationText(
      (String) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kCLIENT_NOTIFICATION_TEXT));
    referral.setProviderNotificationText(
      (String) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kPROVIDER_NOTIFICATION_TEXT));

  }

  /**
   * Retrieves the referral role details for the clients that the referral is to
   * be in relation to.
   *
   * @param clientStringList
   * List of all clients that are to be related to this referral
   * @return list of client referral role data
   */
  protected List<ReferralRoleData> getClientsReferralRoleDetails(
    final String clientStringList) {

    List<ReferralRoleData> referralRoleDataList = new ArrayList<ReferralRoleData>();

    if (clientStringList.length() > CuramConst.gkZero) {

      final String[] caseParticipantRoleList = clientStringList.split(
        CuramConst.gkTabDelimiter);

      for (String caseParticpantRole : caseParticipantRoleList) {
        referralRoleDataList.add(
          setClientReferralRoleDetails(caseParticpantRole));
      }
    }
    return referralRoleDataList;
  }

  /**
   * Sets the referral role details for a client that the referral is in
   * relation to.
   *
   * @param caseParticpantRole
   * The participant role identifier for a client the referral is in
   * relation to
   * @return the referral role data for a client
   */
  protected ReferralRoleData setClientReferralRoleDetails(
    final String caseParticpantRole) {

    ReferralRoleData clientReferralRoleData = referralRoleData.get();

    clientReferralRoleData.setRelatedObjectID(
      Long.parseLong(caseParticpantRole));
    clientReferralRoleData.setRelatedObjectType(
      REFERRALRELATEDROLETYPEEntry.CLIENT);
    clientReferralRoleData.setRelatedObjectName(CuramConst.gkEmpty);

    return clientReferralRoleData;
  }

  /**
   * Retrieves the {@link User} who is the referrer of this referral from the
   * passed in {@link curam.datastore.impl.Datastore} entity.
   *
   * @param referralEntity
   * the data store entity the referrer of the referral details are to
   * be retrieved from
   * @return the user who referred this referral
   */
  protected User getReferredBy(final Entity referralEntity) {

    if ((Boolean) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kREFERRED_BY_ME_IND)) {
      return userDAO.get(TransactionInfo.getProgramUser());
    }

    return userDAO.get(
      (String) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kREFERRED_BY));
  }

  /**
   * Retrieves a referral role data object containing the details for a service
   * that this {@link Referral} is to be in relation to.
   *
   * @param referralEntity
   * the data store entity containing the service details
   * @return the referral role data object containing the details for a service
   * that this referral is to be relation to
   */
  protected ReferralRoleData getServiceReferralRoleDetails(
    final Entity referralEntity) {

    // retrieve the details for a service selected from the service repository
    if (CuramConst.gkZero
      != (Long) (Long) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kSERVICE_OFFERING_ID)) {
      return getServiceOfferingReferralRoleDetails(
        serviceOfferingDAO.get(
          (Long) referralEntity.getTypedAttributeWithDefault(
            ReferralWizardConstants.kSERVICE_OFFERING_ID)));
    }

    // retrieve the details for an entered service name
    return getServiceNameReferralRoleDetails(
      (String) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kSERVICE_NAME));

  }

  /**
   * Retrieves a referral role data object containing the details for a provider
   * that this {@link Referral} is to be in relation to.
   *
   * @param referralEntity
   * the data store entity containing the provider details
   * @return the referral role data object containing the details for a provider
   * that this referral is to be relation to
   * @throws InformationalException
   * Generic Information Exception
   * @throws AppException
   * Generic Application Exception
   */
  protected ReferralRoleData getProviderReferralRoleDetails(
    final Entity referralEntity) throws AppException, InformationalException {

    // retrieve the details for a provider selected from the system
    if (CuramConst.gkZero
      != (Long) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kPROVIDER_ID)) {
      return getProviderReferralRoleData(
        providerDAO.get(
          (Long) referralEntity.getTypedAttributeWithDefault(
            ReferralWizardConstants.kPROVIDER_ID)));
    }

    // retrieve the details for an entered provider representative
    return getProviderRepresentativeReferralRoleData(referralEntity);

  }

  /**
   * Retrieves a referral role data object containing the details for a
   * unregistered service that this {@link Referral} is to be in relation to.
   *
   * @param serviceName
   * The details that the unregistered service details are to be
   * extracted from
   * @return the referral role data object containing the details for a
   * unregistered service that this referral is to be relation to
   */
  protected ReferralRoleData getServiceNameReferralRoleDetails(
    final String serviceName) {

    ReferralRoleData serviceReferralRoleData = referralRoleData.get();

    serviceReferralRoleData.setRelatedObjectName(serviceName);
    serviceReferralRoleData.setRelatedObjectID(CuramConst.gkZero);
    serviceReferralRoleData.setRelatedObjectType(
      REFERRALRELATEDROLETYPEEntry.UNREGISTEREDSERVICEOFFERING);

    return serviceReferralRoleData;
  }

  /**
   * Retrieves the referral role data object containing the details for a
   * {@link ServiceOffering} to be related to this {@link Referral}.
   *
   * @param serviceOffering
   * The details that the service details are to be extracted from
   * @return the referral role data object containing the details for a service
   * to be related to this referral.
   */
  protected ReferralRoleData getServiceOfferingReferralRoleDetails(
    final ServiceOffering serviceOffering) {

    ReferralRoleData serviceReferralRoleData = referralRoleData.get();

    serviceReferralRoleData.setRelatedObjectID(serviceOffering.getID());
    serviceReferralRoleData.setRelatedObjectType(
      REFERRALRELATEDROLETYPEEntry.SERVICEOFFERING);
    serviceReferralRoleData.setRelatedObjectName(CuramConst.gkEmpty);

    return serviceReferralRoleData;

  }

  /**
   * Retrieves the referral role data object containing the details for a
   * provider representative to be related to this referral.
   *
   * @param referralEntity
   * The {@link curam.datastore.impl.Datastore} entity containing the details of the
   * provider representative
   * @return the referral role data object containing the details for a provider
   * representative to be related to this referral
   */
  protected ReferralRoleData getProviderRepresentativeReferralRoleData(
    final Entity referralEntity) throws AppException, InformationalException {

    ReferralRoleData providerRepresentativeReferralRoleData = referralRoleData.get();

    curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

    curam.core.sl.struct.RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

    representativeRegistrationDetails.representativeDtls.representativeName = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_NAME);
    representativeRegistrationDetails.representativeDtls.representativeType = REPRESENTATIVETYPEEntry.CONTACT.getCode();
    representativeRegistrationDetails.representativeRegistrationDetails.addressData = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_ADDRESS_DETAILS);
    representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_PHONE_AREA_CODE);
    representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_PHONE_COUNTRY_CODE);
    representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_PHONE_NUMBER);
    representativeRegistrationDetails.representativeRegistrationDetails.phoneType = PHONETYPEEntry.BUSINESS.getCode();
    representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();
    representativeRegistrationDetails.representativeRegistrationDetails.sensitivity = SENSITIVITYEntry.LOW.getCode();

    representativeObj.registerRepresentative(representativeRegistrationDetails);

    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // create the email address
    if (!StringHelper.isEmpty(
      (String) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_EMAIL_ADDRESS))) {
      EmailAddress emailAddressObj = EmailAddressFactory.newInstance();
      EmailAddressDtls emailAddressDtls = new EmailAddressDtls();

      emailAddressDtls.emailAddressID = uniqueIDObj.getNextID();
      emailAddressDtls.statusCode = RECORDSTATUSEntry.NORMAL.getCode();
      emailAddressDtls.emailAddress = (String) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_EMAIL_ADDRESS);
      emailAddressObj.insert(emailAddressDtls);

      ConcernRoleEmailAddress concernRoleEmailAddress = ConcernRoleEmailAddressFactory.newInstance();
      ConcernRoleEmailAddressDtls concernRoleEmailAddressDtls = new ConcernRoleEmailAddressDtls();

      concernRoleEmailAddressDtls.concernRoleEmailAddressID = uniqueIDObj.getNextID();

      concernRoleEmailAddressDtls.concernRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
      concernRoleEmailAddressDtls.emailAddressID = emailAddressDtls.emailAddressID;
      concernRoleEmailAddress.insert(concernRoleEmailAddressDtls);

      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = concernRoleEmailAddressDtls.concernRoleID;

      ConcernRoleDtls concernRoleDtls = ConcernRoleFactory.newInstance().read(
        concernRoleKey);

      concernRoleDtls.primaryEmailAddressID = concernRoleEmailAddressDtls.emailAddressID;
      curam.core.intf.ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      concernRoleObj.modify(concernRoleKey, concernRoleDtls);
    }

    providerRepresentativeReferralRoleData.setRelatedObjectID(
      representativeRegistrationDetails.representativeDtls.concernRoleID);
    providerRepresentativeReferralRoleData.setRelatedObjectType(
      REFERRALRELATEDROLETYPEEntry.PROVIDERREPRESENTATIVE);
    providerRepresentativeReferralRoleData.setRelatedObjectName(
      (String) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_NAME));

    return providerRepresentativeReferralRoleData;

  }

  /**
   * Retrieves the referral role data object containing the details for a
   * registered provider details to be related to this referral.
   *
   * @param provider
   * The details that the provider details are to be extracted from
   * @return the referral role data object containing the details for a
   * registered provider details to be related to this referral
   */
  protected ReferralRoleData getProviderReferralRoleData(
    final curam.provider.impl.Provider provider) {

    ReferralRoleData providerReferralRoleData = referralRoleData.get();

    providerReferralRoleData.setRelatedObjectType(
      REFERRALRELATEDROLETYPEEntry.PROVIDER);
    providerReferralRoleData.setRelatedObjectID(provider.getID());
    providerReferralRoleData.setRelatedObjectName(provider.getName());

    return providerReferralRoleData;
  }

  /**
   * {@inheritDoc}
   */
  public void validateServiceDetails(final AddReferralWizardData dtls) {

    /*
     * validate a service offering or unregistered service is entered
     */
    if (StringHelper.isEmpty(dtls.serviceName)
      && dtls.serviceOfferingID == CuramConst.gkZero) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_XFV_SERVICE_NAME_OR_SERVICE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

    /*
     * validate both a service offering and a unregistered service have not
     * being entered
     */
    if (!StringHelper.isEmpty(dtls.serviceName)
      && dtls.serviceOfferingID != CuramConst.gkZero) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_XFV_SERVICE_NAME_MUST_NOT_BE_ENTERED_IF_SERVICE_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }
  }

  /**
   * {@inheritDoc}
   */
  public void updateReferralWizardDataBasedOnServiceChange(
    final AddReferralWizardData dtls, final Entity referralEntity) {

    // raise the pre-event
    dispatcher.get(ReferralWizardHelperEvent.class).preUpdateReferralWizardDataBasedOnServiceChange(
      dtls);

    /*
     * reset the provider details if the passed in service is a free text
     * service and provider is selected from the system.
     */
    if (CuramConst.gkEmpty != dtls.serviceName
      && CuramConst.gkZero
        != (Long) referralEntity.getTypedAttributeWithDefault(
          ReferralWizardConstants.kPROVIDER_ID)) {
      referralEntity.setTypedAttribute(ReferralWizardConstants.kPROVIDER_ID,
        CuramConst.gkZero);
      referralEntity.setTypedAttribute(
        ReferralWizardConstants.kNOTIFIY_PROVIDER_AUTOMATICALLY, false);
      referralEntity.setTypedAttribute(
        ReferralWizardConstants.kPROVIDER_NOTIFICATION_TEXT, "");
    }

    // if service offering entered
    if (CuramConst.gkZero != dtls.serviceOfferingID) {

      ServiceOffering serviceOffering = serviceOfferingDAO.get(
        dtls.serviceOfferingID);

      /*
       * service is entered for multiple clients, determine if the existing
       * provider - if entered - is configured to offer the passed in service
       * from the client
       */
      if (serviceOffering.getSingleOrMultipleClients().equals(
        SOSINGLEORMULTIPLECLIENTSEntry.MULTIPLE)) {

        // if list is empty provider is not configured to offer service so
        // reset
        if (!providerConfiguredForService(referralEntity, serviceOffering)) {
          referralEntity.setTypedAttribute(ReferralWizardConstants.kPROVIDER_ID,
            CuramConst.gkZero);
          referralEntity.setTypedAttribute(
            ReferralWizardConstants.kNOTIFIY_PROVIDER_AUTOMATICALLY, false);
          referralEntity.setTypedAttribute(
            ReferralWizardConstants.kPROVIDER_NOTIFICATION_TEXT, "");
        }

      }

      // single select service passed in from client
      if (serviceOffering.getSingleOrMultipleClients().equals(
        SOSINGLEORMULTIPLECLIENTSEntry.SINGLE)) {

        // reset all selected clients if the existing service is a
        // multiple client service
        if (multipleClientServiceStoredOnDatastore(referralEntity)
          && multipleClientsSelectedOnDatastore(referralEntity)) {
          referralEntity.setTypedAttribute(
            ReferralWizardConstants.kSELECTED_CLIENTS, "");
          referralEntity.setTypedAttribute(
            ReferralWizardConstants.kNOTIFIY_CLIENT_AUTOMATICALLY, false);
          referralEntity.setTypedAttribute(
            ReferralWizardConstants.kCLIENT_NOTIFICATION_TEXT, "");
        }

        // if provider is not configured to offer service reset the provider
        if (!providerConfiguredForService(referralEntity, serviceOffering)) {
          referralEntity.setTypedAttribute(ReferralWizardConstants.kPROVIDER_ID,
            CuramConst.gkZero);
          referralEntity.setTypedAttribute(
            ReferralWizardConstants.kNOTIFIY_PROVIDER_AUTOMATICALLY, false);
          referralEntity.setTypedAttribute(
            ReferralWizardConstants.kPROVIDER_NOTIFICATION_TEXT, "");
        }

      }
    }

    // raise the post-event
    dispatcher.get(ReferralWizardHelperEvent.class).postUpdateReferralWizardDataBasedOnServiceChange(
      dtls);
  }

  /**
   * Determines if multiple clients have been selected and stored on the
   * {@link curam.datastore.impl.Datastore} for this referral.
   *
   * @param referralEntity
   * the data store entity the selected clients exist on
   * @return true if multiple clients have been selected for this referral,
   * otherwise
   */
  protected boolean multipleClientsSelectedOnDatastore(
    final Entity referralEntity) {

    String clients = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kSELECTED_CLIENTS);

    return clients.split(CuramConst.gkTabDelimiter).length > CuramConst.gkOne;
  }

  /**
   * Determines if the service stored on the {@link curam.datastore.impl.Datastore} is configured for
   * multiple clients.
   *
   * @param referralEntity
   * the referral data store entity containing the service details to
   * be examined
   * @return true if the service is configured for multiple clients, otherwise
   * false
   */
  protected boolean multipleClientServiceStoredOnDatastore(
    final Entity referralEntity) {
    boolean multipleClientService = true;

    // existing service is for multiple clients
    Long serviceOfferingID = (Long) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kSERVICE_OFFERING_ID);

    // a service offering from the service registry is stored on data store
    if (CuramConst.gkZero != serviceOfferingID.longValue()) {

      // the service offering is configured for a single client only
      if (serviceOfferingDAO.get(serviceOfferingID).getSingleOrMultipleClients().equals(
        SOSINGLEORMULTIPLECLIENTSEntry.SINGLE)) {
        multipleClientService = false;
      }

    }
    return multipleClientService;
  }

  /**
   * Determines if a provider is stored on the {@link curam.datastore.impl.Datastore} that is
   * configured to offer the passed in {@link ServiceOffering}.
   * <p>
   * If no provider is stored on the data store, false is returned. If a
   * provider details of a provider not existing on the service repository are
   * stored on the data store then false is returned. If provider details exist
   * of a provider that exist on the service repository, then false is returned
   * if the provider is not configured to offer the service, and true is
   * returned if the provider is configured to offer the service.
   * </p>
   *
   * @param referralEntity
   * the data store entity the provider details are stored on
   * @param serviceOffering
   * the service offering to be determined if the provider (if one is
   * stored) on the data store is configured to offer
   * @return true if a provider exists on the data store configured to offer the
   * passed in service offering, otherwise false
   */
  protected boolean providerConfiguredForService(final Entity referralEntity,
    final ServiceOffering serviceOffering) {

    if (CuramConst.gkZero
      == (Long) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kPROVIDER_ID)) {
      return false;
    }

    curam.provider.impl.Provider provider = providerDAO.get(
      (Long) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kPROVIDER_ID));

    final Set<ProviderOffering> providerOfferingSet = providerOfferingDAO.searchProviderOffering(
      provider.getID(), serviceOffering.getID());

    return !providerOfferingSet.isEmpty();
  }

  /**
   * {@inheritDoc}
   */
  public List<CaseParticipantRole> getSelectedCaseParticipantRoles(
    final Entity referralEntity) {
    List<CaseParticipantRole> referralClients = new ArrayList<CaseParticipantRole>();
    String clients = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kSELECTED_CLIENTS);

    if (!StringHelper.isEmpty(clients)) { // its a multi select

      String[] caseParticipantRoleIDs = clients.split(CuramConst.gkTabDelimiter);

      for (String caseParticipantRoleID : caseParticipantRoleIDs) {
        CaseParticipantRole caseParticipantRole = caseParticipantRoleDAO.get(
          Long.parseLong(caseParticipantRoleID));

        referralClients.add(caseParticipantRole);
      }
    }
    return referralClients;
  }

  /**
   * {@inheritDoc}
   */
  public AddReferralContextDetails getContextDetails(
    final AddReferralWizardData wizardData) throws AppException,
      InformationalException {
    AddReferralContextDetails addReferralContextDetails = new AddReferralContextDetails();

    if (REFERRALRELATEDLINKTYPEEntry.get(wizardData.relatedType).equals(
      REFERRALRELATEDLINKTYPEEntry.CASE)) {
      addReferralContextDetails.pageDescription = caseHeaderDAO.get(wizardData.wizardData.relatedID).getDescription();
    }

    addReferralContextDetails.wizardMenu = wizardData.wizardData.wizardPropertyName;
    return addReferralContextDetails;
  }

  /**
   * {@inheritDoc}
   */
  public Boolean getFinishWizardAndCreateInd(final Entity referralEntity) {
    return (Boolean) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kFINISH_WIZARD_AND_CREATE_IND);
  }

  /**
   * {@inheritDoc}
   */
  public void setFinishWizardAndCreateInd(final AddReferralWizardData key,
    final Entity referralEntity) {
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kFINISH_WIZARD_AND_CREATE_IND,
      key.wizardData.finishWizardAndCreateInd);

    referralEntity.update();
  }

}
