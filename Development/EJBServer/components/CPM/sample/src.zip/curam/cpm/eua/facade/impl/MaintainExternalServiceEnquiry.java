/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.eua.facade.impl;


import java.util.LinkedHashMap;
import java.util.List;
import com.google.inject.Inject;
import curam.codetable.impl.PROVIDERENQUIRYRESPONSEEntry;
import curam.core.impl.EnvVars;
import curam.cpm.facade.struct.ServiceEnquiryCommentDetails;
import curam.cpm.facade.struct.ServiceEnquiryListDetailsList;
import curam.cpm.facade.struct.ServiceEnquiryResponse;
import curam.cpm.facade.struct.ServiceEnquiryResponseDetails;
import curam.cpm.facade.struct.ServiceEnquiryResponseList;
import curam.cpm.facade.struct.ServiceEnquiryViewDetails;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.struct.ServiceEnquiryKey;
import curam.cpm.util.impl.EmailUtility;
import curam.cpm.util.impl.ServiceEnquiryFacadeUtil;
import curam.message.impl.SERVICEENQUIRYEMAILExceptionCreator;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.servicedelivery.impl.ServiceDelivery;
import curam.serviceenquiry.impl.ServiceEnquiryDAO;
import curam.serviceoffering.impl.ServiceOfferingSecurity;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * Facade operations for Service Enquiries via the external provider web portal.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
public class MaintainExternalServiceEnquiry extends curam.cpm.eua.facade.base.MaintainExternalServiceEnquiry {

  @Inject
  protected ServiceEnquiryDAO serviceEnquiryDAO;

  @Inject
  protected com.google.inject.Provider<ServiceEnquiryFacadeUtil> serviceEnquiryFacadeUtilProvider;

  @Inject
  protected com.google.inject.Provider<EmailUtility> emailUtilityProvider;

  @Inject
  protected ServiceOfferingSecurity serviceOfferingSecurity;
  
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Constructor.
   */
  protected MaintainExternalServiceEnquiry() {
    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public void addCommentQuestion(
    final ServiceEnquiryCommentDetails commentDetails) throws AppException,
      InformationalException {
    serviceEnquiryFacadeUtilProvider.get().addComment(
      commentDetails.serviceEnquiryID, commentDetails.comments,
      commentDetails.versionNo);
    buildAndSendServiceEnquiryUpdatedEmail(commentDetails.serviceEnquiryID);
  }

  /**
   * {@inheritDoc}
   */
  public void submitEnquiryResponse(
    final ServiceEnquiryResponseDetails responseDetails) throws AppException,
      InformationalException {
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.get(
      responseDetails.serviceEnquiryID);

    serviceEnquiryFacadeUtilProvider.get().submitEnquiryResponse(
      responseDetails.versionNo, serviceEnquiry,
      PROVIDERENQUIRYRESPONSEEntry.get(responseDetails.providerResponse),
      responseDetails.comment);
    buildAndSendServiceEnquiryUpdatedEmail(responseDetails.serviceEnquiryID);
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryViewDetails viewServiceEnquiry(
    final ServiceEnquiryKey key) throws AppException, InformationalException {
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.get(
      key.serviceEnquiryID);
    ServiceEnquiryViewDetails serviceEnquiryViewDetails = serviceEnquiryFacadeUtilProvider.get().viewServiceEnquiry(
      serviceEnquiry);

    return serviceEnquiryViewDetails;
  }

  public ServiceEnquiryResponseList getResponseListForEnquiryUpdate(
    ServiceEnquiryKey serviceEnquiryKey) throws AppException,
      InformationalException {
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.get(
      serviceEnquiryKey.serviceEnquiryID);
    ServiceEnquiryResponseList responses = new ServiceEnquiryResponseList();

    ServiceEnquiryResponse serviceEnquiryResponse;

    responses.serviceEnquiryResponse = serviceEnquiry.getProviderResponse().getCode();
    LinkedHashMap<String, String> codes = CodeTable.getAllEnabledItems(
      PROVIDERENQUIRYRESPONSEEntry.TABLENAME,
      TransactionInfo.getProgramLocale());

    for (String code : codes.keySet()) {
      if ((code.equals(PROVIDERENQUIRYRESPONSEEntry.CANDELIVER.getCode()))
        || (code.equals(PROVIDERENQUIRYRESPONSEEntry.CANTDELIVER.getCode()))) {
        serviceEnquiryResponse = new ServiceEnquiryResponse();
        serviceEnquiryResponse.responseCode = code;
        serviceEnquiryResponse.responseDescription = codes.get(code);
        responses.response.addRef(serviceEnquiryResponse);
      }
    }
    return responses;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryListDetailsList listWebServiceEnquiries(
    final ProviderConcernRoleKey key) throws AppException,
      InformationalException {
    Provider provider = providerDAO.get(key.providerConcernRoleID);
    List<curam.serviceenquiry.impl.ServiceEnquiry> serviceEnquiries = serviceEnquiryDAO.searchActiveWebServiceEnquiriesForProvider(
      provider);

    return serviceEnquiryFacadeUtilProvider.get().assignServiceEnquiryListDetails(
      serviceEnquiries);
  }

  /**
   * Constructs an email message for the service enquiry which the provider has
   * updated and sends the email to the caseworkers email address.
   *
   * @param serviceEnquiryID
   * unique identifier for the updated service enquiry
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  protected void buildAndSendServiceEnquiryUpdatedEmail(
    final long serviceEnquiryID) throws AppException, InformationalException {

    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.get(
      serviceEnquiryID);

    if (serviceEnquiry.getCreatedBy().getEmailAddress() != null) {
     
      String emailSubject = SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY__RESPONSE_EMAIL_SUBJECT(serviceEnquiry.getServiceOffering().getName()).getLocalizedMessage();

      ServiceDelivery serviceDelivery = serviceEnquiry.getServiceDelivery();

      // check view security rights for service delivery
      serviceOfferingSecurity.checkViewRights(
        serviceDelivery.getServiceOffering());
      
      StringBuffer emailBody = new StringBuffer();

      emailBody.append(
        SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_PROVIDER_RESPONSE_EMAIL_BODY(serviceEnquiry.getProvider().getName(), serviceEnquiry.getServiceOffering().getName(), serviceDelivery.listCaseParticipantRoles().size()).getLocalizedMessage());

      // determine if an email notifications are to be sent
      if (!emailUtilityProvider.get().determineSendEmail(
        EnvVars.ENV_SERVICE_ENQUIRY_SEND_CASEWORKER_EMAIL_NOTIFICATIONS,
        EnvVars.ENV_SERVICE_ENQUIRY_SEND_CASEWORKER_EMAIL_NOTIFICATIONS_DEFAULT)) {
        return;
      }
      emailUtilityProvider.get().sendEmail(
        emailUtilityProvider.get().getSMTPMessage(emailSubject,
        emailBody.toString(),
        serviceEnquiry.getCreatedBy().getEmailAddress().getEmail()),
        serviceEnquiry.getProvider().getName());
    }
  }
}
