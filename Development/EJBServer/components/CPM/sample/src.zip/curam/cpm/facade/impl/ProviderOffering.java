/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.LOCALEEntry;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.ProviderOfferingInformation;
import curam.cpm.facade.struct.ProviderOfferingPlaceLimitDetailsForContracts;
import curam.cpm.facade.struct.ProviderOfferingPlaceLimitDetailsForNonContracts;
import curam.cpm.facade.struct.ProviderOfferingRateDetails;
import curam.cpm.facade.struct.ProviderOfferingRateDetailsForNonContracts;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetails;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetailsList;
import curam.cpm.facade.struct.ProviderOfferingSummaryVersionDetails;
import curam.cpm.facade.struct.ProviderOfferingSummaryVersionDetailsList;
import curam.cpm.facade.struct.ReasonDetails;
import curam.cpm.facade.struct.ViewProviderOfferingDetails;
import curam.cpm.facade.struct.ViewProviderOfferingInformation;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ProviderOfferingDtls;
import curam.cpm.sl.entity.struct.ProviderOfferingKey;
import curam.cpm.sl.entity.struct.ProviderOfferingPlaceLimitDtls;
import curam.cpm.sl.entity.struct.ProviderOfferingRateDtls;
import curam.cpm.sl.entity.struct.ProviderOfferingRateKey;
import curam.cpm.sl.fact.ProviderNotificationFactory;
import curam.cpm.sl.intf.ProviderNotification;
import curam.cpm.sl.struct.ProviderNotificationKey;
import curam.localization.translation.facade.struct.LocalizableTextTranslationDetails;
import curam.message.impl.PROVIDEROFFERINGRATEExceptionCreator;
import curam.provider.ProviderNotificationEvent;
import curam.provider.impl.ProviderDAO;
import curam.providerservice.ProviderOfferingDenialReason;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingDenialReasonEntry;
import curam.providerservice.impl.ProviderOfferingEndReasonEntry;
import curam.providerservice.impl.ProviderOfferingPlaceLimit;
import curam.providerservice.impl.ProviderOfferingPlaceLimitTypeEntry;
import curam.providerservice.impl.ProviderOfferingRate;
import curam.providerservice.impl.ProviderOfferingRateDAO;
import curam.providerservice.impl.ProviderOfferingRateTypeEntry;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.type.CodeTable;
import curam.util.type.DateRange;
import curam.util.type.Money;
import curam.util.type.StringHelper;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.message.impl.LOCALIZABLETEXTExceptionCreator;


/**
 * Facade Layer class for all the functionality relating to a Provider Offering.
 */
public abstract class ProviderOffering extends curam.cpm.facade.base.ProviderOffering {

  /**
   * Constant for empty string.
   */
  protected static final String kEmptyString = "";

  /**
   * ProviderOffering DAO Object.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * ProviderOfferingRate DAO Object.
   */
  @Inject
  protected ProviderOfferingRateDAO providerOfferingRateDAO;

  /**
   * Provider DAO Object.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * ServiceOffering DAO Object.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  // BEGIN, CR00178272, AK
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;
  // END, CR00178272

  /**
   * Constructor for the class.
   */
  public ProviderOffering() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Lists all the provider offerings for a given provider.
   *
   * @param providerKey
   * The Key for the Provider for whom the provider offerings are to be
   * retrieved.
   * @return ProviderOfferingSummaryDetailsList The Provider offerings list for
   * a given provider.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderOfferingSummaryDetailsList listServiceOfferingsByProvider(
    ProviderKey providerKey) throws AppException, InformationalException {

    ProviderOfferingSummaryDetailsList providerOfferingSummaryDetailsList = new ProviderOfferingSummaryDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    Set<curam.providerservice.impl.ProviderOffering> unModifiableProviderOfferings = provider.getProviderOfferings();
    Set<curam.providerservice.impl.ProviderOffering> providerOfferings = new HashSet<curam.providerservice.impl.ProviderOffering>();

    providerOfferings.addAll(unModifiableProviderOfferings);

    // BEGIN, CR00110056, JSP
    for (final curam.providerservice.impl.ProviderOffering providerOffering : sortProviderOfferings(
      providerOfferings)) {

      providerOfferingSummaryDetailsList.providerOfferingSummaryDetails.addRef(
        getProviderOfferingSummaryDetails(providerOffering));
    }
    // END, CR00110056

    return providerOfferingSummaryDetailsList;

  }

  // BEGIN, CR00110056, JSP
  /**
   * Lists all the approved provider offerings for a given provider.
   *
   * @param key
   * The Key for the Provider for whom the provider offerings are to be
   * retrieved.
   * @return ProviderOfferingSummaryDetailsList The Provider offerings list for
   * a given provider.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderOfferingSummaryDetailsList listApprovedServiceOfferingsByProvider(
    ProviderKey key) throws AppException, InformationalException {

    ProviderOfferingSummaryDetailsList providerOfferingSummaryDetailsList = new ProviderOfferingSummaryDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      key.providerConcernRoleID);

    Set<curam.providerservice.impl.ProviderOffering> unModifiableProviderOfferings = provider.getProviderOfferings();
    Set<curam.providerservice.impl.ProviderOffering> providerOfferings = new HashSet<curam.providerservice.impl.ProviderOffering>();

    providerOfferings.addAll(unModifiableProviderOfferings);

    for (final curam.providerservice.impl.ProviderOffering providerOffering : sortProviderOfferings(
      providerOfferings)) {

      if (ProviderOfferingStatusEntry.APPROVED.equals(
        providerOffering.getLifecycleState())) {
        providerOfferingSummaryDetailsList.providerOfferingSummaryDetails.addRef(
          getProviderOfferingSummaryDetails(providerOffering));
      }
    }

    return providerOfferingSummaryDetailsList;
  }

  // END, CR00110056


  // BEGIN, CR00158128, KR
  /**
   * Lists all the active provider offerings for a given provider.
   *
   * @param providerKey
   * The Key for the Provider for whom the provider offerings are to be
   * retrieved.
   *
   * @return The Provider offerings list for
   * a given provider.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderOfferingSummaryDetailsList listActiveProviderOfferingsForProvider(
    curam.cpm.facade.struct.ProviderKey providerKey) throws AppException, InformationalException {

    ProviderOfferingSummaryDetailsList providerOfferingSummaryDetailsList = new ProviderOfferingSummaryDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerID);

    Set<curam.providerservice.impl.ProviderOffering> unModifiableProviderOfferings = provider.getProviderOfferings();
    Set<curam.providerservice.impl.ProviderOffering> providerOfferings = new HashSet<curam.providerservice.impl.ProviderOffering>();

    providerOfferings.addAll(unModifiableProviderOfferings);

    for (final curam.providerservice.impl.ProviderOffering providerOffering : sortProviderOfferings(
      providerOfferings)) {

      if (!ProviderOfferingStatusEntry.CANCELED.equals(
        providerOffering.getLifecycleState())) {
        providerOfferingSummaryDetailsList.providerOfferingSummaryDetails.addRef(
          getProviderOfferingSummaryDetails(providerOffering));
      }
    }

    return providerOfferingSummaryDetailsList;
  }

  // END, CR00158128

  /**
   * Creates a Provider Offering(A service offering-provider combination).
   *
   * @param providerOfferingDtls
   * Contains the details for the provider offering to be created.
   *
   * @return ProviderOfferingKey The key for the new provider offering created.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderOfferingKey createProviderOffering(
    ProviderOfferingDtls providerOfferingDtls) throws AppException,
      InformationalException {
    curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.newInstance();

    // map details passed from client
    setProviderOfferingFields(providerOffering, providerOfferingDtls);

    providerOffering.insert();

    if (providerOffering.getLifecycleState().equals(
      ProviderOfferingStatusEntry.APPROVED)) {
      // Send Provider Offering approval Notification
      final curam.provider.impl.Provider provider = providerOffering.getProvider();
      ServiceOffering serviceOffering = providerOffering.getServiceOffering();

      ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();
      ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

      providerNotificationKey.concernRoleID = provider.getID();
      providerNotificationKey.serviceOfferingID = serviceOffering.getID();
      providerNotificationKey.event = ProviderNotificationEvent.SERVICE_OFFERING_APPROVAL;
      providerNotificationKey.date = providerOffering.getDateRange().start();
      providerNotification.sendNotification(providerNotificationKey);
    }

    ProviderOfferingKey providerOfferingKey = new ProviderOfferingKey();

    providerOfferingKey.providerOfferingID = providerOffering.getID();
    return providerOfferingKey;
  }

  /**
   * Sets the fields updateable by the user to the fields on the service layer
   * object.
   *
   *
   * @param providerOffering
   * the service layer object into which the user-updateable fields
   * must be mapped
   * @param providerOfferingDtls
   * struct contain fields set by the user (as well as other fields
   * which will be ignored)
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setProviderOfferingFields(
    // END, CR00177241
    final curam.providerservice.impl.ProviderOffering providerOffering,
    final ProviderOfferingDtls providerOfferingDtls) throws AppException,
      InformationalException {

    final curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceOfferingDAO.get(
      providerOfferingDtls.serviceOfferingID);
    final curam.provider.impl.Provider provider = providerDAO.get(
      providerOfferingDtls.providerConcernRoleID);

    providerOffering.setServiceOffering(serviceOffering);
    providerOffering.setProvider(provider);
    providerOffering.setComments(providerOfferingDtls.comments);

    final DateRange dateRange = new DateRange(providerOfferingDtls.startDate,
      providerOfferingDtls.endDate);

    providerOffering.setDateRange(dateRange);

  }

  /**
   * Reads the provider offering details.
   *
   * @param providerOfferingKey
   * The key for the provider offering.
   * @return ViewProviderOfferingDetails Contains the provider offering details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewProviderOfferingDetails viewProviderOffering(
    ProviderOfferingKey providerOfferingKey) throws AppException,
      InformationalException {

    ViewProviderOfferingDetails viewProviderOfferingDetails = new ViewProviderOfferingDetails();
    ProviderOfferingRateDetailsForNonContracts providerOfferingRateDetailsForNonContracts;
    ProviderOfferingPlaceLimitDetailsForContracts providerOfferingPlaceLimitDetailsForContracts;
    ProviderOfferingPlaceLimitDetailsForNonContracts providerOfferingPlaceLimitDetailsForNonContracts;

    final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      providerOfferingKey.providerOfferingID);

    final curam.provider.impl.Provider provider = providerOffering.getProvider();

    ServiceOffering serviceOffering = providerOffering.getServiceOffering();

    viewProviderOfferingDetails.providerOfferingDtls.serviceOfferingID = serviceOffering.getID();
    viewProviderOfferingDetails.serviceOfferingName = serviceOffering.getName();
    viewProviderOfferingDetails.providerOfferingDtls.startDate = providerOffering.getDateRange().start();
    viewProviderOfferingDetails.providerOfferingDtls.endDate = providerOffering.getDateRange().end();
    viewProviderOfferingDetails.providerOfferingDtls.providerOfferingID = providerOffering.getID();
    viewProviderOfferingDetails.providerOfferingDtls.providerConcernRoleID = provider.getID();
    viewProviderOfferingDetails.providerOfferingDtls.endReason = providerOffering.getEndReason().getCode();
    viewProviderOfferingDetails.providerOfferingDtls.denialReason = providerOffering.getDenialReason().getCode();
    viewProviderOfferingDetails.providerOfferingDtls.comments = providerOffering.getComments();

    viewProviderOfferingDetails.providerOfferingDtls.recordStatus = providerOffering.getLifecycleState().getCode();

    viewProviderOfferingDetails.providerOfferingDtls.versionNo = providerOffering.getVersionNo();

    Set<ProviderOfferingRate> unModifiableProviderOfferingRates = providerOffering.getProviderOfferingRates();
    Set<ProviderOfferingRate> providerOfferingRateRecords = new HashSet<ProviderOfferingRate>();

    providerOfferingRateRecords.addAll(unModifiableProviderOfferingRates);

    for (final curam.providerservice.impl.ProviderOfferingRate providerOfferingRate : sortProviderOfferingRates(
      providerOfferingRateRecords)) {
      viewProviderOfferingDetails.providerOfferingRateDetailsList.addRef(
        getProviderOfferingRateFieldsForList(providerOfferingRate));
      if ((providerOfferingRate.getProviderOfferingRateType().equals(
        ProviderOfferingRateTypeEntry.NONCONTRACT))
          || (providerOfferingRate.getProviderOfferingRateType().equals(
            ProviderOfferingRateTypeEntry.LIVEANDLICENSEDCONTRACT))
            || (providerOfferingRate.getProviderOfferingRateType().equals(
              ProviderOfferingRateTypeEntry.LIVEANDINVALIDLICENSEDCONTRACT))
              || (providerOfferingRate.getProviderOfferingRateType().equals(
                ProviderOfferingRateTypeEntry.LIVECONTRACT))) {
        providerOfferingRateDetailsForNonContracts = new ProviderOfferingRateDetailsForNonContracts();
        providerOfferingRateDetailsForNonContracts.assign(
          getProviderOfferingRateFieldsForList(providerOfferingRate));
        viewProviderOfferingDetails.providerOfferingRateDetailsForNonContracts.addRef(
          providerOfferingRateDetailsForNonContracts);
      }
    }

    Set<ProviderOfferingPlaceLimit> unModifiableProviderOfferingPlaceLimits = providerOffering.getProviderOfferingPlaceLimits();
    Set<ProviderOfferingPlaceLimit> providerOfferingPlaceLimits = new HashSet<ProviderOfferingPlaceLimit>();

    providerOfferingPlaceLimits.addAll(unModifiableProviderOfferingPlaceLimits);

    for (final curam.providerservice.impl.ProviderOfferingPlaceLimit providerOfferingPlaceLimit : sortProviderOfferingPlaceLimit(
      providerOfferingPlaceLimits)) {
      viewProviderOfferingDetails.providerOfferingPlaceLimitDtlsList.addRef(
        getProviderOfferingPlaceLimitFields(providerOfferingPlaceLimit));
      if ((providerOfferingPlaceLimit.getProviderOfferingPlaceLimitType().equals(
        ProviderOfferingPlaceLimitTypeEntry.NONCONTRACT))
          || (providerOfferingPlaceLimit.getProviderOfferingPlaceLimitType().equals(
            ProviderOfferingPlaceLimitTypeEntry.LIVECONTRACT))) {
        providerOfferingPlaceLimitDetailsForNonContracts = new ProviderOfferingPlaceLimitDetailsForNonContracts();
        providerOfferingPlaceLimitDetailsForNonContracts.assign(
          getProviderOfferingPlaceLimitFields(providerOfferingPlaceLimit));
        providerOfferingPlaceLimitDetailsForNonContracts.type = providerOfferingPlaceLimit.getProviderOfferingPlaceLimitType().toUserLocaleString();
        viewProviderOfferingDetails.placeLimitDetailsForNonContractList.addRef(
          providerOfferingPlaceLimitDetailsForNonContracts);
      } else if (providerOfferingPlaceLimit.getProviderOfferingPlaceLimitType().equals(
        ProviderOfferingPlaceLimitTypeEntry.PRELIVECONTRACT)) {
        providerOfferingPlaceLimitDetailsForContracts = new ProviderOfferingPlaceLimitDetailsForContracts();
        providerOfferingPlaceLimitDetailsForContracts.assign(
          getProviderOfferingPlaceLimitFields(providerOfferingPlaceLimit));
        providerOfferingPlaceLimitDetailsForContracts.type = providerOfferingPlaceLimit.getProviderOfferingPlaceLimitType().toUserLocaleString();
        viewProviderOfferingDetails.placeLimitDetailsForContractList.addRef(
          providerOfferingPlaceLimitDetailsForContracts);
      }
    }
    return viewProviderOfferingDetails;
  }

  /**
   * Gets the fields on the service layer to those presented to the user on the
   * screen.
   *
   * @param providerOfferingRate
   * the service layer object from which the user-displayable fields
   * must be mapped
   *
   * @return the dtls struct containing the fields for display
   */
  // BEGIN, CR00177241, PM
  protected ProviderOfferingRateDetails getProviderOfferingRateFieldsForList(
    // END, CR00177241
    final curam.providerservice.impl.ProviderOfferingRate providerOfferingRate) {
    final ProviderOfferingRateDetails providerOfferingRateDetails = new ProviderOfferingRateDetails();

    providerOfferingRateDetails.providerOfferingRateID = providerOfferingRate.getID();
    providerOfferingRateDetails.startDate = providerOfferingRate.getDateRange().start();
    providerOfferingRateDetails.endDate = providerOfferingRate.getDateRange().end();
    providerOfferingRateDetails.type = providerOfferingRate.getProviderOfferingRateType().toUserLocaleString();
    providerOfferingRateDetails.versionNo = providerOfferingRate.getVersionNo();

    if (providerOfferingRate.getMinAmount().isNegative()) {
      providerOfferingRateDetails.minAmountString = kEmptyString;
    } else {
      providerOfferingRateDetails.minAmountString = providerOfferingRate.getMinAmount().toString();
    }

    if (providerOfferingRate.getMaxAmount().isNegative()) {
      providerOfferingRateDetails.maxAmountString = kEmptyString;
    } else {
      providerOfferingRateDetails.maxAmountString = providerOfferingRate.getMaxAmount().toString();
    }

    if (providerOfferingRate.getFixedAmount().isNegative()) {
      providerOfferingRateDetails.fixedAmountString = kEmptyString;
    } else {
      providerOfferingRateDetails.fixedAmountString = providerOfferingRate.getFixedAmount().toString();
    }

    return providerOfferingRateDetails;
  }

  /**
   * Maps the fields on the service layer to those presented to the user on the
   * screen.
   *
   * @param providerOfferingRate
   * the service layer object from which the user-displayable fields
   * must be mapped
   *
   * @return the details struct containing the fields for display
   */
  // BEGIN, CR00177241, PM
  protected ProviderOfferingRateDetails getProviderOfferingRateFields(
    // END, CR00177241
    final curam.providerservice.impl.ProviderOfferingRate providerOfferingRate) {
    final ProviderOfferingRateDetails providerOfferingRateDetails = new ProviderOfferingRateDetails();

    providerOfferingRateDetails.providerOfferingRateID = providerOfferingRate.getID();
    providerOfferingRateDetails.providerOfferingID = providerOfferingRate.getProviderOffering().getID();
    providerOfferingRateDetails.startDate = providerOfferingRate.getDateRange().start();
    providerOfferingRateDetails.endDate = providerOfferingRate.getDateRange().end();
    providerOfferingRateDetails.minAmountString = money2String(
      providerOfferingRate.getMinAmount());
    providerOfferingRateDetails.maxAmountString = money2String(
      providerOfferingRate.getMaxAmount());
    providerOfferingRateDetails.fixedAmountString = money2String(
      providerOfferingRate.getFixedAmount());
    providerOfferingRateDetails.versionNo = providerOfferingRate.getVersionNo();
    providerOfferingRateDetails.comments = providerOfferingRate.getComments();

    return providerOfferingRateDetails;
  }

  /**
   * Maps the fields on the service layer to those presented to the user on the
   * screen.
   *
   * @param providerOfferingPlaceLimit
   * the service layer object from which the user-displayable fields
   * must be mapped
   *
   * @return the dtls struct containing the fields for display
   */
  // BEGIN, CR00177241, PM
  protected ProviderOfferingPlaceLimitDtls getProviderOfferingPlaceLimitFields(
    // END, CR00177241
    final curam.providerservice.impl.ProviderOfferingPlaceLimit providerOfferingPlaceLimit) {
    final ProviderOfferingPlaceLimitDtls providerOfferingPlaceLimitDtls = new ProviderOfferingPlaceLimitDtls();

    providerOfferingPlaceLimitDtls.providerOfferingPlaceLimitID = providerOfferingPlaceLimit.getID();
    providerOfferingPlaceLimitDtls.providerOfferingID = providerOfferingPlaceLimit.getProviderOffering().getID();
    providerOfferingPlaceLimitDtls.startDate = providerOfferingPlaceLimit.getDateRange().start();
    providerOfferingPlaceLimitDtls.endDate = providerOfferingPlaceLimit.getDateRange().end();
    providerOfferingPlaceLimitDtls.placeLimit = providerOfferingPlaceLimit.getPlaceLimit();
    providerOfferingPlaceLimitDtls.recordStatus = providerOfferingPlaceLimit.getLifecycleState().getCode();
    providerOfferingPlaceLimitDtls.versionNo = providerOfferingPlaceLimit.getVersionNo();

    return providerOfferingPlaceLimitDtls;
  }

  /**
   * Updates the provider offering.
   *
   * @param providerOfferingDtls
   * Contains the details for the provider offering to be modified.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void updateProviderOffering(ProviderOfferingDtls providerOfferingDtls)
    throws AppException, InformationalException {
    final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      providerOfferingDtls.providerOfferingID);

    setProviderOfferingFields(providerOffering, providerOfferingDtls);
    providerOffering.setEndReason(
      ProviderOfferingEndReasonEntry.get(providerOfferingDtls.endReason));

    providerOffering.modify(providerOfferingDtls.versionNo);

  }

  /**
   * Creates a provider offering rate for a provider offering.
   *
   * @param providerOfferingRateDetails
   * Contains the details for the provider offering rate to be created.
   *
   * @return ProviderOfferingRateKey The key for the new ProviderOfferingRate
   * created.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderOfferingRateKey createProviderServiceOfferingRate(
    ProviderOfferingRateDetails providerOfferingRateDetails)
    throws AppException, InformationalException {
    curam.providerservice.impl.ProviderOfferingRate providerOfferingRate = providerOfferingRateDAO.newInstance();

    // map details passed from client
    setProviderOfferingRateFields(providerOfferingRate,
      providerOfferingRateDetails);

    providerOfferingRate.insert();

    ProviderOfferingRateKey providerOfferingRateKey = new ProviderOfferingRateKey();

    providerOfferingRateKey.providerOfferingRateID = providerOfferingRate.getID();
    return providerOfferingRateKey;
  }

  /**
   * Maps the fields updateable by the user to the fields on the service layer
   * object.
   *
   *
   * @param providerOfferingRate
   * the service layer object into which the user-updateable fields
   * must be mapped
   * @param providerOfferingRateDetails
   * struct contain fields set by the user (as well as other fields
   * which will be ignored)
   *
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void setProviderOfferingRateFields(
    // END, CR00177241
    final curam.providerservice.impl.ProviderOfferingRate providerOfferingRate,
    final ProviderOfferingRateDetails providerOfferingRateDetails)
    throws AppException, InformationalException {

    final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      providerOfferingRateDetails.providerOfferingID);

    providerOfferingRate.setProviderOffering(providerOffering);
    providerOfferingRate.setComments(providerOfferingRateDetails.comments);
    providerOfferingRate.setDefaultRates();

    // Check if at least fixed or minimum or maximum rate is entered
    if ((providerOfferingRateDetails.fixedAmountString + providerOfferingRateDetails.maxAmountString + providerOfferingRateDetails.minAmountString).trim().length()
      == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDEROFFERINGRATEExceptionCreator.ERR_PROVIDEROFFERINGRATE_XFV_MANDATORY_FIELDS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);

    } else {
      // Try to set the provider offering rate
      try {
        if (!providerOfferingRateDetails.fixedAmountString.trim().equals(
          kEmptyString)) {
          providerOfferingRate.setFixedAmount(
            string2Money(providerOfferingRateDetails.fixedAmountString));
        }
      } catch (Exception e) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDEROFFERINGRATEExceptionCreator.ERR_PROVIDEROFFERINGRATE_FV_FIXED_AMT_INVALID_ENTRY(
            providerOfferingRateDetails.fixedAmountString),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            1);
      }
      try {
        if (!providerOfferingRateDetails.maxAmountString.trim().equals(
          kEmptyString)) {
          providerOfferingRate.setMaxAmount(
            string2Money(providerOfferingRateDetails.maxAmountString));
        }
      } catch (Exception e) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDEROFFERINGRATEExceptionCreator.ERR_PROVIDEROFFERINGRATE_FV_MAX_AMT_INVALID_ENTRY(
            providerOfferingRateDetails.maxAmountString),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            1);
      }
      try {
        if (!providerOfferingRateDetails.minAmountString.trim().equals(
          kEmptyString)) {
          providerOfferingRate.setMinAmount(
            string2Money(providerOfferingRateDetails.minAmountString));
        }
      } catch (Exception e) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDEROFFERINGRATEExceptionCreator.ERR_PROVIDEROFFERINGRATE_FV_MIN_AMT_INVALID_ENTRY(
            providerOfferingRateDetails.minAmountString),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            1);
      }
    }

    // Check if fixed rate is entered with min or max rate
    if (providerOfferingRateDetails.fixedAmountString.trim().length() > 0
      && ((providerOfferingRateDetails.maxAmountString + providerOfferingRateDetails.minAmountString).trim().length()
        > 0)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDEROFFERINGRATEExceptionCreator.ERR_PROVIDEROFFERINGRATE_XFV_INCORRECT_FIELD_ENTRY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    final DateRange dateRange = new DateRange(
      providerOfferingRateDetails.startDate,
      providerOfferingRateDetails.endDate);

    providerOfferingRate.setDateRange(dateRange);

  }

  /**
   * Updates a provider offering rate for the provider offering.
   *
   * @param providerOfferingRateDetails
   * Contains the details for the provider offering rate to be
   * modified.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void updateProviderServiceOfferingRate(
    ProviderOfferingRateDetails providerOfferingRateDetails)
    throws AppException, InformationalException {
    final curam.providerservice.impl.ProviderOfferingRate providerOfferingRate = providerOfferingRateDAO.get(
      providerOfferingRateDetails.providerOfferingRateID);

    final ProviderOfferingRateDtls oldProviderOfferingRate = new ProviderOfferingRateDtls();

    oldProviderOfferingRate.startDate = providerOfferingRate.getDateRange().start();
    oldProviderOfferingRate.endDate = providerOfferingRate.getDateRange().start();
    oldProviderOfferingRate.fixedAmount = providerOfferingRate.getFixedAmount();
    oldProviderOfferingRate.minAmount = providerOfferingRate.getMinAmount();
    oldProviderOfferingRate.maxAmount = providerOfferingRate.getMaxAmount();

    setProviderOfferingRateFields(providerOfferingRate,
      providerOfferingRateDetails);

    providerOfferingRate.modify(providerOfferingRateDetails.versionNo);

  }

  /**
   * A helper method to convert a string to a money instance
   *
   * @param string -
   * A money value in string format
   * @return - money value in the form of a money instance.
   */
  // BEGIN, CR00177241, PM
  protected Money string2Money(final String string) {
    // END, CR00177241
    return StringHelper.isEmpty(string) ? null : new Money(string);
  }

  /**
   * A helper method to convert a money to a string instance
   *
   * @param money -
   * A money value in money format
   * @return - money value in the form of a string instance.
   */
  // BEGIN, CR00177241, PM
  protected String money2String(final Money money) {
    // END, CR00177241
    return money.isNegative() ? StringHelper.EMPTY_STRING : money.toString();
  }

  /**
   * Gets the provider offering rate details.
   *
   * @param providerOfferingRateKey
   * The key for the Provider Offering Rate.
   * @return ProviderOfferingRateDetails Contains the provider offering rate
   * details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderOfferingRateDetails viewProviderServiceOfferingRate(
    ProviderOfferingRateKey providerOfferingRateKey) throws AppException,
      InformationalException {
    ProviderOfferingRateDetails providerOfferingRateDetails = new ProviderOfferingRateDetails();

    final curam.providerservice.impl.ProviderOfferingRate providerOfferingRate = providerOfferingRateDAO.get(
      providerOfferingRateKey.providerOfferingRateID);

    providerOfferingRateDetails = getProviderOfferingRateFields(
      providerOfferingRate);
    return providerOfferingRateDetails;
  }

  /**
   * Logically deletes a provider offering rate.
   *
   * @param keyVersionDetails
   * Contains the id and the version of the provider offering rate
   * which is to be logically deleted.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public void removeProviderServiceOfferingRate(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {

    final curam.providerservice.impl.ProviderOfferingRate providerOfferingRate = providerOfferingRateDAO.get(
      keyVersionDetails.id);

    providerOfferingRate.remove(keyVersionDetails.version);
  }

  /**
   * Logically deletes a provider offering.
   *
   * @param keyVersionDetails
   * Contains the id and the version of the provider offering which is
   * to be logically deleted.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelProviderOffering(KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      keyVersionDetails.id);

    providerOffering.cancel(keyVersionDetails.version);

  }

  /**
   * Approves a provider offering.
   *
   * @param keyVersionDetails
   * Contains the id and the version of the provider offering which is
   * to be approved.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void approveProviderOffering(KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {
    final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      keyVersionDetails.id);

    providerOffering.approve(keyVersionDetails.version);

    // Send Provider Offering approval Notification
    final curam.provider.impl.Provider provider = providerOffering.getProvider();
    ServiceOffering serviceOffering = providerOffering.getServiceOffering();

    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();
    ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = provider.getID();
    providerNotificationKey.serviceOfferingID = serviceOffering.getID();
    providerNotificationKey.event = ProviderNotificationEvent.SERVICE_OFFERING_APPROVAL;
    providerNotificationKey.date = providerOffering.getDateRange().start();

    providerNotification.sendNotification(providerNotificationKey);

  }

  /**
   * Displays the warnings to the user about approval criteria required for
   * provider offering, before he approves a provider offering.
   *
   * @param keyVersionDetails
   * Contains the id and the version of the provider offering which is
   * to be approved.
   * @return InformationalMessageList Contains list of informationals.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMessageList checkApprovalCriteria(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {

    // START CR00085749, SP
    final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      keyVersionDetails.id);

    return providerOffering.checkApprovalCriteria(keyVersionDetails);
    // END CR00085749
  }

  /**
   * Denies approval of a provider offering.
   *
   * @param reasonDetails
   * Contains the id , version and the rejection reason for the
   * provider offering which is to be denied approval.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void denyProviderOffering(ReasonDetails reasonDetails)
    throws AppException, InformationalException {
    final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      reasonDetails.keyVersionDetails.id);

    providerOffering.deny(reasonDetails.keyVersionDetails.version,
      ProviderOfferingDenialReasonEntry.get(reasonDetails.reason));

    // Send Provider Offering deny approval Notification
    final curam.provider.impl.Provider provider = providerOffering.getProvider();
    ServiceOffering serviceOffering = providerOffering.getServiceOffering();

    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();
    ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = provider.getID();
    providerNotificationKey.serviceOfferingID = serviceOffering.getID();
    providerNotificationKey.event = ProviderNotificationEvent.SERVICE_OFFERING_APPROVAL_DENIAL;
    providerNotificationKey.reason = CodeTable.getOneItem(
      ProviderOfferingDenialReason.TABLENAME, reasonDetails.reason);
    providerNotification.sendNotification(providerNotificationKey);

  }

  /**
   * Sorts a set of provider offerings into a sorted list for display.
   *
   * @param unsortedProviderOfferings
   * the set of provider offerings
   * @return a sorted list of provider offerings for display.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.providerservice.impl.ProviderOffering> sortProviderOfferings(
    // END, CR00177241
    final Set<curam.providerservice.impl.ProviderOffering> unsortedProviderOfferings) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    final List<curam.providerservice.impl.ProviderOffering> providerOfferings = new ArrayList<curam.providerservice.impl.ProviderOffering>(
      unsortedProviderOfferings);

    Collections.sort(providerOfferings,
      new Comparator<curam.providerservice.impl.ProviderOffering>() {
      public int compare(
        final curam.providerservice.impl.ProviderOffering lhs,
        curam.providerservice.impl.ProviderOffering rhs) {
        return lhs.getServiceOffering().getName().compareTo(
          rhs.getServiceOffering().getName());
      }
    });
    return providerOfferings;
  }

  /**
   * Sorts a set of provider offering rates into a sorted list for display.
   *
   * @param unsortedProviderOfferingRates
   * the set of provider offerings
   * @return a sorted list of provider offerings for display.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.providerservice.impl.ProviderOfferingRate> sortProviderOfferingRates(
    // END, CR00177241
    final Set<curam.providerservice.impl.ProviderOfferingRate> unsortedProviderOfferingRates) {

    // Sort by Start Date descending order for display - using a list
    // (instead
    // of a set)

    final List<curam.providerservice.impl.ProviderOfferingRate> providerOfferingRates = new ArrayList<curam.providerservice.impl.ProviderOfferingRate>(
      unsortedProviderOfferingRates);

    Collections.sort(providerOfferingRates,
      new Comparator<curam.providerservice.impl.ProviderOfferingRate>() {
      public int compare(
        final curam.providerservice.impl.ProviderOfferingRate lhs,
        curam.providerservice.impl.ProviderOfferingRate rhs) {
        return rhs.getDateRange().start().compareTo(lhs.getDateRange().start());
      }
    });
    return providerOfferingRates;

  }

  /**
   * Sorts a set of provider offering place limits into a sorted list for
   * display.
   *
   * @param unsortedProviderOfferingPlaceLimits
   * the set of provider offering place limits
   * @return a sorted list of provider offering place limits for display.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.providerservice.impl.ProviderOfferingPlaceLimit> sortProviderOfferingPlaceLimit(
    // END, CR00177241
    final Set<curam.providerservice.impl.ProviderOfferingPlaceLimit> unsortedProviderOfferingPlaceLimits) {

    // Sort by Start Date descending order for display - using a list
    // (instead
    // of a set)
    final List<curam.providerservice.impl.ProviderOfferingPlaceLimit> providerOfferingPlaceLimits = new ArrayList<curam.providerservice.impl.ProviderOfferingPlaceLimit>(
      unsortedProviderOfferingPlaceLimits);

    Collections.sort(providerOfferingPlaceLimits,
      new Comparator<curam.providerservice.impl.ProviderOfferingPlaceLimit>() {
      public int compare(
        final curam.providerservice.impl.ProviderOfferingPlaceLimit lhs,
        curam.providerservice.impl.ProviderOfferingPlaceLimit rhs) {
        return rhs.getDateRange().start().compareTo(lhs.getDateRange().start());
      }
    });
    return providerOfferingPlaceLimits;
  }

  // BEGIN, CR00110056, JSP
  /**
   * Gets the provider offering summary details from provider offering.
   *
   * @param providerOffering
   * Contains the provider offering details.
   * @return ProviderOfferingSummaryDetails The Provider offerings summary
   * details.
   */
  protected ProviderOfferingSummaryDetails getProviderOfferingSummaryDetails(
    curam.providerservice.impl.ProviderOffering providerOffering) {

    ProviderOfferingSummaryDetails providerOfferingSummaryDetails = new ProviderOfferingSummaryDetails();
    ServiceOffering serviceOffering = providerOffering.getServiceOffering();

    providerOfferingSummaryDetails.serviceOfferingID = serviceOffering.getID();
    providerOfferingSummaryDetails.providerOfferingID = providerOffering.getID();

    providerOfferingSummaryDetails.startDate = providerOffering.getDateRange().start();
    providerOfferingSummaryDetails.endDate = providerOffering.getDateRange().end();
    providerOfferingSummaryDetails.name = serviceOffering.getName();
    providerOfferingSummaryDetails.recordStatus = providerOffering.getLifecycleState().getCode();

    return providerOfferingSummaryDetails;
  }

  // END, CR00110056

  // BEGIN, CR00178272, AK

  /**
   * Creates a text translation for the provider offering attribute, client fee
   * information.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the client fee information.
   *
   * @return The localizable text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00180149, ASN
  public LocalizableTextTranslationDetails addClientFeeInfoTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {
    LocalizableTextTranslationDetails result = new LocalizableTextTranslationDetails();
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    validateTextEntered(localizableTextTranslationDetails.text);
    localizableTextHandler.setShortTextInd(true);
    localizableTextHandler.addValue(localizableTextTranslationDetails.text,
      LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
    // END, CR00180149
    result.localizableTextID = localizableTextHandler.store();
    curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      localizableTextTranslationDetails.localizableTextParentID);

    providerOffering.setClientFeeInfoTextID(result.localizableTextID);
    // BEGIN, CR00180149, ASN
    providerOffering.modify(
      localizableTextTranslationDetails.keyVersionDetails.version);
    // END, CR00180149
    return result;
  }

  /**
   * Creates a text translation for the provider offering attribute, documents
   * required information.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the documents required information.
   *
   * @return The localizable text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00180149, ASN
  public LocalizableTextTranslationDetails addDocumentsRequiredInfoTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {
    LocalizableTextTranslationDetails result = new LocalizableTextTranslationDetails();
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    validateTextEntered(localizableTextTranslationDetails.text);
    localizableTextHandler.setShortTextInd(true);
    localizableTextHandler.addValue(localizableTextTranslationDetails.text,
      LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
    // END, CR00180149
    result.localizableTextID = localizableTextHandler.store();
    curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      localizableTextTranslationDetails.localizableTextParentID);

    providerOffering.setDocumentsRequiredInfoTextID(result.localizableTextID);
    // BEGIN, CR00180149, ASN
    providerOffering.modify(
      localizableTextTranslationDetails.keyVersionDetails.version);
    // END, CR00180149
    return result;
  }

  /**
   * Creates a text translation for the provider offering attribute, eligibility
   * information.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the eligibility information.
   *
   * @return The localizable text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00180149, ASN
  public LocalizableTextTranslationDetails addEligibilityInfoTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {
    LocalizableTextTranslationDetails result = new LocalizableTextTranslationDetails();
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    validateTextEntered(localizableTextTranslationDetails.text);
    localizableTextHandler.setShortTextInd(true);
    localizableTextHandler.addValue(localizableTextTranslationDetails.text,
      LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
    // END, CR00180149
    result.localizableTextID = localizableTextHandler.store();
    curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      localizableTextTranslationDetails.localizableTextParentID);

    // BEGIN, CR00180149, ASN
    providerOffering.setEligibilityInfoTextID(result.localizableTextID);
    providerOffering.modify(
      localizableTextTranslationDetails.keyVersionDetails.version);
    // END, CR00180149
    return result;
  }

  /**
   * Creates a text translation for the provider offering attribute, intake
   * procedure Information.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the intake procedure information.
   *
   * @return The localizable text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00180149, ASN
  public LocalizableTextTranslationDetails addIntakeProcedureTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {
    LocalizableTextTranslationDetails result = new LocalizableTextTranslationDetails();
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    validateTextEntered(localizableTextTranslationDetails.text);
    localizableTextHandler.setShortTextInd(true);
    localizableTextHandler.addValue(localizableTextTranslationDetails.text,
      LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
    // END, CR00180149
    result.localizableTextID = localizableTextHandler.store();
    curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      localizableTextTranslationDetails.localizableTextParentID);

    // BEGIN, CR00180149, ASN
    providerOffering.setIntakeProcedureInfoTextID(result.localizableTextID);
    providerOffering.modify(
      localizableTextTranslationDetails.keyVersionDetails.version);
    // END, CR00180149
    return result;
  }

  /**
   * Creates a provider offering i.e., adds a service offering to the
   * provider.
   *
   * @param providerInformation
   * The provider offering details to be created.
   *
   * @return The provider offering ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public curam.cpm.facade.struct.ProviderOfferingKey createProviderOfferingDetails(
    ProviderOfferingInformation providerInformation) throws AppException,
      InformationalException {

    curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.newInstance();

    setProviderOfferingDetails(providerOffering, providerInformation);

    providerOffering.insert();

    if (providerOffering.getLifecycleState().equals(
      ProviderOfferingStatusEntry.APPROVED)) {
      final curam.provider.impl.Provider provider = providerOffering.getProvider();
      ServiceOffering serviceOffering = providerOffering.getServiceOffering();

      ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();
      ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

      providerNotificationKey.concernRoleID = provider.getID();
      providerNotificationKey.serviceOfferingID = serviceOffering.getID();
      providerNotificationKey.event = ProviderNotificationEvent.SERVICE_OFFERING_APPROVAL;
      providerNotificationKey.date = providerOffering.getDateRange().start();
      providerNotification.sendNotification(providerNotificationKey);
    }

    curam.cpm.facade.struct.ProviderOfferingKey providerOfferingKey = new curam.cpm.facade.struct.ProviderOfferingKey();

    providerOfferingKey.providerOfferingKey.providerOfferingID = providerOffering.getID();
    return providerOfferingKey;

  }

  /**
   * Modifies the provider offering details.
   *
   * @param providerOfferingInformation
   * The provider offering details to be modified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void updateProviderOfferingDetails(
    ProviderOfferingInformation providerOfferingInformation)
    throws AppException, InformationalException {

    final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      providerOfferingInformation.providerOfferingDtls.providerOfferingID);

    setProviderOfferingDetails(providerOffering, providerOfferingInformation);
    providerOffering.setEndReason(
      ProviderOfferingEndReasonEntry.get(
        providerOfferingInformation.providerOfferingDtls.endReason));

    providerOffering.modify(
      providerOfferingInformation.providerOfferingDtls.versionNo);
  }

  /**
   * Reads the provider offering details.
   *
   * @param providerOfferingKey
   * The provider offering ID.
   *
   * @return The provider offering details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewProviderOfferingInformation viewProviderOfferingDetails(
    curam.cpm.facade.struct.ProviderOfferingKey providerOfferingKey) throws AppException,
      InformationalException {
    ViewProviderOfferingInformation providerOfferingInformation = new ViewProviderOfferingInformation();
    ProviderOfferingRateDetailsForNonContracts providerOfferingRateDetailsForNonContracts;
    ProviderOfferingPlaceLimitDetailsForContracts providerOfferingPlaceLimitDetailsForContracts;
    ProviderOfferingPlaceLimitDetailsForNonContracts providerOfferingPlaceLimitDetailsForNonContracts;

    final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      providerOfferingKey.providerOfferingKey.providerOfferingID);

    final curam.provider.impl.Provider provider = providerOffering.getProvider();

    ServiceOffering serviceOffering = providerOffering.getServiceOffering();

    providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.serviceOfferingID = serviceOffering.getID();
    providerOfferingInformation.providerOfferingDetails.serviceOfferingName = serviceOffering.getName();
    providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.startDate = providerOffering.getDateRange().start();
    providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.endDate = providerOffering.getDateRange().end();
    providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.providerOfferingID = providerOffering.getID();
    providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.providerConcernRoleID = provider.getID();
    providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.endReason = providerOffering.getEndReason().getCode();
    providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.denialReason = providerOffering.getDenialReason().getCode();
    providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.comments = providerOffering.getComments();

    providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.recordStatus = providerOffering.getLifecycleState().getCode();

    providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.versionNo = providerOffering.getVersionNo();

    getClientInformation(providerOffering, providerOfferingInformation);

    Set<ProviderOfferingRate> unModifiableProviderOfferingRates = providerOffering.getProviderOfferingRates();
    Set<ProviderOfferingRate> providerOfferingRateRecords = new HashSet<ProviderOfferingRate>();

    providerOfferingRateRecords.addAll(unModifiableProviderOfferingRates);

    for (final curam.providerservice.impl.ProviderOfferingRate providerOfferingRate : sortProviderOfferingRates(
      providerOfferingRateRecords)) {
      providerOfferingInformation.providerOfferingDetails.providerOfferingRateDetailsList.addRef(
        getProviderOfferingRateFieldsForList(providerOfferingRate));
      if ((providerOfferingRate.getProviderOfferingRateType().equals(
        ProviderOfferingRateTypeEntry.NONCONTRACT))
          || (providerOfferingRate.getProviderOfferingRateType().equals(
            ProviderOfferingRateTypeEntry.LIVEANDLICENSEDCONTRACT))
            || (providerOfferingRate.getProviderOfferingRateType().equals(
              ProviderOfferingRateTypeEntry.LIVEANDINVALIDLICENSEDCONTRACT))
              || (providerOfferingRate.getProviderOfferingRateType().equals(
                ProviderOfferingRateTypeEntry.LIVECONTRACT))) {
        providerOfferingRateDetailsForNonContracts = new ProviderOfferingRateDetailsForNonContracts();
        providerOfferingRateDetailsForNonContracts.assign(
          getProviderOfferingRateFieldsForList(providerOfferingRate));
        providerOfferingInformation.providerOfferingDetails.providerOfferingRateDetailsForNonContracts.addRef(
          providerOfferingRateDetailsForNonContracts);
      }
    }

    Set<ProviderOfferingPlaceLimit> unModifiableProviderOfferingPlaceLimits = providerOffering.getProviderOfferingPlaceLimits();
    Set<ProviderOfferingPlaceLimit> providerOfferingPlaceLimits = new HashSet<ProviderOfferingPlaceLimit>();

    providerOfferingPlaceLimits.addAll(unModifiableProviderOfferingPlaceLimits);

    for (final curam.providerservice.impl.ProviderOfferingPlaceLimit providerOfferingPlaceLimit : sortProviderOfferingPlaceLimit(
      providerOfferingPlaceLimits)) {
      providerOfferingInformation.providerOfferingDetails.providerOfferingPlaceLimitDtlsList.addRef(
        getProviderOfferingPlaceLimitFields(providerOfferingPlaceLimit));
      if ((providerOfferingPlaceLimit.getProviderOfferingPlaceLimitType().equals(
        ProviderOfferingPlaceLimitTypeEntry.NONCONTRACT))
          || (providerOfferingPlaceLimit.getProviderOfferingPlaceLimitType().equals(
            ProviderOfferingPlaceLimitTypeEntry.LIVECONTRACT))) {
        providerOfferingPlaceLimitDetailsForNonContracts = new ProviderOfferingPlaceLimitDetailsForNonContracts();
        providerOfferingPlaceLimitDetailsForNonContracts.assign(
          getProviderOfferingPlaceLimitFields(providerOfferingPlaceLimit));
        providerOfferingPlaceLimitDetailsForNonContracts.type = providerOfferingPlaceLimit.getProviderOfferingPlaceLimitType().toUserLocaleString();
        providerOfferingInformation.providerOfferingDetails.placeLimitDetailsForNonContractList.addRef(
          providerOfferingPlaceLimitDetailsForNonContracts);
      } else if (providerOfferingPlaceLimit.getProviderOfferingPlaceLimitType().equals(
        ProviderOfferingPlaceLimitTypeEntry.PRELIVECONTRACT)) {
        providerOfferingPlaceLimitDetailsForContracts = new ProviderOfferingPlaceLimitDetailsForContracts();
        providerOfferingPlaceLimitDetailsForContracts.assign(
          getProviderOfferingPlaceLimitFields(providerOfferingPlaceLimit));
        providerOfferingPlaceLimitDetailsForContracts.type = providerOfferingPlaceLimit.getProviderOfferingPlaceLimitType().toUserLocaleString();
        providerOfferingInformation.providerOfferingDetails.placeLimitDetailsForContractList.addRef(
          providerOfferingPlaceLimitDetailsForContracts);
      }
    }

    return providerOfferingInformation;

  }
  
  // BEGIN, CR00199320, GP
  /**
   * Lists all the provider offerings for a given provider.
   *
   * @param providerKey
   * Provider for which provider offerings have to be listed.
   *
   * @return The list of provider offerings.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderOfferingSummaryVersionDetailsList listProviderOfferings(
    final ProviderKey providerKey) throws AppException,
      InformationalException {

    ProviderOfferingSummaryVersionDetailsList providerOfferingSummaryVersionDetailsList = new ProviderOfferingSummaryVersionDetailsList();

    curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    Set<curam.providerservice.impl.ProviderOffering> unModifiableProviderOfferings = provider.getProviderOfferings();
    Set<curam.providerservice.impl.ProviderOffering> providerOfferings = new HashSet<curam.providerservice.impl.ProviderOffering>();

    providerOfferings.addAll(unModifiableProviderOfferings);

    for (final curam.providerservice.impl.ProviderOffering providerOffering : sortProviderOfferings(
      providerOfferings)) {

      providerOfferingSummaryVersionDetailsList.detailsList.addRef(
        getProviderOfferingSummaryVersionDetails(providerOffering));
    }

    return providerOfferingSummaryVersionDetailsList;
  }

  // END, CR00199320
  
  /**
   * Reads the client information like intake procedure information, eligibility
   * information, etc. for the provider offering.
   *
   * @param providerOffering
   * The provider offering object.
   * @param providerOfferingInformation
   * The provider offering details including the information for the
   * client.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void getClientInformation(
    final curam.providerservice.impl.ProviderOffering providerOffering,
    final ViewProviderOfferingInformation providerOfferingInformation)
    throws AppException, InformationalException {

    if (0 != providerOffering.getIntakeProcedureInfoTextID()) {
      providerOfferingInformation.intakeProcedureInfo = providerOffering.getIntakeProcedureInfo().getValue();
      providerOfferingInformation.intakeProcInfoTranslationExistsInd = true;
      providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.intkProcInfoTextID = providerOffering.getIntakeProcedureInfoTextID();

      // BEGIN, CR00180149, ASN
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.intkProcInfoTextID);

      if (0 == localizableTextHandler.listTranslations().size()) {
        providerOfferingInformation.intakeProcAddInd = true;
      } else {
        providerOfferingInformation.intakeProcViewInd = true;
      }
    } else {
      providerOfferingInformation.intakeProcInfoTranslationExistsInd = false;
    }

    if (0 != providerOffering.getEligibilityInfoTextID()) {
      providerOfferingInformation.eligibilityInfo = providerOffering.getEligibilityInfo().getValue();
      providerOfferingInformation.eligibilityInfoTranslationExistsInd = true;
      providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.eligibilityInfoTextID = providerOffering.getEligibilityInfoTextID();

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.eligibilityInfoTextID);

      if (0 == localizableTextHandler.listTranslations().size()) {
        providerOfferingInformation.eligibilityAddInd = true;
      } else {
        providerOfferingInformation.eligibilityViewInd = true;
      }
    } else {
      providerOfferingInformation.eligibilityInfoTranslationExistsInd = false;
    }

    if (providerOffering.getClientFeeInfoTextID() != 0) {
      providerOfferingInformation.clientFeeInfo = providerOffering.getClientFeeInfo().getValue();
      providerOfferingInformation.clientFeeInfoTranslationExistsInd = true;
      providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.clientFeeInfTextID = providerOffering.getClientFeeInfoTextID();

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.clientFeeInfTextID);

      if (0 == localizableTextHandler.listTranslations().size()) {
        providerOfferingInformation.clientFeeAddInd = true;
      } else {
        providerOfferingInformation.clientFeeViewInd = true;
      }

    }

    if (providerOffering.getDocumentsRequiredInfoTextID() != 0) {
      providerOfferingInformation.documentsRequiredInfo = providerOffering.getDocumentsRequiredInfo().getValue();
      providerOfferingInformation.documentsReqInfoTranslationExistsInd = true;
      providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.docsReqdInfTextID = providerOffering.getDocumentsRequiredInfoTextID();

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        providerOfferingInformation.providerOfferingDetails.providerOfferingDtls.docsReqdInfTextID);

      if (0 == localizableTextHandler.listTranslations().size()) {
        providerOfferingInformation.docReqdAddInd = true;
      } else {
        providerOfferingInformation.docReqdViewInd = true;
      }
    }
    // END, CR00180149
  }

  // BEGIN, CR00199320, GP
  /**
   * Gets the provider offering summary details from provider offering.
   *
   * @param providerOffering
   * Provider offering for which summary version details are to be
   * retrieved.
   *
   * @return The Provider offering summary details.
   */
  protected ProviderOfferingSummaryVersionDetails getProviderOfferingSummaryVersionDetails(
    final curam.providerservice.impl.ProviderOffering providerOffering) {

    ProviderOfferingSummaryVersionDetails providerOfferingSummaryVersionDetails = new ProviderOfferingSummaryVersionDetails();

    ServiceOffering serviceOffering = providerOffering.getServiceOffering();

    providerOfferingSummaryVersionDetails.versionDetails.serviceOfferingID = serviceOffering.getID();
    providerOfferingSummaryVersionDetails.versionDetails.providerOfferingID = providerOffering.getID();

    providerOfferingSummaryVersionDetails.versionDetails.startDate = providerOffering.getDateRange().start();
    providerOfferingSummaryVersionDetails.versionDetails.endDate = providerOffering.getDateRange().end();
    providerOfferingSummaryVersionDetails.versionDetails.name = serviceOffering.getName();
    providerOfferingSummaryVersionDetails.versionDetails.recordStatus = providerOffering.getLifecycleState().getCode();
    providerOfferingSummaryVersionDetails.versionNo = providerOffering.getVersionNo();
    providerOfferingSummaryVersionDetails.endReason = providerOffering.getEndReason().getCode();
    providerOfferingSummaryVersionDetails.rejectionReason = providerOffering.getDenialReason().getCode();

    return providerOfferingSummaryVersionDetails;
  }

  // END, CR00199320
  
  /**
   * Sets the fields modifiable by the user to the fields on the service layer
   * object.
   *
   * @param providerOffering
   * the service layer object into which the user-modifiable fields
   * must be mapped.
   * @param providerOfferingInformation
   * Contains fields set by the user (as well as other fields
   * which will be ignored).
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void setProviderOfferingDetails(
    final curam.providerservice.impl.ProviderOffering providerOffering,
    final ProviderOfferingInformation providerOfferingInformation)
    throws AppException, InformationalException {

    final curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceOfferingDAO.get(
      providerOfferingInformation.providerOfferingDtls.serviceOfferingID);
    final curam.provider.impl.Provider provider = providerDAO.get(
      providerOfferingInformation.providerOfferingDtls.providerConcernRoleID);

    providerOffering.setServiceOffering(serviceOffering);
    providerOffering.setProvider(provider);
    providerOffering.setComments(
      providerOfferingInformation.providerOfferingDtls.comments);
    final DateRange dateRange = new DateRange(
      providerOfferingInformation.providerOfferingDtls.startDate,
      providerOfferingInformation.providerOfferingDtls.endDate);

    providerOffering.setDateRange(dateRange);
    if (providerOffering.getIntakeProcedureInfoTextID() == 0) {
      LocalizableTextTranslationDetails localizableTextTranslationDetails = new LocalizableTextTranslationDetails();
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.setShortTextInd(true);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text);
      providerOffering.setIntakeProcedureInfoTextID(
        localizableTextHandler.store());
    }
    providerOffering.getIntakeProcedureInfo().addValue(
      providerOfferingInformation.intakeProcedureInfo);

    if (providerOffering.getClientFeeInfoTextID() == 0) {
      LocalizableTextTranslationDetails localizableTextTranslationDetails = new LocalizableTextTranslationDetails();
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.setShortTextInd(true);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text);
      providerOffering.setClientFeeInfoTextID(localizableTextHandler.store());
    }
    providerOffering.getClientFeeInfo().addValue(
      providerOfferingInformation.clientFeeInfo);

    if (providerOffering.getEligibilityInfoTextID() == 0) {
      LocalizableTextTranslationDetails localizableTextTranslationDetails = new LocalizableTextTranslationDetails();
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.setShortTextInd(true);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text);
      providerOffering.setEligibilityInfoTextID(localizableTextHandler.store());
    }
    providerOffering.getEligibilityInfo().addValue(
      providerOfferingInformation.eligibilityInfo);

    if (providerOffering.getDocumentsRequiredInfoTextID() == 0) {
      LocalizableTextTranslationDetails localizableTextTranslationDetails = new LocalizableTextTranslationDetails();
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.setShortTextInd(true);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text);
      providerOffering.setDocumentsRequiredInfoTextID(
        localizableTextHandler.store());
    }
    providerOffering.getDocumentsRequiredInfo().addValue(
      providerOfferingInformation.documentsRequiredInfo);
  }

  // END, CR00178272

  /**
   * Ensures that the String passed as an argument is not empty. If it is, a
   * validation is thrown.
   *
   * @param text
   * The localizable text.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void validateTextEntered(String text) throws AppException,
      // END, CR00177241
      InformationalException {
    if (StringHelper.isEmpty(text)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LOCALIZABLETEXTExceptionCreator.ERR_TEXT_IS_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      ValidationHelper.failIfErrorsExist();

    }
  }
}
