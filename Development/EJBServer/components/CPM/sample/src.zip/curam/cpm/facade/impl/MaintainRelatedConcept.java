/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.core.sl.struct.WizardStateID;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.RelatedConceptDetails;
import curam.cpm.facade.struct.RelatedConceptDetailsList;
import curam.cpm.facade.struct.RelatedConceptWizMenuDetails;
import curam.cpm.facade.struct.SearchTaxonomyTermsWizForRelatedConcept;
import curam.cpm.facade.struct.TaxonomyTermDetails;
import curam.cpm.facade.struct.TaxonomyTermRelatedConceptDetails;
import curam.cpm.facade.struct.TaxonomyTermWizDetailsList;
import curam.cpm.facade.struct.ViewRelatedConceptDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.RelatedConceptKey;
import curam.cpm.sl.entity.struct.TaxonomyTermRelatedConceptKey;
import curam.message.TAXONOMYTERM;
import curam.message.impl.TAXONOMYTERMExceptionCreator;
import curam.taxonomy.impl.RelatedConcept;
import curam.taxonomy.impl.RelatedConceptDAO;
import curam.taxonomy.impl.RelatedConceptWizState;
import curam.taxonomy.impl.RelatedConceptWizStateImpl;
import curam.taxonomy.impl.TaxonomyConstants;
import curam.taxonomy.impl.TaxonomyInEditData;
import curam.taxonomy.impl.TaxonomyInEditDataConverter;
import curam.taxonomy.impl.TaxonomyInEditDataDAO;
import curam.taxonomy.impl.TaxonomyTerm;
import curam.taxonomy.impl.TaxonomyTermDAO;
import curam.taxonomy.impl.TaxonomyTermRelatedConcept;
import curam.taxonomy.impl.TaxonomyTermRelatedConceptDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.StringHelper;
import curam.util.type.StringList;


/**
 * Facade class having API's for maintaining the related concepts for taxonomy.
 */
public abstract class MaintainRelatedConcept extends curam.cpm.facade.base.MaintainRelatedConcept {

  /**
   * Reference to related concept DAO.
   *
   */
  @Inject
  protected RelatedConceptDAO relatedConceptDAO;

  /**
   * The related concept wizard state object.
   */
  protected RelatedConceptWizState relatedConceptWizState = new RelatedConceptWizStateImpl();

  /**
   * Reference to taxonomy in edit data converter.
   */
  @Inject
  protected TaxonomyInEditDataConverter taxonomyInEditDataConverter;

  /**
   * Reference to taxonomy in edit data DAO.
   */
  @Inject
  protected TaxonomyInEditDataDAO taxonomyInEditDataDAO;
  
  /**
   * Reference to taxonomy term DAO.
   *
   */
  @Inject
  protected TaxonomyTermDAO taxonomyTermDAO;

  /**
   * Reference to taxonomy term related concept DAO.
   *
   */
  @Inject
  protected TaxonomyTermRelatedConceptDAO taxonomyTermRelatedConceptDAO;

  /**
   * Constructor for the class.
   */
  public MaintainRelatedConcept() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a related concept.
   *
   * @param relatedConceptDetails
   * Contains the related concept details.
   *
   * @return The related concept ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RelatedConceptKey createRelatedConcept(
    final RelatedConceptDetails relatedConceptDetails) throws AppException,
      InformationalException {

    RelatedConceptKey relatedConceptKey = new RelatedConceptKey();
    WizardStateID wizardStateID = new WizardStateID();
    
    if (relatedConceptDetails.customInd) {
      
      relatedConceptDetails.dtls.customConceptInd = relatedConceptDetails.customInd;
    }

    if (relatedConceptDetails.actionString.equals(
      TaxonomyConstants.kStoreAction)) {
      wizardStateID = relatedConceptWizState.storeRelatedConcept(
        relatedConceptDetails);
      relatedConceptKey.relatedConceptID = wizardStateID.wizardStateID;
    } else {
      
      RelatedConcept relatedConcept = relatedConceptDAO.newInstance();

      setRelatedConceptDetails(relatedConceptDetails, relatedConcept);
      relatedConcept.insert();
      relatedConceptKey.relatedConceptID = relatedConcept.getID();
    }

    return relatedConceptKey;
  }

  /**
   * Retrieves all the related concepts.
   *
   * @return The list of related concepts.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RelatedConceptDetailsList listRelatedConcept() throws AppException,
      InformationalException {

    RelatedConceptDetailsList relatedConceptDetailsList = new RelatedConceptDetailsList();

    List<RelatedConcept> relatedConcepts = sortRelatedConcepts(
      relatedConceptDAO.readAll());

    for (final RelatedConcept relatedConcept : relatedConcepts) {
      RelatedConceptDetails relatedConceptDetails = new RelatedConceptDetails();

      relatedConceptDetailsList.details.addRef(
        getRelatedConceptDetails(relatedConceptDetails, relatedConcept));
    }
    
    return relatedConceptDetailsList;
  }

  /**
   * Modifies the related concept.
   *
   * @param relatedConceptDetails
   * Contains the related concept details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyRelatedConcept(final RelatedConceptDetails relatedConceptDetails)
    throws AppException,
      InformationalException {

    RelatedConcept relatedConcept = relatedConceptDAO.get(
      relatedConceptDetails.dtls.relatedConceptID);

    LOCALEEntry locale = getLocale();

    relatedConcept.setName(locale, relatedConceptDetails.name);

    if (relatedConceptDetails.customInd) {
      relatedConcept.setCode(relatedConceptDetails.dtls.code);
    }
    relatedConcept.setComments(locale, relatedConceptDetails.comments);
    relatedConcept.setCustomConcept(relatedConceptDetails.customInd);

    relatedConcept.modify(relatedConceptDetails.dtls.versionNo);

  }

  /**
   * Retrieves the related concept details from the data store.
   *
   * @param wizardStateID
   * Contains the wizard state ID.
   *
   * @return The related concept details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RelatedConceptDetails previewRelatedConcept(
    final WizardStateID wizardStateID) throws AppException,
      InformationalException {

    RelatedConceptDetails relatedConceptDetails = relatedConceptWizState.readRelatedConcept(
      wizardStateID);

    relatedConceptDetails.wizardMenu = TaxonomyConstants.kCreateRelatedConceptWizard2;
    return relatedConceptDetails;
  }

  /**
   * Retrieves the taxonomy terms from the data store.
   *
   * @param wizardStateID
   * Contains the wizard state ID.
   *
   * @return The taxonomy term details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TaxonomyTermWizDetailsList previewTaxonomyTerms(
    final WizardStateID wizardStateID) throws AppException,
      InformationalException {

    TaxonomyTermWizDetailsList existingTaxonomyTermWizDetailsList = relatedConceptWizState.readTaxonomyTerms(
      wizardStateID);

    TaxonomyTermWizDetailsList taxonomyTermWizDetailsList = new TaxonomyTermWizDetailsList();

    taxonomyTermWizDetailsList.searchDetails.wizDetails.taxonomyTermTabList = existingTaxonomyTermWizDetailsList.searchDetails.wizDetails.taxonomyTermTabList;
    
    Set<TaxonomyTerm> selectedTaxonomyTerms = getTaxonomyTermsFromTabList(
      existingTaxonomyTermWizDetailsList.searchDetails.wizDetails.taxonomyTermTabList);

    for (TaxonomyTerm taxonomyTerm : selectedTaxonomyTerms) {
      taxonomyTermWizDetailsList.searchResultsList.dtls.addRef(
        getTaxonomyTermDetails(taxonomyTerm));
    }
    
    if (selectedTaxonomyTerms.size() > 0) {
      taxonomyTermWizDetailsList.searchDetails.termsSelectedInd = true;  
    }

    taxonomyTermWizDetailsList.searchDetails.wizardMenu = TaxonomyConstants.kCreateRelatedConceptWizard2;
    
    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(taxonomyTermWizDetailsList.informationalMsgDtlsOpt);
    // END, CR00292696
    
    return taxonomyTermWizDetailsList;
  }

  /**
   * Returns the create related concept wizard menu details.
   *
   * @return The name of the properties file having create related concept
   * wizard menu details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RelatedConceptWizMenuDetails readWizardMenu() throws AppException,
      InformationalException {
    RelatedConceptWizMenuDetails relatedConceptWizMenuDetails = new RelatedConceptWizMenuDetails();

    relatedConceptWizMenuDetails.wizardMenu = TaxonomyConstants.kCreateRelatedConceptWizard1;
    return relatedConceptWizMenuDetails;
  }

  /**
   * Removes the related concept and its associated taxonomy terms.
   *
   * @param keyVersionDetails
   * Contains the related concept ID and version number.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void removeRelatedConcept(final KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    final RelatedConcept relatedConcept = relatedConceptDAO.get(
      keyVersionDetails.id);

    relatedConcept.remove(keyVersionDetails.version);

  }

  /**
   * Removes the taxonomy term from the related concept wizard.
   *
   * @param searchTaxonomyTermsWizForRelatedConcept
   * Contains the taxonomy term related concept ID details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void removeTaxonomyTerm(
    final SearchTaxonomyTermsWizForRelatedConcept searchTaxonomyTermsWizForRelatedConcept)
    throws AppException, InformationalException {

    relatedConceptWizState.removeTaxonomyTerm(
      searchTaxonomyTermsWizForRelatedConcept);
  }

  /**
   * Removes the taxonomy term from the related concept.
   *
   * @param taxonomyTermRelatedConceptKey
   * Contains the taxonomy term related concept ID.
   *
   * @throws InformationalException
   * {@link TAXONOMYTERM#ERR_TAXONOMYTERM_UPDATED_REQUIRES_REPUBLISHING_REVIST_EDIT_VERSION}
   * -If taxonomy term is already updated and in edit version exists.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void removeTaxonomyTermFromRelatedConcept(
    final TaxonomyTermRelatedConceptKey taxonomyTermRelatedConceptKey)
    throws AppException, InformationalException {

    TaxonomyTermRelatedConcept taxonomyTermRelatedConcept = taxonomyTermRelatedConceptDAO.get(
      taxonomyTermRelatedConceptKey.taxonomyTermRelatedConceptID);
    TaxonomyTerm taxonomyTerm = taxonomyTermRelatedConcept.getTaxonomyTerm();
    StringBuilder existingRelatedConceptTabList = new StringBuilder();

    Set<TaxonomyInEditData> taxonomyInEditDataSet = taxonomyInEditDataDAO.readByTaxonomyTerm(
      taxonomyTerm);

    if (taxonomyInEditDataSet.size() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TAXONOMYTERMExceptionCreator.ERR_TAXONOMYTERM_UPDATED_REQUIRES_REPUBLISHING_REVIST_EDIT_VERSION(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      ValidationHelper.failIfErrorsExist();
    }

    TaxonomyInEditData taxonomyInEditData = taxonomyInEditDataConverter.createTaxonomyInEditTerm(
      taxonomyTerm);

    for (RelatedConcept existingRelatedConcept : taxonomyTerm.getRelatedConcepts()) {
      
      if (!existingRelatedConcept.getID().equals(
        taxonomyTermRelatedConcept.getRelatedConcept().getID())) {
        
        existingRelatedConceptTabList.append(existingRelatedConcept.getID());
        existingRelatedConceptTabList.append(CuramConst.gkTabDelimiter);
      }
    }
    taxonomyInEditData.resetRelatedConcepts();
    taxonomyInEditData.setRelatedConcepts(
      existingRelatedConceptTabList.toString());

    taxonomyInEditData.insert();

  }

  /**
   * Searches the taxonomy terms and adds the selected the taxonomy terms to the
   * related concept.
   *
   * @param searchTaxonomyTermsByNameAndCode
   * Contains the taxonomy term name and code.
   *
   * @return The list of taxonomy terms matching the search criteria.
   *
   * @throws InformationalException
   * {@link TAXONOMYTERM#ERR_TAXONOMYTERM_XFV_MUST_SPECIFY_SEARCH_CRITERIA}
   * -If the search criteria is not entered.
   * @throws InformationalException
   * {@link TAXONOMYTERM#ERR_TAXONOMYTERM_UPDATED_REQUIRES_REPUBLISHING_REVIST_EDIT_VERSION}
   * -If taxonomy term is already updated and in edit version exists.
   * @throws InformationalException
   * {@link TAXONOMYTERM#ERR_TAXONOMYTERM_XRV_MUST_SELECT_ATLEAST_ONE_TERM}
   * -If taxonomy term is not selected.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TaxonomyTermWizDetailsList searchAddTaxonomyTermsToRelatedConcept(
    final SearchTaxonomyTermsWizForRelatedConcept searchTaxonomyTermsByNameAndCode)
    throws AppException, InformationalException {

    TaxonomyTermWizDetailsList taxonomyTermWizDetailsList = new TaxonomyTermWizDetailsList();
    TaxonomyTermWizDetailsList existingTaxonomyTermWizDetailsList = new TaxonomyTermWizDetailsList();

    LOCALEEntry locale = getLocale();

    final RelatedConcept relatedConcept = relatedConceptDAO.get(
      searchTaxonomyTermsByNameAndCode.wizDetails.relatedConceptID);

    if (CPMConstants.kSearchActionStr.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)) {

      if (StringHelper.isEmpty(
        searchTaxonomyTermsByNameAndCode.wizDetails.details.name)
          && StringHelper.isEmpty(
            searchTaxonomyTermsByNameAndCode.wizDetails.details.code)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TAXONOMYTERMExceptionCreator.ERR_TAXONOMYTERM_XFV_MUST_SPECIFY_SEARCH_CRITERIA(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }

      if (0 != searchTaxonomyTermsByNameAndCode.wizardStateID) {
        WizardStateID wizardStateID = new WizardStateID();

        wizardStateID.wizardStateID = searchTaxonomyTermsByNameAndCode.wizardStateID;
        existingTaxonomyTermWizDetailsList = relatedConceptWizState.readTaxonomyTerms(
          wizardStateID);
      }

      List<TaxonomyTerm> taxonomyTerms = sortTaxonomyTerms(
        taxonomyTermDAO.searchBy(locale,
        searchTaxonomyTermsByNameAndCode.wizDetails.details.name,
        searchTaxonomyTermsByNameAndCode.wizDetails.details.code));
      Set<TaxonomyTerm> selectedTaxonomyTerms = null;
      boolean termAlreadyExists = false;

      for (final TaxonomyTerm taxonomyTerm : taxonomyTerms) {
      
        termAlreadyExists = false;
        if (!StringUtil.isNullOrEmpty(
          existingTaxonomyTermWizDetailsList.searchDetails.wizDetails.taxonomyTermTabList)) {
          selectedTaxonomyTerms = getTaxonomyTermsFromTabList(
            existingTaxonomyTermWizDetailsList.searchDetails.wizDetails.taxonomyTermTabList);
          for (TaxonomyTerm existingtaxonomyTerm : selectedTaxonomyTerms) {
            if (existingtaxonomyTerm.getID() == taxonomyTerm.getID()) {
              termAlreadyExists = true;
            }
          }
        }
        if (!termAlreadyExists) {
          taxonomyTermWizDetailsList.searchResultsList.dtls.addRef(
            getTaxonomyTermDetails(taxonomyTerm));
        }
      }
      return taxonomyTermWizDetailsList;

    } else if (TaxonomyConstants.kAddAction.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)) {

      relatedConceptWizState.storeTaxonomyTerm(searchTaxonomyTermsByNameAndCode);
    } else if (TaxonomyConstants.kSaveAction.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)) {

      Set<TaxonomyTerm> selectedTaxonomyTerms = getTaxonomyTermsFromTabList(
        searchTaxonomyTermsByNameAndCode.wizDetails.taxonomyTermTabList);

      if (0 == selectedTaxonomyTerms.size()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TAXONOMYTERMExceptionCreator.ERR_TAXONOMYTERM_XRV_MUST_SELECT_ATLEAST_ONE_TERM(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }

      for (TaxonomyTerm taxonomyTerm : selectedTaxonomyTerms) {
        Set<TaxonomyInEditData> taxonomyInEditDataSet = taxonomyInEditDataDAO.readByTaxonomyTerm(
          taxonomyTerm);

        if (taxonomyInEditDataSet.size() > 0) {
          TaxonomyInEditData existingTaxonomyInEditData = taxonomyInEditDataSet.iterator().next();

          if (0 != existingTaxonomyInEditData.getID()) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              TAXONOMYTERMExceptionCreator.ERR_TAXONOMYTERM_UPDATED_REQUIRES_REPUBLISHING_REVIST_EDIT_VERSION(),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
            ValidationHelper.failIfErrorsExist();
          }
        }

        TaxonomyInEditData taxonomyInEditData = taxonomyInEditDataConverter.createTaxonomyInEditTerm(
          taxonomyTerm);

        taxonomyInEditData.associateTermWithRelatedConcept(
          relatedConcept.getID().toString());
        taxonomyInEditData.insert();

      }
    } else if (TaxonomyConstants.kStoreAction.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)) {
      relatedConceptWizState.storeTaxonomyTerm(searchTaxonomyTermsByNameAndCode);

    } else if (TaxonomyConstants.kSaveFromWizardAction.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)) {
      relatedConceptWizState.storeTaxonomyTerm(searchTaxonomyTermsByNameAndCode);
      WizardStateID wizardStateID = new WizardStateID();

      wizardStateID.wizardStateID = searchTaxonomyTermsByNameAndCode.wizardStateID;
      relatedConceptWizState.saveRelatedConcept(wizardStateID);
    } else if (TaxonomyConstants.kResetSearchAction.equals(
      searchTaxonomyTermsByNameAndCode.wizDetails.actionString)
        && searchTaxonomyTermsByNameAndCode.wizardStateID != 0) {
      relatedConceptWizState.resetSearch(searchTaxonomyTermsByNameAndCode);

    }

    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(taxonomyTermWizDetailsList.informationalMsgDtlsOpt);
    // END, CR00292696
    
    return taxonomyTermWizDetailsList;

  }

  /**
   * Reads the related concept details and its associated taxonomy terms.
   *
   * @param relatedConceptKey
   * Contains the related concept ID.
   *
   * @return The related concept details and its associated taxonomy terms.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewRelatedConceptDetails viewRelatedConcept(
    final RelatedConceptKey relatedConceptKey) throws AppException,
      InformationalException {

    ViewRelatedConceptDetails viewRelatedConceptDetails = new ViewRelatedConceptDetails();
    RelatedConceptDetails relatedConceptDetails = new RelatedConceptDetails();

    RelatedConcept relatedConcept = relatedConceptDAO.get(
      relatedConceptKey.relatedConceptID);

    viewRelatedConceptDetails.conceptDetails = getRelatedConceptDetails(
      relatedConceptDetails, relatedConcept);

    List<TaxonomyTermRelatedConcept> taxonomyTermRelatedConceptList = sortTaxonomyTermRelatedConcepts(
      taxonomyTermRelatedConceptDAO.searchBy(relatedConcept));

    for (final TaxonomyTermRelatedConcept taxonomyTermRelatedConcept : taxonomyTermRelatedConceptList) {
      TaxonomyTermRelatedConceptDetails taxonomyTermRelatedConceptDetails = new TaxonomyTermRelatedConceptDetails();
      final RelatedConcept associatedRelatedConcept = taxonomyTermRelatedConcept.getRelatedConcept();
      final TaxonomyTerm associatedTaxonomyTerm = taxonomyTermRelatedConcept.getTaxonomyTerm();
      final LOCALEEntry locale = getLocale();

      taxonomyTermRelatedConceptDetails.dtls.taxonomyTermRelatedConceptID = taxonomyTermRelatedConcept.getID();
      taxonomyTermRelatedConceptDetails.dtls.relatedConceptID = associatedRelatedConcept.getID();
      taxonomyTermRelatedConceptDetails.relatedConceptCode = associatedRelatedConcept.getCode();
      taxonomyTermRelatedConceptDetails.relatedConceptName = associatedRelatedConcept.getName(
        locale);
      taxonomyTermRelatedConceptDetails.dtls.taxonomyTermID = associatedTaxonomyTerm.getID();
      taxonomyTermRelatedConceptDetails.taxonomyTermName = associatedTaxonomyTerm.getName(
        locale);
      taxonomyTermRelatedConceptDetails.taxonomyTermCode = associatedTaxonomyTerm.getCode();
      taxonomyTermRelatedConceptDetails.taxonomyTermStatus = associatedTaxonomyTerm.getStatus().getCode();
      taxonomyTermRelatedConceptDetails.versionNo = associatedTaxonomyTerm.getVersionNo();
      
      viewRelatedConceptDetails.termRelConceptList.details.addRef(
        taxonomyTermRelatedConceptDetails);
    }

    return viewRelatedConceptDetails;
  }

  /**
   * Gets the locale of the taxonomy.
   *
   * @return Locale of taxonomy.
   */
  protected LOCALEEntry getLocale() {
    LOCALEEntry locale = LOCALEEntry.get(TransactionInfo.getProgramLocale());

    if (LOCALEEntry.ENGLISH_GB.equals(locale)
      || LOCALEEntry.ENGLISH_US.equals(locale)
      || LOCALEEntry.ENGLISH.equals(locale)) {
      return LOCALEEntry.ENGLISH;
    }

    return locale;
  }

  /**
   * Gets the related concept fields from an instance to details struct.
   *
   * @param relatedConceptDetails
   * The related concept details struct.
   *
   * @param relatedConcept
   * related concept object.
   * @return The related concept details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected RelatedConceptDetails getRelatedConceptDetails(
    final RelatedConceptDetails relatedConceptDetails,
    final RelatedConcept relatedConcept) throws AppException,
      InformationalException {

    LOCALEEntry locale = LOCALEEntry.get(TransactionInfo.getProgramLocale());

    relatedConceptDetails.name = relatedConcept.getName(locale);
    relatedConceptDetails.dtls.code = relatedConcept.getCode();
    relatedConceptDetails.dtls.customConceptInd = relatedConcept.isCustomConcept();
    relatedConceptDetails.comments = relatedConcept.getComments(locale);
    relatedConceptDetails.dtls.relatedConceptID = relatedConcept.getID();
    relatedConceptDetails.dtls.versionNo = relatedConcept.getVersionNo();
    relatedConceptDetails.dtls.nameTextID = relatedConcept.getNameTextID();
    relatedConceptDetails.dtls.commentsTextID = relatedConcept.getCommentsTextID();
    
    Set<TaxonomyTermRelatedConcept> taxonomyTermRelatedConceptList = taxonomyTermRelatedConceptDAO.searchBy(
      relatedConcept);

    relatedConceptDetails.noOfAssociatedTaxonomyTerms = taxonomyTermRelatedConceptList.size(); 

    return relatedConceptDetails;
  }

  /**
   * Gets the taxonomy term details from the taxonomy term object.
   *
   * @param taxonomyTerm
   * The taxonomy term object.
   *
   * @return The taxonomy term details struct.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected TaxonomyTermDetails getTaxonomyTermDetails(
    final TaxonomyTerm taxonomyTerm) throws AppException,
      InformationalException {

    TaxonomyTermDetails taxonomyTermDetails = new TaxonomyTermDetails();
    LOCALEEntry locale = getLocale();

    taxonomyTermDetails.dtls.taxonomyTermID = taxonomyTerm.getID();
    taxonomyTermDetails.name = taxonomyTerm.getName(locale);
    taxonomyTermDetails.dtls.code = taxonomyTerm.getCode();
    taxonomyTermDetails.definition = taxonomyTerm.getDefinition(locale);
    taxonomyTermDetails.dtls.creationDate = taxonomyTerm.getCreationDate();
    taxonomyTermDetails.dtls.lastModifiedDate = taxonomyTerm.getLastModifiedDate();
    taxonomyTermDetails.dtls.facetCode = taxonomyTerm.getFacet().getCode();
    taxonomyTermDetails.dtls.customTermInd = taxonomyTerm.isCustomTerm();
    taxonomyTermDetails.parentID = taxonomyTerm.getParentTerm().getID();
    taxonomyTermDetails.dtls.status = taxonomyTerm.getStatus().getCode();
    taxonomyTermDetails.bibliographicRef = taxonomyTerm.getBibliographicReferences(
      locale);
    taxonomyTermDetails.comments = taxonomyTerm.getComments(locale);
    taxonomyTermDetails.dtls.nameTextID = taxonomyTerm.getNameTextID();
    taxonomyTermDetails.dtls.definitionTextID = taxonomyTerm.getDefinitionTextID();
    taxonomyTermDetails.dtls.bibliographicRefTextID = taxonomyTerm.getBibliographicRefTextID();
    taxonomyTermDetails.dtls.commentsTextID = taxonomyTerm.getCommentsTextID();
    taxonomyTermDetails.dtls.versionNo = taxonomyTerm.getVersionNo();

    return taxonomyTermDetails;
  }

  /**
   * Retrieves the taxonomy terms from the tabbed list.
   *
   * @param taxonomyTermTabList
   * The tabbed list of taxonomy terms.
   *
   * @return The set of taxonomy terms selected.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Set<TaxonomyTerm> getTaxonomyTermsFromTabList(
    final String taxonomyTermTabList) throws InformationalException {

    StringList taxonomyTermIDList = StringUtil.delimitedText2StringList(
      taxonomyTermTabList, CuramConst.gkTabDelimiterChar);
    Set<TaxonomyTerm> taxonomyTermIDSet = new HashSet<TaxonomyTerm>();

    for (String resourceIDString : taxonomyTermIDList.items()) {
      if (!StringUtil.isNullOrEmpty(resourceIDString)) {
        StringList resourceIDs = StringUtil.delimitedText2StringList(
          resourceIDString, CuramConst.gkPipeDelimiterChar);

        taxonomyTermIDSet.add(
          taxonomyTermDAO.get(Long.valueOf(resourceIDs.item(0))));
      }
    }

    return taxonomyTermIDSet;
  }

  /**
   * Sets the related concept fields from details struct to an Related Concept
   * object.
   *
   * @param relatedConceptDetails
   * The related concept details.
   * @param relatedConcept
   * Related concept object.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void setRelatedConceptDetails(
    final RelatedConceptDetails relatedConceptDetails,
    final RelatedConcept relatedConcept) throws AppException,
      InformationalException {
    LOCALEEntry locale = getLocale();

    relatedConcept.setName(locale, relatedConceptDetails.name);
    relatedConcept.setCode(relatedConceptDetails.dtls.code);
    relatedConcept.setComments(locale, relatedConceptDetails.comments);
    relatedConcept.setCustomConcept(relatedConceptDetails.customInd);
  }

  /**
   * Sorts a set of related concepts into a sorted list for display.
   *
   * @param unsortRelatedConcepts
   * The set of related concepts.
   *
   * @return The sorted list of related concepts.
   */
  protected List<RelatedConcept> sortRelatedConcepts(
    final Set<RelatedConcept> unsortRelatedConcepts) {

    final List<RelatedConcept> relatedConcepts = new ArrayList<RelatedConcept>(
      unsortRelatedConcepts);
    final LOCALEEntry locale = LOCALEEntry.get(
      TransactionInfo.getProgramLocale());

    Collections.sort(relatedConcepts, new Comparator<RelatedConcept>() {
      public int compare(final RelatedConcept lhs, final RelatedConcept rhs) {
        return lhs.getName(locale).compareTo(rhs.getName(locale));
      }
    });
    return relatedConcepts;
  }
  
  /**
   * Sorts a set of taxonomy term related concepts into a sorted list by the
   * taxonomy term name.
   *
   * @param unsortedTaxonomyTermRelatedConcepts
   * The set of taxonomy term related concepts.
   *
   * @return The sorted list of taxonomy term related concepts.
   */
  protected List<TaxonomyTermRelatedConcept> sortTaxonomyTermRelatedConcepts(
    final Set<TaxonomyTermRelatedConcept> unsortedTaxonomyTermRelatedConcepts) {

    final List<TaxonomyTermRelatedConcept> taxonomyTermRelatedConcepts = new ArrayList<TaxonomyTermRelatedConcept>(
      unsortedTaxonomyTermRelatedConcepts);
    final LOCALEEntry locale = LOCALEEntry.get(
      TransactionInfo.getProgramLocale());

    Collections.sort(taxonomyTermRelatedConcepts,
      new Comparator<TaxonomyTermRelatedConcept>() {
      public int compare(final TaxonomyTermRelatedConcept lhs,
        final TaxonomyTermRelatedConcept rhs) {
        return lhs.getTaxonomyTerm().getName(locale).compareTo(
          rhs.getTaxonomyTerm().getName(locale));
      }
    });
    return taxonomyTermRelatedConcepts;
  }
  
  /**
   * Sorts a set of taxonomy terms into a sorted list for display.
   *
   * @param unsortedTaxonomyTerms
   * The set of taxonomy terms.
   *
   * @return The sorted list of taxonomy terms.
   */
  protected List<TaxonomyTerm> sortTaxonomyTerms(
    final Set<TaxonomyTerm> unsortedTaxonomyTerms) {

    final List<TaxonomyTerm> taxonomyTerms = new ArrayList<TaxonomyTerm>(
      unsortedTaxonomyTerms);
    final LOCALEEntry locale = getLocale();

    Collections.sort(taxonomyTerms, new Comparator<TaxonomyTerm>() {
      public int compare(final TaxonomyTerm lhs, final TaxonomyTerm rhs) {
        return lhs.getName(locale).compareTo(rhs.getName(locale));
      }
    });
    return taxonomyTerms;
  }
  
  // BEGIN, CR00292696, IBM
  /**
   * Collects the list of informations from the informational manager and adds
   * them to the list parameter passed in.
   *
   * @param informationalMsgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList informationalMsgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }
  // END, CR00292696
}
