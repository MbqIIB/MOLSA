/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.creoleruleset.impl;


import com.google.inject.ImplementedBy;

import curam.codetable.impl.CREOLERULESETTYPEEntry;
import curam.codetable.impl.RELATEDTYPEEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.OptimisticLockRemovable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;


/**
 * Associates the Creole rule set with related entities.
 */
@ImplementedBy(CreoleRuleSetLinkImpl.class)
public interface CreoleRuleSetLink extends CreoleRuleSetLinkAccessor,
    Insertable, DateRanged, Commented, LogicallyDeleteable,
    OptimisticLockModifiable, OptimisticLockRemovable {

  /**
   * Sets the unique system generated identifier for the creole rule set record.
   *
   * @param creoleRuleSetID
   * Unique ID of the creole rule set record.
   */
  void setCreoleRuleSetID(long creoleRuleSetID);

  /**
   * Sets the unique system generated identifier for the related entity. For
   * example service Offering ID.
   *
   * @param relatedID
   * Unique ID of the related entity record.
   */
  void setRelatedID(long relatedID);

  /**
   * Sets the related type for which rule set is associated. For example Service
   * Offering.
   *
   * @param relatedType
   * Related type for which rule set is associated.
   */
  void setRelatedType(RELATEDTYPEEntry relatedType);

  /**
   * Sets Rule set type associated with related type. For example Estimated Cost
   * rule set for Service Offering.
   *
   * @param ruleSetType
   * Rule set type.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  void setRuleSetType(CREOLERULESETTYPEEntry ruleSetType);

  /**
   * Sets the "lifetime" of the creole rule set link record.
   *
   * @param dateRange
   * the "lifetime" of the creole rule set link record.
   *
   * @see curam.cpm.creoleruleset.impl.CreoleRuleSetLinkImpl#setDateRange(DateRange) The default
   * implementation - curam.cpm.creoleruleset.impl.CreoleRuleSetLinkImpl#setDateRange(DateRange).
   */
  void setDateRange(DateRange dateRange);

  /**
   * Sets the name of the rule set class.
   *
   * @param ruleSetClassName
   * Rule set class name.
   */
  void setRuleSetClassName(String ruleSetClassName);

  /**
   * Sets the schema name of the data store.
   *
   * @param ruleSetDataStoreName
   * Rule set data store schema name.
   */
  void setDataStoreName(String ruleSetDataStoreName);

  /**
   * Sets the service offering for the creole rule set.
   *
   * @param serviceOffering
   * The service offering associated with creole rule set
   * configuration.
   */
  void setServiceOffering(final ServiceOffering serviceOffering);

  /**
   * Interface to the creole rule set link events functionality surrounding the
   * insert method.
   */
  public interface CreoleRuleSetLinkInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.cpm.creoleruleset.impl.CreoleRuleSetLink#insert}
     *
     * @param creoleRuleSetLink
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(CreoleRuleSetLink creoleRuleSetLink)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.cpm.creoleruleset.impl.CreoleRuleSetLink#insert}
     *
     * @param creoleRuleSetLink
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(CreoleRuleSetLink creoleRuleSetLink)
      throws InformationalException;
  }

 
  /**
   * Interface to the creole rule set link events functionality surrounding the
   * modify method.
   */
  public interface CreoleRuleSetLinkModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.cpm.creoleruleset.impl.CreoleRuleSetLink#modify}
     *
     * @param creoleRuleSetLink
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(CreoleRuleSetLink creoleRuleSetLink, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.cpm.creoleruleset.impl.CreoleRuleSetLink#modify}
     *
     * @param creoleRuleSetLink
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(CreoleRuleSetLink creoleRuleSetLink,
      Integer versionNo) throws InformationalException;
  }
  

  /**
   * Interface to the creole rule set link events functionality surrounding the
   * cancel method.
   */
  public interface CreoleRuleSetLinkCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.cpm.creoleruleset.impl.CreoleRuleSetLink#cancel}
     *
     * @param creoleRuleSetLink
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(CreoleRuleSetLink creoleRuleSetLink, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.cpm.creoleruleset.impl.CreoleRuleSetLink#cancel}
     *
     * @param creoleRuleSetLink
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(CreoleRuleSetLink creoleRuleSetLink, int versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the creole rule set link events functionality surrounding the
   * remove method.
   */
  public interface CreoleRuleSetLinkRemoveEvents {

    /**
     * Event interface invoked before the main body of the remove method.
     * {@linkplain curam.cpm.creoleruleset.impl.CreoleRuleSetLink#remove}
     *
     * @param creoleRuleSetLink
     * The object instance as it was before the main body of the remove
     * method.
     * @param versionNo
     * The parameter as passed to the remove method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preRemove(
      CreoleRuleSetLink creoleRuleSetLink, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the remove method.
     * {@linkplain curam.cpm.creoleruleset.impl.CreoleRuleSetLink#remove}
     *
     * @param creoleRuleSetLink
     * The object instance as it was after the main body of the remove
     * method.
     * @param versionNo
     * The parameter as passed to the remove method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postRemove(
      CreoleRuleSetLink creoleRuleSetLink, Integer versionNo)
      throws InformationalException;
  }
  
}
