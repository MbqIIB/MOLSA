/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.cpm.facade.fact.ContextDescriptionFactory;
import curam.cpm.facade.struct.HomeStudyDetails;
import curam.cpm.facade.struct.HomeStudyDetailsList;
import curam.cpm.facade.struct.HomeStudyKey;
import curam.cpm.facade.struct.HomeStudyRejectKey;
import curam.cpm.facade.struct.HomeStudySearchByProviderKey;
import curam.cpm.facade.struct.HomeStudyStatusHistoryDetails;
import curam.cpm.facade.struct.HomeStudyStatusHistoryDetailsList;
import curam.cpm.facade.struct.HomeStudyStatusHistorySummaryDetails;
import curam.cpm.facade.struct.HomeStudyStatusHistorySummaryDetailsList;
import curam.cpm.facade.struct.HomeStudyVersionDetails;
import curam.cpm.facade.struct.HomeStudyVersionDetailsList;
import curam.cpm.facade.struct.HomeStudyVersionedKey;
import curam.cpm.facade.struct.ProviderKey;
import curam.cpm.facade.struct.UserNameDetails;
import curam.cpm.sl.entity.struct.HomeStudyDtls;
import curam.homestudy.HomeStudyStatus;
import curam.homestudy.impl.HomeStudyDAO;
import curam.homestudy.impl.HomeStudyFinalRecommendationEntry;
import curam.homestudy.impl.HomeStudyPurposeEntry;
import curam.homestudy.impl.HomeStudyReturnReasonEntry;
import curam.homestudy.impl.HomeStudyStatusHistory;
import curam.homestudy.impl.HomeStudyTypeEntry;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderSecurity;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality for the home study facade
 * layer.
 */
public abstract class HomeStudy extends curam.cpm.facade.base.HomeStudy {

  @Inject
  protected HomeStudyDAO homeStudyDAO;

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00235784, GP
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;
  // END, CR00235784
  
  /**
   * Constructor
   */
  public HomeStudy() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  // BEGIN, CR00236219, PS
  /**
   * Gets the details of the user who is home study assessor.
   *
   * @param homeStudyKey
   * Home study for which assessor details are to be retrieved.
   *
   * @return Details of the user who is home study assessor.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public UserNameDetails getHomeStudyAssessorDetails(HomeStudyKey homeStudyKey)
    throws AppException, InformationalException {

    UserNameDetails userNameDetails = new UserNameDetails();
    curam.homestudy.impl.HomeStudy homeStudy = homeStudyDAO.get(
      homeStudyKey.key.homeStudyID);

    userNameDetails.userName = homeStudy.getAssessor();
    User user = userDAO.get(homeStudy.getAssessor());

    userNameDetails.fullName = user.getFullName();

    return userNameDetails;
  }

  // END, CR00236219

  /**
   * Returns a list of home studies by provider.
   *
   * @param key
   * the key specifying the provider to search by
   * @return list of relevant home studies.
   * @throws InformationalException
   * @throws AppException
   */
  public HomeStudyDetailsList listByProvider(HomeStudySearchByProviderKey key)
    throws AppException, InformationalException {

    HomeStudyDetailsList homeStudyDetailsList = new HomeStudyDetailsList();

    // Read the provider to search by
    Provider provider = providerDAO.get(key.key.providerConcernRoleID);

    // Call the search method
    Set<curam.homestudy.impl.HomeStudy> homeStudySet = homeStudyDAO.searchByProvider(
      provider);

    // sort the list by Date Initiated for display
    List<curam.homestudy.impl.HomeStudy> sortedHomeStudies = sortHomeStudiesByDateInitiated(
      homeStudySet);

    // convert to HomeStudyDetailsList for return to client
    for (curam.homestudy.impl.HomeStudy homeStudy : sortedHomeStudies) {
      HomeStudyDetails homeStudyDetails = setHomeStudyDetails(homeStudy);

      homeStudyDetailsList.dtls.dtls.addRef(homeStudyDetails.homeStudyDtls);
    }

    // set the context description
    // Start CR00096126, JSP
    curam.cpm.facade.intf.ContextDescription contextDescription = ContextDescriptionFactory.newInstance();
    // End CR00096126
    ProviderKey providerKey = new ProviderKey();

    providerKey.providerID = key.key.providerConcernRoleID;
    homeStudyDetailsList.contextDescription = contextDescription.getContextDescription(
      providerKey);

    return homeStudyDetailsList;
  }

  // BEGIN, CR00235784, GP
  /**
   * Retrieves a list of home studies for a provider.
   *
   * @param homeStudySearchByProviderKey
   * Provider for which home studies are to be retrieved.
   *
   * @return List of home studies for a provider.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public HomeStudyVersionDetailsList listHomeStudiesForProvider(
    final HomeStudySearchByProviderKey homeStudySearchByProviderKey)
    throws AppException, InformationalException {

    HomeStudyVersionDetailsList homeStudyVersionDetailsList = new HomeStudyVersionDetailsList();

    HomeStudyDetailsList homeStudyDetailsList = listByProvider(
      homeStudySearchByProviderKey);

    for (final HomeStudyDtls homeStudyDtls : homeStudyDetailsList.dtls.dtls.items()) {

      curam.homestudy.impl.HomeStudy homeStudy = homeStudyDAO.get(
        homeStudyDtls.homeStudyID);
      Provider provider = homeStudy.getProvider();

      HomeStudyVersionDetails homeStudyVersionDetails = new HomeStudyVersionDetails();

      homeStudyVersionDetails.homeStudyDetails = homeStudyDtls;
      homeStudyVersionDetails.versionNo = homeStudyDtls.versionNo;

      User user = userDAO.get(homeStudyDtls.assessorName);

      homeStudyVersionDetails.assessorFullName = user.getFullName();

      String currentUser = TransactionInfo.getProgramUser();

      // BEGIN, CR00236219, PS
      if (homeStudyVersionDetails.homeStudyDetails.status.equals(
        HomeStudyStatus.SUBMITTED)
          && (providerSecurity.isUserProviderSupervisor(provider, currentUser))) {

        homeStudyVersionDetails.showSupervisorLinks = true;

      } else if (homeStudyVersionDetails.homeStudyDetails.status.equals(
        HomeStudyStatus.OPEN)) {

        homeStudyVersionDetails.editInd = true;
        homeStudyVersionDetails.submitForApprovalInd = true;
        homeStudyVersionDetails.deleteInd = true;

      } else if (homeStudyVersionDetails.homeStudyDetails.status.equals(
        HomeStudyStatus.RETURNED)) {

        homeStudyVersionDetails.editInd = true;
        homeStudyVersionDetails.submitForApprovalInd = true;

      } else if (homeStudyVersionDetails.homeStudyDetails.status.equals(
        HomeStudyStatus.APPROVED)
          || (homeStudyVersionDetails.homeStudyDetails.status.equals(
            HomeStudyStatus.CANCELLED))) {

        homeStudyVersionDetails.editInd = false;
        homeStudyVersionDetails.submitForApprovalInd = false;
        homeStudyVersionDetails.deleteInd = false;
      }
      // END, CR00236219
      
      homeStudyVersionDetailsList.homeStudyVersionDetails.addRef(
        homeStudyVersionDetails);
    }

    return homeStudyVersionDetailsList;
  }

  /**
   * Retrieves a list of home study status history details for a provider.
   *
   * @param homeStudyKey Home study for which status history details are to be retrieved.
   *
   * @return A list of status history details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public HomeStudyStatusHistoryDetailsList listHomeStudyStatusHistoryForProvider(
    final HomeStudyKey homeStudyKey) throws AppException,
      InformationalException {

    HomeStudyStatusHistoryDetailsList homeStudyStatusHistoryDetailsList = new HomeStudyStatusHistoryDetailsList();

    HomeStudyStatusHistorySummaryDetailsList homeStudyStatusHistorySummaryDetailsList = listHomeStudyStatusHistory(
      homeStudyKey);

    for (final HomeStudyStatusHistorySummaryDetails homeStudyStatusHistorySummaryDetails :
      homeStudyStatusHistorySummaryDetailsList.detailsList.items()) {

      HomeStudyStatusHistoryDetails homeStudyStatusHistoryDetails = new HomeStudyStatusHistoryDetails();

      homeStudyStatusHistoryDetails.statusHistoryDetails = homeStudyStatusHistorySummaryDetails.dtls;
      homeStudyStatusHistoryDetails.reason = homeStudyStatusHistorySummaryDetails.reason;

      User user = userDAO.get(
        homeStudyStatusHistorySummaryDetails.dtls.createdBy);

      homeStudyStatusHistoryDetails.createdByFullName = user.getFullName();

      homeStudyStatusHistoryDetailsList.homeStudyStatusHistoryDetails.addRef(
        homeStudyStatusHistoryDetails);
    }

    return homeStudyStatusHistoryDetailsList;
  }

  // END, CR00235784
  
  /**
   * Creates a new home study.
   *
   * @param details
   * the details passed from the client to create the home study
   * @return key of the home study created by this method.
   * @throws InformationalException
   * @throws AppException
   */
  public HomeStudyKey createHomeStudy(HomeStudyDetails details)
    throws AppException, InformationalException {

    // Return object
    HomeStudyKey key = new HomeStudyKey();

    // create a new instance
    curam.homestudy.impl.HomeStudy homeStudy = homeStudyDAO.newInstance();

    // set the fields sent in by client
    homeStudy = setHomeStudyFields(homeStudy, details);

    // call insert
    homeStudy.insert();

    // set and return key
    key.key.homeStudyID = homeStudy.getID();
    return key;
  }

  /**
   * Modifies an existing home study.
   *
   * @param details
   * the details passed from the client to modify the home study
   * @throws InformationalException
   * @throws AppException
   */
  public void modifyHomeStudy(HomeStudyDetails details) throws AppException,
      InformationalException {

    curam.homestudy.impl.HomeStudy homeStudyToModify = homeStudyDAO.get(
      details.homeStudyDtls.homeStudyID);

    homeStudyToModify = setHomeStudyFields(homeStudyToModify, details);

    homeStudyToModify.modify(details.homeStudyDtls.versionNo);
  }

  /**
   * Reads a home study.
   *
   * @param key
   * the key specifying the home study to read
   * @return details of the home study.
   * @throws InformationalException
   * @throws AppException
   */
  public HomeStudyDetails viewHomeStudy(HomeStudyKey key) throws AppException,
      InformationalException {
    // Read the Home Study
    curam.homestudy.impl.HomeStudy homeStudy = homeStudyDAO.get(
      key.key.homeStudyID);

    // set the details on the return struct
    HomeStudyDetails homeStudyDetails = setHomeStudyDetails(homeStudy);

    // set the context description
    // Start CR00096126, JSP
    curam.cpm.facade.intf.ContextDescription contextDescription = ContextDescriptionFactory.newInstance();
    // End CR00096126
    ProviderKey providerKey = new ProviderKey();
    Provider provider = homeStudy.getProvider();

    providerKey.providerID = provider.getID();
    homeStudyDetails.contextDescription = contextDescription.getContextDescription(
      providerKey);

    // check if the user is a supervisor or resource manager and set the
    // display links booleans accordingly
    String currentUser = TransactionInfo.getProgramUser();

    if (providerSecurity.isUserProviderSupervisor(provider, currentUser)) {
      homeStudyDetails.showSupervisorLinks = true;
    } else // if they're not a supervisor, display resource manager links
    {
      homeStudyDetails.showResourceManagerLinks = true;
    }

    return homeStudyDetails;
  }

  /**
   * Cancels an existing home study.
   *
   * @param key
   * the key specifying the home study and record version to cancel
   * @throws InformationalException
   * @throws AppException
   */
  public void deleteHomeStudy(HomeStudyVersionedKey key) throws AppException,
      InformationalException {

    // Read the Home Study to cancel
    curam.homestudy.impl.HomeStudy homeStudyToCancel = homeStudyDAO.get(
      key.key.homeStudyID);

    // call cancel, passing the version no from the client
    homeStudyToCancel.cancel(key.versionNo);

  }

  /**
   * Approves a home study.
   *
   * @param key
   * the key specifying the home study and record version to be
   * approved
   * @throws InformationalException
   * @throws AppException
   */
  public void approveHomeStudy(HomeStudyVersionedKey key) throws AppException,
      InformationalException {

    // Read the Home Study to approve
    curam.homestudy.impl.HomeStudy homeStudyToApprove = homeStudyDAO.get(
      key.key.homeStudyID);

    // call approve, passing the version no from the client
    homeStudyToApprove.approve(key.versionNo);

  }

  /**
   * Rejects a home study that has been submitted for approval.
   *
   * @param key
   * the key specifying the home study to be rejected
   * @throws InformationalException
   * @throws AppException
   */
  public void rejectHomeStudy(HomeStudyRejectKey key) throws AppException,
      InformationalException {

    // Read the Home Study to reject
    curam.homestudy.impl.HomeStudy homeStudyToReject = homeStudyDAO.get(
      key.key.homeStudyID);

    // call reject, passing the version no from the client
    homeStudyToReject.reject(key.versionNo,
      HomeStudyReturnReasonEntry.get(key.returnedReason));

  }

  /**
   * Submits a home study for approval by a supervisor.
   *
   * @param key
   * the key specifying the home study and record version to be
   * submitted
   * @throws InformationalException
   * @throws AppException
   */
  public void submitHomeStudy(HomeStudyVersionedKey key) throws AppException,
      InformationalException {

    // Read the Home Study to submit
    curam.homestudy.impl.HomeStudy homeStudyToSubmit = homeStudyDAO.get(
      key.key.homeStudyID);

    // call submit, passing the version no from the client
    homeStudyToSubmit.submit(key.versionNo);

  }

  /**
   * Returns a list of all home study status history records for a given home
   * study.
   *
   * @param key
   * the key specifying the home study to list home study status
   * history records by
   * @return list of home study status history summary details.
   * @throws InformationalException
   * @throws AppException
   */
  public HomeStudyStatusHistorySummaryDetailsList listHomeStudyStatusHistory(
    HomeStudyKey key) throws AppException, InformationalException {

    final HomeStudyStatusHistorySummaryDetailsList homeStudyStatusHistoryList = new HomeStudyStatusHistorySummaryDetailsList();

    final curam.homestudy.impl.HomeStudy homeStudy = homeStudyDAO.get(
      key.key.homeStudyID);

    List<HomeStudyStatusHistory> unModifiableHomeStudyStatusHistory = homeStudy.getStatusHistory();
    List<HomeStudyStatusHistory> homeStudyStatusHistoryRecords = new ArrayList<HomeStudyStatusHistory>();

    homeStudyStatusHistoryRecords.addAll(unModifiableHomeStudyStatusHistory);

    for (final curam.homestudy.impl.HomeStudyStatusHistory homeStudyStatusHistory : homeStudyStatusHistoryRecords) {

      HomeStudyStatusHistorySummaryDetails homeStudyStatusHistorySummaryDetails = new HomeStudyStatusHistorySummaryDetails();

      homeStudyStatusHistorySummaryDetails.dtls.homeStudyStatusHistoryID = homeStudyStatusHistory.getID();
      homeStudyStatusHistorySummaryDetails.dtls.homeStudyID = homeStudy.getID();
      homeStudyStatusHistorySummaryDetails.dtls.homeStudyStatus = homeStudyStatusHistory.getHomeStudyStatus().getCode();
      homeStudyStatusHistorySummaryDetails.dtls.dateTime = homeStudyStatusHistory.getEventDateTime();
      homeStudyStatusHistorySummaryDetails.dtls.createdBy = homeStudyStatusHistory.getUser();
      homeStudyStatusHistorySummaryDetails.dtls.returnedReason = homeStudyStatusHistory.getReturnedReason().getCode();

      // determine reason to display
      if (homeStudyStatusHistorySummaryDetails.dtls.homeStudyStatus.equals(
        HomeStudyStatus.RETURNED)) {

        homeStudyStatusHistorySummaryDetails.reason = homeStudyStatusHistory.getReturnedReason().toUserLocaleString();
      }

      homeStudyStatusHistoryList.detailsList.addRef(
        homeStudyStatusHistorySummaryDetails);
    }

    // set the context description
    // Start CR00096126,JSP
    curam.cpm.facade.intf.ContextDescription contextDescription = ContextDescriptionFactory.newInstance();
    // End CR00096126

    ProviderKey providerKey = new ProviderKey();

    providerKey.providerID = homeStudy.getProvider().getID();
    homeStudyStatusHistoryList.contextDescription = contextDescription.getContextDescription(
      providerKey);

    return homeStudyStatusHistoryList;
  }

  /**
   * Sets the fields passed in by the client to the home study.
   *
   * @param homeStudy
   * the home study to be populated for insertion
   * @param homeStudyDetails
   * the details passed from the client
   * @return populated home study to be inserted
   */
  // BEGIN, CR00177241, PM
  protected curam.homestudy.impl.HomeStudy setHomeStudyFields(
    // END, CR00177241
    curam.homestudy.impl.HomeStudy homeStudy,
    curam.cpm.facade.struct.HomeStudyDetails homeStudyDetails) {

    homeStudy.setComments(homeStudyDetails.homeStudyDtls.comments);
    homeStudy.setDateInitiated(homeStudyDetails.homeStudyDtls.dateInitiated);
    homeStudy.setFinalRecommendation(
      HomeStudyFinalRecommendationEntry.get(
        homeStudyDetails.homeStudyDtls.finalRecommendation));
    homeStudy.setHomeStudyType(
      HomeStudyTypeEntry.get(homeStudyDetails.homeStudyDtls.homeStudyType));
    homeStudy.setProvider(
      providerDAO.get(homeStudyDetails.homeStudyDtls.providerConcernRoleID));
    homeStudy.setPurpose(
      HomeStudyPurposeEntry.get(homeStudyDetails.homeStudyDtls.purpose));
    homeStudy.setReevaluationDate(
      homeStudyDetails.homeStudyDtls.reevaluationDate);
    homeStudy.setSupportForRecommendation(
      homeStudyDetails.homeStudyDtls.supportForRecommendation);
    homeStudy.setAssessor(homeStudyDetails.homeStudyDtls.assessorName);

    return homeStudy;
  }

  /**
   * Returns a details struct for use by client.
   *
   * @param homeStudy
   * the home study to be returned
   * @return home study details
   */
  // BEGIN, CR00177241, PM
  protected HomeStudyDetails setHomeStudyDetails(
    // END, CR00177241
    curam.homestudy.impl.HomeStudy homeStudy) {

    // Set valid values for the service offering and service rate record
    HomeStudyDetails homeStudyDetails = new curam.cpm.facade.struct.HomeStudyDetails();

    homeStudyDetails.homeStudyDtls.homeStudyID = homeStudy.getID();
    homeStudyDetails.homeStudyDtls.comments = homeStudy.getComments();
    homeStudyDetails.homeStudyDtls.dateInitiated = homeStudy.getDateInitiated();
    homeStudyDetails.homeStudyDtls.finalRecommendation = homeStudy.getFinalRecommendation().getCode();
    homeStudyDetails.homeStudyDtls.homeStudyType = homeStudy.getHomeStudyType().getCode();
    homeStudyDetails.homeStudyDtls.providerConcernRoleID = homeStudy.getProvider().getID();
    homeStudyDetails.homeStudyDtls.purpose = homeStudy.getPurpose().getCode();
    homeStudyDetails.homeStudyDtls.reevaluationDate = homeStudy.getReevaluationDate();
    homeStudyDetails.homeStudyDtls.status = homeStudy.getLifecycleState().getCode();
    homeStudyDetails.homeStudyDtls.supportForRecommendation = homeStudy.getSupportForRecommendation();
    homeStudyDetails.homeStudyDtls.versionNo = homeStudy.getVersionNo();
    homeStudyDetails.homeStudyDtls.assessorName = homeStudy.getAssessor();

    return homeStudyDetails;
  }

  /**
   * Sorts a set of home studies into a sorted list by date initiated for
   * display.
   *
   * @param unsortedHomeStudies
   * the set of home studies to sort
   * @return sorted list of home studies for display
   */
  // BEGIN, CR00177241, PM
  protected List<curam.homestudy.impl.HomeStudy> sortHomeStudiesByDateInitiated(
    // END, CR00177241
    final Set<curam.homestudy.impl.HomeStudy> unsortedHomeStudies) {
    // Sort by name for display - using a list (instead of a set) in case there
    // are duplicate names.

    final List<curam.homestudy.impl.HomeStudy> homeStudies = new ArrayList<curam.homestudy.impl.HomeStudy>(
      unsortedHomeStudies);

    Collections.sort(homeStudies,
      new Comparator<curam.homestudy.impl.HomeStudy>() {
      public int compare(final curam.homestudy.impl.HomeStudy lhs,
        curam.homestudy.impl.HomeStudy rhs) {
        return lhs.getDateInitiated().compareTo(rhs.getDateInitiated());
      }
    });
    return homeStudies;
  }
}
