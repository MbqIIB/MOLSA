/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.Collections;
import java.util.Comparator;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.ADDRESSELEMENTTYPE;
import curam.codetable.LANGUAGE;
import curam.codetable.PHONETYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.ADDRESSELEMENTTYPEEntry;
import curam.codetable.impl.COMMUNICATIONMETHODEntry;
import curam.codetable.impl.LANGUAGEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.struct.UserSkillListKey;
import curam.core.facade.struct.UserSkills;
import curam.core.fact.AddressElementFactory;
import curam.core.fact.AddressFactory;
import curam.core.fact.PhoneNumberFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.Address;
import curam.core.intf.AddressElement;
import curam.core.intf.PhoneNumber;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.UserSkillLanguagesFactory;
import curam.core.sl.entity.struct.UserSkillDetails;
import curam.core.sl.entity.struct.UserSkillLanguagesDtls;
import curam.core.sl.entity.struct.UserSkillLanguagesDtlsList;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.struct.AddressTabDetails;
import curam.core.sl.struct.UserSkillLanguageReadMultiKey;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressElementDtls;
import curam.core.struct.AddressElementDtlsList;
import curam.core.struct.AddressKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PhoneNumberDtls;
import curam.core.struct.PhoneNumberKey;
import curam.core.struct.UsersKey;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.ProviderEnquiryAdminRoleDetailsList;
import curam.cpm.facade.struct.ProviderEnquiryDetails;
import curam.cpm.facade.struct.ProviderEnquiryRegistrationDetails;
import curam.cpm.facade.struct.ProviderEnquirySummaryDetails;
import curam.cpm.facade.struct.ProviderEnquirySummaryDetailsList;
import curam.cpm.facade.struct.ProviderEnquiryViewDetails;
import curam.cpm.facade.struct.ProviderEnquiryViewDetailsList;
import curam.cpm.facade.struct.ProviderEnrollmentDetails;
import curam.cpm.facade.struct.SearchByDateRangeKey;
import curam.cpm.facade.struct.SetProviderEnquiryAdminRoleDetails;
import curam.cpm.facade.struct.UserNameDetails;
import curam.cpm.facade.struct.UserNameDetailsList;
import curam.cpm.facade.struct.ViewProviderEnquiryTabDetails;
import curam.cpm.facade.struct.WizardMenuDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ListProviderEnquiryKey;
import curam.cpm.sl.entity.struct.ProviderEnquiryKey;
import curam.cpm.sl.entity.struct.SearchProviderEnquiryKey;
import curam.events.PROVIDERENQUIRY;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.PROVIDERENQUIRYExceptionCreator;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.EnquiryStatus;
import curam.provider.impl.EnquiryStatusEntry;
import curam.provider.impl.ProviderCategoryNameEntry;
import curam.provider.impl.ProviderCategoryPeriod;
import curam.provider.impl.ProviderCategoryPeriodDAO;
import curam.provider.impl.ProviderEnquiryDAO;
import curam.provider.impl.ProviderEnquiryReferenceNumberGenerator;
import curam.provider.impl.ProviderEnquirySecurityCheck;
import curam.provider.impl.ProviderReferenceNumberStrategy;
import curam.provider.impl.ProviderType;
import curam.provider.impl.ProviderTypeDAO;
import curam.provider.impl.ProviderTypeNameEntry;
import curam.useradmin.impl.MaintainAdminConcernRole;
import curam.useradmin.impl.ProviderEnquiryAdminRole;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * Facade layer class having API for managing provider enquiry.
 *
 */

public abstract class ProviderEnquiry extends curam.cpm.facade.base.ProviderEnquiry {

  /**
   * Instance of provider enquiry DAO.
   */
  @Inject
  protected ProviderEnquiryDAO providerEnquiryDAO;

  /**
   * Instance of provider category period DAO.
   */
  @Inject
  protected ProviderCategoryPeriodDAO providerCategoryPeriodDAO;

  /**
   * Instance of provider type DAO.
   */
  @Inject
  protected ProviderTypeDAO providerTypeDAO;

  /**
   * Instance of provider enquiry security check.
   */
  @Inject
  protected ProviderEnquirySecurityCheck providerEnquirySecurityCheck;

  /**
   * Instance of providerReferenceNumberStrategy.
   */
  @Inject
  ProviderReferenceNumberStrategy providerReferenceNumberStrategy;

  // BEGIN, CR00170638, GP
  /**
   * Reference to Provider Enquiry Reference Number Generator.
   */
  @Inject
  ProviderEnquiryReferenceNumberGenerator providerEnquiryReferenceNumberGenerator;
  // END, CR00170638

  // BEGIN, CR00234082, GP
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;
  // END, CR00234082
  
  /**
   * Constant for minimum Physical and designated capacity.
   */
  protected static final short kMinimumNumberOfChildren = 0;

  /**
   * Default Constructor.
   */
  public ProviderEnquiry() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * Creates the provider enquiry given the provider enquiry details. The
   * enquiry made by a potential provider requesting information about providing
   * services on behalf of the organization would be the provider enquiry
   * details.
   *
   * @param details
   * Contains the provider enquiry registration details.
   *
   * @return ProviderEnquiryKey Contains the provider enquiry ID.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERENQUIRY#ERR_PROVIDER_ENQUIRY_FV_NUMBER_OF_CHILDREN_NOT_WHOLE_NUMBER} -
   * If the number of children entered is not a whole number.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnquiryKey createProviderEnquiry(
    ProviderEnquiryRegistrationDetails details) throws AppException,
      InformationalException {

    // variables for creating provider enquiry
    curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.newInstance();

    // trim all the string values
    trimAllStringFields(details);

    validateNumberOfChildrenField(details);

    // BEGIN, CR00170638, GP
    providerEnquiry.setReferenceNumber(
      providerEnquiryReferenceNumberGenerator.generateReferenceNumber());
    // END, CR00170638

    // update the creator user id
    // instance of SystemUser for getting owner name
    SystemUser systemUser = SystemUserFactory.newInstance();

    providerEnquiry.setOwnerName(systemUser.getUserDetails().userName);

    // set workAddressDtls
    setWorkAddressDtls(details, providerEnquiry);

    // set homeAdressDtls
    setHomeAddressDtls(details, providerEnquiry);

    // set homePhoneDtls
    setHomePhoneDtls(details, providerEnquiry);

    // set workPhoneDtls
    setWorkPhoneDtls(details, providerEnquiry);

    // set mobilePhoneDtls
    setMobileNumberDtls(details, providerEnquiry);

    providerEnquiry.setProviderEnquiryDetails();

    return createEnquiryCategoryAndType(providerEnquiry, details);
  }

  // BEGIN, CR00234082, GP
  /**
   * Retrieves the create provider enquiry wizard menu properties.
   *
   * @return Create provider enquiry wizard menu properties.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public WizardMenuDetails getProviderEnquiryWizardMenuDetails()
    throws AppException, InformationalException {

    WizardMenuDetails wizardMenuDetails = new WizardMenuDetails();

    wizardMenuDetails.wizardMenu = CPMConstants.kCreateProviderEnquiryWizard;

    return wizardMenuDetails;
  }

  // END, CR00234082

  // BEGIN, CR00216313, RD
  /**
   * Lists Provider Enquiry summary details based on the date specified.
   *
   * @param searchByDateRangeKey
   * Contains the date range within which the provider enquiries have
   * to be searched.
   *
   * @return The list of Provider Enquiry Summary details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnquirySummaryDetailsList listProviderEnquiryWithinDateRange(
    SearchByDateRangeKey searchByDateRangeKey) throws AppException,
      InformationalException {

    ProviderEnquirySummaryDetailsList providerEnquirySummaryDetailsList = new ProviderEnquirySummaryDetailsList();

    // BEGIN, CR00225866, GP
    Set<curam.provider.impl.ProviderEnquiry> providerEnquirySet = providerEnquiryDAO.searchByDateRangeOwnerAndEnquiryStatus(
      SystemUserFactory.newInstance().getUserDetails().userName,
      EnquiryStatusEntry.OPEN.getCode(), searchByDateRangeKey.startDate,
      searchByDateRangeKey.endDate);

    // END, CR00225866
    
    for (curam.provider.impl.ProviderEnquiry providerEnquiry : providerEnquirySet) {
      providerEnquirySummaryDetailsList.enquriySummaryDetails.addRef(
        getProviderEnquiryFields(providerEnquiry));
    }

    return providerEnquirySummaryDetailsList;
  }

  // END, CR00216313

  /**
   * Trims all the string values provided in the provider enquiry registration
   * details.
   *
   * @param details
   * Contains the provider enquiry registration details.
   */
  // BEGIN, CR00177241, PM
  protected void trimAllStringFields(ProviderEnquiryRegistrationDetails details) {
    // END, CR00177241

    details.additionalInformation = details.additionalInformation.trim();
    details.additionalName = details.additionalName.trim();
    details.availabilityForContact = details.availabilityForContact.trim();
    details.homeAddressData = details.homeAddressData.trim();
    details.homePhoneAreaCode = details.homePhoneAreaCode.trim();
    details.homePhoneCountryCode = details.homePhoneCountryCode.trim();
    details.homePhoneExtension = details.homePhoneExtension.trim();
    details.homePhoneNumber = details.homePhoneNumber.trim();
    details.mobilePhoneAreaCode = details.mobilePhoneAreaCode.trim();
    details.mobilePhoneCountryCode = details.mobilePhoneCountryCode.trim();
    details.mobilePhoneExtension = details.mobilePhoneExtension.trim();
    details.mobilePhoneNumber = details.mobilePhoneNumber.trim();
    details.name = details.name.trim();
    details.preferredSession = details.preferredSession.trim();
    details.reasonForEnquiry = details.reasonForEnquiry.trim();
    details.scheduledMeeting = details.scheduledMeeting.trim();
    details.workAddressData = details.workAddressData.trim();
    details.workPhoneAreaCode = details.workPhoneAreaCode.trim();
    details.workPhoneCountryCode = details.workPhoneCountryCode.trim();
    details.workPhoneExtension = details.workPhoneExtension.trim();
    details.workPhoneNumber = details.workPhoneNumber.trim();

  }

  /**
   * Creates the provider enquiry, provider category period and provider type.
   *
   * @param providerEnquiry
   * The service layer instance into which the user-updateable fields
   * must be mapped.
   * @param details
   * The provider enquiry registration struct contain fields set by the
   * user.
   * @return ProviderEnquiryKey The provider enquiry ID.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected ProviderEnquiryKey createEnquiryCategoryAndType(
    // END, CR00177241
    curam.provider.impl.ProviderEnquiry providerEnquiry,
    ProviderEnquiryRegistrationDetails details) throws AppException,
      InformationalException {

    setProviderEnquiryFields(providerEnquiry, details);

    String providerCategory = CodeTable.getParentCode(
      ProviderTypeNameEntry.TABLENAME, details.providerType);

    // validate provider category and type
    validateProviderType(details.providerType);

    // create provider category period
    if ((providerCategory != null) && (providerCategory.length() > 0)) {

      // variables for creating provider category period
      ProviderCategoryPeriod providerCategoryPeriod = providerCategoryPeriodDAO.newInstance();

      providerCategoryPeriod.setCategory(
        ProviderCategoryNameEntry.get(providerCategory));
      providerCategoryPeriod.setPrimary(true);
      DateRange dateRange = new DateRange(Date.getCurrentDate(), null);

      providerCategoryPeriod.setDateRange(dateRange);

      providerCategoryPeriod.insert();
      // set provider category
      providerEnquiry.setProviderCategoryPeriod(providerCategoryPeriod);
      // create provider type based on category
      // variables for creating provider type based on provider category
      ProviderType providerType = providerTypeDAO.newInstance();

      providerType.setProviderCategoryPeriod(providerCategoryPeriod);
      providerType.setType(details.providerType);

      providerType.insert();
    }

    ProviderEnquiryKey providerEnquiryKey = new ProviderEnquiryKey();

    providerEnquiry.insert();
    providerEnquiryKey.providerEnquiryID = providerEnquiry.getID();

    details.referenceNumber = providerEnquiry.getReferenceNumber();

    ValidationHelper.failIfErrorsExist();

    return providerEnquiryKey;

  }

  /**
   * Validates the number of children currently in the household of the person
   * enquiring about becoming a provider. The number of children should be
   * greater than or equal to zero.
   *
   * @param providerType
   * Contains the provider type.
   * @throws InformationException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void validateProviderType(String providerType) throws AppException,
      // END, CR00177241
      InformationalException {

    if ((providerType == null) || (0 == providerType.length())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_PROVIDER_TYPE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * Updates the provider enquiry, category period and provider type details.
   *
   * @param providerEnquiry
   * Provider enquiry.
   * @param details
   * Provider enquiry registration details.
   * @return ProviderEnquiryKey Contains provider enquiry ID.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnquiryKey updateEnquiryCategoryAndType(
    curam.provider.impl.ProviderEnquiry providerEnquiry,
    ProviderEnquiryRegistrationDetails details) throws AppException,
      InformationalException {

    setProviderEnquiryFields(providerEnquiry, details);

    String providerCategory = CodeTable.getParentCode(
      ProviderTypeNameEntry.TABLENAME, details.providerType);

    // update provider category period
    // variables for updating provider category period
    // variables for creating provider category period
    if (details.providerCategoryPeriodID != 0) {
      // update the provider category
      final ProviderCategoryPeriod providerCategoryPeriod = providerCategoryPeriodDAO.get(
        details.providerCategoryPeriodID);

      providerCategoryPeriod.setCategory(
        ProviderCategoryNameEntry.get(providerCategory));
      // providerCategoryPeriod.setProviderEnquiry(providerEnquiry);
      providerCategoryPeriod.modify(details.providerCategoryVersionNo);
      providerEnquiry.setProviderCategoryPeriod(providerCategoryPeriod);

      // update provider type based on category
      if (details.providerTypeID != 0) {
        // update the provider type
        ProviderType providerType = providerTypeDAO.get(details.providerTypeID);

        providerType.setProviderCategoryPeriod(providerCategoryPeriod);
        providerType.setType(details.providerType);
        providerType.modify(details.providerTypeVersionNo);
      }
    }

    // details.registrationDetails.providerCategoryPeriodID =
    // providerCategoryPeriodKey.providerCategoryID;

    ProviderEnquiryKey providerEnquiryKey = new ProviderEnquiryKey();

    providerEnquiry.modify(details.versionNo);
    providerEnquiryKey.providerEnquiryID = providerEnquiry.getID();
    return providerEnquiryKey;
  }

  /**
   * Maps the enquiry fields updateable by the user to the fields on the service
   * layer object.
   *
   * @param providerEnquiry
   * The service layer instance into which the user-updateable fields
   * must be mapped.
   * @param details
   * The provider enquiry registration struct contain fields set by the
   * user.
   */
  // BEGIN, CR00177241, PM
  protected void setProviderEnquiryFields(
    // END, CR00177241
    curam.provider.impl.ProviderEnquiry providerEnquiry,
    ProviderEnquiryRegistrationDetails details) {

    providerEnquiry.setAdditionalInformation(details.additionalInformation);
    providerEnquiry.setAdditionalName(details.additionalName);
    providerEnquiry.setAttendedMeeting(details.attendedMeeting);
    providerEnquiry.setAvailabilityForContact(details.availabilityForContact);
    providerEnquiry.setConfirmedMeetingDetails(details.confirmedMeetingDetails);
    providerEnquiry.setName(details.name);
    providerEnquiry.setNumberOfChildren(details.noOfChildren);
    providerEnquiry.setObtainedApplicationForm(details.obtainedApplicationForm);
    providerEnquiry.setPreferredSession(details.preferredSession);
    providerEnquiry.setReasonForEnquiry(details.reasonForEnquiry);
    providerEnquiry.setScheduledMeeting(details.scheduledMeeting);
    providerEnquiry.setEnquiryDate(details.enquiryDate);

    // BEGIN, CR00100280, GYH
    providerEnquiry.setPreferredLanguage(
      LANGUAGEEntry.get(details.preferredLanguage));
    providerEnquiry.setPreferredCommunication(
      COMMUNICATIONMETHODEntry.get(details.preferredCommunication));
    // END, CR00100280

  }

  /**
   * Maps the work address fields updateable by the user to the fields on the
   * service layer object.
   *
   * @param details
   * The provider enquiry registration struct contain fields set by the
   * user.
   * @param providerEnquiry
   * The service layer instance into which the user-updateable fields
   * must be mapped.
   */
  // BEGIN, CR00177241, PM
  protected void setWorkAddressDtls(ProviderEnquiryRegistrationDetails details,
    // END, CR00177241
    curam.provider.impl.ProviderEnquiry providerEnquiry) {
    AddressDtls workAddressDtls = new AddressDtls();

    workAddressDtls.addressData = details.workAddressData;
    providerEnquiry.setWorkAddressID(details.workAddressID);
    providerEnquiry.setWorkAddressDtls(workAddressDtls);
  }

  /**
   * Maps the home address fields updateable by the user to the fields on the
   * service layer object.
   *
   * @param details
   * The provider enquiry registration struct contain fields set by the
   * user.
   * @param providerEnquiry
   * The service layer instance into which the user-updateable fields
   * must be mapped.
   */
  // BEGIN, CR00177241, PM
  protected void setHomeAddressDtls(ProviderEnquiryRegistrationDetails details,
    // END, CR00177241
    curam.provider.impl.ProviderEnquiry providerEnquiry) {
    AddressDtls homeAddressDtls = new AddressDtls();

    homeAddressDtls.addressData = details.homeAddressData;
    homeAddressDtls.versionNo = details.homeAddressVersionNo;
    providerEnquiry.setHomeAddressID(details.homeAddressID);
    providerEnquiry.setHomeAddressDtls(homeAddressDtls);

  }

  /**
   * Maps the home phone fields updateable by the user to the fields on the
   * service layer object.
   *
   * @param details
   * The provider enquiry registration struct contain fields set by the
   * user.
   * @param providerEnquiry
   * The service layer instance into which the user-updateable fields
   * must be mapped.
   */
  // BEGIN, CR00177241, PM
  protected void setHomePhoneDtls(ProviderEnquiryRegistrationDetails details,
    // END, CR00177241
    curam.provider.impl.ProviderEnquiry providerEnquiry) {
    PhoneNumberDtls homePhoneNumberDtls = new PhoneNumberDtls();

    homePhoneNumberDtls.phoneCountryCode = details.homePhoneCountryCode;
    homePhoneNumberDtls.phoneAreaCode = details.homePhoneAreaCode;
    homePhoneNumberDtls.phoneNumber = details.homePhoneNumber;
    homePhoneNumberDtls.phoneExtension = details.homePhoneExtension;
    homePhoneNumberDtls.statusCode = RECORDSTATUS.NORMAL;
    homePhoneNumberDtls.versionNo = details.homePhoneVersionNo;

    providerEnquiry.setHomePhoneNumberDtls(homePhoneNumberDtls);
    providerEnquiry.setHomePhoneNumberID(details.homePhoneNumberID);
  }

  /**
   * Maps the work phone fields updateable by the user to the fields on the
   * service layer object.
   *
   * @param details
   * The provider enquiry registration struct contain fields set by the
   * user.
   * @param providerEnquiry
   * The service layer instance into which the user-updateable fields
   * must be mapped.
   */
  // BEGIN, CR00177241, PM
  protected void setWorkPhoneDtls(ProviderEnquiryRegistrationDetails details,
    // END, CR00177241
    curam.provider.impl.ProviderEnquiry providerEnquiry) {

    PhoneNumberDtls workPhoneNumberDtls = new PhoneNumberDtls();

    workPhoneNumberDtls.phoneCountryCode = details.workPhoneCountryCode;
    workPhoneNumberDtls.phoneAreaCode = details.workPhoneAreaCode;
    workPhoneNumberDtls.phoneNumber = details.workPhoneNumber;
    workPhoneNumberDtls.phoneExtension = details.workPhoneExtension;
    workPhoneNumberDtls.statusCode = RECORDSTATUS.NORMAL;
    workPhoneNumberDtls.versionNo = details.workPhoneVersionNo;

    providerEnquiry.setWorkPhoneNumberDtls(workPhoneNumberDtls);

    providerEnquiry.setWorkPhoneNumberID(details.workPhoneNumberID);
  }

  /**
   * Maps the mobile number fields updateable by the user to the fields on the
   * service layer object.
   *
   * @param details
   * The provider enquiry registration struct contain fields set by the
   * user.
   * @param providerEnquiry
   * The service layer instance into which the user-updateable fields
   * must be mapped.
   */
  // BEGIN, CR00177241, PM
  protected void setMobileNumberDtls(ProviderEnquiryRegistrationDetails details,
    // END, CR00177241
    curam.provider.impl.ProviderEnquiry providerEnquiry) {
    PhoneNumberDtls mobilePhoneNumberDtls = new PhoneNumberDtls();

    mobilePhoneNumberDtls.phoneCountryCode = details.mobilePhoneCountryCode;
    mobilePhoneNumberDtls.phoneAreaCode = details.mobilePhoneAreaCode;
    mobilePhoneNumberDtls.phoneNumber = details.mobilePhoneNumber;
    mobilePhoneNumberDtls.phoneExtension = details.mobilePhoneExtension;
    providerEnquiry.setMobilePhoneNumberDtls(mobilePhoneNumberDtls);
    mobilePhoneNumberDtls.statusCode = RECORDSTATUS.NORMAL;
    mobilePhoneNumberDtls.versionNo = details.mobilePhoneVersionNo;

    providerEnquiry.setMobilePhoneNumberID(details.mobilePhoneNumberID);
  }

  /**
   * Modifies the provider enquiry details made by a potential provider
   * requesting information about providing services on behalf of the
   * organization.
   *
   * @param details
   * Contains the provider enquiry registration details.
   * @return ProviderEnquiryKey The provider enquiry ID.
   * @throws InformationalException
   * {@link curam.message.PROVIDERENQUIRY#ERR_PROVIDER_ENQUIRY_FV_NUMBER_OF_CHILDREN_NOT_WHOLE_NUMBER} -
   * If the number of children entered is not a whole number.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnquiryKey modifyProviderEnquiry(
    ProviderEnquiryRegistrationDetails details) throws AppException,
      InformationalException {

    curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.get(
      details.providerEnquiryID);

    // trim all the string values
    trimAllStringFields(details);
    validateNumberOfChildrenField(details);
    providerEnquiry.setReferenceNumber(details.referenceNumber);
    providerEnquiry.setOwnerName(details.ownerName);

    // set workAddressDtls
    setWorkAddressDtls(details, providerEnquiry);

    // set homeAdressDtls
    setHomeAddressDtls(details, providerEnquiry);

    // set homePhoneDtls
    setHomePhoneDtls(details, providerEnquiry);

    // set workPhoneDtls
    setWorkPhoneDtls(details, providerEnquiry);

    // set mobilePhoneDtls
    setMobileNumberDtls(details, providerEnquiry);

    providerEnquiry.setProviderEnquiryUpdateDetails();

    return updateEnquiryCategoryAndType(providerEnquiry, details);

  }

  /**
   * Validates the value entered for the Number of Children field.
   *
   * @param details
   * Contains the provider enquiry registration details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void validateNumberOfChildrenField(
    // END, CR00177241
    ProviderEnquiryRegistrationDetails details) throws AppException,
      InformationalException {
    // Manipulation variable
    short numberOfChildrenIntType = kMinimumNumberOfChildren;
    String numberOfChildren = details.numberOfChildren;

    if (numberOfChildren.length() > kMinimumNumberOfChildren) {
      try {
        // Convert physicalCapacity String to int
        numberOfChildrenIntType = Short.parseShort(numberOfChildren);

        details.noOfChildren = numberOfChildrenIntType;

      } catch (NumberFormatException exception) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERENQUIRYExceptionCreator.ERR_PROVIDER_ENQUIRY_FV_NUMBER_OF_CHILDREN_NOT_WHOLE_NUMBER(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        // END, CR00168877
        ValidationHelper.failIfErrorsExist();
      }

      // BEGIN CR00085445, GYH
      // Number of children cannot be less than zero
      if (numberOfChildrenIntType < kMinimumNumberOfChildren) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERENQUIRYExceptionCreator.ERR_PROVIDER_FV_NUMBER_OF_CHILDREN_GT_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }

    }
  }

  /**
   * Retrieves the provider enquiry details given the provider enquiry ID.
   *
   * @param key
   * Contains the provider enquiry ID.
   * @return ProviderEnquiryRegistrationDetails Contains the existing provider
   * enquiry details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnquiryRegistrationDetails viewProviderEnquiry(
    ProviderEnquiryKey key) throws AppException, InformationalException {

    // Provider Enquiry
    curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.get(
      key.providerEnquiryID);

    // Provider Category
    curam.provider.impl.ProviderCategoryPeriod providerCategoryPeriod = providerEnquiry.getProviderCategoryPeriod();

    // Address Entity
    Address addressObj = AddressFactory.newInstance();

    // Phone Number Entity
    PhoneNumber phoneNumberObj = PhoneNumberFactory.newInstance();

    // Return Struct
    ProviderEnquiryRegistrationDetails details = new
      ProviderEnquiryRegistrationDetails();

    AddressKey addressKey = new AddressKey();
    AddressDtls addressHomeDtls = new AddressDtls();
    AddressDtls addressWorkDtls = new AddressDtls();
    OtherAddressData formattedAddressData = new OtherAddressData();
    PhoneNumberKey phoneNumberKey = new PhoneNumberKey();
    PhoneNumberDtls phoneNumberDtls = new PhoneNumberDtls();

    // set page context description
    details.pageContextDescription = providerEnquiry.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + providerEnquiry.getReferenceNumber();

    // Check if home address is specified for enquiry
    if (providerEnquiry.getHomeAddressID() != 0) {
      // Read the enquiry home address
      addressKey.addressID = providerEnquiry.getHomeAddressID();
      addressHomeDtls = addressObj.read(addressKey);

      // Assign the enquiry home address

      details.homeAddressData = addressHomeDtls.addressData;
      details.homeAddressVersionNo = addressHomeDtls.versionNo;
      details.homeAddressID = addressHomeDtls.addressID;
      formattedAddressData.addressData = addressHomeDtls.addressData;
      addressObj.getAddressStrings(formattedAddressData);
      details.formattedHomeAddressData = formattedAddressData.addressData;
    }

    // Check if work address is specified for enquiry
    if (providerEnquiry.getWorkAddressID() != 0) {
      // Read the enquiry work address
      addressKey.addressID = providerEnquiry.getWorkAddressID();
      addressWorkDtls = addressObj.read(addressKey);

      // Assign the enquiry work address
      details.workAddressData = addressWorkDtls.addressData;
      details.workAddressVersionNo = addressWorkDtls.versionNo;
      formattedAddressData.addressData = addressWorkDtls.addressData;
      details.workAddressID = addressWorkDtls.addressID;
      addressObj.getAddressStrings(formattedAddressData);
      details.formattedWorkAddressData = formattedAddressData.addressData;
    }

    // Check if home phone number is specified for provider enquiry
    if (providerEnquiry.getHomePhoneNumberID() != 0) {

      // Read the enquiry home phone number
      phoneNumberKey.phoneNumberID = providerEnquiry.getHomePhoneNumberID();
      phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);

      // Assign enquiry home phone number
      details.homePhoneAreaCode = phoneNumberDtls.phoneAreaCode;

      details.homePhoneNumberID = phoneNumberDtls.phoneNumberID;
      details.homePhoneCountryCode = phoneNumberDtls.phoneCountryCode;
      details.homePhoneExtension = phoneNumberDtls.phoneExtension;
      details.homePhoneNumber = phoneNumberDtls.phoneNumber;
      details.homePhoneVersionNo = phoneNumberDtls.versionNo;
    }

    // Check if work phone number is specified for provider enquiry
    if (providerEnquiry.getWorkPhoneNumberID() != 0) {
      // Read the enquiry work phone number
      phoneNumberKey.phoneNumberID = providerEnquiry.getWorkPhoneNumberID();
      phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);

      // Assign enquiry work phone number
      details.workPhoneNumberID = phoneNumberDtls.phoneNumberID;
      details.workPhoneAreaCode = phoneNumberDtls.phoneAreaCode;
      details.workPhoneCountryCode = phoneNumberDtls.phoneCountryCode;
      details.workPhoneExtension = phoneNumberDtls.phoneExtension;
      details.workPhoneNumber = phoneNumberDtls.phoneNumber;
      details.workPhoneVersionNo = phoneNumberDtls.versionNo;
    }

    // Check if mobile phone number is specified for provider enquiry
    if (providerEnquiry.getMobilePhoneNumberID() != 0) {

      // Read the enquiry mobile phone number
      phoneNumberKey.phoneNumberID = providerEnquiry.getMobilePhoneNumberID();
      phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);

      // Assign enquiry mobile phone number
      details.mobilePhoneNumberID = phoneNumberDtls.phoneNumberID;
      details.mobilePhoneAreaCode = phoneNumberDtls.phoneAreaCode;
      details.mobilePhoneCountryCode = phoneNumberDtls.phoneCountryCode;
      details.mobilePhoneExtension = phoneNumberDtls.phoneExtension;
      details.mobilePhoneNumber = phoneNumberDtls.phoneNumber;
      details.mobilePhoneVersionNo = phoneNumberDtls.versionNo;
    }

    // Check if category is specified for provider enquiry
    if (providerCategoryPeriod.getID() != null
      && (!providerCategoryPeriod.getID().equals(0L))) {

      // Assign the enquiry category
      details.providerTypeCategory = ProviderCategoryNameEntry.get(providerCategoryPeriod.getCategory().getCode()).getCode();
      details.providerCategoryPeriodID = providerCategoryPeriod.getID();
      details.providerCategoryVersionNo = providerCategoryPeriod.getVersionNo();

      // Provider Type Entity
      for (final ProviderType providerType : providerTypeDAO.searchBy(
        providerCategoryPeriod)) {

        details.providerTypeID = providerType.getID();
        details.providerType = providerType.getType();
        details.providerTypeVersionNo = providerType.getVersionNo();
      }
    }

    details.providerEnquiryID = providerEnquiry.getID();
    details.additionalInformation = providerEnquiry.getAdditionalInformation();
    details.additionalName = providerEnquiry.getAdditionalName();
    details.attendedMeeting = providerEnquiry.hasAttendedMeeting();
    details.availabilityForContact = providerEnquiry.getAvailabilityForContact();
    details.confirmedMeetingDetails = providerEnquiry.isMeetingConfirmed();

    details.enquiryDate = providerEnquiry.getEnquiryDate();
    details.endDate = providerEnquiry.getEndDate();
    details.name = providerEnquiry.getName();
    details.noOfChildren = providerEnquiry.getNumberOfChildren();
    details.obtainedApplicationForm = providerEnquiry.hasObtainedApplicationForm();
    
    details.ownerName = providerEnquiry.getOwnerName();
    
    details.preferredSession = providerEnquiry.getPreferredSession();
    details.reasonForEnquiry = providerEnquiry.getReasonForEnquiry().getCode();
    details.recordStatus = providerEnquiry.getRecordStatus().getCode();
    details.referenceNumber = providerEnquiry.getReferenceNumber();
    details.scheduledMeeting = providerEnquiry.getScheduledMeeting();
    details.versionNo = providerEnquiry.getVersionNo();

    // BEGIN, CR00100280, GYH
    details.preferredLanguage = providerEnquiry.getPreferredLanguage().getCode();
    details.preferredCommunication = providerEnquiry.getPreferredCommunication().getCode();
    // END, CR00100280

    // BEGIN CR00113233 KR
    details.isExternalUser = providerEnquiry.isExternalUser(details.ownerName);
    // END CR00113233
    return details;
  }

  // BEGIN, CR00234402, GP
  /**
   * Retrieves the provider enquiry details for the given provider enquiry ID.
   *
   * @param key
   * Contains the provider enquiry ID.
   *
   * @return The existing provider enquiry details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnquiryDetails viewProviderEnquiryDetails(
    final ProviderEnquiryKey key) throws AppException, InformationalException {

    curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.get(
      key.providerEnquiryID);

    ProviderCategoryPeriod providerCategoryPeriod = providerEnquiry.getProviderCategoryPeriod();

    Address addressObj = AddressFactory.newInstance();

    PhoneNumber phoneNumberObj = PhoneNumberFactory.newInstance();

    ProviderEnquiryDetails providerEnquiryDetails = new ProviderEnquiryDetails();

    AddressKey addressKey = new AddressKey();
    AddressDtls addressHomeDtls = new AddressDtls();
    AddressDtls addressWorkDtls = new AddressDtls();
    OtherAddressData formattedAddressData = new OtherAddressData();
    PhoneNumberKey phoneNumberKey = new PhoneNumberKey();
    PhoneNumberDtls phoneNumberDtls = new PhoneNumberDtls();

    providerEnquiryDetails.pageContextDescription = providerEnquiry.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + providerEnquiry.getReferenceNumber();

    if (0 != providerEnquiry.getHomeAddressID()) {
      addressKey.addressID = providerEnquiry.getHomeAddressID();
      addressHomeDtls = addressObj.read(addressKey);

      providerEnquiryDetails.homeAddressData = addressHomeDtls.addressData;
      providerEnquiryDetails.homeAddressVersionNo = addressHomeDtls.versionNo;
      providerEnquiryDetails.homeAddressID = addressHomeDtls.addressID;
      formattedAddressData.addressData = addressHomeDtls.addressData;
      addressObj.getAddressStrings(formattedAddressData);
      providerEnquiryDetails.formattedHomeAddressData = formattedAddressData.addressData;
    }

    if (0 != providerEnquiry.getWorkAddressID()) {
      addressKey.addressID = providerEnquiry.getWorkAddressID();
      addressWorkDtls = addressObj.read(addressKey);

      providerEnquiryDetails.workAddressData = addressWorkDtls.addressData;
      providerEnquiryDetails.workAddressVersionNo = addressWorkDtls.versionNo;
      formattedAddressData.addressData = addressWorkDtls.addressData;
      providerEnquiryDetails.workAddressID = addressWorkDtls.addressID;
      addressObj.getAddressStrings(formattedAddressData);
      providerEnquiryDetails.formattedWorkAddressData = formattedAddressData.addressData;
    }

    if (0 != providerEnquiry.getHomePhoneNumberID()) {

      phoneNumberKey.phoneNumberID = providerEnquiry.getHomePhoneNumberID();
      phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);

      providerEnquiryDetails.homePhoneAreaCode = phoneNumberDtls.phoneAreaCode;

      providerEnquiryDetails.homePhoneNumberID = phoneNumberDtls.phoneNumberID;
      providerEnquiryDetails.homePhoneCountryCode = phoneNumberDtls.phoneCountryCode;
      providerEnquiryDetails.homePhoneExtension = phoneNumberDtls.phoneExtension;
      providerEnquiryDetails.homePhoneNumber = phoneNumberDtls.phoneNumber;
      providerEnquiryDetails.homePhoneVersionNo = phoneNumberDtls.versionNo;
    }

    if (0 != providerEnquiry.getWorkPhoneNumberID()) {
      phoneNumberKey.phoneNumberID = providerEnquiry.getWorkPhoneNumberID();
      phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);

      providerEnquiryDetails.workPhoneNumberID = phoneNumberDtls.phoneNumberID;
      providerEnquiryDetails.workPhoneAreaCode = phoneNumberDtls.phoneAreaCode;
      providerEnquiryDetails.workPhoneCountryCode = phoneNumberDtls.phoneCountryCode;
      providerEnquiryDetails.workPhoneExtension = phoneNumberDtls.phoneExtension;
      providerEnquiryDetails.workPhoneNumber = phoneNumberDtls.phoneNumber;
      providerEnquiryDetails.workPhoneVersionNo = phoneNumberDtls.versionNo;
    }

    if (0 != providerEnquiry.getMobilePhoneNumberID()) {

      phoneNumberKey.phoneNumberID = providerEnquiry.getMobilePhoneNumberID();
      phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);

      providerEnquiryDetails.mobilePhoneNumberID = phoneNumberDtls.phoneNumberID;
      providerEnquiryDetails.mobilePhoneAreaCode = phoneNumberDtls.phoneAreaCode;
      providerEnquiryDetails.mobilePhoneCountryCode = phoneNumberDtls.phoneCountryCode;
      providerEnquiryDetails.mobilePhoneExtension = phoneNumberDtls.phoneExtension;
      providerEnquiryDetails.mobilePhoneNumber = phoneNumberDtls.phoneNumber;
      providerEnquiryDetails.mobilePhoneVersionNo = phoneNumberDtls.versionNo;
    }

    if (null != providerCategoryPeriod.getID()
      && (!providerCategoryPeriod.getID().equals(0L))) {

      providerEnquiryDetails.providerTypeCategory = ProviderCategoryNameEntry.get(providerCategoryPeriod.getCategory().getCode()).getCode();
      providerEnquiryDetails.providerCategoryPeriodID = providerCategoryPeriod.getID();
      providerEnquiryDetails.providerCategoryVersionNo = providerCategoryPeriod.getVersionNo();

      for (final ProviderType providerType : providerTypeDAO.searchBy(
        providerCategoryPeriod)) {

        providerEnquiryDetails.providerTypeID = providerType.getID();
        providerEnquiryDetails.providerType = providerType.getType();
        providerEnquiryDetails.providerTypeVersionNo = providerType.getVersionNo();
      }
    }

    providerEnquiryDetails.providerEnquiryID = providerEnquiry.getID();
    providerEnquiryDetails.additionalInformation = providerEnquiry.getAdditionalInformation();
    providerEnquiryDetails.additionalName = providerEnquiry.getAdditionalName();
    providerEnquiryDetails.attendedMeeting = providerEnquiry.hasAttendedMeeting();
    providerEnquiryDetails.availabilityForContact = providerEnquiry.getAvailabilityForContact();
    providerEnquiryDetails.confirmedMeetingDetails = providerEnquiry.isMeetingConfirmed();

    providerEnquiryDetails.enquiryDate = providerEnquiry.getEnquiryDate();
    providerEnquiryDetails.endDate = providerEnquiry.getEndDate();
    providerEnquiryDetails.name = providerEnquiry.getName();
    providerEnquiryDetails.noOfChildren = providerEnquiry.getNumberOfChildren();
    providerEnquiryDetails.obtainedApplicationForm = providerEnquiry.hasObtainedApplicationForm();

    User user = userDAO.get(providerEnquiry.getOwnerName());

    providerEnquiryDetails.ownerFullName = user.getFullName();
    providerEnquiryDetails.ownerName = providerEnquiry.getOwnerName();

    providerEnquiryDetails.preferredSession = providerEnquiry.getPreferredSession();
    providerEnquiryDetails.reasonForEnquiry = providerEnquiry.getReasonForEnquiry().getCode();
    providerEnquiryDetails.recordStatus = providerEnquiry.getRecordStatus().getCode();
    providerEnquiryDetails.referenceNumber = providerEnquiry.getReferenceNumber();
    providerEnquiryDetails.scheduledMeeting = providerEnquiry.getScheduledMeeting();
    providerEnquiryDetails.versionNo = providerEnquiry.getVersionNo();

    providerEnquiryDetails.preferredLanguage = providerEnquiry.getPreferredLanguage().getCode();
    providerEnquiryDetails.preferredCommunication = providerEnquiry.getPreferredCommunication().getCode();

    providerEnquiryDetails.isExternalUser = providerEnquiry.isExternalUser(
      providerEnquiryDetails.ownerName);

    InformationalMessageList informationalMessageList = getProviderEnquiryInformationals(
      key);

    if (informationalMessageList.dtls.size() > 0) {
      providerEnquiryDetails.userSkillsInd = true;
    }

    return providerEnquiryDetails;
  }

  // END, CR00234402

  // BEGIN, CR00237197, GP
  /**
   * Lists all the provider enquiries that are assigned to that user, consisting
   * of the Reference Number, Name, Address Line 1, Enquiry Date and Status. The
   * list is ordered by Name.
   *
   * @param key
   * Contains the ListProviderEnquiryKey.
   *
   * @return List of all provider enquiry.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listProviderEnquiryDetails(ListProviderEnquiryKey)}.
   * This method is not useful for displaying user full name as well
   * as conditional display of links in list of provider enquiries
   * for resource manager. Hence this method is deprecated. The
   * newly added method will give the option to the user to display
   * the user full name as well as conditional display links. See
   * release note: CR00237197.
   */
  @Deprecated
  // END, CR00237197
  public ProviderEnquirySummaryDetailsList listProviderEnquiries(
    ListProviderEnquiryKey key) throws AppException, InformationalException {

    // Create instance of System User
    SystemUser user = SystemUserFactory.newInstance();

    // set user name
    key.userName = user.getUserDetails().userName;

    // Create instance
    ProviderEnquirySummaryDetailsList list = new
      ProviderEnquirySummaryDetailsList();

    // Populate facade layer ProviderEnquirySummaryDetailsList object
    final Set<curam.provider.impl.ProviderEnquiry> providerEnquiries = providerEnquiryDAO.searchBy(
      key.userName);

    for (final curam.provider.impl.ProviderEnquiry providerEnquiry :
      providerEnquiries) {
      list.enquriySummaryDetails.addRef(
        getProviderEnquiryFields(providerEnquiry));
    }

    return sortProviderEnquries(list);
  }

  // BEGIN, CR00205476, GP
  /**
   * Retrieves a list of provider enquiry details.
   *
   * @param providerEnquiryKey
   * Provider enquiry for which details are to returned.
   *
   * @return Provider enquiry details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnquiryViewDetailsList listProviderEnquiryDetails(
    final ListProviderEnquiryKey providerEnquiryKey) throws AppException,
      InformationalException {
    
    // BEGIN, CR00206443, SS
    SystemUser user = SystemUserFactory.newInstance();

    providerEnquiryKey.userName = user.getUserDetails().userName;
    // END, CR00206443
    
    ProviderEnquiryViewDetailsList providerEnquiryViewDetailsList = new ProviderEnquiryViewDetailsList();

    final Set<curam.provider.impl.ProviderEnquiry> providerEnquiries = providerEnquiryDAO.searchBy(
      providerEnquiryKey.userName);

    for (final curam.provider.impl.ProviderEnquiry providerEnquiry : providerEnquiries) {

      providerEnquiryViewDetailsList.providerEnquiryViewDetails.addRef(
        getProviderEnquiryDetailsFields(providerEnquiry));
    }

    return sortProviderEnquiryDetails(providerEnquiryViewDetailsList);
  }

  // END, CR00205476
  

  // BEGIN, CR00237197, GP
  /**
   * List of all provider enquiries that are assigned to the supervisor,
   * consisting of the Reference Number, Name, Address Line 1, Enquiry Date and
   * Status. The list is ordered by Name.
   *
   * @param key
   * Contains the ListProviderEnquiryKey.
   *
   * @return The List of all provider enquiries for supervisor.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listProviderEnquiryDetailsForSupervisor()}. This method
   * is not useful for displaying user full name in list of provider
   * enquiries for resource manager supervisor. Hence this method is
   * deprecated. The newly added method will give the option to the
   * user to display the user full name. See release note:
   * CR00237197.
   */
  @Deprecated
  // END, CR00237197
  public ProviderEnquirySummaryDetailsList listProviderEnquiriesForSupervisor(
    ListProviderEnquiryKey key) throws AppException, InformationalException {

    // Create instance of System User
    SystemUser user = SystemUserFactory.newInstance();

    MaintainAdminConcernRole maintainAdminConcernRole = new
      MaintainAdminConcernRole();

    // set user name
    key.userName = user.getUserDetails().userName;
    UsersKey usersKey = new UsersKey();
    UserNameDetailsList userNameDetailsList = new UserNameDetailsList();

    usersKey.userName = key.userName;

    userNameDetailsList = maintainAdminConcernRole.listSubordinateUser(usersKey);
    UserNameDetails userNameDetails = new UserNameDetails();

    userNameDetails.userName = key.userName;
    userNameDetailsList.detailsList.addRef(userNameDetails);

    int noOfUsers = userNameDetailsList.detailsList.size();

    // Create instance
    ProviderEnquirySummaryDetailsList list = new
      ProviderEnquirySummaryDetailsList();

    for (int i = 0; i < noOfUsers; i++) {

      // Populate facade layer ProviderEnquirySummaryDetailsList object
      final Set<curam.provider.impl.ProviderEnquiry> providerEnquiries = providerEnquiryDAO.searchBy(
        userNameDetailsList.detailsList.item(i).userName);

      for (final curam.provider.impl.ProviderEnquiry providerEnquiry :
        providerEnquiries) {
        list.enquriySummaryDetails.addRef(
          getProviderEnquiryFields(providerEnquiry));
      }
    }

    return sortProviderEnquries(list);

  }

  // BEGIN, CR00236233, GP
  /**
   * Lists all the provider enquiries that are assigned to the resource manager
   * supervisor. The list is ordered by reference number.
   *
   * @return A list of provider enquiries that are assigned to resource manager
   * supervisor.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnquiryViewDetailsList listProviderEnquiryDetailsForSupervisor()
    throws AppException, InformationalException {

    ProviderEnquiryViewDetailsList providerEnquiryViewDetailsList = new ProviderEnquiryViewDetailsList();

    SystemUser user = SystemUserFactory.newInstance();

    MaintainAdminConcernRole maintainAdminConcernRole = new
      MaintainAdminConcernRole();

    UsersKey usersKey = new UsersKey();
    UserNameDetailsList userNameDetailsList = new UserNameDetailsList();

    usersKey.userName = user.getUserDetails().userName;

    userNameDetailsList = maintainAdminConcernRole.listSubordinateUser(usersKey);
    UserNameDetails userNameDetails = new UserNameDetails();

    userNameDetails.userName = usersKey.userName;
    userNameDetailsList.detailsList.addRef(userNameDetails);

    for (final UserNameDetails userNameDetail : userNameDetailsList.detailsList.items()) {

      final Set<curam.provider.impl.ProviderEnquiry> providerEnquiries = providerEnquiryDAO.searchBy(
        userNameDetail.userName);

      for (final curam.provider.impl.ProviderEnquiry providerEnquiry :
        providerEnquiries) {
        
        providerEnquiryViewDetailsList.providerEnquiryViewDetails.addRef(
          getProviderEnquiryDetailsFields(providerEnquiry));
      }
    }
    
    return sortProviderEnquiryDetails(providerEnquiryViewDetailsList);
  }

  // END, CR00236233
  
  /**
   * Searches all the Provider Enquiries that match the criteria entered and
   * which are in open status. The list is ordered by Name.
   *
   * @param key
   * Contains the SearchProviderEnquiryKey.
   * @return ProviderEnquirySummaryDetailsList Contains provider enquiry summary
   * details returned by the search.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnquirySummaryDetailsList searchProviderEnquiry(
    SearchProviderEnquiryKey key) throws
      AppException, InformationalException {

    // Check if user has specified search criteria
    if (key.referenceNumber.length() == 0 && key.name.length() == 0
      && key.street1.length() == 0 && key.city.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 4);
    }

    ProviderEnquirySummaryDetailsList list = new
      ProviderEnquirySummaryDetailsList();

    // BEGIN, CR00097355, NRV
    key.enquiryStatus = EnquiryStatus.OPEN;
    // END, CR00097355
    // populate facade layer ProviderEnquirySummaryDetailsList object
    final Set<curam.provider.impl.ProviderEnquiry> providerEnquiries = providerEnquiryDAO.searchBy(
      key.name, key.referenceNumber, key.street1, key.city, key.searchByName,
      key.searchByReferenceNumber, key.searchByStreet1, key.searchByCity,
      key.addressLine1Type, key.cityTypeCode, key.enquiryStatus);

    for (final curam.provider.impl.ProviderEnquiry providerEnquiry :
      providerEnquiries) {
      list.enquriySummaryDetails.addRef(
        getProviderEnquiryFields(providerEnquiry));
    }
    ValidationHelper.failIfErrorsExist();

    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(list.informationalMsgDtlsOpt);
    // END, CR00292696
    
    return sortProviderEnquries(list);
  }

  /**
   * Searches the provider enquiry irrespective of status. Lists all the
   * provider enquiries that match the criteria entered and is ordered by Name.
   *
   * @param key
   * Contains the SearchProviderEnquiryKey.
   * @return ProviderEnquirySummaryDetailsList Contains provider enquiry summary
   * details returned by the search.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnquirySummaryDetailsList searchAllEnquiries(
    SearchProviderEnquiryKey key) throws
      AppException, InformationalException {

    // Check if user has specified search criteria
    if (0 == key.referenceNumber.length() && 0 == key.name.length()
      && 0 == key.street1.length() && 0 == key.city.length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 5);
    }

    ProviderEnquirySummaryDetailsList list = new
      ProviderEnquirySummaryDetailsList();

    // populate facade layer ProviderEnquirySummaryDetailsList object
    final Set<curam.provider.impl.ProviderEnquiry> providerEnquiries = providerEnquiryDAO.searchBy(
      key.name, key.referenceNumber, key.street1, key.city, key.searchByName,
      key.searchByReferenceNumber, key.searchByStreet1, key.searchByCity,
      key.addressLine1Type, key.cityTypeCode, key.enquiryStatus);

    for (final curam.provider.impl.ProviderEnquiry providerEnquiry :
      providerEnquiries) {
      list.enquriySummaryDetails.addRef(
        getProviderEnquiryFields(providerEnquiry));
    }
    ValidationHelper.failIfErrorsExist();

    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(list.informationalMsgDtlsOpt);
    // END, CR00292696
    
    return sortProviderEnquries(list);
  }

  /**
   * Closes the enquiry setting the end date to the current business date and
   * updates the enquiry status.
   *
   * @param key
   * Contains the provider enquiry ID.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void closeProviderEnquiry(ProviderEnquiryKey key) throws AppException,
      InformationalException {

    // Enquiry details struct
    curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.get(
      key.providerEnquiryID);

    // Check if enquiry is already closed
    // BEGIN, CR00097355, NRV
    if (providerEnquiry.getRecordStatus().equals(EnquiryStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_CLOSE_CLOSED_ENQUIRY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    ValidationHelper.failIfErrorsExist();

    // Close provider enquiry
    providerEnquiry.close(providerEnquiry.getVersionNo());

    // create event
    Event closeEnquiry = new Event();

    closeEnquiry.eventKey = PROVIDERENQUIRY.CLOSEENQUIRY;
    closeEnquiry.primaryEventData = key.providerEnquiryID;

    // Raise event to close this workflow task.
    EventService.raiseEvent(closeEnquiry);

  }

  // ____________________________________________________________________________
  /**
   * Transfers the Provider Enquiry details to an enrolled Provider.
   *
   * @param enquiryKey
   * Contains provider enquiry ID.
   * @return ProviderEnrollmentDetails contains the provider enrollment details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnrollmentDetails transferEnquiryToProvider(
    ProviderEnquiryKey enquiryKey) throws AppException,
      InformationalException {

    // Provider Enquiry entity
    curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.get(
      enquiryKey.providerEnquiryID);

    // Provider Category Entity
    ProviderCategoryPeriod providerCategoryPeriod = providerEnquiry.getProviderCategoryPeriod();

    // Address Entity
    Address addressObj = AddressFactory.newInstance();

    // Phone Number Entity
    PhoneNumber phoneNumberObj = PhoneNumberFactory.newInstance();

    // Key and Details Structs
    ProviderEnrollmentDetails providerEnrollmentDetails = new
      ProviderEnrollmentDetails();

    AddressKey addressKey = new AddressKey();
    AddressDtls addressDtls = new AddressDtls();
    PhoneNumberKey phoneNumberKey = new PhoneNumberKey();
    PhoneNumberDtls phoneNumberDtls = new PhoneNumberDtls();

    // Assign the enquiry name to provider name
    providerEnrollmentDetails.providerName = providerEnquiry.getName();
    providerEnrollmentDetails.versionNo = providerEnquiry.getVersionNo();

    // BEGIN, CR00100280, GYH
    providerEnrollmentDetails.prefLanguage = providerEnquiry.getPreferredLanguage().getCode();
    providerEnrollmentDetails.prefCommMethod = providerEnquiry.getPreferredCommunication().getCode();
    // END, CR00100280

    // Read the enquiry home address
    if (providerEnquiry.getHomeAddressID() != 0) {
      addressKey.addressID = providerEnquiry.getHomeAddressID();
      addressDtls = addressObj.read(addressKey);

      // Assign the enquiry home address to provider address
      providerEnrollmentDetails.addressData = addressDtls.addressData;
    }

    // Read the enquiry home phone number
    if (providerEnquiry.getHomePhoneNumberID() != 0) {
      phoneNumberKey.phoneNumberID = providerEnquiry.getHomePhoneNumberID();
      phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);

      // Assign enquiry home phone number to provider primary phone number
      providerEnrollmentDetails.phoneAreaCode = phoneNumberDtls.phoneAreaCode;
      providerEnrollmentDetails.phoneCountryCode = phoneNumberDtls.phoneCountryCode;
      providerEnrollmentDetails.phoneExtension = phoneNumberDtls.phoneExtension;
      providerEnrollmentDetails.phoneNumber = phoneNumberDtls.phoneNumber;
      providerEnrollmentDetails.phoneType = PHONETYPE.PERSONAL;
    }

    if (providerCategoryPeriod.getID() != 0) {

      // Assign the enquiry category as provider primary category
      // providerEnrollmentDetails.providerType = CodeTable.getOneItem(
      // ProviderTypeNameEntry.TABLENAME, providerCategoryPeriod.getCategory());
      providerEnrollmentDetails.providerType = ProviderCategoryNameEntry.get(providerCategoryPeriod.getCategory().getCode()).getCode();
      // Provider Type Entity
      for (final ProviderType providerType :
        providerCategoryPeriod.getProviderTypes()) {

        providerEnrollmentDetails.providerCategory = providerType.getType();
      }
    }

    // create event
    Event transferEnquiryToProvider = new Event();

    transferEnquiryToProvider.eventKey = PROVIDERENQUIRY.TRANSFERENQUIRYTOPROVIDER;
    transferEnquiryToProvider.primaryEventData = enquiryKey.providerEnquiryID;

    // Raise event to close this workflow task.
    EventService.raiseEvent(transferEnquiryToProvider);

    return providerEnrollmentDetails;

  }

  /**
   * Checks whether the enquiry has already been registered as provider or
   * enquiry is closed.
   *
   * @param key
   * Contains the provider enquiry ID.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void confirmEnquiryNotTransferred(ProviderEnquiryKey key)
    throws AppException, InformationalException {

    // Provider Enquiry entity
    curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.get(
      key.providerEnquiryID);

    // perform a security check
    providerEnquirySecurityCheck.checkEnquirySecurity(providerEnquiry);

    // Check the status of the enquiry
    // BEGIN, CR00097355, NRV
    if (providerEnquiry.getRecordStatus().equals(EnquiryStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_TRANSFER_CLOSED_ENQUIRY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    ValidationHelper.failIfErrorsExist();

  }

  /**
   * Set the new owner for the provider enquiry supplied.
   *
   * @param details
   * Contains the provider enquiry id and owner user name details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void setOwner(SetProviderEnquiryAdminRoleDetails details)
    throws AppException, InformationalException {

    ProviderEnquiryAdminRole providerEnquiryAdminRole = new
      ProviderEnquiryAdminRole();

    providerEnquiryAdminRole.setOwner(details);

    // check for informational exceptions
    TransactionInfo.getInformationalManager().failOperation();

  }

  /**
   * Returns a list of provider enquiry administration role details list given
   * the provider enquiry ID.
   *
   * @param key
   * Contains provider enquiry ID.
   * @return ProviderEnquiryAdminRoleDetailsList Administration role details
   * list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnquiryAdminRoleDetailsList listAdminRole(
    ProviderEnquiryKey key) throws AppException, InformationalException {

    ProviderEnquiryAdminRoleDetailsList providerEnquiryAdminRoleDetailsList = new ProviderEnquiryAdminRoleDetailsList();

    ProviderEnquiryAdminRole providerEnquiryAdminRole = new
      ProviderEnquiryAdminRole();

    // Create instance of provider enquiry
    curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.get(
      key.providerEnquiryID);

    providerEnquiryAdminRoleDetailsList = providerEnquiryAdminRole.listProviderEnquiryAdminUserRole(
      key);

    // set page context description
    providerEnquiryAdminRoleDetailsList.description = providerEnquiry.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + providerEnquiry.getReferenceNumber();

    return providerEnquiryAdminRoleDetailsList;
  }

  // BEGIN, CR00184531, GP
  /**
   * Reads the provider enquiry details that are required to be shown on
   * provider enquiry tab details.
   *
   * @param providerEnquiryKey
   * Provider enquiry for which details are to be returned.
   *
   * @return Provider enquiry details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewProviderEnquiryTabDetails viewProviderEnquiryTabDetails(
    ProviderEnquiryKey providerEnquiryKey) throws AppException,
      InformationalException {

    ViewProviderEnquiryTabDetails viewProviderEnquiryTabDetails = new ViewProviderEnquiryTabDetails();

    ProviderEnquiryRegistrationDetails providerEnquiryRegistrationDetails = viewProviderEnquiry(
      providerEnquiryKey);

    // BEGIN, CR00186342, GP
    TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
    AddressTabDetails addressTabDetails = new AddressTabDetails();

    if (0 != providerEnquiryRegistrationDetails.workAddressID) {

      addressTabDetails.addressData = providerEnquiryRegistrationDetails.workAddressData;

    } else {

      addressTabDetails.addressData = providerEnquiryRegistrationDetails.homeAddressData;
    }

    // BEGIN, CR00207463, RD
    if (!CuramConst.gkEmpty.equals(addressTabDetails.addressData)) {
      viewProviderEnquiryTabDetails.addressString = tabDetailFormatterObj.formatAddress(addressTabDetails).addressString;
    }
    // END, CR00207463

    PhoneNumberKey phoneNumberKey = new PhoneNumberKey();

    if (0 != providerEnquiryRegistrationDetails.workPhoneNumberID) {

      phoneNumberKey.phoneNumberID = providerEnquiryRegistrationDetails.workPhoneNumberID;
      // BEGIN, CR00197421, PS
      viewProviderEnquiryTabDetails.phoneNumberString = tabDetailFormatterObj.formatPhoneNumber(phoneNumberKey).phoneNumberString;
      // END, CR00197421
    } else if (0 != providerEnquiryRegistrationDetails.homePhoneNumberID) {

      phoneNumberKey.phoneNumberID = providerEnquiryRegistrationDetails.homePhoneNumberID;

      // BEGIN, CR00197421, PS
      viewProviderEnquiryTabDetails.phoneNumberString = tabDetailFormatterObj.formatPhoneNumber(phoneNumberKey).phoneNumberString;
    } else if (0 != providerEnquiryRegistrationDetails.mobilePhoneNumberID) {

      phoneNumberKey.phoneNumberID = providerEnquiryRegistrationDetails.mobilePhoneNumberID;
      viewProviderEnquiryTabDetails.phoneNumberString = tabDetailFormatterObj.formatPhoneNumber(phoneNumberKey).phoneNumberString;
    }
    // END, CR00197421
    // END, CR00186342

    viewProviderEnquiryTabDetails.enquiryDate = providerEnquiryRegistrationDetails.enquiryDate;
    viewProviderEnquiryTabDetails.enquiryStatus = providerEnquiryRegistrationDetails.recordStatus;
    viewProviderEnquiryTabDetails.primaryCategory = providerEnquiryRegistrationDetails.providerTypeCategory;
    viewProviderEnquiryTabDetails.providerConcernRoleID = providerEnquiryRegistrationDetails.providerID;
    viewProviderEnquiryTabDetails.providerEnquiryID = providerEnquiryRegistrationDetails.providerEnquiryID;
    viewProviderEnquiryTabDetails.providerName = providerEnquiryRegistrationDetails.name;
    viewProviderEnquiryTabDetails.referenceNumber = providerEnquiryRegistrationDetails.referenceNumber;

    return viewProviderEnquiryTabDetails;
  }

  // END, CR00184531

  /**
   * Returns provider enquiry fields.
   *
   * @param providerEnquiry
   * Instance of provider enquiry.
   * @return ProviderEnquirySummaryDetails Contains provider enquiry summary
   * details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected ProviderEnquirySummaryDetails getProviderEnquiryFields(
    // END, CR00177241
    curam.provider.impl.ProviderEnquiry providerEnquiry) throws AppException,
      InformationalException {

    ProviderEnquirySummaryDetails enquirySummaryDetails = new
      ProviderEnquirySummaryDetails();

    enquirySummaryDetails.referenceNumber = providerEnquiry.getReferenceNumber();
    enquirySummaryDetails.providerEnquiryID = providerEnquiry.getID();
    enquirySummaryDetails.name = providerEnquiry.getName();
    enquirySummaryDetails.enquiryDate = providerEnquiry.getEnquiryDate();
    enquirySummaryDetails.statusCode = providerEnquiry.getRecordStatus().getCode();
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = providerEnquiry.getHomeAddressID();

    // create instance of addressElementObj
    AddressElement addressElementObj = AddressElementFactory.newInstance();
    AddressElementDtlsList addressElementDtlsList = addressElementObj.readAddressElementDetails(
      addressKey);

    int size = addressElementDtlsList.dtls.size();

    // loop the addressElmentdetailsList to fetch the city and addressLine1
    for (int i = 0; i < size; i++) {
      if (addressElementDtlsList.dtls.item(i).elementType.equals(
        ADDRESSELEMENTTYPE.CITY)) {
        enquirySummaryDetails.city = addressElementDtlsList.dtls.item(i).elementValue;
      } else if (addressElementDtlsList.dtls.item(i).elementType.equals(
        ADDRESSELEMENTTYPE.LINE1)) {
        enquirySummaryDetails.street1 = addressElementDtlsList.dtls.item(i).elementValue;
      }
    }

    enquirySummaryDetails.owner = providerEnquiry.getOwnerName();
    return enquirySummaryDetails;

  }

  /**
   * Sorts a set of provider enquiries into a sorted list for display by enquiry
   * name.
   *
   * @param unsortedProviderEnquries
   * The set of unsorted provider enquiries.
   * @return ProviderEnquirySummaryDetailsList A sorted list of Provider
   * Enquiries by Enquiry name.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  // BEGIN, CR00177241, PM
  protected ProviderEnquirySummaryDetailsList sortProviderEnquries(
    // END, CR00177241
    ProviderEnquirySummaryDetailsList unsortedProviderEnquries) {

    // Sort by name for display - using a list (instead of a set) in case there
    // are duplicate names.

    Collections.sort(unsortedProviderEnquries.enquriySummaryDetails,
      new Comparator<ProviderEnquirySummaryDetails>() {
      public int compare(final ProviderEnquirySummaryDetails lhs,
        ProviderEnquirySummaryDetails rhs) {
        return lhs.name.compareToIgnoreCase(rhs.name);
      }
    });

    ProviderEnquirySummaryDetailsList providerEnquirySummaryDetailsList = new
      ProviderEnquirySummaryDetailsList();

    providerEnquirySummaryDetailsList.enquriySummaryDetails.addAll(
      unsortedProviderEnquries.enquriySummaryDetails);

    return providerEnquirySummaryDetailsList;
  }

  /**
   * Sets the owner of the provider enquiry to be the logged in user given the
   * provider enquiry ID.
   *
   * @param key
   * Contains the provider enquiry ID.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void updateProviderEnquiryOwner(ProviderEnquiryKey key)
    throws AppException, InformationalException {

    SetProviderEnquiryAdminRoleDetails setProviderEnquiryAdminRoleDetails = new
      SetProviderEnquiryAdminRoleDetails();

    // set the details
    setProviderEnquiryAdminRoleDetails.providerEnquiryID = key.providerEnquiryID;
    setProviderEnquiryAdminRoleDetails.userName = TransactionInfo.getProgramUser();

    setOwner(setProviderEnquiryAdminRoleDetails);

    // create event
    Event closeEnquiry = new Event();

    closeEnquiry.eventKey = PROVIDERENQUIRY.CLOSEENQUIRY;
    closeEnquiry.primaryEventData = key.providerEnquiryID;

    // Raise event to close this workflow task.
    EventService.raiseEvent(closeEnquiry);
  }

  // BEGIN, CR00100280, GYH

  /**
   * Displays the informational message if the preferred language of the
   * provider enquiry does not match any language in the user skills.
   *
   * @param key
   * Contains unique ID of a provider enquiry.
   * @return The informational message if the preferred language specified in
   * provider enquiry does not match any language in the user skills.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationalMessageList getProviderEnquiryInformationals(
    ProviderEnquiryKey key) throws AppException, InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();

    curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.get(
      key.providerEnquiryID);

    // BEGIN, CR00246086, SS   
    // Read skills of the organization user and check if any of the languages of
    // the user matches the preferred language of the provider enquiry, when the 
    // user skill is "Languages".
    curam.core.facade.intf.Organization organisationObj = curam.core.facade.fact.OrganizationFactory.newInstance();

    UserSkillListKey userSkillListKey = new UserSkillListKey();

    userSkillListKey.userSkillList.userName = TransactionInfo.getProgramUser();

    // BEGIN, CR00332487, SK
    UserSkills listUserSkillDetails = organisationObj.getUserSkills(
      userSkillListKey);

    boolean isUserSkillLangMatched = false;
    
    for (UserSkillDetails userSkillDetails : listUserSkillDetails.listUserSkillDetails.userSkillDtlsList.items()) {

      UserSkillLanguageReadMultiKey userSkillLanguageReadMultiKey = new UserSkillLanguageReadMultiKey();

      userSkillLanguageReadMultiKey.userSkillID = userSkillDetails.dtls.userSkillID;
      
      UserSkillLanguagesDtlsList userSkillLanguagesDtlsList = UserSkillLanguagesFactory.newInstance().searchByUserSkillID(
        userSkillLanguageReadMultiKey);
      
      if (RECORDSTATUSEntry.NORMAL.getCode().equals(
        userSkillDetails.dtls.recordStatus)) {
        // END, CR00332487
        
        for (UserSkillLanguagesDtls userSkillLanguagesDtls : 
          userSkillLanguagesDtlsList.dtls) {
          
          if (CodeTable.getOneItemForUserLocale(LANGUAGE.TABLENAME, providerEnquiry.getPreferredLanguage().getCode()).equals(
            CodeTable.getOneItemForUserLocale(LANGUAGE.TABLENAME,
            userSkillLanguagesDtls.languageCode))) {
            isUserSkillLangMatched = true;
            break;
          }
        }
      } 
    }
    // END, CR00246086
    // If preferred language of the provider enquiry does not match any of the
    // languages when user skill is "Languages" then assign and return the
    // information message of the same to the client.
    // BEGIN, CR00234402, GP
    if (!isUserSkillLangMatched) {
      // END, CR00234402
      
      AppException message = PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_XRV_PROVIDER_ENQUIRY_PREFFERED_LANGUAGE_DOES_NOT_MATCH_USER_SKILLS_LANGUAGE(
        LANGUAGEEntry.get(providerEnquiry.getPreferredLanguage().getCode()).getCodeTableItemIdentifier());

      InformationalManager informationalManager = new InformationalManager();

      informationalManager.addInformationalMsg(message,
        CPMConstants.kEmptyString,
        InformationalElement.InformationalType.kWarning);

      String warnings[] = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        InformationalMessage infoMessage = new InformationalMessage();

        infoMessage.messageTest = warnings[i];
        informationalMessageList.dtls.addRef(infoMessage);
      }
    }

    return informationalMessageList;
  }

  // END, CR00100280

  // BEGIN, CR00205476, GP
  /**
   * Returns provider enquiry details.
   *
   * @param providerEnquiry
   * Provider enquiry for which details are to be returned.
   *
   * @return Provider enquiry details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ProviderEnquiryViewDetails getProviderEnquiryDetailsFields(
    final curam.provider.impl.ProviderEnquiry providerEnquiry)
    throws AppException, InformationalException {

    ProviderEnquiryViewDetails providerEnquiryViewDetails = new ProviderEnquiryViewDetails();

    providerEnquiryViewDetails.referenceNumber = providerEnquiry.getReferenceNumber();
    providerEnquiryViewDetails.providerEnquiryID = providerEnquiry.getID();
    providerEnquiryViewDetails.name = providerEnquiry.getName();
    providerEnquiryViewDetails.enquiryDate = providerEnquiry.getEnquiryDate();
    providerEnquiryViewDetails.statusCode = providerEnquiry.getRecordStatus().getCode();
    providerEnquiryViewDetails.versionNo = providerEnquiry.getVersionNo();

    AddressKey addressKey = new AddressKey();

    addressKey.addressID = providerEnquiry.getHomeAddressID();

    AddressElement addressElementObj = AddressElementFactory.newInstance();
    AddressElementDtlsList addressElementDtlsList = addressElementObj.readAddressElementDetails(
      addressKey);

    for (AddressElementDtls addressElementDtls : addressElementDtlsList.dtls.items()) {

      if (ADDRESSELEMENTTYPEEntry.CITY.getCode().equals(
        addressElementDtls.elementType)) {

        providerEnquiryViewDetails.city = addressElementDtls.elementValue;
      } else if (ADDRESSELEMENTTYPEEntry.LINE1.getCode().equals(
        addressElementDtls.elementType)) {

        providerEnquiryViewDetails.street1 = addressElementDtls.elementValue;
      }
    }

    // BEGIN, CR00293652, ASN
    TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
    AddressTabDetails addressTabDetails = new AddressTabDetails();
    Address addressObj = AddressFactory.newInstance();

    if (0 != providerEnquiry.getHomeAddressID()) {
      addressKey.addressID = providerEnquiry.getHomeAddressID();
      addressTabDetails.addressData = addressObj.read(addressKey).addressData;
    }

    if (!CuramConst.gkEmpty.equals(addressTabDetails.addressData)) {
      providerEnquiryViewDetails.addressStringOpt = tabDetailFormatterObj.formatAddress(addressTabDetails).addressString;
    }
    // END, CR00293652
    providerEnquiryViewDetails.owner = providerEnquiry.getOwnerName();
    
    // BEGIN, CR00236233, GP
    User user = userDAO.get(providerEnquiryViewDetails.owner);

    providerEnquiryViewDetails.ownerFullName = user.getFullName();
    // END, CR00236233
    
    ProviderCategoryPeriod providerCategoryPeriod = providerEnquiry.getProviderCategoryPeriod();

    if (null != providerCategoryPeriod.getID()
      && 0 != providerCategoryPeriod.getID()) {

      providerEnquiryViewDetails.categoryVersionNo = providerCategoryPeriod.getVersionNo();

      for (final ProviderType providerType : providerTypeDAO.searchBy(
        providerCategoryPeriod)) {

        providerEnquiryViewDetails.typeVersionNo = providerType.getVersionNo();
      }
    }

    // BEGIN, CR00413903, RD
    if (EnquiryStatusEntry.TRANSFERRED.getCode().equals(
      providerEnquiryViewDetails.statusCode)) {
      providerEnquiryViewDetails.relatedProviderExist = true;
    }
    // END, CR00413903
    return providerEnquiryViewDetails;

  }

  // END, CR00205476
  

  // BEGIN, CR00236233, GP
  /**
   * Sorts a set of provider enquiries into a sorted list for display. The list
   * is sorted in ascending order of the reference numbers.
   *
   * @param unsortedProviderEnquries
   * The set of unsorted provider enquiries.
   *
   * @return A sorted list of provider enquiries sorted by reference number.
   */
  protected ProviderEnquiryViewDetailsList sortProviderEnquiryDetails(
    ProviderEnquiryViewDetailsList unsortedProviderEnquries) {

    Collections.sort(unsortedProviderEnquries.providerEnquiryViewDetails,
      new Comparator<ProviderEnquiryViewDetails>() {
      public int compare(final ProviderEnquiryViewDetails lhs,
        ProviderEnquiryViewDetails rhs) {
        return lhs.referenceNumber.compareToIgnoreCase(rhs.referenceNumber);
      }
    });

    ProviderEnquiryViewDetailsList providerEnquiryViewDetailsList = new ProviderEnquiryViewDetailsList();

    providerEnquiryViewDetailsList.providerEnquiryViewDetails.addAll(
      unsortedProviderEnquries.providerEnquiryViewDetails);

    return providerEnquiryViewDetailsList;
  }

  // END, CR00236233
  
  // BEGIN, CR00292696, IBM
  /**
   * Collects the list of informations from the informational manager and adds
   * them to the list parameter passed in.
   *
   * @param informationalMsgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList informationalMsgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }
  // END, CR00292696
}
