/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.impl;


import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Helper base class for entity implementations.
 *
 * The following standard operations are implemented:
 * <ul>
 * <li>insert
 * <li>
 * <li>modify </li>
 * <ul>
 *
 * However, the interface of each entity will dictate which of these operations
 * is/are exposed to calling code.
 */
public abstract class ClassicEntity<StandardDtls> {

  protected StandardDtls standardDtls;

  /**
   * Default constructor.
   */
  public ClassicEntity(StandardDtls standardDtls) {
    this.standardDtls = standardDtls;
  }

  /**
   * Convenience method to get the single physical row details.
   */
  protected StandardDtls getDtls() {
    return standardDtls;
  }

  /**
   * Standard implementation of entity insert.
   *
   * Subclasses may override this method in order to provide operations such as
   * validation or notification processing.
   */
  public abstract void insert() throws AppException, InformationalException;

  /**
   * Standard implementation of entity modify with optimistic lock check.
   *
   * Subclasses may override this method in order to provide operations such as
   * validation or notification processing.
   */
  public abstract void modify() throws AppException, InformationalException;

}
