/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import curam.cpm.facade.fact.ProviderEnquiryFactory;
import curam.cpm.facade.intf.ProviderEnquiry;
import curam.cpm.facade.struct.ProviderEnquiryRegistrationDetails;
import curam.cpm.sl.entity.struct.ProviderEnquiryKey;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.DateTime;


/**
 * This process class provides the functionality for Provider
 * Enquiry facade layer through the external application
 *
 */
public abstract class ExternalProviderEnquiry extends curam.cpm.eua.facade.base.ExternalProviderEnquiry {

  // ___________________________________________________________________________
  /**
   * Creates a provider enquiry
   *
   * @param details - contains the provider enquiry details
   *
   * @throws InformationalException
   *
   * @throws AppException
   */
  public void createEnquiry(ProviderEnquiryRegistrationDetails details)
    throws AppException, InformationalException {

    details.enquiryDate = DateTime.getCurrentDateTime();
    ProviderEnquiry providerEnquiryObj = ProviderEnquiryFactory.newInstance();

    ProviderEnquiryKey providerEnquiryKey = new ProviderEnquiryKey();

    providerEnquiryKey = providerEnquiryObj.createProviderEnquiry(details);

    // BEGIN, CR00171487, AK
    final Event event = new Event();

    event.eventKey = curam.events.PROVIDERENQUIRY.CREATEENQUIRY;
    event.primaryEventData = providerEnquiryKey.providerEnquiryID;
    EventService.raiseEvent(event);
    // END, CR00171487

  }
}
