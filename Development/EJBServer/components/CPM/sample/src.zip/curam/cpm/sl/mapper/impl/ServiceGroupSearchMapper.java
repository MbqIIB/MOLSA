/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.sl.mapper.impl;


import curam.core.impl.CuramConst;
import curam.core.impl.ExtractReadMultiOperation;
import curam.core.impl.Mapper;
import curam.core.struct.SearchServiceFieldDtls;
import curam.core.struct.SearchServiceKey;
import curam.core.struct.SearchServiceRowDtlsList;
import curam.cpm.sl.entity.fact.ServiceGroupFactory;
import curam.cpm.sl.entity.intf.ServiceGroup;
import curam.cpm.sl.entity.struct.ServiceGroupDtls;
import curam.cpm.sl.entity.struct.ServiceGroupKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.util.ArrayList;
import java.util.List;


/**
 * This mapper maps the data from the application database table to the staging
 * database table for service group search
 */
public class ServiceGroupSearchMapper extends curam.cpm.sl.mapper.base.ServiceGroupSearchMapper implements Mapper {

  /**
   * Gets the row external value for the specified object list.
   *
   * @param searchServiceID
   * the identifier of the search service
   *
   * @param objList
   * the list of search service related entity objects
   *
   * @return the externalKey
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public String getExtKey(SearchServiceKey searchServiceID, final List objList)
    throws AppException, InformationalException {

    String extValue = CuramConst.gkEmpty;

    if (objList != null) {
      for (int i = 0; i < objList.size(); i++) {
        Object obj = objList.get(i);

        if (obj instanceof ServiceGroupDtls) {
          extValue = Long.toString(((ServiceGroupDtls) obj).serviceGroupID);
          break;
        }
      }
    }
    return extValue;
  }

  /**
   * If a specialized field value can't be covered by the
   * ServiceGroupSearchMapper.getValue() case functionality this method should be
   * overridden in the mapper for the specific search service
   *
   * @param searchServiceID
   * the identifier of the search service
   * @param objList
   * list of entity objects for this specific mappers service id
   * @param dtls
   * The field whose value is required
   * @return The Object
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public Object getFieldValue(SearchServiceKey searchServiceID, List objList,
    SearchServiceFieldDtls dtls) throws AppException, InformationalException {
    return null;
  }

  public List<?> getObjectList(SearchServiceKey searchServiceID, Object objKey)
    throws AppException, InformationalException {

    ArrayList result = new ArrayList();

    ServiceGroupDtls serviceGroupDtls = new ServiceGroupDtls();

    ServiceGroup serviceGroupObj = ServiceGroupFactory.newInstance();

    ServiceGroupKey serviceGroupKey = new ServiceGroupKey();

    if (objKey instanceof ServiceGroupDtls) {

      serviceGroupDtls = (ServiceGroupDtls) objKey;
      serviceGroupKey.serviceGroupID = serviceGroupDtls.serviceGroupID;

      serviceGroupDtls = serviceGroupObj.read(serviceGroupKey);
    }

    result.add(serviceGroupDtls);

    return result;
  }

  /**
   * Maps information in the Application database to the search service staging
   * database for the specified search service id.
   *
   * @param searchServiceID
   * the identifier of the search service
   *
   * @return the list of all mapped rows for the specified search service
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchServiceRowDtlsList mapToStagingDb(
    SearchServiceKey searchServiceID) throws AppException,
      InformationalException {

    final ExtractReadMultiOperation readMultiOp = new ExtractReadMultiOperation(
      searchServiceID);

    ServiceGroup serviceGroupObj = ServiceGroupFactory.newInstance();

    serviceGroupObj.readAll(readMultiOp);

    return readMultiOp.getResult();
  }

  // BEGIN, CR00279574, MR
  /**
   * Deletes the row identified by the specified key from the staging
   * database.
   *
   * @param searchServiceKey
   * The identifier of the search service.
   * @param objKey
   * The object key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2. This method is deprecated as it is not
   * implemented and not used anywhere. See release note:
   * CR00279574.
   */
  @Deprecated
  public void remove(final SearchServiceKey searchServiceKey, final Object objKey)
    throws AppException, InformationalException {// Insert remove implementation here.
  }
  // END, CR00279574
}
