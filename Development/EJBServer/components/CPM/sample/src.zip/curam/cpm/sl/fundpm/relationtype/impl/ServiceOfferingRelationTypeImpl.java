/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.sl.fundpm.relationtype.impl;


import curam.core.fundpm.relationtype.impl.FundRelationType;
import curam.cpm.bom.impl.CPMBusinessObjectConst;
import curam.cpm.sl.entity.fact.ServiceOfferingFactory;
import curam.cpm.sl.entity.intf.ServiceOffering;
import curam.cpm.sl.entity.struct.ServiceOfferingDtls;
import curam.cpm.sl.entity.struct.ServiceOfferingKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * An implementation of {@link FundRelationType} that 
 * represents a Product.
 */
public class ServiceOfferingRelationTypeImpl implements FundRelationType {
  
  /**
   * {@inheritDoc}
   */
  @Override
  public String getKey() {    
    return CPMBusinessObjectConst.kServiceOfferingFundRelationType;
  }

  /**
   * {@inheritDoc}
   */  
  @Override
  public String getDisplayName(final Long relatedObjectId) 
    throws AppException, InformationalException {
   
    final ServiceOfferingDtls serviceOfferingDtls = getServiceOfferingDtls(
      relatedObjectId);

    return serviceOfferingDtls.name;
  }
 
  @Override
  public String getType(final Long relatedObjectId) 
    throws AppException, InformationalException {
    return CPMBusinessObjectConst.kServiceOfferingBOType;
  }
  
  /**
   * Returns the generated details object for the specified product identifier.
   *
   * @param relatedObjectId
   * @return the generated details object for the specified product identifier.
   * @throws AppException
   * @throws InformationalException
   */
  private ServiceOfferingDtls getServiceOfferingDtls(final Long relatedObjectId)
    throws AppException, InformationalException {

    final ServiceOfferingKey serviceOfferingKey = new ServiceOfferingKey();

    serviceOfferingKey.serviceOfferingID = relatedObjectId;
    
    final ServiceOffering serviceOfferingObj = ServiceOfferingFactory.newInstance();

    return serviceOfferingObj.read(serviceOfferingKey);
  }
}
