/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.cpm.facade.fact.ContextDescriptionFactory;
import curam.cpm.facade.struct.CancelHomeStudyHomeVisitKey;
import curam.cpm.facade.struct.CreateHomeStudyHomeVisitDetails;
import curam.cpm.facade.struct.HomeStudyHomeVisitDetails;
import curam.cpm.facade.struct.HomeStudyHomeVisitDetailsList;
import curam.cpm.facade.struct.HomeStudyHomeVisitDtls;
import curam.cpm.facade.struct.HomeStudyHomeVisitDtlsList;
import curam.cpm.facade.struct.HomeStudyHomeVisitKey;
import curam.cpm.facade.struct.HomeStudyHomeVisitSearchByHomeStudyKey;
import curam.cpm.facade.struct.ProviderKey;
import curam.cpm.facade.struct.UserNameDetails;
import curam.homestudy.impl.HomeStudy;
import curam.homestudy.impl.HomeStudyDAO;
import curam.homestudy.impl.HomeStudyHomeVisitDAO;
import curam.homestudy.impl.HomeVisitPurposeEntry;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * The facade implementation for {@link curam.homestudy.impl.HomeStudyHomeVisit}.
 */
public abstract class HomeStudyHomeVisit extends curam.cpm.facade.base.HomeStudyHomeVisit {

  /**
   * Guice no argument Constructor.
   */
  public HomeStudyHomeVisit() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected HomeStudyHomeVisitDAO homeStudyHomeVisitDAO;

  @Inject
  protected HomeStudyDAO homeStudyDAO;

  // BEGIN, CR00236233, GP
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;
  // END, CR00236233

  /**
   * Reads a home study home visit.
   *
   * @param key
   * The home study home visit key.
   * @return the home study home visit.
   * @throws AppException
   * @throws InformationalException
   */
  public HomeStudyHomeVisitDtls viewHomeStudyHomeVisit(
    HomeStudyHomeVisitKey key) throws AppException,
      InformationalException {

    curam.homestudy.impl.HomeStudyHomeVisit homeStudyHomeVisit = homeStudyHomeVisitDAO.get(
      key.homeStudyHomeVisitKey.homeStudyHomeVisitID);

    // Start CR00096126, JSP
    curam.cpm.facade.intf.ContextDescription contextDescription = ContextDescriptionFactory.newInstance();
    // End CR00096126

    // Get the values and populate the return struct
    HomeStudyHomeVisitDtls homeStudyHomeVisitDtls = new HomeStudyHomeVisitDtls();

    homeStudyHomeVisitDtls.homeStudyHomeVisitDtls = getHomeStudyHomeVisitFields(
      homeStudyHomeVisit);

    ProviderKey providerKey = new ProviderKey();

    providerKey.providerID = (homeStudyHomeVisit.getHomeStudy()).getProvider().getID();

    homeStudyHomeVisitDtls.providerConcernRoleID = providerKey.providerID;

    homeStudyHomeVisitDtls.contextDescription = contextDescription.getContextDescription(
      providerKey);

    return homeStudyHomeVisitDtls;
  }

  /**
   * Returns a list of home study home visit records for the given home study.
   *
   * @param key
   * the home study home visit key.
   * @return list of home study home visit records for the given home study.
   * @throws AppException
   * @throws InformationalException
   */
  public HomeStudyHomeVisitDtlsList listByHomeStudy(
    HomeStudyHomeVisitSearchByHomeStudyKey key) throws AppException,
      InformationalException {

    HomeStudyHomeVisitDtlsList homeStudyHomeVisitDtlsList = new HomeStudyHomeVisitDtlsList();

    final HomeStudy homeStudy = homeStudyDAO.get(
      key.searchByHomeStudyKey.homeStudyID);

    Set<curam.homestudy.impl.HomeStudyHomeVisit> activeHomeStudyHomeVisitSet = homeStudyHomeVisitDAO.searchByHomeStudy(
      homeStudy);

    for (curam.homestudy.impl.HomeStudyHomeVisit homeStudyHomeVisit : sortHomeStudyHomeVisits(
      activeHomeStudyHomeVisitSet)) {

      curam.cpm.sl.entity.struct.HomeStudyHomeVisitDtls homeStudyHomeVisitDtls = getHomeStudyHomeVisitFields(
        homeStudyHomeVisit);

      homeStudyHomeVisitDtlsList.HomeStudyHomeVisitDtlsList.dtls.addRef(
        homeStudyHomeVisitDtls);
    }

    // Add the context description
    curam.cpm.facade.intf.ContextDescription contextDescription = ContextDescriptionFactory.newInstance();

    ProviderKey providerKey = new ProviderKey();

    providerKey.providerID = (homeStudyDAO.get(key.searchByHomeStudyKey.homeStudyID)).getProvider().getID();

    homeStudyHomeVisitDtlsList.contextDescription = contextDescription.getContextDescription(
      providerKey);

    return homeStudyHomeVisitDtlsList;
  }

  // BEGIN, CR00236233, GP
  /**
   * Lists all the home study home visits for a given home study.
   *
   * @param homeStudyHomeVisitSearchByHomeStudyKey
   * Home study home visit details.
   *
   * @return A list of home study home visits for a given home study.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public HomeStudyHomeVisitDetailsList listHomeStudyHomeVisits(
    final HomeStudyHomeVisitSearchByHomeStudyKey homeStudyHomeVisitSearchByHomeStudyKey)
    throws AppException, InformationalException {
    HomeStudyHomeVisitDetailsList homeStudyHomeVisitDetailsList = new HomeStudyHomeVisitDetailsList();

    HomeStudyHomeVisitDtlsList homeStudyHomeVisitDtlsList = listByHomeStudy(
      homeStudyHomeVisitSearchByHomeStudyKey);

    for (final curam.cpm.sl.entity.struct.HomeStudyHomeVisitDtls homeStudyHomeVisitDtls : 
      homeStudyHomeVisitDtlsList.HomeStudyHomeVisitDtlsList.dtls.items()) {

      HomeStudy homeStudy = homeStudyDAO.get(homeStudyHomeVisitDtls.homeStudyID);
      HomeStudyHomeVisitDetails homeStudyHomeVisitDetails = new HomeStudyHomeVisitDetails();

      homeStudyHomeVisitDetails.homeStudyHomeVisitDetails = homeStudyHomeVisitDtls;
      homeStudyHomeVisitDetails.providerConcernRoleID = homeStudy.getProvider().getID();
      
      User user = userDAO.get(homeStudyHomeVisitDtls.conductedBy);

      homeStudyHomeVisitDetails.conductedByFullName = user.getFullName();
      
      homeStudyHomeVisitDetailsList.homeSudyHomeVisitDetailsList.addRef(
        homeStudyHomeVisitDetails);
    }

    return homeStudyHomeVisitDetailsList;
  }

  /**
   * Gets the details of the user who conducted the home study home visit.
   *
   * @param homeStudyHomeVisitKey
   * Home study home visit for which user details are to be retrieved.
   *
   * @return Details of the user who conducted the home study home visit.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public UserNameDetails getHomeStudyHomeVisitConductedByUser(
    final HomeStudyHomeVisitKey homeStudyHomeVisitKey) throws AppException,
      InformationalException {

    UserNameDetails userNameDetails = new UserNameDetails();
    curam.homestudy.impl.HomeStudyHomeVisit homeStudyHomeVisit = homeStudyHomeVisitDAO.get(
      homeStudyHomeVisitKey.homeStudyHomeVisitKey.homeStudyHomeVisitID);

    userNameDetails.userName = homeStudyHomeVisit.getConductedBy();
    
    User user = userDAO.get(homeStudyHomeVisit.getConductedBy());

    userNameDetails.fullName = user.getFullName();
    
    return userNameDetails;
  }

  // END, CR00236233

  /**
   * Creates a new home study home visit.
   *
   * @param details
   * the details for a home study home visit
   * @return the key identifying the home study home visit that was created.
   * @throws InformationalException
   * @throws AppException
   */
  public HomeStudyHomeVisitKey createHomeStudyHomeVisit(
    CreateHomeStudyHomeVisitDetails details) throws AppException,
      InformationalException {

    curam.homestudy.impl.HomeStudyHomeVisit homeStudyHomeVisit = homeStudyHomeVisitDAO.newInstance();

    // Set the values for the new record
    homeStudyHomeVisit.setComments(
      details.createHomeStudyHomeVisitDetails.comments);
    homeStudyHomeVisit.setConductedBy(
      details.createHomeStudyHomeVisitDetails.conductedBy);
    homeStudyHomeVisit.setHomeStudy(
      homeStudyDAO.get(details.createHomeStudyHomeVisitDetails.homeStudyID));
    homeStudyHomeVisit.setDateOfVisit(
      details.createHomeStudyHomeVisitDetails.dateOfVisit);
    homeStudyHomeVisit.setHomeVisitFindings(
      details.createHomeStudyHomeVisitDetails.homeVisitFindings);
    homeStudyHomeVisit.setPurpose(
      HomeVisitPurposeEntry.get(details.createHomeStudyHomeVisitDetails.purpose));

    // Insert the new record
    homeStudyHomeVisit.insert();

    // Initialize and populate the return struct
    HomeStudyHomeVisitKey homeStudyHomeVisitKey = new HomeStudyHomeVisitKey();

    homeStudyHomeVisitKey.homeStudyHomeVisitKey.homeStudyHomeVisitID = homeStudyHomeVisit.getID();

    return homeStudyHomeVisitKey;
  }

  /**
   * Modifies an existing home study home visit.
   *
   * @param details
   * the home study home visit details
   * @return the key identifying the home study home visit that was modified.
   * @throws InformationalException
   * @throws AppException
   */
  public HomeStudyHomeVisitKey modifyHomeStudyHomeVisit(
    HomeStudyHomeVisitDtls details) throws AppException,
      InformationalException {

    curam.homestudy.impl.HomeStudyHomeVisit homeStudyHomeVisit = homeStudyHomeVisitDAO.get(
      details.homeStudyHomeVisitDtls.homeStudyHomeVisitID);

    homeStudyHomeVisit.setComments(details.homeStudyHomeVisitDtls.comments);
    homeStudyHomeVisit.setConductedBy(
      details.homeStudyHomeVisitDtls.conductedBy);
    homeStudyHomeVisit.setDateOfVisit(
      details.homeStudyHomeVisitDtls.dateOfVisit);
    homeStudyHomeVisit.setHomeStudy(
      homeStudyDAO.get(details.homeStudyHomeVisitDtls.homeStudyID));
    homeStudyHomeVisit.setHomeVisitFindings(
      details.homeStudyHomeVisitDtls.homeVisitFindings);
    homeStudyHomeVisit.setPurpose(
      HomeVisitPurposeEntry.get(details.homeStudyHomeVisitDtls.purpose));

    // Modify the record using the version number from the facade.
    homeStudyHomeVisit.modify(details.homeStudyHomeVisitDtls.versionNo);

    // Initialize and populate the return struct
    HomeStudyHomeVisitKey homeStudyHomeVisitKey = new HomeStudyHomeVisitKey();

    homeStudyHomeVisitKey.homeStudyHomeVisitKey.homeStudyHomeVisitID = homeStudyHomeVisit.getID();

    return homeStudyHomeVisitKey;
  }

  /**
   * Logically deletes a home study home visit.
   *
   * @param key
   * the key identifying the home study home visit to delete.
   * @throws InformationalException
   * @throws AppException
   */
  public void deleteHomeStudyHomeVisit(CancelHomeStudyHomeVisitKey key)
    throws AppException, InformationalException {

    curam.homestudy.impl.HomeStudyHomeVisit homeStudyHomeVisit = homeStudyHomeVisitDAO.get(
      key.homeStudyHomeVisitID);

    // Call cancel and pass in the version number from the facade
    homeStudyHomeVisit.cancel(key.versionNo);
  }

  /**
   * Returns the details for the home study home visit.
   *
   * @param homeStudyHomeVisit
   * the home study home visit
   * @return the details for the home study home visit.
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected curam.cpm.sl.entity.struct.HomeStudyHomeVisitDtls getHomeStudyHomeVisitFields(
    // END, CR00177241
    curam.homestudy.impl.HomeStudyHomeVisit homeStudyHomeVisit)
    throws AppException, InformationalException {

    // Initialize and populate the return struct
    curam.cpm.sl.entity.struct.HomeStudyHomeVisitDtls homeStudyHomeVisitDtls = new curam.cpm.sl.entity.struct.HomeStudyHomeVisitDtls();

    homeStudyHomeVisitDtls.comments = homeStudyHomeVisit.getComments();
    homeStudyHomeVisitDtls.conductedBy = homeStudyHomeVisit.getConductedBy();
    homeStudyHomeVisitDtls.dateOfVisit = homeStudyHomeVisit.getDateOfVisit();
    homeStudyHomeVisitDtls.homeStudyID = homeStudyHomeVisit.getHomeStudy().getID();
    homeStudyHomeVisitDtls.homeStudyHomeVisitID = homeStudyHomeVisit.getID();
    homeStudyHomeVisitDtls.homeVisitFindings = homeStudyHomeVisit.getHomeVisitFindings();
    homeStudyHomeVisitDtls.purpose = homeStudyHomeVisit.getPurpose().getCode();
    homeStudyHomeVisitDtls.recordStatus = homeStudyHomeVisit.getLifecycleState().getCode();
    homeStudyHomeVisitDtls.versionNo = homeStudyHomeVisit.getVersionNo();

    ProviderKey providerKey = new ProviderKey();

    providerKey.providerID = (homeStudyHomeVisit.getHomeStudy()).getProvider().getID();

    return homeStudyHomeVisitDtls;
  }

  /**
   * Sorts a list of home study home visits by date of visit.
   *
   * @param unsortedHomeStudyHomeVisits
   * the unsorted list of home study home visits
   * @return the sorted list of home study home visits.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.homestudy.impl.HomeStudyHomeVisit> sortHomeStudyHomeVisits(
    // END, CR00177241
    final Set<curam.homestudy.impl.HomeStudyHomeVisit> unsortedHomeStudyHomeVisits) {

    final List<curam.homestudy.impl.HomeStudyHomeVisit> homeStudyHomeVisits = new ArrayList<curam.homestudy.impl.HomeStudyHomeVisit>(
      unsortedHomeStudyHomeVisits);

    Collections.sort(homeStudyHomeVisits,
      new Comparator<curam.homestudy.impl.HomeStudyHomeVisit>() {
      public int compare(
        curam.homestudy.impl.HomeStudyHomeVisit lhs,
        curam.homestudy.impl.HomeStudyHomeVisit rhs) {

        return lhs.getDateOfVisit().compareTo(rhs.getDateOfVisit());
      }
    });

    return homeStudyHomeVisits;
  }
}
