/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


import com.google.inject.ImplementedBy;
import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ListBuilder;
import curam.cefwidgets.docbuilder.impl.StackContainerBuilder;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.referral.impl.Referral;
import curam.servicedelivery.impl.ServiceDelivery;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.util.List;


/**
 * Helper interface for creating context panels for a
 * {@link curam.servicedelivery.impl.ServiceDelivery} or a
 * {@link curam.referral.impl.Referral}.
 *
 * @curam .non-implementable
 * @since 6.0
 */
@ImplementedBy(ServiceAndReferralContextPanelHelperImpl.class)
public interface ServiceAndReferralContextPanelHelper {

  /**
   * Format the XML data to display a single {@link CaseParticipantRole} in an
   * context panel. This consists of the persons image and any relevant images
   * for incidents, investigations, special cautions, etc.
   *
   * @param caseParticipantRole
   * The person being displayed
   * @return The panel with the person image
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  public ContentPanelBuilder getCaseMemberThumbnailDetails(
    final CaseParticipantRole caseParticipantRole) throws AppException,
      InformationalException;

  /**
   * Format XML data for the given list of {@link CaseParticipantRole} to be
   * displayed in a context panel.
   *
   * @param caseParticipantRoleList
   * The list of case participant roles being displayed
   * @return ContentPanelBuilder with the details of the panel to be displayed
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  public StackContainerBuilder getCaseMemberThumbnailDetails(
    final List<CaseParticipantRole> caseParticipantRoleList)
    throws AppException, InformationalException;

  /**
   * Format XML data for the context panel for an {@link Referral}.
   *
   * @param referral
   * The referral being displayed
   * @return ContentPanelBuilder with the details of the panel to be displayed
   */
  public ContentPanelBuilder getContextPanelDetails(final Referral referral);

  /**
   * Format XML data for the context panel for a {@link ServiceDelivery} on an
   * {@link OutcomePlan}.
   *
   * @param serviceDelivery
   * The service delivery being displayed
   * @return ContentPanelBuilder with the details of the panel to be displayed
   */
  public ContentPanelBuilder getContextPanelDetails(
    final ServiceDelivery serviceDelivery);

  /**
   * Returns a list containing the main details of the given
   * {@link ServiceDelivery}. This contains the following items:
   * <ul>
   * <li>Provider</li>
   * <li>Outcome</li>
   * <li>Reason (if Outcome Not Successful)</li>
   * <li>Latest Payment</li>
   * <li>Total</li>
   * </ul>
   *
   * @param serviceDelivery
   * The service delivery to read
   * @return The service delivery main details list
   */
  public ListBuilder getServiceDeliveryMainDetailsList(
    final ServiceDelivery serviceDelivery);

  /**
   * Returns a list containing the main details of the given {@link Referral}.
   * This contains the following items:
   * <ul>
   * <li>Provider</li>
   * <li>Created</li>
   * <li>Referred By</li>
   * </ul>
   *
   * @param referral
   * The referral to read
   * @return The referral main details list
   */
  public ListBuilder getReferralMainDetailsList(final Referral referral);
  
}
