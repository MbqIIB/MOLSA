/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.core.impl.CuramConst;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.ProviderAccreditationList;
import curam.cpm.facade.struct.ProviderAccreditationPeriodDetails;
import curam.cpm.facade.struct.ProviderAccreditationSummaryDetails;
import curam.cpm.sl.entity.struct.AccreditationPeriodDtls;
import curam.cpm.sl.entity.struct.AccreditationPeriodKey;
import curam.cpm.sl.entity.struct.ProviderAccreditationDtls;
import curam.cpm.sl.entity.struct.ProviderAccreditationKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.message.PROVIDERACCREDITATION;
import curam.provider.impl.AccreditationPeriod;
import curam.provider.impl.AccreditationPeriodDAO;
import curam.provider.impl.ProviderAccreditationDAO;
import curam.provider.impl.ProviderDAO;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.serviceoffering.ApprovalCriterion;
import curam.serviceoffering.impl.ServiceOfferingApprovalCriterion;
import curam.serviceoffering.impl.ServiceOfferingApprovalCriterionDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * Facade layer class for all the functionality relating to a Provider
 * Accreditation.
 *
 */
public abstract class ProviderAccreditation extends curam.cpm.facade.base.ProviderAccreditation {

  @Inject
  protected ProviderAccreditationDAO providerAccreditationDAO;

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected AccreditationPeriodDAO accreditationPeriodDAO;

  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  @Inject
  protected ServiceOfferingApprovalCriterionDAO soApprovalCriteriaDAO;

  // ___________________________________________________________________________
  /**
   * Constructor
   */
  public ProviderAccreditation() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  // ___________________________________________________________________________
  /**
   * Lists all accreditations for provider.
   *
   * @param providerKey
   * provider ID.
   *
   * @return ProviderAccreditationList list of accreditations for the provider.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderAccreditationList listAccreditationsforProvider(
    ProviderKey providerKey) throws AppException, InformationalException {

    ProviderAccreditationList providerAccreditationList = new ProviderAccreditationList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    Set<curam.provider.impl.ProviderAccreditation> unModifiableProviderAccreditations = provider.getAccreditations();
    Set<curam.provider.impl.ProviderAccreditation> providerAccreditations = new HashSet<curam.provider.impl.ProviderAccreditation>();

    providerAccreditations.addAll(unModifiableProviderAccreditations);

    for (final curam.provider.impl.ProviderAccreditation providerAccreditation : sortProviderAccreditations(
      providerAccreditations)) {

      providerAccreditationList.providerAccreditationDtls.addRef(
        getAccreditationDetails(providerAccreditation));
    }

    return providerAccreditationList;
  }

  // ___________________________________________________________________________
  /**
   * Creates accreditation for a provider.
   *
   * @param details
   * provider accreditation details.
   *
   * @return ProviderAccreditationKey ID of the newly created provider
   * accreditation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderAccreditationKey createProviderAccreditation(
    ProviderAccreditationPeriodDetails details) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderAccreditation providerAccreditation = providerAccreditationDAO.newInstance();

    /*
     * Set the details for provider accreditation */
    setProviderAccreditation(providerAccreditation, details);

    providerAccreditation.insert();

    final ProviderAccreditationKey providerAccreditationKey = new ProviderAccreditationKey();

    providerAccreditationKey.providerAccreditationID = providerAccreditation.getID();

    /*
     * Set the details for accreditation period */
    AccreditationPeriodDtls accreditationPeriodDtls = new AccreditationPeriodDtls();

    accreditationPeriodDtls.providerAccreditationID = providerAccreditationKey.providerAccreditationID;
    accreditationPeriodDtls.startDate = details.startDate;
    accreditationPeriodDtls.endDate = details.expiryDate;
    createProviderAccreditationPeriod(accreditationPeriodDtls);

    return providerAccreditationKey;

  }

  // ___________________________________________________________________________
  /**
   * Updates the accreditation details for a provider.
   *
   * @param dtls
   * The updated details of the provider accreditation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void updateProviderAccreditation(ProviderAccreditationDtls dtls)
    throws AppException, InformationalException {

    final curam.provider.impl.ProviderAccreditation providerAccreditation = providerAccreditationDAO.get(
      dtls.providerAccreditationID);

    /*
     * Set the details for provider accreditation */
    setProviderAccreditation(providerAccreditation, dtls);

    providerAccreditation.modify(dtls.versionNo);

  }

  // ___________________________________________________________________________
  /**
   * Reads all the details for a provider accreditation.
   *
   * @param key
   * provider accreditation ID.
   *
   * @return ProviderAccreditationSummaryDetails provider accreditation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderAccreditationSummaryDetails viewProviderAccreditation(
    ProviderAccreditationKey key) throws AppException, InformationalException {

    final curam.provider.impl.ProviderAccreditation providerAccreditation = providerAccreditationDAO.get(
      key.providerAccreditationID);

    final ProviderAccreditationSummaryDetails details = new ProviderAccreditationSummaryDetails();

    /*
     * read the details of provider accreditation */
    details.providerAccreditation.providerAccreditationID = providerAccreditation.getID();
    details.providerAccreditation.providerConcernRoleID = providerAccreditation.getProvider().getID();
    details.providerAccreditation.type = providerAccreditation.getType();
    details.providerAccreditation.recordStatus = providerAccreditation.getLifecycleState().toString();
    details.providerAccreditation.description = providerAccreditation.getDescription();
    details.providerAccreditation.versionNo = providerAccreditation.getVersionNo();

    // read all the accreditation periods associated with accreditation
    Set<AccreditationPeriod> unModifiableAccreditationPeriods = providerAccreditation.getAccreditationPeriods();
    Set<AccreditationPeriod> accreditionPeriods = new HashSet<AccreditationPeriod>();

    accreditionPeriods.addAll(unModifiableAccreditationPeriods);

    for (final curam.provider.impl.AccreditationPeriod accreditationPeriod : sortAccreditationPeriods(
      accreditionPeriods)) {
      details.accreditationPeriod.addRef(
        getAccreditationPeriodDetails(accreditationPeriod));
    }
    return details;
  }

  // ___________________________________________________________________________
  /**
   * Cancels the provider accreditation.
   *
   * @param keyVersionDetails
   * ID and version details of provider accreditation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelProviderAccreditation(KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    final curam.provider.impl.ProviderAccreditation providerAccreditation = providerAccreditationDAO.get(
      keyVersionDetails.id);

    providerAccreditation.cancel(keyVersionDetails.version);

  }

  // ___________________________________________________________________________
  /**
   * Creates provider accreditation period.
   *
   * @param dtls
   * The provider accreditation details.
   *
   * @return AccreditationPeriodKey ID of the newly created provider
   * accreditation period.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public AccreditationPeriodKey createProviderAccreditationPeriod(
    AccreditationPeriodDtls dtls) throws AppException, InformationalException {

    final curam.provider.impl.AccreditationPeriod accreditationPeriod = accreditationPeriodDAO.newInstance();

    /*
     * set the details of accreditation period */
    setAccreditationPeriod(accreditationPeriod, dtls);

    accreditationPeriod.insert();

    final AccreditationPeriodKey key = new AccreditationPeriodKey();

    key.accreditationPeriodID = accreditationPeriod.getID();

    return key;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the provider accreditation period details.
   *
   * @param dtls
   * updated details of provider accreditation period.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void updateProviderAccreditationPeriod(AccreditationPeriodDtls dtls)
    throws AppException, InformationalException {

    final curam.provider.impl.AccreditationPeriod accreditationPeriod = accreditationPeriodDAO.get(
      dtls.accreditationPeriodID);

    /*
     * set the details of accreditation period */
    setAccreditationPeriod(accreditationPeriod, dtls);

    accreditationPeriod.modify(dtls.versionNo);

  }

  // ___________________________________________________________________________
  /**
   * Reads all the details for a provider accreditation period.
   *
   * @param key
   * provider accreditation period ID.
   *
   * @return AccreditationPeriodDtls Details of the provider accreditation
   * period.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public AccreditationPeriodDtls viewProviderAccreditationPeriod(
    AccreditationPeriodKey key) throws AppException, InformationalException {

    final curam.provider.impl.AccreditationPeriod accreditationPeriod = accreditationPeriodDAO.get(
      key.accreditationPeriodID);

    final AccreditationPeriodDtls details = new AccreditationPeriodDtls();

    details.accreditationPeriodID = accreditationPeriod.getID();
    details.providerAccreditationID = accreditationPeriod.getProviderAccreditation().getID();
    details.startDate = accreditationPeriod.getDateRange().start();
    details.endDate = accreditationPeriod.getDateRange().end();
    details.versionNo = accreditationPeriod.getVersionNo();

    return details;
  }

  // ___________________________________________________________________________
  /**
   * The method to set the details of provider accreditation and accreditation
   * period
   *
   * @param providerAccreditation -
   * ProviderAccreditation
   * @param details -
   * ProviderAccreditationPeriodDetails
   */
  // BEGIN, CR00177241, PM
  protected void setProviderAccreditation(
    // END, CR00177241
    final curam.provider.impl.ProviderAccreditation providerAccreditation,
    final ProviderAccreditationPeriodDetails details) throws AppException,
      InformationalException {

    final curam.provider.impl.Provider provider = providerDAO.get(
      details.providerConcernRoleID);

    providerAccreditation.setType(details.type);
    providerAccreditation.setDescription(details.description);
    providerAccreditation.setProvider(provider);

  }

  // ___________________________________________________________________________
  /**
   * The method to set the details of provider accreditation
   *
   * @param providerAccreditation -
   * ProviderAccreditation
   * @param dtls -
   * ProviderAccreditationDtls
   */
  // BEGIN, CR00177241, PM
  protected void setProviderAccreditation(
    // END, CR00177241
    final curam.provider.impl.ProviderAccreditation providerAccreditation,
    final ProviderAccreditationDtls dtls) throws AppException,
      InformationalException {

    final curam.provider.impl.Provider provider = providerDAO.get(
      dtls.providerConcernRoleID);

    providerAccreditation.setType(dtls.type);
    providerAccreditation.setDescription(dtls.description);
    providerAccreditation.setProvider(provider);

  }

  // ___________________________________________________________________________
  /**
   * The method to get the details of accreditation period
   *
   * @param accreditationPeriod -
   * AccreditationPeriod
   * @return AccreditationPeriodDtls
   */
  // BEGIN, CR00177241, PM
  protected AccreditationPeriodDtls getAccreditationPeriodDetails(
    // END, CR00177241
    AccreditationPeriod accreditationPeriod) {

    AccreditationPeriodDtls accreditationPeriodDtls = new AccreditationPeriodDtls();

    accreditationPeriodDtls.accreditationPeriodID = accreditationPeriod.getID();
    accreditationPeriodDtls.providerAccreditationID = accreditationPeriod.getProviderAccreditation().getID();
    accreditationPeriodDtls.startDate = accreditationPeriod.getDateRange().start();
    accreditationPeriodDtls.endDate = accreditationPeriod.getDateRange().end();
    accreditationPeriodDtls.versionNo = accreditationPeriod.getVersionNo();

    return accreditationPeriodDtls;
  }

  // ___________________________________________________________________________
  /**
   * The method to set the details of accreditation period
   *
   * @param accreditationPeriod -
   * AccreditationPeriod
   * @param details -
   * AccreditationPeriodDtls
   */
  // BEGIN, CR00177241, PM
  protected void setAccreditationPeriod(
    // END, CR00177241
    final AccreditationPeriod accreditationPeriod,
    final AccreditationPeriodDtls details) {

    final DateRange dateRange = new DateRange(details.startDate,
      details.endDate);
    final curam.provider.impl.ProviderAccreditation providerAccreditation = providerAccreditationDAO.get(
      details.providerAccreditationID);

    accreditationPeriod.setProviderAccreditation(providerAccreditation);
    accreditationPeriod.setDateRange(dateRange);

  }

  // ___________________________________________________________________________
  /**
   * The method to get the details of provider accreditation
   *
   * @param accreditation -
   * ProviderAccreditation
   * @return ProviderAccreditationDtls
   */
  // BEGIN, CR00177241, PM
  protected ProviderAccreditationDtls getAccreditationDetails(
    // END, CR00177241
    final curam.provider.impl.ProviderAccreditation accreditation) {

    ProviderAccreditationDtls accreditationDtls = new ProviderAccreditationDtls();

    accreditationDtls.providerAccreditationID = accreditation.getID();
    accreditationDtls.providerConcernRoleID = accreditation.getProvider().getID();
    accreditationDtls.type = accreditation.getType();
    accreditationDtls.versionNo = accreditation.getVersionNo();
    accreditationDtls.description = accreditation.getDescription();
    accreditationDtls.recordStatus = accreditation.getLifecycleState().toString();

    return accreditationDtls;
  }

  // ___________________________________________________________________________
  /**
   * The method to sort the list of provider accreditation
   *
   * @param unsortedList -
   * Set<curam.provider.ProviderAccreditation>
   * @return List<curam.provider.ProviderAccreditation>
   */
  // BEGIN, CR00177241, PM
  protected List<curam.provider.impl.ProviderAccreditation> sortProviderAccreditations(
    // END, CR00177241
    final Set<curam.provider.impl.ProviderAccreditation> unsortedList) {

    final List<curam.provider.impl.ProviderAccreditation> sortedList = new ArrayList<curam.provider.impl.ProviderAccreditation>(
      unsortedList);

    Collections.sort(sortedList,
      new Comparator<curam.provider.impl.ProviderAccreditation>() {
      public int compare(
        final curam.provider.impl.ProviderAccreditation lhs,
        curam.provider.impl.ProviderAccreditation rhs) {
        return lhs.getType().compareTo(rhs.getType());
      }
    });
    return sortedList;
  }

  // ___________________________________________________________________________
  /**
   * The method to sort the list of accreditation periods
   *
   * @param unsortedList -
   * Set<curam.provider.AccreditationPeriod>
   * @return List<curam.provider.AccreditationPeriod>
   */
  // BEGIN, CR00177241, PM
  protected List<curam.provider.impl.AccreditationPeriod> sortAccreditationPeriods(
    // END, CR00177241
    final Set<curam.provider.impl.AccreditationPeriod> unsortedList) {

    final List<curam.provider.impl.AccreditationPeriod> sortedList = new ArrayList<curam.provider.impl.AccreditationPeriod>(
      unsortedList);

    Collections.sort(sortedList,
      new Comparator<curam.provider.impl.AccreditationPeriod>() {
      public int compare(final curam.provider.impl.AccreditationPeriod lhs,
        curam.provider.impl.AccreditationPeriod rhs) {
        return rhs.getDateRange().start().compareTo(lhs.getDateRange().start());
      }
    });
    return sortedList;
  }

  // __________________________________________________________________________
  /**
   * Lists of Informational message if approval criteria is set as accreditation
   * for provider offering.
   *
   * @param keyVersionDetails
   * ID and version details.
   *
   * @return InformationalMsgDtlsList list of Informational messages.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMsgDtlsList cancelProviderAccreditationList(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {

    curam.provider.impl.Provider provider = providerDAO.get(
      keyVersionDetails.id);
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();
    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    // get provider offering
    final Set<ProviderOffering> providerOfferingList = providerOfferingDAO.searchBy(
      provider);
    boolean flag = false;

    // iterate through individual provider offering
    for (ProviderOffering providerOffering : providerOfferingList) {
      curam.serviceoffering.impl.ServiceOffering serviceOffering = providerOffering.getServiceOffering();

      // get approval criteria for service offering
      Set<ServiceOfferingApprovalCriterion> approvalCriteriaList = soApprovalCriteriaDAO.searchBy(
        serviceOffering);

      for (ServiceOfferingApprovalCriterion approvalCriteria : approvalCriteriaList) {

        // set flag if approval criteria is ACCREDITATION and is valid
        // for current date
        if (approvalCriteria.getCriterionType().getCode().equals(
          ApprovalCriterion.ACCREDITATION)
            && approvalCriteria.getDateRange().contains(Date.getCurrentDate())) {
          flag = true;
        }
      }
    }

    // give informational message to user if flag = true
    if (flag) {

      LocalisableString localString = new LocalisableString(
        PROVIDERACCREDITATION.INF_PROVIDERACCREDITATION_XRV_EXIST_FOR_PROVIDEROFFERING);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        localString, CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // iterate through the result from informational manager
    String[] finalResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < finalResults.length; i++) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = finalResults[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
    return informationalMsgDtlsList;
  }
}
