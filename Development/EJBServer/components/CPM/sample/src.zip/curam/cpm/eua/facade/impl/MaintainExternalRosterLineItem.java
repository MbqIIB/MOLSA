/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import com.google.inject.Inject;
import curam.attendance.impl.AbsencePeriod;
import curam.attendance.impl.AbsencePeriodCorrectionDAO;
import curam.attendance.impl.AbsencePeriodCorrectionHistory;
import curam.attendance.impl.AbsencePeriodCorrectionHistoryDAO;
import curam.attendance.impl.AbsencePeriodDAO;
import curam.attendance.impl.AbsencePeriodHistoryDAO;
import curam.attendance.impl.AttendanceConfigurationHelper;
import curam.attendance.impl.DailyAttendance;
import curam.attendance.impl.DailyAttendanceCorrectionHistory;
import curam.attendance.impl.DailyAttendanceCorrectionHistoryDAO;
import curam.attendance.impl.DailyAttendanceDAO;
import curam.attendance.impl.DailyAttendanceHistoryDAO;
import curam.attendance.impl.PRLICorrection;
import curam.attendance.impl.PRLICorrectionDAO;
import curam.attendance.impl.PRLICorrectionHistoryDAO;
import curam.attendance.impl.PRLIHistory;
import curam.attendance.impl.PRLIHistoryDAO;
import curam.attendance.impl.PRLISALILink;
import curam.attendance.impl.PRLISALILinkDAO;
import curam.attendance.impl.PRLITransaction;
import curam.attendance.impl.PRLITransactionDAO;
import curam.attendance.impl.ProviderRosterLineItem;
import curam.attendance.impl.ProviderRosterLineItemDAO;
import curam.attendance.impl.Roster;
import curam.attendance.impl.RosterDAO;
import curam.attendance.impl.RosterLineItemHistory;
import curam.attendance.impl.SOAttendanceConfiguration;
import curam.attendance.impl.SOAttendanceConfigurationDAO;
import curam.codetable.impl.ATTENDANCEABSENCEREASONEntry;
import curam.codetable.impl.ATTENDANCEEntry;
import curam.codetable.impl.ATTENDANCETRACKINGHOURSEntry;
import curam.codetable.impl.ATTENDANCETRACKINGMINUTESEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.fact.AddressFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.Address;
import curam.core.sl.entity.struct.AbsencePeriodHistoryDtlsList;
import curam.core.sl.entity.struct.DailyAttendanceHistoryDtls;
import curam.core.sl.entity.struct.DailyAttendanceHistoryDtlsList;
import curam.core.sl.entity.struct.RosterKey;
import curam.core.sl.entity.struct.RosterLineItemDtls;
import curam.core.sl.entity.struct.RosterLineItemHistoryDtls;
import curam.core.struct.AddressDtls;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.OtherAddressData;
import curam.cpm.facade.struct.AbsenceDetails;
import curam.cpm.facade.struct.AbsenceDetailsList;
import curam.cpm.facade.struct.AbsencePeriodHistoryDetails;
import curam.cpm.facade.struct.AbsencePeriodHistoryDetailsList;
import curam.cpm.facade.struct.CreateAbsenceDetails;
import curam.cpm.facade.struct.DailyAttendanceDetails;
import curam.cpm.facade.struct.DailyAttendanceDetailsList;
import curam.cpm.facade.struct.DailyAttendanceHistory;
import curam.cpm.facade.struct.DailyAttendanceHistoryDetails;
import curam.cpm.facade.struct.DailyAttendanceHistoryDetailsList;
import curam.cpm.facade.struct.DailyAttendanceHistoryList;
import curam.cpm.facade.struct.DailyAttendanceReportingWidgetDetails;
import curam.cpm.facade.struct.DailyAttendanceWidgetDetails;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.PRLICancellationDetails;
import curam.cpm.facade.struct.PRLIHistoryDetails;
import curam.cpm.facade.struct.PRLIHistoryDetailsList;
import curam.cpm.facade.struct.PRLIHistoryWithStatusDetails;
import curam.cpm.facade.struct.PRLIHistoryWithStatusDetailsList;
import curam.cpm.facade.struct.PRLISummaryDetails;
import curam.cpm.facade.struct.PRLITransactionDetails;
import curam.cpm.facade.struct.PRLITransactionDetailsList;
import curam.cpm.facade.struct.ProviderRosterLineItemDetails;
import curam.cpm.facade.struct.ReportingDailyAttendanceDetails;
import curam.cpm.facade.struct.RosterServiceReportingMethod;
import curam.cpm.facade.struct.ServiceAuthorizationLineItemDetails;
import curam.cpm.facade.struct.UnitsExceededDetails;
import curam.cpm.facade.struct.UpdateRLIDetails;
import curam.cpm.facade.struct.ViewDailyAttendanceDetails;
import curam.cpm.facade.struct.ViewDailyAttendanceReportingDetails;
import curam.cpm.facade.struct.ViewReportingDailyAttendanceDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.PRLIHistoryDtls;
import curam.cpm.sl.entity.struct.PRLIHistoryKey;
import curam.cpm.sl.entity.struct.ProviderRosterLineItemDtls;
import curam.cpm.sl.entity.struct.ProviderRosterLineItemKey;
import curam.cpm.util.impl.AttendanceWidgetHelper;
import curam.cpm.util.impl.WidgetHelper;
import curam.message.ENTDAILYATTENDANCE;
import curam.message.ROSTER;
import curam.message.impl.ENTDAILYATTENDANCEExceptionCreator;
import curam.message.impl.ROSTERExceptionCreator;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.PRLICancelationReasonEntry;
import curam.provider.impl.PRLICorrectionStatusEntry;
import curam.provider.impl.PRLIStatusEntry;
import curam.serviceauthorization.impl.ServiceAuthorization;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItem;
import curam.servicedelivery.impl.ServiceDelivery;
import curam.servicedelivery.impl.ServiceDeliveryDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.DateRange;


/**
 * This process class provides the functionality for the roster line item facade
 * layer.
 */
public abstract class MaintainExternalRosterLineItem extends curam.cpm.eua.facade.base.MaintainExternalRosterLineItem {

  /**
   * DailyAttendance DAO object.
   */
  @Inject
  protected DailyAttendanceDAO dailyAttendanceDAO;

  /**
   * AbsencePeriod reference.
   */
  @Inject
  protected AbsencePeriod absencePeriodImpl;

  /**
   * AbsencePeriod DAO reference.
   */
  @Inject
  protected AbsencePeriodDAO absencePeriodDAO;

  /**
   * Provider Roster Line Item DAO.
   */
  @Inject
  protected ProviderRosterLineItemDAO providerRosterLineItemDAO;

  /**
   * Provider Roster Line Item Transaction DAO.
   */
  @Inject
  protected PRLITransactionDAO prliTransactionDAO;

  /**
   * Provider Roster Line Item History DAO.
   */
  @Inject
  protected PRLIHistoryDAO prliHistoryDAO;

  /**
   * A reference to PRLISALILinkDAO.
   */
  @Inject
  protected PRLISALILinkDAO prliSALILinkDAO;

  /**
   * SOAttendanceConfiguration DAO object.
   */
  @Inject
  protected SOAttendanceConfigurationDAO sOAttendanceConfigurationDAO;

  /**
   * Roster DAO object.
   */
  @Inject
  protected RosterDAO rosterDAO;

  /**
   * AbsencePeriodHistory DAO reference.
   */
  @Inject
  protected AbsencePeriodHistoryDAO absencePeriodHistoryDAO;

  /**
   * DailyAttendanceHistory DAO reference.
   */
  @Inject
  protected DailyAttendanceHistoryDAO dailyAttendanceHistoryDAO;

  // BEGIN, CR00176474, AS
  // BEGIN, CR00178377, AS
  /**
   * Reference to Attendance Configuration Helper.
   */
  @Inject
  protected AttendanceConfigurationHelper attendanceConfigurationHelper;
  // END, CR00178377
  // END, CR00176474
  
  // BEGIN, CR00198474, ASN
  /**
   * Reference to DailyAttendance.
   */
  @Inject
  protected DailyAttendance dailyAttendance;

  /**
   * Reference to ConcernRole DAO.
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  // END, CR00198474

  // BEGIN, CR00233623, ASN
  /**
   * Reference to PRLI Correction DAO.
   */
  @Inject
  protected PRLICorrectionDAO prliCorrectionDAO;

  @Inject
  protected PRLICorrectionHistoryDAO prliCorrectionHistoryDAO;

  /**
   * Reference to Absence Period Correction DAO.
   */
  @Inject
  protected AbsencePeriodCorrectionDAO absencePeriodCorrectionDAO;

  /**
   * Reference to Absence Period Correction History DAO.
   */
  @Inject
  protected AbsencePeriodCorrectionHistoryDAO absencePeriodCorrectionHistoryDAO;

  /**
   * Reference to Daily Attendance Correction History DAO.
   */
  @Inject
  protected DailyAttendanceCorrectionHistoryDAO dailyAttendanceCorrectionHistoryDAO;

  // END, CR00233623

  @Inject
  protected ServiceDeliveryDAO serviceDeliveryDAO;
  
  /**
   * Default Constructor.
   */
  public MaintainExternalRosterLineItem() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Adds a absence reason for a specified provider roster line item.
   *
   * @param createAbsenceDetails
   * Details of the Absence details record.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void addAbsence(CreateAbsenceDetails createAbsenceDetails)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      createAbsenceDetails.providerRosterLineItemID);

    AbsencePeriod absencePeriod = absencePeriodImpl.newInstance();

    // Populate the absence details.
    absencePeriod.setAbsenceDate(createAbsenceDetails.details.dtls.absenceDate);
    absencePeriod.setAbsenceReason(
      ATTENDANCEABSENCEREASONEntry.get(
        createAbsenceDetails.details.dtls.absenceReason));
    absencePeriod.setUnitsUnattended(
      createAbsenceDetails.details.dtls.unitsUnattended);
    absencePeriod.setRosterLineItem(
      providerRosterLineItem.getRosterLineItemID());
    absencePeriod.setStatus(RECORDSTATUSEntry.NORMAL);
    if (providerRosterLineItem.getClient() != null) {
      absencePeriod.setClient(providerRosterLineItem.getClient().getID());
    }
    absencePeriod.insert();
  }

  // BEGIN, CR00233623, ASN
  /**
   * Maintains all the daily attendance records and the roster line item record
   * for a specified provider roster line item.
   *
   * @param dailyAttendanceWidgetDetails
   * Contains the xml data received from the Daily Attendance widget.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED}
   * - If other details are specified, the Attendance must be entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_PRESENT_OR_PARTIALLY_PRESENT}
   * - If attendance is present or partially present, units attended
   * must be entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_ABSENT}
   * - If attendance is absent, units attended must not be entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT}
   * - If attendance is present , units not attended must not be
   * entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ABSENT_OR_PARTIALLY_PRESENT}
   * - If attendance is partially present or absent and units not
   * attended is not greater than zero.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED}
   * - If user tries to save all blank daily attendance records.
   * @throws InformationalException
   * {@link ENTDAILYATTENDANCE#ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT}
   * - If attendance is present and absence reason is entered.
   * @throws InformationalException
   * {@link ENTDAILYATTENDANCE#ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_ABSENT_OR_PARTIALLY_PRESENT}
   * - If attendance is partially present or absent but absence reason
   * is not entered.
   */
  // END, CR00233623
  public void addDailyAttendance(
    DailyAttendanceWidgetDetails dailyAttendanceWidgetDetails)
    throws AppException, InformationalException {

    // The xml containing data of daily attendance details list which is
    // received from the Daily Attendance widget is parsed and the xml data
    // is populated to a list of daily attendance details.
    DailyAttendanceDetailsList dailyAttendanceDetailsList = WidgetHelper.convertXmlToAttendanceDetailsList(
      dailyAttendanceWidgetDetails.dailyAttendanceDetails);

    short actualUnits = 0;

    validateDailyAttendance(dailyAttendanceDetailsList);
    
    // BEGIN, CR00198474, ASN
    // BEGIN, CR00199226, ASN
    final ProviderRosterLineItem providerRosterLineItemImpl = providerRosterLineItemDAO.get(
      dailyAttendanceWidgetDetails.providerRosterLineItemID);
    // END, CR00199226
    ArrayList<curam.util.type.Date> serviceDateList = new ArrayList<curam.util.type.Date>();
    
    DailyAttendanceDetailsList dailyAttendanceDetailsViewList = generateDailyAttendance(
      providerRosterLineItemImpl);
    // BEGIN, CR00199226, ASN
    final Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItemImpl.getRosterLineItemID());

    // END, CR00199226
    if (!dailyAttendanceList.isEmpty()) {

      serviceDateList = serviceDatesForActiveDailyAttendance(
        providerRosterLineItemImpl);
    }
    // BEGIN, CR00199226, ASN
    for (final DailyAttendanceDetails viewDailyAttendanceDetails : dailyAttendanceDetailsViewList.details.items()) {

      int count = 0;
     
      for (final DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {
        // END, CR00199226
        dailyAttendanceDetails.dtls.rosterLineItemID = providerRosterLineItemImpl.getRosterLineItemID();
        
        // BEGIN, CR00292566, ASN
        if (null != providerRosterLineItemImpl.getClient()) {
          dailyAttendanceDetails.dtls.concernRoleID = providerRosterLineItemImpl.getClient().getID();
        }
        // END, CR00292566
        
        if (!serviceDateList.contains(dailyAttendanceDetails.dtls.serviceDate)) {
          
          if (0 == dailyAttendanceDetails.dtls.dailyAttendanceID
            && viewDailyAttendanceDetails.dtls.serviceDate.equals(
              dailyAttendanceDetails.dtls.serviceDate)
              && (!StringUtil.isNullOrEmpty(
                dailyAttendanceDetails.dtls.attendance))) {

            dailyAttendanceDetails.dtls.expectedUnits = viewDailyAttendanceDetails.dtls.expectedUnits;

            DailyAttendance dailyAttendanceInstance = dailyAttendance.newInstance();

            dailyAttendanceInstance.setRosterLineItem(
              dailyAttendanceDetails.dtls.rosterLineItemID);
            ServiceAuthorization serviceAuthorization = providerRosterLineItemImpl.getServiceAuthorization();

            if (serviceAuthorization != null) {
              final ServiceDelivery serviceDelivery = serviceDeliveryDAO.readByServiceAuthorization(
                serviceAuthorization);

              dailyAttendanceInstance.setRelatedItem(serviceDelivery);
            }
            
            if (0 != dailyAttendanceDetails.dtls.concernRoleID) {
              curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
                dailyAttendanceDetails.dtls.concernRoleID);

              dailyAttendanceInstance.setClient(concernRole);
            }
            // BEGIN, CR00199226, ASN
            dailyAttendanceInstance.setExpectedUnits(
              viewDailyAttendanceDetails.dtls.expectedUnits);
            
            setDailyAttendanceDetails(dailyAttendanceInstance,
              dailyAttendanceDetails, false);
            // END, CR00199226
            dailyAttendanceInstance.insert();

          }
        } else {
          if (0 != dailyAttendanceDetails.dtls.dailyAttendanceID) {
            
            DailyAttendance maintainDailyAttendance = dailyAttendanceDAO.get(
              dailyAttendanceDetails.dtls.dailyAttendanceID);

            if (RECORDSTATUSEntry.NORMAL.getCode().equals(
              maintainDailyAttendance.getDtls().recordStatus)) {
              
              if (StringUtil.isNullOrEmpty(
                dailyAttendanceDetails.dtls.attendance)
                  && StringUtil.isNullOrEmpty(
                    dailyAttendanceDetails.dtls.absenceReason)
                    && StringUtil.isNullOrEmpty(
                      dailyAttendanceDetails.unitsAttendedString)
                      && StringUtil.isNullOrEmpty(
                        dailyAttendanceDetails.unitsUnAttendedString)) {
                
                // BEGIN, CR00199226, ASN
                maintainDailyAttendance.setAttendance(
                  ATTENDANCEEntry.NOT_SPECIFIED);
                maintainDailyAttendance.setAbsenceReason(
                  ATTENDANCEABSENCEREASONEntry.NOT_SPECIFIED);
                maintainDailyAttendance.setUnitsAttended((short) 0);
                maintainDailyAttendance.setUnitsUnattended((short) 0);
                // END, CR00199226
                maintainDailyAttendance.cancel();
              } else {
                // BEGIN, CR00199226, ASN
                if (count == 1) {
                  break;
                }
                // END, CR00199226
                if (!maintainDailyAttendance.getAttendance().getCode().equals(
                  dailyAttendanceDetails.dtls.attendance)
                    || !maintainDailyAttendance.getAbsenceReason().getCode().equals(
                      dailyAttendanceDetails.dtls.absenceReason)
                      || maintainDailyAttendance.getUnitsAttended()
                        != dailyAttendanceDetails.dtls.unitsAttended
                        || maintainDailyAttendance.getUnitsUnattended()
                          != dailyAttendanceDetails.dtls.unitsUnattended) {

                  maintainDailyAttendance.setAttendance(
                    ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
                  maintainDailyAttendance.setAbsenceReason(
                    ATTENDANCEABSENCEREASONEntry.get(
                      dailyAttendanceDetails.dtls.absenceReason));
                  maintainDailyAttendance.setUnitsAttended(
                    dailyAttendanceDetails.dtls.unitsAttended);
                  maintainDailyAttendance.setUnitsUnattended(
                    dailyAttendanceDetails.dtls.unitsUnattended);
                  maintainDailyAttendance.modify();
                  // BEGIN, CR00199226, ASN
                  count++;
                  // END, CR00199226

                }

              }
            }
          }
        }
      }
    }
    
    Set<DailyAttendance> unitsAttendedList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItemImpl.getRosterLineItemID());

    // BEGIN, CR00199226, ASN
    for (final DailyAttendance actualUnitsValue : unitsAttendedList) {
      // END, CR00199226
      if (RECORDSTATUSEntry.NORMAL.getCode().equals(
        actualUnitsValue.getDtls().recordStatus)) {
        actualUnits += actualUnitsValue.getUnitsAttended();
      }
    }
    // END, CR00198474


    // Modify the actual units attribute in roster line item record.

    providerRosterLineItemImpl.setRLIVersionNo(
      dailyAttendanceWidgetDetails.rliVersionNo);

    // BEGIN, CR00233623, ASN
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        providerRosterLineItemImpl.getRoster())) {
      providerRosterLineItemImpl.setUnitsDelivered(actualUnits);
    }
    // END, CR00233623
    providerRosterLineItemImpl.setRosterLineItemID(
      providerRosterLineItemImpl.getRosterLineItemID());
    providerRosterLineItemImpl.modifyForDailyAttendance();
  }

  /**
   * Lists all the absence details for a specified provider roster line item.
   *
   * @param providerRosterLineItemKey
   * Contains provider roster line item id.
   * @return List of all the absence details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public AbsenceDetailsList listAbsences(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {

    AbsenceDetailsList absenceDetailsList = new AbsenceDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    Set<curam.attendance.impl.AbsencePeriod> absencePeriodList = absencePeriodDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());

    // Populate the absencePeriod details to the list.
    for (curam.attendance.impl.AbsencePeriod absencePeriod : sortAbsenceByServiceDate(
      absencePeriodList)) {

      if (RECORDSTATUSEntry.NORMAL.equals(absencePeriod.getStatus())) {
        AbsenceDetails absenceDetails = new AbsenceDetails();

        absenceDetails.dtls.absenceReason = absencePeriod.getAbsenceReason().getCode();
        absenceDetails.dtls.unitsUnattended = absencePeriod.getUnitsUnattended();
        absenceDetails.dtls.absenceDate = absencePeriod.getAbsenceDate();
        absenceDetails.dtls.absencePeriodID = absencePeriod.getDtls().absencePeriodID;
        // BEGIN, CR00233623, ASN
        absenceDetails.dtls.rosterLineItemID = absencePeriod.getDtls().rosterLineItemID;
        // END, CR00233623
        absenceDetails.dtls.versionNo = absencePeriod.getDtls().versionNo;
        absenceDetailsList.details.addRef(absenceDetails);
      }
    }

    absenceDetailsList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    return absenceDetailsList;
  }

  // BEGIN, CR00233623, ASN
  /**
   * Lists the provider roster line item status history.
   *
   * @param key
   * Contains provider roster line item ID.
   *
   * @return List of all provider roster line item history.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link MaintainExternalRosterLineItem#listHistoryForPRLI(ProviderRosterLineItemKey)}
   * . As part of the PRLI History merge changes, a new indicator
   * need to be added to indicate a correction is denied as a part
   * of list provider roster line item history page. See release
   * note: CR00233623.
   */
  @Deprecated
  public PRLIHistoryDetailsList listHistoryForRosterLineItem(
    ProviderRosterLineItemKey key) throws AppException,
      InformationalException {

    PRLIHistoryDetailsList prliHistoryDetailsList = new PRLIHistoryDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);
    List<PRLIHistory> historyDetailsList = prliHistoryDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);

    // Populating the provider roster line item history details
    for (PRLIHistory prliHistory : historyDetailsList) {

      RosterLineItemHistory rosterLineItemHistory = prliHistory.getRosterLineItemHistory();

      prliHistoryDetailsList.prliDetails.addRef(
        getPRLIAndRLIHistoryDetails(prliHistory, rosterLineItemHistory));
    }
    prliHistoryDetailsList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    return prliHistoryDetailsList;
  }

  // END, CR00233623
  /**
   * Lists the provider roster line item transactions.
   *
   * @param key
   * Contains provider roster line item ID.
   * @return List of all provider roster line item transactions.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLITransactionDetailsList listTransactionsForRosterLineItem(
    ProviderRosterLineItemKey key) throws AppException,
      InformationalException {

    PRLITransactionDetailsList prliTransactionDetailsList = new PRLITransactionDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);

    List<PRLITransaction> transactionDetailsList = prliTransactionDAO.listTransactionsForRosterLineItem(
      providerRosterLineItem);

    // Populating the provider roster line item transactions details
    for (PRLITransaction prliTransaction : transactionDetailsList) {

      PRLITransactionDetails prliTransactionDetails = new PRLITransactionDetails();

      prliTransactionDetails.dtls.creationDateTime = prliTransaction.getCreationDateTime();

      prliTransactionDetails.dtls.transactionType = prliTransaction.getTransactionType().getCode();

      prliTransactionDetails.dtls.amount = prliTransaction.getAmount();

      prliTransactionDetailsList.details.addRef(prliTransactionDetails);

    }
    prliTransactionDetailsList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);
    return prliTransactionDetailsList;
  }

  /**
   * Submits the provider roster line item for processing.
   *
   * @param key
   * ID and version details of the provider roster line item to be
   * submitted.
   * @return The Informational messages added during the processing of the
   * provider roster line item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationalMsgDtlsList submitRosterLineItem(KeyVersionDetails key)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.id);

    providerRosterLineItem.submit(key.version);

    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();
    String[] finalResults = TransactionInfo.getInformationalManager().obtainInformationalAsString();

    // iterate through the result from informational manager
    for (int i = 0; i < finalResults.length; i++) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = finalResults[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }

    return informationalMsgDtlsList;
  }

  // BEGIN, CR00128756, GYH
  /**
   * This method is called in the flow to modify roster line item before
   * actually updating the entered data in the database. Following are the
   * possibilities :
   *
   * 1. If the roster line item is generated by system, client information
   * screen is not shown. Data entered by the user are validated and update
   * method is called.
   *
   * 2. If the roster line item is not generated by the user and if change in
   * service from or service to date has resulted in deletion of some rows in
   * the add daily attendance roster, a confirmation for the same is asked from
   * the user. Once the user confirms, client information page is shown. The
   * update method is called to update the new values.
   *
   * 3. If the roster line item is not generated by the user and if change in
   * service from or service to date has not resulted in any deletion of rows in
   * the add daily attendance roster, client information page is directly shown
   * to the user without the confirmation page. The update method is called to
   * update the new values.
   *
   *
   * @param details
   * Contains the details required to modify the roster line item.
   *
   * @return UpdateRLIDetails to hold the indicator whether update would result
   * in deletion of rows from add daily attendance roster.
   *
   * @throws InformationalException
   * {@link Roster#ERR_ROSTER_LINE_ITEM_XFV_CANNOT_BE_MODIFIED} If
   * roster line item is not in open status, it cannot be updated.
   * {@link Roster#ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_MUST_BE_GT_ZERO}
   * If total units are modified, must be greater than zero.
   * {@link Roster#ERR_ROSTERLINE_ITEM_XRV_SERVICE_FROM_DATE_MUST_BE_ON_OR_AFTER_FROM_DATE_OF_ROSTER}
   * Service from date must be on or after from date of roster.
   * {@link Roster#ERR_ROSTERLINE_ITEM_XRV_SERVICE_TO_DATE_MUST_BE_EARLIER_THAN_OR_EQUAL_TO_ROSTER_TO_DATE}
   * Service to date must be on or after to date of roster.
   * {@link Roster#ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_IS_INVALID}
   * Units delivered must be whole numbers.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00128756

  
  public UpdateRLIDetails preUpdateRosterLineItem(
    ProviderRosterLineItemDetails details) throws AppException,
      InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      details.providerRosterLineItemDtls.providerRosterLineItemID);

    RosterLineItemDtls originalRosterLineItemDtls = providerRosterLineItem.getOriginalDtls();

    DateRange oldDateRange = new DateRange(
      originalRosterLineItemDtls.serviceFrom,
      originalRosterLineItemDtls.serviceTo);
    DateRange newDateRange = new DateRange(
      details.rosterLineItemDtls.serviceFrom,
      details.rosterLineItemDtls.serviceTo);

    Roster roster = rosterDAO.get(originalRosterLineItemDtls.rosterID);

    // If roster line item has exception task process indicator set, it
    // cannot be updated.
    if (providerRosterLineItem.getExceptionProcInd()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_CANNOT_MODIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }

    // If roster line item has service from date after service to date.
    if (details.rosterLineItemDtls.serviceFrom.after(
      details.rosterLineItemDtls.serviceTo)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_FROM_DATE_LATER_THAN_TO_DATE(
          details.rosterLineItemDtls.serviceFrom,
          details.rosterLineItemDtls.serviceTo),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // If roster line item is not in open status, it cannot be updated.
    if (!providerRosterLineItem.getLifecycleState().getCode().equals(
      PRLIStatusEntry.OPEN.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_CANNOT_BE_MODIFIED(
          providerRosterLineItem.getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // BEGIN, CR00128756, GYH
    // If actual units are changed, it must be a whole number.
    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(roster)) {
      // END, CR00178377
      if (details.unitsDeliveredString.trim().length() > 0) {
        try {
          details.rosterLineItemDtls.totalUnitsDelivered = Short.parseShort(
            details.unitsDeliveredString);
        } catch (NumberFormatException ne) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_IS_INVALID(
              details.unitsDeliveredString),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              1);
          ValidationHelper.failIfErrorsExist();
        }
      }
      // END, CR00128756

      // If actual units are changed, it must be greater than zero.
      if (!providerRosterLineItem.getUnitsDelivered().equals(
        details.rosterLineItemDtls.totalUnitsDelivered)
          && details.rosterLineItemDtls.totalUnitsDelivered <= 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_MUST_BE_GT_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
      }
    }
    // END, CR00176474

    if (!details.providerRosterLineItemDtls.autoGeneratedInd) {

      if (details.rosterLineItemDtls.serviceFrom.isZero()
        || (roster.getDateRange().startsAfter(
          details.rosterLineItemDtls.serviceFrom))) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTERLINE_ITEM_XRV_SERVICE_FROM_DATE_MUST_BE_ON_OR_AFTER_FROM_DATE_OF_ROSTER(
            details.rosterLineItemDtls.serviceFrom,
            roster.getDateRange().start()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      if (details.rosterLineItemDtls.serviceTo.isZero()
        || (roster.getDateRange().endsBefore(
          details.rosterLineItemDtls.serviceTo))) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTERLINE_ITEM_XRV_SERVICE_TO_DATE_MUST_BE_EARLIER_THAN_OR_EQUAL_TO_ROSTER_TO_DATE(
            details.rosterLineItemDtls.serviceTo, roster.getDateRange().end()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

    ValidationHelper.failIfErrorsExist();

    UpdateRLIDetails updateRLIDetails = new UpdateRLIDetails();

    if (details.providerRosterLineItemDtls.autoGeneratedInd) {
      updateRosterLineItem(details);
    }

    // If delete rows indicator in the input struct is set to true,
    // that means the check is already done.

    if (!details.deleteRowsInd
      && !details.providerRosterLineItemDtls.autoGeneratedInd) {
      if (newDateRange.endsBefore(oldDateRange.end())
        || newDateRange.startsAfter(oldDateRange.start())) {
        // Only if the daily attendance is configured, delete rows page
        // should be shown.
        if (isDailyAttendanceConfigured(providerRosterLineItem)) {
          updateRLIDetails.deleteRowsInd = true;
        }
      } else {
        updateRLIDetails.deleteRowsInd = false;
        // BEGIN, CR00248746, ASN
        updateRosterLineItem(details);
        // END, CR00248746
      }
    }
    return updateRLIDetails;
  }

  // BEGIN, CR00128756, GYH
  /**
   * Updates the Roster Line Item details with the new values provided by the
   * user.This may or may not contain client information.
   *
   * @param details
   * Contains the details required to modify the roster line item.
   * @throws InformationalException
   * {@link Roster#ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_IS_INVALID}
   * Units delivered must be whole numbers.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00128756

  public void updateRosterLineItem(ProviderRosterLineItemDetails details)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      details.providerRosterLineItemDtls.providerRosterLineItemID);

    // BEGIN, CR00128756, GYH
    // If actual units are changed, it must be a whole number.
    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        providerRosterLineItem.getRoster())) {
      // END, CR00178377
      if (details.unitsDeliveredString.trim().length() > 0) {
        try {
          details.rosterLineItemDtls.totalUnitsDelivered = Short.parseShort(
            details.unitsDeliveredString);
        } catch (NumberFormatException ne) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_IS_INVALID(
              details.unitsDeliveredString),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              2);
          ValidationHelper.failIfErrorsExist();
        }
      }
      // END, CR00128756

      providerRosterLineItem.setUnitsDelivered(
        details.rosterLineItemDtls.totalUnitsDelivered);
    }
    // END, CR00176474
    providerRosterLineItem.setRLIVersionNo(details.rosterLineItemDtls.versionNo);
    providerRosterLineItem.setVoucherNumber(
      details.providerRosterLineItemDtls.voucherNumber);
    providerRosterLineItem.setVersionNo(
      details.providerRosterLineItemDtls.versionNo);

    // Client information, service from and to dates, service authorization
    // reference number can be changed only if
    // they are added by provider (not generated by system).
    if (!details.providerRosterLineItemDtls.autoGeneratedInd) {
      providerRosterLineItem.setCaseReferenceNo(
        details.providerRosterLineItemDtls.caseReferenceNo);
      providerRosterLineItem.setSAReferenceNo(
        details.providerRosterLineItemDtls.saReferenceNo);
      providerRosterLineItem.setServiceDateFrom(
        details.rosterLineItemDtls.serviceFrom);
      providerRosterLineItem.setServiceDateTo(
        details.rosterLineItemDtls.serviceTo);
      providerRosterLineItem.setClientReferenceNo(
        details.providerRosterLineItemDtls.clientReferenceNo);
      providerRosterLineItem.setClientDOB(
        details.providerRosterLineItemDtls.clientDOB);
      providerRosterLineItem.setClientFirstName(
        details.providerRosterLineItemDtls.clientFirstName);
      providerRosterLineItem.setClientLastName(
        details.providerRosterLineItemDtls.clientLastName);

      if (details.providerRosterLineItemDtls.clientReferenceNo.length() == 0) {
        AddressDtls addressDtls = new AddressDtls();

        addressDtls.addressID = details.providerRosterLineItemDtls.addressID;
        addressDtls.addressData = details.addressData;
        providerRosterLineItem.setAddress(addressDtls);
      }
    }

    providerRosterLineItem.modifyRosterLineItem();
  }

  /**
   * Retrieves the Daily Attendance details for a specified provider roster line
   * item key.
   *
   * @param providerRosterLineItemKey
   * Key containing the provider roster line item ID.
   * @return List of Daily Attendance details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewDailyAttendanceDetails viewDailyAttendance(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {
    ViewDailyAttendanceDetails viewDailyAttendanceDetails = new ViewDailyAttendanceDetails();
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    // Populate the details of the roster line item.
    viewDailyAttendanceDetails.fromDate = providerRosterLineItem.getServiceDateFrom();
    viewDailyAttendanceDetails.toDate = providerRosterLineItem.getServiceDateTo();
    if (providerRosterLineItem.getClient() != null) {
      viewDailyAttendanceDetails.clientName = providerRosterLineItem.getClient().getName();
    }

    Set<curam.attendance.impl.DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());

    Locale locale = new Locale(TransactionInfo.getProgramLocale());
    DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG, locale);

    // Populate the list of daily attendance details for a specified roster
    // line
    // item.
    
    DailyAttendanceDetails dailyAttendanceDetails;

    for (curam.attendance.impl.DailyAttendance dailyAttendance : sortDailyAttendanceByServiceDate(
      dailyAttendanceList)) {

      if (RECORDSTATUSEntry.NORMAL.equals(dailyAttendance.getStatus())) {
        // BEGIN, CR00304523, SSK
        dailyAttendanceDetails = new DailyAttendanceDetails();
        dailyAttendanceDetails.dtls.serviceDate = dailyAttendance.getServiceDate();
        // END, CR00304523
        
        // BEGIN, CR00303745, SSK
        dailyAttendanceDetails.serviceDateString = curam.util.resources.Locale.getFormattedDateTime(
          dailyAttendance.getServiceDate().getDateTime(),
          curam.util.resources.Locale.Date_ymd);
        // END, CR00303745
        
        
        dailyAttendanceDetails.dtls.attendance = dailyAttendance.getAttendance().getCode();
        dailyAttendanceDetails.dtls.absenceReason = dailyAttendance.getAbsenceReason().getCode();
        if (dailyAttendance.getExpectedUnits() == 0) {
          dailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceDetails.expectedUnitsString = String.valueOf(
            dailyAttendance.getExpectedUnits());
        }
        if (dailyAttendance.getUnitsAttended() == 0) {
          dailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceDetails.unitsAttendedString = String.valueOf(
            dailyAttendance.getUnitsAttended());
        }
        if (dailyAttendance.getUnitsUnattended() == 0) {
          dailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
            dailyAttendance.getUnitsUnattended());
        }
        dailyAttendanceDetails.dtls.dailyAttendanceID = dailyAttendance.getID();
        dailyAttendanceDetails.dtls.versionNo = dailyAttendance.getVersionNo();
        dailyAttendanceDetails.dtls.rosterLineItemID = dailyAttendance.getRosterLineItem();

        dailyAttendanceDetailsList.details.addRef(dailyAttendanceDetails);
        viewDailyAttendanceDetails.detailsList.details.addRef(
          dailyAttendanceDetails);
      }
    }

    // Setting the indicator for displaying daily Attendance details.
    viewDailyAttendanceDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    // Convert the list of daily attendance details to an xml. This xml is
    // the
    // input to the widget to display the list of daily attendance details.
    viewDailyAttendanceDetails.dailyAttendanceDetails = WidgetHelper.convertDailyAttendanceToXml(
      dailyAttendanceDetailsList);
    viewDailyAttendanceDetails.rliVersionNo = providerRosterLineItem.getRLIVersionNo();

    return viewDailyAttendanceDetails;
  }

  /**
   * Validates if total units are greater than expected units.
   *
   * @param key
   * Contains provider roster line item ID.
   * @return Units exceeded details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public UnitsExceededDetails isTotalUnitsGreaterThanExpectedUnits(
    ProviderRosterLineItemKey key) throws AppException,
      InformationalException {

    UnitsExceededDetails unitsExceededDetails = new UnitsExceededDetails();
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);

    if (providerRosterLineItem.getAutoGeneratedInd()
      && providerRosterLineItem.getUnitsDelivered()
        > providerRosterLineItem.getExpectedUnits()) {
      unitsExceededDetails.unitsExceededInd = true;
    } else {
      unitsExceededDetails.unitsExceededInd = false;
    }
    return unitsExceededDetails;
  }

  /**
   * Reads the roster line item details and also the details of the client
   * associated with the roster line item.
   *
   * @param key
   * Contains the provider roster line item ID.
   * @return The Provider Roster Line Item details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLISummaryDetails viewRosterLineItem(ProviderRosterLineItemKey key)
    throws AppException, InformationalException {

    PRLISummaryDetails summaryDetails = new PRLISummaryDetails();
    ProviderRosterLineItemDetails details = new ProviderRosterLineItemDetails();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);

    details.providerRosterLineItemDtls = getProviderRosterLineItemDetails(
      providerRosterLineItem);
    details.rosterLineItemDtls = getRosterLineItemDetails(
      providerRosterLineItem);

    // Total units/expected units should be shown as blank when it is
    // zero.
    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        providerRosterLineItem.getRoster())) {
      // END, CR00178377
      if (details.rosterLineItemDtls.totalUnitsDelivered == 0) {
        details.unitsDeliveredString = CuramConst.gkEmpty;
      } else {
        details.unitsDeliveredString = String.valueOf(
          details.rosterLineItemDtls.totalUnitsDelivered);
      }

      if (details.rosterLineItemDtls.expectedUnits == 0) {
        details.expectedUnitsString = CuramConst.gkEmpty;
      } else {
        details.expectedUnitsString = String.valueOf(
          details.rosterLineItemDtls.expectedUnits);
      }
    }
    // END, CR00176474

    if (details.providerRosterLineItemDtls.addressID != 0) {
      details.addressData = providerRosterLineItem.getAddressData();
      Address addressObj = AddressFactory.newInstance();

      OtherAddressData formattedAddressData = new OtherAddressData();

      formattedAddressData.addressData = providerRosterLineItem.getAddressData();
      addressObj.getAddressStrings(formattedAddressData);
      summaryDetails.addressData = formattedAddressData.addressData;
    }
    if (details.providerRosterLineItemDtls.status.equals(
      PRLIStatusEntry.PENDINGAPPROVAL.getCode())) {
      summaryDetails.cancelLinkInd = true;
    }
    Set<PRLISALILink> pRLISALILinks = prliSALILinkDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);

    for (PRLISALILink pRLISALILink : pRLISALILinks) {
      summaryDetails.saliDetails.addRef(
        getServiceAuthorizationLineItemDetails(
          pRLISALILink.getServiceAuthorizationLineItem()));
    }

    if (details.providerRosterLineItemDtls.exceptionProcInd) {
      summaryDetails.exceptionTaskCreated = ROSTER.INF_ROSTER_LINE_ITEM_EXCEPTIONTASKCREATED_YES.getMessageText(
        TransactionInfo.getProgramLocale());
    } else {
      summaryDetails.exceptionTaskCreated = ROSTER.INF_ROSTER_LINE_ITEM_EXCEPTIONTASKCREATED_NO.getMessageText(
        TransactionInfo.getProgramLocale());
    }

    summaryDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);
    summaryDetails.details = details;

    if (providerRosterLineItem.getClient() != null) {
      summaryDetails.details.concernRoleID = providerRosterLineItem.getClient().getID();
      summaryDetails.details.isRegisteredClientInd = true;
    }

    summaryDetails.providerID = providerRosterLineItem.getRoster().getProvider().getID();

    return summaryDetails;
  }

  /**
   * Deletes the absence reason associated with roster line item.
   *
   * @param key
   * Contains the absence period id and version number.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deleteAbsenceReason(KeyVersionDetails key) throws AppException,
      InformationalException {

    AbsencePeriod absencePeriod = absencePeriodDAO.get(key.id);

    absencePeriod.cancel(key.version);
  }

  /**
   * Lists the history changes for absence period. The list ordered by creation
   * date, earliest first.
   *
   * @param key
   * Contains absence period id.
   * @return List of all absence period history.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public AbsencePeriodHistoryDetailsList listHistoryForAbsencePeriod(
    ProviderRosterLineItemKey key) throws AppException,
      InformationalException {

    AbsencePeriodHistoryDetailsList absencePeriodHistoryDetailsList = new AbsencePeriodHistoryDetailsList();
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);

    Set<curam.attendance.impl.AbsencePeriod> absencePeriodList = absencePeriodDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());

    // BEGIN, CR00233623, ASN
    List<PRLIHistory> prliHistories = prliHistoryDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);

    for (final PRLIHistory prliHistory : prliHistories) {

      if (0 != prliHistory.getPRLICorrection().getID()) {

        PRLICorrection prliCorrection = prliCorrectionDAO.get(
          prliHistory.getPRLICorrection().getID());

        Set<AbsencePeriodCorrectionHistory> absencePeriodCorrectionHistories = absencePeriodCorrectionHistoryDAO.searchByPRLICorrection(
          prliCorrection);

        if (!PRLICorrectionStatusEntry.DENIED.equals(
          prliCorrection.getLifecycleState())) {

          for (final AbsencePeriodCorrectionHistory absencePeriodCorrectionHistory : absencePeriodCorrectionHistories) {
            
            AbsencePeriodHistoryDetails absencePeriodHistoryDetails = new AbsencePeriodHistoryDetails();

            absencePeriodHistoryDetails.dtls.absenceDate = absencePeriodCorrectionHistory.getAbsenceDate();
            absencePeriodHistoryDetails.dtls.dateTimeChanged = absencePeriodCorrectionHistory.getDateTimeChanged();
            absencePeriodHistoryDetails.dtls.absenceReason = absencePeriodCorrectionHistory.getAbsenceReason();
            absencePeriodHistoryDetails.dtls.unitsUnattended = absencePeriodCorrectionHistory.getUnitsUnattended();
            absencePeriodHistoryDetails.dtls.recordStatus = absencePeriodCorrectionHistory.getStatus().getCode();
            absencePeriodHistoryDetails.dtls.userName = absencePeriodCorrectionHistory.getUserName();
            absencePeriodHistoryDetails.dtls.creationDate = absencePeriodCorrectionHistory.getCreationDate();
            
            absencePeriodHistoryDetailsList.details.addRef(
              absencePeriodHistoryDetails);
          }
          break;
        }
      }
    }
    // END, CR00233623
    // Set the daily attendance indicator.
    absencePeriodHistoryDetailsList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    AbsencePeriodHistoryDtlsList absencePeriodHistoryDtlsList = new AbsencePeriodHistoryDtlsList();

    for (AbsencePeriod absencePeriod : absencePeriodList) {

      absencePeriodHistoryDtlsList = absencePeriodHistoryDAO.searchBy(
        absencePeriod);
      int historySize = 0;

      historySize = absencePeriodHistoryDtlsList.dtls.size();

      for (int i = 0; i < historySize; i++) {
        AbsencePeriodHistoryDetails absencePeriodHistoryDetails = new AbsencePeriodHistoryDetails();

        absencePeriodHistoryDetails.dtls = absencePeriodHistoryDtlsList.dtls.item(
          i);
        absencePeriodHistoryDetailsList.details.addRef(
          absencePeriodHistoryDetails);
      }

    }

    return sortByAbsencePeriodHistoryCreationDate(
      absencePeriodHistoryDetailsList);
  }
  
  /**
   * Lists the history changes for daily attendance. The list ordered by
   * creation date, earliest first.
   *
   * @param key
   * Contains daily attendance id.
   * @return List of all daily attendance history.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public DailyAttendanceHistoryDetailsList listHistoryForDailyAttendance(
    ProviderRosterLineItemKey key) throws AppException,
      InformationalException {

    DailyAttendanceHistoryDetailsList dailyAttendanceHistoryDetailsList = new DailyAttendanceHistoryDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);

    // Set the daily attendance indicator.
    dailyAttendanceHistoryDetailsList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);
    DailyAttendanceHistoryDtlsList dailyAttendanceHistoryDtlsList = new DailyAttendanceHistoryDtlsList();

    Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());

    Locale locale = new Locale(TransactionInfo.getProgramLocale());
    DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG, locale);

    for (DailyAttendance dailyAttendance : dailyAttendanceList) {
      dailyAttendanceHistoryDtlsList = dailyAttendanceHistoryDAO.searchBy(
        dailyAttendance);
      int historySize = 0;

      historySize = dailyAttendanceHistoryDtlsList.dtls.size();
      DailyAttendanceHistoryDetails dailyAttendanceHistoryDetails;

      for (int i = 0; i < historySize; i++) {
        
        // BEGIN, CR00304523, SSK
        dailyAttendanceHistoryDetails = new DailyAttendanceHistoryDetails();
        dailyAttendanceHistoryDetails.dtls.serviceDate = dailyAttendanceHistoryDtlsList.dtls.item(i).serviceDate; 
        // END, CR00304523
         
        java.util.Date serviceDate = new java.util.Date(
          dailyAttendanceHistoryDtlsList.dtls.item(i).serviceDate.asLong());
        String formattedServiceDate = dateFormat.format(serviceDate);

        dailyAttendanceHistoryDetails.serviceDateString = formattedServiceDate;
        // BEGIN, CR00233623, ASN
        if (0 == dailyAttendanceHistoryDtlsList.dtls.item(i).unitsAttended) {
          dailyAttendanceHistoryDetails.unitsAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceHistoryDetails.unitsAttendedString = String.valueOf(
            dailyAttendanceHistoryDtlsList.dtls.item(i).unitsAttended);
        }
        if (0 == dailyAttendanceHistoryDtlsList.dtls.item(i).unitsUnattended) {
          dailyAttendanceHistoryDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceHistoryDetails.unitsUnAttendedString = String.valueOf(
            dailyAttendanceHistoryDtlsList.dtls.item(i).unitsUnattended);
        }
        
        dailyAttendanceHistoryDetails.dtls.dateTimeChanged = dailyAttendanceHistoryDtlsList.dtls.item(i).dateTimeChanged;
        dailyAttendanceHistoryDetails.dtls.absenceReason = dailyAttendanceHistoryDtlsList.dtls.item(i).absenceReason;
        dailyAttendanceHistoryDetails.dtls.attendance = dailyAttendanceHistoryDtlsList.dtls.item(i).attendance;
        dailyAttendanceHistoryDetails.dtls.userName = dailyAttendanceHistoryDtlsList.dtls.item(i).userName;
        // END, CR00233623
        dailyAttendanceHistoryDetails.dtls = dailyAttendanceHistoryDtlsList.dtls.item(
          i);
        dailyAttendanceHistoryDetailsList.details.addRef(
          dailyAttendanceHistoryDetails);
      } 
    }

    // BEGIN, CR00233623, ASN
    List<PRLIHistory> prliHistories = prliHistoryDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);
       
    for (final PRLIHistory prliHistory : prliHistories) {
    
      if (0 != prliHistory.getPRLICorrection().getID()) {
     
        PRLICorrection prliCorrection = prliCorrectionDAO.get(
          prliHistory.getPRLICorrection().getID());
      
        Set <DailyAttendanceCorrectionHistory> DailyAttendanceCorrectionHistories = dailyAttendanceCorrectionHistoryDAO.searchByPRLICorrection(
          prliCorrection);
      
        if (!PRLICorrectionStatusEntry.DENIED.equals(
          prliCorrection.getLifecycleState())) {
          DailyAttendanceHistoryDetails dailyAttendanceHistory;

          for (final DailyAttendanceCorrectionHistory dailyAttendanceCorrectionHistory : DailyAttendanceCorrectionHistories) {
          
            // BEGIN, CR00304523, SSK
            dailyAttendanceHistory = new DailyAttendanceHistoryDetails();
            dailyAttendanceHistory.dtls.serviceDate = dailyAttendanceCorrectionHistory.getServiceDate();
            // END, CR00304523

            java.util.Date serviceDate = new java.util.Date(
              dailyAttendanceCorrectionHistory.getServiceDate().asLong());
            String formattedServiceDate = dateFormat.format(serviceDate);
          
            dailyAttendanceHistory.serviceDateString = formattedServiceDate;
          
            if (0 == dailyAttendanceCorrectionHistory.getUnitsAttended()) {
            
              dailyAttendanceHistory.unitsAttendedString = CPMConstants.kEmptyString;
            } else {
            
              dailyAttendanceHistory.unitsAttendedString = String.valueOf(
                dailyAttendanceCorrectionHistory.getUnitsAttended());
            }
            if (0 == dailyAttendanceCorrectionHistory.getUnitsUnattended()) {
            
              dailyAttendanceHistory.unitsUnAttendedString = CPMConstants.kEmptyString;
            } else {
            
              dailyAttendanceHistory.unitsUnAttendedString = String.valueOf(
                dailyAttendanceCorrectionHistory.getUnitsUnattended());
            }
            dailyAttendanceHistory.dtls.absenceReason = dailyAttendanceCorrectionHistory.getAbsenceReason().getCode();
            dailyAttendanceHistory.dtls.attendance = dailyAttendanceCorrectionHistory.getAttendance().getCode();
            dailyAttendanceHistory.dtls.dateTimeChanged = dailyAttendanceCorrectionHistory.getDateTimeChanged();
            dailyAttendanceHistory.dtls.userName = dailyAttendanceCorrectionHistory.getUserName();
          
            dailyAttendanceHistoryDetailsList.details.addRef(
              dailyAttendanceHistory);
          
          }
          break;
        }
      }
      // END, CR00233623
    }
    return sortByDailyAttendanceHistoryCreationDate(
      dailyAttendanceHistoryDetailsList);
  }

  // BEGIN, CR00176474, AS
  // BEGIN, CR00199226, ASN
  /**
   * Modifies all the daily attendance records and the roster line item record
   * for a specified provider roster line item.
   *
   * @param dailyAttendanceWidgetDetails
   * Contains the xml data received from the Daily Attendance widget.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_ATTENDANCE_CANNOT_BE_MODIFIED}
   * -If the daily attendance is added when the exception task is
   * created.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_DAILY_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED()}
   * -If attendance not entered but other details are entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED()
   * ()} -If user tries to save all blank record.
   */
  // END, CR00199226
  public void addDailyAttendanceForReporting(
    DailyAttendanceReportingWidgetDetails dailyAttendanceWidgetDetails)
    throws AppException, InformationalException {

    // Modify the actual units attribute in roster line item record.
    curam.attendance.impl.ProviderRosterLineItem providerRosterLineItemImpl = providerRosterLineItemDAO.get(
      dailyAttendanceWidgetDetails.providerRosterLineItemID);

    providerRosterLineItemImpl.setRLIVersionNo(
      dailyAttendanceWidgetDetails.rliVersionNo);

    DailyAttendanceDetailsList dailyAttendanceDetailsList = null;

    // The xml containing data of daily attendance details list which is
    // received from the Daily Attendance widget is parsed and the xml data is
    // populated to a list of daily attendance details.
    if (dailyAttendanceWidgetDetails.hoursEnabled) {
      dailyAttendanceDetailsList = AttendanceWidgetHelper.convertXmlToAttendanceDetailsList(
        dailyAttendanceWidgetDetails.dailyAttendanceHoursDetails,
        dailyAttendanceWidgetDetails.hoursEnabled);
    } else {
      dailyAttendanceDetailsList = AttendanceWidgetHelper.convertXmlToAttendanceDetailsList(
        dailyAttendanceWidgetDetails.dailyAttendanceDetails,
        dailyAttendanceWidgetDetails.hoursEnabled);
    }

    addDailyAttendanceDetailsForRLI(dailyAttendanceDetailsList,
      providerRosterLineItemImpl, dailyAttendanceWidgetDetails.hoursEnabled);
  }

  /**
   * Retrieves the Daily Attendance details for a specified provider roster line
   * item key.
   *
   * @param providerRosterLineItemKey
   * Key containing the provider roster line item ID.
   * @return List of Daily Attendance details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewDailyAttendanceReportingDetails viewDailyAttendanceForReporting(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {
    ViewDailyAttendanceReportingDetails viewDailyAttendanceDetails = new ViewDailyAttendanceReportingDetails();
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    // Populate the details of the roster line item.
    viewDailyAttendanceDetails.fromDate = providerRosterLineItem.getServiceDateFrom();
    viewDailyAttendanceDetails.toDate = providerRosterLineItem.getServiceDateTo();
    if (providerRosterLineItem.getClient() != null) {
      viewDailyAttendanceDetails.clientName = providerRosterLineItem.getClient().getName();
    }

    // BEGIN, CR00198474, ASN
    SOAttendanceConfiguration soAttendanceConfig = sOAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      providerRosterLineItem.getRoster().getServiceOffering(),
      providerRosterLineItem.getRoster().getDateGenerated());
    
    if (null != soAttendanceConfig
      && soAttendanceConfig.isDailyAttendanceTrackingRequired()) {
      // Generate daily attendance dynamically using data using either the daily
      // attendance date input at facade level or from daily attendance entity
      // if records exist.
      dailyAttendanceDetailsList = generateDailyAttendance(
        providerRosterLineItem);
    }
    viewDailyAttendanceDetails.viewDetailsList.assign(
      dailyAttendanceDetailsList);
    
    // END, CR00198474

    // Setting the indicator for displaying daily Attendance details.
    viewDailyAttendanceDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    RosterKey rosterKey = new RosterKey();

    rosterKey.rosterID = providerRosterLineItem.getRoster().getID();

    // Convert the list of daily attendance details to an xml. This xml is the
    // input to the widget to display the list of daily attendance details.
    // BEGIN, CR00178377, AS
    if (attendanceConfigurationHelper.isHoursEnabledForAttendanceReporting(
      rosterKey)) {
      // END, CR00178377
      viewDailyAttendanceDetails.hoursEnabled = true;
      viewDailyAttendanceDetails.dailyAttendanceHoursDetails = AttendanceWidgetHelper.convertDailyAttendanceToXml(
        dailyAttendanceDetailsList, viewDailyAttendanceDetails.hoursEnabled);
    } else {
      viewDailyAttendanceDetails.hoursEnabled = false;
      viewDailyAttendanceDetails.dailyAttendanceDetails = AttendanceWidgetHelper.convertDailyAttendanceToXml(
        dailyAttendanceDetailsList, viewDailyAttendanceDetails.hoursEnabled);
    }
    viewDailyAttendanceDetails.rliVersionNo = providerRosterLineItem.getRLIVersionNo();

    return viewDailyAttendanceDetails;
  }

  /**
   * Checks if the reporting method on the service offering attendance
   * configuration is set to Attendance.
   *
   * @param providerRosterLineItemKey
   * Contains the roster line item details.
   *
   * @return The attendance reporting configuration details.
   */
  public RosterServiceReportingMethod isReportingMethodAttendance(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    RosterServiceReportingMethod reportingMethod = new RosterServiceReportingMethod();

    // BEGIN, CR00178377, AS
    reportingMethod.attendanceReportingIndicator = attendanceConfigurationHelper.isReportingMethodAttendance(
      providerRosterLineItem.getRoster());
    // END, CR00178377

    // BEGIN, CR00199226, ASN
    RosterKey rosterKey = new RosterKey();

    rosterKey.rosterID = providerRosterLineItem.getRoster().getID();
    reportingMethod.hoursEnabledIndicator = attendanceConfigurationHelper.isHoursEnabledForAttendanceReporting(
      rosterKey);

    if (!reportingMethod.attendanceReportingIndicator
      && !reportingMethod.hoursEnabledIndicator) {

      reportingMethod.attendanceHoursEnabledIndicator = true;
    }
    if (reportingMethod.attendanceReportingIndicator
      && reportingMethod.hoursEnabledIndicator) {

      reportingMethod.attendanceHoursEnabledIndicator = true;

    }
    // END, CR00199226
    return reportingMethod;
  }

  /**
   * Modifies all the daily attendance records and the roster line item record
   * for a specified provider roster line item.
   *
   * @param dailyAttendanceWidgetDetails
   * Contains the xml data received from the Daily Attendance widget.
   * @param config
   * Hours enabled configuration for the attendance.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void addDailyAttendanceDetailsForRLI(
    DailyAttendanceDetailsList dailyAttendanceDetailsList,
    curam.attendance.impl.ProviderRosterLineItem providerRosterLineItemImpl,
    boolean attendanceConfig) throws AppException, InformationalException {

    // If roster line item has exception task process indicator set, it cannot
    // be updated.
    if (providerRosterLineItemImpl.getExceptionProcInd()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_ATTENDANCE_CANNOT_BE_MODIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }

    // BEGIN, CR00233623, ASN
    validateForAttendanceReporting(dailyAttendanceDetailsList, attendanceConfig);
    // END, CR00233623
    ArrayList<curam.util.type.Date> serviceDateList = new ArrayList<curam.util.type.Date>();
    
    DailyAttendanceDetailsList dailyAttendanceDetailsViewList = generateDailyAttendance(
      providerRosterLineItemImpl);
    // BEGIN, CR00199226, ASN
    final Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItemImpl.getRosterLineItemID());

    // END, CR00199226
    if (!dailyAttendanceList.isEmpty()) {

      serviceDateList = serviceDatesForActiveDailyAttendance(
        providerRosterLineItemImpl);
    }
    // BEGIN, CR00233623, ASN
    for (final DailyAttendanceDetails viewDailyAttendanceDetails : dailyAttendanceDetailsViewList.details.items()) {

      for (final DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {

        if (0
          == viewDailyAttendanceDetails.dtls.serviceDate.compareTo(
            dailyAttendanceDetails.dtls.serviceDate)) {

          dailyAttendanceDetails.dtls.rosterLineItemID = providerRosterLineItemImpl.getRosterLineItemID();          
          
          // BEGIN, CR00292566, ASN
          if (null != providerRosterLineItemImpl.getClient()) {
            dailyAttendanceDetails.dtls.concernRoleID = providerRosterLineItemImpl.getClient().getID();
          }
          // END, CR00292566

          if (!serviceDateList.contains(dailyAttendanceDetails.dtls.serviceDate)) {
            if (0 == dailyAttendanceDetails.dtls.dailyAttendanceID
              && viewDailyAttendanceDetails.dtls.serviceDate.equals(
                dailyAttendanceDetails.dtls.serviceDate)
                && (!StringUtil.isNullOrEmpty(
                  dailyAttendanceDetails.dtls.attendance))) {

              DailyAttendance dailyAttendanceInstance = dailyAttendance.newInstance();

              dailyAttendanceInstance.setRosterLineItem(
                dailyAttendanceDetails.dtls.rosterLineItemID);
              ServiceAuthorization serviceAuthorization = providerRosterLineItemImpl.getServiceAuthorization();

              if (serviceAuthorization != null) {
                final ServiceDelivery serviceDelivery = serviceDeliveryDAO.readByServiceAuthorization(
                  serviceAuthorization);

                dailyAttendanceInstance.setRelatedItem(serviceDelivery);
              }
              
              // BEGIN, CR00292566, ASN
              if (null != providerRosterLineItemImpl.getClient()) {
                curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
                  providerRosterLineItemImpl.getClient().getID());

                dailyAttendanceInstance.setClient(concernRole);
              }
              // END, CR00292566
              
              setDailyAttendanceDetails(dailyAttendanceInstance,
                dailyAttendanceDetails, attendanceConfig);

              dailyAttendanceInstance.insert();

            }
          } else {
            if (0 != dailyAttendanceDetails.dtls.dailyAttendanceID) {

              DailyAttendance maintainDailyAttendance = dailyAttendanceDAO.get(
                dailyAttendanceDetails.dtls.dailyAttendanceID);

              if (RECORDSTATUSEntry.NORMAL.getCode().equals(
                maintainDailyAttendance.getDtls().recordStatus)) {

                boolean checkAttendance = false;
                boolean checkHours = false;

                if (StringUtil.isNullOrEmpty(
                  dailyAttendanceDetails.dtls.attendance)
                    && StringUtil.isNullOrEmpty(
                      dailyAttendanceDetails.dtls.absenceReason)) {
                  checkAttendance = true;
                }
                if (attendanceConfig) {

                  int totalTimeEntered = dailyAttendanceDetails.dtls.numHoursAttended
                    + dailyAttendanceDetails.dtls.numMinutesAttended
                    + dailyAttendanceDetails.dtls.numMinutesAbsent
                    + dailyAttendanceDetails.dtls.numHoursAbsent;

                  if (0 == totalTimeEntered) {
                    checkHours = true;
                  }
                }
                if (checkAttendance || checkHours) {

                  maintainDailyAttendance.setAttendance(
                    ATTENDANCEEntry.NOT_SPECIFIED);
                  maintainDailyAttendance.setAbsenceReason(
                    ATTENDANCEABSENCEREASONEntry.NOT_SPECIFIED);
                  maintainDailyAttendance.setHoursAttended(
                    ATTENDANCETRACKINGHOURSEntry.NOT_SPECIFIED);
                  maintainDailyAttendance.setHoursAbsent(
                    ATTENDANCETRACKINGHOURSEntry.NOT_SPECIFIED);
                  maintainDailyAttendance.setMinutesAttended(
                    ATTENDANCETRACKINGMINUTESEntry.NOT_SPECIFIED);
                  maintainDailyAttendance.setMinutesAbsent(
                    ATTENDANCETRACKINGMINUTESEntry.NOT_SPECIFIED);
                  maintainDailyAttendance.cancel();
                } else {

                  boolean checkHourDetails = false;
                  boolean checkHoursAttended = false;
                  boolean checkHoursAbsent = false;

                  if (attendanceConfig) {
                    if (maintainDailyAttendance.getDtls().numHoursAttended
                      != dailyAttendanceDetails.dtls.numHoursAttended
                        || maintainDailyAttendance.getDtls().numMinutesAttended
                          != dailyAttendanceDetails.dtls.numMinutesAttended) {
                      checkHoursAttended = true;
                    }
                    if (maintainDailyAttendance.getNumOfHoursAbsent()
                      != dailyAttendanceDetails.dtls.numHoursAbsent
                        || maintainDailyAttendance.getNumOfMinutesAbsent()
                          != dailyAttendanceDetails.dtls.numMinutesAbsent) {
                      checkHoursAbsent = true;
                    }
                    if (checkHoursAttended || checkHoursAbsent) {
                      checkHourDetails = true;
                    }
                  }
                  if (!maintainDailyAttendance.getAttendance().getCode().equals(
                    dailyAttendanceDetails.dtls.attendance)
                      || !maintainDailyAttendance.getAbsenceReason().getCode().equals(
                        dailyAttendanceDetails.dtls.absenceReason)
                        || checkHourDetails) {

                    setDailyAttendanceDetails(maintainDailyAttendance,
                      dailyAttendanceDetails, attendanceConfig);

                    maintainDailyAttendance.modify();

                  }

                }
              }
            }
          }
        }
      }
    }
    // END, CR00233623
    // END, CR00198474

    providerRosterLineItemImpl.setRosterLineItemID(
      providerRosterLineItemImpl.getRosterLineItemID());
    providerRosterLineItemImpl.modifyForDailyAttendance();
  }

  // END, CR00176474
  
  /**
   * Populates the roster line item standard struct details from the provider
   * roster line item entity object.
   *
   * @param providerRosterLineItem
   * Provider roster line item object holding the roster line item
   * details.
   * @return Roster Line Item details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected RosterLineItemDtls getRosterLineItemDetails(
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {
    RosterLineItemDtls rosterLineItemDtls = new RosterLineItemDtls();

    rosterLineItemDtls.rosterLineItemID = providerRosterLineItem.getRosterLineItemID();
    if (providerRosterLineItem.getClient() != null) {
      rosterLineItemDtls.concernRoleID = providerRosterLineItem.getClient().getID();
    }
    rosterLineItemDtls.referenceNo = providerRosterLineItem.getReferenceNumber();
    rosterLineItemDtls.rosterID = providerRosterLineItem.getRoster().getID();
    rosterLineItemDtls.serviceFrom = providerRosterLineItem.getServiceDateFrom();
    rosterLineItemDtls.serviceTo = providerRosterLineItem.getServiceDateTo();
    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        providerRosterLineItem.getRoster())) {
      // END, CR00178377
      rosterLineItemDtls.expectedUnits = providerRosterLineItem.getExpectedUnits();
      rosterLineItemDtls.totalUnitsDelivered = providerRosterLineItem.getUnitsDelivered();
    }
    // END, CR00176474
    rosterLineItemDtls.versionNo = providerRosterLineItem.getRLIVersionNo();

    return rosterLineItemDtls;
  }

  /**
   * Populates the provider roster line item standard struct details from the
   * provider roster line item entity object.
   *
   * @param providerRosterLineItem
   * Provider roster line item object holding the provider roster line
   * item details.
   * @return Provider Roster Line Item details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ProviderRosterLineItemDtls getProviderRosterLineItemDetails(
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {
    ProviderRosterLineItemDtls providerRosterLineItemDtls = new ProviderRosterLineItemDtls();

    providerRosterLineItemDtls.providerRosterLineItemID = providerRosterLineItem.getID();
    providerRosterLineItemDtls.rosterLineItemID = providerRosterLineItem.getRosterLineItemID();
    providerRosterLineItemDtls.saReferenceNo = providerRosterLineItem.getSAReferenceNo();
    providerRosterLineItemDtls.clientReferenceNo = providerRosterLineItem.getClientReferenceNo();
    providerRosterLineItemDtls.clientFirstName = providerRosterLineItem.getClientFirstName();
    providerRosterLineItemDtls.clientLastName = providerRosterLineItem.getClientLastName();
    providerRosterLineItemDtls.clientDOB = providerRosterLineItem.getClientDOB();
    providerRosterLineItemDtls.addressID = providerRosterLineItem.getAddressID();
    providerRosterLineItemDtls.status = providerRosterLineItem.getLifecycleState().getCode();

    providerRosterLineItemDtls.versionNo = providerRosterLineItem.getVersionNo();

    providerRosterLineItemDtls.autoGeneratedInd = providerRosterLineItem.getAutoGeneratedInd();

    providerRosterLineItemDtls.caseReferenceNo = providerRosterLineItem.getCaseReferenceNo();
    providerRosterLineItemDtls.voucherNumber = providerRosterLineItem.getVoucherNumber();

    return providerRosterLineItemDtls;
  }

  /**
   * Deletes the specified provider roster line item having the status open
   * only.
   *
   * @param details
   * Contains provider roster line item id and the version numbers of
   * Provider roster line item and roster line item.
   *
   * @throws InformationalException
   * {@link Roster#ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_CANNOT_CANCEL}
   * If exception task indicator set to true.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deleteRosterLineItem(PRLICancellationDetails details)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      details.providerRosterLineItemID);

    if (providerRosterLineItem.isInExceptionProcessing() == true) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_CANNOT_CANCEL(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();

    providerRosterLineItem.cancel(details.prliVersionNo, details.rliVersionNo,
      PRLICancelationReasonEntry.get(details.cancelationReason));

  }

  // BEGIN, CR00198474, ASN
  // BEGIN, CR00199226, ASN
  /**
   * Validate expected units, units attended, units not attended if attendance
   * is entered.
   *
   * @param dailyAttendanceDetailsList
   * List containing the daily attendance details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00199226
  // END, CR00198474
  protected void validateDailyAttendance(
    DailyAttendanceDetailsList dailyAttendanceDetailsList)
    throws InformationalException {
 
    // BEGIN, CR00198474, ASN
    int recordCounter = 0;

    // END, CR00198474
    // BEGIN, CR00233623, ASN
    for (final DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {
      if (0 == dailyAttendanceDetails.dtls.attendance.trim().length()
        && (dailyAttendanceDetails.dtls.absenceReason.trim().length() > 0
          || dailyAttendanceDetails.dtls.unitsAttended > 0
          || dailyAttendanceDetails.dtls.unitsUnattended > 0)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      }

      // Check units attended less than zero or equal to zero and attendance
      // is present or partially present.
      if (dailyAttendanceDetails.dtls.attendance.equals(
        ATTENDANCEEntry.PRESENT.getCode())
          || dailyAttendanceDetails.dtls.attendance.equals(
            ATTENDANCEEntry.PARTIALLYPRESENT.getCode())) {
        if (dailyAttendanceDetails.dtls.unitsAttended <= 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_PRESENT_OR_PARTIALLY_PRESENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        }
      }

      // Check units attended not equal to zero and attendance
      // is not present and not partially present.
      if (dailyAttendanceDetails.dtls.attendance.equals(
        ATTENDANCEEntry.ABSENT.getCode())) {
        if (dailyAttendanceDetails.dtls.unitsAttended != 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_ABSENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        }
      }

      // Check attendance is present and units attended not equal to zero.
      if (dailyAttendanceDetails.dtls.attendance.equals(
        ATTENDANCEEntry.PRESENT.getCode())
          && dailyAttendanceDetails.dtls.unitsUnattended != 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }

      if ((dailyAttendanceDetails.dtls.attendance.equals(
        ATTENDANCEEntry.PARTIALLYPRESENT.getCode())
          || dailyAttendanceDetails.dtls.attendance.equals(
            ATTENDANCEEntry.ABSENT.getCode()))
              && 0 == dailyAttendanceDetails.dtls.unitsUnattended) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ABSENT_OR_PARTIALLY_PRESENT(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
 
      if (ATTENDANCEEntry.ABSENT.getCode().equals(
        dailyAttendanceDetails.dtls.attendance)
          || ATTENDANCEEntry.PARTIALLYPRESENT.getCode().equals(
            dailyAttendanceDetails.dtls.attendance)) {
        if (StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.absenceReason)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ENTDAILYATTENDANCEExceptionCreator.ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_ABSENT_OR_PARTIALLY_PRESENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        }
      }

      if (ATTENDANCEEntry.PRESENT.getCode().equals(
        dailyAttendanceDetails.dtls.attendance)
          && !StringUtil.isNullOrEmpty(
            dailyAttendanceDetails.dtls.absenceReason)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTDAILYATTENDANCEExceptionCreator.ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

      }
      // END, CR00233623

      // BEGIN, CR00198474, ASN
      if (StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.attendance)) {

        recordCounter = recordCounter + 1;
      }
    }
    if (recordCounter == dailyAttendanceDetailsList.details.size()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
    }
    // END, CR00198474
    ValidationHelper.failIfErrorsExist();
  }

  /**
   * Gets the service authorization line item details from the service
   * authorization line item entity object.
   *
   * @param details
   * Service authorization line item object holding the service
   * authorization line item details.
   * @return Service Authorization Line Item details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ServiceAuthorizationLineItemDetails getServiceAuthorizationLineItemDetails(
    ServiceAuthorizationLineItem details) {
    ServiceAuthorizationLineItemDetails dtls = new ServiceAuthorizationLineItemDetails();

    dtls.dateAdded = details.getDateAdded();
    dtls.fromDate = details.getDateRange().start();
    dtls.maximumUnits = CPMConstants.kEmptyString + details.getMaximumUnits();
    if (details.getProvider() != null) {
      dtls.providerID = details.getProvider().getID();
    }
    dtls.status = details.getDerivedStatus();
    dtls.serviceAuthorizationID = details.getServiceAuthorization().getID();
    dtls.ServiceAuthorizationLineItemID = details.getID();
    dtls.serviceID = details.getServiceOffering().getID();
    dtls.serviceName = details.getServiceOffering().getName();
    dtls.toDate = details.getDateRange().end();
    dtls.totalCost = CPMConstants.kEmptyString + details.getTotalCost();
    // BEGIN, CR00142003, ABS
    if (details.getUnitAmount() != null) {
      dtls.unitAmount = details.getUnitAmount();
    }
    // END, CR00142003
    dtls.unitsAmountFixedInd = details.isUnitAmountFixed();
    dtls.unitsAuthorized = CPMConstants.kEmptyString
      + details.getUnitsAuthorized();
    dtls.remainingUints = (int) (details.getUnitsAuthorized()
      - details.getUnitsConsumed());
    return dtls;
  }

  /**
   * Checks whether the daily attendance tracking is required for the service
   * associated with the provider roster line item.
   *
   * @param providerRosterLineItem
   * Provider roster line item for which the daily attendance tracking
   * configuration is to be determined.
   * @return True if daily attendance tracking is required and false otherwise.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected boolean isDailyAttendanceConfigured(
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {

    ServiceOffering serviceOffering = providerRosterLineItem.getRoster().getServiceOffering();
    SOAttendanceConfiguration attendanceConfiguration = sOAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      serviceOffering, providerRosterLineItem.getRoster().getDateGenerated());

    if (attendanceConfiguration != null) {
      return attendanceConfiguration.isDailyAttendanceTrackingRequired();
    }
    return false;
  }

  /**
   * Sorts a set of daily attendance records by service date.
   *
   * @param unsortedDailyAttendance
   * The list of unsorted daily attendance.
   * @return A sorted list of daily attendance.
   */
  protected ArrayList<DailyAttendance> sortDailyAttendanceByServiceDate(
    final Set<DailyAttendance> unsortedDailyAttendance) {

    // Sort by position for display
    final ArrayList<DailyAttendance> dailyAttendanceList = new ArrayList<DailyAttendance>(
      unsortedDailyAttendance);

    Collections.sort(dailyAttendanceList, new Comparator<DailyAttendance>() {
      public int compare(final DailyAttendance lhs, DailyAttendance rhs) {

        return lhs.getServiceDate().compareTo(rhs.getServiceDate());
      }
    });
    return dailyAttendanceList;
  }

  /**
   * Sorts a set of absencePeriods by absence date.
   *
   * @param unsortedAbsenceList
   * The list of unsorted absencePeriod records.
   * @return A sorted list of absence records.
   */
  protected ArrayList<AbsencePeriod> sortAbsenceByServiceDate(
    final Set<AbsencePeriod> unsortedAbsenceList) {

    // Sort by position for display
    final ArrayList<AbsencePeriod> absenceList = new ArrayList<AbsencePeriod>(
      unsortedAbsenceList);

    Collections.sort(absenceList, new Comparator<AbsencePeriod>() {
      public int compare(final AbsencePeriod lhs, AbsencePeriod rhs) {

        return lhs.getAbsenceDate().compareTo(rhs.getAbsenceDate());
      }
    });
    return absenceList;
  }
  
  // BEGIN, CR00233623, ASN
  /**
   * Populates the provider roster line item history struct details from the
   * provider roster line item history and roster line item entity object.
   *
   * @param prliHistory
   * Provider roster line item history interface.
   * @param rosterLineItemHistory
   * Roster line item history interface.
   * @return Provider roster line item history detail.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link MaintainRosterLineItem#getProviderRosterLineitemHistoryDetails(PRLIHistory, RosterLineItemHistory)}
   * . As part of the PRLI History merge changes, a new indicator
   * need to be added to indicate a correction is denied while
   * retrieving provider roster line item history and provider
   * roster line item correction history records. See release note:
   * CR00208448.
   */
  protected PRLIHistoryDetails getPRLIAndRLIHistoryDetails(
    PRLIHistory prliHistory, RosterLineItemHistory rosterLineItemHistory) {

    PRLIHistoryDetails prliHistoryDetails = new PRLIHistoryDetails();

    prliHistoryDetails.prliDtls.prliHistoryID = prliHistory.getID();
    prliHistoryDetails.prliDtls.status = prliHistory.getLifecycleState().getCode();
    prliHistoryDetails.prliDtls.cancelationReason = prliHistory.getCancellationReason().getCode();
    prliHistoryDetails.prliDtls.denialReason = prliHistory.getDenialReason().getCode();

    prliHistoryDetails.rliDtls.dateTimeChanged = rosterLineItemHistory.getDateTimeChanged();
    prliHistoryDetails.rliDtls.totalUnitsDelivered = rosterLineItemHistory.getUnitsDelivered();

    return prliHistoryDetails;
  }

  /**
   * Populates the provider roster line item history details from the provider
   * roster line item history and roster line item entity object.
   *
   * @param prliHistory
   * Provider roster line item history interface.
   * @param rosterLineItemHistory
   * Roster line item history interface.
   *
   * @return Provider roster line item history details with status indicator.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected PRLIHistoryWithStatusDetails getProviderRosterLineitemHistoryDetails(
    final PRLIHistory prliHistory,
    final RosterLineItemHistory rosterLineItemHistory) throws AppException,
      InformationalException {

    PRLIHistoryWithStatusDetails prliHistoryWithStatusDetails = new PRLIHistoryWithStatusDetails();

    prliHistoryWithStatusDetails.prliHistoryDetails.prliHistoryID = prliHistory.getID();
    prliHistoryWithStatusDetails.prliHistoryDetails.status = prliHistory.getLifecycleState().getCode();
    prliHistoryWithStatusDetails.prliHistoryDetails.cancelationReason = prliHistory.getCancellationReason().getCode();
    prliHistoryWithStatusDetails.prliHistoryDetails.denialReason = prliHistory.getDenialReason().getCode();
    
    // BEGIN, CR00273450, ASN
    prliHistoryWithStatusDetails.prliHistoryDetails.correctionReason = prliHistory.getCorrectionReason();
    // END, CR00273450
    prliHistoryWithStatusDetails.rliHistory.dateTimeChanged = rosterLineItemHistory.getDateTimeChanged();
    prliHistoryWithStatusDetails.rliHistory.totalUnitsDelivered = rosterLineItemHistory.getUnitsDelivered();
    prliHistoryWithStatusDetails.prliHistoryDetails.prliCorrectionID = prliHistory.getPRLICorrection().getID();

    return prliHistoryWithStatusDetails;
  }

  /**
   * Populates the provider roster line item history struct details from the
   * provider roster line item history entity object.
   *
   * @param prliHistory
   * Provider roster line item history interface.
   * @return Provider roster line item history detail.
   */
  protected PRLIHistoryDtls getPRLIHistoryDetails(PRLIHistory prliHistory) {

    PRLIHistoryDtls prliHistoryDetails = new PRLIHistoryDtls();

    prliHistoryDetails.prliHistoryID = prliHistory.getID();
    prliHistoryDetails.voucherNumber = prliHistory.getVoucherNumber();
    prliHistoryDetails.clientReferenceNo = prliHistory.getClientReferenceNo();
    prliHistoryDetails.clientFirstName = prliHistory.getClientFirstName();
    prliHistoryDetails.clientLastName = prliHistory.getClientLastName();
    prliHistoryDetails.clientDOB = prliHistory.getClientDOB();
    prliHistoryDetails.saReferenceNo = prliHistory.getSAReferenceNo();
    prliHistoryDetails.status = prliHistory.getLifecycleState().getCode();
    prliHistoryDetails.cancelationReason = prliHistory.getCancellationReason().getCode();
    prliHistoryDetails.denialReason = prliHistory.getDenialReason().getCode();
    // BEGIN, CR00378404, SS
    prliHistoryDetails.caseReferenceNo = prliHistory.getCaseReferenceNumber();
    // END, CR00378404
    prliHistoryDetails.addressID = prliHistory.getProviderRosterLineItem().getAddressID();

    return prliHistoryDetails;
  }

  /**
   * Populates the provider roster line item history struct details from the
   * roster line item history entity object.
   *
   * @param rosterLineItemHistory
   * Roster line item history interface.
   * @return Roster line item history detail.
   */
  protected RosterLineItemHistoryDtls getRLIHistoryDetails(
    RosterLineItemHistory rosterLineItemHistory) {

    RosterLineItemHistoryDtls rosterLineItemHistoryDetails = new RosterLineItemHistoryDtls();

    rosterLineItemHistoryDetails.referenceNo = rosterLineItemHistory.getReferenceNumber();
    rosterLineItemHistoryDetails.dateTimeChanged = rosterLineItemHistory.getDateTimeChanged();
    rosterLineItemHistoryDetails.totalUnitsDelivered = rosterLineItemHistory.getUnitsDelivered();
    rosterLineItemHistoryDetails.expectedUnits = rosterLineItemHistory.getExpectedUnits();
    rosterLineItemHistoryDetails.totalUnitsDelivered = rosterLineItemHistory.getUnitsDelivered();
    rosterLineItemHistoryDetails.serviceFrom = rosterLineItemHistory.getRosterLineItemHistory().getServiceDateFrom();
    rosterLineItemHistoryDetails.serviceTo = rosterLineItemHistory.getRosterLineItemHistory().getServiceDateTo();

    return rosterLineItemHistoryDetails;
  }

  // END, CR00233623
  /**
   * Sorts the Absence Period history list by Date and Time Changed, latest
   * first.
   *
   * @param absencePeriodHistoryDetailsList
   * Contains unsorted daily attendance details list.
   * @return Absence Period History Details List.
   */
  protected AbsencePeriodHistoryDetailsList sortByAbsencePeriodHistoryCreationDate(
    AbsencePeriodHistoryDetailsList absencePeriodHistoryDetailsList) {

    AbsencePeriodHistoryDetailsList absencePeriodHistoryDetailsSortedList = new AbsencePeriodHistoryDetailsList();
    List<AbsencePeriodHistoryDetails> absencePeriodHistoryDetailsSortebleList = new ArrayList<AbsencePeriodHistoryDetails>();

    for (int i = 0; i < absencePeriodHistoryDetailsList.details.size(); i++) {
      absencePeriodHistoryDetailsSortebleList.add(
        absencePeriodHistoryDetailsList.details.item(i));
    }
    // Sorting the absence Periods history list by Date and
    // Time Changed, latest first.
    if (absencePeriodHistoryDetailsSortebleList.size() > 0) {
      Collections.sort(absencePeriodHistoryDetailsSortebleList,
        new Comparator<AbsencePeriodHistoryDetails>() {
        public int compare(final AbsencePeriodHistoryDetails lhs,
          final AbsencePeriodHistoryDetails rhs) {
          return rhs.dtls.creationDate.compareTo(lhs.dtls.creationDate);
        }
      });
    }

    int absenceListSize = 0;

    absenceListSize = absencePeriodHistoryDetailsSortebleList.size();
    for (int i = absenceListSize; i > 0; i--) {
      absencePeriodHistoryDetailsSortedList.details.addRef(
        absencePeriodHistoryDetailsSortebleList.get(i - 1));
    }

    return absencePeriodHistoryDetailsSortedList;
  }

  /**
   * Sorts the daily attendances history list by Date and Time Changed, latest
   * first.
   *
   * @param dailyAttendanceHistoryDetailsList
   * Contains unsorted daily attendance details list.
   * @return Daily Attendance History Details List.
   */
  protected DailyAttendanceHistoryDetailsList sortByDailyAttendanceHistoryCreationDate(
    DailyAttendanceHistoryDetailsList dailyAttendanceHistoryDetailsList) {

    DailyAttendanceHistoryDetailsList dailyAttendanceHistoryDetailsSortedList = new DailyAttendanceHistoryDetailsList();
    List<DailyAttendanceHistoryDetails> dailyAttendanceHistoryDetailsSortebleList = new ArrayList<DailyAttendanceHistoryDetails>();

    for (int i = 0; i < dailyAttendanceHistoryDetailsList.details.size(); i++) {
      dailyAttendanceHistoryDetailsSortebleList.add(
        dailyAttendanceHistoryDetailsList.details.item(i));
    }
    // Sorting the daily attendances history list by Date and
    // Time Changed, latest first.
    if (dailyAttendanceHistoryDetailsSortebleList.size() > 0) {
      Collections.sort(dailyAttendanceHistoryDetailsSortebleList,
        new Comparator<DailyAttendanceHistoryDetails>() {
        public int compare(final DailyAttendanceHistoryDetails lhs,
          final DailyAttendanceHistoryDetails rhs) {
          return lhs.dtls.dateTimeChanged.compareTo(rhs.dtls.dateTimeChanged);
        }
      });
    }

    for (int i = dailyAttendanceHistoryDetailsSortebleList.size(); i > 0; i--) {
      dailyAttendanceHistoryDetailsSortedList.details.addRef(
        dailyAttendanceHistoryDetailsSortebleList.get(i - 1));
    }

    return dailyAttendanceHistoryDetailsSortedList;
  }
  
  // BEGIN, CR00187398, SSK
  /**
   * Retrieves the Daily Attendance details for a specified provider roster line
   * item key.
   *
   * @param providerRosterLineItemKey
   * Key containing the provider roster line item ID.
   *
   * @return List of Daily Attendance details for reporting.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewReportingDailyAttendanceDetails viewDailyAttendanceDetailsForReporting(
    final ProviderRosterLineItemKey providerRosterLineItemKey)
    throws AppException, InformationalException {

    ViewReportingDailyAttendanceDetails viewReportingDailyAttendanceDetails = new ViewReportingDailyAttendanceDetails();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);
    
    // BEGIN, CR00199226, ASN
    RosterKey rosterKey = new RosterKey();

    rosterKey.rosterID = providerRosterLineItem.getRoster().getID();

    viewReportingDailyAttendanceDetails.isHoursEnabled = attendanceConfigurationHelper.isHoursEnabledForAttendanceReporting(
      rosterKey);
    // END, CR00199226

    viewReportingDailyAttendanceDetails.fromDate = providerRosterLineItem.getServiceDateFrom();
    viewReportingDailyAttendanceDetails.toDate = providerRosterLineItem.getServiceDateTo();
    if (providerRosterLineItem.getClient() != null) {
      viewReportingDailyAttendanceDetails.clientName = providerRosterLineItem.getClient().getName();
    }

    Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());

    Locale locale = new Locale(TransactionInfo.getProgramLocale());
    DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG, locale);

    ReportingDailyAttendanceDetails reportingDailyAttendanceDetails;

    for (final DailyAttendance dailyAttendance : sortDailyAttendanceByServiceDate(
      dailyAttendanceList)) {

      if (RECORDSTATUSEntry.NORMAL.equals(dailyAttendance.getStatus())) {
        
        // BEGIN, CR00304523, SSK
        reportingDailyAttendanceDetails = new ReportingDailyAttendanceDetails();
        reportingDailyAttendanceDetails.dtls.serviceDate = dailyAttendance.getServiceDate();
        // END, CR00304523

        Date serviceDate = new Date(dailyAttendance.getServiceDate().asLong());
        String formattedServiceDate = dateFormat.format(serviceDate);

        reportingDailyAttendanceDetails.serviceDateString = formattedServiceDate;
        reportingDailyAttendanceDetails.dtls.absenceReason = dailyAttendance.getAbsenceReason().getCode();

        reportingDailyAttendanceDetails.dtls.attendance = dailyAttendance.getAttendance().getCode();
        // BEGIN, CR00199226, ASN
        if (viewReportingDailyAttendanceDetails.isHoursEnabled) {
          // END, CR00199226  
          reportingDailyAttendanceDetails.hoursAttended = getFormattedTimeDuration(
            dailyAttendance.getHoursAttended(),
            dailyAttendance.getMinutesAttended());

          reportingDailyAttendanceDetails.hoursUnAttended = getFormattedTimeDuration(
            dailyAttendance.getHoursAbsent(),
            dailyAttendance.getMinutesAbsent());
          // BEGIN, CR00199226, ASN
        }
        // END, CR00199226
        reportingDailyAttendanceDetails.dtls.dailyAttendanceID = dailyAttendance.getID();
        reportingDailyAttendanceDetails.dtls.versionNo = dailyAttendance.getVersionNo();
        reportingDailyAttendanceDetails.dtls.rosterLineItemID = dailyAttendance.getRosterLineItem();

        viewReportingDailyAttendanceDetails.details.addRef(
          reportingDailyAttendanceDetails);
      }
    }

    viewReportingDailyAttendanceDetails.rliVersionNo = providerRosterLineItem.getRLIVersionNo();

    viewReportingDailyAttendanceDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    viewReportingDailyAttendanceDetails.rliVersionNo = providerRosterLineItem.getRLIVersionNo();

    return viewReportingDailyAttendanceDetails;
  }

  /**
   * Formats the duration in "HM hours and MM minutes" format.
   *
   * @param hours
   * Hours of attendance or absence.
   * @param minutes
   * Minutes of attendance or absence.
   *
   * @return Formatted duration.
   */
  protected String getFormattedTimeDuration(
    final ATTENDANCETRACKINGHOURSEntry hours,
    final ATTENDANCETRACKINGMINUTESEntry minutes) {

    String formattedHrsMinutes = CPMConstants.kEmptyString;
    String formattedMinutes = CPMConstants.kEmptyString;
    String formattedHrs = CPMConstants.kEmptyString;
    boolean appendMinutesToHrs = false;

    if (!ATTENDANCETRACKINGMINUTESEntry.NOT_SPECIFIED.getCode().equals(
      minutes.getCode())
        && !ATTENDANCETRACKINGMINUTESEntry.ATM2001.getCode().equals(
          minutes.getCode())) {

      // If minutes is 30, append to half an hour.
      if (ATTENDANCETRACKINGMINUTESEntry.ATM2031.getCode().equals(
        minutes.getCode())) {

        appendMinutesToHrs = true;

      } else {

        if (CPMConstants.kMinturesLength == minutes.getCode().length()
          && CPMConstants.kZeroChar
            == minutes.getCode().charAt(CPMConstants.kFirstCharIndex)) {
          formattedMinutes = minutes.getCode().charAt(
            CPMConstants.kSecondCharIndex)
              + CPMConstants.kSpace
              + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_MINUTES_ATTENDED_UNATTENDED).getMessage();
        } else {
          formattedMinutes = minutes.getCode() + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_MINUTES_ATTENDED_UNATTENDED).getMessage();
        }
      }
    }

    if (!ATTENDANCETRACKINGHOURSEntry.NOT_SPECIFIED.getCode().equals(
      hours.getCode())
        && !ATTENDANCETRACKINGHOURSEntry.ATH2001.getCode().equals(
          hours.getCode())) {
      if (CPMConstants.kMinturesLength == hours.getCode().length()
        && hours.getCode().charAt(CPMConstants.kFirstCharIndex)
          == CPMConstants.kZeroChar) {
        formattedHrs = hours.getCode().charAt(CPMConstants.kSecondCharIndex)
          + CPMConstants.kEmptyString;
      } else {
        formattedHrs = hours.getCode();
      }
    }

    if (appendMinutesToHrs) {
      if (CPMConstants.kEmptyString.equals(formattedHrs)) {
        formattedHrs = CPMConstants.kZeroChar + CPMConstants.kEmptyString;
      }

      formattedHrsMinutes = formattedHrs + CPMConstants.khalfAnHour
        + CPMConstants.kSpace
        + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_ATTENDED_UNATTENDED).getMessage();

    } else {
      if (!CPMConstants.kEmptyString.equals(formattedHrs)) {
        if (!CPMConstants.kEmptyString.equals(formattedMinutes)) {
          formattedHrsMinutes = formattedHrs + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_AND_MINUTES_ATTENDED_UNATTENDED).getMessage()
            + formattedMinutes;
        } else {
          formattedHrsMinutes = formattedHrs + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_ATTENDED_UNATTENDED).getMessage();
        }
      } else if (!CPMConstants.kEmptyString.equals(formattedMinutes)) {

        formattedHrsMinutes = formattedMinutes;

      }
    }

    return formattedHrsMinutes;
  }  

  // END, CR00187398

  // BEGIN, CR00198474, ASN
  /**
   * Generates daily attendance for a client who is added to a roster, for each
   * day of the roster line item period dynamically to support non storage of
   * daily attendance empty records.If daily attendance records exists the
   * method will populate else the method will generate the data at runtime
   * using the dates from provider roster line item.
   *
   * @param providerRosterLineItem
   * Contains provider roster line item details.
   *
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected DailyAttendanceDetailsList generateDailyAttendance(
    final ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();
    Map<curam.util.type.Date, DailyAttendance> checkDuplicateMap = new HashMap<curam.util.type.Date, DailyAttendance>();

    ArrayList<curam.util.type.Date> serviceDateList = new ArrayList<curam.util.type.Date>();

    Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());

    curam.util.type.Date startDate = providerRosterLineItem.getServiceDateFrom();
    curam.util.type.Date endDate = providerRosterLineItem.getServiceDateTo();

    serviceDateList = serviceDatesForActiveDailyAttendance(
      providerRosterLineItem);

    boolean isReporting = false;

    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        providerRosterLineItem.getRoster())) {

      isReporting = true;
    }
    
    boolean isPlannedUnitsDefaulted = Boolean.parseBoolean(
      curam.util.resources.Configuration.getProperty(
        CPMConstants.kRosterLineItemPlannedUnits));

    // Create the daily Attendance for each day of the service period.
    while (startDate.before(endDate.addDays(1))) {

      if (!serviceDateList.contains(startDate)) {

        DailyAttendanceDetails dailyAttendanceDetails = new DailyAttendanceDetails();

        // BEGIN, CR00199226, ASN
        dailyAttendanceDetails = generateUnstoredDailyAttendanceDetails(
          providerRosterLineItem, isReporting, isPlannedUnitsDefaulted,
          startDate);
        // END, CR00199226
        dailyAttendanceDetailsList.details.addRef(dailyAttendanceDetails);
      } else {

        for (DailyAttendance dailyAttendance : sortDailyAttendanceByServiceDate(
          dailyAttendanceList)) {

          if (RECORDSTATUSEntry.NORMAL.getCode().equals(
            dailyAttendance.getStatus().getCode())
              && startDate.equals(dailyAttendance.getServiceDate())) {

            if (!checkDuplicateMap.containsKey(dailyAttendance.getServiceDate())) {

              checkDuplicateMap.put(dailyAttendance.getServiceDate(),
                dailyAttendance);
              // BEGIN, CR00199226, ASN
              DailyAttendanceDetails storedDailyAttendanceDetails = new DailyAttendanceDetails();

              storedDailyAttendanceDetails = storedDailyAttendanceDetails(
                dailyAttendance);
              // END, CR00199226
              dailyAttendanceDetailsList.details.addRef(
                storedDailyAttendanceDetails);

            }
          }
        }
      }

      startDate = startDate.addDays(1);
    }

    return sortDailyAttendance(dailyAttendanceDetailsList);

  }

  /**
   * Sorts a set of daily attendance records into a sorted list for display.
   *
   * @param unSortedDailyAttendanceDetailsList
   * List of unsorted daily attendance.
   *
   * @return List of daily attendance records sorted by service date.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  protected DailyAttendanceDetailsList sortDailyAttendance(
    final DailyAttendanceDetailsList unSortedDailyAttendanceDetailsList)
    throws AppException, InformationalException {
    // BEGIN, CR00199226, ASN
    final List<DailyAttendanceDetails> dailyAttendanceDetailsList = new ArrayList<DailyAttendanceDetails>();

    for (final DailyAttendanceDetails dailyAttendance : unSortedDailyAttendanceDetailsList.details.items()) {
      // END, CR00199226
      dailyAttendanceDetailsList.add(dailyAttendance);
    }

    Collections.sort(dailyAttendanceDetailsList,
      new Comparator<DailyAttendanceDetails>() {
      public int compare(final DailyAttendanceDetails lhs,
        final DailyAttendanceDetails rhs) {
        return lhs.dtls.serviceDate.compareTo(rhs.dtls.serviceDate);
      }
    });
    // BEGIN, CR00199226, ASN
    final DailyAttendanceDetailsList sortedDailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    // END, CR00199226
    sortedDailyAttendanceDetailsList.details.addAll(dailyAttendanceDetailsList);

    return sortedDailyAttendanceDetailsList;
  }

  /**
   * Retrieves the Daily Attendance details for a specified provider roster line
   * item key.It supports non storage of daily attendance records in case of
   * empty attendance records.
   *
   * @param providerRosterLineItemKey
   * Key containing the provider roster line item ID.
   *
   * @return List of Daily Attendance details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewDailyAttendanceDetails viewDailyAttendanceList(
    final ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {
    // BEGIN, CR00199226, ASN
    final ViewDailyAttendanceDetails viewDailyAttendanceDetails = new ViewDailyAttendanceDetails();
    // END, CR00199226
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    viewDailyAttendanceDetails.fromDate = providerRosterLineItem.getServiceDateFrom();
    viewDailyAttendanceDetails.toDate = providerRosterLineItem.getServiceDateTo();
    if (null != providerRosterLineItem.getClient()) {
      viewDailyAttendanceDetails.clientName = providerRosterLineItem.getClient().getName();
    }

    SOAttendanceConfiguration soAttendanceConfig = sOAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      providerRosterLineItem.getRoster().getServiceOffering(),
      providerRosterLineItem.getRoster().getDateGenerated());

    if (null != soAttendanceConfig
      && soAttendanceConfig.isDailyAttendanceTrackingRequired()) {
      // Generate daily attendance dynamically using data using either the daily
      // attendance date input at facade level or from daily attendance entity
      // if records exist.
      dailyAttendanceDetailsList = generateDailyAttendance(
        providerRosterLineItem);
    }

    viewDailyAttendanceDetails.detailsList.assign(dailyAttendanceDetailsList);

    viewDailyAttendanceDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    viewDailyAttendanceDetails.dailyAttendanceDetails = WidgetHelper.convertDailyAttendanceToXml(
      dailyAttendanceDetailsList);
    viewDailyAttendanceDetails.rliVersionNo = providerRosterLineItem.getRLIVersionNo();

    return viewDailyAttendanceDetails;
  }

  // BEGIN, CR00199226, ASN
  /**
   * Retrieves the service dates for active daily attendance records.
   *
   * @param providerRosterLineItemImpl
   * Contains provider roster line item details.
   *
   * @return List of Daily Attendance details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ArrayList<curam.util.type.Date> serviceDatesForActiveDailyAttendance(
    final ProviderRosterLineItem providerRosterLineItemImpl)
    throws InformationalException, AppException {

    final ArrayList<curam.util.type.Date> serviceDateList = new ArrayList<curam.util.type.Date>();

    final Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItemImpl.getRosterLineItemID());

    for (final DailyAttendance dailyAttendance : sortDailyAttendanceByServiceDate(
      dailyAttendanceList)) {

      final ArrayList<curam.util.type.Date> serviceDate = new ArrayList<curam.util.type.Date>();

      // END, CR00199226
      if (RECORDSTATUSEntry.NORMAL.getCode().equals(
        dailyAttendance.getDtls().recordStatus)) {
        serviceDate.add(dailyAttendance.getServiceDate());
      }
      serviceDateList.addAll(serviceDate);
    }
    return serviceDateList;
  }

  // BEGIN, CR00233623, ASN
  /**
   * Validates records for reporting method of attendance.
   *
   * @param dailyAttendanceDetailsList
   * List containing the daily attendance details.
   * @param attendanceConfig
   * Hours enabled configuration for the attendance.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void validateForAttendanceReporting(
    final DailyAttendanceDetailsList dailyAttendanceDetailsList,
    final boolean attendanceConfig) throws AppException,
      InformationalException {

    int recordCounter = 0;

    for (DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {

      if (attendanceConfig) {

        boolean checkHoursAttended = false;
        boolean checkHoursAbsent = false;

        if (dailyAttendanceDetails.dtls.absenceReason.trim().length() > 0
          || dailyAttendanceDetails.dtls.numHoursAttended > 0
          || dailyAttendanceDetails.dtls.numMinutesAttended > 0) {
          checkHoursAttended = true;
        }

        if (dailyAttendanceDetails.dtls.numHoursAbsent > 0
          || dailyAttendanceDetails.dtls.numMinutesAbsent > 0) {
          checkHoursAbsent = true;
        }
        if (0 == dailyAttendanceDetails.dtls.attendance.trim().length()
          && (checkHoursAttended || checkHoursAbsent)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_DAILY_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

          ValidationHelper.failIfErrorsExist();
        }

        int timeAttendedEntered = dailyAttendanceDetails.dtls.numHoursAttended
          + dailyAttendanceDetails.dtls.numMinutesAttended;
        int timeAbsentEntered = dailyAttendanceDetails.dtls.numHoursAbsent
          + dailyAttendanceDetails.dtls.numMinutesAbsent;

        if (ATTENDANCEEntry.PRESENT.getCode().equals(
          dailyAttendanceDetails.dtls.attendance)
            && 0 == timeAttendedEntered) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_HOURS_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_PRESENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        }
        if (ATTENDANCEEntry.ABSENT.getCode().equals(
          dailyAttendanceDetails.dtls.attendance)
            && 0 == timeAbsentEntered) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_HOURS_NOT_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_ABSENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        }
        if (ATTENDANCEEntry.PARTIALLYPRESENT.getCode().equals(
          dailyAttendanceDetails.dtls.attendance)
            && (0 == timeAttendedEntered || 0 == timeAbsentEntered)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_HOURS_ATTENDED_NOT_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_PARTIALLY_PRESENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        }
 
      } else {
        if (0 == dailyAttendanceDetails.dtls.attendance.trim().length()
          && dailyAttendanceDetails.dtls.absenceReason.trim().length() > 0) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_FOR_HOURS_DISABLED_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

          ValidationHelper.failIfErrorsExist();
        }
      }

      if (ATTENDANCEEntry.ABSENT.getCode().equals(
        dailyAttendanceDetails.dtls.attendance)
          || ATTENDANCEEntry.PARTIALLYPRESENT.getCode().equals(
            dailyAttendanceDetails.dtls.attendance)) {
        if (StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.absenceReason)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ENTDAILYATTENDANCEExceptionCreator.ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_ABSENT_OR_PARTIALLY_PRESENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
        }
      }

      if (ATTENDANCEEntry.PRESENT.getCode().equals(
        dailyAttendanceDetails.dtls.attendance)
          && !StringUtil.isNullOrEmpty(
            dailyAttendanceDetails.dtls.absenceReason)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTDAILYATTENDANCEExceptionCreator.ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

      }
     
      if (StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.attendance)) {

        recordCounter = recordCounter + 1;
      }
    }
    if (recordCounter == dailyAttendanceDetailsList.details.size()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
      ValidationHelper.failIfErrorsExist();
    }
  }

  // END, CR00233623
  
  // BEGIN, CR00199226, ASN
  /**
   * Lists the history changes for daily attendance. The list ordered by
   * creation date, earliest first.
   *
   * @param providerRosterLineItemKey
   * Contains provider roster line item key.
   *
   * @return List of all daily attendance history.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public DailyAttendanceHistoryList listDailyAttendanceHistory(
    final ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {
    final DailyAttendanceHistoryList dailyAttendanceHistoryList = new DailyAttendanceHistoryList();

    final ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    // Set the daily attendance indicator.
    dailyAttendanceHistoryList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);
    DailyAttendanceHistoryDtlsList dailyAttendanceHistoryDtlsList = new DailyAttendanceHistoryDtlsList();

    final Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());

    Locale locale = new Locale(TransactionInfo.getProgramLocale());
    DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG, locale);

    DailyAttendanceHistory dailyAttendanceHistory;

    for (final DailyAttendance dailyAttendance : dailyAttendanceList) {
      dailyAttendanceHistoryDtlsList = dailyAttendanceHistoryDAO.searchBy(
        dailyAttendance);

      for (final DailyAttendanceHistoryDtls dailyAttendanceHistoryDetails:dailyAttendanceHistoryDtlsList.dtls.items()) {

        // BEGIN, CR00304523, SSK
        dailyAttendanceHistory = new DailyAttendanceHistory();
        dailyAttendanceHistory.dailyAttendanceHistoryDetails.serviceDate = dailyAttendanceHistoryDetails.serviceDate;
        // END, CR00304523
        java.util.Date serviceDate = new java.util.Date(
          dailyAttendanceHistoryDetails.serviceDate.asLong());
        String formattedServiceDate = dateFormat.format(serviceDate);

        dailyAttendanceHistory.serviceDateString = formattedServiceDate;
        if (dailyAttendanceHistoryDetails.unitsAttended == 0) {
          dailyAttendanceHistory.unitsAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceHistory.unitsAttendedString = String.valueOf(
            dailyAttendanceHistoryDetails.unitsAttended);
        }
        if (dailyAttendanceHistoryDetails.unitsUnattended == 0) {
          dailyAttendanceHistory.unitsUnAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceHistory.unitsUnAttendedString = String.valueOf(
            dailyAttendanceHistoryDetails.unitsUnattended);
        }
        
        // BEGIN, CR00233623, ASN
        dailyAttendanceHistory.hoursAttended = getFormattedTimeDuration(
          Integer.parseInt(dailyAttendanceHistoryDetails.totalHours),
          Integer.parseInt(dailyAttendanceHistoryDetails.totalMinutes));

        dailyAttendanceHistory.hoursUnAttended = getFormattedTimeDuration(
          Integer.parseInt(dailyAttendanceHistoryDetails.hoursAbsent),
          Integer.parseInt(dailyAttendanceHistoryDetails.minutesAbsent));
        
        dailyAttendanceHistory.dailyAttendanceHistoryDetails.dateTimeChanged = dailyAttendanceHistoryDetails.dateTimeChanged;
        
        dailyAttendanceHistory.dailyAttendanceHistoryDetails.userName = dailyAttendanceHistoryDetails.userName;
         
        dailyAttendanceHistory.dailyAttendanceHistoryDetails.absenceReason = dailyAttendanceHistoryDetails.absenceReason;
        
        dailyAttendanceHistory.dailyAttendanceHistoryDetails.attendance = dailyAttendanceHistoryDetails.attendance;
        // END, CR00233623

        dailyAttendanceHistory.dailyAttendanceHistoryDetails = dailyAttendanceHistoryDetails;
        dailyAttendanceHistoryList.details.addRef(dailyAttendanceHistory);
        
      }
    }
    
    // BEGIN, CR00233623, ASN
    List<PRLIHistory> prliHistories = prliHistoryDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);

    for (final PRLIHistory prliHistory : prliHistories) {

      if (0 != prliHistory.getPRLICorrection().getID()) {

        PRLICorrection prliCorrection = prliCorrectionDAO.get(
          prliHistory.getPRLICorrection().getID());

        if (!PRLICorrectionStatusEntry.DENIED.equals(
          prliCorrection.getLifecycleState())) {

          Set<DailyAttendanceCorrectionHistory> DailyAttendanceCorrectionHistories = dailyAttendanceCorrectionHistoryDAO.searchByPRLICorrection(
            prliCorrection);

          for (final DailyAttendanceCorrectionHistory dailyAttendanceCorrectionHistory : DailyAttendanceCorrectionHistories) {
            // BEGIN, CR00304523, SSK
            dailyAttendanceHistory = new DailyAttendanceHistory();
            dailyAttendanceHistory.dailyAttendanceHistoryDetails.serviceDate = dailyAttendanceCorrectionHistory.getServiceDate(); 
            // END, CR00304523

            java.util.Date serviceDate = new java.util.Date(
              dailyAttendanceCorrectionHistory.getServiceDate().asLong());
            String formattedServiceDate = dateFormat.format(serviceDate);

            dailyAttendanceHistory.serviceDateString = formattedServiceDate;

            if (0 == dailyAttendanceCorrectionHistory.getUnitsAttended()) {

              dailyAttendanceHistory.unitsAttendedString = CPMConstants.kEmptyString;
            } else {
              dailyAttendanceHistory.unitsAttendedString = String.valueOf(
                dailyAttendanceCorrectionHistory.getUnitsAttended());
            }
            if (0 == dailyAttendanceCorrectionHistory.getUnitsUnattended()) {
              dailyAttendanceHistory.unitsUnAttendedString = CPMConstants.kEmptyString;
            } else {
              dailyAttendanceHistory.unitsUnAttendedString = String.valueOf(
                dailyAttendanceCorrectionHistory.getUnitsUnattended());
            }

            dailyAttendanceHistory.hoursAttended = getFormattedTimeDuration(
              dailyAttendanceCorrectionHistory.getTotalHours(),
              dailyAttendanceCorrectionHistory.getTotalMinutes());
            dailyAttendanceHistory.hoursUnAttended = getFormattedTimeDuration(
              dailyAttendanceCorrectionHistory.getHoursAbsent(),
              dailyAttendanceCorrectionHistory.getMinutesAbsent());

            dailyAttendanceHistory.dailyAttendanceHistoryDetails.dateTimeChanged = dailyAttendanceCorrectionHistory.getDateTimeChanged();

            dailyAttendanceHistory.dailyAttendanceHistoryDetails.userName = dailyAttendanceCorrectionHistory.getUserName();
            dailyAttendanceHistory.dailyAttendanceHistoryDetails.absenceReason = dailyAttendanceCorrectionHistory.getAbsenceReason().getCode();

            dailyAttendanceHistory.dailyAttendanceHistoryDetails.attendance = dailyAttendanceCorrectionHistory.getAttendance().getCode();

            dailyAttendanceHistoryList.details.addRef(dailyAttendanceHistory);
          }
          break;
        }
      }
    }
    // END, CR00233623
    return sortDailyAttendanceHistoryByCreationDate(dailyAttendanceHistoryList);
  }

  // BEGIN, CR00233623, ASN
  /**
   * Lists the provider roster line item status history.
   *
   * @param providerRosterLineItemKey
   * Contains provider roster line item ID.
   *
   * @return List of all provider roster line item history.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLIHistoryWithStatusDetailsList listHistoryForPRLI(
    final ProviderRosterLineItemKey providerRosterLineItemKey)
    throws AppException, InformationalException {

    PRLIHistoryWithStatusDetailsList prliHistoryWithStatusDetailsList = new PRLIHistoryWithStatusDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    List<PRLIHistory> historyDetailsList = prliHistoryDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);

    for (final PRLIHistory prliHistory : historyDetailsList) {

      RosterLineItemHistory rosterLineItemHistory = prliHistory.getRosterLineItemHistory();

      prliHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
        getProviderRosterLineitemHistoryDetails(prliHistory,
        rosterLineItemHistory));

    }
    prliHistoryWithStatusDetailsList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    return filterPRLIHistoryRecords(prliHistoryWithStatusDetailsList);
  }

  /**
   * Validates the actual units against the expected units.
   *
   * @param providerRosterLineItemKey
   * Contains provider roster line item ID.
   *
   * @return The Informational messages are added, when the actual units more
   * than the expected units.
   *
   * @throws InformationalException
   * {@link ROSTER#INF_ROSTER_LINE_ITEM_XFV_ACTUAL_UNITS_MORE_THAN_EXPECTED_UNITS}
   * If actual units more than expected units.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationalMessageList validateTotalAndExpectedUnits(
    final ProviderRosterLineItemKey providerRosterLineItemKey)
    throws AppException, InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);
    boolean unitsExceededInd = false;

    if (providerRosterLineItem.getAutoGeneratedInd()
      && providerRosterLineItem.getUnitsDelivered()
        > providerRosterLineItem.getExpectedUnits()) {
      unitsExceededInd = true;
    } else {
      unitsExceededInd = false;
    }
    if (unitsExceededInd) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();
      AppException appException = ROSTERExceptionCreator.INF_ROSTER_LINE_ITEM_XFV_ACTUAL_UNITS_MORE_THAN_EXPECTED_UNITS();

      informationalManager.addInformationalMsg(appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning);

      String warnings[] = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        InformationalMessage infoMessage = new InformationalMessage();

        infoMessage.messageTest = warnings[i];
        informationalMessageList.dtls.addRef(infoMessage);
      }
    }
    return informationalMessageList;
  }

  /**
   * Retrieves the roster line item modification details.
   *
   * @param prliHistoryKey
   * Contains provider roster line item history ID.
   * @return The provider roster line item history details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLIHistoryDetails viewRosterLineItemModification(
    final PRLIHistoryKey prliHistoryKey) throws AppException,
      InformationalException {
    PRLIHistory prliHistory = prliHistoryDAO.get(prliHistoryKey.prliHistoryID);
    PRLIHistoryDetails prliHistoryDetails = new PRLIHistoryDetails();

    RosterLineItemHistory rosterLineItemHistory = prliHistory.getRosterLineItemHistory();

    prliHistoryDetails.prliDtls = getPRLIHistoryDetails(prliHistory);
    prliHistoryDetails.rliDtls = getRLIHistoryDetails(rosterLineItemHistory);

    if (prliHistoryDetails.prliDtls.addressID != 0) {

      Address addressObj = AddressFactory.newInstance();

      OtherAddressData formattedAddressData = new OtherAddressData();

      formattedAddressData.addressData = prliHistory.getProviderRosterLineItem().getAddressData();

      addressObj.getAddressStrings(formattedAddressData);
      prliHistoryDetails.addressData = formattedAddressData.addressData;

    }

    return prliHistoryDetails;
  }

  // END, CR00233623
  /**
   * Sorts the daily attendances history list by Date and Time Changed, latest
   * first.
   *
   * @param dailyAttendanceHistoryList
   * Contains unsorted daily attendance details list.
   *
   * @return List of daily attendance history.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  protected DailyAttendanceHistoryList sortDailyAttendanceHistoryByCreationDate(
    final DailyAttendanceHistoryList dailyAttendanceHistoryList) {

    final DailyAttendanceHistoryList dailyAttendanceHistoryDetailsSortedList = new DailyAttendanceHistoryList();
    final List<DailyAttendanceHistory> dailyAttendanceHistoryDetailsSortebleList = new ArrayList<DailyAttendanceHistory>();

    for (final DailyAttendanceHistory dailyAttendanceHistory:dailyAttendanceHistoryList.details.items()) {
      dailyAttendanceHistoryDetailsSortebleList.add(dailyAttendanceHistory);
    }

    // Sorting the daily attendances history list by Date and
    // Time Changed, latest first.
    if (dailyAttendanceHistoryDetailsSortebleList.size() > 0) {
      Collections.sort(dailyAttendanceHistoryDetailsSortebleList,
        new Comparator<DailyAttendanceHistory>() {
        public int compare(final DailyAttendanceHistory lhs,
          final DailyAttendanceHistory rhs) {
          return rhs.dailyAttendanceHistoryDetails.dateTimeChanged.compareTo(
            lhs.dailyAttendanceHistoryDetails.dateTimeChanged);
        }
      });
    }

    dailyAttendanceHistoryDetailsSortedList.details.addAll(
      dailyAttendanceHistoryDetailsSortebleList);
    
    return dailyAttendanceHistoryDetailsSortedList;
  }

  /**
   * Generates daily attendance correction for a client who is added to a
   * roster, for each day of the roster line item period in case no daily
   * attendance records exists in the system for a service date.
   *
   * @param providerRosterLineItem
   * Contains provider roster line item correction details.
   * @param isReporting
   * Checks the value of 'Reporting' indicator.
   * @param isPlannedUnitsDefaulted
   * Checks the value of 'Planned Units Defaulted' indicator.
   * @param startDate
   * Service date for which records need to be generated.
   *
   * @return List of Daily Attendance details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected DailyAttendanceDetails generateUnstoredDailyAttendanceDetails(
    final ProviderRosterLineItem providerRosterLineItem,
    final boolean isReporting, final boolean isPlannedUnitsDefaulted,
    final curam.util.type.Date startDate) throws AppException,
      InformationalException {

    final DailyAttendanceDetails dailyAttendanceDetails = new DailyAttendanceDetails();

    dailyAttendanceDetails.dtls.rosterLineItemID = providerRosterLineItem.getRosterLineItemID();
    dailyAttendanceDetails.dtls.recordStatus = RECORDSTATUSEntry.NORMAL.getCode();

    ArrayList<curam.util.type.Date> serviceDateList = new ArrayList<curam.util.type.Date>();

    serviceDateList = serviceDatesForActiveDailyAttendance(
      providerRosterLineItem);

    final Locale locale = new Locale(TransactionInfo.getProgramLocale());
    final DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG,
      locale);

    if (RECORDSTATUSEntry.NORMAL.getCode().equals(
      dailyAttendanceDetails.dtls.recordStatus)) {

      dailyAttendanceDetails.dtls.serviceDate = startDate;

      // BEGIN, CR00303745, SSK
      dailyAttendanceDetails.serviceDateString = curam.util.resources.Locale.getFormattedDateTime(
        dailyAttendanceDetails.dtls.serviceDate.getDateTime(),
        curam.util.resources.Locale.Date_ymd);
      // END, CR00303745

      if (isReporting) {
        dailyAttendanceDetails.dtls.unitsAttended = (short) 0;
        dailyAttendanceDetails.dtls.unitsUnattended = (short) 0;

      }
      if (0 == dailyAttendanceDetails.dtls.unitsAttended) {
        dailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
      } else {
        dailyAttendanceDetails.unitsAttendedString = String.valueOf(
          dailyAttendanceDetails.dtls.unitsAttended);
      }
      if (0 == dailyAttendanceDetails.dtls.unitsUnattended) {
        dailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
      } else {
        dailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
          dailyAttendanceDetails.dtls.unitsUnattended);
      }
      dailyAttendanceDetails.dtls.creationDate = curam.util.type.Date.getCurrentDate();

      // If the service authorization is for the single day set the expected
      // units to units authorized, units attended to expected units and
      // daily attendance as 'Present'.
      final Set<PRLISALILink> prliSALILinks = prliSALILinkDAO.searchByProviderRosterLineItem(
        providerRosterLineItem);

      for (final PRLISALILink prliSALILink : prliSALILinks) {

        providerRosterLineItem.setServiceAuthorizationLineItem(
          prliSALILink.getServiceAuthorizationLineItem());

        if (null != providerRosterLineItem.getServiceAuthorizationLineItem()) {
          
          // BEGIN, CR00206362, ASN
          if (1
            == providerRosterLineItem.getServiceAuthorizationLineItem().getDateRange().length()
              && providerRosterLineItem.getServiceAuthorizationLineItem().getDateRange().contains(
                startDate)) {
            // END, CR00206362
            int expectedUnits = 0;

            if (isReporting) {
              expectedUnits = providerRosterLineItem.getServiceAuthorizationLineItem().getUnitsAuthorized();
              dailyAttendanceDetails.dtls.expectedUnits = (short) expectedUnits;

              if (0 == dailyAttendanceDetails.dtls.expectedUnits) {
                dailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
              } else {
                dailyAttendanceDetails.expectedUnitsString = String.valueOf(
                  expectedUnits);
              }
            }

            if (isPlannedUnitsDefaulted && 0 == serviceDateList.size()) {

              if (isReporting) {
                if (startDate.before(
                  curam.util.type.Date.getCurrentDate().addDays(1))) {
                  dailyAttendanceDetails.dtls.unitsAttended = (short) expectedUnits;
                  dailyAttendanceDetails.unitsAttendedString = String.valueOf(
                    expectedUnits);

                  dailyAttendanceDetails.dtls.attendance = ATTENDANCEEntry.PRESENT.getCode();
                }
              }
            }
          }
        }
      }
    }
    return dailyAttendanceDetails;
  }

  /**
   * Generates daily attendance for a client who is added to a roster, for each
   * day of the roster line item period in case daily attendance records exists
   * in the system.
   *
   * @param dailyAttendance
   * Contains Daily attendance details.
   *
   * @return List of Daily Attendance details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected DailyAttendanceDetails storedDailyAttendanceDetails(
    final DailyAttendance dailyAttendance) throws AppException,
      InformationalException {

    final DailyAttendanceDetails storedDailyAttendanceDetails = new DailyAttendanceDetails();

    storedDailyAttendanceDetails.dtls.serviceDate = dailyAttendance.getServiceDate();

    // BEGIN, CR00303745, SSK
    storedDailyAttendanceDetails.serviceDateString = curam.util.resources.Locale.getFormattedDateTime(
      dailyAttendance.getServiceDate().getDateTime(),
      curam.util.resources.Locale.Date_ymd);
    // END, CR00303745

    storedDailyAttendanceDetails.dtls.attendance = dailyAttendance.getAttendance().getCode();
    storedDailyAttendanceDetails.dtls.absenceReason = dailyAttendance.getAbsenceReason().getCode();
    if (0 == dailyAttendance.getExpectedUnits()) {
      storedDailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
    } else {
      storedDailyAttendanceDetails.expectedUnitsString = String.valueOf(
        dailyAttendance.getExpectedUnits());
    }
    if (0 == dailyAttendance.getUnitsAttended()) {
      storedDailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
    } else {
      storedDailyAttendanceDetails.unitsAttendedString = String.valueOf(
        dailyAttendance.getUnitsAttended());
    }
    if (0 == dailyAttendance.getUnitsUnattended()) {
      storedDailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
    } else {
      storedDailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
        dailyAttendance.getUnitsUnattended());
    }

    // BEGIN, CR00233623, ASN
    storedDailyAttendanceDetails.dtls.numHoursAttended = dailyAttendance.getNumOfHoursAttended();
    storedDailyAttendanceDetails.dtls.numMinutesAttended = dailyAttendance.getNumOfMinutesAttended();
    storedDailyAttendanceDetails.dtls.numHoursAbsent = dailyAttendance.getNumOfHoursAbsent();
    storedDailyAttendanceDetails.dtls.numMinutesAbsent = dailyAttendance.getNumOfMinutesAbsent();
    // END, CR00233623
    storedDailyAttendanceDetails.dtls.dailyAttendanceID = dailyAttendance.getID();
    storedDailyAttendanceDetails.dtls.versionNo = dailyAttendance.getVersionNo();
    storedDailyAttendanceDetails.dtls.rosterLineItemID = dailyAttendance.getRosterLineItem();
    return storedDailyAttendanceDetails;
  }
  
  /**
   * Sets daily attendance details.
   *
   *
   * @param dailyAttendanceInstance
   * Contains Daily attendance object.
   * @param dailyAttendanceDetails
   * Contains daily attendance details.
   * @param attendanceConfig
   * Checks value of 'Hours Enabled' indicator.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void setDailyAttendanceDetails(
    final DailyAttendance dailyAttendanceInstance,
    final DailyAttendanceDetails dailyAttendanceDetails,
    final boolean attendanceConfig) {
    
    dailyAttendanceInstance.setServiceDate(
      dailyAttendanceDetails.dtls.serviceDate);

    // BEGIN, CR00233623, ASN
    int calculateValues = dailyAttendanceDetails.dtls.unitsAttended
      + dailyAttendanceDetails.dtls.unitsUnattended
      + dailyAttendanceDetails.dtls.numHoursAttended
      + dailyAttendanceDetails.dtls.numMinutesAttended
      + dailyAttendanceDetails.dtls.numHoursAbsent
      + dailyAttendanceDetails.dtls.numMinutesAbsent;

    if (0 == calculateValues) {
      dailyAttendanceInstance.setAttendance(
        ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
    }
    dailyAttendanceInstance.setAbsenceReason(
      ATTENDANCEABSENCEREASONEntry.get(
        dailyAttendanceDetails.dtls.absenceReason));

    int totalUnitsEntered = dailyAttendanceDetails.dtls.unitsAttended
      + dailyAttendanceDetails.dtls.unitsUnattended;

    if (totalUnitsEntered > 0) {
      dailyAttendanceInstance.setUnitsAttended(
        dailyAttendanceDetails.dtls.unitsAttended);
      dailyAttendanceInstance.setUnitsUnattended(
        dailyAttendanceDetails.dtls.unitsUnattended);
    }

    if (attendanceConfig) {
      dailyAttendanceInstance.setNumOfHoursAttended(
        dailyAttendanceDetails.dtls.numHoursAttended);
      dailyAttendanceInstance.setNumOfMinutesAttended(
        dailyAttendanceDetails.dtls.numMinutesAttended);
      dailyAttendanceInstance.setNumOfHoursAbsent(
        dailyAttendanceDetails.dtls.numHoursAbsent);
      dailyAttendanceInstance.setNumOfMinutesAbsent(
        dailyAttendanceDetails.dtls.numMinutesAbsent);

    }
    // END, CR00233623
    dailyAttendanceInstance.setProgress(dailyAttendanceDetails.dtls.progress);
    dailyAttendanceInstance.setProgressReason(
      dailyAttendanceDetails.dtls.progressReason);
    dailyAttendanceInstance.setStatus(
      RECORDSTATUSEntry.get(dailyAttendanceDetails.dtls.recordStatus));

    dailyAttendanceInstance.setCreationDate(
      dailyAttendanceDetails.dtls.creationDate);
    dailyAttendanceInstance.setCreatedBySystem(
      dailyAttendanceDetails.dtls.createdBySystem);
    dailyAttendanceInstance.setVersionNo(dailyAttendanceDetails.dtls.versionNo);

  }

  // BEGIN, CR00233623, ASN
  /**
   * Filters the provider roster line item and correction history to display
   * valid history records.
   *
   * @param prliHistoryWithStatusDetailsList
   * Provider roster line item and correction history details list.
   *
   * @return Filtered list of Provider roster line item and correction history
   * details.
   */
  protected PRLIHistoryWithStatusDetailsList filterPRLIHistoryRecords(
    final PRLIHistoryWithStatusDetailsList prliHistoryWithStatusDetailsList) {

    PRLIHistoryWithStatusDetailsList sortedPRLIHistoryWithStatusDetailsList = new PRLIHistoryWithStatusDetailsList();
    boolean inCompleteHistory = false;
    boolean openPRLIHistoryIncluded = false;

    PRLIHistoryWithStatusDetails prliHistoryWithStatusCompletedHistoryDetails = null;

    for (PRLIHistoryWithStatusDetails prliHistoryWithStatusDetails : sortProviderRosterlineItemHistory(
      prliHistoryWithStatusDetailsList)) {

      if (!PRLIStatusEntry.COMPLETE.getCode().equals(
        prliHistoryWithStatusDetails.prliHistoryDetails.status)) {

        if (!inCompleteHistory) {

          if (PRLIStatusEntry.OPEN.getCode().equals(
            prliHistoryWithStatusDetails.prliHistoryDetails.status)) {

            if (!openPRLIHistoryIncluded) {

              sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
                prliHistoryWithStatusDetails);
              openPRLIHistoryIncluded = true;
            }
          } else {
            sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
              prliHistoryWithStatusDetails);
          }
        } else {
          if (0
            != prliHistoryWithStatusDetails.prliHistoryDetails.prliCorrectionID) {

            if (PRLIStatusEntry.OPEN.getCode().equals(
              prliHistoryWithStatusDetails.prliHistoryDetails.status)) {

              if (!isCorrectionCanceled(prliHistoryWithStatusDetails)) {
                sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
                  prliHistoryWithStatusDetails);
              }
            } else if (PRLIStatusEntry.PENDINGAPPROVAL.getCode().equals(
              prliHistoryWithStatusDetails.prliHistoryDetails.status)) {

              if (isCorrectionDenied(prliHistoryWithStatusDetails)) {
                prliHistoryWithStatusDetails.isStatusDeniedInd = true;
              }
              sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
                prliHistoryWithStatusDetails);

              if (prliHistoryWithStatusDetails.isStatusDeniedInd
                && null != prliHistoryWithStatusCompletedHistoryDetails) {

                prliHistoryWithStatusCompletedHistoryDetails.rliHistory.dateTimeChanged = prliHistoryWithStatusDetails.rliHistory.dateTimeChanged;

                sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
                  prliHistoryWithStatusCompletedHistoryDetails);
              }
            }
          }
        }

      } else {

        inCompleteHistory = true;

        prliHistoryWithStatusCompletedHistoryDetails = prliHistoryWithStatusDetails;

        sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
          prliHistoryWithStatusDetails);

      }
    }

    Collections.reverse(
      sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails);
    
    sortedPRLIHistoryWithStatusDetailsList.dailyAttendanceLinkInd = prliHistoryWithStatusDetailsList.dailyAttendanceLinkInd;

    return sortedPRLIHistoryWithStatusDetailsList;
  }

  /**
   * Sorts a set of provider roster line item details into a sorted list by
   * latest date changed for display.
   *
   * @param prliHistoryWithStatusDetailsList
   * The set of provider roster line item details.
   *
   * @return Sorted list of provider roster line item records for display.
   */
  protected List<PRLIHistoryWithStatusDetails> sortProviderRosterlineItemHistory(
    final PRLIHistoryWithStatusDetailsList prliHistoryWithStatusDetailsList) {

    List<PRLIHistoryWithStatusDetails> sortedPRLIHistoryWithStatusDetails = Arrays.asList(
      prliHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.items());

    Collections.sort(sortedPRLIHistoryWithStatusDetails,
      new Comparator<PRLIHistoryWithStatusDetails>() {

      public int compare(final PRLIHistoryWithStatusDetails lhs,
        final PRLIHistoryWithStatusDetails rhs) {

        return lhs.rliHistory.dateTimeChanged.compareTo(
          rhs.rliHistory.dateTimeChanged);

      }
    });
    return sortedPRLIHistoryWithStatusDetails;
  }

  /**
   * Checks if the PRLI correction is canceled.
   *
   * @param prliHistoryWithStatusDetails
   * provider roster line item correction history details.
   *
   * @return True if correction is canceled otherwise false.
   */
  protected boolean isCorrectionCanceled(
    final PRLIHistoryWithStatusDetails prliHistoryWithStatusDetails) {
    PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliHistoryWithStatusDetails.prliHistoryDetails.prliCorrectionID);

    if (0 != prliHistoryWithStatusDetails.prliHistoryDetails.prliCorrectionID
      && PRLICorrectionStatusEntry.CANCELED.getCode().equals(
        prliCorrection.getLifecycleState().getCode())) {
      return true;
    }
    return false;
  }

  /**
   * Checks if the correction is denied.
   *
   * @param prliHistoryWithStatusDetails
   * Provider roster line item and correction history details.
   *
   * @return True if correction is denied otherwise false.
   */
  protected boolean isCorrectionDenied(
    final PRLIHistoryWithStatusDetails prliHistoryWithStatusDetails) {

    PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliHistoryWithStatusDetails.prliHistoryDetails.prliCorrectionID);

    if (0 != prliHistoryWithStatusDetails.prliHistoryDetails.prliCorrectionID
      && PRLICorrectionStatusEntry.DENIED.getCode().equals(
        prliCorrection.getLifecycleState().getCode())) {
      return true;
    }
    return false;
  }
  
  /**
   * Formats the duration in "HM hours and MM minutes" format.
   *
   * @param hours
   * Hours of attendance or absence.
   * @param minutes
   * Minutes of attendance or absence.
   *
   * @return Formatted duration.
   */
  protected String getFormattedTimeDuration(final int hours, final int minutes) {

    String formattedHrsMinutes = CPMConstants.kEmptyString;
    String formattedMinutes = CPMConstants.kEmptyString;
    String formattedHrs = CPMConstants.kEmptyString;
    boolean appendMinutesToHrs = false;

    if (0 != minutes) {

      // If minutes is 30, append to half an hour.
      if (30 == minutes) {

        appendMinutesToHrs = true;

      } else {

        if (CPMConstants.kMinturesLength == Integer.toString(minutes).length()
          && CPMConstants.kZeroChar
            == Integer.toString(minutes).charAt(CPMConstants.kFirstCharIndex)) {
          formattedMinutes = Integer.toString(minutes).charAt(
            CPMConstants.kSecondCharIndex)
              + CPMConstants.kSpace
              + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_MINUTES_ATTENDED_UNATTENDED).getMessage();
        } else {
          formattedMinutes = Integer.toString(minutes) + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_MINUTES_ATTENDED_UNATTENDED).getMessage();
        }
      }
    }

    if (0 != hours) {
      if (CPMConstants.kMinturesLength == Integer.toString(hours).length()
        && Integer.toString(hours).charAt(CPMConstants.kFirstCharIndex)
          == CPMConstants.kZeroChar) {
        formattedHrs = Integer.toString(hours).charAt(
          CPMConstants.kSecondCharIndex)
            + CPMConstants.kEmptyString;
      } else {
        formattedHrs = Integer.toString(hours);
      }
    }
    if (appendMinutesToHrs) {
      if (CPMConstants.kEmptyString.equals(formattedHrs)) {
        formattedHrs = CPMConstants.kZeroChar + CPMConstants.kEmptyString;
      }

      formattedHrsMinutes = formattedHrs + CPMConstants.khalfAnHour
        + CPMConstants.kSpace
        + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_ATTENDED_UNATTENDED).getMessage();

    } else {
      if (!CPMConstants.kEmptyString.equals(formattedHrs)) {
        if (!CPMConstants.kEmptyString.equals(formattedMinutes)) {
          formattedHrsMinutes = formattedHrs + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_AND_MINUTES_ATTENDED_UNATTENDED).getMessage()
            + formattedMinutes;
        } else {
          formattedHrsMinutes = formattedHrs + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_ATTENDED_UNATTENDED).getMessage();
        }
      } else if (!CPMConstants.kEmptyString.equals(formattedMinutes)) {

        formattedHrsMinutes = formattedMinutes;

      }
    }

    return formattedHrsMinutes;
  }
  // END, CR00233623
}
