/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import com.google.inject.Inject;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.TrainingCreditDetails;
import curam.cpm.facade.struct.TrainingCreditDetailsList;
import curam.cpm.facade.struct.TrainingCreditKey;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.TrainingKey;
import curam.message.impl.TRAININGCREDITExceptionCreator;
import curam.provider.impl.CPMProviderCategoryNameEntry;
import curam.provider.impl.CPMProviderTypeNameEntry;
import curam.provider.impl.PeriodUnitEntry;
import curam.provider.impl.TrainingCreditTypeEntry;
import curam.training.impl.Training;
import curam.training.impl.TrainingCreditDAO;
import curam.training.impl.TrainingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


/**
 * Facade class having API's for managing Training Credit. Training Credit is a
 * credit for the training provided. For example, the Child Care Early Years
 * training is common to both child care and foster care related certifications.
 * For the category child care, completing the Child Care Early Years training
 * will earn more credits, and have a greater period of validity, than for the
 * category foster care.
 */
public abstract class MaintainTrainingCredit extends curam.cpm.facade.base.MaintainTrainingCredit {

  /**
   * Reference to TrainingCredit DAO
   */
  @Inject
  protected TrainingCreditDAO trainingCreditDAO;

  /**
   * Reference to TrainingCredit DAO
   */
  @Inject
  protected TrainingDAO trainingDAO;

  /**
   * Constructs a bootstrap dependency injection for this class
   */
  public MaintainTrainingCredit() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Cancels the specified training credit for a training.
   *
   * @param keyVersion
   * Contains training credit ID and version number.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public void cancelTrainingCredit(KeyVersionDetails keyVersion)
    throws AppException, InformationalException {

    curam.training.impl.TrainingCredit trainingCredit = trainingCreditDAO.get(
      keyVersion.id);

    trainingCredit.cancel(keyVersion.version);
  }

  /**
   * Creates a training credit for a training with the specified training credit
   * details.
   *
   * @param details
   * Contains training credit details.
   * @return The training credit ID of the newly created training credit.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public TrainingCreditKey createTrainingCredit(TrainingCreditDetails details)
    throws AppException, InformationalException {

    curam.training.impl.TrainingCredit trainingCredit = trainingCreditDAO.newInstance();

    // BEGIN, CR00112601, GP
    if (!PeriodUnitEntry.NOT_SPECIFIED.getCode().equals(
      details.details.validityPeriodUnit)
        && 0 == details.validityPeriodString.length()) {
      // END, CR00112601, GP

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGCREDITExceptionCreator.ERR_TRAININGCREDIT_XFV_VALIDITY_PERIOD_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    ValidationHelper.failIfErrorsExist();

    setTrainingCreditFields(trainingCredit, details);

    trainingCredit.insert();

    TrainingCreditKey trainingCreditKey = new TrainingCreditKey();

    trainingCreditKey.key.trainingCreditID = trainingCredit.getID();
    return trainingCreditKey;
  }

  /**
   * Lists all the active training credits for a training.
   *
   * @param key
   * Contains the training ID.
   * @return The list of active training credits.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public TrainingCreditDetailsList listTrainingCreditsForTraining(
    TrainingKey key) throws AppException, InformationalException {

    TrainingCreditDetailsList trainingCreditDetailsList = new TrainingCreditDetailsList();

    Training training = trainingDAO.get(key.trainingID);
    // BEGIN CR00112382, NK
    // Retrieve all training credits for a training.
    List<curam.training.impl.TrainingCredit> trainingCredits = sortTrainingCredits(
      trainingCreditDAO.searchBy(training));

    // END CR00112382
    for (final curam.training.impl.TrainingCredit trainingCredit : trainingCredits) {
      trainingCreditDetailsList.details.addRef(
        getTrainingCreditFields(trainingCredit));
    }

    return trainingCreditDetailsList;
  }

  /**
   * Modifies a training credit for a training with the modified training credit
   * details.
   *
   * @param details
   * Contains training credit details to be modified.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public void updateTrainingCredit(TrainingCreditDetails details)
    throws AppException, InformationalException {
    curam.training.impl.TrainingCredit trainingCredit = trainingCreditDAO.get(
      details.details.trainingCreditID);

    // BEGIN, CR00112601, GP
    if (!PeriodUnitEntry.NOT_SPECIFIED.getCode().equals(
      details.details.validityPeriodUnit)
        && 0 == details.validityPeriodString.length()) {
      // END, CR00112601

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGCREDITExceptionCreator.ERR_TRAININGCREDIT_XFV_VALIDITY_PERIOD_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();

    setTrainingCreditFields(trainingCredit, details);

    trainingCredit.modify(details.details.versionNo);
  }

  /**
   * Retrieves the training credit details for the specified training credit ID.
   *
   * @param key
   * Contains training credit ID.
   * @return The training credit details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public TrainingCreditDetails viewTrainingCredit(TrainingCreditKey key)
    throws AppException, InformationalException {

    curam.training.impl.TrainingCredit trainingCredit = trainingCreditDAO.get(
      key.key.trainingCreditID);

    return getTrainingCreditFields(trainingCredit);
  }

  /**
   * Sets the training credit details for a training.
   *
   * @param trainingCredit
   * An instance of Training Credit.
   * @param trainingCreditDetails
   * The training credit details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setTrainingCreditFields(
    // END, CR00177241
    final curam.training.impl.TrainingCredit trainingCredit,
    final TrainingCreditDetails trainingCreditDetails) throws AppException,
      InformationalException {

    // Set the training credit details to Training Credit instance.
    trainingCredit.setValidityPeriod(
      trainingCreditDetails.details.validityPeriod);
    trainingCredit.setType(
      TrainingCreditTypeEntry.get(trainingCreditDetails.details.type));
    trainingCredit.setTraining(
      trainingDAO.get(trainingCreditDetails.details.trainingID));
    trainingCredit.setValidityPeriodUnit(
      PeriodUnitEntry.get(trainingCreditDetails.details.validityPeriodUnit));
    trainingCredit.setValue(trainingCreditDetails.details.value);
    if (!CPMConstants.kEmptyString.equals(
      trainingCreditDetails.validityPeriodString)) {
      try {

        trainingCredit.setValidityPeriod(
          Integer.parseInt(trainingCreditDetails.validityPeriodString));
      } catch (NumberFormatException numberFormatException) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TRAININGCREDITExceptionCreator.ERR_TRAININGCREDIT_FV_VALIDITY_PERIOD_MUST_BE_GT_ZERO(
            trainingCreditDetails.validityPeriodString),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
        ValidationHelper.failIfErrorsExist();
      }
    }
    trainingCredit.setProviderType(
      CPMProviderTypeNameEntry.get(trainingCreditDetails.parentProviderCategory));

    trainingCredit.setProviderCategory(
      CPMProviderCategoryNameEntry.get(
        curam.util.type.CodeTable.getParentCode(
          CPMProviderTypeNameEntry.TABLENAME,
          trainingCreditDetails.parentProviderCategory)));
  }

  /**
   * Gets the training credit details for a training.
   *
   * @param trainingCredit
   * An instance of Training Credit.
   * @return The training credit details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected TrainingCreditDetails getTrainingCreditFields(
    // END, CR00177241
    final curam.training.impl.TrainingCredit trainingCredit)
    throws AppException, InformationalException {

    TrainingCreditDetails trainingCreditDetails = new TrainingCreditDetails();

    // Populate the training credit details.
    trainingCreditDetails.details.trainingCreditID = trainingCredit.getID();
    trainingCreditDetails.details.trainingID = trainingCredit.getTraining().getID();
    trainingCreditDetails.details.providerType = trainingCredit.getProviderType().getCode();
    trainingCreditDetails.details.providerCategory = (CPMProviderCategoryNameEntry.get(curam.util.type.CodeTable.getParentCode(CPMProviderTypeNameEntry.TABLENAME, trainingCredit.getProviderType().getCode())).toString());

    trainingCreditDetails.parentProviderCategory = trainingCredit.getProviderType().getCode();

    trainingCreditDetails.childProviderType = trainingCredit.getProviderType().getCode();

    // Set the string attribute of 'Validity Period' only if the 'Validity
    // Period' is greater than zero. Because if the user does not enter valid
    // input for 'Validity Period' when creating the training credit then zero
    // will be displayed on the view training credits screen.
    if (trainingCredit.getValidityPeriod() > 0) {
      trainingCreditDetails.validityPeriodString = String.valueOf(
        trainingCredit.getValidityPeriod());
    }

    trainingCreditDetails.details.type = trainingCredit.getType().getCode();
    trainingCreditDetails.details.validityPeriodUnit = trainingCredit.getValidityPeriodUnit().getCode();
    trainingCreditDetails.details.value = trainingCredit.getValue();
    trainingCreditDetails.details.validityPeriod = trainingCredit.getValidityPeriod();
    trainingCreditDetails.details.recordStatus = trainingCredit.getLifecycleState().getCode();
    trainingCreditDetails.details.versionNo = trainingCredit.getVersionNo();

    return trainingCreditDetails;
  }

  // BEGIN CR00112382, NK
  /**
   * Sorts a set of training credits into a sorted list for display.
   *
   * @param unsortedTrainingCredits
   * The set of Training Credits.
   * @return a sorted list of training credits for display.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.training.impl.TrainingCredit> sortTrainingCredits(
    // END, CR00177241
    final List<curam.training.impl.TrainingCredit> unsortedTrainingCredits) {

    // Sort by name for display - using a list (instead of a set) in case there
    // are duplicate names.
    final List<curam.training.impl.TrainingCredit> trainingCredits = new ArrayList<curam.training.impl.TrainingCredit>(
      unsortedTrainingCredits);

    Collections.sort(trainingCredits,
      new Comparator<curam.training.impl.TrainingCredit>() {
      public int compare(
        final curam.training.impl.TrainingCredit lhs,
        curam.training.impl.TrainingCredit rhs) {

        return lhs.getProviderType().toUserLocaleString().compareTo(
          rhs.getProviderType().toUserLocaleString());
      }
    });
    return trainingCredits;
  }

  // END CR00112382
}
