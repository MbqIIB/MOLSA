/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2011, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.citizenmessages.internal.impl;


import java.util.HashMap;

import com.google.inject.Inject;

import curam.codetable.impl.REFERRALRELATEDROLETYPEEntry;
import curam.core.impl.CuramConst;
import curam.participantmessages.codetable.impl.ParticipantMessageTypeEntry;
import curam.participantmessages.impl.ParticipantMessage;
import curam.participantmessages.impl.ParticipantMessageLink;
import curam.piwrapper.user.impl.InternalUser;
import curam.piwrapper.user.impl.User;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.referral.impl.Referral;
import curam.referral.impl.ReferralRole;
import curam.referral.impl.ReferralRoleDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * */
class ReferralCitizenMessageComposerImpl implements
  ReferralCitizenMessageComposer {

  @Inject
  private CitizenMessageComposerUtil messageUtil;

  @Inject
  private ProviderDAO providerDAO;

  @Inject
  private ServiceOfferingDAO serviceOfferingDAO;

  @Inject
  private ReferralRoleDAO referralRoleDAO;

  /**
   * HashMap to store the parameters that will be used for this message.
   */
  HashMap<String, String> parameters;

  /**
   * ParticipantMessage object to be returned once populated.
   */
  ParticipantMessage participantMessage;

  /**
   * {@inheritDoc}
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ParticipantMessage getParticipantMessage(final Referral referral)
    throws AppException, InformationalException {

    parameters = new HashMap<String, String>();

    participantMessage = new ParticipantMessage(
      ParticipantMessageTypeEntry.REFERRAL);

    participantMessage.setMessageTitle(setupMessageTitle(referral));

    /**
     * Add the mandatory arguments.
     */
    parameters.put(CitizenMessageComposerConst.kReferralDateReference,
      referral.getReferralDate().toString());
    parameters.put(CitizenMessageComposerConst.kReferralOwner,
      referral.getReferredBy().getFullName());

    participantMessage.setMessageBody(getFirstSentence(referral));

    participantMessage.appendSentenceToMessageBody(getSecondSentence(referral));

    participantMessage.appendSentenceToMessageBody(
      getProperty(CitizenMessageComposerConst.kThirdSentenceReference));

    participantMessage.addLink(
      messageUtil.getMyActivitiesLink(
        CitizenMessageComposerConst.ReferralPropertiesFileName));

    participantMessage.addLink(
      getEmailLink(
        messageUtil.getEmailAddress(
          getUserAsInternalUser(referral.getReferredBy()))));

    participantMessage.addParameters(parameters);

    participantMessage.addImage(
      messageUtil.getParticipantMessageConfigImage(
        ParticipantMessageTypeEntry.REFERRAL));

    return participantMessage;
  }

  /**
   * Depending on whether a provider is specified for this referral, the first
   * sentence may include the provider name as a link, not as a link, or not at
   * all, and have the service name instead.
   *
   * @param referral
   * @return
   * @throws InformationalException
   * @throws AppException
   */
  private String getFirstSentence(final Referral referral) throws AppException,
      InformationalException {
    if (hasProvider(referral) && showProviderLink(referral)) {

      // add an argument for provider name
      parameters.put(CitizenMessageComposerConst.kProviderNameReference,
        referral.getProvider().getName());

      // add provider link
      
      // BEGIN, CR00321586, MR
      if (!REFERRALRELATEDROLETYPEEntry.UNREGISTEREDSERVICEOFFERING.getCode().equals(
        referral.getService().getRelatedObjectRoleType().getCode())) {
        participantMessage.addLink(
          messageUtil.addProviderModalLink(getServiceOffering(referral),
          getProvider(referral)));
      }
      // END, CR00321586      
      return getProperty(CitizenMessageComposerConst.kFirstSentence);

    } else if (hasProvider(referral)) {

      // they have a provider, but it is not a Provider, it is a representative,
      // so just display the name.

      // add an argument for provider name
      parameters.put(CitizenMessageComposerConst.kProviderNameReference,
        referral.getProvider().getName());

      participantMessage.addLink(messageUtil.addReferralModalLink(referral));

      return getProperty(
        CitizenMessageComposerConst.kFirstSentenceRepresentativeProvider);
    } else {
      // set the first sentence with a view to having no provider
      return getProperty(
        CitizenMessageComposerConst.kFirstSentenceStartDateNoProvider);
    }
  }

  /**
   * Only display the provider modal link if the provider is a Provider and not
   * a representative, and a provider offering can be retrieved.
   *
   * @param referral
   * @return
   */
  private boolean showProviderLink(final Referral referral) {

    // there is a safe assumption here that referral.getService returns a
    // ServiceOffering, because we only display referrals with a service
    // offering in citizen account.
    final ServiceOffering serviceOffering = serviceOfferingDAO.get(
      referral.getService().getRelatedObjectID());

    if (!referral.getProviderType().getCode().equals(
      REFERRALRELATEDROLETYPEEntry.PROVIDER.getCode())) {
      return false;
    }

    final Provider provider = providerDAO.get(referral.getProvider().getID());

    if (provider == null) {
      return false;
    }

    if (!messageUtil.hasValidProviderOffering(serviceOffering, provider)) {
      return false;
    }

    return true;
  }

  /**
   * @param referral
   */
  private Boolean hasProvider(final Referral referral) {

    if (referral.getProvider() != null && referral.getProvider().getID() != 0) {
      return true;
    }
    return false;
  }

  /**
   * This method assumes that this Referral is linked to a ServiceOffering via
   * the ReferralRole entity. Only Referrals that have a Provider and
   * ServiceOffering associated should be passed in to this class.
   *
   * @param referral
   * @return
   */
  private ServiceOffering getServiceOffering(final Referral referral) {

    final ReferralRole serviceOfferingReferralRole = referralRoleDAO.readActiveByReferralAndRelatedType(
      referral, REFERRALRELATEDROLETYPEEntry.SERVICEOFFERING);

    final ServiceOffering serviceOffering = serviceOfferingDAO.get(
      serviceOfferingReferralRole.getRelatedObjectID());

    return serviceOffering;
  }

  /**
   * Return the provider associated with this referral. Assumes one exists, if
   * not null will be returned.
   *
   * @param referral
   * the referral.
   * @return ServiceDeliveryCitizenMessageComposer
   */
  private Provider getProvider(final Referral referral) {
    return providerDAO.get(referral.getProvider().getID());
  }

  /**
   * @param referral
   * @return
   * @throws InformationalException
   * @throws AppException
   */
  private String getSecondSentence(final Referral referral)
    throws AppException, InformationalException {

    String secondSentence = CuramConst.gkEmpty;

    // this is safe: external users cannot refer participants.
    final InternalUser internalUser = getUserAsInternalUser(
      referral.getReferredBy());

    if (messageUtil.hasBusinessPhoneNumberAndEmailAddress(internalUser)) {

      secondSentence = getProperty(
        CitizenMessageComposerConst.kSecondSentenceHasContactDetailsReference);

      // contact information parameters
      parameters.put(CitizenMessageComposerConst.kPhoneNumberReference,
        messageUtil.getPhoneNumber(internalUser));
      parameters.put(CitizenMessageComposerConst.kEmailAddressReference,
        messageUtil.getEmailAddress(internalUser));
    } else {
      // no contact details
      secondSentence = getProperty(
        CitizenMessageComposerConst.kSecondSentenceNoContactDetailsReference);
    }
    return secondSentence;
  }

  private InternalUser getUserAsInternalUser(final User user) {
    // this is safe: external users cannot refer participants.
    return (InternalUser) user;
  }

  /**
   * @param string
   * @return
   */
  private ParticipantMessageLink getEmailLink(final String emailAddress) {

    final ParticipantMessageLink emailLink = new ParticipantMessageLink(false,
      CitizenMessageComposerConst.kMailTo + emailAddress,
      CitizenMessageComposerConst.kEmailLinkReference);

    return emailLink;
  }

  /**
   * Sets up a parameter for the Referral name, that is used in the title.
   * Returns the property that is to be used as the message title.
   *
   * @param referral
   * @return the name for the service, which is used as the message title.
   * @throws InformationalException
   * @throws AppException
   */
  private String setupMessageTitle(final Referral referral)
    throws AppException, InformationalException {

    // set up a parameter for the message title value
    parameters.put(CitizenMessageComposerConst.kServiceNameReference,
      referral.getService().getName());

    return getProperty(CitizenMessageComposerConst.kMessageTitleReference);
  }

  /**
   * Retrieves a resource from the associated properties file based on the
   * reference passed in.
   *
   * @param reference
   * key to the property to be retrieved.
   * @return a resource from the associated properties file based on the
   * reference passed in.
   * @throws InformationalException
   * @throws AppException
   */
  private String getProperty(final String reference) throws AppException,
      InformationalException {

    return messageUtil.getPropertyValue(
      CitizenMessageComposerConst.ReferralPropertiesFileName, reference);
  }
}
