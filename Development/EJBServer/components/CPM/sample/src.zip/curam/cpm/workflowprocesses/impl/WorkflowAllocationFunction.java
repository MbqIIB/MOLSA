/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.workflowprocesses.impl;


import curam.codetable.TARGETITEMTYPE;
import curam.core.sl.struct.AllocationTargetDetails;
import curam.core.sl.struct.AllocationTargetList;
import curam.core.struct.AdminConcernRoleDetails;
import curam.core.struct.AdminConcernRoleDetailsList;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.MaintainAdminConcernRoleKey;
import curam.core.sl.entity.struct.RosterLineItemKey;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.PRLIRefKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ServiceInvoiceLineItemKey;
import curam.cpm.sl.entity.struct.TaxonomyTermKey;
import curam.useradmin.impl.MaintainAdminConcernRole;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * Work Flow Allocation Function class.
 */
public abstract class WorkflowAllocationFunction extends curam.cpm.workflowprocesses.base.WorkflowAllocationFunction {

  // ___________________________________________________________________________
  /**
   * (non-Javadoc)
   *
   * @see curam.cpm.workflowprocesses.intf.WorkflowAllocationFunction#siliExceptionProcessingAllocationStrategy(curam.cpm.sl.entity.struct.ServiceInvoiceLineItemKey)
   */
  @SuppressWarnings(CPMConstants.kUnused)
  public AllocationTargetList siliExceptionProcessingAllocationStrategy(
    ServiceInvoiceLineItemKey arg0) throws AppException,
      InformationalException {
    AllocationTargetList allocationTargetList = new AllocationTargetList();
    AllocationTargetDetails allocationTargetDetails = new AllocationTargetDetails();

    allocationTargetDetails.name = CPMConstants.kFour; // "Service Invoice
    // Exception
    // Processing Work
    // Queue";
    allocationTargetDetails.type = TARGETITEMTYPE.WORKQUEUE;
    allocationTargetList.dtls.addRef(allocationTargetDetails);
    return allocationTargetList;
  }
  
  // BEGIN, CR00261445, GP
  /**
   * Allocates the Service Invoice line item exception task to a work queue for
   * processing.
   *
   * @param key
   * Service Invoice line key for which approval task is created.
   * @return AllocationTargetList Contains allocation target details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public AllocationTargetList siliSubmissionProcessingAllocationStrategy(
    ServiceInvoiceLineItemKey key) throws AppException,
      InformationalException {
    AllocationTargetList allocationTargetList = new AllocationTargetList();
    AllocationTargetDetails allocationTargetDetails = new AllocationTargetDetails();

    allocationTargetDetails.name = CPMConstants.kServiceInvoiceLineItemApprovalWorkQueueID;
    allocationTargetDetails.type = TARGETITEMTYPE.WORKQUEUE;
    allocationTargetList.dtls.addRef(allocationTargetDetails);
    return allocationTargetList;
  }

  // END, CR00261445
  
  // BEGIN, CR00110397, SG
  /**
   * Allocates the roster line item exception task to a work queue for
   * processing.
   *
   * @param key
   * Roster line item key for which exception task is created.
   * @return AllocationTargetList Contains allocation target details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public AllocationTargetList prliExceptionProcessingAllocationStrategy(
    RosterLineItemKey key) throws AppException, InformationalException {

    AllocationTargetList allocationTargetList = new AllocationTargetList();
    AllocationTargetDetails allocationTargetDetails = new AllocationTargetDetails();

    if (key.rosterLineItemID != 0) {
      // Roster Exception Processing Work Queue
      allocationTargetDetails.name = CPMConstants.kWorkQueueProcessSix;
      allocationTargetDetails.type = TARGETITEMTYPE.WORKQUEUE;
      allocationTargetList.dtls.addRef(allocationTargetDetails);
    }
    return allocationTargetList;
  }

  // END, CR00110397
  
  // BEGIN, CR00261445, GP
  /**
   * Allocates the roster line item task to the Roster Line Item Approval Work
   * Queue.
   *
   * @param key
   * The Roster line item reference key for which task is created.
   * @return AllocationTargetList Contains allocation target details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public AllocationTargetList prliSubmissionTaskAllocationStrategy(
    PRLIRefKey key) throws AppException, InformationalException {

    AllocationTargetList allocationTargetList = new AllocationTargetList();
    AllocationTargetDetails allocationTargetDetails = new AllocationTargetDetails();

    if (null != key.rliID) {
      
      // Allocate the task to Roster Line Item Approval WorkQueue.
      allocationTargetDetails.name = CPMConstants.kRosterLineItemApprovalWorkQueueID;
      allocationTargetDetails.type = TARGETITEMTYPE.WORKQUEUE;
      allocationTargetList.dtls.addRef(allocationTargetDetails);
    }
    return allocationTargetList;
  }

  // END, CR00261445

  // ___________________________________________________________________________
  /**
   * Allocates the task to the Provider supervisor
   *
   * @param key
   * the key for the provider
   *
   * @return List of allocation targets
   *
   * @throws InformationalException
   * @throws AppException
   */

  public AllocationTargetList providerSupervisorStrategy(ProviderKey key)
    throws AppException, InformationalException {

    // Create return object
    AllocationTargetList allocationTargetList = new AllocationTargetList();

    AllocationTargetDetails allocationTargetDetails;

    if (key.providerConcernRoleID != 0) {

      // AdminRole maintenance object and key
      curam.core.intf.MaintainAdminConcernRole maintainAdminConcernRole = curam.core.fact.MaintainAdminConcernRoleFactory.newInstance();

      // Read list of AdminRoles for this concern role ID
      // BEGIN, CR00235789, AK
      MaintainAdminConcernRoleKey maintainAdminConcernRoleKey = new MaintainAdminConcernRoleKey();
      Date today = Date.getCurrentDate();

      maintainAdminConcernRoleKey.concernRoleID = key.providerConcernRoleID;
      AdminConcernRoleDetailsList adminConcernRoleDetailsList = maintainAdminConcernRole.readAdministratorsForConcernRole(
        maintainAdminConcernRoleKey);

      AdminConcernRoleDetails currentUser;
      DateRange currentSupervisorDateRange;

      for (int i = 0; i < adminConcernRoleDetailsList.details.size(); i++) {
        currentUser = adminConcernRoleDetailsList.details.item(i);
        // END, CR00235789

        // if our user is on the list and is a supervisor
        // check the dates match
        if (currentUser.typeCode.equals(
          curam.codetable.ADMINCONCERNROLETYPE.SUPERVISOR)) {
          currentSupervisorDateRange = new DateRange(currentUser.startDate,
            currentUser.endDate);
          // if still in date, return true
          if (currentSupervisorDateRange.contains(today)) {

            allocationTargetDetails = new AllocationTargetDetails();

            // Set the spec for the allocator
            allocationTargetDetails.name = currentUser.userName;
            allocationTargetDetails.type = TARGETITEMTYPE.USER;

            // Add details to the spec list
            allocationTargetList.dtls.addRef(allocationTargetDetails);
          }
        }
      }
    }

    return allocationTargetList;
  }

  // ___________________________________________________________________________
  /**
   * Allocates the task to the provider owner.
   *
   * @param key
   * Provider Key
   *
   * @return List of allocation targets
   *
   * @throws InformationalException
   * @throws AppException
   */
  public AllocationTargetList providerOwnerStrategy(ProviderKey key)
    throws AppException, InformationalException {

    // Create return object
    AllocationTargetList allocationTargetList = new AllocationTargetList();

    AllocationTargetDetails allocationTargetDetails;

    MaintainAdminConcernRole maintainAdminConcernRoleObj = new MaintainAdminConcernRole();
  
    if (key.providerConcernRoleID != 0) {

      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = key.providerConcernRoleID;

      allocationTargetDetails = new AllocationTargetDetails();

      // Set the spec for the allocator
      allocationTargetDetails.name = maintainAdminConcernRoleObj.getProviderOrganisationOwner(concernRoleKey).userName;
      allocationTargetDetails.type = TARGETITEMTYPE.USER;

      // Add details to the spec list
      allocationTargetList.dtls.addRef(allocationTargetDetails);

    }
    return allocationTargetList;
  }

  // BEGIN, CR00213911, RPB
  /**
   * Allocates the taxonomy update task to the owner.
   *
   * @param key
   * Taxonomy Term Key
   *
   * @return List of allocation targets.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public AllocationTargetList taxonomyUpdateTaskAllocationStrategy(
    final TaxonomyTermKey key) throws AppException, InformationalException {

    AllocationTargetList allocationTargetList = new AllocationTargetList();
    AllocationTargetDetails allocationTargetDetails = new AllocationTargetDetails();

    allocationTargetDetails.name = CPMConstants.kResourceManagerUserName;
    allocationTargetDetails.type = TARGETITEMTYPE.USER;

    allocationTargetList.dtls.addRef(allocationTargetDetails);

    return allocationTargetList;
  }
  // END, CR00213911
  
}
