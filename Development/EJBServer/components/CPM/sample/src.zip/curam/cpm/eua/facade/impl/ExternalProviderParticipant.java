/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008,2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.eua.facade.impl;


import com.google.inject.Inject;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.struct.ConcernRoleKey;
import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.eua.facade.struct.ProviderParticipantDetailsList;
import curam.cpm.facade.fact.ContextDescriptionFactory;
import curam.cpm.facade.fact.ProviderParticipantFactory;
import curam.cpm.facade.intf.ContextDescription;
import curam.cpm.facade.struct.ListProviderParticipantDetails;
import curam.cpm.facade.struct.ListProviderParticipantDetailsList;
import curam.cpm.facade.struct.ViewProviderParticipantDetails;
import curam.cpm.sl.entity.struct.ProviderPartyKey;
import curam.provider.impl.ProviderPartyDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


/**
 * This process class provides the functionality for Provider Participant facade layer
 */
public abstract class ExternalProviderParticipant extends curam.cpm.eua.facade.base.ExternalProviderParticipant {

  /*
   * Inject providerPartyDAO
   */
  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  /**
   * Constructor
   */
  public ExternalProviderParticipant() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * This method returns a list of participants for a provider
   *
   * @param concernRoleKey - Contains the concernRoleID for the provider
   * @return a list of provider participants
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ProviderParticipantDetailsList listProviderParticipants(
    ConcernRoleKey concernRoleKey) throws AppException, InformationalException {

    // Create instance of provider participant facade
    curam.cpm.facade.intf.ProviderParticipant providerParticipantObj = ProviderParticipantFactory.newInstance();

    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    // call method to ensure that logged in user has the rights
    // to view this information
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    ProviderParticipantDetailsList providerParticipantDetailsList = new ProviderParticipantDetailsList();

    // variables for reading the context description
    ContextDescription contextDescription = ContextDescriptionFactory.newInstance();

    providerParticipantDetailsList.pageContextDescription.description = contextDescription.getContextDescriptionForConcern(concernRoleKey).description;

    // invoke facade layer method & filer removing all canceled records
    providerParticipantDetailsList.participantList = filterList(
      providerParticipantObj.listProviderParticipants(concernRoleKey));

    // BEGIN, CR00090217, GD
    // Sort returned list by name
    providerParticipantDetailsList = sortProviderParticipantsByName(
      providerParticipantDetailsList);
    // END, CR00090217

    return providerParticipantDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Sorts a set of provider participants into a sorted list by name.
   *
   * @param unsortedProviderParticipants the set of provider participants to sort
   * @return sorted list of provider participants for display
   */
  // BEGIN, CR00177241, PM
  protected ProviderParticipantDetailsList sortProviderParticipantsByName(
    final ProviderParticipantDetailsList unsortedProviderParticipants) {
    // END, CR00177241

    /*
     * Sort by name for display - using a list.
     */
    final List<ListProviderParticipantDetails> listProviderParticipantDetailsList = new ArrayList<ListProviderParticipantDetails>();

    // Copy items for sorting
    for (int i = 0, j = unsortedProviderParticipants.participantList.participantDetailsList.size(); i
      < j; i++) {

      listProviderParticipantDetailsList.add(
        unsortedProviderParticipants.participantList.participantDetailsList.item(
          i));

    }

    Collections.sort(listProviderParticipantDetailsList,
      new Comparator<ListProviderParticipantDetails>() {

      public int compare(final ListProviderParticipantDetails lhs,
        ListProviderParticipantDetails rhs) {

        return lhs.participantName.compareTo(rhs.participantName);

      }

    });

    // return structure
    ProviderParticipantDetailsList providerParticipantDetailsList = new ProviderParticipantDetailsList();

    // Copy sorted entries into return list structure
    for (int m = 0, n = listProviderParticipantDetailsList.size(); m < n; m++) {

      providerParticipantDetailsList.participantList.participantDetailsList.addRef(
        listProviderParticipantDetailsList.get(m));

    }

    return providerParticipantDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * This method filters the provider participants list removing all canceled
   * records from the list
   *
   * @param unfilteredList - this contains a list of provider participants
   * @return This contains a list of all provider participants except canceled
   */
  // BEGIN, CR00177241, PM
  protected ListProviderParticipantDetailsList filterList(
    ListProviderParticipantDetailsList unfilteredList) {
    // END, CR00177241

    ListProviderParticipantDetailsList result = new ListProviderParticipantDetailsList();

    for (int i = 0; i < unfilteredList.participantDetailsList.size(); i++) {

      // add only non-canceled records to the list
      if (!unfilteredList.participantDetailsList.item(i).recordStatus.equals(
        RECORDSTATUSEntry.CANCELLED.getCode())) {
        result.participantDetailsList.addRef(
          unfilteredList.participantDetailsList.item(i));
      }
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * This method returns details for the selected provider participant
   *
   * @param providerParticipantKey - Contains the participant ID
   * @return details for the selected provider participant
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ViewProviderParticipantDetails viewProviderParticipant(
    ProviderPartyKey providerParticipantKey) throws AppException,
      InformationalException {

    // Create instance of provider participant facade
    curam.cpm.facade.intf.ProviderParticipant providerParticipantObj = ProviderParticipantFactory.newInstance();

    ViewProviderParticipantDetails viewProviderParticipantDetails = providerParticipantObj.viewProviderParticipant(
      providerParticipantKey);

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // set the concern role ID
    concernRoleKey.concernRoleID = providerPartyDAO.get(providerParticipantKey.providerPartyID).getProviderOrganization().getID();

    // call method to ensure that the logged in user has access
    // to view this information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    // invoke facade layer method
    return viewProviderParticipantDetails;

  }

}
