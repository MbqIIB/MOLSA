/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.codetable.MSWORDTEMPLATETYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.cpm.facade.struct.DeleteHomeStudyDocumentKey;
import curam.cpm.facade.struct.DocumentTemplateList;
import curam.cpm.facade.struct.HomeStudyDocumentAndTemplateDataDetails;
import curam.cpm.facade.struct.HomeStudyDocumentDataDetails;
import curam.cpm.facade.struct.HomeStudyDocumentDetails;
import curam.cpm.facade.struct.HomeStudyDocumentKey;
import curam.cpm.facade.struct.HomeStudyDocumentList;
import curam.cpm.facade.struct.HomeStudyDocumentListKey;
import curam.cpm.facade.struct.ProviderKey;
import curam.cpm.facade.struct.ReadHomeStudyDocumentDetails;
import curam.cpm.facade.struct.ReadHomeStudyDocumentTemplateAndDataKey;
import curam.cpm.sl.entity.struct.HomeStudyDocumentDtls;
import curam.cpm.sl.struct.HomeStudyDocumentTemplateCategoryKey;
import curam.cpm.sl.struct.HomeStudyDocumentTemplateDetails;
import curam.cpm.sl.struct.HomeStudyDocumentTemplateList;
import curam.homestudy.impl.HomeStudy;
import curam.homestudy.impl.HomeStudyDAO;
import curam.homestudy.impl.HomeStudyDocumentDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * The facade implementation for {@link curam.homestudy.impl.HomeStudyDocument}.
 */
public abstract class HomeStudyDocument extends curam.cpm.facade.base.HomeStudyDocument {

  /**
   * Constructor
   */
  public HomeStudyDocument() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  // Home Study Document data access object
  @Inject
  protected HomeStudyDocumentDAO homeStudyDocumentDAO;

  // Home Study data access object
  @Inject
  protected HomeStudyDAO homeStudyDAO;

  // BEGIN, CR00360398, CD
  @Inject
  private Provider<CMSMetadataInterface> cmsMetadataProvider;
  // END, CR00360398

  /**
   * Creates a home study document.
   *
   * @param details Contains home study document creation details.
   *
   * @return HomeStudyDocumentKey Home Study Document Key
   * @throws AppException
   * @throws InformationalException If validation errors were detected
   */
  public HomeStudyDocumentKey createHomeStudyDocument(
    HomeStudyDocumentDetails details)
    throws AppException, InformationalException {

    // return structure
    HomeStudyDocumentKey homeStudyDocumentKey = new HomeStudyDocumentKey();

    // home study document entity
    final curam.homestudy.impl.HomeStudyDocument homeStudyDocumentEnt = homeStudyDocumentDAO.newInstance();

    // set the details
    homeStudyDocumentEnt.setDocumentDescription(
      details.documentDetails.documentDescription);
    homeStudyDocumentEnt.setDocumentTemplateID(
      details.documentDetails.documentTemplateID);

    // Home Study entity
    final HomeStudy homeStudyEnt = homeStudyDAO.get(
      details.documentDetails.homeStudyID);

    // Set Home Study details
    homeStudyDocumentEnt.setHomeStudy(homeStudyEnt);

    // BEGIN, CR00360398, CD
    // set up some meta data for the attachment    
    CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

    cmsMetadata.add(CMSMetadataConst.kParticipantID,
      Long.toString(homeStudyEnt.getProvider().getID()));
    // END, CR00360398
    
    // insert the record
    homeStudyDocumentEnt.insert();

    // get ID of the record created
    homeStudyDocumentKey.key.homeStudyDocumentID = homeStudyDocumentEnt.getID();

    return homeStudyDocumentKey;

  }

  /**
   * Modifies a home study document.
   *
   * @param details Contains home study document modification details.
   * @throws AppException
   * @throws InformationalException if validation errors were detected
   */
  public void modifyHomeStudyDocument(HomeStudyDocumentDetails details)
    throws AppException, InformationalException {

    // home study document entity
    final curam.homestudy.impl.HomeStudyDocument homeStudyDocumentEnt = homeStudyDocumentDAO.get(
      details.documentDetails.homeStudyDocumentID);

    // set the details
    homeStudyDocumentEnt.setDocumentDescription(
      details.documentDetails.documentDescription);
    homeStudyDocumentEnt.setDocumentTemplateID(
      details.documentDetails.documentTemplateID);

    // home study entity
    final HomeStudy homeStudyEnt = homeStudyDAO.get(
      details.documentDetails.homeStudyID);

    // Set Home Study details
    homeStudyDocumentEnt.setHomeStudy(homeStudyEnt);

    // modify Home Study Document
    homeStudyDocumentEnt.modify(details.documentDetails.versionNo);

  }

  /**
   * Reads a home study document.
   *
   * @param key Contains home study document ID.
   * @return Home study document details and context description read.
   * @throws AppException
   * @throws InformationalException
   */
  public ReadHomeStudyDocumentDetails viewHomeStudyDocument(
    HomeStudyDocumentKey key) throws AppException, InformationalException {

    // return structure
    final ReadHomeStudyDocumentDetails readHomeStudyDocumentDetails = new ReadHomeStudyDocumentDetails();

    // home study document entity
    final curam.homestudy.impl.HomeStudyDocument homeStudyDocumentEnt = homeStudyDocumentDAO.get(
      key.key.homeStudyDocumentID);

    // assigning the details
    readHomeStudyDocumentDetails.documentDetails.attachmentID = homeStudyDocumentEnt.getAttachmentID();
    readHomeStudyDocumentDetails.documentDetails.dateCreated = homeStudyDocumentEnt.getDateCreated();
    readHomeStudyDocumentDetails.documentDetails.documentDescription = homeStudyDocumentEnt.getDocumentDescription();
    readHomeStudyDocumentDetails.documentDetails.documentTemplateID = homeStudyDocumentEnt.getDocumentTemplateID();
    readHomeStudyDocumentDetails.documentDetails.homeStudyDocumentID = homeStudyDocumentEnt.getID();
    readHomeStudyDocumentDetails.documentDetails.createdBy = homeStudyDocumentEnt.getCreatedBy();
    readHomeStudyDocumentDetails.documentDetails.homeStudyID = homeStudyDocumentEnt.getHomeStudy().getID();
    readHomeStudyDocumentDetails.documentDetails.recordStatus = homeStudyDocumentEnt.getLifecycleState().getCode();
    readHomeStudyDocumentDetails.documentDetails.versionNo = homeStudyDocumentEnt.getVersionNo();

    // get document template name
    readHomeStudyDocumentDetails.documentTemplateName = homeStudyDocumentEnt.getDocumentTemplateName();

    // Context description helper BPO
    curam.cpm.facade.intf.ContextDescription contextDescriptionObj = curam.cpm.facade.fact.ContextDescriptionFactory.newInstance();
    // Provider Key
    ProviderKey providerKey = new ProviderKey();

    // get the HomeStudy, Provider and the provider ID
    providerKey.providerID = homeStudyDocumentEnt.getHomeStudy().getProvider().getID();

    // read and set the context description
    readHomeStudyDocumentDetails.contextDescription = contextDescriptionObj.getContextDescription(
      providerKey);

    return readHomeStudyDocumentDetails;

  }

  /**
   * Deletes a home study document.
   *
   * @param key Contains home study document ID and version number.
   * @throws AppException
   * @throws InformationalException
   */
  public void deleteHomeStudyDocument(DeleteHomeStudyDocumentKey key)
    throws AppException, InformationalException {

    // home study document entity
    final curam.homestudy.impl.HomeStudyDocument homeStudyDocumentEnt = homeStudyDocumentDAO.get(
      key.key.homeStudyDocumentID);

    // logically delete the record
    homeStudyDocumentEnt.cancel(key.versionNo);

  }

  /**
   * Returns a list of home study documents for the home study specified.
   *
   * @param key Contains home study ID.
   * @return Struct containing a list of home study document details and
   * context description.
   * @throws AppException
   * @throws InformationalException
   */
  public HomeStudyDocumentList listHomeStudyDocuments(
    HomeStudyDocumentListKey key) throws AppException,
      InformationalException {

    // return structure
    HomeStudyDocumentList homeStudyDocumentList = new HomeStudyDocumentList();

    // Home study document details
    HomeStudyDocumentDtls homeStudyDocumentDtls;

    // Home Study instance
    final HomeStudy homeStudyEnt = homeStudyDAO.get(key.homeStudyID);

    // Retrieve a Set of Home Study Document instances
    // by Home Study
    final Set<curam.homestudy.impl.HomeStudyDocument> homeStudyDocuments = homeStudyDocumentDAO.searchByHomeStudy(
      homeStudyEnt);

    // sort the documents by date created
    List<curam.homestudy.impl.HomeStudyDocument> homeStudyDocumentsSorted = sortHomeStudyDocuments(
      homeStudyDocuments);

    // Loop through retrieved set adding relevant details to the
    // return structure
    for (final curam.homestudy.impl.HomeStudyDocument
      homeStudyDocumentEnt : homeStudyDocumentsSorted) {

      homeStudyDocumentDtls = new HomeStudyDocumentDtls();

      // set the home study document details
      homeStudyDocumentDtls.attachmentID = homeStudyDocumentEnt.getAttachmentID();
      homeStudyDocumentDtls.dateCreated = homeStudyDocumentEnt.getDateCreated();
      homeStudyDocumentDtls.documentDescription = homeStudyDocumentEnt.getDocumentDescription();
      homeStudyDocumentDtls.documentTemplateID = homeStudyDocumentEnt.getDocumentTemplateID();
      homeStudyDocumentDtls.homeStudyDocumentID = homeStudyDocumentEnt.getID();
      homeStudyDocumentDtls.createdBy = homeStudyDocumentEnt.getCreatedBy();
      homeStudyDocumentDtls.homeStudyID = homeStudyDocumentEnt.getHomeStudy().getID();
      homeStudyDocumentDtls.recordStatus = homeStudyDocumentEnt.getLifecycleState().getCode();
      homeStudyDocumentDtls.versionNo = homeStudyDocumentEnt.getVersionNo();

      // add home study document details to the list
      homeStudyDocumentList.list.dtls.addRef(homeStudyDocumentDtls);

    }

    // Context description helper BPO
    curam.cpm.facade.intf.ContextDescription contextDescriptionObj = curam.cpm.facade.fact.ContextDescriptionFactory.newInstance();
    // Provider Key
    ProviderKey providerKey = new ProviderKey();

    // get the the Provider ID
    providerKey.providerID = homeStudyEnt.getProvider().getID();

    // read and set the context description
    homeStudyDocumentList.contextDescription = contextDescriptionObj.getContextDescription(
      providerKey);

    return homeStudyDocumentList;

  }

  /**
   * Retrieves document template and document data.
   *
   * @param key Contains attachment ID and template ID.
   * @return Struct containing document template and document data.
   * @throws AppException
   * @throws InformationalException
   */
  public HomeStudyDocumentAndTemplateDataDetails getTemplateDocumentAndData(
    ReadHomeStudyDocumentTemplateAndDataKey key) throws AppException,
      InformationalException {

    // home study document entity
    final curam.homestudy.impl.HomeStudyDocument homeStudyDocumentEnt = homeStudyDocumentDAO.get(
      key.key.homeStudyDocumentID);

    // return structure
    HomeStudyDocumentAndTemplateDataDetails homeStudyDocumentAndTemplateDataDetails = new HomeStudyDocumentAndTemplateDataDetails();

    homeStudyDocumentAndTemplateDataDetails.documentData = homeStudyDocumentEnt.getAttachmentData();

    homeStudyDocumentAndTemplateDataDetails.templateData = homeStudyDocumentEnt.getTemplateData();

    return homeStudyDocumentAndTemplateDataDetails;

  }

  /**
   * Modifies home study document data.
   *
   * @param details Contains attachment ID and document data.
   * @throws AppException
   * @throws InformationalException
   */
  public void modifyDocumentData(HomeStudyDocumentDataDetails details)
    throws AppException, InformationalException {

    // home study document entity
    final curam.homestudy.impl.HomeStudyDocument homeStudyDocumentEnt = homeStudyDocumentDAO.get(
      details.homeStudyDocumentKey.homeStudyDocumentID);

    // modify attachment data
    homeStudyDocumentEnt.modifyAttachmentData(details.documentDataDetails);

  }

  /**
   * Sorts a set of home study documents into a sorted list for display.
   *
   * @param unsortedDocuments Contains the set of home study documents.
   * @return a sorted list of home study documents for display.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.homestudy.impl.HomeStudyDocument> sortHomeStudyDocuments(
    // END, CR00177241
    final Set<curam.homestudy.impl.HomeStudyDocument> unsortedDocuments) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    final List<curam.homestudy.impl.HomeStudyDocument> homeStudyDocuments = new ArrayList<curam.homestudy.impl.HomeStudyDocument>(
      unsortedDocuments);

    Collections.sort(homeStudyDocuments,
      new Comparator<curam.homestudy.impl.HomeStudyDocument>() {

      public int compare(final curam.homestudy.impl.HomeStudyDocument lhs,
        curam.homestudy.impl.HomeStudyDocument rhs) {

        return lhs.getDateCreated().compareTo(rhs.getDateCreated());

      }

    });

    return homeStudyDocuments;

  }

  /**
   * Retrieves a list of home study document templates.
   *
   * @return List of home study document templates.
   * @throws AppException
   * @throws InformationalException
   */
  public DocumentTemplateList listHomeStudyDocumentTemplates()
    throws AppException, InformationalException {

    // return structure
    DocumentTemplateList documentTemplateList = new DocumentTemplateList();

    // Home study category key
    HomeStudyDocumentTemplateCategoryKey homeStudyDocumentTemplateCategoryKey = new HomeStudyDocumentTemplateCategoryKey();

    // BEGIN, CR00208316, RD
    homeStudyDocumentTemplateCategoryKey.documentCategoryCode = MSWORDTEMPLATETYPE.HOMESTUDY;
    // END, CR00208316
    
    homeStudyDocumentTemplateCategoryKey.recordStatus = RECORDSTATUS.NORMAL;

    // retrieve the list of home study document templates
    HomeStudyDocumentTemplateList homeStudyDocumentTemplateList = homeStudyDocumentDAO.getDocumentTemplateList(
      homeStudyDocumentTemplateCategoryKey);

    // sort the list of document templates by name
    documentTemplateList.list = sortHomeStudyDocumentTemplates(
      homeStudyDocumentTemplateList);

    return documentTemplateList;

  }

  /**
   * Sorts a set of home study document template records into a sorted list
   * for display.
   *
   * @param unsortedList Contains the unsorted list of document templates.
   * @return a sorted list of home study document templates for display.
   */
  // BEGIN, CR00177241, PM
  protected HomeStudyDocumentTemplateList // END, CR00177241
  sortHomeStudyDocumentTemplates(
    final HomeStudyDocumentTemplateList unsortedList) {

    /*
     * Sort by name for display - using a list.
     */
    final List<HomeStudyDocumentTemplateDetails> homeStudyDocumentTemplates = new ArrayList<HomeStudyDocumentTemplateDetails>();

    // Copy items for sorting
    for (int i = 0, j = unsortedList.listDtls.size(); i < j; i++) {

      homeStudyDocumentTemplates.add(unsortedList.listDtls.item(i));

    }

    Collections.sort(homeStudyDocumentTemplates,
      new Comparator<HomeStudyDocumentTemplateDetails>() {

      public int compare(final HomeStudyDocumentTemplateDetails lhs,
        HomeStudyDocumentTemplateDetails rhs) {

        return lhs.documentTemplateName.compareTo(rhs.documentTemplateName);

      }

    });

    // return structure
    HomeStudyDocumentTemplateList homeStudyDocumentTemplateList = new HomeStudyDocumentTemplateList();

    // Copy sorted entries into return list structure
    for (int m = 0, n = homeStudyDocumentTemplates.size(); m < n; m++) {

      homeStudyDocumentTemplateList.listDtls.addRef(
        homeStudyDocumentTemplates.get(m));

    }

    return homeStudyDocumentTemplateList;

  }

}
