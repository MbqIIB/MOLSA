/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.attachment.impl.Attachment;
import curam.attachmentlink.impl.AttachmentLink;
import curam.attachmentlink.impl.AttachmentLinkDAO;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkKey;
import curam.attachmentlink.struct.ListAttachmentLinkDetails;
import curam.codetable.ATTACHMENTOBJECTLINKTYPE;
import curam.codetable.SENSITIVITY;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.core.fact.SystemUserFactory;
import curam.core.intf.SystemUser;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.struct.AttachmentKey;
import curam.cpm.eua.facade.struct.LicenseDetails;
import curam.cpm.eua.facade.struct.LicenseSummaryList;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.LicenseAndStatusHistoryKey;
import curam.cpm.facade.struct.LicenseCreateDetails;
import curam.cpm.facade.struct.LicenseIDProviderKey;
import curam.cpm.facade.struct.LicenseNotificationKey;
import curam.cpm.facade.struct.LicenseProviderAndVersionNumberKey;
import curam.cpm.facade.struct.LicenseRejectionKey;
import curam.cpm.facade.struct.LicenseRenewalSummaryDetails;
import curam.cpm.facade.struct.LicenseServiceOfferingLinkVersionNumberKey;
import curam.cpm.facade.struct.LicenseServiceOfferingsSummaryDetails;
import curam.cpm.facade.struct.LicenseServiceOfferingsSummaryDetailsList;
import curam.cpm.facade.struct.LicenseStatusHistoryDetails;
import curam.cpm.facade.struct.LicenseStatusHistoryDetailsList;
import curam.cpm.facade.struct.LicenseStatusHistorySummaryDetails;
import curam.cpm.facade.struct.LicenseStatusHistorySummaryDetailsList;
import curam.cpm.facade.struct.LicenseSummaryDetails;
import curam.cpm.facade.struct.LicenseSummaryDetailsList;
import curam.cpm.facade.struct.LicenseSuspensionKey;
import curam.cpm.facade.struct.LicenseTrainingRequirementDetails;
import curam.cpm.facade.struct.LicenseTrainingRequirementDetailsList;
import curam.cpm.facade.struct.LicenseTypeList;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetails;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetailsList;
import curam.cpm.facade.struct.TrainingRemovalDetails;
import curam.cpm.facade.struct.ViewProviderSummaryDetails;
import curam.cpm.sl.entity.struct.LicenseKey;
import curam.cpm.sl.entity.struct.LicenseTrainingRequirementKey;
import curam.cpm.sl.entity.struct.LicenseTrainingRequirementReadmultiKey;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.impl.LicenseNotification;
import curam.cpm.sl.struct.NonComplianceReason;
import curam.cpm.sl.struct.NonComplianceReasonList;
import curam.message.impl.LICENSEExceptionCreator;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.LicenseNonComplianceReason;
import curam.provider.LicenseNotificationEvent;
import curam.provider.LicenseStatus;
import curam.provider.LicenseType;
import curam.provider.impl.LicenseApprovalCriteria;
import curam.provider.impl.LicenseDAO;
import curam.provider.impl.LicenseIssuerEntry;
import curam.provider.impl.LicenseNumberGenerator;
import curam.provider.impl.LicenseRejectionReasonEntry;
import curam.provider.impl.LicenseRenewal;
import curam.provider.impl.LicenseRenewalDAO;
import curam.provider.impl.LicenseServiceOffering;
import curam.provider.impl.LicenseServiceOfferingDAO;
import curam.provider.impl.LicenseStatusEntry;
import curam.provider.impl.LicenseStatusHistory;
import curam.provider.impl.LicenseSuspensionReasonEntry;
import curam.provider.impl.LicenseTrainingRequirementDAO;
import curam.provider.impl.LicenseTypeEntry;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ReasonForNonComplianceDAO;
import curam.provider.impl.TrainingCompletionEntry;
import curam.provider.impl.TrainingRemovalReasonEntry;
import curam.providerservice.ProviderOfferingStatus;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.training.impl.TrainingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * This process class provides the functionality for License related
 * presentation layer.
 */
public abstract class License extends curam.cpm.facade.base.License {

  /**
   * Reference to License DAO
   */
  @Inject
  protected LicenseDAO licenseDAO;

  /**
   * Reference to LicenseRenewal DAO
   */
  @Inject
  protected LicenseRenewalDAO licenseRenewalDAO;

  /**
   * Reference to ReasonForNonCompliance DAO
   */
  @Inject
  protected ReasonForNonComplianceDAO reasonForNonComplianceDAO;

  /**
   * Reference to LicenseServiceOffering DAO
   */
  @Inject
  protected LicenseServiceOfferingDAO licenseServiceOfferingDAO;

  /**
   * Reference to ServiceOffering DAO
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Reference to Provider DAO
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to LicenseTrainingRequirement DAO
   */
  @Inject
  protected LicenseTrainingRequirementDAO licenseTrainingRequirementDAO;

  /**
   * Reference to Training DAO
   */
  @Inject
  protected TrainingDAO trainingDAO;

  // BEGIN CR00117929, RD
  /**
   * Reference to LicenseApprovalCriteria
   */
  @Inject
  protected LicenseApprovalCriteria licenseApprovalCriteria;

  // END CR00117929

  // BEGIN CR00091082, PDN
  @Inject
  protected LicenseNumberGenerator licenseNumberGenerator;
  // END CR00091082

  // BEGIN CR00096014, MST
  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;
  // END CR00096014

  // BEGIN, CR00226594, FM
  @Inject
  protected Attachment attachmentObj;
  // END, CR00226594

  // BEGIN, CR00360398, CD
  @Inject
  private Provider<CMSMetadataInterface> cmsMetadataProvider;
  // END, CR00360398

  // BEGIN, CR00235511, GP
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;
  // END, CR00235511

  /**
   * Constructor
   */
  public License() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * Inserts a new license.
   *
   * @param dtls
   * the details of the license to be inserted
   * @return key which identifies the license that was inserted.
   * @throws AppException
   * @throws InformationalException
   */
  public LicenseKey createLicense(LicenseSummaryDetails dtls)
    throws AppException, InformationalException {

    LicenseKey licenseKey = new LicenseKey();

    curam.provider.impl.License license = licenseDAO.newInstance();

    // map details passed from client
    setLicenseFields(license, dtls);

    license.setRenewed(false);

    license.insert();

    licenseKey.licenseID = license.getID();

    return licenseKey;
  }

  /**
   * Updates an existing license.
   *
   * @param dtls
   * the details of the license to be modified
   * @return key containing the ID of the modified license.
   * @throws AppException
   * @throws InformationalException
   */
  public LicenseKey modifyLicense(LicenseSummaryDetails dtls)
    throws AppException, InformationalException {

    LicenseKey licenseKey = new LicenseKey();

    final curam.provider.impl.License license = licenseDAO.get(
      dtls.dtls.licenseID);

    // map details passed from client
    setLicenseFields(license, dtls);

    license.setRenewed(dtls.dtls.renewedInd);

    license.modify(dtls.dtls.versionNo);

    return licenseKey;
  }

  /**
   * Suspends a license.
   *
   * @param key
   * the key which identifies the license to be suspended
   * @throws AppException
   * @throws InformationalException
   */
  public void suspendLicense(LicenseSuspensionKey key) throws AppException,
      InformationalException {

    final curam.provider.impl.License license = licenseDAO.get(key.licenseID);

    license.suspend(LicenseSuspensionReasonEntry.get(key.suspensionReason),
      key.comments, key.versionNo);

    // Send Notification
    LicenseNotification licenseNotification = new LicenseNotification();
    LicenseNotificationKey licenseNotificationKey = new LicenseNotificationKey();

    licenseNotificationKey.licenseID = key.licenseID;
    licenseNotificationKey.event = LicenseNotificationEvent.SUSPENDLICENSE;

    licenseNotification.sendNotification(licenseNotificationKey, license);

  }

  /**
   * Rejects a license.
   *
   * @param key
   * the key which identifies the license to be rejected
   * @throws AppException
   * @throws InformationalException
   */
  public void rejectLicense(LicenseRejectionKey key) throws AppException,
      InformationalException {

    final curam.provider.impl.License license = licenseDAO.get(key.licenseID);

    license.reject(LicenseRejectionReasonEntry.get(key.rejectionReason),
      key.comments, key.versionNo);

    // Send Notification
    LicenseNotification licenseNotification = new LicenseNotification();
    LicenseNotificationKey licenseNotificationKey = new LicenseNotificationKey();

    licenseNotificationKey.licenseID = key.licenseID;
    licenseNotificationKey.event = LicenseNotificationEvent.REJECTLICENSE;

    licenseNotification.sendNotification(licenseNotificationKey, license);
  }

  /**
   * Cancels a license.
   *
   * @param key
   * the key which identifies the license to be canceled
   * @throws AppException
   * @throws InformationalException
   */
  public void cancelLicense(LicenseProviderAndVersionNumberKey key)
    throws AppException, InformationalException {

    final curam.provider.impl.License license = licenseDAO.get(key.licenseID);

    license.cancel(key.versionNo);

  }

  /**
   * Maps the fields that can be changed by the user to the fields on the
   * service layer object.
   *
   * NB cannot be modeled, as one of the arguments is non-generated.
   *
   * The values of the following fields are calculated by this method (any
   * values passed in will be ignored and overwritten):
   * <UL>
   * <LI>(dtls.licenseNumberUpper)</LI>
   * <LI>...</LI>
   * </UL>
   *
   * @param license
   * the service layer object into which the fields the user can
   * change must be mapped
   *
   * @param licenseDtls
   * struct contain fields set by the user (as well as other fields
   * which will be ignored)
   *
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void setLicenseFields(final curam.provider.impl.License license,
    // END, CR00177241
    final LicenseSummaryDetails licenseDtls) throws AppException,
      InformationalException {

    final curam.provider.impl.Provider provider = providerDAO.get(
      licenseDtls.dtls.providerConcernRoleID);

    license.setLicenseType(LicenseTypeEntry.get(licenseDtls.dtls.licenseType));
    final DateRange dateRange = new DateRange(licenseDtls.dtls.dateIssued,
      licenseDtls.dtls.expirationDate);

    license.setDateRange(dateRange);
    license.setComments(licenseDtls.dtls.comments);
    license.setMaximumPlaces(licenseDtls.dtls.maximumPlaces);
    license.setProvider(provider);
    license.setNumber(licenseDtls.dtls.licenseNumber);
    license.setIssuer(LicenseIssuerEntry.get(licenseDtls.dtls.issuer));
    license.setUser(getCurrentUser());
  }

  /**
   * Returns the current user of the system.
   *
   * @return the current user name.
   * @throws AppException
   * @throws InformationalException
   */
  public String getCurrentUser() throws AppException, InformationalException {

    // Create instance of System User
    SystemUser user = SystemUserFactory.newInstance();

    return user.getUserDetails().userName;

  }

  /**
   * Returns a list of all license status history records for this license.
   *
   * @param key
   * the key which identifies the license
   * @return list of license status history records.
   * @throws AppException
   * @throws InformationalException
   */
  public LicenseStatusHistorySummaryDetailsList listLicenseStatusHistory(
    LicenseKey key) throws AppException, InformationalException {

    final LicenseStatusHistorySummaryDetailsList licenseStatusHistoryList = new LicenseStatusHistorySummaryDetailsList();

    final curam.provider.impl.License license = licenseDAO.get(key.licenseID);

    List<LicenseStatusHistory> unModifiableLicenseStatusHistory = license.getStatusHistory();
    List<LicenseStatusHistory> licenseStatusHistoryRecords = new ArrayList<LicenseStatusHistory>();

    licenseStatusHistoryRecords.addAll(unModifiableLicenseStatusHistory);

    for (final curam.provider.impl.LicenseStatusHistory licenseStatusHistory : licenseStatusHistoryRecords) {

      LicenseStatusHistorySummaryDetails licenseStatusHistorySummaryDetails = new LicenseStatusHistorySummaryDetails();

      licenseStatusHistorySummaryDetails.dtls.licenseStatusHistoryID = licenseStatusHistory.getID();
      licenseStatusHistorySummaryDetails.dtls.licenseID = license.getID();
      licenseStatusHistorySummaryDetails.dtls.licenseStatus = licenseStatusHistory.getLicenseStatus().getCode();
      licenseStatusHistorySummaryDetails.dtls.effectiveDateTime = licenseStatusHistory.getEventDateTime();
      licenseStatusHistorySummaryDetails.dtls.createdBy = licenseStatusHistory.getUser();
      licenseStatusHistorySummaryDetails.dtls.rejectionReason = licenseStatusHistory.getRejectionReason().getCode();
      licenseStatusHistorySummaryDetails.dtls.suspensionReason = licenseStatusHistory.getSuspensionReason().getCode();

      // determine reason to display
      if (licenseStatusHistorySummaryDetails.dtls.licenseStatus.equals(
        LicenseStatus.SUSPENDED)) {

        licenseStatusHistorySummaryDetails.reason = licenseStatusHistory.getSuspensionReason().toUserLocaleString();

      } else if (licenseStatusHistorySummaryDetails.dtls.licenseStatus.equals(
        LicenseStatus.REJECTED)) {

        licenseStatusHistorySummaryDetails.reason = licenseStatusHistory.getRejectionReason().toUserLocaleString();
      }

      licenseStatusHistoryList.detailsList.addRef(
        licenseStatusHistorySummaryDetails);
    }

    return licenseStatusHistoryList;
  }
  
  // BEGIN, CR00248198, GP
  /**
   * Lists all the license status history details.
   *
   * @param licenseKey
   * License for which status history details are to be retrieved.
   *
   * @return A list of license status history details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public LicenseStatusHistoryDetailsList listLicenseStatusHistoryDetails(
    final LicenseKey licenseKey) throws AppException, InformationalException {

    LicenseStatusHistoryDetailsList licenseStatusHistoryDetailsList = new LicenseStatusHistoryDetailsList();

    LicenseStatusHistorySummaryDetailsList licenseStatusHistorySummaryDetailsList = listLicenseStatusHistory(
      licenseKey);

    for (final LicenseStatusHistorySummaryDetails licenseStatusHistorySummaryDetails : licenseStatusHistorySummaryDetailsList.detailsList.items()) {

      LicenseStatusHistoryDetails licenseStatusHistoryDetails = new LicenseStatusHistoryDetails();

      licenseStatusHistoryDetails.statusHistoryDetails = licenseStatusHistorySummaryDetails.dtls;
      licenseStatusHistoryDetails.reason = licenseStatusHistorySummaryDetails.reason;

      User user = userDAO.get(
        licenseStatusHistoryDetails.statusHistoryDetails.createdBy);

      licenseStatusHistoryDetails.createdByFullName = user.getFullName();

      licenseStatusHistoryDetailsList.licenseStatusHistoryDetails.addRef(
        licenseStatusHistoryDetails);
    }

    return licenseStatusHistoryDetailsList;
  }

  // END, CR00248198
  
  /**
   * Returns a list of all license records for a provider.
   *
   * @param key
   * the key which identifies the provider
   * @return List of licenses based on specified provider.
   * @throws AppException
   * @throws InformationalException
   */
  public LicenseSummaryDetailsList listLicenses(ProviderConcernRoleKey key)
    throws AppException, InformationalException {

    final curam.provider.impl.Provider provider = providerDAO.get(
      key.providerConcernRoleID);

    LicenseSummaryDetailsList licenseList = new LicenseSummaryDetailsList();

    Set<curam.provider.impl.License> unsortedLicenses = licenseDAO.searchLicensesByProvider(
      provider);

    for (final curam.provider.impl.License license : sortLicenses(
      unsortedLicenses)) {

      LicenseSummaryDetails licenseSummaryDetails = new LicenseSummaryDetails();

      licenseSummaryDetails.dtls.licenseID = license.getID();
      licenseSummaryDetails.dtls.versionNo = license.getVersionNo();
      licenseSummaryDetails.dtls.providerConcernRoleID = license.getProvider().getID();
      licenseSummaryDetails.dtls.licenseNumber = license.getLicenseNumber();
      licenseSummaryDetails.dtls.licenseType = license.getLicenseType().getCode();
      licenseSummaryDetails.dtls.dateIssued = license.getDateRange().start();
      licenseSummaryDetails.dtls.expirationDate = license.getDateRange().end();
      licenseSummaryDetails.dtls.createdBy = license.getUser();
      licenseSummaryDetails.dtls.licenseStatus = license.getLifecycleState().getCode();
      licenseSummaryDetails.dtls.renewedInd = license.isRenewed();
      // BEGIN, CR00235511, GP
      licenseSummaryDetails.dtls.issuer = license.getIssuer().getCode();
      // END, CR00235511

      licenseList.licenseSummaryDetails.addRef(licenseSummaryDetails);
    }

    licenseList.viewProviderSummaryDetails.pageContextDescription = getContextDescription(
      key.providerConcernRoleID);

    return licenseList;
  }

  // BEGIN, CR00235511, GP
  /**
   * Retrieves a list of licenses for a provider.
   *
   * @param providerConcernRoleKey
   * Provider for which licenses are to be retrieved.
   *
   * @return List of licenses for a provider.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public LicenseSummaryList listLicensesForProvider(
    final ProviderConcernRoleKey providerConcernRoleKey) throws AppException,
      InformationalException {

    LicenseSummaryList licenseSummaryList = new LicenseSummaryList();

    LicenseSummaryDetailsList licenseSummaryDetailsList = listLicenses(
      providerConcernRoleKey);

    for (final LicenseSummaryDetails licenseSummaryDetails : licenseSummaryDetailsList.licenseSummaryDetails.items()) {

      LicenseDetails licenseDetails = new LicenseDetails();

      licenseDetails.createdBy = licenseSummaryDetails.dtls.createdBy;
      licenseDetails.dateIssued = licenseSummaryDetails.dtls.dateIssued;
      licenseDetails.expirationDate = licenseSummaryDetails.dtls.expirationDate;
      licenseDetails.licenseID = licenseSummaryDetails.dtls.licenseID;
      licenseDetails.licenseNumber = licenseSummaryDetails.dtls.licenseNumber;
      licenseDetails.licenseStatus = licenseSummaryDetails.dtls.licenseStatus;
      licenseDetails.licenseType = licenseSummaryDetails.dtls.licenseType;
      licenseDetails.pageContextDescription = licenseSummaryDetails.pageContextDescription;
      licenseDetails.providerConcernRoleID = licenseSummaryDetails.dtls.providerConcernRoleID;
      licenseDetails.renewedInd = licenseSummaryDetails.dtls.renewedInd;
      licenseDetails.versionNo = licenseSummaryDetails.dtls.versionNo;
      licenseDetails.issuer = licenseSummaryDetails.dtls.issuer;

      User user = userDAO.get(licenseDetails.createdBy);

      licenseDetails.createdByFullName = user.getFullName();

      licenseSummaryList.licenseDetails.addRef(licenseDetails);

      // BEGIN, CR00236219, PS
      if (LicenseStatusEntry.APPROVED.getCode().equals(
        licenseDetails.licenseStatus)) {

        licenseDetails.suspendInd = true;
        licenseDetails.editInd = true;
        licenseDetails.renewInd = true;

      } else if (LicenseStatusEntry.INPROGRESS.getCode().equals(
        licenseDetails.licenseStatus)) {

        licenseDetails.editInd = true;
        licenseDetails.approvedInd = true;
        licenseDetails.rejectInd = true;
        licenseDetails.deleteInd = true;

      } else if (LicenseStatusEntry.SUSPENDED.getCode().equals(
        licenseDetails.licenseStatus)) {

        licenseDetails.editInd = true;
        licenseDetails.approvedInd = true;

      } else if (LicenseStatusEntry.REJECTED.getCode().equals(
        licenseDetails.licenseStatus)) {

        licenseDetails.editInd = true;
        licenseDetails.approvedInd = true;

      }
      // END, CR00236219
    }

    return licenseSummaryList;
  }

  // END, CR00235511

  /**
   * Sorts a set of licenses by date issued.
   *
   * @param unsortedLicenses
   * the set of licenses to be sorted
   * @return a sorted list of licenses for display.
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected List<curam.provider.impl.License> sortLicenses(
    // END, CR00177241
    final Set<curam.provider.impl.License> unsortedLicenses) {

    // Sort by date issued (newest first)
    final List<curam.provider.impl.License> licenses = new ArrayList<curam.provider.impl.License>(
      unsortedLicenses);

    Collections.sort(licenses,
      new Comparator<curam.provider.impl.License>() {
      public int compare(final curam.provider.impl.License lhs,
        curam.provider.impl.License rhs) {
        return rhs.getDateRange().start().compareTo(lhs.getDateRange().start());
      }
    });

    return licenses;
  }

  /**
   * Returns the license.
   *
   * @param key
   * the key which identifies the license
   * @return the license.
   * @throws AppException
   * @throws InformationalException
   */
  public LicenseSummaryDetails viewLicense(LicenseKey key)
    throws AppException, InformationalException {

    LicenseSummaryDetails licenseSummaryDetails = new LicenseSummaryDetails();

    final curam.provider.impl.License license = licenseDAO.get(key.licenseID);

    licenseSummaryDetails.dtls.licenseID = license.getID();
    licenseSummaryDetails.dtls.versionNo = license.getVersionNo();
    licenseSummaryDetails.dtls.providerConcernRoleID = license.getProvider().getID();
    licenseSummaryDetails.dtls.issuer = license.getIssuer().getCode();
    licenseSummaryDetails.dtls.licenseNumber = license.getLicenseNumber();
    licenseSummaryDetails.dtls.dateIssued = license.getDateRange().start();
    licenseSummaryDetails.dtls.expirationDate = license.getDateRange().end();
    licenseSummaryDetails.dtls.licenseType = license.getLicenseType().getCode();
    licenseSummaryDetails.dtls.createdBy = license.getUser();
    licenseSummaryDetails.dtls.maximumPlaces = license.getMaximumPlaces();
    licenseSummaryDetails.dtls.comments = license.getComments();
    licenseSummaryDetails.dtls.renewedInd = license.isRenewed();
    licenseSummaryDetails.renewalCompliant = "";
    licenseSummaryDetails.maximumPlacesStr = "";

    if (licenseSummaryDetails.dtls.maximumPlaces == 0) {

      licenseSummaryDetails.maximumPlacesStr = "";

    } else {

      licenseSummaryDetails.maximumPlacesStr = String.valueOf(
        licenseSummaryDetails.dtls.maximumPlaces);
    }

    final LicenseStatusEntry licenseStatus = license.getLifecycleState();

    licenseSummaryDetails.dtls.licenseStatus = licenseStatus.getCode();

    if (licenseStatus.equals(LicenseStatusEntry.SUSPENDED)) {
      licenseSummaryDetails.suspensionReason = license.getSuspensionReason().getCode();
    } else if (licenseStatus.equals(LicenseStatusEntry.REJECTED)) {
      licenseSummaryDetails.rejectionReason = license.getRejectionReason().getCode();
    }

    // there will only one record as the license
    // cannot be renewed more that once
    for (final curam.provider.impl.LicenseRenewal licenseRenewal : licenseRenewalDAO.searchByLicense(
      license)) {

      licenseSummaryDetails.licenseRenewalDetails.renewalCompliantInd = licenseRenewal.isRenewalCompliant();
      licenseSummaryDetails.licenseRenewalDetails.renewalDate = licenseRenewal.getRenewalDate();
    }

    licenseSummaryDetails.licenseRenewalDetails.reasonsForNonCompliance = addNonComplianceReasons(key).toString();

    // determine renewal compliant string to display
    if ((!licenseSummaryDetails.licenseRenewalDetails.renewalCompliantInd)
      && (licenseSummaryDetails.licenseRenewalDetails.reasonsForNonCompliance.length()
        > 0)) {
      // BEGIN, CR00186107, SS
      licenseSummaryDetails.renewalCompliant = new curam.util.exception.LocalisableString(curam.message.LICENSE.NO_TEXT).getMessage();
    } else if (licenseSummaryDetails.licenseRenewalDetails.renewalCompliantInd) {

      licenseSummaryDetails.renewalCompliant = new curam.util.exception.LocalisableString(curam.message.LICENSE.YES_TEXT).getMessage();
      // END, CR00186107
    }

    licenseSummaryDetails.pageContextDescription = getContextDescription(
      licenseSummaryDetails.dtls.providerConcernRoleID);

    return licenseSummaryDetails;
  }

  /**
   * Returns the license status history.
   *
   * @param key
   * the key which identifies the license status history record
   * @return the license status history.
   * @throws AppException
   * @throws InformationalException
   */
  public LicenseStatusHistorySummaryDetails viewLicenseStatusHistory(
    LicenseAndStatusHistoryKey key) throws AppException,
      InformationalException {

    LicenseStatusHistorySummaryDetails licenseStatusHistorySummaryDetails = new LicenseStatusHistorySummaryDetails();

    final curam.provider.impl.License license = licenseDAO.get(key.licenseID);

    List<LicenseStatusHistory> unModifiableLicenseStatusHistory = license.getStatusHistory();
    List<LicenseStatusHistory> licenseStatusHistoryRecords = new ArrayList<LicenseStatusHistory>();

    licenseStatusHistoryRecords.addAll(unModifiableLicenseStatusHistory);

    for (final curam.provider.impl.LicenseStatusHistory licenseStatusHistory : licenseStatusHistoryRecords) {

      if (licenseStatusHistory.getID() == key.licenseStatusHistoryID) {
        licenseStatusHistorySummaryDetails.dtls.comments = licenseStatusHistory.getComments();
        licenseStatusHistorySummaryDetails.dtls.effectiveDateTime = licenseStatusHistory.getEventDateTime();
        licenseStatusHistorySummaryDetails.dtls.licenseStatus = licenseStatusHistory.getLicenseStatus().getCode();
        licenseStatusHistorySummaryDetails.dtls.createdBy = licenseStatusHistory.getUser();
        licenseStatusHistorySummaryDetails.dtls.rejectionReason = licenseStatusHistory.getRejectionReason().getCode();
        licenseStatusHistorySummaryDetails.dtls.suspensionReason = licenseStatusHistory.getSuspensionReason().getCode();

        // determine reason to display
        if (licenseStatusHistorySummaryDetails.dtls.licenseStatus.equals(
          LicenseStatus.SUSPENDED)) {

          licenseStatusHistorySummaryDetails.reason = licenseStatusHistory.getSuspensionReason().toUserLocaleString();

        } else if (licenseStatusHistorySummaryDetails.dtls.licenseStatus.equals(
          LicenseStatus.REJECTED)) {

          licenseStatusHistorySummaryDetails.reason = licenseStatusHistory.getRejectionReason().toUserLocaleString();
        }
      }
    }

    return licenseStatusHistorySummaryDetails;
  }

  /**
   * Returns a list on non-compliance reasons selected and retrieves their
   * codetable description.
   *
   * @param LicenseKey
   * the key which identifies the license
   * @return list of non compliance reasons selected.
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN , CR00177241, PM
  protected StringBuffer addNonComplianceReasons(LicenseKey key)
    // END, CR00177241
    throws AppException, InformationalException {

    StringBuffer listOfNonComplianceReasons = new StringBuffer();

    final curam.provider.impl.License license = licenseDAO.get(key.licenseID);

    for (final curam.provider.impl.ReasonForNonCompliance reasonForNonCompliance : reasonForNonComplianceDAO.searchByLicense(
      license)) {

      final String[] nonComplianceReasons = StringUtil.tabText2StringListWithTrim(reasonForNonCompliance.getNonComplianceReasons()).items();

      for (final String reasonCode : nonComplianceReasons) {

        NonComplianceReason nonComplianceReason = new NonComplianceReason();

        // Begin CR00096779, ABS
        nonComplianceReason.code = reasonCode;
        // End CR00096779
        nonComplianceReason.description = curam.util.type.CodeTable.getOneItemForUserLocale(
          LicenseNonComplianceReason.TABLENAME, nonComplianceReason.code);

        listOfNonComplianceReasons.append(nonComplianceReason.description).append(
          GeneralConstants.kNewLine);
      }
    }

    return listOfNonComplianceReasons;
  }

  /**
   * Returns the context description for license pages.
   *
   * @param providerConcernRoleID
   * the providers concern role ID
   * @return the context description.
   * @throws AppException
   * @throws InformationalException
   */
  public String getContextDescription(long providerConcernRoleID)
    throws AppException, InformationalException {

    String contextDescription = "";

    // creating viewProviderSummaryDetails struct
    ViewProviderSummaryDetails viewProviderSummaryDetails = new ViewProviderSummaryDetails();

    // Provider Entity
    final curam.provider.impl.Provider provider = providerDAO.get(
      providerConcernRoleID);

    // Get the Provider Reference Number
    String refNumber = provider.getPrimaryAlternateID();

    // Set the summary details
    viewProviderSummaryDetails.details.concernRoleID = providerConcernRoleID;
    viewProviderSummaryDetails.details.providerName = provider.getName();
    viewProviderSummaryDetails.details.referenceNumber = refNumber;

    // construct the page context description
    viewProviderSummaryDetails.pageContextDescription = provider.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + refNumber;
    contextDescription = viewProviderSummaryDetails.details.providerName
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace
      + viewProviderSummaryDetails.details.referenceNumber;

    return contextDescription;
  }

  // BEGIN CR00117929, RD

  /**
   * Check if there are training requirements specified for the license type,
   * then all trainings marked as 'Required' must be 'Completed' or 'Waived'
   * for all active provider members. If this rule is not satisfied, the user
   * is notified and allowed to continue with the approval of license process.
   *
   * @param licenseProviderAndVersionNumberKey
   * the key which identifies the license.
   * @return List of Informational messages if the business rule fails.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMessageList checkLicenseApprovalCriteria(
    LicenseProviderAndVersionNumberKey licenseProviderAndVersionNumberKey)
    throws AppException, InformationalException {

    InformationalMessageList informationalMessageList = licenseApprovalCriteria.checkLicenseApprovalCriteria(
      licenseProviderAndVersionNumberKey);

    return informationalMessageList;

  }

  // END CR00117929

  /**
   * Approves a license.
   *
   * @param key
   * the key which identifies the license
   * @throws AppException
   * @throws InformationalException
   */
  public void approveLicense(LicenseProviderAndVersionNumberKey key)
    throws AppException, InformationalException {

    final curam.provider.impl.License license = licenseDAO.get(key.licenseID);

    license.approve(key.comments, key.versionNo);

    // Send Notification
    LicenseNotification licenseNotification = new LicenseNotification();
    LicenseNotificationKey licenseNotificationKey = new LicenseNotificationKey();

    licenseNotificationKey.licenseID = key.licenseID;
    licenseNotificationKey.event = LicenseNotificationEvent.APPROVELICENSE;

    licenseNotification.sendNotification(licenseNotificationKey, license);

  }

  /**
   * Renews a license.
   *
   * @param dtls
   * the license to be renewed
   * @return key which identifies the renewed license.
   * @throws AppException
   * @throws InformationalException
   */
  public LicenseKey renewLicense(LicenseRenewalSummaryDetails dtls)
    throws AppException, InformationalException {

    LicenseKey licenseKey = new LicenseKey();

    curam.provider.impl.License renewedLicense = licenseDAO.newInstance();

    final curam.provider.impl.License license = licenseDAO.get(dtls.licenseID);

    validateLicenseRenewalDetails(dtls, license);

    licenseKey.licenseID = license.getID();

    if (dtls.renewalCompliantInd) {

      // modify original license record to indicate that it has been
      // renewed
      int versionNo = 0;
      String comments = "";

      versionNo = license.getVersionNo();
      license.setRenewed(true);
      license.modify(versionNo);

      setRenewedLicenseFields(license, renewedLicense, dtls);

      // insert a new license
      renewedLicense.insert();

      versionNo = renewedLicense.getVersionNo();
      // the renewed license is automatically approved
      // with no status history comments
      renewedLicense.approve(comments, versionNo);

      // insert a license renewal
      insertLicenseRenewal(licenseKey, dtls);

    } else {

      curam.provider.impl.ReasonForNonCompliance reasonForNonCompliance = reasonForNonComplianceDAO.newInstance();

      reasonForNonCompliance.setLicense(license);
      reasonForNonCompliance.setNonComplianceReasons(
        dtls.reasonsForNonCompliance);

      reasonForNonCompliance.insert();

    }
    
    // BEGIN, CR00281474, MR
    final LicenseNotification licenseNotification = new LicenseNotification();
    final LicenseNotificationKey licenseNotificationKey = new LicenseNotificationKey();

    licenseNotificationKey.licenseID = licenseKey.licenseID;
    licenseNotificationKey.event = LicenseNotificationEvent.RENEWLICENSE;

    licenseNotification.sendNotification(licenseNotificationKey, license);
    // END, CR00281474
    return licenseKey;
  }

  /**
   * Validates the license renewal details.
   *
   * @param dtls
   * the license renewal to be validated
   * @param license
   * the license
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void validateLicenseRenewalDetails(
    // END, CR00177241
    final LicenseRenewalSummaryDetails dtls,
    final curam.provider.impl.License license) throws AppException,
      InformationalException {

    if (license.getLifecycleState().getCode().equals(LicenseStatus.CANCELED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_CANNOT_RENEW_DELETED_LICENSE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if ((dtls.renewalDate.equals(Date.kZeroDate)
      && dtls.renewalCompliantInd)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XFV_RENEWAL_COMPLIANT_SET_RENEWAL_DATE_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    } else if ((!dtls.renewalDate.equals(Date.kZeroDate)
      && !dtls.renewalCompliantInd)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XFV_RENEWAL_DATE_ENTERED_RENEWAL_COMPLIANT_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } // Either renewal date and renewal compliant must be entered or
    // Non-Compliance
    // Reasons must be entered
    else if (((dtls.renewalDate.equals(Date.kZeroDate)
      || !dtls.renewalCompliantInd))
        && dtls.reasonsForNonCompliance.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XFV_LICENSE_RENEWAL_DETAILS_OR_NON_COMPLIANCE_REASONS_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Non-Compliance Reason must not be entered if renewal details have
    // been
    // entered
    if (((!dtls.renewalDate.equals(Date.kZeroDate) || dtls.renewalCompliantInd))
      && dtls.reasonsForNonCompliance.length() > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XFV_LICENSE_RENEWAL_NON_COMPLIANCE_REASON_ENTERED_AND_RENEWAL_DETAILS_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    final Set<LicenseRenewal> licenseRenewalRecords = licenseRenewalDAO.searchByLicense(
      license);

    // This license has already been renewed
    if (licenseRenewalRecords.size() == 1) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_XRV_LICENSE_RENEWED_ALREADY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  /**
   * Maps the fields that can be changed by the user to the fields on the
   * service layer object.
   *
   * NB cannot be modeled, as one of the arguments is non-generated.
   *
   * @param licenseKey
   * key which identifies the license
   * @param dtls
   * struct contain fields set by the user (as well as other fields
   * which will be ignored)
   *
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void insertLicenseRenewal(final LicenseKey licenseKey,
    // END, CR00177241
    final LicenseRenewalSummaryDetails dtls) throws AppException,
      InformationalException {

    final curam.provider.impl.License license = licenseDAO.get(
      licenseKey.licenseID);

    curam.provider.impl.LicenseRenewal licenseRenewal = licenseRenewalDAO.newInstance();

    licenseRenewal.setLicense(license);
    licenseRenewal.setComments(dtls.comments);
    licenseRenewal.setRenewalCompliant(dtls.renewalCompliantInd);
    licenseRenewal.setRenewalDate(dtls.renewalDate);

    licenseRenewal.insert();

  }

  /**
   * Maps the fields that can be changed by the user to the fields on the
   * service layer object.
   *
   * NB cannot be modeled, as one of the arguments is non-generated.
   *
   * @param LicenseRenewalSummaryDetails
   * struct contain fields set by the user (as well as other fields
   * which will be ignored)
   *
   * @param license
   * the service layer object into which the fields the user can
   * change must be mapped
   *
   * @param renewedLicense
   * the service layer object into which the fields the user can
   * change must be mapped
   *
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void setRenewedLicenseFields(
    // END, CR00177241
    final curam.provider.impl.License license,
    final curam.provider.impl.License renewedLicense,
    final LicenseRenewalSummaryDetails dtls) throws AppException,
      InformationalException {

    final curam.provider.impl.Provider provider = providerDAO.get(
      license.getProvider().getID());

    renewedLicense.setProvider(provider);

    final DateRange dateRange = new DateRange(
      license.getDateRange().end().addDays(1), dtls.expirationDate);

    renewedLicense.setRenewed(false);
    renewedLicense.setDateRange(dateRange);
    renewedLicense.setLicenseType(license.getLicenseType());
    renewedLicense.setNumber(license.getLicenseNumber());
    renewedLicense.setIssuer(license.getIssuer());
    renewedLicense.setMaximumPlaces(license.getMaximumPlaces());
    renewedLicense.setComments(license.getComments());
    renewedLicense.setUser(getCurrentUser());
  }

  /**
   * Returns a list of service offerings covered by a license.
   *
   * @param key
   * the key which identifies the license and the provider
   * @return list of service offerings for a license.
   * @throws AppException
   * @throws InformationalException
   */
  public LicenseServiceOfferingsSummaryDetailsList listLicenseServiceOfferings(
    LicenseIDProviderKey key) throws AppException,
      InformationalException {

    LicenseServiceOfferingsSummaryDetailsList list = new LicenseServiceOfferingsSummaryDetailsList();

    final curam.provider.impl.License license = licenseDAO.get(key.licenseID);

    for (final curam.provider.impl.LicenseServiceOffering licenseServiceOffering : licenseServiceOfferingDAO.searchByLicense(
      license)) {

      LicenseServiceOfferingsSummaryDetails licenseServiceOfferingsSummaryDetails = new LicenseServiceOfferingsSummaryDetails();

      licenseServiceOfferingsSummaryDetails.serviceOfferingID = licenseServiceOffering.getServiceOffering().getID();

      // BEGIN, CR00207756, RD
      ServiceOffering serviceOffering = serviceOfferingDAO.get(
        licenseServiceOfferingsSummaryDetails.serviceOfferingID);

      licenseServiceOfferingsSummaryDetails.name = serviceOffering.getName();
      licenseServiceOfferingsSummaryDetails.recordStatus = serviceOffering.getLifecycleState().getCode();
      // END, CR00207756

      licenseServiceOfferingsSummaryDetails.licenseID = licenseServiceOffering.getLicense().getID();
      licenseServiceOfferingsSummaryDetails.licenseServiceOfferingLinkID = licenseServiceOffering.getID();
      licenseServiceOfferingsSummaryDetails.versionNo = licenseServiceOffering.getVersionNo();

      list.serviceOfferingSummaryDetails.addRef(
        licenseServiceOfferingsSummaryDetails);
    }

    list.viewProviderSummaryDetails.pageContextDescription = getContextDescription(
      key.providerConcernRoleID);
    list.viewProviderSummaryDetails.details.concernRoleID = key.providerConcernRoleID;

    return list;
  }

  /**
   * Returns a list of all active provider offerings for a given provider.
   *
   * @param key
   * the key which identifies the provider
   * @return list of the provider offerings for a given provider.
   * @throws AppException
   * @throws InformationalException
   */
  public ProviderOfferingSummaryDetailsList listActiveServiceOfferingsByProvider(
    ProviderKey key) throws AppException, InformationalException {

    ProviderOfferingSummaryDetailsList list = new ProviderOfferingSummaryDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      key.providerConcernRoleID);

    for (final curam.providerservice.impl.ProviderOffering providerOffering : provider.getProviderOfferings()) {

      if (!providerOffering.getLifecycleState().getCode().equals(
        ProviderOfferingStatus.CANCELED)) {

        ProviderOfferingSummaryDetails providerOfferingSummaryDetails = new ProviderOfferingSummaryDetails();

        final curam.serviceoffering.impl.ServiceOffering serviceOffering = providerOffering.getServiceOffering();

        providerOfferingSummaryDetails.serviceOfferingID = serviceOffering.getID();
        providerOfferingSummaryDetails.providerOfferingID = providerOffering.getID();

        providerOfferingSummaryDetails.startDate = providerOffering.getDateRange().start();
        providerOfferingSummaryDetails.endDate = providerOffering.getDateRange().end();
        providerOfferingSummaryDetails.name = serviceOffering.getName();
        providerOfferingSummaryDetails.recordStatus = providerOffering.getLifecycleState().getCode();

        list.providerOfferingSummaryDetails.addRef(
          providerOfferingSummaryDetails);
      }
    }

    return list;
  }

  /**
   * Adds a license service offering.
   *
   * @param dtls
   * the license service offering
   * @throws AppException
   * @throws InformationalException
   */
  public void addLicenseServiceOfferings(
    LicenseServiceOfferingsSummaryDetails dtls) throws AppException,
      InformationalException {

    final curam.provider.impl.License license = licenseDAO.get(dtls.licenseID);

    final String[] serviceOfferingIDs = StringUtil.tabText2StringListWithTrim(dtls.serviceOfferingIDs).items();

    for (final String serviceOfferingID : serviceOfferingIDs) {

      curam.provider.impl.LicenseServiceOffering licenseServiceOffering = licenseServiceOfferingDAO.newInstance();

      final curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceOfferingDAO.get(
        Long.parseLong(serviceOfferingID.trim()));

      licenseServiceOffering.setLicense(license);
      licenseServiceOffering.setServiceOffering(serviceOffering);

      final Set<LicenseServiceOffering> serviceOfferingDuplicates = licenseServiceOfferingDAO.searchDuplicateServiceOfferingForLicense(
        licenseServiceOffering.getLicense(),
        licenseServiceOffering.getServiceOffering());

      if (serviceOfferingDuplicates.size() >= 1) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          LICENSEExceptionCreator.ERR_LICENSE_XRV_SERVICE_OFFERING_ALREADY_EXISTS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }

      // insert a link record for each service offering
      licenseServiceOffering.insert();
    }
  }

  /**
   * Deletes a service offering from a license.
   *
   * @param key
   * the key which identifies the service offering to be deleted
   * @throws AppException
   * @throws InformationalException
   */
  public void deleteServiceOfferingLink(
    LicenseServiceOfferingLinkVersionNumberKey key)
    throws AppException, InformationalException {

    final curam.provider.impl.LicenseServiceOffering licenseServiceOffering = licenseServiceOfferingDAO.get(
      key.licenseServiceOfferingLinkID);

    licenseServiceOffering.deleteServiceOfferingLink(key.versionNo);

  }

  /**
   * Returns a list of license renewal non compliance reasons.
   *
   * @return list containing the license renewal non compliance reasons.
   * @throws AppException
   * @throws InformationalException
   */
  public NonComplianceReasonList listNonComplianceReasons()
    throws AppException, InformationalException {

    NonComplianceReasonList nonComplianceReasonList = new NonComplianceReasonList();

    // Get locale value and codetable
    String locale = curam.util.transaction.TransactionInfo.getProgramLocale();
    String codeTableName = LicenseNonComplianceReason.TABLENAME;

    // Get non compliance reasons for locale value and codetable
    curam.util.type.StringList nonComplianceReasons = curam.util.type.CodeTable.getAllCodesStringList(
      codeTableName, locale);

    // Read code table values into a list
    int numOfNonComplianceReasons = nonComplianceReasons.size();

    for (int i = 0; i < numOfNonComplianceReasons; i++) {
      NonComplianceReason nonComplianceReason = new NonComplianceReason();

      nonComplianceReason.code = nonComplianceReasons.item(i);

      nonComplianceReason.description = curam.util.type.CodeTable.getOneItemForUserLocale(
        codeTableName, nonComplianceReason.code);

      nonComplianceReasonList.reasonList.addRef(nonComplianceReason);
    }

    return nonComplianceReasonList;
  }

  // BEGIN CR00091082, PDN

  /**
   * Retrieves details needed such as default values for the creation of a
   * License.
   *
   * @return details needed for creating a license.
   * @throws AppException
   * @throws InformationalException
   */
  public LicenseCreateDetails readLicenseCreateDetails() throws AppException,
      InformationalException {

    LicenseCreateDetails licenseCreateDetails = new LicenseCreateDetails();

    licenseCreateDetails.licenseNumber = licenseNumberGenerator.generateReferenceNumber();

    return licenseCreateDetails;
  }

  // END CR00091082

  // BEGIN CR00108646, GYH

  /**
   * Lists all the license types in the user specific locale.
   *
   * @return The list of all license types.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END CR00108646
  public LicenseTypeList listLicenseType() throws AppException,
      InformationalException {

    // BEGIN CR00108646, GYH
    // Read all license types from the license type code table.
    // END CR00108646
    LicenseTypeList licenseTypeList = new LicenseTypeList();
    String strLicenseTypeCodes[] = curam.util.type.CodeTable.getAllCodes(
      LicenseType.TABLENAME, TransactionInfo.getProgramLocale());

    for (int i = 0; i < strLicenseTypeCodes.length; i++) {
      curam.cpm.facade.struct.LicenseType licenseType = new curam.cpm.facade.struct.LicenseType();

      licenseType.licenseType = strLicenseTypeCodes[i];
      licenseType.licenseTypeDesc = CodeTable.getOneItem(
        LicenseTypeEntry.TABLENAME, strLicenseTypeCodes[i]);
      licenseTypeList.details.addRef(licenseType);
    }

    return licenseTypeList;
  }

  // BEGIN CR00108646, GYH

  /**
   * Creates a training requirement for a license type.
   *
   * @param details
   * Contains training requirement details for a license type.
   * @return The unique number of license training requirement record i.e.
   * licenseTrainingRequirementID.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END CR00108646
  public LicenseTrainingRequirementKey createTrainingRequirementForLicenseType(
    LicenseTrainingRequirementDetails details) throws AppException,
      InformationalException {

    curam.provider.impl.LicenseTrainingRequirement licenseTrainingRequirement = licenseTrainingRequirementDAO.newInstance();

    setLicenseTrainingRequirement(licenseTrainingRequirement, details);

    licenseTrainingRequirement.insert();

    LicenseTrainingRequirementKey licenseTrainingRequirementKey = new LicenseTrainingRequirementKey();

    licenseTrainingRequirementKey.licenseTrainingRequirementID = licenseTrainingRequirement.getID();

    return licenseTrainingRequirementKey;
  }

  // BEGIN CR00108646, GYH

  /**
   * Lists all the training requirements for a license type.
   *
   * @param key
   * Contains the code value of a license type.
   * @return The list of training requirements for a license type.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END CR00108646
  public LicenseTrainingRequirementDetailsList listTrainingRequirementForLicenseType(
    LicenseTrainingRequirementReadmultiKey key) throws AppException,
      InformationalException {

    LicenseTrainingRequirementDetailsList licenseTrainingRequirementDetailsList = new LicenseTrainingRequirementDetailsList();

    // Retrieve all the training requirements for a license type sorted by
    // training name.
    List<curam.provider.impl.LicenseTrainingRequirement> licenseTrainingRequirements = sortLicenseTrainingRequirements(
      licenseTrainingRequirementDAO.searchByLicenseType(key.licenseType));

    for (final curam.provider.impl.LicenseTrainingRequirement licenseTrainingRequirement : licenseTrainingRequirements) {
      licenseTrainingRequirementDetailsList.details.addRef(
        getLicenseTrainingRequirementFields(licenseTrainingRequirement));
    }

    return licenseTrainingRequirementDetailsList;
  }

  // BEGIN CR00108646, GYH

  /**
   * Modifies a training requirement for a license type.
   *
   * @param details
   * Contains training requirement details to be modified for a
   * license type.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END CR00108646
  public void modifyTrainingRequirementForLicenseType(
    LicenseTrainingRequirementDetails details) throws AppException,
      InformationalException {

    curam.provider.impl.LicenseTrainingRequirement licenseTrainingRequirement = licenseTrainingRequirementDAO.get(
      details.dtls.licenseTrainingRequirementID);

    setLicenseTrainingRequirement(licenseTrainingRequirement, details);

    licenseTrainingRequirement.modify(details.dtls.versionNo);
  }

  // BEGIN CR00108646, GYH

  /**
   * Removes the training requirement from a license type. The status of the
   * training requirement record will be updated to 'Removed'.
   *
   * @param details
   * Contains license type code and removal reason details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END CR00108646
  public void removeTrainingRequirementFromLicenseType(
    TrainingRemovalDetails details) throws AppException,
      InformationalException {

    curam.provider.impl.LicenseTrainingRequirement licenseTrainingRequirement = licenseTrainingRequirementDAO.get(
      details.keyVesrion.id);

    licenseTrainingRequirement.setRemovalReason(
      TrainingRemovalReasonEntry.get(details.removalReason));

    licenseTrainingRequirement.remove(details.keyVesrion.version);

  }

  // BEGIN CR00108646, GYH

  /**
   * Retrieves a training Requirement details for a license type.
   *
   * @param key
   * Contains license training requirement ID.
   * @return The training requirement detail for a license type.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END CR00108646
  public LicenseTrainingRequirementDetails viewTrainingRequirementForLicenseType(
    LicenseTrainingRequirementKey key) throws AppException,
      InformationalException {

    curam.provider.impl.LicenseTrainingRequirement licenseTrainingRequirement = licenseTrainingRequirementDAO.get(
      key.licenseTrainingRequirementID);

    return getLicenseTrainingRequirementFields(licenseTrainingRequirement);
  }

  // BEGIN CR00108646, GYH

  /**
   * Sets the training requirement details for a license type.
   *
   * @param licenseTrainingRequirement
   * The LicenseTrainingRequirement instance.
   * @param details
   * The training requirement for a license type details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END CR00108646
  // BEGIN, CR00177241, PM
  protected void setLicenseTrainingRequirement(
    // END, CR00177241
    final curam.provider.impl.LicenseTrainingRequirement licenseTrainingRequirement,
    final LicenseTrainingRequirementDetails details)
    throws AppException, InformationalException {

    licenseTrainingRequirement.setTraining(
      trainingDAO.get(details.dtls.trainingID));
    licenseTrainingRequirement.setCompletion(
      TrainingCompletionEntry.get(details.dtls.completion));
    licenseTrainingRequirement.setLicenseType(
      LicenseTypeEntry.get(details.dtls.licenseType));
  }

  // BEGIN CR00108646, GYH

  /**
   * Gets the training requirement details for a license type.
   *
   * @param licenseTrainingRequirement
   * The LicenseTrainingRequirement instance.
   * @return The training requirement for a license type details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END CR00108646
  // BEGIN, CR00177241, PM
  protected LicenseTrainingRequirementDetails getLicenseTrainingRequirementFields(
    // END, CR00177241
    final curam.provider.impl.LicenseTrainingRequirement licenseTrainingRequirement)
    throws AppException, InformationalException {

    LicenseTrainingRequirementDetails licenseTrainingRequirementDetails = new LicenseTrainingRequirementDetails();

    licenseTrainingRequirementDetails.dtls.licenseTrainingRequirementID = licenseTrainingRequirement.getID();
    licenseTrainingRequirementDetails.dtls.trainingID = licenseTrainingRequirement.getTraining().getID();
    licenseTrainingRequirementDetails.dtls.completion = licenseTrainingRequirement.getCompletion().getCode();
    licenseTrainingRequirementDetails.dtls.licenseType = licenseTrainingRequirement.getLicenseType().getCode();
    licenseTrainingRequirementDetails.dtls.removalReason = licenseTrainingRequirement.getRemovalReason().getCode();
    licenseTrainingRequirementDetails.trainingName = licenseTrainingRequirement.getTraining().getName();
    licenseTrainingRequirementDetails.dtls.status = licenseTrainingRequirement.getLifecycleState().getCode();
    licenseTrainingRequirementDetails.dtls.versionNo = licenseTrainingRequirement.getVersionNo();

    return licenseTrainingRequirementDetails;
  }

  // BEGIN CR00108646, GYH

  /**
   * Sorts a set of training requirements for a license type based on training
   * name.
   *
   * @param unsortedLicenseTrainingRequirements
   * The set of unsorted training requirements for a license type.
   * @return A sorted list of training requirements for a license type.
   */
  // END CR00108646
  // BEGIN, CR00177241, PM
  protected List<curam.provider.impl.LicenseTrainingRequirement> sortLicenseTrainingRequirements(
    // END, CR00177241
    final Set<curam.provider.impl.LicenseTrainingRequirement> unsortedLicenseTrainingRequirements) {

    // Sort by name for display - using a list (instead of a set) in case
    // there
    // are duplicate names.
    final List<curam.provider.impl.LicenseTrainingRequirement> licenseTrainingRequirements = new ArrayList<curam.provider.impl.LicenseTrainingRequirement>(
      unsortedLicenseTrainingRequirements);

    // BEGIN CR00108646, GYH
    // Sort a list of training requirements for a license type based on
    // training
    // name in alphabetical order.
    // END CR00108646
    Collections.sort(licenseTrainingRequirements,
      new Comparator<curam.provider.impl.LicenseTrainingRequirement>() {
      public int compare(
        final curam.provider.impl.LicenseTrainingRequirement lhs,
        curam.provider.impl.LicenseTrainingRequirement rhs) {
        return lhs.getTraining().getName().compareTo(
          rhs.getTraining().getName());
      }
    });
    return licenseTrainingRequirements;
  }

  // BEGIN CR00096014, MST
  /**
   * Method used to create attachment for Provider License.
   *
   * @param attachmentLinkDetails
   * Details of the attachment to create for license
   *
   * @return Internal identifier for attachment link.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public AttachmentLinkKey createLicenseAttachment(
    AttachmentLinkDetails attachmentLinkDetails) throws AppException,
      InformationalException {

    AttachmentLinkKey attachmentLinkKey = new AttachmentLinkKey();

    AttachmentLink attachmentLink = attachmentLinkDAO.newInstance();

    attachmentLinkDetails.attachmentLinkDtls.relatedObjectType = ATTACHMENTOBJECTLINKTYPE.LICENSE;
    attachmentLinkDetails.attachmentLinkDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;

    // BEGIN, CR00360398, CD
    // set up some meta data for the attachment    
    final curam.provider.impl.License license = licenseDAO.get(
      attachmentLinkDetails.attachmentLinkDtls.relatedObjectID);
    CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

    cmsMetadata.add(CMSMetadataConst.kParticipantID,
      Long.toString(license.getProvider().getID()));
    // END, CR00360398
    
    attachmentLinkKey.attachmentLinkID = attachmentLink.insert(
      attachmentLinkDetails);

    return attachmentLinkKey;
  }

  /**
   * Method used to list all the attachment for a provider license.
   *
   * @param licenseKey
   * Internal identifier for License.
   *
   * @return List of attachment link details
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListAttachmentLinkDetails listLicenseAttachment(LicenseKey licenseKey)
    throws AppException, InformationalException {

    ListAttachmentLinkDetails listAttachmentLinkDetails = new ListAttachmentLinkDetails();

    List<AttachmentLink> attachmentLinks = attachmentLinkDAO.searchByRelatedIDAndType(
      licenseKey.licenseID, ATTACHMENTOBJECTLINKTYPEEntry.LICENSE);

    // Loop through all the attachment link object and populate the values
    // to
    // facade struct.
    for (curam.attachmentlink.impl.AttachmentLink attachmentLink : attachmentLinks) {

      AttachmentLinkDetails attachmentLinkDetails = populateAttachmentLinkDetails(
        attachmentLink);

      listAttachmentLinkDetails.attachmentLinkDetails.addRef(
        attachmentLinkDetails);
    }

    return listAttachmentLinkDetails;
  }

  /**
   * Populates the attachment and attachment link details from the entity
   * struct to facade struct for display.
   *
   * @param attachmentLink
   * An attachmentLink object.
   *
   * @return Attachment link details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected AttachmentLinkDetails populateAttachmentLinkDetails(
    curam.attachmentlink.impl.AttachmentLink attachmentLink)
    throws AppException, InformationalException {

    AttachmentLinkDetails attachmentLinkDetails = new AttachmentLinkDetails();
    AttachmentKey attachmentKey = new AttachmentKey();
    curam.attachmentlink.struct.AttachmentLinkDetails attachmentDetails = new curam.attachmentlink.struct.AttachmentLinkDetails();

    attachmentKey.attachmentID = attachmentLink.getAttachmentID();
    attachmentDetails.attachmentDtls = attachmentObj.read(attachmentKey);

    attachmentLinkDetails.attachmentLinkDtls.attachmentLinkID = attachmentLink.getID();
    attachmentLinkDetails.attachmentLinkDtls.description = attachmentLink.getDescription();
    attachmentLinkDetails.attachmentLinkDtls.versionNo = attachmentLink.getVersionNo();
    attachmentLinkDetails.attachmentLinkDtls.recordStatus = attachmentLink.getLifecycleState().getCode();
    attachmentLinkDetails.attachmentLinkDtls.sensitivityCode = attachmentLink.getSensitivityCode().getCode();
    attachmentLinkDetails.attachmentLinkDtls.creatorUserName = attachmentLink.getCreator();
    attachmentLinkDetails.attachmentDtls.assign(
      attachmentDetails.attachmentDtls);

    return attachmentLinkDetails;
  }
  // END CR00096014

}
