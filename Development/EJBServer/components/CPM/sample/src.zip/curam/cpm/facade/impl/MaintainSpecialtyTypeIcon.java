/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.cpm.facade.struct.IconContent;
import curam.cpm.facade.struct.IconKey;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.SpecialtyTypeIconDetails;
import curam.cpm.facade.struct.SpecialtyTypeIconDetailsList;
import curam.cpm.facade.struct.SpecialtyTypeIconIDKey;
import curam.cpm.facade.struct.SpecialtyTypeResourceDetails;
import curam.cpm.sl.entity.struct.SpecialtyTypeIconDtls;
import curam.cpm.sl.entity.struct.SpecialtyTypeIconKey;
import curam.provider.impl.ProviderSpecialtyTypeEntry;
import curam.provider.impl.SPECIALTYEntry;
import curam.provider.impl.SPECIALTYTYPEEntry;
import curam.specialtytypeicon.impl.SpecialtyTypeIcon;
import curam.specialtytypeicon.impl.SpecialtyTypeIconDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.internal.resources.fact.AppResourceFactory;
import curam.util.internal.resources.intf.AppResource;
import curam.util.internal.resources.struct.NSResourceDetails;
import curam.util.internal.resources.struct.NSResourceKey;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.GeneralConstants;
import curam.util.type.CodeTable;


/**
 * Facade layer class having API for managing specialty type icon.
 *
 */
public abstract class MaintainSpecialtyTypeIcon extends curam.cpm.facade.base.MaintainSpecialtyTypeIcon {

  /**
   * Reference to Specialty Type Icon DAO
   */
  @Inject
  protected SpecialtyTypeIconDAO specialtyTypeIconDAO;

  /**
   * Constructor
   */
  public MaintainSpecialtyTypeIcon() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Adds the icon image for specialty type or specialty.
   *
   * @param details
   * Contains specialty type icon details.
   *
   * @return Key containing specialty type icon ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public SpecialtyTypeIconKey addSpecialtyTypeIcon(
    SpecialtyTypeIconDetails details) throws AppException,
      InformationalException {

    SpecialtyTypeIconKey specialtyTypeIconKey = new SpecialtyTypeIconKey();

    SpecialtyTypeIcon specialtyTypeIcon = specialtyTypeIconDAO.newInstance();

    setSpecialtyIconFields(specialtyTypeIcon, details);
    specialtyTypeIcon.insert();
    specialtyTypeIconKey.specialtyTypeIconID = specialtyTypeIcon.getID();

    return specialtyTypeIconKey;
  }

  /**
   * Modifies the icon image for specialty type or specialty.
   *
   * @param details
   * Contains specialty type icon details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void changeSpecialtyTypeIcon(SpecialtyTypeIconDetails details)
    throws AppException, InformationalException {

    SpecialtyTypeIcon specialtyTypeIcon = specialtyTypeIconDAO.get(
      details.specialtyTypeIconID);

    setSpecialtyIconFields(specialtyTypeIcon, details);
    specialtyTypeIcon.modify(details.versionNo);

  }

  /**
   * Deletes the icon image for specialty type or specialty.
   *
   * @param key
   * Contains version number and specialty type icon ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deleteSpecialtyTypeIcon(KeyVersionDetails key)
    throws AppException, InformationalException {

    SpecialtyTypeIcon specialtyTypeIcon = specialtyTypeIconDAO.get(key.id);

    specialtyTypeIcon.remove();
  }

  /**
   * Lists the icon image for specialty type or specialty.
   *
   * @return List of specialty type icons managed in the system.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public SpecialtyTypeIconDetailsList listSpecialtyTypeIcon()
    throws AppException, InformationalException {

    SpecialtyTypeIconDetailsList specialtyTypeIconDetailsList = new SpecialtyTypeIconDetailsList();
    Set<SpecialtyTypeIcon> specialtyTypeIcons = specialtyTypeIconDAO.readAll();

    for (SpecialtyTypeIcon specialtyTypeIcon : specialtyTypeIcons) {
      specialtyTypeIconDetailsList.dtls.addRef(
        getSpecialtyTypeFields(specialtyTypeIcon));
      specialtyTypeIconDetailsList.resourceDetails.addRef(
        getAppResourceFields(specialtyTypeIcon));
    }

    return specialtyTypeIconDetailsList;
  }

  /**
   * Downloads the icon image for specialty type or specialty.
   *
   * @param key Contains specialty type icon image key.
   *
   * @return Icon image of a specialty type.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public IconContent exportIcon(IconKey key) throws AppException,
      InformationalException {
    final AppResource appResource = AppResourceFactory.newInstance();

    final NSResourceKey nsResourceKey = new NSResourceKey();

    nsResourceKey.name = key.iconName;
    nsResourceKey.localeIdentifier = key.locale;
    nsResourceKey.localeIsNull = key.locale == null
      || GeneralConstants.kEmpty.equals(key.locale);

    final NSResourceDetails nsResourceDetails = appResource.readByNameAndLocale(
      nsResourceKey);

    final String appendLocale = GeneralConstants.kEmpty.equals(
      nsResourceDetails.localeIdentifier)
        ? GeneralConstants.kEmpty
        : GeneralConstants.kUnderScoreString
          + nsResourceDetails.localeIdentifier;

    final IconContent iconContent = new IconContent();

    iconContent.icon = nsResourceDetails.content;
    iconContent.iconName = key.iconName + appendLocale;

    return iconContent;
  }

  /**
   * Returns the the full details of specialty type or specialty icon image.
   *
   * @param specialtyTypeIconIDKey Contains specialty type icon image key.
   *
   * @return Details contains Icon details and specialty type details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public SpecialtyTypeIconDetails readSpecialtyTypeIcon(
    SpecialtyTypeIconIDKey specialtyTypeIconIDKey) throws AppException,
      InformationalException {

    SpecialtyTypeIconDetails specialtyTypeIconDetails = new SpecialtyTypeIconDetails();

    SpecialtyTypeIcon specialtyTypeIcon = specialtyTypeIconDAO.get(
      specialtyTypeIconIDKey.specialtyTypeIconID);

    specialtyTypeIconDetails.resourceID = specialtyTypeIcon.getAppResourceID();
    specialtyTypeIconDetails.specialty = specialtyTypeIcon.getSpecialty().getCode();
    specialtyTypeIconDetails.versionNo = specialtyTypeIcon.getVersionNo();
    specialtyTypeIconDetails.specialtyTypeIconID = specialtyTypeIcon.getID();
    specialtyTypeIconDetails.iconName = specialtyTypeIcon.getIconName();
    specialtyTypeIconDetails.icon = specialtyTypeIcon.getSpecialtyTypeIcon();

    return specialtyTypeIconDetails;
  }

  /**
   * Gets the specialty type icon details into the struct from the entity object.
   *
   * @param specialtyTypeIcon
   * The specialty type icon entity.
   *
   * @return Contains specialty type icon details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected SpecialtyTypeIconDtls getSpecialtyTypeFields(
    SpecialtyTypeIcon specialtyTypeIcon) throws AppException,
      InformationalException {

    SpecialtyTypeIconDtls specialtyTypeIconDtls = new SpecialtyTypeIconDtls();

    specialtyTypeIconDtls.resourceID = specialtyTypeIcon.getAppResourceID();
    specialtyTypeIconDtls.specialty = specialtyTypeIcon.getSpecialty().getCode();
    specialtyTypeIconDtls.specialtyType = specialtyTypeIcon.getSpecialtyType().getCode();
    specialtyTypeIconDtls.versionNo = specialtyTypeIcon.getVersionNo();
    specialtyTypeIconDtls.specialtyTypeIconID = specialtyTypeIcon.getID();

    return specialtyTypeIconDtls;
  }

  /**
   * Gets the specialty type icon details into the struct from the entity object.
   *
   * @param specialtyTypeIcon
   * The specialty type icon entity.
   *
   * @return Contains icon image and icon name.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected SpecialtyTypeResourceDetails getAppResourceFields(
    SpecialtyTypeIcon specialtyTypeIcon) throws AppException,
      InformationalException {

    SpecialtyTypeResourceDetails specialtyTypeResourceDetails = new SpecialtyTypeResourceDetails();

    specialtyTypeResourceDetails.icon = specialtyTypeIcon.getSpecialtyTypeIcon();
    specialtyTypeResourceDetails.iconName = specialtyTypeIcon.getIconName();

    return specialtyTypeResourceDetails;
  }

  /**
   * Sets the specialty type icon details to the entity object.
   *
   * @param specialtyTypeIcon
   * The specialty type icon entity.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void setSpecialtyIconFields(SpecialtyTypeIcon specialtyTypeIcon,
    SpecialtyTypeIconDetails details) throws AppException,
      InformationalException {

    specialtyTypeIcon.setIconName(details.iconName);
    specialtyTypeIcon.setSpecialty(
      ProviderSpecialtyTypeEntry.get(details.specialty));

    String parentCode = CodeTable.getParentCode(SPECIALTYEntry.TABLENAME,
      details.specialty);

    specialtyTypeIcon.setSpecialtyType(SPECIALTYTYPEEntry.get(parentCode));

    if (details.newIcon.length() != 0) {
      specialtyTypeIcon.setSpecialtyTypeIcon(details.newIcon);
    } else {
      specialtyTypeIcon.setSpecialtyTypeIcon(details.icon);
    }
  }

}
