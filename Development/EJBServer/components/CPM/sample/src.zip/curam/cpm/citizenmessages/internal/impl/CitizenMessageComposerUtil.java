/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.citizenmessages.internal.impl;


import com.google.inject.Inject;
import curam.citizenactivity.impl.ProviderOfferingUtil;
import curam.core.impl.CuramConst;
import curam.participant.impl.PhoneNumber;
import curam.participantmessages.codetable.impl.ParticipantMessageTypeEntry;
import curam.participantmessages.configuration.impl.ParticipantMessageConfiguration;
import curam.participantmessages.configuration.impl.ParticipantMessageConfigurationDAO;
import curam.participantmessages.impl.ParticipantMessageLink;
import curam.piwrapper.user.impl.InternalUser;
import curam.piwrapper.user.impl.User;
import curam.provider.impl.Provider;
import curam.referral.impl.Referral;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.impl.PropertiesResourceCache;
import curam.util.type.Date;


/**
 * Utility functions for CPM citizen message composers. This is internal and
 * specific to citizen messages, and should not be called by customers.
 *
 */
class CitizenMessageComposerUtil {

  @Inject
  private ProviderOfferingUtil providerOfferingUtil;

  @Inject
  private ParticipantMessageConfigurationDAO particpantMessageConfigurationDAO;

  public String getPropertyValue(final String fileName,
    final String propertyName) throws AppException, InformationalException {

    return PropertiesResourceCache.getInstance().getProperty(fileName,
      propertyName);
  }

  /**
   * @param owner
   * @return
   */
  boolean hasBusinessPhoneNumberAndEmailAddress(final InternalUser internalUser) {

    if (hasBusinessPhone(internalUser) && hasEmailAddress(internalUser)) {
      return true;
    }
    return false;
  }

  /**
   * @param internalUser
   * @return
   */
  boolean hasEmailAddress(final InternalUser internalUser) {
    return internalUser.getEmailAddress() != null
      && internalUser.getEmailAddress().getID() != 0;
  }

  /**
   * @param internalUser
   * @return
   */
  boolean hasBusinessPhone(final InternalUser internalUser) {
    return internalUser.getBusinessPhoneNumber() != null
      & internalUser.getBusinessPhoneNumber().getID() != 0;
  }

  /**
   * @param internalUser
   * @return
   */
  String getEmailAddress(final User internalUser) {

    if (internalUser.getEmailAddress() == null
      || internalUser.getEmailAddress().getID() == 0) {
      return CuramConst.gkEmpty;
    }

    return internalUser.getEmailAddress().getEmail();
  }

  /**
   * @param internalUser
   * @return
   */
  String getPhoneNumber(final InternalUser internalUser) {

    if (internalUser.getBusinessPhoneNumber() == null
      || internalUser.getBusinessPhoneNumber().getID() == 0) {
      return CuramConst.gkEmpty;
    }

    return getContactNumber(internalUser.getBusinessPhoneNumber());
  }

  /**
   * Gets contact details with country code, area code and number.
   *
   * @param phoneNumber
   * an instance of PhoneNumber which contains phone number details
   * @return phone number including country and area code
   */
  private String getContactNumber(final PhoneNumber phoneNumber) {
    final StringBuffer phoneNumberString = new StringBuffer();

    phoneNumberString.append(phoneNumber.getCountryCode());
    phoneNumberString.append(CuramConst.gkSpace);
    phoneNumberString.append(phoneNumber.getAreaCode());
    phoneNumberString.append(CuramConst.gkSpace);
    phoneNumberString.append(phoneNumber.getNumber());
    return phoneNumberString.toString();
  }

  /**
   * @param serviceDelivery
   */
  ParticipantMessageLink addProviderModalLink(
    final ServiceOffering serviceOffering, final Provider provider) {

    /**
     * Get the providerOfferingID, which is used as the serviceID argument to
     * this link.
     */
    final String providerOfferingID = getProviderOfferingIDAsString(
      serviceOffering, provider);

    final ParticipantMessageLink providerModalLink = new ParticipantMessageLink(
      false, CitizenMessageComposerConst.pagePlayerURL,
      CitizenMessageComposerConst.kProviderModalLinkName);

    providerModalLink.openInNewWindow(
      CitizenMessageComposerConst.providerModalHieght,
      CitizenMessageComposerConst.providerModalWidth);

    providerModalLink.hideBrowserMenuBar();
    providerModalLink.hideBrowserToolBar();

    providerModalLink.addParameter(
      CitizenMessageComposerConst.providerModalPageParameterName,
      CitizenMessageComposerConst.providerModalPageName);

    providerModalLink.addParameter(
      CitizenMessageComposerConst.providerModalServiceIDParameterName,
      providerOfferingID);

    return providerModalLink;
  }

  /**
   * @param serviceDelivery
   * @return
   */
  private String getProviderOfferingIDAsString(
    final ServiceOffering serviceOffering, final Provider provider) {
    return providerOfferingUtil.getByServiceOfferingAndProvider(serviceOffering, provider).getID().toString();
  }

  Boolean hasValidProviderOffering(final ServiceOffering serviceOffering,
    final Provider provider) {
    return providerOfferingUtil.getByServiceOfferingAndProvider(serviceOffering,
      provider)
      != null;
  }

  /**
   * Retrieves the link value from the resource store and creates a link object
   * based on the value and name.
   *
   * @return
   * @throws AppException
   * @throws InformationalException
   */
  ParticipantMessageLink getMyActivitiesLink(final String propertyFileName)
    throws AppException, InformationalException {

    final ParticipantMessageLink myActivitiesLink = new ParticipantMessageLink(
      false,
      getPropertyValue(propertyFileName,
      CitizenMessageComposerConst.kMyActivitiesLinkReference),
      CitizenMessageComposerConst.kMyActivitiesLinkName);

    return myActivitiesLink;
  }

  /**
   * Returns true if messages of the given type are enabled.
   *
   * @param entry
   * The message type.
   * @return true if messages of the given type are enabled. type.
   * @throws InformationalException
   * Generic Application Signature
   * @throws AppException
   * Generic Application Signature
   */
  public Boolean messageTypeIsEnabled(
    final ParticipantMessageTypeEntry participantMessageTypeEntry)
    throws AppException, InformationalException {

    // read the configuration for this type and check to see if its enabled
    final ParticipantMessageConfiguration participantMessageConfiguration = particpantMessageConfigurationDAO.readByParticipantMessageType(
      participantMessageTypeEntry);

    if (participantMessageConfiguration == null) {
      final AppException appException = new AppException(
        curam.cpm.message.PARTICIPANTMESSAGE.ERR_NO_CONFIG_FOR_MESSAGE_TYPE);

      appException.arg(
        ParticipantMessageTypeEntry.get(participantMessageTypeEntry.getCode()).toUserLocaleString());
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        appException,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (!participantMessageConfiguration.isEnabled()) {
      // messages of this type are currently disabled in admin
      return false;
    }
    return true;
  }
  
  public String getParticipantMessageConfigImage(
    final ParticipantMessageTypeEntry participantMessageTypeEntry) throws AppException {
	  
    // read the configuration for this type and check to see if its enabled
    final ParticipantMessageConfiguration participantMessageConfiguration = particpantMessageConfigurationDAO.readByParticipantMessageType(
      participantMessageTypeEntry);

    if (participantMessageConfiguration == null) {
      final AppException appException = new AppException(
        curam.cpm.message.PARTICIPANTMESSAGE.ERR_NO_CONFIG_FOR_MESSAGE_TYPE);

      appException.arg(
        ParticipantMessageTypeEntry.get(participantMessageTypeEntry.getCode()).toUserLocaleString());
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        appException,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
	    
    return participantMessageConfiguration.getImage();
  }

  /**
   * Returns true if today is within the number of days of the start date
   * defined in the property passed in.
   *
   * @param propertyReference
   * a reference to an environment variable that holds an Integer value
   * representing a number of days.
   * @param startDate
   * the start date in question
   * @return true if today is within the number of days of the start date
   * defined in the property passed in.
   */
  public Boolean displayMessage(final String propertyReference,
    final Date startDate) {

    // retrieve the number of days based on the property
    final Integer numberOfDays = Configuration.getIntProperty(propertyReference);

    // calculate based on the start date and number of days whether the message
    // should be displayed
    final Date effectiveDate = startDate.addDays(numberOfDays * -1);

    if (Date.getCurrentDate().before(effectiveDate)) {
      return false;
    } else {
      return true;
    }
  }

  /**
   * Creates a link to the Referral Modal page based on the given Referral.
   *
   * @param referral The referral object containing the details of the referral.
   * @return The link to the Referral Modal that will be added to the Participant Message.
   */
  ParticipantMessageLink addReferralModalLink(final Referral referral) {
    final ParticipantMessageLink link = new ParticipantMessageLink(false,
      CitizenMessageComposerConst.pagePlayerURL,
      CitizenMessageComposerConst.kProviderModalLinkName);

    link.openInNewWindow(CitizenMessageComposerConst.providerModalHieght,
      CitizenMessageComposerConst.providerModalWidth);
    link.hideBrowserMenuBar();
    link.hideBrowserToolBar();
    link.addParameter(
      CitizenMessageComposerConst.providerModalPageParameterName,
      CitizenMessageComposerConst.referralModalPageName);
    link.addParameter(
      CitizenMessageComposerConst.referralModalReferralIDParameterName,
      new Long(referral.getID()).toString());
    return link;
  }
}
