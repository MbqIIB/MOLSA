/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.cpm.impl.CPMConstants;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.EnvironmentConstants.SMTP;
import curam.util.resources.EnvironmentDefaults;
import curam.util.resources.SMTPMessage;


/**
 * Implementation of the {@link EmailUtility} interface.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
class EmailUtilityImpl implements EmailUtility {

  /**
   * {@inheritDoc}
   */
  public SMTPMessage getSMTPMessage(final String subjectText,
    final String messageDetails, final String recipientEmailAddress)
    throws AppException, InformationalException {

    return new SMTPMessage(getEmailFrom(), subjectText, recipientEmailAddress,
      CuramConst.gkEmpty, CuramConst.gkEmpty, messageDetails);

  }

  /**
   * {@inheritDoc}
   */
  public void sendEmail(final SMTPMessage message, final String recipientName)
    throws AppException {

    String strServer = getSMTPServer();
    int port = getSMTPPort();

    // SMTPMailConnection object
    curam.util.resources.SMTPConnection mailConnection = new curam.util.resources.SMTPConnection(
      recipientName, strServer, port);

    // send email message
    mailConnection.sendMessage(message);

  }

  /**
   * {@inheritDoc}
   */
  String getEmailFrom() {
    String emailFrom;

    if (Configuration.getProperty(EnvVars.ENV_NOTIFICATION_EMAIL_FROM) == null) {
      emailFrom = EnvVars.ENV_NOTIFICATION_EMAIL_FROM_DEFAULT;
    } else {
      emailFrom = Configuration.getProperty(EnvVars.ENV_NOTIFICATION_EMAIL_FROM);
    }
    return emailFrom;
  }

  /**
   * {@inheritDoc}
   */
  int getSMTPPort() {
    int port;
    
    // BEGIN, CR00306412, MR
    String strPort = Configuration.getProperty(SMTP.kSMTPServerPort);

    // If the property is not set, use default value.
    if (strPort == null) {
      port = CPMConstants.kSMTPServerPortDefault;
      
      // END, CR00306412
    } else {
      port = Integer.parseInt(strPort);
    }
    return port;
  }

  /**
   * {@inheritDoc}
   */
  String getSMTPServer() {
    String strServer;
    
    // BEGIN, CR00306412, MR
    strServer = Configuration.getProperty(SMTP.kSMTPHostServer);

    // If the property is not set, use default value.
    if (strServer == null) {
      strServer = EnvironmentDefaults.kSMTPHostServerDefault;
      
      // END, CR00306412
    }
    return strServer;
  }

  /**
   * {@inheritDoc}
   */
  public Boolean determineSendEmail(final String propertyValue,
    final String propertyValueDefault) {

    if (getPropertyConfiguration(propertyValue, propertyValueDefault).equalsIgnoreCase(
      CuramConst.kNO)) {
      return false;
    }
    return true;
  }

  /**
   * Reads the value of the given system property as configured by the system.
   *
   * @param propertyValue
   * The system property value to be retrieved
   * @param propertyValueDefault
   * The default value of the system property value to be retrieved
   * @return The value of the property configured for it by the system
   */
  String getPropertyConfiguration(final String propertyValue,
    final String propertyValueDefault) {
    String emails = Configuration.getProperty(propertyValue);

    // If the property is not set, use default value
    if (emails == null) {
      emails = Configuration.getProperty(propertyValueDefault);
    }
    return emails;
  }

}
