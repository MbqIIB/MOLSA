/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import com.google.inject.Inject;
import curam.codetable.impl.WAITLISTENTRYSTATUSEntry;
import curam.codetable.impl.WAITLISTTYPEEntry;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails;
import curam.core.struct.WaitListEntryKey;
import curam.cpm.facade.struct.ProviderKey;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetails;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetailsList;
import curam.cpm.facade.struct.ResourceKey;
import curam.cpm.facade.struct.ViewProviderOfferingDetails;
import curam.cpm.facade.struct.ViewProviderSummaryDetails;
import curam.cpm.facade.struct.WaitListEntryDetails;
import curam.cpm.facade.struct.WaitListEntryDetailsList;
import curam.cpm.sl.entity.struct.ProviderOfferingKey;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.providerservice.impl.ProviderOffering;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.serviceoffering.impl.UnitOfMeasureEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.waitlist.impl.WaitList;
import curam.waitlist.impl.WaitListDAO;
import curam.waitlist.impl.WaitListEntry;
import curam.waitlist.impl.WaitListEntryDAO;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * Facade class having API's for managing Wait Lists. Wait List is a queue of
 * clients waiting on a resource to become available. An entry on a wait list
 * for a resource relating to a client is called Wait List Entry.
 */
public class MaintainExternalProviderWaitList extends curam.cpm.eua.facade.base.MaintainExternalProviderWaitList {

  /**
   * Default constructor for guice
   */
  public MaintainExternalProviderWaitList() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Reference to WaitListEntryDAO.
   */
  @Inject
  protected WaitListEntryDAO waitListEntryDAO;

  /**
   * Reference to WaitListDAO.
   */
  @Inject
  protected WaitListDAO waitListDAO;

  /**
   * Reference to ProviderDAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to ServiceOfferingDAO.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Lists all the provider offering associated to a wait list for a provider.
   *
   * @param key
   * Contains the provider information.
   * @return A list of provider offering details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderOfferingSummaryDetailsList listProviderOfferingWaitListForProvider(
    ProviderKey key) throws AppException, InformationalException {
    ProviderOfferingSummaryDetailsList providerOfferingSummaryDetailsList = new ProviderOfferingSummaryDetailsList();

    Set<ProviderOffering> providerOfferings = listProviderOfferingWaitListForProvider(
      providerDAO.get(key.providerID));

    for (ProviderOffering providerOffering : sortProviderOfferings(
      providerOfferings)) {

      ProviderOfferingSummaryDetails providerOfferingSummaryDetails = new ProviderOfferingSummaryDetails();
      ServiceOffering serviceOffering = providerOffering.getServiceOffering();

      providerOfferingSummaryDetails.serviceOfferingID = serviceOffering.getID();
      providerOfferingSummaryDetails.providerOfferingID = providerOffering.getID();

      providerOfferingSummaryDetails.startDate = providerOffering.getDateRange().start();
      providerOfferingSummaryDetails.endDate = providerOffering.getDateRange().end();
      providerOfferingSummaryDetails.name = serviceOffering.getName();
      providerOfferingSummaryDetails.recordStatus = providerOffering.getLifecycleState().getCode();

      providerOfferingSummaryDetailsList.providerOfferingSummaryDetails.addRef(
        providerOfferingSummaryDetails);
    }
    return providerOfferingSummaryDetailsList;
  }

  /**
   * Lists all the wait list entries for given resource.
   *
   * @param key
   * The key containing the resource id.
   * @return A list of all wait list entries for given resource.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public WaitListEntryDetailsList listWaitListEntryForResource(ResourceKey key)
    throws AppException, InformationalException {
    Set<WaitListEntry> waitListEntries = listWaitListEntryForResource(
      key.resourceID);

    ArrayList<WaitListEntry> sortedWaitListEntries = sortWaitListEntriesByPosition(
      waitListEntries);

    WaitListEntryDetailsList waitListEntryDetailsList = new WaitListEntryDetailsList();

    for (WaitListEntry waitListEntry : sortedWaitListEntries) {
      WaitListEntryDetails waitListEntryDetails = getWaitListEntryDetails(
        waitListEntry);

      waitListEntryDetailsList.details.addRef(waitListEntryDetails);
    }

    return waitListEntryDetailsList;

  }

  /**
   * Retrieves a wait list entry details for a wait list.
   *
   * @param waitListEntryKey
   * Contains a Wait List Entry ID.
   * @return The wait list entry details for a wait list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public WaitListEntryDetails viewWaitListEntry(
    WaitListEntryKey waitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKey.waitListEntryID);
    WaitListEntryDetails waitListEntryDetails = getWaitListEntryDetails(
      waitListEntry);

    return waitListEntryDetails;
  }

  /**
   * Sorts a set of provider offerings based on provider offering name.
   *
   * @param unsortedProviderOfferings
   * A set of unsorted provider offerings.
   * @return A set of sorted list of provider offerings.
   */
  protected List<ProviderOffering> sortProviderOfferings(
    final Set<ProviderOffering> unsortedProviderOfferings) {

    final List<ProviderOffering> sortedProviderOfferings = new ArrayList<ProviderOffering>(
      unsortedProviderOfferings);

    Collections.sort(sortedProviderOfferings,
      new Comparator<ProviderOffering>() {
      public int compare(final ProviderOffering lhs, ProviderOffering rhs) {
        return lhs.getServiceOffering().getName().compareTo(
          rhs.getServiceOffering().getName());
      }
    });
    return sortedProviderOfferings;

  }

  /**
   * Sorts a set of wait list entries by position.
   *
   * @param unsortedWaitListEntries
   * The list of unsorted wait list entries.
   * @return A sorted list of wait list entries.
   */
  protected ArrayList<WaitListEntry> sortWaitListEntriesByPosition(
    final Set<WaitListEntry> unsortedWaitListEntries) {

    // Sort by position for display
    final ArrayList<WaitListEntry> waitListEntries = new ArrayList<WaitListEntry>(
      unsortedWaitListEntries);

    Collections.sort(waitListEntries, new Comparator<WaitListEntry>() {
      public int compare(final WaitListEntry lhs, WaitListEntry rhs) {

        Short lhsPosition = new Short(lhs.getPosition());
        Short rhsPosition = new Short(rhs.getPosition());

        return lhsPosition.compareTo(rhsPosition);
      }
    });
    return waitListEntries;
  }

  /**
   * Retrieves the contents of the Wait List Entry into Wait List Entry Details
   * structs and returns it.
   *
   * @param waitListEntry
   * The source wait list entry from which data is extracted.
   * @return A populated struct containing wait list entry details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected WaitListEntryDetails getWaitListEntryDetails(
    WaitListEntry waitListEntry) throws AppException, InformationalException {

    WaitListEntryDetails waitListEntryDetails = new WaitListEntryDetails();

    waitListEntryDetails.waitListEntryDtls.waitListEntryID = waitListEntry.getID();
    CaseParticipantRole_eoFullDetails clientDetails = retrieveClientDetails(
      waitListEntry.getClient());

    waitListEntryDetails.concernRoleID = clientDetails.participantRoleID;
    waitListEntryDetails.concernRoleName = clientDetails.name;
    waitListEntryDetails.waitListEntryDtls.position = waitListEntry.getPosition();
    waitListEntryDetails.waitListEntryDtls.expiryDate = waitListEntry.getExpiryDate();
    waitListEntryDetails.waitListEntryDtls.priority = waitListEntry.getPriority().getCode();
    waitListEntryDetails.waitListEntryDtls.status = waitListEntry.getLifecycleState().getCode();
    waitListEntryDetails.waitListEntryDtls.removalReason = waitListEntry.getRemovalReason().getCode();
    waitListEntryDetails.waitListEntryDtls.versionNo = waitListEntry.getVersionNo();

    if (waitListEntry.getPosition() > 0) {
      waitListEntryDetails.positionString = String.valueOf(
        waitListEntry.getPosition());
    }

    // Read the context description based on resource type.
    if (waitListEntry.getWaitList().getType().equals(WAITLISTTYPEEntry.PROVIDER)) {

      curam.cpm.facade.intf.Provider providerObj = curam.cpm.facade.fact.ProviderFactory.newInstance();
      curam.cpm.sl.entity.struct.ProviderConcernRoleKey providerConcernRoleKey = new curam.cpm.sl.entity.struct.ProviderConcernRoleKey();

      providerConcernRoleKey.providerConcernRoleID = waitListEntry.getWaitList().getResourceID();
      ViewProviderSummaryDetails viewProviderSummaryDetails = providerObj.readProviderSummaryDetails(
        providerConcernRoleKey);

      waitListEntryDetails.contextDescription = viewProviderSummaryDetails.pageContextDescription;

    } else if (waitListEntry.getWaitList().getType().equals(
      WAITLISTTYPEEntry.PROVIDEROFFERING)) {

      curam.cpm.facade.intf.ProviderOffering providerOfferingObj = curam.cpm.facade.fact.ProviderOfferingFactory.newInstance();
      ProviderOfferingKey providerOfferingKey = new ProviderOfferingKey();

      providerOfferingKey.providerOfferingID = waitListEntry.getWaitList().getResourceID();
      ViewProviderOfferingDetails viewProviderOfferingDetails = providerOfferingObj.viewProviderOffering(
        providerOfferingKey);

      waitListEntryDetails.contextDescription = viewProviderOfferingDetails.serviceOfferingName;

      curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceOfferingDAO.get(
        viewProviderOfferingDetails.providerOfferingDtls.serviceOfferingID);

      // set the allocatePlaceInd flag if the service offering is of type Place.
      if (serviceOffering.getUnitOfMeasure().equals(UnitOfMeasureEntry.PLACE)) {
        waitListEntryDetails.allocatePlaceInd = true;
      }
    }

    return waitListEntryDetails;
  }

  /**
   * Filters the provider offerings of a particular provider, for which wait
   * list is created.
   *
   * @param provider
   * Contains the provider information.
   * @return A list of provider offering details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Set<ProviderOffering> listProviderOfferingWaitListForProvider(
    final Provider provider) throws InformationalException, AppException {

    // Retrieve all the provider offerings for the specified provider.
    Set<curam.providerservice.impl.ProviderOffering> unModifiableProviderOfferings = provider.getProviderOfferings();
    Set<curam.providerservice.impl.ProviderOffering> providerOfferings = new HashSet<curam.providerservice.impl.ProviderOffering>();

    providerOfferings.addAll(unModifiableProviderOfferings);

    // The set contains only those provider offerings which has corresponding
    // wait lists.
    Set<ProviderOffering> filteredProviderOfferings = new HashSet<ProviderOffering>();

    // Retrieve the wait list information for every provider offering, which is
    // a resource in a wait list.
    for (ProviderOffering providerOffering : providerOfferings) {
      Set<WaitListEntry> waitListEntries = listWaitListEntryForResource(
        providerOffering.getID());

      if (waitListEntries.size() > 0) {
        filteredProviderOfferings.add(providerOffering);
        continue;
      }
    }
    return filteredProviderOfferings;
  }

  /**
   * Lists all the wait list entries for a given resource.
   *
   * @param resourceID
   * The ID of the resource for which the wait list entries are to be
   * listed.
   * @return A list of all wait list entries for the given resource.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected Set<WaitListEntry> listWaitListEntryForResource(long resourceID)
    throws InformationalException, AppException {

    Set<WaitListEntry> filteredWaitListEntries = new HashSet<WaitListEntry>();

    // Search the wait list for the resource.
    WaitList waitList = waitListDAO.readByResourceID(resourceID);

    if (waitList != null) {
      Set<WaitListEntry> waitListEntries = waitList.getEntries();

      // Filter the wait list entries by status open.
      for (WaitListEntry waitListEntry : waitListEntries) {
        if (waitListEntry.getLifecycleState().equals(
          WAITLISTENTRYSTATUSEntry.OPEN)) {
          filteredWaitListEntries.add(waitListEntry);
        }
      }
    }
    return filteredWaitListEntries;
  }

  /**
   * Retrieves the details of the client by specifying a case participant role
   * id.
   *
   * @param caseParticipantRoleID
   * Case participant role ID.
   * @return Details of the client.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected CaseParticipantRole_eoFullDetails retrieveClientDetails(
    long caseParticipantRoleID) throws AppException, InformationalException {

    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = caseParticipantRoleID;

    curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();

    // Get the client name from the case participant role ID.
    CaseParticipantRole_eoFullDetails caseParticipantRoleDetails = caseParticipantRole.readFullDetails(
      caseParticipantRoleKey);

    return caseParticipantRoleDetails;
  }

}
