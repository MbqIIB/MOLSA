/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.LOCALEEntry;
import curam.core.fact.AddressFactory;
import curam.core.fact.EmailAddressFactory;
import curam.core.fact.PhoneNumberFactory;
import curam.core.intf.Address;
import curam.core.intf.EmailAddress;
import curam.core.intf.PhoneNumber;
import curam.core.sl.entity.fact.WebAddressFactory;
import curam.core.sl.entity.struct.WebAddressDtls;
import curam.core.sl.entity.struct.WebAddressKey;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.EmailAddressDtls;
import curam.core.struct.EmailAddressKey;
import curam.core.struct.EmptyIndStruct;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PhoneNumberDtls;
import curam.core.struct.PhoneNumberKey;
import curam.cpm.facade.fact.ProviderOfferingFactory;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.localization.translation.facade.struct.LocalizableTextTranslationDetails;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetails;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetailsList;
import curam.cpm.facade.struct.ProviderServiceCenterContactDetails;
import curam.cpm.facade.struct.ProviderServiceCenterRegisterDetails;
import curam.cpm.facade.struct.ProviderServiceCenterRegisterInformation;
import curam.cpm.facade.struct.ProviderServiceCenterSummaryDetails;
import curam.cpm.facade.struct.ProviderServiceCenterSummaryInformation;
import curam.cpm.facade.struct.ProviderServiceCentersList;
import curam.cpm.facade.struct.ServiceCenterProviderOfferingSummaryDetails;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ProviderServiceCenterDtls;
import curam.cpm.sl.entity.struct.ProviderServiceCenterKey;
import curam.participant.impl.PhoneNumberDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderServiceCenterDAO;
import curam.provider.impl.ServiceCenterProviderOffering;
import curam.provider.impl.ServiceCenterProviderOfferingDAO;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.serviceoffering.impl.UnitOfMeasureEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.StringHelper;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.message.impl.LOCALIZABLETEXTExceptionCreator;


/**
 * Facade layer class for all the functionality relating to a Provider Service
 * Center.
 *
 */
public abstract class ProviderServiceCenter extends curam.cpm.facade.base.ProviderServiceCenter {

  @Inject
  protected ProviderServiceCenterDAO providerServiceCenterDAO;

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected ServiceCenterProviderOfferingDAO serviceCenterProviderOfferingDAO;

  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  @Inject
  protected PhoneNumberDAO phoneNumberDAO;

  // BEGIN, CR00178272, AK
  /**
   * Reference to localizable text handler DAO.
   */
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;
  // END, CR00178272

  /**
   * Constructor for the class.
   */
  public ProviderServiceCenter() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * Deletes the service center.
   *
   * @param keyVersionDetails
   * ID and version details of the service center.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelServiceCenter(KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    final curam.provider.impl.ProviderServiceCenter providerServiceCenter = providerServiceCenterDAO.get(
      keyVersionDetails.id);

    providerServiceCenter.cancel(keyVersionDetails.version);
  }

  /**
   * Creates service center for Provider.
   *
   * @param details
   * Service center details as entered by the user.
   *
   * @return ProviderServiceCenterKey ID of the newly created Service Center.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderServiceCenterKey createServiceCenter(
    ProviderServiceCenterRegisterDetails details) throws AppException,
      InformationalException {

    curam.provider.impl.ProviderServiceCenter providerServiceCenter = providerServiceCenterDAO.newInstance();

    setProviderServiceCenterFields(providerServiceCenter, details);

    providerServiceCenter.insert();

    final curam.provider.impl.ServiceCenterProviderOffering serviceCenterProviderOffering = serviceCenterProviderOfferingDAO.newInstance();

    setServiceCenterProviderOffering(serviceCenterProviderOffering, details);
    serviceCenterProviderOffering.setProviderServiceCenter(
      providerServiceCenter);

    serviceCenterProviderOffering.insert();

    ProviderServiceCenterKey providerServiceCenterKey = new ProviderServiceCenterKey();

    providerServiceCenterKey.providerServiceCenterID = providerServiceCenter.getID();

    return providerServiceCenterKey;
  }

  /**
   * Lists service center for Provider.
   *
   * @param key
   * provider ID for whom the service centers are to be listed.
   *
   * @return ProviderServiceCentersList List of service centers for the provider
   * specified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderServiceCentersList listServiceCenters(ProviderKey key)
    throws AppException, InformationalException {

    final ProviderServiceCentersList providerServiceCentersList = new ProviderServiceCentersList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      key.providerConcernRoleID);

    ProviderServiceCenterDtls providerServiceCenterDtls;

    Set<curam.provider.impl.ProviderServiceCenter> unModifiableProviderServiceCenters = provider.getProviderServiceCenters();
    Set<curam.provider.impl.ProviderServiceCenter> providerServiceCenters = new HashSet<curam.provider.impl.ProviderServiceCenter>();

    providerServiceCenters.addAll(unModifiableProviderServiceCenters);
    for (final curam.provider.impl.ProviderServiceCenter providerServiceCenter : sortProviderServiceCenters(
      providerServiceCenters)) {

      providerServiceCenterDtls = new ProviderServiceCenterDtls();

      providerServiceCenterDtls.providerServiceCenterID = providerServiceCenter.getID();
      providerServiceCenterDtls.name = providerServiceCenter.getName();
      providerServiceCenterDtls.startDate = providerServiceCenter.getDateRange().start();
      providerServiceCenterDtls.endDate = providerServiceCenter.getDateRange().end();
      providerServiceCenterDtls.recordStatus = providerServiceCenter.getLifecycleState().getCode();
      providerServiceCenterDtls.providerConcernRoleID = provider.getID();
      // BEGIN, CR00208581, AS
      providerServiceCenterDtls.versionNo = provider.getVersionNo();
      // END, CR00208581

      providerServiceCentersList.providerServiceCenterDtls.addRef(
        providerServiceCenterDtls);
    }

    return providerServiceCentersList;
  }

  /**
   * Updates service center for Provider.
   *
   * @param details
   * Modified details of the service center.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void updateServiceCenter(ProviderServiceCenterRegisterDetails details)
    throws AppException, InformationalException {

    curam.provider.impl.ProviderServiceCenter providerServiceCenter = providerServiceCenterDAO.get(
      details.providerServiceCenterID);

    setProviderServiceCenterFields(providerServiceCenter, details);

    providerServiceCenter.modify(details.versionNo);
  }

  /**
   * Reads the details of service center for Provider.
   *
   * @param key
   * provider service center ID.
   *
   * @return ProviderServiceCenterSummaryDetails details of the provider service
   * center.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderServiceCenterSummaryDetails viewServiceCenter(
    ProviderServiceCenterKey key) throws AppException, InformationalException {

    final curam.provider.impl.ProviderServiceCenter providerServiceCenter = providerServiceCenterDAO.get(
      key.providerServiceCenterID);

    ProviderServiceCenterSummaryDetails providerServiceCenterSummaryDetails = getProviderServiceCenterFields(
      providerServiceCenter);

    Set<ServiceCenterProviderOffering> unModifiableServiceCenterProviderOfferings = providerServiceCenter.getServiceCenterProviderOffering();
    Set<ServiceCenterProviderOffering> serviceCenterProviderOfferings = new HashSet<ServiceCenterProviderOffering>();

    serviceCenterProviderOfferings.addAll(
      unModifiableServiceCenterProviderOfferings);

    for (final ServiceCenterProviderOffering serviceCenterProviderOffering : sortServiceCenterProviderOffering(
      serviceCenterProviderOfferings)) {

      providerServiceCenterSummaryDetails.serviceCenterProviderOfferingDetails.addRef(
        getServiceCenterProviderOfferingFields(serviceCenterProviderOffering));
    }

    return providerServiceCenterSummaryDetails;
  }

  // BEGIN, CR00178272, AK
  /**
   * Creates a localized text translation for the provider service center
   * attribute, areas served information.
   *
   * @param localizableTextTranslationDetails
   * The localized text translation details for areas served
   * information.
   *
   * @return The localized text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00180149, ASN
  public LocalizableTextTranslationDetails addAreasServedInfoTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    LocalizableTextTranslationDetails result = new LocalizableTextTranslationDetails();
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (StringHelper.isEmpty(localizableTextTranslationDetails.text)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LOCALIZABLETEXTExceptionCreator.ERR_TEXT_IS_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
      ValidationHelper.failIfErrorsExist();
    }
    localizableTextHandler.setShortTextInd(true);
    localizableTextHandler.addValue(localizableTextTranslationDetails.text,
      LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
    // END, CR00180149
    result.localizableTextID = localizableTextHandler.store();
    curam.provider.impl.ProviderServiceCenter providerServiceCenter = providerServiceCenterDAO.get(
      localizableTextTranslationDetails.localizableTextParentID);

    providerServiceCenter.setAreasServedInfoTextID(result.localizableTextID);
    // BEGIN, CR00180149, ASN
    providerServiceCenter.modify(
      localizableTextTranslationDetails.keyVersionDetails.version);
    // END, CR00180149
    return result;
  }

  /**
   * Creates a localized text translation for the provider service center
   * attribute, client information.
   *
   * @param localizableTextTranslationDetails
   * The localized text translation details for client information.
   *
   * @return The localized text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00180149, ASN
  public LocalizableTextTranslationDetails addClientInfoTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    LocalizableTextTranslationDetails result = new LocalizableTextTranslationDetails();
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (StringHelper.isEmpty(localizableTextTranslationDetails.text)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LOCALIZABLETEXTExceptionCreator.ERR_TEXT_IS_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
      ValidationHelper.failIfErrorsExist();
    }
    localizableTextHandler.setShortTextInd(true);
    localizableTextHandler.addValue(localizableTextTranslationDetails.text,
      LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
    // END, CR00180149
    result.localizableTextID = localizableTextHandler.store();
    curam.provider.impl.ProviderServiceCenter providerServiceCenter = providerServiceCenterDAO.get(
      localizableTextTranslationDetails.localizableTextParentID);

    providerServiceCenter.setClientInfoTextID(result.localizableTextID);
    // BEGIN, CR00180149, ASN
    providerServiceCenter.modify(
      localizableTextTranslationDetails.keyVersionDetails.version);
    // END, CR00180149

    return result;
  }

  /**
   * Creates service center for Provider.
   *
   * @param providerCenterRegisterInformation
   * Service center details as entered by the user.
   *
   * @return The provider service center ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public curam.cpm.facade.struct.ProviderServiceCenterKey createServiceCenterDetails(
    ProviderServiceCenterRegisterInformation providerCenterRegisterInformation)
    throws AppException, InformationalException {

    curam.provider.impl.ProviderServiceCenter providerServiceCenter = providerServiceCenterDAO.newInstance();

    setProviderServiceCenterDetails(providerServiceCenter,
      providerCenterRegisterInformation);

    providerServiceCenter.insert();

    final curam.provider.impl.ServiceCenterProviderOffering serviceCenterProviderOffering = serviceCenterProviderOfferingDAO.newInstance();

    setServiceCenterProviderOfferingDetails(serviceCenterProviderOffering,
      providerCenterRegisterInformation);
    serviceCenterProviderOffering.setProviderServiceCenter(
      providerServiceCenter);

    serviceCenterProviderOffering.insert();

    curam.cpm.facade.struct.ProviderServiceCenterKey providerServiceCenterKey = new curam.cpm.facade.struct.ProviderServiceCenterKey();

    providerServiceCenterKey.providerServiceCenterKey.providerServiceCenterID = providerServiceCenter.getID();

    return providerServiceCenterKey;
  }

  /**
   * Updates service center details for Provider.
   *
   * @param details
   * Modified details of the service center.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void updateServiceCenterDetails(
    ProviderServiceCenterRegisterInformation details) throws AppException,
      InformationalException {

    curam.provider.impl.ProviderServiceCenter providerServiceCenter = providerServiceCenterDAO.get(
      details.providerServiceCenterRegisterDetails.providerServiceCenterID);

    setProviderServiceCenterDetails(providerServiceCenter, details);

    providerServiceCenter.modify(
      details.providerServiceCenterRegisterDetails.versionNo);
  }

  /**
   * Reads the details of service center for Provider.
   *
   * @param key
   * provider service center ID.
   *
   * @return The details of the provider service center.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderServiceCenterSummaryInformation viewServiceCenterDetails(
    curam.cpm.facade.struct.ProviderServiceCenterKey key)
    throws AppException, InformationalException {

    final curam.provider.impl.ProviderServiceCenter providerServiceCenter = providerServiceCenterDAO.get(
      key.providerServiceCenterKey.providerServiceCenterID);

    ProviderServiceCenterSummaryInformation providerServiceCenterSummaryDetails = getProviderServiceCenterDetails(
      providerServiceCenter);

    Set<ServiceCenterProviderOffering> unModifiableServiceCenterProviderOfferings = providerServiceCenter.getServiceCenterProviderOffering();
    Set<ServiceCenterProviderOffering> serviceCenterProviderOfferings = new HashSet<ServiceCenterProviderOffering>();

    serviceCenterProviderOfferings.addAll(
      unModifiableServiceCenterProviderOfferings);

    for (final ServiceCenterProviderOffering serviceCenterProviderOffering : sortServiceCenterProviderOffering(
      serviceCenterProviderOfferings)) {

      providerServiceCenterSummaryDetails.providerServiceCenterSummaryDetails.serviceCenterProviderOfferingDetails.addRef(
        getServiceCenterProviderOfferingFields(serviceCenterProviderOffering));
    }

    return providerServiceCenterSummaryDetails;
  }

  /**
   * Gets the details of service center for Provider.
   *
   * @param providerServiceCenter
   * The provider service center object.
   *
   * @return The Provider service center details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ProviderServiceCenterSummaryInformation getProviderServiceCenterDetails(
    final curam.provider.impl.ProviderServiceCenter providerServiceCenter)
    throws AppException, InformationalException {

    final ProviderServiceCenterSummaryInformation providerServiceCenterSummaryDetails = new ProviderServiceCenterSummaryInformation();

    ProviderServiceCenterDtls providerServiceCenterDtls = new ProviderServiceCenterDtls();

    providerServiceCenterDtls.providerServiceCenterID = providerServiceCenter.getID();
    providerServiceCenterDtls.comments = providerServiceCenter.getComments();
    providerServiceCenterDtls.providerConcernRoleID = providerServiceCenter.getProvider().getID();
    providerServiceCenterDtls.recordStatus = providerServiceCenter.getLifecycleState().getCode();
    providerServiceCenterDtls.name = providerServiceCenter.getName();
    providerServiceCenterDtls.versionNo = providerServiceCenter.getVersionNo();
    providerServiceCenterDtls.startDate = providerServiceCenter.getDateRange().start();
    providerServiceCenterDtls.endDate = providerServiceCenter.getDateRange().end();
    // BEGIN, CR00180149, ASN

    if (0 != providerServiceCenter.getAreasServedInfoTextID()) {
      providerServiceCenterSummaryDetails.areasServedInformation = providerServiceCenter.getAreasServedInfo().getValue();
      providerServiceCenterSummaryDetails.areasServedInfoExistsInd = true;
      providerServiceCenterDtls.areasSvdInfoTxtID = providerServiceCenter.getAreasServedInfoTextID();

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        providerServiceCenterDtls.areasSvdInfoTxtID);

      if (0 == localizableTextHandler.listTranslations().size()) {
        providerServiceCenterSummaryDetails.areaServiceAddInd = true;
      } else {
        providerServiceCenterSummaryDetails.areaServiceViewInd = true;
      }

    }

    if (0 != providerServiceCenter.getClientInfoTextID()) {
      providerServiceCenterSummaryDetails.clientInformation = providerServiceCenter.getClientInfo().getValue();
      providerServiceCenterSummaryDetails.clientInfoExistsInd = true;
      providerServiceCenterDtls.clientInfoTextID = providerServiceCenter.getClientInfoTextID();

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        providerServiceCenterDtls.clientInfoTextID);

      if (0 == localizableTextHandler.listTranslations().size()) {
        providerServiceCenterSummaryDetails.clientInfoAddInd = true;
      } else {
        providerServiceCenterSummaryDetails.clientInfoViewInd = true;
      }

    }
    // END, CR00180149
    providerServiceCenterSummaryDetails.providerServiceCenterSummaryDetails.providerServiceCenterDtls = providerServiceCenterDtls;

    ProviderServiceCenterContactDetails providerServiceCenterContactDetails = new ProviderServiceCenterContactDetails();

    Address addressObj = AddressFactory.newInstance();
    AddressDtls addressDtls = new AddressDtls();
    OtherAddressData formattedAddressData = new OtherAddressData();

    PhoneNumber phoneNumberObj = PhoneNumberFactory.newInstance();
    PhoneNumberDtls phoneNumberDtls = new PhoneNumberDtls();

    curam.core.sl.entity.intf.WebAddress webAddressObj = WebAddressFactory.newInstance();
    WebAddressDtls webAddressDtls;

    EmailAddress emailAddressObj = EmailAddressFactory.newInstance();
    EmailAddressDtls emailAddressDtls;

    long emailAddressID = providerServiceCenter.getEmailAddressID();

    if (emailAddressID != 0) {
      EmailAddressKey emailAddressKey = new EmailAddressKey();

      emailAddressKey.emailAddressID = emailAddressID;
      emailAddressDtls = emailAddressObj.read(emailAddressKey);

      providerServiceCenterContactDetails.emailAddress = emailAddressDtls.emailAddress;
    }

    long webAddressID = providerServiceCenter.getWebAddressID();

    if (webAddressID != 0) {
      WebAddressKey webAddressKey = new WebAddressKey();

      webAddressKey.webAddressID = webAddressID;
      webAddressDtls = webAddressObj.read(webAddressKey);

      providerServiceCenterContactDetails.webAddress = webAddressDtls.webAddress;
    }

    long addressID = providerServiceCenter.getAddressID();

    // Check if address is specified for service center
    if (addressID != 0) {
      // Read the inquiry home address
      AddressKey addressKey = new AddressKey();

      addressKey.addressID = addressID;
      addressDtls = addressObj.read(addressKey);

      // Assign the inquiry home address

      providerServiceCenterContactDetails.address = addressDtls.addressData;

      formattedAddressData.addressData = addressDtls.addressData;
      addressObj.getAddressStrings(formattedAddressData);

      providerServiceCenterContactDetails.formattedAddress = formattedAddressData.addressData;
    }

    curam.participant.impl.PhoneNumber phoneNumber = providerServiceCenter.getPhoneNumber();

    // Check if home phone number is specified for provider inquiry
    if (phoneNumber != null) {

      // Read the inquiry home phone number
      PhoneNumberKey phoneNumberKey = new PhoneNumberKey();

      phoneNumberKey.phoneNumberID = phoneNumber.getID();
      phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);

      // Assign inquiry home phone number
      providerServiceCenterContactDetails.phoneAreaCode = phoneNumberDtls.phoneAreaCode;

      providerServiceCenterContactDetails.phoneCountryCode = phoneNumberDtls.phoneCountryCode;
      providerServiceCenterContactDetails.phoneExtension = phoneNumberDtls.phoneExtension;
      providerServiceCenterContactDetails.phoneNumber = phoneNumberDtls.phoneNumber;

      final String formattedPhoneNumber = phoneNumberDtls.phoneCountryCode
        + phoneNumberDtls.phoneAreaCode + phoneNumberDtls.phoneNumber;

      providerServiceCenterContactDetails.formattedPhoneNumber = formattedPhoneNumber;
    }

    providerServiceCenterSummaryDetails.providerServiceCenterSummaryDetails.contactDetails = providerServiceCenterContactDetails;

    return providerServiceCenterSummaryDetails;
  }

  /**
   * Sets the details of service center for Provider.
   *
   * @param providerServiceCenter
   * The provider service center ID.
   * @param details
   * The provider service center details as entered by user.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void setProviderServiceCenterDetails(
    final curam.provider.impl.ProviderServiceCenter providerServiceCenter,
    final ProviderServiceCenterRegisterInformation details) throws AppException,
      InformationalException {

    final Provider provider = providerDAO.get(
      details.providerServiceCenterRegisterDetails.providerConcernRoleID);

    providerServiceCenter.setComments(
      details.providerServiceCenterRegisterDetails.comments);
    providerServiceCenter.setName(
      details.providerServiceCenterRegisterDetails.name);
    providerServiceCenter.setProvider(provider);

    final DateRange dateRange = new DateRange(
      details.providerServiceCenterRegisterDetails.startDate,
      details.providerServiceCenterRegisterDetails.endDate);

    providerServiceCenter.setDateRange(dateRange);
    providerServiceCenter.setName(
      details.providerServiceCenterRegisterDetails.name);

    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    if (details.providerServiceCenterRegisterDetails.emailAddress != null
      && details.providerServiceCenterRegisterDetails.emailAddress.trim().length()
        > 0) {
      EmailAddress emailAddressObj = EmailAddressFactory.newInstance();
      EmailAddressDtls emailAddressDtls = new EmailAddressDtls();

      long emailAddressID = providerServiceCenter.getEmailAddressID();

      if (emailAddressID != 0) {
        EmailAddressKey emailAddressKey = new EmailAddressKey();

        emailAddressKey.emailAddressID = emailAddressID;
        emailAddressDtls = emailAddressObj.read(emailAddressKey);
        emailAddressDtls.emailAddress = details.providerServiceCenterRegisterDetails.emailAddress;
        emailAddressObj.modify(emailAddressKey, emailAddressDtls);
      } else {
        emailAddressDtls.emailAddress = details.providerServiceCenterRegisterDetails.emailAddress;
        emailAddressDtls.emailAddressID = uniqueIDObj.getNextID();
        emailAddressObj.insert(emailAddressDtls);
      }

      providerServiceCenter.setEmailAddressID(emailAddressDtls.emailAddressID);
    }

    if (details.providerServiceCenterRegisterDetails.webAddress != null
      && details.providerServiceCenterRegisterDetails.webAddress.trim().length()
        > 0) {

      curam.core.sl.entity.intf.WebAddress webAddressObj = WebAddressFactory.newInstance();
      WebAddressDtls webAddressDtls = new WebAddressDtls();

      long webAddressID = providerServiceCenter.getWebAddressID();
      ConcernRoleIDKey concernRoleIDKey = new ConcernRoleIDKey();

      concernRoleIDKey.concernRoleID = webAddressID;

      if (webAddressID != 0) {
        WebAddressKey webAddressKey = new WebAddressKey();

        webAddressKey.webAddressID = webAddressID;
        webAddressDtls = webAddressObj.read(webAddressKey);
        webAddressDtls.webAddress = details.providerServiceCenterRegisterDetails.webAddress;
        webAddressObj.modify(webAddressKey, webAddressDtls);
      } else {
        webAddressDtls.webAddress = details.providerServiceCenterRegisterDetails.webAddress;
        webAddressDtls.webAddressID = uniqueIDObj.getNextID();
        webAddressObj.insert(webAddressDtls);
      }

      providerServiceCenter.setWebAddressID(webAddressDtls.webAddressID);
    }

    // create or modify address
    if (checkAddressNotEmpty(
      details.providerServiceCenterRegisterDetails.addressData)) {
      // run time object creation
      // variables for creating address
      curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
      AddressKey addressKey;
      AddressDtls addressDtls = new AddressDtls();

      long addressID = providerServiceCenter.getAddressID();

      if (addressID != 0) {
        // if home address key already exists
        // i.e home address already entered during creation
        addressKey = new AddressKey();
        addressKey.addressID = addressID;
        addressDtls = addressObj.read(addressKey);
        addressDtls.addressData = details.providerServiceCenterRegisterDetails.addressData;
        addressObj.modify(addressKey, addressDtls);
      } else {
        addressDtls.addressData = details.providerServiceCenterRegisterDetails.addressData;
        addressObj.insert(addressDtls);
      }

      providerServiceCenter.setAddressID(addressDtls.addressID);
    }

    // create or modify phone
    if ((details.providerServiceCenterRegisterDetails.phoneNumber != null)
      && (details.providerServiceCenterRegisterDetails.phoneNumber.length() > 0)) {
      // run time object creation
      // variables for creating phone number
      curam.core.intf.PhoneNumber phoneNumberObj = curam.core.fact.PhoneNumberFactory.newInstance();
      PhoneNumberDtls phoneNumberDtls = new PhoneNumberDtls();
      PhoneNumberKey phoneNumberKey;

      curam.participant.impl.PhoneNumber phoneNumber = providerServiceCenter.getPhoneNumber();

      if (phoneNumber != null) {
        phoneNumberKey = new PhoneNumberKey();
        phoneNumberKey.phoneNumberID = phoneNumber.getID();
        phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);
        phoneNumberDtls.phoneCountryCode = details.providerServiceCenterRegisterDetails.phoneCountryCode;
        phoneNumberDtls.phoneAreaCode = details.providerServiceCenterRegisterDetails.phoneAreaCode;
        phoneNumberDtls.phoneNumber = details.providerServiceCenterRegisterDetails.phoneNumber;
        phoneNumberDtls.phoneExtension = details.providerServiceCenterRegisterDetails.phoneExtension;
        phoneNumberObj.modify(phoneNumberKey, phoneNumberDtls);
      } else {
        phoneNumberDtls.phoneCountryCode = details.providerServiceCenterRegisterDetails.phoneCountryCode;
        phoneNumberDtls.phoneAreaCode = details.providerServiceCenterRegisterDetails.phoneAreaCode;
        phoneNumberDtls.phoneNumber = details.providerServiceCenterRegisterDetails.phoneNumber;
        phoneNumberDtls.phoneExtension = details.providerServiceCenterRegisterDetails.phoneExtension;
        phoneNumberDtls.phoneNumberID = uniqueIDObj.getNextID();
        phoneNumberObj.insert(phoneNumberDtls);
        phoneNumber = phoneNumberDAO.get(phoneNumberDtls.phoneNumberID);
      }

      providerServiceCenter.setPhoneNumber(phoneNumber);
    }

    if (providerServiceCenter.getAreasServedInfoTextID() == 0) {
      LocalizableTextTranslationDetails localizableTextTranslationDetails = new LocalizableTextTranslationDetails();
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.setShortTextInd(true);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text);
      providerServiceCenter.setAreasServedInfoTextID(
        localizableTextHandler.store());
    }
    providerServiceCenter.getAreasServedInfo().addValue(
      details.areasServedInformation);

    if (providerServiceCenter.getClientInfoTextID() == 0) {
      LocalizableTextTranslationDetails localizableTextTranslationDetails = new LocalizableTextTranslationDetails();
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.setShortTextInd(true);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text);
      providerServiceCenter.setClientInfoTextID(localizableTextHandler.store());
    }
    providerServiceCenter.getClientInfo().addValue(details.clientInformation);

  }

  /**
   * This method returns sets the Service center offering fields
   *
   * @param serviceCenterProviderOffering -
   * The service center provider offering object.
   * @param details -
   * The provider service center register details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void setServiceCenterProviderOfferingDetails(
    ServiceCenterProviderOffering serviceCenterProviderOffering,
    ProviderServiceCenterRegisterInformation details) throws AppException,
      InformationalException {

    final DateRange dateRange = new DateRange(
      details.providerServiceCenterRegisterDetails.serviceStartDate,
      details.providerServiceCenterRegisterDetails.serviceEndDate);

    final ProviderOffering providerOffering = providerOfferingDAO.get(
      details.providerServiceCenterRegisterDetails.providerOfferingID);

    serviceCenterProviderOffering.setDateRange(dateRange);
    serviceCenterProviderOffering.setProviderOffering(providerOffering);

  }

  // END, CR00178272

 
  /**
   * Sets the details of service center for Provider.
   *
   * @param providerServiceCenter
   * provider service center ID.
   * @param details
   * provider service center details as entered by user.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setProviderServiceCenterFields(
    // END, CR00177241
    final curam.provider.impl.ProviderServiceCenter providerServiceCenter,
    final ProviderServiceCenterRegisterDetails details) throws AppException,
      InformationalException {

    final Provider provider = providerDAO.get(details.providerConcernRoleID);

    providerServiceCenter.setComments(details.comments);
    providerServiceCenter.setName(details.name);
    providerServiceCenter.setProvider(provider);

    final DateRange dateRange = new DateRange(details.startDate,
      details.endDate);

    providerServiceCenter.setDateRange(dateRange);
    providerServiceCenter.setName(details.name);

    // unique ID generator
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    if (details.emailAddress != null
      && details.emailAddress.trim().length() > 0) {
      // Email address entry
      EmailAddress emailAddressObj = EmailAddressFactory.newInstance();
      EmailAddressDtls emailAddressDtls = new EmailAddressDtls();

      long emailAddressID = providerServiceCenter.getEmailAddressID();

      if (emailAddressID != 0) {
        EmailAddressKey emailAddressKey = new EmailAddressKey();

        emailAddressKey.emailAddressID = emailAddressID;
        emailAddressDtls = emailAddressObj.read(emailAddressKey);
        emailAddressDtls.emailAddress = details.emailAddress;
        emailAddressObj.modify(emailAddressKey, emailAddressDtls);
      } else {
        emailAddressDtls.emailAddress = details.emailAddress;
        emailAddressDtls.emailAddressID = uniqueIDObj.getNextID();
        emailAddressObj.insert(emailAddressDtls);
      }

      providerServiceCenter.setEmailAddressID(emailAddressDtls.emailAddressID);
    }

    if (details.webAddress != null && details.webAddress.trim().length() > 0) {

      // web address entry
      curam.core.sl.entity.intf.WebAddress webAddressObj = WebAddressFactory.newInstance();
      WebAddressDtls webAddressDtls = new WebAddressDtls();

      long webAddressID = providerServiceCenter.getWebAddressID();
      ConcernRoleIDKey concernRoleIDKey = new ConcernRoleIDKey();

      concernRoleIDKey.concernRoleID = webAddressID;

      if (webAddressID != 0) {
        WebAddressKey webAddressKey = new WebAddressKey();

        webAddressKey.webAddressID = webAddressID;
        webAddressDtls = webAddressObj.read(webAddressKey);
        webAddressDtls.webAddress = details.webAddress;
        webAddressObj.modify(webAddressKey, webAddressDtls);
      } else {
        webAddressDtls.webAddress = details.webAddress;
        webAddressDtls.webAddressID = uniqueIDObj.getNextID();
        webAddressObj.insert(webAddressDtls);
      }

      providerServiceCenter.setWebAddressID(webAddressDtls.webAddressID);
    }

    // create or modify address
    if (checkAddressNotEmpty(details.addressData)) {
      // run time object creation
      // variables for creating address
      curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
      AddressKey addressKey;
      AddressDtls addressDtls = new AddressDtls();

      long addressID = providerServiceCenter.getAddressID();

      if (addressID != 0) {
        // if home address key already exists
        // i.e home address already entered during creation
        addressKey = new AddressKey();
        addressKey.addressID = addressID;
        addressDtls = addressObj.read(addressKey);
        addressDtls.addressData = details.addressData;
        addressObj.modify(addressKey, addressDtls);
      } else {
        addressDtls.addressData = details.addressData;
        addressObj.insert(addressDtls);
      }

      providerServiceCenter.setAddressID(addressDtls.addressID);
    }

    // create or modify phone
    if ((details.phoneNumber != null) && (details.phoneNumber.length() > 0)) {
      // run time object creation
      // variables for creating phone number
      curam.core.intf.PhoneNumber phoneNumberObj = curam.core.fact.PhoneNumberFactory.newInstance();
      PhoneNumberDtls phoneNumberDtls = new PhoneNumberDtls();
      PhoneNumberKey phoneNumberKey;

      curam.participant.impl.PhoneNumber phoneNumber = providerServiceCenter.getPhoneNumber();

      if (phoneNumber != null) {
        phoneNumberKey = new PhoneNumberKey();
        phoneNumberKey.phoneNumberID = phoneNumber.getID();
        phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);
        phoneNumberDtls.phoneCountryCode = details.phoneCountryCode;
        phoneNumberDtls.phoneAreaCode = details.phoneAreaCode;
        phoneNumberDtls.phoneNumber = details.phoneNumber;
        phoneNumberDtls.phoneExtension = details.phoneExtension;
        phoneNumberObj.modify(phoneNumberKey, phoneNumberDtls);
      } else {
        phoneNumberDtls.phoneCountryCode = details.phoneCountryCode;
        phoneNumberDtls.phoneAreaCode = details.phoneAreaCode;
        phoneNumberDtls.phoneNumber = details.phoneNumber;
        phoneNumberDtls.phoneExtension = details.phoneExtension;
        phoneNumberDtls.phoneNumberID = uniqueIDObj.getNextID();
        phoneNumberObj.insert(phoneNumberDtls);
        phoneNumber = phoneNumberDAO.get(phoneNumberDtls.phoneNumberID);
      }

      providerServiceCenter.setPhoneNumber(phoneNumber);
    }

  }

  /**
   * Gets the details of service center for Provider.
   *
   * @param providerServiceCenter
   * provider service center details.
   *
   * @return ProviderServiceCenterSummaryDetails Provider service center
   * details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected ProviderServiceCenterSummaryDetails getProviderServiceCenterFields(
    // END, CR00177241
    final curam.provider.impl.ProviderServiceCenter providerServiceCenter)
    throws AppException, InformationalException {

    final ProviderServiceCenterSummaryDetails providerServiceCenterSummaryDetails = new ProviderServiceCenterSummaryDetails();

    ProviderServiceCenterDtls providerServiceCenterDtls = new ProviderServiceCenterDtls();

    providerServiceCenterDtls.providerServiceCenterID = providerServiceCenter.getID();
    providerServiceCenterDtls.comments = providerServiceCenter.getComments();
    providerServiceCenterDtls.providerConcernRoleID = providerServiceCenter.getProvider().getID();
    providerServiceCenterDtls.recordStatus = providerServiceCenter.getLifecycleState().getCode();
    providerServiceCenterDtls.name = providerServiceCenter.getName();
    providerServiceCenterDtls.versionNo = providerServiceCenter.getVersionNo();
    providerServiceCenterDtls.startDate = providerServiceCenter.getDateRange().start();
    providerServiceCenterDtls.endDate = providerServiceCenter.getDateRange().end();

    providerServiceCenterSummaryDetails.providerServiceCenterDtls = providerServiceCenterDtls;

    ProviderServiceCenterContactDetails providerServiceCenterContactDetails = new ProviderServiceCenterContactDetails();

    // Address Entity
    Address addressObj = AddressFactory.newInstance();
    AddressDtls addressDtls = new AddressDtls();
    OtherAddressData formattedAddressData = new OtherAddressData();

    // Phone Number Entity
    PhoneNumber phoneNumberObj = PhoneNumberFactory.newInstance();
    PhoneNumberDtls phoneNumberDtls = new PhoneNumberDtls();

    // web address entry
    curam.core.sl.entity.intf.WebAddress webAddressObj = WebAddressFactory.newInstance();
    WebAddressDtls webAddressDtls;

    // Email address entry
    EmailAddress emailAddressObj = EmailAddressFactory.newInstance();
    EmailAddressDtls emailAddressDtls;

    long emailAddressID = providerServiceCenter.getEmailAddressID();

    if (emailAddressID != 0) {
      EmailAddressKey emailAddressKey = new EmailAddressKey();

      emailAddressKey.emailAddressID = emailAddressID;
      emailAddressDtls = emailAddressObj.read(emailAddressKey);

      providerServiceCenterContactDetails.emailAddress = emailAddressDtls.emailAddress;
    }

    long webAddressID = providerServiceCenter.getWebAddressID();

    if (webAddressID != 0) {
      WebAddressKey webAddressKey = new WebAddressKey();

      webAddressKey.webAddressID = webAddressID;
      webAddressDtls = webAddressObj.read(webAddressKey);

      providerServiceCenterContactDetails.webAddress = webAddressDtls.webAddress;
    }

    long addressID = providerServiceCenter.getAddressID();

    // Check if address is specified for service center
    if (addressID != 0) {
      // Read the inquiry home address
      AddressKey addressKey = new AddressKey();

      addressKey.addressID = addressID;
      addressDtls = addressObj.read(addressKey);

      // Assign the inquiry home address

      providerServiceCenterContactDetails.address = addressDtls.addressData;

      formattedAddressData.addressData = addressDtls.addressData;
      addressObj.getAddressStrings(formattedAddressData);

      providerServiceCenterContactDetails.formattedAddress = formattedAddressData.addressData;
    }

    curam.participant.impl.PhoneNumber phoneNumber = providerServiceCenter.getPhoneNumber();

    // Check if home phone number is specified for provider inquiry
    if (phoneNumber != null) {

      // Read the inquiry home phone number
      PhoneNumberKey phoneNumberKey = new PhoneNumberKey();

      phoneNumberKey.phoneNumberID = phoneNumber.getID();
      phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);

      // Assign inquiry home phone number
      providerServiceCenterContactDetails.phoneAreaCode = phoneNumberDtls.phoneAreaCode;

      providerServiceCenterContactDetails.phoneCountryCode = phoneNumberDtls.phoneCountryCode;
      providerServiceCenterContactDetails.phoneExtension = phoneNumberDtls.phoneExtension;
      providerServiceCenterContactDetails.phoneNumber = phoneNumberDtls.phoneNumber;

      final String formattedPhoneNumber = phoneNumberDtls.phoneCountryCode
        + phoneNumberDtls.phoneAreaCode + phoneNumberDtls.phoneNumber;

      providerServiceCenterContactDetails.formattedPhoneNumber = formattedPhoneNumber;
    }

    providerServiceCenterSummaryDetails.contactDetails = providerServiceCenterContactDetails;

    return providerServiceCenterSummaryDetails;
  }

  /**
   * Sorts a set of provider offerings into a sorted list for display.
   *
   * @param unsortedProviderServiceCenters
   * the set of service centers
   * @return a sorted list of service center for display.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.provider.impl.ProviderServiceCenter> sortProviderServiceCenters(
    // END, CR00177241
    final Set<curam.provider.impl.ProviderServiceCenter> unsortedProviderServiceCenters) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    final List<curam.provider.impl.ProviderServiceCenter> providerServiceCenters = new ArrayList<curam.provider.impl.ProviderServiceCenter>(
      unsortedProviderServiceCenters);

    Collections.sort(providerServiceCenters,
      new Comparator<curam.provider.impl.ProviderServiceCenter>() {
      public int compare(
        final curam.provider.impl.ProviderServiceCenter lhs,
        curam.provider.impl.ProviderServiceCenter rhs) {
        return lhs.getProviderServiceCenter().getName().compareTo(
          rhs.getProviderServiceCenter().getName());
      }
    });
    return providerServiceCenters;
  }

  /**
   * This method returns sets the Service center offering fields
   *
   * @param serviceCenterProviderOffering -
   * ServiceCenterProviderOffering
   * @param details -
   * ProviderServiceCenterRegisterDetails
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void setServiceCenterProviderOffering(
    // END, CR00177241
    ServiceCenterProviderOffering serviceCenterProviderOffering,
    ProviderServiceCenterRegisterDetails details) throws AppException,
      InformationalException {

    final DateRange dateRange = new DateRange(details.serviceStartDate,
      details.serviceEndDate);

    final ProviderOffering providerOffering = providerOfferingDAO.get(
      details.providerOfferingID);

    serviceCenterProviderOffering.setDateRange(dateRange);
    serviceCenterProviderOffering.setProviderOffering(providerOffering);

  }

  /**
   * Lists the Active provider offerings.
   *
   * @param key
   * provider ID.
   * @return ProviderOfferingSummaryDetailsList Details of provider offerings.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public ProviderOfferingSummaryDetailsList listActiveProviderOffering(
    ProviderKey key) throws AppException, InformationalException {

    final curam.cpm.facade.intf.ProviderOffering providerOffering = ProviderOfferingFactory.newInstance();

    ProviderOfferingSummaryDetailsList providerOfferingSummaryDetailsList = providerOffering.listServiceOfferingsByProvider(
      key);

    int listSize = providerOfferingSummaryDetailsList.providerOfferingSummaryDetails.size();

    ProviderOfferingSummaryDetailsList activeProviderOfferingSummaryDetailsList = new ProviderOfferingSummaryDetailsList();

    for (int i = 0; i < listSize; i++) {

      ProviderOfferingSummaryDetails providerOfferingSummaryDetails = providerOfferingSummaryDetailsList.providerOfferingSummaryDetails.item(
        i);

      curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceOfferingDAO.get(
        providerOfferingSummaryDetails.serviceOfferingID);

      final UnitOfMeasureEntry providerServiceUnitOfMeasure = serviceOffering.getUnitOfMeasure();

      if (!providerServiceUnitOfMeasure.equals(UnitOfMeasureEntry.PLACE)) {

        if ((StringHelper.trim(providerOfferingSummaryDetails.recordStatus)).equalsIgnoreCase(
          curam.providerservice.ProviderOfferingStatus.APPROVED)) {

          if (providerOfferingSummaryDetails.endDate.isZero()
            || (!providerOfferingSummaryDetails.endDate.isZero()
              && providerOfferingSummaryDetails.endDate.after(
                Date.getCurrentDate().addDays(-1)))) {

            activeProviderOfferingSummaryDetailsList.providerOfferingSummaryDetails.addRef(
              providerOfferingSummaryDetails);
          }

        }
      }
    }

    return activeProviderOfferingSummaryDetailsList;
  }

  /**
   * This method returns the service center provider offering fields
   *
   * @param serviceCenterProviderOffering
   * ServiceCenterProviderOffering
   * @return ServiceCenterProviderOfferingSummaryDetails
   */
  // BEGIN, CR00177241, PM
  protected ServiceCenterProviderOfferingSummaryDetails getServiceCenterProviderOfferingFields(
    // END, CR00177241
    final ServiceCenterProviderOffering serviceCenterProviderOffering) {

    final ServiceCenterProviderOfferingSummaryDetails serviceCenterProviderOfferingDetails = new ServiceCenterProviderOfferingSummaryDetails();

    serviceCenterProviderOfferingDetails.servCenterProviderOfferingID = serviceCenterProviderOffering.getID();
    serviceCenterProviderOfferingDetails.serviceCenterRecordStatus = serviceCenterProviderOffering.getLifecycleState().getCode();
    serviceCenterProviderOfferingDetails.serviceName = serviceCenterProviderOffering.getProviderOffering().getServiceOffering().getName();
    // BEGIN, CR00246783, GP
    serviceCenterProviderOfferingDetails.serviceOfferingID = serviceCenterProviderOffering.getProviderOffering().getServiceOffering().getID();
    // END, CR00246783
    serviceCenterProviderOfferingDetails.startDate = serviceCenterProviderOffering.getDateRange().start();
    serviceCenterProviderOfferingDetails.endDate = serviceCenterProviderOffering.getDateRange().end();
    serviceCenterProviderOfferingDetails.versionNo = serviceCenterProviderOffering.getVersionNo();

    return serviceCenterProviderOfferingDetails;
  }

  /**
   * This method checks for empty address
   *
   * @param addressData
   * address data
   * @return boolean value indicating if address is entered or not
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected boolean checkAddressNotEmpty(String addressData) throws AppException,
      // END, CR00177241
      InformationalException {

    curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();

    // check to see if mailing address has been entered
    OtherAddressData otherAddressData = new OtherAddressData();
    EmptyIndStruct emptyIndStruct;

    otherAddressData.addressData = addressData;

    // get the starting position
    int startPos = addressData.indexOf(
      addressObj.getCountry(otherAddressData).addressElementString);
    // get the end position
    int endPos = addressData.indexOf(GeneralConstants.kNewLine, startPos);

    // get the address between start and end position
    if (startPos > 0) {
      otherAddressData.addressData = addressData.substring(0, startPos)
        + addressData.substring(endPos, addressData.length());
    }

    emptyIndStruct = addressObj.isEmpty(otherAddressData);

    // emptyInd is set to true if the address is not entered; else is set to
    // false
    // so, if address is entered, then the return value from this method would
    // be true
    return !emptyIndStruct.emptyInd;

  }

  /**
   * Sorts a set of Service Center Provider Offerings into a sorted list for
   * display.
   *
   * @param unsortedServiceCenterProviderOfferings
   * the set of service centers
   * @return a sorted list of Service Center Provider Offerings for display.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.provider.impl.ServiceCenterProviderOffering> sortServiceCenterProviderOffering(
    // END, CR00177241
    final Set<curam.provider.impl.ServiceCenterProviderOffering> unsortedServiceCenterProviderOfferings) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    final List<curam.provider.impl.ServiceCenterProviderOffering> serviceCenterProviderOfferings = new ArrayList<curam.provider.impl.ServiceCenterProviderOffering>(
      unsortedServiceCenterProviderOfferings);

    Collections.sort(serviceCenterProviderOfferings,
      new Comparator<curam.provider.impl.ServiceCenterProviderOffering>() {
      public int compare(
        final curam.provider.impl.ServiceCenterProviderOffering lhs,
        curam.provider.impl.ServiceCenterProviderOffering rhs) {
        return lhs.getProviderOffering().getServiceOffering().getName().compareTo(
          rhs.getProviderOffering().getServiceOffering().getName());
      }
    });
    return serviceCenterProviderOfferings;
  }
}
