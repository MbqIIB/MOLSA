/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


import curam.codetable.impl.SENSITIVITYEntry;
import curam.datastore.impl.Datastore;
import curam.provider.impl.ProviderSpecialtyTypeEntry;
import curam.referral.impl.Referral;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.type.Date;


/**
 * Facade layer class used by the Add Referral wizard.
 *
 * @since 6.0
 */
public class ReferralWizardConstants {

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} containing the
   * provider notification text.
   */
  public static final String kPROVIDER_NOTIFICATION_TEXT = "providerNotificationText";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} containing the
   * client notification text.
   */
  public static final String kCLIENT_NOTIFICATION_TEXT = "clientNotificationText";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * whether the the provider is to be automatically notified.
   */
  public static final String kNOTIFIY_PROVIDER_AUTOMATICALLY = "notifiyProviderAutomatically";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * whether the the client is to be automatically notified.
   */
  public static final String kNOTIFIY_CLIENT_AUTOMATICALLY = "notifiyClientAutomatically";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * whether the the a provider search on the system has been performed.
   */
  public static final String kPROVIDER_SEARCH_PERFORMED = "providerSearchPerformed";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the selected provider from the results of a performed search for providers
   * on the system.
   */
  public static final String kSEARCHED_PROVIDER_ID = "searchedProviderID";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents a
   * {@link ProviderSpecialtyTypeEntry} selected to filter the results of a
   * performed search for providers on the system.
   */
  public static final String kPROVIDER_SPECIALITY_CODE = "providerSpecialityCodes";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the unique identifier of the address of a client stored on the data store.
   */
  public static final String kCLIENT_ADDRESSS_ID = "clientAddresssID";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the unique identifier of the address of a client stored on the data store.
   */
  public static final String kCASE_PARTICIPANT_ROLE_ID = "clientParticipantID";

  /**
   * The proximity distance code value for the attribute on the
   * {@link curam.datastore.impl.Datastore} that represents the distance proximity filter stored on
   * the data store.
   */
  public static final String kPROXIMITYDISTANCE = "proximityDistance";
  
  /**
   * The provider name for the attribute on the
   * {@link curam.datastore.impl.Datastore} that represents the provider name filter stored on
   * the data store.
   */
  public static final String kPROVIDERNAME = "providerName";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the email address stored for a provider representative.
   */
  public static final String kPROVIDER_REPRESENTATIVE_EMAIL_ADDRESS = "providerRepresentativeEmailAddress";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the phone number stored for a provider representative.
   */
  public static final String kPROVIDER_REPRESENTATIVE_PHONE_NUMBER = "providerRepresentativePhoneNumber";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the phone number country code stored for a provider representative.
   */
  public static final String kPROVIDER_REPRESENTATIVE_PHONE_COUNTRY_CODE = "providerRepresentativePhoneCountryCode";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the phone number area code stored for a provider representative.
   */
  public static final String kPROVIDER_REPRESENTATIVE_PHONE_AREA_CODE = "providerRepresentativePhoneAreaCode";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the address details stored for a provider representative.
   */
  public static final String kPROVIDER_REPRESENTATIVE_ADDRESS_DETAILS = "providerRepresentativeAddressDetails";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the name stored for a provider representative.
   */
  public static final String kPROVIDER_REPRESENTATIVE_NAME = "providerRepresentativeName";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the unique identifier for a provider selected from the provider repository.
   */
  public static final String kPROVIDER_ID = "providerID";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the reason entered for the {@link curam.referral.impl.Referral}.
   */
  public static final String kREASON = "reason";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the selected {@link SENSITIVITYEntry} for the
   * {@link curam.referral.impl.Referral}.
   */
  public static final String kSENSITIVITY = "sensitivity";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the entered follow up warning days for the
   * {@link curam.referral.impl.Referral}.
   */
  public static final String kFOLLOW_UP_WARNING_DAYS = "followUpWarningDays";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * if follow up required option has been selected for the the
   * {@link curam.referral.impl.Referral}.
   */
  public static final String kFOLLOW_UP_REQUIRED_IND = "followUpRequiredInd";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the searched for user that referring the
   * {@link curam.referral.impl.Referral}.
   */
  public static final String kREFERRED_BY = "referredBy";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * that the individual who referred the referral is the user who is created
   * the {@link curam.referral.impl.Referral}.
   */
  public static final String kREFERRED_BY_ME_IND = "referredByMeInd";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * that the referral {@link Date} for the {@link curam.referral.impl.Referral}
   * .
   */
  public static final String kREFERRAL_DATE = "referralDate";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that represents
   * the selected clients.
   */
  public static final String kSELECTED_CLIENTS = "selectedClients";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that contains the
   * entered service name.
   */
  public static final String kSERVICE_NAME = "serviceName";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that contains the
   * unique identifier of a {@link ServiceOffering} search for and selected from
   * the service repository.
   */
  public static final String kSERVICE_OFFERING_ID = "serviceOfferingID";

  /**
   * The identifier for the attribute on the {@link curam.datastore.impl.Datastore} that contains the
   * boolean value indicating that the end of the wizard has been reached and
   * the {@link Referral} is to be created.
   */
  public static final String kFINISH_WIZARD_AND_CREATE_IND = "finishWizardAndCreateInd";

}
