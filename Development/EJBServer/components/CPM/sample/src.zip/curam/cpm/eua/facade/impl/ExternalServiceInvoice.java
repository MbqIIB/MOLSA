/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import curam.core.struct.ConcernRoleKey;
import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.eua.facade.struct.ServiceInvoiceDetailsList;
import curam.cpm.facade.fact.ContextDescriptionFactory;
import curam.cpm.facade.fact.ServiceInvoiceFactory;
import curam.cpm.facade.intf.ContextDescription;
import curam.cpm.facade.intf.ServiceInvoice;
import curam.cpm.facade.struct.ServiceInvoiceDetails;
import curam.cpm.facade.struct.ServiceInvoiceSummaryDetailsList;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ServiceInvoiceKey;
import curam.financial.impl.ServiceInvoiceDerivedStatusEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This process class provides the functionality for retrieving information
 * on Service Invoices for a provider/provider group.
 */
public abstract class ExternalServiceInvoice extends curam.cpm.eua.facade.base.ExternalServiceInvoice {

  /**
   * Constructor
   */
  public ExternalServiceInvoice() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * This facade method lists all service Invoices for a provider/provider
   * group
   *
   * @param concernRoleKey - contains the concern Role ID
   * @return The list of service invoices for a provider/provider group.
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ServiceInvoiceDetailsList listServiceInvoicesForProvider(
    ConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {

    // get the concern Role ID
    ProviderKey providerKey = new ProviderKey();

    providerKey.providerConcernRoleID = concernRoleKey.concernRoleID;

    // perform security checks
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    // call the facade method
    ServiceInvoice serviceInvoice = ServiceInvoiceFactory.newInstance();

    ServiceInvoiceDetailsList serviceInvoiceDetailsList = new ServiceInvoiceDetailsList();

    // remove all canceled records from the list
    // BEGIN, CR00304623, SS
    serviceInvoiceDetailsList.dtlsList = filterList(
      serviceInvoice.retrieveServiceInvoicesDetailsForProvider(providerKey));
    // END, CR00304623
    ContextDescription contextDescription = ContextDescriptionFactory.newInstance();

    serviceInvoiceDetailsList.contextDescription.pageContextDescription = contextDescription.getContextDescriptionForConcern(concernRoleKey).description;

    return serviceInvoiceDetailsList;
  }

  /**
   * This method filters the provider participants list removing all canceled
   * records from the list
   *
   * @param unfilteredList - this contains a list of provider participants
   * @return This contains a list of all provider participants except canceled
   */
  // BEGIN, CR00177241, PM
  protected ServiceInvoiceSummaryDetailsList filterList(
    ServiceInvoiceSummaryDetailsList unfilteredList) {
    // END, CR00177241

    ServiceInvoiceSummaryDetailsList result = new ServiceInvoiceSummaryDetailsList();

    for (int i = 0; i < unfilteredList.summaryDetailsList.size(); i++) {

      // BEGIN, CR00090261, GD
      if (!unfilteredList.summaryDetailsList.item(i).recordStatus.equals(
        ServiceInvoiceDerivedStatusEntry.CANCELED.getCode())) {
        // END, CR00090261
        result.summaryDetailsList.addRef(
          unfilteredList.summaryDetailsList.item(i));
      }
    }

    return result;
  }

  /**
   * This facade method reads service invoice details
   *
   * @param serviceInvoiceKey - contains the unique identifier for the
   * service invoice record
   * @return The service invoice details
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ServiceInvoiceDetails viewServiceInvoice(
    ServiceInvoiceKey serviceInvoiceKey) throws AppException, InformationalException {

    // call the facade method
    ServiceInvoice serviceInvoice = ServiceInvoiceFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ServiceInvoiceDetails serviceInvoiceDetails = serviceInvoice.viewServiceInvoice(
      serviceInvoiceKey);

    concernRoleKey.concernRoleID = serviceInvoiceDetails.serviceInvoiceDtls.originatorID;

    // perform security checks
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    return serviceInvoiceDetails;
  }
}
