/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import com.google.inject.Inject;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.impl.CuramConst;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.SearchTrainingKey;
import curam.cpm.facade.struct.SearchTrainingRequirementKey;
import curam.cpm.facade.struct.SearchTrainingServiceOfferingDetailsList;
import curam.cpm.facade.struct.SearchTrainingServiceOfferingKey;
import curam.cpm.facade.struct.TrainingDetails;
import curam.cpm.facade.struct.TrainingDetailsList;
import curam.cpm.facade.struct.TrainingIDTabList;
import curam.cpm.facade.struct.TrainingRequirementSummaryDetails;
import curam.cpm.facade.struct.TrainingRequirementSummaryDetailsList;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.LicenseTrainingRequirementSearchDetails;
import curam.cpm.sl.entity.struct.LicenseTrainingRequirementSearchDetailsList;
import curam.cpm.sl.entity.struct.LicenseTrainingRequirementSearchKey;
import curam.cpm.sl.entity.struct.TrainingKey;
import curam.cpm.sl.entity.struct.TrainingRequirementSearchDetails;
import curam.cpm.sl.entity.struct.TrainingServiceOfferingDtls;
import curam.cpm.sl.struct.TrainingServiceOfferingSearchDetails;
import curam.message.TRAINING;
import curam.message.TRAININGPROGRAM;
import curam.message.impl.TRAININGExceptionCreator;
import curam.message.impl.TRAININGPROGRAMExceptionCreator;
import curam.provider.impl.LicenseDAO;
import curam.provider.impl.LicenseStatusEntry;
import curam.provider.impl.LicenseTrainingRequirementDAO;
import curam.provider.impl.TrainingTypeEntry;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.SOTrainingRequirementDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.serviceoffering.impl.TrainingServiceOfferingDAO;
import curam.training.impl.Training;
import curam.training.impl.TrainingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;
import curam.util.type.DateRange;
import curam.util.type.StringHelper;
import curam.util.type.StringList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Set;


/**
 * Facade class having API's for managing Training. Training is a training
 * offering that an agency can record participation against. Examples of
 * training are Communicating Effectively in the Workplace, Understanding
 * Learning Disabilities.
 */
public abstract class MaintainTraining extends curam.cpm.facade.base.MaintainTraining {

  /**
   * License DAO
   */
  @Inject
  protected LicenseDAO licenseDAO;

  /**
   * Reference to Training DAO
   */
  @Inject
  protected TrainingDAO trainingDAO;

  /**
   * Reference to Service Offering DAO
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Reference to Training Service Offering DAO
   */
  @Inject
  protected TrainingServiceOfferingDAO trainingServiceOfferingDAO;

  /**
   * Reference to Training Requirement DAO
   */
  @Inject
  protected SOTrainingRequirementDAO trainingRequirementDAO;

  /**
   * License Training Requirement DAO
   */
  @Inject
  protected LicenseTrainingRequirementDAO licenseTrainingRequirementDAO;

  /**
   * Constructor
   */
  public MaintainTraining() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a Training with the specified training details.
   *
   * @param trainingDetails
   * Contains Training details.
   * @return TrainingKey Contains training ID of the newly created Training.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingKey createTraining(TrainingDetails trainingDetails)
    throws AppException, InformationalException {

    // Create an instance of Training.
    curam.training.impl.Training training = trainingDAO.newInstance();

    // Set the Training fields.
    setTrainingFields(training, trainingDetails);

    // Create the Training.
    training.insert();

    // Populate the details for return key.
    TrainingKey trainingKey = new TrainingKey();

    trainingKey.trainingID = training.getID();

    return trainingKey;
  }

  /**
   * Retrieves all the details of the specified Training.
   *
   * @param trainingKey
   * Contains Training ID.
   * @return TrainingDetails Contains Training details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingDetails viewTraining(TrainingKey trainingKey)
    throws AppException, InformationalException {

    // Get the instance of Training.
    curam.training.impl.Training training = trainingDAO.get(
      trainingKey.trainingID);

    return getTrainingFields(training);
  }

  /**
   * Lists all the Trainings present on the system.
   *
   * @return TrainingDetailsList Contains the list of Trainings.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingDetailsList listTraining() throws AppException,
      InformationalException {

    // Initialize the return struct.
    TrainingDetailsList trainingDetailsList = new TrainingDetailsList();

    // Retrieve all the Trainings sorted by Training name.
    List<curam.training.impl.Training> trainings = sortTrainings(
      trainingDAO.readAll());

    // Populate the return struct.
    for (final curam.training.impl.Training training : trainings) {
      trainingDetailsList.details.addRef(getTrainingFields(training));
    }

    return trainingDetailsList;
  }

  /**
   * Modifies a Training with the modified training details.
   *
   * @param trainingDetails
   * Contains training details to be modified.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyTraining(TrainingDetails trainingDetails)
    throws AppException, InformationalException {

    // Get the instance of Training to be modified.
    curam.training.impl.Training training = trainingDAO.get(
      trainingDetails.dtls.trainingID);

    // Set the Training fields.
    setTrainingFields(training, trainingDetails);

    // Modify the Training.
    training.modify(trainingDetails.dtls.versionNo);
  }

  /**
   * Searches for Training based on the search criteria entered.
   *
   * @param searchTrainingKey
   * Contains training name and training type criteria.
   * @return TrainingDtlsList Contains the list of trainings matching search
   * criteria.
   * @throws AppException
   * {@link TRAINING#ERR_TRAINING_XFV_TRAINING_SEARCH_CRITERIA_EMPTY} -
   * If no search criteria is entered.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingDetailsList searchTraining(SearchTrainingKey searchTrainingKey)
    throws AppException, InformationalException {

    // Initialize return struct.
    TrainingDetailsList trainingDetailsList = new TrainingDetailsList();

    // Check if search criteria is entered.
    if ((searchTrainingKey.key.trainingName.trim() + searchTrainingKey.key.trainingType.trim()).length()
      == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGExceptionCreator.ERR_TRAINING_XFV_TRAINING_SEARCH_CRITERIA_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
    }
    ValidationHelper.failIfErrorsExist();

    Training training = trainingDAO.newInstance();

    training.setName(searchTrainingKey.key.trainingName);
    training.setTrainingType(
      TrainingTypeEntry.get(searchTrainingKey.key.trainingType));

    // Search based on search criteria and sort by Training name.
    final List<curam.training.impl.Training> trainings = sortTrainings(
      trainingDAO.searchBy(training));

    // Assign the details to return struct.
    for (final curam.training.impl.Training trainingObj : trainings) {
      trainingDetailsList.details.addRef(getTrainingFields(trainingObj));
    }

    return trainingDetailsList;
  }

  /**
   * Cancels the specified Training.
   *
   * @param keyVersion
   * Contains Training ID and version number.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelTraining(KeyVersionDetails keyVersion) throws AppException,
      InformationalException {

    // Get the Training to be canceled.
    curam.training.impl.Training training = trainingDAO.get(keyVersion.id);

    // Cancel the Training.
    training.cancel(keyVersion.version);
  }

  /**
   * Sets the Training fields from details struct to an Training instance.
   *
   * @param training
   * Training instance.
   * @param trainingDetails
   * Training details struct.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setTrainingFields(final curam.training.impl.Training training,
    // END, CR00177241
    final TrainingDetails trainingDetails) throws AppException,
      InformationalException {

    // Set the Training details to Training instance.
    training.setName(trainingDetails.dtls.trainingName);
    training.setTrainingType(
      TrainingTypeEntry.get(trainingDetails.dtls.trainingType));
    training.setDateRange(
      new DateRange(trainingDetails.dtls.startDate,
      trainingDetails.dtls.endDate));
  }

  /**
   * Gets the Training fields from an instance to details struct.
   *
   * @param training
   * Training instance.
   * @return TrainingDetails Training details struct.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected TrainingDetails getTrainingFields(
    // END, CR00177241
    final curam.training.impl.Training training) throws AppException,
      InformationalException {

    // Initialize the return struct.
    TrainingDetails trainingDetails = new TrainingDetails();

    // Populate the Training details.
    trainingDetails.dtls.trainingID = training.getID();
    trainingDetails.dtls.trainingName = training.getName();
    trainingDetails.dtls.trainingType = training.getTrainingType().getCode();
    trainingDetails.dtls.startDate = training.getDateRange().start();
    trainingDetails.dtls.endDate = training.getDateRange().end();
    trainingDetails.dtls.recordStatus = training.getLifecycleState().getCode();
    trainingDetails.dtls.versionNo = training.getVersionNo();

    return trainingDetails;
  }

  /**
   * Sorts a set of Trainings by Training name into a sorted list for display.
   *
   * @param unsortedTrainings
   * The set of unsorted Trainings.
   * @return List<curam.training.impl.Training> A sorted list of Trainings.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.training.impl.Training> sortTrainings(
    // END, CR00177241
    final Set<curam.training.impl.Training> unsortedTrainings) {

    // Sort by name for display - using a list (instead of a set) in case there
    // are duplicate names.
    final List<curam.training.impl.Training> trainings = new ArrayList<curam.training.impl.Training>(
      unsortedTrainings);

    Collections.sort(trainings,
      new Comparator<curam.training.impl.Training>() {
      public int compare(final curam.training.impl.Training lhs,
        curam.training.impl.Training rhs) {
        return lhs.getName().compareTo(rhs.getName());
      }
    });
    return trainings;
  }

  /**
   * Searches for trainings which are currently offered as services for the
   * specified training name or unit of measure.
   *
   * @param key
   * Contains the training name or the unit of measure.
   * @return List of trainings matching the search criterion.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchTrainingServiceOfferingDetailsList searchByTrainingNameAndUnitOfMeasure(
    SearchTrainingServiceOfferingKey key) throws AppException,
      InformationalException {

    SearchTrainingServiceOfferingDetailsList detailsList = new SearchTrainingServiceOfferingDetailsList();

    if (CPMConstants.kSearchAction.equals(key.actionString)) {
      TrainingIDTabList trainingIDTabList = new TrainingIDTabList();

      trainingIDTabList.trainingIDTabList = key.trainingIDTabList;
      validateTrainingDetails(trainingIDTabList);
      return detailsList;
    }

    // Throw an exception if search criteria empty
    if (StringHelper.isEmpty(key.searchKey.trainingName)
      && StringHelper.isEmpty(key.searchKey.unitOfMeasure)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGExceptionCreator.ERR_TRAINING_XFV_TRAINING_SEARCH_CRITERIA_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
      // BEGIN CR00113459, NRV
      ValidationHelper.failIfErrorsExist();
      // END CR00113459
    }

    curam.cpm.sl.struct.SearchTrainingServiceOfferingKey searchKey = new curam.cpm.sl.struct.SearchTrainingServiceOfferingKey();

    searchKey = key.searchKey;
    searchKey.recordStatus = RECORDSTATUSEntry.NORMAL.getCode();

    /*
     * Trim the input */
    final String trainingNameTrim = StringHelper.trim(searchKey.trainingName);
    final String unitOfMeasureTrim = StringHelper.trim(searchKey.unitOfMeasure);

    /*
     * Initialize the search parameters */
    searchKey.searchByTrainingName = !StringHelper.isEmpty(trainingNameTrim);
    searchKey.searchByUnitOfMeasure = !StringHelper.isEmpty(unitOfMeasureTrim);

    searchKey.trainingName = CuramConst.gkSqlWildcard
      + trainingNameTrim.toUpperCase() + CuramConst.gkSqlWildcard;

    detailsList.SearchDetailsList = trainingServiceOfferingDAO.searchByTrainingNameAndUnitOfMeasure(
      searchKey);

    return getNonEndDatedTrainingServiceOfferigs(detailsList);
  }

  /**
   * Searches for trainings which are currently offered as services for a given
   * training type.
   *
   * @param key
   * Contains the training type.
   * @return List of trainings matching the search criterion.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchTrainingServiceOfferingDetailsList searchByTrainingType(
    SearchTrainingServiceOfferingKey key) throws AppException,
      InformationalException {

    SearchTrainingServiceOfferingDetailsList detailsList = new SearchTrainingServiceOfferingDetailsList();

    if (CPMConstants.kSearchAction.equals(key.actionString)) {
      TrainingIDTabList trainingIDTabList = new TrainingIDTabList();

      trainingIDTabList.trainingIDTabList = key.trainingIDTabList;
      validateTrainingDetails(trainingIDTabList);
      return detailsList;
    }

    curam.cpm.sl.struct.SearchTrainingServiceOfferingKey searchKey = new curam.cpm.sl.struct.SearchTrainingServiceOfferingKey();

    // BEGIN CR00113459, NRV
    if (StringHelper.isEmpty(key.searchKey.trainingType)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGExceptionCreator.ERR_TRAINING_XFV_TRAINING_SEARCH_CRITERIA_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      ValidationHelper.failIfErrorsExist();
    }
    // END CR00113459
    searchKey = key.searchKey;
    searchKey.recordStatus = RECORDSTATUSEntry.NORMAL.getCode();

    detailsList.SearchDetailsList = trainingServiceOfferingDAO.searchByTrainingType(
      searchKey);

    return getNonEndDatedTrainingServiceOfferigs(detailsList);
  }

  /**
   * Search for trainings which are listed as training requirement of any active
   * provider offerings currently held by a provider.
   *
   * @param key
   * Contains the provider ID.
   * @return List of trainings matching the search criterion.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingRequirementSummaryDetailsList retrieveTrainingRequirementsForProvider(
    SearchTrainingRequirementKey key) throws AppException,
      InformationalException {

    TrainingRequirementSummaryDetailsList detailsList = new TrainingRequirementSummaryDetailsList();

    // Declare the search key for service offering training requirements.
    curam.cpm.sl.entity.struct.SearchTrainingRequirementKey searchKey = new curam.cpm.sl.entity.struct.SearchTrainingRequirementKey();

    searchKey = key.searchRequirementKey;
    searchKey.recordStatus = ProviderOfferingStatusEntry.CANCELED.getCode();

    // Iterate through the service offering training requirements and add them
    // to the return struct.
    for (TrainingRequirementSearchDetails searchDetails : trainingRequirementDAO.retrieveForProvider(searchKey).dtls.items()) {
      TrainingRequirementSummaryDetails summaryDetails = getServiceOfferingTrainingRequirementsDetails(
        searchDetails);

      // Add the training requirement to the return struct if the training is an
      // active non ended training service offering.
      if (isActiveNonEndDatedTrainingServiceOfferings(summaryDetails)) {
        detailsList.details.addRef(summaryDetails);
      }
    }

    // Declare the search key for the license training requirements.
    LicenseTrainingRequirementSearchKey licenseSearchKey = new LicenseTrainingRequirementSearchKey();

    licenseSearchKey.concernRoleID = searchKey.concernRoleID;
    licenseSearchKey.licenseStatus = LicenseStatusEntry.APPROVED.getCode();

    // Get all the license training requirements.
    LicenseTrainingRequirementSearchDetailsList licenseList = licenseTrainingRequirementDAO.retrieveForProvider(
      licenseSearchKey);
    // Sort the license training requirements based on the license type.
    List<LicenseTrainingRequirementSearchDetails> duplicatesList = sortTrainingRequirements(
      licenseList);

    // Remove the duplicate training requirements of different licenses with the
    // same license type.
    for (LicenseTrainingRequirementSearchDetails licenseDetails : removeDuplicateLicenses(
      duplicatesList)) {
      TrainingRequirementSummaryDetails summaryDetails = getLicenseTrainingRequirementsDetails(
        licenseDetails);

      // Add the training requirement to the return struct if the training is an
      // active non ended training service offering.
      if (isActiveNonEndDatedTrainingServiceOfferings(summaryDetails)) {
        detailsList.details.addRef(summaryDetails);
      }
    }

    return detailsList;
  }

  /**
   * Search for trainings which are listed as training requirement of any active
   * provider offerings currently held by a provider group.
   *
   * @param key
   * Contains the provider ID.
   * @return List of trainings matching the search criterion.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingRequirementSummaryDetailsList retrieveTrainingRequirementsForProviderGroup(
    SearchTrainingRequirementKey key) throws AppException,
      InformationalException {

    TrainingRequirementSummaryDetailsList detailsList = new TrainingRequirementSummaryDetailsList();

    // Declare the search key for service offering training requirements.
    curam.cpm.sl.entity.struct.SearchTrainingRequirementKey searchKey = new curam.cpm.sl.entity.struct.SearchTrainingRequirementKey();

    searchKey = key.searchRequirementKey;
    searchKey.recordStatus = ProviderOfferingStatusEntry.CANCELED.getCode();

    // Iterate through the service offering training requirements and add them
    // to the return struct.
    for (TrainingRequirementSearchDetails searchDetails : trainingRequirementDAO.retrieveForProviderGroup(searchKey).dtls.items()) {
      TrainingRequirementSummaryDetails summaryDetails = getServiceOfferingTrainingRequirementsDetails(
        searchDetails);

      // Add the training requirement to the return struct if the training is an
      // active non ended training service offering.
      if (isActiveNonEndDatedTrainingServiceOfferings(summaryDetails)) {
        detailsList.details.addRef(summaryDetails);
      }
    }

    // Declare the search key for the license training requirements.
    LicenseTrainingRequirementSearchKey licenseSearchKey = new LicenseTrainingRequirementSearchKey();

    licenseSearchKey.concernRoleID = searchKey.concernRoleID;
    licenseSearchKey.licenseStatus = LicenseStatusEntry.APPROVED.getCode();

    // Get all the license training requirements.
    LicenseTrainingRequirementSearchDetailsList licenseList = licenseTrainingRequirementDAO.retrieveForProviderGroup(
      licenseSearchKey);
    // Sort the license training requirements based on the license type.
    List<LicenseTrainingRequirementSearchDetails> duplicatesList = sortTrainingRequirements(
      licenseList);

    // Remove the duplicate training requirements of different licenses with the
    // same license type.
    for (LicenseTrainingRequirementSearchDetails licenseDetails : removeDuplicateLicenses(
      duplicatesList)) {
      TrainingRequirementSummaryDetails summaryDetails = getLicenseTrainingRequirementsDetails(
        licenseDetails);

      // Add the training requirement to the return struct if the training is an
      // active non ended training service offering.
      if (isActiveNonEndDatedTrainingServiceOfferings(summaryDetails)) {
        detailsList.details.addRef(summaryDetails);
      }
    }

    return detailsList;
  }

  /**
   * Search for trainings which are listed as training requirement of any active
   * provider offerings currently held by a provider group member.
   *
   * @param key
   * Contains the provider ID.
   * @return List of trainings matching the search criterion.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingRequirementSummaryDetailsList retrieveTrainingRequirementsForProviderGroupMember(
    SearchTrainingRequirementKey key) throws AppException,
      InformationalException {

    TrainingRequirementSummaryDetailsList detailsList = new TrainingRequirementSummaryDetailsList();

    // Declare the search key for service offering training requirements.
    curam.cpm.sl.entity.struct.SearchTrainingRequirementKey searchKey = new curam.cpm.sl.entity.struct.SearchTrainingRequirementKey();

    searchKey = key.searchRequirementKey;
    searchKey.recordStatus = ProviderOfferingStatusEntry.CANCELED.getCode();

    // Iterate through the service offering training requirements and add them
    // to the return struct.
    for (TrainingRequirementSearchDetails searchDetails : trainingRequirementDAO.retrieveForProviderGroupMember(searchKey).dtls.items()) {
      TrainingRequirementSummaryDetails summaryDetails = getServiceOfferingTrainingRequirementsDetails(
        searchDetails);

      // Add the training requirement to the return struct if the training is an
      // active non ended training service offering.
      if (isActiveNonEndDatedTrainingServiceOfferings(summaryDetails)) {
        detailsList.details.addRef(summaryDetails);
      }
    }

    // Declare the search key for the license training requirements.
    LicenseTrainingRequirementSearchKey licenseSearchKey = new LicenseTrainingRequirementSearchKey();

    licenseSearchKey.concernRoleID = searchKey.concernRoleID;
    licenseSearchKey.licenseStatus = LicenseStatusEntry.APPROVED.getCode();

    // Get all the license training requirements.
    LicenseTrainingRequirementSearchDetailsList licenseList = licenseTrainingRequirementDAO.retrieveForProviderGroupMember(
      licenseSearchKey);
    // Sort the license training requirements based on the license type.
    List<LicenseTrainingRequirementSearchDetails> duplicatesList = sortTrainingRequirements(
      licenseList);

    // Remove the duplicate training requirements of different licenses with the
    // same license type.
    for (LicenseTrainingRequirementSearchDetails licenseDetails : removeDuplicateLicenses(
      duplicatesList)) {
      TrainingRequirementSummaryDetails summaryDetails = getLicenseTrainingRequirementsDetails(
        licenseDetails);

      // Add the training requirement to the return struct if the training is an
      // active non ended training service offering.
      if (isActiveNonEndDatedTrainingServiceOfferings(summaryDetails)) {
        detailsList.details.addRef(summaryDetails);
      }
    }

    return detailsList;
  }

  /**
   * Search for trainings which are listed as training requirement of any active
   * provider offerings or license types currently held by a provider member.
   *
   * @param key
   * Contains the provider ID.
   * @return List of trainings matching the search criterion.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingRequirementSummaryDetailsList retrieveTrainingRequirementsForProviderMember(
    SearchTrainingRequirementKey key) throws AppException,
      InformationalException {

    TrainingRequirementSummaryDetailsList detailsList = new TrainingRequirementSummaryDetailsList();

    // Declare the search key for service offering training requirements.
    curam.cpm.sl.entity.struct.SearchTrainingRequirementKey searchKey = new curam.cpm.sl.entity.struct.SearchTrainingRequirementKey();

    searchKey = key.searchRequirementKey;
    searchKey.recordStatus = ProviderOfferingStatusEntry.CANCELED.getCode();

    // Iterate through the service offering training requirements and add them
    // to the return struct.
    for (TrainingRequirementSearchDetails searchDetails : trainingRequirementDAO.retrieveForProviderMember(searchKey).dtls.items()) {
      TrainingRequirementSummaryDetails summaryDetails = getServiceOfferingTrainingRequirementsDetails(
        searchDetails);

      // Add the training requirement to the return struct if the training is an
      // active non ended training service offering.
      if (isActiveNonEndDatedTrainingServiceOfferings(summaryDetails)) {
        detailsList.details.addRef(summaryDetails);
      }
    }

    // Declare the search key for the license training requirements.
    LicenseTrainingRequirementSearchKey licenseSearchKey = new LicenseTrainingRequirementSearchKey();

    licenseSearchKey.concernRoleID = searchKey.concernRoleID;
    licenseSearchKey.licenseStatus = LicenseStatusEntry.APPROVED.getCode();

    // Get all the license training requirements.
    LicenseTrainingRequirementSearchDetailsList licenseList = licenseTrainingRequirementDAO.retrieveForProviderMember(
      licenseSearchKey);
    // Sort the license training requirements based on the license type.
    List<LicenseTrainingRequirementSearchDetails> duplicatesList = sortTrainingRequirements(
      licenseList);

    // Remove the duplicate training requirements of different licenses with the
    // same
    // license type.
    for (LicenseTrainingRequirementSearchDetails licenseDetails : removeDuplicateLicenses(
      duplicatesList)) {
      TrainingRequirementSummaryDetails summaryDetails = getLicenseTrainingRequirementsDetails(
        licenseDetails);

      // Add the training requirement to the return struct if the training is an
      // active non ended training service offering.
      if (isActiveNonEndDatedTrainingServiceOfferings(summaryDetails)) {
        detailsList.details.addRef(summaryDetails);
      }
    }
    return detailsList;
  }

  /**
   * Gets the search criterion entered by the user. Used the carry the search
   * criterion entered by the user to the next screen.
   *
   * @param searchKey
   * Contains the search criterion.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAINING#ERR_TRAINING_XFV_TRAINING_SEARCH_CRITERIA_EMPTY} -
   * If the search criteria is empty.
   */
  public void getSearchCriterion(SearchTrainingServiceOfferingKey searchKey) throws AppException, InformationalException {

    // Throw an exception if search criteria empty
    if (StringHelper.isEmpty(searchKey.searchKey.trainingName)
      && StringHelper.isEmpty(searchKey.searchKey.unitOfMeasure)
      && StringHelper.isEmpty(searchKey.searchKey.trainingType)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGExceptionCreator.ERR_TRAINING_XFV_TRAINING_SEARCH_CRITERIA_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }
    // Submit method used to carry the search criterion to the next screen.

  }

  /**
   * Validates that the same training has not been selected twice.
   *
   * @param tabList
   * Contains the list of training IDs selected by the user.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_ATLEAST_ONE_TRAINING_SHOULD_BE_SELECTED} -
   * If no training has been selected.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_TWO_OR_MORE_TRAINING_REQUIREMENTS_REFER_TO_SAME_TRAINING_SERVICE_OFFERING} -
   * If same training has been selected twice.
   */
  public void validateTrainingDetails(TrainingIDTabList tabList)
    throws InformationalException {

    if (tabList.trainingIDTabList.equals("")) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_ATLEAST_ONE_TRAINING_SHOULD_BE_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }

    StringList trainingIDList = StringUtil.delimitedText2StringList(
      tabList.trainingIDTabList, '\t');

    HashMap<String, Training> map = new HashMap<String, Training>();
    StringBuffer trainings = new StringBuffer();

    for (String trainingIDString : trainingIDList.items()) {

      StringList trainingsList = StringUtil.delimitedText2StringList(
        trainingIDString, '|');

      curam.training.impl.Training training = null;

      training = trainingDAO.get(Long.valueOf(trainingsList.item(0)));
      String key = CuramConst.gkEmpty + training.getID();

      // Get the trainings that has been selected more than once.
      if (map.containsKey(key)) {
        trainings.append(training.getName() + CuramConst.gkComma).append(
          CuramConst.gkSpace);
      } else {
        map.put(key, training);
      }
    }
    if (trainings.length() > 0) {
      // Throw error if a training has been selected more than once.
      trainings.delete(trainings.length() - 2, trainings.length());
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_TWO_OR_MORE_TRAINING_REQUIREMENTS_REFER_TO_SAME_TRAINING_SERVICE_OFFERING(
          trainings.toString()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    ValidationHelper.failIfErrorsExist();
  }

  /**
   * Populates the common struct for training requirements with the license
   * training requirement details.
   *
   * @param licenseDetails
   * License training requirement details.
   * @return The common struct for training requirements.
   */
  protected TrainingRequirementSummaryDetails getLicenseTrainingRequirementsDetails(
    LicenseTrainingRequirementSearchDetails licenseDetails) {
    TrainingRequirementSummaryDetails details = new TrainingRequirementSummaryDetails();

    details.licenseTrainingRequirementID = licenseDetails.trainingRequirementID;
    details.trainingID = licenseDetails.trainingID;
    details.trainingName = licenseDetails.trainingName;
    details.trainingRequirementCompletion = licenseDetails.trainingRequirementCompletion;
    details.licenseType = licenseDetails.licenseType;
    return details;
  }

  /**
   * Populates the common struct for training requirements with the service
   * offering training requirement details.
   *
   * @param serviceOfferingDetails
   * Service Offering training requirement details.
   * @return The common struct for training requirements.
   */
  protected TrainingRequirementSummaryDetails getServiceOfferingTrainingRequirementsDetails(
    TrainingRequirementSearchDetails serviceOfferingDetails) {
    TrainingRequirementSummaryDetails details = new TrainingRequirementSummaryDetails();

    details.serviceOfferingTrainingRequirementID = serviceOfferingDetails.trainingRequirementID;
    details.serviceOfferingID = serviceOfferingDetails.serviceOfferingID;
    details.trainingID = serviceOfferingDetails.trainingID;
    details.trainingName = serviceOfferingDetails.trainingName;
    details.trainingRequirementCompletion = serviceOfferingDetails.trainingRequirementCompletion;
    details.serviceName = serviceOfferingDetails.serviceName;
    return details;
  }

  /**
   * Removes the duplicate training requirements of different licenses with the
   * same license type.
   *
   * @param duplicatesList
   * List of license training requirements.
   * @return List of unique license training requirements.
   */
  protected List<LicenseTrainingRequirementSearchDetails> removeDuplicateLicenses(
    List<LicenseTrainingRequirementSearchDetails> duplicatesList) {

    List<LicenseTrainingRequirementSearchDetails> uniquieLicenseList = new ArrayList<LicenseTrainingRequirementSearchDetails>();

    HashMap<String, LicenseTrainingRequirementSearchDetails> map = new HashMap<String, LicenseTrainingRequirementSearchDetails>();

    for (LicenseTrainingRequirementSearchDetails details : duplicatesList) {
      String key = CuramConst.gkEmpty + details.trainingRequirementID;

      if (!map.containsKey(key)) {
        map.put(key, details);
        uniquieLicenseList.add(details);
      }
    }
    return uniquieLicenseList;
  }

  /**
   * Sorts the license training requirements based on the license type.
   *
   * @param licenses
   * List of license training requirements.
   * @return List of license training requirements sorted with respect to
   * license type.
   */
  protected List<LicenseTrainingRequirementSearchDetails> sortTrainingRequirements(
    LicenseTrainingRequirementSearchDetailsList licenses) {

    final List<LicenseTrainingRequirementSearchDetails> licenseList = new ArrayList<LicenseTrainingRequirementSearchDetails>();

    for (LicenseTrainingRequirementSearchDetails licenseDetails : licenses.dtls.items()) {
      curam.provider.impl.License license = licenseDAO.get(
        licenseDetails.licenseID);

      // Only licenses in in-progress, approved or suspended needs to be
      // considered.
      if (license.getLifecycleState().equals(LicenseStatusEntry.INPROGRESS)
        || license.getLifecycleState().equals(LicenseStatusEntry.APPROVED)
        || license.getLifecycleState().equals(LicenseStatusEntry.SUSPENDED)) {
        licenseList.add(licenseDetails);
      }
    }
    Collections.sort(licenseList,
      new Comparator<LicenseTrainingRequirementSearchDetails>() {
      public int compare(final LicenseTrainingRequirementSearchDetails lhs,
        LicenseTrainingRequirementSearchDetails rhs) {
        return lhs.licenseType.compareTo(rhs.licenseType);
      }
    });
    return licenseList;
  }

  /**
   * Gets the list of service offering training requirements which are non end
   * dated training service offerings.
   *
   * @param detailsList
   * List of service offering training requirements.
   * @return List of service offering training requirements which are non end
   * dated training service offering.s.
   */
  protected SearchTrainingServiceOfferingDetailsList getNonEndDatedTrainingServiceOfferigs(
    SearchTrainingServiceOfferingDetailsList detailsList) {
    SearchTrainingServiceOfferingDetailsList activeList = new SearchTrainingServiceOfferingDetailsList();

    for (TrainingServiceOfferingSearchDetails searchDetails : detailsList.SearchDetailsList.dtls.items()) {
      ServiceOffering service = serviceOfferingDAO.get(
        searchDetails.serviceOfferingID);

      // Only services that are training services and which have an end date in
      // future should be considered.
      if (service.getDateRange().endsInFuture()) {
        activeList.SearchDetailsList.dtls.addRef(searchDetails);
      }
    }
    return activeList;
  }

  /**
   * Check if the training related to training requirements are active non end
   * dated training service offerings.
   *
   * @param summaryDetails
   * Training requirement details.
   * @return If the training related to training requirement is an active non
   * end dated training service offering.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected boolean isActiveNonEndDatedTrainingServiceOfferings(
    TrainingRequirementSummaryDetails summaryDetails) throws AppException,
      InformationalException {
    TrainingKey trainingKey = new TrainingKey();

    trainingKey.trainingID = summaryDetails.trainingID;
    TrainingServiceOfferingDtls trainingServiceOffering = trainingServiceOfferingDAO.readByTraining(
      trainingKey);

    // Only services that are training services and which are active and have an
    // end date in future should be considered.
    if (trainingServiceOffering != null) {
      ServiceOffering service = serviceOfferingDAO.get(
        trainingServiceOffering.serviceOfferingID);

      if (service.getDateRange().endsInFuture()
        && service.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)) {
        return true;
      }
    }
    return false;
  }
}
