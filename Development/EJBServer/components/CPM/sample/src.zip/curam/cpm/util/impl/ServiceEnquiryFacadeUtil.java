/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.PROVIDERENQUIRYRESPONSEEntry;
import curam.cpm.facade.struct.ServiceEnquiryListDetailsList;
import curam.cpm.facade.struct.ServiceEnquiryResponseList;
import curam.cpm.facade.struct.ServiceEnquiryViewDetails;
import curam.piwrapper.user.impl.ExternalUserParticipantLink;
import curam.provider.impl.Provider;
import curam.serviceenquiry.impl.ServiceEnquiry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;


/**
 * Helper interface for the {@link ServiceEnquiry} functionality.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
@ImplementedBy(ServiceEnquiryFacadeUtilImpl.class)
public interface ServiceEnquiryFacadeUtil {

  /**
   * Returns the details of the service enquiry.
   *
   * @param serviceEnquiry
   * The service enquiry object
   * @return details of the service enquiry
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  public ServiceEnquiryViewDetails viewServiceEnquiry(
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry)
    throws AppException, InformationalException;

  /**
   * Submits a response from the provider to the service enquiry, updating the
   * status of the service enquiry to closed.
   *
   * @param versionNo
   * used for version control
   * @param serviceEnquiry
   * the service enquiry object instance
   * @param providerResponse
   * provider's response to the service enquiry
   * @param comments
   * comments on the service enquiry
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  public void submitEnquiryResponse(int versionNo,
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry,
    PROVIDERENQUIRYRESPONSEEntry providerResponse, String comments)
    throws AppException, InformationalException;

  /**
   * Submits a comment/question on the service enquiry.
   *
   * @param serviceEnquiryID
   * unique identifier of the service enquiry
   * @param comments
   * comments/question text entered by the provider
   * @param versionNo
   * used for version control
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  public void addComment(long serviceEnquiryID, String comments, int versionNo)
    throws AppException, InformationalException;

  /**
   * Lists all service enquiries for the specified provider.
   *
   * @param key
   * unique identifier of the provider concern role
   * @return list of service enquiry details
   */
  public ServiceEnquiryListDetailsList assignServiceEnquiryListDetails(
    final List<curam.serviceenquiry.impl.ServiceEnquiry> serviceEnquiries);

  /**
   * Populates the possible values which can be selected on providing a response
   * to a service enquiry.
   *
   * @param serviceEnquiry
   * the service enquiry instance to provider possible responses for
   * @return a list of the responses available to select, and the current
   * response value for the service enquiry
   */
  public ServiceEnquiryResponseList getResponseListForEnquiryResponse(
    final ServiceEnquiry serviceEnquiry) throws AppException,
      InformationalException;

  /**
   * Returns an {@link ExternalUserParticipantLink} for the provider, if they
   * have external access, otherwise a null record is returned.
   *
   * @param provider
   * object instance of the provider
   * @return an instance of the {@link ExternalUserParticipantLink} object if
   * one exists, otherwise null.
   */
  public ExternalUserParticipantLink getproviderExternalLink(
    final Provider provider);

  /**
   * Builds a link for the provider to request a password to allow them access
   * to the provider web portal.
   *
   * @return A link for the user to request a password to login to the provider
   * portal
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public String buildRequestAccessLink() throws AppException,
      InformationalException;

  /**
   * Builds a link for the provider to view the {@link ServiceEnquiry}.
   *
   * @param pageLink
   * page description link
   * @return A link for the provider to view the service enquiry
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public String buildProviderViewLink(final String pageLink)
    throws AppException, InformationalException;

  /**
   * Builds a link for the case worker to view the {@link ServiceEnquiry}.
   *
   * @param pageLink
   * page description link
   * @return A link for the provider to view the service enquiry
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public String buildCaseWorkerViewLink(final String pageLink)
    throws AppException, InformationalException;

  /**
   * Gets the request provider portal login password link for the provider. This
   * is read from the environment variables.
   *
   * @return The link to request the login password.
   */
  public String getRequestLoginLink();

  /**
   * Gets the provider portal view service enquiry link for the given service
   * enquiry. This is read from the environment variables.
   *
   * @param serviceEnquiry
   * The service enquiry object to view
   * @return The link to view the service enquiry.
   */
  public String getServiceEnquiryProviderViewLink(
    final curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry);

  /**
   * Gets the case worker view service enquiry link for the given service
   * enquiry. This is read from the environment variables.
   *
   * @param serviceEnquiry
   * The service enquiry object to view
   * @return The link to view the service enquiry.
   */
  public String getServiceEnquiryCaseWorkerViewLink(
    final curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry);

  /**
   * Builds a link to the attachment.
   *
   * @param fileName
   * the name of the attached file.
   * @param secureAccess
   * indicates if it is the secure provider portal link that is
   * required, if this is set to false, return the non-secure link.
   * @param internalAccess
   * indicates whether or not the link to build is for accessing an
   * internal Curam page.
   * @return A link to the attachment
   * @throws MalformedURLException
   * invalid URL exception.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public URL buildLinkUrl(final String fileName, final boolean secureAccess,
    final boolean internalAccess) throws AppException,
      InformationalException, MalformedURLException;

  /**
   * Returns the SSL protocol to use. If the indicator is true, return https, if
   * not return http.
   *
   * @param protocolSSLInd
   * Indicates if the protocol is SSL
   * @return The SSL protocol to use.
   */
  public String getProtocol(final boolean protocolSSLInd);

  /**
   * Reads the property to indicate if the protocol is SSL. This is read from
   * the environment variables.
   *
   * @return true if the protocol is SSL, false otherwise
   */
  public Boolean getProtocolSSLInd();

  /**
   * Returns the application root to use for provider portal access. If the
   * property is not set in the environment variables, use the default value.
   *
   * @param secureAccess
   * indicates if it is the secure provider portal application root
   * that is required, if this is set to false, return the non-secure
   * root.
   * @return The application root to use.
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  public String getProviderPortalRoot(final boolean secureAccess)
    throws AppException, InformationalException;

  /**
   * Returns the application root to use for internal application access. If the
   * property is not set in the environment variables, use the default value.
   *
   * @return The application root to use.
   */
  public String getInternalApplicationRoot();

  /**
   * Returns the application port to use. If the property is not set in the
   * environment variables, use the default value.
   *
   * @return The application port to use.
   */
  public int getPort();

  /**
   * Returns the application host to use. If the property is not set in the
   * environment variables, use the default value.
   *
   * @return The application host to use.
   */
  public String getHost();

}
