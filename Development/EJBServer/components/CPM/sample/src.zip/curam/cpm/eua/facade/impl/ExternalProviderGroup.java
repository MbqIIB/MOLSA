/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.eua.facade.impl;


import java.util.ArrayList;

import com.google.inject.Inject;

import curam.core.struct.ConcernRoleKey;
import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ProviderGroupDetails;
import curam.cpm.facade.fact.ProviderFactory;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.facade.fact.ProviderGroupFactory;
import curam.cpm.facade.intf.Provider;
import curam.cpm.facade.intf.ProviderGroup;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.facade.struct.ProviderGroupAssociateDetails;
import curam.cpm.facade.struct.ViewProviderGroupDetails;
import curam.cpm.facade.struct.ViewProviderGroupVersionDetails;
import curam.cpm.facade.struct.ViewProviderSummaryDetails;
import curam.cpm.sl.entity.struct.ProviderGroupKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.provider.ProviderGroupStatus;
import curam.provider.impl.ProviderGroupAssociate;
import curam.provider.impl.ProviderGroupAssociateDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This process class provides the functionality for Provider facade layer
 */
public abstract class ExternalProviderGroup extends curam.cpm.eua.facade.base.ExternalProviderGroup {

  /**
   * instance of provider group associate DAO
   */
  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;

  /**
   * Constructor
   */
  public ExternalProviderGroup() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * This method lists the provider groups that the provider belongs to
   *
   * @param concernRoleKey - contains the concern role ID for the provider
   * @return A list of provider groups that the provider belongs to
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ProviderGroupDetails listProviderGroupsForProvider(
    ConcernRoleKey concernRoleKey) throws AppException, InformationalException {

    // Create instance of provider group facade
    curam.cpm.facade.intf.ProviderGroup providerGroupObj = ProviderGroupFactory.newInstance();
    ProviderKey providerKey = new ProviderKey();
    ProviderGroupDetails providerGroupDetails = new ProviderGroupDetails();
    // BEGIN CR00090172, PDN
    ArrayList<ProviderGroupAssociateDetails> filteredProviderGroupAssociateDetailsList = new ArrayList<ProviderGroupAssociateDetails>();

    providerKey.providerConcernRoleID = concernRoleKey.concernRoleID;

    // call method to ensure that the user has access to view page
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    providerGroupDetails.dtls = providerGroupObj.listProviderGroupsForProvider(
      providerKey);

    // Need to filter out canceled provider groups
    for (int i = 0; i < providerGroupDetails.dtls.groupAssociateDetails.size(); i++) {
      long providerGroupAssociateID = providerGroupDetails.dtls.groupAssociateDetails.item(i).providerGroupAssociateID;

      ProviderGroupAssociate providerGroupAssociate = providerGroupAssociateDAO.get(
        providerGroupAssociateID);

      // Only include Provider Groups that are active and
      // Only include Provider Groups that the Provider is still an active member of
      if (providerGroupAssociate.getProviderGroup().getLifecycleState().toString().equals(
        ProviderGroupStatus.ACTIVE)
          && providerGroupAssociate.getLifecycleState().toString().equals(
            curam.codetable.RECORDSTATUS.NORMAL)) {
        filteredProviderGroupAssociateDetailsList.add(
          providerGroupDetails.dtls.groupAssociateDetails.item(i));
      }

    }
    providerGroupDetails.dtls.groupAssociateDetails.clear();

    for (ProviderGroupAssociateDetails providerGroupAssociateDetails : filteredProviderGroupAssociateDetailsList) {
      providerGroupDetails.dtls.groupAssociateDetails.addRef(
        providerGroupAssociateDetails);

    }

    // END CR00090172

    Provider providerObj = ProviderFactory.newInstance();

    ProviderConcernRoleKey providerConcernRoleKey = new ProviderConcernRoleKey();

    providerConcernRoleKey.providerConcernRoleID = concernRoleKey.concernRoleID;

    ViewProviderSummaryDetails viewProviderSummaryDetails = providerObj.readProviderSummaryDetails(
      providerConcernRoleKey);

    providerGroupDetails.pageContextDescription = viewProviderSummaryDetails.pageContextDescription;

    // invoke facade layer method
    return providerGroupDetails;

  }

  /**
   * This method returns the details for a provider group
   *
   * @param providerGroupKey - contains the concern role ID for the provider
   * group
   * @return This contains the details for the provider group
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ViewProviderGroupDetails viewProviderGroup(
    ProviderGroupKey providerGroupKey) throws AppException, InformationalException {

    // call method to ensure that the user has access to view page
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey.concernRoleID = providerGroupKey.providerGroupConcernRoleID;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    // Create instance of provider group facade
    curam.cpm.facade.intf.ProviderGroup providerGroupObj = ProviderGroupFactory.newInstance();

    // invoke facade layer method
    return providerGroupObj.viewProviderGroup(providerGroupKey);

  }

  // BEGIN, CR00228977, GP
  /**
   * Retrieves the provider group details.
   *
   * @param providerGroupKey
   * Provider group for which details are to be retrieved.
   *
   * @return Provider group details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewProviderGroupVersionDetails viewProviderGroupDetails(
    final ProviderGroupKey providerGroupKey) throws AppException,
      InformationalException {

    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    externalSecurityKey.concernRoleKey.concernRoleID = providerGroupKey.providerGroupConcernRoleID;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    ProviderGroup providerGroupObj = ProviderGroupFactory.newInstance();

    return providerGroupObj.viewProviderGroupDetails(providerGroupKey);
  }
  // END, CR00228977
}
