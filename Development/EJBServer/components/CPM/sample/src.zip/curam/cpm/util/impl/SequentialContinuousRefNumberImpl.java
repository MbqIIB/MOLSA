/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.util.impl;


import curam.cpm.sl.entity.struct.SequentialContinuousRefNumberDtls;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Standard implementation of {@linkplain SequentialContinuousRefNumber}.
 */
public class SequentialContinuousRefNumberImpl extends SingleTableEntityImpl<SequentialContinuousRefNumberDtls> implements
  SequentialContinuousRefNumber {

  /**
   * Constructor for the class.
   */
  protected SequentialContinuousRefNumberImpl() {// The no-arg constructor for use only by Guice.
  }

  /**
   * {@inheritDoc}
   */
  public long getNextReferenceNumber() {
    return getDtls().nextReferenceNumber;
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No implementation required.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No implementation required.
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// No implementation required.
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// No implementation required.
  }

  /**
   * {@inheritDoc}
   */
  public void setNextReferenceNumber(final long nextReferenceNumber) {
    getDtls().nextReferenceNumber = nextReferenceNumber;
  }

  /**
   * {@inheritDoc}
   */
  public void setReferenceNumberCodeName(String referenceNumberCodeName) {
    getDtls().referenceNumberCodeName = referenceNumberCodeName;
  }

}
