/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import com.google.inject.Inject;

import curam.attendance.impl.AbsencePeriod;
import curam.attendance.impl.AbsencePeriodCorrectionDAO;
import curam.attendance.impl.AbsencePeriodCorrectionHistory;
import curam.attendance.impl.AbsencePeriodCorrectionHistoryDAO;
import curam.attendance.impl.AbsencePeriodDAO;
import curam.attendance.impl.AbsencePeriodHistoryDAO;
import curam.attendance.impl.AttendanceConfigurationHelper;
import curam.attendance.impl.DailyAttendance;
import curam.attendance.impl.DailyAttendanceCorrectionHistory;
import curam.attendance.impl.DailyAttendanceCorrectionHistoryDAO;
import curam.attendance.impl.DailyAttendanceDAO;
import curam.attendance.impl.DailyAttendanceHistoryDAO;
import curam.attendance.impl.PRLICorrection;
import curam.attendance.impl.PRLICorrectionDAO;
import curam.attendance.impl.PRLICorrectionHistoryDAO;
import curam.attendance.impl.PRLIHistory;
import curam.attendance.impl.PRLIHistoryDAO;
import curam.attendance.impl.PRLISALILink;
import curam.attendance.impl.PRLISALILinkDAO;
import curam.attendance.impl.PRLITransaction;
import curam.attendance.impl.PRLITransactionDAO;
import curam.attendance.impl.ProviderRosterLineItem;
import curam.attendance.impl.ProviderRosterLineItemDAO;
import curam.attendance.impl.Roster;
import curam.attendance.impl.RosterDAO;
import curam.attendance.impl.RosterLineItemHistory;
import curam.attendance.impl.SOAttendanceConfiguration;
import curam.attendance.impl.SOAttendanceConfigurationDAO;
import curam.codetable.impl.ATTENDANCEABSENCEREASONEntry;
import curam.codetable.impl.ATTENDANCEEntry;
import curam.codetable.impl.ATTENDANCETRACKINGHOURSEntry;
import curam.codetable.impl.ATTENDANCETRACKINGMINUTESEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.fact.AddressFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.Address;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.struct.AbsencePeriodHistoryDtls;
import curam.core.sl.entity.struct.AbsencePeriodHistoryDtlsList;
import curam.core.sl.entity.struct.DailyAttendanceHistoryDtls;
import curam.core.sl.entity.struct.DailyAttendanceHistoryDtlsList;
import curam.core.sl.entity.struct.RosterKey;
import curam.core.sl.entity.struct.RosterLineItemDtls;
import curam.core.sl.entity.struct.RosterLineItemHistoryDtls;
import curam.core.struct.AddressDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.OtherAddressData;
import curam.cpm.facade.struct.AbsenceDetails;
import curam.cpm.facade.struct.AbsenceDetailsList;
import curam.cpm.facade.struct.AbsencePeriodHistoryDetails;
import curam.cpm.facade.struct.AbsencePeriodHistoryDetailsList;
import curam.cpm.facade.struct.CreateAbsenceDetails;
import curam.cpm.facade.struct.DailyAttendanceDetails;
import curam.cpm.facade.struct.DailyAttendanceDetailsList;
import curam.cpm.facade.struct.DailyAttendanceHistory;
import curam.cpm.facade.struct.DailyAttendanceHistoryDetails;
import curam.cpm.facade.struct.DailyAttendanceHistoryDetailsList;
import curam.cpm.facade.struct.DailyAttendanceHistoryList;
import curam.cpm.facade.struct.DailyAttendanceReportingWidgetDetails;
import curam.cpm.facade.struct.DailyAttendanceWidgetDetails;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.PRLIApprovalDetails;
import curam.cpm.facade.struct.PRLICancellationDetails;
import curam.cpm.facade.struct.PRLIDenialDetails;
import curam.cpm.facade.struct.PRLIHistoryDetails;
import curam.cpm.facade.struct.PRLIHistoryDetailsList;
import curam.cpm.facade.struct.PRLIHistoryWithStatusDetails;
import curam.cpm.facade.struct.PRLIHistoryWithStatusDetailsList;
import curam.cpm.facade.struct.PRLIInformationalSummaryDetails;
import curam.cpm.facade.struct.PRLISummaryDetails;
import curam.cpm.facade.struct.PRLITransactionDetails;
import curam.cpm.facade.struct.PRLITransactionDetailsList;
import curam.cpm.facade.struct.ProviderRosterLineItemDetails;
import curam.cpm.facade.struct.ReportingDailyAttendanceDetails;
import curam.cpm.facade.struct.RosterServiceReportingMethod;
import curam.cpm.facade.struct.ServiceAuthorizationLineItemDetails;
import curam.cpm.facade.struct.UnitsExceededDetails;
import curam.cpm.facade.struct.UpdateRLIDetails;
import curam.cpm.facade.struct.ViewDailyAttendanceDetails;
import curam.cpm.facade.struct.ViewDailyAttendanceReportingDetails;
import curam.cpm.facade.struct.ViewReportingDailyAttendanceDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.PRLIHistoryDtls;
import curam.cpm.sl.entity.struct.PRLIHistoryKey;
import curam.cpm.sl.entity.struct.ProviderRosterLineItemDtls;
import curam.cpm.sl.entity.struct.ProviderRosterLineItemKey;
import curam.cpm.util.impl.AttendanceWidgetHelper;
import curam.cpm.util.impl.WidgetHelper;
import curam.message.ENTDAILYATTENDANCE;
import curam.message.ROSTER;
import curam.message.impl.ENTDAILYATTENDANCEExceptionCreator;
import curam.message.impl.ROSTERExceptionCreator;
import curam.participant.impl.ConcernRoleDAO;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.impl.PRLICancelationReasonEntry;
import curam.provider.impl.PRLICorrectionStatusEntry;
import curam.provider.impl.PRLIDenialReasonEntry;
import curam.provider.impl.PRLIStatusEntry;
import curam.provider.impl.PRLITransactionTypeEntry;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderSecurity;
import curam.serviceauthorization.impl.ServiceAuthorization;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItem;
import curam.servicedelivery.impl.ServiceDelivery;
import curam.servicedelivery.impl.ServiceDeliveryDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.UnitOfMeasureEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.DateRange;
import curam.util.type.Money;


/**
 * {@inheritDoc}
 */
public abstract class MaintainRosterLineItem extends curam.cpm.facade.base.MaintainRosterLineItem {

  /**
   * providerSecurity type of ProviderSecurity
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * Provider DAO object.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * DailyAttendance DAO object.
   */
  @Inject
  protected DailyAttendanceDAO dailyAttendanceDAO;

  /**
   * AbsencePeriod reference.
   */
  @Inject
  protected AbsencePeriod absencePeriodImpl;

  /**
   * AbsencePeriod DAO reference.
   */
  @Inject
  protected AbsencePeriodDAO absencePeriodDAO;

  /**
   * Provider Roster Line Item DAO
   */
  @Inject
  protected ProviderRosterLineItemDAO providerRosterLineItemDAO;

  @Inject
  protected PRLITransactionDAO prliTransactionDAO;

  @Inject
  protected PRLIHistoryDAO prliHistoryDAO;

  /**
   * A reference to PRLISALILinkDAO.
   */
  @Inject
  protected PRLISALILinkDAO prliSALILinkDAO;

  /**
   * SOAttendanceConfiguration DAO object
   */
  @Inject
  protected SOAttendanceConfigurationDAO sOAttendanceConfigurationDAO;

  /**
   * Roster DAO object
   */
  @Inject
  protected RosterDAO rosterDAO;

  /**
   * AbsencePeriodHistory DAO reference.
   */
  @Inject
  protected AbsencePeriodHistoryDAO absencePeriodHistoryDAO;

  /**
   * DailyAttendanceHistory DAO reference.
   */
  @Inject
  protected DailyAttendanceHistoryDAO dailyAttendanceHistoryDAO;

  // BEGIN, CR00176474, AS
  // BEGIN, CR00178377, AS
  /**
   * Reference to Attendance Configuration Helper.
   */
  @Inject
  protected AttendanceConfigurationHelper attendanceConfigurationHelper;
  // END, CR00178377
  // END, CR00176474
  // BEGIN, CR00198474, ASN
  /**
   * Reference to DailyAttendance.
   */
  @Inject
  protected DailyAttendance dailyAttendance;

  /**
   * Reference to ConcernRole DAO.
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  // END, CR00198474
  
  // BEGIN, CR00208448, ASN
  /**
   * Reference to PRLI Correction DAO.
   */
  @Inject
  protected PRLICorrectionDAO prliCorrectionDAO;
  
  @Inject
  protected PRLICorrectionHistoryDAO prliCorrectionHistoryDAO;

  /**
   * Reference to Absence Period Correction DAO.
   */
  @Inject
  protected AbsencePeriodCorrectionDAO absencePeriodCorrectionDAO;
  
  /**
   * Reference to Absence Period Correction History DAO.
   */
  @Inject
  protected AbsencePeriodCorrectionHistoryDAO absencePeriodCorrectionHistoryDAO;
  
  /**
   * Reference to Daily Attendance Correction History DAO.
   */
  @Inject
  protected DailyAttendanceCorrectionHistoryDAO dailyAttendanceCorrectionHistoryDAO;
  
  // END, CR00208448
  
  // BEGIN, CR00233823, PS
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;

  // END, CR00233823
  @Inject
  protected ServiceDeliveryDAO serviceDeliveryDAO;
  
  /**
   * Default Constructor
   */
  public MaintainRosterLineItem() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public void addAbsence(CreateAbsenceDetails createAbsenceDetails)
    throws AppException, InformationalException {

    // Check appropriate security privileges.
    providerSecurity.checkProviderSecurity(
      providerDAO.get(Long.valueOf(createAbsenceDetails.providerID)));

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      createAbsenceDetails.providerRosterLineItemID);

    // If roster line item has exception task process indicator set, it cannot
    // be updated.
    if (providerRosterLineItem.getExceptionProcInd()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_ABSENCE_REASON_CANNOT_BE_ADDED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }

    addAbsenceToRLI(createAbsenceDetails, providerRosterLineItem);
  }

  // BEGIN, CR00228146, ASN
  /**
   * Modifies all the daily attendance records and the roster line item record
   * for a specified provider roster line item.
   *
   * @param dailyAttendanceWidgetDetails
   * Contains the xml data received from the Daily Attendance widget.
   *
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_ABSENT}
   * - If attendance is absent, units attended must not be entered.
   * @throws InformationalException
   * {@link ENTDAILYATTENDANCE#ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_ABSENT_OR_PARTIALLY_PRESENT}
   * - If attendance is partially present or absent but absence reason
   * is not entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT}
   * - If attendance is present , units not attended must not be
   * entered.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_PRESENT_OR_PARTIALLY_PRESENT}
   * - If attendance is present or partially present, units attended
   * must be entered.
   * @throws InformationalException
   * {@link ENTDAILYATTENDANCE#ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT}
   * - If attendance is present and absence reason is entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ABSENT_OR_PARTIALLY_PRESENT}
   * - If attendance is partially present or absent and units not
   * attended is not greater than zero.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_ATTENDANCE_CANNOT_BE_MODIFIED}
   * If the daily attendance is added when the exception task is
   * created.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED}
   * - If other details are specified, the Attendance must be entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED}
   * - If user tries to save all blank daily attendance records.
   */
  // END, CR00228146
  public void addDailyAttendance(
    DailyAttendanceWidgetDetails dailyAttendanceWidgetDetails)
    throws AppException, InformationalException {

    // check appropriate security privileges
    providerSecurity.checkProviderSecurity(
      providerDAO.get(Long.valueOf(dailyAttendanceWidgetDetails.providerID)));

    // Modify the actual units attribute in roster line item record.
    curam.attendance.impl.ProviderRosterLineItem providerRosterLineItemImpl = providerRosterLineItemDAO.get(
      dailyAttendanceWidgetDetails.providerRosterLineItemID);

    // If roster line item has exception task process indicator set, it cannot
    // be updated.
    if (providerRosterLineItemImpl.getExceptionProcInd()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_ATTENDANCE_CANNOT_BE_MODIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
      ValidationHelper.failIfErrorsExist();
    }
    
    addDailyAttendanceForRLI(dailyAttendanceWidgetDetails,
      providerRosterLineItemImpl);
  }

  /**
   * {@inheritDoc}
   */
  public void approveRosterLineItem(PRLIApprovalDetails details)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      details.providerRosterLineItemID);

    // Roster line item can be approved only if it's in PENDINGAPPROVAL status.
    if (!providerRosterLineItem.getLifecycleState().getCode().equals(
      PRLIStatusEntry.PENDINGAPPROVAL.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_NOT_IN_PENDING_APPROVAL_STATUS_CANNOT_BE_APPROVED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      ValidationHelper.failIfErrorsExist();
    }
    // Approve the provider roster line item using specified version.
    providerRosterLineItem.approve(details.prliVersionNo, details.rliVersionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void denyRosterLineItem(PRLIDenialDetails details)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      details.key.providerRosterLineItemID);

    if (providerRosterLineItem.isInExceptionProcessing() == true) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_CANNOT_CANCEL(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
    }
    ValidationHelper.failIfErrorsExist();

    // Deny the provider roster line item using specified version.
    providerRosterLineItem.deny(details.prliVersionNo, details.rliVersionNo,
      PRLIDenialReasonEntry.get(details.denialReason));

  }

  /**
   * {@inheritDoc}
   */
  public AbsenceDetailsList listAbsences(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {

    AbsenceDetailsList absenceDetailsList = new AbsenceDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    Set<curam.attendance.impl.AbsencePeriod> absencePeriodList = absencePeriodDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());

    // Populate the absencePeriod details to the list.
    for (curam.attendance.impl.AbsencePeriod absencePeriod : sortAbsenceByServiceDate(
      absencePeriodList)) {

      if (RECORDSTATUSEntry.NORMAL.equals(absencePeriod.getStatus())) {
        AbsenceDetails absenceDetails = new AbsenceDetails();

        absenceDetails.dtls.absenceReason = absencePeriod.getAbsenceReason().getCode();
        absenceDetails.dtls.unitsUnattended = absencePeriod.getUnitsUnattended();
        absenceDetails.dtls.absenceDate = absencePeriod.getAbsenceDate();
        absenceDetails.dtls.absencePeriodID = absencePeriod.getDtls().absencePeriodID;
        // BEGIN, CR00144116,  KG
        absenceDetails.dtls.rosterLineItemID = absencePeriod.getDtls().rosterLineItemID;
        // END, CR001441163
        absenceDetails.dtls.versionNo = absencePeriod.getDtls().versionNo;

        absenceDetailsList.details.addRef(absenceDetails);
      }
    }

    absenceDetailsList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    return absenceDetailsList;
  }
  
  // BEGIN, CR00208448, ASN
  /**
   * Lists the provider roster line item status history.
   *
   * @param key
   * Contains provider roster line item ID.
   * @return List of all provider roster line item history.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link MaintainRosterLineItem#listHistoryForPRLI(ProviderRosterLineItemKey)}
   * . As part of the PRLI History merge changes, a new indicator
   * need to be added to indicate a correction is denied as a part
   * of list provider roster line item history page. See release
   * note: CR00208448.
   */
  @Deprecated
  public PRLIHistoryDetailsList listHistoryForRosterLineItem(
    ProviderRosterLineItemKey key) throws AppException,
      InformationalException {

    PRLIHistoryDetailsList prliHistoryDetailsList = new PRLIHistoryDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);
    List<PRLIHistory> historyDetailsList = prliHistoryDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);

    // Populating the provider roster line item history details
    for (PRLIHistory prliHistory : historyDetailsList) {

      RosterLineItemHistory rosterLineItemHistory = prliHistory.getRosterLineItemHistory();

      prliHistoryDetailsList.prliDetails.addRef(
        getPRLIAndRLIHistoryDetails(prliHistory, rosterLineItemHistory));
    }
    prliHistoryDetailsList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    return prliHistoryDetailsList;
  }

  // END, CR00208448
  
  // BEGIN, CR00176474, AS
  // BEGIN, CR00228146, ASN
  /**
   * Modifies all the daily attendance records and the roster line item record
   * for a specified provider roster line item.
   *
   * @param dailyAttendanceWidgetDetails
   * Contains the xml data received from the Daily Attendance widget.
   *
   * @throws InformationalException
   * @throws InformationalException
   * {@link ENTDAILYATTENDANCE#ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_ABSENT_OR_PARTIALLY_PRESENT}
   * - If attendance is partially present or absent but absence reason
   * is not entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED()}
   * -If user tries to save all blank record.
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_HOURS_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_PRESENT}
   * - If attendance is present but hours attended is not entered.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_HOURS_NOT_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_ABSENT}
   * - If attendance is absent but hours not attended is not entered.
   * @throws InformationalException
   * {@link ENTDAILYATTENDANCE#ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT}
   * - If attendance is present and absence reason is entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_DAILY_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED}
   * -If attendance not entered but other details are entered for
   * records of type Attendance with Hours Enabled indicator set as
   * true.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_ATTENDANCE_CANNOT_BE_MODIFIED}
   * If the daily attendance is added when the exception task is
   * created.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_HOURS_ATTENDED_NOT_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_PARTIALLY_PRESENT}
   * - If attendance is partially present but hours attended and hours
   * not attended are not entered.
   */
  // END, CR00228146
  public void addDailyAttendanceForReporting(
    DailyAttendanceReportingWidgetDetails dailyAttendanceWidgetDetails) throws AppException,
      InformationalException {
    
    // Check appropriate security privileges.
    providerSecurity.checkProviderSecurity(
      providerDAO.get(Long.valueOf(dailyAttendanceWidgetDetails.providerID)));

    // Modify the actual units attribute in roster line item record.
    curam.attendance.impl.ProviderRosterLineItem providerRosterLineItemImpl = providerRosterLineItemDAO.get(
      dailyAttendanceWidgetDetails.providerRosterLineItemID);

    providerRosterLineItemImpl.setRLIVersionNo(
      dailyAttendanceWidgetDetails.rliVersionNo);
    
    DailyAttendanceDetailsList dailyAttendanceDetailsList = null;
    
    // The xml containing data of daily attendance details list which is
    // received from the Daily Attendance widget is parsed and the xml data is
    // populated to a list of daily attendance details.
    if (dailyAttendanceWidgetDetails.hoursEnabled) {
      dailyAttendanceDetailsList = AttendanceWidgetHelper.convertXmlToAttendanceDetailsList(
        dailyAttendanceWidgetDetails.dailyAttendanceHoursDetails,
        dailyAttendanceWidgetDetails.hoursEnabled);
    } else {
      dailyAttendanceDetailsList = AttendanceWidgetHelper.convertXmlToAttendanceDetailsList(
        dailyAttendanceWidgetDetails.dailyAttendanceDetails,
        dailyAttendanceWidgetDetails.hoursEnabled);
    }

    addDailyAttendanceDetailsForRLI(dailyAttendanceDetailsList,
      providerRosterLineItemImpl, dailyAttendanceWidgetDetails.hoursEnabled);
  }

  /**
   * Retrieves the Daily Attendance details for a specified provider roster line
   * item key.
   *
   * @param providerRosterLineItemKey
   * Key containing the provider roster line item ID.
   * @return List of Daily Attendance details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewDailyAttendanceReportingDetails viewDailyAttendanceForReporting(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {

    ViewDailyAttendanceReportingDetails viewDailyAttendanceDetails = new ViewDailyAttendanceReportingDetails();
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    // Populate the details of the roster line item.
    viewDailyAttendanceDetails.fromDate = providerRosterLineItem.getServiceDateFrom();
    viewDailyAttendanceDetails.toDate = providerRosterLineItem.getServiceDateTo();
    if (providerRosterLineItem.getClient() != null) {
      viewDailyAttendanceDetails.clientName = providerRosterLineItem.getClient().getName();
    }

    // BEGIN, CR00198474, ASN
    SOAttendanceConfiguration soAttendanceConfig = sOAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      providerRosterLineItem.getRoster().getServiceOffering(),
      providerRosterLineItem.getRoster().getDateGenerated());
    
    if (null != soAttendanceConfig
      && soAttendanceConfig.isDailyAttendanceTrackingRequired()) {
      // Generate daily attendance dynamically using data using either the daily
      // attendance date input at facade level or from daily attendance entity
      // if records exist.
      dailyAttendanceDetailsList = generateDailyAttendance(
        providerRosterLineItem);
    }
    viewDailyAttendanceDetails.viewDetailsList.assign(
      dailyAttendanceDetailsList);
    
    // END, CR00198474

    // Setting the indicator for displaying daily Attendance details.
    viewDailyAttendanceDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);
    
    RosterKey rosterKey = new RosterKey();

    rosterKey.rosterID = providerRosterLineItem.getRoster().getID();

    // Convert the list of daily attendance details to an xml. This xml is the
    // input to the widget to display the list of daily attendance details.
    // BEGIN, CR00178377, AS
    if (attendanceConfigurationHelper.isHoursEnabledForAttendanceReporting(
      rosterKey)) {
      // END, CR00178377
      viewDailyAttendanceDetails.hoursEnabled = true;
      viewDailyAttendanceDetails.dailyAttendanceHoursDetails = AttendanceWidgetHelper.convertDailyAttendanceToXml(
        dailyAttendanceDetailsList, viewDailyAttendanceDetails.hoursEnabled);
    } else {
      viewDailyAttendanceDetails.hoursEnabled = false;
      viewDailyAttendanceDetails.dailyAttendanceDetails = AttendanceWidgetHelper.convertDailyAttendanceToXml(
        dailyAttendanceDetailsList, viewDailyAttendanceDetails.hoursEnabled);
    }
    viewDailyAttendanceDetails.rliVersionNo = providerRosterLineItem.getRLIVersionNo();

    return viewDailyAttendanceDetails;
  }

  // END, CR00176474

  /**
   * Retrieves the roster line item modification details.
   *
   * @param prliHistoryKey
   * Contains provider roster line item history ID.
   * @return The provider roster line item history details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public PRLIHistoryDetails viewRosterLineItemModification(
    PRLIHistoryKey prliHistoryKey) throws AppException,
      InformationalException {

    PRLIHistory prliHistory = prliHistoryDAO.get(prliHistoryKey.prliHistoryID);
    PRLIHistoryDetails prliHistoryDetails = new PRLIHistoryDetails();

    RosterLineItemHistory rosterLineItemHistory = prliHistory.getRosterLineItemHistory();

    prliHistoryDetails.prliDtls = getPRLIHistoryDetails(prliHistory);
    prliHistoryDetails.rliDtls = getRLIHistoryDetails(rosterLineItemHistory);

    if (prliHistoryDetails.prliDtls.addressID != 0) {

      Address addressObj = AddressFactory.newInstance();

      OtherAddressData formattedAddressData = new OtherAddressData();

      formattedAddressData.addressData = prliHistory.getProviderRosterLineItem().getAddressData();

      addressObj.getAddressStrings(formattedAddressData);
      prliHistoryDetails.addressData = formattedAddressData.addressData;

    }

    return prliHistoryDetails;
  }

  // BEGIN, CR00176474, AS
  // BEGIN, CR00208448, ASN
  /**
   * Checks if the reporting method on the service offering attendance
   * configuration is set to Attendance.
   *
   * @param providerRosterLineItemKey
   * Provider roster line item key for which details need to be retrieved.
   *
   * @return The attendance reporting configuration details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00208448
  public RosterServiceReportingMethod isReportingMethodAttendance(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    RosterServiceReportingMethod reportingMethod = new RosterServiceReportingMethod();
    
    // BEGIN, CR00178377, AS
    reportingMethod.attendanceReportingIndicator = attendanceConfigurationHelper.isReportingMethodAttendance(
      providerRosterLineItem.getRoster());
    // END, CR00178377
    
    // BEGIN, CR00198730, ASN
    RosterKey rosterKey = new RosterKey();

    rosterKey.rosterID = providerRosterLineItem.getRoster().getID();
    reportingMethod.hoursEnabledIndicator = attendanceConfigurationHelper.isHoursEnabledForAttendanceReporting(
      rosterKey);

    if (!reportingMethod.attendanceReportingIndicator
      && !reportingMethod.hoursEnabledIndicator) {

      reportingMethod.attendanceHoursEnabledIndicator = true;
    }
    if (reportingMethod.attendanceReportingIndicator
      && reportingMethod.hoursEnabledIndicator) {

      reportingMethod.attendanceHoursEnabledIndicator = true;

    }
    // END, CR00198730
    return reportingMethod;
  }

  // END, CR00176474

  // BEGIN, CR00208448, ASN
  /**
   * Populates the provider roster line item history struct details from the
   * provider roster line item history and roster line item entity object.
   *
   * @param prliHistory
   * Provider roster line item history interface.
   * @param rosterLineItemHistory
   * Roster line item history interface.
   * @return Provider roster line item history detail.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link MaintainRosterLineItem#getProviderRosterLineitemHistoryDetails(PRLIHistory, RosterLineItemHistory)}
   * . As part of the PRLI History merge changes, a new indicator
   * need to be added to indicate a correction is denied while
   * retrieving provider roster line item history and provider
   * roster line item correction history records. See release note:
   * CR00208448.
   */
  protected PRLIHistoryDetails getPRLIAndRLIHistoryDetails(
    PRLIHistory prliHistory, RosterLineItemHistory rosterLineItemHistory) {

    PRLIHistoryDetails prliHistoryDetails = new PRLIHistoryDetails();

    prliHistoryDetails.prliDtls.prliHistoryID = prliHistory.getID();
    prliHistoryDetails.prliDtls.status = prliHistory.getLifecycleState().getCode();
    prliHistoryDetails.prliDtls.cancelationReason = prliHistory.getCancellationReason().getCode();
    prliHistoryDetails.prliDtls.denialReason = prliHistory.getDenialReason().getCode();

    prliHistoryDetails.rliDtls.dateTimeChanged = rosterLineItemHistory.getDateTimeChanged();
    prliHistoryDetails.rliDtls.totalUnitsDelivered = rosterLineItemHistory.getUnitsDelivered();
    
    return prliHistoryDetails;
  }

  /**
   * Populates the provider roster line item history  details from the
   * provider roster line item history and roster line item entity object.
   *
   * @param prliHistory
   * Provider roster line item history interface.
   * @param rosterLineItemHistory
   * Roster line item history interface.
   *
   * @return Provider roster line item history details with status indicator.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected PRLIHistoryWithStatusDetails getProviderRosterLineitemHistoryDetails(
    final PRLIHistory prliHistory, final RosterLineItemHistory rosterLineItemHistory) throws AppException, InformationalException {

    PRLIHistoryWithStatusDetails prliHistoryWithStatusDetails = new PRLIHistoryWithStatusDetails();
    
    prliHistoryWithStatusDetails.prliHistoryDetails.prliHistoryID = prliHistory.getID();
    prliHistoryWithStatusDetails.prliHistoryDetails.status = prliHistory.getLifecycleState().getCode();
    prliHistoryWithStatusDetails.prliHistoryDetails.cancelationReason = prliHistory.getCancellationReason().getCode();
    prliHistoryWithStatusDetails.prliHistoryDetails.denialReason = prliHistory.getDenialReason().getCode();

    // BEGIN, CR00273450, ASN
    prliHistoryWithStatusDetails.prliHistoryDetails.correctionReason = prliHistory.getCorrectionReason();
    // END, CR00273450
    prliHistoryWithStatusDetails.rliHistory.dateTimeChanged = rosterLineItemHistory.getDateTimeChanged();
    prliHistoryWithStatusDetails.rliHistory.totalUnitsDelivered = rosterLineItemHistory.getUnitsDelivered();
    prliHistoryWithStatusDetails.prliHistoryDetails.prliCorrectionID = prliHistory.getPRLICorrection().getID();
    
    return prliHistoryWithStatusDetails;
  }

  // END, CR00208448
  
  /**
   * Populates the provider roster line item history struct details from the
   * provider roster line item history entity object.
   *
   * @param prliHistory
   * Provider roster line item history interface.
   * @return Provider roster line item history detail.
   */
  protected PRLIHistoryDtls getPRLIHistoryDetails(PRLIHistory prliHistory) {

    PRLIHistoryDtls prliHistoryDetails = new PRLIHistoryDtls();

    prliHistoryDetails.prliHistoryID = prliHistory.getID();
    prliHistoryDetails.voucherNumber = prliHistory.getVoucherNumber();
    prliHistoryDetails.clientReferenceNo = prliHistory.getClientReferenceNo();
    prliHistoryDetails.clientFirstName = prliHistory.getClientFirstName();
    prliHistoryDetails.clientLastName = prliHistory.getClientLastName();
    prliHistoryDetails.clientDOB = prliHistory.getClientDOB();
    prliHistoryDetails.saReferenceNo = prliHistory.getSAReferenceNo();
    prliHistoryDetails.status = prliHistory.getLifecycleState().getCode();
    prliHistoryDetails.cancelationReason = prliHistory.getCancellationReason().getCode();
    prliHistoryDetails.denialReason = prliHistory.getDenialReason().getCode();
    // BEGIN, CR00273745, ASN
    prliHistoryDetails.caseReferenceNo = prliHistory.getCaseReferenceNumber();
    // END, CR00273745
    prliHistoryDetails.addressID = prliHistory.getProviderRosterLineItem().getAddressID();

    return prliHistoryDetails;
  }

  /**
   * Populates the provider roster line item history struct details from the
   * roster line item history entity object.
   *
   * @param rosterLineItemHistory
   * Roster line item history interface.
   * @return Roster line item history detail.
   */
  protected RosterLineItemHistoryDtls getRLIHistoryDetails(
    RosterLineItemHistory rosterLineItemHistory) {

    RosterLineItemHistoryDtls rosterLineItemHistoryDetails = new RosterLineItemHistoryDtls();

    rosterLineItemHistoryDetails.referenceNo = rosterLineItemHistory.getReferenceNumber();
    rosterLineItemHistoryDetails.dateTimeChanged = rosterLineItemHistory.getDateTimeChanged();
    rosterLineItemHistoryDetails.totalUnitsDelivered = rosterLineItemHistory.getUnitsDelivered();
    rosterLineItemHistoryDetails.expectedUnits = rosterLineItemHistory.getExpectedUnits();
    rosterLineItemHistoryDetails.totalUnitsDelivered = rosterLineItemHistory.getUnitsDelivered();
    rosterLineItemHistoryDetails.serviceFrom = rosterLineItemHistory.getRosterLineItemHistory().getServiceDateFrom();
    rosterLineItemHistoryDetails.serviceTo = rosterLineItemHistory.getRosterLineItemHistory().getServiceDateTo();

    return rosterLineItemHistoryDetails;
  }

  /**
   * {@inheritDoc}
   */
  public PRLITransactionDetailsList listTransactionsForRosterLineItem(
    ProviderRosterLineItemKey key) throws AppException,
      InformationalException {

    PRLITransactionDetailsList prliTransactionDetailsList = new PRLITransactionDetailsList();

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRole concernRole = ConcernRoleFactory.newInstance();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);

    List<PRLITransaction> transactionDetailsList = prliTransactionDAO.listTransactionsForRosterLineItem(
      providerRosterLineItem);

    // BEGIN, CR00133496, ABS
    HashMap<PRLITransactionDetails, Money> hashMap = new HashMap<PRLITransactionDetails, Money>();

    // Loop through the transaction details.
    for (PRLITransaction prliTransaction : transactionDetailsList) {

      PRLITransactionDetails prliTransactionDetails = new PRLITransactionDetails();

      prliTransactionDetails.dtls.creationDateTime = prliTransaction.getCreationDateTime();

      prliTransactionDetails.dtls.transactionType = prliTransaction.getTransactionType().getCode();

      prliTransactionDetails.dtls.payeeID = prliTransaction.getPayeeID();

      Iterator<PRLITransactionDetails> iterator = hashMap.keySet().iterator();

      PRLITransactionDetails matchedTransactionDetails = null;

      // Check if there is already a transaction exist in the hash map with the
      // same creation date time and payee ID.
      while (iterator.hasNext()) {

        PRLITransactionDetails transactionDetails = iterator.next();

        if (transactionDetails.dtls.creationDateTime.equals(
          prliTransaction.getCreationDateTime())
            && transactionDetails.dtls.payeeID == prliTransaction.getPayeeID()) {

          matchedTransactionDetails = transactionDetails;

          break;
        }
      }

      // If no match is found then add the row else add the amount to the existing transaction.
      if (matchedTransactionDetails == null) {

        hashMap.put(prliTransactionDetails, prliTransaction.getAmount());
      } else {

        Money newAmount = new Money(
          hashMap.get(matchedTransactionDetails).getValue()
            + prliTransaction.getAmount().getValue());

        hashMap.put(matchedTransactionDetails, newAmount);
      }
    }

    Set<PRLITransactionDetails> keySet = hashMap.keySet();

    List<PRLITransactionDetails> transactionList = new ArrayList<PRLITransactionDetails>();

    for (PRLITransactionDetails transactionDetails : keySet) {

      Money totalAmount = hashMap.get(transactionDetails);

      PRLITransactionDetails details = new PRLITransactionDetails();

      details.dtls.creationDateTime = transactionDetails.dtls.creationDateTime;

      details.dtls.transactionType = transactionDetails.dtls.transactionType;

      details.dtls.amount = totalAmount;

      if (!PRLITransactionTypeEntry.DENIED.equals(
        PRLITransactionTypeEntry.get(transactionDetails.dtls.transactionType))
          && !PRLITransactionTypeEntry.CANCELED.equals(
            PRLITransactionTypeEntry.get(
              transactionDetails.dtls.transactionType))) {
        // END, CR00129464
        concernRoleKey.concernRoleID = transactionDetails.dtls.payeeID;
        ConcernRoleDtls concernRoleDtls = concernRole.read(concernRoleKey);

        details.payeeName = concernRoleDtls.concernRoleName;
      }
      transactionList.add(details);
    }

    List<PRLITransactionDetails> list = sortByCreationDate(transactionList);

    for (PRLITransactionDetails details : list) {

      prliTransactionDetailsList.details.addRef(details);
    }
    // END, CR00133496

    prliTransactionDetailsList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);
    return prliTransactionDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public InformationalMsgDtlsList submitRosterLineItem(KeyVersionDetails key)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.id);

    providerRosterLineItem.submit(key.version);

    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();
    String[] finalResults = TransactionInfo.getInformationalManager().obtainInformationalAsString();

    // iterate through the result from informational manager
    for (int i = 0; i < finalResults.length; i++) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = finalResults[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }

    return informationalMsgDtlsList;
  }

  /**
   * This method is called in the flow to modify roster line item before
   * actually updating the entered data in the database. Following are the
   * possibilities :
   *
   * 1. If the roster line item is generated by system, client information
   * screen is not shown. Data entered by the user are validated and update
   * method is called.
   *
   * 2. If the roster line item is not generated by the user and if change in
   * service from or service to date has resulted in deletion of some rows in
   * the add daily attendance roster, a confirmation for the same is asked from
   * the user. Once the user confirms, client information page is shown. The
   * update method is called to update the new values.
   *
   * 3. If the roster line item is not generated by the user and if change in
   * service from or service to date has not resulted in any deletion of rows in
   * the add daily attendance roster, client information page is directly shown
   * to the user without the confirmation page. The update method is called to
   * update the new values.
   *
   *
   * @param details
   * Contains the details required to modify the roster line item.
   *
   * @return UpdateRLIDetails to hold the indicator whether update would result
   * in deletion of rows from add daily attendance roster.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link Roster#ERR_ROSTER_LINE_ITEM_XFV_CANNOT_BE_MODIFIED} If
   * roster line item is not in open status, it cannot be updated.
   * {@link Roster#ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_MUST_BE_GT_ZERO}
   * If total units are modified, must be greater than zero.
   * {@link Roster#ERR_ROSTERLINE_ITEM_XRV_SERVICE_FROM_DATE_MUST_BE_ON_OR_AFTER_FROM_DATE_OF_ROSTER}
   * Service from date must be on or after from date of roster.
   * {@link Roster#ERR_ROSTERLINE_ITEM_XRV_SERVICE_TO_DATE_MUST_BE_EARLIER_THAN_OR_EQUAL_TO_ROSTER_TO_DATE}
   * Service to date must be on or after to date of roster.
   * {@link Roster#ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_IS_INVALID}
   * Units delivered should always be numbers.
   */

  public UpdateRLIDetails preUpdateRosterLineItem(
    ProviderRosterLineItemDetails details) throws AppException,
      InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      details.providerRosterLineItemDtls.providerRosterLineItemID);
    
    // BEGIN, CR00248452, SG
    providerRosterLineItem.setExceptionProcessingInd(false);
    // END, CR00248452

    RosterLineItemDtls originalRosterLineItemDtls = providerRosterLineItem.getOriginalDtls();

    DateRange oldDateRange = new DateRange(
      originalRosterLineItemDtls.serviceFrom,
      originalRosterLineItemDtls.serviceTo);
    DateRange newDateRange = new DateRange(
      details.rosterLineItemDtls.serviceFrom,
      details.rosterLineItemDtls.serviceTo);

    Roster roster = rosterDAO.get(originalRosterLineItemDtls.rosterID);

    // If roster line item has service from date after service to date.
    if (details.rosterLineItemDtls.serviceFrom.after(
      details.rosterLineItemDtls.serviceTo)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_FROM_DATE_LATER_THAN_TO_DATE(
          details.rosterLineItemDtls.serviceFrom,
          details.rosterLineItemDtls.serviceTo),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    // If roster line item is not in open status, it cannot be updated.
    if (!providerRosterLineItem.getLifecycleState().getCode().equals(
      PRLIStatusEntry.OPEN.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_CANNOT_BE_MODIFIED(
          providerRosterLineItem.getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    // Actual Units cannot be anything other than numbers.
    // BEGIN, CR00132041, SG
    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        providerRosterLineItem.getRoster())) {
      // END, CR00178377
      if (details.unitsDeliveredString.trim().length() > 0) {
        try {
          details.rosterLineItemDtls.totalUnitsDelivered = Short.parseShort(
            details.unitsDeliveredString);
        } catch (NumberFormatException ne) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_IS_INVALID(
              details.unitsDeliveredString),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              4);
          ValidationHelper.failIfErrorsExist();
        }
      }
      // END, CR00132041

      // If actual units are changed, it must be greater than zero.
      if (!providerRosterLineItem.getUnitsDelivered().equals(
        details.rosterLineItemDtls.totalUnitsDelivered)
          && details.rosterLineItemDtls.totalUnitsDelivered <= 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_MUST_BE_GT_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 5);
      }
    }
    // END, CR00176474

    if (!details.providerRosterLineItemDtls.autoGeneratedInd) {

      if (details.rosterLineItemDtls.serviceFrom.isZero()
        || (roster.getDateRange().startsAfter(
          details.rosterLineItemDtls.serviceFrom))) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTERLINE_ITEM_XRV_SERVICE_FROM_DATE_MUST_BE_ON_OR_AFTER_FROM_DATE_OF_ROSTER(
            details.rosterLineItemDtls.serviceFrom,
            roster.getDateRange().start()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            1);
      }

      if (details.rosterLineItemDtls.serviceTo.isZero()
        || (roster.getDateRange().endsBefore(
          details.rosterLineItemDtls.serviceTo))) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTERLINE_ITEM_XRV_SERVICE_TO_DATE_MUST_BE_EARLIER_THAN_OR_EQUAL_TO_ROSTER_TO_DATE(
            details.rosterLineItemDtls.serviceTo, roster.getDateRange().end()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            2);
      }
    }

    ValidationHelper.failIfErrorsExist();

    UpdateRLIDetails updateRLIDetails = new UpdateRLIDetails();

    if (details.providerRosterLineItemDtls.autoGeneratedInd) {
      updateRosterLineItem(details);
    }

    // If delete rows indicator in the input struct is set to true,
    // that means the check is already done.

    if (!details.deleteRowsInd
      && !details.providerRosterLineItemDtls.autoGeneratedInd) {
 
      if (newDateRange.endsBefore(oldDateRange.end())
        || newDateRange.startsAfter(oldDateRange.start())) {
        // Only if the daily attendance is configured, delete rows page
        // should be shown.
        if (isDailyAttendanceConfigured(providerRosterLineItem)) {
          updateRLIDetails.deleteRowsInd = true;
          // BEGIN, CR00278784, GP
        } else {          
          updateRosterLineItem(details);
          // END, CR00278784
        }
        
      } else {
        updateRLIDetails.deleteRowsInd = false;
        // BEGIN, CR00246679, ASN
        updateRosterLineItem(details);
        // END, CR00246679
      }
    }
    return updateRLIDetails;
  }

  /**
   * {@inheritDoc}
   */
  public void updateRosterLineItem(ProviderRosterLineItemDetails details)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      details.providerRosterLineItemDtls.providerRosterLineItemID);

    // Actual Units cannot be anything other than numbers.
    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        providerRosterLineItem.getRoster())) {
      // END, CR00178377

      try {
        details.rosterLineItemDtls.totalUnitsDelivered = Short.parseShort(
          details.unitsDeliveredString);
      } catch (NumberFormatException ne) {// This validation is already done in preUpdateRosterLineItem.
      }

      providerRosterLineItem.setUnitsDelivered(
        details.rosterLineItemDtls.totalUnitsDelivered);
    }
    // END, CR00176474
    
    providerRosterLineItem.setRLIVersionNo(details.rosterLineItemDtls.versionNo);
    providerRosterLineItem.setVoucherNumber(
      details.providerRosterLineItemDtls.voucherNumber);
    providerRosterLineItem.setVersionNo(
      details.providerRosterLineItemDtls.versionNo);

    // Client information, service from and to dates, service authorization
    // reference number can be changed only if
    // they are added by provider (not generated by system).
    if (!details.providerRosterLineItemDtls.autoGeneratedInd) {
      providerRosterLineItem.setCaseReferenceNo(
        details.providerRosterLineItemDtls.caseReferenceNo);
      providerRosterLineItem.setSAReferenceNo(
        details.providerRosterLineItemDtls.saReferenceNo);
      providerRosterLineItem.setServiceDateFrom(
        details.rosterLineItemDtls.serviceFrom);
      providerRosterLineItem.setServiceDateTo(
        details.rosterLineItemDtls.serviceTo);
      providerRosterLineItem.setClientReferenceNo(
        details.providerRosterLineItemDtls.clientReferenceNo);
      providerRosterLineItem.setClientDOB(
        details.providerRosterLineItemDtls.clientDOB);
      providerRosterLineItem.setClientFirstName(
        details.providerRosterLineItemDtls.clientFirstName);
      providerRosterLineItem.setClientLastName(
        details.providerRosterLineItemDtls.clientLastName);

      AddressDtls addressDtls = new AddressDtls();

      addressDtls.addressID = details.providerRosterLineItemDtls.addressID;
      addressDtls.addressData = details.addressData;
      providerRosterLineItem.setAddress(addressDtls);
    }

    providerRosterLineItem.modifyRosterLineItem();
  }

  /**
   * This method is called in the flow to modify roster line item from exception
   * task before actually updating the entered data in the database. Following
   * are the possibilities :
   *
   * 1. If the roster line item is generated by system, client information
   * screen is not shown. Data entered by the user are validated and update
   * method is called.
   *
   * 2. If the roster line item is not generated by the user and if change in
   * service from or service to date has resulted in deletion of some rows in
   * the add daily attendance roster, a confirmation for the same is asked from
   * the user. Once the user confirms, client information page is shown. The
   * update method is called to update the new values.
   *
   * 3. If the roster line item is not generated by the user and if change in
   * service from or service to date has not resulted in any deletion of rows in
   * the add daily attendance roster, client information page is directly shown
   * to the user without the confirmation page. The update method is called to
   * update the new values.
   *
   *
   * @param details
   * Contains the details required to modify the roster line item.
   *
   * @return UpdateRLIDetails to hold the indicator whether update would result
   * in deletion of rows from add daily attendance roster.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link Roster#ERR_ROSTER_LINE_ITEM_XFV_CANNOT_BE_MODIFIED} If
   * roster line item is not in open status, it cannot be updated.
   * {@link Roster#ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_MUST_BE_GT_ZERO}
   * If total units are modified, must be greater than zero.
   * {@link Roster#ERR_ROSTERLINE_ITEM_XRV_SERVICE_FROM_DATE_MUST_BE_ON_OR_AFTER_FROM_DATE_OF_ROSTER}
   * Service from date must be on or after from date of roster.
   * {@link Roster#ERR_ROSTERLINE_ITEM_XRV_SERVICE_TO_DATE_MUST_BE_EARLIER_THAN_OR_EQUAL_TO_ROSTER_TO_DATE}
   * Service to date must be on or after to date of roster.
   * {@link Roster#ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_IS_INVALID}
   * Units delivered should always be numbers.
   */

  public UpdateRLIDetails preUpdateRosterLineItemFromExceptionTask(
    ProviderRosterLineItemDetails details) throws AppException,
      InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      details.providerRosterLineItemDtls.providerRosterLineItemID);

    RosterLineItemDtls originalRosterLineItemDtls = providerRosterLineItem.getOriginalDtls();

    DateRange oldDateRange = new DateRange(
      originalRosterLineItemDtls.serviceFrom,
      originalRosterLineItemDtls.serviceTo);
    DateRange newDateRange = new DateRange(
      details.rosterLineItemDtls.serviceFrom,
      details.rosterLineItemDtls.serviceTo);

    Roster roster = rosterDAO.get(originalRosterLineItemDtls.rosterID);

    // If roster line item is not in open status, it cannot be updated.
    if (!providerRosterLineItem.getLifecycleState().getCode().equals(
      PRLIStatusEntry.OPEN.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_CANNOT_BE_MODIFIED(
          providerRosterLineItem.getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }

    // Actual Units cannot be anything other than numbers.
    // BEGIN, CR00132041, SG
    if (details.unitsDeliveredString.trim().length() > 0) {
      try {
        details.rosterLineItemDtls.totalUnitsDelivered = Short.parseShort(
          details.unitsDeliveredString);
      } catch (NumberFormatException ne) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_IS_INVALID(
            details.unitsDeliveredString),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            5);
        ValidationHelper.failIfErrorsExist();
      }
    }
    // END, CR00132041

    // If actual units are changed, it must be greater than zero.
    if (!providerRosterLineItem.getUnitsDelivered().equals(
      details.rosterLineItemDtls.totalUnitsDelivered)
        && details.rosterLineItemDtls.totalUnitsDelivered <= 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_MUST_BE_GT_ZERO(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 6);
    }

    if (!details.providerRosterLineItemDtls.autoGeneratedInd) {

      if (details.rosterLineItemDtls.serviceFrom.isZero()
        || (roster.getDateRange().startsAfter(
          details.rosterLineItemDtls.serviceFrom))) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTERLINE_ITEM_XRV_SERVICE_FROM_DATE_MUST_BE_ON_OR_AFTER_FROM_DATE_OF_ROSTER(
            details.rosterLineItemDtls.serviceFrom,
            roster.getDateRange().start()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            2);
      }

      if (details.rosterLineItemDtls.serviceTo.isZero()
        || (roster.getDateRange().endsBefore(
          details.rosterLineItemDtls.serviceTo))) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTERLINE_ITEM_XRV_SERVICE_TO_DATE_MUST_BE_EARLIER_THAN_OR_EQUAL_TO_ROSTER_TO_DATE(
            details.rosterLineItemDtls.serviceTo, roster.getDateRange().end()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            1);
      }
    }

    ValidationHelper.failIfErrorsExist();

    UpdateRLIDetails updateRLIDetails = new UpdateRLIDetails();

    if (details.providerRosterLineItemDtls.autoGeneratedInd) {
      updateRosterLineItem(details);
    }

    // If delete rows indicator in the input struct is set to true,
    // that means the check is already done.

    if (!details.deleteRowsInd
      && !details.providerRosterLineItemDtls.autoGeneratedInd) {
      if (newDateRange.endsBefore(oldDateRange.end())
        || newDateRange.startsAfter(oldDateRange.start())) {
        // Only if the daily attendance is configured, delete rows page
        // should be shown.
        if (isDailyAttendanceConfigured(providerRosterLineItem)) {
          updateRLIDetails.deleteRowsInd = true;
        }
      } else {
        updateRLIDetails.deleteRowsInd = false;
      }
    }
    return updateRLIDetails;
  }

  /**
   * Retrieves the Daily Attendance details for a specified provider roster line
   * item key.
   *
   * @param providerRosterLineItemKey
   * Key containing the provider roster line item ID.
   * @return List of Daily Attendance details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewDailyAttendanceDetails viewDailyAttendance(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {
    ViewDailyAttendanceDetails viewDailyAttendanceDetails = new ViewDailyAttendanceDetails();
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    // Populate the details of the roster line item.
    viewDailyAttendanceDetails.fromDate = providerRosterLineItem.getServiceDateFrom();
    viewDailyAttendanceDetails.toDate = providerRosterLineItem.getServiceDateTo();
    if (providerRosterLineItem.getClient() != null) {
      viewDailyAttendanceDetails.clientName = providerRosterLineItem.getClient().getName();
    }

    Locale locale = new Locale(TransactionInfo.getProgramLocale());
    DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG, locale);

    // Populate the list of daily attendance details for a specified roster
    // line
    // item.
    
    DailyAttendanceDetails dailyAttendanceDetails;
    
    // BEGIN, CR00314944, SSK
    boolean hoursEnabled = isHoursDailyAttendanceConfigured(
      providerRosterLineItem);
    Set<curam.attendance.impl.DailyAttendance> dailyAttendanceList = null;
    
    dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID(), hoursEnabled);
    // END, CR00314944
      
    for (curam.attendance.impl.DailyAttendance dailyAttendance : sortDailyAttendanceByServiceDate(
      dailyAttendanceList)) {

      if (RECORDSTATUSEntry.NORMAL.equals(dailyAttendance.getStatus())) {
        
        // BEGIN, CR00303745, SSK, 
        dailyAttendanceDetails = new DailyAttendanceDetails();
        dailyAttendanceDetails.dtls.serviceDate = dailyAttendance.getServiceDate();
        // END, CR00303745
        
        // BEGIN, CR00303745, SSK
        dailyAttendanceDetails.serviceDateString = curam.util.resources.Locale.getFormattedDateTime(
          dailyAttendance.getServiceDate().getDateTime(),
          curam.util.resources.Locale.Date_ymd);
        // END, CR00303745
        dailyAttendanceDetails.dtls.attendance = dailyAttendance.getAttendance().getCode();
        dailyAttendanceDetails.dtls.absenceReason = dailyAttendance.getAbsenceReason().getCode();
        if (dailyAttendance.getExpectedUnits() == 0) {
          dailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceDetails.expectedUnitsString = String.valueOf(
            dailyAttendance.getExpectedUnits());
        }
        if (dailyAttendance.getUnitsAttended() == 0) {
          dailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceDetails.unitsAttendedString = String.valueOf(
            dailyAttendance.getUnitsAttended());
        }
        if (dailyAttendance.getUnitsUnattended() == 0) {
          dailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
            dailyAttendance.getUnitsUnattended());
        }
        dailyAttendanceDetails.dtls.dailyAttendanceID = dailyAttendance.getID();
        dailyAttendanceDetails.dtls.versionNo = dailyAttendance.getVersionNo();
        dailyAttendanceDetails.dtls.rosterLineItemID = dailyAttendance.getRosterLineItem();

        dailyAttendanceDetailsList.details.addRef(dailyAttendanceDetails);
        viewDailyAttendanceDetails.detailsList.details.addRef(
          dailyAttendanceDetails);
      }
    }

    // Setting the indicator for displaying daily Attendance details.
    viewDailyAttendanceDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    // Convert the list of daily attendance details to an xml. This xml is
    // the
    // input to the widget to display the list of daily attendance details.
    viewDailyAttendanceDetails.dailyAttendanceDetails = WidgetHelper.convertDailyAttendanceToXml(
      dailyAttendanceDetailsList);
    viewDailyAttendanceDetails.rliVersionNo = providerRosterLineItem.getRLIVersionNo();

    return viewDailyAttendanceDetails;
  }

  /**
   * Validates if total units are greater than expected units.
   *
   * @param key
   * Contains roster ID.
   * @return Units exceeded details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public UnitsExceededDetails isTotalUnitsGreaterThanExpectedUnits(
    ProviderRosterLineItemKey key) throws AppException,
      InformationalException {

    UnitsExceededDetails unitsExceededDetails = new UnitsExceededDetails();
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);

    if (providerRosterLineItem.getAutoGeneratedInd()
      && providerRosterLineItem.getUnitsDelivered()
        > providerRosterLineItem.getExpectedUnits()) {
      unitsExceededDetails.unitsExceededInd = true;
    } else {
      unitsExceededDetails.unitsExceededInd = false;
    }
    return unitsExceededDetails;
  }

  /**
   * {@inheritDoc}
   */
  public PRLISummaryDetails viewRosterLineItem(ProviderRosterLineItemKey key)
    throws AppException, InformationalException {

    PRLISummaryDetails summaryDetails = new PRLISummaryDetails();
    ProviderRosterLineItemDetails details = new ProviderRosterLineItemDetails();
    
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);

    details.providerRosterLineItemDtls = getProviderRosterLineItemDetails(
      providerRosterLineItem);
    details.rosterLineItemDtls = getRosterLineItemDetails(
      providerRosterLineItem);
   
    // Total units/expected units should be shown as blank when it is
    // zero.
    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        providerRosterLineItem.getRoster())) {
      // END, CR00178377
      if (details.rosterLineItemDtls.totalUnitsDelivered == 0) {
        details.unitsDeliveredString = CuramConst.gkEmpty;
      } else {
        details.unitsDeliveredString = String.valueOf(
          details.rosterLineItemDtls.totalUnitsDelivered);
      }

      if (details.rosterLineItemDtls.expectedUnits == 0) {
        details.expectedUnitsString = CuramConst.gkEmpty;
      } else {
        details.expectedUnitsString = String.valueOf(
          details.rosterLineItemDtls.expectedUnits);
      }
    }
    // END, CR00176474

    if (details.providerRosterLineItemDtls.addressID != 0) {
      details.addressData = providerRosterLineItem.getAddressData();
      Address addressObj = AddressFactory.newInstance();

      OtherAddressData formattedAddressData = new OtherAddressData();

      formattedAddressData.addressData = providerRosterLineItem.getAddressData();
      addressObj.getAddressStrings(formattedAddressData);
      summaryDetails.addressData = formattedAddressData.addressData;
    }
    if (details.providerRosterLineItemDtls.status.equals(
      PRLIStatusEntry.PENDINGAPPROVAL.getCode())) {
      summaryDetails.cancelLinkInd = true;
    }
    Set<PRLISALILink> pRLISALILinks = prliSALILinkDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);
    // BEGIN, CR00281033, SSK
    ServiceAuthorizationLineItemDetails serviceAuthorizationLineItemDetails = null;

    for (final PRLISALILink pRLISALILink : pRLISALILinks) {
      // BEGIN, CR00237055, RPB
      serviceAuthorizationLineItemDetails = getSALIDetails(
        pRLISALILink.getServiceAuthorizationLineItem());
      serviceAuthorizationLineItemDetails.remainingUints = pRLISALILink.getRemainingUnits();
     
      summaryDetails.saliDetails.addRef(serviceAuthorizationLineItemDetails);
      // END, CR00281033
      // END, CR00237055
    }
    // BEGIN CR00131152, SSH
    if (details.providerRosterLineItemDtls.exceptionProcInd) {
      summaryDetails.exceptionTaskCreated = ROSTER.INF_ROSTER_LINE_ITEM_EXCEPTIONTASKCREATED_YES.getMessageText(
        TransactionInfo.getProgramLocale());
    } else {
      summaryDetails.exceptionTaskCreated = ROSTER.INF_ROSTER_LINE_ITEM_EXCEPTIONTASKCREATED_NO.getMessageText(
        TransactionInfo.getProgramLocale());
    }
    // END CR00131152
    summaryDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);
    summaryDetails.details = details;
    // BEGIN CR00124135, SSH
    if (providerRosterLineItem.getClient() != null) {
      summaryDetails.details.concernRoleID = providerRosterLineItem.getClient().getID();
      summaryDetails.details.isRegisteredClientInd = true;
      // BEGIN, CR00136553, ABS
      summaryDetails.details.clientName = providerRosterLineItem.getClient().getName();
      // END, CR00136553
    }
    // END CR00124135
    summaryDetails.providerID = providerRosterLineItem.getRoster().getProvider().getID();

    return summaryDetails;
  }

  /**
   * {@inheritDoc}
   */
  public void deleteAbsenceReason(KeyVersionDetails key) throws AppException,
      InformationalException {

    AbsencePeriod absencePeriod = absencePeriodDAO.get(key.id);

    // Retrieve the provider roster line item from the absence period.
    Set<ProviderRosterLineItem> providerRosterLineItemList = providerRosterLineItemDAO.searchByRosterLineItemID(
      absencePeriod.getRosterLineItem());
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemList.iterator().next();

    // If roster line item has exception task process indicator set, it cannot
    // be updated.
    if (providerRosterLineItem.getExceptionProcInd()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_ABSENCE_REASON_CANNOT_BE_DELETED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }
    absencePeriod.cancel(key.version);
  }

  /**
   * {@inheritDoc}
   */
  public AbsencePeriodHistoryDetailsList listHistoryForAbsencePeriod(
    ProviderRosterLineItemKey key) throws AppException,
      InformationalException {
    
    AbsencePeriodHistoryDtlsList absencePeriodHistoryDtlsList = new AbsencePeriodHistoryDtlsList();
         
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);

    Set<curam.attendance.impl.AbsencePeriod> absencePeriodList = absencePeriodDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());
    
    // BEGIN, CR00208448, ASN
    AbsencePeriodHistoryDetailsList absencePeriodHistoryDetailsList = new AbsencePeriodHistoryDetailsList();
    List<PRLIHistory> prliHistories = prliHistoryDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);

    for (final PRLIHistory prliHistory : prliHistories) {

      if (0 != prliHistory.getPRLICorrection().getID()) {

        PRLICorrection prliCorrection = prliCorrectionDAO.get(
          prliHistory.getPRLICorrection().getID());

        Set<AbsencePeriodCorrectionHistory> absencePeriodCorrectionHistories = absencePeriodCorrectionHistoryDAO.searchByPRLICorrection(
          prliCorrection);

        // BEGIN, CR00281157, ASN
        if (!PRLICorrectionStatusEntry.DENIED.equals(
          prliCorrection.getLifecycleState())
            && !PRLICorrectionStatusEntry.APPROVED.equals(
              prliCorrection.getLifecycleState())) {
          // END, CR00281157
          for (final AbsencePeriodCorrectionHistory absencePeriodCorrectionHistory : absencePeriodCorrectionHistories) {
            
            AbsencePeriodHistoryDetails absencePeriodHistoryDetails = new AbsencePeriodHistoryDetails();

            absencePeriodHistoryDetails.dtls.absenceDate = absencePeriodCorrectionHistory.getAbsenceDate();
            absencePeriodHistoryDetails.dtls.dateTimeChanged = absencePeriodCorrectionHistory.getDateTimeChanged();
            absencePeriodHistoryDetails.dtls.absenceReason = absencePeriodCorrectionHistory.getAbsenceReason();
            absencePeriodHistoryDetails.dtls.unitsUnattended = absencePeriodCorrectionHistory.getUnitsUnattended();
            absencePeriodHistoryDetails.dtls.recordStatus = absencePeriodCorrectionHistory.getStatus().getCode();
            // BEGIN, CR00281157, ASN
            absencePeriodHistoryDetails.dtls.createdBySystem = absencePeriodCorrectionHistory.isCreatedBySystem();
            // END, CR00281157
            // BEGIN, CR00233823, PS
            User user = userDAO.get(
              absencePeriodCorrectionHistory.getUserName());

            absencePeriodHistoryDetails.dtls.userName = user.getFullName();
            // END, CR00233823
            
            absencePeriodHistoryDetails.dtls.creationDate = absencePeriodCorrectionHistory.getCreationDate();
            // BEGIN, CR00281157, ASN
            if (absencePeriodHistoryDetails.dtls.createdBySystem) {
              absencePeriodHistoryDetailsList.details.addRef(
                absencePeriodHistoryDetails);
            }
            // END, CR00281157
          }
          break;
        }
      }
    }
    // END, CR00208448
   
    // Set the daily attendance indicator.
    absencePeriodHistoryDetailsList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);
    
    // BEGIN, CR00281157, ASN
    Set<Long> absencePeriodID = new HashSet<Long>();

    // END, CR00281157
    for (AbsencePeriod absencePeriod : absencePeriodList) {

      absencePeriodHistoryDtlsList = absencePeriodHistoryDAO.searchBy(
        absencePeriod);
      int historySize = 0;
      
      historySize = absencePeriodHistoryDtlsList.dtls.size();
      
      // BEGIN, CR00281157, ASN
      for (final AbsencePeriodHistoryDtls absencePeriodHistoryDtls : absencePeriodHistoryDtlsList.dtls.items()) {

        if (!absencePeriodHistoryDtls.createdBySystem) {
          absencePeriodID.add(absencePeriodHistoryDtls.absencePeriodID);
        }
      }
      // END, CR00281157

      for (int i = 0; i < historySize; i++) {
        AbsencePeriodHistoryDetails absencePeriodHistoryDetails = new AbsencePeriodHistoryDetails();

        absencePeriodHistoryDetails.dtls = absencePeriodHistoryDtlsList.dtls.item(
          i);

        // BEGIN, CR00281157, ASN
        User user = userDAO.get(absencePeriodHistoryDetails.dtls.userName);

        absencePeriodHistoryDetails.dtls.userName = user.getFullName();  
        
        if (absencePeriodHistoryDetails.dtls.createdBySystem
          && !absencePeriodID.contains(
            absencePeriodHistoryDetails.dtls.absencePeriodID)) {

          absencePeriodHistoryDetailsList.details.addRef(
            absencePeriodHistoryDetails);
        }
        // END, CR00281157
 
      }

    }

    return sortByAbsencePeriodHistoryCreationDate(
      absencePeriodHistoryDetailsList);
  }

  /**
   * Lists the history changes for daily attendance. The list ordered by
   * creation date, earliest first.
   *
   * @param key
   * Contains daily attendance id.
   * @return List of all daily attendance history.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public DailyAttendanceHistoryDetailsList listHistoryForDailyAttendance(
    ProviderRosterLineItemKey key) throws AppException,
      InformationalException {

    DailyAttendanceHistoryDetailsList dailyAttendanceHistoryDetailsList = new DailyAttendanceHistoryDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);

    dailyAttendanceHistoryDetailsList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);
    DailyAttendanceHistoryDtlsList dailyAttendanceHistoryDtlsList = new DailyAttendanceHistoryDtlsList();

    Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());

    Locale locale = new Locale(TransactionInfo.getProgramLocale());
    DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG, locale);

    DailyAttendanceHistoryDetails dailyAttendanceHistoryDetails;

    for (DailyAttendance dailyAttendance : dailyAttendanceList) {
      dailyAttendanceHistoryDtlsList = dailyAttendanceHistoryDAO.searchBy(
        dailyAttendance);
      int historySize = 0;

      historySize = dailyAttendanceHistoryDtlsList.dtls.size();

      for (int i = 0; i < historySize; i++) {

        // BEGIN, CR00304523, SSK
        dailyAttendanceHistoryDetails = new DailyAttendanceHistoryDetails();
        dailyAttendanceHistoryDetails.dtls.serviceDate = dailyAttendanceHistoryDtlsList.dtls.item(i).serviceDate;
        // END, CR00304523
        
        java.util.Date serviceDate = new java.util.Date(
          dailyAttendanceHistoryDtlsList.dtls.item(i).serviceDate.asLong());
        String formattedServiceDate = dateFormat.format(serviceDate);

        dailyAttendanceHistoryDetails.serviceDateString = formattedServiceDate;
        if (dailyAttendanceHistoryDtlsList.dtls.item(i).unitsAttended == 0) {
          dailyAttendanceHistoryDetails.unitsAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceHistoryDetails.unitsAttendedString = String.valueOf(
            dailyAttendanceHistoryDtlsList.dtls.item(i).unitsAttended);
        }
        if (dailyAttendanceHistoryDtlsList.dtls.item(i).unitsUnattended == 0) {
          dailyAttendanceHistoryDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceHistoryDetails.unitsUnAttendedString = String.valueOf(
            dailyAttendanceHistoryDtlsList.dtls.item(i).unitsUnattended);
        }
        
        // BEGIN, CR00208448, ASN
        dailyAttendanceHistoryDetails.dtls.dateTimeChanged = dailyAttendanceHistoryDtlsList.dtls.item(i).dateTimeChanged;
        dailyAttendanceHistoryDetails.dtls.absenceReason = dailyAttendanceHistoryDtlsList.dtls.item(i).absenceReason;
        dailyAttendanceHistoryDetails.dtls.attendance = dailyAttendanceHistoryDtlsList.dtls.item(i).attendance;
        dailyAttendanceHistoryDetails.dtls.userName = dailyAttendanceHistoryDtlsList.dtls.item(i).userName;
        // END, CR00208448

        dailyAttendanceHistoryDetails.dtls = dailyAttendanceHistoryDtlsList.dtls.item(
          i);
        dailyAttendanceHistoryDetailsList.details.addRef(
          dailyAttendanceHistoryDetails);

      }
    }
    // BEGIN, CR00208448, ASN
    List<PRLIHistory> prliHistories = prliHistoryDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);
    
    DailyAttendanceHistoryDetails dailyAttendanceHistory;
    PRLICorrection prliCorrection;
    
    for (final PRLIHistory prliHistory : prliHistories) {
    
      if (0 != prliHistory.getPRLICorrection().getID()) {
     
        prliCorrection = prliCorrectionDAO.get(
          prliHistory.getPRLICorrection().getID());
      
        Set <DailyAttendanceCorrectionHistory> DailyAttendanceCorrectionHistories = dailyAttendanceCorrectionHistoryDAO.searchByPRLICorrection(
          prliCorrection);
      
        if (!PRLICorrectionStatusEntry.DENIED.equals(
          prliCorrection.getLifecycleState())) {

          for (final DailyAttendanceCorrectionHistory dailyAttendanceCorrectionHistory : DailyAttendanceCorrectionHistories) {
            // BEGIN, CR00304523. SSK
            dailyAttendanceHistory = new DailyAttendanceHistoryDetails();
            dailyAttendanceHistory.dtls.serviceDate = dailyAttendanceCorrectionHistory.getServiceDate();
            // END, CR00304523

            java.util.Date serviceDate = new java.util.Date(
              dailyAttendanceCorrectionHistory.getServiceDate().asLong());
            String formattedServiceDate = dateFormat.format(serviceDate);
          
            dailyAttendanceHistory.serviceDateString = formattedServiceDate;
           
            if (0 == dailyAttendanceCorrectionHistory.getUnitsAttended()) {
            
              dailyAttendanceHistory.unitsAttendedString = CPMConstants.kEmptyString;
            } else {
            
              dailyAttendanceHistory.unitsAttendedString = String.valueOf(
                dailyAttendanceCorrectionHistory.getUnitsAttended());
            }
            if (0 == dailyAttendanceCorrectionHistory.getUnitsUnattended()) {
            
              dailyAttendanceHistory.unitsUnAttendedString = CPMConstants.kEmptyString;
            } else {
            
              dailyAttendanceHistory.unitsUnAttendedString = String.valueOf(
                dailyAttendanceCorrectionHistory.getUnitsUnattended());
            }
            dailyAttendanceHistory.dtls.absenceReason = dailyAttendanceCorrectionHistory.getAbsenceReason().getCode();
            dailyAttendanceHistory.dtls.attendance = dailyAttendanceCorrectionHistory.getAttendance().getCode();
            dailyAttendanceHistory.dtls.dateTimeChanged = dailyAttendanceCorrectionHistory.getDateTimeChanged();
               
            // BEGIN, CR00233823, PS
            User user = userDAO.get(
              dailyAttendanceCorrectionHistory.getUserName());

            dailyAttendanceHistory.dtls.userName = user.getFullName();
            // END, CR00233823
            
            dailyAttendanceHistoryDetailsList.details.addRef(
              dailyAttendanceHistory);
          
          }
          break;
        }
      }
      // END, CR00208448
    }
    
    return sortByDailyAttendanceHistoryCreationDate(
      dailyAttendanceHistoryDetailsList);
  }
  
  /**
   * Sorts the daily attendances history list by Date and Time Changed, latest
   * first.
   *
   * @param dailyAttendanceHistoryDetailsList
   * Contains unsorted daily attendance details list.
   */
  protected DailyAttendanceHistoryDetailsList sortByDailyAttendanceHistoryCreationDate(
    DailyAttendanceHistoryDetailsList dailyAttendanceHistoryDetailsList) {

    DailyAttendanceHistoryDetailsList dailyAttendanceHistoryDetailsSortedList = new DailyAttendanceHistoryDetailsList();
    List<DailyAttendanceHistoryDetails> dailyAttendanceHistoryDetailsSortebleList = new ArrayList<DailyAttendanceHistoryDetails>();

    for (int i = 0; i < dailyAttendanceHistoryDetailsList.details.size(); i++) {
      dailyAttendanceHistoryDetailsSortebleList.add(
        dailyAttendanceHistoryDetailsList.details.item(i));
    }
    // BEGIN, CR00124023, AK
    // Sorting the daily attendances history list by Date and
    // Time Changed, latest first.
    if (dailyAttendanceHistoryDetailsSortebleList.size() > 0) {
      Collections.sort(dailyAttendanceHistoryDetailsSortebleList,
        new Comparator<DailyAttendanceHistoryDetails>() {
        public int compare(final DailyAttendanceHistoryDetails lhs,
          final DailyAttendanceHistoryDetails rhs) {
          return lhs.dtls.dateTimeChanged.compareTo(rhs.dtls.dateTimeChanged);
        }
      });
    }
    // END, CR00124023

    for (int i = dailyAttendanceHistoryDetailsSortebleList.size(); i > 0; i--) {
      dailyAttendanceHistoryDetailsSortedList.details.addRef(
        dailyAttendanceHistoryDetailsSortebleList.get(i - 1));
    }

    return dailyAttendanceHistoryDetailsSortedList;
  }

  /**
   * Sorts the Absence Period history list by Date and Time Changed, latest
   * first.
   *
   * @param absencePeriodHistoryDetailsList
   * Contains unsorted daily attendance details list.
   */
  protected AbsencePeriodHistoryDetailsList sortByAbsencePeriodHistoryCreationDate(
    AbsencePeriodHistoryDetailsList absencePeriodHistoryDetailsList) {

    AbsencePeriodHistoryDetailsList absencePeriodHistoryDetailsSortedList = new AbsencePeriodHistoryDetailsList();
    List<AbsencePeriodHistoryDetails> absencePeriodHistoryDetailsSortebleList = new ArrayList<AbsencePeriodHistoryDetails>();

    for (int i = 0; i < absencePeriodHistoryDetailsList.details.size(); i++) {
      absencePeriodHistoryDetailsSortebleList.add(
        absencePeriodHistoryDetailsList.details.item(i));
    }
    // Sorting the absence Periods history list by Date and
    // Time Changed, latest first.
    if (absencePeriodHistoryDetailsSortebleList.size() > 0) {
      Collections.sort(absencePeriodHistoryDetailsSortebleList,
        new Comparator<AbsencePeriodHistoryDetails>() {
        public int compare(final AbsencePeriodHistoryDetails lhs,
          final AbsencePeriodHistoryDetails rhs) {
          return rhs.dtls.creationDate.compareTo(lhs.dtls.creationDate);
        }
      });
    }

    int absenceListSize = 0;

    absenceListSize = absencePeriodHistoryDetailsSortebleList.size();
    for (int i = absenceListSize; i > 0; i--) {
      absencePeriodHistoryDetailsSortedList.details.addRef(
        absencePeriodHistoryDetailsSortebleList.get(i - 1));
    }

    return absencePeriodHistoryDetailsSortedList;
  }

  /**
   * Populates the roster line item standard struct details from the provider
   * roster line item entity object.
   *
   * @param providerRosterLineItem
   * Provider roster line item object holding the roster line item
   * details.
   * @return Roster Line Item details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected RosterLineItemDtls getRosterLineItemDetails(
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {
    RosterLineItemDtls rosterLineItemDtls = new RosterLineItemDtls();

    rosterLineItemDtls.rosterLineItemID = providerRosterLineItem.getRosterLineItemID();
    if (providerRosterLineItem.getClient() != null) {
      rosterLineItemDtls.concernRoleID = providerRosterLineItem.getClient().getID();
    }
    rosterLineItemDtls.referenceNo = providerRosterLineItem.getReferenceNumber();
    rosterLineItemDtls.rosterID = providerRosterLineItem.getRoster().getID();
    rosterLineItemDtls.serviceFrom = providerRosterLineItem.getServiceDateFrom();
    rosterLineItemDtls.serviceTo = providerRosterLineItem.getServiceDateTo();
    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        providerRosterLineItem.getRoster())) {
      // END, CR00178377
      rosterLineItemDtls.expectedUnits = providerRosterLineItem.getExpectedUnits();
      rosterLineItemDtls.totalUnitsDelivered = providerRosterLineItem.getUnitsDelivered();
    }
    // END, CR00176474
    rosterLineItemDtls.versionNo = providerRosterLineItem.getRLIVersionNo();

    return rosterLineItemDtls;
  }

  /**
   * Populates the provider roster line item standard struct details from the
   * provider roster line item entity object.
   *
   * @param providerRosterLineItem
   * Provider roster line item object holding the provider roster line
   * item details.
   * @return Provider Roster Line Item details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ProviderRosterLineItemDtls getProviderRosterLineItemDetails(
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {
    ProviderRosterLineItemDtls providerRosterLineItemDtls = new ProviderRosterLineItemDtls();

    providerRosterLineItemDtls.providerRosterLineItemID = providerRosterLineItem.getID();
    providerRosterLineItemDtls.rosterLineItemID = providerRosterLineItem.getRosterLineItemID();
    providerRosterLineItemDtls.saReferenceNo = providerRosterLineItem.getSAReferenceNo();
    providerRosterLineItemDtls.clientReferenceNo = providerRosterLineItem.getClientReferenceNo();
    providerRosterLineItemDtls.clientFirstName = providerRosterLineItem.getClientFirstName();
    providerRosterLineItemDtls.clientLastName = providerRosterLineItem.getClientLastName();
    providerRosterLineItemDtls.clientDOB = providerRosterLineItem.getClientDOB();
    providerRosterLineItemDtls.addressID = providerRosterLineItem.getAddressID();
    providerRosterLineItemDtls.status = providerRosterLineItem.getLifecycleState().getCode();

    providerRosterLineItemDtls.versionNo = providerRosterLineItem.getVersionNo();

    providerRosterLineItemDtls.autoGeneratedInd = providerRosterLineItem.getAutoGeneratedInd();
    // BEGIN, CR00131152, SSH
    providerRosterLineItemDtls.exceptionProcInd = providerRosterLineItem.getExceptionProcInd();
    // END, CR00131152

    providerRosterLineItemDtls.caseReferenceNo = providerRosterLineItem.getCaseReferenceNo();
    providerRosterLineItemDtls.voucherNumber = providerRosterLineItem.getVoucherNumber();

    return providerRosterLineItemDtls;
  }

  /**
   * Denies the specified provider roster line item having the status open and
   * in exception task only.
   *
   * @param details
   * Contains provider roster line item id and the version numbers of
   * Provider roster line item and roster line item.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void denyRosterLineItemFromExceptionTask(PRLIDenialDetails details)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      details.key.providerRosterLineItemID);

    // Deny the provider roster line item using specified version.
    providerRosterLineItem.deny(details.prliVersionNo, details.rliVersionNo,
      PRLIDenialReasonEntry.get(details.denialReason));

  }

  /**
   * Deletes the specified provider roster line item having the status open and
   * in exception task only.
   *
   * @param details
   * Contains provider roster line item id and the version numbers of
   * Provider roster line item and roster line item.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deleteRosterLineItemFromExceptionTask(
    PRLICancellationDetails details) throws AppException,
      InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      details.providerRosterLineItemID);

    PRLICancelationReasonEntry cancelationReasonEntry = PRLICancelationReasonEntry.CASENOTMATCHEDWITHSA;

    if (details.cancelationReason.length() == 0) {

      cancelationReasonEntry = PRLICancelationReasonEntry.NOT_SPECIFIED;
    } else {
      cancelationReasonEntry = PRLICancelationReasonEntry.get(
        details.cancelationReason);
    }
    providerRosterLineItem.cancel(details.prliVersionNo, details.rliVersionNo,
      cancelationReasonEntry);

  }

  /**
   * {@inheritDoc}
   */
  public void deleteRosterLineItem(PRLICancellationDetails details)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      details.providerRosterLineItemID);

    if (providerRosterLineItem.isInExceptionProcessing() == true) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_CANNOT_CANCEL(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    ValidationHelper.failIfErrorsExist();

    providerRosterLineItem.cancel(details.prliVersionNo, details.rliVersionNo,
      PRLICancelationReasonEntry.get(details.cancelationReason));

  }

  /**
   * {@inheritDoc}
   */
  public void cancelRosterLineItem(PRLICancellationDetails details)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      details.providerRosterLineItemID);

    if (providerRosterLineItem.isInExceptionProcessing() == true) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_CANNOT_CANCEL(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }
    ValidationHelper.failIfErrorsExist();

    providerRosterLineItem.cancel(details.prliVersionNo, details.rliVersionNo,
      PRLICancelationReasonEntry.get(details.cancelationReason));
  }

  // BEGIN,CR00129319, KR
  /**
   * Validates the actual units against the expected units.
   *
   * @param providerRosterLineItemKey
   * Contains provider roster line item ID.
   *
   * @return The Informational messages are added, when the actual units more
   * than the expected units.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_ACTUAL_UNITS_MORE_THAN_EXPECTED_UNITS}
   * If actual units more than expected units.
   */
  public InformationalMessageList validateTotalAndExpectedUnits(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);
    boolean unitsExceededInd = false;

    if (providerRosterLineItem.getAutoGeneratedInd()
      && providerRosterLineItem.getUnitsDelivered()
        > providerRosterLineItem.getExpectedUnits()) {
      unitsExceededInd = true;
    } else {
      unitsExceededInd = false;
    }
    if (unitsExceededInd) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();
      AppException appException = ROSTERExceptionCreator.INF_ROSTER_LINE_ITEM_XFV_ACTUAL_UNITS_MORE_THAN_EXPECTED_UNITS();

      informationalManager.addInformationalMsg(appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning);

      String warnings[] = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        InformationalMessage infoMessage = new InformationalMessage();

        infoMessage.messageTest = warnings[i];
        informationalMessageList.dtls.addRef(infoMessage);
      }
    }
    return informationalMessageList;
  }

  // END, CR00129319

  // BEGIN, CR00198474, ASN
  /**
   * Validate expected units, units attended, units not attended if attendance
   * is entered.
   *
   * @param dailyAttendanceDetailsList
   * List containing the daily attendance details.
   */
  // END, CR00198474
  protected void validateDailyAttendance(
    DailyAttendanceDetailsList dailyAttendanceDetailsList)
    throws InformationalException {
    // BEGIN, CR00198474, ASN
    int recordCounter = 0;

    // END, CR00198474
    for (DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {

      if (dailyAttendanceDetails.dtls.attendance.trim().length() == 0
        && (dailyAttendanceDetails.dtls.absenceReason.trim().length() > 0
          || dailyAttendanceDetails.dtls.unitsAttended > 0
          || dailyAttendanceDetails.dtls.unitsUnattended > 0)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
      }

      // Check units attended less than zero or equal to zero and attendance
      // is present or partially present.
      if (dailyAttendanceDetails.dtls.attendance.equals(
        ATTENDANCEEntry.PRESENT.getCode())
          || dailyAttendanceDetails.dtls.attendance.equals(
            ATTENDANCEEntry.PARTIALLYPRESENT.getCode())) {
        if (dailyAttendanceDetails.dtls.unitsAttended <= 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_PRESENT_OR_PARTIALLY_PRESENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
        }
      }

      // Check units attended not equal to zero and attendance
      // is not present and not partially present.
      if (dailyAttendanceDetails.dtls.attendance.equals(
        ATTENDANCEEntry.ABSENT.getCode())) {
        if (dailyAttendanceDetails.dtls.unitsAttended != 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_ABSENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
        }
      }

      // Check attendance is present and units attended not equal to zero.
      if (dailyAttendanceDetails.dtls.attendance.equals(
        ATTENDANCEEntry.PRESENT.getCode())
          && dailyAttendanceDetails.dtls.unitsUnattended != 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      }

      if ((dailyAttendanceDetails.dtls.attendance.equals(
        ATTENDANCEEntry.PARTIALLYPRESENT.getCode())
          || dailyAttendanceDetails.dtls.attendance.equals(
            ATTENDANCEEntry.ABSENT.getCode()))
              && dailyAttendanceDetails.dtls.unitsUnattended == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ABSENT_OR_PARTIALLY_PRESENT(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      }
      // BEGIN, CR00228146, ASN

      if (ATTENDANCEEntry.ABSENT.getCode().equals(
        dailyAttendanceDetails.dtls.attendance)
          || ATTENDANCEEntry.PARTIALLYPRESENT.getCode().equals(
            dailyAttendanceDetails.dtls.attendance)) {
        if (StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.absenceReason)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ENTDAILYATTENDANCEExceptionCreator.ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_ABSENT_OR_PARTIALLY_PRESENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
        }
      }

      if (ATTENDANCEEntry.PRESENT.getCode().equals(
        dailyAttendanceDetails.dtls.attendance)
          && !StringUtil.isNullOrEmpty(
            dailyAttendanceDetails.dtls.absenceReason)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTDAILYATTENDANCEExceptionCreator.ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);

      }
      // END, CR00228146
      // BEGIN, CR00198474, ASN
      if (StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.attendance)) {

        recordCounter = recordCounter + 1;
      }
    }
    if (recordCounter == dailyAttendanceDetailsList.details.size()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 7);
    }
    // END, CR00198474
    ValidationHelper.failIfErrorsExist();
  }

  /**
   * Returns the informational message, when the actual units are greater than
   * the units remaining after taking in to account total units delivered of
   * `Pending Approval` roster line items.
   *
   * @param providerRosterLineItemKey
   * Contains the provider roster line item key to compare the units
   * delivered.
   *
   * @return InformationalMessageList Contains informational message.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMessageList validatePRLIUnitsDeliveredInPendingApproval(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    // Retrieve all PRLISALI links for the roster line items.
    Set<PRLISALILink> prliSALILinks = prliSALILinkDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);

    for (PRLISALILink prliSALILink : prliSALILinks) {

      Set<PRLISALILink> prliSALILinkList = prliSALILinkDAO.searchByServiceAuthorizationLineItem(
        prliSALILink.getServiceAuthorizationLineItem());

      long unitsDelivered = 0;

      // Add up the units delivered for the pending approval roster line
      // items.
      for (PRLISALILink prliSALILinkObj : prliSALILinkList) {

        if (PRLIStatusEntry.PENDINGAPPROVAL.equals(
          prliSALILinkObj.getProviderRosterLineItem().getLifecycleState())) {
          if (prliSALILink.getServiceAuthorizationLineItem().getID().equals(
            prliSALILinkObj.getServiceAuthorizationLineItem().getID())) {
            unitsDelivered += prliSALILinkObj.getTotalUnitsAllocated();
          }

        }
      }
      // Calculate the units remaining for the service authorization line
      // item.
      long unitsRemaining = prliSALILink.getServiceAuthorizationLineItem().getUnitsAuthorized()
        - (prliSALILink.getServiceAuthorizationLineItem().getUnitsConsumed()
          + unitsDelivered);

      if (unitsRemaining < 0) {

        InformationalManager informationalManager = TransactionInfo.getInformationalManager();
        AppException appException = ROSTERExceptionCreator.INF_ROSTER_LINE_ITEM_XRV_ACTUAL_UNITS_MORE_THAN_UNITS_REMAINING_FOR_PENDING_APPROVAL_PRLIS();

        informationalManager.addInformationalMsg(appException,
          CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning);

        // Assign informational messages to return struct
        String warnings[] = informationalManager.obtainInformationalAsString();

        for (int i = 0; i < warnings.length; i++) {
          InformationalMessage infoMessage = new InformationalMessage();

          infoMessage.messageTest = warnings[i];
          informationalMessageList.dtls.addRef(infoMessage);
        }
        break;
      }

    }

    return informationalMessageList;
  }

  /**
   * Adds a absence reason for a specified provider roster line item from the
   * exception task.
   *
   * @param createAbsenceDetails
   * Details of the Absence details record.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addAbsenceFromExceptionTask(
    CreateAbsenceDetails createAbsenceDetails) throws AppException,
      InformationalException {

    // Check appropriate security privileges.
    providerSecurity.checkProviderSecurity(
      providerDAO.get(Long.valueOf(createAbsenceDetails.providerID)));

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      createAbsenceDetails.providerRosterLineItemID);

    addAbsenceToRLI(createAbsenceDetails, providerRosterLineItem);

  }

  // BEGIN, CR00228146, ASN
  /**
   * Modifies all the daily attendance records and the roster line item record
   * for a specified provider roster line item.
   *
   * @param dailyAttendanceWidgetDetails
   * Contains the xml data received from the Daily Attendance widget.
   *
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED}
   * - If other details are specified, the Attendance must be entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_ABSENT}
   * - If attendance is absent, units attended must not be entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ABSENT_OR_PARTIALLY_PRESENT}
   * - If attendance is partially present or absent and units not
   * attended is not greater than zero.
   * @throws InformationalException
   * {@link ENTDAILYATTENDANCE#ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT}
   * - If attendance is present and absence reason is entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED}
   * - If user tries to save all blank daily attendance records.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link ENTDAILYATTENDANCE#ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_ABSENT_OR_PARTIALLY_PRESENT}
   * - If attendance is partially present or absent but absence reason
   * is not entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED}
   * - If other details are specified, the Attendance must be entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ABSENT_OR_PARTIALLY_PRESENT}
   * - If attendance is partially present or absent and units not
   * attended is not greater than zero.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT}
   * - If attendance is present , units not attended must not be
   * entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_PRESENT_OR_PARTIALLY_PRESENT}
   * - If attendance is present or partially present, units attended
   * must be entered.
   * @throws InformationalException
   * {@link ENTDAILYATTENDANCE#ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_ABSENT_OR_PARTIALLY_PRESENT}
   * - If attendance is partially present or absent but absence reason
   * is not entered.
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_ABSENT}
   * - If attendance is absent, units attended must not be entered.
   * {@link ENTDAILYATTENDANCE#ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT}
   * - If attendance is present and absence reason is entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED}
   * - If user tries to save all blank daily attendance records.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT}
   * - If attendance is present , units not attended must not be
   * entered.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_PRESENT_OR_PARTIALLY_PRESENT}
   * - If attendance is present or partially present, units attended
   * must be entered.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00228146
  public void addDailyAttendanceFromExceptionTask(
    DailyAttendanceWidgetDetails dailyAttendanceWidgetDetails)
    throws AppException, InformationalException {
    // check appropriate security privileges
    providerSecurity.checkProviderSecurity(
      providerDAO.get(Long.valueOf(dailyAttendanceWidgetDetails.providerID)));

    // Modify the actual units attribute in roster line item record.
    curam.attendance.impl.ProviderRosterLineItem providerRosterLineItemImpl = providerRosterLineItemDAO.get(
      dailyAttendanceWidgetDetails.providerRosterLineItemID);

    addDailyAttendanceForRLI(dailyAttendanceWidgetDetails,
      providerRosterLineItemImpl);

  }

  // BEGIN, CR00237055, RPB
  /**
   * Gets the service authorization line item details from the service
   * authorization line item entity object.
   *
   * @param details
   * Service authorization line item object holding the service
   * authorization line item details.
   * @return Service Authorization Line Item details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link MaintainRosterLineItem#getSALIDetails(ServiceAuthorizationLineItem details)}
   * .Units remaining for a Service Authorization Line Item should be
   * obtained from the getUnitsRemaining method provided instead of
   * calculating it as the difference between units authorized and
   * units consumed. The getUnitsRemaining method throws exceptions
   * and calling this would require change in the signature of
   * calling method. So, this method has been replaced with new
   * method with different signature. See release note: CR00237055.
   */
  protected ServiceAuthorizationLineItemDetails getServiceAuthorizationLineItemDetails(
    ServiceAuthorizationLineItem details) {
    ServiceAuthorizationLineItemDetails dtls = new ServiceAuthorizationLineItemDetails();

    dtls.dateAdded = details.getDateAdded();
    dtls.fromDate = details.getDateRange().start();
    dtls.maximumUnits = CPMConstants.kEmptyString + details.getMaximumUnits();
    if (details.getProvider() != null) {
      dtls.providerID = details.getProvider().getID();
    }
    dtls.status = details.getDerivedStatus();
    dtls.serviceAuthorizationID = details.getServiceAuthorization().getID();
    dtls.ServiceAuthorizationLineItemID = details.getID();
    dtls.serviceID = details.getServiceOffering().getID();
    dtls.serviceName = details.getServiceOffering().getName();
    dtls.toDate = details.getDateRange().end();
    dtls.totalCost = CPMConstants.kEmptyString + details.getTotalCost();
    // BEGIN, CR00142003, ABS
    if (details.getUnitAmount() != null) {
      dtls.unitAmount = details.getUnitAmount();
    }
    // END, CR00142003
    dtls.unitsAmountFixedInd = details.isUnitAmountFixed();
    dtls.unitsAuthorized = CPMConstants.kEmptyString
      + details.getUnitsAuthorized();
    // BEGIN, CR00125943, NK
    dtls.remainingUints = (int) (details.getUnitsAuthorized()
      - details.getUnitsConsumed());
    // END, CR00125943
    return dtls;
  }

  /**
   * Gets the service authorization line item details from the service
   * authorization line item entity object.
   *
   * @param details
   * Service authorization line item object holding the service
   * authorization line item details.
   *
   * @return Service Authorization Line Item details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ServiceAuthorizationLineItemDetails getSALIDetails(
    final ServiceAuthorizationLineItem details) throws AppException,
      InformationalException {
    ServiceAuthorizationLineItemDetails dtls = new ServiceAuthorizationLineItemDetails();

    dtls.dateAdded = details.getDateAdded();
    dtls.fromDate = details.getDateRange().start();
    dtls.maximumUnits = CPMConstants.kEmptyString + details.getMaximumUnits();
    if (details.getProvider() != null) {
      dtls.providerID = details.getProvider().getID();
    }
    dtls.status = details.getDerivedStatus();
    dtls.serviceAuthorizationID = details.getServiceAuthorization().getID();
    dtls.ServiceAuthorizationLineItemID = details.getID();
    dtls.serviceID = details.getServiceOffering().getID();
    dtls.serviceName = details.getServiceOffering().getName();
    dtls.toDate = details.getDateRange().end();
    dtls.totalCost = CPMConstants.kEmptyString + details.getTotalCost();

    if (details.getUnitAmount() != null) {
      dtls.unitAmount = details.getUnitAmount();
    }
    dtls.unitsAmountFixedInd = details.isUnitAmountFixed();
    dtls.unitsAuthorized = CPMConstants.kEmptyString
      + details.getUnitsAuthorized();
    dtls.remainingUints = details.getUnitsRemaining();
    return dtls;
  }

  // END, CR00237055

  /**
   * Checks whether the daily attendance tracking is required for the service
   * associated with the provider roster line item.
   *
   * @param providerRosterLineItem
   * Provider roster line item for which the daily attendance tracking
   * configuration is to be determined.
   * @return True if daily attendance tracking is required and false otherwise.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected boolean isDailyAttendanceConfigured(
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {

    ServiceOffering serviceOffering = providerRosterLineItem.getRoster().getServiceOffering();
    SOAttendanceConfiguration attendanceConfiguration = sOAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      serviceOffering, providerRosterLineItem.getRoster().getDateGenerated());

    if (attendanceConfiguration != null) {
      return attendanceConfiguration.isDailyAttendanceTrackingRequired();
    }
    return false;
  }
  
  /**
   * Sorts a set of daily attendance records by service date.
   *
   * @param unsortedDailyAttendance
   * The list of unsorted daily attendance.
   * @return A sorted list of daily attendance.
   */
  protected ArrayList<DailyAttendance> sortDailyAttendanceByServiceDate(
    final Set<DailyAttendance> unsortedDailyAttendance) {

    // Sort by position for display
    final ArrayList<DailyAttendance> dailyAttendanceList = new ArrayList<DailyAttendance>(
      unsortedDailyAttendance);

    Collections.sort(dailyAttendanceList, new Comparator<DailyAttendance>() {
      public int compare(final DailyAttendance lhs, DailyAttendance rhs) {

        return lhs.getServiceDate().compareTo(rhs.getServiceDate());
      }
    });
    return dailyAttendanceList;
  }

  /**
   * Sorts a set of absencePeriods by absence date.
   *
   * @param unsortedAbsenceList
   * The list of unsorted absencePeriod records.
   * @return A sorted list of absence records.
   */
  protected ArrayList<AbsencePeriod> sortAbsenceByServiceDate(
    final Set<AbsencePeriod> unsortedAbsenceList) {

    // Sort by position for display
    final ArrayList<AbsencePeriod> absenceList = new ArrayList<AbsencePeriod>(
      unsortedAbsenceList);

    Collections.sort(absenceList, new Comparator<AbsencePeriod>() {
      public int compare(final AbsencePeriod lhs, AbsencePeriod rhs) {

        return lhs.getAbsenceDate().compareTo(rhs.getAbsenceDate());
      }
    });
    return absenceList;
  }

  // BEGIN CR00131152, SSH
  /**
   * {@inheritDoc}
   */
  public InformationalMsgDtlsList viewRLIExceptionTask(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    // Retrieve all the mismatch reasons.
    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    informationalMsgDtlsList = providerRosterLineItem.viewExceptionTask();

    return informationalMsgDtlsList;
  }

  // END CR00131152
  /**
   * Adds a absence reason for a specified provider roster line item.
   *
   * @param createAbsenceDetails
   * Details of the Absence details record.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void addAbsenceToRLI(CreateAbsenceDetails createAbsenceDetails,
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {

    AbsencePeriod absencePeriod = absencePeriodImpl.newInstance();

    // Populate the absence details.
    absencePeriod.setAbsenceDate(createAbsenceDetails.details.dtls.absenceDate);
    absencePeriod.setAbsenceReason(
      ATTENDANCEABSENCEREASONEntry.get(
        createAbsenceDetails.details.dtls.absenceReason));
    absencePeriod.setUnitsUnattended(
      createAbsenceDetails.details.dtls.unitsUnattended);
    absencePeriod.setRosterLineItem(
      providerRosterLineItem.getRosterLineItemID());
    absencePeriod.setStatus(RECORDSTATUSEntry.NORMAL);
    if (providerRosterLineItem.getClient() != null) {
      absencePeriod.setClient(providerRosterLineItem.getClient().getID());
    }
    absencePeriod.insert();
  }

  /**
   * Maintains all the daily attendance records and the roster line item record
   * for a specified provider roster line item.
   *
   * @param dailyAttendanceWidgetDetails
   * Contains the xml data received from the Daily Attendance widget.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void addDailyAttendanceForRLI(
    DailyAttendanceWidgetDetails dailyAttendanceWidgetDetails,
    curam.attendance.impl.ProviderRosterLineItem providerRosterLineItemImpl)
    throws AppException, InformationalException {
    // The xml containing data of daily attendance details list which is
    // received from the Daily Attendance widget is parsed and the xml data
    // is populated to a list of daily attendance details.
    DailyAttendanceDetailsList dailyAttendanceDetailsList = WidgetHelper.convertXmlToAttendanceDetailsList(
      dailyAttendanceWidgetDetails.dailyAttendanceDetails);

    short actualUnits = 0;

    providerRosterLineItemImpl.getServiceAuthorizationLineItem();
    validateDailyAttendance(dailyAttendanceDetailsList);
    // BEGIN, CR00320064, SSK
    validateDailyAttendanceUnits(providerRosterLineItemImpl,
      dailyAttendanceDetailsList);
    // END, CR00320064
    
    // BEGIN, CR00198474, ASN
    ArrayList<curam.util.type.Date> serviceDateList = new ArrayList<curam.util.type.Date>();
    DailyAttendanceDetailsList dailyAttendanceDetailsViewList = generateDailyAttendance(
      providerRosterLineItemImpl);

    Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItemImpl.getRosterLineItemID());

    if (!dailyAttendanceList.isEmpty()) {

      serviceDateList = serviceDatesForActiveDailyAttendance(
        providerRosterLineItemImpl);
    }
    
    for (DailyAttendanceDetails viewDailyAttendanceDetails : dailyAttendanceDetailsViewList.details.items()) {
      // BEGIN, CR00198730, ASN
      int count = 0;

      // END, CR00198730
      for (DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {
        
        dailyAttendanceDetails.dtls.rosterLineItemID = providerRosterLineItemImpl.getRosterLineItemID();
        // BEGIN, CR00236982, SSK
        if (null != providerRosterLineItemImpl.getClient()) {
          // END, CR00236982
          dailyAttendanceDetails.dtls.concernRoleID = providerRosterLineItemImpl.getClient().getID();
        }
        if (!serviceDateList.contains(dailyAttendanceDetails.dtls.serviceDate)) {
          if (0 == dailyAttendanceDetails.dtls.dailyAttendanceID
            && viewDailyAttendanceDetails.dtls.serviceDate.equals(
              dailyAttendanceDetails.dtls.serviceDate)
              && (!StringUtil.isNullOrEmpty(
                dailyAttendanceDetails.dtls.attendance))) {

            dailyAttendanceDetails.dtls.expectedUnits = viewDailyAttendanceDetails.dtls.expectedUnits;

            DailyAttendance dailyAttendanceInstance = dailyAttendance.newInstance();

            dailyAttendanceInstance.setRosterLineItem(
              dailyAttendanceDetails.dtls.rosterLineItemID);

            ServiceAuthorization serviceAuthorization = providerRosterLineItemImpl.getServiceAuthorization();

            if (serviceAuthorization != null) {
              final ServiceDelivery serviceDelivery = serviceDeliveryDAO.readByServiceAuthorization(
                serviceAuthorization);

              dailyAttendanceInstance.setRelatedItem(serviceDelivery);
            }

            if (0 != dailyAttendanceDetails.dtls.concernRoleID) {
              curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
                dailyAttendanceDetails.dtls.concernRoleID);

              dailyAttendanceInstance.setClient(concernRole);
            }
            // BEGIN, CR00199226, ASN
            dailyAttendanceInstance.setExpectedUnits(
              viewDailyAttendanceDetails.dtls.expectedUnits);
            
            setDailyAttendanceDetails(dailyAttendanceInstance,
              dailyAttendanceDetails, false);
            // END, CR00199226           
            dailyAttendanceInstance.insert();

          }
        } else {
          if (0 != dailyAttendanceDetails.dtls.dailyAttendanceID) {
            DailyAttendance maintainDailyAttendance = dailyAttendanceDAO.get(
              dailyAttendanceDetails.dtls.dailyAttendanceID);

            if (RECORDSTATUSEntry.NORMAL.getCode().equals(
              maintainDailyAttendance.getDtls().recordStatus)) {
              
              if (StringUtil.isNullOrEmpty(
                dailyAttendanceDetails.dtls.attendance)
                  && StringUtil.isNullOrEmpty(
                    dailyAttendanceDetails.dtls.absenceReason)
                    && StringUtil.isNullOrEmpty(
                      dailyAttendanceDetails.unitsAttendedString)
                      && StringUtil.isNullOrEmpty(
                        dailyAttendanceDetails.unitsUnAttendedString)) {
                // BEGIN, CR00199226, ASN
                maintainDailyAttendance.setAttendance(
                  ATTENDANCEEntry.NOT_SPECIFIED);
                maintainDailyAttendance.setAbsenceReason(
                  ATTENDANCEABSENCEREASONEntry.NOT_SPECIFIED);
                maintainDailyAttendance.setUnitsAttended((short) 0);
                maintainDailyAttendance.setUnitsUnattended((short) 0);
                // END, CR00199226
                maintainDailyAttendance.cancel();
              } else {
                // BEGIN, CR00198730, ASN
                if (count == 1) {
                  break;
                }
                // END, CR00198730
                if (!maintainDailyAttendance.getAttendance().getCode().equals(
                  dailyAttendanceDetails.dtls.attendance)
                    || !maintainDailyAttendance.getAbsenceReason().getCode().equals(
                      dailyAttendanceDetails.dtls.absenceReason)
                      || maintainDailyAttendance.getUnitsAttended()
                        != dailyAttendanceDetails.dtls.unitsAttended
                        || maintainDailyAttendance.getUnitsUnattended()
                          != dailyAttendanceDetails.dtls.unitsUnattended) {

                  maintainDailyAttendance.setAttendance(
                    ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
                  maintainDailyAttendance.setAbsenceReason(
                    ATTENDANCEABSENCEREASONEntry.get(
                      dailyAttendanceDetails.dtls.absenceReason));
                  maintainDailyAttendance.setUnitsAttended(
                    dailyAttendanceDetails.dtls.unitsAttended);
                  maintainDailyAttendance.setUnitsUnattended(
                    dailyAttendanceDetails.dtls.unitsUnattended);
                  
                  maintainDailyAttendance.modify();
                  // BEGIN, CR00198730, ASN
                  count++;
                  // END, CR00198730
                }

              }
            }
          }
        }
      }
    }
    
    Set<DailyAttendance> unitsAttendedList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItemImpl.getRosterLineItemID());
    
    for (DailyAttendance actualUnitsValue:unitsAttendedList) {
      
      if (RECORDSTATUSEntry.NORMAL.getCode().equals(
        actualUnitsValue.getDtls().recordStatus)) {
        actualUnits += actualUnitsValue.getUnitsAttended();
      }
    }
    
    // END, CR00198474
    providerRosterLineItemImpl.setRLIVersionNo(
      dailyAttendanceWidgetDetails.rliVersionNo);
    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        providerRosterLineItemImpl.getRoster())) {
      // END, CR00178377
      providerRosterLineItemImpl.setUnitsDelivered(actualUnits);
    }
    // END, CR00176474
    providerRosterLineItemImpl.setRosterLineItemID(
      providerRosterLineItemImpl.getRosterLineItemID());
    providerRosterLineItemImpl.modifyForDailyAttendance();
  }

  // BEGIN, CR00176474, AS
  // BEGIN, CR00199859, ASN
  /**
   * Modifies all the daily attendance records and the roster line item record
   * for a specified provider roster line item.
   *
   * @param dailyAttendanceWidgetDetails
   * Contains the xml data received from the Daily Attendance widget.
   * @param attendanceConfig
   * Hours enabled configuration for the attendance.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationException
   * Generic Exception Signature.
   */
  protected void addDailyAttendanceDetailsForRLI(
    final DailyAttendanceDetailsList dailyAttendanceDetailsList,
    final ProviderRosterLineItem providerRosterLineItemImpl,
    final boolean attendanceConfig) throws AppException,
      InformationalException {
    // END, CR00199859

    // If roster line item has exception task process indicator set, it cannot
    // be updated.
    if (providerRosterLineItemImpl.getExceptionProcInd()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_EXCEPTION_TASK_PRESENT_ATTENDANCE_CANNOT_BE_MODIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      ValidationHelper.failIfErrorsExist();
    }
    // BEGIN, CR00198474, ASN
    // BEGIN, CR00228146, ASN
    validateForAttendanceReporting(dailyAttendanceDetailsList, attendanceConfig);
    // END, CR00228146
    ArrayList<curam.util.type.Date> serviceDateList = new ArrayList<curam.util.type.Date>();
    DailyAttendanceDetailsList dailyAttendanceDetailsViewList = generateDailyAttendance(
      providerRosterLineItemImpl);

    Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItemImpl.getRosterLineItemID());

    if (!dailyAttendanceList.isEmpty()) {

      serviceDateList = serviceDatesForActiveDailyAttendance(
        providerRosterLineItemImpl);
    }
    // BEGIN, CR00228146, ASN
    for (final DailyAttendanceDetails viewDailyAttendanceDetails : dailyAttendanceDetailsViewList.details.items()) {

      for (final DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {

        if (0
          == viewDailyAttendanceDetails.dtls.serviceDate.compareTo(
            dailyAttendanceDetails.dtls.serviceDate)) {

          dailyAttendanceDetails.dtls.rosterLineItemID = providerRosterLineItemImpl.getRosterLineItemID();
          
          // BEGIN, CR00292566, ASN
          if (null != providerRosterLineItemImpl.getClient()) {
            dailyAttendanceDetails.dtls.concernRoleID = providerRosterLineItemImpl.getClient().getID();
          }
          // END, CR00292566
          
          if (!serviceDateList.contains(dailyAttendanceDetails.dtls.serviceDate)) {
            if (0 == dailyAttendanceDetails.dtls.dailyAttendanceID
              && viewDailyAttendanceDetails.dtls.serviceDate.equals(
                dailyAttendanceDetails.dtls.serviceDate)
                && (!StringUtil.isNullOrEmpty(
                  dailyAttendanceDetails.dtls.attendance))) {

              DailyAttendance dailyAttendanceInstance = dailyAttendance.newInstance();

              dailyAttendanceInstance.setRosterLineItem(
                dailyAttendanceDetails.dtls.rosterLineItemID);
              
              ServiceAuthorization serviceAuthorization = providerRosterLineItemImpl.getServiceAuthorization();

              if (serviceAuthorization != null) {
                final ServiceDelivery serviceDelivery = serviceDeliveryDAO.readByServiceAuthorization(
                  serviceAuthorization);

                dailyAttendanceInstance.setRelatedItem(serviceDelivery);
              }
              
              // BEGIN, CR00292566, ASN
              if (null != providerRosterLineItemImpl.getClient()) {
                curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
                  providerRosterLineItemImpl.getClient().getID());

                dailyAttendanceInstance.setClient(concernRole);

              }
              // END, CR00292566
              
              setDailyAttendanceDetails(dailyAttendanceInstance,
                dailyAttendanceDetails, attendanceConfig);

              dailyAttendanceInstance.insert();

            }
          } else {
            if (0 != dailyAttendanceDetails.dtls.dailyAttendanceID) {

              DailyAttendance maintainDailyAttendance = dailyAttendanceDAO.get(
                dailyAttendanceDetails.dtls.dailyAttendanceID);

              if (RECORDSTATUSEntry.NORMAL.getCode().equals(
                maintainDailyAttendance.getDtls().recordStatus)) {

                boolean checkAttendance = false;
                boolean checkHours = false;

                if (StringUtil.isNullOrEmpty(
                  dailyAttendanceDetails.dtls.attendance)
                    && StringUtil.isNullOrEmpty(
                      dailyAttendanceDetails.dtls.absenceReason)) {
                  checkAttendance = true;
                }
                if (attendanceConfig) {

                  int totalTimeEntered = dailyAttendanceDetails.dtls.numHoursAttended
                    + dailyAttendanceDetails.dtls.numMinutesAttended
                    + dailyAttendanceDetails.dtls.numMinutesAbsent
                    + dailyAttendanceDetails.dtls.numHoursAbsent;

                  if (0 == totalTimeEntered) {
                    checkHours = true;
                  }
                }
                if (checkAttendance || checkHours) {

                  maintainDailyAttendance.setAttendance(
                    ATTENDANCEEntry.NOT_SPECIFIED);
                  maintainDailyAttendance.setAbsenceReason(
                    ATTENDANCEABSENCEREASONEntry.NOT_SPECIFIED);
                  maintainDailyAttendance.setHoursAttended(
                    ATTENDANCETRACKINGHOURSEntry.NOT_SPECIFIED);
                  maintainDailyAttendance.setHoursAbsent(
                    ATTENDANCETRACKINGHOURSEntry.NOT_SPECIFIED);
                  maintainDailyAttendance.setMinutesAttended(
                    ATTENDANCETRACKINGMINUTESEntry.NOT_SPECIFIED);
                  maintainDailyAttendance.setMinutesAbsent(
                    ATTENDANCETRACKINGMINUTESEntry.NOT_SPECIFIED);
                  maintainDailyAttendance.cancel();
                } else {

                  boolean checkHourDetails = false;
                  boolean checkHoursAttended = false;
                  boolean checkHoursAbsent = false;

                  if (attendanceConfig) {
                    if (maintainDailyAttendance.getDtls().numHoursAttended
                      != dailyAttendanceDetails.dtls.numHoursAttended
                        || maintainDailyAttendance.getDtls().numMinutesAttended
                          != dailyAttendanceDetails.dtls.numMinutesAttended) {
                      checkHoursAttended = true;
                    }
                    if (maintainDailyAttendance.getNumOfHoursAbsent()
                      != dailyAttendanceDetails.dtls.numHoursAbsent
                        || maintainDailyAttendance.getNumOfMinutesAbsent()
                          != dailyAttendanceDetails.dtls.numMinutesAbsent) {
                      checkHoursAbsent = true;
                    }
                    if (checkHoursAttended || checkHoursAbsent) {
                      checkHourDetails = true;
                    }
                  }
                  if (!maintainDailyAttendance.getAttendance().getCode().equals(
                    dailyAttendanceDetails.dtls.attendance)
                      || !maintainDailyAttendance.getAbsenceReason().getCode().equals(
                        dailyAttendanceDetails.dtls.absenceReason)
                        || checkHourDetails) {

                    setDailyAttendanceDetails(maintainDailyAttendance,
                      dailyAttendanceDetails, attendanceConfig);

                    maintainDailyAttendance.modify();

                  }

                }
              }
            }
          }
        }
      }
    }
    // END, CR00228146
    providerRosterLineItemImpl.setRosterLineItemID(
      providerRosterLineItemImpl.getRosterLineItemID());
    providerRosterLineItemImpl.modifyForDailyAttendance();
  }

  // END, CR00176474
  
  /**
   * Reads the roster line item details and also the details of the client
   * associated with the roster line item from exception task.
   *
   * @param providerRosterLineItemKey
   * Contains the provider roster line item ID.
   * @return The Provider Roster Line Item details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PRLIInformationalSummaryDetails viewRosterLineItemFromExceptionTask(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {
    PRLIInformationalSummaryDetails informationalSummaryDetails = new PRLIInformationalSummaryDetails();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    providerRosterLineItem.matchAndValidateRosterLineItem();

    String[] messages = TransactionInfo.getInformationalManager().obtainInformationalAsString();

    for (String message : messages) {
      InformationalMsgDtls dtls = new InformationalMsgDtls();

      dtls.informationMsgTxt = message;
      informationalSummaryDetails.informationalDtlsList.dtls.addRef(dtls);
    }
    informationalSummaryDetails.dtls = viewRosterLineItem(
      providerRosterLineItemKey);
    return informationalSummaryDetails;
  }

  /**
   * Deletes the absence reason associated with roster line item from exception
   * task.
   *
   * @param keyVersionDetails
   * Contains the absence period id and version number.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deleteAbsenceReasonFromExceptionTask(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {
    AbsencePeriod absencePeriod = absencePeriodDAO.get(keyVersionDetails.id);

    absencePeriod.cancel(keyVersionDetails.version);

  }

  // BEGIN, CR00216955, ASN
  /**
   * {@inheritDoc}
   */
  public PRLIHistoryWithStatusDetailsList listHistoryForPRLI(
    final ProviderRosterLineItemKey providerRosterLineItemKey)
    throws AppException, InformationalException {

    PRLIHistoryWithStatusDetailsList prliHistoryWithStatusDetailsList = new PRLIHistoryWithStatusDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);
    
    List<PRLIHistory> historyDetailsList = prliHistoryDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);

    for (final PRLIHistory prliHistory : historyDetailsList) {

      RosterLineItemHistory rosterLineItemHistory = prliHistory.getRosterLineItemHistory();
      
      prliHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
        getProviderRosterLineitemHistoryDetails(prliHistory,
        rosterLineItemHistory));
      
    }
    prliHistoryWithStatusDetailsList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);
   
    return filterPRLIHistoryRecords(prliHistoryWithStatusDetailsList);
  }

  // END, CR00216955

  // BEGIN, CR00133496, ABS
  /**
   * Sorts the list of provider roster line item transactions by creation date time.
   *
   * @param transactionList
   * Unsorted list of provider roster line item transaction.
   *
   * @return List Sorted list of provider roster line item transaction.
   */
  protected List<PRLITransactionDetails> sortByCreationDate(
    List<PRLITransactionDetails> transactionList) {

    Collections.sort(transactionList,
      new Comparator<PRLITransactionDetails>() {
      public int compare(final PRLITransactionDetails lhs,
        PRLITransactionDetails rhs) {
        return rhs.dtls.creationDateTime.compareTo(lhs.dtls.creationDateTime);
      }
    });

    return transactionList;
  }

  // END, CR00133496

  // BEGIN, CR00187099, SSK
  /**
   * {@inheritDoc}
   */
  public ViewReportingDailyAttendanceDetails viewDailyAttendanceDetailsForReporting(
    final ProviderRosterLineItemKey providerRosterLineItemKey)
    throws AppException, InformationalException {

    ViewReportingDailyAttendanceDetails viewReportingDailyAttendanceDetails = new ViewReportingDailyAttendanceDetails();
  
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);
    
    // BEGIN, CR00198730, ASN
    RosterKey rosterKey = new RosterKey();

    rosterKey.rosterID = providerRosterLineItem.getRoster().getID();

    viewReportingDailyAttendanceDetails.isHoursEnabled = attendanceConfigurationHelper.isHoursEnabledForAttendanceReporting(
      rosterKey);
    // END, CR00198730
    
    viewReportingDailyAttendanceDetails.fromDate = providerRosterLineItem.getServiceDateFrom();
    viewReportingDailyAttendanceDetails.toDate = providerRosterLineItem.getServiceDateTo();
    if (providerRosterLineItem.getClient() != null) {
      viewReportingDailyAttendanceDetails.clientName = providerRosterLineItem.getClient().getName();
    }

    Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());

    Locale locale = new Locale(TransactionInfo.getProgramLocale());
    DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG, locale);

    ReportingDailyAttendanceDetails reportingDailyAttendanceDetails;

    for (final DailyAttendance dailyAttendance : sortDailyAttendanceByServiceDate(
      dailyAttendanceList)) {

      if (RECORDSTATUSEntry.NORMAL.equals(dailyAttendance.getStatus())) {
        
        // BEGIN, CR00304523, SSK
        reportingDailyAttendanceDetails = new ReportingDailyAttendanceDetails();
        reportingDailyAttendanceDetails.dtls.serviceDate = dailyAttendance.getServiceDate();
        // END, CR00304523

        Date serviceDate = new Date(dailyAttendance.getServiceDate().asLong());
        String formattedServiceDate = dateFormat.format(serviceDate);

        reportingDailyAttendanceDetails.serviceDateString = formattedServiceDate;
        reportingDailyAttendanceDetails.dtls.absenceReason = dailyAttendance.getAbsenceReason().getCode();

        reportingDailyAttendanceDetails.dtls.attendance = dailyAttendance.getAttendance().getCode();
        // BEGIN, CR00198730, ASN
        if (viewReportingDailyAttendanceDetails.isHoursEnabled) {
          // END, CR00198730
           
          // BEGIN, CR00228146, ASN
          reportingDailyAttendanceDetails.hoursAttended = getFormattedTimeDuration(
            dailyAttendance.getNumOfHoursAttended(),
            dailyAttendance.getNumOfMinutesAttended());

          reportingDailyAttendanceDetails.hoursUnAttended = getFormattedTimeDuration(
            dailyAttendance.getNumOfHoursAbsent(),
            dailyAttendance.getNumOfMinutesAbsent());
          // END, CR00228146
          
          // BEGIN, CR00198730, ASN
        }
        // END, CR00198730
        reportingDailyAttendanceDetails.dtls.dailyAttendanceID = dailyAttendance.getID();
        reportingDailyAttendanceDetails.dtls.versionNo = dailyAttendance.getVersionNo();
        reportingDailyAttendanceDetails.dtls.rosterLineItemID = dailyAttendance.getRosterLineItem();

        viewReportingDailyAttendanceDetails.details.addRef(
          reportingDailyAttendanceDetails);
      }
    }

    viewReportingDailyAttendanceDetails.rliVersionNo = providerRosterLineItem.getRLIVersionNo();

    viewReportingDailyAttendanceDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    viewReportingDailyAttendanceDetails.rliVersionNo = providerRosterLineItem.getRLIVersionNo();

    return viewReportingDailyAttendanceDetails;
  }

  /**
   * Formats the duration in "HM hours and MM minutes" format.
   *
   * @param hours
   * Hours of attendance or absence.
   * @param minutes
   * Minutes of attendance or absence.
   *
   * @return Formatted duration.
   */
  // BEGIN, CR00228146, ASN
  protected String getFormattedTimeDuration(final int hours, final int minutes) {

    String formattedHrsMinutes = CPMConstants.kEmptyString;
    String formattedMinutes = CPMConstants.kEmptyString;
    String formattedHrs = CPMConstants.kEmptyString;
    boolean appendMinutesToHrs = false;

    if (0 != minutes) {

      // If minutes is 30, append to half an hour.
      if (30 == minutes) {

        appendMinutesToHrs = true;

      } else {

        if (CPMConstants.kMinturesLength == Integer.toString(minutes).length()
          && CPMConstants.kZeroChar
            == Integer.toString(minutes).charAt(CPMConstants.kFirstCharIndex)) {
          formattedMinutes = Integer.toString(minutes).charAt(
            CPMConstants.kSecondCharIndex)
              + CPMConstants.kSpace
              + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_MINUTES_ATTENDED_UNATTENDED).getMessage();
        } else {
          formattedMinutes = Integer.toString(minutes) + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_MINUTES_ATTENDED_UNATTENDED).getMessage();
        }
      }
    }

    if (0 != hours) {
      if (CPMConstants.kMinturesLength == Integer.toString(hours).length()
        && Integer.toString(hours).charAt(CPMConstants.kFirstCharIndex)
          == CPMConstants.kZeroChar) {
        formattedHrs = Integer.toString(hours).charAt(
          CPMConstants.kSecondCharIndex)
            + CPMConstants.kEmptyString;
      } else {
        formattedHrs = Integer.toString(hours);
      }
    }
    // END, CR00228146
    if (appendMinutesToHrs) {
      if (CPMConstants.kEmptyString.equals(formattedHrs)) {
        formattedHrs = CPMConstants.kZeroChar + CPMConstants.kEmptyString;
      }

      formattedHrsMinutes = formattedHrs + CPMConstants.khalfAnHour
        + CPMConstants.kSpace
        + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_ATTENDED_UNATTENDED).getMessage();

    } else {
      if (!CPMConstants.kEmptyString.equals(formattedHrs)) {
        if (!CPMConstants.kEmptyString.equals(formattedMinutes)) {
          formattedHrsMinutes = formattedHrs + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_AND_MINUTES_ATTENDED_UNATTENDED).getMessage()
            + formattedMinutes;
        } else {
          formattedHrsMinutes = formattedHrs + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_ATTENDED_UNATTENDED).getMessage();
        }
      } else if (!CPMConstants.kEmptyString.equals(formattedMinutes)) {

        formattedHrsMinutes = formattedMinutes;

      }
    }

    return formattedHrsMinutes;
  }

  // END, CR00187099
  // BEGIN, CR00198474, ASN
  /**
   * Generates daily attendance for a client who is added to a roster, for each
   * day of the roster line item period dynamically to support non storage of
   * daily attendance empty records.
   *
   * @param providerRosterLineItem
   * Contains provider roster line item details.
   *
   * @return List of Daily Attendance details. 
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected DailyAttendanceDetailsList generateDailyAttendance(
    final ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();
    Map<curam.util.type.Date, DailyAttendance> checkDuplicateMap = new HashMap<curam.util.type.Date, DailyAttendance>();

    ArrayList<curam.util.type.Date> serviceDateList = new ArrayList<curam.util.type.Date>();

    Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());

    curam.util.type.Date startDate = providerRosterLineItem.getServiceDateFrom();
    curam.util.type.Date endDate = providerRosterLineItem.getServiceDateTo();

    serviceDateList = serviceDatesForActiveDailyAttendance(
      providerRosterLineItem);

    boolean isReporting = false;

    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        providerRosterLineItem.getRoster())) {

      isReporting = true;
    }

    boolean isPlannedUnitsDefaulted = Boolean.parseBoolean(
      curam.util.resources.Configuration.getProperty(
        CPMConstants.kRosterLineItemPlannedUnits));

    // Create the daily Attendance for each day of the service period.
    while (startDate.before(endDate.addDays(1))) {

      if (!serviceDateList.contains(startDate)) {

        DailyAttendanceDetails dailyAttendanceDetails = new DailyAttendanceDetails();

        // BEGIN, CR00199217, ASN
        // BEGIN, CR00198730, ASN
        dailyAttendanceDetails = generateUnstoredDailyAttendanceDetails(
          providerRosterLineItem, isReporting, isPlannedUnitsDefaulted,
          startDate);
        // END, CR00198730
        // END, CR00199217
        dailyAttendanceDetailsList.details.addRef(dailyAttendanceDetails);
      } else {

        for (curam.attendance.impl.DailyAttendance dailyAttendance : sortDailyAttendanceByServiceDate(
          dailyAttendanceList)) {
          
          if (RECORDSTATUSEntry.NORMAL.getCode().equals(
            dailyAttendance.getStatus().getCode())
              && startDate.equals(dailyAttendance.getServiceDate())) {
            
            if (!checkDuplicateMap.containsKey(dailyAttendance.getServiceDate())) {

              checkDuplicateMap.put(dailyAttendance.getServiceDate(),
                dailyAttendance);
              // BEGIN, CR00199217, ASN
              // BEGIN, CR00198730, ASN
              DailyAttendanceDetails storedDailyAttendanceDetails = new DailyAttendanceDetails();

              storedDailyAttendanceDetails = storedDailyAttendanceDetails(
                dailyAttendance);
              // END, CR00198730
              // END, CR00199217
              dailyAttendanceDetailsList.details.addRef(
                storedDailyAttendanceDetails);

            }
          }
        }
      }

      startDate = startDate.addDays(1);
    }

    return sortDailyAttendance(dailyAttendanceDetailsList);

  }

  /**
   * Sorts a set of daily attendance records into a sorted list for display.
   *
   * @param unSortedDailyAttendanceDetailsList
   * List of unsorted daily attendance.
   *
   * @return List of daily attendance records sorted by service date.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  protected DailyAttendanceDetailsList sortDailyAttendance(
    final DailyAttendanceDetailsList unSortedDailyAttendanceDetailsList)
    throws AppException, InformationalException {

    List<DailyAttendanceDetails> dailyAttendanceDetailsList = new ArrayList<DailyAttendanceDetails>();

    for (DailyAttendanceDetails dailyAttendance : unSortedDailyAttendanceDetailsList.details.items()) {
      dailyAttendanceDetailsList.add(dailyAttendance);
    }

    Collections.sort(dailyAttendanceDetailsList,
      new Comparator<DailyAttendanceDetails>() {
      public int compare(final DailyAttendanceDetails lhs,
        final DailyAttendanceDetails rhs) {
        return lhs.dtls.serviceDate.compareTo(rhs.dtls.serviceDate);
      }
    });

    DailyAttendanceDetailsList sortedDailyAttendanceDetailsList = new DailyAttendanceDetailsList();
   
    sortedDailyAttendanceDetailsList.details.addAll(dailyAttendanceDetailsList);

    return sortedDailyAttendanceDetailsList;
  }

  /**
   * Retrieves the Daily Attendance details for a specified provider roster line
   * item key.It supports non storage of daily attendance records in case of
   * empty attendance records.
   *
   * @param providerRosterLineItemKey
   * Key containing the provider roster line item ID.
   *
   * @return List of Daily Attendance details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewDailyAttendanceDetails viewDailyAttendanceList(
    final ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {
    ViewDailyAttendanceDetails viewDailyAttendanceDetails = new ViewDailyAttendanceDetails();
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    viewDailyAttendanceDetails.fromDate = providerRosterLineItem.getServiceDateFrom();
    viewDailyAttendanceDetails.toDate = providerRosterLineItem.getServiceDateTo();
    if (null != providerRosterLineItem.getClient()) {
      
      viewDailyAttendanceDetails.clientName = providerRosterLineItem.getClient().getName();
    }

    SOAttendanceConfiguration soAttendanceConfig = sOAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      providerRosterLineItem.getRoster().getServiceOffering(),
      providerRosterLineItem.getRoster().getDateGenerated());

    if (null != soAttendanceConfig
      && soAttendanceConfig.isDailyAttendanceTrackingRequired()) {
      // Generate daily attendance dynamically using data using either the daily
      // attendance date input at facade level or from daily attendance entity
      // if records exist.
      dailyAttendanceDetailsList = generateDailyAttendance(
        providerRosterLineItem);
    }

    viewDailyAttendanceDetails.detailsList.assign(dailyAttendanceDetailsList);

    viewDailyAttendanceDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    viewDailyAttendanceDetails.dailyAttendanceDetails = WidgetHelper.convertDailyAttendanceToXml(
      dailyAttendanceDetailsList);
    viewDailyAttendanceDetails.rliVersionNo = providerRosterLineItem.getRLIVersionNo();

    return viewDailyAttendanceDetails;
  }
  
  /**
   * Retrieves the service dates for active daily attendance records.
   *
   * @param providerRosterLineItemImpl
   * Contains provider roster line item details.
   *
   * @return List of Daily Attendance details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00199217, ASN
  // BEGIN, CR00198730, ASN
  protected ArrayList<curam.util.type.Date> serviceDatesForActiveDailyAttendance(
    final ProviderRosterLineItem providerRosterLineItemImpl)
    throws InformationalException, AppException {
    // END, CR00198730
    // END, CR00199217
    ArrayList<curam.util.type.Date> serviceDateList = new ArrayList<curam.util.type.Date>();

    Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItemImpl.getRosterLineItemID());

    for (final DailyAttendance dailyAttendance : sortDailyAttendanceByServiceDate(
      dailyAttendanceList)) {

      ArrayList<curam.util.type.Date> serviceDate = new ArrayList<curam.util.type.Date>();

      if (RECORDSTATUSEntry.NORMAL.getCode().equals(
        dailyAttendance.getDtls().recordStatus)) {

        serviceDate.add(dailyAttendance.getServiceDate());
      }
      serviceDateList.addAll(serviceDate);
    }
    return serviceDateList;
  }

  // BEGIN, CR00228146, ASN
  /**
   * Validates records for reporting method of attendance.
   *
   * @param dailyAttendanceDetailsList
   * List containing the daily attendance details.
   * @param attendanceConfig
   * Hours enabled configuration for the attendance.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateForAttendanceReporting(
    final DailyAttendanceDetailsList dailyAttendanceDetailsList,
    final boolean attendanceConfig) throws AppException,
      InformationalException {

    int recordCounter = 0;

    for (DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {
      // BEGIN, CR00198730, ASN
      // BEGIN, CR00199859, ASN
      if (attendanceConfig) {
        // END, CR00199859
        boolean checkHoursAttended = false;
        boolean checkHoursAbsent = false;

        if (dailyAttendanceDetails.dtls.absenceReason.trim().length() > 0
          || dailyAttendanceDetails.dtls.numHoursAttended > 0
          || dailyAttendanceDetails.dtls.numMinutesAttended > 0) {
          checkHoursAttended = true;
        }

        if (dailyAttendanceDetails.dtls.numHoursAbsent > 0
          || dailyAttendanceDetails.dtls.numMinutesAbsent > 0) {
          checkHoursAbsent = true;
        }
        if (0 == dailyAttendanceDetails.dtls.attendance.trim().length()
          && (checkHoursAttended || checkHoursAbsent)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_DAILY_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
          // END, CR00199226
          ValidationHelper.failIfErrorsExist();
        }

        int timeAttendedEntered = dailyAttendanceDetails.dtls.numHoursAttended
          + dailyAttendanceDetails.dtls.numMinutesAttended;
        int timeAbsentEntered = dailyAttendanceDetails.dtls.numHoursAbsent
          + dailyAttendanceDetails.dtls.numMinutesAbsent;

        if (ATTENDANCEEntry.PRESENT.getCode().equals(
          dailyAttendanceDetails.dtls.attendance)
            && 0 == timeAttendedEntered) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_HOURS_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_PRESENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
        }
        if (ATTENDANCEEntry.ABSENT.getCode().equals(
          dailyAttendanceDetails.dtls.attendance)
            && 0 == timeAbsentEntered) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_HOURS_NOT_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_ABSENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
        }
        if (ATTENDANCEEntry.PARTIALLYPRESENT.getCode().equals(
          dailyAttendanceDetails.dtls.attendance)
            && (0 == timeAttendedEntered || 0 == timeAbsentEntered)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_HOURS_ATTENDED_NOT_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_PARTIALLY_PRESENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
        }
        // END, CR00228146
        // END, CR00198730
        // BEGIN, CR00199859, ASN
      } else {
        if (0 == dailyAttendanceDetails.dtls.attendance.trim().length()
          && dailyAttendanceDetails.dtls.absenceReason.trim().length() > 0) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_FOR_HOURS_DISABLED_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);

          ValidationHelper.failIfErrorsExist();
        }
      }
      // END, CR00199859
      // BEGIN, CR00228146, ASN
      if (ATTENDANCEEntry.ABSENT.getCode().equals(
        dailyAttendanceDetails.dtls.attendance)
          || ATTENDANCEEntry.PARTIALLYPRESENT.getCode().equals(
            dailyAttendanceDetails.dtls.attendance)) {
        if (StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.absenceReason)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ENTDAILYATTENDANCEExceptionCreator.ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_ABSENT_OR_PARTIALLY_PRESENT(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
        }
      }

      if (ATTENDANCEEntry.PRESENT.getCode().equals(
        dailyAttendanceDetails.dtls.attendance)
          && !StringUtil.isNullOrEmpty(
            dailyAttendanceDetails.dtls.absenceReason)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTDAILYATTENDANCEExceptionCreator.ERR_DAILYATTENDANCE_XFV_ABSENCE_REASON_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);

      }
      // END, CR00228146
      if (StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.attendance)) {

        recordCounter = recordCounter + 1;
      }
    }
    if (recordCounter == dailyAttendanceDetailsList.details.size()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 6);
      ValidationHelper.failIfErrorsExist();
    }
  }

  // BEGIN, CR00198730, ASN
  /**
   * {@inheritDoc}
   */
  public DailyAttendanceHistoryList listDailyAttendanceHistory(
    final ProviderRosterLineItemKey providerRosterLineItemKey)
    throws AppException, InformationalException {
    final DailyAttendanceHistoryList dailyAttendanceHistoryList = new DailyAttendanceHistoryList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    dailyAttendanceHistoryList.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);
    DailyAttendanceHistoryDtlsList dailyAttendanceHistoryDtlsList = new DailyAttendanceHistoryDtlsList();

    Set<DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID());

    Locale locale = new Locale(TransactionInfo.getProgramLocale());
    DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG, locale);

    DailyAttendanceHistory dailyAttendanceHistory;

    for (final DailyAttendance dailyAttendance : dailyAttendanceList) {
      dailyAttendanceHistoryDtlsList = dailyAttendanceHistoryDAO.searchBy(
        dailyAttendance);

      for (final DailyAttendanceHistoryDtls dailyAttendanceHistoryDetails : dailyAttendanceHistoryDtlsList.dtls.items()) {

        // BEGIN, CR00304523, SSK
        dailyAttendanceHistory = new DailyAttendanceHistory();
        dailyAttendanceHistory.dailyAttendanceHistoryDetails.serviceDate = dailyAttendanceHistoryDetails.serviceDate;
        // END, CR00304523
        java.util.Date serviceDate = new java.util.Date(
          dailyAttendanceHistoryDetails.serviceDate.asLong());
        String formattedServiceDate = dateFormat.format(serviceDate);
        
        dailyAttendanceHistory.serviceDateString = formattedServiceDate;
        if (dailyAttendanceHistoryDetails.unitsAttended == 0) {
          dailyAttendanceHistory.unitsAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceHistory.unitsAttendedString = String.valueOf(
            dailyAttendanceHistoryDetails.unitsAttended);
        }
        if (dailyAttendanceHistoryDetails.unitsUnattended == 0) {
          dailyAttendanceHistory.unitsUnAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceHistory.unitsUnAttendedString = String.valueOf(
            dailyAttendanceHistoryDetails.unitsUnattended);
        }
        // BEGIN, CR00228146, ASN
        dailyAttendanceHistory.hoursAttended = getFormattedTimeDuration(
          Integer.parseInt(dailyAttendanceHistoryDetails.totalHours),
          Integer.parseInt(dailyAttendanceHistoryDetails.totalMinutes));

        dailyAttendanceHistory.hoursUnAttended = getFormattedTimeDuration(
          Integer.parseInt(dailyAttendanceHistoryDetails.hoursAbsent),
          Integer.parseInt(dailyAttendanceHistoryDetails.minutesAbsent));
        // END, CR00228146
     
        // BEGIN, CR00208448, ASN
        dailyAttendanceHistory.dailyAttendanceHistoryDetails.dateTimeChanged = dailyAttendanceHistoryDetails.dateTimeChanged;
                
        // BEGIN, CR00233823, PS
        dailyAttendanceHistory.dailyAttendanceHistoryDetails.userName = dailyAttendanceHistoryDetails.userName;
        // END, CR00233823
        
        User user = userDAO.get(dailyAttendanceHistoryDetails.userName);

        dailyAttendanceHistory.userFullName = user.getFullName();
        
        dailyAttendanceHistory.dailyAttendanceHistoryDetails.absenceReason = dailyAttendanceHistoryDetails.absenceReason;
        
        dailyAttendanceHistory.dailyAttendanceHistoryDetails.attendance = dailyAttendanceHistoryDetails.attendance;
         
        dailyAttendanceHistoryList.details.addRef(dailyAttendanceHistory);
        // END, CR00208448
      }
    }
    
    // BEGIN, CR00208448, ASN
    List<PRLIHistory> prliHistories = prliHistoryDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);

    for (final PRLIHistory prliHistory : prliHistories) {

      if (0 != prliHistory.getPRLICorrection().getID()) {

        PRLICorrection prliCorrection = prliCorrectionDAO.get(
          prliHistory.getPRLICorrection().getID());

        if (!PRLICorrectionStatusEntry.DENIED.equals(
          prliCorrection.getLifecycleState())) {

          Set<DailyAttendanceCorrectionHistory> DailyAttendanceCorrectionHistories = dailyAttendanceCorrectionHistoryDAO.searchByPRLICorrection(
            prliCorrection);

          for (final DailyAttendanceCorrectionHistory dailyAttendanceCorrectionHistory : DailyAttendanceCorrectionHistories) {
            // BEGIN, CR00304523, SSK
            dailyAttendanceHistory = new DailyAttendanceHistory();
            dailyAttendanceHistory.dailyAttendanceHistoryDetails.serviceDate = dailyAttendanceCorrectionHistory.getServiceDate(); 
            // END, CR00304523
            java.util.Date serviceDate = new java.util.Date(
              dailyAttendanceCorrectionHistory.getServiceDate().asLong());
            String formattedServiceDate = dateFormat.format(serviceDate);

            dailyAttendanceHistory.serviceDateString = formattedServiceDate;

            if (0 == dailyAttendanceCorrectionHistory.getUnitsAttended()) {

              dailyAttendanceHistory.unitsAttendedString = CPMConstants.kEmptyString;
            } else {
              dailyAttendanceHistory.unitsAttendedString = String.valueOf(
                dailyAttendanceCorrectionHistory.getUnitsAttended());
            }
            if (0 == dailyAttendanceCorrectionHistory.getUnitsUnattended()) {
              dailyAttendanceHistory.unitsUnAttendedString = CPMConstants.kEmptyString;
            } else {
              dailyAttendanceHistory.unitsUnAttendedString = String.valueOf(
                dailyAttendanceCorrectionHistory.getUnitsUnattended());
            }
            // BEGIN, CR00228146, ASN
            dailyAttendanceHistory.hoursAttended = getFormattedTimeDuration(
              dailyAttendanceCorrectionHistory.getTotalHours(),
              dailyAttendanceCorrectionHistory.getTotalMinutes());
            // END, CR00228146
            dailyAttendanceHistory.hoursUnAttended = getFormattedTimeDuration(
              dailyAttendanceCorrectionHistory.getHoursAbsent(),
              dailyAttendanceCorrectionHistory.getMinutesAbsent());

            dailyAttendanceHistory.dailyAttendanceHistoryDetails.dateTimeChanged = dailyAttendanceCorrectionHistory.getDateTimeChanged();

            // BEGIN, CR00233823, PS
            User user = userDAO.get(
              dailyAttendanceCorrectionHistory.getUserName());

            dailyAttendanceHistory.dailyAttendanceHistoryDetails.userName = user.getFullName();
            // END, CR00233823

            dailyAttendanceHistory.dailyAttendanceHistoryDetails.absenceReason = dailyAttendanceCorrectionHistory.getAbsenceReason().getCode();

            dailyAttendanceHistory.dailyAttendanceHistoryDetails.attendance = dailyAttendanceCorrectionHistory.getAttendance().getCode();

            dailyAttendanceHistoryList.details.addRef(dailyAttendanceHistory);
          }
          break;
        }
      }
    }
    // END, CR00208448
    return sortDailyAttendanceHistoryByCreationDate(dailyAttendanceHistoryList);
  }

  /**
   * Sorts the daily attendances history list by Date and Time Changed, latest
   * first.
   *
   * @param dailyAttendanceHistoryList
   * Contains unsorted daily attendance details list.
   *
   * @return List of daily attendance history.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  protected DailyAttendanceHistoryList sortDailyAttendanceHistoryByCreationDate(
    final DailyAttendanceHistoryList dailyAttendanceHistoryList) {

    final DailyAttendanceHistoryList dailyAttendanceHistoryDetailsSortedList = new DailyAttendanceHistoryList();
    List<DailyAttendanceHistory> dailyAttendanceHistoryDetailsSortebleList = new ArrayList<DailyAttendanceHistory>();

    for (final DailyAttendanceHistory dailyAttendanceHistory : dailyAttendanceHistoryList.details.items()) {
      dailyAttendanceHistoryDetailsSortebleList.add(dailyAttendanceHistory);
    }

    // Sorting the daily attendances history list by Date and
    // Time Changed, latest first.
    if (dailyAttendanceHistoryDetailsSortebleList.size() > 0) {
      Collections.sort(dailyAttendanceHistoryDetailsSortebleList,
        new Comparator<DailyAttendanceHistory>() {
        public int compare(final DailyAttendanceHistory lhs,
          final DailyAttendanceHistory rhs) {
          return rhs.dailyAttendanceHistoryDetails.dateTimeChanged.compareTo(
            lhs.dailyAttendanceHistoryDetails.dateTimeChanged);
        }
      });
    }

    dailyAttendanceHistoryDetailsSortedList.details.addAll(
      dailyAttendanceHistoryDetailsSortebleList);

    return dailyAttendanceHistoryDetailsSortedList;
  }

  /**
   * Generates daily attendance correction for a client who is added to a
   * roster, for each day of the roster line item period in case no daily
   * attendance records exists in the system for a service date.
   *
   * @param prliCorrection
   * Contains provider roster line item correction details.
   * @param isReporting
   * Checks the value of 'Reporting' indicator.
   * @param isPlannedUnitsDefaulted
   * Checks the value of 'Planned Units Defaulted' indicator.
   * @param startDate
   * Service date for which records need to be generated.
   *
   * @return List of Daily Attendance details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected DailyAttendanceDetails generateUnstoredDailyAttendanceDetails(
    final ProviderRosterLineItem providerRosterLineItem,
    final boolean isReporting, final boolean isPlannedUnitsDefaulted,
    final curam.util.type.Date startDate) throws AppException,
      InformationalException {

    DailyAttendanceDetails dailyAttendanceDetails = new DailyAttendanceDetails();

    dailyAttendanceDetails.dtls.rosterLineItemID = providerRosterLineItem.getRosterLineItemID();
    dailyAttendanceDetails.dtls.recordStatus = RECORDSTATUSEntry.NORMAL.getCode();

    ArrayList<curam.util.type.Date> serviceDateList = new ArrayList<curam.util.type.Date>();

    serviceDateList = serviceDatesForActiveDailyAttendance(
      providerRosterLineItem);

    Locale locale = new Locale(TransactionInfo.getProgramLocale());
    DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG, locale);

    if (RECORDSTATUSEntry.NORMAL.getCode().equals(
      dailyAttendanceDetails.dtls.recordStatus)) {

      dailyAttendanceDetails.dtls.serviceDate = startDate;

      // BEGIN, CR00303745, SSK
      dailyAttendanceDetails.serviceDateString = curam.util.resources.Locale.getFormattedDateTime(
        dailyAttendanceDetails.dtls.serviceDate.getDateTime(),
        curam.util.resources.Locale.Date_ymd);
      // END, CR00303745
      
      if (isReporting) {
        dailyAttendanceDetails.dtls.unitsAttended = (short) 0;
        dailyAttendanceDetails.dtls.unitsUnattended = (short) 0;

      }
      if (0 == dailyAttendanceDetails.dtls.unitsAttended) {
        dailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
      } else {
        dailyAttendanceDetails.unitsAttendedString = String.valueOf(
          dailyAttendanceDetails.dtls.unitsAttended);
      }
      if (0 == dailyAttendanceDetails.dtls.unitsUnattended) {
        dailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
      } else {
        dailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
          dailyAttendanceDetails.dtls.unitsUnattended);
      }
      dailyAttendanceDetails.dtls.creationDate = curam.util.type.Date.getCurrentDate();

      // If the service authorization is for the single day set the expected
      // units to units authorized, units attended to expected units and
      // daily attendance as 'Present'.
      Set<PRLISALILink> prliSALILinks = prliSALILinkDAO.searchByProviderRosterLineItem(
        providerRosterLineItem);

      for (PRLISALILink prliSALILink : prliSALILinks) {

        providerRosterLineItem.setServiceAuthorizationLineItem(
          prliSALILink.getServiceAuthorizationLineItem());

        if (null != providerRosterLineItem.getServiceAuthorizationLineItem()) {
         
          // BEGIN, CR00206362, ASN
          if (1
            == providerRosterLineItem.getServiceAuthorizationLineItem().getDateRange().length()
              && providerRosterLineItem.getServiceAuthorizationLineItem().getDateRange().contains(
                startDate)) {
            // END, CR00206362
            
            int expectedUnits = 0;

            if (isReporting) {
              expectedUnits = providerRosterLineItem.getServiceAuthorizationLineItem().getUnitsAuthorized();
              dailyAttendanceDetails.dtls.expectedUnits = (short) expectedUnits;

              if (0 == dailyAttendanceDetails.dtls.expectedUnits) {
                dailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
              } else {
                dailyAttendanceDetails.expectedUnitsString = String.valueOf(
                  expectedUnits);
              }
            }

            if (isPlannedUnitsDefaulted && 0 == serviceDateList.size()) {

              if (isReporting) {
                if (startDate.before(
                  curam.util.type.Date.getCurrentDate().addDays(1))) {
                  dailyAttendanceDetails.dtls.unitsAttended = (short) expectedUnits;
                  dailyAttendanceDetails.unitsAttendedString = String.valueOf(
                    expectedUnits);

                  dailyAttendanceDetails.dtls.attendance = ATTENDANCEEntry.PRESENT.getCode();
                }
              }
            }
          }
        }
      }
    }
    return dailyAttendanceDetails;
  }

  /**
   * Generates daily attendance for a client who is added to a roster, for each
   * day of the roster line item period in case daily attendance records exists
   * in the system.
   *
   * @param dailyAttendance
   * Contains Daily attendance details.
   *
   * @return List of Daily Attendance details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected DailyAttendanceDetails storedDailyAttendanceDetails(
    final DailyAttendance dailyAttendance) throws AppException,
      InformationalException {

    final DailyAttendanceDetails storedDailyAttendanceDetails = new DailyAttendanceDetails();

    storedDailyAttendanceDetails.dtls.serviceDate = dailyAttendance.getServiceDate();

    // BEGIN, CR00303745, SSK
    storedDailyAttendanceDetails.serviceDateString = curam.util.resources.Locale.getFormattedDateTime(
      dailyAttendance.getServiceDate().getDateTime(),
      curam.util.resources.Locale.Date_ymd);
    // END, CR00303745
    storedDailyAttendanceDetails.dtls.attendance = dailyAttendance.getAttendance().getCode();
    storedDailyAttendanceDetails.dtls.absenceReason = dailyAttendance.getAbsenceReason().getCode();
    if (0 == dailyAttendance.getExpectedUnits()) {
      storedDailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
    } else {
      storedDailyAttendanceDetails.expectedUnitsString = String.valueOf(
        dailyAttendance.getExpectedUnits());
    }
    if (0 == dailyAttendance.getUnitsAttended()) {
      storedDailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
    } else {
      storedDailyAttendanceDetails.unitsAttendedString = String.valueOf(
        dailyAttendance.getUnitsAttended());
    }
    if (0 == dailyAttendance.getUnitsUnattended()) {
      storedDailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
    } else {
      storedDailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
        dailyAttendance.getUnitsUnattended());
    }
    // BEGIN, CR00228146, ASN
    storedDailyAttendanceDetails.dtls.numHoursAttended = dailyAttendance.getNumOfHoursAttended();
    storedDailyAttendanceDetails.dtls.numMinutesAttended = dailyAttendance.getNumOfMinutesAttended();
    storedDailyAttendanceDetails.dtls.numHoursAbsent = dailyAttendance.getNumOfHoursAbsent();
    storedDailyAttendanceDetails.dtls.numMinutesAbsent = dailyAttendance.getNumOfMinutesAbsent();
    // END, CR00228146
    
    storedDailyAttendanceDetails.dtls.dailyAttendanceID = dailyAttendance.getID();
    storedDailyAttendanceDetails.dtls.versionNo = dailyAttendance.getVersionNo();
    storedDailyAttendanceDetails.dtls.rosterLineItemID = dailyAttendance.getRosterLineItem();
    return storedDailyAttendanceDetails;
  }

  // END, CR00198730
  
  // BEGIN, CR00199226, ASN
  /**
   * Sets daily attendance details.
   *
   *
   * @param dailyAttendanceInstance
   * Contains Daily attendance object.
   * @param dailyAttendanceDetails
   * Contains daily attendance details.
   * @param attendanceConfig
   * Checks value of 'Hours Enabled' indicator.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void setDailyAttendanceDetails(
    final DailyAttendance dailyAttendanceInstance,
    final DailyAttendanceDetails dailyAttendanceDetails,
    final boolean attendanceConfig) { 

    dailyAttendanceInstance.setServiceDate(
      dailyAttendanceDetails.dtls.serviceDate);
    // BEGIN, CR00228146, ASN
    int calculateValues = dailyAttendanceDetails.dtls.unitsAttended
      + dailyAttendanceDetails.dtls.unitsUnattended
      + dailyAttendanceDetails.dtls.numHoursAttended
      + dailyAttendanceDetails.dtls.numMinutesAttended
      + dailyAttendanceDetails.dtls.numHoursAbsent
      + dailyAttendanceDetails.dtls.numMinutesAbsent;
       
    if (0 == calculateValues) {
      dailyAttendanceInstance.setAttendance(
        ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
    }
    dailyAttendanceInstance.setAbsenceReason(
      ATTENDANCEABSENCEREASONEntry.get(
        dailyAttendanceDetails.dtls.absenceReason));
    
    int totalUnitsEntered = dailyAttendanceDetails.dtls.unitsAttended
      + dailyAttendanceDetails.dtls.unitsUnattended;
   
    if (totalUnitsEntered > 0) {
      dailyAttendanceInstance.setUnitsAttended(
        dailyAttendanceDetails.dtls.unitsAttended);
      dailyAttendanceInstance.setUnitsUnattended(
        dailyAttendanceDetails.dtls.unitsUnattended);
    }
    // END, CR00228146
    // BEGIN, CR00199682, ASN
    // BEGIN, CR00228146, ASN
    if (attendanceConfig) {
      // END, CR00199682
      dailyAttendanceInstance.setNumOfHoursAttended(
        dailyAttendanceDetails.dtls.numHoursAttended);
      dailyAttendanceInstance.setNumOfMinutesAttended(
        dailyAttendanceDetails.dtls.numMinutesAttended);
      dailyAttendanceInstance.setNumOfHoursAbsent(
        dailyAttendanceDetails.dtls.numHoursAbsent);
      dailyAttendanceInstance.setNumOfMinutesAbsent(
        dailyAttendanceDetails.dtls.numMinutesAbsent);

    }
    dailyAttendanceInstance.setProgress(dailyAttendanceDetails.dtls.progress);
    dailyAttendanceInstance.setProgressReason(
      dailyAttendanceDetails.dtls.progressReason);
    dailyAttendanceInstance.setStatus(
      RECORDSTATUSEntry.get(dailyAttendanceDetails.dtls.recordStatus));
    // END, CR00228146
    dailyAttendanceInstance.setCreationDate(
      dailyAttendanceDetails.dtls.creationDate);
    dailyAttendanceInstance.setCreatedBySystem(
      dailyAttendanceDetails.dtls.createdBySystem);
    dailyAttendanceInstance.setVersionNo(dailyAttendanceDetails.dtls.versionNo);

  }

  // END, CR00199226
  
  // BEGIN, CR00216955, ASN
  /**
   * Filters the provider roster line item and correction history to display
   * valid history records.
   *
   * @param prliHistoryWithStatusDetailsList
   * Provider roster line item and correction history details list.
   *
   * @return Filtered list of Provider roster line item and correction history
   * details.
   */
  protected PRLIHistoryWithStatusDetailsList filterPRLIHistoryRecords(
    final PRLIHistoryWithStatusDetailsList prliHistoryWithStatusDetailsList) {

    PRLIHistoryWithStatusDetailsList sortedPRLIHistoryWithStatusDetailsList = new PRLIHistoryWithStatusDetailsList();
    boolean inCompleteHistory = false;
    // BEGIN, CR00270518, GP
    String prevStatus = new String();
    // END, CR00270518

    PRLIHistoryWithStatusDetails prliHistoryWithStatusCompletedHistoryDetails = null;

    for (PRLIHistoryWithStatusDetails prliHistoryWithStatusDetails : sortProviderRosterlineItemHistory(
      prliHistoryWithStatusDetailsList)) {

      if (!PRLIStatusEntry.COMPLETE.getCode().equals(
        prliHistoryWithStatusDetails.prliHistoryDetails.status)) {

        if (!inCompleteHistory) {
          
          if (PRLIStatusEntry.OPEN.getCode().equals(
            prliHistoryWithStatusDetails.prliHistoryDetails.status)) {
            
            // BEGIN, CR00270518, GP
            if (!prevStatus.equals(
              prliHistoryWithStatusDetails.prliHistoryDetails.status)) {
            
              sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
                prliHistoryWithStatusDetails);
              // END, CR00270518 
            }
          } else {
            sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
              prliHistoryWithStatusDetails);
          }
        } else {
          if (0
            != prliHistoryWithStatusDetails.prliHistoryDetails.prliCorrectionID) {

            if (PRLIStatusEntry.OPEN.getCode().equals(
              prliHistoryWithStatusDetails.prliHistoryDetails.status)) {
              // BEGIN, CR00270518, GP
              if (!isCorrectionCanceled(prliHistoryWithStatusDetails)
                && !prevStatus.equals(
                  prliHistoryWithStatusDetails.prliHistoryDetails.status)) {
                // END, CR00270518
                sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
                  prliHistoryWithStatusDetails);
              }
            } else if (PRLIStatusEntry.PENDINGAPPROVAL.getCode().equals(
              prliHistoryWithStatusDetails.prliHistoryDetails.status)) {

              if (isCorrectionDenied(prliHistoryWithStatusDetails)) {
                prliHistoryWithStatusDetails.isStatusDeniedInd = true;
              }
              sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
                prliHistoryWithStatusDetails);

              if (prliHistoryWithStatusDetails.isStatusDeniedInd
                && null != prliHistoryWithStatusCompletedHistoryDetails) {

                prliHistoryWithStatusCompletedHistoryDetails.rliHistory.dateTimeChanged = prliHistoryWithStatusDetails.rliHistory.dateTimeChanged;

                sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
                  prliHistoryWithStatusCompletedHistoryDetails);
              }
            }
          }
        }

      } else {

        inCompleteHistory = true;
        prliHistoryWithStatusCompletedHistoryDetails = prliHistoryWithStatusDetails;
        // BEGIN, CR00270518, GP
        if (!prevStatus.equals(
          prliHistoryWithStatusDetails.prliHistoryDetails.status)) {
          // END, CR00270518
          sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.addRef(
            prliHistoryWithStatusDetails);
        }

      }
      // BEGIN, CR00270518, GP
      prevStatus = prliHistoryWithStatusDetails.prliHistoryDetails.status;
      // END, CR00270518
    }

    Collections.reverse(
      sortedPRLIHistoryWithStatusDetailsList.prliHistoryWithStatusDetails);
    
    sortedPRLIHistoryWithStatusDetailsList.dailyAttendanceLinkInd = prliHistoryWithStatusDetailsList.dailyAttendanceLinkInd;

    return sortedPRLIHistoryWithStatusDetailsList;
  }

  /**
   * Sorts a set of provider roster line item details into a sorted list by
   * latest date changed for display.
   *
   * @param prliHistoryWithStatusDetailsList
   * The set of provider roster line item details.
   *
   * @return Sorted list of provider roster line item records for display.
   */
  protected List<PRLIHistoryWithStatusDetails> sortProviderRosterlineItemHistory(
    final PRLIHistoryWithStatusDetailsList prliHistoryWithStatusDetailsList) {

    List<PRLIHistoryWithStatusDetails> sortedPRLIHistoryWithStatusDetails = Arrays.asList(
      prliHistoryWithStatusDetailsList.prliHistoryWithStatusDetails.items());

    Collections.sort(sortedPRLIHistoryWithStatusDetails,
      new Comparator<PRLIHistoryWithStatusDetails>() {

      public int compare(final PRLIHistoryWithStatusDetails lhs,
        final PRLIHistoryWithStatusDetails rhs) {

        return lhs.rliHistory.dateTimeChanged.compareTo(
          rhs.rliHistory.dateTimeChanged);

      }
    });
    return sortedPRLIHistoryWithStatusDetails;
  }

  /**
   * Checks if the PRLI correction is canceled.
   *
   * @param prliHistoryWithStatusDetails
   * provider roster line item correction history details.
   *
   * @return True if correction is canceled otherwise false.
   */
  protected boolean isCorrectionCanceled(
    final PRLIHistoryWithStatusDetails prliHistoryWithStatusDetails) {
    PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliHistoryWithStatusDetails.prliHistoryDetails.prliCorrectionID);

    if (0 != prliHistoryWithStatusDetails.prliHistoryDetails.prliCorrectionID
      && PRLICorrectionStatusEntry.CANCELED.getCode().equals(
        prliCorrection.getLifecycleState().getCode())) {
      return true;
    }
    return false;
  }

  /**
   * Checks if the correction is denied.
   *
   * @param prliHistoryWithStatusDetails
   * Provider roster line item and correction history details.
   *
   * @return True if correction is denied otherwise false.
   */
  protected boolean isCorrectionDenied(
    final PRLIHistoryWithStatusDetails prliHistoryWithStatusDetails) {

    PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliHistoryWithStatusDetails.prliHistoryDetails.prliCorrectionID);

    if (0 != prliHistoryWithStatusDetails.prliHistoryDetails.prliCorrectionID
      && PRLICorrectionStatusEntry.DENIED.getCode().equals(
        prliCorrection.getLifecycleState().getCode())) {
      return true;
    }
    return false;
  }

  // END, CR00216955
  
  // BEGIN, CR00314944, SSK
  /**
   * Checks whether the hours is enabled for daily attendance tracking
   * configuration for the service associated with the provider roster line
   * item.
   *
   * @param providerRosterLineItem
   * Provider roster line item for which hours enabled configuration is
   * to be determined. 
   *
   * @return True if hours is enabled on daily attendance configuration.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected boolean isHoursDailyAttendanceConfigured(
    final ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {

    final ServiceOffering serviceOffering = providerRosterLineItem.getRoster().getServiceOffering();
    final SOAttendanceConfiguration attendanceConfiguration = sOAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      serviceOffering, providerRosterLineItem.getRoster().getDateGenerated());

    if (null != attendanceConfiguration) {
      return attendanceConfiguration.isHoursEnabled();
       
    }
    return false;
  }

  // END, CR00314944
  
  // BEGIN, CR00320064, SSK
  /**
   * Validates if the units attended/units not attended is less than or equal to
   * 24.
   *
   * @param providerRosterLineItem
   * Contains provider roster line item details.
   * @param dailyAttendanceDetailsList
   * List of daily attendance details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateDailyAttendanceUnits(
    final ProviderRosterLineItem providerRosterLineItem,
    final DailyAttendanceDetailsList dailyAttendanceDetailsList)
    throws InformationalException, AppException {

    if (UnitOfMeasureEntry.HOUR.equals(
      providerRosterLineItem.getRoster().getServiceOffering().getUnitOfMeasure())) {
      for (final DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {

        if (CPMConstants.kHoursInDay
          <= dailyAttendanceDetails.dtls.unitsAttended) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_HOURS_ATTENDED_MUST_LESS_OR_EQUAL_T0_24(
              dailyAttendanceDetails.dtls.unitsAttended
                + CPMConstants.kEmptyString),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                3);
          break;
        } else if (CPMConstants.kHoursInDay
          <= dailyAttendanceDetails.dtls.unitsUnattended) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_HOURS_UNATTENDED_MUST_LESS_OR_EQUAL_T0_24(
              dailyAttendanceDetails.dtls.unitsUnattended
                + CPMConstants.kEmptyString),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                3);
          break;
        }
      }

    }
    ValidationHelper.failIfErrorsExist();

  }

  // END, CR00320064
}
