/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.attendance.impl.AttendancePaymentProcessing;
import curam.attendance.impl.PRLISALILink;
import curam.attendance.impl.PRLISALILinkDAO;
import curam.attendance.impl.ProviderRosterLineItem;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.cpm.facade.struct.BudgetInformation;
import curam.cpm.facade.struct.RelatedPRLIDetails;
import curam.cpm.facade.struct.RelatedServiceInvoiceLineItemInformationDetails;
import curam.cpm.facade.struct.RelatedServiceInvoiceLineItemInformationDetailsList;
import curam.cpm.facade.struct.SALIDetails;
import curam.cpm.facade.struct.ServiceAuthorizationClientDetails;
import curam.cpm.facade.struct.ServiceAuthorizationDetails;
import curam.cpm.facade.struct.ServiceAuthorizationDetailsList;
import curam.cpm.facade.struct.ServiceAuthorizationLineItemDetails;
import curam.cpm.facade.struct.ServiceAuthorizationLineItemStatusHistory;
import curam.cpm.facade.struct.ServiceAuthorizationLineItemStatusHistoryList;
import curam.cpm.facade.struct.ServiceAuthorizationMultipleClientDetails;
import curam.cpm.facade.struct.ViewBudgetInformation;
import curam.cpm.facade.struct.ViewSALIDetails;
import curam.cpm.facade.struct.ViewSALIDetailsList;
import curam.cpm.facade.struct.ViewServiceAuthorizationDetails;
import curam.cpm.facade.struct.ViewServiceAuthorizationLineItemDetails;
import curam.cpm.facade.struct.ViewServiceAuthorizationLineItemDetailsList;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ActualServiceDeliveryDetails;
import curam.cpm.sl.entity.struct.ConcernRoleAndCaseIDKey;
import curam.cpm.sl.entity.struct.ServiceAuthorizationKey;
import curam.cpm.sl.entity.struct.ServiceAuthorizationLineItemKey;
import curam.financial.impl.ServiceInvoiceLineItemDAO;
import curam.financial.impl.ServiceInvoiceLineItemStatusEntry;
import curam.financial.impl.ServiceInvoiceLineItemTransaction;
import curam.financial.impl.ServiceInvoiceLineItemTransactionStatusEntry;
import curam.financial.impl.ServiceInvoiceLineItemTransactionTypeEntry;
import curam.participant.impl.ConcernRole;
import curam.serviceauthorization.impl.ServiceAuthorizationDAO;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItem;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItemDAO;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItemHistory;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItemHistoryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Money;


/**
 * Facade layer class having API for obtaining service authorization details.
 *
 */

public abstract class ServiceAuthorization extends curam.cpm.facade.base.ServiceAuthorization {

  /**
   * Injecting the Data Access Object for ServiceAuthorization class.
   */
  @Inject
  protected ServiceAuthorizationDAO serviceAuthorizationDAO;

  /**
   * Injecting the Data Access Object for ServiceAuthorizationLineItem class.
   */
  @Inject
  protected ServiceAuthorizationLineItemDAO serviceAuthorizationLineItemDAO;

  /**
   * Injecting the Data Access Object for ServiceInvoiceLineItem class.
   */
  @Inject
  protected ServiceInvoiceLineItemDAO serviceInvoiceLineItemDAO;

  /**
   * Injecting the Data Access Object for ServiceAuthorizationLineItemHistory
   * class.
   */
  @Inject
  protected ServiceAuthorizationLineItemHistoryDAO serviceAuthorizationLIHistoryDAO;

  /**
   * Reference to AttendancePaymentProcessing.
   */
  @Inject
  protected AttendancePaymentProcessing attendancePaymentProcessing;

  // BEGIN, CR00291750, SSK
  /**
   * Reference to PRLISALILink DAO.
   */
  @Inject
  protected PRLISALILinkDAO prliSaliDAO;
  // END, CR00291750
  
  /**
   * Default constructor.
   */
  public ServiceAuthorization() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * Reads the service authorization details for the given service authorization
   * ID.
   *
   * @param serviceAuthorizationKey
   * Service Authorization ID.
   *
   * @return The Service authorization details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewServiceAuthorizationDetails viewServiceAuthorizationDetails(
    ServiceAuthorizationKey serviceAuthorizationKey) throws AppException,
      InformationalException {

    ViewServiceAuthorizationDetails viewServiceAuthorizationDetails = new ViewServiceAuthorizationDetails();

    final curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorizationObj = serviceAuthorizationDAO.get(
      serviceAuthorizationKey.serviceAuthorizationID);

    final ConcernRole client = serviceAuthorizationObj.getClient();

    viewServiceAuthorizationDetails.serviceAuthorizationDetails.serviceAuthorizationID = serviceAuthorizationObj.getID();
    viewServiceAuthorizationDetails.serviceAuthorizationDetails.referenceNumber = serviceAuthorizationObj.getReferenceNumber();
    viewServiceAuthorizationDetails.serviceAuthorizationDetails.caseReferenceNumber = serviceAuthorizationObj.getCaseReferenceNumber();
    viewServiceAuthorizationDetails.serviceAuthorizationDetails.clientReferenceNumber = client.getPrimaryAlternateID();
    viewServiceAuthorizationDetails.serviceAuthorizationDetails.clientName = client.getName();
    viewServiceAuthorizationDetails.serviceAuthorizationDetails.creationDate = serviceAuthorizationObj.getCreationDate();
    viewServiceAuthorizationDetails.serviceAuthorizationDetails.derivedStatus = serviceAuthorizationObj.getDerivedStatus();

    viewServiceAuthorizationDetails.contextDescription.description = serviceAuthorizationObj.getReferenceNumber();

    viewServiceAuthorizationDetails.serviceAuthorization.caseID = serviceAuthorizationObj.getCaseID();
    viewServiceAuthorizationDetails.serviceAuthorization.caseParticipantRoleID = serviceAuthorizationObj.getCaseParticipantRoleID();
    viewServiceAuthorizationDetails.serviceAuthorization.concernRoleID = serviceAuthorizationObj.getConcernRoleID();
    viewServiceAuthorizationDetails.serviceAuthorization.creationDate = serviceAuthorizationObj.getCreationDate();
    viewServiceAuthorizationDetails.serviceAuthorization.recordStatus = serviceAuthorizationObj.getRecordStatus();
    viewServiceAuthorizationDetails.serviceAuthorization.referenceNo = serviceAuthorizationObj.getReferenceNumber();
    viewServiceAuthorizationDetails.serviceAuthorization.serviceAuthorizationID = serviceAuthorizationObj.getID();
    viewServiceAuthorizationDetails.serviceAuthorization.caseParticipantRoleID = serviceAuthorizationObj.getCaseParticipantRoleID();

    return viewServiceAuthorizationDetails;

  }

  /**
   * This method is used to list all the service authorization line items of a
   * service authorization with their details.
   *
   * @param serviceAuthorizationKey
   * Service Authorization ID.
   *
   * @return The list of Service Authorization Line Item details associated with
   * the Service Authorization ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServiceAuthorization#listSALI(ServiceAuthorizationKey)}
   * In order to display the 'Units Remaining' field which has to be
   * shown as 'Unlimited' when it is blank, this method has been
   * replaced with a new method to return a different struct. See
   * release note: CR00228769.
   */
  public ViewServiceAuthorizationLineItemDetailsList listServiceAuthorizationLineItem(
    ServiceAuthorizationKey serviceAuthorizationKey) throws AppException,
      InformationalException {

    ViewServiceAuthorizationLineItemDetailsList viewServiceAuthorizationLineItemDetailsList = new ViewServiceAuthorizationLineItemDetailsList();

    final curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorizationObj = serviceAuthorizationDAO.get(
      serviceAuthorizationKey.serviceAuthorizationID);

    final Set<curam.serviceauthorization.impl.ServiceAuthorizationLineItem> serviceAuthorizationLineItems = serviceAuthorizationLineItemDAO.searchByServiceAuthorization(
      serviceAuthorizationObj);

    ServiceAuthorizationLineItemDetails serviceAuthorizationLineItemDetails;

    for (final ServiceAuthorizationLineItem serviceAuthorizationLineItem : serviceAuthorizationLineItems) {
      serviceAuthorizationLineItemDetails = new ServiceAuthorizationLineItemDetails();
      serviceAuthorizationLineItemDetails.ServiceAuthorizationLineItemID = serviceAuthorizationLineItem.getID();
      serviceAuthorizationLineItemDetails.fromDate = serviceAuthorizationLineItem.getDateRange().start();
      serviceAuthorizationLineItemDetails.dateAdded = serviceAuthorizationLineItem.getDateAdded();
      serviceAuthorizationLineItemDetails.toDate = serviceAuthorizationLineItem.getDateRange().end();
      // BEGIN, CR00096779, ABS
      serviceAuthorizationLineItemDetails.unitsAuthorized = CPMConstants.kEmptyString
        + serviceAuthorizationLineItem.getUnitsAuthorized();
      // END, CR00096779
      serviceAuthorizationLineItemDetails.status = serviceAuthorizationLineItem.getDerivedStatus();
      serviceAuthorizationLineItemDetails.remainingUints = (int) (serviceAuthorizationLineItem.getUnitsAuthorized()
        - serviceAuthorizationLineItem.getUnitsConsumed());
      serviceAuthorizationLineItemDetails.serviceName = serviceAuthorizationLineItem.getServiceOffering().getName();
      serviceAuthorizationLineItemDetails.maximumUnitFrequency = serviceAuthorizationLineItem.getMaximumUnitsFrequency();
      serviceAuthorizationLineItemDetails.maximumUnits = String.valueOf(
        serviceAuthorizationLineItem.getMaximumUnits());
      if (serviceAuthorizationLineItem.getProvider() != null) {
        serviceAuthorizationLineItemDetails.providerID = serviceAuthorizationLineItem.getProvider().getID();
      }

      serviceAuthorizationLineItemDetails.serviceAuthorizationID = serviceAuthorizationLineItem.getServiceAuthorization().getID();
      serviceAuthorizationLineItemDetails.serviceID = serviceAuthorizationLineItem.getServiceOffering().getID();
      serviceAuthorizationLineItemDetails.totalCost = Double.toString(
        serviceAuthorizationLineItem.getTotalCost().getValue());
      // BEGIN, CR00142003, ABS
      if (serviceAuthorizationLineItem.getUnitAmount() != null) {
        serviceAuthorizationLineItemDetails.unitAmount = serviceAuthorizationLineItem.getUnitAmount();
      }
      // END, CR00142003

      viewServiceAuthorizationLineItemDetailsList.serviceAuthorizationLineItemDetails.addRef(
        serviceAuthorizationLineItemDetails);
    }

    return sortServiceAuthorizationLineItemDetails(
      viewServiceAuthorizationLineItemDetailsList);
  }

  /**
   * Reads the service authorization line item details for the given service
   * authorization line item ID.
   *
   * @param serviceAuthorizationLineItemKey
   * Service Authorization Line Item ID.
   *
   * @return The Service Authorization Line Item details and related Service
   * Invoice Line Item List details which associated with the Service
   * Invoice Line Item ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServiceAuthorization#viewSALIDetails(ServiceAuthorizationLineItemKey)}
   * In order to display the 'Units Remaining' field which has to be
   * shown as 'Unlimited' when it is blank, this method has been
   * replaced with a new method to return a different struct. See
   * release note: CR00228769.
   */
  @Deprecated
  public ViewServiceAuthorizationLineItemDetails viewServiceAuthorizationLineItemDetails(
    ServiceAuthorizationLineItemKey serviceAuthorizationLineItemKey)
    throws AppException, InformationalException {

    ViewServiceAuthorizationLineItemDetails viewServiceAuthorizationLineItemDetails = new ViewServiceAuthorizationLineItemDetails();

    final curam.serviceauthorization.impl.ServiceAuthorizationLineItem serviceAuthorizationDetailsLineItem = serviceAuthorizationLineItemDAO.get(
      serviceAuthorizationLineItemKey.serviceAuthorizationLIID);
    // BEGIN, CR00116920, SSH
    final curam.core.intf.ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    // END, CR00116920

    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.serviceAuthorizationID = serviceAuthorizationDetailsLineItem.getServiceAuthorization().getID();
    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.ServiceAuthorizationLineItemID = serviceAuthorizationDetailsLineItem.getID();
    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.fromDate = serviceAuthorizationDetailsLineItem.getDateRange().start();
    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.toDate = serviceAuthorizationDetailsLineItem.getDateRange().end();
    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.dateAdded = serviceAuthorizationDetailsLineItem.getDateAdded();
    // BEGIN, CR00096779, ABS
    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.unitsAuthorized = CPMConstants.kEmptyString
      + serviceAuthorizationDetailsLineItem.getUnitsAuthorized();
    // END, CR00096779
    // BEGIN, CR00118204, SG
    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.providerType = serviceAuthorizationDetailsLineItem.getProviderType().getCode();
    // END, CR00118204
    // BEGIN, CR00142003, ABS
    if (serviceAuthorizationDetailsLineItem.getUnitAmount() != null) {
      viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.unitAmount = serviceAuthorizationDetailsLineItem.getUnitAmount();
    }
    // END, CR00142003
    if (serviceAuthorizationDetailsLineItem.getMaximumUnitsFrequency() != null
      && (!serviceAuthorizationDetailsLineItem.getMaximumUnitsFrequency().equals(
        ""))) {
      viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.maximumUnits = // BEGIN, CR00096779, ABS
        CPMConstants.kEmptyString
        + serviceAuthorizationDetailsLineItem.getMaximumUnits();
      // END, CR00096779
    }

    // BEGIN, CR00116240, SSH
    // BEGIN, CR00116920, SSH
    // BEGIN, CR00118201, SSH
    // BEGIN, CR00129927, ABS
    if (serviceAuthorizationDetailsLineItem.getNominee().concernRoleID
      != CPMConstants.kZeroLong) {
      // END, CR00129927
      viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.nomineeID = serviceAuthorizationDetailsLineItem.getNominee().concernRoleID;

      concernRoleKey.concernRoleID = viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.nomineeID;

      concernRoleDtls.assign(concernRoleObj.read(concernRoleKey));
      viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.nomineeReference = concernRoleDtls.primaryAlternateID;
      // END, CR00118201

      viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.nomineeName = concernRoleDtls.concernRoleName;
    }
    // END, CR00116920
    // END, CR00116240
    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.maximumUnitFrequency = serviceAuthorizationDetailsLineItem.getMaximumUnitsFrequency();
    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.serviceName = serviceAuthorizationDetailsLineItem.getServiceOffering().getName();
    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.serviceID = serviceAuthorizationDetailsLineItem.getServiceOffering().getID();
    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.status = serviceAuthorizationDetailsLineItem.getDerivedStatus();
    if (serviceAuthorizationDetailsLineItem.getTotalCost().getValue() > 0) {
      viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.totalCost = serviceAuthorizationDetailsLineItem.getTotalCost().toString();
    }

    if (serviceAuthorizationDetailsLineItem.getProvider() != null) {
      viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.providerName = serviceAuthorizationDetailsLineItem.getProvider().getName();
      viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.providerID = serviceAuthorizationDetailsLineItem.getProvider().getID();
    }

    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.unitsAmountFixedInd = serviceAuthorizationDetailsLineItem.isUnitAmountFixed();

    // Get Related service invoice line item details
    viewServiceAuthorizationLineItemDetails.relatedServiceInvoiceLineItemInformationDetailsList = viewRelatedServiceInvoiceLineItemInformation(
      serviceAuthorizationLineItemKey);

    // BEGIN, CR00123231, RPB
    ServiceAuthorizationLineItem sali = serviceAuthorizationLineItemDAO.get(
      serviceAuthorizationLineItemKey.serviceAuthorizationLIID);
    Set<ProviderRosterLineItem> prliSet = sali.getRelatedRosterLineItem();

    for (ProviderRosterLineItem prli : prliSet) {
      RelatedPRLIDetails relatedPrliDetails = new RelatedPRLIDetails();

      relatedPrliDetails.actualUnits = prli.getUnitsDelivered().toString();
      relatedPrliDetails.serviceFrom = prli.getServiceDateFrom();
      relatedPrliDetails.serviceTo = prli.getServiceDateTo();
      relatedPrliDetails.status = prli.getLifecycleState().getCode();
      relatedPrliDetails.amountPaid = attendancePaymentProcessing.getPaymentAmountForProviderRosterLineItem(
        prli);
      relatedPrliDetails.prliId = prli.getID();
      if (prli.getProvider() != null) {
        relatedPrliDetails.concernRoleId = prli.getProvider().getID();
      }
      viewServiceAuthorizationLineItemDetails.relatedPRLIDetailsList.addRef(
        relatedPrliDetails);
    }

    // END, CR00123231


    // Add remaining units to service authorization from total units
    // consumed
    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.remainingUints = (int) (serviceAuthorizationDetailsLineItem.getUnitsAuthorized()
      - serviceAuthorizationDetailsLineItem.getUnitsConsumed());

    // BEGIN, CR00227661, RPB
    viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.remainingUints = (serviceAuthorizationDetailsLineItem.getUnitsRemaining());
    // END, CR00227661

    final curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorizationDetails = serviceAuthorizationDAO.get(
      serviceAuthorizationDetailsLineItem.getServiceAuthorization().getID());

    viewServiceAuthorizationLineItemDetails.contextDescription.description = serviceAuthorizationDetails.getReferenceNumber()
      + CuramConst.kSeparator
      + viewServiceAuthorizationLineItemDetails.serviceAuthorizationLineItemDetails.serviceName;

    return viewServiceAuthorizationLineItemDetails;
  }

  /**
   * Lists all the Service Authorizations created for the client and the case.
   *
   * @param concernRoleAndCaseIDKey
   * Contains caseID and concernRoleID.
   *
   * @return The list of Service Authorization details which related with CaseID
   * and ConcernRoleID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceAuthorizationDetailsList listServiceAuthorizationForConcernRoleIDAndCaseID(
    ConcernRoleAndCaseIDKey concernRoleAndCaseIDKey) throws AppException,
      InformationalException {

    ServiceAuthorizationDetailsList serviceAuthorizationDetailsList = new ServiceAuthorizationDetailsList();

    final Set<curam.serviceauthorization.impl.ServiceAuthorization> serviceAuthorizations = serviceAuthorizationDAO.searchByConcernRoleIDAndCaseID(
      concernRoleAndCaseIDKey);

    for (final curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization : serviceAuthorizations) {
      serviceAuthorizationDetailsList.serviceAuthorizationDetails.addRef(
        getServiceAuthorizationFields(serviceAuthorization));
    }

    return serviceAuthorizationDetailsList;
  }

  /**
   * Lists all the Service Authorizations created for a given Case Participant
   * ID (i.e. for a client and case).
   *
   * @param caseParticipantRoleKey
   * Contains caseID and concernRoleID.
   *
   * @return The list of Service Authorization details which is related with the
   * caseID and concernRoleID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceAuthorizationDetailsList listServiceAuthorizationForCaseParticipantRoleID(
    CaseParticipantRoleKey caseParticipantRoleKey) throws AppException,
      InformationalException {

    ServiceAuthorizationDetailsList serviceAuthorizationDetailsList = new ServiceAuthorizationDetailsList();

    final Set<curam.serviceauthorization.impl.ServiceAuthorization> serviceAuthorizations = serviceAuthorizationDAO.searchByCaseParticipantRoleID(
      caseParticipantRoleKey);

    for (final curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization : serviceAuthorizations) {
      serviceAuthorizationDetailsList.serviceAuthorizationDetails.addRef(
        getServiceAuthorizationFields(serviceAuthorization));
    }

    return serviceAuthorizationDetailsList;
  }

  /**
   * Lists the history of changes made to the Service Authorization Line Item
   * for the given Service Authorization Line Item ID.
   *
   * @param serviceAuthorizationLineItemKey
   * Contains service authorization line item ID.
   *
   * @return The list of historical information of Service Authorization Line
   * Item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceAuthorizationLineItemStatusHistoryList serviceAuthorizationLineItemStatusHistoryList(
    ServiceAuthorizationLineItemKey serviceAuthorizationLineItemKey)
    throws AppException, InformationalException {

    ServiceAuthorizationLineItemStatusHistoryList serviceAuthorizationLineItemStatusHistoryList = new ServiceAuthorizationLineItemStatusHistoryList();

    final curam.serviceauthorization.impl.ServiceAuthorizationLineItem serviceAuthorizationDetailsLineItem = serviceAuthorizationLineItemDAO.get(
      serviceAuthorizationLineItemKey.serviceAuthorizationLIID);

    final Set<ServiceAuthorizationLineItemHistory> serviceAuthorizationLIHistoryList = serviceAuthorizationLIHistoryDAO.searchBy(
      serviceAuthorizationDetailsLineItem);
    ServiceAuthorizationLineItemStatusHistory serviceAuthorizationLineItemStatusHistory;

    for (final ServiceAuthorizationLineItemHistory serviceAuthorizationLIHistroy : serviceAuthorizationLIHistoryList) {

      serviceAuthorizationLineItemStatusHistory = new ServiceAuthorizationLineItemStatusHistory();
      serviceAuthorizationLineItemStatusHistory.dateTimeChanged = serviceAuthorizationLIHistroy.getDateTimeChanged();
      serviceAuthorizationLineItemStatusHistory.modificationReason = serviceAuthorizationLIHistroy.getModificationReason();
      serviceAuthorizationLineItemStatusHistory.unitsAuthorized = serviceAuthorizationLIHistroy.getUnitsAuthorized();
      serviceAuthorizationLineItemStatusHistory.unitAmount = serviceAuthorizationLIHistroy.getUnitAmount();
      serviceAuthorizationLineItemStatusHistory.fromDate = serviceAuthorizationLIHistroy.getDateRange().start();
      serviceAuthorizationLineItemStatusHistory.toDate = serviceAuthorizationLIHistroy.getDateRange().end();

      serviceAuthorizationLineItemStatusHistoryList.details.addRef(
        serviceAuthorizationLineItemStatusHistory);
    }

    return serviceAuthorizationLineItemStatusHistoryList;
  }

  /**
   * Lists all the Service Invoice Line Items which are created for a Service
   * Authorization Line Item given the Service Authorization Line Item ID.
   *
   * @param serviceAuthorizationLineItemKey
   * Contains service authorization line item ID.
   *
   * @return The list of related Service Invoice Line item which is related to
   * Service Authorization Line Item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RelatedServiceInvoiceLineItemInformationDetailsList viewRelatedServiceInvoiceLineItemInformation(
    ServiceAuthorizationLineItemKey serviceAuthorizationLineItemKey)
    throws AppException, InformationalException {

    RelatedServiceInvoiceLineItemInformationDetailsList relatedServiceInvoiceLineItemInformationDetailsList = new RelatedServiceInvoiceLineItemInformationDetailsList();

    final curam.serviceauthorization.impl.ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceAuthorizationLineItemDAO.get(
      serviceAuthorizationLineItemKey.serviceAuthorizationLIID);

    RelatedServiceInvoiceLineItemInformationDetails relatedServiceInvoiceLineItemInformationDetails;

    final Set<curam.financial.impl.ServiceInvoiceLineItem> serviceInvoiceLineItems = serviceInvoiceLineItemDAO.searchByServiceAuthorizationLineItem(
      serviceAuthorizationLineItem);

    for (final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem : serviceInvoiceLineItems) {
      relatedServiceInvoiceLineItemInformationDetails = new RelatedServiceInvoiceLineItemInformationDetails();

      relatedServiceInvoiceLineItemInformationDetails.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
      relatedServiceInvoiceLineItemInformationDetails.referenceNumber = serviceInvoiceLineItem.getReferenceNumber();
      relatedServiceInvoiceLineItemInformationDetails.numberofUnits = serviceInvoiceLineItem.getNumberOfUnits();
      relatedServiceInvoiceLineItemInformationDetails.amountInvoiced = serviceInvoiceLineItem.getAmountInvoiced();
      relatedServiceInvoiceLineItemInformationDetails.status = serviceInvoiceLineItem.getStatus().toString();
      relatedServiceInvoiceLineItemInformationDetailsList.relatedServiceInvoiceLineItemInformationDetails.addRef(
        relatedServiceInvoiceLineItemInformationDetails);

      double amountPaid = 0;

      // BEGIN, CR00085040, GYH
      // Populate the calculated amount to amountPaid when
      // status of the service invoice line item is not CANCELED/DENIED.
      if (!relatedServiceInvoiceLineItemInformationDetails.status.equals(
        ServiceInvoiceLineItemStatusEntry.CANCELED.toString())
          && !relatedServiceInvoiceLineItemInformationDetails.status.equals(
            ServiceInvoiceLineItemStatusEntry.DENIED.toString())) {
        // END, CR00085040
        for (ServiceInvoiceLineItemTransaction transaction : serviceInvoiceLineItem.getTransactions()) {
          // BEGIN, CR00225358, RPB
          if (transaction.getTransactionType().equals(
            ServiceInvoiceLineItemTransactionTypeEntry.PAID)
              && transaction.getStatus().equals(
                ServiceInvoiceLineItemTransactionStatusEntry.ACTIVE)) {
            // END, CR00225358
            amountPaid += transaction.getAmount().getValue();
          }
        }
        // BEGIN, CR00085040, GYH
      }
      // END, CR00085040
      relatedServiceInvoiceLineItemInformationDetails.amountPaid = new Money(
        amountPaid);
    }

    return relatedServiceInvoiceLineItemInformationDetailsList;

  }

  /**
   * Reads the budget information of a Service Authorization given the Service
   * Authorization ID.
   *
   * @param serviceAuthorizationKey
   * Contains Service Authorization ID.
   *
   * @return The Service Authorization budget information related to the Service
   * Authorization ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewBudgetInformation viewServiceAuthorizationBudgetInformation(
    ServiceAuthorizationKey serviceAuthorizationKey) throws AppException,
      InformationalException {

    ViewBudgetInformation viewBudgetInformation = new ViewBudgetInformation();
    BudgetInformation budgetInformation = new BudgetInformation();

    double totalBilled = 0;
    long unitsConsumed = 0;
    ActualServiceDeliveryDetails actualServiceDeliveryDetails = new ActualServiceDeliveryDetails();

    final curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.get(
      serviceAuthorizationKey.serviceAuthorizationID);

    final Set<curam.serviceauthorization.impl.ServiceAuthorizationLineItem> serviceAuthorizationLineItems = serviceAuthorizationLineItemDAO.searchByServiceAuthorization(
      serviceAuthorization);

    for (final curam.serviceauthorization.impl.ServiceAuthorizationLineItem serviceAuthorizationLineItem : serviceAuthorizationLineItems) {

      final Set<curam.financial.impl.ServiceInvoiceLineItem> serviceInvoiceLineItems = serviceInvoiceLineItemDAO.searchByServiceAuthorizationLineItem(
        serviceAuthorizationLineItem);

      for (final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem : serviceInvoiceLineItems) {

        if (serviceInvoiceLineItem.getStatus().getCode().equals(
          curam.financial.ServiceInvoiceLineItemStatus.COMPLETE)) {
          totalBilled += serviceInvoiceLineItem.getAmountInvoiced().getValue();
          unitsConsumed += serviceInvoiceLineItem.getNumberOfUnits();
        }
      }

      budgetInformation = new BudgetInformation();
      budgetInformation.serviceName = serviceAuthorizationLineItem.getServiceOffering().getName();
      budgetInformation.unitsAuthorized = serviceAuthorizationLineItem.getUnitsAuthorized();
      budgetInformation.unitCost = serviceAuthorizationLineItem.getUnitAmount();
      budgetInformation.totaCost = serviceAuthorizationLineItem.getTotalCost();
      actualServiceDeliveryDetails.totalBilled = new Money(totalBilled);
      actualServiceDeliveryDetails.unitsConsumed = unitsConsumed;
      budgetInformation.actualServiceDeliveryDetails = actualServiceDeliveryDetails;
      totalBilled = 0;
      unitsConsumed = 0;

      viewBudgetInformation.budgetInformation.addRef(budgetInformation);

    }

    return viewBudgetInformation;
  }

  /**
   * Lists all the Service Authorizations created till date.
   *
   * @return The list of Service Authorization details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceAuthorizationDetailsList listServiceAuthorization()
    throws AppException, InformationalException {

    ServiceAuthorizationDetailsList serviceAuthorizationDetailsList = new ServiceAuthorizationDetailsList();

    final Set<curam.serviceauthorization.impl.ServiceAuthorization> serviceAuthorizations = serviceAuthorizationDAO.readAll();

    for (final curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization : serviceAuthorizations) {
      serviceAuthorizationDetailsList.serviceAuthorizationDetails.addRef(
        getServiceAuthorizationFields(serviceAuthorization));
    }

    return serviceAuthorizationDetailsList;
  }

  // BEGIN, CR00154438, ABS
  /**
   * Reads the service authorization details for the given service authorization
   * ID for multiple clients.
   *
   * @param serviceAuthorizationKey
   * Service Authorization ID.
   *
   * @return The Service authorization details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceAuthorizationMultipleClientDetails viewServiceAuthorizationMultipleClientDetails(
    ServiceAuthorizationKey serviceAuthorizationKey) throws AppException,
      InformationalException {

    ServiceAuthorizationMultipleClientDetails viewServiceAuthorizationDetails = new ServiceAuthorizationMultipleClientDetails();

    final curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorizationObj = serviceAuthorizationDAO.get(
      serviceAuthorizationKey.serviceAuthorizationID);

    final ConcernRole client = serviceAuthorizationObj.getClient();

    if (serviceAuthorizationObj.getConcernRoles().size() > 1) {

      // BEGIN, CR00155384, ABS
      viewServiceAuthorizationDetails.multipleClientsInd = true;

      List<ConcernRole> concernRoleList = sortConcernRole(
        serviceAuthorizationObj.getConcernRoles());

      for (ConcernRole concernRole : concernRoleList) {
        // END, CR00155384

        ServiceAuthorizationClientDetails authorizationClientDetails = new ServiceAuthorizationClientDetails();

        authorizationClientDetails.clientName = concernRole.getName();

        authorizationClientDetails.clientReferenceNumber = concernRole.getPrimaryAlternateID();

        viewServiceAuthorizationDetails.clientList.clientDetails.addRef(
          authorizationClientDetails);
      }
    }

    viewServiceAuthorizationDetails.serviceAuthorizationDetails.serviceAuthorizationID = serviceAuthorizationObj.getID();
    viewServiceAuthorizationDetails.serviceAuthorizationDetails.referenceNumber = serviceAuthorizationObj.getReferenceNumber();
    viewServiceAuthorizationDetails.serviceAuthorizationDetails.caseReferenceNumber = serviceAuthorizationObj.getCaseReferenceNumber();
    viewServiceAuthorizationDetails.serviceAuthorizationDetails.clientReferenceNumber = client.getPrimaryAlternateID();
    viewServiceAuthorizationDetails.serviceAuthorizationDetails.clientName = client.getName();
    viewServiceAuthorizationDetails.serviceAuthorizationDetails.creationDate = serviceAuthorizationObj.getCreationDate();
    viewServiceAuthorizationDetails.serviceAuthorizationDetails.derivedStatus = serviceAuthorizationObj.getDerivedStatus();

    viewServiceAuthorizationDetails.contextDescription.description = serviceAuthorizationObj.getReferenceNumber();

    viewServiceAuthorizationDetails.serviceAuthorization.caseID = serviceAuthorizationObj.getCaseID();
    viewServiceAuthorizationDetails.serviceAuthorization.caseParticipantRoleID = serviceAuthorizationObj.getCaseParticipantRoleID();
    viewServiceAuthorizationDetails.serviceAuthorization.concernRoleID = serviceAuthorizationObj.getConcernRoleID();
    viewServiceAuthorizationDetails.serviceAuthorization.creationDate = serviceAuthorizationObj.getCreationDate();
    viewServiceAuthorizationDetails.serviceAuthorization.recordStatus = serviceAuthorizationObj.getRecordStatus();
    viewServiceAuthorizationDetails.serviceAuthorization.referenceNo = serviceAuthorizationObj.getReferenceNumber();
    viewServiceAuthorizationDetails.serviceAuthorization.serviceAuthorizationID = serviceAuthorizationObj.getID();
    viewServiceAuthorizationDetails.serviceAuthorization.caseParticipantRoleID = serviceAuthorizationObj.getCaseParticipantRoleID();

    return viewServiceAuthorizationDetails;

  }

  // END, CR00154438

  // BEGIN, CR00228769, RPB
  /**
   * This method is used to list all the service authorization line items of a
   * service authorization with their details.
   *
   * @param serviceAuthorizationKey
   * Service Authorization ID.
   *
   * @return The list of Service Authorization Line Item details associated with
   * the Service Authorization ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewSALIDetailsList listSALI(
    final ServiceAuthorizationKey serviceAuthorizationKey)
    throws AppException, InformationalException {

    ViewSALIDetailsList viewSALIDetailsList = new ViewSALIDetailsList();

    final curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorizationObj = serviceAuthorizationDAO.get(
      serviceAuthorizationKey.serviceAuthorizationID);

    final Set<curam.serviceauthorization.impl.ServiceAuthorizationLineItem> serviceAuthorizationLineItems = serviceAuthorizationLineItemDAO.searchByServiceAuthorization(
      serviceAuthorizationObj);

    SALIDetails saliDetails;

    for (final ServiceAuthorizationLineItem serviceAuthorizationLineItem : serviceAuthorizationLineItems) {
      saliDetails = new SALIDetails();
      saliDetails.serviceAuthorizationLineItemDetails.ServiceAuthorizationLineItemID = serviceAuthorizationLineItem.getID();
      saliDetails.serviceAuthorizationLineItemDetails.fromDate = serviceAuthorizationLineItem.getDateRange().start();
      saliDetails.serviceAuthorizationLineItemDetails.dateAdded = serviceAuthorizationLineItem.getDateAdded();
      saliDetails.serviceAuthorizationLineItemDetails.toDate = serviceAuthorizationLineItem.getDateRange().end();

      // BEGIN, CR00237055, RPB
      if (-1 == serviceAuthorizationLineItem.getUnitsAuthorized()) {
        saliDetails.serviceAuthorizationLineItemDetails.unitsAuthorized = new LocalisableString(curam.message.SERVICEAUTHORIZATION.TEXT_SALI_UNITS_UNLIMITED).getMessage();
      } // END, CR00237055
      else {
        saliDetails.serviceAuthorizationLineItemDetails.unitsAuthorized = CPMConstants.kEmptyString
          + serviceAuthorizationLineItem.getUnitsAuthorized();
      }

      saliDetails.serviceAuthorizationLineItemDetails.status = serviceAuthorizationLineItem.getDerivedStatus();

      saliDetails.serviceAuthorizationLineItemDetails.remainingUints = (int) (serviceAuthorizationLineItem.getUnitsAuthorized()
        - serviceAuthorizationLineItem.getUnitsConsumed());

      // BEGIN, CR00235947, RPB
      if (-1 == serviceAuthorizationLineItem.getUnitsRemaining()) {
        saliDetails.unitsRemainingString = CPMConstants.kEmptyString;
      } else {
        // BEGIN, CR00291750, SSK
        if (-1 != serviceAuthorizationLineItem.getUnitsAuthorized() 
          && null != serviceAuthorizationLineItem.getServiceOffering()
          && serviceAuthorizationLineItem.getServiceOffering().isPayBasedOnAttendance()) {
          Set<PRLISALILink> prliSaliLinkList = prliSaliDAO.searchByServiceAuthorizationLineItem(
            serviceAuthorizationLineItem);
              
          Integer unitsRemaining = 0;

          for (final PRLISALILink prliSaliLink : prliSaliLinkList) {
            unitsRemaining += prliSaliLink.getRemainingUnits();
          }
          // BEGIN, CR00291750, SSK
          if (0 == prliSaliLinkList.size()) {
            saliDetails.unitsRemainingString = serviceAuthorizationLineItem.getUnitsAuthorized().toString();
          } else {
            saliDetails.unitsRemainingString = unitsRemaining.toString(); 
          }
          // END, CR00291750
        } // END, CR00291750
        else {

          saliDetails.unitsRemainingString = serviceAuthorizationLineItem.getUnitsRemaining().toString();
        }
      }
      // END, CR00235947

      saliDetails.serviceAuthorizationLineItemDetails.serviceName = serviceAuthorizationLineItem.getServiceOffering().getName();
      saliDetails.serviceAuthorizationLineItemDetails.maximumUnitFrequency = serviceAuthorizationLineItem.getMaximumUnitsFrequency();
      saliDetails.serviceAuthorizationLineItemDetails.maximumUnits = String.valueOf(
        serviceAuthorizationLineItem.getMaximumUnits());
      if (serviceAuthorizationLineItem.getProvider() != null) {
        saliDetails.serviceAuthorizationLineItemDetails.providerID = serviceAuthorizationLineItem.getProvider().getID();
      }

      saliDetails.serviceAuthorizationLineItemDetails.serviceAuthorizationID = serviceAuthorizationLineItem.getServiceAuthorization().getID();
      saliDetails.serviceAuthorizationLineItemDetails.serviceID = serviceAuthorizationLineItem.getServiceOffering().getID();
      saliDetails.serviceAuthorizationLineItemDetails.totalCost = Double.toString(
        serviceAuthorizationLineItem.getTotalCost().getValue());

      if (serviceAuthorizationLineItem.getUnitAmount() != null) {
        saliDetails.serviceAuthorizationLineItemDetails.unitAmount = serviceAuthorizationLineItem.getUnitAmount();
      }

      viewSALIDetailsList.saliDetails.addRef(saliDetails);

    }
    return sortSALIDetails(viewSALIDetailsList);
  }

  /**
   * Reads the service authorization line item details for the given service
   * authorization line item ID.
   *
   * @param serviceAuthorizationLineItemKey
   * Service Authorization Line Item ID.
   *
   * @return The Service Authorization Line Item details and related Service
   * Invoice Line Item List details which associated with the Service
   * Invoice Line Item ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewSALIDetails viewSALIDetails(
    final ServiceAuthorizationLineItemKey serviceAuthorizationLineItemKey)
    throws AppException, InformationalException {

    ViewSALIDetails viewSALIDetails = new ViewSALIDetails();

    final curam.serviceauthorization.impl.ServiceAuthorizationLineItem serviceAuthorizationDetailsLineItem = serviceAuthorizationLineItemDAO.get(
      serviceAuthorizationLineItemKey.serviceAuthorizationLIID);

    final curam.core.intf.ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.serviceAuthorizationID = serviceAuthorizationDetailsLineItem.getServiceAuthorization().getID();
    viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.ServiceAuthorizationLineItemID = serviceAuthorizationDetailsLineItem.getID();
    viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.fromDate = serviceAuthorizationDetailsLineItem.getDateRange().start();
    viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.toDate = serviceAuthorizationDetailsLineItem.getDateRange().end();
    viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.dateAdded = serviceAuthorizationDetailsLineItem.getDateAdded();

    // BEGIN, CR00237055, RPB
    if (-1 == serviceAuthorizationDetailsLineItem.getUnitsAuthorized()) {
      viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.unitsAuthorized = new LocalisableString(curam.message.SERVICEAUTHORIZATION.TEXT_SALI_UNITS_UNLIMITED).getMessage();
    } // END, CR00237055
    else {
      viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.unitsAuthorized = CPMConstants.kEmptyString
        + serviceAuthorizationDetailsLineItem.getUnitsAuthorized();
    }

    viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.providerType = serviceAuthorizationDetailsLineItem.getProviderType().getCode();

    if (serviceAuthorizationDetailsLineItem.getUnitAmount() != null) {
      viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.unitAmount = serviceAuthorizationDetailsLineItem.getUnitAmount();
    }

    if (serviceAuthorizationDetailsLineItem.getMaximumUnitsFrequency() != null
      && (!serviceAuthorizationDetailsLineItem.getMaximumUnitsFrequency().equals(
        ""))) {
      viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.maximumUnits = CPMConstants.kEmptyString
        + serviceAuthorizationDetailsLineItem.getMaximumUnits();
    }

    if (serviceAuthorizationDetailsLineItem.getNominee().concernRoleID
      != CPMConstants.kZeroLong) {

      viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.nomineeID = serviceAuthorizationDetailsLineItem.getNominee().concernRoleID;

      concernRoleKey.concernRoleID = viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.nomineeID;

      concernRoleDtls.assign(concernRoleObj.read(concernRoleKey));
      viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.nomineeReference = concernRoleDtls.primaryAlternateID;

      viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.nomineeName = concernRoleDtls.concernRoleName;
    }

    viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.maximumUnitFrequency = serviceAuthorizationDetailsLineItem.getMaximumUnitsFrequency();
    viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.serviceName = serviceAuthorizationDetailsLineItem.getServiceOffering().getName();
    viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.serviceID = serviceAuthorizationDetailsLineItem.getServiceOffering().getID();
    viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.status = serviceAuthorizationDetailsLineItem.getDerivedStatus();
    if (serviceAuthorizationDetailsLineItem.getTotalCost().getValue() > 0) {
      viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.totalCost = serviceAuthorizationDetailsLineItem.getTotalCost().toString();
    }

    if (serviceAuthorizationDetailsLineItem.getProvider() != null) {
      viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.providerName = serviceAuthorizationDetailsLineItem.getProvider().getName();
      viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.providerID = serviceAuthorizationDetailsLineItem.getProvider().getID();
    }

    viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.unitsAmountFixedInd = serviceAuthorizationDetailsLineItem.isUnitAmountFixed();

    viewSALIDetails.saliDetails.relatedServiceInvoiceLineItemInformationDetailsList = viewRelatedServiceInvoiceLineItemInformation(
      serviceAuthorizationLineItemKey);

    ServiceAuthorizationLineItem sali = serviceAuthorizationLineItemDAO.get(
      serviceAuthorizationLineItemKey.serviceAuthorizationLIID);
    Set<ProviderRosterLineItem> prliSet = sali.getRelatedRosterLineItem();

    for (ProviderRosterLineItem prli : prliSet) {
      RelatedPRLIDetails relatedPrliDetails = new RelatedPRLIDetails();

      relatedPrliDetails.actualUnits = prli.getUnitsDelivered().toString();
      relatedPrliDetails.serviceFrom = prli.getServiceDateFrom();
      relatedPrliDetails.serviceTo = prli.getServiceDateTo();
      relatedPrliDetails.status = prli.getLifecycleState().getCode();
      relatedPrliDetails.amountPaid = attendancePaymentProcessing.getPaymentAmountForProviderRosterLineItem(
        prli);
      relatedPrliDetails.prliId = prli.getID();
      if (prli.getProvider() != null) {
        relatedPrliDetails.concernRoleId = prli.getProvider().getID();
      }
      viewSALIDetails.saliDetails.relatedPRLIDetailsList.addRef(
        relatedPrliDetails);
    }

    // Add remaining units to service authorization from total units
    // consumed.

    // BEGIN, CR00235947, RPB
    if (-1 == serviceAuthorizationDetailsLineItem.getUnitsRemaining()) {
      viewSALIDetails.unitsRemainingString = CPMConstants.kEmptyString;
    } else {
      viewSALIDetails.unitsRemainingString = serviceAuthorizationDetailsLineItem.getUnitsRemaining().toString();
    }
    // END, CR00235947

    final curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorizationDetails = serviceAuthorizationDAO.get(
      serviceAuthorizationDetailsLineItem.getServiceAuthorization().getID());

    viewSALIDetails.saliDetails.contextDescription.description = serviceAuthorizationDetails.getReferenceNumber()
      + CuramConst.kSeparator
      + viewSALIDetails.saliDetails.serviceAuthorizationLineItemDetails.serviceName;

    return viewSALIDetails;
  }

  // END, CR00228769

  /**
   * Sorts a set of Service Authorization Line Items into a sorted list for
   * display.
   *
   * @param unsortedServiceAuthLineItems
   * Set of unsorted Service Authorization Line Items.
   *
   * @return The list of Service Authorization Line Item details sorted by name.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  protected ViewServiceAuthorizationLineItemDetailsList sortServiceAuthorizationLineItemDetails(
    ViewServiceAuthorizationLineItemDetailsList unsortedServiceAuthLineItems) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    List<ServiceAuthorizationLineItemDetails> serviceAuthLineItemDetailsList = new ArrayList<ServiceAuthorizationLineItemDetails>();
    int noOfServiceAuthLineItems = unsortedServiceAuthLineItems.serviceAuthorizationLineItemDetails.size();

    for (int i = 0; i < noOfServiceAuthLineItems; i++) {
      serviceAuthLineItemDetailsList.add(
        unsortedServiceAuthLineItems.serviceAuthorizationLineItemDetails.item(i));
    }

    Collections.sort(serviceAuthLineItemDetailsList,
      new Comparator<ServiceAuthorizationLineItemDetails>() {
      public int compare(final ServiceAuthorizationLineItemDetails lhs,
        ServiceAuthorizationLineItemDetails rhs) {
        return lhs.serviceName.compareToIgnoreCase(rhs.serviceName);
      }
    });

    ViewServiceAuthorizationLineItemDetailsList viewServiceAuthorizationLineItemDetailsListSorted = new ViewServiceAuthorizationLineItemDetailsList();

    viewServiceAuthorizationLineItemDetailsListSorted.serviceAuthorizationLineItemDetails.addAll(
      serviceAuthLineItemDetailsList);

    return viewServiceAuthorizationLineItemDetailsListSorted;
  }

  /**
   * Gets the Service Authorization details for the given service authorization.
   *
   * @param serviceAuthorization
   * Contains Service Authorization details.
   *
   * @return The Service Authorization details.
   */
  protected ServiceAuthorizationDetails getServiceAuthorizationFields(
    final curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization) {

    final ServiceAuthorizationDetails serviceAuthorizationDtls = new ServiceAuthorizationDetails();

    serviceAuthorizationDtls.referenceNumber = serviceAuthorization.getReferenceNumber();
    serviceAuthorizationDtls.clientName = serviceAuthorization.getClient().getName();
    serviceAuthorizationDtls.creationDate = serviceAuthorization.getCreationDate();
    serviceAuthorizationDtls.derivedStatus = serviceAuthorization.getDerivedStatus();
    serviceAuthorizationDtls.serviceAuthorizationID = serviceAuthorization.getID();
    serviceAuthorizationDtls.caseReferenceNumber = serviceAuthorization.getCaseReferenceNumber();

    return serviceAuthorizationDtls;
  }

  // BEGIN, CR00155384, ABS
  /**
   * Sorts the list of concern roles by name.
   *
   * @param unsortedConcernRoles
   * Unsorted set of concern roles.
   *
   * @return Sorted list of concern roles.
   */
  protected List<ConcernRole> sortConcernRole(
    Set<ConcernRole> unsortedConcernRoles) {

    final List<ConcernRole> concernRoleList = new ArrayList<ConcernRole>(
      unsortedConcernRoles);

    Collections.sort(concernRoleList, new Comparator<ConcernRole>() {
      public int compare(
        final ConcernRole lhs,
        ConcernRole rhs) {
        return (lhs.getName().compareTo(rhs.getName()));
      }
    });

    return concernRoleList;
  }

  // END, CR00155384

  // BEGIN, CR00228769, RPB
  /**
   * Sorts a set of Service Authorization Line Items into a sorted list for
   * display.
   *
   * @param unsortedServiceAuthLineItems
   * Set of unsorted Service Authorization Line Items.
   *
   * @return The list of Service Authorization Line Item details sorted by name.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  protected ViewSALIDetailsList sortSALIDetails(
    final ViewSALIDetailsList unsortedServiceAuthLineItems) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    List<SALIDetails> saliDetailsList = new ArrayList<SALIDetails>();
    int noOfServiceAuthLineItems = unsortedServiceAuthLineItems.saliDetails.size();

    for (int i = 0; i < noOfServiceAuthLineItems; i++) {
      saliDetailsList.add(unsortedServiceAuthLineItems.saliDetails.item(i));
    }

    Collections.sort(saliDetailsList,
      new Comparator<SALIDetails>() {
      public int compare(final SALIDetails lhs, final SALIDetails rhs) {
        return lhs.serviceAuthorizationLineItemDetails.serviceName.compareToIgnoreCase(
          rhs.serviceAuthorizationLineItemDetails.serviceName);
      }
    });

    ViewSALIDetailsList viewSALIDetailsListSorted = new ViewSALIDetailsList();

    viewSALIDetailsListSorted.saliDetails.addAll(saliDetailsList);

    return viewSALIDetailsListSorted;
  }

  // END, CR00228769
}
