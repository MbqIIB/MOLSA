/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.sl.impl;


import java.io.ByteArrayOutputStream;
import java.util.Set;

import com.google.inject.Inject;

import curam.attendance.impl.ProviderRosterLineItem;
import curam.attendance.impl.ProviderRosterLineItemDAO;
import curam.codetable.COMMUNICATIONFORMAT;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONSTATUS;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.INTERACTIONTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.codetable.impl.CMISNAMINGTYPEEntry;
import curam.codetable.impl.CMSLINKRELATEDTYPEEntry;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.CONTRACTTYPEEntry;
import curam.codetable.impl.TEMPLATEIDCODEEntry;
import curam.codetable.impl.XSLTEMPLATETYPEEntry;
import curam.contracts.ContractNotificationEvent;
import curam.contracts.impl.ContractNotification;
import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.ContractVersionDAO;
import curam.core.facade.struct.ListProFormaTemplateByTypeAndParticipantKey;
import curam.core.facade.struct.ListProFormaTemplateByTypeAndParticpant;
import curam.core.facade.struct.PrintProFormaKey;
import curam.core.fact.AdminUserAssistantFactory;
import curam.core.fact.ConcernRoleCommunicationFactory;
import curam.core.fact.ConcernRoleDocumentsFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.OrganisationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.EnvVars;
import curam.core.intf.AdminUserAssistant;
import curam.core.intf.ConcernRole;
import curam.core.intf.ConcernRoleCommunication;
import curam.core.intf.ConcernRoleDocuments;
import curam.core.intf.Organisation;
import curam.core.intf.SystemUser;
import curam.core.intf.UniqueID;
import curam.core.sl.fact.ClientInteractionFactory;
import curam.core.sl.infrastructure.cmis.impl.CMISAccessInterface;
import curam.core.sl.intf.ClientInteraction;
import curam.core.sl.struct.ClientInteractionSupplementaryDetails;
import curam.core.sl.struct.DataSetData;
import curam.core.sl.struct.LanguageLocaleMapDetails;
import curam.core.sl.struct.ProFormaReturnDocDetails;
import curam.core.struct.ConcernRoleCommunicationDtls;
import curam.core.struct.ConcernRoleCommunicationKey;
import curam.core.struct.ConcernRoleDocumentDetails;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.GetResourcesDetails;
import curam.core.struct.OrganisationID;
import curam.core.struct.OrganisationKey;
import curam.core.struct.OrganisationNameAndAddressDetails;
import curam.core.struct.SearchTemplatesByConcernAndTypeResult;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UserKeyStruct;
import curam.core.struct.UsersKey;
import curam.core.struct.XSLTemplateDetails;
import curam.cpm.facade.struct.ContractNotificationDetails;
import curam.cpm.facade.struct.ContractNotificationKey;
import curam.cpm.facade.struct.LicenseNotificationDetails;
import curam.cpm.facade.struct.ProviderNotificationReturnDocDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.fact.ServiceOfferingFactory;
import curam.cpm.sl.entity.intf.ServiceOffering;
import curam.cpm.sl.entity.struct.ServiceOfferingDtls;
import curam.cpm.sl.entity.struct.ServiceOfferingKey;
import curam.cpm.sl.fact.FinancialNotificationFactory;
import curam.cpm.sl.fact.RosterNotificationFactory;
import curam.cpm.sl.intf.FinancialNotification;
import curam.cpm.sl.intf.RosterNotification;
import curam.cpm.sl.struct.CommunicationDetails;
import curam.cpm.sl.struct.FinancialNotificationDetails;
import curam.cpm.sl.struct.FinancialNotificationKey;
import curam.cpm.sl.struct.ProviderNotificationDetails;
import curam.cpm.sl.struct.ProviderNotificationKey;
import curam.cpm.sl.struct.RosterNotificationDetails;
import curam.cpm.sl.struct.RosterNotificationKey;
import curam.financial.FinancialNotificationEvent;
import curam.financial.impl.ServiceInvoiceLineItem;
import curam.financial.impl.ServiceInvoiceLineItemDAO;
import curam.message.BPOCONCERNROLEDOCUMENTGENERATION;
import curam.message.GENERALCOMMUNICATION;
import curam.message.GENERALCONCERN;
import curam.provider.LicenseNotificationEvent;
import curam.provider.ProviderNotificationEvent;
import curam.provider.RosterNotificationEvent;
import curam.provider.impl.CommunicationCVLink;
import curam.provider.impl.CommunicationCVLinkDAO;
import curam.provider.impl.CommunicationLicenseLink;
import curam.provider.impl.CommunicationLicenseLinkDAO;
import curam.provider.impl.CommunicationPOLink;
import curam.provider.impl.CommunicationPOLinkDAO;
import curam.provider.impl.CommunicationPRLILink;
import curam.provider.impl.CommunicationPRLILinkDAO;
import curam.provider.impl.CommunicationSILILink;
import curam.provider.impl.CommunicationSILILinkDAO;
import curam.provider.impl.License;
import curam.provider.impl.LicenseDAO;
import curam.providerservice.ProviderOfferingDenialReason;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.serviceoffering.impl.ServiceRate;
import curam.serviceoffering.impl.ServiceRateDAO;
import curam.util.administration.struct.XSLTemplateDetailsList;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.internal.xml.fact.XSLTemplateFactory;
import curam.util.internal.xml.impl.XMLPrintStreamConstants;
import curam.util.internal.xml.intf.XSLTemplate;
import curam.util.internal.xml.struct.XSLTemplateDtls;
import curam.util.internal.xml.struct.XSLTemplateKey;
import curam.util.message.CURAMXML;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.Locale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Blob;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.Money;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.impl.XMLDocument;
import curam.util.xml.impl.XMLEncodingConstants;
import curam.util.xml.impl.XMLPrintStream;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;


/**
 * This class holds the API for sending the provider notifications
 *
 */
// BEGIN, CR00399406, PS
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
// END, CR00399406
// Start CR00096126, JSP
public abstract class ProviderNotification extends curam.cpm.sl.base.ProviderNotification {
  // End CR00096126

  // BEGIN, CR00292749, MR
  /**
   * Reference to CMIS Access Interface.
   */
  @Inject
  protected CMISAccessInterface cmisAccessInterface;
  // END, CR00292749

  // BEGIN, CR00281474, MR
  /**
   * Reference to communication contract version link DAO.
   */
  @Inject
  protected CommunicationCVLinkDAO communicationCVLinkDAO;

  /**
   * Reference to communication license link DAO.
   */
  @Inject
  protected CommunicationLicenseLinkDAO communicationLicenseLinkDAO;

  /**
   * Reference to communication service invoice line item link DAO.
   */
  @Inject
  protected CommunicationSILILinkDAO communicationSILILinkDAO;
  
  /**
   * Reference to contract version DAO.
   */
  @Inject
  protected ContractVersionDAO contractVersionDAO;

  /**
   * Reference to license DAO.
   */
  @Inject
  protected LicenseDAO licenseDAO;

  /**
   * Reference to service invoice line item DAO.
   */
  @Inject
  protected ServiceInvoiceLineItemDAO serviceInvoiceLineItemDAO;
  // END, CR00281474

  // BEGIN, CR00304493, MR
  /**
   * Reference to communication provider roster line item link DAO.
   */
  @Inject
  protected CommunicationPRLILinkDAO communicationPRLILinkDAO;
  
  /**
   * Reference to provider roster line item DAO.
   */
  @Inject
  protected ProviderRosterLineItemDAO providerRosterLineItemDAO;
  
  // END, CR00304493
  
  /**
   * Service Offering DAO
   */
  @Inject
  protected ServiceRateDAO serviceRateDAO;

  // BEGIN, CR00200196, SSK
  /**
   * Reference to communication provider offering link DAO.
   */
  @Inject
  protected CommunicationPOLinkDAO communicationPOLinkDAO;

  /**
   * Reference to service offering DAO.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  // BEGIN, CR00213258, AS
  /**
   * Reference to provider offering DAO.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;
  // END, CR00213258
  // END, CR00200196


  /**
   * Constructor
   */
  public ProviderNotification() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * This methods sends the notifications by either using the XSL or XML
   * templates for a particular event.
   *
   * @param providerNotificationKey Contains ProviderNotificationKey
   *
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00399406, PS
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END, CR00399406
  public void sendNotification(ProviderNotificationKey providerNotificationKey)
    throws AppException, InformationalException {

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = null;

    // Checking if concernRoleID of a provider is passed or it is a group
    if (providerNotificationKey.concernRoleID != 0) {
      concernRoleKey.concernRoleID = providerNotificationKey.concernRoleID;
    } else { // providerGroupID is passed instead of concernRoleID
      concernRoleKey.concernRoleID = providerNotificationKey.providerGroupID;
    }
    // Read concern role details
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    generateDocumentFromTemplate(concernRoleDtls, providerNotificationKey);
  }

  /**
   * Method for generating the document
   *
   * @param concernRoleDtls
   * ConcernRoleDtls
   * @param key
   * ProviderNotificationKey
   * @throws InformationalException
   * @throws AppException
   */

  public void generateDocumentFromTemplate(ConcernRoleDtls concernRoleDtls,
    ProviderNotificationKey key) throws AppException,
      InformationalException {
    final ConcernRoleDocumentDetails details = new ConcernRoleDocumentDetails();
    ProviderNotificationDetails pnd = new ProviderNotificationDetails();

    // XSLTemplateUtility manipulation variables
    final XSLTemplateUtility xslTemplateUtilityObj = XSLTemplateUtilityFactory.newInstance();
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new curam.util.xml.struct.XSLTemplateIDCodeKey();

    // BEGIN, CR00178508, SK
    final curam.core.intf.ConcernRoleDocuments concernRoleDocumentsObj = curam.core.fact.ConcernRoleDocumentsFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = concernRoleDtls.concernRoleID;

    // Get the locale information
    final LanguageLocaleMapDetails languageLocaleMapDetails = concernRoleDocumentsObj.getLocaleInfo(
      concernRoleKey);

    // Set key to read latest template by name
    xslTemplateIDCodeKey.templateIDCode = getTemplateIDCode(key);
    xslTemplateIDCodeKey.localeIdentifier = languageLocaleMapDetails.dtls.localeIdentifier;
    XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    try {
      xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);
    } catch (final RecordNotFoundException recordNotFoundException) {
      final AppException appException = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE);

      final String codeItemDescription = CodeTable.getOneItem(
        TEMPLATEIDCODE.TABLENAME, xslTemplateIDCodeKey.templateIDCode,
        TransactionInfo.getProgramLocale());

      appException.arg(codeItemDescription);

      throw appException;
    }
    details.documentID = xslTemplateInstanceKey.templateID;
    details.versionNo = xslTemplateInstanceKey.templateVersion;
    details.localeIdentifier = languageLocaleMapDetails.dtls.localeIdentifier;
    // END, CR00178508

    // Get Provider details
    pnd = getProviderNotificationDetails(concernRoleDtls, key);

    // BEGIN, CR00292749, MR
    createDocumentAndInsertProviderCommunication(key, details, pnd);
    // END, CR00292749

  }

  /**
   * Generates an XML document from the specified XSL template and prints that
   * document.
   *
   * @param details
   * Contains details of the document to be used
   * @param data
   * Contains the data to be entered into the document
   * @throws InformationalException
   * @throws AppException
   */

  public void createDocumentFromDetails(ConcernRoleDocumentDetails details,
    ProviderNotificationDetails data) throws AppException,
      InformationalException {

    final SystemUser systemUserObj = SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // BEGIN, CR00235681, PM
    // Create XMLPrintStream object
    final XMLPrintStream printStreamObj = new XMLPrintStream();
    // END, CR00235681

    final XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    // Set up XSL template instance
    xslTemplateInstanceKey.templateID = details.documentID;
    xslTemplateInstanceKey.templateVersion = details.versionNo;
    // BEGIN, CR00178508, SK
    xslTemplateInstanceKey.locale = details.localeIdentifier;
    // END, CR00178508

    // BEGIN, CR00414039, KRK
    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS_DEFAULT))) {
      
      try {
        // BEGIN, CR00235681, PM
        printStreamObj.open(xslTemplateInstanceKey);
        // END, CR00235681

      } catch (final AppException ex) {

        // an error occurred - was the document not in valid XML format?
        if (ex.getCatEntry().equals(CURAMXML.ERR_PRINT_STREAM_BAD_RESPONSE)) {

          // the pro-forma form is not a valid XML document -
          // convert this to a more meaningful message for the user
          throw new AppException(
            BPOCONCERNROLEDOCUMENTGENERATION.ERR_INVALID_FORMAT_NOT_PRINTABLE,
            ex);
        } else {
          // we can't do anything with it -
          // just pass it on up to the calling method
          throw ex;
        }
      }

      final XMLDocument documentObj = new XMLDocument(
        printStreamObj.getStream(), XMLEncodingConstants.kEncodeUTF8);

      // Set data to print the document
      systemUserDtls = systemUserObj.getUserDetails();
      final String userName = systemUserDtls.userName;
      final String generatedDate = curam.util.type.Date.getCurrentDate().toString();
      final String versionNo = String.valueOf(details.versionNo);
      final String comments = details.comments;

      // Open document
      documentObj.open(userName, generatedDate, versionNo, comments);

      // Add data to document
      documentObj.add(data);

      // Close document and print stream objects
      documentObj.close();
      printStreamObj.close();      
    }  
    // END, CR00414039

  }
  
  // BEGIN, CR00292749, MR
  /**
   * Creates an XML document from the specified XSL template and inserts
   * provider communication. It also stores the document content to the
   * content management system.
   *
   * @param providerNotificationKey
   * Contains details for which provider communication will be
   * created.
   * @param concernRoleDocumentDetails
   * Contains details of the document to be used.
   * @param providerNotificationDetails
   * Contains the details to be entered into the document.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createDocumentAndInsertProviderCommunication(
    final ProviderNotificationKey providerNotificationKey,
    final ConcernRoleDocumentDetails concernRoleDocumentDetails,
    final ProviderNotificationDetails providerNotificationDetails)
    throws AppException, InformationalException {
    createDocumentFromDetails(concernRoleDocumentDetails,
      providerNotificationDetails);

    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls = insertProviderCommunication(
      providerNotificationKey);

    final XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    xslTemplateInstanceKey.templateID = concernRoleDocumentDetails.documentID;
    xslTemplateInstanceKey.templateVersion = concernRoleDocumentDetails.versionNo;
    xslTemplateInstanceKey.locale = concernRoleDocumentDetails.localeIdentifier;

    final DataSetData dataSetData = new DataSetData();
    XMLDocument xmlDocumentObj = new XMLDocument(
      XMLEncodingConstants.kEncodeUTF8);

    xmlDocumentObj.add(providerNotificationDetails);
    dataSetData.dataSetData = xmlDocumentObj.toString();

    final LicenseNotification licenseNotification = new LicenseNotification();

    licenseNotification.storeDocumentContent(concernRoleCommunicationDtls,
      xslTemplateInstanceKey, dataSetData);
  }

  // END, CR00292749

  /**
   * Method for returning the organization name.By default theres one
   * organization and function fetches the name of that from database.
   *
   * @return String
   * @throws InformationalException
   * @throws AppException
   */

  // BEGIN, CR00177241, PM
  protected String getOrganisationName() throws AppException,
      InformationalException {
    // END, CR00177241
    final Organisation organisation = OrganisationFactory.newInstance();
    final OrganisationID organisationID = organisation.readOrganisationID();
    final OrganisationKey organisationKey = new OrganisationKey();

    organisationKey.organisationID = organisationID.organisationID;
    final OrganisationNameAndAddressDetails details = organisation.readNameAndAddress(
      organisationKey);

    return details.name;
  }

  /**
   * This method gets the Template ID code
   *
   * @param key
   * Contains ProviderNotificationKey
   * @return String TemplateIDCode
   * @throws AppException
   * @throws InformationalException
   */

  // BEGIN, CR00177241, PM
  
  // BEGIN, CR00304493, MR
  protected String getTemplateIDCode(final ProviderNotificationKey key)
    throws AppException, InformationalException {
    // END, CR00177241
    String templateIDCode = CPMConstants.kEmptyString;

    if (ProviderNotificationEvent.ENROLLMENT.equals(key.event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERENROLLMENTNOTIFICATION.getCode();
    } else if (ProviderNotificationEvent.REJECTION.equals(key.event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERREJECTIONNOTIFICATION.getCode();
    } else if (ProviderNotificationEvent.APPROVAL.equals(key.event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERAPPROVALNOTIFICATION.getCode();
    } else if (ProviderNotificationEvent.SUSPENSION.equals(key.event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERSUSPENSIONNOTIFICATION.getCode();
    } else if (ProviderNotificationEvent.CLOSURE.equals(key.event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERCLOSURENOTIFICATION.getCode();
    } else if (ProviderNotificationEvent.REOPENING.equals(key.event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERREOPENINGNOTIFICATION.getCode();
    } else if (ProviderNotificationEvent.GROUP_REGISTRATION.equals(key.event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERGROUPENROLLMENTNOTIFICATION.getCode();
    } else if (ProviderNotificationEvent.GROUP_CLOSURE.equals(key.event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERGROUPCLOSURENOTIFICATION.getCode();
    } else if (ProviderNotificationEvent.GROUP_REOPENING.equals(key.event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERGROUPREOPENINGNOTIFICATION.getCode();
    } else if (ProviderNotificationEvent.SERVICE_OFFERING_APPROVAL.equals(
      key.event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERSERVICEOFFERINGAPPROVALNOTIFICATION.getCode();
    } else if (ProviderNotificationEvent.SERVICE_OFFERING_APPROVAL_DENIAL.equals(
      key.event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERSERVICEOFFERINGAPPROVALDENIALNOTIFICATION.getCode();
    } else if (ProviderNotificationEvent.SERVICE_RATE_UPDATE.equals(key.event)) {
      templateIDCode = TEMPLATEIDCODEEntry.SERVICERATEUPDATENOTIFICATION.getCode();
    }

    // Begin CR00096779, ABS
    return templateIDCode;

    // END, CR00304493
    // End CR00096779
  }

  /**
   * This method gets the provider notification details
   *
   * @param concernRoleDtls
   * Contains ConcernRoleDtls
   * @param key
   * Contains ProviderNotificationKey
   * @return String TemplateIDCode
   * @throws AppException
   * @throws InformationalException
   */

  // BEGIN, CR00177241, PM
  protected ProviderNotificationDetails getProviderNotificationDetails(
    ConcernRoleDtls concernRoleDtls, ProviderNotificationKey key)
    throws AppException, InformationalException {
    // END, CR00177241

    final ProviderNotificationDetails providerNotificationDetails = new ProviderNotificationDetails();

    // BEGIN, CR00186174, SS
    providerNotificationDetails.currentDate = Date.getCurrentDate().toString();
    // END, CR00186174
    providerNotificationDetails.organisationName = getOrganisationName();

    // set the values based on concernRoleType i.e. provider
    if (concernRoleDtls.concernRoleType.equals(CONCERNROLETYPE.PROVIDER)) {
      providerNotificationDetails.providerName = concernRoleDtls.concernRoleName;
      providerNotificationDetails.providerRefNumber = concernRoleDtls.primaryAlternateID;
      // BEGIN, CR00186174, SS
      providerNotificationDetails.providerEnrollDate = concernRoleDtls.registrationDate.toString();

      providerNotificationDetails.providerEndDate = concernRoleDtls.endDate.toString();
      // END, CR00186174

    } else if (concernRoleDtls.concernRoleType.equals(
      CONCERNROLETYPE.PROVIDERGROUP)) {
      // set the values based on concernRoleType i.e. provider group
      providerNotificationDetails.providerGrpName = concernRoleDtls.concernRoleName;
      providerNotificationDetails.providerGrpRefNumber = concernRoleDtls.primaryAlternateID;
      // BEGIN, CR00186174, SS
      providerNotificationDetails.providerGrpEnrollDate = concernRoleDtls.registrationDate.toString();

      providerNotificationDetails.providerGrpEndDate = concernRoleDtls.endDate.toString();
      // END, CR00186174

    }

    if (ProviderNotificationEvent.ENROLLMENT.equals(key.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.REJECTION.equals(key.event)) {
      providerNotificationDetails.reason = key.reason;
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.APPROVAL.equals(key.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.SUSPENSION.equals(key.event)) {
      providerNotificationDetails.reason = key.reason;
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.CLOSURE.equals(key.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.REOPENING.equals(key.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.GROUP_REGISTRATION.equals(key.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.GROUP_CLOSURE.equals(key.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.GROUP_REOPENING.equals(key.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.SERVICE_OFFERING_APPROVAL.equals(
      key.event)) {
      // BEGIN, CR00246416, ASN
      curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceOfferingDAO.get(
        key.serviceOfferingID);

      providerNotificationDetails.serviceOfferingName = serviceOffering.getName();
      // END, CR00246416

      // BEGIN, CR00186174, SS
      providerNotificationDetails.providerOffStartDate = key.date.toString();
      // END, CR00186174

      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.SERVICE_OFFERING_APPROVAL_DENIAL.equals(
      key.event)) {
      // BEGIN, CR00246416, ASN
      curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceOfferingDAO.get(
        key.serviceOfferingID);

      providerNotificationDetails.serviceOfferingName = serviceOffering.getName();
      // END, CR00246416
      providerNotificationDetails.providerOffDenialReason = key.reason;
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.SERVICE_RATE_UPDATE.equals(key.event)) {
      final ServiceOfferingDtls serviceOfferingDtls = getServiceOfferingDetails(
        key);
      final ServiceRate serviceRate = serviceRateDAO.get(key.serviceRateID);

      providerNotificationDetails.serviceOfferingName = serviceOfferingDtls.name;
      Money rate;

      if (serviceRate.getFixedAmount().isPositive()) {
        rate = serviceRate.getFixedAmount();
      } else if (serviceRate.getMaxAmount().isPositive()) {
        rate = serviceRate.getMaxAmount();
      } else {
        rate = serviceRate.getMinAmount();
      }

      providerNotificationDetails.currentServiceRate = rate.toString();
      // BEGIN, CR00186174, SS
      providerNotificationDetails.serviceRateStartDate = serviceRate.getDateRange().start().toString();

      providerNotificationDetails.serviceRateEndDate = serviceRate.getDateRange().end().toString();
      ;
      // END, CR00186174
      return providerNotificationDetails;
    }
    return providerNotificationDetails;
  }

  /**
   * Method for getting service offering details using service offering ID
   *
   * @param key Contains ProviderNotificationKey
   * @return ServiceOfferingDtls
   * @throws InformationalException
   * @throws AppException
   */

  // BEGIN, CR00177241, PM
  protected ServiceOfferingDtls getServiceOfferingDetails(
    ProviderNotificationKey key) throws AppException,
      InformationalException {
    // END, CR00177241
    final ServiceOffering serviceOffering = ServiceOfferingFactory.newInstance();
    final ServiceOfferingKey serviceOfferingKey = new ServiceOfferingKey();

    serviceOfferingKey.serviceOfferingID = key.serviceOfferingID;
    final ServiceOfferingDtls serviceOfferingDtls = serviceOffering.read(
      serviceOfferingKey);

    return serviceOfferingDtls;
  }

  // BEGIN, CR00292749, MR
  /**
   * Inserts the communication details for a new communication.
   *
   * @param providerNotificationKey
   * Contains providerNotificationKey.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced by
   * {@link #insertProviderCommunication(ProviderNotificationKey)}
   * . This method is deprecated because it is not returning
   * concern role communication details which is required while
   * storing the document content to the content management
   * system. See release note: CR00292749.
   */
  @Deprecated
	
  // END, CR00292749
  public void insertCommunication(
    ProviderNotificationKey providerNotificationKey)
    throws AppException, InformationalException {

    // based on domain CURAM_DATE
    final Date currentDate = Date.getCurrentDate();

    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // ConcernRoleComm manipulation variables
    final ConcernRoleCommunication concernRoleCommunicationObj = ConcernRoleCommunicationFactory.newInstance();
    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls = new ConcernRoleCommunicationDtls();

    long concernRoleCommunicationID = 0;

    // XSLTemplate manipulation variables
    final XSLTemplate xslTemplateObj = XSLTemplateFactory.newInstance();
    final XSLTemplateKey xslTemplateKey = new XSLTemplateKey();
    XSLTemplateDtls xslTemplateDtls;

    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    final XSLTemplateUtility xslTemplateUtilityObj = XSLTemplateUtilityFactory.newInstance();

    // concernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    // Generate unique id for ConcernRoleCommunication
    concernRoleCommunicationID = uniqueIDObj.getNextID();

    concernRoleCommunicationDtls.attachmentInd = false;

    concernRoleCommunicationDtls.typeCode = COMMUNICATIONTYPE.LETTER;

    concernRoleCommunicationDtls.communicationID = concernRoleCommunicationID;
    concernRoleCommunicationDtls.statusCode = RECORDSTATUS.NORMAL;

    concernRoleCommunicationDtls.proFormaInd = true;

    // BEGIN, CR00178508, SK
    final ConcernRoleDocuments concernRoleDocumentsObj = ConcernRoleDocumentsFactory.newInstance();

    concernRoleKey.concernRoleID = providerNotificationKey.concernRoleID;
    // Get the locale information
    final LanguageLocaleMapDetails languageLocaleMapDetails = concernRoleDocumentsObj.getLocaleInfo(
      concernRoleKey);

    xslTemplateIDCodeKey.localeIdentifier = languageLocaleMapDetails.dtls.localeIdentifier;

    xslTemplateIDCodeKey.templateIDCode = getTemplateIDCode(
      providerNotificationKey);

    try {
      xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);
    } catch (final RecordNotFoundException recordNotFoundException) {
      final AppException appException = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE);
      final String codeItemDescription = CodeTable.getOneItem(
        TEMPLATEIDCODE.TABLENAME, xslTemplateIDCodeKey.templateIDCode,
        TransactionInfo.getProgramLocale());

      appException.arg(codeItemDescription);
      throw appException;
    }
    // Copy the proforma document type to the subject
    xslTemplateKey.templateID = xslTemplateInstanceKey.templateID;
    xslTemplateKey.localeIdentifier = xslTemplateInstanceKey.locale;
    // END, CR00178508
    try {
      xslTemplateDtls = xslTemplateObj.read(xslTemplateKey);
    } catch (final RecordNotFoundException e) {
      xslTemplateDtls = null;
    }

    if (xslTemplateDtls != null) {
      concernRoleCommunicationDtls.subjectText = xslTemplateDtls.templateName;
    } else {
      final AppException e = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE);

      e.arg(xslTemplateInstanceKey.templateID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 4);
    }

    final SystemUser user = SystemUserFactory.newInstance();

    // Checking if concernRoleID of a provider is passed or it is a group
    if (providerNotificationKey.concernRoleID != 0) {
      concernRoleCommunicationDtls.concernRoleID = providerNotificationKey.concernRoleID;
    } else { // providerGroupID is passed instead of concernRoleID
      concernRoleCommunicationDtls.concernRoleID = providerNotificationKey.providerGroupID;
    }

    concernRoleCommunicationDtls.proFormaVersionNo = xslTemplateInstanceKey.templateVersion;
    concernRoleCommunicationDtls.userName = user.getUserDetails().userName;

    // Checking if concernRoleID of a provider is passed or it is a group
    if (providerNotificationKey.concernRoleID != 0) {
      concernRoleCommunicationDtls.correspondentConcernRoleID = providerNotificationKey.concernRoleID;
    } else { // providerGroupID is passed instead of concernRoleID
      concernRoleCommunicationDtls.correspondentConcernRoleID = providerNotificationKey.providerGroupID;
    }

    concernRoleKey.concernRoleID = concernRoleCommunicationDtls.concernRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    concernRoleCommunicationDtls.addressID = concernRoleDtls.primaryAddressID;
    concernRoleCommunicationDtls.correspondentName = concernRoleDtls.concernRoleName;
    concernRoleCommunicationDtls.communicationDate = currentDate;
    concernRoleCommunicationDtls.communicationStatus = COMMUNICATIONSTATUS.SENT;
    concernRoleCommunicationDtls.communicationFormat = COMMUNICATIONFORMAT.PROFORMA;
    concernRoleCommunicationDtls.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
    concernRoleCommunicationDtls.correspondentTypeCode = CORRESPONDENT.CLIENT;
    concernRoleCommunicationDtls.documentTemplateID = xslTemplateIDCodeKey.templateIDCode;
    // BEGIN, CR00178508, SK
    concernRoleCommunicationDtls.localeIdentifier = xslTemplateIDCodeKey.localeIdentifier;
    concernRoleCommunicationDtls.proFormaID = xslTemplateDtls.templateID;
    // END, CR00178508
    // Insert new communication entry
    concernRoleCommunicationObj.insert(concernRoleCommunicationDtls);

    // BEGIN, CR00200196, SSK
    if (0 != providerNotificationKey.serviceOfferingID) {
      createCommunicationPOLink(concernRoleCommunicationDtls,
        providerNotificationKey);
    }
    // END, CR00200196
  }
  
  // BEGIN, CR00292749, MR
  /**
   * Inserts the provider communication details for a new communication.
   *
   * @param providerNotificationKey
   * Contains details for which provider communication will be
   * created.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link curam.message.GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE}
   * - If the pro forma template is not found.
   * @throws AppException
   * {@link curam.message.GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE}
   * - If the pro forma template ID is not found.
   */
  public ConcernRoleCommunicationDtls insertProviderCommunication(
    final ProviderNotificationKey providerNotificationKey)
    throws AppException, InformationalException {
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = providerNotificationKey.concernRoleID;

    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.localeIdentifier = ConcernRoleDocumentsFactory.newInstance().getLocaleInfo(concernRoleKey).dtls.localeIdentifier;
    xslTemplateIDCodeKey.templateIDCode = getTemplateIDCode(
      providerNotificationKey);

    XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    try {
      xslTemplateInstanceKey = XSLTemplateUtilityFactory.newInstance().getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);
    } catch (final RecordNotFoundException e) {
      final AppException appException = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE);
      final String codeItemDescription = CodeTable.getOneItem(
        TEMPLATEIDCODE.TABLENAME, xslTemplateIDCodeKey.templateIDCode,
        TransactionInfo.getProgramLocale());

      appException.arg(codeItemDescription);
      throw appException;
    }

    final XSLTemplateKey xslTemplateKey = new XSLTemplateKey();

    xslTemplateKey.templateID = xslTemplateInstanceKey.templateID;
    xslTemplateKey.localeIdentifier = xslTemplateInstanceKey.locale;

    XSLTemplateDtls xslTemplateDtls = new XSLTemplateDtls();

    try {
      xslTemplateDtls = XSLTemplateFactory.newInstance().read(xslTemplateKey);
    } catch (final RecordNotFoundException e) {
      xslTemplateDtls = null;
    }

    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls = new ConcernRoleCommunicationDtls();

    concernRoleCommunicationDtls.attachmentInd = false;
    concernRoleCommunicationDtls.typeCode = COMMUNICATIONTYPE.LETTER;
    concernRoleCommunicationDtls.communicationID = UniqueIDFactory.newInstance().getNextID();
    concernRoleCommunicationDtls.statusCode = RECORDSTATUS.NORMAL;
    concernRoleCommunicationDtls.proFormaInd = true;

    if (null != xslTemplateDtls) {
      concernRoleCommunicationDtls.subjectText = xslTemplateDtls.templateName;
    } else {
      final AppException e = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE);

      e.arg(xslTemplateInstanceKey.templateID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 5);
    }

    if (0 != providerNotificationKey.concernRoleID) {
      concernRoleCommunicationDtls.concernRoleID = providerNotificationKey.concernRoleID;
    } else {
      concernRoleCommunicationDtls.concernRoleID = providerNotificationKey.providerGroupID;
    }
    concernRoleCommunicationDtls.proFormaVersionNo = xslTemplateInstanceKey.templateVersion;
    concernRoleCommunicationDtls.userName = SystemUserFactory.newInstance().getUserDetails().userName;

    if (0 != providerNotificationKey.concernRoleID) {
      concernRoleCommunicationDtls.correspondentConcernRoleID = providerNotificationKey.concernRoleID;
    } else {
      concernRoleCommunicationDtls.correspondentConcernRoleID = providerNotificationKey.providerGroupID;
    }

    concernRoleKey.concernRoleID = concernRoleCommunicationDtls.concernRoleID;

    final ConcernRoleDtls concernRoleDtls = ConcernRoleFactory.newInstance().read(
      concernRoleKey);

    concernRoleCommunicationDtls.addressID = concernRoleDtls.primaryAddressID;
    concernRoleCommunicationDtls.correspondentName = concernRoleDtls.concernRoleName;
    concernRoleCommunicationDtls.communicationDate = Date.getCurrentDate();
    concernRoleCommunicationDtls.communicationStatus = COMMUNICATIONSTATUS.SENT;
    concernRoleCommunicationDtls.communicationFormat = COMMUNICATIONFORMAT.PROFORMA;
    concernRoleCommunicationDtls.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
    concernRoleCommunicationDtls.correspondentTypeCode = CORRESPONDENT.CLIENT;
    concernRoleCommunicationDtls.documentTemplateID = xslTemplateIDCodeKey.templateIDCode;
    concernRoleCommunicationDtls.localeIdentifier = xslTemplateIDCodeKey.localeIdentifier;
    concernRoleCommunicationDtls.proFormaID = xslTemplateDtls.templateID;
    ConcernRoleCommunicationFactory.newInstance().insert(
      concernRoleCommunicationDtls);

    if (0 != providerNotificationKey.serviceOfferingID) {
      createCommunicationPOLink(concernRoleCommunicationDtls,
        providerNotificationKey);
    }
    return concernRoleCommunicationDtls;
  }

  // END, CR00292749
  
  /**
   * Method for generating the document
   *
   * @param concernRoleDtls Contains concernRoleDtls
   * @param key             Contains ProviderNotificationKey
   *
   * @return DataSetData    Contains the data generated for the document
   *
   * @throws InformationalException
   * @throws AppException
   */
  public DataSetData generateDocument(ConcernRoleDtls concernRoleDtls,
    ProviderNotificationKey key) throws AppException,
      InformationalException {

    final DataSetData dataSetData = new DataSetData();

    ProviderNotificationDetails providerNotificationDetails = new ProviderNotificationDetails();

    providerNotificationDetails = getProviderNotificationDetails(
      concernRoleDtls, key);

    // Add all the receipt data to XML document object
    final XMLDocument documentObj = new XMLDocument(
      XMLEncodingConstants.kEncodeUTF8);

    documentObj.add(providerNotificationDetails);

    // Retrieve XML stream for data set and return
    dataSetData.dataSetData = documentObj.toString();

    return dataSetData;
  }

  // BEGIN CR00085398, SK

  /**
   * Returns a list of templates based on template type and the participant
   * identifier,provider and provider group.
   *
   * @param listProFormaTemplateByTypeAndParticipantKey Contains key to read the
   * list of templates.
   *
   * @return List of templates for participant.
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00399406, PS
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END, CR00399406
  public ListProFormaTemplateByTypeAndParticpant listTemplateByTypeAndProviderParticipant(
    ListProFormaTemplateByTypeAndParticipantKey
    listProFormaTemplateByTypeAndParticipantKey)
    throws AppException, InformationalException {

    // create return object
    ListProFormaTemplateByTypeAndParticpant listProFormaTemplateByTypeAndParticpant = new ListProFormaTemplateByTypeAndParticpant();

    // Concern Role Entity, Key and Dtls
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // Set the key and read ConcernRole from database
    concernRoleKey.concernRoleID = listProFormaTemplateByTypeAndParticipantKey.participantRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // if the concern role type is provider or provider group.
    if (concernRoleDtls.concernRoleType.equals(CONCERNROLETYPE.PROVIDER)
      || concernRoleDtls.concernRoleType.equals(CONCERNROLETYPE.PROVIDERGROUP)) {

      listProFormaTemplateByTypeAndParticpant = listProFormaTemplateByTypeAndProviderParticipant(
        listProFormaTemplateByTypeAndParticipantKey);

    } else {
      // else call core communication API
      final curam.core.facade.intf.Communication communicationObj = curam.core.facade.fact.CommunicationFactory.newInstance();

      listProFormaTemplateByTypeAndParticpant = communicationObj.listTemplateByTypeAndParticipant(
        listProFormaTemplateByTypeAndParticipantKey);
    }

    return listProFormaTemplateByTypeAndParticpant;

  }

  // BEGIN, CR00291621, MR
  /**
   * Lists pro forma templates based on the template type and the participant
   * identifier.
   *
   * @param listProFormaTemplateByTypeAndParticipantKey Contains a key to read the
   * list of templates.
   *
   * @return List of templates for a participant.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ListProFormaTemplateByTypeAndParticpant listProFormaTemplateByTypeAndProviderParticipant
    (final ListProFormaTemplateByTypeAndParticipantKey
    listProFormaTemplateByTypeAndParticipantKey)
    throws AppException, InformationalException {

    // END, CR00291621
    // create return object
    final ListProFormaTemplateByTypeAndParticpant listProFormaTemplateByTypeAndParticpant = new ListProFormaTemplateByTypeAndParticpant();

    // search struct
    final SearchTemplatesByConcernAndTypeResult searchTemplatesByConcernAndTypeResult = new SearchTemplatesByConcernAndTypeResult();

    // Concern Role Entity, Key and Dtls
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // XSL Template Utility Entity, Template Type Key and Template Details List
    final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj = curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();
    final curam.util.xml.struct.XSLTemplateTypeKey xslTemplateTypeKey = new curam.util.xml.struct.XSLTemplateTypeKey();
    XSLTemplateDetailsList xslTemplateDetailsList;

    // Structure to add to the Out Parameter

    curam.core.struct.XSLTemplateDetails xslTemplateDetails;

    // Boolean variable used to indicate TemplateDtls should be returned
    boolean returnTemplateDtls = false;

    // variable to hold each xslTemplateDtls
    curam.util.administration.struct.XSLTemplateDetails xslTemplateDtls;

    // variable to hold each xslTemplateDtls relatesTo value
    String relatesTo;

    // Set the key and read ConcernRole from database
    
    // BEGIN, CR00291621, MR
    concernRoleKey.concernRoleID = listProFormaTemplateByTypeAndParticipantKey.participantRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    xslTemplateTypeKey.templateType = listProFormaTemplateByTypeAndParticipantKey.templateType;

    xslTemplateDetailsList = xslTemplateUtilityObj.getAllTemplatesByType(
      xslTemplateTypeKey);

    for (int i = 0; i < xslTemplateDetailsList.dtls.size(); i++) {

      returnTemplateDtls = false;

      xslTemplateDtls = xslTemplateDetailsList.dtls.item(i);
      relatesTo = xslTemplateDtls.relatesTo;

      if (XSLTEMPLATETYPEEntry.ALLPARTICIPANTTYPES.getCode().equals(relatesTo)
        || XSLTEMPLATETYPEEntry.ALLCOMMUNICATIONS.getCode().equals(relatesTo)) {
        returnTemplateDtls = true;
      }

      // BEGIN, CR00273756, GYH
      if (XSLTEMPLATETYPEEntry.PROVIDER.getCode().equals(relatesTo)
        && CONCERNROLETYPEEntry.PROVIDER.getCode().equals(
          concernRoleDtls.concernRoleType)) {
        returnTemplateDtls = true;
      }
      if (XSLTEMPLATETYPEEntry.PROVIDERGROUP.getCode().equals(relatesTo)
        && CONCERNROLETYPEEntry.PROVIDERGROUP.getCode().equals(
          concernRoleDtls.concernRoleType)) {
        returnTemplateDtls = true;
      }
      // END, CR00273756

      // END, CR00291621
      if (returnTemplateDtls) {
        
        xslTemplateDetails = new XSLTemplateDetails();
        xslTemplateDetails.templateID = xslTemplateDtls.templateID;
        xslTemplateDetails.templateName = xslTemplateDtls.templateName;
        xslTemplateDetails.latestVersion = xslTemplateDtls.latestVersion;
        xslTemplateDetails.checkedOutInd = xslTemplateDtls.checkedOut;
        xslTemplateDetails.checkedOutBy = xslTemplateDtls.checkedOutBy;
        xslTemplateDetails.checkedOutVersion = xslTemplateDtls.checkedOutVersion;
        xslTemplateDetails.checkedOutTime = xslTemplateDtls.checkedOutTime;
        xslTemplateDetails.comment = xslTemplateDtls.coComment;
        xslTemplateDetails.editableInd = xslTemplateDtls.editable;
        // BEGIN, CR00273756, GYH
        xslTemplateDetails.localeIdentifier = xslTemplateDtls.locale;
        // END, CR00273756

        searchTemplatesByConcernAndTypeResult.xslTemplateDetailsListOut.dtls.addRef(
          xslTemplateDetails);
      }
    }
    listProFormaTemplateByTypeAndParticpant.searchTemplatesByConcernAndTypeResult = searchTemplatesByConcernAndTypeResult;

    return listProFormaTemplateByTypeAndParticpant;

  }

  // END CR00085398


  // BEGIN, CR00196848, SSK
  // BEGIN, CR00198982, SSK
  /**
   * Previews a pro forma communication.
   *
   * @param communicationDetails
   * Contains communication ID.
   *
   * @return Provider notification document details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00399406, PS
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END, CR00399406
  public ProviderNotificationReturnDocDetails previewProForma(
    final CommunicationDetails communicationDetails)
    throws AppException, InformationalException {
    ProviderNotificationReturnDocDetails providerNotificationReturnDocDetails = new ProviderNotificationReturnDocDetails();
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = null;

    if (CPMConstants.kZeroLong != communicationDetails.concernRoleID) {
      concernRoleKey.concernRoleID = communicationDetails.concernRoleID;
    } else {
      concernRoleKey.concernRoleID = communicationDetails.providerGroupID;
    }
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    final DataSetData dataSetData = new DataSetData();
    final XMLDocument documentObj = new XMLDocument(
      XMLEncodingConstants.kEncodeUTF8);
    
    // BEGIN, CR00281474, MR
    if (isLicenseNotificationEvent(communicationDetails.event)) {
      final LicenseNotificationDetails licenseNotificationDetails = getLicenseNotificationDetails(
        communicationDetails.communicationID);

      documentObj.add(licenseNotificationDetails);
    } else if (isContractNotificationEvent(communicationDetails.event)) {
      final ContractNotificationDetails contractNotificationDetails = getContractNotificationDetails(
        communicationDetails.communicationID);

      documentObj.add(contractNotificationDetails);
    } // BEGIN, CR00304493, MR
    else if (isRosterNotificationEvent(communicationDetails.event)) {
      final RosterNotificationDetails rosterNotificationDetails = getRosterNotificationDetails(
        communicationDetails.communicationID);

      documentObj.add(rosterNotificationDetails);
    } // END, CR00304493
    else if (isFinancialNotificationEvent(communicationDetails.event)) {
      final FinancialNotificationDetails financialNotificationDetails = getFinancialNotificationDetails(
        communicationDetails.communicationID);

      documentObj.add(financialNotificationDetails);
    } else {
      final ProviderNotificationDetails providerNotificationDetails = getProviderNotificationDetails(
        concernRoleDtls, communicationDetails);

      documentObj.add(providerNotificationDetails);
    }
    // END, CR00281474

    dataSetData.dataSetData = documentObj.toString();
    providerNotificationReturnDocDetails = createAndPreviewContract(dataSetData,
      communicationDetails);

    return providerNotificationReturnDocDetails;
  }

  /**
   * Generates an XML document from the specified XSL template and previews
   * that document.
   *
   * @param providerNotificationKey
   * Details of the document to be used.
   *
   * @param dataSetData
   * The XML data to be entered into the document.
   * @return The file name and file data(blob).
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ProviderNotificationReturnDocDetails createAndPreviewContract(
    final DataSetData dataSetData,
    final CommunicationDetails communicationDetails)
    throws AppException,
      InformationalException {

    // END, CR00198982

    final ProviderNotificationReturnDocDetails providerNotificationReturnDocDetails = new ProviderNotificationReturnDocDetails();    

    ByteArrayOutputStream previewStream = new ByteArrayOutputStream();
   
    // BEGIN, CR00306952, KRK
    final XMLPrintStream printStreamObj = new XMLPrintStream();
    // END, CR00306952
    XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    // BEGIN, CR00281474, MR
    xslTemplateIDCodeKey.templateIDCode = getTemplateIDCodeForPreview(
      communicationDetails.event);
    // END, CR00281474

    XSLTemplateUtility xslTemplateUtilityObj = XSLTemplateUtilityFactory.newInstance();

    xslTemplateIDCodeKey.localeIdentifier = TransactionInfo.getProgramLocale();

    XSLTemplateInstanceKey xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
      xslTemplateIDCodeKey);

    AdminUserAssistant adminUserAssistantObj = AdminUserAssistantFactory.newInstance();
    UserKeyStruct userKeyStruct = new UserKeyStruct();
    UsersKey usersKey = new UsersKey();

    usersKey.userName = TransactionInfo.getProgramUser();
    userKeyStruct.userName = usersKey.userName;

    GetResourcesDetails getResourcesDetails = adminUserAssistantObj.getUserDefaultPrinter(
      userKeyStruct);

    if (CPMConstants.kZeroLong != getResourcesDetails.resourceID) {
      printStreamObj.setPrinterName(getResourcesDetails.name);
    }

    printStreamObj.setPreviewStream(previewStream);
    printStreamObj.setJobType(XMLPrintStreamConstants.kJobTypePDF);
    
    // BEGIN, CR00306952, KRK
    printStreamObj.open(xslTemplateInstanceKey);
    // END, CR00306952
    
    XMLDocument documentObj = new XMLDocument(printStreamObj.getStream(),
      XMLEncodingConstants.kEncodeISOLATIN1);

    SystemUser systemUserObj = SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    systemUserDtls = systemUserObj.getUserDetails();
    String userName = systemUserDtls.userName;
    String generatedDate = DateTime.getCurrentDateTime().toString();
    String versionNo = String.valueOf(xslTemplateInstanceKey.templateVersion);
    String comments = CPMConstants.kEmptyString;

    documentObj.open(userName, generatedDate, versionNo, comments);
    documentObj.addFromXML(dataSetData.dataSetData);
    documentObj.close();

    printStreamObj.close();

    // BEGIN, CR00198982, SSK
    providerNotificationReturnDocDetails.fileName = TEMPLATEIDCODEEntry.get(xslTemplateIDCodeKey.templateIDCode).toUserLocaleString()
      + CPMConstants.kpdfExtension;
    // END, CR00198982
    providerNotificationReturnDocDetails.fileData = new Blob(
      previewStream.toByteArray());

    return providerNotificationReturnDocDetails;
  }

  // END, CR00196848


  // BEGIN, CR00200196, SSK
  /**
   * Creates an association between communication and provider offering.
   *
   * @param concernRoleCommunicationDtls
   * Communication details.
   * @param providerNotificationKey
   * Provider notification key.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void createCommunicationPOLink(
    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls,
    final ProviderNotificationKey providerNotificationKey) throws AppException,
      InformationalException {
    curam.provider.impl.CommunicationPOLink communicationPOLink = communicationPOLinkDAO.newInstance();

    communicationPOLink.setCommunicationID(
      concernRoleCommunicationDtls.communicationID);
    curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceOfferingDAO.get(
      providerNotificationKey.serviceOfferingID);

    communicationPOLink.setServiceOffering(serviceOffering);
    communicationPOLink.insert();
  }

  /**
   * This method gets the provider notification details
   *
   * @param concernRoleDtls
   * Contains ConcernRoleDtls.
   * @param communicationDetails
   * Communication details.
   *
   * @return Provider notification details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ProviderNotificationDetails getProviderNotificationDetails(
    final ConcernRoleDtls concernRoleDtls, final CommunicationDetails communicationDetails)
    throws AppException, InformationalException {

    final ProviderNotificationDetails providerNotificationDetails = new ProviderNotificationDetails();

    providerNotificationDetails.currentDate = Date.getCurrentDate().toString();
    providerNotificationDetails.organisationName = getOrganisationName();

    if (CONCERNROLETYPE.PROVIDER.equals(concernRoleDtls.concernRoleType)) {
      providerNotificationDetails.providerName = concernRoleDtls.concernRoleName;
      providerNotificationDetails.providerRefNumber = concernRoleDtls.primaryAlternateID;
      providerNotificationDetails.providerEnrollDate = concernRoleDtls.registrationDate.toString();

      providerNotificationDetails.providerEndDate = concernRoleDtls.endDate.toString();

    } else if (CONCERNROLETYPE.PROVIDERGROUP.equals(
      concernRoleDtls.concernRoleType)) {
      providerNotificationDetails.providerGrpName = concernRoleDtls.concernRoleName;
      providerNotificationDetails.providerGrpRefNumber = concernRoleDtls.primaryAlternateID;
      providerNotificationDetails.providerGrpEnrollDate = concernRoleDtls.registrationDate.toString();

      providerNotificationDetails.providerGrpEndDate = concernRoleDtls.endDate.toString();
    }

    if (ProviderNotificationEvent.ENROLLMENT.equals(communicationDetails.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.REJECTION.equals(
      communicationDetails.event)) {
      providerNotificationDetails.reason = communicationDetails.reason;
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.APPROVAL.equals(
      communicationDetails.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.SUSPENSION.equals(
      communicationDetails.event)) {
      providerNotificationDetails.reason = communicationDetails.reason;
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.CLOSURE.equals(
      communicationDetails.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.REOPENING.equals(
      communicationDetails.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.GROUP_REGISTRATION.equals(
      communicationDetails.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.GROUP_CLOSURE.equals(
      communicationDetails.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.GROUP_REOPENING.equals(
      communicationDetails.event)) {
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.SERVICE_OFFERING_APPROVAL.equals(
      communicationDetails.event)) {

      CommunicationPOLink communicationPOLink = communicationPOLinkDAO.get(
        communicationDetails.communicationID);

      providerNotificationDetails.serviceOfferingName = communicationPOLink.getServiceOffering().getName();
      providerNotificationDetails.providerOffStartDate = communicationDetails.date.toString();

      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.SERVICE_OFFERING_APPROVAL_DENIAL.equals(
      communicationDetails.event)) {
      CommunicationPOLink communicationPOLink = communicationPOLinkDAO.get(
        communicationDetails.communicationID);
      // BEGIN, CR00213258, AS
      Set<ProviderOffering> providerOfferings = providerOfferingDAO.searchProviderOffering(
        communicationDetails.concernRoleID,
        communicationPOLink.getServiceOffering().getID());

      for (final ProviderOffering providerOffering : providerOfferings) {
        if (!ProviderOfferingStatusEntry.CANCELED.equals(
          providerOffering.getLifecycleState())) {
          communicationDetails.reason = CodeTable.getOneItem(
            ProviderOfferingDenialReason.TABLENAME,
            providerOffering.getDenialReason().getCode());
          break;
        }
      }
      // END, CR00213258
      providerNotificationDetails.serviceOfferingName = communicationPOLink.getServiceOffering().getName();
      providerNotificationDetails.providerOffDenialReason = communicationDetails.reason;
      return providerNotificationDetails;
    } else if (ProviderNotificationEvent.SERVICE_RATE_UPDATE.equals(
      communicationDetails.event)) {

      CommunicationPOLink communicationPOLink = communicationPOLinkDAO.get(
        communicationDetails.communicationID);

      curam.serviceoffering.impl.ServiceOffering serviceOffering = communicationPOLink.getServiceOffering();

      providerNotificationDetails.serviceOfferingName = serviceOffering.getName();

      final ServiceRate serviceRate = serviceOffering.getServiceRates().iterator().next();

      Money rate;

      if (serviceRate.getFixedAmount().isPositive()) {
        rate = serviceRate.getFixedAmount();
      } else if (serviceRate.getMaxAmount().isPositive()) {
        rate = serviceRate.getMaxAmount();
      } else {
        rate = serviceRate.getMinAmount();
      }

      providerNotificationDetails.currentServiceRate = rate.toString();
      providerNotificationDetails.serviceRateStartDate = serviceRate.getDateRange().start().toString();

      providerNotificationDetails.serviceRateEndDate = serviceRate.getDateRange().end().toString();
      return providerNotificationDetails;
    }
    return providerNotificationDetails;
  }

  // END, CR00200196


  // BEGIN, CR00272932, GYH
  /**
   * Prints a pro forma communication. Also, creates client interaction records
   * for the communication for both the client and correspondent.
   *
   * @param printProFormaKey
   * Contains communication identifier.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00399406, PS
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END, CR00399406
  public void printProFormaCommunication(final PrintProFormaKey key)
    throws AppException, InformationalException {

    final ConcernRoleCommunicationKey concernRoleCommunicationKey = new ConcernRoleCommunicationKey();

    concernRoleCommunicationKey.communicationID = key.printProformaKey.communicationID;
    ConcernRoleCommunicationDtls concernRoleCommunicationDtls = ConcernRoleCommunicationFactory.newInstance().read(
      concernRoleCommunicationKey);
    
    // BEGIN, CR00292749, MR
    final ProFormaReturnDocDetails proFormaReturnDocDetails = generatePrintAndPreviewProFormaDocument(
      concernRoleCommunicationDtls);

    if (COMMUNICATIONSTATUS.SENT.equals(
      concernRoleCommunicationDtls.communicationStatus)
        && cmisAccessInterface.isCMISEnabledFor(
          CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {

      if (cmisAccessInterface.contentExists(
        concernRoleCommunicationDtls.communicationID,
        CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {

        // Modify the file on the content management system.
        cmisAccessInterface.modify(concernRoleCommunicationDtls.communicationID,
          CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION,
          proFormaReturnDocDetails.fileDate.copyBytes(), null);
      } else {

        // Save the contents to the content management system.
        cmisAccessInterface.create(concernRoleCommunicationDtls.communicationID,
          CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION,
          proFormaReturnDocDetails.fileDate.copyBytes(),
          proFormaReturnDocDetails.fileName,
          CMISNAMINGTYPEEntry.PROFORMA_GENERIC, null);
      }

    }
	
    // END, CR00292749
    
    // Once the proforma is printed, create client interaction records for the
    // communication for both the client and correspondent.
    recordClientInteraction(concernRoleCommunicationDtls);

  }

  /**
   * Generates an XML document from the specified XSL template and prints that
   * document.
   *
   * @param concernRoleCommunicationDtls
   * Contains details of the document to be printed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void printProFormaDocument(
    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls)
    throws AppException, InformationalException {

    // Construct the data object to be printed.
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = concernRoleCommunicationDtls.concernRoleID;
    ConcernRoleDtls concernRoleDtls = ConcernRoleFactory.newInstance().read(
      concernRoleKey);

    OrganisationID organisationID = OrganisationFactory.newInstance().readOrganisationID();
    final OrganisationKey organisationKey = new OrganisationKey();

    organisationKey.organisationID = organisationID.organisationID;
    OrganisationNameAndAddressDetails organisationNameAndAddressDetails = OrganisationFactory.newInstance().readNameAndAddress(
      organisationKey);

    ProviderNotificationDetails data = new ProviderNotificationDetails();

    data.providerName = concernRoleDtls.concernRoleName;
    data.providerRefNumber = concernRoleDtls.primaryAlternateID;
    data.providerEnrollDate = concernRoleDtls.registrationDate.toString();
    data.providerGrpName = concernRoleDtls.concernRoleName;
    data.providerGrpRefNumber = concernRoleDtls.primaryAlternateID;
    data.providerGrpEnrollDate = concernRoleDtls.registrationDate.toString();
    data.providerGrpEnrollDate = concernRoleDtls.registrationDate.toString();
    data.organisationName = organisationNameAndAddressDetails.name;

    // Find user's default printer and connect to printer.
    SystemUserDtls systemUserDtls = SystemUserFactory.newInstance().getUserDetails();
    String userName = systemUserDtls.userName;

    final UserKeyStruct userKeyStruct = new UserKeyStruct();

    userKeyStruct.userName = userName;
    
    final XMLPrintStream printStreamObj = new XMLPrintStream();

    printStreamObj.setPrinterName(
      AdminUserAssistantFactory.newInstance().getUserDefaultPrinter(userKeyStruct).name);
    
    // Set up XSL template instance
    final XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    xslTemplateInstanceKey.templateID = concernRoleCommunicationDtls.proFormaID;
    xslTemplateInstanceKey.templateVersion = concernRoleCommunicationDtls.versionNo;
    xslTemplateInstanceKey.locale = concernRoleCommunicationDtls.localeIdentifier;

    // open the print stream
    try {
      printStreamObj.open(xslTemplateInstanceKey);

    } catch (final AppException ex) {

      // An error occurred - was the document not in valid XML format?
      if (ex.getCatEntry().equals(CURAMXML.ERR_PRINT_STREAM_BAD_RESPONSE)) {

        // The pro-forma form is not a valid XML document -
        // convert this to a more meaningful message for the user
        throw new AppException(
          BPOCONCERNROLEDOCUMENTGENERATION.ERR_INVALID_FORMAT_NOT_PRINTABLE, ex);
      } else {

        // we can't do anything with it - 
        // just pass it on up to the calling method
        throw ex;
      }
    }

    final XMLDocument documentObj = new XMLDocument(printStreamObj.getStream(),
      XMLEncodingConstants.kEncodeUTF8);

    // Set data to print the document
    final String generatedDate = Locale.getFormattedTime(
      DateTime.getCurrentDateTime());
    final String versionNo = String.valueOf(
      concernRoleCommunicationDtls.versionNo);
    final String comments = concernRoleCommunicationDtls.comments;

    // Open document
    documentObj.open(userName, generatedDate, versionNo, comments);

    // Add data to document
    documentObj.add(data);

    // Close document and print stream objects
    documentObj.close();
    printStreamObj.close();
  }

  // BEGIN, CR00292749, MR
  /**
   * Generates an XML document from the specified XSL template and prints and
   * previews that document.
   *
   * @param concernRoleCommunicationDtls
   * Contains the details of the document to be used.
   *
   * @return The document details to be printed and previewed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ProFormaReturnDocDetails generatePrintAndPreviewProFormaDocument(
    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls)
    throws AppException, InformationalException {
    printProFormaDocument(concernRoleCommunicationDtls);
    return previewProFormaDocument(concernRoleCommunicationDtls);
  }

  /**
   * Generates an XML document from the specified XSL template and previews
   * that document.
   *
   * @param concernRoleCommunicationDtls
   * Contains details of the document to be previewed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link ERR_INVALID_FORMAT_NOT_PRINTABLE} - If the the
   * document format is invalid.
   */
  protected ProFormaReturnDocDetails previewProFormaDocument(
    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls)
    throws AppException, InformationalException {
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = concernRoleCommunicationDtls.concernRoleID;
    final ConcernRoleDtls concernRoleDtls = ConcernRoleFactory.newInstance().read(
      concernRoleKey);

    final ProviderNotificationDetails providerNotificationDetails = new ProviderNotificationDetails();

    providerNotificationDetails.providerName = concernRoleDtls.concernRoleName;
    providerNotificationDetails.providerRefNumber = concernRoleDtls.primaryAlternateID;
    providerNotificationDetails.providerEnrollDate = concernRoleDtls.registrationDate.toString();
    providerNotificationDetails.providerGrpName = concernRoleDtls.concernRoleName;
    providerNotificationDetails.providerGrpRefNumber = concernRoleDtls.primaryAlternateID;
    providerNotificationDetails.providerGrpEnrollDate = concernRoleDtls.registrationDate.toString();
    providerNotificationDetails.providerGrpEnrollDate = concernRoleDtls.registrationDate.toString();

    final OrganisationKey organisationKey = new OrganisationKey();

    organisationKey.organisationID = OrganisationFactory.newInstance().readOrganisationID().organisationID;
    providerNotificationDetails.organisationName = OrganisationFactory.newInstance().readNameAndAddress(organisationKey).name;

    final String userName = SystemUserFactory.newInstance().getUserDetails().userName;

    final UserKeyStruct userKeyStruct = new UserKeyStruct();

    userKeyStruct.userName = userName;

    final XMLPrintStream xmlPrintStreamObj = new XMLPrintStream();
    final ByteArrayOutputStream byteArrayOutputStreamObj = new ByteArrayOutputStream();

    xmlPrintStreamObj.setPreviewStream(byteArrayOutputStreamObj);
    xmlPrintStreamObj.setPrinterName(
      AdminUserAssistantFactory.newInstance().getUserDefaultPrinter(userKeyStruct).name);

    final XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    xslTemplateInstanceKey.templateID = concernRoleCommunicationDtls.proFormaID;
    xslTemplateInstanceKey.templateVersion = concernRoleCommunicationDtls.versionNo;
    xslTemplateInstanceKey.locale = concernRoleCommunicationDtls.localeIdentifier;
    
    // BEGIN, CR00408986, KRK
    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS_DEFAULT))) {
      
      try {
        xmlPrintStreamObj.open(xslTemplateInstanceKey);
      } catch (final AppException e) {

        // An error occurred - was the document not in valid XML format?
        if (CURAMXML.ERR_PRINT_STREAM_BAD_RESPONSE.equals(e.getCatEntry())) {
          throw new AppException(
            BPOCONCERNROLEDOCUMENTGENERATION.ERR_INVALID_FORMAT_NOT_PRINTABLE,
            e);
        } else {

          // We can't do anything with it -
          // just pass it on up to the calling method.
          throw e;
        }
      }

      final XMLDocument xmlDocumentObj = new XMLDocument(
        xmlPrintStreamObj.getStream(), XMLEncodingConstants.kEncodeUTF8);

      xmlDocumentObj.open(userName,
        Locale.getFormattedTime(DateTime.getCurrentDateTime()),
        String.valueOf(concernRoleCommunicationDtls.versionNo),
        concernRoleCommunicationDtls.comments);
      xmlDocumentObj.add(providerNotificationDetails);
      xmlDocumentObj.close();
      xmlPrintStreamObj.close();
    }
    // END, CR00408986

    final ProFormaReturnDocDetails proFormaReturnDocDetails = new ProFormaReturnDocDetails();

    StringBuilder fileName = new StringBuilder();

    fileName.append(concernRoleCommunicationDtls.subjectText);
    fileName.append(CPMConstants.kpdfExtension);
    proFormaReturnDocDetails.fileName = fileName.toString();
    proFormaReturnDocDetails.fileDate = new Blob(
      byteArrayOutputStreamObj.toByteArray());
    return proFormaReturnDocDetails;
  }

  // END, CR00292749
	
  /**
   * Records client and correspondent interaction.
   *
   * @param concernRoleCommunicationDtls Contains communication details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void recordClientInteraction(final ConcernRoleCommunicationDtls 
    concernRoleCommunicationDtls) throws AppException, 
      InformationalException {

    final ClientInteractionSupplementaryDetails clientInteractionSupplementaryDetails = new ClientInteractionSupplementaryDetails();
    final ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();

    clientInteractionSupplementaryDetails.clientDtls.dtls.concernRoleID = concernRoleCommunicationDtls.concernRoleID;
    clientInteractionSupplementaryDetails.clientDtls.dtls.relatedID = concernRoleCommunicationDtls.communicationID;
    clientInteractionSupplementaryDetails.clientDtls.dtls.description = GENERALCOMMUNICATION.INF_COMMUNICATION.getMessageText(
      TransactionInfo.getProgramLocale());
    clientInteractionSupplementaryDetails.correspondentConcernRoleID = concernRoleCommunicationDtls.correspondentConcernRoleID;
    clientInteractionSupplementaryDetails.communicationDirectionInd = false;
    clientInteractionSupplementaryDetails.clientDtls.dtls.interactionTypeCode = INTERACTIONTYPE.HARDCOPY;
    
    // create client interaction records for the communication for both the 
    // client and correspondent.
    clientInteractionObj.recordClientAndCorrespondentInteraction(
      clientInteractionSupplementaryDetails);
  }

  // END, CR00272932

  // BEGIN, CR00281474, MR
  /**
   * Gets the license notification details based on the communication ID.
   *
   * @param communicationID
   * Contains communicationID for which license notification
   * details are required.
   *
   * @return License notification details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected LicenseNotificationDetails getLicenseNotificationDetails(
    final Long communicationID) throws AppException,
      InformationalException {
    final CommunicationLicenseLink communicationLicenseLink = communicationLicenseLinkDAO.get(
      communicationID);
    final License license = licenseDAO.get(
      communicationLicenseLink.getLicense().getID());
    final LicenseNotification licenseNotification = new LicenseNotification();

    return licenseNotification.getLicenseDetails(license);
  }

  /**
   * Gets the contract notification details based on the communication ID.
   *
   * @param communicationID
   * Contains communicationID for which contract notification
   * details are required.
   *
   * @return Contract notification details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ContractNotificationDetails getContractNotificationDetails(
    final Long communicationID) throws AppException,
      InformationalException {

    final CommunicationCVLink communicationCVLink = communicationCVLinkDAO.get(
      communicationID);
    final ContractVersion contractVersion = contractVersionDAO.get(
      communicationCVLink.getContractVersion().getID());
    final ContractNotificationKey contractNotificationKey = new ContractNotificationKey();

    contractNotificationKey.contractVersionID = contractVersion.getID();
    final ContractNotification contractNotification = new ContractNotification();
    ContractNotificationDetails contractNotificationDetails = new ContractNotificationDetails();

    if (CONTRACTTYPEEntry.FLATRATE.equals(contractVersion.getContractType())) {
      contractNotificationDetails = contractNotification.getFlatRateContractDetails(
        contractNotificationKey);
    } else if (CONTRACTTYPEEntry.UTILIZATION.equals(
      contractVersion.getContractType())) {
      contractNotificationDetails = contractNotification.getUtilizationContractDetails(
        contractNotificationKey);
    }
    return contractNotificationDetails;
  }

  /**
   * Gets the financial notification details based on the communication ID.
   *
   * @param communicationID
   * Contains communicationID for which financial notification
   * details are required.
   *
   * @return Financial notification details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected FinancialNotificationDetails getFinancialNotificationDetails(
    final Long communicationID) throws AppException,
      InformationalException {

    // BEGIN, CR00304493, MR
    CommunicationSILILink communicationSILILink = null;
    final FinancialNotificationKey financialNotificationKey = new FinancialNotificationKey();
    final FinancialNotification financialNotificationObj = FinancialNotificationFactory.newInstance();
    long serviceInvoiceLineItemID = 0;

    try {
      communicationSILILink = communicationSILILinkDAO.get(communicationID);
      serviceInvoiceLineItemID = communicationSILILink.getServiceInvoiceLineItem().getID();
    } catch (final RecordNotFoundException e) {
      final CommunicationPRLILink communicationPRLILink = communicationPRLILinkDAO.get(
        communicationID);
      final ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
        communicationPRLILink.getProviderRosterLineItem().getID());

      financialNotificationKey.providerRosterLineItemID = providerRosterLineItem.getID();
      financialNotificationKey.amount = communicationPRLILink.getAmount();
      financialNotificationKey.event = communicationPRLILink.getFinancialEvent().getCode();
      if (FinancialNotificationEvent.PRLIC_OVERPAYMENT.equals(
        financialNotificationKey.event)
          || FinancialNotificationEvent.PRLIC_UNDERPAYMENT.equals(
            financialNotificationKey.event)) {
        return financialNotificationObj.getNotificationDetailsForPRLI(
          financialNotificationKey);
      }
    }
    final ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      serviceInvoiceLineItemID);

    financialNotificationKey.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
    financialNotificationKey.amount = communicationSILILink.getAmount();
    financialNotificationKey.event = communicationSILILink.getEvent().getCode();
    return financialNotificationObj.getNotificationDetails(
      financialNotificationKey);
  }

  /**
   * Gets the roster notification details based on the communication ID.
   *
   * @param communicationID
   * Contains communicationID for which roster notification details are
   * required.
   *
   * @return Roster notification details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected RosterNotificationDetails getRosterNotificationDetails(
    final Long communicationID) throws AppException, InformationalException {

    final CommunicationPRLILink communicationPRLILink = communicationPRLILinkDAO.get(
      communicationID);
    final ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      communicationPRLILink.getProviderRosterLineItem().getID());

    final RosterNotificationKey rosterNotificationKey = new RosterNotificationKey();

    rosterNotificationKey.providerRosterLineItemID = providerRosterLineItem.getID();
    rosterNotificationKey.rosterID = providerRosterLineItem.getRoster().getID();
    rosterNotificationKey.event = communicationPRLILink.getRosterEvent().getCode();
    final RosterNotification rosterNotificationObj = RosterNotificationFactory.newInstance();

    return rosterNotificationObj.getNotificationDetails(rosterNotificationKey);
  }

  // END, CR00304493
  
  /**
   * Gets the Template ID code based on the communication event.
   *
   * @param event
   * Contains communication event for which XSL template ID code is
   * required.
   *
   * @return The TemplateIDCode.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected String getTemplateIDCodeForPreview(final String event)
    throws AppException, InformationalException {

    final ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.event = event;
    
    // BEGIN, CR00304493, MR
    String templateIDCode = CPMConstants.kEmptyString;

    if (!StringUtil.isNullOrEmpty(getTemplateIDCode(providerNotificationKey))) {

      templateIDCode = getTemplateIDCode(providerNotificationKey);

    } else if (!StringUtil.isNullOrEmpty(
      getTemplateIDCodeForLicenseNotification(event))) {

      templateIDCode = getTemplateIDCodeForLicenseNotification(event);

    } else if (!StringUtil.isNullOrEmpty(
      getTemplateIDCodeForContractNotification(event))) {

      templateIDCode = getTemplateIDCodeForContractNotification(event);
    } else if (!StringUtil.isNullOrEmpty(
      getTemplateIDCodeForFinancialNotification(event))) {

      templateIDCode = getTemplateIDCodeForFinancialNotification(event);
    } else if (!StringUtil.isNullOrEmpty(
      getTemplateIDCodeForRosterNotification(event))) {

      templateIDCode = getTemplateIDCodeForRosterNotification(event);
    }
    return templateIDCode;
    
    // END, CR00304493
  }

  /**
   * Gets the Template ID code based on the contract notification event.
   *
   * @param event
   * Contains contract notification event for which XSL template ID
   * code is required.
   *
   * @return The TemplateIDCode.
   */
  protected String getTemplateIDCodeForContractNotification(final String event) {
    
    // BEGIN, CR00304493, MR
    String templateIDCode = CPMConstants.kEmptyString;

    if (ContractNotificationEvent.ACTIVATEPROVIDERCONTRACT.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERCONTRACTACTIVATIONNOTIFICATION.getCode();
    } else if (ContractNotificationEvent.ACTIVATEPGCONTRACT.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PGCONTRACTACTIVATIONNOTIFICATION.getCode();
    } else if (ContractNotificationEvent.TERMINATEPROVIDERCONTRACT.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERCONTRACTTERMINATIONNOTIFICATION.getCode();
    } else if (ContractNotificationEvent.TERMINATEPGCONTRACT.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PGCONTRACTTERMINATIONNOTIFICATION.getCode();
    } else if (ContractNotificationEvent.RENEWPROVIDERCONTRACT.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERCONTRACTRENEWALNOTIFICATION.getCode();
    } else if (ContractNotificationEvent.RENEWPGCONTRACT.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PGCONTRACTRENEWALNOTIFICATION.getCode();
    } else if (ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTREG.equals(
      event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERFLATRATECONTRACTREG.getCode();
    } else if (ContractNotificationEvent.NEWPGFLATRATECONTRACTREG.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PGFLATRATECONTRACTREG.getCode();
    } else if (ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTTOTAL.equals(
      event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERFLATRATECONTRACTTOTAL.getCode();
    } else if (ContractNotificationEvent.NEWPGFLATRATECONTRACTTOTAL.equals(
      event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PGFLATRATECONTRACTTOTAL.getCode();
    } else if (ContractNotificationEvent.NEWPROVIDERUTILIZATIONCONTRACT.equals(
      event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERUTILIZATIONCONTRACT.getCode();
    } else if (ContractNotificationEvent.NEWPGUTILIZATIONCONTRACT.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PGUTILIZATIONCONTRACT.getCode();
    } else if (ContractNotificationEvent.PROVIDERCONTRACTCOVERLETTER.equals(
      event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PROVIDERCONTRACTCOVERLETTER.getCode();
    } else if (ContractNotificationEvent.PGCONTRACTCOVERLETTER.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PGCONTRACTCOVERLETTER.getCode();
    }
    return templateIDCode;

    // END, CR00304493
  }

  /**
   * Gets the Template ID code based on the financial notification event.
   *
   * @param event
   * Contains financial notification event for which XSL template
   * ID code is required.
   *
   * @return The TemplateIDCode.
   */
  protected String getTemplateIDCodeForFinancialNotification(
    final String event) {
    
    // BEGIN, CR00304493, MR
    String templateIDCode = CPMConstants.kEmptyString;

    if (FinancialNotificationEvent.SILI_DENIED.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.SILIDENIEDNOTIFICATION.getCode();
    } else if (FinancialNotificationEvent.SILIC_UNDERPAYMENT.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.SILICORRECTIONUNDERPAYMENTNOTIFICATION.getCode();
    } else if (FinancialNotificationEvent.SILIC_OVERPAYMENT.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.SILICORRECTIONOVERPAYMENTNOTIFICATION.getCode();
    } else if (FinancialNotificationEvent.PRLIC_OVERPAYMENT.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PRLICORRECTIONOVERPAYMENTNOTIFICATION.getCode();
    } else if (FinancialNotificationEvent.PRLIC_UNDERPAYMENT.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.PRLICORRECTIONUNDERPAYMENTNOTIFICATION.getCode();
    }
    return templateIDCode;

    // END, CR00304493
  }

  // BEGIN, CR00304493, MR
  /**
   * Gets the Template ID code based on the roster notification event.
   *
   * @param event
   * Contains roster notification event for which XSL template ID code
   * is required.
   *
   * @return The TemplateIDCode.
   */
  protected String getTemplateIDCodeForRosterNotification(final String event) {
    
    String templateIDCode = CPMConstants.kEmptyString;

    if (RosterNotificationEvent.ROSTER_LINE_ITEM_DENIED.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.ROSTERLINEITEMDENIALNOTIFICATION.getCode();
    } 
    return templateIDCode;
  }

  // END, CR00304493
  
  /**
   * Gets the Template ID code based on the license notification event.
   *
   * @param event
   * Contains license notification event for which XSL template ID
   * code is required.
   *
   * @return The TemplateIDCode.
   */
  protected String getTemplateIDCodeForLicenseNotification(final String event) {
   
    // BEGIN, CR00304493, MR
    String templateIDCode = CPMConstants.kEmptyString;

    if (LicenseNotificationEvent.APPROVELICENSE.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.LICENSEAPPROVALNOTIFICATION.getCode();
    } else if (LicenseNotificationEvent.SUSPENDLICENSE.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.LICENSESUSPENSIONNOTIFICATION.getCode();
    } else if (LicenseNotificationEvent.REJECTLICENSE.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.LICENSEREJECTIONNOTIFICATION.getCode();
    } else if (LicenseNotificationEvent.RENEWLICENSE.equals(event)) {
      templateIDCode = TEMPLATEIDCODEEntry.LICENSERENEWALNOTIFICATION.getCode();
    }
    return templateIDCode;

    // END, CR00304493
  }

  /**
   * Returns the boolean value for the contract notification event.
   *
   * @param event
   * Contains notification event for which contract notifications
   * are considered.
   *
   * @return True if it is a contract notification event false otherwise.
   */
  protected boolean isContractNotificationEvent(final String event) {
    
    // BEGIN, CR00304493, MR
    boolean isContractNotification = false;

    if (ContractNotificationEvent.ACTIVATEPROVIDERCONTRACT.equals(event)
      || ContractNotificationEvent.ACTIVATEPGCONTRACT.equals(event)
      || ContractNotificationEvent.TERMINATEPROVIDERCONTRACT.equals(event)
      || ContractNotificationEvent.TERMINATEPGCONTRACT.equals(event)
      || ContractNotificationEvent.RENEWPROVIDERCONTRACT.equals(event)
      || ContractNotificationEvent.RENEWPGCONTRACT.equals(event)
      || ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTREG.equals(event)
      || ContractNotificationEvent.NEWPGFLATRATECONTRACTREG.equals(event)
      || ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTTOTAL.equals(
        event)
        || ContractNotificationEvent.NEWPGFLATRATECONTRACTTOTAL.equals(event)
        || ContractNotificationEvent.NEWPROVIDERUTILIZATIONCONTRACT.equals(
          event)
          || ContractNotificationEvent.NEWPGUTILIZATIONCONTRACT.equals(event)
          || ContractNotificationEvent.PROVIDERCONTRACTCOVERLETTER.equals(event)
          || ContractNotificationEvent.PGCONTRACTCOVERLETTER.equals(event)) {
      isContractNotification = true;
    }
    return isContractNotification;

    // END, CR00304493
  }

  /**
   * Returns the boolean value for the financial notification event.
   *
   * @param event
   * Contains notification event for which financial notifications
   * are considered.
   *
   * @return True if it is a financial notification event false otherwise.
   */
  protected boolean isFinancialNotificationEvent(final String event) {
    
    // BEGIN, CR00304493, MR
    boolean isFinancialNotification = false;

    if (FinancialNotificationEvent.SILI_DENIED.equals(event)
      || FinancialNotificationEvent.SILIC_UNDERPAYMENT.equals(event)
      || FinancialNotificationEvent.SILIC_OVERPAYMENT.equals(event)
      || FinancialNotificationEvent.PRLIC_OVERPAYMENT.equals(event)
      || FinancialNotificationEvent.PRLIC_UNDERPAYMENT.equals(event)) {
      isFinancialNotification = true;
    }
    return isFinancialNotification;

    // END, CR00304493
  }

  /**
   * Returns the boolean value for the license notification event.
   *
   * @param event
   * Contains notification event for which license notifications
   * are considered.
   *
   * @return True if it is a license notification event false otherwise.
   */
  protected boolean isLicenseNotificationEvent(final String event) {
    
    // BEGIN, CR00304493, MR
    boolean isLicenseNotification = false;

    if (LicenseNotificationEvent.APPROVELICENSE.equals(event)
      || LicenseNotificationEvent.SUSPENDLICENSE.equals(event)
      || LicenseNotificationEvent.REJECTLICENSE.equals(event)
      || LicenseNotificationEvent.RENEWLICENSE.equals(event)) {
      isLicenseNotification = true;
    }
    return isLicenseNotification;

    // END, CR00304493
  }

  // END, CR00281474
  
  // BEGIN, CR00304493, MR
  /**
   * Returns the boolean value for the roster notification event.
   *
   * @param event
   * Contains notification event for which roster notifications are
   * considered.
   *
   * @return True if it is a roster notification event false otherwise.
   */
  protected boolean isRosterNotificationEvent(final String event) {
    boolean isRosterNotification = false;

    if (RosterNotificationEvent.ROSTER_LINE_ITEM_DENIED.equals(event)) {
      isRosterNotification = true;
    }
    return isRosterNotification;
  }

  // END, CR00304493
}
