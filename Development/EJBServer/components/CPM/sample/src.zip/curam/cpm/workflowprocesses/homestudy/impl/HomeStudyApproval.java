/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 - 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.workflowprocesses.homestudy.impl;


import java.util.ArrayList;
import java.util.List;

import com.google.inject.Inject;

import curam.core.struct.ConcernRoleKey;
import curam.cpm.facade.struct.UserNameDetails;
import curam.cpm.sl.entity.struct.HomeStudyKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.workflowprocesses.homestudy.struct.HomeStudyDetails;
import curam.cpm.workflowprocesses.homestudy.struct.ProviderAndProviderOwnerDetails;
import curam.homestudy.HomeStudyReturnReason;
import curam.homestudy.impl.HomeStudy;
import curam.homestudy.impl.HomeStudyDAO;
import curam.homestudy.impl.HomeStudyStatusHistory;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.useradmin.impl.MaintainAdminConcernRole;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.CodeTable;


/**
 * Class containing all BPO methods invoked from Home Study Approval work flow
 *
 */
// Start CR00096126, JSP
public abstract class HomeStudyApproval extends curam.cpm.workflowprocesses.homestudy.base.HomeStudyApproval {
  // End CR00096126

  @Inject
  protected ProviderDAO providerDAO;
  
  @Inject
  protected HomeStudyDAO homeStudyDAO;

  /**
   * Method invoked from the Home Study approval work flow to retrieve
   * the name, reference number and owner of a provider
   *
   * @param key Concern role id for the provider.
   * @return Provider details and Provider Owner details
   * @throws InformationalException 
   *
   * @throws AppException 
   */
  public ProviderAndProviderOwnerDetails getProviderAndProviderOwnerDetails(ProviderKey key) 
    throws AppException, InformationalException {
    
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
    
    ProviderAndProviderOwnerDetails providerAndProviderOwnerDetails = new ProviderAndProviderOwnerDetails();
    
    // retrieve provider
    Provider provider = providerDAO.get(key.providerConcernRoleID);
    
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.providerConcernRoleID;
    
    // populate provider owner details
    MaintainAdminConcernRole maintainAdminConcernRoleObj = new MaintainAdminConcernRole();
    UserNameDetails owner = maintainAdminConcernRoleObj.getProviderOrganisationOwner(
      concernRoleKey);
    
    providerAndProviderOwnerDetails.owner = owner.userName;
    providerAndProviderOwnerDetails.providerID = provider.getID();
    providerAndProviderOwnerDetails.providerName = provider.getName();
    providerAndProviderOwnerDetails.providerReferenceNumber = provider.getPrimaryAlternateID();
    
    return providerAndProviderOwnerDetails;
  }
  
  /**
   * Method invoked from the Home Study approval work flow to retrieve
   * the full details of the Home Study
   *
   * @param key Home study id.
   * @return Home Study details
   *
   * @throws InformationalException  
   * @throws AppException
   */
  public HomeStudyDetails getHomeStudyDetails(HomeStudyKey key) 
    throws AppException, InformationalException {
    
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
    
    // retrieve home study
    HomeStudy homeStudy = homeStudyDAO.get(key.homeStudyID);
    
    // Set valid values for the service offering and service rate record
    HomeStudyDetails homeStudyDetails = new HomeStudyDetails();

    homeStudyDetails.homeStudyID = homeStudy.getID();
    homeStudyDetails.comments = homeStudy.getComments();
    homeStudyDetails.dateInitiated = homeStudy.getDateInitiated();
    homeStudyDetails.finalRecommendation = homeStudy.getFinalRecommendation().getCode();
    homeStudyDetails.homeStudyType = homeStudy.getHomeStudyType().getCode();
    homeStudyDetails.providerConcernRoleID = homeStudy.getProvider().getID();
    homeStudyDetails.purpose = homeStudy.getPurpose().getCode();
    homeStudyDetails.reevaluationDate = homeStudy.getReevaluationDate();
    homeStudyDetails.status = homeStudy.getLifecycleState().getCode();
    homeStudyDetails.supportForRecommendation = homeStudy.getSupportForRecommendation();
    homeStudyDetails.versionNumber = homeStudy.getVersionNo();
    homeStudyDetails.assessorName = homeStudy.getAssessor();

    List<HomeStudyStatusHistory> unModifiableHomeStudyStatusHistory = homeStudy.getStatusHistory();
    List<HomeStudyStatusHistory> homeStudyStatusHistoryRecords = new ArrayList<HomeStudyStatusHistory>();

    homeStudyStatusHistoryRecords.addAll(unModifiableHomeStudyStatusHistory);
    
    HomeStudyStatusHistory homeStudyStatusHistory = homeStudyStatusHistoryRecords.iterator().next();
    
    String sDescription;

    sDescription = CodeTable.getOneItem(HomeStudyReturnReason.TABLENAME,
      homeStudyStatusHistory.getReturnedReason().getCode());
  
    homeStudyDetails.returnedReason = sDescription;
    
    return homeStudyDetails;
    
  }
}
