/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2010, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


import com.google.inject.Inject;

import curam.codetable.impl.CASESTATUSEntry;
import curam.codetable.impl.INCIDENTSTATUSEntry;
import curam.codetable.impl.PROXIMITYDISTANCEEntry;
import curam.codetable.impl.UNITOFDISTANCEEntry;
import curam.core.impl.EnvVars;
import curam.core.sl.entity.struct.RelatedConcernRoleKey;
import curam.core.sl.struct.InvestigationDeliveryDetailsList;
import curam.core.sl.struct.InvestigationDeliveryListDetails;
import curam.cpm.facade.struct.CaseClientNameDetails;
import curam.cpm.facade.struct.ListCaseClientsNameListResult;
import curam.cpm.facade.struct.ListProviderDetailsKey;
import curam.cpm.facade.struct.ProviderSpecialtyDetail;
import curam.cpm.facade.struct.ProviderSpecialtyList;
import curam.cpm.facade.struct.ServiceProviderDetails;
import curam.cpm.facade.struct.ServiceProviderDetailsList;
import curam.cpm.impl.CPMConstants;
import curam.message.PROVIDER;
import curam.message.impl.SERVICEDELIVERYExceptionCreator;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.impl.Address;
import curam.piwrapper.impl.AddressDAO;
import curam.piwrapper.user.impl.ExternalUserParticipantLink;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderCategoryNameEntry;
import curam.provider.impl.ProviderCategoryPeriod;
import curam.provider.impl.ProviderIncident;
import curam.provider.impl.ProviderSpecialty;
import curam.provider.impl.ProviderSpecialtyTypeEntry;
import curam.provider.impl.ServiceCenterProviderOffering;
import curam.provider.impl.ServiceCenterProviderOfferingDAO;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.servicedelivery.impl.CuramConst;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.message.CatEntry;
import curam.util.persistence.helper.LifecycleHelper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


/**
 * Helper class for the service/referral processing.
 *
 * @since 6.0
 */
class ServiceProviderSearchHelperImpl implements ServiceProviderSearchHelper {

  /**
   * Reference to Provider Offering DAO.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Reference to Address DAO.
   */
  @Inject
  protected AddressDAO addressDAO;

  /**
   * Reference to Service Center Provider Offering DAO.
   */
  @Inject
  protected ServiceCenterProviderOfferingDAO serviceCenterProviderOfferingDAO;

  /**
   * Reference to Service Enquiry facade util provider instance.
   */
  @Inject
  protected com.google.inject.Provider<ServiceEnquiryFacadeUtil> serviceEnquiryFacadeUtilProvider;

  /**
   * {@inheritDoc}
   */
  public ServiceProviderDetailsList listProvidersForServiceOffering(
    final ServiceOffering serviceOffering, final Address recipientAddress,
    final List<ProviderSpecialtyTypeEntry> specialties,
    final PROXIMITYDISTANCEEntry proximityDistance, String providerName)
    throws InformationalException, AppException {
    ServiceProviderDetailsList providerDetailsList = new ServiceProviderDetailsList();

    List<ProviderOffering> providerOfferingList = getProviderOfferingList(
      serviceOffering);

    UNITOFDISTANCEEntry unitOfDistance = getMeasurementDistance();
    Address providerAddress;
    Provider provider;
    
    // BEGIN, CR00334193, GA
    providerName = providerName.trim();
    // END, CR00334193
    
    for (ProviderOffering providerOffering : providerOfferingList) {
      provider = providerOffering.getProvider();
      // BEGIN, CR00334193, GA
      if (providerName.equals(Character.toString(CuramConst.gkSqlWildcardChar))
        || providerNameMatch(provider, providerName)) {
        // END, CR00334193
        if (providerOffersSpecialty(specialties, provider)) {

          providerAddress = addressDAO.get(provider.getPrimaryAddressID());
          Double proximity = getProximityTo(recipientAddress, providerAddress,
            unitOfDistance);

          if (providerAddressWithinProximity(proximityDistance, proximity)) {
            providerDetailsList.providerDetails.addRef(
              populateProviderDetails(unitOfDistance, providerAddress, provider,
              proximity));
          }
          for (ServiceCenterProviderOffering serviceCenter : serviceCenterProviderOfferingDAO.searchByProviderOffering(
            providerOffering)) {

            Address serviceCenterAddress = addressDAO.get(
              serviceCenter.getProviderServiceCenter().getAddressID());

            proximity = getProximityTo(recipientAddress, providerAddress,
              unitOfDistance);
            if (providerAddressWithinProximity(proximityDistance, proximity)) {

              providerDetailsList.providerDetails.addRef(
                populateProviderDetails(unitOfDistance, serviceCenterAddress,
                provider, proximity));
              break;

            }
          }
        }
      }
    }
    return providerDetailsList;
  }

  /**
   * Determines if the specified provider name filter matches the providers name
   * for the specified provider offering.
   *
   * @param provider
   * provider instance to check condition match on
   * @param providerName
   * the provider name string which is to be matched
   * @return
   */
  protected boolean providerNameMatch(Provider provider, String providerName) {

    providerName = providerName.trim().toUpperCase();
    
    // BEGIN, CR00334193, GA
    if (!providerName.equals(CPMConstants.kEmptyString)) {
              	 
      providerName = providerName.replaceAll(
        Character.toString(CuramConst.gkUnderscoreChar),
        Character.toString(CuramConst.gkDotChar));
      providerName = providerName.replaceAll(
        Character.toString(CuramConst.gkSqlWildcardChar),
        CuramConst.gkZeroOrMore_AnyAlphaNumericCharacterRegExp);
      	
      if ((-1
        == providerName.indexOf(Character.toString(CuramConst.gkAsterisk)))
          && (-1
            == providerName.indexOf(Character.toString(CuramConst.gkDotChar)))) {
        	
        providerName = CuramConst.gkZeroOrMore_AnyAlphaNumericCharacterRegExp
          + providerName
          + CuramConst.gkZeroOrMore_AnyAlphaNumericCharacterRegExp; 
      }
      if (!providerName.endsWith(
        CuramConst.gkZeroOrMore_AnyAlphaNumericCharacterRegExp)) {
        providerName += CuramConst.gkZeroOrMore_AnyAlphaNumericCharacterRegExp;
      }
      if (!providerName.startsWith(
        CuramConst.gkZeroOrMore_AnyAlphaNumericCharacterRegExp)) {
        providerName = CuramConst.gkZeroOrMore_AnyAlphaNumericCharacterRegExp
          + providerName;
      }
      // END, CR00334193   

      java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(
        providerName);
    
      // perform match
      java.util.regex.Matcher matcher = pattern.matcher(
        provider.getName().toUpperCase());

      return matcher.matches();
     
    } 
    return true;
  }
  
  /**
   * Populates the ServiceProviderDetails with the given details.
   *
   * @param unitOfDistance
   * The {@link UNITOFDISTANCEEntry} the proximity has been calculated
   * in
   * @param relatedAddress
   * the {@link Address} of the {@link Provider} or a
   * {@link ServiceCenterProviderOffering} representing a location
   * where the {@link ServiceOffering} can be provided.
   * @param provider
   * The provider of the service the details to be populated are being
   * retrieved from
   * @param proximity
   * the proximity of the given address to an individuals address who
   * the service the provider is in related to is intended for
   * @return the populated ServiceProviderDetails
   * @throws AppException
   * Generic Application Exception
   * @throws InformationalException
   * Generic Application Exception
   */
  protected ServiceProviderDetails populateProviderDetails(
    final UNITOFDISTANCEEntry unitOfDistance, final Address relatedAddress,
    final Provider provider, final Double proximity)
    throws InformationalException, AppException {
    ServiceProviderDetails providerDetails;

    providerDetails = getProviderDetails(provider, relatedAddress);
    if (null != proximity) {
      providerDetails.proximity = SERVICEDELIVERYExceptionCreator.INFO_UNIT_OF_DISTANCE_TEXT(proximity, unitOfDistance.toUserLocaleString()).getLocalizedMessage();
    }
    return providerDetails;
  }

  /**
   * Determines if the address object passed in not null.
   *
   * @param address
   * the address to be determine if it is null
   * @return true if the address is not null, otherwise false
   */
  protected Boolean determineAddressExists(final Address address) {
    return address.getID() != CuramConst.gkZero;
  }

  /**
   * Gets a list of the providers offering the specified {@link ServiceOffering}
   * .
   *
   * @param serviceOffering
   * service offering object
   * @return a list, sorted by provider name, of {@link ProviderOffering}
   * instances, representing the providers of the specified service.
   */
  protected List<ProviderOffering> getProviderOfferingList(
    final ServiceOffering serviceOffering) {
    Set<ProviderOffering> providerOfferingSet = LifecycleHelper.filter(
      providerOfferingDAO.searchBy(serviceOffering),
      ProviderOfferingStatusEntry.APPROVED);
    // Convert to a list, to enable a sort.
    List<ProviderOffering> providerOfferingList = new ArrayList<ProviderOffering>(
      providerOfferingSet);

    Collections.sort(providerOfferingList,
      new Comparator<ProviderOffering>() {
      public int compare(final ProviderOffering lhs, final ProviderOffering rhs) {
        return rhs.getProvider().getName().compareTo(
          lhs.getProvider().getName());
      }
    });
    return providerOfferingList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderSpecialtyList getProviderSpecialityCodesAsList()
    throws AppException, InformationalException {
    ProviderSpecialtyList providerSpecialtyList = new ProviderSpecialtyList();
    LinkedHashMap<String, String> codes = CodeTable.getAllEnabledItems(
      ProviderSpecialtyTypeEntry.TABLENAME, TransactionInfo.getProgramLocale());
    ProviderSpecialtyDetail providerSpecialty;

    for (String code : codes.keySet()) {
      providerSpecialty = new ProviderSpecialtyDetail();
      providerSpecialty.specialtyCode = code;
      providerSpecialty.specialtyDescription = codes.get(code);
      providerSpecialtyList.specialtyDetails.addRef(providerSpecialty);
    }
    return providerSpecialtyList;
  }

  /**
   * Populates the {@link ServiceProviderDetails} using the details of the given
   * parameters.
   *
   * @param provider
   * The {@link Provider} to retrieve the details for populated the
   * provider details from
   * @param providerAddress
   * The address of the provider from the address contained in
   * {@link ListProviderDetailsKey}
   * @return The populated {@link ReferralProviderDetails} struct
   * @throws AppException
   * Generic Application Exception
   * @throws InformationalException
   * Generic Application Exception
   */
  protected ServiceProviderDetails getProviderDetails(final Provider provider,
    final Address providerAddress) throws InformationalException,
      AppException {
    ServiceProviderDetails providerDetails = new ServiceProviderDetails();
    ExternalUserParticipantLink externalUserParticipantLink;

    providerDetails.providerID = provider.getID();
    providerDetails.providerName = provider.getName();

    // Get the primary provider category.
    final ProviderCategoryPeriod providerCategoryPeriod = provider.getPrimaryProviderCategoryPeriod();

    if (null != providerCategoryPeriod) {
      providerDetails.providerCategory = ProviderCategoryNameEntry.get(providerCategoryPeriod.getCategory().getCode()).getCode();
    }

    providerDetails.providerSpecialties = getProviderSpecialties(provider);
    providerDetails.providerAddress = providerAddress.getOneLineAddressString();
    if (null != provider.getEmailAddress()) {
      providerDetails.emailAddressInd = true;
    }
    externalUserParticipantLink = serviceEnquiryFacadeUtilProvider.get().getproviderExternalLink(
      provider);

    if (null != externalUserParticipantLink) {
      providerDetails.webPortalAccessInd = true;
    }
    boolean providerIncidentsExist = hasProviderIncidents(provider);
    boolean providerInvestigationsExist = hasProviderOpenInvestigations(
      provider);

    if (providerIncidentsExist && providerInvestigationsExist) {
      providerDetails.openInvestigationsIncidentsIconXML = addOpenInvestigationIncidentXML(
        PROVIDER.INF_OPEN_INVESTIGATIONS_INCIDENTS_FOR_PROVIDER);
    } else if (providerIncidentsExist) {
      providerDetails.openInvestigationsIncidentsIconXML = addOpenInvestigationIncidentXML(
        PROVIDER.INF_OPEN_INCIDENTS_FOR_PROVIDER);
    } else if (providerInvestigationsExist) {
      providerDetails.openInvestigationsIncidentsIconXML = addOpenInvestigationIncidentXML(
        PROVIDER.INF_OPEN_INVESTIGATIONS_FOR_PROVIDER);
    }
    return providerDetails;
  }

  /**
   * Determines if there are any open incidents for a provider.
   *
   * @param provider
   * the provider instance
   * @return indicator for open incidents existing for the provider, where open
   * refers to any incident which is not in a 'Closed' or 'Cancelled'
   * state.
   * @throws AppException
   * Generic Application Exception
   * @throws InformationalException
   * Generic Exception Signature
   */
  protected boolean hasProviderIncidents(final Provider provider) {
    List<ProviderIncident> providerIncidents = provider.getIncidents();

    for (ProviderIncident providerIncident : providerIncidents) {
      if (providerIncident.getLifecycleState().equals(
        INCIDENTSTATUSEntry.CANCELLED)
          || (providerIncident.getLifecycleState().equals(
            INCIDENTSTATUSEntry.CLOSED))) {
        continue;
      } else {
        return true;
      }
    }
    return false;
  }

  /**
   * Determines if there are any open investigations for a provider.
   *
   * @param provider
   * the provider instance
   * @return indicator for open investigations existing for the provider, where
   * open refers to any investigation which is not in a 'Closed' or
   * 'Cancelled' state.
   * @throws AppException
   * Generic Application Exception
   * @throws InformationalException
   * Generic Exception Signature
   */
  protected boolean hasProviderOpenInvestigations(Provider provider)
    throws AppException, InformationalException {

    RelatedConcernRoleKey relatedConcernRoleKey = new RelatedConcernRoleKey();

    relatedConcernRoleKey.relatedConcernRoleID = provider.getID();

    InvestigationDeliveryDetailsList investigations = curam.core.sl.fact.InvestigationDeliveryFactory.newInstance().listInvestigationByRelatedConcernID(
      relatedConcernRoleKey);

    for (InvestigationDeliveryListDetails investigation : investigations.dtlsList) {
      if ((investigation.status.equals(CASESTATUSEntry.CLOSED.getCode()))
        || (investigation.status.equals(CASESTATUSEntry.CANCELED.getCode()))) {
        continue;
      } else {
        return true;
      }
    }
    return false;
  }

  /**
   * Populates the xml data required to render the open investigations or
   * incidents icon for a provider.
   *
   * @return the xml data containing the data required to render the icon.
   * @throws AppException
   * Generic Application Exception
   * @throws InformationalException
   * Generic Exception Signature
   */
  protected String addOpenInvestigationIncidentXML(CatEntry tooltipMessage)
    throws InformationalException, AppException {

    Document document = DomUtils.createNewDocument();
    final Element openInvestigationsIncidentsIndicator = document.createElement(
      CuramConst.kOpenInvestigationsIncidentsElement);

    openInvestigationsIncidentsIndicator.setAttribute(
      CuramConst.kTooltipElement, tooltipMessage.getMessageText());
    document.appendChild(openInvestigationsIncidentsIndicator);

    return DomUtils.convertDocumentToText(document);
  }

  /**
   * Determines if the proximity to the specified provider address is within the
   * specified proximity distance.
   *
   * @param proximityDistance
   * proximity distance filter
   * @param providerAddressProximity
   * proximity to the provider address
   * @return true if the address is within the proximity, false otherwise
   */
  protected boolean providerAddressWithinProximity(
    final PROXIMITYDISTANCEEntry proximityDistance,
    final Double providerAddressProximity) {

    if (proximityDistance.equals(PROXIMITYDISTANCEEntry.NOT_SPECIFIED)) {
      return true;
    } else if (null == providerAddressProximity) {
      return false;
    } else if (proximityDistance.equals(PROXIMITYDISTANCEEntry.ONE)) {
      return providerAddressProximity <= CuramConst.gkOne;

    } else if (proximityDistance.equals(PROXIMITYDISTANCEEntry.TWO)) {
      return providerAddressProximity <= CPMConstants.gkTwo;
    } else if (proximityDistance.equals(PROXIMITYDISTANCEEntry.THREE)) {
      return providerAddressProximity <= CuramConst.gkThree;
    } else if (proximityDistance.equals(PROXIMITYDISTANCEEntry.FOUR)) {
      return providerAddressProximity <= CuramConst.gkFour;
    } else if (proximityDistance.equals(PROXIMITYDISTANCEEntry.FIVE)) {
      return providerAddressProximity <= CuramConst.gkFive;
    } else if (proximityDistance.equals(PROXIMITYDISTANCEEntry.TEN)) {
      return providerAddressProximity <= CuramConst.gkTen;
    } else if (proximityDistance.equals(PROXIMITYDISTANCEEntry.TWENTY)) {
      return providerAddressProximity <= CuramConst.gkTwenty;
    }
    return true;
  }

  /**
   * Retrieves the proximity between this address and the given address.
   * <p>
   * To determine the proximity between the two addresses the HaverSine formula
   * is used. If a geoCode, longitude or latitude do not exist for either this
   * address or the related address null is returned. If either address is null,
   * null is returned.
   * </p>
   *
   * @param clientAddress
   * the address of the client
   * @param relatedAddress
   * The address of the provider
   * @param unitOfDistance
   * the unit of measurement the calculated proximity is to be returned
   * in
   * @return The proximity of this address to the given address if a geoCode,
   * longitude, and latitude details exist for both addresses, otherwise
   * null
   */
  protected Double getProximityTo(final Address clientAddress,
    final Address relatedAddress, final UNITOFDISTANCEEntry unitOfDistance) {

    if (!possibleToCalculateProximity(clientAddress, relatedAddress)) {
      return null;
    }

    // get the difference of the points in radians
    Double differenceInLatitude = Math.toRadians(
      relatedAddress.getLatitude() - clientAddress.getLatitude());
    Double differenceInLongitude = Math.toRadians(
      relatedAddress.getLongitude() - clientAddress.getLongitude());

    // calculate the proximity between the addresses
    Double a = Math.sin(differenceInLatitude / 2)
      * Math.sin(differenceInLatitude / 2)
        + Math.cos(Math.toRadians(clientAddress.getLatitude()))
          * Math.cos(Math.toRadians(relatedAddress.getLatitude()))
          * Math.sin(differenceInLongitude / 2)
          * Math.sin(differenceInLongitude / 2);
    Double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    Double proximity = getRadius(unitOfDistance) * c;

    BigDecimal bigDecimal = new BigDecimal(proximity);
    BigDecimal proximityRounded = bigDecimal.setScale(
      getNumDigitsAfterDecimalPoint(), BigDecimal.ROUND_HALF_UP);

    return proximityRounded.doubleValue();

  }

  /**
   * Determines if it is possible to calculate the proximity between this
   * address and the given address.
   *
   * @param clientAddress
   * the address of the client
   * @param relatedAddress
   * the address of the provider
   * @return true if it is possible to calculate the proximity, otherwise false
   */
  protected boolean possibleToCalculateProximity(final Address clientAddress,
    final Address relatedAddress) {

    if (!determineAddressExists(clientAddress)
      || !determineAddressExists(relatedAddress)) {
      return false;
    }

    if (longitudeLatiduteCoordinatesDontExist(relatedAddress)) {
      return false;
    }

    if (longitudeLatiduteCoordinatesDontExist(clientAddress)) {
      return false;
    }

    return true;
  }

  /**
   * Determines if longitude and latitude co-ordinates have been entered for the
   * given addresses.
   *
   * @param address
   * the address to determine if longitude and latitude co-ordinates
   * have been entered
   * @return true if longitude and latitude co-ordinates have not been entered,
   * otherwise false
   */
  protected boolean longitudeLatiduteCoordinatesDontExist(final Address address) {
    return address.getLongitude() == CuramConst.gkZero
      && address.getLatitude() == CuramConst.gkZero;
  }

  /**
   * Retrieves the radius of the earth depending on the unit of distance that
   * was specified.
   *
   * @param unitOfDistance
   * the unit of distance the retrieved radius of the earth is to be
   * measured in
   * @return the radius of the earth, with the distance depending on the passed
   * in {@link UNITOFDISTANCEEntry}
   */
  protected int getRadius(final UNITOFDISTANCEEntry unitOfDistance) {
    int radius;

    if (unitOfDistance.equals(UNITOFDISTANCEEntry.KILOMETER)) {
      radius = CuramConst.kRadiusOfEarthKilometers;
    } else {
      radius = CuramConst.kRadiusOfEarthMiles;
    }
    return radius;
  }

  /**
   * Retrieves the list number of decimal digits the calculated proximity is to
   * be rounded to, configured in the
   * {@link curam.core.impl.EnvVars#ENV_PROXIMITY_NUMBER_OF_DECIMAL_POINTS}.
   *
   * @return the number of decimal digits the calculated proximity is to be
   * rounded to
   */
  protected int getNumDigitsAfterDecimalPoint() {

    Integer numDigitsAfterDecimalPoint = Integer.parseInt(
      Configuration.getProperty(EnvVars.ENV_PROXIMITY_NUMBER_OF_DECIMAL_POINTS));

    if (null == numDigitsAfterDecimalPoint) {
      numDigitsAfterDecimalPoint = EnvVars.ENV_PROXIMITY_NUMBER_OF_DECIMAL_POINTS_DEFAULT;
    }
    return numDigitsAfterDecimalPoint;
  }

  /**
   * Retrieves a comma separated list of the specialties, if any, the provider
   * is listed for. If the provider does not have any specialties listed for it
   * an empty string is returned.
   *
   * @param provider
   * the provider to retrieve the specialty details from
   * @return a comma separated list of the providers specialties, or an empty
   * string if no specialties exist for the provider
   * @since 6.0
   */
  protected String getProviderSpecialties(final Provider provider) {
    StringBuffer providerSpecialties = new StringBuffer();

    java.util.Iterator<ProviderSpecialty> providerSpecialityIterator = provider.getProviderSpecialties().iterator();

    while (providerSpecialityIterator.hasNext()) {
      ProviderSpecialty providerSpecialty = providerSpecialityIterator.next();

      providerSpecialties.append(
        providerSpecialty.getSpecialty().toUserLocaleString());

      if (providerSpecialityIterator.hasNext()) {
        providerSpecialties.append(CuramConst.gkComma + CuramConst.gkSpace);
      }

    }
    return providerSpecialties.toString();
  }

  /**
   * {@inheritDoc}
   */
  public UNITOFDISTANCEEntry getMeasurementDistance() {

    String unitOfDistance = Configuration.getProperty(
      EnvVars.ENV_PROXIMITY_CALCULATE_DISTANCE_MEASUREMENT);

    if (null == unitOfDistance) {
      unitOfDistance = EnvVars.ENV_PROXIMITY_CALCULATE_DISTANCE_MEASUREMENT_DEFAULT;
    }
    return UNITOFDISTANCEEntry.get(unitOfDistance);

  }

  /**
   * Determines if the {@link Provider} offers the
   * {@link ProviderSpecialtyTypeEntry}.
   *
   * @param requiredProviderSpecialties
   * the required provider specialties
   * @param provider
   * the provider to determine if it is offering the given Provider
   * Specialty
   * @return true if the provider is offering the provider specialty, false
   * otherwise
   * @since 6.0
   */
  protected boolean providerOffersSpecialty(
    final List<ProviderSpecialtyTypeEntry> requiredProviderSpecialties,
    final Provider provider) {

    if (0 == requiredProviderSpecialties.size()) {
      return true;
    }
    Set<ProviderSpecialty> providerSpecialtyList = provider.getProviderSpecialties();

    for (ProviderSpecialtyTypeEntry requiredSpecialty : requiredProviderSpecialties) {
      for (ProviderSpecialty specialty : providerSpecialtyList) {
        if (specialty.getSpecialty().equals(requiredSpecialty)) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * {@inheritDoc}
   */
  public ListCaseClientsNameListResult getCaseClientsNameList(
    final List<CaseParticipantRole> caseParticipantRoles)
    throws AppException, InformationalException {

    ListCaseClientsNameListResult listCaseClientsNameListResult = new ListCaseClientsNameListResult();

    for (CaseParticipantRole caseParticipantRole : caseParticipantRoles) {
      CaseClientNameDetails caseClientNameDetails = new CaseClientNameDetails();

      caseClientNameDetails.caseParticipantRoleID = caseParticipantRole.getID();
      caseClientNameDetails.recipientName = caseParticipantRole.getConcernRole().getName();
      listCaseClientsNameListResult.clientNameDetails.addRef(
        caseClientNameDetails);
    }
    return listCaseClientsNameListResult;
  }
}
