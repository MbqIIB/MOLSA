/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.util.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Utility interface which has method to generate reference number which is a
 * unique identifier. The generation mechanism can be changed by the custom
 * implementations of the class.
 */
@ImplementedBy(ReferenceNumberUtilityImpl.class)
public interface ReferenceNumberUtility {

  // BEGIN, CR00170638, GP
  /**
   * Generates reference number and returns the string representation of the
   * same. The generation mechanism involves creation of a unique identifier
   * which is combination of current date time along with the random number.
   *
   * @return String representation of the reference number.
   *
   * @deprecated This is replaced by {@link #generateRosterReferenceNumber()}.
   * This method does not throw AppException and
   * InformationalException and UniqueID.getNextIDFromKeySet used
   * for generation of continuous sequential throws AppException and
   * InformationException. Roster reference number is continuous
   * sequential so another method
   * {@link #generateRosterReferenceNumber()} is provided for this
   * purpose.
   * @deprecated -since 6.0.
   */
  String generateReferenceNumber();

  // BEGIN, CR00186039, GP
  /**
   * Generates a unique sequential reference number and returns the string
   * representation of the same.
   *
   * @return String representation of the reference number.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00186039
  String generateRosterReferenceNumber() throws AppException,
      InformationalException;
  // END, CR00170638
  
  // BEGIN, CR00314817, GYH
  /**
   * Generates a reference number from the key server for the given key set identifier.
   *
   * @return The reference number.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  String generateReferenceNumber(final String keySetName) throws AppException,
      InformationalException;
  // END, CR00314817

}
