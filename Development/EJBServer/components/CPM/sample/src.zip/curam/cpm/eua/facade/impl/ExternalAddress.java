/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.struct.ReadParticipantAddressDetails;
import curam.core.facade.struct.ReadParticipantAddressKey;
import curam.core.facade.struct.ReadParticipantAddressList;
import curam.core.fact.ConcernRoleAddressFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRoleAddress;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.struct.AddressTabDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressElementStruct;
import curam.core.struct.AddressKey;
import curam.core.struct.AddressRMDtls;
import curam.core.struct.AddressReadMultiDtlsList;
import curam.core.struct.AddressReadMultiKey;
import curam.core.struct.ConcernRoleAddressDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ReadMultiByConcRoleIDResult;
import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.facade.fact.ContextDescriptionFactory;
import curam.cpm.facade.intf.ContextDescription;
import curam.participant.impl.ConcernRoleDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;


/**
 * This process class provides the functionality for ExternalAddress
 * functionality through the External User Access application
 */
public abstract class ExternalAddress extends curam.cpm.eua.facade.base.ExternalAddress {
  
  /**
   * Constructor
   */
  public ExternalAddress() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }
  
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * This method is called from the client and returns a list of addresses
   * based on the logged in user 
   *
   * @param concernRoleKey - containing a concernRoleID 
   * @return Contains  a list of addresses for the Concern Role
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ReadParticipantAddressList listAddresses(
    ConcernRoleKey concernRoleKey) throws AppException, InformationalException {
    
    // Address manipulation variables
    ReadParticipantAddressList readParticipantAddressList = new ReadParticipantAddressList();
    ConcernRoleAddress concernRoleAddressObj = ConcernRoleAddressFactory.newInstance();
    AddressReadMultiKey addressReadMultiKey = new AddressReadMultiKey();
    AddressReadMultiDtlsList addressReadMultiDtlsList;
    OtherAddressData otherAddressData = new OtherAddressData();
    AddressElementStruct addressElementStruct;
    curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    
    // informational manager variable
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();
    
    ReadMultiByConcRoleIDResult addressListResult = new ReadMultiByConcRoleIDResult();
    
    // call security check
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();
    
    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);
       
    // set the key for reading addresses
    addressReadMultiKey.concernRoleID = concernRoleKey.concernRoleID;
    // Read concernRoleAddress from database
    addressReadMultiDtlsList = concernRoleAddressObj.searchAddressesByConcernRole(
      addressReadMultiKey);

    // Reserve space
    addressListResult.details.dtls.ensureCapacity(
      addressReadMultiDtlsList.dtls.size());

    // perform iteration
    for (int i = 0; i < addressReadMultiDtlsList.dtls.size(); i++) {

      AddressRMDtls addressRMDtls = new AddressRMDtls();

      // map structure
      addressRMDtls.assign(addressReadMultiDtlsList.dtls.item(i));
      // get first address line
      otherAddressData.addressData = addressReadMultiDtlsList.dtls.item(i).addressData;
     
      // BEGIN, CR00236455, GP
      TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
      AddressTabDetails addressTabDetails = new AddressTabDetails();

      addressTabDetails.addressData = otherAddressData.addressData;
      addressRMDtls.addressLine1 = tabDetailFormatterObj.formatAddress(addressTabDetails).addressString;
      // END, CR00236455
      
      addressElementStruct = addressObj.getCity(otherAddressData);
      addressRMDtls.city = addressElementStruct.addressElementString;

      // if returned addressID and primary address ID are the same
      if (addressReadMultiDtlsList.dtls.item(i).addressID
        == concernRoleDAO.get(concernRoleKey.concernRoleID).getPrimaryAddressID()) {
        addressRMDtls.primaryInd = true;

        if (!(addressReadMultiDtlsList.dtls.item(i).endDate.isZero())
          && (addressReadMultiDtlsList.dtls.item(i).endDate.before(
            Date.getCurrentDate()))) {

          // The end date has passed on the primary record, display an
          // informational saying as such.
          AppException e = new AppException(
            curam.message.GENERALCONCERN.ERR_CONCERNROLE_FV_ADDRESS_DATE_PASSED);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            e.arg(true), CuramConst.gkEmpty,
            curam.util.exception.InformationalElement.InformationalType.kWarning,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        }

      } else {
        addressRMDtls.primaryInd = false;
      }
      
      // only add addresses that are not canceled to the list
      if (!addressRMDtls.statusCode.equals(
        RECORDSTATUSEntry.CANCELLED.getCode())) {
        // add to list
        readParticipantAddressList.readMultiByConcRoleIDResult.details.dtls.addRef(
          addressRMDtls);
         
      }

    }

    // variables for reading the context description
    ContextDescription contextDescription = ContextDescriptionFactory.newInstance();
    
    // Get the context description for the concern role
    readParticipantAddressList.participantContextDescriptionDetails.description = contextDescription.getContextDescriptionForConcern(concernRoleKey).description;
    
    return readParticipantAddressList;
    
  }

  /**
   * This method is called from the client and returns details of a concern
   * Role Address based on a key passed in.
   *
   * @param key - contains the concernRoleAddressID
   *
   * @return contains the address Details.
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ReadParticipantAddressDetails viewAddress(
    ReadParticipantAddressKey key) throws AppException, InformationalException {
    
    // result
    ReadParticipantAddressDetails readParticipantAddressDetails = new ReadParticipantAddressDetails();
    
    // Concern role address object, struct and key
    ParticipantEvidenceInterface concernRoleAddressObj = (ParticipantEvidenceInterface) ConcernRoleAddressFactory.newInstance();
    EIEvidenceKey evidenceKey = new EIEvidenceKey();
    ConcernRoleAddressDtls concernRoleAddressDtls;
    
    // Address manipulation variables
    curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    AddressDtls addressDtls;
    AddressKey addressKey = new AddressKey();
    
    // set the key
    evidenceKey.evidenceID = key.readConcernRoleAddressKey.concernRoleAddressID;

    // read concernRoleAddress from database
    concernRoleAddressDtls = (ConcernRoleAddressDtls) concernRoleAddressObj.readEvidence(
      evidenceKey);
    
    // call security check
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();
    
    concernRoleKey.concernRoleID = concernRoleAddressDtls.concernRoleID;
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    
    // this will throw error if user does not have access.
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);
    
    // set the details
    readParticipantAddressDetails.addressDetails.assign(concernRoleAddressDtls);

    // set the version number explicitly
    readParticipantAddressDetails.addressDetails.concernRoleAddressVersionNo = concernRoleAddressDtls.versionNo;

    // set the key for reading address
    addressKey.addressID = concernRoleAddressDtls.addressID;
    // read address from database
    addressDtls = addressObj.read(addressKey);

    // set the version number explicitly
    readParticipantAddressDetails.addressDetails.addressVersionNo = addressDtls.versionNo;

    // map obtained address information to output structures
    OtherAddressData addressDataStr = new OtherAddressData();

    addressDataStr.addressData = addressDtls.addressData;

    readParticipantAddressDetails.addressDetails.addressData = addressDtls.addressData;
    addressObj.getLongFormat(addressDataStr);
    readParticipantAddressDetails.addressDetails.formattedAddressData = addressDataStr.addressData;

    // find the primary address indicator
    // read concern role address
    // set the key for reading concernRole

    // Set the result field for primary address indicator
    if (concernRoleAddressDtls.addressID
      == concernRoleDAO.get(readParticipantAddressDetails.addressDetails.concernRoleID).getPrimaryAddressID()) {
      readParticipantAddressDetails.addressDetails.primaryAddressInd = true;
    } else {
      readParticipantAddressDetails.addressDetails.primaryAddressInd = false;
    }
    
    // Context Description variables
    ContextDescription contextDescription = ContextDescriptionFactory.newInstance();
    
    // Get the context description for the concern role
    readParticipantAddressDetails.participantContextDescriptionDetails.description = contextDescription.getContextDescriptionForConcern(concernRoleKey).description;
    
    return readParticipantAddressDetails;
  }

}
