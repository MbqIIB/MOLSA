/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import com.google.inject.Inject;

import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.cefwidgets.docbuilder.impl.ImagePanelBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.cefwidgets.docbuilder.impl.LinksPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ListBuilder;
import curam.cefwidgets.docbuilder.impl.TooltipBuilder;
import curam.cefwidgets.docbuilder.impl.helper.impl.CodeTableItemEntry;
import curam.cefwidgets.docbuilder.impl.helper.impl.DocBuilderHelperFactory;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.CONTACTLOGTYPE;
import curam.codetable.INVESTIGATECONFIGTYPE;
import curam.codetable.INVESTIGDELIVERYSUBTYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.RESOLUTIONCONIFIGURATION;
import curam.codetable.impl.CONTACTLOGLINKTYPEEntry;
import curam.core.facade.fact.InvestigationTabFactory;
import curam.core.facade.intf.InvestigationTab;
import curam.core.facade.struct.ICProductDeliveryCaseRelationshipDetails;
import curam.core.facade.struct.ICProductDeliveryNoteDetails;
import curam.core.facade.struct.ICProductDeliveryNoteDetails1;
import curam.core.facade.struct.ICProductDeliveryStatusHistoryDetails;
import curam.core.facade.struct.InvestigationDeliveryEventAndActivityDetails1;
import curam.core.facade.struct.InvestigationDeliveryMenuDataDetails;
import curam.core.facade.struct.SearchCaseEventAndActivityKey;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.HomePageIdentifier;
import curam.core.sl.entity.struct.InvestigationDeliveryDtls;
import curam.core.sl.entity.struct.InvestigationDeliveryKey;
import curam.core.sl.entity.struct.InvestigationDeliveryTabDtls;
import curam.core.sl.entity.struct.InvestigationTabDtlsList;
import curam.core.sl.entity.struct.LinkKey;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.RelatedConcernRoleKey;
import curam.core.sl.entity.struct.SearchInvestigationKey;
import curam.core.sl.entity.struct.SearchInvestigationRoleKey;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.ConcernRoleImageFactory;
import curam.core.sl.fact.ContactLogFactory;
import curam.core.sl.fact.InvestigationDeliveryFactory;
import curam.core.sl.fact.MilestoneDeliveryFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.fact.TabDetailsHelperFactory;
import curam.core.sl.impl.CaseTabDetailsHelper;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.ConcernRoleImage;
import curam.core.sl.intf.InvestigationDelivery;
import curam.core.sl.intf.MilestoneDelivery;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.intf.TabDetailsHelper;
import curam.core.sl.struct.CaseAndConcernLinkedTaskDtls;
import curam.core.sl.struct.CaseIDAndConcernRoleIDKey;
import curam.core.sl.struct.CaseMemberTabDetails;
import curam.core.sl.struct.CaseNoteList1;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.CommunicationKey;
import curam.core.sl.struct.ContactLogLinkIDLinkTypeKey;
import curam.core.sl.struct.ContactLogTabDetails;
import curam.core.sl.struct.ContactTabDetails;
import curam.core.sl.struct.IncidentAndRoleTabDetailsList;
import curam.core.sl.struct.InvestigationAndRoleTabDetails;
import curam.core.sl.struct.InvestigationAndRoleTabDetailsList;
import curam.core.sl.struct.InvestigationCreationDetails;
import curam.core.sl.struct.InvestigationTabDetails;
import curam.core.sl.struct.ReadContactLogDetails;
import curam.core.sl.struct.SearchTaskForConcernOrCaseKey;
import curam.core.sl.struct.ViewCaseParticipantRoleDetailsList;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.core.struct.AttachmentCaseID;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseIDAndRecordStatus;
import curam.core.struct.CaseIDAndTypeCodeKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseStatusHistoryDetailsList1;
import curam.core.struct.CaseStatusHistoryKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.GetRelatedCasesKey;
import curam.core.struct.GetRelatedCasesList;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.IntegratedCaseKey;
import curam.core.struct.RelatedCaseProductType;
import curam.core.struct.UsersKey;
import curam.core.struct.ViewActiveCaseEventDetails;
import curam.core.struct.ViewActiveCaseEventDetailsList;
import curam.core.struct.ViewActiveCaseEventDetailsList1;
import curam.core.struct.ViewCaseEventsByCaseIDAndTypeKey;
import curam.cpm.facade.fact.ProviderFactory;
import curam.cpm.facade.intf.Provider;
import curam.cpm.facade.struct.InvestigationDeliveryListForProvider;
import curam.cpm.facade.struct.InvestigationInd;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryActionPlanList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryAllegationList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryAttachmentList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryClientRoleList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryCommunicationList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryContactLogList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryEventList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryMilestoneList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryNoteList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryRelatedCaseList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryStatusHistoryList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryTaskList;
import curam.cpm.facade.struct.ProviderInvestigationDeliveryUserRoleList;
import curam.cpm.facade.struct.ProviderInvestigationEventAndActivityDetails;
import curam.cpm.facade.struct.ProviderInvestigationHomeDtls;
import curam.cpm.facade.struct.ProviderInvestigationTabDetails;
import curam.cpm.facade.struct.ViewProviderSummaryDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderInvestigationDetails;
import curam.cpm.sl.entity.struct.ProviderInvestigationDetailsList;
import curam.message.BPOCASETAB;
import curam.message.BPOINVESTIGATIONTAB;
import curam.message.BPOPARTICIPANT;
import curam.message.PROVIDERINVESTIGATION;
import curam.provider.impl.ProviderDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;


/**
 * {@inheritDoc}
 */
public abstract class ProviderInvestigation extends curam.cpm.facade.base.ProviderInvestigation {

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kParamCaseID = XmlMetaDataConst.kParamCaseID;

  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kParamCaseParticipantRoleID = XmlMetaDataConst.kParamCaseParticipantRoleID;

  protected static final String kParamConcernRoleID = XmlMetaDataConst.kParamConcernRoleID;

  protected static final String kTypeCase = XmlMetaDataConst.kTypeCase;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kTypeProduct = XmlMetaDataConst.kTypeProduct;

  protected static final String kTypeInvestigation = XmlMetaDataConst.kTypeInvestigation;

  protected static final String kQuote = CuramCalendarHeaderConst.kQuote;

  protected static final String kSpace = CuramCalendarHeaderConst.kSpace;

  // BEGIN, CR00197371, GP
  /**
   * Reference to Provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  // END, CR00197371

  /**
   * Constructor for the class.
   */
  public ProviderInvestigation() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryList listProviderInvestigations(
    ProviderConcernRoleKey key) throws AppException, InformationalException {

    Provider providerObj = ProviderFactory.newInstance();

    ProviderInvestigationDeliveryList providerInvestigationDeliveryList = new ProviderInvestigationDeliveryList();

    RelatedConcernRoleKey relatedConcernRoleKey = new RelatedConcernRoleKey();

    relatedConcernRoleKey.relatedConcernRoleID = key.providerConcernRoleID;

    providerInvestigationDeliveryList.investigationDeliveryDetailsList = curam.core.sl.fact.InvestigationDeliveryFactory.newInstance().listInvestigationByRelatedConcernID(
      relatedConcernRoleKey);

    ViewProviderSummaryDetails viewProviderSummaryDetails = providerObj.readProviderSummaryDetails(
      key);

    providerInvestigationDeliveryList.viewProviderSummaryDetails = viewProviderSummaryDetails;

    return providerInvestigationDeliveryList;

  }
  
  /**
   * {@inheritDoc}
   */
  public InvestigationDeliveryKey createProviderInvestigation(
    InvestigationCreationDetails details) throws AppException,
      InformationalException {

    InvestigationDelivery investigationDeliveryObj = InvestigationDeliveryFactory.newInstance();

    return investigationDeliveryObj.createInvestigationDelivery(details);

  }

  /**
   * Reads the menu data for a provider investigation.
   *
   * @param key
   * The key of the investigation.
   * @return The menu data details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InvestigationDeliveryMenuDataDetails getProviderInvestigationDeliveryMenuData(
    CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    InvestigationDeliveryMenuDataDetails investigationDeliveryMenuDataDetails = new InvestigationDeliveryMenuDataDetails();

    // CaseHeader manipulation variables
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseKey caseKey = new CaseKey();

    // InvestigationDelivery manipulation variables
    curam.core.sl.entity.intf.InvestigationDelivery investigationDeliveryObj = curam.core.sl.entity.fact.InvestigationDeliveryFactory.newInstance();
    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    InvestigationDeliveryDtls investigationDeliveryDtls;

    // ConcernRole manipulation variables
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set key to read Investigation Delivery
    investigationDeliveryKey.caseID = key.caseID;

    // Read Investigation Delivery
    investigationDeliveryDtls = investigationDeliveryObj.read(
      investigationDeliveryKey);

    // Read the case header details
    CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(key);

    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    // Read concernRoleName
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Set key to read productDelivery
    caseKey.caseID = key.caseID;

    // Read Investigation Delivery to retrieve the case home page name
    HomePageIdentifier homePageIdentifier = investigationDeliveryObj.readHomePageIdentifier(
      investigationDeliveryKey);

    // Create Root Node
    Element navigationMenuElement = new Element(kNavigationMenu);

    // Create Child Node
    Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID, CPMConstants.kProviderListInvestigation);

    LocalisableString description = new LocalisableString(
      PROVIDERINVESTIGATION.INF_PROVIDER_MENU_DESCRIPTION);

    description.arg(concernRoleDtls.concernRoleName);
    description.arg(concernRoleDtls.primaryAlternateID);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    navigationMenuElement.addContent(linkElement);

    Element paramElement = new Element(kParam);

    paramElement = new Element(kParam);
    paramElement.setAttribute(kName, kParamConcernRoleID);
    paramElement.setAttribute(kValue,
      Long.toString(concernRoleKey.concernRoleID));

    linkElement.addContent(paramElement);

    // Create product item child element and add it to the root
    linkElement = new Element(kItem);
    linkElement.setAttribute(kPageID, homePageIdentifier.homePageIdentifier);

    description = new LocalisableString(
      PROVIDERINVESTIGATION.INF_INVESTIGATION_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(
        curam.codetable.INVESTIGATECONFIGTYPE.TABLENAME,
        investigationDeliveryDtls.investigationType));
    description.arg(caseHeaderDtls.caseReference);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeInvestigation);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);
    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue, Long.toString(key.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    XMLOutputter outputter = new XMLOutputter();

    investigationDeliveryMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return investigationDeliveryMenuDataDetails;

  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationHomeDtls readProviderInvestigationHomeDetails(
    InvestigationDeliveryKey key) throws AppException, InformationalException {

    ProviderInvestigationHomeDtls providerInvestigationHomeDtls = new ProviderInvestigationHomeDtls();
    curam.core.facade.intf.InvestigationDelivery investigationDeliveryObj = curam.core.facade.fact.InvestigationDeliveryFactory.newInstance();

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Read main home page details
    // BEGIN, CR00236076, AK
    providerInvestigationHomeDtls.homeDtls.assign(
      investigationDeliveryObj.readHomePageDetails1(key));
    // END, CR00236076

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationHomeDtls.menuDtls = getProviderInvestigationDeliveryMenuData(
      caseHeaderKey);

    // Read context description
    providerInvestigationHomeDtls.homeDtls.contextDtls.description = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(key).description;

    return providerInvestigationHomeDtls;

  }

  /**
   * Helper method which indicates if an investigation is standalone, belongs to
   * an integrated case or a provider.
   *
   * @param key
   * The key of the investigation.
   * @return Indicator whether its a investigation thats standalone, belongs to
   * an integrated case or a provider.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InvestigationInd resolveInvestigation(CaseHeaderKey key)
    throws AppException, InformationalException {

    InvestigationInd investigationInd = new InvestigationInd();

    CaseHeaderDtls caseHeaderDtls = CaseHeaderFactory.newInstance().read(key);

    if (caseHeaderDtls.integratedCaseID != 0) {

      investigationInd.integratedCaseInd = true;
    } else {

      // Check to see if investigation is for a provider
      ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

      ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

      if (concernRoleDtls.concernRoleType.equals(CONCERNROLETYPE.PROVIDER)) {

        investigationInd.providerInd = true;

      }
    }

    return investigationInd;

  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryActionPlanList listInvestigationDeliveryActionPlan(
    LinkKey key) throws AppException, InformationalException {

    // Create return object
    ProviderInvestigationDeliveryActionPlanList providerInvestigationDeliveryActionPlanList = new ProviderInvestigationDeliveryActionPlanList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    CaseKeyStruct caseKeyStruct = new CaseKeyStruct();

    curam.core.sl.entity.intf.ActionPlan actionPlanObj = curam.core.sl.entity.fact.ActionPlanFactory.newInstance();

    // Get the list of allegations for this investigation
    caseKeyStruct.caseID = key.linkID;

    providerInvestigationDeliveryActionPlanList.dtlsList = actionPlanObj.searchByLinkID(
      key);

    // Set key to read context description
    investigationDeliveryKey.caseID = key.linkID;

    // Read context description
    providerInvestigationDeliveryActionPlanList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.linkID;

    providerInvestigationDeliveryActionPlanList.menuDtls = getProviderInvestigationDeliveryMenuData(
      caseHeaderKey);

    return providerInvestigationDeliveryActionPlanList;

  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryAllegationList listInvestigationDeliveryAllegation(
    CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    ProviderInvestigationDeliveryAllegationList providerInvestigationDeliveryAllegationList = new ProviderInvestigationDeliveryAllegationList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    CaseKeyStruct caseKeyStruct = new CaseKeyStruct();

    curam.core.sl.intf.Allegation allegationObj = curam.core.sl.fact.AllegationFactory.newInstance();

    // Get the list of allegations for this investigation
    caseKeyStruct.caseID = key.caseID;

    providerInvestigationDeliveryAllegationList.dtlsList = allegationObj.list(
      caseKeyStruct);

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationDeliveryAllegationList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationDeliveryAllegationList.menuDtls = getProviderInvestigationDeliveryMenuData(
      caseHeaderKey);

    return providerInvestigationDeliveryAllegationList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryAttachmentList listInvestigationDeliveryAttachment(
    CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    ProviderInvestigationDeliveryAttachmentList providerInvestigationDeliveryAttachmentList = new ProviderInvestigationDeliveryAttachmentList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // MaintainAttachment manipulation variables
    curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory.newInstance();
    AttachmentCaseID attachmentCaseID = new AttachmentCaseID();
    curam.core.struct.AttachmentDetailsList attachmentDetailsList;

    // Set key to read the list of attachment
    attachmentCaseID.caseID = key.caseID;

    // Call MaintainAttachment BPO to retrieve the list of attachments
    attachmentDetailsList = maintainAttachmentObj.readCaseAttachments(
      attachmentCaseID);

    // Check to see if the list is populated
    if (!attachmentDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      providerInvestigationDeliveryAttachmentList.dtlsList.dtls.ensureCapacity(
        attachmentDetailsList.dtls.size());

      // Assign details to return object
      providerInvestigationDeliveryAttachmentList.dtlsList.assign(
        attachmentDetailsList);
    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationDeliveryAttachmentList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    caseHeaderKey.caseID = key.caseID;

    providerInvestigationDeliveryAttachmentList.menuDtls = getProviderInvestigationDeliveryMenuData(
      caseHeaderKey);

    return providerInvestigationDeliveryAttachmentList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryClientRoleList listInvestigationDeliveryCaseMember(
    CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    // Reuse the client role list struct as it contains identical values
    ProviderInvestigationDeliveryClientRoleList iCInvestigationDeliveryClientRoleList = new ProviderInvestigationDeliveryClientRoleList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;

    // CaseParticipantRole manipulation variables
    curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // Set key to read list of client roles
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj.viewCaseMemberList(
      viewCaseParticipantRole_boKey);

    // Reserve space in participantList
    iCInvestigationDeliveryClientRoleList.dtlsList.ensureCapacity(
      viewCaseParticipantRoleDetailsList.dtls.size());

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      if (viewCaseParticipantRoleDetailsList.dtls.item(i).recordStatus.equals(
        RECORDSTATUS.NORMAL)) {
        iCInvestigationDeliveryClientRoleList.dtlsList.addRef(
          viewCaseParticipantRoleDetailsList.dtls.item(i));
      }
    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    iCInvestigationDeliveryClientRoleList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    caseHeaderKey.caseID = key.caseID;

    iCInvestigationDeliveryClientRoleList.menuDtls = getProviderInvestigationDeliveryMenuData(
      key);

    return iCInvestigationDeliveryClientRoleList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryClientRoleList listInvestigationDeliveryClientRole(
    CaseHeaderKey key) throws AppException, InformationalException {

    // Create the return object
    ProviderInvestigationDeliveryClientRoleList providerInvestigationDeliveryClientRoleList = new ProviderInvestigationDeliveryClientRoleList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    // CaseParticipantRole manipulation variables
    curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;
    ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    // Assign key details
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read case participant role details
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj.viewCaseParticipantRoleList(
      viewCaseParticipantRole_boKey);

    // Reserve space in caseParticipantList
    providerInvestigationDeliveryClientRoleList.dtlsList.ensureCapacity(
      viewCaseParticipantRoleDetailsList.dtls.size());

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails = new curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails();

      caseParticipantRoleFullDetails.assign(
        viewCaseParticipantRoleDetailsList.dtls.item(i));

      // Add the integrated case id as part of struct to be returned
      // BEGIN, CR00303986, SG
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = key.caseID;
      final IntegratedCaseKey integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(
        caseKey);

      caseParticipantRoleFullDetails.parentCaseID = integratedCaseKey.integratedCaseID;
      // END, CR00303986
      
      providerInvestigationDeliveryClientRoleList.dtlsList.addRef(
        caseParticipantRoleFullDetails);
    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationDeliveryClientRoleList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationDeliveryClientRoleList.menuDtls = getProviderInvestigationDeliveryMenuData(
      key);

    return providerInvestigationDeliveryClientRoleList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryCommunicationList listInvestigationDeliveryCommunication(
    CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    ProviderInvestigationDeliveryCommunicationList providerInvestigationDeliveryCommunicationList = new ProviderInvestigationDeliveryCommunicationList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    // Communication service layer object
    curam.core.sl.intf.Communication communicationObj = curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call Communications BPO to retrieve the list of
    // communications
    CommunicationKey communicationKey = new CommunicationKey();

    communicationKey.caseID = key.caseID;

    providerInvestigationDeliveryCommunicationList.dtlsList = communicationObj.listCommunication(
      communicationKey);

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationDeliveryCommunicationList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationDeliveryCommunicationList.menuDtls = getProviderInvestigationDeliveryMenuData(
      key);

    return providerInvestigationDeliveryCommunicationList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryContactLogList listInvestigationDeliveryContactLog(
    CaseHeaderKey key) throws AppException, InformationalException {

    ProviderInvestigationDeliveryContactLogList iCInvestigationDeliveryContactLogList = new ProviderInvestigationDeliveryContactLogList();

    curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory.newInstance();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    LinkKey linkKey = new LinkKey();

    linkKey.linkID = key.caseID;

    // BEGIN, CR00145224, VKR
    ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new ContactLogLinkIDLinkTypeKey();

    contactLogLinkIDLinkTypeKey.linkID = key.caseID;

    // BEGIN, CR00145344, AK
    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPEEntry.CASE.getCode();
    // END, CR00145344

    // BEGIN, CR00236076, AK
    iCInvestigationDeliveryContactLogList.dtlsList.assign(
      contactLogObj.list1(contactLogLinkIDLinkTypeKey));
    // END, CR00236076

    // BEGIN, CR00147548, SK
    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i
      < iCInvestigationDeliveryContactLogList.dtlsList.dtls.size(); i++) {

      readContactLogDetails.contactLogDetails.assign(
        iCInvestigationDeliveryContactLogList.dtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj.formatContactLogPurpose(
        readContactLogDetails);

      iCInvestigationDeliveryContactLogList.dtlsList.dtls.item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
    }
    // END, CR00147548
    // END, CR00145224
    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    iCInvestigationDeliveryContactLogList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    iCInvestigationDeliveryContactLogList.menuDtls = getProviderInvestigationDeliveryMenuData(
      key);

    return iCInvestigationDeliveryContactLogList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryEventList listInvestigationDeliveryEvent(
    CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    ProviderInvestigationDeliveryEventList providerInvestigationDeliveryEventList = new ProviderInvestigationDeliveryEventList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    // ViewCaseEvents manipulation variables
    curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory.newInstance();
    ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();
    // BEGIN, CR00236076, AK
    ViewActiveCaseEventDetailsList1 viewActiveCaseEventDetailsList1;
    ViewActiveCaseEventDetailsList viewActiveCaseEventDetailsList = new ViewActiveCaseEventDetailsList();

    // Assign key to retrieve list of events
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;

    // Call ViewCaseEvents BPO to retrieve the list of events
    viewActiveCaseEventDetailsList1 = viewCaseEventsObj.readActiveEventsByType1(
      viewCaseEventsByCaseIDAndTypeKey);

    // Check to see if the list is populated
    if (!viewActiveCaseEventDetailsList1.dtls.isEmpty()) {

      // Reserve space in the return object
      providerInvestigationDeliveryEventList.dtlsList.dtls.ensureCapacity(
        viewActiveCaseEventDetailsList1.dtls.size());

      // Assign details to the return object
      ViewActiveCaseEventDetails viewActiveCaseEventDetails;

      for (int i = 0; i < viewActiveCaseEventDetailsList1.dtls.size(); i++) {
        viewActiveCaseEventDetails = new ViewActiveCaseEventDetails();
        viewActiveCaseEventDetails.assign(
          viewActiveCaseEventDetailsList1.dtls.item(i));
        viewActiveCaseEventDetailsList.dtls.addRef(viewActiveCaseEventDetails);
      }

      providerInvestigationDeliveryEventList.dtlsList.assign(
        viewActiveCaseEventDetailsList);
    }
    // END, CR00236076

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationDeliveryEventList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationDeliveryEventList.menuDtls = getProviderInvestigationDeliveryMenuData(
      key);

    return providerInvestigationDeliveryEventList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryMilestoneList listInvestigationDeliveryMilestone(
    CaseHeaderKey key) throws AppException, InformationalException {

    ProviderInvestigationDeliveryMilestoneList providerInvestigationDeliveryMilestoneList = new ProviderInvestigationDeliveryMilestoneList();

    MilestoneDelivery milestoneDeliveryObj = MilestoneDeliveryFactory.newInstance();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    providerInvestigationDeliveryMilestoneList.dtlsList.dtls = milestoneDeliveryObj.listAllMilestoneDeliveries(
      key);

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationDeliveryMilestoneList.dtlsList.description.description = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(investigationDeliveryKey).description;

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationDeliveryMilestoneList.menuDtls = getProviderInvestigationDeliveryMenuData(
      key);

    return providerInvestigationDeliveryMilestoneList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryNoteList listInvestigationDeliveryNote(
    CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    ProviderInvestigationDeliveryNoteList providerInvestigationDeliveryNoteList = new ProviderInvestigationDeliveryNoteList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    // CaseNote manipulation variables
    curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory.newInstance();
    curam.core.sl.struct.CaseKey caseSLKey = new curam.core.sl.struct.CaseKey();
    CaseNoteList1 caseNoteList;

    // Set key to read the list of notes
    caseSLKey.key.caseID = key.caseID;

    // Call CaseNotes BPO to retrieve the list of notes
    caseNoteList = caseNoteObj.list1(caseSLKey);

    // Check to see if the list if populated
    if (!caseNoteList.details.isEmpty()) {

      // Reserve space in the return object
      providerInvestigationDeliveryNoteList.dtlsList.dtls.ensureCapacity(
        caseNoteList.details.size());

      // ICProductDeliveryNoteDetails object
      ICProductDeliveryNoteDetails1 icProductDeliveryNoteDetails;

      // Assign details to return object
      for (int i = 0; i < caseNoteList.details.size(); i++) {

        icProductDeliveryNoteDetails = new ICProductDeliveryNoteDetails1();

        // Assign note details
        icProductDeliveryNoteDetails.assign(caseNoteList.details.item(i));

        // Add details to the return objects
        providerInvestigationDeliveryNoteList.dtlsList.dtls.addRef(
          assign(icProductDeliveryNoteDetails));
      }

    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationDeliveryNoteList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationDeliveryNoteList.menuDtls = getProviderInvestigationDeliveryMenuData(
      key);

    return providerInvestigationDeliveryNoteList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryRelatedCaseList listInvestigationDeliveryRelatedCase(
    CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    ProviderInvestigationDeliveryRelatedCaseList providerInvestigationDeliveryRelatedCaseList = new ProviderInvestigationDeliveryRelatedCaseList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    CaseKey caseKey = new CaseKey();

    // MaintainRelatedCases manipulation variables
    curam.core.intf.MaintainRelatedCases maintainRelatedCasesObj = curam.core.fact.MaintainRelatedCasesFactory.newInstance();
    GetRelatedCasesKey getRelatedCasesKey = new GetRelatedCasesKey();
    GetRelatedCasesList getRelatedCasesList;

    // Assign key details to retrieve list of related cases
    getRelatedCasesKey.caseID = key.caseID;

    // Call MaintainRelatedCases BPO to retrieve the list of related cases
    getRelatedCasesList = maintainRelatedCasesObj.getRelatedCases(
      getRelatedCasesKey);

    // Check to see if the list is populated
    if (!getRelatedCasesList.dtls.isEmpty()) {

      // Reserve space in the return object
      providerInvestigationDeliveryRelatedCaseList.dtlsList.ensureCapacity(
        getRelatedCasesList.dtls.size());

      // CaseHeader object
      curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      CaseTypeCode caseTypeCode = new CaseTypeCode();
      CaseIDAndTypeCodeKey caseIDAndTypeCodeKey = new CaseIDAndTypeCodeKey();

      for (int i = 0; i < getRelatedCasesList.dtls.size(); i++) {

        ICProductDeliveryCaseRelationshipDetails icProductDeliveryCaseRelationshipDetails = new ICProductDeliveryCaseRelationshipDetails();

        caseKey.caseID = getRelatedCasesList.dtls.item(i).relatedCaseID;
        caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

        caseIDAndTypeCodeKey.caseID = getRelatedCasesList.dtls.item(i).relatedCaseID;
        caseIDAndTypeCodeKey.caseTypeCode = caseTypeCode.caseTypeCode;

        RelatedCaseProductType relatedCaseProductType = maintainRelatedCasesObj.getRelatedCaseProductType(
          caseIDAndTypeCodeKey);

        getRelatedCasesList.dtls.item(i).relatedCaseProductType = relatedCaseProductType.relatedCaseProductType;

        icProductDeliveryCaseRelationshipDetails.caseID = getRelatedCasesList.dtls.item(i).caseID;
        icProductDeliveryCaseRelationshipDetails.caseRelationshipID = getRelatedCasesList.dtls.item(i).caseRelationshipID;
        icProductDeliveryCaseRelationshipDetails.caseTypeCode = getRelatedCasesList.dtls.item(i).caseTypeCode;
        icProductDeliveryCaseRelationshipDetails.endDate = getRelatedCasesList.dtls.item(i).endDate;
        icProductDeliveryCaseRelationshipDetails.relatedCaseID = getRelatedCasesList.dtls.item(i).relatedCaseID;
        icProductDeliveryCaseRelationshipDetails.relatedCaseProductType = getRelatedCasesList.dtls.item(i).relatedCaseProductType;
        icProductDeliveryCaseRelationshipDetails.relatedCaseReference = getRelatedCasesList.dtls.item(i).relatedCaseReference;
        icProductDeliveryCaseRelationshipDetails.startDate = getRelatedCasesList.dtls.item(i).startDate;
        icProductDeliveryCaseRelationshipDetails.typeCode = getRelatedCasesList.dtls.item(i).typeCode;
        icProductDeliveryCaseRelationshipDetails.statusCode = getRelatedCasesList.dtls.item(i).statusCode;

        // Assign details to return object
        providerInvestigationDeliveryRelatedCaseList.dtlsList.addRef(
          icProductDeliveryCaseRelationshipDetails);
      }

    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationDeliveryRelatedCaseList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationDeliveryRelatedCaseList.menuDtls = getProviderInvestigationDeliveryMenuData(
      key);

    return providerInvestigationDeliveryRelatedCaseList;
  }

  /**
   * Returns the list of status history of an investigation delivery case on a provider.
   *
   * @param key
   * Case identifier.
   *
   * @return List of the statuses for an investigation delivery case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderInvestigationDeliveryStatusHistoryList listInvestigationDeliveryStatusHistory(
    CaseHeaderKey key) throws AppException, InformationalException {

    ProviderInvestigationDeliveryStatusHistoryList providerInvestigationDeliveryStatusHistoryList = new ProviderInvestigationDeliveryStatusHistoryList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    // ProductDeliveryHome manipulation variables, can be used for
    // investigation deliveries also
    curam.core.intf.ProductDeliveryHome productDeliveryHomeObj = curam.core.fact.ProductDeliveryHomeFactory.newInstance();
    CaseStatusHistoryKey caseStatusHistoryKey = new CaseStatusHistoryKey();

    // Set key to read case status history details
    caseStatusHistoryKey.caseID = key.caseID;

    // BEGIN, CR00225696, ASN
    // Read case status history details and assign to output object
    CaseStatusHistoryDetailsList1 caseStatusHistoryDetailsList = productDeliveryHomeObj.getCaseStatusHistory1(
      caseStatusHistoryKey);

    // END, CR00225696
    for (int i = 0; i < caseStatusHistoryDetailsList.dtls.size(); i++) {

      ICProductDeliveryStatusHistoryDetails icProductDeliveryStatusHistoryDetails = new ICProductDeliveryStatusHistoryDetails();

      icProductDeliveryStatusHistoryDetails.caseStatusID = caseStatusHistoryDetailsList.dtls.item(i).caseStatusID;
      icProductDeliveryStatusHistoryDetails.endDate = caseStatusHistoryDetailsList.dtls.item(i).endDate;
      icProductDeliveryStatusHistoryDetails.reasonCode = caseStatusHistoryDetailsList.dtls.item(i).reasonCode;
      icProductDeliveryStatusHistoryDetails.startDate = caseStatusHistoryDetailsList.dtls.item(i).startDate;
      icProductDeliveryStatusHistoryDetails.statusCode = caseStatusHistoryDetailsList.dtls.item(i).statusCode;

      providerInvestigationDeliveryStatusHistoryList.dtlsList.addRef(
        icProductDeliveryStatusHistoryDetails);

    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationDeliveryStatusHistoryList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationDeliveryStatusHistoryList.menuDtls = getProviderInvestigationDeliveryMenuData(
      key);

    // Return the status history list
    return providerInvestigationDeliveryStatusHistoryList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryTaskList listInvestigationDeliveryTask(
    CaseHeaderKey key) throws AppException, InformationalException {

    // create return object
    ProviderInvestigationDeliveryTaskList providerInvestigationDeliveryTaskList = new ProviderInvestigationDeliveryTaskList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    // Task manipulation variables
    curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj = curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();
    SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey = new SearchTaskForConcernOrCaseKey();
    CaseAndConcernLinkedTaskDtls caseAndConcernLinkedTaskDtls;

    // set key to read the list of tasks
    searchTaskForConcernOrCaseKey.details.linkedID = key.caseID;

    // Get list of case tasks
    caseAndConcernLinkedTaskDtls = workAllocationTaskObj.listCaseTasks(
      searchTaskForConcernOrCaseKey);

    // assign list to output structure
    providerInvestigationDeliveryTaskList.dtlsList.assign(
      caseAndConcernLinkedTaskDtls.dtls);

    // Iterate through the list and set reservedByExistsInd to true
    for (int i = 0; i
      < providerInvestigationDeliveryTaskList.dtlsList.dtls.size(); i++) {

      if (providerInvestigationDeliveryTaskList.dtlsList.dtls.item(i).reservedBy.length()
        > 0) {

        providerInvestigationDeliveryTaskList.dtlsList.dtls.item(i).reservedByExistsInd = true;
      }
    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationDeliveryTaskList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationDeliveryTaskList.menuDtls = getProviderInvestigationDeliveryMenuData(
      key);

    return providerInvestigationDeliveryTaskList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryUserRoleList listInvestigationDeliveryUserRole(
    CaseHeaderKey key) throws AppException, InformationalException {

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Create return object
    ProviderInvestigationDeliveryUserRoleList providerInvestigationDeliveryUserRoleList = new ProviderInvestigationDeliveryUserRoleList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    // CaseUserRole manipulation variables
    curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();
    curam.core.sl.struct.CaseUserRoleDetailsList caseUserRoleDetailsList;
    curam.core.sl.struct.CaseUserRoleCaseIDKey caseUserRoleCaseIDKey = new curam.core.sl.struct.CaseUserRoleCaseIDKey();

    // Assign key details
    caseUserRoleCaseIDKey.dtls.caseID = key.caseID;

    // Call CaseUserRole BPO to return the list of Case User Roles
    caseUserRoleDetailsList = caseUserRoleObj.listCaseUserRoles(
      caseUserRoleCaseIDKey);

    // Reserve space in caseUserRoleDetailsList
    providerInvestigationDeliveryUserRoleList.dtlsList.ensureCapacity(
      caseUserRoleDetailsList.dtls.size());

    // Assign details to output object
    for (int i = 0; i < caseUserRoleDetailsList.dtls.size(); i++) {

      curam.core.sl.struct.CaseUserRoleDetails caseUserRoleSLDetails = new curam.core.sl.struct.CaseUserRoleDetails();

      caseUserRoleSLDetails.dtls.assign(
        caseUserRoleDetailsList.dtls.item(i).dtls);

      providerInvestigationDeliveryUserRoleList.dtlsList.addRef(
        caseUserRoleSLDetails);
    }

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationDeliveryUserRoleList.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationDeliveryUserRoleList.menuDtls = getProviderInvestigationDeliveryMenuData(
      key);

    // retrieve any informational messages
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      providerInvestigationDeliveryUserRoleList.informationalDtls.dtls.addRef(
        informationalMsgDtls);
    }

    return providerInvestigationDeliveryUserRoleList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDeliveryMilestoneList listInvestigationUncompletedMilestone(
    CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    ProviderInvestigationDeliveryMilestoneList providerInvestigationDeliveryMilestoneList = new ProviderInvestigationDeliveryMilestoneList();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    // Milestone manipulation variables
    MilestoneDelivery milestoneDeliveryObj = MilestoneDeliveryFactory.newInstance();

    providerInvestigationDeliveryMilestoneList.dtlsList.dtls = milestoneDeliveryObj.listUncompletedMilestoneDeliveries(
      key);

    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationDeliveryMilestoneList.dtlsList.description.description = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(investigationDeliveryKey).description;

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationDeliveryMilestoneList.menuDtls = getProviderInvestigationDeliveryMenuData(
      key);

    return providerInvestigationDeliveryMilestoneList;
  }

  /**
   * Returns data representing case events and activities for an Investigation
   * Delivery on a Provider.
   *
   * @param key
   * Contains caseID, calendar date and the calendar view type.
   *
   * @return Data representing case events and activities.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderInvestigationEventAndActivityDetails searchInvestigationEventAndActivity(
    SearchCaseEventAndActivityKey key) throws AppException,
      InformationalException {

    // Create return object
    ProviderInvestigationEventAndActivityDetails providerInvestigationEventAndActivityDetails = new ProviderInvestigationEventAndActivityDetails();

    InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
    CaseKey caseKey = new CaseKey();

    // ViewCaseEvents manipulation variables
    curam.core.facade.intf.InvestigationDelivery investigationFacadeObj = curam.core.facade.fact.InvestigationDeliveryFactory.newInstance();

    // BEGIN, CR00236076, AK
    InvestigationDeliveryEventAndActivityDetails1 investigationActivityDetails = investigationFacadeObj.searchInvestigationDeliveryEventAndActivity1(
      key);

    providerInvestigationEventAndActivityDetails.dtls.calendarDtls.assign(
      investigationActivityDetails.calendarDtls);
    providerInvestigationEventAndActivityDetails.dtls.contextDescription.assign(
      investigationActivityDetails.contextDescription);
    // END, CR00236076

    // Set key to read context description
    investigationDeliveryKey.caseID = key.caseID;

    // Read context description
    providerInvestigationEventAndActivityDetails.contextDtls = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(
      investigationDeliveryKey);

    // Set key to read menu data
    caseKey.caseID = key.caseID;

    CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey);

    // Set key to read menu data
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    providerInvestigationEventAndActivityDetails.menuDtls = getProviderInvestigationDeliveryMenuData(
      caseHeaderKey);

    return providerInvestigationEventAndActivityDetails;
  }

  // BEGIN, CR00197371, GP
  // BEGIN, CR00292039, ASN
  /**
   * Reads the investigation tab details for provider and person.
   *
   * @param investigationDeliveryKey
   * Key to read the investigation delivery details.
   *
   * @return Provider investigation delivery details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00292039
  public ProviderInvestigationTabDetails readProviderInvestigationTabDetails(
    final InvestigationDeliveryKey investigationDeliveryKey)
    throws AppException, InformationalException {

    ProviderInvestigationTabDetails providerInvestigationTabDetails = new ProviderInvestigationTabDetails();

    curam.cpm.sl.entity.intf.Provider providerObj = curam.cpm.sl.entity.fact.ProviderFactory.newInstance();

    CaseIDAndRecordStatus caseIDAndRecordStatus = new CaseIDAndRecordStatus();

    caseIDAndRecordStatus.caseID = investigationDeliveryKey.caseID;
    
    // BEGIN, CR00292039, ASN
    CaseHeaderKey key = new CaseHeaderKey();

    key.caseID = investigationDeliveryKey.caseID;
    
    InvestigationInd InvestigationInd = resolveInvestigation(key);

    if (InvestigationInd.providerInd) {
      // END, CR00292039
      
      InvestigationDeliveryTabDtls investigationDeliveryTabDtls = providerObj.readProviderInvestigationTabDetails(
        caseIDAndRecordStatus);

      CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
      OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();

      orgObjectLinkKey.orgObjectLinkID = investigationDeliveryTabDtls.orgObjectLinkID;

      CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwnerName(
        orgObjectLinkKey);

      // BEGIN, CR00199708, GP
      if (ORGOBJECTTYPE.USER.equals(caseOwnerDetails.orgObjectType)) {
        // END, CR00199708

        TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
        UsersKey usersKey = new UsersKey();

        usersKey.userName = caseOwnerDetails.userName;

        caseOwnerDetails.orgObjectReferenceName = tabDetailFormatterObj.formatUserFullName(usersKey).fullName;

      } else {
        caseOwnerDetails.orgObjectReferenceName = caseOwnerDetails.orgObjectReferenceName;
      }

      CaseMemberTabDetails caseMemberTabDetails = new CaseMemberTabDetails();

      caseMemberTabDetails.assign(investigationDeliveryTabDtls);

      CaseIDAndConcernRoleIDKey caseIDAndConcernRoleIDKey = new CaseIDAndConcernRoleIDKey();

      caseIDAndConcernRoleIDKey.caseID = investigationDeliveryKey.caseID;
      caseIDAndConcernRoleIDKey.concernRoleID = investigationDeliveryTabDtls.concernRoleID;

      // BEGIN, CR00198941, DRS
      InvestigationAndRoleTabDetailsList investigationList = readRelatedInvestigationRoleTabDetails(
        caseIDAndConcernRoleIDKey);
      // END, CR00198941

      // BEGIN, CR00199708, GP
      ContentPanelBuilder containerPanel = ContentPanelBuilder.createPanel(
        CPMConstants.gkContainerPanelProviderInvestigation);

      ContentPanelBuilder imagePanel = getCasePrimaryClientThumbnailDetails(
        caseMemberTabDetails, investigationList);

      containerPanel.addWidgetItem(imagePanel, CuramConst.gkStyle,
        CuramConst.gkContentPanel, CuramConst.gkCaseParticipantPanel);

      // BEGIN, CR00198941, DRS
      ContentPanelBuilder detailsPanelBuilder = getInvestigationCaseDetails(
        investigationDeliveryTabDtls, investigationDeliveryKey);

      // END, CR00198941

      containerPanel.addWidgetItem(detailsPanelBuilder, CuramConst.gkStyle,
        CuramConst.gkContentPanel, CuramConst.gkInvestigationContentPanel);

      ContentPanelBuilder linksPanel = getInvestigationLinkDetails(
        investigationDeliveryTabDtls, caseOwnerDetails);

      containerPanel.addWidgetItem(linksPanel, CuramConst.gkStyle,
        CuramConst.gkContentPanel, CPMConstants.gkInvestigationLinksPanel);

      providerInvestigationTabDetails.providerInvestigationTabDetails = containerPanel.toString();

      // BEGIN, CR00228396, PS
      providerInvestigationTabDetails.investigationType = investigationDeliveryTabDtls.investigationType;
      providerInvestigationTabDetails.referenceNumber = investigationDeliveryTabDtls.caseReference;
      providerInvestigationTabDetails.primaryClientName = investigationDeliveryTabDtls.concernRoleName;
      // END, CR00228396

      providerInvestigationTabDetails.investigationType = investigationDeliveryTabDtls.investigationType;
      providerInvestigationTabDetails.referenceNumber = investigationDeliveryTabDtls.caseReference;
      providerInvestigationTabDetails.primaryClientName = investigationDeliveryTabDtls.concernRoleName;
      // END, CR00199708
      // BEGIN, CR00292039, ASN
    } else {

      InvestigationTab investigationTabForMember = InvestigationTabFactory.newInstance();
      InvestigationTabDetails investigationTabDetails = investigationTabForMember.readInvestigationTabDetails(
        investigationDeliveryKey);

      providerInvestigationTabDetails.investigationType = investigationTabDetails.investigationType;
      providerInvestigationTabDetails.referenceNumber = investigationTabDetails.investigationRef;
      providerInvestigationTabDetails.primaryClientName = investigationTabDetails.personName;
      providerInvestigationTabDetails.providerInvestigationTabDetails = investigationTabDetails.xmlPanelData;
    }
    // END, CR00292039

    return providerInvestigationTabDetails;
  }

  // BEGIN, CR00198941, DRS
  /**
   * Reads the related Investigation details and role details list.
   *
   * @param key
   * Key of concern role and investigation to read related
   * investigations.
   *
   * @return Related investigation details and role details list
   */
  protected InvestigationAndRoleTabDetailsList readRelatedInvestigationRoleTabDetails(
    final CaseIDAndConcernRoleIDKey key) throws AppException,
      InformationalException {

    InvestigationAndRoleTabDetailsList investigationAndRoleTabDetailsList = new InvestigationAndRoleTabDetailsList();
    curam.core.sl.entity.intf.InvestigationDelivery investigationDeliveryObj = curam.core.sl.entity.fact.InvestigationDeliveryFactory.newInstance();
    SearchInvestigationKey searchInvestigationKey = new SearchInvestigationKey();
    SearchInvestigationRoleKey searchInvestigationRoleKey = new SearchInvestigationRoleKey();

    searchInvestigationKey.assign(key);

    InvestigationTabDtlsList investigationList = investigationDeliveryObj.searchActiveRelatedInvestigation(
      searchInvestigationKey);

    searchInvestigationRoleKey.concernRoleID = key.concernRoleID;

    InvestigationAndRoleTabDetails investigationAndRoleTabDetails;

    for (int i = 0; i < investigationList.dtls.size(); i++) {

      investigationAndRoleTabDetails = new InvestigationAndRoleTabDetails();

      investigationAndRoleTabDetails.assign(investigationList.dtls.item(i));

      searchInvestigationRoleKey.caseID = investigationList.dtls.item(i).caseID;
      investigationAndRoleTabDetails.roleList = investigationDeliveryObj.searchActiveRelatedInvestigationRole(
        searchInvestigationRoleKey);

      investigationAndRoleTabDetailsList.dtls.addRef(
        investigationAndRoleTabDetails);
    }

    return investigationAndRoleTabDetailsList;
  }

  // END, CR00198941

  // BEGIN, CR00198941, DRS
  /**
   * Formats XML data for an Investigation case tab details.
   *
   * @param caseOwnerDetails
   * Case owner details.
   * @param details
   * Investigation case details.
   * @param investigationDeliveryKey
   * Investigation Delivery Key
   *
   * @return Content panel builder which has formatted data.
   */
  protected ContentPanelBuilder getInvestigationCaseDetails(
    final InvestigationDeliveryTabDtls details,
    final InvestigationDeliveryKey investigationDeliveryKey)
    throws AppException, InformationalException {

    // Create a content panel using the content panel builder to build the xml
    // required. The id for this content panel is case-details. This should
    // be unique id.
    // BEGIN, CR00199708, GP
    ContentPanelBuilder investigationTabDetails = ContentPanelBuilder.createPanel(
      CuramConst.gkInvestigationTabDetails);

    investigationTabDetails.addRoundedCorners();

    ContentPanelBuilder investigationDetails = ContentPanelBuilder.createPanel(
      CPMConstants.gkProviderInvestigationDetails);
    // BEGIN, CR00224728, JMA
    // TODO Remove reference number from message arg when message update is
    // available (CEF017)
    String caseName = new LocalisableString(BPOCASETAB.INF_CASE_NAME).arg(new CodeTableItemIdentifier(INVESTIGATECONFIGTYPE.TABLENAME, details.investigationType)).arg(details.caseReference).toClientFormattedText();

    investigationDetails.addlocalisableStringItem(caseName,
      CPMConstants.gkProviderInvestigationReference);
    // TODO Uncomment when CuramConst.gkProductDeliveryRefID is available
    // (CEF017)
    // investigationDetails.addStringItem(
    // details.caseReference, CuramConst.gkProductDeliveryRefID);

    ListBuilder detailsList = ListBuilder.createHorizontalList(2);

    detailsList.addRow();

    LocalisableString investigationLabel = new LocalisableString(
      PROVIDERINVESTIGATION.INF_INVESTIGATION_STATUS);

    detailsList.addEntry(1, 1, investigationLabel);

    CodeTableItemEntry caseStatus = DocBuilderHelperFactory.getCodeTableItemEntry(
      details.caseStatus, CuramConst.gkDomainCaseStatus);

    detailsList.addEntry(2, 1, caseStatus);

    detailsList.addRow();

    LocalisableString typeLabel = new LocalisableString(
      BPOINVESTIGATIONTAB.INF_TYPE_LABEL);

    detailsList.addEntry(1, 2, typeLabel);

    if (details.investigationSubtype.length() > 0) {
      LocalisableString investigationType = new LocalisableString(BPOINVESTIGATIONTAB.INF_TYPE_SUBTYPE).arg(new CodeTableItemIdentifier(INVESTIGATECONFIGTYPE.TABLENAME, details.investigationType)).arg(
        new CodeTableItemIdentifier(INVESTIGDELIVERYSUBTYPE.TABLENAME,
        details.investigationSubtype));

      detailsList.addEntry(2, 2, investigationType);

    } else {

      CodeTableItemEntry investigationType = DocBuilderHelperFactory.getCodeTableItemEntry(
        details.investigationType, CuramConst.gkDomainInvestigationType);

      detailsList.addEntry(2, 2, investigationType);
    }

    detailsList.addRow();

    LocalisableString registeredLabel = new LocalisableString(
      BPOINVESTIGATIONTAB.INF_REGISTERED_LABEL);

    detailsList.addEntry(1, 3, registeredLabel);

    detailsList.addEntry(2, 3, details.registrationDate);

    detailsList.addRow();

    LocalisableString incidentsLabel = new LocalisableString(
      PROVIDERINVESTIGATION.TEXT_INVESTIGATION_RELATED_INCIDENTS);

    detailsList.addEntry(1, 4, incidentsLabel);

    ProviderInvestigationHomeDtls providerInvestigationHomeDtls = readProviderInvestigationHomeDetails(
      investigationDeliveryKey);
    int numberOfRelatedIncidents = providerInvestigationHomeDtls.homeDtls.dtls.incidentList.dtlsList.size();

    detailsList.addEntry(2, 4, String.valueOf(numberOfRelatedIncidents));

    detailsList.addRow();

    LocalisableString initialContactLabel = new LocalisableString(
      BPOINVESTIGATIONTAB.INF_INITIAL_CONTACT_LABEL);

    detailsList.addEntry(1, 5, initialContactLabel);

    LocalisableString initialContact = null;

    Date initialContactStartDate = new Date(details.initialContactStartDateTime);

    if (!initialContactStartDate.isZero()) {
      new LocalisableString(BPOINVESTIGATIONTAB.INF_CONTACT_DATE_TYPE).arg(initialContactStartDate).arg(
        new CodeTableItemIdentifier(CONTACTLOGTYPE.TABLENAME,
        details.initialContactType));
    } else {
      initialContact = new LocalisableString(BPOPARTICIPANT.INF_NOT_RECORDED);
    }

    detailsList.addEntry(2, 5, initialContact);

    investigationDetails.addSingleListItem(detailsList,
      CuramConst.gkInvestigationDetailTable);

    if (details.resolution.length() > CuramConst.gkZero) {

      String resolution = new LocalisableString(BPOINVESTIGATIONTAB.INF_RESOLUTION).arg(new CodeTableItemIdentifier(RESOLUTIONCONIFIGURATION.TABLENAME, details.resolution)).arg(details.resolutionCreationDate).toClientFormattedText();

      investigationDetails.addlocalisableStringItem(resolution,
        CuramConst.gkStyleWatermark);
    }

    investigationTabDetails.addWidgetItem(investigationDetails,
      CuramConst.gkStyle, CuramConst.gkContentPanel);

    // Get the latest contact details
    ContentPanelBuilder contactContent = ContentPanelBuilder.createPanel(
      CuramConst.gkContactContent);

    ContentPanelBuilder contactContentDetail = ContentPanelBuilder.createPanel(
      CuramConst.gkContactContentDetail);

    ImageBuilder latestContactImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconScheduleBlue, CuramConst.gkEmpty);

    latestContactImageBuilder.setImageResource(CuramConst.gkRendererImages);
    contactContentDetail.addImageItem(latestContactImageBuilder);

    ListBuilder latestContact = ListBuilder.createHorizontalList(2);

    latestContact.addRow();

    LocalisableString lastContactLabel = new LocalisableString(
      BPOINVESTIGATIONTAB.INF_LATEST_CONTACT_LABEL);

    latestContact.addEntry(1, 1, lastContactLabel);

    Date latestContactStartDate = new Date(details.latestContactStartDateTime);

    LocalisableString lastContact = null;

    if (!latestContactStartDate.isZero()) {
      lastContact = new LocalisableString(BPOINVESTIGATIONTAB.INF_CONTACT_DATE_TYPE).arg(latestContactStartDate).arg(
        new CodeTableItemIdentifier(CONTACTLOGTYPE.TABLENAME,
        details.latestContactType));
    } else {
      lastContact = new LocalisableString(BPOPARTICIPANT.INF_NOT_RECORDED);
    }

    latestContact.addEntry(2, 1, lastContact);

    contactContentDetail.addSingleListItem(latestContact,
      CuramConst.gkLatestContactTable);

    contactContent.addWidgetItem(contactContentDetail, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    investigationTabDetails.addWidgetItem(contactContent, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    return investigationTabDetails;
  }

  // END, CR00198941
  // END, CR00224728

  /**
   * Formats XML data for a Contacts details.
   *
   * @param contentPanelBuilder
   * Content panel builder to hold XML data
   * @param details
   * Investigation case tab details.
   *
   * @return ListBuilder with contacts details list XML data.
   */
  public static ContentPanelBuilder getContactDetails(
    final ContactLogTabDetails details) throws AppException,
      InformationalException {

    ContentPanelBuilder contactContent = ContentPanelBuilder.createPanel(
      CPMConstants.gkContactContent);

    ContentPanelBuilder contactContentDetail = ContentPanelBuilder.createPanel(
      CPMConstants.gkContactContentDetail);

    // Create a image builder for a contact log icon
    ImageBuilder initialContactImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconScheduleBlue, CuramConst.gkEmpty);

    initialContactImageBuilder.setImageResource(CuramConst.gkRendererImages);
    contactContentDetail.addImageItem(initialContactImageBuilder);

    String initialContactLabel = new LocalisableString(BPOINVESTIGATIONTAB.INF_INITIAL_CONTACT_LABEL).toClientFormattedText();

    contactContentDetail.addlocalisableStringItem(initialContactLabel,
      CPMConstants.gkInitialContactLabel);

    String initialContact = null;

    if (!details.initialContactStartDate.isZero()) {
      initialContact = new LocalisableString(BPOINVESTIGATIONTAB.INF_CONTACT_DATE_TYPE).arg(details.initialContactStartDate).arg(new CodeTableItemIdentifier(CONTACTLOGTYPE.TABLENAME, details.initialContactType)).toClientFormattedText();
    } else {
      initialContact = new LocalisableString(BPOPARTICIPANT.INF_NOT_RECORDED).toClientFormattedText();
    }

    contactContentDetail.addlocalisableStringItem(initialContact,
      CPMConstants.gkInitialContact);

    if (details.initialContactLogID != details.latestContactLogID) {

      ImageBuilder latestContactImageBuilder = ImageBuilder.createImage(
        CuramConst.gkIconScheduleBlue, CuramConst.gkEmpty);

      latestContactImageBuilder.setImageResource(CuramConst.gkRendererImages);
      contactContentDetail.addImageItem(latestContactImageBuilder);

      String lastContactLabel = new LocalisableString(BPOINVESTIGATIONTAB.INF_LATEST_CONTACT_LABEL).toClientFormattedText();

      contactContentDetail.addlocalisableStringItem(lastContactLabel,
        CPMConstants.gkLatestContactLabel);

      String lastContact = new LocalisableString(BPOINVESTIGATIONTAB.INF_CONTACT_DATE_TYPE).arg(details.latestContactStartDate).arg(new CodeTableItemIdentifier(CONTACTLOGTYPE.TABLENAME, details.latestContactType)).toClientFormattedText();

      contactContentDetail.addlocalisableStringItem(lastContact,
        CPMConstants.gkLatestContact);

    }

    contactContent.addWidgetItem(contactContentDetail, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    return contactContent;
  }

  /**
   * Formats the XML data for a case primary client details.
   *
   * @param details
   * Case member details.
   * @param investigationAndRoleTabDetailsList
   * Case member investigation list.
   *
   * @return Content panel builder.
   */
  protected ContentPanelBuilder getCasePrimaryClientThumbnailDetails(
    final CaseMemberTabDetails details,
    InvestigationAndRoleTabDetailsList investigationAndRoleTabDetailsList)
    throws AppException, InformationalException {
    // BEGIN, CR00224728, JMA
    // Create a content panel using the image panel builder to build the xml
    // required.
    ImagePanelBuilder imagePanelBuilder = ImagePanelBuilder.createPanel();

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.concernRoleID;

    // END, CR00195538
    imagePanelBuilder.addNameAsLink(
      providerDAO.get(details.concernRoleID).getName(), "",
      details.concernRoleID);

    LinkBuilder linkBuilder = LinkBuilder.createLink(CuramConst.gkEmpty,
      CuramConst.gkParticipantHomePage);

    ConcernRoleImage concernRoleImageObj = ConcernRoleImageFactory.newInstance();
    String image = CuramConst.gkEmpty;
    String imageResource = CuramConst.gkEmpty;

    if (concernRoleImageObj.hasImage(concernRoleKey).statusInd) {

      image = CuramConst.gkCaseMemberFileDownLoadLink
        + String.valueOf(details.concernRoleID);
      imageResource = CuramConst.gkEmpty;

    } else {

      image = CPMConstants.kIconProvider;
      imageResource = CPMConstants.kRendererImages;
    }

    String imageIdentifier = imagePanelBuilder.addParticipantImage(image, "",
      imageResource);

    ContactTabDetails contactTabDetails = new ContactTabDetails();

    contactTabDetails.assign(details);

    TooltipBuilder contactTooltipBuilder = curam.core.sl.impl.TabDetailsHelper.getParticipantContactDetailsTooltip(
      contactTabDetails, imageIdentifier);

    imagePanelBuilder.addTooltipItem(contactTooltipBuilder);

    TabDetailsHelper tabDetailsHelperObj = TabDetailsHelperFactory.newInstance();

    IncidentAndRoleTabDetailsList incidentList = tabDetailsHelperObj.readIncidentTabDetails(
      concernRoleKey);

    if (null == investigationAndRoleTabDetailsList) {
      investigationAndRoleTabDetailsList = tabDetailsHelperObj.readInvestigationTabDetails(
        concernRoleKey);
    }

    if (incidentList.dtls.size() > 0) {

      CaseTabDetailsHelper.getMemberIncidentDetailsForImagePanel(concernRoleKey,
        incidentList, imagePanelBuilder);
    }

    if (investigationAndRoleTabDetailsList.dtls.size() > 0) {

      CaseTabDetailsHelper.getMemberInvestigationDetailsForImagePanel(
        concernRoleKey, investigationAndRoleTabDetailsList, imagePanelBuilder);
    }

    return imagePanelBuilder.getImagePanel();
  }

  // END, CR00224728
  /**
   * Formats XML data for an Allegation and case owner details link.
   *
   * @param details
   * Investigation case details.
   * @param caseOwnerDetails
   * Case owner details.
   *
   * @return List builder with allegation details XML data.
   */
  public ContentPanelBuilder getInvestigationLinkDetails(
    final InvestigationDeliveryTabDtls details,
    final CaseOwnerDetails caseOwnerDetails) throws AppException,
      InformationalException {
    // BEGIN, CR00224728, JMA
    LinksPanelBuilder linksPanelBuilder = LinksPanelBuilder.createLinksPanel(3);

    // Open allegations
    LocalisableString openAllegationsTooltip = new LocalisableString(
      BPOCASETAB.INF_OPEN_ALLEGATIONS_TOOLTIP);
    ImageBuilder openAllegationImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconOpenAllegation, CuramConst.gkEmpty);

    openAllegationImageBuilder.setImageResource(CuramConst.gkRendererImages);
    openAllegationImageBuilder.setImageAltText(
      openAllegationsTooltip.toClientFormattedText());

    String openAllegation = new LocalisableString(BPOINVESTIGATIONTAB.INF_NUM_OPEN_ALLEGATIONS).arg(details.countAllegationAll - details.countAllegationDecided).toClientFormattedText();

    LinkBuilder openAllegationLinkBuilder = LinkBuilder.createLocalizableLink(
      openAllegation, CuramConst.gkInvestigationAllegationListPage);
    // BEGIN, CR00260650, GP
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseReference caseReference = new CaseReference();

    caseReference.caseReference = details.caseReference;
    details.caseID = caseHeaderObj.readByCaseReference(caseReference).caseID;
    
    openAllegationLinkBuilder.addParameter(CuramConst.gkPageParameterCaseID,
      String.valueOf(details.caseID));
    openAllegationLinkBuilder.addParameter(
      CuramConst.gkPageParameterConcernRoleID,
      String.valueOf(details.concernRoleID));
    // END, CR00260650
    
    // BEGIN, CR00262179, GP
    openAllegationLinkBuilder.addLinkTitle(
      new LocalisableString(
        PROVIDERINVESTIGATION.TEXT_INVESTIGATION_OPEN_ALLEGATIONS_TITLE));
    // END, CR00262179
    
    linksPanelBuilder.addLinkEntry(openAllegationImageBuilder,
      openAllegationLinkBuilder);

    // Decided allegations
    LocalisableString decidedAllegationsTooltip = new LocalisableString(
      BPOCASETAB.INF_DECIDED_ALLEGATIONS_TOOLTIP);
    ImageBuilder decidedAllegationImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconDecidedAllegation, CuramConst.gkEmpty);

    decidedAllegationImageBuilder.setImageResource(CuramConst.gkRendererImages);
    decidedAllegationImageBuilder.setImageAltText(
      decidedAllegationsTooltip.toClientFormattedText());

    LinkBuilder decidedAllegationLinkBuilder = LinkBuilder.createLocalizableLink(
      new LocalisableString(BPOINVESTIGATIONTAB.INF_NUM_DECIDED_ALLEGATIONS).arg(details.countAllegationDecided).toClientFormattedText(),
      CuramConst.gkInvestigationAllegationListPage);

    decidedAllegationLinkBuilder.addParameter(CuramConst.gkPageParameterCaseID,
      String.valueOf(details.caseID));
    // BEGIN, CR00260650, GP
    decidedAllegationLinkBuilder.addParameter(
      CuramConst.gkPageParameterConcernRoleID,
      String.valueOf(details.concernRoleID));
    // END, CR00260650
    
    // BEGIN, CR00262179, GP
    decidedAllegationLinkBuilder.addLinkTitle(
      new LocalisableString(
        PROVIDERINVESTIGATION.TEXT_INVESTIGATION_DECIDED_ALLEGATIONS_TITLE));
    // END, CR00262179
    
    linksPanelBuilder.addLinkEntry(decidedAllegationImageBuilder,
      decidedAllegationLinkBuilder);

    ContentPanelBuilder caseOwnerPanelBuilder = ContentPanelBuilder.createPanel(
      CuramConst.gkInvCaseOwnerPanel);

    ImageBuilder ownerImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconCaseOwner, CuramConst.gkEmpty);

    ownerImageBuilder.setImageResource(CuramConst.gkRendererImages);

    caseOwnerPanelBuilder.addImageItem(ownerImageBuilder,
      CuramConst.gkInvCaseOwnerIcon);

    LinkBuilder linkBuilder = LinkBuilder.createLink(
      caseOwnerDetails.orgObjectReferenceName, CuramConst.gkCaseOwnerHomePage);

    linkBuilder.openAsModal();
    linkBuilder.addParameter(CuramConst.gkPageParameterUserName,
      String.valueOf(caseOwnerDetails.userName));
    linkBuilder.addParameter(CuramConst.gkPageParameterOrgObjectReference,
      String.valueOf(caseOwnerDetails.orgObjectReference));
    linkBuilder.addParameter(CuramConst.gkPageParameterOrgObjectType,
      String.valueOf(caseOwnerDetails.orgObjectType));

    caseOwnerPanelBuilder.addLinkItem(linkBuilder, CuramConst.gkInvCaseOwner);

    linksPanelBuilder.addContentPanel(caseOwnerPanelBuilder);

    return linksPanelBuilder.getLinksPanel();
  }

  // END, CR00224728
  // END, CR00197371

  /**
   * Assigns the values.
   *
   * @param ICProductDeliveryNoteDetails1
   * Contains the integrated note product delivery note details.
   *
   * @return The integrated note product delivery note details.
   */
  protected ICProductDeliveryNoteDetails assign(
    final ICProductDeliveryNoteDetails1 ICProductDeliveryNoteDetails1) {
    ICProductDeliveryNoteDetails icProductDeliveryNoteDetails = new ICProductDeliveryNoteDetails();

    icProductDeliveryNoteDetails.caseID = ICProductDeliveryNoteDetails1.caseID;
    icProductDeliveryNoteDetails.caseNoteID = ICProductDeliveryNoteDetails1.caseNoteID;
    icProductDeliveryNoteDetails.creationDateTime = ICProductDeliveryNoteDetails1.creationDateTime;
    icProductDeliveryNoteDetails.fullname = ICProductDeliveryNoteDetails1.fullname;
    icProductDeliveryNoteDetails.notesText = ICProductDeliveryNoteDetails1.notesText;
    icProductDeliveryNoteDetails.priorityCode = ICProductDeliveryNoteDetails1.priorityCode;
    icProductDeliveryNoteDetails.recordStatus = ICProductDeliveryNoteDetails1.recordStatus;
    icProductDeliveryNoteDetails.sensitivityCode = ICProductDeliveryNoteDetails1.sensitivityCode;
    icProductDeliveryNoteDetails.userName = ICProductDeliveryNoteDetails1.userName;
    icProductDeliveryNoteDetails.versionNo = ICProductDeliveryNoteDetails1.versionNo;

    return icProductDeliveryNoteDetails;

  }

  // BEGIN, CR00291801, ASN
  /**
   * {@inheritDoc}
   */
  public InvestigationDeliveryListForProvider listInvestigationsForProvider(
    final ProviderConcernRoleKey providerConcernRoleKey) throws AppException,
      InformationalException {

    InvestigationDeliveryListForProvider investigationDeliveryListForProvider = new InvestigationDeliveryListForProvider();

    curam.provider.impl.Provider provider = providerDAO.newInstance();

    ProviderInvestigationDetailsList providerInvestigationDetailsList = provider.listInvestigationsForProvider(
      providerConcernRoleKey);

    for (final ProviderInvestigationDetails providerInvestigationDetails : providerInvestigationDetailsList.dtls.items()) {

      curam.cpm.facade.struct.ProviderInvestigationDetails providerInvestigation = new curam.cpm.facade.struct.ProviderInvestigationDetails();

      providerInvestigation.caseID = providerInvestigationDetails.caseID;
      providerInvestigation.caseParticipantRoleID = providerInvestigationDetails.caseParticipantRoleID;
      providerInvestigation.participantRoleID = providerInvestigationDetails.participantRoleID;
      providerInvestigation.caseReference = providerInvestigationDetails.caseReference;
      providerInvestigation.investigationType = providerInvestigationDetails.investigationType;
      providerInvestigation.roleString = providerInvestigationDetails.participantRoleType;
      providerInvestigation.startDate = providerInvestigationDetails.startDate;
      providerInvestigation.statusCode = providerInvestigationDetails.statusCode;
      providerInvestigation.resolutionStatus = providerInvestigationDetails.resolutionStatus;
      investigationDeliveryListForProvider.providerInvestigationDetails.add(
        providerInvestigation);

    }
    return investigationDeliveryListForProvider;
  }
  // END, CR00291801
}
