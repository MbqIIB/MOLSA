/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.cpm.sl.entity.fact.ProviderGroupAssociateFactory;
import curam.cpm.sl.entity.struct.CancelProviderGroupAssociateDetails;
import curam.cpm.sl.entity.struct.ProviderGroupAssociateDtls;
import curam.cpm.sl.entity.struct.ProviderGroupAssociateKey;
import curam.message.impl.PROVIDERGROUPASSOCIATEExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;


/**
 * This class is to set the values for entity operation.
 */
public abstract class ProviderGroupAssociate extends curam.cpm.sl.entity.base.ProviderGroupAssociate {

  // ___________________________________________________________________________
  /**
   * Pre Cancel Provider Group Associate method checks if associate is already
   * canceled
   *
   * @param providerGroupAssociateKey
   * contains ProviderGroupAssociateKey
   * @param cancelDetails
   * contains CancelProviderGroupAssociateDetails
   */
  protected void precancel(ProviderGroupAssociateKey providerGroupAssociateKey,
    CancelProviderGroupAssociateDetails cancelDetails) throws AppException,
      InformationalException {
    curam.cpm.sl.entity.intf.ProviderGroupAssociate associateObj = ProviderGroupAssociateFactory.newInstance();
    // read associate details
    ProviderGroupAssociateDtls associateDtls = associateObj.read(
      providerGroupAssociateKey);

    // check if associate is already canceled
    if (associateDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      throw PROVIDERGROUPASSOCIATEExceptionCreator.ERR_PROVIDERGROUPASSOCIATE_XRV_CANNOT_CANCEL_CANCELLED_PROVIDERGROUPASSOCIATE();
    }
    // set end date to current date and status to canceled
    cancelDetails.endDate = Date.getCurrentDate();
    cancelDetails.recordStatus = RECORDSTATUS.CANCELLED;

  }

}
