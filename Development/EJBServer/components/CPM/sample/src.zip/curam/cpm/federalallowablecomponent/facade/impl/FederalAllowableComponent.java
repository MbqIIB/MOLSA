/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.federalallowablecomponent.facade.impl;


import com.google.inject.Inject;
import curam.codetable.impl.CACLIENTPAIDSTATUSEntry;
import curam.codetable.impl.COUNTABLETYPEEntry;
import curam.codetable.impl.FEDALLOWCOMPRELATEDTYPEEntry;
import curam.core.facade.fact.ProductFactory;
import curam.core.facade.struct.ListProductDetailsStruct;
import curam.core.facade.struct.ProductDetailsStruct;
import curam.core.impl.CuramConst;
import curam.federalallowablecomponent.entity.struct.FederalAllowableComponentKey;
import curam.federalallowablecomponent.impl.FederalAllowableComponentDAO;
import curam.cpm.federalallowablecomponent.facade.struct.FederalAllowableComponentCancelKey;
import curam.cpm.federalallowablecomponent.facade.struct.FederalAllowableComponentCreateDetails;
import curam.cpm.federalallowablecomponent.facade.struct.FederalAllowableComponentDetails;
import curam.cpm.federalallowablecomponent.facade.struct.FederalAllowableComponentList;
import curam.cpm.federalallowablecomponent.facade.struct.FederalAllowableComponentModifyDetails;
import curam.cpm.federalallowablecomponent.facade.struct.FederalAllowableComponentViewDetails;
import curam.piwrapper.caseconfiguration.impl.Product;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.StringHelper;
import java.util.List;


/**
 * Facade operations for the Federal Allowable Component processing.
 *
 * @since 6.0
 */
public class FederalAllowableComponent extends curam.cpm.federalallowablecomponent.facade.base.FederalAllowableComponent {

  /**
   * Reference to Federal Allowable Component DAO.
   */
  @Inject
  protected FederalAllowableComponentDAO federalAllowableComponentDAO;

  /**
   * Constructor.
   */
  protected FederalAllowableComponent() {
    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public void cancelFederalAllowableComponent(
    final FederalAllowableComponentCancelKey cancelKey) throws AppException,
      InformationalException {
    curam.federalallowablecomponent.impl.FederalAllowableComponent federalAllowableComponent = federalAllowableComponentDAO.get(
      cancelKey.key.federalAllowableComponentID);

    federalAllowableComponent.cancel(cancelKey.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public FederalAllowableComponentList listAll() throws AppException,
      InformationalException {
    FederalAllowableComponentList federalAllowableComponentList = new FederalAllowableComponentList();
    FederalAllowableComponentDetails federalAllowableComponentDetails;

    List<curam.federalallowablecomponent.impl.FederalAllowableComponent> federalAllowableComponents = federalAllowableComponentDAO.listActive();

    for (curam.federalallowablecomponent.impl.FederalAllowableComponent federalAllowableComponent : federalAllowableComponents) {
      federalAllowableComponentDetails = new FederalAllowableComponentDetails();
      federalAllowableComponentDetails.name = federalAllowableComponent.getName();
      federalAllowableComponentDetails.description = federalAllowableComponent.getDescription();
      federalAllowableComponentDetails.dtls.federalAllowableComponentID = federalAllowableComponent.getID();
      federalAllowableComponentDetails.dtls.cAClientPaidStatus = federalAllowableComponent.getCAClientPaidStatus().getCode();
      federalAllowableComponentDetails.dtls.countableType = federalAllowableComponent.getCountableType().getCode();
      if (null != federalAllowableComponent.getNameLocalizableText()) {
        federalAllowableComponentDetails.dtls.nameTextID = federalAllowableComponent.getNameLocalizableText().getID();
      }
      if (null != federalAllowableComponent.getDescriptionLocalizableText()) {
        federalAllowableComponentDetails.dtls.descriptionTextID = federalAllowableComponent.getDescriptionLocalizableText().getID();
      }
      federalAllowableComponentDetails.dtls.endDate = federalAllowableComponent.getEndDate();
      federalAllowableComponentDetails.dtls.projectionAllowed = federalAllowableComponent.isProjectionAllowed();
      federalAllowableComponentDetails.dtls.recordStatus = federalAllowableComponent.getLifecycleState().getCode();
      federalAllowableComponentDetails.dtls.startDate = federalAllowableComponent.getStartDate();
      federalAllowableComponentDetails.dtls.versionNo = federalAllowableComponent.getVersionNo();
      federalAllowableComponentList.details.addRef(
        federalAllowableComponentDetails);
    }
    return federalAllowableComponentList;
  }

  /**
   * {@inheritDoc}
   */
  public FederalAllowableComponentKey createFederalAllowableComponent(
    final FederalAllowableComponentCreateDetails createDetails)
    throws AppException, InformationalException {

    FederalAllowableComponentKey key = new FederalAllowableComponentKey();
    curam.federalallowablecomponent.impl.FederalAllowableComponent federalAllowableComponent = federalAllowableComponentDAO.newInstance();

    assignDetails(createDetails, federalAllowableComponent);

    federalAllowableComponent.insert();
    key.federalAllowableComponentID = federalAllowableComponent.getID();
    // link the programs to the federal allowable component
    if (!StringHelper.isEmpty(createDetails.programIDList)) {
      final String[] programIDsString = createDetails.programIDList.split(
        CuramConst.gkTabDelimiter);

      for (String programID : programIDsString) {
        federalAllowableComponent.addFederalAllowableComponentLink(
          Long.valueOf(programID), FEDALLOWCOMPRELATEDTYPEEntry.PRODUCT);
      }
    }
    return key;
  }

  /**
   * Assign the passed in details to the federal allowable component object
   * instance.
   *
   * @param details
   * the details passed in
   * @param federalAllowableComponent
   * the object instance to assign the details to
   */
  protected void assignDetails(
    final FederalAllowableComponentCreateDetails details,
    final curam.federalallowablecomponent.impl.FederalAllowableComponent federalAllowableComponent) {
    federalAllowableComponent.setCAClientPaidStatus(
      CACLIENTPAIDSTATUSEntry.get(details.details.dtls.cAClientPaidStatus));
    federalAllowableComponent.setCountableType(
      COUNTABLETYPEEntry.get(details.details.dtls.countableType));
    federalAllowableComponent.setDescription(details.details.description);
    federalAllowableComponent.setEndDate(details.details.dtls.endDate);
    federalAllowableComponent.setName(details.details.name);
    federalAllowableComponent.setProjectionAllowed(
      details.details.dtls.projectionAllowed);
    federalAllowableComponent.setStartDate(details.details.dtls.startDate);
  }

  /**
   * {@inheritDoc}
   */
  public void editFederalAllowableComponent(
    final FederalAllowableComponentCreateDetails editDetails)
    throws AppException, InformationalException {

    curam.federalallowablecomponent.impl.FederalAllowableComponent federalAllowableComponent = federalAllowableComponentDAO.get(
      editDetails.details.dtls.federalAllowableComponentID);

    assignDetails(editDetails, federalAllowableComponent);
    federalAllowableComponent.modify(editDetails.details.dtls.versionNo);
    // update the associated programs
    // link the case participants to the service delivery
    federalAllowableComponent.updateFederalAllowableComponentLinks(
      editDetails.programIDList, FEDALLOWCOMPRELATEDTYPEEntry.PRODUCT);
  }

  /**
   * {@inheritDoc}
   */
  public FederalAllowableComponentModifyDetails readFederalAllowableComponentForModify(
    final FederalAllowableComponentKey key) throws AppException,
      InformationalException {

    curam.federalallowablecomponent.impl.FederalAllowableComponent federalAllowableComponent = federalAllowableComponentDAO.get(
      key.federalAllowableComponentID);

    FederalAllowableComponentModifyDetails details = new FederalAllowableComponentModifyDetails();

    details.modifyDetails.details = assignViewDetails(federalAllowableComponent);

    details.modifyDetails.programIDList = getStringTabbedAssociatedPrograms(
      federalAllowableComponent);

    curam.core.facade.intf.Product product = ProductFactory.newInstance();

    details.programs = product.listAllProducts();

    return details;
  }

  /**
   * Gets a tab delimited string of the products associated a the federal
   * allowable component.
   *
   * @param federalAllowableComponent
   * federal allowable component object instance
   * @return tab delimited string of the program identifiers
   */
  protected String getStringTabbedAssociatedPrograms(
    final curam.federalallowablecomponent.impl.FederalAllowableComponent federalAllowableComponent) {
    ListProductDetailsStruct products = getAssociatedPrograms(
      federalAllowableComponent);

    StringBuffer strBuf = new StringBuffer();

    for (ProductDetailsStruct product : products.productDetailsStruct.items()) {
      if (strBuf.length() != 0) {
        strBuf.append(CuramConst.gkTabDelimiterChar);
      }
      strBuf.append(product.productID);
    }
    return strBuf.toString();
  }

  /**
   * {@inheritDoc}
   */
  public FederalAllowableComponentViewDetails viewFederalAllowableComponent(
    final FederalAllowableComponentKey key) throws AppException,
      InformationalException {

    FederalAllowableComponentViewDetails federalAllowableComponentViewDetails = new FederalAllowableComponentViewDetails();

    curam.federalallowablecomponent.impl.FederalAllowableComponent federalAllowableComponent = federalAllowableComponentDAO.get(
      key.federalAllowableComponentID);

    federalAllowableComponentViewDetails.details = assignViewDetails(
      federalAllowableComponent);

    federalAllowableComponentViewDetails.programs = getAssociatedPrograms(
      federalAllowableComponent);
    if (0
      < federalAllowableComponentViewDetails.programs.productDetailsStruct.size()) {
      federalAllowableComponentViewDetails.programsExistInd = true;
    }

    return federalAllowableComponentViewDetails;
  }

  /**
   * Retrieves and populates the list of programs in the system which are
   * associated to this federal allowable component.
   *
   * @param federalAllowableComponent
   * the federal allowable component object instance
   * @return the programs list
   */
  protected ListProductDetailsStruct getAssociatedPrograms(
    final curam.federalallowablecomponent.impl.FederalAllowableComponent federalAllowableComponent) {

    // list the programs for the federal allowable component
    List<Product> products = federalAllowableComponent.listPrograms();

    ListProductDetailsStruct listProductDetailsStruct = new ListProductDetailsStruct();

    ProductDetailsStruct productDetails;

    for (Product programLink : products) {
      productDetails = new ProductDetailsStruct();
      productDetails.productID = programLink.getID();
      // productDetails.name = product.getProductType().getCode();
      productDetails.typeCode = programLink.getProductType().getCode();
      listProductDetailsStruct.productDetailsStruct.addRef(productDetails);
    }
    return listProductDetailsStruct;
  }

  /**
   * Assigns the view details of the federal allowable component.
   *
   * @param federalAllowableComponent
   * the federal allowable component object instance
   * @return the populated details
   */
  protected FederalAllowableComponentDetails assignViewDetails(
    final curam.federalallowablecomponent.impl.FederalAllowableComponent federalAllowableComponent) {

    FederalAllowableComponentDetails viewDetails = new FederalAllowableComponentDetails();

    viewDetails.dtls.federalAllowableComponentID = federalAllowableComponent.getID();
    viewDetails.name = federalAllowableComponent.getName();
    if (null != federalAllowableComponent.getNameLocalizableText()) {
      viewDetails.dtls.nameTextID = federalAllowableComponent.getNameLocalizableText().getID();
    }
    viewDetails.description = federalAllowableComponent.getDescription();
    if (null != federalAllowableComponent.getDescriptionLocalizableText()) {
      viewDetails.dtls.descriptionTextID = federalAllowableComponent.getDescriptionLocalizableText().getID();
    }
    viewDetails.dtls.countableType = federalAllowableComponent.getCountableType().getCode();
    viewDetails.dtls.cAClientPaidStatus = federalAllowableComponent.getCAClientPaidStatus().getCode();
    viewDetails.dtls.projectionAllowed = federalAllowableComponent.isProjectionAllowed();
    viewDetails.dtls.startDate = federalAllowableComponent.getStartDate();
    viewDetails.dtls.endDate = federalAllowableComponent.getEndDate();
    viewDetails.dtls.versionNo = federalAllowableComponent.getVersionNo();
    return viewDetails;
  }
}
