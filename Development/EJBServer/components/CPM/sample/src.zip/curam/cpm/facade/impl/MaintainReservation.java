/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RESERVATIONCANCELREASONEntry;
import curam.codetable.impl.RESERVATIONSTATUSEntry;
import curam.core.impl.CuramConst;
import curam.core.struct.ConcernRoleID;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.PlaceAndPlaceLocation;
import curam.cpm.facade.struct.PlaceAndPlaceLocationDetailsList;
import curam.cpm.facade.struct.PlaceAndPlaceLocationList;
import curam.cpm.facade.struct.PlaceLocationDetails;
import curam.cpm.facade.struct.PlaceReservationPeriodKey;
import curam.cpm.facade.struct.ProviderKey;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetails;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetailsList;
import curam.cpm.facade.struct.ReservationCancelKey;
import curam.cpm.facade.struct.ReservationClientIDAndProviderStatusSearchCriteria;
import curam.cpm.facade.struct.ReservationConfirmDetails;
import curam.cpm.facade.struct.ReservationHistoryDetails;
import curam.cpm.facade.struct.ReservationHistoryDetailsList;
import curam.cpm.facade.struct.ReservationKey;
import curam.cpm.facade.struct.ReservationPeriodDetails;
import curam.cpm.facade.struct.ReservationPeriodKey;
import curam.cpm.facade.struct.ReservationSearchDetails;
import curam.cpm.facade.struct.ReservationSearchDetailsList;
import curam.cpm.facade.struct.ReservationStatusHistoryDetails;
import curam.cpm.facade.struct.ReservationStatusHistoryDetailsList;
import curam.cpm.facade.struct.ReservationSummaryDetails;
import curam.cpm.facade.struct.ReservationSummaryDetailsList;
import curam.cpm.facade.struct.ReservationUpdateDetails;
import curam.cpm.facade.struct.ReservationVerifyDetails;
import curam.cpm.facade.struct.ReservationViewDetails;
import curam.cpm.facade.struct.ReservationViewDetailsList;
import curam.cpm.facade.struct.ReservationViewSummaryDetails;
import curam.cpm.facade.struct.SearchReservationKey;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.PlaceKey;
import curam.cpm.sl.entity.struct.ProviderOfferingIDAndDateTimeKey;
import curam.message.impl.RESERVATIONExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.place.impl.Compartment;
import curam.place.impl.CompartmentDAO;
import curam.place.impl.Place;
import curam.place.impl.PlaceDAO;
import curam.place.impl.Placement;
import curam.place.impl.PlacementDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderSecurity;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.reservation.impl.Reservation;
import curam.reservation.impl.ReservationDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.DateTimeRange;


/**
 * {@inheritDoc}
 */
public abstract class MaintainReservation extends curam.cpm.facade.base.MaintainReservation {

  /**
   * Reservation DAO object
   */
  @Inject
  protected ReservationDAO reservationDAO;

  /**
   * Place DAO object
   */
  @Inject
  protected PlaceDAO placeDAO;

  /**
   * Compartment DAO object
   */
  @Inject
  protected CompartmentDAO compartmentDAO;

  /**
   * providerSecurity type of ProviderSecurity
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * Provider DAO object.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Service Offering DAO object.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Placement DAO object.
   */
  @Inject
  protected PlacementDAO placementDAO;

  /**
   * Concern Role DAO object.
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  // BEGIN, CR00248428, GP
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;
  // END, CR00248428
  
  /**
   * Default constructor
   */
  public MaintainReservation() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public ReservationKey cancelReservation(
    ReservationCancelKey reservationCancelKey) throws AppException,
      InformationalException {

    Reservation reservation = reservationDAO.get(
      reservationCancelKey.reservationID);

    // check appropriate security privileges
    providerSecurity.checkProviderSecurity(
      reservation.getProviderOffering().getProvider());

    reservation.cancelReservation(reservationCancelKey.versionNo,
      RESERVATIONCANCELREASONEntry.get(reservationCancelKey.cancellationReason),
      reservationCancelKey.comments);

    ReservationKey reservationKey = new ReservationKey();

    reservationKey.key.reservationID = reservation.getID();
    return reservationKey;
  }

  // BEGIN, CR00293856, IBM
  /**
   * Confirms the reservation as placement.
   *
   * @param reservationConfirmDetails
   * Reservation confirm details.
   * @return ReservationConfirmDetails Reservation confirm details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 5.2 SP5, replaced with {@link
   * MaintainReservation#verifyReservation(ReservationConfirmDetails)}
   *
   * This method is deprecated as informational messages are not returned. 
   * This method is replaced by verifyReservation(ReservationConfirmDetails)
   * which returns the informational message along with reservation details
   * as well. See release note: CS-09152/CR00293856.
   */
  @Deprecated
  public ReservationConfirmDetails confirmReservation(
    ReservationConfirmDetails reservationConfirmDetails) throws AppException,
      InformationalException {
    // END, CR00293856
  
    Placement placement = placementDAO.newInstance();
    Reservation reservation = reservationDAO.get(
      reservationConfirmDetails.reservationID);

    // check appropriate security privileges
    providerSecurity.checkProviderSecurity(
      reservation.getProviderOffering().getProvider());
    
    // BEGIN, CR00154949, AK
    DateTimeRange placementPeriod = new DateTimeRange(
      reservationConfirmDetails.from, reservationConfirmDetails.to);

    Place placeObj = placeDAO.get(reservationConfirmDetails.placeID);

    List<Reservation> activeReservations = reservationDAO.searchOverlappingActiveReservationsForPlace(
      placeObj, placementPeriod);

    if (activeReservations.size() != 0) {
      for (Reservation activeReservation : activeReservations) {
        if (activeReservation.getID() != reservation.getID().longValue()) {
          reservationConfirmDetails.activeReservationDtls.activeReservationExistsInd = true;
        }
      }
    }
    // END, CR00154949

    Placement overlappingPlacement = placement.getOverlappingPlacementForClient(
      reservation.getCaseParticipantRoleID(),
      new DateTimeRange(reservationConfirmDetails.from,
      reservationConfirmDetails.to));

    if (overlappingPlacement != null) {
      reservationConfirmDetails.updateOverlappingPlacementPeriodInd = true;
    }

    // BEGIN, CR00154949, AK
    // If there are no overlapping placements, then confirm the reservation
    if (!reservationConfirmDetails.updateOverlappingPlacementPeriodInd
      && !reservationConfirmDetails.activeReservationDtls.activeReservationExistsInd) {
      confirmReservationASPlacement(reservationConfirmDetails);
    }
    // END, CR00154949

    // Retrieve the list of reservations overlapping with the
    // placement period
    // BEGIN, CR00137279, JSP
    List<Reservation> overlappingReservations = reservationDAO.searchOverlappingReservationsForClient(
      reservation, reservation.getDateTimeRange());

    if (overlappingReservations.size() != 0) {
      reservationConfirmDetails.cancelExistingReservations = true;
    }
    // END, CR00137279

    return reservationConfirmDetails;

  }

  // BEGIN, CR00293856, IBM
  /**
   * Confirms the placement and modifies the overlapping placement period.
   *
   * @param reservationConfirmDetails
   * Confirm reservation details.
   * @return ReservationConfirmDetails Confirm reservation details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 5.2 SP5, replaced with {@link 
   * MaintainReservation#confirmUpdatedPlacement(ReservationConfirmDetails)}
   *
   * This method is deprecated as informational messages are not returned. 
   * This method is replaced by confirmUpdatedPlacement(ReservationConfirmDetails) 
   * which returns the informational message along with reservation details 
   * as well. See release note: CS-09152/CR00293856.
   */
  @Deprecated
  public ReservationConfirmDetails confirmModifyPlacement(
    ReservationConfirmDetails reservationConfirmDetails) throws AppException,
      InformationalException {
    // END, CR00293856
    boolean confirmCancelOverlappingReservation = false;

    if (reservationConfirmDetails.cancelExistingReservations == true) {
      confirmCancelOverlappingReservation = true;
    }

    reservationConfirmDetails.cancelExistingReservations = false;

    confirmReservationASPlacement(reservationConfirmDetails);

    reservationConfirmDetails.cancelExistingReservations = confirmCancelOverlappingReservation;
    
    return reservationConfirmDetails;

  }

  /**
   * {@inheritDoc}
   */
  public ReservationConfirmDetails confirmCancelExistingReservation(
    ReservationConfirmDetails reservationConfirmDetails) throws AppException,
      InformationalException {

    Reservation reservation = reservationDAO.get(
      reservationConfirmDetails.reservationID);

    reservation.cancelOverlappingActiveReservations();

    return reservationConfirmDetails;
  }

  /**
   * Returns the Reservation details like client name, from Date, to Date and
   * status depending upon the search criteria entered.
   *
   * @param searchReservationKey
   * key to search Reservation details.
   * @return ReservationSearchDetailsList Contains the list of reservation
   * details retrieved based on the search criteria
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link curam.cpm.facade.impl.MaintainReservation#searchByReservationStatusProviderAndClient(ReservationClientIDAndProviderStatusSearchCriteria reservationClientIDAndProviderStatusSearchCriteria)}
   * . In order to search reservations specific to client from
   * search criteria. See release notes: CR00186599
   */
  @Deprecated
  public ReservationSearchDetailsList searchReservation(
    SearchReservationKey searchReservationKey) throws AppException,
      InformationalException {

    String clientName = searchReservationKey.name.trim();
    String status = searchReservationKey.status.trim();

    // Check whether the search criteria is entered
    if (clientName.length() == 0 && status.length() == 0
      && searchReservationKey.fromDate.isZero()
      && searchReservationKey.toDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        RESERVATIONExceptionCreator.ERR_RESERVATION_FV_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    // Check whether From Date is after To Date
    if (searchReservationKey.fromDate != null
      && !searchReservationKey.fromDate.isZero()
      && searchReservationKey.toDate != null
      && !searchReservationKey.toDate.isZero()
      && searchReservationKey.fromDate.after(searchReservationKey.toDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        RESERVATIONExceptionCreator.ERR_RESERVATION_XRV_FROM_DATE_TIME_LATER_THAN_TO_DATE_TIME(
          searchReservationKey.fromDate, searchReservationKey.toDate),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    if ((searchReservationKey.fromDate == null
      || searchReservationKey.fromDate.isZero())
        && (searchReservationKey.toDate != null
          && !searchReservationKey.toDate.isZero())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        RESERVATIONExceptionCreator.ERR_RESERVATION_FV_FROMDATE_MANDATORY_IF_TODATE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    ValidationHelper.failIfErrorsExist();

    // Retrieve list of reservation details based on the search criteria
    ReservationSearchDetailsList reservationSearchDetailsList = new ReservationSearchDetailsList();
    RESERVATIONSTATUSEntry reservationStatusEntry = RESERVATIONSTATUSEntry.get(
      searchReservationKey.status);

    ConcernRole concernRole = concernRoleDAO.get(
      searchReservationKey.providerConcernRoleID);

    final List<Reservation> reservations = reservationDAO.searchByReservationStatusProviderAndClient(
      reservationStatusEntry, searchReservationKey.name, concernRole);

    DateTimeRange dateTimeRange = null;

    if (!searchReservationKey.fromDate.equals(DateTime.kZeroDateTime)) {

      dateTimeRange = new DateTimeRange(searchReservationKey.fromDate,
        searchReservationKey.toDate);
    }

    // Populating the list of reservation details to return struct
    for (final curam.reservation.impl.Reservation reservation : reservations) {

      if (dateTimeRange != null) {
        if (dateTimeRange.overlapsWith(reservation.getDateTimeRange())) {
          reservationSearchDetailsList.searchList.addRef(
            getReservationSearchFields(reservation));
        }
      } else {
        reservationSearchDetailsList.searchList.addRef(
          getReservationSearchFields(reservation));
      }

    }

    return sortReservations(reservationSearchDetailsList);
  }

  /**
   * {@inheritDoc}
   */
  public ReservationKey updateReservation(
    ReservationUpdateDetails reservationUpdateDetails) throws AppException,
      InformationalException {

    Reservation reservation = reservationDAO.get(
      reservationUpdateDetails.reservationID);

    // check appropriate security privileges
    providerSecurity.checkProviderSecurity(
      reservation.getProviderOffering().getProvider());
    Place place = validatePlaceID(reservationUpdateDetails.placeID);
    ServiceOffering serviceOffering = validateServiceOfferingID(
      reservationUpdateDetails.serviceOfferingID);
    DateTimeRange reservationPeriod = new DateTimeRange(
      reservationUpdateDetails.from, reservationUpdateDetails.to);
    // call the API method to update the reservation.
    Reservation reservationInformation = reservation.updateReservation(
      reservationPeriod, serviceOffering, place,
      reservationUpdateDetails.comments, reservationUpdateDetails.versionNo);
    ReservationKey reservationKey = new ReservationKey();

    reservationKey.key.reservationID = reservationInformation.getID();
    return reservationKey;
   
  }

  /**
   * {@inheritDoc}
   */
  public ReservationViewSummaryDetails viewReservation(
    ReservationKey reservationKey) throws AppException,
      InformationalException {

    Reservation reservation = reservationDAO.get(
      reservationKey.key.reservationID);

    ReservationViewSummaryDetails details = getReservationFields(reservation);

    if (reservation.getLifecycleState().equals(RESERVATIONSTATUSEntry.FULFILLED)) {
      details.isFulfilled = true;
      if (reservation.getPlacement() != null) {
        details.placementID = reservation.getPlacement().getID();
      }
    } else {
      details.isFulfilled = false;
    }
    
    return details;
   
  }

  /**
   * Returns a list of all reservation status history records for a given
   * reservation.
   *
   * @param reservationKey
   * The key specifying the reservation to list reservation status
   * history records by.
   * @return ReservationStatusHistoryDetailsList list of reservation status
   * history summary details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReservationStatusHistoryDetailsList viewReservationStatusHistory(
    ReservationKey reservationKey) throws AppException,
      InformationalException {

    final ReservationStatusHistoryDetailsList reservationStatusHistoryList = new ReservationStatusHistoryDetailsList();

    final Reservation reservation = reservationDAO.get(
      reservationKey.key.reservationID);

    for (final curam.reservation.impl.ReservationStatusHistory reservationStatusHistory : reservation.getStatusHistory()) {

      ReservationStatusHistoryDetails reservationStatusHistorySummaryDetails = new ReservationStatusHistoryDetails();

      reservationStatusHistorySummaryDetails.status = reservationStatusHistory.getReservationRecordStatus().getCode();
      reservationStatusHistorySummaryDetails.creationDateTime = reservationStatusHistory.getCreationDateTime();
      reservationStatusHistorySummaryDetails.userName = reservationStatusHistory.getUserName();
      reservationStatusHistorySummaryDetails.cancellationReason = reservationStatusHistory.getCancellationReason().getCode();

      reservationStatusHistoryList.detailsList.addRef(
        reservationStatusHistorySummaryDetails);
    }

    return reservationStatusHistoryList;
  }

  // BEGIN, CR00248428, GP
  /**
   * {@inheritDoc}
   */
  public ReservationHistoryDetailsList viewReservationStatusHistoryDetails(
    final ReservationKey reservationKey) throws AppException,
      InformationalException {

    ReservationHistoryDetailsList reservationHistoryDetailsList = new ReservationHistoryDetailsList();

    ReservationStatusHistoryDetailsList reservationStatusHistoryDetailsList = viewReservationStatusHistory(
      reservationKey);

    for (final ReservationStatusHistoryDetails reservationStatusHistoryDetails : 
      reservationStatusHistoryDetailsList.detailsList.items()) {

      ReservationHistoryDetails reservationHistoryDetails = new ReservationHistoryDetails();

      reservationHistoryDetails.reservationHistoryDetails = reservationStatusHistoryDetails;

      User user = userDAO.get(reservationStatusHistoryDetails.userName);

      reservationHistoryDetails.userFullName = user.getFullName();

      reservationHistoryDetailsList.reservationHistoryDetails.addRef(
        reservationHistoryDetails);
    }
    return reservationHistoryDetailsList;
  }

  // END, CR00248428

  /**
   * Retrieves location for a specified Place.
   *
   * @param key
   * Contains Place ID.
   * @return PlaceLocationDetails Contains Place location details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public PlaceLocationDetails getLocationForPlace(PlaceKey key)
    throws AppException, InformationalException {
    PlaceLocationDetails locationDetails = new PlaceLocationDetails();
    Place place = placeDAO.get(key.placeID);
    Compartment currentCompartment = place.getCompartment();
    Compartment parentCompartment = currentCompartment.getParentCompartment();
    String location = "";

    if (parentCompartment != null) {
      location = buildLocation(parentCompartment, location);
    }
    location += currentCompartment.getName();
    locationDetails.location = location;
    return locationDetails;
  }

  // BEGIN, CR00293856, IBM
  /**
   * Retrieves the list of available places for the reservation date range.
   *
   * @param reservationPeriodKey
   * Contains reservation period.
   * @return PlaceAndPlaceLocationList List of available places.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 5.2 SP5, replaced with {@link
   * MaintainReservation#getAvailablePlacesForReservation(ReservationPeriodKey)}
   *
   * This method is deprecated as informational messages are not returned. 
   * This method is replaced by getAvailablePlacesForReservation(ReservationPeriodKey)
   * which returns the informational message along with place and place location details 
   * as well. See release note: CS-09152/CR00293856.
   */
  @Deprecated
  public PlaceAndPlaceLocationList listAvailablePlacesForReservation(
    ReservationPeriodKey reservationPeriodKey) throws AppException,
      InformationalException {
    // END , CR00293856
    PlaceAndPlaceLocationList placeLocationList = new PlaceAndPlaceLocationList();

    Reservation reservation = reservationDAO.get(
      reservationPeriodKey.reservationID);

    // Retrieve the list of places for the provider and date range
    Set<Place> availablePlaces = reservation.getPlaceAvailableInDateRange(
      reservation.getProvider(), reservation.getDateTimeRange());

    // BEGIN CR00121319, NRV
    placeLocationList.placeIndicator = CuramConst.gkZero;
    int placeCount = availablePlaces.size();

    // END CR00121319

    // Retrieve the place and location details for each place
    for (curam.place.impl.Place place : availablePlaces) {

      PlaceKey placeKey = new PlaceKey();

      PlaceAndPlaceLocation placeAndLocation = new PlaceAndPlaceLocation();

      placeKey.placeID = place.getID();

      // Retrieves the location details
      PlaceLocationDetails placeLocationDetails = place.getLocationForPlace();

      // Set the place and location details
      placeAndLocation.placeLocation = placeLocationDetails.location;

      placeAndLocation.placeName = place.getName();

      placeAndLocation.placeID = place.getID();

      placeLocationList.place.addRef(placeAndLocation);
    }
    // BEGIN CR00121319, NRV
    if (placeCount > CuramConst.gkZero) {
      placeLocationList.placeIndicator = placeCount;
    }
    // END CR00121319

    return placeLocationList;
  }

  /**
   * Retrieves the update details which is passed by input screen.
   *
   * @param reservationUpdateDetails
   * Reservation update details.
   * @return ReservationUpdateDetails Reservation update details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReservationUpdateDetails retrieveUpdateDetailsPassedByClient(
    ReservationUpdateDetails reservationUpdateDetails) throws AppException,
      InformationalException {

    return reservationUpdateDetails;
  }

  /**
   * Retrieves the confirm details which is passed by input screen.
   *
   * @param reservationConfirmDetails
   * Reservation confirm details.
   * @return ReservationConfirmDetails Reservation confirm details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReservationConfirmDetails retrieveConfirmDetailsPassedByClient(
    ReservationConfirmDetails reservationConfirmDetails) throws AppException,
      InformationalException {
  
    return reservationConfirmDetails;
  }

  /**
   * List all active reservation for provider.
   *
   * @param providerKey
   * Contains providerID
   * @return ReservationSummaryDetailsList contains list of reservation for
   * provider.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReservationSummaryDetailsList listReservations(ProviderKey providerKey)
    throws AppException, InformationalException {

    Provider provider = providerDAO.get(providerKey.providerID);
    ReservationSummaryDetailsList reservationSummaryList = new ReservationSummaryDetailsList();

    for (final curam.providerservice.impl.ProviderOffering providerOffering : provider.getProviderOfferings()) {

      ProviderOfferingIDAndDateTimeKey providerOfferingKey = new ProviderOfferingIDAndDateTimeKey();

      providerOfferingKey.providerOfferingID = providerOffering.getID();

      // Reservation can be done only for service offering of type 'Place'
      // and for approved provider offering.
      // BEGIN, CR00124019, NK
      if (providerOffering.getLifecycleState().equals(
        ProviderOfferingStatusEntry.APPROVED)) {
        // END, CR00124019

        // Retrieve list of active reservation for provider offering.
        List<curam.reservation.impl.Reservation> reservations = reservationDAO.listReservationByProviderOfferingAndStatus(
          providerOffering, RESERVATIONSTATUSEntry.ACTIVE);

        for (final curam.reservation.impl.Reservation reservation : reservations) {
          ReservationSummaryDetails reservationSummary = new ReservationSummaryDetails();

          reservationSummary.clientID = reservation.getClient().getID();
          reservationSummary.clientName = reservation.getClient().getName();
          reservationSummary.from = reservation.getDateTimeRange().start();
          reservationSummary.to = reservation.getDateTimeRange().end();
          if (reservation.getPlace() != null) {
            reservationSummary.placeName = reservation.getPlace().getName();
          }
          reservationSummary.reservationID = reservation.getID();
          reservationSummary.versionNo = reservation.getVersionNo();

          reservationSummaryList.summaryList.addRef(reservationSummary);

        }
      }

    }

    return sortListReservations(reservationSummaryList);

  }

  /**
   * Lists all the provider offerings with status approved and service offerings
   * with unit of measure place for a given provider.
   *
   * @param providerKey
   * The Key for the Provider for whom the provider offerings are to be
   * retrieved.
   * @return ProviderOfferingSummaryDetailsList The Provider offerings list for
   * a given provider.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderOfferingSummaryDetailsList listApprovedProviderOffering(
    ProviderKey providerKey) throws AppException, InformationalException {

    ProviderOfferingSummaryDetailsList providerOfferingSummaryDetailsList = new ProviderOfferingSummaryDetailsList();

    final Provider provider = providerDAO.get(providerKey.providerID);
    ProviderOfferingSummaryDetails providerOfferingSummaryDetails;

    for (final curam.providerservice.impl.ProviderOffering providerOffering : provider.getProviderOfferings()) {
      providerOfferingSummaryDetails = new ProviderOfferingSummaryDetails();
      curam.serviceoffering.impl.ServiceOffering serviceOffering = providerOffering.getServiceOffering();

      // BEGIN, CR00124019, NK
      if (providerOffering.getLifecycleState().getCode().equals(
        ProviderOfferingStatusEntry.APPROVED.getCode())) {

        providerOfferingSummaryDetails.name = serviceOffering.getName();
        providerOfferingSummaryDetails.providerOfferingID = serviceOffering.getID();

        providerOfferingSummaryDetailsList.providerOfferingSummaryDetails.addRef(
          providerOfferingSummaryDetails);
      }
      // END, CR00124019
    }

    return providerOfferingSummaryDetailsList;
  }
  
  // BEGIN, CR00205476, GP
  /**
   * {@inheritDoc}
   */
  public ReservationViewDetailsList listReservationDetails(
    final ProviderKey providerKey) throws AppException,
      InformationalException {

    Provider provider = providerDAO.get(providerKey.providerID);
    ReservationViewDetailsList reservationViewDetailsList = new ReservationViewDetailsList();

    for (final curam.providerservice.impl.ProviderOffering providerOffering : provider.getProviderOfferings()) {

      ProviderOfferingIDAndDateTimeKey providerOfferingKey = new ProviderOfferingIDAndDateTimeKey();

      providerOfferingKey.providerOfferingID = providerOffering.getID();

      // Reservation can be done only for service offering of type 'Place'
      // and for approved provider offering.
      if (ProviderOfferingStatusEntry.APPROVED.equals(
        providerOffering.getLifecycleState())) {

        List<Reservation> reservations = reservationDAO.listReservationByProviderOfferingAndStatus(
          providerOffering, RESERVATIONSTATUSEntry.ACTIVE);

        for (final Reservation reservation : reservations) {

          ReservationViewDetails reservationViewDetails = new ReservationViewDetails();

          reservationViewDetails.clientID = reservation.getClient().getID();
          reservationViewDetails.clientName = reservation.getClient().getName();
          reservationViewDetails.serviceName = providerOffering.getServiceOffering().getName();
          reservationViewDetails.from = reservation.getDateTimeRange().start();
          reservationViewDetails.to = reservation.getDateTimeRange().end();
          
          if (null != reservation.getPlace()) {
            
            reservationViewDetails.placeName = reservation.getPlace().getName();
          }
          
          reservationViewDetails.reservationID = reservation.getID();
          reservationViewDetails.versionNo = reservation.getVersionNo();

          if (RESERVATIONSTATUSEntry.FULFILLED.equals(
            reservation.getLifecycleState())) {

            reservationViewDetails.isFulfilled = true;

            if (null != reservation.getPlacement()) {
              reservationViewDetails.placementID = reservation.getPlacement().getID();
            }
          } else {
            reservationViewDetails.isFulfilled = false;
          }

          reservationViewDetailsList.reservationViewDetails.addRef(
            reservationViewDetails);

        }
      }

    }

    return sortReservations(reservationViewDetailsList);
  }

  // END, CR00205476

  // BEGIN, CR00154949, AK
  /**
   * Checks if there is an active reservation exists, on the place, overlapping
   * with the given period.
   *
   * @param placeReservationPeriodKey
   * The reservation period details.
   *
   * @return The list of informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationalMessageList searchActiveReservationWithOverlappingPeriod(
    PlaceReservationPeriodKey placeReservationPeriodKey) throws AppException,
      InformationalException {

    InformationalMessageList messageList = new InformationalMessageList();

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    DateTimeRange placementPeriod = new DateTimeRange(
      placeReservationPeriodKey.from, placeReservationPeriodKey.to);

    Place placeObj = placeDAO.get(placeReservationPeriodKey.placeID);

    List<Reservation> reservations = reservationDAO.searchOverlappingActiveReservationsForPlace(
      placeObj, placementPeriod);

    if (reservations.size() > 0) {
      for (Reservation reservation : reservations) {
        if (reservation.getID() != placeReservationPeriodKey.reservationID) {
          AppException appException = RESERVATIONExceptionCreator.INF_PLACE_XRV_ACTIVE_RESERVATION_EXISTS_CONFIRM_CANCEL_RESERVATION(
            new Date(reservation.getDateTimeRange().start()),
            new Date(reservation.getDateTimeRange().end()));

          informationalManager.addInformationalMsg(appException,
            CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning);
        }
      }

      // Assign informational messages to the returned struct
      String warnings[] = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        InformationalMessage infoMessage = new InformationalMessage();

        infoMessage.messageTest = warnings[i];
        messageList.dtls.addRef(infoMessage);
      }
    }

    return messageList;
  }

  /**
   * Confirms the placement and cancels the existing reservation.
   *
   * @param reservationConfirmDetails
   * Confirm reservation details.
   * @return ReservationConfirmDetails Confirm reservation details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReservationConfirmDetails confirmCancelExistingReservationForAnyClient(
    ReservationConfirmDetails reservationConfirmDetails) throws AppException,
      InformationalException {

    boolean confirmCancelOverlappingReservation = false;

    if (reservationConfirmDetails.cancelExistingReservations == true) {
      confirmCancelOverlappingReservation = true;
    }

    reservationConfirmDetails.cancelExistingReservations = false;

    confirmReservationASPlacement(reservationConfirmDetails);

    // Cancel the existing active reservation
    DateTimeRange placementPeriod = new DateTimeRange(
      reservationConfirmDetails.from, reservationConfirmDetails.to);
    Place placeObj = placeDAO.get(reservationConfirmDetails.placeID);

    List<Reservation> reservations = reservationDAO.searchOverlappingActiveReservationsForPlace(
      placeObj, placementPeriod);

    if (reservations.size() > 0) {
      for (Reservation reservation : reservations) {
        reservation.cancel(reservation.getVersionNo(),
          RESERVATIONCANCELREASONEntry.OVERRRIDENBYPLACEMENT);
      }
    }

    reservationConfirmDetails.cancelExistingReservations = confirmCancelOverlappingReservation;
    
    return reservationConfirmDetails;

  }

  // END, CR00154949

  /**
   * Validate ID passed and returns an instance of place
   *
   * @param placeID
   * Contains place ID
   * @return Place Contains Place instance
   * @throws InformationalException
   */
  protected Place validatePlaceID(long placeID) throws InformationalException {
    Place place = null;

    if (placeID != 0) {
      try {
        place = placeDAO.get(placeID);
        place.getLifecycleState();
      } catch (RecordNotFoundException e) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          RESERVATIONExceptionCreator.ERR_RESERVATION_FV_PLACE_ID_IS_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }
    }
    return place;

  }

  /**
   * Validate ID passed and returns an instance of ServiceOffering
   *
   * @param serviceOfferingID
   * Contains service Offering ID
   * @return serviceOffering Contains serviceOffering instance
   * @throws InformationalException
   */
  protected ServiceOffering validateServiceOfferingID(long serviceOfferingID)
    throws InformationalException {
    ServiceOffering serviceOffering = null;

    try {
      if (serviceOfferingID != 0) {
        serviceOffering = serviceOfferingDAO.get(serviceOfferingID);
      } else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          RESERVATIONExceptionCreator.ERR_RESERVATION_FV_SERVICEOFFERING_ID_IS_MANDATORY(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }
      serviceOffering.getLifecycleState();
    } catch (RecordNotFoundException e) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        RESERVATIONExceptionCreator.ERR_RESERVATION_FV_SERVICEOFFERING_IS_INVALID(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }
    return serviceOffering;

  }

  /**
   * Confirms the reservation and creates a placement.
   *
   * @param reservationConfirmDetails
   * Reservation confirm details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void confirmReservationASPlacement(
    ReservationConfirmDetails reservationConfirmDetails) throws AppException,
      InformationalException {

    Reservation reservation = reservationDAO.get(
      reservationConfirmDetails.reservationID);
    Place place = validatePlaceID(reservationConfirmDetails.placeID);

    // BEGIN, CR00131554, GYH
    reservation.confirmPlacement(place,
      new DateTimeRange(reservationConfirmDetails.from,
      reservationConfirmDetails.to),
      reservationConfirmDetails.versionNo,
      reservationConfirmDetails.updateOverlappingPlacementPeriodInd,
      reservationConfirmDetails.cancelExistingReservations,
      reservationConfirmDetails.comments);
    // END, CR00131554

  }

  /**
   * Gets the location of the compartment and concatenates it.
   *
   * @param parentCompartment
   * Compartment contains parent Compartment ID.
   * @param location
   * Contains the location of the place.
   * @return String location of the place after concatenate all the related
   * locations.
   */
  protected String buildLocation(Compartment parentCompartment, String location) {
    if (parentCompartment != null) {
      Compartment currentCompartment = compartmentDAO.get(
        parentCompartment.getID());

      location = buildLocation(currentCompartment.getParentCompartment(),
        location);
      location += currentCompartment.getName() + CPMConstants.kGreaterThan;
    }
    return location;
  }

  /**
   * Sorts a set of Reservations in the ascending order of from date of
   * Reservation.
   *
   * @param unsortedReservations
   * The set of unsorted Reservations.
   * @return ReservationSearchDetailsList contains a list of Reservations sorted
   * by from date in Ascending order.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  protected ReservationSearchDetailsList sortReservations(
    ReservationSearchDetailsList unsortedReservations) {

    List<ReservationSearchDetails> searchReservationDetailsList = new ArrayList<ReservationSearchDetails>();
    int countOfUnsortedReservations = unsortedReservations.searchList.size();

    for (int i = 0; i < countOfUnsortedReservations; i++) {
      searchReservationDetailsList.add(unsortedReservations.searchList.item(i));
    }

    // Sort the unsorted reservations
    Collections.sort(searchReservationDetailsList,
      new Comparator<ReservationSearchDetails>() {
      public int compare(final ReservationSearchDetails lhs,
        ReservationSearchDetails rhs) {
        return lhs.from.compareTo(rhs.from);
      }
    });

    ReservationSearchDetailsList searchReservationDetailsListSorted = new ReservationSearchDetailsList();

    searchReservationDetailsListSorted.searchList.addAll(
      searchReservationDetailsList);

    return searchReservationDetailsListSorted;
  }

  /**
   * Sorts a set of Reservations in the ascending order of from date of
   * Reservation.
   *
   * @param unsortedReservations
   * The set of unsorted Reservations.
   * @return ReservationSummaryDetailsList contains a list of Reservations
   * sorted by from date in Ascending order.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  protected ReservationSummaryDetailsList sortListReservations(
    ReservationSummaryDetailsList unsortedReservations) {

    List<ReservationSummaryDetails> ReservationSummaryDetailsList = new ArrayList<ReservationSummaryDetails>();
    int countOfUnsortedReservations = unsortedReservations.summaryList.size();

    for (int i = 0; i < countOfUnsortedReservations; i++) {
      ReservationSummaryDetailsList.add(
        unsortedReservations.summaryList.item(i));
    }

    // Sort the unsorted reservations
    Collections.sort(ReservationSummaryDetailsList,
      new Comparator<ReservationSummaryDetails>() {
      public int compare(final ReservationSummaryDetails lhs,
        ReservationSummaryDetails rhs) {
        return lhs.from.compareTo(rhs.from);
      }
    });

    ReservationSummaryDetailsList ReservationDetailsListSorted = new ReservationSummaryDetailsList();

    ReservationDetailsListSorted.summaryList.addAll(
      ReservationSummaryDetailsList);

    return ReservationDetailsListSorted;
  }
  
  // BEGIN, CR00205476, GP
  /**
   * Sorts a set of Reservations in the ascending order of from date of
   * Reservation.
   *
   * @param unsortedReservations
   * The set of unsorted Reservations.
   *
   * @return List of Reservations sorted by from date in Ascending order.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  protected ReservationViewDetailsList sortReservations(
    ReservationViewDetailsList unsortedReservations) {

    List<ReservationViewDetails> reservationViewDetailsList = new ArrayList<ReservationViewDetails>();

    for (ReservationViewDetails reservationViewDetails : unsortedReservations.reservationViewDetails.items()) {
      
      reservationViewDetailsList.add(reservationViewDetails);
    }

    Collections.sort(reservationViewDetailsList,
      new Comparator<ReservationViewDetails>() {
      public int compare(final ReservationViewDetails lhs,
        ReservationViewDetails rhs) {
        return lhs.from.compareTo(rhs.from);
      }
    });

    ReservationViewDetailsList reservationDetailsListSorted = new ReservationViewDetailsList();

    reservationDetailsListSorted.reservationViewDetails.addAll(
      reservationViewDetailsList);

    return reservationDetailsListSorted;
  }

  // END, CR00205476
  
  /**
   * Returns the Reservation details like client name, from Date, to Date and
   * status.
   *
   * @param reservation
   * Contains reservation details retrieved from DAO.
   * @return ReservationSearchDetails Contains the reservation details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ReservationSearchDetails getReservationSearchFields(
    Reservation reservation) throws AppException, InformationalException {

    ReservationSearchDetails reservationSearchDetails = new ReservationSearchDetails();

    reservationSearchDetails.clientName = reservation.getClient().getName();
    reservationSearchDetails.clientID = reservation.getClient().getID();
    reservationSearchDetails.clientType = reservation.getClient().getConcernRoleType().getCode();
    reservationSearchDetails.from = reservation.getDateTimeRange().start();
    reservationSearchDetails.to = reservation.getDateTimeRange().end();
    if (reservation.getPlace() != null) {
      reservationSearchDetails.placeName = reservation.getPlace().getName();
    }
    reservationSearchDetails.status = reservation.getLifecycleState().getCode();
    reservationSearchDetails.reservationID = reservation.getID();
    reservationSearchDetails.versionNo = reservation.getVersionNo();

    return reservationSearchDetails;
  }

  /**
   * Gets the reservation details into the facade struct from the entity object.
   *
   * @param reservation
   * The reservation entity.
   * @return ReservationViewSummaryDetails the facade struct with reservation
   * details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ReservationViewSummaryDetails getReservationFields(
    Reservation reservation) throws AppException, InformationalException {

    ReservationViewSummaryDetails details = new ReservationViewSummaryDetails();

    details.clientName = reservation.getClient().getName();
    details.serviceOfferingName = reservation.getProviderOffering().getServiceOffering().getName();
    
    details.from = reservation.getDateTimeRange().start();
    
    details.to = reservation.getDateTimeRange().end();
    details.dateOfExpiry = reservation.getExpiryDateTime();
    if (reservation.getPlace() != null) {
      details.placeID = reservation.getPlace().getID();
      details.placeName = reservation.getPlace().getName();
      PlaceKey placeKey = new PlaceKey();

      placeKey.placeID = details.placeID;
      details.placeLocation = getLocationForPlace(placeKey).location;
    }

    details.Status = reservation.getLifecycleState().toString();
    details.comments = reservation.getComments();
    details.reservationID = reservation.getID();
    details.versionNo = reservation.getVersionNo();

    return details;
  }
  
  // BEGIN, CR00186599, SSK
  /**
   * {@inheritDoc}
   */
  public ReservationSearchDetailsList searchByReservationStatusProviderAndClient(
    final ReservationClientIDAndProviderStatusSearchCriteria reservationClientIDAndProviderStatusSearchCriteria)
    throws AppException, InformationalException {

    final ConcernRoleID clientConcernRoleID = new ConcernRoleID();

    clientConcernRoleID.concernRoleID = reservationClientIDAndProviderStatusSearchCriteria.clientID;
    String status = reservationClientIDAndProviderStatusSearchCriteria.status.trim();

    // Exception is specific to screen when criteria is not entered
    if (CPMConstants.kZeroLong == clientConcernRoleID.concernRoleID
      && CPMConstants.kZeroLong == status.length()
      && reservationClientIDAndProviderStatusSearchCriteria.fromDate.isZero()
      && reservationClientIDAndProviderStatusSearchCriteria.toDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        RESERVATIONExceptionCreator.ERR_RESERVATION_FV_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Exception is specific to screen when From date is later than To date
    if (reservationClientIDAndProviderStatusSearchCriteria.fromDate != null
      && reservationClientIDAndProviderStatusSearchCriteria.toDate != null) {
      
      if (!reservationClientIDAndProviderStatusSearchCriteria.fromDate.isZero()
        && !reservationClientIDAndProviderStatusSearchCriteria.toDate.isZero()
        && reservationClientIDAndProviderStatusSearchCriteria.fromDate.after(
          reservationClientIDAndProviderStatusSearchCriteria.toDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          RESERVATIONExceptionCreator.ERR_RESERVATION_XRV_FROM_DATE_TIME_LATER_THAN_TO_DATE_TIME(
            reservationClientIDAndProviderStatusSearchCriteria.fromDate,
            reservationClientIDAndProviderStatusSearchCriteria.toDate),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
    
    // Exception is specific to screen when To date and From date is not entered
    if ((reservationClientIDAndProviderStatusSearchCriteria.fromDate == null
      || reservationClientIDAndProviderStatusSearchCriteria.fromDate.isZero())
        && (reservationClientIDAndProviderStatusSearchCriteria.toDate != null
          && !reservationClientIDAndProviderStatusSearchCriteria.toDate.isZero())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        RESERVATIONExceptionCreator.ERR_RESERVATION_FV_FROMDATE_MANDATORY_IF_TODATE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    ValidationHelper.failIfErrorsExist();

    ReservationSearchDetailsList reservationSearchDetailsList = new ReservationSearchDetailsList();
    RESERVATIONSTATUSEntry reservationStatusEntry = RESERVATIONSTATUSEntry.get(
      reservationClientIDAndProviderStatusSearchCriteria.status);

    final ConcernRole concernRole = concernRoleDAO.get(
      reservationClientIDAndProviderStatusSearchCriteria.providerConcernRoleID);

    final List<Reservation> reservations = reservationDAO.searchByReservationStatusProviderAndClient(
      reservationStatusEntry, clientConcernRoleID, concernRole);

    DateTimeRange dateTimeRange = null;

    if (!reservationClientIDAndProviderStatusSearchCriteria.fromDate.equals(
      DateTime.kZeroDateTime)) {

      dateTimeRange = new DateTimeRange(
        reservationClientIDAndProviderStatusSearchCriteria.fromDate,
        reservationClientIDAndProviderStatusSearchCriteria.toDate);
    }

    for (final Reservation reservation : reservations) {
      if (dateTimeRange != null) {
        if (dateTimeRange.overlapsWith(reservation.getDateTimeRange())) {
          reservationSearchDetailsList.searchList.addRef(
            getReservationSearchFields(reservation));
        }
      } else {
        reservationSearchDetailsList.searchList.addRef(
          getReservationSearchFields(reservation));
      }

    }
    
    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(
      reservationSearchDetailsList.informationalMsgDtlsOpt);
    // END, CR00292696
    
    return sortReservations(reservationSearchDetailsList);
  }

  // END, CR00186599

  // BEGIN, CR00236455, SSK
  /**
   * Retrieves the reservation period.
   *
   * @param reservationPeriodDetails
   * Contains reservation details.
   *
   * @return Retrieves the reservation period details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReservationPeriodDetails retrieveReservationPeriod(
    final ReservationPeriodDetails reservationPeriodDetails)
    throws AppException, InformationalException {

    return reservationPeriodDetails;
  }
  
  // END, CR00236455

  // BEGIN, CR00293856, IBM
  /**
   * {@inheritDoc}
   */
  public ReservationVerifyDetails verifyReservation(
    final ReservationConfirmDetails reservationConfirmDetails)
    throws AppException, InformationalException {

    Placement placement = placementDAO.newInstance();
    Reservation reservation = reservationDAO.get(
      reservationConfirmDetails.reservationID);

    providerSecurity.checkProviderSecurity(
      reservation.getProviderOffering().getProvider());

    DateTimeRange placementPeriod = new DateTimeRange(
      reservationConfirmDetails.from, reservationConfirmDetails.to);

    Place placeObj = placeDAO.get(reservationConfirmDetails.placeID);

    List<Reservation> activeReservations = reservationDAO.searchOverlappingActiveReservationsForPlace(
      placeObj, placementPeriod);

    if (0 != activeReservations.size()) {
      for (Reservation activeReservation : activeReservations) {
        if (activeReservation.getID() != reservation.getID().longValue()) {
          reservationConfirmDetails.activeReservationDtls.activeReservationExistsInd = true;
        }
      }
    }

    Placement overlappingPlacement = placement.getOverlappingPlacementForClient(
      reservation.getCaseParticipantRoleID(),
      new DateTimeRange(reservationConfirmDetails.from,
      reservationConfirmDetails.to));

    if (null != overlappingPlacement) {
      reservationConfirmDetails.updateOverlappingPlacementPeriodInd = true;
    }

    // If there are no overlapping placements, then confirm the reservation
    if (!reservationConfirmDetails.updateOverlappingPlacementPeriodInd
      && !reservationConfirmDetails.activeReservationDtls.activeReservationExistsInd) {
      confirmReservationASPlacement(reservationConfirmDetails);
    }
    List<Reservation> overlappingReservations = reservationDAO.searchOverlappingReservationsForClient(
      reservation, reservation.getDateTimeRange());

    if (0 != overlappingReservations.size()) {
      reservationConfirmDetails.cancelExistingReservations = true;
    }

    ReservationVerifyDetails reservationVerifyDetails = new ReservationVerifyDetails();

    reservationVerifyDetails.cancelExistingReservations = reservationConfirmDetails.cancelExistingReservations;
    reservationVerifyDetails.updateOverlappingPlacementPeriodInd = reservationConfirmDetails.updateOverlappingPlacementPeriodInd;
    reservationVerifyDetails.reservationID = reservationConfirmDetails.reservationID;
    reservationVerifyDetails.placeID = reservationConfirmDetails.placeID;
    reservationVerifyDetails.versionNo = reservationConfirmDetails.versionNo;
    reservationVerifyDetails.from = reservationConfirmDetails.from;
    reservationVerifyDetails.to = reservationConfirmDetails.to;
    reservationVerifyDetails.concernRoleID = reservationConfirmDetails.concernRoleID;
    reservationVerifyDetails.comments = reservationConfirmDetails.comments;
    reservationVerifyDetails.activeReservationDtls = reservationConfirmDetails.activeReservationDtls;

    collectInformationalMsgs(reservationVerifyDetails.informationalMsgDtls);

    return reservationVerifyDetails;
  }

  /**
   * Confirms the placement and modifies the overlapping placement period.
   *
   * @param reservationConfirmDetails
   * Confirm reservation details.
   *
   * @return ReservationConfirmDetails Confirm reservation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReservationVerifyDetails confirmUpdatedPlacement(
    final ReservationConfirmDetails reservationConfirmDetails)
    throws AppException, InformationalException {

    boolean confirmCancelOverlappingReservation = false;

    if (reservationConfirmDetails.cancelExistingReservations) {
      confirmCancelOverlappingReservation = true;
    }

    reservationConfirmDetails.cancelExistingReservations = false;

    confirmReservationASPlacement(reservationConfirmDetails);

    reservationConfirmDetails.cancelExistingReservations = confirmCancelOverlappingReservation;

    ReservationVerifyDetails reservationVerifyDetails = new ReservationVerifyDetails();

    reservationVerifyDetails.cancelExistingReservations = reservationConfirmDetails.cancelExistingReservations;
    reservationVerifyDetails.updateOverlappingPlacementPeriodInd = reservationConfirmDetails.updateOverlappingPlacementPeriodInd;
    reservationVerifyDetails.reservationID = reservationConfirmDetails.reservationID;
    reservationVerifyDetails.placeID = reservationConfirmDetails.placeID;
    reservationVerifyDetails.versionNo = reservationConfirmDetails.versionNo;
    reservationVerifyDetails.from = reservationConfirmDetails.from;
    reservationVerifyDetails.to = reservationConfirmDetails.to;
    reservationVerifyDetails.concernRoleID = reservationConfirmDetails.concernRoleID;
    reservationVerifyDetails.comments = reservationConfirmDetails.comments;
    reservationVerifyDetails.activeReservationDtls = reservationConfirmDetails.activeReservationDtls;

    collectInformationalMsgs(reservationVerifyDetails.informationalMsgDtls);

    return reservationVerifyDetails;
  }

  /**
   * {@inheritDoc}
   */
  public PlaceAndPlaceLocationDetailsList getAvailablePlacesForReservation(
    final ReservationPeriodKey reservationPeriodKey) throws AppException,
      InformationalException {

    PlaceAndPlaceLocationDetailsList placeLocationList = new PlaceAndPlaceLocationDetailsList();

    Reservation reservation = reservationDAO.get(
      reservationPeriodKey.reservationID);

    Set<Place> availablePlaces = reservation.getPlaceAvailableInDateRange(
      reservation.getProvider(), reservation.getDateTimeRange());

    placeLocationList.placeIndicator = CuramConst.gkZero;
    int placeCount = availablePlaces.size();
    PlaceKey placeKey;

    for (final Place place : availablePlaces) {

      placeKey = new PlaceKey();

      PlaceAndPlaceLocation placeAndLocation = new PlaceAndPlaceLocation();

      placeKey.placeID = place.getID();

      PlaceLocationDetails placeLocationDetails = place.getLocationForPlace();

      placeAndLocation.placeLocation = placeLocationDetails.location;

      placeAndLocation.placeName = place.getName();

      placeAndLocation.placeID = place.getID();

      placeLocationList.place.addRef(placeAndLocation);
    }

    if (placeCount > CuramConst.gkZero) {
      placeLocationList.placeIndicator = placeCount;
    }

    collectInformationalMsgs(placeLocationList.informationalMsgDtls);

    return placeLocationList;
  }

  // END, CR00293856

  // BEGIN, CR00292696, IBM
  /**
   * Collects the list of informations from the informational manager and adds
   * them to the list parameter passed in.
   *
   * @param informationalMsgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList informationalMsgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }
  // END, CR00292696


}
