/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.sl.impl;


import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.intf.ParticipantSearch;
import curam.util.resources.Configuration;


/**
 * Provides methods which will route participant searches to the appropriate
 * search engine based on environment settings. This class is the overridden
 * class from the core class
 * {@linkplain curam.core.sl.impl.ParticipantSearchRouter
 * ParticipantSearchRouter}.
 *
 */
public class ParticipantSearchRouter extends curam.core.sl.impl.ParticipantSearchRouter {

  /**
   * Checks if the lucene environmental variable is enabled to determine if
   * the search will be a database or lucene index search.
   *
   * @param participantRoleType
   * Contains participant role type. Ex: Person, Employer, Provider
   * etc.
   *
   * @return Participant search object that is either lucene index search
   * object or database search object.
   */
  @Override
  protected ParticipantSearch getParticipantSearchObj(
    final String participantRoleType) {

    boolean luceneSearchEnabledInd = false;

    if (CONCERNROLETYPEEntry.PERSON.getCode().equals(participantRoleType)) {
      luceneSearchEnabledInd = Configuration.getBooleanProperty(
        EnvVars.ENV_LUCENE_ENHANCED_PERSON_SEARCH_ENABLED);
    } else if (CONCERNROLETYPEEntry.EMPLOYER.getCode().equals(
      participantRoleType)) {
      luceneSearchEnabledInd = Configuration.getBooleanProperty(
        EnvVars.ENV_LUCENE_ENHANCED_EMPLOYER_SEARCH_ENABLED);
    } else if (CONCERNROLETYPEEntry.EXTERNALPARTY.getCode().equals(
      participantRoleType)) {
      luceneSearchEnabledInd = Configuration.getBooleanProperty(
        EnvVars.ENV_LUCENE_ENHANCED_EXTERNAL_PARTY_SEARCH_ENABLED);
    } else if (CONCERNROLETYPEEntry.INFORMATIONPROVIDER.getCode().equals(
      participantRoleType)) {
      luceneSearchEnabledInd = Configuration.getBooleanProperty(
        EnvVars.ENV_LUCENE_ENHANCED_INFORMATION_PROVIDER_SEARCH_ENABLED);
    } else if (CONCERNROLETYPEEntry.PRODUCTPROVIDER.getCode().equals(
      participantRoleType)) {
      luceneSearchEnabledInd = Configuration.getBooleanProperty(
        EnvVars.ENV_LUCENE_ENHANCED_PRODUCT_PROVIDER_SEARCH_ENABLED);
    } else if (CONCERNROLETYPEEntry.SERVICESUPPLIER.getCode().equals(
      participantRoleType)) {
      luceneSearchEnabledInd = Configuration.getBooleanProperty(
        EnvVars.ENV_LUCENE_ENHANCED_SERVICE_SUPPLIER_SEARCH_ENABLED);
    } else if (CONCERNROLETYPEEntry.UTILITY.getCode().equals(
      participantRoleType)) {
      luceneSearchEnabledInd = Configuration.getBooleanProperty(
        EnvVars.ENV_LUCENE_ENHANCED_UTILITY_SEARCH_ENABLED);
    } else if (CONCERNROLETYPEEntry.PROVIDER.getCode().equals(
      participantRoleType)) {
      luceneSearchEnabledInd = Configuration.getBooleanProperty(
        EnvVars.ENV_PARTICIPANT_PROVIDER_SEARCH_ENABLED);
    } else if (CONCERNROLETYPEEntry.PROVIDERGROUP.getCode().equals(
      participantRoleType)) {
      luceneSearchEnabledInd = Configuration.getBooleanProperty(
        EnvVars.ENV_PARTICIPANT_PROVIDER_GROUP_SEARCH_ENABLED);
    } else if (CuramConst.gkEmpty.equals(participantRoleType)) {
      luceneSearchEnabledInd = Configuration.getBooleanProperty(
        EnvVars.ENV_LUCENE_ENHANCED_ALL_PARTICIPANT_SEARCH_ENABLED);
    }

    luceneSearchEnabledInd = luceneSearchEnabledInd
      && Configuration.getBooleanProperty(
        EnvVars.ENV_LUCENE_ENHANCED_SEARCH_ENABLED);

    ParticipantSearch participantSearchObj;

    if (luceneSearchEnabledInd) {
      participantSearchObj = new IndexParticipantSearch();
    } else {
      participantSearchObj = new DatabaseParticipantSearch();
    }
    return participantSearchObj;
  }
}
