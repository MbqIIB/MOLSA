/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.ProviderSpecialtyDetailsList;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ProviderSpecialtyDtls;
import curam.cpm.sl.entity.struct.ProviderSpecialtyKey;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderSpecialtyDAO;
import curam.provider.impl.ProviderSpecialtyTypeEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.DateRange;


/**
 * Facade layer class for the maintenance of Provider Specialty. Provider
 * Specialty means, the areas in which a provider has particular experience or
 * expertise. Provider Specialty can be used in conjunction with the services
 * desired to match to an appropriate provider.
 */

public abstract class ProviderSpecialty extends curam.cpm.facade.base.ProviderSpecialty {

  /**
   * Injecting the Data Access Object for Provider Specialty
   */
  @Inject
  protected ProviderSpecialtyDAO providerSpecialtyDAO;

  /**
   * Injecting the Data Access Object for Provider
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Constructor
   */
  public ProviderSpecialty() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * Creates a specialty for a provider. Specialty may include things like
   * Languages Spoken, Method of Payment Accepted etc.
   *
   * @param providerSpecialtyDtls
   * The details for the Provider Specialty to be created.
   *
   * @return ProviderSpecialtyKey the key for the new ProviderSpecialty created.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderSpecialtyKey createSpecialty(
    ProviderSpecialtyDtls providerSpecialtyDtls) throws AppException,
      InformationalException {

    // check if the user has appropriate privileges
    checkSecurityPrivileges();

    curam.provider.impl.ProviderSpecialty providerSpecialty = providerSpecialtyDAO.newInstance();

    // map details passed from client
    setProviderSpecialtyFields(providerSpecialty, providerSpecialtyDtls);

    providerSpecialty.insert();

    ProviderSpecialtyKey providerSpecialtyKey = new ProviderSpecialtyKey();

    providerSpecialtyKey.providerSpecialtyID = providerSpecialty.getID();
    return providerSpecialtyKey;
  }

  /**
   * Modifies a Specialty for a provider.
   *
   * @param providerSpecialtyDtls
   * The details for the Provider Specialty to be modified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifySpecialty(ProviderSpecialtyDtls providerSpecialtyDtls)
    throws AppException, InformationalException {

    // check if the user has appropriate privileges
    checkSecurityPrivileges();

    final curam.provider.impl.ProviderSpecialty providerSpecialty = providerSpecialtyDAO.get(
      providerSpecialtyDtls.providerSpecialtyID);

    setProviderSpecialtyFields(providerSpecialty, providerSpecialtyDtls);

    providerSpecialty.modify(providerSpecialtyDtls.versionNo);

  }

  /**
   * Reads the details of a specialty for a provider.
   *
   * @param providerSpecialtyKey
   * The key for the Provider Specialty.
   *
   * @return ProviderSpecialtyDtls The Provider Specialty Details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderSpecialtyDtls viewSpecialty(
    ProviderSpecialtyKey providerSpecialtyKey) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderSpecialty providerSpecialty = providerSpecialtyDAO.get(
      providerSpecialtyKey.providerSpecialtyID);

    ProviderSpecialtyDtls providerSpecialtyDtls = getProviderSpecialtyFields(
      providerSpecialty);

    return providerSpecialtyDtls;
  }

  /**
   * Lists all specialties that have been created for the provider.
   *
   * @param providerKey
   * The Key for the Provider for whom the specialties are to be
   * retrieved.
   *
   * @return ProviderSpecialtyDetailsList The Provider specialty list for a
   * given provider.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderSpecialtyDetailsList listProviderSpecialties(
    ProviderKey providerKey) throws AppException, InformationalException {
    ProviderSpecialtyDetailsList providerSpecialtyDetailsList = new ProviderSpecialtyDetailsList();
    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);
    ProviderSpecialtyDtls providerSpecialtyDtls;

    // sort the provider specialty set and iterate
    Set<curam.provider.impl.ProviderSpecialty> unModifiableProviderSpecialties = provider.getProviderSpecialties();
    Set<curam.provider.impl.ProviderSpecialty> providerSpecialties = new HashSet<curam.provider.impl.ProviderSpecialty>();

    providerSpecialties.addAll(unModifiableProviderSpecialties);

    for (final curam.provider.impl.ProviderSpecialty providerSpecialty : sortProviderSpecialties(
      providerSpecialties)) {
      providerSpecialtyDtls = new ProviderSpecialtyDtls();

      providerSpecialtyDtls.providerSpecialtyID = providerSpecialty.getID();
      providerSpecialtyDtls.startDate = providerSpecialty.getDateRange().start();
      providerSpecialtyDtls.endDate = providerSpecialty.getDateRange().end();
      providerSpecialtyDtls.specialty = providerSpecialty.getSpecialty().getCode();
      providerSpecialtyDtls.recordStatus = providerSpecialty.getLifecycleState().getCode();
      // BEGIN, CR00208581, AS
      providerSpecialtyDtls.versionNo = providerSpecialty.getVersionNo();
      // END, CR00208581
      providerSpecialtyDetailsList.providerSpecialtyDtls.addRef(
        providerSpecialtyDtls);
    }

    return providerSpecialtyDetailsList;
  }

  /**
   * Deletes a Provider Specialty.
   *
   * @param keyVersionDetails
   * The id and version of the entity to be logically deleted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancelSpecialty(KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    // check if the user has appropriate privileges
    checkSecurityPrivileges();

    final curam.provider.impl.ProviderSpecialty providerSpecialty = providerSpecialtyDAO.get(
      keyVersionDetails.id);

    providerSpecialty.cancel(keyVersionDetails.version);

  }

  /**
   * Maps the fields updateable by the user to the fields on the service layer
   * object.
   *
   * @param providerSpecialty
   * the service layer object into which the user-updateable fields
   * must be mapped.
   * @param providerSpecialtyDtls
   * Contains provider specialty field details set by the user (as well
   * as other fields which will be ignored).
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setProviderSpecialtyFields(
    // END, CR00177241
    final curam.provider.impl.ProviderSpecialty providerSpecialty,
    final ProviderSpecialtyDtls providerSpecialtyDtls) throws AppException,
      InformationalException {

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerSpecialtyDtls.providerConcernRoleID);

    providerSpecialty.setProvider(provider);
    providerSpecialty.setComments(providerSpecialtyDtls.comments);

    final DateRange dateRange = new DateRange(providerSpecialtyDtls.startDate,
      providerSpecialtyDtls.endDate);

    providerSpecialty.setDateRange(dateRange);

    providerSpecialty.setSpecialty(
      ProviderSpecialtyTypeEntry.get(providerSpecialtyDtls.specialty));

  }

  /**
   * Maps the fields on the service layer to those presented to the user on the
   * screen.
   *
   * @param providerSpecialty
   * the service layer object from which the user-displayable fields
   * must be mapped.
   *
   * @return ProviderSpecialtyDtls Contain the details of fields for display.
   */
  // BEGIN, CR00177241, PM
  protected ProviderSpecialtyDtls getProviderSpecialtyFields(
    // END, CR00177241
    final curam.provider.impl.ProviderSpecialty providerSpecialty) {
    final ProviderSpecialtyDtls providerSpecialtyDtls = new ProviderSpecialtyDtls();

    providerSpecialtyDtls.providerSpecialtyID = providerSpecialty.getID();
    providerSpecialtyDtls.providerConcernRoleID = providerSpecialty.getProvider().getID();
    providerSpecialtyDtls.startDate = providerSpecialty.getDateRange().start();
    providerSpecialtyDtls.endDate = providerSpecialty.getDateRange().end();
    providerSpecialtyDtls.specialty = providerSpecialty.getSpecialty().getCode();
    providerSpecialtyDtls.comments = providerSpecialty.getComments();
    providerSpecialtyDtls.recordStatus = providerSpecialty.getLifecycleState().getCode();
    providerSpecialtyDtls.versionNo = providerSpecialty.getVersionNo();

    return providerSpecialtyDtls;
  }

  /**
   * Sorts a set of provider specialties into a sorted list.
   *
   * @param unsortedProviderSpecialties
   * the unsorted set of provider specialties.
   * @return a sorted list of provider specialties.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.provider.impl.ProviderSpecialty> sortProviderSpecialties(
    // END, CR00177241
    final Set<curam.provider.impl.ProviderSpecialty> unsortedProviderSpecialties) {

    // sort by Start Date and later by name
    final List<curam.provider.impl.ProviderSpecialty> providerSpecialties = new ArrayList<curam.provider.impl.ProviderSpecialty>(
      unsortedProviderSpecialties);

    Collections.sort(providerSpecialties,
      new Comparator<curam.provider.impl.ProviderSpecialty>() {
      public int compare(final curam.provider.impl.ProviderSpecialty lhs,
        curam.provider.impl.ProviderSpecialty rhs) {
        return rhs.getDateRange().start().compareTo(lhs.getDateRange().start());
      }
    });

    return providerSpecialties;
  }

  /**
   * This method checks security privileges of the user, whether the user has
   * enough privileges to modify/create the record.
   */
  // BEGIN, CR00177241, PM
  protected void checkSecurityPrivileges() {// END, CR00177241
    // get user
    // curam.core.intf.SystemUser systemUser = SystemUserFactory.newInstance();
    // check if the user is a part of resource manager organizational object
    // if not, throw a validation error
    /*
     * ValidationHelper.addValidationError(
     * CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_USER_MUST_BE_MEMBER_OF_RESOURCE_MANAGER_ORGANIZATIONAL_OBJECT(
     * systemUser.getUserDetails().userName,"Resource Manager Object"));
     */}

}
