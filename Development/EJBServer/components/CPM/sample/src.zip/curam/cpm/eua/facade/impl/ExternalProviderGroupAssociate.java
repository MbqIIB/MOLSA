/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.facade.fact.MaintainProviderGroupAssociatePaymentConfigurationFactory;
import curam.cpm.facade.fact.ProviderGroupAssociateFactory;
import curam.cpm.facade.intf.MaintainProviderGroupAssociatePaymentConfiguration;
import curam.cpm.facade.struct.PGAssociatePaymentConfigDetailsList;
import curam.cpm.facade.struct.ProviderGroupAssociateSummaryDetails;
import curam.cpm.facade.struct.ProviderGroupAssociateSummaryInformationDetails;
import curam.cpm.facade.struct.ViewPGAssociatePaymentConfigKey;
import curam.cpm.sl.entity.struct.ProviderGroupAssociateKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for the External Provider Group
 * Associate facade layer
 */

public abstract class ExternalProviderGroupAssociate extends curam.cpm.eua.facade.base.ExternalProviderGroupAssociate {

  /**
   * View details for provider group associate
   *
   * @param providerGroupAssociateKey
   * - contains the provider group associate ID
   * @return This contains the details for the provider group associate.
   *
   * @throws InformationalException
   *
   * @throws AppException
   */
  public ProviderGroupAssociateSummaryDetails viewProviderGroupAssociate(
    ProviderGroupAssociateKey providerGroupAssociateKey) throws AppException,
      InformationalException {

    // Create instance of provider group associate facade
    curam.cpm.facade.intf.ProviderGroupAssociate providerGroupAssociateObj = ProviderGroupAssociateFactory.newInstance();

    ProviderGroupAssociateSummaryDetails providerGroupAssociateSummaryDetails = new ProviderGroupAssociateSummaryDetails();

    // invoke facade layer method
    ProviderGroupAssociateSummaryInformationDetails summaryDetails = providerGroupAssociateObj.viewProviderGroupAssociateDetails(
      providerGroupAssociateKey);

    // call security check
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey.concernRoleID = summaryDetails.providerConcernRoleID;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    // assign the struct values
    providerGroupAssociateSummaryDetails = assignProviderGroupAssociateSummaryDetails(
      summaryDetails);

    // this will throw error if user does not have access.
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    return providerGroupAssociateSummaryDetails;
  }

  // BEGIN, CR00228977, GP
  /**
   * Lists the provider group payment configurations.
   *
   * @param providerGroupAssociateKey
   * Contains provider group associate ID.
   *
   * @return A list of provider group payment configurations.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public PGAssociatePaymentConfigDetailsList listProviderGroupPaymentConfiguration(
    final ProviderGroupAssociateKey providerGroupAssociateKey)
    throws AppException, InformationalException {

    viewProviderGroupAssociate(providerGroupAssociateKey);

    MaintainProviderGroupAssociatePaymentConfiguration MaintainProviderGroupAssociatePaymentConfigurationObj = MaintainProviderGroupAssociatePaymentConfigurationFactory.newInstance();

    ViewPGAssociatePaymentConfigKey viewPGAssociatePaymentConfigKey = new ViewPGAssociatePaymentConfigKey();

    viewPGAssociatePaymentConfigKey.providerGroupAssociateID = providerGroupAssociateKey.providerGroupAssociateID;
    return MaintainProviderGroupAssociatePaymentConfigurationObj.listPGAPaymentConfiguration(
      viewPGAssociatePaymentConfigKey);
  }

  // END, CR00228977

  /**
   * Assigns provider group associate details.
   *
   * @param providerGroupAssociateSummaryInformationDetails
   * contains the provider group associate details.
   *
   * @return The provider group associate details.
   */
  protected ProviderGroupAssociateSummaryDetails assignProviderGroupAssociateSummaryDetails(
    ProviderGroupAssociateSummaryInformationDetails providerGroupAssociateSummaryInformationDetails) {
    ProviderGroupAssociateSummaryDetails providerGroupAssociateSummaryDetails = new ProviderGroupAssociateSummaryDetails();

    providerGroupAssociateSummaryDetails.providerGroupAssociateID = providerGroupAssociateSummaryInformationDetails.providerGroupAssociateID;
    providerGroupAssociateSummaryDetails.providerConcernRoleID = providerGroupAssociateSummaryInformationDetails.providerConcernRoleID;
    providerGroupAssociateSummaryDetails.providerGroupConcernRoleID = providerGroupAssociateSummaryInformationDetails.providerGroupConcernRoleID;
    providerGroupAssociateSummaryDetails.providerName = providerGroupAssociateSummaryInformationDetails.providerName;

    providerGroupAssociateSummaryDetails.recordStatus = providerGroupAssociateSummaryInformationDetails.recordStatus;

    providerGroupAssociateSummaryDetails.comments = providerGroupAssociateSummaryInformationDetails.comments;
    providerGroupAssociateSummaryDetails.contractedAssociateInd = providerGroupAssociateSummaryInformationDetails.contractedAssociateInd;
    providerGroupAssociateSummaryDetails.groupToReceivePayments = providerGroupAssociateSummaryInformationDetails.groupToReceivePayments;

    providerGroupAssociateSummaryDetails.endDate = providerGroupAssociateSummaryInformationDetails.endDate;
    providerGroupAssociateSummaryDetails.startDate = providerGroupAssociateSummaryInformationDetails.startDate;
    providerGroupAssociateSummaryDetails.versionNo = providerGroupAssociateSummaryInformationDetails.versionNo;

    return providerGroupAssociateSummaryDetails;

  }

}
