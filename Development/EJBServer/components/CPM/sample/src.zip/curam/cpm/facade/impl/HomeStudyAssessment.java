/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 - 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.cpm.facade.fact.ContextDescriptionFactory;
import curam.cpm.facade.struct.ContextDescriptionDetails;
import curam.cpm.facade.struct.HomeStudyAssessmentCancelKey;
import curam.cpm.facade.struct.HomeStudyAssessmentDtls;
import curam.cpm.facade.struct.HomeStudyAssessmentDtlsList;
import curam.cpm.facade.struct.HomeStudyAssessmentKey;
import curam.cpm.facade.struct.HomeStudyAssessmentListByHomeStudyKey;
import curam.cpm.facade.struct.ProviderKey;
import curam.homestudy.impl.HomeStudy;
import curam.homestudy.impl.HomeStudyAssessmentDAO;
import curam.homestudy.impl.HomeStudyAssessmentResultEntry;
import curam.homestudy.impl.HomeStudyAssessmentTypeEntry;
import curam.homestudy.impl.HomeStudyDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This process class provides the functionality for home study assessment
 * facade layer.
 */
public abstract class HomeStudyAssessment extends curam.cpm.facade.base.HomeStudyAssessment {

  @Inject
  protected HomeStudyAssessmentDAO homeStudyAssessmentDAO;

  @Inject
  protected HomeStudyDAO homeStudyDAO;

  /**
   * Constructor
   */
  public HomeStudyAssessment() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Returns a list of home study assessments for a parent home study.
   *
   * @param key
   * the key specifying the home study to list by
   * @return struct containing a list of home study assessment details and the
   * context description.
   * @throws InformationalException
   * @throws AppException
   */
  public HomeStudyAssessmentDtlsList listByHomeStudy(
    HomeStudyAssessmentListByHomeStudyKey key) throws AppException,
      InformationalException {

    HomeStudyAssessmentDtlsList homeStudyAssessmentDtlsList = new HomeStudyAssessmentDtlsList();

    // Read the provider to search by
    HomeStudy homeStudy = homeStudyDAO.get(
      key.homeStudyAssessmentKey.homeStudyID);

    // Call the search method
    Set<curam.homestudy.impl.HomeStudyAssessment> homeStudyAssessmentSet = homeStudyAssessmentDAO.searchByHomeStudy(
      homeStudy);

    // convert to HomeStudyDetailsList for return to client
    for (curam.homestudy.impl.HomeStudyAssessment homeStudyAssessment : sortRequests(
      homeStudyAssessmentSet)) {
      HomeStudyAssessmentDtls homeStudyAssessmentDetails = setHomeStudyAssessmentDetails(
        homeStudyAssessment);

      homeStudyAssessmentDtlsList.homeStudyAssessmentDtlsList.dtls.addRef(
        homeStudyAssessmentDetails.homeStudyAssessmentDtls);
    }
    homeStudyAssessmentDtlsList.contextDescription = this.getContextDescription(
      homeStudy);

    return homeStudyAssessmentDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Creates a home study assessment record for the parent home study record.
   *
   * @param details
   * the home study assessment creation details
   * @return key from the created record.
   * @throws InformationalException
   * @throws AppException
   */
  public HomeStudyAssessmentKey createHomeStudyAssessment(
    HomeStudyAssessmentDtls details) throws AppException,
      InformationalException {
    // Return object
    HomeStudyAssessmentKey homeStudyAssessmentKey = new HomeStudyAssessmentKey();
    curam.homestudy.impl.HomeStudyAssessment homeStudyAssessment = homeStudyAssessmentDAO.newInstance();

    // set the fields sent in by client
    homeStudyAssessment = setHomeStudyAssessmentFields(homeStudyAssessment,
      details);

    // call insert
    homeStudyAssessment.insert();

    // set and return key
    homeStudyAssessmentKey.homeStudyAssessmentKey.homeStudyAssessmentID = homeStudyAssessment.getID();
    return homeStudyAssessmentKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies a home study assessment record with the details returned from
   * the client.
   *
   * @param details
   * the details modified from the client
   * @throws InformationalException
   * @throws AppException
   */
  public void modifyHomeStudyAssessment(HomeStudyAssessmentDtls details)
    throws AppException, InformationalException {
    curam.homestudy.impl.HomeStudyAssessment homeStudyAssessment = homeStudyAssessmentDAO.get(
      details.homeStudyAssessmentDtls.homeStudyAssessmentID);

    // set the fields sent in by client
    homeStudyAssessment = setHomeStudyAssessmentFields(homeStudyAssessment,
      details);

    homeStudyAssessment.modify(details.homeStudyAssessmentDtls.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Reads a home study assessment record for the user to view.
   *
   * @param key
   * the key specifying the home study assessment record to be read
   * @return details for the selected home study assessment record.
   * @throws InformationalException
   * @throws AppException
   */
  public HomeStudyAssessmentDtls viewHomeStudyAssessment(
    HomeStudyAssessmentKey key) throws AppException,
      InformationalException {

    HomeStudyAssessmentDtls homeStudyAssessmentDtls = new HomeStudyAssessmentDtls();

    // Read the Home Study
    curam.homestudy.impl.HomeStudyAssessment homeStudyAssessment = homeStudyAssessmentDAO.get(
      key.homeStudyAssessmentKey.homeStudyAssessmentID);

    // set the details on the return struct
    homeStudyAssessmentDtls = setHomeStudyAssessmentDetails(homeStudyAssessment);

    homeStudyAssessmentDtls.contextDescription = this.getContextDescription(
      homeStudyAssessment.getHomeStudy());

    return homeStudyAssessmentDtls;
  }

  // ___________________________________________________________________________
  /**
   * Logically deletes a home study assessment.
   *
   * <p>
   * Transitions the life cycle state of the record from 'Normal' to
   * 'Canceled'.
   *
   * @param key
   * the cancel key for the delete function
   * @throws InformationalException
   * @throws AppException
   */
  public void deleteHomeStudyAssessment(HomeStudyAssessmentCancelKey key)
    throws AppException, InformationalException {
    curam.homestudy.impl.HomeStudyAssessment homeStudyAssessment = homeStudyAssessmentDAO.get(
      key.homeStudyAssessmentKey.homeStudyAssessmentID);

    // Call cancel and pass in the version number from the facade
    homeStudyAssessment.cancel(key.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to set the fields passed in by the client to the Home Study
   * Assessment.
   *
   * @param homeStudyAssessment
   * The HomeStudyAssessment to be inserted
   * @param homeStudyAssessmentDetails
   * The details passed from the client
   * @return populated home study assessment to insert.
   */
  // BEGIN, CR00177241, PM
  protected curam.homestudy.impl.HomeStudyAssessment setHomeStudyAssessmentFields(
    // END, CR00177241
    curam.homestudy.impl.HomeStudyAssessment homeStudyAssessment,
    HomeStudyAssessmentDtls homeStudyAssessmentDetails) {

    homeStudyAssessment.setComments(
      homeStudyAssessmentDetails.homeStudyAssessmentDtls.comments);
    homeStudyAssessment.setAssessmentType(
      HomeStudyAssessmentTypeEntry.get(
        homeStudyAssessmentDetails.homeStudyAssessmentDtls.assessmentType));
    homeStudyAssessment.setCorrectiveActionPlan(
      homeStudyAssessmentDetails.homeStudyAssessmentDtls.correctiveActionPlan);
    homeStudyAssessment.setCorrectiveActionRequired(
      homeStudyAssessmentDetails.homeStudyAssessmentDtls.correctiveActionRequired);
    homeStudyAssessment.setHomeStudy(
      homeStudyDAO.get(
        homeStudyAssessmentDetails.homeStudyAssessmentDtls.homeStudyID));
    homeStudyAssessment.setDateCompleted(
      homeStudyAssessmentDetails.homeStudyAssessmentDtls.dateCompleted);
    homeStudyAssessment.setResult(
      HomeStudyAssessmentResultEntry.get(
        homeStudyAssessmentDetails.homeStudyAssessmentDtls.result));

    return homeStudyAssessment;
  }

  // ___________________________________________________________________________
  /**
   * Returns details struct for use by client
   *
   * @param homeStudyAssessment
   * the Home Study Assessment to be returned
   * @return home study assessment details.
   */
  // BEGIN, CR00177241, PM
  protected HomeStudyAssessmentDtls setHomeStudyAssessmentDetails(
    // END, CR00177241
    curam.homestudy.impl.HomeStudyAssessment homeStudyAssessment) {

    // Set valid values for the service offering and service rate record
    HomeStudyAssessmentDtls homeStudyAssessmentDetails = new curam.cpm.facade.struct.HomeStudyAssessmentDtls();

    homeStudyAssessmentDetails.homeStudyAssessmentDtls.homeStudyAssessmentID = homeStudyAssessment.getID();
    homeStudyAssessmentDetails.homeStudyAssessmentDtls.comments = homeStudyAssessment.getComments();
    homeStudyAssessmentDetails.homeStudyAssessmentDtls.assessmentType = homeStudyAssessment.getAssessmentType().getCode();
    homeStudyAssessmentDetails.homeStudyAssessmentDtls.correctiveActionPlan = homeStudyAssessment.getCorrectiveActionPlan();
    homeStudyAssessmentDetails.homeStudyAssessmentDtls.correctiveActionRequired = homeStudyAssessment.isCorrectiveActionRequired();
    homeStudyAssessmentDetails.homeStudyAssessmentDtls.dateCompleted = homeStudyAssessment.getDateCompleted();
    homeStudyAssessmentDetails.homeStudyAssessmentDtls.homeStudyAssessmentID = homeStudyAssessment.getID();
    homeStudyAssessmentDetails.homeStudyAssessmentDtls.homeStudyID = homeStudyAssessment.getHomeStudy().getID();
    homeStudyAssessmentDetails.homeStudyAssessmentDtls.recordStatus = homeStudyAssessment.getLifecycleState().getCode();
    homeStudyAssessmentDetails.homeStudyAssessmentDtls.result = homeStudyAssessment.getResult().getCode();
    homeStudyAssessmentDetails.homeStudyAssessmentDtls.versionNo = homeStudyAssessment.getVersionNo();

    return homeStudyAssessmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the context description for the Home Visit Interview Record
   *
   * @param homeStudy
   * the parent homeStudy of the Assessment
   *
   * @return Returns Context Description string
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00177241, PM
  protected ContextDescriptionDetails getContextDescription(HomeStudy homeStudy)
    // END, CR00177241
    throws AppException, InformationalException {
    // Add the context description
    // Start CR00096126, JSP
    curam.cpm.facade.intf.ContextDescription contextDescription = ContextDescriptionFactory.newInstance();
    // End CR00096126

    // get the provider from the home study through
    // the home study home visit parent
    ProviderKey providerKey = new ProviderKey();

    providerKey.providerID = homeStudy.getProvider().getID();

    // get the context description details and return them
    return contextDescription.getContextDescription(providerKey);
  }

  // ___________________________________________________________________________
  /**
   * Sorts a set of Assessments by date created, if dates are equal then sort
   * by id to ensure a consistent ordering.
   *
   * @param unsortedRequests -
   * the set of requests
   * @return a sorted list of requests.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.homestudy.impl.HomeStudyAssessment> sortRequests(
    // END, CR00177241
    final Set<curam.homestudy.impl.HomeStudyAssessment> unsortedRequests) {

    // Sort by start date
    final List<curam.homestudy.impl.HomeStudyAssessment> requests = new ArrayList<curam.homestudy.impl.HomeStudyAssessment>(
      unsortedRequests);

    Collections.sort(requests,
      new Comparator<curam.homestudy.impl.HomeStudyAssessment>() {
      public int compare(
        final curam.homestudy.impl.HomeStudyAssessment lhs,
        curam.homestudy.impl.HomeStudyAssessment rhs) {
        int compareTo = lhs.getDateCompleted().compareTo(rhs.getDateCompleted());

        // if dates are equal compare by id instead
        if (compareTo == 0) {
          return lhs.getID().compareTo(rhs.getID());
        } else {
          return compareTo;
        }
      }
    });

    return requests;
  }
}
