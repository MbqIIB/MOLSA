/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;

import com.google.inject.Inject;

import curam.approvalcheck.entity.struct.ApprovalCheckDtls;
import curam.approvalcheck.impl.ApprovalCheck;
import curam.approvalcheck.impl.ApprovalCheckDAO;
import curam.codetable.impl.APPROVALCHECKTYPEEntry;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.facade.struct.ApprovalCheckDetails;
import curam.cpm.facade.struct.ApprovalCheckDetailsList;
import curam.cpm.facade.struct.ApprovalCheckKey;
import curam.cpm.facade.struct.CreateApprovalCheckDetails;
import curam.cpm.facade.struct.ModifyApprovalCheckDetails;
import curam.cpm.facade.struct.ViewApprovalCheckKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.message.PROVIDERAPPROVALCHECK;
import curam.message.impl.PROVIDERAPPROVALCHECKExceptionCreator;
import curam.provider.impl.ProviderApprovalCheck;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.SERVICEDELIVERYAPPROVALSEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;


/**
 * Facade layer class having APIs for managing Approval Check for the Provider.
 */
public class MaintainProviderApprovalCheck extends curam.cpm.facade.base.MaintainProviderApprovalCheck {

  /**
   * Reference to provider approval check.
   */
  @Inject
  ProviderApprovalCheck providerApprovalCheck;
  
  /**
   * Reference to approval check.
   */
  @Inject
  ApprovalCheck approvalCheck;
  
  /**
   * Reference to approval check DAO.
   */
  @Inject
  protected ApprovalCheckDAO approvalCheckDAO;
  
  /**
   * Reference to provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;
  
  /**
   * Constructor for the Maintain Provider Approval Check.
   */
  public MaintainProviderApprovalCheck() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  
  /**
   * Creates an approval check for the provider.
   *
   * @param createApprovalCheckDetails
   * Approval check details for the provider.
   *
   * @return The approval check ID of the created approval check.
   *
   * @throws AppException 
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature. 
   */
  public ApprovalCheckKey createProviderApprovalCheck(
    CreateApprovalCheckDetails createApprovalCheckDetails)
    throws AppException, InformationalException {
    
    ApprovalCheckDtls approvalCheckDtls = new ApprovalCheckDtls();
    
    approvalCheckDtls.comments = createApprovalCheckDetails.comments;
    approvalCheckDtls.percentage = createApprovalCheckDetails.percentage;
    approvalCheckDtls.relatedID = createApprovalCheckDetails.providerID;
    
    ApprovalCheckKey approvalCheckKey = providerApprovalCheck.createProviderApprovalCheck(
      approvalCheckDtls);
    
    return approvalCheckKey;
  }

  /**
   * Creates a provider approval check for the organization unit.
   *
   * @param createApprovalCheckDetails
   * Approval check details for the provider.
   *
   * @return The approval check ID of the created approval check.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECK#ERR_PROVIDER_APPROVALCHECK_XFV_INDIVIDUAL_PROVIDER_SELECTED_APPLIES_TO_ALL_CANNOT_BE_TRUE} -
   * If the indicator "Applies to All Providers" is set to true and
   * also a individual provider is selected.
   * @throws InformationalException
   * {@link PROVIDERAPPROVALCHECK#ERR_PROVIDER_APPROVALCHECK_XFV_EITHER_INDIVIDUAL_PROVIDER_OR_APPLIES_TO_ALL_PROVIDER_MUST_BE_SELECTED} -
   * If neither individual provider nor "Applies to All Providers" is
   * selected for an approval check for the organization unit.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckKey createProviderApprovalCheckForOrganisationUnit(
    CreateApprovalCheckDetails createApprovalCheckDetails)
    throws AppException, InformationalException {
    
    ApprovalCheckKey approvalCheckKey = new ApprovalCheckKey();
    
    if (createApprovalCheckDetails.appliesToAllInd
      && 0 != createApprovalCheckDetails.providerID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERAPPROVALCHECKExceptionCreator.ERR_PROVIDER_APPROVALCHECK_XFV_INDIVIDUAL_PROVIDER_SELECTED_APPLIES_TO_ALL_CANNOT_BE_TRUE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    } else if (!createApprovalCheckDetails.appliesToAllInd
      && 0 == createApprovalCheckDetails.providerID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERAPPROVALCHECKExceptionCreator.ERR_PROVIDER_APPROVALCHECK_XFV_EITHER_INDIVIDUAL_PROVIDER_OR_APPLIES_TO_ALL_PROVIDER_MUST_BE_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    
    ValidationHelper.failIfErrorsExist();

    approvalCheck = approvalCheckDAO.newInstance();

    approvalCheck.setComments(createApprovalCheckDetails.comments);
    approvalCheck.setPercentage(createApprovalCheckDetails.percentage);
    approvalCheck.setOrganisationUnitID(
      createApprovalCheckDetails.organisationUnitID);

    approvalCheck.createApprovalCheck(APPROVALRELATEDTYPEEntry.PROVIDER,
      createApprovalCheckDetails.providerID,
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT);

    approvalCheckKey.approvalCheckID = approvalCheck.getID();
      
    return approvalCheckKey;
  }

  /**
   * Creates a provider approval check for the user.
   *
   * @param createApprovalCheckDetails
   * Approval check details for the provider.
   *
   * @return The approval check ID of the created approval check.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECK#ERR_PROVIDER_APPROVALCHECK_XFV_INDIVIDUAL_PROVIDER_SELECTED_APPLIES_TO_ALL_CANNOT_BE_TRUE} -
   * If the indicator "Applies to All Providers" is set to true and
   * also a individual provider is selected.
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECK#ERR_PROVIDER_APPROVALCHECK_XFV_EITHER_INDIVIDUAL_PROVIDER_OR_APPLIES_TO_ALL_PROVIDER_MUST_BE_SELECTED} -
   * If neither individual provider nor "Applies to All Providers" is
   * selected for an approval check for the user.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckKey createProviderApprovalCheckForUser(
    CreateApprovalCheckDetails createApprovalCheckDetails) throws AppException,
      InformationalException {
    ApprovalCheckKey approvalCheckKey = new ApprovalCheckKey();
    
    if (createApprovalCheckDetails.appliesToAllInd
      && 0 != createApprovalCheckDetails.providerID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERAPPROVALCHECKExceptionCreator.ERR_PROVIDER_APPROVALCHECK_XFV_INDIVIDUAL_PROVIDER_SELECTED_APPLIES_TO_ALL_CANNOT_BE_TRUE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

    } else if (!createApprovalCheckDetails.appliesToAllInd
      && 0 == createApprovalCheckDetails.providerID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERAPPROVALCHECKExceptionCreator.ERR_PROVIDER_APPROVALCHECK_XFV_EITHER_INDIVIDUAL_PROVIDER_OR_APPLIES_TO_ALL_PROVIDER_MUST_BE_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    
    ValidationHelper.failIfErrorsExist();

    approvalCheck = approvalCheckDAO.newInstance();

    approvalCheck.setComments(createApprovalCheckDetails.comments);
    approvalCheck.setPercentage(createApprovalCheckDetails.percentage);
    approvalCheck.setUsername(createApprovalCheckDetails.userName);

    approvalCheck.createApprovalCheck(APPROVALRELATEDTYPEEntry.PROVIDER,
      createApprovalCheckDetails.providerID, APPROVALCHECKTYPEEntry.USER);

    approvalCheckKey.approvalCheckID = approvalCheck.getID();
      
    return approvalCheckKey;
  }

  /**
   * Deletes the approval check for the provider.
   *
   * @param viewApprovalCheckKey
   * Contains the IDs related to provider approval check.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deleteProviderApprovalCheck(
    ViewApprovalCheckKey viewApprovalCheckKey) throws AppException,
      InformationalException {
    
    approvalCheck = approvalCheckDAO.get(viewApprovalCheckKey.approvalCheckID);
    
    approvalCheck.cancel(viewApprovalCheckKey.versionNo);
  }

  /**
   * Lists the approval checks for a provider.
   *
   * @param providerKey
   * Contains the provider ID. 
   *
   * @return The list of approval check details for the provider.
   *
   * @throws AppException 
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature. 
   */
  public ApprovalCheckDetailsList listProviderApprovalChecks(
    ProviderKey providerKey) throws AppException, InformationalException {    
       
    ApprovalCheckDetailsList approvalCheckDetailsList = new ApprovalCheckDetailsList();
    ApprovalCheck approvalCheck;
    ApprovalCheckDetails approvalCheckDtls;
    
    List<ApprovalCheck> approvalChecks = providerApprovalCheck.listProviderApprovalChecks(
      providerKey.providerConcernRoleID);
    
    ListIterator<ApprovalCheck> approvalChecksIterator = approvalChecks.listIterator();

    while (approvalChecksIterator.hasNext()) {
      approvalCheckDtls = new ApprovalCheckDetails();
      
      approvalCheck = approvalChecksIterator.next();
      
      approvalCheckDtls.approvalCheckDtls.approvalCheckID = approvalCheck.getID();
      approvalCheckDtls.approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
      approvalCheckDtls.approvalCheckDtls.percentage = approvalCheck.getPercentage();
      approvalCheckDtls.approvalCheckDtls.versionNo = approvalCheck.getVersionNo();
      
      approvalCheckDetailsList.approvalCheckDtls.addRef(approvalCheckDtls);
    }
    
    return approvalCheckDetailsList;
  }

  /**
   * Lists all the provider approval checks for a organization unit.
   *
   * @param viewApprovalCheckKey
   * Contains provider ID and organization unit ID.
   *
   * @return The list approval check details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ApprovalCheckDetailsList listProviderApprovalChecksForOrganisationUnit(
    ViewApprovalCheckKey viewApprovalCheckKey) throws AppException,
      InformationalException {
    
    ApprovalCheckDetailsList approvalCheckDetailsList = new ApprovalCheckDetailsList();
    ApprovalCheck approvalCheck;
    ApprovalCheckDetails approvalCheckDtls;
    
    List<ApprovalCheck> approvalChecks = new ArrayList<ApprovalCheck>();
    
    List<ApprovalCheck> activeApprovalChecks = approvalCheckDAO.searchByTypeOrganisationUnitAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.PROVIDER,
      viewApprovalCheckKey.organisationUnitID, RECORDSTATUSEntry.NORMAL);
    
    List<ApprovalCheck> canceledApprovalChecks = approvalCheckDAO.searchByTypeOrganisationUnitAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.PROVIDER,
      viewApprovalCheckKey.organisationUnitID, RECORDSTATUSEntry.CANCELLED);
    
    approvalChecks.addAll(activeApprovalChecks);
    approvalChecks.addAll(canceledApprovalChecks);
    
    ListIterator<ApprovalCheck> approvalChecksIterator = approvalChecks.listIterator();

    while (approvalChecksIterator.hasNext()) {
      approvalCheckDtls = new ApprovalCheckDetails();

      approvalCheck = approvalChecksIterator.next();

      approvalCheckDtls.approvalCheckDtls.approvalCheckID = approvalCheck.getID();
      approvalCheckDtls.approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
      approvalCheckDtls.approvalCheckDtls.percentage = approvalCheck.getPercentage();
      approvalCheckDtls.approvalCheckDtls.versionNo = approvalCheck.getVersionNo();
      
      if (0 != approvalCheck.getRelatedID()) {
        approvalCheckDtls.providerName = providerDAO.get(approvalCheck.getRelatedID()).getName();
      } else {
        approvalCheckDtls.providerName = SERVICEDELIVERYAPPROVALSEntry.ALLPROVIDERS.toUserLocaleString();
      }
      
      approvalCheckDetailsList.approvalCheckDtls.addRef(approvalCheckDtls);
    }

    return sortProviderApprovalChecks(approvalCheckDetailsList);
  }

  /**
   * Lists the provider approval checks for a user.
   *
   * @param viewApprovalCheckKey
   * Contains the provider ID and user name.
   *
   * @return The list of approval check details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ApprovalCheckDetailsList listProviderApprovalChecksForUser(
    ViewApprovalCheckKey viewApprovalCheckKey) throws AppException,
      InformationalException {
    
    ApprovalCheckDetailsList approvalCheckDetailsList = new ApprovalCheckDetailsList();
    ApprovalCheck approvalCheck;
    ApprovalCheckDetails approvalCheckDtls;
    
    List<ApprovalCheck> approvalChecks = new ArrayList<ApprovalCheck>();
    
    List<ApprovalCheck> activeApprovalChecks = approvalCheckDAO.searchByTypeUsernameAndStatus(
      APPROVALCHECKTYPEEntry.USER, APPROVALRELATEDTYPEEntry.PROVIDER,
      viewApprovalCheckKey.userName, RECORDSTATUSEntry.NORMAL);

    List<ApprovalCheck> canceledApprovalChecks = approvalCheckDAO.searchByTypeUsernameAndStatus(
      APPROVALCHECKTYPEEntry.USER, APPROVALRELATEDTYPEEntry.PROVIDER,
      viewApprovalCheckKey.userName, RECORDSTATUSEntry.CANCELLED);
    
    approvalChecks.addAll(activeApprovalChecks);
    approvalChecks.addAll(canceledApprovalChecks);
    
    ListIterator<ApprovalCheck> approvalChecksIterator = approvalChecks.listIterator();

    while (approvalChecksIterator.hasNext()) {
      approvalCheckDtls = new ApprovalCheckDetails();

      approvalCheck = approvalChecksIterator.next();

      approvalCheckDtls.approvalCheckDtls.approvalCheckID = approvalCheck.getID();
      approvalCheckDtls.approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
      approvalCheckDtls.approvalCheckDtls.percentage = approvalCheck.getPercentage();
      approvalCheckDtls.approvalCheckDtls.versionNo = approvalCheck.getVersionNo();
      
      if (0 != approvalCheck.getRelatedID()) {
        approvalCheckDtls.providerName = providerDAO.get(approvalCheck.getRelatedID()).getName();
      } else {
        approvalCheckDtls.providerName = SERVICEDELIVERYAPPROVALSEntry.ALLPROVIDERS.toUserLocaleString();
      }      
      approvalCheckDetailsList.approvalCheckDtls.addRef(approvalCheckDtls);
    }

    return sortProviderApprovalChecks(approvalCheckDetailsList);
  }

  /**
   * Modifies the approval check details for a provider.
   *
   * @param modifyApprovalCheckDetails 
   * Details of the provider approval check.
   *
   * @return The approval check ID. 
   *
   * @throws AppException 
   * Generic Exception Signature.
   * @throws InformationalException 
   * Generic Exception Signature.
   */
  public ApprovalCheckKey modifyProviderApprovalCheck(
    ModifyApprovalCheckDetails modifyApprovalCheckDetails)
    throws AppException, InformationalException {

    ApprovalCheckDtls approvalCheckDtls = new ApprovalCheckDtls();

    approvalCheckDtls.approvalCheckID = modifyApprovalCheckDetails.approvalCheckID;
    approvalCheckDtls.comments = modifyApprovalCheckDetails.approvalCheckDtls.comments;
    approvalCheckDtls.percentage = modifyApprovalCheckDetails.approvalCheckDtls.percentage;
    approvalCheckDtls.versionNo = modifyApprovalCheckDetails.versionNo;
    approvalCheckDtls.relatedID = modifyApprovalCheckDetails.approvalCheckDtls.providerID;

    ApprovalCheckKey approvalCheckKey = providerApprovalCheck.modifyProviderApprovalCheck(
      approvalCheckDtls);

    return approvalCheckKey;
  }

  /**
   * Modifies the provider approval check details for a organization unit.
   *
   * @param modifyApprovalCheckDetails 
   * The provider approval check details.
   *
   * @return The approval check ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ApprovalCheckKey modifyProviderApprovalCheckForOrganisationUnit(
    ModifyApprovalCheckDetails modifyApprovalCheckDetails)
    throws AppException, InformationalException {
    
    ApprovalCheckKey approvalCheckKey = new ApprovalCheckKey();
    
    approvalCheck = approvalCheckDAO.get(
      modifyApprovalCheckDetails.approvalCheckID);
    
    approvalCheck.setComments(
      modifyApprovalCheckDetails.approvalCheckDtls.comments);
    approvalCheck.setPercentage(
      modifyApprovalCheckDetails.approvalCheckDtls.percentage);
    
    approvalCheck.modifyApprovalCheck(modifyApprovalCheckDetails.versionNo);
    
    approvalCheckKey.approvalCheckID = approvalCheck.getID();
    
    return approvalCheckKey;
  }

  /**
   * Modifies the provider approval check details for a user.
   *
   * @param modifyApprovalCheckDetails
   * The provider approval check details.
   *
   * @return The approval check ID.
   *
   * @throws AppException
   * Generic Exception Signature.   
   * @throws InformationalException 
   * Generic Exception Signature.
   */
  public ApprovalCheckKey modifyProviderApprovalCheckForUser(
    ModifyApprovalCheckDetails modifyApprovalCheckDetails)
    throws AppException, InformationalException {
    ApprovalCheckKey approvalCheckKey = new ApprovalCheckKey();

    approvalCheck = approvalCheckDAO.get(
      modifyApprovalCheckDetails.approvalCheckID);

    approvalCheck.setComments(
      modifyApprovalCheckDetails.approvalCheckDtls.comments);
    approvalCheck.setPercentage(
      modifyApprovalCheckDetails.approvalCheckDtls.percentage);

    approvalCheck.modifyApprovalCheck(modifyApprovalCheckDetails.versionNo);

    approvalCheckKey.approvalCheckID = approvalCheck.getID();

    return approvalCheckKey;
  }

  /**
   * Reads the approval check details for a provider.
   *
   * @param approvalCheckKey
   * Contains the approval check ID for the provider.
   *
   * @return The approval check details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ApprovalCheckDetails viewProviderApprovalCheck(
    ApprovalCheckKey approvalCheckKey) throws AppException,
      InformationalException {
    
    ApprovalCheckDetails approvalCheckDetails = new ApprovalCheckDetails();
    
    approvalCheck = approvalCheckDAO.get(approvalCheckKey.approvalCheckID);
    
    approvalCheckDetails.approvalCheckDtls.comments = approvalCheck.getComments();
    approvalCheckDetails.approvalCheckDtls.percentage = approvalCheck.getPercentage();
    approvalCheckDetails.approvalCheckDtls.approvalCheckID = approvalCheck.getID();
    approvalCheckDetails.approvalCheckDtls.organisationUnitID = approvalCheck.getOrganisationUnitID();
    approvalCheckDetails.approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
    approvalCheckDetails.approvalCheckDtls.relatedID = approvalCheck.getRelatedID();
    approvalCheckDetails.approvalCheckDtls.relatedType = approvalCheck.getRelatedType().getCode();
    approvalCheckDetails.approvalCheckDtls.typeCode = approvalCheck.getType().getCode();
    approvalCheckDetails.providerName = providerDAO.get(approvalCheck.getRelatedID()).getName();
    approvalCheckDetails.approvalCheckDtls.versionNo = approvalCheck.getVersionNo();
    
    return approvalCheckDetails;
  }

  /**
   * Reads the provider approval check details for a organization unit.
   *
   * @param approvalCheckKey
   * Contains the approval check ID for the provider and the
   * organization unit.
   *
   * @return The approval check details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ApprovalCheckDetails viewProviderApprovalCheckForOrganisationUnit(
    ApprovalCheckKey approvalCheckKey) throws AppException,
      InformationalException {
    
    ApprovalCheckDetails approvalCheckDetails = new ApprovalCheckDetails();
    
    approvalCheck = approvalCheckDAO.get(approvalCheckKey.approvalCheckID);
    
    approvalCheckDetails.approvalCheckDtls.comments = approvalCheck.getComments();
    approvalCheckDetails.approvalCheckDtls.percentage = approvalCheck.getPercentage();
    approvalCheckDetails.approvalCheckDtls.approvalCheckID = approvalCheck.getID();
    approvalCheckDetails.approvalCheckDtls.organisationUnitID = approvalCheck.getOrganisationUnitID();
    approvalCheckDetails.approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
    approvalCheckDetails.approvalCheckDtls.relatedID = approvalCheck.getRelatedID();
    approvalCheckDetails.approvalCheckDtls.relatedType = approvalCheck.getRelatedType().getCode();
    approvalCheckDetails.approvalCheckDtls.typeCode = approvalCheck.getType().getCode();
    
    if (0 != approvalCheck.getRelatedID()) {
      approvalCheckDetails.providerName = providerDAO.get(approvalCheck.getRelatedID()).getName();
    } else {
      approvalCheckDetails.providerName = SERVICEDELIVERYAPPROVALSEntry.ALLPROVIDERS.toUserLocaleString();
    }
    
    approvalCheckDetails.approvalCheckDtls.versionNo = approvalCheck.getVersionNo();

    return approvalCheckDetails;
  }

  /**
   * Reads the provider approval check details for a user.
   *
   * @param approvalCheckKey
   * Contains the approval check ID for the provider and the user.
   *
   * @return The approval check details.
   *
   * @throws AppException 
   * Generic Exception Signature.
   * @throws InformationalException  
   * Generic Exception Signature.
   */
  public ApprovalCheckDetails viewProviderApprovalCheckForUser(
    ApprovalCheckKey approvalCheckKey) throws AppException,
      InformationalException {
    ApprovalCheckDetails approvalCheckDetails = new ApprovalCheckDetails();
    
    approvalCheck = approvalCheckDAO.get(approvalCheckKey.approvalCheckID);
    
    approvalCheckDetails.approvalCheckDtls.comments = approvalCheck.getComments();
    approvalCheckDetails.approvalCheckDtls.percentage = approvalCheck.getPercentage();
    approvalCheckDetails.approvalCheckDtls.approvalCheckID = approvalCheck.getID();
    approvalCheckDetails.approvalCheckDtls.username = approvalCheck.getUsername();
    approvalCheckDetails.approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
    approvalCheckDetails.approvalCheckDtls.relatedID = approvalCheck.getRelatedID();
    approvalCheckDetails.approvalCheckDtls.relatedType = approvalCheck.getRelatedType().getCode();
    approvalCheckDetails.approvalCheckDtls.typeCode = approvalCheck.getType().getCode();
    
    if (0 != approvalCheck.getRelatedID()) {
      approvalCheckDetails.providerName = providerDAO.get(approvalCheck.getRelatedID()).getName();
    } else {
      approvalCheckDetails.providerName = SERVICEDELIVERYAPPROVALSEntry.ALLPROVIDERS.toUserLocaleString();
    }

    approvalCheckDetails.approvalCheckDtls.versionNo = approvalCheck.getVersionNo();

    return approvalCheckDetails;
  }
  
  /**
   * Sorts the list of provider approval check details by name.
   *
   * @param unSortedApprovalCheckList
   * The list of approval check details.
   *
   * @return The list of sorted approval check details.
   */
  protected ApprovalCheckDetailsList sortProviderApprovalChecks(
    ApprovalCheckDetailsList unSortedApprovalCheckList) {

    List<ApprovalCheckDetails> approvalCheckList = new ArrayList<ApprovalCheckDetails>();
    int countOfUnsortedApprovalCheck = unSortedApprovalCheckList.approvalCheckDtls.size();

    for (int i = 0; i < countOfUnsortedApprovalCheck; i++) {
      approvalCheckList.add(unSortedApprovalCheckList.approvalCheckDtls.item(i));
    }

    Collections.sort(approvalCheckList,
      new Comparator<ApprovalCheckDetails>() {
      public int compare(final ApprovalCheckDetails lhs,
        ApprovalCheckDetails rhs) {
        return lhs.providerName.compareTo(rhs.providerName);
      }
    });

    ApprovalCheckDetailsList sortedApprovalCheckList = new ApprovalCheckDetailsList();

    for (ApprovalCheckDetails approvalCheckDetails : approvalCheckList) {
      sortedApprovalCheckList.approvalCheckDtls.addRef(approvalCheckDetails);
    }

    return sortedApprovalCheckList;
  }

}
