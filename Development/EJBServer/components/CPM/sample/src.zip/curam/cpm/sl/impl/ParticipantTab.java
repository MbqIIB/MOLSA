/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.sl.impl;


import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.INFORMATIONPROVIDERTYPEEntry;
import curam.core.fact.InformationProviderFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.InformationProvider;
import curam.core.sl.struct.ClientPageURL;
import curam.core.struct.ConcernRoleIDType;
import curam.core.struct.InformationProviderDtls;
import curam.core.struct.InformationProviderKey;
import curam.cpm.impl.CPMConstants;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for the participant tab
 * details. This class is the overridden class from the core class
 * {@linkplain curam.core.sl.impl.ParticipantTab ParticipantTab}.
 */
public class ParticipantTab extends curam.core.sl.impl.ParticipantTab {

  /**
   * Resolves participant tab details page.
   *
   * @param details
   * Contains concern role id and type code details.
   *
   * @return Participant tab details page url.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ClientPageURL resolveParticipantTabPageURL(
    final ConcernRoleIDType details) throws AppException,
      InformationalException {
    final ClientPageURL clientPageURL = new ClientPageURL();

    if (CONCERNROLETYPEEntry.PERSON.getCode().equals(details.concernRoleType)) {
      clientPageURL.pageURL = CuramConst.gkPersonTabDetailsPage;
    } else if (CONCERNROLETYPEEntry.PROSPECTPERSON.getCode().equals(
      details.concernRoleType)) {
      clientPageURL.pageURL = CuramConst.gkProspectPersonTabDetailsPage;
    } else if (CONCERNROLETYPEEntry.EMPLOYER.getCode().equals(
      details.concernRoleType)) {
      clientPageURL.pageURL = CuramConst.gkEmployerTabDetailsPage;
    } else if (CONCERNROLETYPEEntry.PROSPECTEMPLOYER.getCode().equals(
      details.concernRoleType)) {
      clientPageURL.pageURL = CuramConst.gkProspectEmployerTabDetailsPage;
    } else if (CONCERNROLETYPEEntry.PRODUCTPROVIDER.getCode().equals(
      details.concernRoleType)) {
      clientPageURL.pageURL = CuramConst.gkProductProviderTabDetailsPage;
    } else if (CONCERNROLETYPEEntry.SERVICESUPPLIER.getCode().equals(
      details.concernRoleType)) {
      clientPageURL.pageURL = CuramConst.gkServiceSupplierTabDetailsPage;
    } else if (CONCERNROLETYPEEntry.UTILITY.getCode().equals(
      details.concernRoleType)) {
      clientPageURL.pageURL = CuramConst.gkUtilityTabDetailsPage;
    } else if (CONCERNROLETYPEEntry.PROVIDER.getCode().equals(
      details.concernRoleType)) {
      clientPageURL.pageURL = CPMConstants.gkProviderTabDetailsPage;
    } else if (CONCERNROLETYPEEntry.PROVIDERGROUP.getCode().equals(
      details.concernRoleType)) {
      clientPageURL.pageURL = CPMConstants.gkProviderGroupTabDetailsPage;
    } else if (CONCERNROLETYPEEntry.INFORMATIONPROVIDER.getCode().equals(
      details.concernRoleType)) {
      final InformationProvider informationalProviderObj = InformationProviderFactory.newInstance();
      final InformationProviderKey informationProviderKey = new InformationProviderKey();

      informationProviderKey.concernRoleID = details.concernRoleID;
      final InformationProviderDtls informationProviderDtls = informationalProviderObj.read(
        informationProviderKey);

      if (INFORMATIONPROVIDERTYPEEntry.EDUINSTITUTE.getCode().equals(
        informationProviderDtls.typeCode)) {
        clientPageURL.pageURL = CuramConst.gkEducationInstituteTabDetailsPage;
      } else {
        clientPageURL.pageURL = CuramConst.gkInformationProviderTabDetailsPage;
      }
    } else if (CONCERNROLETYPEEntry.EXTERNALPARTY.getCode().equals(
      details.concernRoleType)) {
      clientPageURL.pageURL = CuramConst.gkExternalPartyTabDetailsPage;
    }

    clientPageURL.pageURL += CuramConst.kQuestion
      + CuramConst.gkPageParameterConcernRoleID + CuramConst.gkEqualsNoSpaces
      + details.concernRoleID;
    return clientPageURL;
  }
}
