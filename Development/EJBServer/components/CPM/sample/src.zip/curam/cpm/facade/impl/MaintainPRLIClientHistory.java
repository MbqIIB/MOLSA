/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import com.google.inject.Inject;
import curam.attendance.impl.PRLIClientHistory;
import curam.attendance.impl.PRLIClientHistoryDAO;
import curam.attendance.impl.PRLIHistory;
import curam.attendance.impl.PRLIHistoryDAO;
import curam.core.impl.CuramConst;
import curam.cpm.facade.struct.PRLIClientHistoryDetails;
import curam.cpm.facade.struct.PRLIClientHistoryDetailsList;
import curam.cpm.sl.entity.struct.PRLIHistoryKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import java.util.Set;


/**
 * Contains methods to manage the roster line item history client.
 *
 */
public abstract class MaintainPRLIClientHistory extends curam.cpm.facade.base.MaintainPRLIClientHistory {

  /**
   * Data Access Object for PRLIClientHistory.
   */
  @Inject
  protected PRLIClientHistoryDAO prliClientHistoryDAO;

  /**
   * Data Access Object for PRLIHistory.
   */
  @Inject
  protected PRLIHistoryDAO prliHistoryDAO;

  /**
   * Default constructor that does Guice injections.
   */
  protected MaintainPRLIClientHistory() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Returns the list of all clients associated with the given roster line item
   * history item.
   *
   * @param prliHistoryKey
   * Contains PRLI history ID.
   *
   * @return List of PRLI history clients.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLIClientHistoryDetailsList listPRLIClientHistory(
    PRLIHistoryKey prliHistoryKey) throws AppException,
      InformationalException {
    PRLIClientHistoryDetailsList prliClientHistoryDetailsList = new PRLIClientHistoryDetailsList();
    PRLIHistory prliHistory = prliHistoryDAO.get(prliHistoryKey.prliHistoryID);

    if (prliHistory.isClientAttached()) {
      PRLIClientHistoryDetails prliClientHistoryDetails = new PRLIClientHistoryDetails();

      prliClientHistoryDetails.addressData = prliHistory.getAddressData();

      prliClientHistoryDetails.dtls.clientFirstName = prliHistory.getClientFirstName();
      prliClientHistoryDetails.dtls.clientLastName = prliHistory.getClientLastName();
      prliClientHistoryDetails.dtls.clientReferenceNo = prliHistory.getClientReferenceNo();
      prliClientHistoryDetails.dtls.clientDOB = prliHistory.getClientDOB();
      prliClientHistoryDetails.dtls.addressID = prliHistory.getAddressID();

      prliClientHistoryDetailsList.clientDtls.addRef(prliClientHistoryDetails);
      
    }
    
    Set<PRLIClientHistory> clientList = prliClientHistoryDAO.listClientsForPRLIHistory(
      prliHistory);

    for (PRLIClientHistory client : clientList) {
      PRLIClientHistoryDetails prliClientHistoryDetails = new PRLIClientHistoryDetails();

      prliClientHistoryDetails.addressData = client.getAddressData();

      prliClientHistoryDetails.dtls.clientFirstName = client.getClientFirstName();
      prliClientHistoryDetails.dtls.clientLastName = client.getClientLastName();
      prliClientHistoryDetails.dtls.clientReferenceNo = client.getClientReferenceNo();
      prliClientHistoryDetails.dtls.clientDOB = client.getClientDOB();
      prliClientHistoryDetails.dtls.addressID = client.getAddressID();

      prliClientHistoryDetailsList.clientDtls.addRef(prliClientHistoryDetails);
    }
    return prliClientHistoryDetailsList;
  }

  /**
   * Returns the client details of roster line item history for view.
   *
   * @param prliClientHistoryKey
   * contains identifier for provider roster line item history client.
   *
   * @return the roster line item history client details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLIClientHistoryDetails viewPRLIClientHistory(
    curam.cpm.facade.struct.PRLIClientHistoryKey prliClientHistoryKey)
    throws AppException, InformationalException {
    PRLIClientHistoryDetails prliClientHistoryDetails = new PRLIClientHistoryDetails();

    if (prliClientHistoryKey.prliClientHistoryID != CuramConst.gkZero) {
      PRLIClientHistory prliClientHistory = prliClientHistoryDAO.get(
        prliClientHistoryKey.prliClientHistoryID);

      prliClientHistoryDetails.addressData = prliClientHistory.getAddressData();

      prliClientHistoryDetails.dtls.prliClientHistoryID = prliClientHistory.getID();
      prliClientHistoryDetails.dtls.prliHistoryID = prliClientHistoryKey.prliHistoryID;
      prliClientHistoryDetails.dtls.addressID = prliClientHistory.getAddressID();
      prliClientHistoryDetails.dtls.clientDOB = prliClientHistory.getClientDOB();
      prliClientHistoryDetails.dtls.clientFirstName = prliClientHistory.getClientFirstName();
      prliClientHistoryDetails.dtls.clientLastName = prliClientHistory.getClientLastName();
      prliClientHistoryDetails.dtls.clientReferenceNo = prliClientHistory.getClientReferenceNo();
    } else {
      PRLIHistory prliHistory = prliHistoryDAO.get(
        prliClientHistoryKey.prliHistoryID);

      prliClientHistoryDetails.addressData = prliHistory.getAddressData();

      prliClientHistoryDetails.dtls.prliClientHistoryID = prliHistory.getID();
      prliClientHistoryDetails.dtls.prliHistoryID = prliClientHistoryKey.prliHistoryID;
      prliClientHistoryDetails.dtls.addressID = prliHistory.getAddressID();
      prliClientHistoryDetails.dtls.clientDOB = prliHistory.getClientDOB();
      prliClientHistoryDetails.dtls.clientFirstName = prliHistory.getClientFirstName();
      prliClientHistoryDetails.dtls.clientLastName = prliHistory.getClientLastName();
      prliClientHistoryDetails.dtls.clientReferenceNo = prliHistory.getClientReferenceNo();
    }
    return prliClientHistoryDetails;

  }

}
