/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2011, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.sl.impl;


import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.INFORMATIONPROVIDERTYPEEntry;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.struct.AllParticipantDatabaseSearchKey;
import curam.core.sl.struct.AllParticipantSearchDetails;
import curam.core.sl.struct.AllParticipantSearchDtls;
import curam.core.sl.struct.AllParticipantSearchKey;
import curam.core.sl.struct.AllParticipantSearchResult;
import curam.core.sl.struct.AllParticipantSearchStruct;
import curam.core.sl.struct.SQLStatement;
import curam.message.GENERAL;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;


/**
 * Participant search in database. This class is the overridden class from the
 * core class {@linkplain curam.core.sl.impl.DatabaseParticipantSearch
 * DatabaseParticipantSearch}.
 *
 */
public class DatabaseParticipantSearch extends curam.core.sl.impl.DatabaseParticipantSearch {

  /**
   * Performs a database search for participant type using the specified
   * search criteria.
   *
   * @param key
   * Contains data on which the participant search will be based.
   *
   * @return The details of any participant records found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AllParticipantSearchResult searchAll(
    final AllParticipantSearchKey key) throws AppException,
      InformationalException {
    AllParticipantSearchResult allParticipantSearchResult = new AllParticipantSearchResult();
    
    final AllParticipantSearchStruct allParticipantSearchStruct = new AllParticipantSearchStruct();

    allParticipantSearchStruct.assign(key);

    boolean personSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_PERSON_SEARCH_ENABLED);

    if (personSearchEnabled) {
      allParticipantSearchResult.dtlsList.addAll(
        searchByType(allParticipantSearchStruct, formatPersonSQL(allParticipantSearchStruct)).dtlsList);
    }

    boolean employerSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_EMPLOYER_SEARCH_ENABLED);

    if (employerSearchEnabled) {
      allParticipantSearchResult.dtlsList.addAll(
        searchByType(allParticipantSearchStruct, formatEmployerSQL(allParticipantSearchStruct)).dtlsList);
    }

    boolean externalPartySearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_EXTERNAL_PARTY_SEARCH_ENABLED);

    if (externalPartySearchEnabled) {
      allParticipantSearchStruct.concernRoleType = CONCERNROLETYPEEntry.EXTERNALPARTY.getCode();
      allParticipantSearchResult.dtlsList.addAll(
        searchByType(allParticipantSearchStruct, formatSQLByType(allParticipantSearchStruct)).dtlsList);
    }

    boolean informationProviderSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_INFORMATION_PROVIDER_SEARCH_ENABLED);
    boolean educationalInstituteSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_EDUCATIONAL_INSTITUTE_SEARCH_ENABLED);

    // Display educational institute if educational institute administration
    // setting is disabled but information provide administration setting is
    // enabled as educational institute is information provider.
    if (informationProviderSearchEnabled) {
      educationalInstituteSearchEnabled = true;
    }

    if (informationProviderSearchEnabled || educationalInstituteSearchEnabled) {
      allParticipantSearchStruct.subtype = INFORMATIONPROVIDERTYPEEntry.EDUINSTITUTE.getCode();
      allParticipantSearchStruct.concernRoleType = CONCERNROLETYPEEntry.INFORMATIONPROVIDER.getCode();

      if (!informationProviderSearchEnabled) {
        allParticipantSearchStruct.concernRoleType = CuramConst.gkEmpty;
      }
      allParticipantSearchResult.dtlsList.addAll(
        searchByType(allParticipantSearchStruct, formatSQLByType(allParticipantSearchStruct)).dtlsList);
      allParticipantSearchStruct.subtype = CuramConst.gkEmpty;

    }

    boolean productProviderSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_PRODUCT_PROVIDER_SEARCH_ENABLED);

    if (productProviderSearchEnabled) {
      allParticipantSearchStruct.concernRoleType = CONCERNROLETYPEEntry.PRODUCTPROVIDER.getCode();
      allParticipantSearchResult.dtlsList.addAll(
        searchByType(allParticipantSearchStruct, formatSQLByType(allParticipantSearchStruct)).dtlsList);
    }

    boolean productServiceSupplierSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_SERVICE_SUPPLIER_SEARCH_ENABLED);

    if (productServiceSupplierSearchEnabled) {
      allParticipantSearchStruct.concernRoleType = CONCERNROLETYPEEntry.SERVICESUPPLIER.getCode();
      allParticipantSearchResult.dtlsList.addAll(
        searchByType(allParticipantSearchStruct, formatSQLByType(allParticipantSearchStruct)).dtlsList);
    }

    boolean productUtilitySearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_UTILITY_SEARCH_ENABLED);

    if (productUtilitySearchEnabled) {
      allParticipantSearchStruct.concernRoleType = CONCERNROLETYPEEntry.UTILITY.getCode();
      allParticipantSearchResult.dtlsList.addAll(
        searchByType(allParticipantSearchStruct, formatSQLByType(allParticipantSearchStruct)).dtlsList);
    }

    // Add additional participant type search SQL statements here.
    allParticipantSearchResult.dtlsList.addAll(
      searchProviderParticipant(key).dtlsList);
    return allParticipantSearchResult;
  }

  /**
   * Performs participant search for specified concern role type.
   *
   * @param key
   * Contains all participant search criteria.
   * @param sqlStatement
   * Contains SQL statement to search participants.
   *
   * @return Found participant details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  @Override
  protected AllParticipantSearchResult searchByType(
    final AllParticipantSearchStruct key,
    final SQLStatement sqlStatement) throws AppException,
      InformationalException {
    final AllParticipantDatabaseSearchKey allParticipantDatabaseSearchKey = calculateAllSearchKey(
      key);
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    CuramValueList<AllParticipantSearchDtls> curamValueList = null;

    try {
      // BEGIN, CR00292696, IBM	
      curamValueList = DynamicDataAccess.executeNsMulti(
        AllParticipantSearchDtls.class, allParticipantDatabaseSearchKey, false,
        true, sqlStatement.sqlStatement);
      // END, CR00292696
    } catch (curam.util.exception.ReadmultiMaxException e) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      informationalManager.failOperation();
    }

    final ParticipantSearch participantSearch = new ParticipantSearch();
    final int listSize = curamValueList.size();
    final AllParticipantSearchResult allParticipantSearchResult = new AllParticipantSearchResult();

    allParticipantSearchResult.dtlsList.ensureCapacity(listSize);

    for (int i = 0; i < listSize; i++) {
      final AllParticipantSearchDtls allParticipantSearchDtls = curamValueList.get(
        i);
      final AllParticipantSearchDetails allParticipantSearchDetails = participantSearch.processAllSearchDetails(
        allParticipantSearchDtls);

      if (null != allParticipantSearchDetails) {
        allParticipantSearchResult.dtlsList.addRef(allParticipantSearchDetails);
      }
    }
    return allParticipantSearchResult;
  }

  /**
   * Performs a database search for provider participant type using the
   * specified search criteria.
   *
   * @param key
   * Contains data on which the provider participant search will be
   * based.
   *
   * @return The details of any provider participant records found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected AllParticipantSearchResult searchProviderParticipant(
    final AllParticipantSearchKey key) throws AppException,
      InformationalException {
    final AllParticipantSearchResult allParticipantSearchResult = new AllParticipantSearchResult();
    
    final AllParticipantSearchStruct allParticipantSearchStruct = new AllParticipantSearchStruct();

    allParticipantSearchStruct.assign(key);

    boolean providerSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_PROVIDER_SEARCH_ENABLED);

    if (providerSearchEnabled) {
      allParticipantSearchStruct.concernRoleType = CONCERNROLETYPEEntry.PROVIDER.getCode();
      allParticipantSearchResult.dtlsList.addAll(
        searchByType(allParticipantSearchStruct, formatSQLByType(allParticipantSearchStruct)).dtlsList);
    }

    boolean providerGroupSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_PROVIDER_GROUP_SEARCH_ENABLED);

    if (providerGroupSearchEnabled) {
      allParticipantSearchStruct.concernRoleType = CONCERNROLETYPEEntry.PROVIDERGROUP.getCode();
      allParticipantSearchResult.dtlsList.addAll(
        searchByType(allParticipantSearchStruct, formatSQLByType(allParticipantSearchStruct)).dtlsList);
    }
    
    return allParticipantSearchResult;
  }
}
