/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.util.impl;


import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import curam.core.impl.CuramConst;
import curam.cpm.impl.CPMConstants;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.StringUtil;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.FrequencyPattern;
import curam.util.type.FrequencyPattern.DayOfWeekMask;
import curam.util.type.FrequencyPattern.PatternType;
import curam.util.type.StringList;


/**
 * Implementation of the {@link FrequencyPatternUtil} interface.
 *
 */
public class FrequencyPatternUtilImpl implements FrequencyPatternUtil {

  /**
   * Constructor for the class.
   */
  public FrequencyPatternUtilImpl() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public Date getAnchorDateAfterReferenceDate(final Date referenceDate,
    final FrequencyPattern frequencyPattern) {

    Date anchorDate = Date.kZeroDate;

    // BEGIN, CR00305409, SSK
    if (isAnchorDate(referenceDate, frequencyPattern)) {
      anchorDate = referenceDate;
      // END, CR00305409
    } else {
      
      final PatternType patternType = frequencyPattern.getPatternType();

      if (FrequencyPattern.PatternType.kDaily.equals(patternType)) {
        anchorDate = getAnchorDateForDailyFrequencyPattern(referenceDate,
          frequencyPattern, false);

      } else if (FrequencyPattern.PatternType.kWeekly.equals(patternType)) {

        if (FrequencyPattern.kStartDayEachWeekPattern.equals(frequencyPattern)) {
          anchorDate = referenceDate;
        } else {
          anchorDate = getAnchorDateForWeeklyFrequencyPattern(referenceDate,
            frequencyPattern, false);
        }

      } else if (FrequencyPattern.PatternType.kMonthly.equals(patternType)) {

        // END, CR00304013
        anchorDate = getAnchorDateForMonthlyFrequencyPattern(referenceDate,
          frequencyPattern, false);
      } else {
        anchorDate = frequencyPattern.getNextOccurrence(referenceDate);
      }
    }
    return anchorDate;
  }

  /**
   * {@inheritDoc}
   */
  public Date getAnchorDateBeforeReferenceDate(final Date referenceDate,
    final FrequencyPattern frequencyPattern) {

    Date anchorDate = Date.kZeroDate;

    // BEGIN, CR00305409, SSK
    if (isAnchorDate(referenceDate, frequencyPattern)) {
      anchorDate = referenceDate;
      // END, CR00305409
    } else {
      // BEGIN, CR00304013, MR
      final PatternType patternType = frequencyPattern.getPatternType();

      if (FrequencyPattern.PatternType.kDaily.equals(patternType)) {
        anchorDate = getAnchorDateForDailyFrequencyPattern(referenceDate,
          frequencyPattern, true);

      } else if (FrequencyPattern.PatternType.kWeekly.equals(patternType)) {
        if (FrequencyPattern.kStartDayEachWeekPattern.equals(frequencyPattern)) {
          anchorDate = referenceDate;
        } else {
          anchorDate = getAnchorDateForWeeklyFrequencyPattern(referenceDate,
            frequencyPattern, true);
        }
      } else if (FrequencyPattern.PatternType.kMonthly.equals(patternType)) {

        // END, CR00304013
        anchorDate = getAnchorDateForMonthlyFrequencyPattern(referenceDate,
          frequencyPattern, true);
      } else {

        anchorDate = frequencyPattern.getPrevOccurrence(referenceDate);
      }
    }
    return anchorDate;
  }

  /**
   * {@inheritDoc}
   */
  public List<Date> getFrequencyOccurrencesStartingFromAnchorDate(
    final FrequencyPattern frequencyPattern, final Date endDate,
    final Date anchorDate) {

    final Date lastOccurrenceDate = endDate.addDays(1);

    final Date prevStartDate = frequencyPattern.getPrevOccurrence(anchorDate);

    final List<Date> occurrences = new ArrayList<Date>();

    if (FrequencyPattern.PatternType.kWeekly.equals(
      frequencyPattern.getPatternType())) {
      DateRange period = new DateRange(anchorDate, endDate);
      List<Date> weeklyFrequencyOccurrences = getWeeklyFrequencyOccurrences(
        frequencyPattern, period, anchorDate);

      for (final Date date : weeklyFrequencyOccurrences) {

        if (date.before(lastOccurrenceDate)) {
          occurrences.add(date);
        }

      }

    } else {
      Date[] dates = frequencyPattern.getAllOccurrences(
        prevStartDate.addDays(1), lastOccurrenceDate);

      for (final Date date : dates) {
        if (date.before(lastOccurrenceDate)) {
          occurrences.add(date);
        }

      }
    }

    return occurrences;
  }

  /**
   * {@inheritDoc}
   */
  public List<Date> getFrequencyOccurrencesWithinPeriod(
    final FrequencyPattern frequencyPattern, final DateRange period,
    final Date anchorDate) {

    final Date endDate = period.end().addDays(1);

    final Date prevStartDate = frequencyPattern.getPrevOccurrence(anchorDate);

    final List<Date> occurrences = new ArrayList<Date>();

    if (FrequencyPattern.PatternType.kWeekly.equals(
      frequencyPattern.getPatternType())) {
      final List<Date> weeklyFrequencyOccurrences = getWeeklyFrequencyOccurrences(
        frequencyPattern, period, anchorDate);

      for (final Date date : weeklyFrequencyOccurrences) {
        if (period.contains(date)) {
          occurrences.add(date);
        }
      }
    } else {
      final Date[] dates = frequencyPattern.getAllOccurrences(
        prevStartDate.addDays(1), endDate);

      for (final Date date : dates) {
        if (period.contains(date)) {
          occurrences.add(date);
        }

      }
    }
    return occurrences;
  }

  /**
   * List of dates for the given weekly pattern falling between start and end
   * date.
   *
   * @param referenceDate
   * Reference date to be considered for the date list generation.
   * @param startDate
   * Starting date for the list of dates
   * @param endDate
   * Ending date for the list of dates.
   * @param frequencyPattern
   * Weekly frequency pattern to be considered for date list
   * generation.
   *
   * @return List of dates generated for the week.
   */
  protected Date[] generateWeeklyFrequencyOccurrences(final Date referenceDate,
    final Date startDate, final Date endDate,
    final FrequencyPattern frequencyPattern) {

    Date weeklyReferenceStartDate = referenceDate;

    if (!frequencyPattern.kStartDayEachWeekPattern.equals(frequencyPattern)) {
      if (referenceDate.isZero() || referenceDate.after(startDate)) {
        weeklyReferenceStartDate = getWeeklyFirstOccurrenceDate(startDate,
          frequencyPattern);
      }
    }

    Date startPoint = startDate;
    final Date previousOccurrence = frequencyPattern.getPrevOccurrence(
      weeklyReferenceStartDate);

    boolean isValidWeeklyReferenceDate = false;

    if (!frequencyPattern.kStartDayEachWeekPattern.equals(frequencyPattern)) {
      isValidWeeklyReferenceDate = isValidWeeklyReferenceDate(
        weeklyReferenceStartDate, frequencyPattern);
    } else {
      isValidWeeklyReferenceDate = true;
    }

    if (isValidWeeklyReferenceDate) {
      startPoint = previousOccurrence.addDays(1);
    } else {
      startPoint = startDate;
    }
    Date[] dates = frequencyPattern.getAllOccurrences(startPoint,
      endDate.addDays(1));

    return dates;
  }

  /**
   * Calculates the anchor date for daily frequency pattern.For daily pattern,
   * if the reference day is week day then reference date is anchor date else
   * next/previous weekday is anchor date. E.g For each weekday pattern and
   * reference date 11-02-2011(Friday) then anchor date is 11-02-2011. For each
   * weekday pattern and reference date 12-02-2011(Saturday) then anchor date is
   * 14-02-2011(Monday).
   *
   * @param referenceDate
   * Reference date to calculate the anchor date.
   * @param frequencyPattern
   * Daily frequency pattern to calculate anchor date.
   * @param shouldConsiderPreviousDate
   * Indicates if previous date should be considered.
   *
   * @return Calculated daily anchor date.
   */
  protected Date getAnchorDateForDailyFrequencyPattern(
    final Date referenceDate, final FrequencyPattern frequencyPattern,
    final boolean shouldConsiderPreviousDate) {

    Date dailyAnchorDate = referenceDate;
    final DayOfWeekMask weekDaysOfFreq = frequencyPattern.getDayOfWeekMask();

    if (DayOfWeekMask.kEachday.equals(weekDaysOfFreq)) {
      dailyAnchorDate = referenceDate;
    } else {
      // DayOfWeekMask is WeekDay pattern
      while (!isWeekday(dailyAnchorDate)) {
        if (shouldConsiderPreviousDate) {
          dailyAnchorDate = dailyAnchorDate.addDays(-1);
        } else {
          dailyAnchorDate = dailyAnchorDate.addDays(1);
        }
      }

    }

    return dailyAnchorDate;
  }

  /**
   * Derives the anchor date for monthly frequency pattern.
   *
   * @param shouldPreviousDateConsidered
   * Is true if previous occurrences from start date should be
   * considered to find the anchor date, otherwise its false.
   *
   * @param referenceDate
   * Reference date from which anchor date is derived.
   * @param frequencyPattern
   * Monthly frequency pattern.
   * @param shouldConsiderPreviousDate
   * Indicates if previous should be considered.
   *
   * @return The calculated monthly anchor date.
   */
  protected Date getAnchorDateForMonthlyFrequencyPattern(
    final Date referenceDate, final FrequencyPattern frequencyPattern,
    final boolean shouldConsiderPreviousDate) {
    Date monthlyAnchorDate = referenceDate;

    if (shouldConsiderPreviousDate) {

      final Date nextDate = frequencyPattern.getNextOccurrence(referenceDate);

      if (referenceDate.equals(frequencyPattern.getPrevOccurrence(nextDate))) {
        monthlyAnchorDate = referenceDate;
      } else if (referenceDate.after(
        frequencyPattern.getPrevOccurrence(nextDate))) {
        monthlyAnchorDate = frequencyPattern.getPrevOccurrence(nextDate);
      } else {
        monthlyAnchorDate = frequencyPattern.getPrevOccurrence(referenceDate);
      }

    } else {
      final Date previousDate = frequencyPattern.getPrevOccurrence(
        referenceDate);

      if (referenceDate.equals(frequencyPattern.getNextOccurrence(previousDate))) {
        monthlyAnchorDate = referenceDate;
      } else if (referenceDate.before(
        frequencyPattern.getNextOccurrence(previousDate))) {
        monthlyAnchorDate = frequencyPattern.getNextOccurrence(previousDate);
      } else {

        monthlyAnchorDate = frequencyPattern.getNextOccurrence(referenceDate);
      }
    }
    return monthlyAnchorDate;
  }

  /**
   * Derives the anchor date for weekly frequency pattern.
   *
   * @param referenceDate
   * Reference date from which anchor date is derived.
   * @param frequencyPattern
   * Weekly frequency pattern to be considered.
   * @param forPerviousDate
   * Indicates if previous dates should be considered.
   *
   * @return Derived anchor date for weekly frequency pattern.
   */

  protected Date getAnchorDateForWeeklyFrequencyPattern(
    final Date referenceDate, final FrequencyPattern frequencyPattern,
    final boolean forPerviousDate) {

    // BEGIN, CR00304013, MR
    Date anchorDate = referenceDate;

    final String weekDaysOfFreq = frequencyPattern.getDayOfWeekMask().toString();
    final StringList weekDaysList = StringUtil.delimitedText2StringList(
      weekDaysOfFreq, CPMConstants.kCommaChar);

    // END, CR00304013
    final String firstDay = weekDaysList.get(0).toString();
    String lastDay = weekDaysList.get(weekDaysList.size() - 1).toString();

    if (weekDaysList.size() > 1) {
      lastDay = lastDay.split(CPMConstants.kSpace)[2];
      weekDaysList.set(weekDaysList.size() - 1, lastDay);
    }

    StringList daysOfTheWeekList = new StringList();

    for (final String weekDay : weekDaysList) {
      daysOfTheWeekList.add(weekDay.trim());
    }

    String[] weekdays = new DateFormatSymbols().getWeekdays();
    String patternFirstDay = CuramConst.gkEmpty;

    // If the first day is Sunday in the pattern.
    if (firstDay.equalsIgnoreCase(weekdays[1])) {
      patternFirstDay = firstDay;
    } else {
      patternFirstDay = lastDay;
    }

    int referenceDateDayOfWeek = anchorDate.getCalendar().get(
      Calendar.DAY_OF_WEEK);

    // if the referenceDate day matches the frequency pattern's days
    // then referenceDate is the anchor date
    if (daysOfTheWeekList.contains(weekdays[referenceDateDayOfWeek])) {
      return referenceDate;
    }

    while (!patternFirstDay.equalsIgnoreCase(weekdays[referenceDateDayOfWeek])) {

      if (daysOfTheWeekList.contains(weekdays[referenceDateDayOfWeek])) {
        return anchorDate;
      }
      if (forPerviousDate) {
        anchorDate = anchorDate.addDays(-1);
      } else {
        anchorDate = anchorDate.addDays(1);
      }
      referenceDateDayOfWeek = anchorDate.getCalendar().get(
        Calendar.DAY_OF_WEEK);

    }

    return anchorDate;
  }

  /**
   * Retrieves the days of the week from frequency pattern.
   *
   * @param frequencyPattern
   * Frequency Pattern.
   *
   * @return List of days associated in the pattern.
   */
  protected StringList getWeekDaysOfFrequency(
    final FrequencyPattern frequencyPattern) {

    // BEGIN, CR00304013, MR
    final String weekDaysOfFreq = frequencyPattern.getDayOfWeekMask().toString();
    final StringList weekDaysList = StringUtil.delimitedText2StringList(
      weekDaysOfFreq, CPMConstants.kCommaChar);

    // END, CR00304013
    String lastDay = weekDaysList.get(weekDaysList.size() - 1).toString();

    if (weekDaysList.size() > 1) {
      lastDay = lastDay.split(CPMConstants.kSpace)[2];
      weekDaysList.set(weekDaysList.size() - 1, lastDay);
    }
    StringList daysOfTheWeekList = new StringList();

    for (final String weekDay : weekDaysList) {
      daysOfTheWeekList.add(weekDay.trim());
    }

    return daysOfTheWeekList;

  }

  /**
   * Calculates the list of dates for given weekly frequency pattern. If the
   * start date falls on the first week day present in the weekly frequency
   * pattern, start date itself will be considered as first occurrence date. If
   * the start date falls on any other weekday, then the very next week day
   * which is same as the first week day selected in the weekly frequency
   * pattern is considered as the reference date. E.g if the pattern selected is
   * 'Recur every 2 week(s) on Thursday, Wednesday, Tuesday, and Monday' and if
   * the start date happens to be 20110215 which is Tuesday, then the first
   * occurrence date would be on next Monday - 20110221. But if the start date
   * is 20110214 which is Monday, that date itself will be the first occurrence
   * date.
   *
   *
   * @param startDate
   * Starting date which is considered for the generation of list of
   * dates.
   * @param frequencyPattern
   * Weekly frequency pattern to be considered.
   *
   * @return First occurrence date calculated from the start date for the given
   * weekly frequency pattern.
   */

  protected Date getWeeklyFirstOccurrenceDate(final Date startDate,
    final FrequencyPattern frequencyPattern) {

    // BEGIN, CR00304013, MR
    Date firstOccurrenceDate = startDate;

    final String weekDaysOfFreq = frequencyPattern.getDayOfWeekMask().toString();
    final StringList weekDaysList = StringUtil.delimitedText2StringList(
      weekDaysOfFreq, CPMConstants.kCommaChar);

    // END, CR00304013
    String firstDay = weekDaysList.get(0).toString();

    String[] weekdays = new DateFormatSymbols().getWeekdays();
    String patternFirstDay = CuramConst.gkEmpty;
    String lastDay = weekDaysList.get(weekDaysList.size() - 1).toString();

    // If the first day is Sunday in the pattern.
    if (firstDay.equalsIgnoreCase(weekdays[1])) {
      patternFirstDay = firstDay;
    } else {
      patternFirstDay = lastDay;
    }

    int weekdayOfStartDateInt = firstOccurrenceDate.getCalendar().get(
      Calendar.DAY_OF_WEEK);
    String weekDayOfStartDate = weekdays[weekdayOfStartDateInt];

    while (-1 == patternFirstDay.indexOf(weekDayOfStartDate)) {
      firstOccurrenceDate = firstOccurrenceDate.addDays(1);
      weekdayOfStartDateInt = firstOccurrenceDate.getCalendar().get(
        Calendar.DAY_OF_WEEK);
      weekDayOfStartDate = weekdays[weekdayOfStartDateInt];
    }
    return firstOccurrenceDate;
  }

  /**
   * Retrieves weekly frequency occurrences.
   *
   * @param frequencyPattern
   * Weekly Frequency Pattern
   * @param period
   * The period within which the frequency should be retrieved.
   * @param anchorDate
   * Anchor Date with respect to which the frequency occurrences is
   * calculated.
   *
   * @return Weekly frequency occurrences.
   */
  protected List<Date> getWeeklyFrequencyOccurrences(
    final FrequencyPattern frequencyPattern, final DateRange period,
    final Date anchorDate) {

    int frequencyInterval = frequencyPattern.getInterval();

    StringList weekDaysOfFrequencyPattern = new StringList();
    List<Date> frequencyOccurrences = new ArrayList<Date>();

    if (FrequencyPattern.kStartDayEachWeekPattern.equals(frequencyPattern)) {
      String[] weekdays = new DateFormatSymbols().getWeekdays();
      String anchorDay = weekdays[anchorDate.getCalendar().get(Calendar.DAY_OF_WEEK)];

      weekDaysOfFrequencyPattern.add(anchorDay);
    } else {

      weekDaysOfFrequencyPattern = getWeekDaysOfFrequency(frequencyPattern);
    }

    if (1 == weekDaysOfFrequencyPattern.size() || 1 == frequencyInterval) {
      Date endperiodDate = period.end().addDays(1);

      Date prevStartDate = frequencyPattern.getPrevOccurrence(anchorDate);

      Date[] dates = frequencyPattern.getAllOccurrences(
        prevStartDate.addDays(1), endperiodDate);

      frequencyOccurrences = Arrays.asList(dates);

    } else {
      Date nextOccurrences = anchorDate;

      frequencyOccurrences = new ArrayList<Date>();
      frequencyOccurrences.add(nextOccurrences);
      while (nextOccurrences.before(period.end().addDays(1))) {
        nextOccurrences = nextOccurrences.addDays(
          frequencyInterval * CPMConstants.kdaysInWeek);
        frequencyOccurrences.add(nextOccurrences);
      }

      frequencyOccurrences = getWeeklyFrequencyOccurrencesForMultipleInterval(
        frequencyOccurrences, frequencyPattern, anchorDate);

    }

    return frequencyOccurrences;

  }

  /**
   * Retrieves weekly frequency occurrences for frequency pattern having
   * multiple interval.
   *
   * @param singleIntervalFrequencyOccurrences
   * Frequency occurrences occurring at single interval.
   * @param frequencyPattern
   * Weekly Frequency Pattern.
   * @param anchorDate
   * Anchor Date with respect to which the frequency occurrences is
   * calculated.
   *
   * @return Weekly frequency occurrences.
   */
  protected List<Date> getWeeklyFrequencyOccurrencesForMultipleInterval(
    final List<Date> singleIntervalFrequencyOccurrences,
    final FrequencyPattern frequencyPattern, final Date anchorDate) {

    final List<Date> weeklyFrequencyOccurrences = new ArrayList<Date>();
    List<DateRange> weekDayIntervals = new ArrayList<DateRange>();
    final StringList weekDaysOfFrequencyPattern = getWeekDaysOfFrequency(
      frequencyPattern);

    if (weekDaysOfFrequencyPattern.size() > 1) {

      List<Integer> periodLengths = new ArrayList<Integer>();
      int periodLength = 0;

      // BEGIN, CR00305409, SSK
      weekDayIntervals = getWeekdayIntervals(singleIntervalFrequencyOccurrences,
        frequencyPattern, anchorDate);

      for (final DateRange weeklyperiod : weekDayIntervals) {
        periodLength = weeklyperiod.end().subtract(weeklyperiod.start());
        periodLengths.add(periodLength);
      }

      weeklyFrequencyOccurrences.add(anchorDate);
      for (Date date : singleIntervalFrequencyOccurrences) {
        for (int length : periodLengths) {
          date = date.addDays(length).addDays(1);
          weeklyFrequencyOccurrences.add(date);
        }
      }
    }
    // END, CR00305409
    return weeklyFrequencyOccurrences;
  }

  /**
   * Checks if the reference date provided is valid or not for the given weekly
   * pattern. If it happens to be on the first week day of the weekly pattern,
   * then it is a valid reference date. Otherwise it is not a valid reference
   * date.
   *
   * @param referenceDate
   * Reference date to check if the date is valid with respect to
   * frequency pattern.
   * @param frequencyPattern
   * Weekly frequency that needs to be considered.
   *
   * @return If the reference date provided is valid or not.
   */
  protected boolean isValidWeeklyReferenceDate(final Date referenceDate,
    final FrequencyPattern frequencyPattern) {

    // BEGIN, CR00304013, MR
    final int weekdayOfReferenceDateInt = referenceDate.getCalendar().get(
      Calendar.DAY_OF_WEEK);

    final String weekDaysOfFreq = frequencyPattern.getDayOfWeekMask().toString();
    final StringList weekDaysList = StringUtil.delimitedText2StringList(
      weekDaysOfFreq, CPMConstants.kCommaChar);

    // END, CR00304013
    String[] weekdays = new DateFormatSymbols().getWeekdays();
    String weekDayOfReferenceDate = weekdays[weekdayOfReferenceDateInt];

    boolean isValidReference = false;
    String lastDay = weekDaysList.get(weekDaysList.size() - 1).toString();

    // Check if first day in the pattern is Sunday, if so the reference date
    // should also be Sunday.
    String firstDay = weekDaysList.get(0).toString();

    if (firstDay.equalsIgnoreCase(weekdays[1])) {
      if (weekDayOfReferenceDate.equalsIgnoreCase(weekdays[1])) {
        isValidReference = true;
      }
    } else if (lastDay.indexOf(weekDayOfReferenceDate) != -1) {
      isValidReference = true;
    }
    return isValidReference;
  }

  /**
   * Checks if the date is weekday.
   *
   * @param referenceDate
   * Date to check if its week day.
   *
   * @return True if the date is a week day, false otherwise.
   */
  protected boolean isWeekday(final Date referenceDate) {
    int dayOfTheWeek = referenceDate.getCalendar().get(Calendar.DAY_OF_WEEK);

    if (Calendar.SUNDAY == dayOfTheWeek || Calendar.SATURDAY == dayOfTheWeek) {
      return false;
    }
    return true;
  }

  // BEGIN, CR00305409, SSK
  /**
   * Checks if the reference date is a anchor date or not with respect to the
   * frequency pattern.
   *
   * @param referenceDate
   * Reference date from which anchor date is derived.
   * @param frequencyPattern
   * Frequency pattern for deriving anchor date.
   *
   * @return True if reference date is valid anchor date with respect to the
   * frequency pattern otherwise false.
   */
  protected boolean isAnchorDate(final Date referenceDate,
    final FrequencyPattern frequencyPattern) {

    Date anchorDate = Date.kZeroDate;
    boolean isValidAnchorDate = false;
    final Date prevDate = frequencyPattern.getPrevOccurrence(referenceDate);
    final Date nextDate = frequencyPattern.getNextOccurrence(referenceDate);
    Date[] allOccurences;

    final PatternType patternType = frequencyPattern.getPatternType();

    if (FrequencyPattern.PatternType.kWeekly.equals(patternType)) {
      allOccurences = generateWeeklyFrequencyOccurrences(anchorDate, prevDate,
        nextDate, frequencyPattern);
    } else {
      allOccurences = frequencyPattern.getAllOccurrences(prevDate, nextDate);
    }
    if (Arrays.asList(allOccurences).contains(referenceDate)) {
      isValidAnchorDate = true;
    }

    return isValidAnchorDate;
  }

  /**
   * Retrieves weekday interval with respect to frequency pattern and anchor
   * date.For E.g Frequency pattern of every one week on Monday, Tuesday and
   * Friday and anchor date is ON Monday the weekday intervalS will be 1,3 and 3
   * that is the interval between Monday and Tuesday is 1 day like wise interval
   * between Tuesday and Friday is 3 days and interval between Friday and Monday
   * is 3 days.
   *
   * @param singleIntervalFrequencyOccurrences
   * Frequency occurrences occurring at single interval.
   * @param frequencyPattern
   * Weekly Frequency Pattern.
   * @param anchorDate
   * Anchor Date with respect to which the frequency occurrences is
   * calculated.
   *
   * @return Intervals between subsequent days in the frequency pattern.
   */
  protected List<DateRange> getWeekdayIntervals(
    final List<Date> singleIntervalFrequencyOccurrences,
    final FrequencyPattern frequencyPattern, final Date anchorDate) {
    final List<DateRange> weekDayIntervals = new ArrayList<DateRange>();
    final StringList weekDaysOfFrequencyPattern = getWeekDaysOfFrequency(
      frequencyPattern);
    Date periodStartDate = Date.kZeroDate;
    Date periodEndDate = Date.kZeroDate;
    DateRange weekPeriod = null;

    if (singleIntervalFrequencyOccurrences.size() > 2) {
      periodStartDate = singleIntervalFrequencyOccurrences.get(0);
      periodEndDate = singleIntervalFrequencyOccurrences.get(1);
      final String[] weekdays = new DateFormatSymbols().getWeekdays();
      Date weekPeriodStartDate = periodStartDate;
      Date weekPeriodEndDate = periodEndDate;

      while (weekPeriodStartDate.before(periodEndDate)) {

        weekPeriodEndDate = weekPeriodStartDate.addDays(1);
        int dayOfTheWeek = weekPeriodEndDate.getCalendar().get(
          Calendar.DAY_OF_WEEK);

        while (!weekDaysOfFrequencyPattern.contains(weekdays[dayOfTheWeek])) {
          weekPeriodEndDate = weekPeriodEndDate.addDays(1);
          dayOfTheWeek = weekPeriodEndDate.getCalendar().get(
            Calendar.DAY_OF_WEEK);
        }

        if (weekDayIntervals.isEmpty()) {
          weekPeriod = new DateRange(anchorDate, weekPeriodEndDate.addDays(-1));
        } else if (weekDayIntervals.size()
          == weekDaysOfFrequencyPattern.size() - 1) {
          weekPeriod = new DateRange(weekPeriodStartDate,
            periodEndDate.addDays(-1));
        } else {
          weekPeriod = new DateRange(weekPeriodStartDate,
            weekPeriodEndDate.addDays(-1));
        }

        weekDayIntervals.add(weekPeriod);
        if (weekDayIntervals.size() == weekDaysOfFrequencyPattern.size()) {
          break;
        }

        weekPeriodStartDate = weekPeriodEndDate;
      }
    }
    return weekDayIntervals;

  }

  // END, CR00305409
}
