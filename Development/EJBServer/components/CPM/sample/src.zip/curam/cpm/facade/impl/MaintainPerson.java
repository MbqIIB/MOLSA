/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.Calendar;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.REPRESENTATIVETYPE;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.REPRESENTATIVETYPEEntry;
import curam.codetable.impl.TRAININGPROGRAMPARTYSTATUSEntry;
import curam.codetable.impl.WAITLISTENTRYSTATUSEntry;
import curam.codetable.impl.WAITLISTTYPEEntry;
import curam.core.facade.struct.ConcernRoleWaitListDetailsList;
import curam.core.facade.struct.ConcernRoleWaitListStructList;
import curam.core.fact.AddressFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.EmploymentFactory;
import curam.core.fact.MaintainPersonFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.Employment;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EmploymentAndStatusReadMultiKey;
import curam.core.struct.EmploymentRMDtls;
import curam.core.struct.EmploymentReadMultiDtlsList;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PersonWaitListDetails;
import curam.core.struct.PersonWaitListStruct;
import curam.core.struct.PersonWaitListStructList;
import curam.cpm.facade.struct.CreatePersonDetails;
import curam.cpm.facade.struct.CreateUnassignedProviderMemberDetails;
import curam.cpm.facade.struct.PersonKey;
import curam.cpm.facade.struct.ProviderEmploymentHistory;
import curam.cpm.facade.struct.ProviderEmploymentHistoryList;
import curam.cpm.facade.struct.ProviderMembershipHistory;
import curam.cpm.facade.struct.ProviderMembershipHistoryList;
import curam.cpm.facade.struct.SearchPersonAndRepresentativeDetailsList;
import curam.cpm.facade.struct.SearchPersonDetails;
import curam.cpm.facade.struct.SearchPersonDetails1;
import curam.cpm.facade.struct.SearchPersonDetailsList;
import curam.cpm.facade.struct.SearchPersonKey;
import curam.cpm.facade.struct.SearchUnassignedProviderMemberDetailsList;
import curam.cpm.facade.struct.SearchUnassignedProviderMembers;
import curam.cpm.facade.struct.UnassignedMemberDetails;
import curam.cpm.facade.struct.ViewPersonDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.SearchUnassignedProviderMemberDetails;
import curam.message.CPMCOMMONMESSAGES;
import curam.message.PERSON;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.PERSONExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.Person;
import curam.provider.impl.PersonDAO;
import curam.provider.impl.ProviderMember;
import curam.provider.impl.ProviderMemberDAO;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.provider.impl.ProviderPartyCategoryEntry;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.training.impl.TrainingProgramMember;
import curam.training.impl.TrainingProgramMemberDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateTime;
import curam.util.type.DateTimeRange;
import curam.util.type.StringHelper;
import curam.waitlist.impl.WaitListEntryDAO;
import curam.waitlist.impl.WaitListEntryStatusHistory;


/**
 * Facade layer class having API for managing Person.
 *
 */
public abstract class MaintainPerson extends curam.cpm.facade.base.MaintainPerson {

  /**
   * Injecting the Data Access Object for Person class
   */
  @Inject
  protected PersonDAO personDAO;

  /**
   * Injecting the Data Access Object for Concern role class
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Injecting the Data Access Object for Provider Organization class
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Injecting the Data Access Object for Provider member class
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  /**
   * Injecting the Data Access Object for training program member.
   */
  @Inject
  protected TrainingProgramMemberDAO trainingProgramMemberDAO;

  // BEGIN, CR00228719, SK
  /**
   * Reference to provider offering DAO.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Reference to wait List Entry DAO.
   */
  @Inject
  protected WaitListEntryDAO waitListEntryDAO;
  // END, CR00228719

  /**
   * Default constructor for guice
   */
  public MaintainPerson() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates an individual person. If the person is not already registered with
   * the agency, then the system registers the person with the organization,
   * else if the person is not an active provider member or there is no provider
   * party record for the person, then the system creates the person with the
   * category as unassigned.
   *
   * @param createPersonDetails
   * Person register details.
   *
   * @return The provider party ID and other details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_NAME_NOT_ENTERED} -
   * If the name is not entered.
   */
  public PersonKey createPerson(CreatePersonDetails createPersonDetails)
    throws AppException, InformationalException {

    validateInsert(createPersonDetails);

    PersonKey personKey = new PersonKey();

    boolean createUnassignedRec = false;

    // If the person is not registered with the agency, then create a person
    // record.
    if (0 == createPersonDetails.searchConcernRoleID) {
      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      if (StringHelper.isEmpty(createPersonDetails.name)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new curam.util.exception.AppException(
            curam.message.CPMCOMMONMESSAGES.ERR_CPMCOMMONMSG_FV_NAME_NOT_ENTERED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            4);
      }

      RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = createPersonDetails.name;

      representativeRegistrationDetails.representativeRegistrationDetails.addressData = createPersonDetails.addressData;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = createPersonDetails.phoneCountryCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = createPersonDetails.phoneAreaCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = createPersonDetails.phoneNumber;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension = createPersonDetails.phoneExtension;
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();

      representativeRegistrationDetails.representativeDtls.representativeType = REPRESENTATIVETYPE.CONTACT;

      representativeObj.registerRepresentative(
        representativeRegistrationDetails);

      createPersonDetails.participantID = representativeRegistrationDetails.representativeDtls.concernRoleID;
      personKey.concernRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
    } else {

      createPersonDetails.participantID = createPersonDetails.searchConcernRoleID;
      personKey.concernRoleID = createPersonDetails.searchConcernRoleID;

      Set<ProviderMember> providerMemberSet = providerMemberDAO.listPersonMembershipHistory(
        createPersonDetails.searchConcernRoleID,
        ProviderPartyCategoryEntry.MEMBER, RECORDSTATUSEntry.NORMAL);

      // Check if there are any active provider members exist.
      for (ProviderMember providerMember : providerMemberSet) {
        if (providerMember.getDateRange().end().equals(Date.kZeroDate)) {
          createUnassignedRec = true;
          personKey.providerPartyID = providerMember.getID();
        }
      }
      // Retrieve provider party record with category unassigned if present
      // for the person.
      if (!createUnassignedRec) {
        Set<Person> personSet = personDAO.listPersonMembershipHistory(
          createPersonDetails.searchConcernRoleID,
          ProviderPartyCategoryEntry.UNASSIGNED, RECORDSTATUSEntry.NORMAL);

        // Check if there are any unassigned records exist for the person.
        for (Person person : personSet) {

          personKey.providerPartyID = person.getID();

          createUnassignedRec = true;
        }
      }
    }
    if (!createUnassignedRec) {
      curam.provider.impl.Person person = personDAO.newInstance();

      final curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
        createPersonDetails.participantID);

      person.setParty(concernRole);

      person.setDateRange(
        new DateRange(concernRole.getRegistrationDate(), Date.kZeroDate));
      
      // Create a provider party record for the person with category unassigned.
      person.insert();

      personKey.providerPartyID = person.getID();

      personKey.versionNo = person.getVersionNo();

    }

    return personKey;
  }

  /**
   * Cancels the person.
   *
   * @param personKey
   * Person key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PERSON#ERR_PERSON_XRV_ASSOCIATED_WITH_TRAINING}
   * - If an open or approved or waived training is associated with
   * the person.
   */
  public void deletePerson(PersonKey personKey) throws AppException,
      InformationalException {

    Set<TrainingProgramMember> trainingProgramMemberList = trainingProgramMemberDAO.retrieveMemberTrainingPrograms(
      TRAININGPROGRAMPARTYSTATUSEntry.CANCELED.getCode(),
      personKey.concernRoleID);

    // If an open approved or waived training is associated with the member the
    // person cannot be deleted.
    ConcernRole concernRole = concernRoleDAO.get(personKey.concernRoleID);

    for (TrainingProgramMember trainingProgramMember : trainingProgramMemberList) {
      if (TRAININGPROGRAMPARTYSTATUSEntry.APPROVED.equals(
        trainingProgramMember.getLifecycleState())
          || TRAININGPROGRAMPARTYSTATUSEntry.OPEN.equals(
            trainingProgramMember.getLifecycleState())
            || TRAININGPROGRAMPARTYSTATUSEntry.WAIVED.equals(
              trainingProgramMember.getLifecycleState())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PERSONExceptionCreator.ERR_PERSON_XRV_ASSOCIATED_WITH_TRAINING(
            concernRole.getName(),
            trainingProgramMember.getLifecycleState().getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
        ValidationHelper.failIfErrorsExist();
      }
    }

    Set<Person> personSet = personDAO.listPersonMembershipHistory(
      personKey.concernRoleID, ProviderPartyCategoryEntry.UNASSIGNED,
      RECORDSTATUSEntry.NORMAL);

    if (personSet.size() != 0) {

      for (Person person : personSet) {
        person.cancel(personKey.versionNo);
      }
    }
  }

  /**
   * Retrieves the list of person membership history details.
   *
   * @param personKey
   * The person key contains concern role ID.
   *
   * @return The list of provider membership history details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderMembershipHistoryList listPersonMembershipHistory(
    PersonKey personKey) throws AppException, InformationalException {

    ProviderMembershipHistoryList providerMembershipHistoryList = new ProviderMembershipHistoryList();

    // BEGIN, CR00128037, JSP
    Set<curam.provider.impl.ProviderMember> providerMemberList = providerMemberDAO.listPersonMembershipHistory(
      personKey.concernRoleID, ProviderPartyCategoryEntry.MEMBER,
      RECORDSTATUSEntry.NORMAL);

    // END, CR00128037

    for (ProviderMember providerMember : providerMemberList) {
      ProviderMembershipHistory providerMembershipHistory = new ProviderMembershipHistory();

      providerMembershipHistory.fromDate = providerMember.getDateRange().start();

      providerMembershipHistory.toDate = providerMember.getDateRange().end();

      providerMembershipHistory.providerName = providerOrganizationDAO.get(providerMember.getProviderOrganization().getID()).getName();

      providerMembershipHistory.role = providerMember.getType();

      providerMembershipHistory.status = providerMember.getLifecycleState().getCode();

      providerMembershipHistory.providerID = providerMember.getProviderOrganization().getID();

      providerMembershipHistory.concernRoleType = providerMember.getProviderOrganization().getConcernRoleType().getCode();

      providerMembershipHistoryList.historyDetails.addRef(
        providerMembershipHistory);
    }

    return providerMembershipHistoryList;
  }

  /**
   * Retrieves the list of person and representatives that satisfies the search
   * criteria.
   *
   * @param searchPersonKey
   * Contains search criteria.
   *
   * @return The list of person details that satisfies the search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PERSON#ERR_PERSON_FV_SEARCH_CRITERIA_NOT_ENTERED}
   * - If the person search criteria is not entered.
   * @deprecated Since Curam 6.0, this method has been replaced by {@link 
   * #searchPerson1()}. The new method returns the details like address line and 
   * city in the search results.
   */
  @Deprecated
  public SearchPersonDetailsList searchPerson(SearchPersonKey searchPersonKey)
    throws AppException, InformationalException {

    String searchPerson = searchPersonKey.searchKey.addressLine1.trim()
      + searchPersonKey.searchKey.firstName.trim()
      + searchPersonKey.searchKey.lastName.trim()
      + searchPersonKey.searchKey.referenceNo.trim();

    if (searchPerson.equals(GeneralConstants.kEmpty)
      && !searchPersonKey.searchKey.personWithTraining
      && !searchPersonKey.searchKey.personWithProviderMembership) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PERSONExceptionCreator.ERR_PERSON_FV_SEARCH_CRITERIA_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      // BEGIN CR00113459, NRV
      ValidationHelper.failIfErrorsExist();
      // END CR00113459
    }

    SearchPersonDetailsList personDetailsList = new SearchPersonDetailsList();

    // Retrieve the list of persons that satisfies the search criteria.
    curam.cpm.sl.entity.struct.SearchPersonDetailsList searchPersonDetailsList = personDAO.searchPersonByNameAndAddress(
      searchPersonKey.searchKey.referenceNo,
      searchPersonKey.searchKey.addressLine1,
      searchPersonKey.searchKey.firstName, searchPersonKey.searchKey.lastName,
      searchPersonKey.searchKey.personWithTraining,
      searchPersonKey.searchKey.personWithProviderMembership);

    for (int i = 0; i < searchPersonDetailsList.dtls.size(); i++) {
      SearchPersonDetails searchPersonDetails = new SearchPersonDetails();

      if (searchPersonKey.searchKey.personWithProviderMembership) {
        searchPersonDetails.providerMembership = PERSON.INF_PERSON_YES.getMessageText(
          TransactionInfo.getProgramLocale());
      } else {
        searchPersonDetails.providerMembership = PERSON.INF_PERSON_NO.getMessageText(
          TransactionInfo.getProgramLocale());
      }
      if (searchPersonKey.searchKey.personWithTraining) {
        searchPersonDetails.trainingPlan = PERSON.INF_PERSON_YES.getMessageText(
          TransactionInfo.getProgramLocale());
      } else {
        searchPersonDetails.trainingPlan = PERSON.INF_PERSON_NO.getMessageText(
          TransactionInfo.getProgramLocale());
      }
      searchPersonDetails.searchDetails = searchPersonDetailsList.dtls.item(i);
      personDetailsList.details.addRef(searchPersonDetails);

    }
    searchPersonDetailsList = personDAO.searchRepresentativeByNameAndAddress(
      searchPersonKey.searchKey.referenceNo,
      searchPersonKey.searchKey.addressLine1,
      searchPersonKey.searchKey.firstName, searchPersonKey.searchKey.lastName,
      searchPersonKey.searchKey.personWithTraining,
      searchPersonKey.searchKey.personWithProviderMembership);

    for (int i = 0; i < searchPersonDetailsList.dtls.size(); i++) {
      SearchPersonDetails searchPersonDetails = new SearchPersonDetails();

      if (searchPersonKey.searchKey.personWithProviderMembership) {
        searchPersonDetails.providerMembership = PERSON.INF_PERSON_YES.getMessageText(
          TransactionInfo.getProgramLocale());
      } else {
        searchPersonDetails.providerMembership = PERSON.INF_PERSON_NO.getMessageText(
          TransactionInfo.getProgramLocale());
      }
      if (searchPersonKey.searchKey.personWithTraining) {
        searchPersonDetails.trainingPlan = PERSON.INF_PERSON_YES.getMessageText(
          TransactionInfo.getProgramLocale());
      } else {
        searchPersonDetails.trainingPlan = PERSON.INF_PERSON_NO.getMessageText(
          TransactionInfo.getProgramLocale());
      }
      searchPersonDetails.searchDetails = searchPersonDetailsList.dtls.item(i);
      personDetailsList.details.addRef(searchPersonDetails);

    }
    return personDetailsList;
  }

  /**
   * Reads the person details. If exists, system retrieves the provider party
   * details of category 'unassigned'. If there is no unassigned provider party
   * record exists, then system retrieves the concern role details as person
   * details.
   *
   *
   * @param personKey
   * Contains person ID.
   *
   * @return The details of the person.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewPersonDetails viewPerson(PersonKey personKey) throws AppException,
      InformationalException {

    ViewPersonDetails viewPersonDetails = new ViewPersonDetails();

    Set<Person> personSet = personDAO.listPersonMembershipHistory(
      personKey.concernRoleID, ProviderPartyCategoryEntry.UNASSIGNED,
      RECORDSTATUSEntry.NORMAL);

    for (Person person : personSet) {

      viewPersonDetails.versionNo = person.getVersionNo();

      viewPersonDetails.providerPartyID = person.getID();

      viewPersonDetails.from = person.getDateRange().start();

      viewPersonDetails.name = person.getParty().getName();

      viewPersonDetails.concernRoleType = person.getParty().getConcernRoleType().getCode();

      viewPersonDetails.concernRoleID = person.getParty().getID();

    }

    ConcernRole concernRole = concernRoleDAO.get(personKey.concernRoleID);

    if (personSet.size() == 0) {

      viewPersonDetails.concernRoleID = personKey.concernRoleID;

      viewPersonDetails.concernRoleType = concernRole.getConcernRoleType().getCode();

      viewPersonDetails.from = concernRole.getRegistrationDate();

      viewPersonDetails.name = concernRole.getName();
    }

    viewPersonDetails.recordStatus = concernRole.getStatusCode().getCode();

    viewPersonDetails.pageContextDescription = concernRole.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + concernRole.getPrimaryAlternateID();

    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(viewPersonDetails.informationalMsgDtlsOpt);
    // END, CR00292696
    
    return viewPersonDetails;
  }

  // BEGIN, CR00246961, GP
  /**
   * Reads the person details. If exists, system retrieves the provider party
   * details of category 'unassigned'. If there is no unassigned provider party
   * record exists, then system retrieves the concern role details as person
   * details.
   *
   *
   * @param personKey
   * Contains person ID.
   *
   * @return The details of the person.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public UnassignedMemberDetails viewPersonDetails(final PersonKey personKey)
    throws AppException, InformationalException {

    UnassignedMemberDetails unassignedMemberDetails = new UnassignedMemberDetails();

    Set<Person> personSet = personDAO.listPersonMembershipHistory(
      personKey.concernRoleID, ProviderPartyCategoryEntry.UNASSIGNED,
      RECORDSTATUSEntry.NORMAL);

    for (Person person : personSet) {

      unassignedMemberDetails.versionNo = person.getVersionNo();

      unassignedMemberDetails.providerPartyID = person.getID();

      unassignedMemberDetails.from = person.getDateRange().start();

      unassignedMemberDetails.name = person.getParty().getName();

      unassignedMemberDetails.concernRoleType = person.getParty().getConcernRoleType().getCode();

      unassignedMemberDetails.concernRoleID = person.getParty().getID();
      unassignedMemberDetails.toDate = person.getDateRange().end();

    }

    ConcernRole concernRole = concernRoleDAO.get(personKey.concernRoleID);

    if (0 == personSet.size()) {

      unassignedMemberDetails.concernRoleID = personKey.concernRoleID;

      unassignedMemberDetails.concernRoleType = concernRole.getConcernRoleType().getCode();

      unassignedMemberDetails.from = concernRole.getRegistrationDate();

      unassignedMemberDetails.name = concernRole.getName();

      unassignedMemberDetails.toDate = concernRole.getEndDate();
    }

    unassignedMemberDetails.recordStatus = concernRole.getStatusCode().getCode();

    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(unassignedMemberDetails.informationalMsgDtlsOpt);
    // END, CR00292696

    return unassignedMemberDetails;
  }

  // END, CR00246961
  
  // BEGIN CR00118202, NRV
  /**
   * Retrieves the person employment history.
   *
   * @param personKey
   * Person key.
   *
   * @return The list of provider member employment details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public ProviderEmploymentHistoryList listPersonEmploymentHistory(
    PersonKey personKey) throws AppException, InformationalException {

    ProviderEmploymentHistoryList providerEmploymentHistoryList = new ProviderEmploymentHistoryList();
    Employment employmentObj = EmploymentFactory.newInstance();
    EmploymentAndStatusReadMultiKey employmentAndStatusReadMultiKey = new EmploymentAndStatusReadMultiKey();

    employmentAndStatusReadMultiKey.concernRoleID = personKey.concernRoleID;
    employmentAndStatusReadMultiKey.status = RECORDSTATUSEntry.NORMAL.getCode();
    EmploymentReadMultiDtlsList employmentReadMultiDtlsList = new EmploymentReadMultiDtlsList();

    employmentReadMultiDtlsList = employmentObj.searchActiveEmploymentsByConcernRole(
      employmentAndStatusReadMultiKey);

    EmploymentRMDtls employmentRMDtls = new EmploymentRMDtls();
    ProviderEmploymentHistory providerEmploymentHistory;

    for (int i = 0; i < employmentReadMultiDtlsList.dtls.size(); i++) {

      providerEmploymentHistory = new ProviderEmploymentHistory();
      employmentRMDtls.assign(employmentReadMultiDtlsList.dtls.item(i));

      providerEmploymentHistory.employerName = employmentRMDtls.employerName;
      providerEmploymentHistory.empFromDate = employmentRMDtls.fromDate;
      providerEmploymentHistory.empToDate = employmentRMDtls.toDate;
      providerEmploymentHistory.empOccupation = employmentRMDtls.occupationType;
      providerEmploymentHistory.empStatus = employmentRMDtls.status;
      providerEmploymentHistory.employerConcernRoleID = employmentRMDtls.employerConcernRoleID;
      providerEmploymentHistory.employerType = employmentRMDtls.employerType;

      providerEmploymentHistoryList.empHistoryDetails.addRef(
        providerEmploymentHistory);
    }

    return providerEmploymentHistoryList;

  }

  // END CR00118202

  // BEGIN, CR00205270, ASN
  /**
   * Retrieves the list of unassigned provider members that satisfies the search
   * criteria.
   *
   * @param searchPersonKey
   * Contains search criteria.
   *
   * @return The list of unassigned provider member details that satisfies the
   * search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link PERSON#ERR_PERSON_FV_SEARCH_CRITERIA_NOT_ENTERED} - If the
   * search criteria is not entered.
   */
  public SearchUnassignedProviderMemberDetailsList searchUnassignedProviderMember(
    final SearchPersonKey searchPersonKey) throws AppException,
      InformationalException {

    String searchPerson = searchPersonKey.searchKey.firstName.trim()
      + searchPersonKey.searchKey.lastName.trim()
      + searchPersonKey.searchKey.referenceNo.trim();

    if (searchPerson.equals(GeneralConstants.kEmpty)
      && !searchPersonKey.searchKey.personWithTraining) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PERSONExceptionCreator.ERR_PERSON_FV_SEARCH_CRITERIA_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);

      ValidationHelper.failIfErrorsExist();
    }

    SearchUnassignedProviderMemberDetailsList searchUnassignedProviderMemberDetailsList = new SearchUnassignedProviderMemberDetailsList();

    Set<SearchUnassignedProviderMemberDetails> searchUnassignedProviderMembers = personDAO.searchUnassignedProviderMember(
      searchPersonKey.searchKey.referenceNo,
      searchPersonKey.searchKey.firstName, searchPersonKey.searchKey.lastName,
      searchPersonKey.searchKey.personWithTraining);

    for (final SearchUnassignedProviderMemberDetails searchUnassignedProviderMemberDetails : searchUnassignedProviderMembers) {

      SearchUnassignedProviderMembers searchUnassignedProviderMember = new SearchUnassignedProviderMembers();

      searchUnassignedProviderMember.searchUnassignedProviderMemberDetails.startDate = searchUnassignedProviderMemberDetails.startDate;
      searchUnassignedProviderMember.searchUnassignedProviderMemberDetails.endDate = searchUnassignedProviderMemberDetails.endDate;
      searchUnassignedProviderMember.searchUnassignedProviderMemberDetails.status = searchUnassignedProviderMemberDetails.status;
      searchUnassignedProviderMember.searchUnassignedProviderMemberDetails.concernRoleName = searchUnassignedProviderMemberDetails.concernRoleName;
      searchUnassignedProviderMember.searchUnassignedProviderMemberDetails.concernRoleID = searchUnassignedProviderMemberDetails.concernRoleID;
      searchUnassignedProviderMember.searchUnassignedProviderMemberDetails.providerPartyID = searchUnassignedProviderMemberDetails.providerPartyID;
      searchUnassignedProviderMember.searchUnassignedProviderMemberDetails.versionNo = searchUnassignedProviderMemberDetails.versionNo;

      if (0 != searchUnassignedProviderMemberDetails.trainingProgramMemberID) {

        searchUnassignedProviderMember.trainingInd = true;

      } else {

        searchUnassignedProviderMember.trainingInd = false;
      }

      searchUnassignedProviderMemberDetailsList.searchUnassignedMembers.addRef(
        searchUnassignedProviderMember);

    }
    
    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(
      searchUnassignedProviderMemberDetailsList.informationalMsgDtlsOpt);
    // END, CR00292696
    
    return searchUnassignedProviderMemberDetailsList;
  }

  /**
   * Creates an unassigned provider member. If the person is not already
   * registered with the agency, then the system registers the person with the
   * organization, else if the person is not an active provider member or there
   * is no provider party record for the person, then the system creates the
   * person with the category as unassigned.
   *
   * @param createUnassignedProviderMemberDetails
   * Details required to create unassigned provider member.
   *
   * @return The provider party ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_NAME_NOT_ENTERED} -
   * If the name is not entered.
   */
  public PersonKey createUnassignedProviderMember(
    final CreateUnassignedProviderMemberDetails createUnassignedProviderMemberDetails)
    throws AppException, InformationalException {

    validateUnassignedProviderMemberDetails(
      createUnassignedProviderMemberDetails);

    PersonKey personKey = new PersonKey();

    if (0 == createUnassignedProviderMemberDetails.searchConcernRoleID) {
      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      if (StringHelper.isEmpty(createUnassignedProviderMemberDetails.name)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new curam.util.exception.AppException(
            curam.message.CPMCOMMONMESSAGES.ERR_CPMCOMMONMSG_FV_NAME_NOT_ENTERED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            3);
      }

      RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = createUnassignedProviderMemberDetails.name;

      representativeRegistrationDetails.representativeRegistrationDetails.addressData = createUnassignedProviderMemberDetails.addressData;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = createUnassignedProviderMemberDetails.phoneCountryCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = createUnassignedProviderMemberDetails.phoneAreaCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = createUnassignedProviderMemberDetails.phoneNumber;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension = createUnassignedProviderMemberDetails.phoneExtension;
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();

      representativeRegistrationDetails.representativeDtls.representativeType = REPRESENTATIVETYPEEntry.CONTACT.getCode();

      representativeObj.registerRepresentative(
        representativeRegistrationDetails);

      createUnassignedProviderMemberDetails.participantID = representativeRegistrationDetails.representativeDtls.concernRoleID;
      personKey.concernRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;

      Person person = personDAO.newInstance();

      final curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
        createUnassignedProviderMemberDetails.participantID);

      person.setParty(concernRole);

      person.setDateRange(
        new DateRange(createUnassignedProviderMemberDetails.fromDate,
        createUnassignedProviderMemberDetails.toDate));

      // Create a provider party record for the person with category unassigned.
      person.insert();

      personKey.providerPartyID = person.getID();

      personKey.versionNo = person.getVersionNo();
    } else {

      createUnassignedProviderMemberDetails.participantID = createUnassignedProviderMemberDetails.searchConcernRoleID;

      personKey.concernRoleID = createUnassignedProviderMemberDetails.searchConcernRoleID;

      Person person = personDAO.newInstance();

      final curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
        createUnassignedProviderMemberDetails.participantID);

      person.setParty(concernRole);
      person.setDateRange(
        new DateRange(createUnassignedProviderMemberDetails.fromDate,
        createUnassignedProviderMemberDetails.toDate));

      person.insert();

      personKey.providerPartyID = person.getID();

      personKey.versionNo = person.getVersionNo();

    }

    return personKey;
  }

  /**
   * Validates if both the person details and the representative details are
   * entered.
   *
   * @param createUnassignedProviderMemberDetails
   * Contains details of Unassigned provider member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_XRV_REGISTERED_PERSON_OR_REGISTRATION_DETAILS}
   * - If both registered person and registration details are entered.
   */
  protected void validateUnassignedProviderMemberDetails(
    final CreateUnassignedProviderMemberDetails createUnassignedProviderMemberDetails)
    throws AppException, InformationalException {

    StringBuffer representativeDetails = new StringBuffer();
    OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = createUnassignedProviderMemberDetails.addressData;
    curam.core.intf.Address addressObj = AddressFactory.newInstance();

    representativeDetails.append(createUnassignedProviderMemberDetails.name);

    if (!(addressObj.isEmpty(otherAddressData)).emptyInd) {

      addressObj.getAddressStrings(otherAddressData);
      representativeDetails.append(otherAddressData.addressData.trim());
    }

    representativeDetails.append(
      createUnassignedProviderMemberDetails.phoneAreaCode);
    representativeDetails.append(
      createUnassignedProviderMemberDetails.phoneCountryCode);
    representativeDetails.append(
      createUnassignedProviderMemberDetails.phoneExtension);
    representativeDetails.append(
      createUnassignedProviderMemberDetails.phoneNumber);

    if (0 != createUnassignedProviderMemberDetails.searchConcernRoleID
      && 0 != representativeDetails.toString().length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_REGISTERED_PERSON_OR_REGISTRATION_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }

  }

  // END, CR00205270
  /**
   * Validates if both the person details and the representative details are
   * entered.
   *
   * @param createPersonDetails
   * Create person details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_XRV_REGISTERED_PERSON_OR_REGISTRATION_DETAILS}
   * - If both registered person and registration details are entered.
   */
  // BEGIN, CR00177241, PM
  protected void validateInsert(CreatePersonDetails createPersonDetails)
    // END, CR00177241
    throws AppException, InformationalException {

    StringBuffer representativeDetails = new StringBuffer();
    OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = createPersonDetails.addressData;
    curam.core.intf.Address addressObj = AddressFactory.newInstance();

    representativeDetails.append(createPersonDetails.name);

    // BEGIN, CR00129731, SK
    if (!(addressObj.isEmpty(otherAddressData)).emptyInd) {
      // Concatenate all the input details
      addressObj.getAddressStrings(otherAddressData);
      representativeDetails.append(otherAddressData.addressData.trim());
    }
    // END, CR00129731

    representativeDetails.append(createPersonDetails.phoneAreaCode);
    representativeDetails.append(createPersonDetails.phoneCountryCode);
    representativeDetails.append(createPersonDetails.phoneExtension);
    representativeDetails.append(createPersonDetails.phoneNumber);

    // Check if the input details and search details are entered
    if (0 != createPersonDetails.searchConcernRoleID
      && 0 != representativeDetails.toString().length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_REGISTERED_PERSON_OR_REGISTRATION_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      ValidationHelper.failIfErrorsExist();
    }
  }

  // BEGIN, CR00284541, ZV
  // BEGIN, CR00228719, SK
  /**
   * Retrieves the list of all the wait list entries for a person.
   *
   * @param concernRoleKey
   * The concern role ID of the person.
   *
   * @return The list of all the wait list entries for a person.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, SP2 this method has been replaced by {@link 
   * #listWaitList()}. The new method returns the case name field instead of 
   * case type.
   */
  @Deprecated
  public ConcernRoleWaitListDetailsList listWaitListEntriesForPerson(
    final ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    ConcernRoleWaitListDetailsList listConcernRoleWaitListDetailsList = new ConcernRoleWaitListDetailsList();

    curam.core.intf.MaintainPerson maintainPersonObj = MaintainPersonFactory.newInstance();
    
    // BEGIN, CR00270741, GP
    PersonWaitListStructList personWaitListStructList = maintainPersonObj.listWaitList(
      concernRoleKey);
    
    for (final PersonWaitListStruct personWaitListStruct :  personWaitListStructList.details) {
      
      PersonWaitListDetails personWaitListDetails = new PersonWaitListDetails();

      personWaitListDetails.waitListDtls.caseID = personWaitListStruct.waitListDtls.caseID;
      personWaitListDetails.waitListDtls.caseParticipantRoleID = personWaitListStruct.waitListDtls.caseParticipantRoleID;
      personWaitListDetails.waitListDtls.caseReference = personWaitListStruct.waitListDtls.caseReference;
      personWaitListDetails.waitListDtls.caseTypeCode = personWaitListStruct.waitListDtls.caseTypeCode;
      personWaitListDetails.waitListDtls.comments = personWaitListStruct.waitListDtls.comments;
      personWaitListDetails.waitListDtls.priority = personWaitListStruct.waitListDtls.priority;
      personWaitListDetails.waitListDtls.removalReason = personWaitListStruct.waitListDtls.removalReason;
      personWaitListDetails.waitListDtls.status = personWaitListStruct.waitListDtls.status;
      personWaitListDetails.waitListDtls.type = personWaitListStruct.waitListDtls.type;
      personWaitListDetails.waitListDtls.createdDateTime = personWaitListStruct.waitListDtls.createdDateTime;
      personWaitListDetails.waitListDtls.expiryDate = personWaitListStruct.waitListDtls.expiryDate;
      personWaitListDetails.waitListDtls.position = personWaitListStruct.waitListDtls.position;
      personWaitListDetails.waitListDtls.resourceID = personWaitListStruct.waitListDtls.resourceID;
      personWaitListDetails.waitListDtls.reviewDate = personWaitListStruct.waitListDtls.reviewDate;
      personWaitListDetails.waitListDtls.versionNo = personWaitListStruct.waitListDtls.versionNo;
      personWaitListDetails.waitListDtls.waitListEntryID = personWaitListStruct.waitListDtls.waitListEntryID;
      personWaitListDetails.waitListDtls.waitListID = personWaitListStruct.waitListDtls.waitListID;
      
      ConcernRoleKey concernRoleKey1 = new ConcernRoleKey();

      concernRoleKey1.concernRoleID = personWaitListStruct.waitListDtls.resourceID;
      curam.core.intf.ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      if (personWaitListStruct.waitListDtls.type.equals(
        WAITLISTTYPEEntry.PROVIDER.getCode())) {
        personWaitListDetails.resource = concernRoleObj.readConcernRoleName(concernRoleKey1).concernRoleName;
      } else if (personWaitListStruct.waitListDtls.type.equals(
        WAITLISTTYPEEntry.PROVIDEROFFERING.getCode())) {
        curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
          personWaitListStruct.waitListDtls.resourceID);

        if (providerOffering != null) {
          personWaitListDetails.resource = providerOffering.getProvider().getName()
            + CuramConst.gkSpace + CPMConstants.kHypen + CuramConst.gkSpace
            + providerOffering.getServiceOffering().getName();

        }

      }
      personWaitListDetails.daysOnWaitList = getDaysOnWaitlist(
        waitListEntryDAO.get(personWaitListStruct.waitListDtls.waitListEntryID));
      
      listConcernRoleWaitListDetailsList.details.details.addRef(
        personWaitListDetails);
    }
    // END, CR00270741

    return listConcernRoleWaitListDetailsList;
  }

  // END, CR00284541

  /**
   * Gets the number of days the wait list entry is in Open state as of current
   * business day.
   *
   * @param waitListEntry
   * The wait list entry which is in open state.
   *
   * @return The number of days the wait list entry is in Open state as of
   * current business day.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected int getDaysOnWaitlist(
    final curam.waitlist.impl.WaitListEntry waitListEntry)
    throws InformationalException, AppException {

    DateTime waitListEntryCreatedDateTime = DateTime.kZeroDateTime;
    Set<WaitListEntryStatusHistory> waitListEntryStatusHistories = waitListEntry.getHistory();

    for (final WaitListEntryStatusHistory waitListEntryStatusHistory : waitListEntryStatusHistories) {
      if (waitListEntryStatusHistory.getStatus().equals(
        WAITLISTENTRYSTATUSEntry.OPEN)) {
        waitListEntryCreatedDateTime = waitListEntryStatusHistory.getChangeDateTime();
        break;
      }
    }

    int daysOnWaitList = 0;

    if (!waitListEntryCreatedDateTime.isZero()) {
      Calendar currentDateCalendar = Date.getCurrentDate().getCalendar();
      Calendar waitListEntryCreatedCalendar = waitListEntryCreatedDateTime.getCalendar();
      Date currentDate = Date.getFromJavaUtilDate(currentDateCalendar.getTime());
      Date waitListEntryCreatedDate = Date.getFromJavaUtilDate(
        waitListEntryCreatedCalendar.getTime());

      daysOnWaitList = currentDate.subtract(waitListEntryCreatedDate) + 1;

    }

    return daysOnWaitList;

  }

  // END, CR00227186
  
  /**
   * Retrieves the list of person and representatives that satisfies the search
   * criteria.
   *
   * @param searchPersonKey
   * Contains search criteria.
   *
   * @return The list of person details that satisfies the search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PERSON#ERR_PERSON_FV_SEARCH_CRITERIA_NOT_ENTERED}
   * - If the person search criteria is not entered.
   */
  public SearchPersonAndRepresentativeDetailsList searchPerson1(SearchPersonKey searchPersonKey)
    throws AppException, InformationalException {

    String searchPerson = searchPersonKey.searchKey.addressLine1.trim()
      + searchPersonKey.searchKey.firstName.trim()
      + searchPersonKey.searchKey.lastName.trim()
      + searchPersonKey.searchKey.referenceNo.trim();

    if (searchPerson.equals(GeneralConstants.kEmpty)
      && !searchPersonKey.searchKey.personWithTraining
      && !searchPersonKey.searchKey.personWithProviderMembership) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PERSONExceptionCreator.ERR_PERSON_FV_SEARCH_CRITERIA_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }

    SearchPersonAndRepresentativeDetailsList personDetailsList = new SearchPersonAndRepresentativeDetailsList();

    // Retrieve the list of persons that satisfies the search criteria.
    curam.cpm.sl.entity.struct.SearchPersonDetails1List searchPersonDetailsList = personDAO.searchPersonByNameAndAddress1(
      searchPersonKey.searchKey.referenceNo,
      searchPersonKey.searchKey.addressLine1,
      searchPersonKey.searchKey.firstName, searchPersonKey.searchKey.lastName,
      searchPersonKey.searchKey.personWithTraining,
      searchPersonKey.searchKey.personWithProviderMembership);

    for (int i = 0; i < searchPersonDetailsList.dtls.size(); i++) {
      SearchPersonDetails1 searchPersonDetails = new SearchPersonDetails1();

      if (searchPersonKey.searchKey.personWithProviderMembership) {
        searchPersonDetails.providerMembership = PERSON.INF_PERSON_YES.getMessageText(
          TransactionInfo.getProgramLocale());
      } else {
        searchPersonDetails.providerMembership = PERSON.INF_PERSON_NO.getMessageText(
          TransactionInfo.getProgramLocale());
      }
      if (searchPersonKey.searchKey.personWithTraining) {
        searchPersonDetails.trainingPlan = PERSON.INF_PERSON_YES.getMessageText(
          TransactionInfo.getProgramLocale());
      } else {
        searchPersonDetails.trainingPlan = PERSON.INF_PERSON_NO.getMessageText(
          TransactionInfo.getProgramLocale());
      }
      searchPersonDetails.searchDetails = searchPersonDetailsList.dtls.item(i);
      personDetailsList.personDetails.addRef(searchPersonDetails);

    }
    searchPersonDetailsList = personDAO.searchRepresentativeByNameAndAddress1(
      searchPersonKey.searchKey.referenceNo,
      searchPersonKey.searchKey.addressLine1,
      searchPersonKey.searchKey.firstName, searchPersonKey.searchKey.lastName,
      searchPersonKey.searchKey.personWithTraining,
      searchPersonKey.searchKey.personWithProviderMembership);

    for (int i = 0; i < searchPersonDetailsList.dtls.size(); i++) {
      SearchPersonDetails1 searchPersonDetails = new SearchPersonDetails1();

      if (searchPersonKey.searchKey.personWithProviderMembership) {
        searchPersonDetails.providerMembership = PERSON.INF_PERSON_YES.getMessageText(
          TransactionInfo.getProgramLocale());
      } else {
        searchPersonDetails.providerMembership = PERSON.INF_PERSON_NO.getMessageText(
          TransactionInfo.getProgramLocale());
      }
      if (searchPersonKey.searchKey.personWithTraining) {
        searchPersonDetails.trainingPlan = PERSON.INF_PERSON_YES.getMessageText(
          TransactionInfo.getProgramLocale());
      } else {
        searchPersonDetails.trainingPlan = PERSON.INF_PERSON_NO.getMessageText(
          TransactionInfo.getProgramLocale());
      }
      searchPersonDetails.searchDetails = searchPersonDetailsList.dtls.item(i);
      personDetailsList.personDetails.addRef(searchPersonDetails);
      ;

    }
    
    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(personDetailsList.informationalMsgDtlsOpt);
    // END, CR00292696
    
    return personDetailsList;
  }

  // BEGIN, CR00284541, ZV
  /**
   * Retrieves the list of all the wait list entries for a person.
   *
   * @param concernRoleKey
   * The concern role ID of the person.
   *
   * @return The list of all the wait list entries for a person.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ConcernRoleWaitListStructList listWaitList(ConcernRoleKey key)
    throws AppException, InformationalException {
    ConcernRoleWaitListStructList listConcernRoleWaitListDetailsList = new ConcernRoleWaitListStructList();

    curam.core.intf.MaintainPerson maintainPersonObj = MaintainPersonFactory.newInstance();
    
    PersonWaitListStructList personWaitListStructList = maintainPersonObj.listWaitList(
      key);
    
    for (final PersonWaitListStruct personWaitListStruct :  personWaitListStructList.details) {
      
      ConcernRoleKey concernRoleKey1 = new ConcernRoleKey();

      concernRoleKey1.concernRoleID = personWaitListStruct.waitListDtls.resourceID;
      curam.core.intf.ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      if (personWaitListStruct.waitListDtls.type.equals(
        WAITLISTTYPEEntry.PROVIDER.getCode())) {
        personWaitListStruct.resource = concernRoleObj.readConcernRoleName(concernRoleKey1).concernRoleName;
      } else if (personWaitListStruct.waitListDtls.type.equals(
        WAITLISTTYPEEntry.PROVIDEROFFERING.getCode())) {
        curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
          personWaitListStruct.waitListDtls.resourceID);

        if (providerOffering != null) {
          personWaitListStruct.resource = providerOffering.getProvider().getName()
            + CuramConst.gkSpace + CPMConstants.kHypen + CuramConst.gkSpace
            + providerOffering.getServiceOffering().getName();

        }

      }
      personWaitListStruct.daysOnWaitList = getDaysOnWaitlist(
        waitListEntryDAO.get(personWaitListStruct.waitListDtls.waitListEntryID));
      
      listConcernRoleWaitListDetailsList.details.details.addRef(
        personWaitListStruct);
    }

    return listConcernRoleWaitListDetailsList;
  }

  // END, CR00284541
 
  // BEGIN, CR00292696, IBM
  /**
   * Collects the list of informations from the informational manager and adds
   * them to the list parameter passed in.
   *
   * @param informationalMsgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList informationalMsgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }

  // END, CR00292696
 
}
