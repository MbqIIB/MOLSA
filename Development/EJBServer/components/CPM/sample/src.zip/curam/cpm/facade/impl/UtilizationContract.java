/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.CONTRACTSTATUS;
import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.contracts.impl.CPMContractDAO;
import curam.contracts.impl.ContractContact;
import curam.contracts.impl.ContractContactDAO;
import curam.contracts.impl.ContractServicesTypeEntry;
import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.ContractVersionDAO;
import curam.contracts.impl.ContractVersionProviderGroupAssociate;
import curam.contracts.impl.ContractVersionProviderGroupAssociateDAO;
import curam.contracts.impl.ContractVersionProviderOffering;
import curam.contracts.impl.ContractVersionProviderOfferingDAO;
import curam.contracts.impl.UtilizationContractDAO;
import curam.core.impl.CuramConst;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.cpm.facade.struct.AmendContractVersionKey;
import curam.cpm.facade.struct.ContractVersionInformationalsDtls;
import curam.cpm.facade.struct.DeleteContractVersionKey;
import curam.cpm.facade.struct.ProviderDetails;
import curam.cpm.facade.struct.ProviderDetailsList;
import curam.cpm.facade.struct.ProviderGroupAssociateDtls;
import curam.cpm.facade.struct.ProviderGroupAssociateTabbedList;
import curam.cpm.facade.struct.ProviderOfferingRateInformationalDtls;
import curam.cpm.facade.struct.ProviderOfferingTabbedList;
import curam.cpm.facade.struct.UtilizationContractDetails;
import curam.cpm.facade.struct.UtilizationContractProviderOfferingRateDetails;
import curam.cpm.facade.struct.ViewAmendmentHistoryDetails;
import curam.cpm.facade.struct.ViewAmendmentHistoryDetailsList;
import curam.cpm.facade.struct.ViewContractContactDetails;
import curam.cpm.facade.struct.ViewUtilizationContractDetails;
import curam.cpm.facade.struct.ViewUtilizationContractDetails1;
import curam.cpm.facade.struct.ViewUtilizationProviderOfferingDetails;
import curam.cpm.facade.struct.ViewUtilizationProviderOfferingDetailsList;
import curam.cpm.impl.CPMConstants;
import curam.cpm.message.impl.CONTRACTVERSIONExceptionCreator;
import curam.cpm.sl.entity.struct.ContractPOLinkKey;
import curam.cpm.sl.entity.struct.ContractVersionKey;
import curam.message.impl.PROVIDEROFFERINGRATEExceptionCreator;
import curam.provider.impl.LicenseTypeEntry;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderGroup;
import curam.provider.impl.ProviderGroupAssociate;
import curam.provider.impl.ProviderGroupAssociateDAO;
import curam.provider.impl.ProviderGroupDAO;
import curam.provider.impl.ProviderPartyDAO;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingRate;
import curam.providerservice.impl.ProviderOfferingRateDAO;
import curam.providerservice.impl.ProviderOfferingRateTypeEntry;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceRate;
import curam.serviceoffering.impl.ServiceRateDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.LifecycleHelper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.Money;
import curam.util.type.StringHelper;


/**
 * This is a facade class for all the functionality relating to utilization
 * contract.
 */
public abstract class UtilizationContract extends curam.cpm.facade.base.UtilizationContract {

  @Inject
  protected UtilizationContractDAO utilizationContractDAO;

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;

  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  @Inject
  protected ContractVersionProviderOfferingDAO contractVersionProviderOfferingDAO;

  @Inject
  protected ContractVersionProviderGroupAssociateDAO contractVersionProviderGroupAssociateDAO;

  @Inject
  protected CPMContractDAO cpmContractDAO;

  @Inject
  protected ContractVersionDAO contractVersionDAO;

  @Inject
  protected ContractContactDAO contractContactDAO;

  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  @Inject
  protected ProviderOfferingRateDAO providerOfferingRateDAO;

  @Inject
  protected ServiceRateDAO serviceRateDAO;

  protected static final String kEmptyString = "";

  /**
   * Constructor
   */
  public UtilizationContract() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a new version of the contract with the specified start date and
   * status {@linkplain curam.codetable.impl.CONTRACTSTATUSEntry#INEDIT}.
   * <p>
   * It also creates new copies of the utilization contract's related
   * {@linkplain curam.contracts.impl.ContractContact}s,
   * {@linkplain curam.contracts.impl.ContractVersionProviderOffering}s and
   * {@linkplain curam.contracts.impl.ContractVersionProviderGroupAssociate}s.
   *
   * @param key
   * The key containing contractID, version number and new start date.
   *
   * @return The informational message details list obtained during creation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMsgDtlsList preAmendUtilizationContract(
    final AmendContractVersionKey key) throws AppException,
      InformationalException {

    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // retrieve the entity
    final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
      key.contractVersionID);

    utilizationContract.preAmend(key.startDate);

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);

    }

    return informationalMsgDtlsList;
  }

  /**
   * Creates {@linkplain curam.contracts.impl.UtilizationContract}s for
   * {@linkplain curam.provider.impl.ProviderGroup}s.
   *
   * @param contractDetails
   * The contract details for the contract to be created
   * @param providerGroupAssociateTabbedList
   * The tabbed list of provider group associate identifiers.
   *
   * @return Details of contract versions created in the method.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ContractVersionInformationalsDtls createProviderGroupUtilizationContract(
    final UtilizationContractDetails contractDetails,
    final ProviderGroupAssociateTabbedList providerGroupAssociateTabbedList)
    throws AppException, InformationalException {

    final ProviderGroup providerGroup = providerGroupDAO.get(
      contractDetails.providerOrganizationConcernRoleID);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    // Create a new UtilizationContract and transfer facade struct attribute
    // values to it
    final curam.contracts.impl.UtilizationContract utilizationContract = setUtilizationContractFields(
      utilizationContractDAO.newInstance(), contractDetails);

    // Create a new CPMContract
    final curam.contracts.impl.CPMContract cpmContract = cpmContractDAO.newInstance();

    // BEGIN CR00092239, PDN
    cpmContract.insert(utilizationContract);
    utilizationContract.setCPMContract(cpmContract);
    // END CR00092239

    utilizationContract.setProviderOrganization(providerGroup);

    utilizationContract.insert();

    // Create ContractVersionProviderGroupAssociate records
    createContractVersionProviderGroupAssociates(utilizationContract,
      providerGroupAssociateTabbedList);

    // Contract Contact
    createContractContact(utilizationContract,
      contractDetails.contactConcernRoleID);

    // Return struct
    ContractVersionInformationalsDtls contractVersionInformationalsDtls = new ContractVersionInformationalsDtls();

    contractVersionInformationalsDtls.contractVersionKey.contractVersionID = utilizationContract.getID();

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      contractVersionInformationalsDtls.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    return contractVersionInformationalsDtls;
  }

  /**
   * Creates a new {@linkplain curam.contracts.impl.UtilizationContract}, and
   * entries for each ProviderOffering listed in the
   * {@linkplain curam.cpm.facade.struct.ProviderOfferingTabbedList}.
   *
   * @param contractDetails
   * The details of the contract to be created.
   * @param providerOfferingTabbedList
   * The tabbed list specifying the provider offerings to create
   * contracts.
   *
   * @return The details of the created contract versions.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public ContractVersionInformationalsDtls createProviderUtilizationContract(
    final UtilizationContractDetails contractDetails,
    final ProviderOfferingTabbedList providerOfferingTabbedList)
    throws AppException, InformationalException {

    // create a new entity instance and transfer facade struct attribute values
    // to it
    final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.newInstance();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final ContractVersionInformationalsDtls contractVersionInformationalsDtls = new ContractVersionInformationalsDtls();

    // Check if the Provider Offerings cover the period of the contract
    checkProviderOfferingsCoverContractPeriod(providerOfferingTabbedList,
      contractDetails);

    setUtilizationContractFields(utilizationContract, contractDetails);

    // Create a new CPMContract
    final curam.contracts.impl.CPMContract cpmContract = cpmContractDAO.newInstance();

    // BEGIN CR00092239, PDN
    utilizationContract.setProviderOrganization(
      providerDAO.get(contractDetails.providerOrganizationConcernRoleID));

    cpmContract.insert(utilizationContract);

    utilizationContract.setCPMContract(cpmContract);
    // END CR00092239

    utilizationContract.insert();

    // Contract Contact
    createContractContact(utilizationContract,
      contractDetails.contactConcernRoleID);

    // Create ContractVersionProviderOffering entries
    InformationalMsgDtlsList informationalMsgDtlsList = createContractVersionProviderOfferings(
      utilizationContract, providerOfferingTabbedList);

    contractVersionInformationalsDtls.informationalMsgDtlsList = informationalMsgDtlsList;

    // BEGIN, CR00090335, PDN
    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      contractVersionInformationalsDtls.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    // Return key
    contractVersionInformationalsDtls.contractVersionKey.contractVersionID = utilizationContract.getID();
    // END, CR00090335

    return contractVersionInformationalsDtls;
  }

  /**
   * Creates a {@linkplain curam.providerservice.impl.ProviderOfferingRate} for
   * the contract.
   *
   * @param details
   * The details of the contract to be created.
   * @param contractVersionKey
   * The key specifying the contract version.
   *
   * @return Details of the provider offerings created in the method.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderOfferingRateInformationalDtls createProviderOfferingRate(
    final UtilizationContractProviderOfferingRateDetails details,
    ContractVersionKey contractVersionKey) throws AppException,
      InformationalException {

    // Return struct
    ProviderOfferingRateInformationalDtls providerOfferingRateInformationalDtls = new ProviderOfferingRateInformationalDtls();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    ProviderOfferingRate providerOfferingRate = providerOfferingRateDAO.newInstance();

    curam.contracts.impl.UtilizationContract contract = utilizationContractDAO.get(
      contractVersionKey.contractVersionID);

    contract.reEdit(contract.getVersionNo());

    providerOfferingRate.setContractVersion(contract);

    // map details passed from client
    providerOfferingRate = setProviderOfferingRateForProvider(
      providerOfferingRate, details, contract.getDateRange().end());

    providerOfferingRate.insert();

    providerOfferingRateInformationalDtls.providerOfferingRateKey.providerOfferingRateID = providerOfferingRate.getID();

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      providerOfferingRateInformationalDtls.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    return providerOfferingRateInformationalDtls;
  }

  /**
   * Deletes a utilization contract from the system.
   *
   * @param key
   * The key specifying the contract version to be deleted.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deleteUtilizationContract(DeleteContractVersionKey key)
    throws AppException, InformationalException {

    // retrieve the entity
    final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
      key.contractVersionID);

    utilizationContract.delete(key.versionNo);
  }

  /**
   * Modifies provider group utilization contract and synchronizes the
   * contract's
   * {@linkplain curam.contracts.impl.ContractVersionProviderGroupAssociate}s
   * with the list of {@linkplain curam.provider.impl.ProviderGroupAssociate}s.
   *
   * @param contractDetails
   * The user-updated field values with only user modifiable fields
   * updated.
   * @param providerGroupAssociateTabbedList
   * The tabbed list specifying the
   * {@linkplain curam.provider.impl.ProviderGroupAssociate}.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyProviderGroupUtilizationContract(
    UtilizationContractDetails contractDetails,
    ProviderGroupAssociateTabbedList providerGroupAssociateTabbedList)
    throws AppException, InformationalException {

    // At least one Provider Group Associate must be on the contract
    if (providerGroupAssociateTabbedList.tabbedList.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_NO_PROVIDER_GROUP_ASSOCIATES_ON_CONTRACT(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }

    final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
      contractDetails.contractVersionID);

    utilizationContract.setName(contractDetails.name);
    utilizationContract.setContractServicesType(
      ContractServicesTypeEntry.get(contractDetails.contractServicesType));
    utilizationContract.setRequiredLicenseType(
      LicenseTypeEntry.get(contractDetails.requiredLicenseType));
    utilizationContract.setDateRange(
      new DateRange(contractDetails.startDate, contractDetails.endDate));
    utilizationContract.setComments(contractDetails.comments);

    utilizationContract.modify(contractDetails.versionNo);

    // Modify the list of ContractProviderGroupAssociate records
    modifyContractVersionProviderGroupAssociates(utilizationContract,
      providerGroupAssociateTabbedList);
  }

  /**
   * Modifies provider utilization contract.
   *
   * @param dtls
   * The user-updated field values, with only user-modifiable details
   * being updated.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyProviderUtilizationContract(
    final UtilizationContractDetails dtls) throws AppException,
      InformationalException {

    // retrieve the entity
    final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
      dtls.contractVersionID);

    utilizationContract.setName(dtls.name);
    utilizationContract.setContractServicesType(
      ContractServicesTypeEntry.get(dtls.contractServicesType));
    utilizationContract.setRequiredLicenseType(
      LicenseTypeEntry.get(dtls.requiredLicenseType));
    utilizationContract.setDateRange(
      new DateRange(dtls.startDate, dtls.endDate));
    utilizationContract.setComments(dtls.comments);

    utilizationContract.modify(dtls.versionNo);
  }

  /**
   * Lists the history of changes made to a contract version.
   *
   * @param key
   * The key specifying the contract version.
   *
   * @return List of amendment history entries for the contract version.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewAmendmentHistoryDetailsList listAmendmentHistory(
    ContractVersionKey key) throws AppException, InformationalException {

    ViewAmendmentHistoryDetailsList viewAmendmentHistoryDetailsList = new ViewAmendmentHistoryDetailsList();

    curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
      key.contractVersionID);

    viewAmendmentHistoryDetailsList.contractName = utilizationContract.getName();
    viewAmendmentHistoryDetailsList.referenceNumber = utilizationContract.getCPMContract().getReferenceNumber();

    ViewAmendmentHistoryDetails viewAmendmentHistoryDetails;

    // Get the set of ContractVersions relating to the current ContractVersion's
    // CPMContract
    for (final ContractVersion contractVersion : sortContractVersionHistory(
      contractVersionDAO.searchBy(
        utilizationContractDAO.get(key.contractVersionID).getCPMContract()))) {

      viewAmendmentHistoryDetails = new ViewAmendmentHistoryDetails();

      viewAmendmentHistoryDetails.contractVersionID = contractVersion.getID();
      viewAmendmentHistoryDetails.amendmentVersionNumber = contractVersion.getAmendmentVersionNumber();
      viewAmendmentHistoryDetails.status = contractVersion.getLifecycleState().getCode();
      viewAmendmentHistoryDetails.startDate = contractVersion.getDateRange().start();
      viewAmendmentHistoryDetails.endDate = contractVersion.getDateRange().end();
      viewAmendmentHistoryDetails.lastTransitionedBy = contractVersion.getLastTransitionedBy();

      viewAmendmentHistoryDetailsList.dtls.addRef(viewAmendmentHistoryDetails);
    }

    return viewAmendmentHistoryDetailsList;
  }

  /**
   * Sorts a set of contract version history records into a sorted list for
   * display.
   *
   * @param unsortedContractVersionHistory
   * The set of contract versions.
   *
   * @return Sorted list of contract version history records for display.
   */
  // BEGIN, CR00177241, PM
  protected List<ContractVersion> sortContractVersionHistory(
    // END, CR00177241
    final Set<ContractVersion> unsortedContractVersionHistory) {
    // Sort by name for display - using a list (instead of a set) in case there
    // are duplicate names.
    final List<ContractVersion> contractVersions = new ArrayList<ContractVersion>(
      unsortedContractVersionHistory);

    Collections.sort(contractVersions, new Comparator<ContractVersion>() {
      public int compare(final ContractVersion lhs, ContractVersion rhs) {

        return rhs.getDateRange().compareTo(lhs.getDateRange());

      }
    });
    return contractVersions;
  }

  /**
   * Returns a provider group utilization contract for a given contract version.
   *
   * @param key
   * The key specifying the contract version.
   *
   * @return Contract details for the provider group.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewUtilizationContractDetails viewProviderGroupUtilizationContract(
    ContractVersionKey key) throws AppException, InformationalException {

    ViewUtilizationContractDetails viewUtilizationContractDetails = this.viewProviderUtilizationContract(
      key);

    ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);

    // Get the current set of ServiceOfferings for the Contract
    Set<ServiceOffering> visibleServiceOfferingSet = new HashSet<ServiceOffering>();

    // Get list of Provider Offerings for Contract - Filter out duplicate
    // service names
    ViewUtilizationProviderOfferingDetails viewUtilizationProviderOfferingDetails;
    ServiceOffering serviceOffering;
    ProviderOfferingRate currentRate;

    viewUtilizationContractDetails.viewUtilizationProviderOfferingDetailsList = new ViewUtilizationProviderOfferingDetailsList();

    for (final curam.contracts.impl.ContractVersionProviderOffering contractProviderOfferingLink : contractVersionProviderOfferingDAO.searchBy(
      contractVersion)) {

      serviceOffering = contractProviderOfferingLink.getProviderOffering().getServiceOffering();

      if (contractProviderOfferingLink.getProviderOffering().getLifecycleState().equals(
        ProviderOfferingStatusEntry.APPROVED)) {

        if (!visibleServiceOfferingSet.contains(serviceOffering)) {

          visibleServiceOfferingSet.add(serviceOffering);

          viewUtilizationProviderOfferingDetails = new ViewUtilizationProviderOfferingDetails();

          viewUtilizationProviderOfferingDetails.contractVersionID = contractProviderOfferingLink.getContractVersion().getID();
          viewUtilizationProviderOfferingDetails.providerOfferingID = contractProviderOfferingLink.getProviderOffering().getID();
          viewUtilizationProviderOfferingDetails.contractProviderOfferingLinkID = contractProviderOfferingLink.getID();
          viewUtilizationProviderOfferingDetails.serviceOfferingID = contractProviderOfferingLink.getProviderOffering().getServiceOffering().getID();
          viewUtilizationProviderOfferingDetails.name = contractProviderOfferingLink.getProviderOffering().getServiceOffering().getName();
          viewUtilizationProviderOfferingDetails.status = contractProviderOfferingLink.getProviderOffering().getLifecycleState().getCode();

          // Get the current rate for the service
          currentRate = getCurrentRateForProviderOffering(
            contractProviderOfferingLink);

          viewUtilizationProviderOfferingDetails.fixedAmt = money2String(
            currentRate.getFixedAmount());
          viewUtilizationProviderOfferingDetails.maxAmt = money2String(
            currentRate.getMaxAmount());
          viewUtilizationProviderOfferingDetails.minAmt = money2String(
            currentRate.getMinAmount());

          viewUtilizationContractDetails.viewUtilizationProviderOfferingDetailsList.viewUtilizationProviderOfferingDetails.addRef(
            viewUtilizationProviderOfferingDetails);
        }
      }
    }

    ProviderGroupAssociateDtls providerGroupAssociateDtls;

    // Get list of Providers currently associated with the ContractVersion
    for (final ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : contractVersionProviderGroupAssociateDAO.searchBy(
      contractVersion)) {

      providerGroupAssociateDtls = new ProviderGroupAssociateDtls();

      providerGroupAssociateDtls.providerGroupAssociateID = contractVersionProviderGroupAssociate.getProviderGroupAssociate().getID();
      providerGroupAssociateDtls.providerGroupAssociateName = contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getName();
      providerGroupAssociateDtls.providerConcernRoleID = contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getID();

      viewUtilizationContractDetails.providerGroupAssociateDtls.addRef(
        providerGroupAssociateDtls);

    }

    // List of ProviderGroupAssociates in ProviderGroup: this list should be
    // filtered to include only ProviderGroupAssociates licensed to deliver the
    // services on the contract, if the contract has had services added to it.
    // If no services have been added to the contract, all
    // ProviderGroupAssociates will be listed.

    viewUtilizationContractDetails.providerDetailsList = getContractVersionProviderGroupAssociates(
      contractVersion);

    // Tabbed list of ProviderGroupAssociate IDs already on the contract
    viewUtilizationContractDetails.providerGroupAssociateTabbedList = getContractVersionProviderGroupAssociatesAsTabbedList(
      key.contractVersionID);

    return viewUtilizationContractDetails;
  }

  // BEGIN, CR00236379, SK
  /**
   * Returns a provider utilization contract for a given contract version.
   *
   * @param key
   * The key specifying the contract version.
   *
   * @return Utilization contract details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, this method has been replaced by
   * {@link cpm.facade.UtilizationContract#viewProviderUtilizationContractDetails()}
   * . The new method reads the utilization contract details for a
   * provider.
   *
   * This new method provides the implementation of the business
   * rule 'Start Date of a contract created by renewing a previous
   * contract cannot be directly edited by a user'.
   */
  @Deprecated
  // END, CR00236379
  public ViewUtilizationContractDetails viewProviderUtilizationContract(
    ContractVersionKey key) throws AppException, InformationalException {

    // return struct
    ViewUtilizationContractDetails viewUtilizationContractDetails = new ViewUtilizationContractDetails();

    // Read details
    final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
      key.contractVersionID);

    // Assign the details to return struct
    viewUtilizationContractDetails.viewUtilizationContractDtls.versionNo = utilizationContract.getVersionNo();
    viewUtilizationContractDetails.viewUtilizationContractDtls.contractVersionID = utilizationContract.getID();
    viewUtilizationContractDetails.viewUtilizationContractDtls.cpmContractID = utilizationContract.getCPMContract().getID();
    viewUtilizationContractDetails.viewUtilizationContractDtls.referenceNumber = utilizationContract.getCPMContract().getReferenceNumber();
    viewUtilizationContractDetails.viewUtilizationContractDtls.name = utilizationContract.getName();
    viewUtilizationContractDetails.viewUtilizationContractDtls.contractType = utilizationContract.getContractType().getCode();
    viewUtilizationContractDetails.viewUtilizationContractDtls.startDate = utilizationContract.getDateRange().start();
    viewUtilizationContractDetails.viewUtilizationContractDtls.endDate = utilizationContract.getDateRange().end();
    viewUtilizationContractDetails.viewUtilizationContractDtls.contractServicesType = utilizationContract.getContractServicesType().getCode();
    viewUtilizationContractDetails.viewUtilizationContractDtls.requiredLicenseType = utilizationContract.getRequiredLicenseType().getCode();
    viewUtilizationContractDetails.viewUtilizationContractDtls.createdBy = utilizationContract.getCreatedBy();
    viewUtilizationContractDetails.viewUtilizationContractDtls.generationReason = utilizationContract.getGenerationReason().getCode();
    viewUtilizationContractDetails.viewUtilizationContractDtls.generationDate = utilizationContract.getGenerationDate();
    viewUtilizationContractDetails.viewUtilizationContractDtls.comments = utilizationContract.getComments();
    viewUtilizationContractDetails.viewUtilizationContractDtls.terminationReason = utilizationContract.getTerminationReason().getCode();
    viewUtilizationContractDetails.viewUtilizationContractDtls.providerConcernRoleID = utilizationContract.getProviderOrganization().getID();

    if (utilizationContract.getTerminationDateTime() != null) {

      viewUtilizationContractDetails.viewUtilizationContractDtls.terminationDate = new Date(
        utilizationContract.getTerminationDateTime());
    }

    // Check Expiration
    if (Date.getCurrentDate().after(utilizationContract.getDateRange().end())
      && utilizationContract.getLifecycleState().equals(
        CONTRACTSTATUSEntry.LIVE)) {

      // If the contract end date has passed set contract status to 'Expired'
      viewUtilizationContractDetails.viewUtilizationContractDtls.status = CONTRACTSTATUS.EXPIRED;
    } else {

      viewUtilizationContractDetails.viewUtilizationContractDtls.status = utilizationContract.getLifecycleState().getCode();
    }

    ViewUtilizationProviderOfferingDetails viewUtilizationProviderOfferingDetails;
    ProviderOfferingRate currentRate;

    // Get list of Provider Offerings for Contract

    for (final curam.contracts.impl.ContractVersionProviderOffering contractProviderOfferingLink : contractVersionProviderOfferingDAO.searchBy(
      utilizationContract)) {

      viewUtilizationProviderOfferingDetails = new ViewUtilizationProviderOfferingDetails();

      viewUtilizationProviderOfferingDetails.contractVersionID = contractProviderOfferingLink.getContractVersion().getID();
      viewUtilizationProviderOfferingDetails.providerOfferingID = contractProviderOfferingLink.getProviderOffering().getID();
      viewUtilizationProviderOfferingDetails.contractProviderOfferingLinkID = contractProviderOfferingLink.getID();
      viewUtilizationProviderOfferingDetails.serviceOfferingID = contractProviderOfferingLink.getProviderOffering().getServiceOffering().getID();
      viewUtilizationProviderOfferingDetails.name = contractProviderOfferingLink.getProviderOffering().getServiceOffering().getName();
      viewUtilizationProviderOfferingDetails.status = contractProviderOfferingLink.getProviderOffering().getLifecycleState().getCode();

      // Get the current rate for the service
      currentRate = getCurrentRateForProviderOffering(
        contractProviderOfferingLink);

      viewUtilizationProviderOfferingDetails.fixedAmt = money2String(
        currentRate.getFixedAmount());
      viewUtilizationProviderOfferingDetails.maxAmt = money2String(
        currentRate.getMaxAmount());
      viewUtilizationProviderOfferingDetails.minAmt = money2String(
        currentRate.getMinAmount());

      viewUtilizationContractDetails.viewUtilizationProviderOfferingDetailsList.viewUtilizationProviderOfferingDetails.addRef(
        viewUtilizationProviderOfferingDetails);
    }

    // Contract Contacts
    ViewContractContactDetails viewContractContactDetails;

    for (final ContractContact contractContact : utilizationContract.getContacts()) {

      if (contractContact.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)) {

        viewContractContactDetails = new ViewContractContactDetails();

        viewContractContactDetails.contactConcernRoleID = contractContact.getProviderParty().getParty().getID();
        viewContractContactDetails.concernRoleType = contractContact.getProviderParty().getParty().getConcernRoleType().getCode();
        viewContractContactDetails.contactName = contractContact.getProviderParty().getParty().getName();
        viewContractContactDetails.contractContactID = contractContact.getID();
        viewContractContactDetails.contractVersionID = contractContact.getVersionNo();
        viewContractContactDetails.startDate = contractContact.getDateRange().start();
        viewContractContactDetails.endDate = contractContact.getDateRange().end();
        viewContractContactDetails.versionNo = contractContact.getVersionNo();

        viewUtilizationContractDetails.viewContractContactDetailsList.viewContractContactDetails.addRef(
          viewContractContactDetails);
      }
    }

    return viewUtilizationContractDetails;
  }

  // BEGIN, CR00236379, SK
  /**
   * Reads a provider utilization contract for a given contract version.
   *
   *
   * @param contractVersionKey
   * The key specifying the contract version.
   *
   * @return Utilization contract details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewUtilizationContractDetails1 viewProviderUtilizationContractDetails(
    ContractVersionKey contractVersionKey) throws AppException, InformationalException {

    ViewUtilizationContractDetails1 viewUtilizationContractDetails = new ViewUtilizationContractDetails1();

    final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
      contractVersionKey.contractVersionID);

    viewUtilizationContractDetails.details.viewUtilizationContractDtls.versionNo = utilizationContract.getVersionNo();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.contractVersionID = utilizationContract.getID();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.cpmContractID = utilizationContract.getCPMContract().getID();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.referenceNumber = utilizationContract.getCPMContract().getReferenceNumber();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.name = utilizationContract.getName();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.contractType = utilizationContract.getContractType().getCode();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.startDate = utilizationContract.getDateRange().start();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.endDate = utilizationContract.getDateRange().end();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.contractServicesType = utilizationContract.getContractServicesType().getCode();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.requiredLicenseType = utilizationContract.getRequiredLicenseType().getCode();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.createdBy = utilizationContract.getCreatedBy();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.generationReason = utilizationContract.getGenerationReason().getCode();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.generationDate = utilizationContract.getGenerationDate();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.comments = utilizationContract.getComments();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.terminationReason = utilizationContract.getTerminationReason().getCode();
    viewUtilizationContractDetails.details.viewUtilizationContractDtls.providerConcernRoleID = utilizationContract.getProviderOrganization().getID();

    if (utilizationContract.getTerminationDateTime() != null) {

      viewUtilizationContractDetails.details.viewUtilizationContractDtls.terminationDate = new Date(
        utilizationContract.getTerminationDateTime());
    }

    if (Date.getCurrentDate().after(utilizationContract.getDateRange().end())
      && utilizationContract.getLifecycleState().equals(
        CONTRACTSTATUSEntry.LIVE)) {

      // If the contract end date has passed set contract status to 'Expired'
      viewUtilizationContractDetails.details.viewUtilizationContractDtls.status = CONTRACTSTATUS.EXPIRED;
    } else {

      viewUtilizationContractDetails.details.viewUtilizationContractDtls.status = utilizationContract.getLifecycleState().getCode();
    }
    viewUtilizationContractDetails.renewedContractInd = utilizationContract.getRenewedContractInd();
    ViewUtilizationProviderOfferingDetails viewUtilizationProviderOfferingDetails;
    ProviderOfferingRate currentRate;

    // Get list of Provider Offerings for Contract

    for (final curam.contracts.impl.ContractVersionProviderOffering contractProviderOfferingLink : contractVersionProviderOfferingDAO.searchBy(
      utilizationContract)) {

      viewUtilizationProviderOfferingDetails = new ViewUtilizationProviderOfferingDetails();

      viewUtilizationProviderOfferingDetails.contractVersionID = contractProviderOfferingLink.getContractVersion().getID();
      viewUtilizationProviderOfferingDetails.providerOfferingID = contractProviderOfferingLink.getProviderOffering().getID();
      viewUtilizationProviderOfferingDetails.contractProviderOfferingLinkID = contractProviderOfferingLink.getID();
      viewUtilizationProviderOfferingDetails.serviceOfferingID = contractProviderOfferingLink.getProviderOffering().getServiceOffering().getID();
      viewUtilizationProviderOfferingDetails.name = contractProviderOfferingLink.getProviderOffering().getServiceOffering().getName();
      viewUtilizationProviderOfferingDetails.status = contractProviderOfferingLink.getProviderOffering().getLifecycleState().getCode();

      // Get the current rate for the service
      currentRate = getCurrentRateForProviderOffering(
        contractProviderOfferingLink);

      viewUtilizationProviderOfferingDetails.fixedAmt = money2String(
        currentRate.getFixedAmount());
      viewUtilizationProviderOfferingDetails.maxAmt = money2String(
        currentRate.getMaxAmount());
      viewUtilizationProviderOfferingDetails.minAmt = money2String(
        currentRate.getMinAmount());

      viewUtilizationContractDetails.details.viewUtilizationProviderOfferingDetailsList.viewUtilizationProviderOfferingDetails.addRef(
        viewUtilizationProviderOfferingDetails);
    }

    // Contract Contacts
    ViewContractContactDetails viewContractContactDetails;

    for (final ContractContact contractContact : utilizationContract.getContacts()) {

      if (contractContact.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)) {

        viewContractContactDetails = new ViewContractContactDetails();

        viewContractContactDetails.contactConcernRoleID = contractContact.getProviderParty().getParty().getID();
        viewContractContactDetails.concernRoleType = contractContact.getProviderParty().getParty().getConcernRoleType().getCode();
        viewContractContactDetails.contactName = contractContact.getProviderParty().getParty().getName();
        viewContractContactDetails.contractContactID = contractContact.getID();
        viewContractContactDetails.contractVersionID = contractContact.getVersionNo();
        viewContractContactDetails.startDate = contractContact.getDateRange().start();
        viewContractContactDetails.endDate = contractContact.getDateRange().end();
        viewContractContactDetails.versionNo = contractContact.getVersionNo();

        viewUtilizationContractDetails.details.viewContractContactDetailsList.viewContractContactDetails.addRef(
          viewContractContactDetails);
      }
    }

    return viewUtilizationContractDetails;
  }

  // END, CR00236379
  /**
   * Modifies the {@linkplain curam.providerservice.impl.ProviderOfferingRate}
   * for a provider contract.
   *
   * @param details
   * The modified details returned from the client.
   *
   * @return List of informational messages from the creation process.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMsgDtlsList modifyProviderOfferingRate(
    UtilizationContractProviderOfferingRateDetails details)
    throws AppException, InformationalException {

    // Return Struct
    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    ProviderOfferingRate providerOfferingRate = providerOfferingRateDAO.get(
      details.providerOfferingRateID);

    curam.contracts.impl.UtilizationContract contract = (curam.contracts.impl.UtilizationContract) providerOfferingRate.getContractVersion();

    contract.reEdit(contract.getVersionNo());

    providerOfferingRate = setProviderOfferingRateForProvider(
      providerOfferingRate, details,
      providerOfferingRate.getContractVersion().getDateRange().end());

    providerOfferingRate.modify(details.versionNo);

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);

    }

    return informationalMsgDtlsList;
  }

  /**
   * Transfers user modifiable field values to their equivalent fields on the
   * contract entity.
   * <p>
   * This does not set the contract's provider organization.
   *
   * @param utilizationContract
   * The contract onto which the user-updated values will be
   * transferred.
   * @param contractDetails
   * New field values to update the utilization contract with.
   *
   * @return Contract entity with user modifiable fields set.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected curam.contracts.impl.UtilizationContract setUtilizationContractFields(
    // END, CR00177241
    final curam.contracts.impl.UtilizationContract utilizationContract,
    final UtilizationContractDetails contractDetails) throws AppException,
      InformationalException {

    utilizationContract.setName(contractDetails.name);
    utilizationContract.setContractServicesType(
      ContractServicesTypeEntry.get(contractDetails.contractServicesType));
    utilizationContract.setRequiredLicenseType(
      LicenseTypeEntry.get(contractDetails.requiredLicenseType));
    utilizationContract.setDateRange(
      new DateRange(contractDetails.startDate, contractDetails.endDate));
    utilizationContract.setComments(contractDetails.comments);
    return utilizationContract;
  }

  /**
   * Creates a {@linkplain curam.contracts.impl.ContractVersionProviderOffering}
   * for each {@linkplain curam.providerservice.impl.ProviderOffering} ID in the
   * each {@linkplain curam.providerservice.ProviderOffering} identifier in the
   * providerOfferingTabbedList
   *
   * @param contract
   * The contract to be used for each provider offering.
   * @param providerOfferingTabbedList
   * The list of provider offerings to create contracts for.
   *
   * @return List of informational messages from the creation process.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected InformationalMsgDtlsList createContractVersionProviderOfferings(
    // END, CR00177241
    ContractVersion contract,
    ProviderOfferingTabbedList providerOfferingTabbedList)
    throws InformationalException {

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();
    InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

    if (providerOfferingTabbedList.tabbedList.length() > 0) {

      ContractVersionProviderOffering contractProviderOfferingLink;

      // for each providerOfferingID in the tabbed list of providerOfferingIDs
      for (final String providerOfferingID : StringUtil.tabText2StringList(providerOfferingTabbedList.tabbedList).items()) {

        ProviderOffering providerOffering = providerOfferingDAO.get(
          Long.parseLong(providerOfferingID.trim()));

        // Create a new ContractVersionProviderOffering entry
        contractProviderOfferingLink = contractVersionProviderOfferingDAO.newInstance();
        contractProviderOfferingLink.setContractVersion(contract);
        contractProviderOfferingLink.setProviderOffering(providerOffering);
        contractProviderOfferingLink.insert();
        contractProviderOfferingLink.createDefaultRate();

        informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();
        ;

        // Obtain the informational(s) to be returned to the client
        matchedResults = informationalManager.obtainInformationalAsString();

        informationalMsgDtls = new InformationalMsgDtls();

        for (int i = 0; i < matchedResults.length; i++) {

          informationalMsgDtls.informationMsgTxt = matchedResults[i];

          informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);

        }

        TransactionInfo.setInformationalManager();

      }
    }

    return informationalMsgDtlsList;
  }

  /**
   * Creates a {@linkplain curam.contracts.impl.ContractContact}.
   *
   * @param contract
   * The contract the contact is for.
   * @param contactProviderPartyID
   * The contact to be associated with the contract.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void createContractContact(final ContractVersion contract,
    // END, CR00177241
    long contactProviderPartyID) throws InformationalException {

    if (contactProviderPartyID != 0) {

      ContractContact contractContact = contractContactDAO.newInstance();

      contractContact.setContractVersion(contract);
      contractContact.setContactPeriod(contract.getDateRange());
      contractContact.setProviderParty(
        providerPartyDAO.get(contactProviderPartyID));

      contractContact.insert();
    }
  }

  /**
   * Creates a {@linkplain curam.contracts.impl.ContractPGAssociateLink} for
   * each {@linkplain curam.provider.impl.ProviderGroupAssociate} identifier in
   * the providerGroupAssociateTabbedList
   *
   * @param contract
   * The contract used to in the link creation.
   * @param providerGroupAssociateTabbedList
   * The list of provider group associates to have links created for.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void createContractVersionProviderGroupAssociates(
    // END, CR00177241
    final ContractVersion contract,
    final ProviderGroupAssociateTabbedList providerGroupAssociateTabbedList)
    throws InformationalException {

    // If no Providers were added to the contract
    if (providerGroupAssociateTabbedList.tabbedList.length() == 0) {

      // Raise informational message
      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      // BEGIN CR00090002, GP
      AppException appException = CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_NO_GROUPASSOCIATE();

      // END CR00090002
      informationalManager.addInformationalMsg(appException,
        curam.core.impl.CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning);
    } else {

      // Associate each ProviderGroupAssociate with the contract
      ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate;

      // for each providerGroupAssociateID in the tabbed list
      for (final String providerGroupAssociateID : StringUtil.tabText2StringList(providerGroupAssociateTabbedList.tabbedList).items()) {

        // Create a ContractPGAssociateLink
        contractVersionProviderGroupAssociate = contractVersionProviderGroupAssociateDAO.newInstance();
        contractVersionProviderGroupAssociate.setContractVersion(contract);
        contractVersionProviderGroupAssociate.setProviderGroupAssociate(
          providerGroupAssociateDAO.get(
            Long.parseLong(providerGroupAssociateID)));
        contractVersionProviderGroupAssociate.insert();
      }
    }
  }

  /**
   * Modifies the list of
   * {@linkplain curam.contracts.impl.ContractPGAssociateLink} according to the
   * list of {@linkplain curam.provider.impl.ProviderGroupAssociate} ID in the
   * providerGroupAssociateTabbedList
   *
   * @param contract
   * The contract used to in the link creation.
   * @param providerGroupAssociateTabbedList
   * The list of provider group associates to have links created for.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void modifyContractVersionProviderGroupAssociates(
    // END, CR00177241
    final ContractVersion contract,
    final ProviderGroupAssociateTabbedList providerGroupAssociateTabbedList)
    throws InformationalException {

    // Get the modified Set of ProviderGroupAssociates
    Set<ProviderGroupAssociate> newProviderGroupAssociateSet = new HashSet<ProviderGroupAssociate>();

    for (final String providerGroupAssociateID : StringUtil.tabText2StringList(providerGroupAssociateTabbedList.tabbedList).items()) {
      newProviderGroupAssociateSet.add(
        providerGroupAssociateDAO.get(Long.parseLong(providerGroupAssociateID)));
    }

    // Get the services that this contract covers
    Set<ContractVersionProviderOffering> contractVersionProviderOfferings = contractVersionProviderOfferingDAO.searchBy(
      contract);

    Set<Long> commonServiceOfferingIDs = new HashSet<Long>();

    for (ContractVersionProviderOffering contractVersionProviderOffering : contractVersionProviderOfferings) {
      Long serviceOfferingID = contractVersionProviderOffering.getProviderOffering().getServiceOffering().getID();

      if (!commonServiceOfferingIDs.contains(serviceOfferingID)) {
        commonServiceOfferingIDs.add(serviceOfferingID);
      }
    }

    // Delete the ContractPGAssociateLink for any ProviderGroupAssociates
    // removed from the contract
    for (final ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : contractVersionProviderGroupAssociateDAO.searchBy(
      contract)) {
      if (!newProviderGroupAssociateSet.contains(
        contractVersionProviderGroupAssociate.getProviderGroupAssociate())) {

        contractVersionProviderGroupAssociate.remove();

        // Need to remove the contract version provider offerings that were for
        // the removed Provider
        for (final ContractVersionProviderOffering contractVersionProviderOffering : contractVersionProviderOfferings) {
          if (contractVersionProviderOffering.getProviderOffering().getProvider().getID().equals(
            contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getID())) {
            contractVersionProviderOffering.remove();
          }
        }

      }
    }

    // Get the current set of ProviderGroupAssociates
    Set<ProviderGroupAssociate> currentProviderGroupAssociateSet = new HashSet<ProviderGroupAssociate>();

    for (final ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : contractVersionProviderGroupAssociateDAO.searchBy(
      contract)) {
      currentProviderGroupAssociateSet.add(
        contractVersionProviderGroupAssociate.getProviderGroupAssociate());
    }

    // Create a new ContractPGAssociateLink for any ProviderGroupAssociates
    // added to the contract
    ContractVersionProviderGroupAssociate newContractPGAssociateLink;

    for (final ProviderGroupAssociate providerGroupAssociate : newProviderGroupAssociateSet) {
      if (!currentProviderGroupAssociateSet.contains(providerGroupAssociate)) {
        newContractPGAssociateLink = contractVersionProviderGroupAssociateDAO.newInstance();
        newContractPGAssociateLink.setContractVersion(contract);
        newContractPGAssociateLink.setProviderGroupAssociate(
          providerGroupAssociate);
        newContractPGAssociateLink.insert();

        // Get all the APPROVED Provider Offerings for this Provider
        Set<curam.providerservice.impl.ProviderOffering> unModifiableProviderOfferings = newContractPGAssociateLink.getProviderGroupAssociate().getProvider().getProviderOfferings();
        Set<curam.providerservice.impl.ProviderOffering> providerOfferings = new HashSet<curam.providerservice.impl.ProviderOffering>();

        providerOfferings.addAll(unModifiableProviderOfferings);

        providerOfferings = LifecycleHelper.filter(providerOfferings,
          ProviderOfferingStatusEntry.APPROVED);

        // Need to find the Provider Offerings that are for this provider and
        // common service
        for (ProviderOffering providerOffering : providerOfferings) {
          for (Long serviceOfferingID : commonServiceOfferingIDs) {
            if (serviceOfferingID.equals(
              providerOffering.getServiceOffering().getID())) {
              // Create a ContractVersionProviderOffering for each of these
              ContractVersionProviderOffering contractVersionProviderOffering = contractVersionProviderOfferingDAO.newInstance();

              contractVersionProviderOffering.setContractVersion(contract);
              contractVersionProviderOffering.setProviderOffering(
                providerOffering);
              contractVersionProviderOffering.insert();

              // Also need to create a default contract rate for the Provider
              // Offering
              contractVersionProviderOffering.createDefaultRate();
            }
          }

        }
      }
    }
  }

  /**
   * @param contractVersion
   * Contains the contract version.
   *
   * @return List of {@linkplain curam.contracts.impl.ProviderGroupAssociate}s
   * in the {@linkplain curam.contracts.impl.ContractVersion}'s
   * ProviderGroup: this list should be filtered to include only
   * ProviderGroupAssociates licensed to deliver the services on the
   * contract, if the contract has had services added to it. If no
   * services have been added to the contract, all
   * ProviderGroupAssociates in the ProviderGroup will be listed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected ProviderDetailsList getContractVersionProviderGroupAssociates(
    // END, CR00177241
    final ContractVersion contractVersion) throws InformationalException {

    ProviderDetailsList providerDetailsList = new ProviderDetailsList();
    ProviderDetails providerDetails;

    ProviderGroup providerGroup = (ProviderGroup) contractVersion.getProviderOrganization();

    // Set of ServiceOfferings currently on the contract
    Set<ServiceOffering> contractedServices = new HashSet<ServiceOffering>();

    for (ProviderOffering providerOffering : contractVersion.getProviderOfferings()) {

      contractedServices.add(providerOffering.getServiceOffering());
    }

    if (contractedServices.size() > 0) {
      // Only add the ProviderGroupAssociate if it is approved to offer all
      // services on the contract
      for (final ProviderGroupAssociate providerGroupAssociate : providerGroupAssociateDAO.searchByProviderGroup(
        providerGroup)) {
        if (providerGroupAssociateIsApprovedToOfferAll(providerGroupAssociate,
          contractedServices)) {
          // BEGIN, CR00159227, ASN
          // Only those provider group associates who do not have an End Date
          // in the past or do not have a status of 'Canceled' must be available
          // for selection.
          if (!(RECORDSTATUSEntry.CANCELLED.equals(
            providerGroupAssociate.getLifecycleState()))
              && (!(providerGroupAssociate.getDateRange().endsInPast()))) {
            providerDetails = new ProviderDetails();
            // providerDetails.code =
            // providerGroupAssociate.getProvider().getID();
            providerDetails.code = providerGroupAssociate.getID();
            providerDetails.description = providerGroupAssociate.getProvider().getName();

            providerDetailsList.providerDetails.addRef(providerDetails);
          }
          // END, CR00159227
        }
      }
    } else {
      for (final ProviderGroupAssociate providerGroupAssociate : providerGroupAssociateDAO.searchByProviderGroup(
        providerGroup)) {
        // BEGIN, CR00159227, ASN
        // Only those provider group associates who do not have an End Date
        // in the past or do not have a status of 'Canceled' must be available
        // for selection.
        if (!(RECORDSTATUSEntry.CANCELLED.equals(
          providerGroupAssociate.getLifecycleState()))
            && (!(providerGroupAssociate.getDateRange().endsInPast()))) {
          providerDetails = new ProviderDetails();
          // providerDetails.code =
          // providerGroupAssociate.getProvider().getID();
          providerDetails.code = providerGroupAssociate.getID();
          providerDetails.description = providerGroupAssociate.getProvider().getName();

          providerDetailsList.providerDetails.addRef(providerDetails);
        }
        // END, CR00159227
      }
    }
    return providerDetailsList;
  }

  /**
   * @param contractVersionID
   * Contains the contract version id.
   *
   * @return Tabbed list of
   * {@linkplain curam.contracts.impl.ContractPGAssociateLink} IDs/names
   * for the contract.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected ProviderGroupAssociateTabbedList getContractVersionProviderGroupAssociatesAsTabbedList(
    // END, CR00177241
    final long contractVersionID) throws InformationalException {

    StringBuffer stringBuffer = new StringBuffer();

    for (final ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : contractVersionProviderGroupAssociateDAO.searchBy(
      utilizationContractDAO.get(contractVersionID))) {
      stringBuffer.append(
        Long.toString(
          contractVersionProviderGroupAssociate.getProviderGroupAssociate().getID())
            + CuramConst.gkTabDelimiter);
    }

    ProviderGroupAssociateTabbedList providerGroupAssociateTabbedList = new ProviderGroupAssociateTabbedList();

    providerGroupAssociateTabbedList.tabbedList = stringBuffer.toString();

    return providerGroupAssociateTabbedList;
  }

  /**
   * Assign attribute values for a provider to a
   * {@linkplain curam.providerservice.impl.ProviderOfferingRate}
   *
   * @param providerOfferingRate
   * Contains the provider offering rate.
   * @param details
   * Contains the provider offering rate details for utilization
   * contract.
   * @param contractEndDate
   * Contains the end date of the contract.
   *
   * @return Provider offering rate.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected ProviderOfferingRate setProviderOfferingRateForProvider(
    // END, CR00177241
    final ProviderOfferingRate providerOfferingRate,
    final UtilizationContractProviderOfferingRateDetails details,
    final Date contractEndDate) throws AppException, InformationalException {

    final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      details.providerOfferingID);

    return setProviderOfferingRateAttributes(providerOfferingRate, details,
      contractEndDate, providerOffering);
  }

  /**
   * Assign attribute values to a
   * {@linkplain curam.providerservice.impl.ProviderOfferingRate}
   *
   * @param ProviderOffering
   * Contains provider offering.
   *
   * @param providerOfferingRate
   * Contains the provider offering rate.
   * @param details
   * Contains the provider offering rate details for utilization
   * contract.
   * @param contractEndDate
   * Contains the end date of the contract.
   * @return Provider offering rate.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected ProviderOfferingRate setProviderOfferingRateAttributes(
    // END, CR00177241
    final ProviderOfferingRate providerOfferingRate,
    final UtilizationContractProviderOfferingRateDetails details,
    final Date contractEndDate, final ProviderOffering providerOffering)
    throws AppException, InformationalException {

    providerOfferingRate.setProviderOffering(providerOffering);
    providerOfferingRate.setComments(details.comments);
    providerOfferingRate.setDefaultRates();

    // Check if at least one of fixed or minimum or maximum rate is entered
    if ((details.fixedAmountString + details.maxAmountString + details.minAmountString).trim().length()
      == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDEROFFERINGRATEExceptionCreator.ERR_PROVIDEROFFERINGRATE_XFV_MANDATORY_FIELDS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else {
      // Try to set the provider offering rate
      try {
        if (!details.fixedAmountString.trim().equals(kEmptyString)) {
          providerOfferingRate.setFixedAmount(
            string2Money(details.fixedAmountString));
        }
      } catch (Exception e) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDEROFFERINGRATEExceptionCreator.ERR_PROVIDEROFFERINGRATE_FV_FIXED_AMT_INVALID_ENTRY(
            details.fixedAmountString),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
      try {
        if (!details.maxAmountString.trim().equals(kEmptyString)) {
          providerOfferingRate.setMaxAmount(
            string2Money(details.maxAmountString));
        }
      } catch (Exception e) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDEROFFERINGRATEExceptionCreator.ERR_PROVIDEROFFERINGRATE_FV_MAX_AMT_INVALID_ENTRY(
            details.maxAmountString),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
      try {
        if (!details.minAmountString.trim().equals(kEmptyString)) {
          providerOfferingRate.setMinAmount(
            string2Money(details.minAmountString));
        }
      } catch (Exception e) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDEROFFERINGRATEExceptionCreator.ERR_PROVIDEROFFERINGRATE_FV_MIN_AMT_INVALID_ENTRY(
            details.minAmountString),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

    // Check if fixed rate is entered with min or max rate
    if (details.fixedAmountString.trim().length() > 0
      && ((details.maxAmountString + details.minAmountString).trim().length()
        > 0)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDEROFFERINGRATEExceptionCreator.ERR_PROVIDEROFFERINGRATE_XFV_INCORRECT_FIELD_ENTRY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // If no end date was set, default to the contract's end date.
    Date endDate = details.endDate.equals(Date.kZeroDate)
      ? contractEndDate
      : details.endDate;

    providerOfferingRate.setDateRange(new DateRange(details.startDate, endDate));

    return providerOfferingRate;
  }

  /**
   * A helper method to convert a string to a money instance
   *
   * @param string
   * - A money value in string format.
   *
   * @return - Money value in the form of a money instance.
   */
  // BEGIN, CR00177241, PM
  protected Money string2Money(final String string) {
    // END, CR00177241

    return StringHelper.isEmpty(string) ? null : new Money(string);
  }

  /**
   * @param contractProviderOfferingLink
   * Contains the contract and ProviderOffering.
   *
   * @return the ProviderOfferingRate applicable at the time of viewing for the
   * specified ProviderOfferingLink. If the contract begins in the
   * future, the rate applicable on the first day of the contract will
   * be returned. If the contract has expired, the rate applicable on
   * the last day of the contract will be returned.<br/>
   * If no applicable ProviderOfferingRate is found, null will be
   * returned.
   */
  // BEGIN, CR00177241, PM
  protected ProviderOfferingRate getCurrentRateForProviderOffering(
    // END, CR00177241
    ContractVersionProviderOffering contractProviderOfferingLink) {

    ContractVersion contractVersion = contractProviderOfferingLink.getContractVersion();
    ProviderOffering providerOffering = contractProviderOfferingLink.getProviderOffering();
    ProviderOfferingRate rate = null;

    // Search for a contracted rate
    if (contractProviderOfferingLink.getContractVersion().getDateRange().endsInPast()) {

      rate = DateRange.latest(
        providerOfferingRateDAO.searchBy(providerOffering, contractVersion));
    } else if (contractProviderOfferingLink.getContractVersion().getDateRange().startsInFuture()) {

      rate = DateRange.earliest(
        providerOfferingRateDAO.searchBy(providerOffering, contractVersion));
    } else {

      for (ProviderOfferingRate providerOfferingRate : providerOfferingRateDAO.searchBy(
        providerOffering, contractVersion)) {

        if (providerOfferingRate.getDateRange().contains(Date.getCurrentDate())) {

          rate = providerOfferingRate;
          break;
        }
      }
    }

    // If no contracted rate was found, search for a non-contracted rate
    if (rate == null) {
      if (contractProviderOfferingLink.getContractVersion().getDateRange().endsInPast()) {

        rate = DateRange.latest(
          getNonContractedProviderOfferingRates(providerOffering,
          contractProviderOfferingLink.getContractVersion().getDateRange()));
      } else if (contractProviderOfferingLink.getContractVersion().getDateRange().startsInFuture()) {

        rate = DateRange.earliest(
          getNonContractedProviderOfferingRates(providerOffering,
          contractProviderOfferingLink.getContractVersion().getDateRange()));
      } else {

        for (ProviderOfferingRate providerOfferingRate : getNonContractedProviderOfferingRates(
          providerOffering,
          contractProviderOfferingLink.getContractVersion().getDateRange())) {

          if (providerOfferingRate.getDateRange().contains(
            Date.getCurrentDate())) {

            rate = providerOfferingRate;
            break;
          }
        }
      }
    }

    // If no non-contracted rate was found, fall back to the appropriate
    // ServiceRate
    if (rate == null) {

      ServiceRate serviceRate = null;

      if (contractProviderOfferingLink.getContractVersion().getDateRange().endsInPast()) {

        serviceRate = DateRange.latest(
          getServiceRates(providerOffering.getServiceOffering(),
          contractProviderOfferingLink.getContractVersion().getDateRange()));
      } else if (contractProviderOfferingLink.getContractVersion().getDateRange().startsInFuture()) {

        serviceRate = DateRange.earliest(
          getServiceRates(providerOffering.getServiceOffering(),
          contractProviderOfferingLink.getContractVersion().getDateRange()));
      } else {

        for (ServiceRate sRate : getServiceRates(
          providerOffering.getServiceOffering(),
          contractProviderOfferingLink.getContractVersion().getDateRange())) {

          if (sRate.getDateRange().contains(Date.getCurrentDate())) {

            serviceRate = sRate;
            break;
          }
        }
      }

      rate = providerOfferingRateDAO.newInstance();
      // Begin CR00096779, ABS
      if (serviceRate != null) {
        rate.setFixedAmount(serviceRate.getFixedAmount());
        rate.setMaxAmount(serviceRate.getMaxAmount());
        rate.setMinAmount(serviceRate.getMinAmount());
      }
      // End CR00096779
    }

    return rate;
  }

  /**
   * @param providerOffering
   * Contains provider offering.
   * @param dateRange
   * Contains date range.
   *
   * @return Set of {@linkplain curam.providerservice.impl.ProviderOfferingRate}
   * of type
   * {@linkplain curam.providerservice.impl.ProviderOfferingRateTypeEntry#NONCONTRACT}
   * whose date ranges overlap with the contract's date range.
   */
  // BEGIN, CR00177241, PM
  protected Set<ProviderOfferingRate> getNonContractedProviderOfferingRates(
    // END, CR00177241
    ProviderOffering providerOffering, DateRange dateRange) {

    Set<ProviderOfferingRate> rates = new HashSet<ProviderOfferingRate>();

    for (ProviderOfferingRate rate : providerOfferingRateDAO.searchBy(
      providerOffering)) {

      if (rate.getProviderOfferingRateType().equals(
        ProviderOfferingRateTypeEntry.NONCONTRACT)
          && rate.getDateRange().overlapsWith(dateRange)) {

        rates.add(rate);
      }
    }
    return rates;
  }

  /**
   * To retrieve service offering rate.
   *
   * @param serviceOffering
   * Contains Service Offering information.
   * @param dateRange
   * Contains date range.
   *
   * @return Set of ServiceOfferings for the specified date range.
   */
  // BEGIN, CR00177241, PM
  protected Set<ServiceRate> getServiceRates(ServiceOffering serviceOffering,
    // END, CR00177241
    DateRange dateRange) {

    Set<ServiceRate> rates = new HashSet<ServiceRate>();

    for (ServiceRate rate : serviceRateDAO.searchBy(serviceOffering)) {

      if (rate.getDateRange().overlapsWith(dateRange)) {

        rates.add(rate);
      }
    }
    return rates;
  }

  /**
   * A helper method to convert a money to a string instance
   *
   * @param money
   * - A money value in money format.
   *
   * @return - Money value in the form of a string instance.
   */
  // BEGIN, CR00177241, PM
  protected String money2String(final Money money) {
    // END, CR00177241
    return money.isNegative() ? StringHelper.EMPTY_STRING : money.toString();
  }

  /**
   * Modify the {@linkplain curam.providerservice.impl.ProviderOfferingRate} for
   * a provider group contract.
   *
   * @param details
   * The modified details for the provider offering rate.
   *
   * @return List of informational messages relating to the modification.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMsgDtlsList modifyProviderGroupProviderOfferingRate(
    UtilizationContractProviderOfferingRateDetails details)
    throws AppException, InformationalException {

    // Return struct
    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    ProviderOfferingRate providerOfferingRate = providerOfferingRateDAO.get(
      details.providerOfferingRateID);

    // Get the Service that this rate is for
    ServiceOffering serviceOffering = providerOfferingRate.getProviderOffering().getServiceOffering();

    curam.contracts.impl.UtilizationContract contract = (curam.contracts.impl.UtilizationContract) providerOfferingRate.getContractVersion();

    // Return the Contract to In edit
    contract.reEdit(contract.getVersionNo());

    // Modify all ProviderOfferingRates for the ServiceOffering
    for (ProviderOfferingRate rate : providerOfferingRateDAO.searchBy(contract)) {

      // Check if the rate is for the service and that the start and end date is
      // the same
      if (rate.getProviderOffering().getServiceOffering().equals(
        serviceOffering)
          && rate.getDateRange().compareTo(
            new DateRange(details.origStartDate, details.origEndDate))
              == 0) {

        rate = setProviderOfferingRateAttributes(rate, details,
          rate.getContractVersion().getDateRange().end(),
          rate.getProviderOffering());

        rate.modify(rate.getVersionNo());
      }
    }

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);

    }

    return informationalMsgDtlsList;

  }

  /**
   * Creates a {@linkplain curam.providerservice.impl.ProviderOfferingRate} for
   * the contract.
   *
   * @param details
   * The creation details returned from the client.
   * @param contractVersionKey
   * The key specifying the contract version.
   *
   * @return List of informational messages generated from the creation process.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMsgDtlsList createProviderGroupProviderOfferingRate(
    final UtilizationContractProviderOfferingRateDetails details,
    ContractVersionKey contractVersionKey) throws AppException,
      InformationalException {

    // Return struct
    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    ServiceOffering serviceOffering = providerOfferingDAO.get(details.providerOfferingID).getServiceOffering();

    curam.contracts.impl.UtilizationContract contract = utilizationContractDAO.get(
      contractVersionKey.contractVersionID);

    contract.reEdit(contract.getVersionNo());

    // Check if at least one of fixed or minimum or maximum rate is entered
    if ((details.fixedAmountString + details.maxAmountString + details.minAmountString).trim().length()
      == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDEROFFERINGRATEExceptionCreator.ERR_PROVIDEROFFERINGRATE_XFV_MANDATORY_FIELDS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    // Insert a ProviderOfferingRate for each ContractVersionProviderOffering
    // containing the ServiceOffering
    for (ContractVersionProviderOffering contractProviderOfferingLink : contractVersionProviderOfferingDAO.searchBy(
      contract)) {

      if (contractProviderOfferingLink.getProviderOffering().getServiceOffering().equals(
        serviceOffering)) {

        ProviderOfferingRate newRate = providerOfferingRateDAO.newInstance();

        newRate.setContractVersion(contract);

        newRate = setProviderOfferingRateAttributes(newRate, details,
          newRate.getContractVersion().getDateRange().end(),
          contractProviderOfferingLink.getProviderOffering());

        newRate.insert();
      }
    }

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);

    }

    return informationalMsgDtlsList;

  }

  /**
   * Delete all {@link curam.contracts.impl.ContractVersionProviderOffering}s
   * referencing the specified ServiceOffering and any related
   * {@linkplain curam.providerservice.impl.ProviderOfferingRate} records.
   *
   * @param key
   * The key specifying the contract provider offering link.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deleteServiceFromProviderGroupContract(final ContractPOLinkKey key)
    throws AppException, InformationalException {

    // Get the ContractVersion and ServiceOffering
    final ContractVersionProviderOffering contractProviderOfferingLink = contractVersionProviderOfferingDAO.get(
      key.contractPOLinkID);
    ContractVersion contract = contractProviderOfferingLink.getContractVersion();
    ServiceOffering serviceOffering = contractProviderOfferingLink.getProviderOffering().getServiceOffering();

    // For each of the contract's ContractVersionProviderOfferings
    for (ContractVersionProviderOffering link : contractVersionProviderOfferingDAO.searchBy(
      contract)) {

      // If the ContractVersionProviderOffering's ServiceOffering is the same as
      // the ServiceOffering to be removed from the contract

      if (link.getProviderOffering().getServiceOffering().equals(
        serviceOffering)) {

        // Remove any contracted ProviderOfferingRates
        for (ProviderOfferingRate rate : providerOfferingRateDAO.searchBy(
          link.getProviderOffering(), link.getContractVersion())) {

          rate.remove(rate.getVersionNo());
        }

        // Delete the ContractVersionProviderOffering
        link.remove();
      }
    }
  }

  /**
   * Checks provider Group Associate is approved to offer all services in the
   * list of services.
   *
   * @param providerGroupAssociate
   * Contains provider group associate information.
   * @param services
   * Contains services information.
   *
   * @return True if the ProviderGroupAssociate is approved to offer all
   * services in the list of services
   */
  // BEGIN, CR00177241, PM
  protected boolean providerGroupAssociateIsApprovedToOfferAll(
    // END, CR00177241
    ProviderGroupAssociate providerGroupAssociate,
    Set<ServiceOffering> services) {

    // Get the set of approved ServiceOfferings for the ProviderGroupAssociate
    Set<ServiceOffering> providerServices = new HashSet<ServiceOffering>();

    Set<curam.providerservice.impl.ProviderOffering> unModifiableProviderOfferings = providerGroupAssociate.getProvider().getProviderOfferings();
    Set<curam.providerservice.impl.ProviderOffering> providerOfferings = new HashSet<curam.providerservice.impl.ProviderOffering>();

    providerOfferings.addAll(unModifiableProviderOfferings);

    for (ProviderOffering providerOffering : LifecycleHelper.filter(
      providerOfferings, ProviderOfferingStatusEntry.APPROVED)) {

      providerServices.add(providerOffering.getServiceOffering());
    }

    return providerServices.containsAll(services);
  }

  /**
   * Checks if the supplied provider offerings cover the period of a contract
   *
   * @param providerOfferingTabbedList
   * Tabbed list of ProviderOffering IDs.
   *
   * @param contractDetails
   * Contract details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void checkProviderOfferingsCoverContractPeriod(
    // END, CR00177241
    final ProviderOfferingTabbedList providerOfferingTabbedList,
    final UtilizationContractDetails contractDetails) throws AppException,
      InformationalException {

    StringBuffer stringPOStartDatesErrorBuffer = new StringBuffer();
    StringBuffer stringPOEndDatesErrorBuffer = new StringBuffer();

    boolean providerOfferingsStartDatesError = false;
    boolean providerOfferingsEndDatesError = false;

    // Validation on provider offerings
    for (final String providerOfferingID : StringUtil.tabText2StringList(providerOfferingTabbedList.tabbedList).items()) {

      ProviderOffering providerOffering = providerOfferingDAO.get(
        new Long(providerOfferingID));

      if (providerOffering.getDateRange().start().after(
        contractDetails.startDate)) {

        providerOfferingsStartDatesError = true;
        String details = providerOffering.getServiceOffering().getName()
          + CuramConst.gkComma;

        stringPOStartDatesErrorBuffer.append(details);
      }

      if (!providerOffering.getDateRange().end().isZero()
        && providerOffering.getDateRange().end().before(contractDetails.endDate)) {

        providerOfferingsEndDatesError = true;
        String details = providerOffering.getServiceOffering().getName()
          + CuramConst.gkComma;

        stringPOEndDatesErrorBuffer.append(details);
      }

    }

    // Business rule: A contract cannot be generated if the start date of any
    // provider offering in the contract
    // is after the Start Date of the contract
    if (providerOfferingsStartDatesError) {
      stringPOStartDatesErrorBuffer = stringPOStartDatesErrorBuffer.replace(
        stringPOStartDatesErrorBuffer.length() - 1,
        stringPOStartDatesErrorBuffer.length(), "");

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_GROUP_PROVOFFERINGS_STARTDATES(
          stringPOStartDatesErrorBuffer.toString(), contractDetails.startDate),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }

    // Business rule: A contract cannot be generated if the End Date of any
    // provider offering in the contract
    // is before the End Date of the contract.
    if (providerOfferingsEndDatesError) {
      stringPOEndDatesErrorBuffer = stringPOEndDatesErrorBuffer.replace(
        stringPOEndDatesErrorBuffer.length() - 1,
        stringPOEndDatesErrorBuffer.length(), "");

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_GROUP_PROVOFFERINGS_ENDDATES(
          stringPOEndDatesErrorBuffer.toString(), contractDetails.endDate),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }

    // BEGIN, CR00090335, PDN
    // Business rule: Warn that the contract cannot be generated if no services
    // have been
    // added.
    if (StringUtil.tabText2StringList(providerOfferingTabbedList.tabbedList).size()
      == 0) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_NO_SERVICES(),
        curam.core.impl.CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }
    // END, CR00090335

  }

  // BEGIN, CR00198722, SSK
  /**
   * Returns a utilization contract provider offering for a given contract
   * version.
   *
   * @param contractVersion
   * The key specifying the contract version.
   *
   * @return Utilization contract provider offering details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewUtilizationProviderOfferingDetailsList viewUtilizationContractProviderOffering(
    ContractVersionKey contractVersion) throws AppException,
      InformationalException {
    final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
      contractVersion.contractVersionID);

    ViewUtilizationProviderOfferingDetails viewUtilizationProviderOfferingDetails;

    ViewUtilizationProviderOfferingDetailsList viewUtilizationProviderOfferingDetailsList = new ViewUtilizationProviderOfferingDetailsList();

    // For adding "All Contract Services" services
    viewUtilizationProviderOfferingDetails = new ViewUtilizationProviderOfferingDetails();
    viewUtilizationProviderOfferingDetails.serviceOfferingID = 1;
    viewUtilizationProviderOfferingDetails.name = CPMConstants.kAll;
    viewUtilizationProviderOfferingDetailsList.viewUtilizationProviderOfferingDetails.addRef(
      viewUtilizationProviderOfferingDetails);

    for (ContractVersionProviderOffering contractProviderOfferingLink : contractVersionProviderOfferingDAO.searchBy(
      utilizationContract)) {

      viewUtilizationProviderOfferingDetails = new ViewUtilizationProviderOfferingDetails();

      viewUtilizationProviderOfferingDetails.contractVersionID = contractProviderOfferingLink.getContractVersion().getID();
      viewUtilizationProviderOfferingDetails.providerOfferingID = contractProviderOfferingLink.getProviderOffering().getID();
      viewUtilizationProviderOfferingDetails.contractProviderOfferingLinkID = contractProviderOfferingLink.getID();
      viewUtilizationProviderOfferingDetails.serviceOfferingID = contractProviderOfferingLink.getProviderOffering().getServiceOffering().getID();
      viewUtilizationProviderOfferingDetails.name = contractProviderOfferingLink.getProviderOffering().getServiceOffering().getName();
      viewUtilizationProviderOfferingDetails.status = contractProviderOfferingLink.getProviderOffering().getLifecycleState().getCode();

      viewUtilizationProviderOfferingDetailsList.viewUtilizationProviderOfferingDetails.addRef(
        viewUtilizationProviderOfferingDetails);
    }

    return viewUtilizationProviderOfferingDetailsList;
  }

  // END, CR00198722
}
