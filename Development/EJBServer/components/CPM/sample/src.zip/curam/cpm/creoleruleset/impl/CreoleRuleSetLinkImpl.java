/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.creoleruleset.impl;


import java.util.List;

import com.google.inject.Inject;

import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CREOLERULESETTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.RELATEDTYPEEntry;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.CreoleRuleSetLinkDtls;
import curam.message.CREOLERULESETLINK;
import curam.message.impl.CREOLERULESETLINKExceptionCreator;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.DateRange;


/**
 * Standard implementation of
 * {@linkplain curam.cpm.creoleruleset.impl.CreoleRuleSetLink}.
 */

public class CreoleRuleSetLinkImpl extends SingleTableLogicallyDeleteableEntityImpl<CreoleRuleSetLinkDtls> implements
  CreoleRuleSetLink {

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<CreoleRuleSetLinkInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<CreoleRuleSetLinkCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<CreoleRuleSetLinkModifyEvents> modifyEventDispatcherFactory;

  /**
   * Event dispatcher for remove events.
   */
  @Inject
  protected EventDispatcherFactory<CreoleRuleSetLinkRemoveEvents> removeEventDispatcherFactory;
  // END, CR00235789

  /**
   * Reference to Creole Rule Set Link DAO
   */
  @Inject
  protected CreoleRuleSetLinkDAO creoleRuleSetLinkDAO;

  /**
   * Reference to service offering DAO.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Constructor for the class.
   */
  protected CreoleRuleSetLinkImpl() {// The no-arg constructor for use only by Guice.
  }

  /**
   * {@inheritDoc}
   */
  public void setRuleSetClassName(String ruleSetClassName) {
    getDtls().ruleSetClassName = ruleSetClassName;

  }

  /**
   * {@inheritDoc}
   */
  public void setCreoleRuleSetID(long creoleRuleSetID) {
    getDtls().creoleRuleSetID = creoleRuleSetID;

  }

  /**
   * Sets the date range for rule set associate.
   *
   * @param dateRange
   * Rule set association date range.
   *
   * <p>
   * It adds the following informational exceptions to the validation
   * helper when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XFV_START_DATE_LATER_THAN_END_DATE}
   * If end date is earlier than start date.</li>
   * </ul>
   */
  public void setDateRange(DateRange dateRange) {
    final ServiceOffering serviceOffering = getServiceOffering();

    getTransactionHelper().lock(serviceOffering);
    if (!dateRange.end().isZero()) {
      if (dateRange.start().after(dateRange.end())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CREOLERULESETLINKExceptionCreator.ERR_CREOLERULESETLINK_XFV_START_DATE_LATER_THAN_END_DATE(
            dateRange.start(), dateRange.end()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
    getDtls().startDate = dateRange.start();
    getDtls().endDate = dateRange.end();

    DateRange serviceOfferingDateRange = new DateRange(
      serviceOffering.getDateRange().start(),
      serviceOffering.getDateRange().end());

    if (serviceOfferingDateRange.isEnded() && !dateRange.isEnded()) {
      getDtls().startDate = dateRange.start();
      getDtls().endDate = serviceOfferingDateRange.end();
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedID(long relatedID) {
    getDtls().relatedID = relatedID;

  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedType(RELATEDTYPEEntry relatedType) {
    getDtls().relatedType = relatedType.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setRuleSetType(CREOLERULESETTYPEEntry ruleSetType) {
    getDtls().type = ruleSetType.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setDataStoreName(String ruleSetDataStoreName) {
    getDtls().creoleDataStoreName = ruleSetDataStoreName;

  }

  /**
   * {@inheritDoc}
   */
  public void setServiceOffering(ServiceOffering serviceOffering) {

    getDtls().relatedID = serviceOffering.getID();
  }

  /**
   * {@inheritDoc}
   */
  public long getCreoleRuleSetID() {
    return getDtls().creoleRuleSetID;
  }

  /**
   * {@inheritDoc}
   */
  public long getRelatedID() {
    return getDtls().relatedID;
  }

  /**
   * {@inheritDoc}
   */
  public RELATEDTYPEEntry getRelatedType() {
    return RELATEDTYPEEntry.get(getDtls().relatedType);
  }

  /**
   * {@inheritDoc}
   */
  public String getRuleSetClassName() {
    return getDtls().ruleSetClassName;
  }

  /**
   * {@inheritDoc}
   */
  public CREOLERULESETTYPEEntry getRuleSetType() {
    return CREOLERULESETTYPEEntry.get(getDtls().type);
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  /**
   * {@inheritDoc}
   */
  public void setComments(String value) {
    getDtls().comments = value;

  }

  /**
   * {@inheritDoc}
   */
  public String getDataStoreName() {
    return getDtls().creoleDataStoreName;
  }

  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {
    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * Validates that changes made to creole rule set entity on the database are
   * consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XRV_RULESET_START_DATE_LATER_THAN_SERVICE_OFFERING_START_DATE}
   * -If the rule set start date is before service offering start date.</li>
   * <li>
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XRV_RULESET_END_DATE_LATER_THAN_SERVICE_OFFERING_END_DATE}
   * -If the rule set end date is after service offering end date.</li>
   * </ul>
   */
  public void crossEntityValidation() {
    final ServiceOffering serviceOffering = getServiceOffering();

    getTransactionHelper().lock(serviceOffering);
    DateRange serviceOfferingDateRange = new DateRange(
      serviceOffering.getDateRange().start(),
      serviceOffering.getDateRange().end());

    if (!serviceOfferingDateRange.contains(getDateRange())) {

      if (getDateRange().startsBefore(serviceOfferingDateRange.start())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CREOLERULESETLINKExceptionCreator.ERR_CREOLERULESETLINK_XRV_RULESET_START_DATE_LATER_THAN_SERVICE_OFFERING_START_DATE(
            getDtls().startDate, serviceOffering.getDateRange().start()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      } else if (serviceOfferingDateRange.isEnded() && getDateRange().isEnded()
        && getDateRange().endsAfter(serviceOfferingDateRange.end())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CREOLERULESETLINKExceptionCreator.ERR_CREOLERULESETLINK_XRV_RULESET_END_DATE_LATER_THAN_SERVICE_OFFERING_END_DATE(
            getDtls().endDate, serviceOffering.getDateRange().end()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  }

  /**
   * Validates that changes made to creole rule set entity on the database are
   * consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XFV_RULESET_ENTERED_DATASTORE_NOT_ENTERED}
   * -If rule set entered but data store not entered.</li>
   * <li>
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XFV_DATASTORE_ENTERED_RULESET_NOT_ENTERED}
   * -If data store entered but rule set not entered.</li>
   * <li>
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_FV_START_DATE_EMPTY}
   * -If rule set entered but start date not entered.</li>
   * <li>
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XFV_RULESET_START_DATE_ENTERED_RULESET_DATASTORE_NOT_ENTERED}
   * -If rule set start date entered but rule set and data store name not
   * entered. selected. measure is not "Place".</li>
   * <li>
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XFV_RULESET_START_DATE_ENTERED_RULESET_NOT_ENTERED}
   * -If rule set start date entered but rule set not
   * entered.</li>
   * <li>
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XFV_RULESET_END_DATE_ENTERED_RULESET_STARTDATE_NOT_ENTERED}
   * -If rule set end date entered but rule set and start date not
   * entered.</li>
   * </ul>
   *
   */
  public void crossFieldValidation() {
    
    if ((CPMConstants.kEmptyString.equals(this.getDataStoreName()))
      && (0 != this.getCreoleRuleSetID())
      && CREOLERULESETTYPEEntry.SOESTIMATEDCOST.getCode().equals(
        this.getRuleSetType().getCode())) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CREOLERULESETLINKExceptionCreator.ERR_CREOLERULESETLINK_XFV_RULESET_ENTERED_DATASTORE_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    
    if ((0 == this.getCreoleRuleSetID())
      && (!(CPMConstants.kEmptyString.equals(this.getDataStoreName())))
      && CREOLERULESETTYPEEntry.SOESTIMATEDCOST.getCode().equals(
        this.getRuleSetType().getCode())) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CREOLERULESETLINKExceptionCreator.ERR_CREOLERULESETLINK_XFV_DATASTORE_ENTERED_RULESET_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (getDtls().startDate.isZero() && 0 != getDtls().creoleRuleSetID) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CREOLERULESETLINKExceptionCreator.ERR_CREOLERULESETLINK_FV_START_DATE_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (!getDtls().startDate.isZero() && getDtls().creoleRuleSetID == 0
      && CPMConstants.kEmptyString.equals(getDtls().creoleDataStoreName)
      && CREOLERULESETTYPEEntry.SOESTIMATEDCOST.getCode().equals(
      this.getRuleSetType().getCode())) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CREOLERULESETLINKExceptionCreator.ERR_CREOLERULESETLINK_XFV_RULESET_START_DATE_ENTERED_RULESET_DATASTORE_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    
    }

    if (!getDtls().endDate.isZero() && 0 == getDtls().creoleRuleSetID
      && CPMConstants.kEmptyString.equals(getDtls().creoleDataStoreName)
      && CREOLERULESETTYPEEntry.SOESTIMATEDCOST.getCode().equals(
      this.getRuleSetType().getCode())) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CREOLERULESETLINKExceptionCreator.ERR_CREOLERULESETLINK_XFV_RULESET_END_DATE_ENTERED_RULESET_DATASTORE_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// No implementation required.
  }

  /**
   * Creates a new rule set association.
   *
   * @throws InformationalException
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XRV_RULE_SET_ALREADY_EXISTS}
   * If record is already exists.
   */
  @Override
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    insertEventDispatcherFactory.get(CreoleRuleSetLinkInsertEvents.class).preInsert(
      this);
    // END, CR00235789
    try {
      validatedNewRuleSet();
    } catch (AppException appException) {
      ValidationHelper.addValidationError(appException);
    }
    super.insert();
    // BEGIN, CR00235789, AK
    insertEventDispatcherFactory.get(CreoleRuleSetLinkInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * Modifies the Rule set association.
   *
   * @throws InformationalException
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XRV_ASSOCIATION_IS_NOT_ACTIVE_CANNOT_BE_MODIFIED}
   * If record is already canceled.
   * @throws InformationalException
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XRV_RULE_SET_ALREADY_EXISTS}
   * If record is already exists.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    modifyEventDispatcherFactory.get(CreoleRuleSetLinkModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789
    
    if (getDtls().recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CREOLERULESETLINKExceptionCreator.ERR_CREOLERULESETLINK_XRV_ASSOCIATION_IS_NOT_ACTIVE_CANNOT_BE_MODIFIED(
          RECORDSTATUSEntry.get(getDtls().recordStatus).getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    ValidationHelper.failIfErrorsExist();

    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    modifyEventDispatcherFactory.get(CreoleRuleSetLinkModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Deletes the Rule set association.
   *
   * @throws InformationalException
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XRV_ASSOCIATION_IS_NOT_ACTIVE_CANNOT_BE_DELETED}
   * If record is already canceled.
   */
  @Override
  public void cancel(int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    cancelEventDispatcherFactory.get(CreoleRuleSetLinkCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789
    
    if (getDtls().recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CREOLERULESETLINKExceptionCreator.ERR_CREOLERULESETLINK_XRV_ASSOCIATION_IS_NOT_ACTIVE_CANNOT_BE_DELETED(
          RECORDSTATUSEntry.get(getDtls().recordStatus).getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    ValidationHelper.failIfErrorsExist();
    super.cancel(versionNo);

    // BEGIN, CR00235789, AK
    cancelEventDispatcherFactory.get(CreoleRuleSetLinkCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */

  @Override
  public void remove(final Integer versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    removeEventDispatcherFactory.get(CreoleRuleSetLinkRemoveEvents.class).preRemove(
      this, versionNo);
    // END, CR00235789
    super.remove(versionNo);
    // BEGIN, CR00235789, AK
    removeEventDispatcherFactory.get(CreoleRuleSetLinkRemoveEvents.class).postRemove(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Validates for duplicate rule set associated for the same related type for
   * the specified period at the time of creation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link CREOLERULESETLINK#ERR_CREOLERULESETLINK_XRV_RULE_SET_ALREADY_EXISTS}
   * If record is already exists.
   */
  protected void validatedNewRuleSet() throws AppException,
      InformationalException {

    DateRange value = new DateRange(getDtls().startDate, getDtls().endDate);

    List<CreoleRuleSetLink> creoleRuleSetLinkList = creoleRuleSetLinkDAO.searchBy(
      getDtls().relatedID, RELATEDTYPEEntry.get(getDtls().relatedType),
      CREOLERULESETTYPEEntry.get(getDtls().type), value);

    if (creoleRuleSetLinkList.size() >= 1) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CREOLERULESETLINKExceptionCreator.ERR_CREOLERULESETLINK_XRV_RULE_SET_ALREADY_EXISTS(
          CREOLERULESETTYPEEntry.get(getDtls().type).getCodeTableItemIdentifier(),
          RELATEDTYPEEntry.get(getDtls().relatedType).getCodeTableItemIdentifier(),
          value.start(), value.end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

      ValidationHelper.failIfErrorsExist();
    }
  }

  /**
   * {@inheritDoc}
   */
  public ServiceOffering getServiceOffering() {

    return serviceOfferingDAO.get(getDtls().relatedID);
  }

}
