/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.impl;


/**
 * This class assigns values to the exception processing constants.
 */
public abstract class CPMExceptionProcessingConstants {

  /**
   * Used for giving the class name as a part of the key to process exception
   * messages occurred for service invoice line item.
   */
  public static final String kSILIExceptionCreatorName = "curam.message.impl.SERVICEINVOICELINEITEMExceptionCreator";

  /**
   * Used for giving the class name as a part of the key to process exception
   * messages occurred for provider roster line item.
   */
  public static final String kROSTERExceptionCreatorName = "curam.message.impl.ROSTERExceptionCreator";

}
