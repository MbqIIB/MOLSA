/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.util.impl;


import java.util.Random;

import curam.core.fact.UniqueIDFactory;
import curam.core.intf.UniqueID;
import curam.core.struct.UniqueIDKeySet;
import curam.cpm.impl.CPMConstants;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.DateTime;


// BEGIN, CR00186039, GP
/**
 * Standard implementation of {@linkplain ReferenceNumberUtility}.
 */
// END, CR00186039
public class ReferenceNumberUtilityImpl implements ReferenceNumberUtility {

  /**
   * Constructor for the class.
   */
  // BEGIN, CR00183213, SS
  protected ReferenceNumberUtilityImpl() {
    // END, CR00183213
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00170638, GP
  /**
   * Generates reference number and returns the string representation of the
   * same. The generation mechanism involves creation of a unique identifier
   * which is combination of current date time along with the random number.
   *
   * @return String representation of the reference number.
   *
   * @deprecated This is replaced by {@link #generateRosterReferenceNumber()}.
   * This method does not throw AppException and
   * InformationalException and UniqueID.getNextIDFromKeySet used
   * for generation of continuous sequential throws AppException and
   * InformationException. Roster reference number is continuous
   * sequential so another method
   * {@link #generateRosterReferenceNumber()} is provided for this
   * purpose.
   * @deprecated -since 6.0.
   */
  // END, CR00170638
  public String generateReferenceNumber() {

    // Length of the reference number.
    final int kMAXLENGTH = 19;

    // Generate the first part of reference number using system date time.
    String firstPart = String.valueOf(DateTime.getCurrentDateTime().asLong());

    // Generate the second part of reference number using random number.
    Random generator = new Random();
    String secondPart = String.valueOf(generator.nextLong()).substring(1,
      kMAXLENGTH - firstPart.length());

    String referenceNumber = firstPart + secondPart;

    return referenceNumber;
  }

  // BEGIN, CR00170638, GP
  /**
   * {@inheritDoc}
   */
  public String generateRosterReferenceNumber() throws AppException,
      InformationalException {

    // BEGIN, CR00186039, GP
    UniqueID uniqueIDObj = UniqueIDFactory.newInstance();
    // END, CR00186039

    UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    uniqueIDKeySet.keySetName = CPMConstants.kRosterKeySetName;

    // BEGIN, CR00186039, GP
    String referenceNumber = String.valueOf(
      uniqueIDObj.getNextIDFromKeySet(uniqueIDKeySet));

    // END, CR00186039

    return referenceNumber;
  }

  // END, CR00170638
  
  // BEGIN, CR00314817, GYH
  /**
   * {@inheritDoc}
   */
  public String generateReferenceNumber(final String keySetName)
    throws AppException, InformationalException {

    final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    uniqueIDKeySet.keySetName = keySetName;
    return String.valueOf(
      UniqueIDFactory.newInstance().getNextIDFromKeySet(uniqueIDKeySet));
  }
  // END, CR00314817
}
