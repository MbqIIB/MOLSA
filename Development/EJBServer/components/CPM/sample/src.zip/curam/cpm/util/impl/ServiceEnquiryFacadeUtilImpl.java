/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


import com.google.inject.Inject;
import curam.codetable.impl.EXTERNALUSERSPARTRELTYPEEntry;
import curam.codetable.impl.PROVIDERENQUIRYRESPONSEEntry;
import curam.codetable.impl.SERVICEDELENQUIRYMETHODEntry;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.cpm.facade.struct.ServiceEnquiryListDetails;
import curam.cpm.facade.struct.ServiceEnquiryListDetailsList;
import curam.cpm.facade.struct.ServiceEnquiryResponse;
import curam.cpm.facade.struct.ServiceEnquiryResponseList;
import curam.cpm.facade.struct.ServiceEnquiryViewDetails;
import curam.message.impl.SERVICEENQUIRYEMAILExceptionCreator;
import curam.message.impl.SERVICEENQUIRYExceptionCreator;
import curam.participant.impl.ConcernRoleDAO;
import curam.piwrapper.user.impl.ExternalUserParticipantLink;
import curam.piwrapper.user.impl.ExternalUserParticipantLinkDAO;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.impl.Provider;
import curam.serviceenquiry.impl.ServiceEnquiry;
import curam.serviceenquiry.impl.ServiceEnquiryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.List;


/**
 * Helper class for the {@link ServiceEnquiry} functionality.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
class ServiceEnquiryFacadeUtilImpl implements ServiceEnquiryFacadeUtil {

  @Inject
  protected ServiceEnquiryDAO serviceEnquiryDAO;

  /**
   * Reference to User DAO instance.
   */
  @Inject
  protected UserDAO userDAO;

  /**
   * Reference to External User Participant Link DAO instance.
   */
  @Inject
  protected ExternalUserParticipantLinkDAO externalUserParticipantLinkDAO;

  /**
   * Reference to Concern Role DAO instance.
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryViewDetails viewServiceEnquiry(
    final curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry)
    throws AppException, InformationalException {

    ServiceEnquiryViewDetails serviceEnquiryViewDetails = new ServiceEnquiryViewDetails();

    serviceEnquiryViewDetails.details.dtls.serviceEnquiryID = serviceEnquiry.getID();
    java.util.Date serviceEnquiryDate = serviceEnquiry.getCreationDateTime().getCalendar().getTime();

    serviceEnquiryViewDetails.createdByDescription = SERVICEENQUIRYExceptionCreator.INF_SERVICE_ENQUIRY_CREATION_DESCRIPTION(Date.getFromJavaUtilDate(serviceEnquiryDate)).getMessage(
      TransactionInfo.getProgramLocale());

    serviceEnquiryViewDetails.createdByFullName = serviceEnquiry.getCreatedBy().getFullName();
    serviceEnquiryViewDetails.details.dtls.createdBy = serviceEnquiry.getCreatedBy().getUsername();
    serviceEnquiryViewDetails.details.dtls.frequency = serviceEnquiry.getFrequency();
    serviceEnquiryViewDetails.serviceName = serviceEnquiry.getServiceOffering().getName();
    serviceEnquiryViewDetails.details.dtls.fromDate = serviceEnquiry.getFromDate();
    serviceEnquiryViewDetails.details.dtls.timeOfDay = serviceEnquiry.getTimeOfDay().getCode();
    serviceEnquiryViewDetails.details.dtls.toDate = serviceEnquiry.getToDate();
    serviceEnquiryViewDetails.details.dtls.lastUpdateDateTime = serviceEnquiry.getLastUpdateDateTime();
    if (null != serviceEnquiry.getNote()) {
      serviceEnquiryViewDetails.details.dtls.noteID = serviceEnquiry.getNote().getID();
      serviceEnquiryViewDetails.details.comments = serviceEnquiry.getNote().getNotesText();
    }
    serviceEnquiryViewDetails.details.dtls.providerResponse = serviceEnquiry.getProviderResponse().getCode();
    serviceEnquiryViewDetails.details.dtls.versionNo = serviceEnquiry.getVersionNo();

    return serviceEnquiryViewDetails;
  }

  /**
   * {@inheritDoc}
   */
  public void submitEnquiryResponse(final int versionNo,
    final curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry,
    final PROVIDERENQUIRYRESPONSEEntry providerResponse, final String comments)
    throws AppException, InformationalException {
    serviceEnquiry.setNote(comments);
    serviceEnquiry.setProviderResponse(providerResponse);

    serviceEnquiry.modify(versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void addComment(final long serviceEnquiryID, final String comments,
    final int versionNo) throws AppException, InformationalException {
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.get(
      serviceEnquiryID);

    serviceEnquiry.setNote(comments);
    serviceEnquiry.modify(versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryListDetailsList assignServiceEnquiryListDetails(
    final List<ServiceEnquiry> serviceEnquiries) {
    ServiceEnquiryListDetailsList serviceEnquiryListDetailsList = new ServiceEnquiryListDetailsList();

    // Retrieve the applicable participant role types
    String enquiriesListSize = Configuration.getProperty(
      EnvVars.ENV_PROVIDER_RECENT_SERVICE_ENQUIRIES_LIST_SIZE);

    if (enquiriesListSize == null) {
      enquiriesListSize = String.valueOf(
        EnvVars.ENV_PROVIDER_RECENT_SERVICE_ENQUIRIES_LIST_SIZE_DEFAULT);
    }

    ServiceEnquiryListDetails serviceEnquiryListDetails;

    for (curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry : serviceEnquiries) {
      serviceEnquiryListDetails = new ServiceEnquiryListDetails();
      serviceEnquiryListDetails.dtls.serviceEnquiryID = serviceEnquiry.getID();
      serviceEnquiryListDetails.dtls.enquiryMethod = serviceEnquiry.getEnquiryMethod().getCode();
      if (serviceEnquiry.getEnquiryMethod().equals(
        SERVICEDELENQUIRYMETHODEntry.PHONE)) {
        serviceEnquiryListDetails.deletePhoneEnquiryInd = true;
      }
      serviceEnquiryListDetails.providerName = serviceEnquiry.getProvider().getName();
      serviceEnquiryListDetails.dtls.providerConcernRoleID = serviceEnquiry.getProvider().getID();
      serviceEnquiryListDetails.serviceName = serviceEnquiry.getServiceOffering().getName();
      serviceEnquiryListDetails.dtls.providerResponse = serviceEnquiry.getProviderResponse().getCode();
      java.util.Date serviceEnquiryDate = serviceEnquiry.getCreationDateTime().getCalendar().getTime();

      serviceEnquiryListDetails.serviceEnquiryDate = Date.getFromJavaUtilDate(
        serviceEnquiryDate);
      serviceEnquiryListDetails.dtls.versionNo = serviceEnquiry.getVersionNo();
      serviceEnquiryListDetailsList.listDetails.addRef(
        serviceEnquiryListDetails);
      // only display the configured number of service enquiries in the list
      if (serviceEnquiryListDetailsList.listDetails.size()
        == Integer.valueOf(enquiriesListSize)) {
        break;
      }
    }

    return serviceEnquiryListDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryResponseList getResponseListForEnquiryResponse(
    final ServiceEnquiry serviceEnquiry) throws AppException,
      InformationalException {
    ServiceEnquiryResponseList responses = new ServiceEnquiryResponseList();

    ServiceEnquiryResponse serviceEnquiryResponse;

    responses.serviceEnquiryResponse = serviceEnquiry.getProviderResponse().getCode();
    LinkedHashMap<String, String> codes = CodeTable.getAllEnabledItems(
      PROVIDERENQUIRYRESPONSEEntry.TABLENAME,
      TransactionInfo.getProgramLocale());

    for (String code : codes.keySet()) {
      if ((code.equals(PROVIDERENQUIRYRESPONSEEntry.CALLNOTANSWERED.getCode()))
        || (code.equals(PROVIDERENQUIRYRESPONSEEntry.PENDING.getCode()))) {
        continue;
      }
      serviceEnquiryResponse = new ServiceEnquiryResponse();
      serviceEnquiryResponse.responseCode = code;
      serviceEnquiryResponse.responseDescription = codes.get(code);
      responses.response.addRef(serviceEnquiryResponse);
    }

    return responses;
  }

  /**
   * {@inheritDoc}
   */
  public String buildRequestAccessLink() throws AppException,
      InformationalException {

    String requestPasswordLink = CuramConst.gkEmpty;

    try {
      requestPasswordLink = buildLinkUrl(getRequestLoginLink(), false, false).toString();
    } catch (MalformedURLException e) {
      throw SERVICEENQUIRYEMAILExceptionCreator.ERR_MALFORMED_VIEW_LINK_URL();
    }

    return requestPasswordLink;
  }

  /**
   * {@inheritDoc}
   */
  public String buildProviderViewLink(final String pageLink)
    throws AppException, InformationalException {

    String viewEnquiryLink = CuramConst.gkEmpty;

    try {
      viewEnquiryLink = buildLinkUrl(pageLink, true, false).toString();
    } catch (MalformedURLException e) {
      throw SERVICEENQUIRYEMAILExceptionCreator.ERR_MALFORMED_VIEW_LINK_URL();
    }

    return viewEnquiryLink;
  }

  /**
   * {@inheritDoc}
   */
  public String buildCaseWorkerViewLink(final String pageLink)
    throws AppException, InformationalException {

    String viewEnquiryLink = CuramConst.gkEmpty;

    try {
      viewEnquiryLink = buildLinkUrl(pageLink, true, true).toString();
    } catch (MalformedURLException e) {
      throw SERVICEENQUIRYEMAILExceptionCreator.ERR_MALFORMED_VIEW_LINK_URL();
    }

    return viewEnquiryLink;
  }

  /**
   * {@inheritDoc}
   */
  public String getRequestLoginLink() {
    // get the Service Enquiry view property
    String requestLoginLink = Configuration.getProperty(
      EnvVars.ENV_PROVIDER_EXTERNAL_NON_SECURE__REQUEST_LOGIN_LINK);

    if (requestLoginLink == null) {
      requestLoginLink = EnvVars.ENV_PROVIDER_EXTERNAL_NON_SECURE__REQUEST_LOGIN_LINK_DEFAULT;
    }
    StringBuffer retValue = new StringBuffer();

    retValue.append(requestLoginLink);
    retValue.append(
      curam.servicedelivery.impl.CuramConst.gkProviderPortalRequestLoginPageIDString);
    return retValue.toString();
  }

  /**
   * {@inheritDoc}
   */
  public String getServiceEnquiryProviderViewLink(
    final curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry) {
    // get the Service Enquiry view property
    String serviceEnquiryViewLink = Configuration.getProperty(
      EnvVars.ENV_SERVICE_ENQUIRY_PROVIDER_VIEW_LINK);

    if (serviceEnquiryViewLink == null) {
      serviceEnquiryViewLink = EnvVars.ENV_SERVICE_ENQUIRY_PROVIDER_VIEW_LINK;
    }
    StringBuffer retValue = new StringBuffer();

    retValue.append(serviceEnquiryViewLink);
    retValue.append(
      curam.servicedelivery.impl.CuramConst.gkServiceEnquiryPageIDString);
    retValue.append(serviceEnquiry.getID());
    return retValue.toString();
  }

  /**
   * {@inheritDoc}
   */
  public String getServiceEnquiryCaseWorkerViewLink(
    final ServiceEnquiry serviceEnquiry) {
    // get the Service Enquiry view property
    String serviceEnquiryViewLink = Configuration.getProperty(
      EnvVars.ENV_SERVICE_ENQUIRY_CASEWORKER_VIEW_LINK);

    if (serviceEnquiryViewLink == null) {
      serviceEnquiryViewLink = EnvVars.ENV_SERVICE_ENQUIRY_CASEWORKER_VIEW_LINK;
    }
    StringBuffer retValue = new StringBuffer();

    retValue.append(serviceEnquiryViewLink);
    retValue.append(
      curam.servicedelivery.impl.CuramConst.gkServiceEnquiryPageIDString);
    retValue.append(serviceEnquiry.getID());
    return retValue.toString();
  }

  /**
   * {@inheritDoc}
   */
  public URL buildLinkUrl(final String fileName, final boolean secureAccess,
    final boolean internalAccess) throws AppException,
      InformationalException, MalformedURLException {

    Boolean protocolSSLInd = getProtocolSSLInd();
    String protocol = getProtocol(protocolSSLInd);
    String host = getHost();
    int port = getPort();
    String root;

    if (internalAccess) {
      root = getInternalApplicationRoot();
    } else {
      root = getProviderPortalRoot(secureAccess);
    }

    // send email
    String defaultLocale = userDAO.get(TransactionInfo.getProgramUser()).getDefaultLocale().getCode();

    String formattedFileName = curam.servicedelivery.impl.CuramConst.gkForwardSlash
      + root + curam.servicedelivery.impl.CuramConst.gkForwardSlash
      + defaultLocale + curam.servicedelivery.impl.CuramConst.gkForwardSlash
      + fileName;

    URL url = new URL(protocol, host, port, formattedFileName);

    return url;
  }

  /**
   * {@inheritDoc}
   */
  public String getProtocol(final boolean protocolSSLInd) {

    if (protocolSSLInd) {
      return curam.servicedelivery.impl.CuramConst.gkSSLProtocol;
    }
    return curam.servicedelivery.impl.CuramConst.gkNoSSLProtocol;
  }

  /**
   * {@inheritDoc}
   */
  public Boolean getProtocolSSLInd() {
    // get the protocol
    Boolean protocolSSLInd;

    if (Configuration.getProperty(EnvVars.ENV_APPLICATION_SSL) == null) {
      protocolSSLInd = Boolean.valueOf(EnvVars.ENV_APPLICATION_SSL_DEFAULT);
    } else {
      protocolSSLInd = Boolean.valueOf(
        Configuration.getBooleanProperty(EnvVars.ENV_APPLICATION_SSL));
    }
    return protocolSSLInd;
  }

  /**
   * {@inheritDoc}
   */
  public String getProviderPortalRoot(final boolean secureAccess)
    throws AppException, InformationalException {
    // get the root
    String root;

    if (secureAccess) {
      if (Configuration.getProperty(
        EnvVars.ENV_PROVIDER_PORTAL_SECURE_APPLICATION_ROOT)
          == null) {
        root = EnvVars.ENV_PROVIDER_PORTAL_SECURE_APPLICATION_ROOT_DEFAULT;
      } else {
        root = Configuration.getProperty(
          EnvVars.ENV_PROVIDER_PORTAL_SECURE_APPLICATION_ROOT);
      }
    } else {
      if (Configuration.getProperty(
        EnvVars.ENV_PROVIDER_PORTAL_NON_SECURE_APPLICATION_ROOT)
          == null) {
        root = EnvVars.ENV_PROVIDER_PORTAL_NON_SECURE_APPLICATION_ROOT_DEFAULT;
      } else {
        root = Configuration.getProperty(
          EnvVars.ENV_PROVIDER_PORTAL_NON_SECURE_APPLICATION_ROOT);
      }
    }
    return root;
  }

  /**
   * {@inheritDoc}
   */
  public String getInternalApplicationRoot() {
    // get the root
    if (Configuration.getProperty(EnvVars.ENV_APPLICATION_ROOT) == null) {
      return EnvVars.ENV_APPLICATION_ROOT_DEFAULT;
    } else {
      return Configuration.getProperty(EnvVars.ENV_APPLICATION_ROOT);
    }
  }

  /**
   * {@inheritDoc}
   */
  public int getPort() {
    // get the port
    int port;

    if (Configuration.getIntProperty(EnvVars.ENV_APPLICATION_PORT) == null) {
      port = EnvVars.ENV_APPLICATION_PORT_DEFAULT;
    } else {
      port = Configuration.getIntProperty(EnvVars.ENV_APPLICATION_PORT);
    }
    return port;
  }

  /**
   * {@inheritDoc}
   */
  public String getHost() {
    // get the host
    String host;

    if (Configuration.getProperty(EnvVars.ENV_APPLICATION_HOST) == null) {
      host = EnvVars.ENV_APPLICATION_HOST_DEFAULT;
    } else {
      host = Configuration.getProperty(EnvVars.ENV_APPLICATION_HOST);
    }
    return host;
  }

  /**
   * {@inheritDoc}
   */
  public ExternalUserParticipantLink getproviderExternalLink(
    final Provider provider) {
    ExternalUserParticipantLink externalUserParticipantLink = externalUserParticipantLinkDAO.readByParticipantRole(
      concernRoleDAO.get(provider.getID()),
      EXTERNALUSERSPARTRELTYPEEntry.PROVIDER);

    return externalUserParticipantLink;
  }

}
