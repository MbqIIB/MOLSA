/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2013
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office 
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import com.google.inject.Inject;

import curam.codetable.impl.CONCERNROLESTATUSEntry;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.EXTERNALUSERSPARTRELTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.struct.ParticipantContextDetails;
import curam.core.fact.ConcernRoleAlternateIDFactory;
import curam.core.fact.ConcernRoleCommunicationFactory;
import curam.core.fact.EmailAddressFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.ConcernRoleAdapter;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.ConcernRoleAlternateID;
import curam.core.intf.ConcernRoleCommunication;
import curam.core.intf.EmailAddress;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.ExternalUserFactory;
import curam.core.sl.entity.fact.ExternalUserParticipantLinkFactory;
import curam.core.sl.entity.impl.ExternalUserAdapter;
import curam.core.sl.entity.intf.ExternalUserParticipantLink;
import curam.core.sl.entity.struct.ExtUserPasswordDetails;
import curam.core.sl.entity.struct.ExternalUserDtls;
import curam.core.sl.entity.struct.ExternalUserKey;
import curam.core.sl.entity.struct.ExternalUserParticipantLinkDtls;
import curam.core.sl.entity.struct.ExternalUserParticipantLinkDtlsList;
import curam.core.sl.entity.struct.ParticipantRoleIDAndType;
import curam.core.sl.struct.ExternalUserDetails;
import curam.core.sl.struct.ExternalUserParticipantLinkDetailsList;
import curam.core.struct.ConcernRoleAlternateIDDtlsStruct1;
import curam.core.struct.ConcernRoleAlternateIDDtlsStruct1List;
import curam.core.struct.ConcernRoleAlternateIDKey1;
import curam.core.struct.ConcernRoleCommunicationDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EmailAddressDtls;
import curam.core.struct.EmailAddressKey;
import curam.core.struct.EmailDetails;
import curam.cpm.eua.facade.fact.ExternalParticipantFactory;
import curam.cpm.eua.facade.struct.ExternalMemberCreationDetails;
import curam.cpm.eua.facade.struct.ExternalProviderCreationDetails;
import curam.cpm.eua.facade.struct.ExternalRelationshipDetails;
import curam.cpm.eua.facade.struct.ExternalUserPasswordDetails;
import curam.cpm.eua.facade.struct.ProviderMemberList;
import curam.cpm.eua.facade.struct.ReestablishPasswordDetails;
import curam.cpm.facade.fact.ContextDescriptionFactory;
import curam.cpm.facade.intf.ContextDescription;
import curam.cpm.sl.entity.struct.SearchRefNumDetails;
import curam.externaluseraccess.impl.ExternalUserDetailsStrategy;
import curam.externaluseraccess.impl.ExternalUserEmailAddressStrategy;
import curam.externaluseraccess.impl.ExternalUserPasswordStrategy;
import curam.message.BPOADMINEXTERNALUSER;
import curam.message.BPOADMINUSER;
import curam.message.impl.EXTERNALUSERExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderGroup;
import curam.provider.impl.ProviderGroupDAO;
import curam.provider.impl.ProviderGroupStatusEntry;
import curam.provider.impl.ProviderMember;
import curam.provider.impl.ProviderMemberDAO;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.provider.impl.ProviderPartyCategoryEntry;
import curam.provider.impl.ProviderStatusEntry;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.ProgramLocale;
import curam.util.security.EncryptionAdmin;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.UniqueID;


/**
 * This class defines functionality used for External Users
 * of the system.
 */
public abstract class ExternalUser extends curam.cpm.eua.facade.base.ExternalUser {

  /**
   * Inject passwordStrategyReference
   */
  @Inject
  protected com.google.inject.Provider<ExternalUserPasswordStrategy> passwordStrategyReference;

  /**
   * Inject userDetailsStrategyReference
   */
  @Inject
  protected com.google.inject.Provider<ExternalUserDetailsStrategy> userDetailsStrategyReference;

  /**
   * Inject userEmailAddressStrategyReference
   */
  @Inject
  protected com.google.inject.Provider<ExternalUserEmailAddressStrategy> userEmailAddressStrategyReference;

  /**
   * Inject providerMemberDAO
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  /**
   * Inject providerDAO
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Inject providerOrganizationDAO
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Inject providerGroupDAO
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /**
   * Inject concernRoleDAO
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Constructor
   */
  public ExternalUser() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * This method creates an external user account using the username passed in.
   * The password for the user is generated. Once the user is successfully set
   * up, they are sent an email with their password and the owner of the new
   * user is sent a notification.
   *
   * @param details
   * - contains details used for searching to ensure that this
   * participant exists on the system
   *
   *
   * @throws InformationalException
   * {@link curam.message.EXTERNALUSER#ERR_USERNAME_REFERENCE_NUMBER_INCORRECT}
   * - If the reference number is invalid.
   * @throws InformationalException
   * {@link curam.message.EXTERNALUSER#ERR_PROVIDER_DOES_NOT_EXIST} -
   * If the participant does not exist.
   * @throws InformationalException
   * {@link curam.message.EXTERNALUSER#ERR_EXTERNALUSER_FV_USERNAME_MUST_BE_LESS_THAN_OR_EQUAL_TO_SIZE}
   * - If user name is not less than or equal to 60 characters.
   * @throws InformationalException
   * {@link curam.message.EXTERNALUSER#ERR_EMAIL_ADDRESS_DOES_NOT_EXIST}
   * - If the participant email address does not exist.
   * @throws InformationalException
   * {@link curam.message.EXTERNALUSER#ERR_PROVIDER_ALREADY_EXISTS} -
   * if we find a participant as we can only have one external user
   * account for a provider/provider group.
   * @throws AppException
   */
  public void createExternalUser(
    ExternalProviderCreationDetails details) throws AppException,
      InformationalException {

    // ExternalUserParticipantlink variables
    ExternalUserParticipantLink externalUserParticipantLinkObj = ExternalUserParticipantLinkFactory.newInstance();
    ParticipantRoleIDAndType participantRoleIDAndType = new ParticipantRoleIDAndType();

    // BEGIN, CR00275719, MC
    int userNameMaxLength = ExternalUserAdapter.kMaxLength_userName;

    if (details.username.length() > userNameMaxLength) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        EXTERNALUSERExceptionCreator.ERR_EXTERNALUSER_FV_USERNAME_MUST_BE_LESS_THAN_OR_EQUAL_TO_SIZE(
          "" + userNameMaxLength),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00275719
    // BEGIN, CR00128895, KR
    if ((details.referenceNumber.length()
      > ConcernRoleAdapter.kMaxLength_primaryAlternateID)) {
      throw EXTERNALUSERExceptionCreator.ERR_USERNAME_REFERENCE_NUMBER_INCORRECT(
        details.username, details.referenceNumber);
    }
    // END, CR00128895

    // call method to get the provider/provider group.
    final ConcernRole concernRole = searchConcernByReferenceNumber(
      details.referenceNumber);

    // check the external user participant link table to ensure that
    // no user currently exists for this concern role
    // set the type
    participantRoleIDAndType.participantRoleID = concernRole.getID();

    // we must have either a provider or provider, the
    // searchConcernByReferenceNumebr method above throws an error if the
    // concernRoleType is anything other than provider/provider group.
    if (concernRole.getConcernRoleType().equals(CONCERNROLETYPEEntry.PROVIDER)) {

      participantRoleIDAndType.extUserPartRelType = curam.codetable.impl.EXTERNALUSERSPARTRELTYPEEntry.PROVIDER.getCode();

    } else {

      participantRoleIDAndType.extUserPartRelType = curam.codetable.impl.EXTERNALUSERSPARTRELTYPEEntry.PROVIDERGROUP.getCode();
    }
    ExternalUserParticipantLinkDtls externalUserParticipantLinkDtls = new ExternalUserParticipantLinkDtls();

    try {
      externalUserParticipantLinkDtls = externalUserParticipantLinkObj.readByParticipantRoleIDAndType(
        participantRoleIDAndType);

      // throw error if we find a participant as we can only have one
      // external user account for a provider/provider group
      if (concernRole.getConcernRoleType().equals(CONCERNROLETYPEEntry.PROVIDER)) {
        throw EXTERNALUSERExceptionCreator.ERR_PROVIDER_ALREADY_EXISTS(
          concernRole.getPrimaryAlternateID());
      } else {
        // must be provider group
        throw EXTERNALUSERExceptionCreator.ERR_PROVIDERGROUP_ALREADY_EXISTS(
          concernRole.getPrimaryAlternateID());
      }
    } catch (RecordNotFoundException rnfe) {// do nothing
    }

    // search the users table for the username entered, to ensure
    // it does not already exist. This will throw an error if the user name
    // already exists.
    searchUserName(details.username);

    // once userName has been entered, generate password
    // get an instance of the ExternalUserPasswordStrategy class
    final ExternalUserPasswordStrategy externalUserPasswordStrategy = passwordStrategyReference.get();

    final ExternalUserDetailsStrategy externalUserDetailsStrategy = userDetailsStrategyReference.get();

    final ExternalUserEmailAddressStrategy externalUserEmailAddressStrategy = userEmailAddressStrategyReference.get();

    ExternalUserDtls externalUserDtls = new ExternalUserDtls();
    curam.core.sl.entity.intf.ExternalUser externalUserObj = curam.core.sl.entity.fact.ExternalUserFactory.newInstance();

    // get the password
    externalUserDtls.password = externalUserPasswordStrategy.getPassword();

    // set the human readable password
    String password = externalUserDtls.password;

    // set the user name
    externalUserDtls.userName = details.username;

    // set the user details
    externalUserDtls = externalUserDetailsStrategy.setDefaultDetails(
      concernRole, externalUserDtls.password);

    externalUserDtls.userName = details.username;

    if (concernRole.getPrimaryEmailAddressID() == 0) {

      // throw error, they must have an email address set up in order
      // for the system to send the new user their password
      throw EXTERNALUSERExceptionCreator.ERR_EMAIL_ADDRESS_DOES_NOT_EXIST();

    } else {

      // read the email address
      EmailAddress emailAddressObj = EmailAddressFactory.newInstance();
      EmailAddressKey emailAddressKey = new EmailAddressKey();

      // set the key
      emailAddressKey.emailAddressID = concernRole.getPrimaryEmailAddressID();
      EmailAddressDtls emailAddressDtls = emailAddressObj.read(emailAddressKey);

      // insert the user and then send email
      externalUserDtls.userName = details.username;
      externalUserObj.insert(externalUserDtls);

      // set the details for inserting an external user participant
      // relationship
      externalUserParticipantLinkDtls.participantRoleID = concernRole.getID();
      externalUserParticipantLinkDtls.userName = externalUserDtls.userName;

      if (concernRole.getConcernRoleType().equals(CONCERNROLETYPEEntry.PROVIDER)) {
        externalUserParticipantLinkDtls.extUserPartRelType = curam.codetable.impl.EXTERNALUSERSPARTRELTYPEEntry.PROVIDER.getCode();
      } else {
        externalUserParticipantLinkDtls.extUserPartRelType = curam.codetable.impl.EXTERNALUSERSPARTRELTYPEEntry.PROVIDERGROUP.getCode();
      }

      // insert the external user participant link record
      externalUserParticipantLinkObj.insert(externalUserParticipantLinkDtls);

      EmailDetails emailDetails = new EmailDetails();

      // create Communication
      createConcernRoleCommunication(concernRole,
        emailAddressKey.emailAddressID, externalUserDtls.userName);

      // set the details
      emailDetails.to = emailAddressDtls.emailAddress;
      emailDetails.from = externalUserEmailAddressStrategy.getEmailAddress();
      emailDetails.subject = curam.message.impl.CPMEMAILExceptionCreator.EXTERNAL_USER_ACCOUNT_CREATED_SUBJECT().getMessage();
      emailDetails.emailMessage = curam.message.impl.CPMEMAILExceptionCreator.EXTERNAL_USER_ACCOUNT_CREATED_MESSAGE(password).getMessage();
      sendEmail(emailDetails, externalUserDtls.userName);

      // create a notification by raising a workflow event.
      // BEGIN, CR00171487, AK
      curam.core.sl.struct.ExternalUserKey externalUserKey = new curam.core.sl.struct.ExternalUserKey();

      externalUserKey.userKey.userName = externalUserDtls.userName;

      ExternalUserParticipantLinkDetailsList list = curam.core.sl.fact.ExternalUserParticipantLinkFactory.newInstance().searchLinkByUsername(
        externalUserKey);

      long externalUserParticipantLinkID = 0;

      for (int i = 0; i < list.details.dtls.size(); i++) {
        if (list.details.dtls.item(i).participantRoleID == concernRole.getID()) {
          externalUserParticipantLinkID = list.details.dtls.item(i).externalUserParticipantLinkDtls.linkID;
          break;
        }
      }

      final Event event = new Event();

      event.eventKey = curam.events.EXTERNALUSER.EXTERNALUSER_CREATED;
      event.primaryEventData = concernRole.getID();
      event.secondaryEventData = externalUserParticipantLinkID;
      EventService.raiseEvent(event);
      // END, CR00171487

    }

  }

  /**
   * This method checks to ensure that a username does not
   * Method to search for username and if one found, provide an alternative
   *
   * @param username - the username as entered by the user
   *
   * @throws InformationalException
   * @throws AppException
   */
  public void searchUserName(String username) throws AppException, InformationalException {

    // users variables
    curam.core.sl.entity.intf.ExternalUser externalUsersObj = ExternalUserFactory.newInstance();
    ExternalUserKey externalUserKey = new ExternalUserKey();
    
    // BEGIN, CR00275719, MC
    int userNameMaxLength = ExternalUserAdapter.kMaxLength_userName;

    if (username.length() > userNameMaxLength) {
      throw EXTERNALUSERExceptionCreator.ERR_EXTERNALUSER_FV_USERNAME_MUST_BE_LESS_THAN_OR_EQUAL_TO_SIZE(
        "" + userNameMaxLength);
    }
    // END, CR00275719
    
    // set the key
    externalUserKey.userName = username;
    boolean userFound = false;

    // try searching for the specified user
    try {
      externalUsersObj.read(externalUserKey);
      // suggest a different user name
      userFound = true;
      boolean newUserFound = true;

      // need to ensure that the new user name suggested
      // is not already on the system.
      while (newUserFound) {
        int randomInt = (short) (Math.random() * 50);

        externalUserKey.userName += CuramConst.gkUnderscore + randomInt;
        try {
          externalUsersObj.read(externalUserKey);
        } catch (RecordNotFoundException rn) {
          newUserFound = false;
        }
      }
    } catch (RecordNotFoundException rnfe) {
      userFound = false;
    } // end record not found

    if (userFound) {
      // throw an exception but suggest the new user name
      throw EXTERNALUSERExceptionCreator.ERR_USERNAME_ALREADY_EXISTS(username,
        externalUserKey.userName);
    }

  }

  /**
   * Method to send the email to the new user.
   * @param emailDetails - The details for sending the email.
   *
   * @param clientName - client name details
   * @throws AppException
   */
  public void sendEmail(EmailDetails emailDetails,
    String clientName) throws AppException {

    // get port details
    if (emailDetails.port == 0) {

      emailDetails.port = Short.parseShort(
        curam.util.resources.Configuration.getProperty(EnvVars.ENV_EMAILPORT));

      // if environment variable not set, set to the default value
      if (emailDetails.port == 0) {
        // default to port 25 if not specified
        emailDetails.port = EnvVars.ENV_EMAILPORT_DEFAULT;
      }

    }

    // get the server
    emailDetails.emailServer = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_CPM_PROVIDER_EMAIL_SERVER);

    // If the property is not set, use default value
    if (emailDetails.emailServer == null) {
      emailDetails.emailServer = curam.util.resources.Configuration.getProperty(
        EnvVars.ENV_CPM_PROVIDER_EMAIL_SERVER_DEFAULT);
    }

    curam.util.resources.SMTPConnection mailConnection = new curam.util.resources.SMTPConnection(
      clientName, emailDetails.emailServer, emailDetails.port);

    // send the email
    // BEGIN, CR00372221, SS
    mailConnection.sendMessage(emailDetails.from, emailDetails.subject,
      emailDetails.to, CuramConst.gkEmpty, CuramConst.gkEmpty,
      emailDetails.emailMessage);
    // END, CR00372221

  }

  /**
   * This method modifies the password for the external user
   *
   * @param externalUserPasswordDetails - This contains the password details
   *
   * @throws InformationalException
   * @throws AppException
   */
  public void modifyExternalUserPassword(
    ExternalUserPasswordDetails externalUserPasswordDetails) throws AppException, InformationalException {

    // Encrypt the password details
    try {
      externalUserPasswordDetails.newPassword = EncryptionAdmin.encryptPassword(
        externalUserPasswordDetails.newPassword);
    } catch (Exception e) {
      AppException wrappedException = new AppException(
        BPOADMINUSER.ERR_ENCRYPTION_FAILED, e);

      wrappedException.setLoggable(true);
      throw wrappedException;
    }

    try {
      externalUserPasswordDetails.confirmPassword = EncryptionAdmin.encryptPassword(
        externalUserPasswordDetails.confirmPassword);
    } catch (Exception e) {
      AppException wrappedException = new AppException(
        BPOADMINUSER.ERR_ENCRYPTION_FAILED, e);

      wrappedException.setLoggable(true);
      throw wrappedException;
    }

    try {
      externalUserPasswordDetails.currentPassword = EncryptionAdmin.encryptPassword(
        externalUserPasswordDetails.currentPassword);
    } catch (Exception e) {
      AppException wrappedException = new AppException(
        BPOADMINUSER.ERR_ENCRYPTION_FAILED, e);

      wrappedException.setLoggable(true);
      throw wrappedException;
    }

    curam.core.sl.entity.intf.ExternalUser externalUsersObj = ExternalUserFactory.newInstance();

    ExtUserPasswordDetails extUserPasswordDetails = new ExtUserPasswordDetails();

    SystemUser systemUser = SystemUserFactory.newInstance();

    ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.userName = systemUser.getUserDetails().userName;

    ExternalUserDetails externalUserDetails = readCurrentExternalUser();

    // Validate the password
    if (!externalUserDetails.userDtls.password.equals(
      externalUserPasswordDetails.currentPassword)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOADMINEXTERNALUSER.ERR_USER_INVALID_PASSWORD),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (externalUserDetails.userDtls.password.equals(
      externalUserPasswordDetails.newPassword)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOADMINEXTERNALUSER.ERR_USER_PASSWORD_NOT_CHANGED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (!externalUserPasswordDetails.newPassword.equals(
      externalUserPasswordDetails.confirmPassword)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOADMINEXTERNALUSER.ERR_USER_XFV_PASSWORD_ERROR),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    extUserPasswordDetails.password = externalUserPasswordDetails.newPassword;
    extUserPasswordDetails.passwordChanged = Date.getCurrentDate();
    extUserPasswordDetails.versionNo = externalUserPasswordDetails.versionNo;
    externalUsersObj.modifyPassword(externalUserKey, extUserPasswordDetails);

  }

  /**
   * This method reads the current user details
   * @return ExternalUserDetails contains External User Details
   *
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ExternalUserDetails readCurrentExternalUser() throws AppException, InformationalException {

    ExternalUserDetails externalUserDetails = new ExternalUserDetails();

    curam.core.sl.entity.intf.ExternalUser externalUserObj = ExternalUserFactory.newInstance();

    ExternalUserKey usersKey = new ExternalUserKey();

    usersKey.userName = TransactionInfo.getProgramUser();

    ExternalUserDtls externalUserDtls = externalUserObj.read(usersKey);

    externalUserDetails.userDtls = externalUserDtls;

    return externalUserDetails;
  }

  /**
   * This method reads the context description for the logged in user
   *
   * @return The context description details
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ParticipantContextDetails readContextDescription() throws AppException, InformationalException {

    // variables for reading the context description

    curam.cpm.eua.facade.intf.ExternalParticipant externalParticipantObj = ExternalParticipantFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // set the key
    concernRoleKey.concernRoleID = externalParticipantObj.readParticipantIDAppCodeByExternalUser().participantRoleID;

    ContextDescription contextDescription = ContextDescriptionFactory.newInstance();

    // Get the context description for the concern role
    ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    participantContextDetails.participantContextDescriptionDetails.description = contextDescription.getContextDescriptionForConcern(concernRoleKey).description;
    return participantContextDetails;

  }

  /**
   * Method to search the provider or provider group records
   * using reference number,
   *
   * @param referenceNumber - contains the reference number of the concern
   *
   * @return - contains the concernRoleID if the concern is found, 0
   * otherwise.
   *
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00177241, PM
  protected curam.participant.impl.ConcernRole searchConcernByReferenceNumber(
    String referenceNumber) throws
      AppException, InformationalException {
    // END, CR00177241

    // search for the provider or provider group
    // BEGIN, CR00399304, SS
    ConcernRole concernRole = null;

    final ConcernRoleAlternateIDKey1 alternateIDKey = new ConcernRoleAlternateIDKey1();

    alternateIDKey.alternateID = referenceNumber;
    final ConcernRoleAlternateID concernRoleAlternateID = ConcernRoleAlternateIDFactory.newInstance();
    final ConcernRoleAlternateIDDtlsStruct1List alternateIDDtlsStruct1List = concernRoleAlternateID.searchByAlternateID(
      alternateIDKey);

    for (final ConcernRoleAlternateIDDtlsStruct1 alternateIDDtlsStruct1 : alternateIDDtlsStruct1List.dtls.items()) {
      concernRole = concernRoleDAO.get(alternateIDDtlsStruct1.concernRoleID);
      if ((CONCERNROLETYPEEntry.PROVIDER.equals(
        concernRole.getConcernRoleType())
          || CONCERNROLETYPEEntry.PROVIDERGROUP.equals(
            concernRole.getConcernRoleType()))
              && CONCERNROLESTATUSEntry.CURRENT.equals(
                concernRole.getStatusCode())) {
        concernRole = concernRoleDAO.get(alternateIDDtlsStruct1.concernRoleID);
        break;
      }
    }
    // END, CR00399304

    if (concernRole == null) {

      // throw error
      throw EXTERNALUSERExceptionCreator.ERR_PROVIDER_DOES_NOT_EXIST(
        referenceNumber);

    }

    // if record found we need to get the corresponding provider or provider group
    // record to ensure the status is correct.
    if (concernRole.getConcernRoleType().equals(CONCERNROLETYPEEntry.PROVIDER)) {

      Provider provider = providerDAO.get(concernRole.getID());

      if (!provider.getLifecycleState().equals(ProviderStatusEntry.APPROVED)) {
        // throw specific error
        throw EXTERNALUSERExceptionCreator.ERR_PROVIDER_MUST_BE_APPROVED(
          referenceNumber);
      }

    } else if (concernRole.getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDERGROUP)) {

      ProviderGroup providerGroup = providerGroupDAO.get(concernRole.getID());

      if (!providerGroup.getLifecycleState().equals(
        ProviderGroupStatusEntry.ACTIVE)) {
        // throw error
        throw EXTERNALUSERExceptionCreator.ERR_PROVIDERGROUP_MUST_BE_ACTIVE(
          referenceNumber);
      }

    } else {
      // if we get here, a concernRole has been found but its not a provider or provider
      // group, so throw error.
      throw EXTERNALUSERExceptionCreator.ERR_PROVIDER_DOES_NOT_EXIST(
        referenceNumber);

    }

    // if we get here, then the correct concern role has been found
    return concernRole;

  }

  /**
   * Method that takes in a reference number and username and searches the
   * system to ensure that a provider with that reference number and username
   * exists. Once we have a successful match, a new password is created
   * and sent to the email of the selected user.
   *
   * @param details - contains the reference number and user name
   *
   * @throws InformationalException
   * @throws AppException
   */
  public void reestablishPassword(ReestablishPasswordDetails details) throws AppException, InformationalException {

    // search the system to find a user name for the external user
    curam.core.sl.entity.intf.ExternalUser externalUserObj = ExternalUserFactory.newInstance();
    ExternalUserKey externalUserKey = new ExternalUserKey();
    ExternalUserDtls externalUserDtls = new ExternalUserDtls();
    ConcernRole concernRole = null;

    // BEGIN, CR00128895, KR
    if ((details.referenceNumber.length()
      > ConcernRoleAdapter.kMaxLength_primaryAlternateID)) {
      throw EXTERNALUSERExceptionCreator.ERR_USERNAME_REFERENCE_NUMBER_INCORRECT(
        details.username, details.referenceNumber);
    }
    // END, CR00128895

    // set the usersKey
    externalUserKey.userName = details.username;

    try {
      externalUserDtls = externalUserObj.read(externalUserKey);
    } catch (RecordNotFoundException rnfe) {
      // throw error
      throw EXTERNALUSERExceptionCreator.ERR_USERNAME_REFERENCE_NUMBER_INCORRECT(
        details.referenceNumber, details.username);
    }

    // get the concernRole
    ExternalUserParticipantLink externalUserParticipantLinkObj = ExternalUserParticipantLinkFactory.newInstance();

    // search the external participant link table for the user name
    ExternalUserParticipantLinkDtlsList externalUserParticipantLinkDtlsList = externalUserParticipantLinkObj.searchByUsername(
      externalUserKey);

    // if no link exists, then this is not a registered concern
    if (externalUserParticipantLinkDtlsList.dtls.size() == 0) {
      // throw error, as the username
      throw EXTERNALUSERExceptionCreator.ERR_USERNAME_REFERENCE_NUMBER_INCORRECT(
        details.referenceNumber, details.username);
    } else {
      // BEGIN, CR00399304, SS
      concernRole = concernRoleDAO.get(
        externalUserParticipantLinkDtlsList.dtls.item(0).participantRoleID);
      if (!CONCERNROLESTATUSEntry.CURRENT.equals(concernRole.getStatusCode())) {
        concernRole = null;
      }

      if (null == concernRole) {
        throw EXTERNALUSERExceptionCreator.ERR_USERNAME_REFERENCE_NUMBER_INCORRECT(
          details.referenceNumber, details.username);
      }

      if (!concernRole.getPrimaryAlternateID().toString().equals(
        details.referenceNumber)) {
        // END, CR00399304
        // throw error, user name and reference number do not match
        throw EXTERNALUSERExceptionCreator.ERR_USERNAME_REFERENCE_NUMBER_INCORRECT(
          details.referenceNumber, details.username);
      }
    } // end else if

    // create a new password and send the user an email.
    final ExternalUserPasswordStrategy externalUserPasswordStrategy = passwordStrategyReference.get();

    final ExternalUserEmailAddressStrategy externalUserEmailAddressStrategy = userEmailAddressStrategyReference.get();

    // get the password
    externalUserDtls.password = externalUserPasswordStrategy.getPassword();

    // set human readable password
    String readablePassword = externalUserDtls.password;

    // encrypt the password
    try {
      externalUserDtls.password = EncryptionAdmin.encryptPassword(
        externalUserDtls.password);
    } catch (Exception e) {
      AppException wrappedException = new AppException(
        BPOADMINUSER.ERR_ENCRYPTION_FAILED, e);

      wrappedException.setLoggable(true);
      throw wrappedException;
    }

    // update the users table with the new password and send email to
    // the user
    // search email addresses
    EmailAddress emailAddressObj = EmailAddressFactory.newInstance();
    EmailAddressKey emailAddressKey = new EmailAddressKey();

    // set the key
    emailAddressKey.emailAddressID = concernRole.getPrimaryEmailAddressID();

    if (emailAddressKey.emailAddressID == 0) {

      // throw error, they must have an email address set up.
      throw EXTERNALUSERExceptionCreator.ERR_EMAIL_ADDRESS_DOES_NOT_EXIST();
    }

    // read the email address details
    EmailAddressDtls emailAddressDtls = emailAddressObj.read(emailAddressKey);

    // modify the users table with the new password details.
    externalUserDtls.passwordChanged = Date.getCurrentDate();

    // update the external user details with the new password
    externalUserObj.modify(externalUserKey, externalUserDtls);

    ConcernRoleCommunication concernRoleCommunicationObj = ConcernRoleCommunicationFactory.newInstance();

    ConcernRoleCommunicationDtls concernRoleCommunicationDetails = new ConcernRoleCommunicationDtls();
    EmailDetails emailDetails = new EmailDetails();

    // set the details
    emailDetails.to = emailAddressDtls.emailAddress;
    emailDetails.from = externalUserEmailAddressStrategy.getEmailAddress();
    emailDetails.subject = curam.message.impl.CPMEMAILExceptionCreator.EXTERNAL_USER_ACCOUNT_CREATED_SUBJECT().getMessage();
    emailDetails.emailMessage = curam.message.impl.CPMEMAILExceptionCreator.EXTERNAL_USER_ACCOUNT_CREATED_MESSAGE(readablePassword).getMessage();
    sendEmail(emailDetails, externalUserDtls.userName);

    // set the details
    concernRoleCommunicationDetails.communicationID = UniqueID.nextUniqueID();
    concernRoleCommunicationDetails.communicationText = curam.message.impl.CPMCOMMUNICATIONExceptionCreator.EXTERNAL_USER_ACCOUNT_CREATED().getMessage();
    concernRoleCommunicationDetails.concernRoleID = externalUserParticipantLinkDtlsList.dtls.item(0).participantRoleID;
    concernRoleCommunicationDetails.communicationDate = Date.getCurrentDate();
    concernRoleCommunicationDetails.emailAddressID = emailAddressDtls.emailAddressID;
    concernRoleCommunicationDetails.subjectText = curam.message.impl.CPMCOMMUNICATIONExceptionCreator.EXTERNAL_USER_ACCOUNT_CREATED().getMessage();
    concernRoleCommunicationDetails.userName = externalUserDtls.userName;
    concernRoleCommunicationObj.insert(concernRoleCommunicationDetails);

  }

  /**
   * This method checks for the provider member specified, and if one
   * exists, creates a new user record for this member.
   *
   * @param details - contains the reference number and user name
   *
   * @throws InformationalException
   * @throws AppException
   */
  public void createMemberExternalUser(
    ExternalMemberCreationDetails details) throws AppException, InformationalException {

    // search the users table for the username entered to ensure
    // it does not already exist. This will throw an error if the username
    // already exists.
    searchUserName(details.username);

    // get the concern Role ID of the provider/provider group
    // requesting the member login credentials
    ExternalUserParticipantLink externalUserParticipantLinkObj = ExternalUserParticipantLinkFactory.newInstance();
    ParticipantRoleIDAndType participantRoleIDAndType = new ParticipantRoleIDAndType();

    // set the key
    participantRoleIDAndType.extUserPartRelType = EXTERNALUSERSPARTRELTYPEEntry.PROVIDERMEMBEROF.getCode();
    participantRoleIDAndType.participantRoleID = details.concernRoleID;

    ExternalUserParticipantLinkDtls externalUserParticipantLinkDtls = new ExternalUserParticipantLinkDtls();

    // check that the concernRole entered does not already have a username
    final curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
      details.concernRoleID);

    try {
      externalUserParticipantLinkDtls = externalUserParticipantLinkObj.readByParticipantRoleIDAndType(
        participantRoleIDAndType);

      // throw error if we find a participant as we can only have one
      // external user account for a provider/provider group
      throw EXTERNALUSERExceptionCreator.ERR_PROVIDER_MEMBER_ALREADY_EXISTS(
        concernRole.getPrimaryAlternateID());
    } catch (RecordNotFoundException rnfe) {// do nothing
    }

    // once username has been entered, now generate password
    // get an instance of the ExternalUserPasswordStrategy class
    final ExternalUserPasswordStrategy externalUserPasswordStrategy = passwordStrategyReference.get();

    final ExternalUserDetailsStrategy externalUserDetailsStrategy = userDetailsStrategyReference.get();

    final ExternalUserEmailAddressStrategy externalUserEmailAddressStrategy = userEmailAddressStrategyReference.get();

    ExternalUserDtls externalUserDtls = new ExternalUserDtls();
    curam.core.sl.entity.intf.ExternalUser externalUserObj = ExternalUserFactory.newInstance();

    // get the password
    externalUserDtls.password = externalUserPasswordStrategy.getPassword();

    String password = externalUserDtls.password;

    externalUserDtls.userName = details.username;

    // set the user details
    externalUserDtls = externalUserDetailsStrategy.setDefaultMemberDetails(
      concernRole, externalUserDtls.password);

    externalUserDtls.userName = details.username;

    if (concernRole.getPrimaryEmailAddressID() == 0) {

      // throw error, they must have an email address set up.
      throw EXTERNALUSERExceptionCreator.ERR_EMAIL_ADDRESS_DOES_NOT_EXIST();

    } else {

      EmailAddress emailAddressObj = EmailAddressFactory.newInstance();
      EmailAddressKey emailAddressKey = new EmailAddressKey();

      // set the key
      emailAddressKey.emailAddressID = concernRole.getPrimaryEmailAddressID();

      EmailAddressDtls emailAddressDtls = emailAddressObj.read(emailAddressKey);

      // insert the user and then send email
      // create the user
      externalUserObj.insert(externalUserDtls);

      // set the details for inserting an external user participant
      // relationship
      externalUserParticipantLinkDtls.participantRoleID = details.concernRoleID;
      externalUserParticipantLinkDtls.userName = externalUserDtls.userName;
      externalUserParticipantLinkDtls.extUserPartRelType = EXTERNALUSERSPARTRELTYPEEntry.PROVIDERMEMBEROF.getCode();
      externalUserParticipantLinkObj.insert(externalUserParticipantLinkDtls);

      EmailDetails emailDetails = new EmailDetails();

      // set the details
      emailDetails.to = emailAddressDtls.emailAddress;
      emailDetails.from = externalUserEmailAddressStrategy.getEmailAddress();
      emailDetails.subject = curam.message.impl.CPMEMAILExceptionCreator.EXTERNAL_USER_ACCOUNT_CREATED_SUBJECT().getMessage();
      emailDetails.emailMessage = curam.message.impl.CPMEMAILExceptionCreator.EXTERNAL_USER_ACCOUNT_CREATED_MESSAGE(password).getMessage();
      sendEmail(emailDetails, externalUserDtls.userName);

      // Create a communication
      createConcernRoleCommunication(concernRole,
        emailAddressKey.emailAddressID, externalUserDtls.userName);

    }

  }

  /**
   * This method creates a concernRoleCommunication record
   *
   * @param concernRole - contains the concern role details
   * @param emailAddressID - contains the email address ID
   * @param userName - contains the user name
   *
   * @throws InformationalException
   * @throws AppException
   */

  // BEGIN, CR00177241, PM
  protected void createConcernRoleCommunication(ConcernRole concernRole,
    long emailAddressID, String userName) throws AppException, InformationalException {
    // END, CR00177241

    // Get the Server Locale.
    String serverLocale = ProgramLocale.getDefaultServerLocale();

    // Create a communication
    ConcernRoleCommunication communication = ConcernRoleCommunicationFactory.newInstance();
    ConcernRoleCommunicationDtls concernRoleCommunicationDetails = new ConcernRoleCommunicationDtls();

    // set the details
    concernRoleCommunicationDetails.communicationID = UniqueID.nextUniqueID();
    concernRoleCommunicationDetails.communicationText = curam.message.CPMCOMMUNICATION.EXTERNAL_USER_ACCOUNT_CREATED.getMessageText(
      serverLocale);
    concernRoleCommunicationDetails.concernRoleID = concernRole.getID();
    concernRoleCommunicationDetails.communicationDate = Date.getCurrentDate();
    concernRoleCommunicationDetails.emailAddressID = emailAddressID;
    concernRoleCommunicationDetails.subjectText = curam.message.CPMCOMMUNICATION.EXTERNAL_USER_ACCOUNT_CREATED.getMessageText();
    concernRoleCommunicationDetails.userName = userName;

    communication.insert(concernRoleCommunicationDetails);
  }

  /**
   * This method returns a list of active provider members for the logged in
   * user who should be the provider or provider group.
   *
   * @return This contains a list of provider members for the logged in user
   * i.e. the provider user or the provider group user.
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ProviderMemberList listAllActiveProviderMembers() throws AppException, InformationalException {

    // result list
    ProviderMemberList providerMemberList = new ProviderMemberList();

    // get the concernRoleID for the provider or provider group.
    curam.cpm.eua.facade.intf.ExternalParticipant externalParticipantObj = ExternalParticipantFactory.newInstance();

    // call method to get the relevant provider information
    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      externalParticipantObj.readProviderProviderGroupID().participantRoleID);

    for (final ProviderMember providerMembers : providerMemberDAO.searchBy(
      providerOrganization)) {

      curam.cpm.eua.facade.struct.ProviderMember providerMember = new curam.cpm.eua.facade.struct.ProviderMember();

      // iterate through each, only take the members that are active and
      // where the end date has not yet passed
      if (providerMembers.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)
        && providerMembers.getDateRange().endsInFuture()) {

        // only add active members to the list
        setProviderMemberDetails(providerMembers, providerMember);
        providerMemberList.providerMember.addRef(providerMember);
      }

    }

    return providerMemberList;

  }

  /**
   * This method concatenates the provider reference number with the provider
   * role.
   *
   * @param providerMember
   * @param providerMemberDetails
   */
  // BEGIN, CR00177241, PM
  protected void setProviderMemberDetails(final ProviderMember providerMember,
    curam.cpm.eua.facade.struct.ProviderMember providerMemberDetails) {
    // END, CR00177241

    // set the details
    providerMemberDetails.concernRoleID = providerMember.getParty().getID();
    providerMemberDetails.name = providerMember.getParty().getName()
      + CuramConst.gkDash + providerMember.getRole().toUserLocaleString();
  }

  /**
   * Method to list participant link details for the given External User.
   *
   * @param key The user name of the External User.
   *
   * @return A list of links related to the current user.
   * @throws InformationalException
   * @throws AppException
   */
  public ExternalUserParticipantLinkDtlsList searchParticipantLinksByUsername(
    ExternalUserKey key) throws AppException, InformationalException {

    ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.userName = TransactionInfo.getProgramUser();

    // Retrieve all links with username
    ExternalUserParticipantLinkDtlsList externalUserParticipantAccessDtlsList = new ExternalUserParticipantLinkDtlsList();

    externalUserParticipantAccessDtlsList = ExternalUserParticipantLinkFactory.newInstance().searchByUsername(
      externalUserKey);

    for (int i = 0; i < externalUserParticipantAccessDtlsList.dtls.size(); i++) {

      ConcernRole concernRole = concernRoleDAO.get(
        externalUserParticipantAccessDtlsList.dtls.item(i).participantRoleID);

      externalUserParticipantAccessDtlsList.dtls.item(i).userName = concernRole.getName();
    }
    return externalUserParticipantAccessDtlsList;
  }

  /**
   * Method to list participant link details for the given External User.
   *
   * @param key The user name of the External User.
   *
   * @return A list of links related to the current user.
   * @throws InformationalException
   * @throws AppException
   */
  public ExternalRelationshipDetails getExternalRelationshipDetails(
    ConcernRoleKey key) throws AppException, InformationalException {

    // result variable
    ExternalRelationshipDetails externalRelationshipDetails = new ExternalRelationshipDetails();

    // get concern role details
    ConcernRole concernRole = concernRoleDAO.get(key.concernRoleID);

    if (concernRole.getConcernRoleType().equals(CONCERNROLETYPEEntry.PROVIDER)
      || concernRole.getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDERGROUP)) {
      // set the type
      externalRelationshipDetails.providerType = concernRole.getConcernRoleType().getCode();
      externalRelationshipDetails.providerConcernRoleID = key.concernRoleID;

      externalRelationshipDetails.providerMemberID = 0;
    } else {

      // must be a member
      // must be provider member or provider group member.
      SearchRefNumDetails searchRefNumDetails = new SearchRefNumDetails();

      searchRefNumDetails.referenceNumber = concernRoleDAO.get(key.concernRoleID).getPrimaryAlternateID();

      // set the details
      searchRefNumDetails.category = ProviderPartyCategoryEntry.MEMBER.getCode();
      searchRefNumDetails.currentDate = Date.getCurrentDate();

      ProviderMember providerMember = providerMemberDAO.searchByReferenceNumber(
        searchRefNumDetails);

      externalRelationshipDetails.providerMemberID = providerMember.getID();

      // BEGIN, CR00399304, SS
      final ProviderOrganization providerOrganization = providerMember.getProviderOrganization();

      final ConcernRole memberConcernRole = concernRoleDAO.get(
        providerOrganization.getID());

      if (CONCERNROLESTATUSEntry.CURRENT.equals(
        memberConcernRole.getStatusCode())) {
        externalRelationshipDetails.memberType = memberConcernRole.getConcernRoleType().getCode();
        externalRelationshipDetails.providerConcernRoleID = 0;

        ContextDescription contextDescription = ContextDescriptionFactory.newInstance();
        ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = memberConcernRole.getID();

        externalRelationshipDetails.pageContextDescription = contextDescription.getContextDescriptionForConcern(concernRoleKey).description;
      }     
      // END, CR00399304
    }
    return externalRelationshipDetails;
  }

}
