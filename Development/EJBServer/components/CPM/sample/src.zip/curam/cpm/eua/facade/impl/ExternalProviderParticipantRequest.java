/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008,2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.eua.facade.impl;


import com.google.inject.Inject;
import curam.cpm.eua.facade.struct.ProviderParticipantRequestDetails;
import curam.externaluseraccess.impl.ProviderParticipantRequest;
import curam.externaluseraccess.impl.ProviderParticipantRequestDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This process class provides the functionality for ProviderParticipantRequest facade layer
 */
public abstract class ExternalProviderParticipantRequest extends curam.cpm.eua.facade.base.ExternalProviderParticipantRequest {

  /**
   * Constructor
   */
  public ExternalProviderParticipantRequest() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  @Inject
  protected ProviderParticipantRequestDAO providerParticipantRequestDAO;
  // ___________________________________________________________________________
  /**
   * facade method to create the provider participant request
   *
   * @param providerParticipantRequestDetails
   * the details of the Provider Participant Request
   *
   * @throws InformationalException
   *
   * @throws AppException
   */
  public void createProviderParticipantRequest(ProviderParticipantRequestDetails providerParticipantRequestDetails) 
    throws AppException, InformationalException {

    // create instance of ProviderParticipantRequest
    ProviderParticipantRequest providerParticipantRequest = providerParticipantRequestDAO.newInstance();

    // map details passed from client
    setProviderParticipantRequestFields(providerParticipantRequest,
      providerParticipantRequestDetails);

    // insert ProviderParticipantRequest
    providerParticipantRequest.insert();

  }

  // ___________________________________________________________________________
  /**
   * Maps the fields updateable by the user to the fields on the service layer
   * object.
   *
   * NB cannot be modeled, as one of the arguments is non-generated.
   *
   * @param providerParticipantRequest
   * the service layer object into which the user-updateable fields
   * must be mapped
   * @param providerParticipantRequestDetails
   * struct contain fields set by the user (as well as other fields
   * which will be ignored)
   *
   * @throws InformationalException
   *
   * @throws AppException
   */
  // BEGIN, CR00177241, PM
  protected void setProviderParticipantRequestFields(
    final ProviderParticipantRequest providerParticipantRequest,
    final ProviderParticipantRequestDetails providerParticipantRequestDetails) throws AppException,
      InformationalException {
    // END, CR00177241

    // set fields
    providerParticipantRequest.setReferenceNumber(
      providerParticipantRequestDetails.dtls.referenceNumber);
    providerParticipantRequest.setStartDate(
      providerParticipantRequestDetails.dtls.startDate);
    providerParticipantRequest.setEndDate(
      providerParticipantRequestDetails.dtls.endDate);
    providerParticipantRequest.setType(
      providerParticipantRequestDetails.dtls.type);

  }

}
