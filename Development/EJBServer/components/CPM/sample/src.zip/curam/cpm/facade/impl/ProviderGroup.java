/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import com.google.inject.Inject;

import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.cefwidgets.docbuilder.impl.ImagePanelBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.cefwidgets.docbuilder.impl.ListBuilder;
import curam.cefwidgets.docbuilder.impl.helper.impl.CodeTableItemEntry;
import curam.cefwidgets.docbuilder.impl.helper.impl.DocBuilderHelperFactory;
import curam.codetable.ADDRESSELEMENTTYPE;
import curam.codetable.LANGUAGE;
import curam.codetable.impl.ADDRESSELEMENTTYPEEntry;
import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.codetable.impl.CONTRACTTYPEEntry;
import curam.codetable.impl.CURRENCYEntry;
import curam.codetable.impl.LANGUAGEEntry;
import curam.codetable.impl.METHODOFDELIVERYEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.ContractVersionDAO;
import curam.core.facade.fact.OrganizationFactory;
import curam.core.facade.intf.Organization;
import curam.core.facade.struct.CaseMenuData;
import curam.core.facade.struct.ListUserSkillDetails;
import curam.core.facade.struct.UserSkillListKey;
import curam.core.facade.struct.UserSkills;
import curam.core.fact.AddressElementFactory;
import curam.core.fact.AddressFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ConcernRolePhoneNumberFactory;
import curam.core.fact.DeliveryMethodFactory;
import curam.core.fact.PhoneNumberFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.Address;
import curam.core.intf.AddressElement;
import curam.core.intf.ConcernRole;
import curam.core.intf.ConcernRolePhoneNumber;
import curam.core.intf.DeliveryMethod;
import curam.core.intf.PhoneNumber;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.UserSkillLanguagesFactory;
import curam.core.sl.entity.struct.UserSkillDetails;
import curam.core.sl.entity.struct.UserSkillDtls;
import curam.core.sl.entity.struct.UserSkillLanguagesDtls;
import curam.core.sl.entity.struct.UserSkillLanguagesDtlsList;
import curam.core.sl.fact.ParticipantTabFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.struct.AddressTabDetails;
import curam.core.sl.struct.PhoneFaxDetails;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.sl.struct.UserSkillLanguageReadMultiKey;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressElementDtls;
import curam.core.struct.AddressElementDtlsList;
import curam.core.struct.AddressKey;
import curam.core.struct.BankAccountDetails;
import curam.core.struct.ConcernRoleAddressDtls;
import curam.core.struct.ConcernRoleContactDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.ConcernRolePhoneNumberDtls;
import curam.core.struct.DeliveryMethodDtls;
import curam.core.struct.DeliveryMethodKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PhoneForConcernRoleKey;
import curam.core.struct.PhoneNumberDtls;
import curam.core.struct.PhoneNumberKey;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.ModifyProviderGroupDetails;
import curam.cpm.facade.struct.ProviderGroupAssociateDetails;
import curam.cpm.facade.struct.ProviderGroupAssociateDetailsList;
import curam.cpm.facade.struct.ProviderGroupAssociateSummaryDetails;
import curam.cpm.facade.struct.ProviderGroupAssociateSummaryDetailsList;
import curam.cpm.facade.struct.ProviderGroupAssociateSummaryInformationDetails;
import curam.cpm.facade.struct.ProviderGroupAssociateSummaryInformationDetailsList;
import curam.cpm.facade.struct.ProviderGroupEnrollmentDetails;
import curam.cpm.facade.struct.ProviderGroupSummaryDetails;
import curam.cpm.facade.struct.ProviderGroupSummaryDetailsList;
import curam.cpm.facade.struct.ProviderGroupSummaryVersionDetails;
import curam.cpm.facade.struct.ProviderGroupSummaryVersionDetailsList;
import curam.cpm.facade.struct.ProviderGroupTabDetails;
import curam.cpm.facade.struct.ViewProviderGroupDetails;
import curam.cpm.facade.struct.ViewProviderGroupSummaryDetails;
import curam.cpm.facade.struct.ViewProviderGroupVersionDetails;
import curam.cpm.facade.struct.WizardMenuDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ProviderGroupEnrollmentReferenceKey;
import curam.cpm.sl.entity.struct.ProviderGroupKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.SearchProviderGroupKey;
import curam.message.BPOINTEGRATEDCASE;
import curam.message.BPOPARTICIPANT;
import curam.message.PROVIDERGROUP;
import curam.message.impl.PROVIDERGROUPExceptionCreator;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderGroupAssociateDAO;
import curam.provider.impl.ProviderGroupDAO;
import curam.provider.impl.ProviderGroupStatusEntry;
import curam.useradmin.impl.MaintainAdminConcernRole;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.FrequencyPattern;


/**
 * Facade layer class having API for managing Provider Groups.
 */
public abstract class ProviderGroup extends curam.cpm.facade.base.ProviderGroup {

  /**
   * obtain current date
   */
  Date currentDate = Date.getCurrentDate();

  /**
   * Constant for number of contracts to display in Provider context panel.
   */
  protected static final int kNumContractsToDisplay = 5;

  /**
   * instance of provider DAO
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * instance of provider group DAO
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /**
   * instance of provider group associate DAO
   */
  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;

  // BEGIN, CR00186342, GP
  /**
   * Reference to Contract Version DAO.
   */
  @Inject
  protected ContractVersionDAO contractVersionDAO;

  // END, CR00186342

  // BEGIN, CR00236233, GP
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;
  // END, CR00236233
  
  /**
   * Constructor
   */
  public ProviderGroup() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * Enrolls Provider Group with the specified Provider Group details.
   *
   * @param details
   * Contains Provider Group enrollment details.
   * @return ProviderGroupEnrollmentReferenceKey Contains concern role ID and
   * reference number.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderGroupEnrollmentReferenceKey enrollProviderGroup(
    ProviderGroupEnrollmentDetails details) throws AppException,
      InformationalException {

    // check the security privileges
    checkSecurityPrivileges();
    // trim all the input values
    trimAllStringFields(details);
    // unique id generator class
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // return key
    final ProviderGroupEnrollmentReferenceKey providerGroupEnrollmentReferenceKey = new ProviderGroupEnrollmentReferenceKey();

    // provider group object instance
    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.newInstance();

    // map details passed from client
    setProviderGroupFields(providerGroup, details);

    // map phone details.
    PhoneNumberDtls phoneNumberDtls = new PhoneNumberDtls();
    ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls = new ConcernRolePhoneNumberDtls();

    concernRolePhoneNumberDtls.concernRolePhoneNumberID = uniqueIDObj.getNextID();
    phoneNumberDtls.phoneNumberID = uniqueIDObj.getNextID();
    setPhoneAndConcernRolePhoneFields(details, phoneNumberDtls,
      concernRolePhoneNumberDtls);

    // map concern role details
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    setConcernRoleFields(details, concernRoleDtls);

    ConcernRoleAddressDtls concernRoleAddressDtls = new ConcernRoleAddressDtls();

    concernRoleAddressDtls.concernRoleAddressID = uniqueIDObj.getNextID();
    AddressDtls addressDtls = new AddressDtls();

    setAddressFields(details, concernRoleAddressDtls, addressDtls);

    // map the bank details.
    BankAccountDetails bankAccountDetails = new BankAccountDetails();

    setConcernRoleBankFields(details, bankAccountDetails);
    // Struct passed to Representative::registerRepresentative
    RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();
    ConcernRoleContactDtls concernRoleContactDtls = new ConcernRoleContactDtls();

    // generate unique ID for contact details
    concernRoleContactDtls.contactID = uniqueIDObj.getNextID();
    setRepresentativeAndContactFields(details,
      representativeRegistrationDetails, concernRoleContactDtls);

    // invoke enrollment of provider group in service layer
    providerGroup.enroll(addressDtls, phoneNumberDtls,
      concernRolePhoneNumberDtls, concernRoleDtls, concernRoleAddressDtls,
      bankAccountDetails, representativeRegistrationDetails,
      concernRoleContactDtls);
    providerGroupEnrollmentReferenceKey.concernRoleID = providerGroup.getID();

    // return the generated provider group enrollment reference key
    return providerGroupEnrollmentReferenceKey;
  }

  // BEGIN, CR00234402, GP
  /**
   * Displays the informational message if the Provider group's Preferred
   * language does not match any language in the user skills.
   *
   * @param providerGroupKey
   * Contains Concern Role ID for a provider group.
   *
   * @return The list of informational messages.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMessageList getProviderGroupInformationals(
    final ProviderGroupKey providerGroupKey) throws AppException,
      InformationalException {

    InformationalManager informationalManager = new InformationalManager();
    InformationalMessageList informationalMessageList = new InformationalMessageList();

    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      providerGroupKey.providerGroupConcernRoleID);

    Organization organisationObj = OrganizationFactory.newInstance();

    UserSkillListKey userSkillListKey = new UserSkillListKey();

    userSkillListKey.userSkillList.userName = TransactionInfo.getProgramUser();
 
    // BEGIN, CR00246086, SS
    // Find if the Preferred language of provider matches any one of the 
    // language of user if the skill type is "Languages".
    boolean isUserSkillLangMatched = false;
    
    // BEGIN, CR00332487, SK
    UserSkills listUserSkillDetails = organisationObj.getUserSkills(
      userSkillListKey);

    for (UserSkillDetails userSkillDetails : listUserSkillDetails.listUserSkillDetails.userSkillDtlsList.items()) {

      UserSkillLanguageReadMultiKey userSkillLanguageReadMultiKey = new UserSkillLanguageReadMultiKey();

      userSkillLanguageReadMultiKey.userSkillID = userSkillDetails.dtls.userSkillID;
        
      UserSkillLanguagesDtlsList userSkillLanguagesDtlsList = UserSkillLanguagesFactory.newInstance().searchByUserSkillID(
        userSkillLanguageReadMultiKey);

      if (RECORDSTATUSEntry.NORMAL.getCode().equals(
        userSkillDetails.dtls.recordStatus)) {
        // END, CR00332487
        
        for (UserSkillLanguagesDtls userSkillLanguagesDtls : 
          userSkillLanguagesDtlsList.dtls) {
            
          if (CodeTable.getOneItemForUserLocale(LANGUAGE.TABLENAME, providerGroup.getPreferredLanguage().getCode()).equals(
            CodeTable.getOneItemForUserLocale(LANGUAGE.TABLENAME,
            userSkillLanguagesDtls.languageCode))) {
            isUserSkillLangMatched = true;
            break;
          }
        }
      }    
    }

    if (!isUserSkillLangMatched) {
      // END, CR00246086
      AppException message = PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_XRV_PROVIDER_GROUP_PREFFERED_LANGUAGE_DOES_NOT_MATCH_USER_SKILLS_LANGUAGE(
        LANGUAGEEntry.get(providerGroup.getPreferredLanguage().getCode()).getCodeTableItemIdentifier());

      informationalManager.addInformationalMsg(message,
        CPMConstants.kEmptyString,
        InformationalElement.InformationalType.kWarning);
    }

    String warnings[] = informationalManager.obtainInformationalAsString();

    for (final String warning : warnings) {

      InformationalMessage infoMessage = new InformationalMessage();

      infoMessage.messageTest = warning;
      informationalMessageList.dtls.addRef(infoMessage);
    }

    return informationalMessageList;
  }

  // END, CR00234402

  // BEGIN, CR00234082, GP
  /**
   * Retrieves the enroll provider group wizard menu properties.
   *
   * @return Enroll provider group wizard menu properties.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public WizardMenuDetails getProviderGroupWizardMenuDetails()
    throws AppException, InformationalException {

    WizardMenuDetails wizardMenuDetails = new WizardMenuDetails();

    wizardMenuDetails.wizardMenu = CPMConstants.kEnrollProviderGroupWizard;

    return wizardMenuDetails;
  }

  // END, CR00234082

  /**
   * Sets the fields for Representative and his contact details.
   *
   * @param details
   * Contain Provider Group enrollment details.
   * @param representativeRegistrationDetails
   * Contains Representative Registration details.
   * @param concernRoleContactDtls
   * Contains the Concern Role details.
   */
  // BEGIN, CR00177241, PM
  protected void setRepresentativeAndContactFields(
    // END, CR00177241
    final ProviderGroupEnrollmentDetails details,
    RepresentativeRegistrationDetails representativeRegistrationDetails,
    ConcernRoleContactDtls concernRoleContactDtls) {
    representativeRegistrationDetails.representativeDtls.representativeName = details.contactName;
    representativeRegistrationDetails.representativeDtls.representativeType = curam.codetable.REPRESENTATIVETYPE.CONTACT;
    representativeRegistrationDetails.representativeRegistrationDetails.addressData = details.addressData;
    representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = details.contactPhoneCountryCode;
    representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = details.contactPhoneAreaCode;
    representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = details.contactPhoneNumber;
    representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension = details.contactPhoneExtension;
    representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = currentDate;
    representativeRegistrationDetails.representativeRegistrationDetails.sensitivity = curam.codetable.SENSITIVITY.DEFAULTCODE;

    concernRoleContactDtls.contactTypeCode = details.contactType;
    concernRoleContactDtls.name = details.contactName;
    concernRoleContactDtls.statusCode = curam.codetable.CONTACTSTATUS.ACTIVE;

  }

  /**
   * Sets the Bank Account fields for Provider Group.
   *
   * @param details
   * Contains Provider Group enrollment details.
   * @param bankAccountDetails
   * Contains the Bank Account details.
   */
  // BEGIN, CR00177241, PM
  protected void setConcernRoleBankFields(
    ProviderGroupEnrollmentDetails details,
    // END, CR00177241
    BankAccountDetails bankAccountDetails) {
    bankAccountDetails.name = details.bankAccountName;
    bankAccountDetails.typeCode = details.bankAccountType;
    bankAccountDetails.bankSortCode = details.bankSortCode;
    bankAccountDetails.accountNumber = details.bankAccountNumber;
    bankAccountDetails.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
    bankAccountDetails.startDate = currentDate;
    bankAccountDetails.primaryBankInd = true;
    bankAccountDetails.jointAccountInd = details.bankJointAccount;
    // BEGIN, CR00377006, GA
    bankAccountDetails.bicOpt = details.bicOpt;
    bankAccountDetails.ibanOpt = details.ibanOpt;
    // END, CR00377006    
  }

  /**
   * Sets the Concern Role details for a Provider Group.
   *
   * @param details
   * Contains Provider Group enrollment details.
   * @param concernRoleDtls
   * Contains Concern Role details.
   */
  // BEGIN, CR00177241, PM
  protected void setConcernRoleFields(ProviderGroupEnrollmentDetails details,
    // END, CR00177241
    ConcernRoleDtls concernRoleDtls) throws AppException,
      InformationalException {

    concernRoleDtls.concernRoleType = curam.codetable.CONCERNROLETYPE.PROVIDERGROUP;
    concernRoleDtls.creationDate = currentDate;
    concernRoleDtls.registrationDate = currentDate;
    concernRoleDtls.startDate = currentDate;
    concernRoleDtls.endDate = curam.util.type.Date.kZeroDate;
    concernRoleDtls.statusCode = curam.codetable.CONCERNROLESTATUS.CURRENT;
    concernRoleDtls.concernRoleName = details.name;

    // instance of SystemUser for getting owner name
    curam.core.intf.SystemUser systemUser = SystemUserFactory.newInstance();

    concernRoleDtls.regUserName = systemUser.getUserDetails().userName;

    concernRoleDtls.preferredLanguage = details.prefLanguage;
    concernRoleDtls.sensitivity = curam.codetable.SENSITIVITY.DEFAULTCODE;
    concernRoleDtls.prefCommMethod = details.prefCommMethod;

    if (details.prefCommMethod.length() != 0) {
      concernRoleDtls.prefCommFromDate = currentDate;
    }
  }

  /**
   * Sets the Address fields for a Provider Group.
   *
   * @param details
   * provider enrollment struct contain fields set by the user
   * @param concernRoleAddressDtls
   * Contains the address details. the service layer struct into which
   * the user updated fields must be mapped
   * @param addressDtls
   * address details struct
   */
  // BEGIN, CR00177241, PM
  protected void setAddressFields(ProviderGroupEnrollmentDetails details,
    // END, CR00177241
    ConcernRoleAddressDtls concernRoleAddressDtls, AddressDtls addressDtls) {
    concernRoleAddressDtls.typeCode = curam.codetable.CONCERNROLEADDRESSTYPE.BUSINESS;
    concernRoleAddressDtls.startDate = currentDate;
    concernRoleAddressDtls.endDate = Date.kZeroDate;
    concernRoleAddressDtls.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
    addressDtls.addressData = details.addressData;

  }

  /**
   * Maps the phone fields that can be updated by the user to the fields on the
   * service layer object.
   *
   * @param details
   * provider group enrollment struct contain fields set by the user
   * @param phoneNumberDtls
   * phone number detail struct
   *
   * @param concernRolePhoneNumberDtls
   * the service layer struct into which the user fields that can be
   * updated must be mapped
   */
  // BEGIN, CR00177241, PM
  protected void setPhoneAndConcernRolePhoneFields(
    // END, CR00177241
    ProviderGroupEnrollmentDetails details, PhoneNumberDtls phoneNumberDtls,
    ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls) {

    phoneNumberDtls.phoneCountryCode = details.phoneCountryCode;
    phoneNumberDtls.phoneAreaCode = details.phoneAreaCode;
    phoneNumberDtls.phoneNumber = details.phoneNumber;
    phoneNumberDtls.phoneExtension = details.phoneExtension;
    concernRolePhoneNumberDtls.typeCode = details.phoneType;
    concernRolePhoneNumberDtls.startDate = currentDate;
    concernRolePhoneNumberDtls.endDate = Date.kZeroDate;

  }

  /**
   * Maps the provider group related fields updated by the user to the fields on
   * the service layer object.
   *
   * @param providerGroup
   * the service layer object into which the user updated fields must
   * be mapped
   * @param details
   * struct contain fields set by the user (as well as other fields
   * which will be ignored)
   */
  // BEGIN, CR00177241, PM
  protected void setProviderGroupFields(
    // END, CR00177241
    final curam.provider.impl.ProviderGroup providerGroup,
    final ProviderGroupEnrollmentDetails details) {

    providerGroup.setCurrencyType(CURRENCYEntry.get(details.currencyType));
    providerGroup.setMethodOfPayment(details.methodOfPayment);
    if (!details.paymentFrequency.equals(GeneralConstants.kEmpty)) {
      // FrequencyPattern frequencyPattern = new FrequencyPattern(
      // details.paymentFrequency);
      providerGroup.setPaymentFrequency(details.paymentFrequency);
    } else {
      providerGroup.setPaymentFrequency(
        FrequencyPattern.kZeroFrequencyPattern.toString());
    }
  }

  // BEGIN, CR00237197, GP
  /**
   * Returns the list of all Provider Groups, who are assigned resource manager.
   *
   * @return List of all Provider Group details belonging to resource manager.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listProviderGroupDetailsForResourceManager()}.
   * This method is not useful for displaying user full name as well
   * as conditional display of links in list of provider groups for
   * resource manager. Hence this method is deprecated. The newly
   * added method will give the option to the user to display the
   * user full name as well as conditional display links. See
   * release note: CR00237197.
   */
  @Deprecated
  // END, CR00237197
  public ProviderGroupSummaryDetailsList listProviderGroupsForResourceManager()
    throws AppException, InformationalException {
    // Create instance of System User
    SystemUser user = SystemUserFactory.newInstance();

    // Create instance of ProviderGroupSummaryDetailsList
    ProviderGroupSummaryDetailsList listDetails = new ProviderGroupSummaryDetailsList();

    final Set<curam.provider.impl.ProviderGroup> providerGroups = providerGroupDAO.searchProviderGroupsForResourceManager(
      user.getUserDetails().userName);

    for (final curam.provider.impl.ProviderGroup providerGroup : providerGroups) {
      // get the owner of this provider
      curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      // set the key
      concernRoleKey.concernRoleID = providerGroup.getID();
      String owner = maintainAdminConcernRole.getProviderOrganisationOwner(concernRoleKey).userName;

      if (owner.equals(TransactionInfo.getProgramUser())) {
        listDetails.details.addRef(getProviderGroupDetails(providerGroup));
      }

    }

    return sortProviderGroupsByReferenceNumber(listDetails);
  }

  // BEGIN, CR00206542, GP
  /**
   * Retrieves a list of provider groups for the resource manager.
   *
   * @return List of provider groups for the resource manager.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderGroupSummaryVersionDetailsList listProviderGroupDetailsForResourceManager()
    throws AppException, InformationalException {

    SystemUser user = SystemUserFactory.newInstance();

    ProviderGroupSummaryVersionDetailsList providerGroupSummaryVersionDetailsList = new ProviderGroupSummaryVersionDetailsList();

    final Set<curam.provider.impl.ProviderGroup> providerGroups = providerGroupDAO.searchProviderGroupsForResourceManager(
      user.getUserDetails().userName.trim());

    for (final curam.provider.impl.ProviderGroup providerGroup : providerGroups) {

      MaintainAdminConcernRole maintainAdminConcernRole = new MaintainAdminConcernRole();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = providerGroup.getID();
      String owner = maintainAdminConcernRole.getProviderOrganisationOwner(concernRoleKey).userName;

      if (owner.equals(TransactionInfo.getProgramUser())) {

        providerGroupSummaryVersionDetailsList.providerGroupSummaryVersionDetails.addRef(
          getProviderGroupVersionDetails(providerGroup));
      }
    }

    return sortProviderGroupsByReferenceNumber(
      providerGroupSummaryVersionDetailsList);
  }

  // END, CR00206542

  // BEGIN, CR00237197, GP
  /**
   * Returns the list of Provider Groups belonging to the resource manager
   * supervisor.
   *
   * @return List of all provider group details belonging to resource manager
   * supervisor.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listProviderGroupDetailsForResourceManagerSupervisor()}
   * . This method is not useful for displaying user full name in
   * list of provider groups for resource manager supervisor. Hence
   * this method is deprecated. The newly added method will give the
   * option to the user to display the user full name. See release
   * note: CR00237197.
   */
  @Deprecated
  // END, CR00237197
  public ProviderGroupSummaryDetailsList listProviderGroupsForResourceManagerSupervisor()
    throws AppException, InformationalException {
    // Create instance of System User
    SystemUser user = SystemUserFactory.newInstance();

    // Create instance of ProviderGroupSummaryDetailsList
    ProviderGroupSummaryDetailsList listDetails = new ProviderGroupSummaryDetailsList();

    final Set<curam.provider.impl.ProviderGroup> providerGroups = providerGroupDAO.searchProviderGroupsForResourceManager(
      user.getUserDetails().userName);

    for (final curam.provider.impl.ProviderGroup providerGroup : providerGroups) {
      // get the owner of this provider
      curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      // set the key
      concernRoleKey.concernRoleID = providerGroup.getID();
      String owner = maintainAdminConcernRole.getProviderOrganisationOwner(concernRoleKey).userName;

      // BEGIN, CR00207466, NBR
      if (owner.equals(TransactionInfo.getProgramUser())) {
        listDetails.details.addRef(getProviderGroupDetails(providerGroup));
      }
    }
    // END, CR00207466
    return sortProviderGroupsByReferenceNumber(listDetails);
  }

  // BEGIN, CR00236233, GP
  /**
   * Retrieves a list of provider groups for the resource manager supervisor.
   *
   * @return A list of provider groups for the resource manager supervisor.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderGroupSummaryVersionDetailsList listProviderGroupDetailsForResourceManagerSupervisor()
    throws AppException, InformationalException {

    ProviderGroupSummaryVersionDetailsList providerGroupSummaryVersionDetailsList = new ProviderGroupSummaryVersionDetailsList();

    SystemUser user = SystemUserFactory.newInstance();

    final Set<curam.provider.impl.ProviderGroup> providerGroups = providerGroupDAO.searchProviderGroupsForResourceManager(
      user.getUserDetails().userName);

    for (final curam.provider.impl.ProviderGroup providerGroup : providerGroups) {

      MaintainAdminConcernRole maintainAdminConcernRole = new MaintainAdminConcernRole();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = providerGroup.getID();
      String owner = maintainAdminConcernRole.getProviderOrganisationOwner(concernRoleKey).userName;

      if (owner.equals(TransactionInfo.getProgramUser())) {
        
        providerGroupSummaryVersionDetailsList.providerGroupSummaryVersionDetails.addRef(
          getProviderGroupVersionDetails(providerGroup));
      }
    }

    return sortProviderGroupsByReferenceNumber(
      providerGroupSummaryVersionDetailsList);
  }

  // END, CR00236233
  
  /**
   * Reads the Provider Group details.
   *
   * @param providerGroupKey
   * Contains the Concern Role ID of the Provider Group.
   * @return ViewProviderGroupDetails Contains the Provider Group details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewProviderGroupDetails viewProviderGroup(
    ProviderGroupKey providerGroupKey) throws AppException,
      InformationalException {

    // return struct
    ViewProviderGroupDetails viewProviderGroupDetails = new ViewProviderGroupDetails();

    final curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      providerGroupKey.providerGroupConcernRoleID);

    // populate the viewProviderGroupDetails struct
    viewProviderGroupDetails.referenceNumber = providerGroup.getPrimaryAlternateID();
    // Begin CR00096779, ABS
    viewProviderGroupDetails.paymentFrequency = providerGroup.getPaymentFrequency();
    // End CR00096779
    viewProviderGroupDetails.methodOfPayment = providerGroup.getMethodOfPayment();

    DeliveryMethod deliveryMethod = DeliveryMethodFactory.newInstance();
    DeliveryMethodKey deliveryMethodKey = new DeliveryMethodKey();

    deliveryMethodKey.deliveryMethodID = providerGroup.getMethodOfPayment();
    DeliveryMethodDtls deliveryMethodDtls = deliveryMethod.read(
      deliveryMethodKey);

    viewProviderGroupDetails.methodOfPaymentString = CodeTable.getOneItemForUserLocale(
      METHODOFDELIVERYEntry.TABLENAME, deliveryMethodDtls.name);

    viewProviderGroupDetails.currencyType = providerGroup.getCurrencyType().getCode();
    viewProviderGroupDetails.recordStatus = providerGroup.getLifecycleState().getCode();
    viewProviderGroupDetails.versionNo = providerGroup.getVersionNo();

    // ConcernRole for pref.lang, pref.comm, comments and name
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = providerGroupKey.providerGroupConcernRoleID;
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    viewProviderGroupDetails.prefLanguage = concernRoleDtls.preferredLanguage;
    viewProviderGroupDetails.prefCommMethod = concernRoleDtls.prefCommMethod;
    viewProviderGroupDetails.comments = concernRoleDtls.comments;
    viewProviderGroupDetails.providerName = concernRoleDtls.concernRoleName;
    viewProviderGroupDetails.enrollmentDate = concernRoleDtls.registrationDate;
    viewProviderGroupDetails.endDate = concernRoleDtls.endDate;
    viewProviderGroupDetails.concernRoleID = concernRoleDtls.concernRoleID;

    viewProviderGroupDetails.pageContextDescription = concernRoleDtls.concernRoleName
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + providerGroup.getPrimaryAlternateID();

    // Address
    Address addressObj = AddressFactory.newInstance();
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = concernRoleDtls.primaryAddressID;

    AddressDtls addressDtls = addressObj.read(addressKey);

    OtherAddressData formattedAddressData = new OtherAddressData();

    formattedAddressData.addressData = addressDtls.addressData;

    addressObj.getAddressStrings(formattedAddressData);

    viewProviderGroupDetails.formattedAddressData = formattedAddressData.addressData;

    viewProviderGroupDetails.addressData = addressDtls.addressData;

    // Phone number
    if (concernRoleDtls.primaryPhoneNumberID != 0) {

      PhoneNumberKey phoneNumberKey = new PhoneNumberKey();

      phoneNumberKey.phoneNumberID = concernRoleDtls.primaryPhoneNumberID;

      PhoneNumber phoneNumberObj = PhoneNumberFactory.newInstance();

      ConcernRolePhoneNumber concernRolePhoneNumberObj = ConcernRolePhoneNumberFactory.newInstance();
      PhoneForConcernRoleKey phoneForConcernRoleKey = new PhoneForConcernRoleKey();

      phoneForConcernRoleKey.concernRoleID = concernRoleDtls.concernRoleID;
      phoneForConcernRoleKey.phoneNumberID = concernRoleDtls.primaryPhoneNumberID;

      PhoneNumberDtls phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);

      ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls = concernRolePhoneNumberObj.readPhoneForConcernRole(
        phoneForConcernRoleKey);

      viewProviderGroupDetails.phoneNumber = phoneNumberDtls.phoneNumber;
      viewProviderGroupDetails.phoneAreaCode = phoneNumberDtls.phoneAreaCode;
      viewProviderGroupDetails.phoneCountryCode = phoneNumberDtls.phoneCountryCode;
      viewProviderGroupDetails.phoneExtension = phoneNumberDtls.phoneExtension;
      viewProviderGroupDetails.phoneType = concernRolePhoneNumberDtls.typeCode;

    }

    ProviderGroupAssociateDetails providerGroupAssociateDetails;
    ProviderGroupAssociateDetailsList providerGroupAssociateDetailsList = new ProviderGroupAssociateDetailsList();

    for (final curam.provider.impl.ProviderGroupAssociate providerGroupAssociate : providerGroupAssociateDAO.searchByProviderGroup(
      providerGroup)) {

      providerGroupAssociateDetails = new ProviderGroupAssociateDetails();

      // Setting the value from ConcernRole
      // concernRoleKey.concernRoleID = providerGroupAssociate.getID();
      concernRoleKey.concernRoleID = providerGroupAssociate.getProvider().getID();
      concernRoleDtls = concernRoleObj.read(concernRoleKey);
      providerGroupAssociateDetails.name = concernRoleDtls.concernRoleName;

      // Setting the value from ProviderGroupAssociate
      providerGroupAssociateDetails.startDate = providerGroupAssociate.getDateRange().start();
      providerGroupAssociateDetails.endDate = providerGroupAssociate.getDateRange().end();
      // BEGIN, CR00093612, MC
      providerGroupAssociateDetails.providerStatus = providerGroupAssociate.getProvider().getLifecycleState().getCode();
      providerGroupAssociateDetails.recordStatus = providerGroupAssociate.getLifecycleState().getCode();
      // END, CR00093612
      providerGroupAssociateDetails.concernRoleID = providerGroupAssociate.getID();

      providerGroupAssociateDetailsList.groupAssociateDetails.addRef(
        providerGroupAssociateDetails);
    }
    viewProviderGroupDetails.providerDetailsList = sortProvidersByName(
      providerGroupAssociateDetailsList);

    return viewProviderGroupDetails;
  }

  // BEGIN, CR00205476, GP
  /**
   * Reads the provider group details.
   *
   * @param providerGroupKey
   * Provider group for which details are to be retrieved.
   *
   * @return Provider group details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewProviderGroupVersionDetails viewProviderGroupDetails(
    final ProviderGroupKey providerGroupKey) throws AppException,
      InformationalException {

    ViewProviderGroupVersionDetails viewProviderGroupVersionDetails = new ViewProviderGroupVersionDetails();

    final curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      providerGroupKey.providerGroupConcernRoleID);

    viewProviderGroupVersionDetails.referenceNumber = providerGroup.getPrimaryAlternateID();
    viewProviderGroupVersionDetails.paymentFrequency = providerGroup.getPaymentFrequency();
    viewProviderGroupVersionDetails.methodOfPayment = providerGroup.getMethodOfPayment();

    DeliveryMethod deliveryMethod = DeliveryMethodFactory.newInstance();
    DeliveryMethodKey deliveryMethodKey = new DeliveryMethodKey();

    deliveryMethodKey.deliveryMethodID = providerGroup.getMethodOfPayment();
    DeliveryMethodDtls deliveryMethodDtls = deliveryMethod.read(
      deliveryMethodKey);

    viewProviderGroupVersionDetails.methodOfPaymentString = CodeTable.getOneItemForUserLocale(
      METHODOFDELIVERYEntry.TABLENAME, deliveryMethodDtls.name);

    viewProviderGroupVersionDetails.currencyType = providerGroup.getCurrencyType().getCode();
    viewProviderGroupVersionDetails.recordStatus = providerGroup.getLifecycleState().getCode();
    viewProviderGroupVersionDetails.versionNo = providerGroup.getVersionNo();

    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = providerGroupKey.providerGroupConcernRoleID;
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    viewProviderGroupVersionDetails.prefLanguage = concernRoleDtls.preferredLanguage;
    viewProviderGroupVersionDetails.prefCommMethod = concernRoleDtls.prefCommMethod;
    viewProviderGroupVersionDetails.comments = concernRoleDtls.comments;
    viewProviderGroupVersionDetails.providerName = concernRoleDtls.concernRoleName;
    viewProviderGroupVersionDetails.enrollmentDate = concernRoleDtls.registrationDate;
    viewProviderGroupVersionDetails.endDate = concernRoleDtls.endDate;
    viewProviderGroupVersionDetails.concernRoleID = concernRoleDtls.concernRoleID;

    viewProviderGroupVersionDetails.pageContextDescription = concernRoleDtls.concernRoleName
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + providerGroup.getPrimaryAlternateID();

    Address addressObj = AddressFactory.newInstance();
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = concernRoleDtls.primaryAddressID;

    AddressDtls addressDtls = addressObj.read(addressKey);

    OtherAddressData formattedAddressData = new OtherAddressData();

    formattedAddressData.addressData = addressDtls.addressData;

    addressObj.getAddressStrings(formattedAddressData);

    viewProviderGroupVersionDetails.formattedAddressData = formattedAddressData.addressData;

    viewProviderGroupVersionDetails.addressData = addressDtls.addressData;

    if (0 != concernRoleDtls.primaryPhoneNumberID) {

      PhoneNumberKey phoneNumberKey = new PhoneNumberKey();

      phoneNumberKey.phoneNumberID = concernRoleDtls.primaryPhoneNumberID;

      PhoneNumber phoneNumberObj = PhoneNumberFactory.newInstance();

      ConcernRolePhoneNumber concernRolePhoneNumberObj = ConcernRolePhoneNumberFactory.newInstance();
      PhoneForConcernRoleKey phoneForConcernRoleKey = new PhoneForConcernRoleKey();

      phoneForConcernRoleKey.concernRoleID = concernRoleDtls.concernRoleID;
      phoneForConcernRoleKey.phoneNumberID = concernRoleDtls.primaryPhoneNumberID;

      PhoneNumberDtls phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);

      ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls = concernRolePhoneNumberObj.readPhoneForConcernRole(
        phoneForConcernRoleKey);

      viewProviderGroupVersionDetails.phoneNumber = phoneNumberDtls.phoneNumber;
      viewProviderGroupVersionDetails.phoneAreaCode = phoneNumberDtls.phoneAreaCode;
      viewProviderGroupVersionDetails.phoneCountryCode = phoneNumberDtls.phoneCountryCode;
      viewProviderGroupVersionDetails.phoneExtension = phoneNumberDtls.phoneExtension;
      viewProviderGroupVersionDetails.phoneType = concernRolePhoneNumberDtls.typeCode;

    }

    ProviderGroupAssociateSummaryInformationDetailsList providerGroupAssociateSummaryDetailsList = new ProviderGroupAssociateSummaryInformationDetailsList();

    for (final curam.provider.impl.ProviderGroupAssociate providerGroupAssociate : providerGroupAssociateDAO.searchByProviderGroup(
      providerGroup)) {

      ProviderGroupAssociateSummaryInformationDetails providerGroupAssociateSummaryDetails = new ProviderGroupAssociateSummaryInformationDetails();

      providerGroupAssociateSummaryDetails.providerConcernRoleID = providerGroupAssociate.getProvider().getID();
      providerGroupAssociateSummaryDetails.providerName = providerGroupAssociate.getProvider().getName();
      providerGroupAssociateSummaryDetails.startDate = providerGroupAssociate.getDateRange().start();
      providerGroupAssociateSummaryDetails.endDate = providerGroupAssociate.getDateRange().end();
      providerGroupAssociateSummaryDetails.providerStatus = providerGroupAssociate.getProvider().getLifecycleState().getCode();
      providerGroupAssociateSummaryDetails.recordStatus = providerGroupAssociate.getLifecycleState().getCode();
      providerGroupAssociateSummaryDetails.providerGroupAssociateID = providerGroupAssociate.getID();
      providerGroupAssociateSummaryDetails.versionNo = providerGroupAssociate.getVersionNo();

      providerGroupAssociateSummaryDetailsList.providerGroupAssociateSummaryDetails.addRef(
        providerGroupAssociateSummaryDetails);
    }

    viewProviderGroupVersionDetails.providerGroupAssociationSummaryDetailsList = sortProvidersByName(
      providerGroupAssociateSummaryDetailsList);

    // BEGIN, CR00234402, GP
    InformationalMessageList informationalMessageList = getProviderGroupInformationals(
      providerGroupKey);

    if (informationalMessageList.dtls.size() > 0) {
      viewProviderGroupVersionDetails.userSkillsInd = true;
    }
    // END, CR00234402

    // BEGIN, CR00234497, PS
    if (ProviderGroupStatusEntry.ACTIVE.equals(
      providerGroup.getLifecycleState())) {

      viewProviderGroupVersionDetails.openStatusInd = true;
    } else {
      viewProviderGroupVersionDetails.closedStatusInd = true;
    }
    // END, CR00234497

    return viewProviderGroupVersionDetails;
  }

  // END, CR00205476

  /**
   * Sorts a set of Provider Group Associate into a sorted list for display.
   *
   * @param unsortedProviders
   * the set of unsorted Provider Group Associates
   * @return a sorted list of Provider Group Associates
   */

  // BEGIN, CR00177241, PM
  protected ProviderGroupAssociateDetailsList sortProvidersByName(
    // END, CR00177241
    ProviderGroupAssociateDetailsList unsortedProviders) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    List<ProviderGroupAssociateDetails> providerGroupAssociateDetailsList = new ArrayList<ProviderGroupAssociateDetails>();
    int noOfEnquiries = unsortedProviders.groupAssociateDetails.size();

    for (int i = 0; i < noOfEnquiries; i++) {
      providerGroupAssociateDetailsList.add(
        unsortedProviders.groupAssociateDetails.item(i));
    }

    Collections.sort(providerGroupAssociateDetailsList,
      new Comparator<ProviderGroupAssociateDetails>() {
      public int compare(final ProviderGroupAssociateDetails lhs,
        ProviderGroupAssociateDetails rhs) {
        // BEGIN CR00099146 KR
        return lhs.name.compareToIgnoreCase(rhs.name);
        // END CR00099146
      }
    });

    ProviderGroupAssociateDetailsList providerGroupAssociateDetailsListSorted = new ProviderGroupAssociateDetailsList();

    providerGroupAssociateDetailsListSorted.groupAssociateDetails.addAll(
      providerGroupAssociateDetailsList);

    return providerGroupAssociateDetailsListSorted;
  }
  
  /**
   * Sorts a set of Provider Group Associate into a sorted list for display.
   *
   * @param unsortedProviders
   * the set of unsorted Provider Group Associates
   * @return a sorted list of Provider Group Associates
   */

  protected ProviderGroupAssociateSummaryInformationDetailsList sortProvidersByName(
    ProviderGroupAssociateSummaryInformationDetailsList unsortedProviders) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    List<ProviderGroupAssociateSummaryInformationDetails> providerGroupAssociateDetailsList = new ArrayList<ProviderGroupAssociateSummaryInformationDetails>();
    int noOfEnquiries = unsortedProviders.providerGroupAssociateSummaryDetails.size();

    for (int i = 0; i < noOfEnquiries; i++) {
      providerGroupAssociateDetailsList.add(
        unsortedProviders.providerGroupAssociateSummaryDetails.item(i));
    }

    Collections.sort(providerGroupAssociateDetailsList,
      new Comparator<ProviderGroupAssociateSummaryInformationDetails>() {
      public int compare(final ProviderGroupAssociateSummaryInformationDetails lhs,
        ProviderGroupAssociateSummaryInformationDetails rhs) {
        return lhs.providerName.compareToIgnoreCase(rhs.providerName);
      }
    });

    ProviderGroupAssociateSummaryInformationDetailsList providerGroupAssociateDetailsListSorted = new ProviderGroupAssociateSummaryInformationDetailsList();

    providerGroupAssociateDetailsListSorted.providerGroupAssociateSummaryDetails.addAll(
      providerGroupAssociateDetailsList);

    return providerGroupAssociateDetailsListSorted;
  }

  /**
   * Closes the Provider Group.
   *
   * @param details
   * Contains Concern Role ID and version number of the Provider Group.
   * @return ProviderGroupKey Contains Concern Role ID of the Provider Group.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public ProviderGroupKey closeProviderGroup(KeyVersionDetails details)
    throws AppException, InformationalException {

    // read the provider group
    final curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      details.id);

    for (ContractVersion contracts : providerGroup.getContracts()) {
      if (contracts.getContractType().equals(CONTRACTTYPEEntry.FLATRATE)
        && contracts.getLifecycleState().equals(CONTRACTSTATUSEntry.LIVE)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_XRV_LIVE_CONTRACTS_PRESENT_PROVIDERGROUP_CANNOT_BE_CLOSED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }
    }

    providerGroup.close(details.version);
    ProviderGroupKey providerGroupKey = new ProviderGroupKey();

    providerGroupKey.providerGroupConcernRoleID = details.id;

    return providerGroupKey;
  }

  /**
   * Reopens the closed Provider Group for offering the service.
   *
   * @param details
   * Contains Concern Role ID and version number of the Provider Group.
   * @return ProviderGroupKey Contains Concern Role ID of the Provider Group.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderGroupKey reopenProviderGroup(KeyVersionDetails details)
    throws AppException, InformationalException {

    // read the provider group
    final curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      details.id);

    providerGroup.reopen(details.version);
    ProviderGroupKey providerGroupKey = new ProviderGroupKey();

    providerGroupKey.providerGroupConcernRoleID = details.id;

    return providerGroupKey;
  }

  // BEGIN, CR00208860, AS
  /**
   * Lists all Provider Groups having association with a Provider.
   *
   * @param providerKey
   * Contains the Concern Role ID of the Provider.
   *
   * @return The list of Provider Group and Provider association details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderGroupAssociateSummaryDetailsList listProviderGroupAssociateDetailsForProvider(
    final ProviderKey providerKey) throws AppException,
      InformationalException {

    ProviderGroupAssociateSummaryDetailsList providerGroupAssociateSummaryDetailsList = new ProviderGroupAssociateSummaryDetailsList();

    curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    ProviderGroupAssociateSummaryDetails providerGroupAssociateSummaryDetails;

    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    for (final curam.provider.impl.ProviderGroupAssociate providerGroupAssociate : providerGroupAssociateDAO.searchProviderGroupsForProvider(
      provider)) {

      providerGroupAssociateSummaryDetails = new ProviderGroupAssociateSummaryDetails();

      concernRoleKey.concernRoleID = providerGroupAssociate.getProviderGroup().getID();
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      providerGroupAssociateSummaryDetails.providerName = concernRoleDtls.concernRoleName;

      providerGroupAssociateSummaryDetails.startDate = providerGroupAssociate.getDateRange().start();
      providerGroupAssociateSummaryDetails.endDate = providerGroupAssociate.getDateRange().end();
      providerGroupAssociateSummaryDetails.recordStatus = providerGroupAssociate.getLifecycleState().getCode();
      providerGroupAssociateSummaryDetails.providerGroupConcernRoleID = providerGroupAssociate.getProviderGroup().getID();
      providerGroupAssociateSummaryDetails.providerGroupAssociateID = providerGroupAssociate.getID();
      providerGroupAssociateSummaryDetails.versionNo = providerGroupAssociate.getVersionNo();
      providerGroupAssociateSummaryDetailsList.providerGroupAssociateSummaryDetails.addRef(
        providerGroupAssociateSummaryDetails);
    }
    return sortProviderGroupAssociateDetailsByDate(
      providerGroupAssociateSummaryDetailsList);
  }

  // END, CR00208860

  /**
   * Returns the list of Provider Groups having association with a Provider.
   *
   * @param key
   * Contains the Concern Role ID of the Provider.
   *
   * @return ProviderGroupAssociateDetailsList Contains the list of Provider
   * Group and Provider association details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderGroupAssociateDetailsList listProviderGroupsForProvider(
    ProviderKey key) throws AppException, InformationalException {

    ProviderGroupAssociateDetailsList providerGroupAssociateDetailsList = new ProviderGroupAssociateDetailsList();

    curam.provider.impl.Provider provider = providerDAO.get(
      key.providerConcernRoleID);

    ProviderGroupAssociateDetails providerGroupAssociateDetails;

    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    for (final curam.provider.impl.ProviderGroupAssociate providerGroupAssociate : providerGroupAssociateDAO.searchProviderGroupsForProvider(
      provider)) {

      providerGroupAssociateDetails = new ProviderGroupAssociateDetails();

      // Setting the value from ConcernRole
      concernRoleKey.concernRoleID = providerGroupAssociate.getProviderGroup().getID();
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      providerGroupAssociateDetails.name = concernRoleDtls.concernRoleName;

      // Setting the value from ProviderGroupAssociate
      providerGroupAssociateDetails.startDate = providerGroupAssociate.getDateRange().start();
      providerGroupAssociateDetails.endDate = providerGroupAssociate.getDateRange().end();
      providerGroupAssociateDetails.recordStatus = providerGroupAssociate.getLifecycleState().getCode();

      // BEGIN, CR00093612, MC
      providerGroupAssociateDetails.providerStatus = providerGroupAssociate.getProvider().getLifecycleState().getCode();
      // END, CR00093612

      providerGroupAssociateDetails.concernRoleID = providerGroupAssociate.getProviderGroup().getID();
      providerGroupAssociateDetails.providerGroupAssociateID = providerGroupAssociate.getID();
      providerGroupAssociateDetailsList.groupAssociateDetails.addRef(
        providerGroupAssociateDetails);
    }
    return sortProviderGroupsByDate(providerGroupAssociateDetailsList);
  }

  /**
   * Sorts a set of Provider Group Associates into a sorted list for display.
   *
   * @param unsortedProviderGroups
   * the set of unsorted Provider Group Associates.
   *
   * @return a sorted list of Provider Group Associates by Start Date
   */
  // BEGIN, CR00177241, PM
  protected ProviderGroupAssociateDetailsList sortProviderGroupsByDate(
    // END, CR00177241
    ProviderGroupAssociateDetailsList unsortedProviderGroups) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */

    List<ProviderGroupAssociateDetails> providerGroupAssociateDetailsList = new ArrayList<ProviderGroupAssociateDetails>();
    int noOfEnquiries = unsortedProviderGroups.groupAssociateDetails.size();

    for (int i = 0; i < noOfEnquiries; i++) {
      providerGroupAssociateDetailsList.add(
        unsortedProviderGroups.groupAssociateDetails.item(i));
    }

    Collections.sort(providerGroupAssociateDetailsList,
      new Comparator<ProviderGroupAssociateDetails>() {
      public int compare(final ProviderGroupAssociateDetails lhs,
        ProviderGroupAssociateDetails rhs) {
        return rhs.startDate.compareTo(lhs.startDate);
      }
    });

    ProviderGroupAssociateDetailsList providerGroupAssociateDetailsListSorted = new ProviderGroupAssociateDetailsList();

    providerGroupAssociateDetailsListSorted.groupAssociateDetails.addAll(
      providerGroupAssociateDetailsList);

    return providerGroupAssociateDetailsListSorted;
  }

  /**
   * Modifies the Provider Group details.
   *
   * @param details
   * Contains Provider Group details to be modified.
   * @return ProviderGroupKey Contains Concern Role ID of the Provider Group.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public ProviderGroupKey modifyProviderGroup(ModifyProviderGroupDetails details)
    throws AppException, InformationalException {

    // check the security privileges
    checkSecurityPrivileges();

    // provider group object instance
    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      details.concernRoleID);

    // map details passed from client
    setProviderGroupFields(providerGroup, details);

    // Map concern role details

    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.concernRoleID;
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    setConceRoleFieldsForModification(details, concernRoleDtls, concernRoleObj);
    // return struct
    ProviderGroupKey providerGroupKey = new ProviderGroupKey();

    providerGroupKey = providerGroup.modify(concernRoleObj, concernRoleDtls,
      details.versionNo);

    return providerGroupKey;
  }

  /**
   * This method sets the concern role details for the Provider Group
   * modification.
   *
   * @param details
   * modify provider group details struct.
   * @param concernRoleDtls
   * concern role standard struct.
   * @param concernRoleObj
   * concern role object.
   *
   * @throws AppException
   * application exception
   * @throws InformationalException
   * informational exception
   */
  // BEGIN, CR00177241, PM
  protected void setConceRoleFieldsForModification(
    // END, CR00177241
    ModifyProviderGroupDetails details, ConcernRoleDtls concernRoleDtls,
    ConcernRole concernRoleObj)
    throws AppException, InformationalException {

    concernRoleDtls.preferredLanguage = details.prefLanguage;
    concernRoleDtls.prefCommMethod = details.prefCommMethod;
    concernRoleDtls.comments = details.comments;
    concernRoleDtls.concernRoleName = details.name;
  }

  /**
   * Reads the context description for a Provider Group.
   *
   * @param key
   * Contains the Concern Role ID of the Provider Group.
   * @return ViewProviderGroupSummaryDetails Contains context description for a
   * Provider Group.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewProviderGroupSummaryDetails readProviderGroupSummaryDetails(
    ProviderGroupKey key) throws AppException, InformationalException {
    // return struct
    ViewProviderGroupSummaryDetails viewProviderGroupSummaryDetails = new ViewProviderGroupSummaryDetails();

    // Provider Entity
    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      key.providerGroupConcernRoleID);

    // reading the provider name from concern role
    ConcernRoleNameDetails concernRoleNameDetails;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    concernRoleKey.concernRoleID = providerGroup.getID();
    concernRoleNameDetails = concernRoleObj.readConcernRoleName(concernRoleKey);

    // construct the pageContextDescription
    StringBuffer pageContext = new StringBuffer();

    pageContext.append(concernRoleNameDetails.concernRoleName);
    pageContext.append(GeneralConstants.kSpace);
    pageContext.append(GeneralConstants.kMinus);
    pageContext.append(GeneralConstants.kSpace);
    pageContext.append(providerGroup.getPrimaryAlternateID());

    viewProviderGroupSummaryDetails.pageContextDescription = pageContext.toString();

    return viewProviderGroupSummaryDetails;
  }

  /**
   * Searches for all the Provider Groups based on search criteria.
   *
   * @param key
   * Contains the search criteria.
   * @return ProviderGroupSummaryDetailsList Contains search results.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderGroupSummaryDetailsList searchAllProviderGroup(
    SearchProviderGroupKey key) throws AppException, InformationalException {

    // trim the input fields
    final String referenceNumber = key.referenceNumber.trim();
    final String name = key.name.trim();
    final String street1 = key.street1.trim();
    final String city = key.city.trim();

    // Check if user has specified search criteria
    if (name.equals(GeneralConstants.kEmpty)
      && street1.equals(GeneralConstants.kEmpty)
      && city.equals(GeneralConstants.kEmpty)
      && referenceNumber.equals(GeneralConstants.kEmpty)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERGROUPExceptionCreator.ERR_PROVIDERGROUP_FV_SOME_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }
    ProviderGroupSummaryDetailsList listDetails = new ProviderGroupSummaryDetailsList();

    final Set<curam.provider.impl.ProviderGroup> providerGroups = providerGroupDAO.searchBy(
      name, referenceNumber, street1, city);

    for (final curam.provider.impl.ProviderGroup providerGroup : providerGroups) {

      listDetails.details.addRef(getProviderGroupDetails(providerGroup));
    }
    ValidationHelper.failIfErrorsExist();
    return sortProviderGroupsByName(listDetails);
  }

  /**
   * Retrieves the provider group details.
   *
   * @param providerGroup
   * Contains provider group object.
   *
   * @return Provider group summary details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected ProviderGroupSummaryDetails getProviderGroupDetails(
    // END, CR00177241
    curam.provider.impl.ProviderGroup providerGroup) throws AppException,
      InformationalException {
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    AddressElement addressElementObj = AddressElementFactory.newInstance();
    AddressElementDtlsList addressElementDtlsList;
    AddressKey addressKey = new AddressKey();
    ProviderGroupSummaryDetails providerGroupSummaryDetails = new ProviderGroupSummaryDetails();

    providerGroupSummaryDetails = new ProviderGroupSummaryDetails();

    // Setting the values from ProviderGroup
    providerGroupSummaryDetails.concernRoleID = providerGroup.getID();
    providerGroupSummaryDetails.recordStatus = providerGroup.getLifecycleState().getCode();
    providerGroupSummaryDetails.referenceNumber = providerGroup.getPrimaryAlternateID();

    // Setting the values from ConcernRole
    concernRoleKey.concernRoleID = providerGroup.getID();
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    providerGroupSummaryDetails.name = concernRoleDtls.concernRoleName;
    
    // BEGIN, CR00282506, MR
    providerGroupSummaryDetails.nameReferenceNumberOpt = concernRoleDtls.concernRoleName
      + CuramConst.kSeparator + providerGroup.getPrimaryAlternateID();
    // END, CR00282506

    // Setting the value from Address
    addressKey.addressID = concernRoleDtls.primaryAddressID;

    addressElementDtlsList = addressElementObj.readAddressElementDetails(
      addressKey);

    for (final AddressElementDtls addressElementDtls : addressElementDtlsList.dtls.items()) {
      if (ADDRESSELEMENTTYPE.CITY.equals(addressElementDtls.elementType)) {
        providerGroupSummaryDetails.city = addressElementDtls.elementValue;
      }
      if (ADDRESSELEMENTTYPE.LINE1.equals(addressElementDtls.elementType)) {
        providerGroupSummaryDetails.street1 = addressElementDtls.elementValue;
      }
    }
    // get the owner of this provider
    curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();

    providerGroupSummaryDetails.owner = maintainAdminConcernRole.getProviderOrganisationOwner(concernRoleKey).userName;

    return providerGroupSummaryDetails;
  }

  /**
   * Maps the Provider group fields updated by the user to the fields on the
   * service layer object for the provider group modification.
   *
   *
   * @param providerGroup
   * the service layer object into which the user updated fields must
   * be mapped
   * @param details
   * struct contain fields set by the user (as well as other fields
   * which will be ignored)
   */
  // BEGIN, CR00177241, PM
  protected void setProviderGroupFields(
    // END, CR00177241
    final curam.provider.impl.ProviderGroup providerGroup,
    final ModifyProviderGroupDetails details) {

    providerGroup.setCurrencyType(CURRENCYEntry.get(details.currencyType));
    providerGroup.setMethodOfPayment(details.methodOfPayment);

    if (!details.paymentFrequency.equals(GeneralConstants.kEmpty)) {
      // FrequencyPattern frequencyPattern = new FrequencyPattern(
      // details.paymentFrequency);
      providerGroup.setPaymentFrequency(details.paymentFrequency);
    } else {
      providerGroup.setPaymentFrequency(
        FrequencyPattern.kZeroFrequencyPattern.toString());
    }

  }

  /**
   * This method checks security privileges of the user, whether the user has
   * enough privileges to modify/create the record.
   */
  // BEGIN, CR00177241, PM
  protected void checkSecurityPrivileges() {// END, CR00177241
    // get user
    // curam.core.intf.SystemUser systemUser =
    // SystemUserFactory.newInstance();
    // check if the user is a part of resource manager organizational object
    // if not, throw a validation error
    /*
     * ValidationHelper.addValidationError(CPMCOMMONMESSAGESExceptionCreator.
     * ERR_CPMCOMMONMSG_XRV_USER_MUST_BE_MEMBER_OF_RESOURCE_MANAGER_ORGANIZATIONAL_OBJECT
     * ( systemUser.getUserDetails().userName,"Resource Manager Object"));
     */}

  /**
   * Sorts a set of Provider Groups name into a sorted list for display.
   *
   * @param unsortedProviderGroups
   * the set of unsorted ProviderGroups
   *
   * @return a sorted list of Provider Groups by Group name
   */

  // BEGIN, CR00177241, PM
  protected ProviderGroupSummaryDetailsList sortProviderGroupsByName(
    // END, CR00177241
    ProviderGroupSummaryDetailsList unsortedProviderGroups) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    List<ProviderGroupSummaryDetails> providerGroupSummaryDetailsList = new ArrayList<ProviderGroupSummaryDetails>();
    int noOfEnquiries = unsortedProviderGroups.details.size();

    for (int i = 0; i < noOfEnquiries; i++) {
      providerGroupSummaryDetailsList.add(
        unsortedProviderGroups.details.item(i));
    }

    Collections.sort(providerGroupSummaryDetailsList,
      new Comparator<ProviderGroupSummaryDetails>() {
      public int compare(final ProviderGroupSummaryDetails lhs,
        ProviderGroupSummaryDetails rhs) {
        return lhs.name.compareToIgnoreCase(rhs.name);
      }
    });

    ProviderGroupSummaryDetailsList providerGroupSummaryDetailsListSorted = new ProviderGroupSummaryDetailsList();

    providerGroupSummaryDetailsListSorted.details.addAll(
      providerGroupSummaryDetailsList);

    return providerGroupSummaryDetailsListSorted;
  }

  /**
   * Sorts a set of provider groups into a sorted list for display.
   *
   * @param unsortedProviderGroups
   * the set of unsorted provider groups
   *
   * @return a sorted list of Provider groups by reference number
   */

  // BEGIN, CR00177241, PM
  protected ProviderGroupSummaryDetailsList sortProviderGroupsByReferenceNumber(
    // END, CR00177241
    ProviderGroupSummaryDetailsList unsortedProviderGroups) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    List<ProviderGroupSummaryDetails> providerGroupSummaryDetailsList = new ArrayList<ProviderGroupSummaryDetails>();
    int noOfEnquiries = unsortedProviderGroups.details.size();

    for (int i = 0; i < noOfEnquiries; i++) {
      providerGroupSummaryDetailsList.add(
        unsortedProviderGroups.details.item(i));
    }

    Collections.sort(providerGroupSummaryDetailsList,
      new Comparator<ProviderGroupSummaryDetails>() {
      public int compare(final ProviderGroupSummaryDetails lhs,
        ProviderGroupSummaryDetails rhs) {
        return lhs.referenceNumber.compareTo(rhs.referenceNumber);
      }
    });

    ProviderGroupSummaryDetailsList providerGroupSummaryDetailsListSorted = new ProviderGroupSummaryDetailsList();

    providerGroupSummaryDetailsListSorted.details.addAll(
      providerGroupSummaryDetailsList);

    return providerGroupSummaryDetailsListSorted;
  }

  /**
   * This method is called to trim string values
   *
   * @param details
   * ProviderGroupEnrollmentDetails
   */
  // BEGIN, CR00177241, PM
  protected void trimAllStringFields(ProviderGroupEnrollmentDetails details) {
    // END, CR00177241

    details.bankAccountName = details.bankAccountName.trim();
    details.bankAccountNumber = details.bankAccountNumber.trim();
    details.contactName = details.contactName.trim();
    details.contactPhoneAreaCode = details.contactPhoneAreaCode.trim();
    details.contactPhoneCountryCode = details.contactPhoneCountryCode.trim();
    details.contactPhoneExtension = details.contactPhoneExtension.trim();
    details.contactPhoneNumber = details.contactPhoneNumber.trim();
    details.currencyType = details.currencyType.trim();
    details.name = details.name.trim();
    details.phoneAreaCode = details.phoneAreaCode.trim();
    details.phoneCountryCode = details.phoneCountryCode.trim();
    details.phoneExtension = details.phoneExtension.trim();
    details.phoneNumber = details.phoneNumber.trim();

  }

  // START CR00117630, ASB
  /**
   * Get the menu context description for the View Provider Group.
   *
   * @param providerGroupKey
   * Internal system identifier of Provider Group record.
   *
   * @return Menu Context description
   *
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  public CaseMenuData viewProviderGroupMenuContextDescription(
    ProviderGroupKey providerGroupKey) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      providerGroupKey.providerGroupConcernRoleID);

    Element navigationMenuElement = new Element(
      XmlMetaDataConst.kNavigationMenu);
    Element linkElement = new Element(XmlMetaDataConst.kItem);
    Element paramElement = new Element(XmlMetaDataConst.kParam);

    // Set up node property values
    LocalisableString description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(providerGroup.getName());

    // Set up node property values
    linkElement.setAttribute(XmlMetaDataConst.kPageID,
      CPMConstants.kViewProviderGroupHome);
    linkElement.setAttribute(XmlMetaDataConst.kDesc,
      description.toClientFormattedText());
    linkElement.setAttribute(XmlMetaDataConst.kType, XmlMetaDataConst.kTypeCase);

    navigationMenuElement.addContent(linkElement);

    // set the parameter values
    paramElement = new Element(XmlMetaDataConst.kParam);
    paramElement.setAttribute(XmlMetaDataConst.kName,
      CPMConstants.kParamProviderGroupConcernRoleID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(providerGroupKey.providerGroupConcernRoleID));

    linkElement.addContent(paramElement);

    XMLOutputter outputter = new XMLOutputter();
    CaseMenuData caseMenuData = new CaseMenuData();

    caseMenuData.menuData = outputter.outputString(navigationMenuElement);
    return caseMenuData;
  }

  // END CR00117630

  // BEGIN, CR00186342, GP
  /**
   * Reads provider group tab details.
   *
   * @param providerGroupKey
   * Provider group for which tab details are to be retrieved.
   *
   * @return Provider group tab details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderGroupTabDetails viewProviderGroupTabDetails(
    ProviderGroupKey providerGroupKey) throws AppException,
      InformationalException {

    ProviderGroupTabDetails providerGroupTabDetails = new ProviderGroupTabDetails();

    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      providerGroupKey.providerGroupConcernRoleID);

    ViewProviderGroupDetails viewProviderGroupDetails = viewProviderGroup(
      providerGroupKey);

    providerGroupTabDetails.providerGroupName = viewProviderGroupDetails.providerName;
    providerGroupTabDetails.referenceNumber = viewProviderGroupDetails.referenceNumber;
    providerGroupTabDetails.enrollmentDate = viewProviderGroupDetails.enrollmentDate;
    providerGroupTabDetails.addressData = viewProviderGroupDetails.formattedAddressData;
    providerGroupTabDetails.status = viewProviderGroupDetails.recordStatus;
    providerGroupTabDetails.phoneCountryCode = viewProviderGroupDetails.phoneCountryCode;
    providerGroupTabDetails.phoneAreaCode = viewProviderGroupDetails.phoneAreaCode;
    providerGroupTabDetails.phoneNumber = viewProviderGroupDetails.phoneNumber;
    providerGroupTabDetails.phoneExtension = viewProviderGroupDetails.phoneExtension;

    // BEGIN, CR00197239, DRS
    // BEGIN, CR00199066, GP
    // BEGIN, CR00224728, JMA
    ContentPanelBuilder containerPanel = ContentPanelBuilder.createPanel(
      CPMConstants.gkProviderGroupContainer);
    // END, CR00199066

    // Get image panel details
    ImagePanelBuilder imagePanelBuilder = ImagePanelBuilder.createPanel();

    // BEGIN, CR00236083, GP
    imagePanelBuilder.addParticipantImage(CPMConstants.kIconProviderGroup,
      CuramConst.gkEmpty, CPMConstants.kRendererImages);
    // END, CR00236083
    
    ContentPanelBuilder imagePanel = imagePanelBuilder.getImagePanel();

    imagePanel.addRoundedCorners();

    // Get center panels details
    ContentPanelBuilder centrePanel = getProviderGroupDetails(providerGroup,
      viewProviderGroupDetails);

    // BEGIN, CR00199066
    containerPanel.addWidgetItem(imagePanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CPMConstants.gkProviderGroupImagePanel);

    // Add the center panel to the border container
    containerPanel.addWidgetItem(centrePanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CPMConstants.gkProviderGroupDetailsPanel);
    // END, CR00199066

    // END, CR00197239
    providerGroupTabDetails.providerGroupTabDetails = containerPanel.toString();
    // END, CR00199066

    return providerGroupTabDetails;
  }

  // END, CR00186342

  // BEGIN, CR00236083, GP
  /**
   * Reads the details for an Provider Group to be displayed in the details
   * section on the context panel.
   *
   * @param providerGroup
   * The provider group to display details for.
   * @param viewProviderGroupDetails
   * Details of the provider group.
   *
   * @return Content panel builder.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ContentPanelBuilder getProviderGroupDetails(
    curam.provider.impl.ProviderGroup providerGroup,
    ViewProviderGroupDetails viewProviderGroupDetails) throws AppException,
      InformationalException {
    // END, CR00236083
    
    ContentPanelBuilder centerPanel = ContentPanelBuilder.createPanel(
      CPMConstants.gkProviderGroupTabDetails);

    centerPanel.addRoundedCorners();

    centerPanel.addStringItem(providerGroup.getName(),
      CuramConst.gkContentParticipantName);
    centerPanel.addStringItem(providerGroup.getPrimaryAlternateID(), 
      CuramConst.gkContentParticipantID);
    
    TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
    AddressTabDetails addressTabDetails = new AddressTabDetails();

    addressTabDetails.addressData = viewProviderGroupDetails.addressData;

    centerPanel.addStringItem(
      tabDetailFormatterObj.formatAddress(addressTabDetails).addressString,
      CuramConst.gkContentAddress);    

    String mapEnabled = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GEOCODE_ENABLED);

    if (mapEnabled == null) {
      mapEnabled = EnvVars.ENV_GEOCODE_ENABLED_DEFAULT;
    }

    if (mapEnabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {      
    
      LocalisableString mapString = new LocalisableString(
        BPOPARTICIPANT.INF_MAP);

      LinkBuilder googleLinkBuilder = LinkBuilder.createLocalizableLink(
        mapString.toClientFormattedText(), CuramConst.gkAddressMapPage);

      googleLinkBuilder.addParameter(CuramConst.gkAddressID,
        String.valueOf(providerGroup.getPrimaryAddressID()));
      googleLinkBuilder.openAsModal();
      googleLinkBuilder.setTextResource(CuramConst.gkRendererImages);
      // BEGIN, CR00236083, GP
      googleLinkBuilder.addImage(CuramConst.gkIconMap, CuramConst.gkEmpty);
      // END, CR00236083
    
      centerPanel.addWidgetItem(googleLinkBuilder, CuramConst.gkStyle,
        CuramConst.gkLink, CuramConst.gkContentMap);    
    }
    
    ListBuilder enrollmentDetailsList = ListBuilder.createHorizontalList(2);

    enrollmentDetailsList.addRow();
    enrollmentDetailsList.addEntry(1, 1,
      new LocalisableString(PROVIDERGROUP.INF_PROVIDERGROUP_STATUS));
    CodeTableItemEntry codeTable = DocBuilderHelperFactory.getCodeTableItemEntry(
      viewProviderGroupDetails.recordStatus,
      CPMConstants.gkDominProviderGroupStatus);

    enrollmentDetailsList.addEntry(2, 1, codeTable);   
    
    enrollmentDetailsList.addRow();    
    enrollmentDetailsList.addEntry(1, 2,
      new LocalisableString(PROVIDERGROUP.TEXT_PROVIDERGROUP_ENROLLED));
    enrollmentDetailsList.addEntry(2, 2,
      viewProviderGroupDetails.enrollmentDate);
 
    centerPanel.addSingleListItem(enrollmentDetailsList, 
      CPMConstants.gkProviderGroupDetailsTable);
    
    ContentPanelBuilder contactContents = ContentPanelBuilder.createPanel(
      CuramConst.gkContentContacts);

    // Create a image builder for a phone icon
    ImageBuilder phoneIconImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconPhone, CuramConst.gkEmpty);

    phoneIconImageBuilder.setImageResource(CuramConst.gkRendererImages);

    // BEGIN, CR00262179, GP
    phoneIconImageBuilder.setImageAltText(
      new LocalisableString(PROVIDERGROUP.TEXT_PROVIDERGROUP_PHONE_NUMBER).toClientFormattedText());
    // END, CR00262179
    
    contactContents.addImageItem(phoneIconImageBuilder);
  
    // Get the phone number for the Provider
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = providerGroup.getID();
    PhoneFaxDetails phoneFaxDetails = ParticipantTabFactory.newInstance().getPhoneFaxDetails(
      concernRoleKey); 
  
    if (phoneFaxDetails.phoneNumberString.length() != 0) {

      contactContents.addStringItem(phoneFaxDetails.phoneNumberString,
        CuramConst.gkPhoneNumber);
    } else {
      LocalisableString detailsNotRecorded = new LocalisableString(
        BPOPARTICIPANT.INF_NOT_RECORDED);

      contactContents.addlocalisableStringItem(
        detailsNotRecorded.toClientFormattedText(), CuramConst.gkPhoneNumber);
    }

    // Create a image builder for an email icon
    // BEGIN, CR00236083, GP
    ImageBuilder emailIconImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconEmail, CuramConst.gkEmpty);

    // END, CR00236083
    emailIconImageBuilder.setImageResource(CuramConst.gkRendererImages);

    // BEGIN, CR00262179, GP
    emailIconImageBuilder.setImageAltText(
      new LocalisableString(PROVIDERGROUP.TEXT_PROVIDERGROUP_EMAIL_ADDRESS).toClientFormattedText());
    // END, CR00262179
    
    contactContents.addImageItem(emailIconImageBuilder);    
  
    if (null != providerGroup.getEmailAddress()) {

      LinkBuilder emailLinkBuilder = LinkBuilder.createLink(
        providerGroup.getEmailAddress().getEmail(),
        CuramConst.gkMailto + providerGroup.getEmailAddress().getEmail());

      // BEGIN, CR00262179, GP
      emailLinkBuilder.addLinkTitle(
        new LocalisableString(PROVIDERGROUP.TEXT_PROVIDERGROUP_EMAIL_TITLE));
      // END, CR00262179
      
      contactContents.addWidgetItem(emailLinkBuilder, CuramConst.gkStyle,
        CuramConst.gkLink, CuramConst.gkEmail);
    } else {
      LocalisableString detailsNotRecorded = new LocalisableString(
        BPOPARTICIPANT.INF_NOT_RECORDED);

      contactContents.addlocalisableStringItem(
        detailsNotRecorded.toClientFormattedText(), CuramConst.gkEmail);
    }

    // Create a image builder for an web address icon
    // BEGIN, CR00236083, GP
    ImageBuilder webAddressIconImageBuilder = ImageBuilder.createImage(
      CPMConstants.gkIconWeb, CuramConst.gkEmpty);

    // END, CR00236083
    webAddressIconImageBuilder.setImageResource(CuramConst.gkRendererImages);

    // BEGIN, CR00262179, GP
    webAddressIconImageBuilder.setImageAltText(
      new LocalisableString(PROVIDERGROUP.TEXT_PROVIDERGROUP_WEB_ADDRESS).toClientFormattedText());
    // END, CR00262179
    
    contactContents.addImageItem(webAddressIconImageBuilder);        
    
    // BEGIN, CR00236083, GP
    if (null != providerGroup.getWebAddress()) {

      LinkBuilder webAddressBuilder = LinkBuilder.createLink(
        providerGroup.getWebAddress().getWebAddress(),
        providerGroup.getWebAddress().getWebAddress());

      // BEGIN, CR00262179, GP
      webAddressBuilder.addLinkTitle(
        new LocalisableString(
          PROVIDERGROUP.TEXT_PROVIDERGROUP_WEB_ADDRESS_TITLE));
      // END, CR00262179
      
      contactContents.addWidgetItem(webAddressBuilder, CuramConst.gkStyle,
        CuramConst.gkLink, CuramConst.gkEmail);
    } else {
      LocalisableString detailsNotRecorded = new LocalisableString(
        BPOPARTICIPANT.INF_NOT_RECORDED);

      contactContents.addlocalisableStringItem(
        detailsNotRecorded.toClientFormattedText(), CPMConstants.gkWebAddress);
    }
    // END, CR00236083
    
    centerPanel.addWidgetItem(contactContents, CuramConst.gkStyle,
      CuramConst.gkContentPanel);    

    return centerPanel;
  }

  // END, CR00224728
  
  // BEGIN, CR00205476, GP
  /**
   * Sorts a set of Provider Group Associate into a sorted list for display.
   *
   * @param unsortedProviders
   * The set of unsorted Provider Group Associates.
   *
   * @return A sorted list of Provider Group Associates.
   */
  protected ProviderGroupAssociateSummaryDetailsList sortProvidersByName(
    final ProviderGroupAssociateSummaryDetailsList unsortedProviders) {

    List<ProviderGroupAssociateSummaryDetails> providerGroupAssociateSummaryDetailsList = new ArrayList<ProviderGroupAssociateSummaryDetails>();

    for (ProviderGroupAssociateSummaryDetails providerGroupAssociateSummaryDetails 
      : unsortedProviders.providerGroupAssociateSummaryDetails.items()) {
      
      providerGroupAssociateSummaryDetailsList.add(
        providerGroupAssociateSummaryDetails);
    }

    Collections.sort(providerGroupAssociateSummaryDetailsList,
      new Comparator<ProviderGroupAssociateSummaryDetails>() {
      public int compare(final ProviderGroupAssociateSummaryDetails lhs,
        ProviderGroupAssociateSummaryDetails rhs) {
        return lhs.providerName.compareToIgnoreCase(rhs.providerName);
      }
    });

    ProviderGroupAssociateSummaryDetailsList providerGroupAssociateDetailsListSorted = new ProviderGroupAssociateSummaryDetailsList();

    providerGroupAssociateDetailsListSorted.providerGroupAssociateSummaryDetails.addAll(
      providerGroupAssociateSummaryDetailsList);

    return providerGroupAssociateDetailsListSorted;
  }

  // END, CR00205476
  
  // BEGIN, CR00206542, GP
  /**
   * Returns the provider group details.
   *
   * @param providerGroup
   * Provider group for which details are to be retrieved.
   *
   * @return Provider group summary details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ProviderGroupSummaryVersionDetails getProviderGroupVersionDetails(
    final curam.provider.impl.ProviderGroup providerGroup)
    throws AppException, InformationalException {
    
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    AddressElement addressElementObj = AddressElementFactory.newInstance();
    AddressElementDtlsList addressElementDtlsList;
    AddressKey addressKey = new AddressKey();
    ProviderGroupSummaryVersionDetails providerGroupSummaryVersionDetails = new ProviderGroupSummaryVersionDetails();
    
    providerGroupSummaryVersionDetails.concernRoleID = providerGroup.getID();
    providerGroupSummaryVersionDetails.recordStatus = providerGroup.getLifecycleState().getCode();
    providerGroupSummaryVersionDetails.referenceNumber = providerGroup.getPrimaryAlternateID();
    providerGroupSummaryVersionDetails.versionNo = providerGroup.getVersionNo();

    concernRoleKey.concernRoleID = providerGroup.getID();
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    providerGroupSummaryVersionDetails.name = concernRoleDtls.concernRoleName;

    addressKey.addressID = concernRoleDtls.primaryAddressID;

    addressElementDtlsList = addressElementObj.readAddressElementDetails(
      addressKey);

    for (final AddressElementDtls addressElementDtls : addressElementDtlsList.dtls.items()) {

      if (ADDRESSELEMENTTYPEEntry.CITY.getCode().equals(
        addressElementDtls.elementType)) {

        providerGroupSummaryVersionDetails.city = addressElementDtls.elementValue;
      }
      
      if (ADDRESSELEMENTTYPEEntry.LINE1.getCode().equals(
        addressElementDtls.elementType)) {

        providerGroupSummaryVersionDetails.street1 = addressElementDtls.elementValue;
      }
    }

    MaintainAdminConcernRole maintainAdminConcernRole = new MaintainAdminConcernRole();

    providerGroupSummaryVersionDetails.owner = maintainAdminConcernRole.getProviderOrganisationOwner(concernRoleKey).userName;
    
    // BEGIN, CR00236233, GP
    User user = userDAO.get(providerGroupSummaryVersionDetails.owner);

    providerGroupSummaryVersionDetails.ownerFullName = user.getFullName();
    // END, CR00236233
    
    // BEGIN, CR00234497, PS
    if (ProviderGroupStatusEntry.ACTIVE.equals(
      providerGroup.getLifecycleState())) {

      providerGroupSummaryVersionDetails.editIndicator = true;
    }

    // END, CR00234497
    return providerGroupSummaryVersionDetails;
  }
  
  /**
   * Sorts a set of provider groups in ascending order of the reference number.
   *
   * @param unsortedProviderGroups
   * The set of unsorted provider groups.
   *
   * @return A list of provider groups by sorted in ascending order of the
   * reference number.
   */
  protected ProviderGroupSummaryVersionDetailsList sortProviderGroupsByReferenceNumber(
    final ProviderGroupSummaryVersionDetailsList unsortedProviderGroups) {

    List<ProviderGroupSummaryVersionDetails> providerGroupSummaryVersionDetailsList = new ArrayList<ProviderGroupSummaryVersionDetails>();

    for (final ProviderGroupSummaryVersionDetails providerGroupSummaryVersionDetails : 
      unsortedProviderGroups.providerGroupSummaryVersionDetails.items()) {

      providerGroupSummaryVersionDetailsList.add(
        providerGroupSummaryVersionDetails);
    }

    Collections.sort(providerGroupSummaryVersionDetailsList,
      new Comparator<ProviderGroupSummaryVersionDetails>() {
      public int compare(final ProviderGroupSummaryVersionDetails lhs,
        ProviderGroupSummaryVersionDetails rhs) {
        return lhs.referenceNumber.compareTo(rhs.referenceNumber);
      }
    });

    ProviderGroupSummaryVersionDetailsList providerGroupSummaryVersionDetailsListSorted = new ProviderGroupSummaryVersionDetailsList();

    providerGroupSummaryVersionDetailsListSorted.providerGroupSummaryVersionDetails.addAll(
      providerGroupSummaryVersionDetailsList);

    return providerGroupSummaryVersionDetailsListSorted;
  }

  // END, CR00206542
  
  // BEGIN, CR00208860, AS
  /**
   * Sorts a set of Provider Group Associates by date.
   *
   * @param unsortedProviderGroupAssociateSummaryDetailsList
   * Contains set of unsorted Provider Group Associates.
   *
   * @return Sorted list of Provider Group Associates
   */
  protected ProviderGroupAssociateSummaryDetailsList sortProviderGroupAssociateDetailsByDate(
    final ProviderGroupAssociateSummaryDetailsList unsortedProviderGroupAssociateSummaryDetailsList) {

    List<ProviderGroupAssociateSummaryDetails> providerGroupAssociateSummaryDetailsList = new ArrayList<ProviderGroupAssociateSummaryDetails>();

    for (final ProviderGroupAssociateSummaryDetails providerGroupAssociateSummaryDetails : unsortedProviderGroupAssociateSummaryDetailsList.providerGroupAssociateSummaryDetails.items()) {
      providerGroupAssociateSummaryDetailsList.add(
        providerGroupAssociateSummaryDetails);
    }
    Collections.sort(providerGroupAssociateSummaryDetailsList,
      new Comparator<ProviderGroupAssociateSummaryDetails>() {
      public int compare(final ProviderGroupAssociateSummaryDetails lhs,
        ProviderGroupAssociateSummaryDetails rhs) {
        return rhs.startDate.compareTo(lhs.startDate);
      }
    });
    ProviderGroupAssociateSummaryDetailsList providerGroupAssociateSummaryDetailsListSorted = new ProviderGroupAssociateSummaryDetailsList();

    providerGroupAssociateSummaryDetailsListSorted.providerGroupAssociateSummaryDetails.addAll(
      providerGroupAssociateSummaryDetailsList);

    return providerGroupAssociateSummaryDetailsListSorted;
  }
  // END, CR00208860
}
