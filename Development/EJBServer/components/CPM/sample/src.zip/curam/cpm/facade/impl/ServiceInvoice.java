/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.impl.CuramConst;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.cpm.facade.fact.SILICorrectionFactory;
import curam.cpm.facade.intf.SILICorrection;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.ProviderSILItemDetails;
import curam.cpm.facade.struct.ProviderSILItemDetailsList;
import curam.cpm.facade.struct.ResolveSILIAdjustmentFactorDetails;
import curam.cpm.facade.struct.ResolveSILIAdjustmentFactorKey;
import curam.cpm.facade.struct.SILIAndClientKey;
import curam.cpm.facade.struct.SILIAndCorrectionHistoryDetails;
import curam.cpm.facade.struct.SILIAndCorrectionHistoryDetailsList;
import curam.cpm.facade.struct.SILIClientDetails;
import curam.cpm.facade.struct.SILIClientDetailsList;
import curam.cpm.facade.struct.SILICorrectionVersionKey;
import curam.cpm.facade.struct.SILIDetail;
import curam.cpm.facade.struct.SILIDetails;
import curam.cpm.facade.struct.SILIDetailsList;
import curam.cpm.facade.struct.SILITransactionDetails;
import curam.cpm.facade.struct.SILItemCorrectionDetails;
import curam.cpm.facade.struct.ServiceDetails;
import curam.cpm.facade.struct.ServiceInvoiceContextDescription;
import curam.cpm.facade.struct.ServiceInvoiceDetails;
import curam.cpm.facade.struct.ServiceInvoiceLineItemContextDescription;
import curam.cpm.facade.struct.ServiceInvoiceLineItemDetails;
import curam.cpm.facade.struct.ServiceInvoiceLineItemHistory;
import curam.cpm.facade.struct.ServiceInvoiceLineItemHistoryList;
import curam.cpm.facade.struct.ServiceInvoiceLineItemList;
import curam.cpm.facade.struct.ServiceInvoiceLineItemTransactionDetails;
import curam.cpm.facade.struct.ServiceInvoiceLineItemTransactionsList;
import curam.cpm.facade.struct.ServiceInvoiceLineItemsDetailsList;
import curam.cpm.facade.struct.ServiceInvoiceSearchKey;
import curam.cpm.facade.struct.ServiceInvoiceSummaryDetails;
import curam.cpm.facade.struct.ServiceInvoiceSummaryDetailsList;
import curam.cpm.facade.struct.UpdateSILIDetails;
import curam.cpm.facade.struct.UpdateServiceInvoiceLineItemDetails;
import curam.cpm.facade.struct.ViewServiceInvoiceLineItemDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.fact.SILITransactionFactory;
import curam.cpm.sl.entity.fact.ServiceInvoiceLineItemFactory;
import curam.cpm.sl.entity.intf.SILITransaction;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.RetrieveProviderSILIKey;
import curam.cpm.sl.entity.struct.SILIHistoryDtls;
import curam.cpm.sl.entity.struct.SILIHistoryKey;
import curam.cpm.sl.entity.struct.SILITransactionDtls;
import curam.cpm.sl.entity.struct.SILITransactionDtlsList;
import curam.cpm.sl.entity.struct.SILITransactionKey;
import curam.cpm.sl.entity.struct.SearchServiceInvoiceKey;
import curam.cpm.sl.entity.struct.ServiceInvoiceDtls;
import curam.cpm.sl.entity.struct.ServiceInvoiceKey;
import curam.cpm.sl.entity.struct.ServiceInvoiceLineItemDtls;
import curam.cpm.sl.entity.struct.ServiceInvoiceLineItemKey;
import curam.cpm.sl.fact.FinancialNotificationFactory;
import curam.cpm.sl.intf.FinancialNotification;
import curam.cpm.sl.struct.FinancialNotificationKey;
import curam.cpm.util.impl.WidgetHelper;
import curam.events.NEWINVOICECREATED;
import curam.events.PROVIDERMANAGEMENT;
import curam.financial.FinancialNotificationEvent;
import curam.financial.ServiceInvoiceDerivedStatus;
import curam.financial.ServiceInvoiceLineItemAdjustmentReason;
import curam.financial.ServiceInvoiceLineItemAdjustmentfactor;
import curam.financial.ServiceInvoiceLineItemStatus;
import curam.financial.impl.RETURN_INVOICES_RECEIVEDEntry;
import curam.financial.impl.SILIClientHistory;
import curam.financial.impl.SILIClientHistoryDAO;
import curam.financial.impl.ServiceInvoiceDAO;
import curam.financial.impl.ServiceInvoiceLineItem;
import curam.financial.impl.ServiceInvoiceLineItemClient;
import curam.financial.impl.ServiceInvoiceLineItemClientDAO;
import curam.financial.impl.ServiceInvoiceLineItemCorrection;
import curam.financial.impl.ServiceInvoiceLineItemCorrectionDAO;
import curam.financial.impl.ServiceInvoiceLineItemCorrectionHistory;
import curam.financial.impl.ServiceInvoiceLineItemCorrectionHistoryDAO;
import curam.financial.impl.ServiceInvoiceLineItemCorrectionStatusEntry;
import curam.financial.impl.ServiceInvoiceLineItemDAO;
import curam.financial.impl.ServiceInvoiceLineItemHistoryDAO;
import curam.financial.impl.ServiceInvoiceLineItemStatusEntry;
import curam.financial.impl.ServiceInvoiceLineItemTransaction;
import curam.financial.impl.ServiceInvoiceLineItemTransactionDAO;
import curam.financial.impl.ServiceInvoiceLineItemTransactionHelper;
import curam.financial.impl.ServiceInvoiceLineItemTransactionStatusEntry;
import curam.financial.impl.ServiceInvoiceLineItemTransactionTypeEntry;
import curam.message.SERVICEINVOICE;
import curam.message.SERVICEINVOICELINEITEM;
import curam.message.TRAINING;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.SERVICEINVOICEExceptionCreator;
import curam.message.impl.SERVICEINVOICELINEITEMExceptionCreator;
import curam.provider.impl.ProviderGroupAssociateDAO;
import curam.provider.impl.ProviderGroupDAO;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.serviceauthorization.impl.ServiceAuthorizationDAO;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItem;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.Money;
import curam.util.type.StringHelper;
import curam.util.type.StringList;


/**
 * {@inheritDoc}
 */
// Start CR00096126, JSP
public abstract class ServiceInvoice extends curam.cpm.facade.base.ServiceInvoice {
  // End CR00096126

  /**
   * Service Invoice DAO object
   */
  @Inject
  protected ServiceInvoiceDAO serviceInvoiceDAO;

  /**
   * Service Invoice Line Item DAO object
   */
  @Inject
  protected ServiceInvoiceLineItemDAO serviceInvoiceLineItemDAO;

  /**
   * Service Offering DAO object
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Service Invoice Line Item History DAO object
   */
  @Inject
  protected ServiceInvoiceLineItemHistoryDAO sILIHistoryDAO;

  /**
   * Service Authorization DAO object
   */
  @Inject
  protected ServiceAuthorizationDAO serviceAuthorizationDAO;

  /**
   * Provider Organization DAO object
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Service Invoice Line Item Transaction DAO object
   */
  @Inject
  protected ServiceInvoiceLineItemTransactionDAO siliTransactionDAO;

  /**
   * Provider Group Associate DAO object
   */
  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;

  /**
   * Provider Group DAO object
   */
  @Inject
  ProviderGroupDAO providerGroupDAO;

  // BEGIN, CR00158345, GP
  /**
   * Reference to Service Invoice Line Item Client DAO.
   */
  @Inject
  ServiceInvoiceLineItemClientDAO serviceInvoiceLineItemClientDAO;

  /**
   * Reference to Service Invoice Line Item Client History DAO.
   */
  @Inject
  SILIClientHistoryDAO siliClientHistoryDAO;

  /**
   * Reference to Service Invoice Line Item History DAO.
   */
  @Inject
  ServiceInvoiceLineItemHistoryDAO serviceInvoiceLineItemHistoryDAO;

  // END, CR00158345

  // BEGIN, CR00200393, SSK
  /**
   * Reference to service invoice line item correction DAO.
   */
  @Inject
  protected ServiceInvoiceLineItemCorrectionDAO siliCorrectionDAO;

  /**
   * Reference to service invoice line item DAO.
   */
  @Inject
  protected ServiceInvoiceLineItemCorrectionHistoryDAO siliCorrectionHistoryDAO;

  // END, CR00200393

  // BEGIN, CR00216897, RPB
  /**
   * Reference to service invoice line item transaction helper.
   */
  @Inject
  protected ServiceInvoiceLineItemTransactionHelper siliTransactionHelper;

  // END, CR00216897

  /**
   * No-arg constructor used by Guice.
   */
  public ServiceInvoice() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public ServiceInvoiceKey createServiceInvoice(ServiceInvoiceDtls details)
    throws InformationalException {
    // create a new instance
    final curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.newInstance();

    // create an instance of the return struct
    final ServiceInvoiceKey key = new ServiceInvoiceKey();

    // map details passed from client
    setServiceInvoiceFields(serviceInvoice, details);
    serviceInvoice.insert();

    key.serviceInvoiceID = serviceInvoice.getID();

    // return to the client
    return key;
  }

  /**
   * {@inheritDoc}
   */
  public void updateServiceInvoice(ServiceInvoiceDtls serviceInvoiceDtls)
    throws InformationalException {
    final curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
      serviceInvoiceDtls.serviceInvoiceID);

    // START CR00094326, JSP
    ServiceInvoiceDetails serviceInvoiceDetails = serviceInvoice.getServiceInvoiceDerivedStatus();

    // END CR00094326

    // Begin CR00096779, ABS
    if (serviceInvoice.getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)
      // End CR00096779
      || !serviceInvoiceDetails.serviceInvoiceDerivedStatus.equals(
        ServiceInvoiceDerivedStatus.OPEN)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICEExceptionCreator.ERR_SERVICEINVOICE_XRV_THIS_SERVICE_INVOICE_IS_NOT_OPEN_IT_CANNOT_BE_MODIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else {
      // map details passed from client
      setServiceInvoiceFields(serviceInvoice, serviceInvoiceDtls);

      serviceInvoice.modify(serviceInvoice.getVersionNo());
    }
    ValidationHelper.failIfErrorsExist();
  }

  /**
   * {@inheritDoc}
   */
  // START CR00094504, JSP
  public void cancelServiceInvoice(
    curam.cpm.facade.struct.ServiceInvoiceKey invoiceKey)
    throws AppException, InformationalException {

    final curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
      invoiceKey.key.serviceInvoiceID);
    // END CR00094504

    // START CR00094326, JSP
    ServiceInvoiceDetails serviceInvoiceDetails = serviceInvoice.getServiceInvoiceDerivedStatus();

    // END CR00094326
    // Begin CR00096779, ABS
    if (serviceInvoice.getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)
      // End CR00096779, ABS
      || !serviceInvoiceDetails.serviceInvoiceDerivedStatus.equals(
        ServiceInvoiceDerivedStatus.OPEN)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICEExceptionCreator.ERR_SERVICEINVOICE_XRV_THIS_SERVICE_INVOICE_IS_NOT_OPEN_IT_CANNOT_BE_DELETED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    } else {
      serviceInvoice.cancel(invoiceKey.versionNo);
    }
    ValidationHelper.failIfErrorsExist();

    // create event
    Event cancelServiceInvoice = new Event();

    cancelServiceInvoice.eventKey = NEWINVOICECREATED.INVOICECANCELLED;
    // START CR00094504, JSP
    cancelServiceInvoice.primaryEventData = invoiceKey.key.serviceInvoiceID;
    // END CR00094504

    // The service invoice has been canceled
    // Raise event to close this workflow task.
    EventService.raiseEvent(cancelServiceInvoice);
  }

  /**
   * {@inheritDoc}
   */
  public ServiceInvoiceDetails viewServiceInvoice(ServiceInvoiceKey key) {

    ServiceInvoiceDetails serviceInvoiceDetails = new ServiceInvoiceDetails();

    final curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
      key.serviceInvoiceID);

    ServiceInvoiceDtls serviceInvoiceDtls = getServiceInvoiceFields(
      serviceInvoice);

    serviceInvoiceDetails.serviceInvoiceDtls.assign(serviceInvoiceDtls);

    if (!(serviceInvoice.getLifecycleState().getCode().equals(
      RECORDSTATUS.CANCELLED))) {
      // START CR00094326, JSP
      ServiceInvoiceDetails serviceInvoiceStatus = serviceInvoice.getServiceInvoiceDerivedStatus();

      // END CR00094326
      serviceInvoiceDetails.serviceInvoiceDerivedStatus = serviceInvoiceStatus.serviceInvoiceDerivedStatus;
    } else {
      serviceInvoiceDetails.serviceInvoiceDerivedStatus = ServiceInvoiceDerivedStatus.CANCELED;
    }
    serviceInvoiceDetails.desc = getServiceInvoiceContextDescription(key);

    // return to the client
    return serviceInvoiceDetails;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceInvoiceLineItemKey createServiceInvoiceLineItem(
    ServiceInvoiceLineItemDtls serviceInvoiceLineItemDtls)
    throws AppException, InformationalException {
    // BEGIN, CR00084504, SP
    curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
      serviceInvoiceLineItemDtls.serviceInvoiceID);

    final ServiceInvoiceLineItemKey key = serviceInvoice.addLineItem(
      serviceInvoiceLineItemDtls);

    // END, CR00084504
    return key;
  }

  // BEGIN, CR00358952, SS
  /**
   * {@inheritDoc}
   */
  public ServiceInvoiceLineItemDetails retrieveServiceInvoiceLineItem(
    final ServiceInvoiceLineItemKey key) throws AppException,
      InformationalException {
    // retrieve the instance of the entity
    final ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.serviceInvoiceLineItemID);
    final ServiceInvoiceLineItemDetails serviceInvoiceLineItemDetails = new ServiceInvoiceLineItemDetails();

    serviceInvoiceLineItemDetails.details.assign(
      getServiceInvoiceLineItemFields(serviceInvoiceLineItem));
    serviceInvoiceLineItemDetails.details.serviceAuthorizationLIID = serviceInvoiceLineItem.getServiceAuthorizationLineItem().getID();
    serviceInvoiceLineItemDetails.details.validityStatus = serviceInvoiceLineItem.getValidityStatus().getCode();
    serviceInvoiceLineItemDetails.details.allowDuplicateSILI = serviceInvoiceLineItem.getAllowDuplicateSILI();
    serviceInvoiceLineItemDetails.details.expProInd = serviceInvoiceLineItem.isInExceptionProcessing();

    return serviceInvoiceLineItemDetails;
  }

  // END, CR00358952

  /**
   * {@inheritDoc}
   */
  public ServiceInvoiceLineItemDetails viewServiceInvoiceLineItem(
    ServiceInvoiceLineItemKey key) throws AppException,
      InformationalException {
    // retrieve the instance of the entity
    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.serviceInvoiceLineItemID);
    // return to the client
    ServiceInvoiceLineItemDetails serviceInvoiceLineItemDetails = new ServiceInvoiceLineItemDetails();

    serviceInvoiceLineItemDetails.details.assign(
      getServiceInvoiceLineItemFields(serviceInvoiceLineItem));

    if (serviceInvoiceLineItemDetails.details.saReferenceNo == null
      || serviceInvoiceLineItemDetails.details.saReferenceNo.length() == 0) {
      serviceInvoiceLineItemDetails.derivedSA = true;
    } else {
      serviceInvoiceLineItemDetails.derivedSA = false;
    }
    // START CR00094326, JSP
    serviceInvoiceLineItemDetails.details.expProInd = serviceInvoiceLineItem.isInExceptionProcessing();
    // END CR00094326

    final ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceInvoiceLineItem.getServiceAuthorizationLineItem();
    // Begin CR00085400, ABS
    boolean frcExist = false;

    try {
      frcExist = serviceInvoiceLineItem.matchAgainstFlatRateContract();
    } catch (Exception e) {// Suppress the exceptions
    }
    // End CR00085400
    // CR00085047 starts here
    if (!serviceInvoiceLineItemDetails.details.status.equals(
      ServiceInvoiceLineItemStatusEntry.OPEN.toString())) {
      if (!frcExist) {
        if (serviceAuthorizationLineItem != null) {

          serviceInvoiceLineItemDetails.serviceAuthorizationID = serviceAuthorizationLineItem.getServiceAuthorization().getID();
        } else if (serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber()
          != null
            && !serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber().equals(
              GeneralConstants.kEmpty)) {
          curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.findByReferenceNumber(
            serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber());

          if (serviceAuthorization != null) {
            serviceInvoiceLineItemDetails.serviceAuthorizationID = serviceAuthorization.getID();
          }
        }
      }
    }
    // CR00085047 ends here
    ServiceDetails serviceDetails = getServiceDetails(
      serviceInvoiceLineItem.getServiceOffering());

    Double amountPaid = new Double(0);

    // BEGIN CR00085040, GYH
    // Populate the calculated amount to amountPaid when
    // status of the service invoice line item is not CANCELED/DENIED
    if (!serviceInvoiceLineItemDetails.details.status.equals(
      ServiceInvoiceLineItemStatus.CANCELED)
        && !serviceInvoiceLineItemDetails.details.status.equals(
          ServiceInvoiceLineItemStatus.DENIED)) {
      // END CR00085040
      for (ServiceInvoiceLineItemTransaction sILITransaction : serviceInvoiceLineItem.getTransactions()) {
        if (sILITransaction.getTransactionType().equals(
          ServiceInvoiceLineItemTransactionTypeEntry.PAID)
            && sILITransaction.getStatus().equals(
              ServiceInvoiceLineItemTransactionStatusEntry.ACTIVE)) {
          amountPaid += sILITransaction.getAmount().getValue();
        }
      }
      // BEGIN CR00085040, GYH
    }
    // END CR00085040

    // Begin CR00085400, ABS
    if (serviceInvoiceLineItemDetails.details.status.equals(
      ServiceInvoiceLineItemStatusEntry.OPEN.toString())
        && serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber().length()
          == 0) {
      curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = null;

      try {
        serviceAuthorization = serviceInvoiceLineItem.retrieveServiceAuthorization();
      } catch (AppException ap) {// suppress exception if occurred
      }
      if (serviceAuthorization != null && !frcExist) {
        serviceInvoiceLineItemDetails.details.saReferenceNo = serviceAuthorization.getReferenceNumber();
      }
    }
    // End CR00085400

    serviceInvoiceLineItemDetails.dtls.amountPaid = new Money(amountPaid);

    serviceInvoiceLineItemDetails.dtls.service = serviceDetails.service;
    serviceInvoiceLineItemDetails.desc = getServiceInvoiceLineItemContextDescription(
      key);
    // Begin CR00085400, ABS
    // START CR00094326, JSP
    // BEGIN CR00103810, ABS
    if (serviceInvoiceLineItem.isInExceptionProcessing()) {
      // END CR00094326
      serviceInvoiceLineItemDetails.exceptionTaskCreated = SERVICEINVOICELINEITEM.INF_SERVICEINVOICELINEITEM_EXCEPTIONTASKCREATED_YES.getMessageText(
        TransactionInfo.getProgramLocale());
    } else {
      serviceInvoiceLineItemDetails.exceptionTaskCreated = SERVICEINVOICELINEITEM.INF_SERVICEINVOICELINEITEM_EXCEPTIONTASKCREATED_NO.getMessageText(
        TransactionInfo.getProgramLocale());
    }
    // END, CR00103810

    // End CR00085400

    if (ServiceInvoiceLineItemStatus.PENDINGAPPROVAL.equals(
      serviceInvoiceLineItemDetails.details.status)) {
      serviceInvoiceLineItemDetails.deleteSILIInd = false;
    } else {
      serviceInvoiceLineItemDetails.deleteSILIInd = true;
    }

    if (serviceInvoiceLineItemDetails.serviceAuthorizationID != 0
      && (serviceInvoiceLineItemDetails.details.saReferenceNo != null
        && !(GeneralConstants.kEmpty.equals(
          serviceInvoiceLineItemDetails.details.saReferenceNo)))) {
      serviceInvoiceLineItemDetails.flag = true;
    }

    // START CR00094326, JSP
    serviceInvoiceLineItemDetails.excprocInd = serviceInvoiceLineItem.isInExceptionProcessing();
    // BEGIN, CR00103810, ABS
    // Determine whether the exception task is created during submission of
    // approval
    if (serviceInvoiceLineItemDetails.excprocInd == true
      && serviceInvoiceLineItem.getStatus().equals(
        ServiceInvoiceLineItemStatusEntry.PENDINGAPPROVAL)) {

      serviceInvoiceLineItemDetails.approvalExceptionTaskInd = true;
    }
    // END, CR00103810
    // END CR00094326
    // Set allowDuplicateSILI flag if service invoice line item is a duplicate
    // Begin CR00100313,CR00095289, ABS
    serviceInvoiceLineItem.matchIdentifiers(false);
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    InformationalException exception = informationalManager.obtainInformationalAsException();

    if (exception != null) {
      serviceInvoiceLineItemDetails.details.allowDuplicateSILI = ValidationHelper.informationalContains(
        exception,
        SERVICEINVOICELINEITEM.ERR_SERVICEINVOICELINEITEM_XRV_DUPLICATE_SERVICE_INVOICE_LINE_ITEM);
    }
    // End CR00100313,CR00095289

    serviceInvoiceLineItemDetails.clientName = serviceInvoiceLineItemDetails.details.clientFirstName
      + GeneralConstants.kSpace
      + serviceInvoiceLineItemDetails.details.clientLastName;

    return serviceInvoiceLineItemDetails;

  }

  /**
   * Reads the Service Invoice Line Item details after creation.
   *
   * @param key
   * Contains service invoice line item ID.
   * @return ViewServiceInvoiceLineItemDetails Contains service invoice line
   * item details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewServiceInvoiceLineItemDetails viewServiceInvoiceLineItemInsertion(
    ServiceInvoiceLineItemKey key) throws AppException,
      InformationalException {
    // retrieve the instance of the entity
    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.serviceInvoiceLineItemID);
    // return to the client
    ViewServiceInvoiceLineItemDetails serviceInvoiceLineItemDetails = new ViewServiceInvoiceLineItemDetails();

    serviceInvoiceLineItemDetails.dtls.details.assign(
      getServiceInvoiceLineItemFields(serviceInvoiceLineItem));
    if (serviceInvoiceLineItemDetails.dtls.details.saReferenceNo == null
      || serviceInvoiceLineItemDetails.dtls.details.saReferenceNo.length() == 0) {
      serviceInvoiceLineItemDetails.dtls.derivedSA = true;
    } else {
      serviceInvoiceLineItemDetails.dtls.derivedSA = false;
    }
    // START CR00094326, JSP
    serviceInvoiceLineItemDetails.dtls.details.expProInd = serviceInvoiceLineItem.isInExceptionProcessing();
    // END CR00094326

    final ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceInvoiceLineItem.getServiceAuthorizationLineItem();
    // Begin CR00085400, ABS
    boolean frcExist = false;

    try {
      frcExist = serviceInvoiceLineItem.matchAgainstFlatRateContract();
    } catch (Exception e) {// Suppress the exceptions
    }
    // End CR00085400, ABS
    // CR00085047 starts here
    if (!serviceInvoiceLineItemDetails.dtls.details.status.equals(
      ServiceInvoiceLineItemStatusEntry.OPEN.toString())) {
      if (!frcExist) {
        if (serviceAuthorizationLineItem != null) {

          serviceInvoiceLineItemDetails.dtls.serviceAuthorizationID = serviceAuthorizationLineItem.getServiceAuthorization().getID();
        } else if (serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber()
          != null
            && !serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber().equals(
              GeneralConstants.kEmpty)) {
          curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.findByReferenceNumber(
            serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber());

          if (serviceAuthorization != null) {
            serviceInvoiceLineItemDetails.dtls.serviceAuthorizationID = serviceAuthorization.getID();
          }
        }
      }
      // // CR00085047 ends here
    }

    // Begin CR00085400, ABS
    if (serviceInvoiceLineItemDetails.dtls.details.status.equals(
      ServiceInvoiceLineItemStatusEntry.OPEN.toString())
        && serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber().length()
          == 0) {
      curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = null;

      try {
        serviceAuthorization = serviceInvoiceLineItem.retrieveServiceAuthorization();
      } catch (AppException ap) {// suppress exception if occurred
      }
      if (serviceAuthorization != null && !frcExist) {
        serviceInvoiceLineItemDetails.dtls.details.saReferenceNo = serviceAuthorization.getReferenceNumber();
      }
    }

    // START CR00094326, JSP
    if (serviceInvoiceLineItem.isInExceptionProcessing()) {
      // END CR00094326
      serviceInvoiceLineItemDetails.dtls.exceptionTaskCreated = SERVICEINVOICELINEITEM.INF_SERVICEINVOICELINEITEM_EXCEPTIONTASKCREATED_YES.getMessageText(
        TransactionInfo.getProgramLocale());
    } else {
      serviceInvoiceLineItemDetails.dtls.exceptionTaskCreated = SERVICEINVOICELINEITEM.INF_SERVICEINVOICELINEITEM_EXCEPTIONTASKCREATED_NO.getMessageText(
        TransactionInfo.getProgramLocale());
    }
    // End CR00085400
    ServiceDetails serviceDetails = new ServiceDetails();

    serviceDetails = getServiceDetails(
      serviceInvoiceLineItem.getServiceOffering());

    Double amountPaid = new Double(0);

    for (ServiceInvoiceLineItemTransaction sILITransaction : serviceInvoiceLineItem.getTransactions()) {
      if (sILITransaction.getTransactionType().equals(
        ServiceInvoiceLineItemTransactionTypeEntry.PAID)
          && sILITransaction.getStatus().equals(
            ServiceInvoiceLineItemTransactionStatusEntry.ACTIVE)) {
        amountPaid += sILITransaction.getAmount().getValue();
      }
    }

    serviceInvoiceLineItemDetails.dtls.amountPaid = new Money(amountPaid);

    serviceInvoiceLineItemDetails.dtls.dtls.service = serviceDetails.service;
    serviceInvoiceLineItemDetails.dtls.desc = getServiceInvoiceLineItemContextDescription(
      key);

    serviceInvoiceLineItem.matchIdentifiers(false);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] messages = informationalManager.obtainInformationalAsString();

    for (String message : messages) {
      InformationalMsgDtls dtls = new InformationalMsgDtls();

      dtls.informationMsgTxt = message;
      serviceInvoiceLineItemDetails.msgList.dtls.addRef(dtls);
    }

    // Begin CR00079491, ABS
    if (ServiceInvoiceLineItemStatus.PENDINGAPPROVAL.equals(
      serviceInvoiceLineItemDetails.dtls.details.status)) {
      serviceInvoiceLineItemDetails.dtls.deleteSILIInd = false;
    } else {
      serviceInvoiceLineItemDetails.dtls.deleteSILIInd = true;
    }
    // End CR00079491

    if (serviceInvoiceLineItemDetails.dtls.serviceAuthorizationID != 0
      && (serviceInvoiceLineItemDetails.dtls.details.saReferenceNo != null
        && !(GeneralConstants.kEmpty.equals(
          serviceInvoiceLineItemDetails.dtls.details.saReferenceNo)))) {
      serviceInvoiceLineItemDetails.dtls.flag = true;
    }

    // START CR00094326, JSP
    serviceInvoiceLineItemDetails.dtls.excprocInd = serviceInvoiceLineItem.isInExceptionProcessing();
    // END CR00094326

    return serviceInvoiceLineItemDetails;

  }

  /**
   * {@inheritDoc}
   */
  public void updateServiceInvoiceLineItem(
    UpdateServiceInvoiceLineItemDetails details)
    throws InformationalException {

    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      details.details.serviceInvoiceLineItemID);

    if (serviceInvoiceLineItem.getStatus().getCode().equals(
      ServiceInvoiceLineItemStatus.OPEN)) {

      setServiceInvoiceLineItemFields(serviceInvoiceLineItem, details.details);

      serviceInvoiceLineItem.modify(details.details.versionNo);

    } else {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICELINEITEM_XRV_THIS_SERVICE_INVOICE_LINE_ITEM_IS_NOT_OPEN_IT_CANNOT_BE_MODIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }
    ValidationHelper.failIfErrorsExist();
  }

  /**
   * {@inheritDoc}
   */
  // START CR00094504, JSP
  public void cancelServiceInvoiceLineItem(
    curam.cpm.facade.struct.ServiceInvoiceLineItemKey siliKey)
    throws AppException, InformationalException {

    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      siliKey.key.serviceInvoiceLineItemID);

    serviceInvoiceLineItem.cancel(siliKey.versionNo);
    // END CR00094504
  }

  // BEGIN, CR00200393, SSK
  /**
   * Reads the list of Service Invoice Line Item for the service invoice.
   *
   * @param key
   * Contains service invoice ID.
   * @return ServiceInvoiceLineItemsDetailsList The list of service invoice line
   * item.
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServiceInvoice#listAllServiceInvoiceLineItems(ServiceInvoiceKey)}
   * . As part of the merging service invoice line item and service
   * invoice line item correction changes has been done to maintain
   * correction clients in service invoice line item client and
   * maintain correction history in service invoice line item
   * history entity. See release note: CR00200393.
   */
  @Deprecated
  public ServiceInvoiceLineItemsDetailsList listServiceInvoiceLineItems(
    ServiceInvoiceKey key) {

    // END, CR00200393
    ServiceInvoiceLineItemsDetailsList serviceInvoiceLineItemsDetailsList = new ServiceInvoiceLineItemsDetailsList();

    if (key.serviceInvoiceID != 0) {
      curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
        key.serviceInvoiceID);

      final Set<curam.financial.impl.ServiceInvoiceLineItem> serviceInvoiceLineItems = serviceInvoiceLineItemDAO.listServiceInvoiceLineItems(
        serviceInvoice);

      // BEGIN, CR00137716, ABS
      // Sort the service invoice line items by client name.
      List<curam.financial.impl.ServiceInvoiceLineItem> serviceInvoiceLineItemList = sortSILIByClientName(
        serviceInvoiceLineItems);

      for (final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem : serviceInvoiceLineItemList) {
        // END, CR00137716

        ServiceInvoiceLineItemDetails serviceInvoiceLineItemDetails = new ServiceInvoiceLineItemDetails();

        serviceInvoiceLineItemDetails.details.assign(
          getServiceInvoiceLineItemFields(serviceInvoiceLineItem));
        serviceInvoiceLineItemDetails.SILIIDVersionNo = serviceInvoiceLineItem.getID()
          + GeneralConstants.kUnderScoreString
          + serviceInvoiceLineItem.getVersionNo();

        // BEGIN, CR00158345, GP
        List<ServiceInvoiceLineItemClient> serviceInvoiceLineItemClients = sortSILIClientByClientName(
          serviceInvoiceLineItem.getServiceInvoiceLineItemClients());

        ServiceInvoiceLineItemClient serviceInvoiceLineItemClient = serviceInvoiceLineItemClients.iterator().next();

        if (!(serviceInvoiceLineItemClient.getClientFirstName().equals(
          GeneralConstants.kEmpty))) {
          serviceInvoiceLineItemDetails.clientName = serviceInvoiceLineItemClient.getClientFirstName();
        }
        if (!(serviceInvoiceLineItemClient.getClientLastName().equals(
          GeneralConstants.kEmpty))) {
          serviceInvoiceLineItemDetails.clientName = serviceInvoiceLineItemDetails.clientName
            + CuramConst.gkSpace
            + serviceInvoiceLineItemClient.getClientLastName();
        }
        // END, CR00158345

        // START CR00094326, JSP
        Double amountPaid = serviceInvoiceLineItem.retrieveSILIAmountPaid();

        // END CR00094326

        serviceInvoiceLineItemDetails.amountPaid = new Money(amountPaid);
        serviceInvoiceLineItemDetails.dtls = getServiceDetails(
          serviceInvoiceLineItem.getServiceOffering());
        // START CR00094326, JSP
        serviceInvoiceLineItemDetails.excprocInd = serviceInvoiceLineItem.isInExceptionProcessing();
        // END CR00094326, JSP
        serviceInvoiceLineItemsDetailsList.dtlsList.addRef(
          serviceInvoiceLineItemDetails);
      }
    }

    serviceInvoiceLineItemsDetailsList.desc = getServiceInvoiceContextDescription(
      key);

    return serviceInvoiceLineItemsDetailsList;
  }

  /**
   * Reads the Service Offering details.
   *
   * @param serviceOffering
   * Contains service offering ID.
   * @return ServiceDetails The service offering details.
   */
  // BEGIN, CR00177241, PM
  protected ServiceDetails getServiceDetails(ServiceOffering serviceOffering) {
    // END, CR00177241
    ServiceDetails serviceDetails = new ServiceDetails();

    if (serviceOffering != null) {
      serviceDetails.service = serviceOffering.getName();
    }
    return serviceDetails;
  }

  // BEGIN, CR00200393, SSK
  /**
   * Reads Service Invoice Line Item History for the service invoice line item.
   *
   * @param key
   * Contains service invoice line item ID.
   * @return ServiceInvoiceLineItemHistoryList The list of service invoice line
   * item history.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServiceInvoice#viewSILIAndCorrectionHistory(ServiceInvoiceLineItemKey)}
   * . As part of the merging service invoice line item and service
   * invoice line item correction changes has been done to maintain
   * correction clients in service invoice line item client and
   * maintain correction history in service invoice line item
   * history entity. See release note: CR00200393.
   */
  @Deprecated
  public ServiceInvoiceLineItemHistoryList viewServiceInvoiceLineItemHistory(
    ServiceInvoiceLineItemKey key) {
    // END, CR00200393

    // Return Struct
    ServiceInvoiceLineItemHistoryList serviceInvoiceLineItemHistoryList = new ServiceInvoiceLineItemHistoryList();

    // START CR00094326, JSP
    ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.serviceInvoiceLineItemID);

    Set<curam.financial.impl.ServiceInvoiceLineItemHistory> sILIHistorys = sILIHistoryDAO.searchByServiceInvoiceLineItem(
      serviceInvoiceLineItem);

    // END CR00094326

    for (final curam.financial.impl.ServiceInvoiceLineItemHistory sILIHistory : sILIHistorys) {

      SILIHistoryDtls sILIHistoryDtls = new SILIHistoryDtls();
      ServiceInvoiceLineItemHistory history = new ServiceInvoiceLineItemHistory();

      history.dtls = setServiceDetails(sILIHistoryDtls, sILIHistory);
      history.details = getServiceDetails(sILIHistory.getServiceOffering());
      serviceInvoiceLineItemHistoryList.dtlsList.addRef(history);
    }
    serviceInvoiceLineItemHistoryList.desc = getServiceInvoiceLineItemContextDescription(
      key);

    // BEGIN, CR00153049, AS
    // Sort the service invoice line items history first by changed date and
    // time and then by status.
    serviceInvoiceLineItemHistoryList = sortSILIHistoryByTransactionType(
      sortHistoryArray(serviceInvoiceLineItemHistoryList));

    // END, CR00153049

    return serviceInvoiceLineItemHistoryList;
  }

  /**
   * Creates a Service Invoice Line Item using the details of an existing
   * service invoice line item.
   *
   * @param serviceInvoiceLineItemDtls
   * Contains service invoice line item details to be inserted.
   * @return ServiceInvoiceLineItemKey Contains service invoice line item ID.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceInvoiceLineItemKey createNewServiceInvoiceLineItem(
    ServiceInvoiceLineItemDtls serviceInvoiceLineItemDtls)
    throws AppException, InformationalException {
    // BEGIN, CR00084504, SP
    curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
      serviceInvoiceLineItemDtls.serviceInvoiceID);
    final ServiceInvoiceLineItemKey key = serviceInvoice.addLineItem(
      serviceInvoiceLineItemDtls);

    // END, CR00084504
    return key;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceInvoiceSummaryDetailsList searchServiceInvoice(
    SearchServiceInvoiceKey key) throws InformationalException {

    ServiceInvoiceSummaryDetailsList serviceInvoiceSummaryDtlsList = new ServiceInvoiceSummaryDetailsList();
    Boolean searchByReferenceNo = false;
    Boolean searchByPayeereferencenumber = false;
    Boolean searchByReceiptDateFrom = false;
    Boolean searchByReceiptDateTo = false;
    Boolean searchByPayeeName = false;
    Boolean searchByStatus = false;
    // BEGIN CR00117758, KR
    Boolean searchByOriginatorName = false;
    Boolean searchByOriginatorReferenceNo = false;

    // END CR00117758
    if (key.referenceNo.equals(GeneralConstants.kEmpty)
      && key.payeeName.equals(GeneralConstants.kEmpty)
      && key.payeeReferenceNo.equals(GeneralConstants.kEmpty)
      && key.status.equals(GeneralConstants.kEmpty)
      && key.receiptDateFrom.isZero() && key.receiptDateTo.isZero() // BEGIN CR00117758, KR
      && key.originatorName.equals(GeneralConstants.kEmpty)
      && key.originatorReferenceNo.equals(GeneralConstants.kEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICEExceptionCreator.ERR_SERVICEINVOICE_XRV_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    } else if (!key.receiptDateTo.isZero()
      && key.receiptDateFrom.after(key.receiptDateTo)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICEExceptionCreator.ERR_SERVICEINVOICE_XRV_THE_RECEIPT_DATE_FROM_MUST_BE_ON_OR_BEFORE_THE_RECEIPT_DATE_TO(
          key.receiptDateFrom, key.receiptDateTo),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    } else if (key.referenceNo.equals(GeneralConstants.kEmpty)
      && key.payeeName.equals(GeneralConstants.kEmpty)
      && key.payeeReferenceNo.equals(GeneralConstants.kEmpty)
      && !key.status.equals(GeneralConstants.kEmpty)
      && key.receiptDateFrom.isZero() && key.receiptDateTo.isZero()) {

      final Set<curam.financial.impl.ServiceInvoice> activeServiceInvoices = serviceInvoiceDAO.listAllActiveServiceInvoices();

      for (final curam.financial.impl.ServiceInvoice activeServiceInvoice : sortByRecieptDate(
        activeServiceInvoices)) {

        // START CR00094326, JSP
        ServiceInvoiceDetails silidetails = new ServiceInvoiceDetails();

        silidetails = activeServiceInvoice.getServiceInvoiceDerivedStatus();
        // END CR00094326

        if (silidetails.serviceInvoiceDerivedStatus.equals(key.status)) {

          ServiceInvoiceSummaryDetails dtls = new ServiceInvoiceSummaryDetails();

          dtls.serviceInvoiceID = activeServiceInvoice.getID();
          dtls.referenceNo = activeServiceInvoice.getReferenceNo();
          dtls.receiptDate = activeServiceInvoice.getReceiptDate();
          dtls.creationDate = activeServiceInvoice.getCreationDate();
          dtls.originatorName = activeServiceInvoice.getOriginatorName();

          serviceInvoiceSummaryDtlsList.summaryDetailsList.addRef(dtls);
        }
      }
    } else {

      // BEGIN, CR00121613, GP
      if (key.referenceNo.length() > 0) {
        searchByReferenceNo = true;
      }
      if (key.payeeName.length() > 0) {
        searchByPayeeName = true;
      }
      if (key.payeeReferenceNo.length() > 0) {
        searchByPayeereferencenumber = true;
      }
      if (!key.receiptDateFrom.isZero()) {
        searchByReceiptDateFrom = true;
      }
      if (!key.receiptDateTo.isZero()) {
        searchByReceiptDateTo = true;
      }
      if (key.status.length() > 0) {
        searchByStatus = true;
      }
      if (key.originatorName.length() > 0) {
        searchByOriginatorName = true;
      }

      if (key.originatorReferenceNo.length() > 0) {
        searchByOriginatorReferenceNo = true;
      }

      final Set<curam.financial.impl.ServiceInvoice> serviceInvoiceDetails = serviceInvoiceDAO.searchServiceInvoiceDetails(
        key.referenceNo, key.payeeReferenceNo, key.receiptDateFrom,
        key.receiptDateTo, key.payeeName, key.status, searchByReferenceNo,
        searchByPayeereferencenumber, searchByReceiptDateFrom,
        searchByReceiptDateTo, searchByPayeeName, searchByStatus, false,
        Long.valueOf(0), true, Long.valueOf(0), false,
        CPMConstants.kEmptyString, Long.valueOf(0), false, key.originatorName,
        searchByOriginatorName, key.originatorReferenceNo,
        searchByOriginatorReferenceNo);

      // END, CR00121613

      for (final curam.financial.impl.ServiceInvoice serviceInvoice : sortByRecieptDate(
        serviceInvoiceDetails)) {

        ServiceInvoiceSummaryDetails details = new ServiceInvoiceSummaryDetails();
        ServiceInvoiceDetails silidetails = new ServiceInvoiceDetails();

        if (key.status.equals(GeneralConstants.kEmpty)) {

          details.serviceInvoiceID = serviceInvoice.getID();
          details.referenceNo = serviceInvoice.getReferenceNo();
          details.receiptDate = serviceInvoice.getReceiptDate();
          details.creationDate = serviceInvoice.getCreationDate();
          details.originatorName = serviceInvoice.getOriginatorName();

          serviceInvoiceSummaryDtlsList.summaryDetailsList.addRef(details);
        } else {
          // START CR00094326, JSP
          silidetails = serviceInvoice.getServiceInvoiceDerivedStatus();
          // END CR00094326
          if (silidetails.serviceInvoiceDerivedStatus.equals(key.status)) {

            details.serviceInvoiceID = serviceInvoice.getID();
            details.referenceNo = serviceInvoice.getReferenceNo();
            details.receiptDate = serviceInvoice.getReceiptDate();
            details.creationDate = serviceInvoice.getCreationDate();
            details.originatorName = serviceInvoice.getOriginatorName();

            serviceInvoiceSummaryDtlsList.summaryDetailsList.addRef(details);
          }

        }

      }
    }
    ValidationHelper.failIfErrorsExist();

    for (int i = 0; i < serviceInvoiceSummaryDtlsList.summaryDetailsList.size(); i++) {

      // START CR00094326, JSP
      curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
        serviceInvoiceSummaryDtlsList.summaryDetailsList.item(i).serviceInvoiceID);

      final Set<curam.financial.impl.ServiceInvoiceLineItem> serviceInvoiceLineItems = serviceInvoiceLineItemDAO.listServiceInvoiceLineItems(
        serviceInvoice);
      // END CR00094326

      ServiceInvoiceKey serviceInvoiceKey = new ServiceInvoiceKey();
      ServiceInvoiceDetails silidtls = new ServiceInvoiceDetails();

      serviceInvoiceKey.serviceInvoiceID = serviceInvoiceSummaryDtlsList.summaryDetailsList.item(i).serviceInvoiceID;

      final curam.financial.impl.ServiceInvoice serviceInvoiceObj = serviceInvoiceDAO.get(
        serviceInvoiceKey.serviceInvoiceID);

      // START CR00094326, JSP
      silidtls = serviceInvoiceObj.getServiceInvoiceDerivedStatus();
      // END CR00094326

      serviceInvoiceSummaryDtlsList.summaryDetailsList.item(i).serviceInvoiceDerivedStatus = silidtls.serviceInvoiceDerivedStatus;

      Double totalAmountInvoiced = new Double(0);

      for (final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem : serviceInvoiceLineItems) {

        // summing up all the amount invoiced from all the service invoice
        // line items
        totalAmountInvoiced += serviceInvoiceLineItem.getAmountInvoiced().getValue();
      }

      serviceInvoiceSummaryDtlsList.summaryDetailsList.item(i).amountInvoiced = new Money(
        totalAmountInvoiced);

    }

    return serviceInvoiceSummaryDtlsList;
  }

  // BEGIN, CR00206755, GP
  /**
   * Searches service invoices for a given input search criteria.
   *
   * @param serviceInvoiceSearchKey
   * Search criteria to retrieve service invoice details.
   *
   * @return Service invoice details which matched the search criteria.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceInvoiceSummaryDetailsList searchServiceInvoiceDetails(
    final ServiceInvoiceSearchKey serviceInvoiceSearchKey)
    throws AppException, InformationalException {

    SearchServiceInvoiceKey searchServiceInvoiceKey = getSearchCriteria(
      serviceInvoiceSearchKey);

    ServiceInvoiceSummaryDetailsList serviceInvoiceSummaryDtlsList = searchServiceInvoice(
      searchServiceInvoiceKey);

    return serviceInvoiceSummaryDtlsList;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceInvoiceSummaryDetailsList searchServiceInvoiceDetailsForProvider(
    final ServiceInvoiceSearchKey serviceInvoiceSearchKey,
    final ProviderKey providerKey) throws AppException,
      InformationalException {

    SearchServiceInvoiceKey searchServiceInvoiceKey = getSearchCriteria(
      serviceInvoiceSearchKey);
    // BEGIN, CR00304623, SS
    final ServiceInvoiceSummaryDetailsList serviceInvoiceSummaryDetailsList = searchServiceInvoicesDetailsForProvider(
      searchServiceInvoiceKey, providerKey);

    // END, CR00304623
    return serviceInvoiceSummaryDetailsList;
  }

  /**
   * Gets the search criteria using which service invoices are to be searched.
   *
   * @param serviceInvoiceSearchKey
   * Search criteria which will be used to calculate the final search
   * criteria.
   *
   * @return Search criteria using which service invoices are to be searched.
   */
  protected SearchServiceInvoiceKey getSearchCriteria(
    final ServiceInvoiceSearchKey serviceInvoiceSearchKey) {

    final SearchServiceInvoiceKey searchServiceInvoiceKey = new SearchServiceInvoiceKey();

    searchServiceInvoiceKey.originatorName = serviceInvoiceSearchKey.originatorName;
    searchServiceInvoiceKey.originatorReferenceNo = serviceInvoiceSearchKey.originatorReferenceNo;
    searchServiceInvoiceKey.payeeName = serviceInvoiceSearchKey.payeeName;
    searchServiceInvoiceKey.payeeReferenceNo = serviceInvoiceSearchKey.payeeReferenceNo;
    searchServiceInvoiceKey.referenceNo = serviceInvoiceSearchKey.referenceNo;
    searchServiceInvoiceKey.status = serviceInvoiceSearchKey.status;

    // BEGIN, CR00343237, SS
    final RETURN_INVOICES_RECEIVEDEntry returnInvoicesReceived = RETURN_INVOICES_RECEIVEDEntry.get(
      serviceInvoiceSearchKey.returnInvoicesReceived);

    if (RETURN_INVOICES_RECEIVEDEntry.TODAY.equals(returnInvoicesReceived)) {

      searchServiceInvoiceKey.receiptDateFrom = Date.getCurrentDate();

    } else if (RETURN_INVOICES_RECEIVEDEntry.LAST_SEVEN_DAYS.equals(
      returnInvoicesReceived)) {

      searchServiceInvoiceKey.receiptDateFrom = Date.getCurrentDate().addDays(
        -CPMConstants.kNoOfDaysInAWeek);

    } else if (RETURN_INVOICES_RECEIVEDEntry.LAST_FOURTEEN_DAYS.equals(
      returnInvoicesReceived)) {

      searchServiceInvoiceKey.receiptDateFrom = Date.getCurrentDate().addDays(
        -CPMConstants.kNoOfDaysInTwoWeeks);

    } else if (RETURN_INVOICES_RECEIVEDEntry.LAST_TWENTYONE_DAYS.equals(
      returnInvoicesReceived)) {

      searchServiceInvoiceKey.receiptDateFrom = Date.getCurrentDate().addDays(
        -CPMConstants.kNoOfDaysInThreeWeeks);
    }
    // END, CR00343237
    return searchServiceInvoiceKey;
  }

  // END, CR00206755

  /**
   * Reads Service Invoice Context description for the service invoice.
   *
   * @param key
   * Contains the service invoice ID.
   * @return ServiceInvoiceContextDescription The service invoice context
   * description.
   */
  // BEGIN, CR00177241, PM
  protected ServiceInvoiceContextDescription getServiceInvoiceContextDescription(
    // END, CR00177241
    ServiceInvoiceKey key) {
    final curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
      key.serviceInvoiceID);
    ServiceInvoiceContextDescription serviceInvoiceContextDescription = new ServiceInvoiceContextDescription();

    serviceInvoiceContextDescription.description = serviceInvoice.getReferenceNo();
    return serviceInvoiceContextDescription;
  }

  /**
   * Reads Service Invoice Line Item Context description for the service invoice
   * line item.
   *
   * @param key
   * Contains the service invoice line item ID.
   * @return ServiceInvoiceContextDescription The service invoice line item
   * context description.
   */
  // BEGIN, CR00177241, PM
  protected ServiceInvoiceLineItemContextDescription getServiceInvoiceLineItemContextDescription(
    // END, CR00177241
    ServiceInvoiceLineItemKey key) {
    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.serviceInvoiceLineItemID);
    ServiceInvoiceLineItemContextDescription desc = new ServiceInvoiceLineItemContextDescription();

    desc.description = serviceInvoiceLineItem.getReferenceNumber();
    return desc;
  }

  /**
   * Retrieves the Service Invoice details.
   *
   * @param serviceInvoice
   * Service invoice object.
   * @return ServiceInvoiceDtls Contains service invoice details.
   */
  // BEGIN, CR00177241, PM
  protected ServiceInvoiceDtls getServiceInvoiceFields(
    // END, CR00177241
    curam.financial.impl.ServiceInvoice serviceInvoice) {

    ServiceInvoiceDtls serviceInvoiceDtls = new ServiceInvoiceDtls();

    serviceInvoiceDtls.serviceInvoiceID = serviceInvoice.getID();
    serviceInvoiceDtls.referenceNo = serviceInvoice.getReferenceNo();
    serviceInvoiceDtls.externalReferenceNo = serviceInvoice.getExternalReferenceNo();
    serviceInvoiceDtls.comments = serviceInvoice.getComments();
    serviceInvoiceDtls.creationDate = serviceInvoice.getCreationDate();
    serviceInvoiceDtls.receiptDate = serviceInvoice.getReceiptDate();
    serviceInvoiceDtls.originatorName = serviceInvoice.getOriginatorName();
    serviceInvoiceDtls.originatorReferenceNo = serviceInvoice.getOriginatorReferenceNo();
    // START CR00094326, JSP
    serviceInvoiceDtls.originatorID = serviceInvoice.getOriginator().getID();
    // END CR00094326
    // START CR00094504, JSP
    serviceInvoiceDtls.versionNo = serviceInvoice.getVersionNo();
    // END CR00094504

    return serviceInvoiceDtls;
  }

  /**
   * Sets the Service Invoice details in the service invoice object.
   *
   * @param serviceInvoice
   * Service Invoice object.
   * @param serviceInvoiceDtls
   * Service invoice details.
   */
  // BEGIN, CR00177241, PM
  protected void setServiceInvoiceFields(
    // END, CR00177241
    final curam.financial.impl.ServiceInvoice serviceInvoice,
    final ServiceInvoiceDtls serviceInvoiceDtls) {

    serviceInvoice.setExternalReferenceNo(
      serviceInvoiceDtls.externalReferenceNo);
    serviceInvoice.setOriginatorReferenceNo(
      serviceInvoiceDtls.originatorReferenceNo);
    serviceInvoice.setOriginatorName(serviceInvoiceDtls.originatorName);
    serviceInvoice.setComments(serviceInvoiceDtls.comments);
    Date currentDate = Date.getCurrentDate();

    serviceInvoice.setReceiptDate(serviceInvoiceDtls.receiptDate);
    serviceInvoice.setCreationDate(currentDate);

  }

  /**
   * Sets the Service Invoice Line Item details in the Service Invoice Line Item
   * object.
   *
   * @param serviceInvoiceLineItem
   * Service Invoice line item object.
   * @param serviceInvoiceLineItemDtls
   * Contains the service invoice line item details.
   */
  // BEGIN, CR00177241, PM
  protected void setServiceInvoiceLineItemFields(
    // END, CR00177241
    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem,
    final ServiceInvoiceLineItemDtls serviceInvoiceLineItemDtls) {

    final curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceLineItemDtls.serviceInvoiceID
      == 0
        ? null
        : serviceInvoiceDAO.get(serviceInvoiceLineItemDtls.serviceInvoiceID);

    serviceInvoiceLineItem.setServiceInvoice(serviceInvoice);
    serviceInvoiceLineItem.setExternalReferenceNumber(
      serviceInvoiceLineItemDtls.externalReferenceNo);
    serviceInvoiceLineItem.setCaseReferenceNumber(
      serviceInvoiceLineItemDtls.caseReferenceNo);
    serviceInvoiceLineItem.setClientReferenceNumber(
      serviceInvoiceLineItemDtls.clientReferenceNo);
    serviceInvoiceLineItem.setClientFirstName(
      serviceInvoiceLineItemDtls.clientFirstName);
    serviceInvoiceLineItem.setClientLastName(
      serviceInvoiceLineItemDtls.clientLastName);
    serviceInvoiceLineItem.setPayeeName(serviceInvoiceLineItemDtls.payeeName);
    serviceInvoiceLineItem.setPayeeReferenceNumber(
      serviceInvoiceLineItemDtls.payeeReferenceNo);
    serviceInvoiceLineItem.setProviderName(
      serviceInvoiceLineItemDtls.providerName);
    serviceInvoiceLineItem.setProviderReferenceNumber(
      serviceInvoiceLineItemDtls.providerReferenceNo);
    serviceInvoiceLineItem.setAmountInvoiced(
      serviceInvoiceLineItemDtls.amountInvoiced);
    serviceInvoiceLineItem.setClientDateOfBirth(
      serviceInvoiceLineItemDtls.clientDOB);
    serviceInvoiceLineItem.setNumberOfUnits(
      serviceInvoiceLineItemDtls.noOfUnits);
    serviceInvoiceLineItem.setServiceDateFrom(
      serviceInvoiceLineItemDtls.serviceDateFrom);
    serviceInvoiceLineItem.setServiceDateTo(
      serviceInvoiceLineItemDtls.serviceDateTo);
    serviceInvoiceLineItem.setUnitAmount(serviceInvoiceLineItemDtls.unitAmount);
    serviceInvoiceLineItem.setServiceAuthorizationReferenceNumber(
      serviceInvoiceLineItemDtls.saReferenceNo);
    serviceInvoiceLineItem.setStatus(ServiceInvoiceLineItemStatusEntry.OPEN);
    serviceInvoiceLineItem.setServiceOffering(
      serviceOfferingDAO.get(serviceInvoiceLineItemDtls.serviceID));

  }

  /**
   * Gets the Service Invoice Line Item details from the object.
   *
   * @param serviceInvoiceLineItem
   * Service invoice line item object.
   * @return ServiceInvoiceLineItemDtls Contains service invoice line item
   * details.
   */
  // BEGIN, CR00177241, PM
  protected ServiceInvoiceLineItemDtls getServiceInvoiceLineItemFields(
    // END, CR00177241
    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem) {
    final ServiceInvoiceLineItemDtls serviceInvoiceLineItemDtls = new ServiceInvoiceLineItemDtls();

    serviceInvoiceLineItemDtls.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
    serviceInvoiceLineItemDtls.serviceInvoiceID = serviceInvoiceLineItem.getServiceInvoice().getID();
    serviceInvoiceLineItemDtls.referenceNo = serviceInvoiceLineItem.getReferenceNumber();
    serviceInvoiceLineItemDtls.externalReferenceNo = serviceInvoiceLineItem.getExternalReferenceNumber();
    serviceInvoiceLineItemDtls.saReferenceNo = serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber();

    serviceInvoiceLineItemDtls.caseReferenceNo = serviceInvoiceLineItem.getCaseReferenceNumber();
    serviceInvoiceLineItemDtls.caseID = serviceInvoiceLineItem.getCaseID();

    serviceInvoiceLineItemDtls.serviceID = serviceInvoiceLineItem.getServiceOffering().getID();

    serviceInvoiceLineItemDtls.serviceDateFrom = serviceInvoiceLineItem.getServiceDateFrom();
    serviceInvoiceLineItemDtls.serviceDateTo = serviceInvoiceLineItem.getServiceDateTo();
    serviceInvoiceLineItemDtls.status = serviceInvoiceLineItem.getStatus().toString();
    serviceInvoiceLineItemDtls.unitAmount = serviceInvoiceLineItem.getUnitAmount();
    serviceInvoiceLineItemDtls.noOfUnits = serviceInvoiceLineItem.getNumberOfUnits();
    serviceInvoiceLineItemDtls.amountInvoiced = serviceInvoiceLineItem.getAmountInvoiced();

    serviceInvoiceLineItemDtls.clientID = serviceInvoiceLineItem.getClientID();
    serviceInvoiceLineItemDtls.clientReferenceNo = serviceInvoiceLineItem.getClientReferenceNumber();
    serviceInvoiceLineItemDtls.clientLastName = serviceInvoiceLineItem.getClientLastName();
    serviceInvoiceLineItemDtls.clientFirstName = serviceInvoiceLineItem.getClientFirstName();
    serviceInvoiceLineItemDtls.clientDOB = serviceInvoiceLineItem.getClientDateOfBirth();

    // START CR00094326, JSP
    if (serviceInvoiceLineItem.getPayee() != null) {
      serviceInvoiceLineItemDtls.payeeID = serviceInvoiceLineItem.getPayee().getID();
    } else {
      serviceInvoiceLineItemDtls.payeeID = CPMConstants.kZeroLong;
    }
    // END CR00094326
    serviceInvoiceLineItemDtls.payeeName = serviceInvoiceLineItem.getPayeeName();
    serviceInvoiceLineItemDtls.payeeReferenceNo = serviceInvoiceLineItem.getPayeeReferenceNumber();
    if (serviceInvoiceLineItem.getProvider() != null) {
      serviceInvoiceLineItemDtls.providerID = serviceInvoiceLineItem.getProvider().getID();
    }
    serviceInvoiceLineItemDtls.providerReferenceNo = serviceInvoiceLineItem.getProviderReferenceNumber();
    serviceInvoiceLineItemDtls.providerName = serviceInvoiceLineItem.getProviderName();

    serviceInvoiceLineItemDtls.versionNo = serviceInvoiceLineItem.getVersionNo();

    return serviceInvoiceLineItemDtls;
  }

  /**
   * {@inheritDoc}
   */
  public void approveServiceInvoiceLineItems(ServiceInvoiceKey invoiceKey)
    throws AppException, InformationalException {

    if (invoiceKey.serviceInvoiceID != 0) {

      // START CR00094326, JSP
      curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
        invoiceKey.serviceInvoiceID);
      final Set<curam.financial.impl.ServiceInvoiceLineItem> serviceInvoiceLineItems = serviceInvoiceLineItemDAO.listServiceInvoiceLineItems(
        serviceInvoice);

      // END CR00094326

      for (final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem : serviceInvoiceLineItems) {

        serviceInvoiceLineItem.approve(serviceInvoiceLineItem.getVersionNo());
      }
    }

  }

  // BEGIN, CR00123486, SG
  /**
   * Approves the service invoice line items selected by the user, in bulk.
   *
   * @param serviceInvoiceLineItemList
   * List of SILI ID's which needs to be approved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void bulkApproveServiceInvoiceLineItems(final 
    ServiceInvoiceLineItemList serviceInvoiceLineItemList)
    throws AppException, InformationalException {

    // Create string list from ServiceInvoiceLineItem IDs string.
    final StringList siliIDKeyList = StringUtil.delimitedText2StringList(
      serviceInvoiceLineItemList.ServiceInvoiceLineItemIDList, '\t');

    final List<ServiceInvoiceLineItem> serviceInvoiceLineItems = new ArrayList<ServiceInvoiceLineItem>();
    ServiceInvoiceLineItem serviceInvoiceLineItem = null;

    SILICorrectionVersionKey siliCorrectionVersionKey = null;
    final SILICorrection siliCorrectionObj = SILICorrectionFactory.newInstance();
    String[] currentItem;

    // BEGIN, CR00124250, SG
    // Approve service invoice line items.
    for (final String siliIDKeys : siliIDKeyList) {

      // Separate the ID and version number.
      currentItem = siliIDKeys.split(GeneralConstants.kUnderScoreString);
      long currentSILIID = Long.parseLong(
        currentItem[0].replace(CuramConst.gkComma, ""));
      int currentSILIVersionNo = Integer.parseInt(currentItem[1]);

      serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(currentSILIID);
      // BEGIN, CR00305409, SSK
      long sILICorrectionID = checkIfCorrectionExitsForSILI(
        serviceInvoiceLineItem);

      if (0 == sILICorrectionID) {
        if (serviceInvoiceLineItem.getVersionNo() == currentSILIVersionNo) {
          serviceInvoiceLineItems.add(serviceInvoiceLineItem);
        }
      } else {
        siliCorrectionVersionKey = new SILICorrectionVersionKey();
        siliCorrectionVersionKey.SILICorrectionID = sILICorrectionID;
        ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
          siliCorrectionVersionKey.SILICorrectionID);

        siliCorrectionVersionKey.versionNo = siliCorrection.getVersionNo();
        siliCorrectionObj.approveServiceInvoiceLineItemCorrection(
          siliCorrectionVersionKey);
      }
      // END, CR00305409
    }

    if (serviceInvoiceLineItem != null) {

      serviceInvoiceLineItem.getServiceInvoice().bulkApprove(
        serviceInvoiceLineItems);

    }
    // END, CR00124250
  }

  /**
   * Validates if at least one of the service invoice line item is selected
   * before approval.
   *
   * @param siliList
   * List of SILI ID's which needs to be approved.
   *
   * @throws InformationalException
   * {@link SERVICEINVOICE#ERR_SERVICEINVOICE_FV_ALTEAST_ONE_SILI_MUST_BE_SELECTED}
   * If none of the service invoice line item is selected for
   * processing.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void validateSelectionForBulkApproval(
    ServiceInvoiceLineItemList siliList) throws AppException,
      InformationalException {

    // Create string list from ServiceInvoiceLineItem IDs string.
    StringList siliIDKeyList = StringUtil.delimitedText2StringList(
      siliList.ServiceInvoiceLineItemIDList, '\t');

    // At least one SILI must be selected on multiple selection to process SILI.
    if (siliIDKeyList.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICEExceptionCreator.ERR_SERVICEINVOICE_FV_ALTEAST_ONE_SILI_MUST_BE_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      ValidationHelper.failIfErrorsExist();
    }
  }

  /**
   * Lists all the 'Open' service invoice line items for a service invoice.
   *
   * @param key
   * Contains the service invoice ID for which the service invoice line
   * items to be retrieved.
   * @return The list of service invoice line items.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceInvoiceLineItemsDetailsList listOpenServiceInvoiceLineItems(
    ServiceInvoiceKey key) throws AppException, InformationalException {

    ServiceInvoiceLineItemsDetailsList openServiceInvoiceLineItemsDetailsList = new ServiceInvoiceLineItemsDetailsList();
    // BEGIN, CR00303803, SS
    ServiceInvoiceLineItemsDetailsList allServiceInvoiceLineItemsDetailsList = listServiceInvoiceLineItems(
      key);

    // END, CR00303803
    for (int i = 0; i < allServiceInvoiceLineItemsDetailsList.dtlsList.size(); i++) {
      if (allServiceInvoiceLineItemsDetailsList.dtlsList.item(i).details.status.equals(
        ServiceInvoiceLineItemStatusEntry.OPEN.toString())) {
        openServiceInvoiceLineItemsDetailsList.dtlsList.addRef(
          allServiceInvoiceLineItemsDetailsList.dtlsList.item(i));
      }
    }
   
    // BEGIN, CR00094793, SG
    openServiceInvoiceLineItemsDetailsList.desc = getServiceInvoiceContextDescription(
      key);
    // END, CR00094793

    return openServiceInvoiceLineItemsDetailsList;
  }

  /**
   * Lists all the 'Pending Approval' service invoice line items for a service
   * invoice.
   *
   * @param key
   * Contains the service invoice ID for which the service invoice line
   * items to be retrieved.
   * @return The list of service invoice line items.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceInvoiceLineItemsDetailsList listSubmittedServiceInvoiceLineItems(
    ServiceInvoiceKey key) throws AppException, InformationalException {
    // BEGIN, CR00303803, SS
    ServiceInvoiceLineItemsDetailsList allServiceInvoiceLineItemsDetailsList;
    // END, CR00303803
    ServiceInvoiceLineItemsDetailsList submittedServiceInvoiceLineItemsDetailsList = new ServiceInvoiceLineItemsDetailsList();

    allServiceInvoiceLineItemsDetailsList = listServiceInvoiceLineItems(key);

    for (int i = 0; i < allServiceInvoiceLineItemsDetailsList.dtlsList.size(); i++) {
      if (allServiceInvoiceLineItemsDetailsList.dtlsList.item(i).details.status.equals(
        ServiceInvoiceLineItemStatusEntry.PENDINGAPPROVAL.toString())) {
        submittedServiceInvoiceLineItemsDetailsList.dtlsList.addRef(
          allServiceInvoiceLineItemsDetailsList.dtlsList.item(i));
      }
    }

    // BEGIN, CR00094793, SG
    submittedServiceInvoiceLineItemsDetailsList.desc = getServiceInvoiceContextDescription(
      key);
    // END, CR00094793

    return submittedServiceInvoiceLineItemsDetailsList;
  }

  // END, CR00123486

  /**
   * {@inheritDoc}
   */
  public SILIDetailsList listAllSubmittedServiceInvoiceLineItems(
    ServiceInvoiceKey serviceInvoiceKey) throws AppException,
      InformationalException {

    SILIDetailsList submittedSILIDetailsList = new SILIDetailsList();
    SILIDetailsList siliDetailsList = listAllServiceInvoiceLineItems(
      serviceInvoiceKey);
    ServiceInvoiceLineItem serviceInvoiceLineItem = null;

    for (final SILIDetail siliDetail : siliDetailsList.details.items()) {

      serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
        siliDetail.siliDetails.serviceInvoiceLineItemID);

      siliDetail.status = serviceInvoiceLineItem.getStatus().toUserLocaleString();

      if (ServiceInvoiceLineItemStatusEntry.COMPLETE.equals(
        serviceInvoiceLineItem.getStatus())) {

        siliDetail.siliCompletedInd = true;
        siliDetail.siliCorrectionID = checkIfCorrectionExitsForSILI(
          serviceInvoiceLineItem);

        if (0 != siliDetail.siliCorrectionID) {

          ServiceInvoiceLineItemCorrection serviceInvoiceLineItemCorrection = siliCorrectionDAO.get(
            siliDetail.siliCorrectionID);

          siliDetail.status = serviceInvoiceLineItemCorrection.getCorrection().getStatus().toUserLocaleString();

          if (ServiceInvoiceLineItemCorrectionStatusEntry.PENDINGAPPROVAL.equals(
            serviceInvoiceLineItemCorrection.getCorrection().getStatus())) {

            submittedSILIDetailsList.details.addRef(siliDetail);
          }
        }
      } else {

        if (ServiceInvoiceLineItemStatusEntry.PENDINGAPPROVAL.equals(
          serviceInvoiceLineItem.getStatus())) {
          submittedSILIDetailsList.details.addRef(siliDetail);
        }
      }

      // BEGIN, CR00247586, PS
      if (siliDetail.siliInPendingApprovalInd
        || siliDetail.siliInPendingApprovalCorrection) {

        siliDetail.approveInd = true;
      }
      if (siliDetail.siliInPendingApprovalInd) {

        siliDetail.approveActionURL = CPMConstants.kApproveSILIPendingApproval;
      } else {
        if (siliDetail.siliInPendingApprovalCorrection) {

          siliDetail.approveActionURL = CPMConstants.kApproveSILIPendingApprovalCorrection;
          siliDetail.restoreActionURL = CPMConstants.kRestoreOriginalDataForLineItemPendingApprovalCorrection;
        }
      }
      // END, CR00247586
    }

    return submittedSILIDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public void cancelServiceInvoiceLineItems(ServiceInvoiceKey key)
    throws InformationalException {

    if (key.serviceInvoiceID != 0) {
      // START CR00094326, JSP
      curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
        key.serviceInvoiceID);

      final Set<curam.financial.impl.ServiceInvoiceLineItem> serviceInvoiceLineItems = serviceInvoiceLineItemDAO.listServiceInvoiceLineItems(
        serviceInvoice);

      // END CR00094326

      for (final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem : serviceInvoiceLineItems) {

        serviceInvoiceLineItem.setStatus(
          ServiceInvoiceLineItemStatusEntry.CANCELED);
        serviceInvoiceLineItem.modify(serviceInvoiceLineItem.getVersionNo());
      }
    }
  }

  /**
   * {@inheritDoc}
   */
  public void denyServiceInvoiceLineItems(ServiceInvoiceKey invoiceKey)
    throws InformationalException {

    if (invoiceKey.serviceInvoiceID != 0) {

      // START CR00094326, JSP
      curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
        invoiceKey.serviceInvoiceID);
      final Set<curam.financial.impl.ServiceInvoiceLineItem> serviceInvoiceLineItems = serviceInvoiceLineItemDAO.listServiceInvoiceLineItems(
        serviceInvoice);

      // END CR00094326

      for (final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem : serviceInvoiceLineItems) {

        serviceInvoiceLineItem.setStatus(
          ServiceInvoiceLineItemStatusEntry.DENIED);
        serviceInvoiceLineItem.modify(serviceInvoiceLineItem.getVersionNo());
      }
    }

  }

  /**
   * {@inheritDoc}
   */
  // START CR00094504, JSP
  public void approveServiceInvoiceLineItem(
    curam.cpm.facade.struct.ServiceInvoiceLineItemKey siliKey)
    throws AppException, InformationalException {

    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      siliKey.key.serviceInvoiceLineItemID);

    // BEGIN CR00103810, ABS
    serviceInvoiceLineItem.approve(siliKey.versionNo);
    // Suppress the exception since exception task should be created.
    // }
    // END CR00103810
    // END CR00094504
  }

  /**
   * {@inheritDoc}
   */
  // START CR00094504, JSP
  public void denyServiceInvoiceLineItem(
    curam.cpm.facade.struct.ServiceInvoiceLineItemKey siliKey)
    throws AppException, InformationalException {

    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      siliKey.key.serviceInvoiceLineItemID);

    serviceInvoiceLineItem.deny(siliKey.versionNo);
    // END CR00094504

    // send notification to the payee regarding denial of SILI
    FinancialNotification notification = FinancialNotificationFactory.newInstance();
    FinancialNotificationKey notificationKey = new FinancialNotificationKey();

    // START CR00094504, JSP
    notificationKey.serviceInvoiceLineItemID = siliKey.key.serviceInvoiceLineItemID;
    // END CR00094504
    notificationKey.event = FinancialNotificationEvent.SILI_DENIED;

    // create financial notification
    notification.createNotification(notificationKey);

  }

  /**
   * {@inheritDoc}
   */
  public InformationalMsgDtlsList submitServiceInvoiceForProcessing(
    ServiceInvoiceKey key) throws AppException, InformationalException {

    final curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
      key.serviceInvoiceID);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    boolean errorWhileProcessing = false;

    String referenceNumbers = "";

    // START CR00094326, JSP
    ServiceInvoiceDetails silidetails = serviceInvoice.getServiceInvoiceDerivedStatus();

    // END CR00094326

    if (serviceInvoice.getLifecycleState().getCode().equals(
      RECORDSTATUS.CANCELLED)
        || !silidetails.serviceInvoiceDerivedStatus.equals(
          ServiceInvoiceDerivedStatus.OPEN)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICEExceptionCreator.ERR_SERVICEINVOICE_XRV_THIS_SERVICE_INVOICE_IS_NOT_OPEN_IT_CANNOT_BE_SUBMITFORPROCESSING(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    } else {

      ServiceInvoiceLineItemsDetailsList siliItemsDetailsList = listServiceInvoiceLineItems(
        key);

      int size = siliItemsDetailsList.dtlsList.size();

      if (size == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          SERVICEINVOICEExceptionCreator.ERR_SERVICEINVOICE_XRV_NO_SILI_ASSOCIATED_WITH_SI(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      } else {
        for (int i = 0; i < size; i++) {
          ServiceInvoiceLineItemDetails ServiceInvoiceLineItemsDetails = siliItemsDetailsList.dtlsList.item(
            i);

          if (ServiceInvoiceLineItemsDetails.details.status.equalsIgnoreCase(
            curam.financial.ServiceInvoiceLineItemStatus.OPEN)) {
            curam.cpm.facade.struct.ServiceInvoiceLineItemKey siliKey = new curam.cpm.facade.struct.ServiceInvoiceLineItemKey();

            siliKey.key.serviceInvoiceLineItemID = ServiceInvoiceLineItemsDetails.details.serviceInvoiceLineItemID;
            siliKey.versionNo = ServiceInvoiceLineItemsDetails.details.versionNo;
            ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
              siliKey.key.serviceInvoiceLineItemID);
            String referenceNumber = serviceInvoiceLineItem.getReferenceNumber();

            InformationalMsgDtlsList dtlsList = submitSILIForProcessing(siliKey);

            if (dtlsList.dtls.size() != 0) {
              referenceNumbers += referenceNumber + GeneralConstants.kComma
                + GeneralConstants.kSpace;
              errorWhileProcessing = true;
            }
          }
        }
        if (true == errorWhileProcessing) {

          AppException ae = new AppException(SERVICEINVOICELINEITEM.ERR_SERVICEINVOICELINEITEM_XFV_EXCEPTION_TASK_CREATED).arg(
            referenceNumbers);

          TransactionInfo.setInformationalManager();
          informationalManager = TransactionInfo.getInformationalManager();
          informationalManager.addInformationalMsg(ae,
            curam.core.impl.CuramConst.gkEmpty,
            InformationalElement.InformationalType.kWarning);

          String[] messages = informationalManager.obtainInformationalAsString();

          InformationalMsgDtls dtls = new InformationalMsgDtls();

          dtls.informationMsgTxt = messages[0];

          informationalMsgDtlsList.dtls.addRef(dtls);
        }
      }
    }

    return informationalMsgDtlsList;

  }

  /**
   * {@inheritDoc}
   */
  public InformationalMsgDtlsList submitServiceInvoiceLineItemForProcessing(
    curam.cpm.facade.struct.ServiceInvoiceLineItemKey key)
    throws AppException, InformationalException {

    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.key.serviceInvoiceLineItemID);

    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    try {
      serviceInvoiceLineItem.submit(key.versionNo);
    } catch (AppException ae) {
      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      informationalManager.addInformationalMsg(ae,
        curam.core.impl.CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError);
      if (ae.getCatEntry().equals(
        SERVICEINVOICELINEITEM.ERR_SERVICEINVOICELINEITEM_XRV_THIS_SERVICE_INVOICE_LINE_ITEM_IS_NOT_OPEN_IT_CANNOT_BE_SUBMITFORPROCESSING)) {
        informationalManager.failOperation();
      }
    }

    // create event
    Event submitServiceInvoiceLI = new Event();

    submitServiceInvoiceLI.eventKey = NEWINVOICECREATED.INVOICESUBMITTED;
    submitServiceInvoiceLI.primaryEventData = serviceInvoiceLineItem.getServiceInvoice().getID();

    // The service invoice has been submitted
    // Raise event to close this workflow task.
    EventService.raiseEvent(submitServiceInvoiceLI);

    return informationalMsgDtlsList;
  }

  /**
   * Sets the Service Invoice Line Item History details.
   *
   * @param sILIHistoryDtls
   * Contains service invoice line item history details.
   * @param sILIHistory
   * Service invoice line item history object.
   * @return SILIHistoryDtls Contains service invoice line item history details.
   */
  // BEGIN, CR00177241, PM
  protected SILIHistoryDtls setServiceDetails(SILIHistoryDtls sILIHistoryDtls,
    // END, CR00177241
    curam.financial.impl.ServiceInvoiceLineItemHistory sILIHistory) {

    sILIHistoryDtls.siliHistoryID = sILIHistory.getID();

    sILIHistoryDtls.dateTimeChanged = sILIHistory.getDateTimeChanged();

    sILIHistoryDtls.status = sILIHistory.getStatus().toString();

    sILIHistoryDtls.serviceDateFrom = sILIHistory.getServiceDateFrom();

    sILIHistoryDtls.serviceDateTo = sILIHistory.getServiceDateTo();

    sILIHistoryDtls.serviceID = sILIHistory.getServiceOffering().getID();

    return sILIHistoryDtls;

  }

  // BEGIN, CR00304623, SS
  /**
   * Reads all the Service Invoices for a provider for which the provider is an
   * originator or is present as a payee in the one of the service invoice line
   * items or is a service provider for one of the service invoice line items.
   *
   * @param providerKey
   * Contains provider ID.
   *
   * @return The list of service invoices associated with the provider
   *
   * @deprecated Since Curam 5.2 SP6, replaced with
   * {@link ServiceInvoice#retrieveServiceInvoicesDetailsForProvider(ServiceInvoiceSummaryDetailsList)}
   * . This method is not performant. This method takes a long time
   * when a service invoice for a provider is searched. This method
   * is replaced by a more performant method. See release note:
   * CR00304623.
   */
  @Deprecated
  public ServiceInvoiceSummaryDetailsList retrieveServiceInvoicesForProvider(
    ProviderKey providerKey) {

    final ServiceInvoiceSummaryDetailsList serviceInvoiceSummaryDetailsList = new ServiceInvoiceSummaryDetailsList();

    final Set<curam.financial.impl.ServiceInvoice> serviceInvoiceList = serviceInvoiceDAO.searchBy(
      providerKey.providerConcernRoleID, providerKey.providerConcernRoleID,
      providerKey.providerConcernRoleID);

    for (final curam.financial.impl.ServiceInvoice serviceInvoice : serviceInvoiceList) {
      serviceInvoiceSummaryDetailsList.summaryDetailsList.addRef(
        getServiceInvoiceSummaryDetails(serviceInvoice, providerKey));
    }
    return serviceInvoiceSummaryDetailsList;
  }
  
  /**
   * {@inheritDoc}
   */
  public ServiceInvoiceSummaryDetailsList retrieveServiceInvoicesDetailsForProvider(
    ProviderKey providerKey) throws AppException, InformationalException {

    final ServiceInvoiceSummaryDetailsList serviceInvoiceSummaryDetailsList = new ServiceInvoiceSummaryDetailsList();
    final Set<curam.financial.impl.ServiceInvoice> serviceInvoiceList = serviceInvoiceDAO.searchBy(
      providerKey.providerConcernRoleID, providerKey.providerConcernRoleID,
      providerKey.providerConcernRoleID);

    for (final curam.financial.impl.ServiceInvoice serviceInvoice : serviceInvoiceList) {
      serviceInvoiceSummaryDetailsList.summaryDetailsList.addRef(
        getServiceInvoiceDetailsForProvider(serviceInvoice, providerKey));
    }
    return serviceInvoiceSummaryDetailsList;
  }

  /**
   * Searches Service Invoices based on the search criteria.
   *
   * @param key
   * Service invoice details to search with.
   * @param providerKey
   * Contains provider ID.
   *
   * @return The list of service invoice summary details.
   *
   * @throws InformationalException
   * {@link SERVICEINVOICE#ERR_SERVICEINVOICE_XFV_IF_RECEIPT_DATE_TO_ENTERED_RECEIPT_DATE_FROM_MUST_BE_ENTERED}
   * If receipt To Date is entered and receipt From Date is not
   * entered.
   * {@link SERVICEINVOICE#ERR_SERVICEINVOICE_XFV_IF_RECEIPT_DATE_TO_MUST_BE_LATER_THAN_RECEIPT_DATE_FROM}
   * If receipt To Date is before than receipt From Date.
   *
   * @deprecated Since Curam 5.2 SP6, replaced with
   * {@link ServiceInvoice#searchServiceInvoicesDetailsForProvider(ServiceInvoiceSummaryDetailsList)}
   * .This method is not performant. This method takes a long time
   * when a service invoice for a provider is searched. This method
   * is replaced by a more performant method. See release note:
   * CR00304623.
   */
  @Deprecated
  public ServiceInvoiceSummaryDetailsList searchServiceInvoicesForProvider(
    SearchServiceInvoiceKey key, ProviderKey providerKey)
    throws InformationalException {
    // END, CR00304623
    if (key.referenceNo.length() == 0 && key.receiptDateFrom.isZero()
      && key.receiptDateTo.isZero() && key.status.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
    }

    if (!key.receiptDateTo.isZero()) {
      if (key.receiptDateFrom.isZero()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          SERVICEINVOICEExceptionCreator.ERR_SERVICEINVOICE_XFV_IF_RECEIPT_DATE_TO_ENTERED_RECEIPT_DATE_FROM_MUST_BE_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } else if (key.receiptDateTo.before(key.receiptDateFrom)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          SERVICEINVOICEExceptionCreator.ERR_SERVICEINVOICE_XFV_IF_RECEIPT_DATE_TO_MUST_BE_LATER_THAN_RECEIPT_DATE_FROM(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }

    ValidationHelper.failIfErrorsExist();

    ServiceInvoiceSummaryDetailsList serviceInvoiceSummaryDetailsList = new ServiceInvoiceSummaryDetailsList();

    final ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      providerKey.providerConcernRoleID);
    final String referenceNumber = providerOrganization.getPrimaryAlternateID();

    Boolean bReferenceNo = StringHelper.trim(key.referenceNo).length() > 0;
    Boolean bStatus = StringHelper.trim(key.status).length() > 0;
    Boolean bReceiptDateFrom = !key.receiptDateFrom.isZero();
    Boolean bReceiptDateTo = !key.receiptDateTo.isZero();
    Boolean searchByProviderReferenceNo = StringHelper.trim(referenceNumber).length()
      > 0;

    // BEGIN, CR00121613, GP
    Set<curam.financial.impl.ServiceInvoice> serviceInvoiceList = serviceInvoiceDAO.searchServiceInvoiceDetails(
      key.referenceNo, referenceNumber, key.receiptDateFrom, key.receiptDateTo,
      CPMConstants.kEmptyString, key.status, bReferenceNo, true,
      bReceiptDateFrom, bReceiptDateTo, false, bStatus, true,
      providerOrganization.getID(), true, providerOrganization.getID(),
      searchByProviderReferenceNo, referenceNumber,
      providerOrganization.getID(), true, key.originatorName, false,
      key.originatorReferenceNo, false);

    // END, CR00121613

    for (curam.financial.impl.ServiceInvoice serviceInvoice : serviceInvoiceList) {

      if (key.status.length() == 0) {
        serviceInvoiceSummaryDetailsList.summaryDetailsList.addRef(
          getServiceInvoiceSummaryDetails(serviceInvoice, providerKey));
      } else {
        // START CR00094326, JSP
        ServiceInvoiceDetails silidetails = serviceInvoice.getServiceInvoiceDerivedStatus();

        // END CR00094326
        if (silidetails.serviceInvoiceDerivedStatus.equals(key.status)) {
          serviceInvoiceSummaryDetailsList.summaryDetailsList.addRef(
            getServiceInvoiceSummaryDetails(serviceInvoice, providerKey));
        }
      }
    }
    return serviceInvoiceSummaryDetailsList;
  }

  // BEGIN, CR00304623, SS
  /**
   * Searches Service Invoices based on the search criteria.
   *
   * @param key
   * Service invoice details to search with.
   * @param providerKey
   * Contains provider ID.
   *
   * @return The list of service invoice summary details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link SERVICEINVOICE#ERR_SERVICEINVOICE_XFV_IF_RECEIPT_DATE_TO_ENTERED_RECEIPT_DATE_FROM_MUST_BE_ENTERED}
   * If receipt To Date is entered and receipt From Date is not
   * entered.
   * {@link SERVICEINVOICE#ERR_SERVICEINVOICE_XFV_IF_RECEIPT_DATE_TO_MUST_BE_LATER_THAN_RECEIPT_DATE_FROM}
   * If receipt To Date is before than receipt From Date.
   */
  public ServiceInvoiceSummaryDetailsList searchServiceInvoicesDetailsForProvider(
    SearchServiceInvoiceKey key, ProviderKey providerKey)
    throws AppException, InformationalException {
    if (0 == key.referenceNo.length() && key.receiptDateFrom.isZero()
      && key.receiptDateTo.isZero() && 0 == key.status.length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }

    if (!key.receiptDateTo.isZero()) {
      if (key.receiptDateFrom.isZero()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          SERVICEINVOICEExceptionCreator.ERR_SERVICEINVOICE_XFV_IF_RECEIPT_DATE_TO_ENTERED_RECEIPT_DATE_FROM_MUST_BE_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      } else if (key.receiptDateTo.before(key.receiptDateFrom)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          SERVICEINVOICEExceptionCreator.ERR_SERVICEINVOICE_XFV_IF_RECEIPT_DATE_TO_MUST_BE_LATER_THAN_RECEIPT_DATE_FROM(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      }
    }

    ValidationHelper.failIfErrorsExist();

    final ServiceInvoiceSummaryDetailsList serviceInvoiceSummaryDetailsList = new ServiceInvoiceSummaryDetailsList();

    final ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      providerKey.providerConcernRoleID);
    final String referenceNumber = providerOrganization.getPrimaryAlternateID();

    Boolean bReferenceNo = StringHelper.trim(key.referenceNo).length() > 0;
    Boolean bStatus = StringHelper.trim(key.status).length() > 0;
    Boolean bReceiptDateFrom = !key.receiptDateFrom.isZero();
    Boolean bReceiptDateTo = !key.receiptDateTo.isZero();
    Boolean searchByProviderReferenceNo = StringHelper.trim(referenceNumber).length()
      > 0;

    final Set<curam.financial.impl.ServiceInvoice> serviceInvoiceList = serviceInvoiceDAO.searchServiceInvoiceDetails(
      key.referenceNo, referenceNumber, key.receiptDateFrom, key.receiptDateTo,
      CPMConstants.kEmptyString, key.status, bReferenceNo, true,
      bReceiptDateFrom, bReceiptDateTo, false, bStatus, true,
      providerOrganization.getID(), true, providerOrganization.getID(),
      searchByProviderReferenceNo, referenceNumber,
      providerOrganization.getID(), true, key.originatorName, false,
      key.originatorReferenceNo, false);

    for (final curam.financial.impl.ServiceInvoice serviceInvoice : serviceInvoiceList) {
      if (0 == key.status.length()) {
        serviceInvoiceSummaryDetailsList.summaryDetailsList.addRef(
          getServiceInvoiceDetailsForProvider(serviceInvoice, providerKey));
      } else {
        final ServiceInvoiceDetails silidetails = serviceInvoice.getServiceInvoiceDerivedStatus();

        if (silidetails.serviceInvoiceDerivedStatus.equals(key.status)) {
          serviceInvoiceSummaryDetailsList.summaryDetailsList.addRef(
            getServiceInvoiceDetailsForProvider(serviceInvoice, providerKey));
        }
      }
    }
    return serviceInvoiceSummaryDetailsList;
  }

  /**
   * Reads the Service Invoice summary details for the service invoice passed.
   *
   * @param serviceInvoice
   * Service invoice object.
   * @param providerKey
   * Contains provider ID.
   *
   * @return The service invoice summary details.
   *
   * @deprecated Since Curam 5.2 SP6, replaced with
   * {@link ServiceInvoice#getServiceInvoiceDetailsForProvider(ServiceInvoice, ProviderKey)}
   * . This method is not performant. This method takes a long time
   * when a service invoice for a provider is searched. This method
   * is replaced by a more performant method. See release note:
   * CR00304623.
   */
  @Deprecated
  // BEGIN, CR00177241, PM
  protected ServiceInvoiceSummaryDetails getServiceInvoiceSummaryDetails(
    // END, CR00177241
    curam.financial.impl.ServiceInvoice serviceInvoice,
    ProviderKey providerKey) {
    // END, CR00304623
    
    ServiceInvoiceSummaryDetails serviceInvoiceSummaryDetails = new ServiceInvoiceSummaryDetails();

    serviceInvoiceSummaryDetails.referenceNo = serviceInvoice.getReferenceNo();
    serviceInvoiceSummaryDetails.serviceInvoiceID = serviceInvoice.getID();
    serviceInvoiceSummaryDetails.externalReferenceNo = serviceInvoice.getExternalReferenceNo();
    serviceInvoiceSummaryDetails.originatorName = serviceInvoice.getOriginatorName();
    ServiceInvoiceKey invoiceKey = new ServiceInvoiceKey();

    invoiceKey.serviceInvoiceID = serviceInvoice.getID();
    // START CR00094326, JSP
    ServiceInvoiceDetails serviceInvoiceDetails = serviceInvoice.getServiceInvoiceDerivedStatus();

    // END CR00094326

    serviceInvoiceSummaryDetails.recordStatus = serviceInvoiceDetails.serviceInvoiceDerivedStatus;
    if (!(serviceInvoice.getLifecycleState().getCode().equals(
      RECORDSTATUS.CANCELLED))) {
      // START CR00094326, JSP
      ServiceInvoiceDetails serviceInvoiceStatus = serviceInvoice.getServiceInvoiceDerivedStatus();

      // END CR00094326
      serviceInvoiceSummaryDetails.serviceInvoiceDerivedStatus = serviceInvoiceStatus.serviceInvoiceDerivedStatus;
    } else {
      serviceInvoiceSummaryDetails.serviceInvoiceDerivedStatus = ServiceInvoiceDerivedStatus.CANCELED;
    }

    serviceInvoiceSummaryDetails.receiptDate = serviceInvoice.getReceiptDate();
    serviceInvoiceSummaryDetails.creationDate = serviceInvoice.getCreationDate();

    // BEGIN, CR00304623, SS
    final Set<ServiceInvoiceLineItem> serviceInvoiceLineItemList = serviceInvoiceLineItemDAO.searchByProviderAndServiceInvoice(
      providerKey.providerConcernRoleID, providerKey.providerConcernRoleID,
      serviceInvoice.getID());

    Double totalAmountInvoiced = new Double(0);

    Double totalAmountPaid = new Double(0);

    if (null != serviceInvoiceLineItemList
      && !serviceInvoiceLineItemList.isEmpty()) {

      for (final ServiceInvoiceLineItem serviceInvoiceLineItem : serviceInvoiceLineItemList) {
        // summing up all the amount invoiced from all the service invoice
        // line items
        totalAmountInvoiced += serviceInvoiceLineItem.getAmountInvoiced().getValue();

        // BEGIN CR00089833, GYH
        // Populate the calculated amount of each service invoice line item to
        // amountPaid when status of the service invoice COMPLETED

        if (ServiceInvoiceDerivedStatus.COMPLETE.equals(
          serviceInvoiceDetails.serviceInvoiceDerivedStatus)) {
          for (final ServiceInvoiceLineItemTransaction sILITransaction : serviceInvoiceLineItem.getTransactions()) {
            if (ServiceInvoiceLineItemTransactionTypeEntry.PAID.equals(
              sILITransaction.getTransactionType())
                && ServiceInvoiceLineItemTransactionStatusEntry.ACTIVE.equals(
                  sILITransaction.getStatus())) {
              totalAmountPaid += sILITransaction.getAmount().getValue();
            }
          }
        }
        // END CR00089833

      }
      serviceInvoiceSummaryDetails.amountInvoiced = new Money(
        totalAmountInvoiced);

      // BEGIN CR00089833, GYH
      serviceInvoiceSummaryDetails.amountPaid = new Money(totalAmountPaid);
      // END CR00089833

    }
    return serviceInvoiceSummaryDetails;
  }

  /**
   * Reads the Service Invoice summary details for the service invoice passed.
   *
   * @param serviceInvoice
   * Service invoice object.
   * @param providerKey
   * Contains provider ID.
   *
   * @return The service invoice summary details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ServiceInvoiceSummaryDetails getServiceInvoiceDetailsForProvider(
    final curam.financial.impl.ServiceInvoice serviceInvoice,
    final ProviderKey providerKey) throws AppException,
      InformationalException {

    final ServiceInvoiceSummaryDetails serviceInvoiceSummaryDetails = new ServiceInvoiceSummaryDetails();

    serviceInvoiceSummaryDetails.referenceNo = serviceInvoice.getReferenceNo();
    serviceInvoiceSummaryDetails.serviceInvoiceID = serviceInvoice.getID();
    serviceInvoiceSummaryDetails.externalReferenceNo = serviceInvoice.getExternalReferenceNo();
    serviceInvoiceSummaryDetails.originatorName = serviceInvoice.getOriginatorName();
    final ServiceInvoiceKey invoiceKey = new ServiceInvoiceKey();

    invoiceKey.serviceInvoiceID = serviceInvoice.getID();
    final ServiceInvoiceDetails serviceInvoiceDetails = serviceInvoice.getServiceInvoiceDerivedStatus();

    serviceInvoiceSummaryDetails.recordStatus = serviceInvoiceDetails.serviceInvoiceDerivedStatus;
    if (!(RECORDSTATUS.CANCELLED.equals(
      serviceInvoice.getLifecycleState().getCode()))) {
      ServiceInvoiceDetails serviceInvoiceStatus = serviceInvoice.getServiceInvoiceDerivedStatus();

      serviceInvoiceSummaryDetails.serviceInvoiceDerivedStatus = serviceInvoiceStatus.serviceInvoiceDerivedStatus;
    } else {
      serviceInvoiceSummaryDetails.serviceInvoiceDerivedStatus = ServiceInvoiceDerivedStatus.CANCELED;
    }

    serviceInvoiceSummaryDetails.receiptDate = serviceInvoice.getReceiptDate();
    serviceInvoiceSummaryDetails.creationDate = serviceInvoice.getCreationDate();

    final RetrieveProviderSILIKey retrieveProviderSILIKey = new RetrieveProviderSILIKey();

    retrieveProviderSILIKey.payeeID = providerKey.providerConcernRoleID;
    retrieveProviderSILIKey.providerID = providerKey.providerConcernRoleID;
    retrieveProviderSILIKey.serviceInvoiceID = serviceInvoice.getID();

    final curam.cpm.sl.entity.intf.ServiceInvoiceLineItem serviceInvoiceLineItem = ServiceInvoiceLineItemFactory.newInstance();
    final curam.cpm.sl.entity.struct.SILIDetailsList siliDetailsList = serviceInvoiceLineItem.searchByProviderAndServiceInvoiceID(
      retrieveProviderSILIKey);

    Double totalAmountInvoiced = new Double(0);

    Double totalAmountPaid = new Double(0);

    final ServiceInvoiceLineItemKey siliInvoiceLineItemKey = new ServiceInvoiceLineItemKey();
    final SILITransaction siliTransaction = SILITransactionFactory.newInstance();
    SILITransactionDtlsList siliTransactionDtlsList;

    if (null != siliDetailsList) {
      for (final curam.cpm.sl.entity.struct.SILIDetails siliDetails : siliDetailsList.dtls.items()) {
        totalAmountInvoiced += siliDetails.amountInvoiced.getValue();
        siliInvoiceLineItemKey.serviceInvoiceLineItemID = siliDetails.serviceInvoiceLineItemID;
        if (ServiceInvoiceDerivedStatus.COMPLETE.equals(
          serviceInvoiceDetails.serviceInvoiceDerivedStatus)) {
          siliTransactionDtlsList = siliTransaction.searchByServiceInvoiceLineItem(
            siliInvoiceLineItemKey);

          for (final SILITransactionDtls siliTransactionDtls : siliTransactionDtlsList.dtls.items()) {
            if (ServiceInvoiceLineItemTransactionTypeEntry.PAID.equals(
              siliTransactionDtls.transactionType)
                && ServiceInvoiceLineItemTransactionStatusEntry.ACTIVE.equals(
                  siliTransactionDtls.status)) {
              totalAmountPaid += siliTransactionDtls.amount.getValue();
            }
          }
        }
      }
      serviceInvoiceSummaryDetails.amountInvoiced = new Money(
        totalAmountInvoiced);
      serviceInvoiceSummaryDetails.amountPaid = new Money(totalAmountPaid);
    }
    return serviceInvoiceSummaryDetails;
  }

  /**
   * Gets the list of Service Invoice Line Item associated with the service
   * invoice and related to the provider.
   *
   * @param providerKey
   * Contains provider ID.
   * @param serviceInvoiceKey
   * Contains service invoice ID.
   *
   * @return The list of service invoice line item.
   *
   * @deprecated Since Curam 5.2 SP6, replaced with
   * {@link ServiceInvoice#retrieveSILIDetailsForProvider(ProviderSILItemDetailsList)}
   * .This method is not performant. This method takes a long time
   * when a service invoice for a provider is searched. This method
   * is replaced by a more performant method. See release note:
   * CR00304623.
   */
  @Deprecated
  public ProviderSILItemDetailsList retrieveSILItemsForProvider(
    ProviderKey providerKey, ServiceInvoiceKey serviceInvoiceKey) {
    // END, CR00304623
    ProviderSILItemDetailsList providerSILItemDetailsList = new ProviderSILItemDetailsList();

    // BEGIN, CR00304623, SS
    final Set<ServiceInvoiceLineItem> serviceInvoiceLineItemList = serviceInvoiceLineItemDAO.searchByProviderAndServiceInvoice(
      providerKey.providerConcernRoleID, providerKey.providerConcernRoleID,
      serviceInvoiceKey.serviceInvoiceID);
    // END, CR00304623
    
    // Iterating through the providers associated with the provider group
    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      providerKey.providerConcernRoleID);

    // BEGIN, CR00304623, SS
    if (CONCERNROLETYPEEntry.PROVIDERGROUP.equals(
      providerOrganization.getConcernRoleType())) {
      final curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
        providerOrganization.getID());
      curam.provider.impl.Provider provider;

      for (final curam.provider.impl.ProviderGroupAssociate providerGroupAssociate : providerGroupAssociateDAO.searchByProviderGroup(
        providerGroup)) {
        provider = providerGroupAssociate.getProvider();

        serviceInvoiceLineItemList.addAll(
          serviceInvoiceLineItemDAO.searchByProviderAndServiceInvoice(
            provider.getID(), provider.getID(),
            serviceInvoiceKey.serviceInvoiceID));
      }
    }

    Double totalAmountInvoiced = new Double(0);
    Double amountPaid = new Double(0);

    if (null != serviceInvoiceLineItemList
      && !serviceInvoiceLineItemList.isEmpty()) {

      for (final ServiceInvoiceLineItem serviceInvoiceLineItem : serviceInvoiceLineItemList) {

        providerSILItemDetailsList.details.addRef(
          getServiceInvoiceSummaryDetails(serviceInvoiceLineItem));

        for (ServiceInvoiceLineItemTransaction sILITransaction : serviceInvoiceLineItem.getTransactions()) {
          if (!ServiceInvoiceLineItemStatusEntry.DENIED.equals(
            serviceInvoiceLineItem.getStatus())
              && !ServiceInvoiceLineItemStatusEntry.CANCELED.equals(
                serviceInvoiceLineItem.getStatus())) {
            if (ServiceInvoiceLineItemTransactionTypeEntry.PAID.equals(
              sILITransaction.getTransactionType())
                && ServiceInvoiceLineItemTransactionStatusEntry.ACTIVE.equals(
                  sILITransaction.getStatus())) {
              amountPaid += sILITransaction.getAmount().getValue();
            }
          }
        }

        // summing up all the amount invoiced from all the service invoice
        // line items

        totalAmountInvoiced += serviceInvoiceLineItem.getAmountInvoiced().getValue();

      }
    }
    // END, CR00304623
    curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
      serviceInvoiceKey.serviceInvoiceID);

    // calculating the amount paid field and according displaying it
    // START CR00094326, JSP
    if (serviceInvoice.getServiceInvoiceDerivedStatus().serviceInvoiceDerivedStatus.equals(
      ServiceInvoiceDerivedStatus.COMPLETE)) {
      // END CR00094326
      providerSILItemDetailsList.isDisplayOnlyAmountInvoiced = false;
      providerSILItemDetailsList.isDisplayBothPaidAndInvoiced = true;

    } else {
      providerSILItemDetailsList.isDisplayOnlyAmountInvoiced = true;
      providerSILItemDetailsList.isDisplayBothPaidAndInvoiced = false;
    }

    providerSILItemDetailsList.totalAmountInvoiced = new Money(
      totalAmountInvoiced);

    providerSILItemDetailsList.totalAmountPaid = new Money(amountPaid);

    return providerSILItemDetailsList;
  }

  // BEGIN, CR00304623, SS
  /**
   * {@inheritDoc}
   */
  public ProviderSILItemDetailsList retrieveSILIDetailsForProvider(
    ProviderKey providerKey, ServiceInvoiceKey serviceInvoiceKey)
    throws AppException, InformationalException {
    
    final ProviderSILItemDetailsList providerSILItemDetailsList = new ProviderSILItemDetailsList();
    final RetrieveProviderSILIKey retrieveProviderSILIKey = new RetrieveProviderSILIKey();

    retrieveProviderSILIKey.payeeID = providerKey.providerConcernRoleID;
    retrieveProviderSILIKey.providerID = providerKey.providerConcernRoleID;
    retrieveProviderSILIKey.serviceInvoiceID = serviceInvoiceKey.serviceInvoiceID;
    final curam.cpm.sl.entity.intf.ServiceInvoiceLineItem serviceInvoiceLineItem = ServiceInvoiceLineItemFactory.newInstance();
    final curam.cpm.sl.entity.struct.SILIDetailsList siliDetailsList = serviceInvoiceLineItem.searchByProviderAndServiceInvoiceID(
      retrieveProviderSILIKey);

    // Iterating through the providers associated with the provider group
    final ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      providerKey.providerConcernRoleID);
    curam.provider.impl.Provider provider;
    final RetrieveProviderSILIKey retrieveProviderSILIKeys = new RetrieveProviderSILIKey();

    if (CONCERNROLETYPEEntry.PROVIDERGROUP.equals(
      providerOrganization.getConcernRoleType())) {
      final curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
        providerOrganization.getID());

      for (final curam.provider.impl.ProviderGroupAssociate providerGroupAssociate : providerGroupAssociateDAO.searchByProviderGroup(
        providerGroup)) {
        provider = providerGroupAssociate.getProvider();
        retrieveProviderSILIKeys.payeeID = provider.getID();
        retrieveProviderSILIKeys.providerID = provider.getID();
        retrieveProviderSILIKeys.serviceInvoiceID = serviceInvoiceKey.serviceInvoiceID;
        siliDetailsList.assign(
          serviceInvoiceLineItem.searchByProviderAndServiceInvoiceID(
            retrieveProviderSILIKeys));
      }
    }
    Double totalAmountInvoiced = new Double(0);
    Double amountPaid = new Double(0);
    final ServiceInvoiceLineItemKey siliInvoiceLineItemKey = new ServiceInvoiceLineItemKey();
    SILITransaction siliTransaction = SILITransactionFactory.newInstance();

    if (null != siliDetailsList) {
      for (final curam.cpm.sl.entity.struct.SILIDetails siliDetails : siliDetailsList.dtls.items()) {
        providerSILItemDetailsList.details.addRef(
          getServiceInvoiceDetails(siliDetails));
        siliInvoiceLineItemKey.serviceInvoiceLineItemID = siliDetails.serviceInvoiceLineItemID;
        for (final SILITransactionDtls siliTransactionDtls : siliTransaction.searchByServiceInvoiceLineItem(siliInvoiceLineItemKey).dtls.items()) {
          if (!ServiceInvoiceLineItemStatusEntry.DENIED.equals(
            siliDetails.status)
              && !ServiceInvoiceLineItemStatusEntry.CANCELED.equals(
                siliDetails.status)) {
            if (ServiceInvoiceLineItemTransactionTypeEntry.PAID.equals(
              siliTransactionDtls.status)
                && ServiceInvoiceLineItemTransactionStatusEntry.ACTIVE.equals(
                  siliTransactionDtls.status)) {
              amountPaid += siliTransactionDtls.amount.getValue();
            }
          }
        }
        totalAmountInvoiced += siliDetails.amountInvoiced.getValue();
      }
    }
    final curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
      serviceInvoiceKey.serviceInvoiceID);

    // calculating the amount paid field and according displaying it.
    if (ServiceInvoiceDerivedStatus.COMPLETE.equals(
      serviceInvoice.getServiceInvoiceDerivedStatus().serviceInvoiceDerivedStatus)) {
      providerSILItemDetailsList.isDisplayOnlyAmountInvoiced = false;
      providerSILItemDetailsList.isDisplayBothPaidAndInvoiced = true;

    } else {
      providerSILItemDetailsList.isDisplayOnlyAmountInvoiced = true;
      providerSILItemDetailsList.isDisplayBothPaidAndInvoiced = false;
    }

    providerSILItemDetailsList.totalAmountInvoiced = new Money(
      totalAmountInvoiced);

    providerSILItemDetailsList.totalAmountPaid = new Money(amountPaid);

    return providerSILItemDetailsList;
  }

  /**
   * Gets the Service Invoice Line Item details from the service invoice line
   * item object.
   *
   * @param serviceInvoiceLineItem
   * Service invoice line item object.
   * @return The service invoice line item details.
   * @deprecated Since Curam 5.2 SP6, replaced with
   * {@link curam.cpm.sl.entity.base.ServiceInvoiceLineItem#searchByProviderAndServiceInvoiceID(RetrieveProviderSILIKey)}
   * * This method is not performant. This method takes a long time
   * when a service invoice for a provider is searched. This method
   * is replaced by a more performant method. See release note:See
   * release note: CR00303803.
   */
  // BEGIN, CR00177241, PM
  @Deprecated
  // END, CR00304623
  protected ProviderSILItemDetails getServiceInvoiceSummaryDetails(
    // END, CR00177241
    ServiceInvoiceLineItem serviceInvoiceLineItem) {

    final ServiceOffering serviceOfferingObj = serviceInvoiceLineItem.getServiceOffering();

    ProviderSILItemDetails providerSILItemDetails = new ProviderSILItemDetails();

    providerSILItemDetails.amountInvoiced = serviceInvoiceLineItem.getAmountInvoiced();

    // BEGIN, CR00158345, GP
    List<ServiceInvoiceLineItemClient> serviceInvoiceLineItemClients = sortSILIClientByClientName(
      serviceInvoiceLineItem.getServiceInvoiceLineItemClients());

    ServiceInvoiceLineItemClient serviceInvoiceLineItemClient = serviceInvoiceLineItemClients.iterator().next();

    providerSILItemDetails.clientName = serviceInvoiceLineItemClient.getClientFirstName()
      + GeneralConstants.kSpace
      + serviceInvoiceLineItemClient.getClientLastName();
    // END, CR00158345

    providerSILItemDetails.service = serviceOfferingObj.getName();
    providerSILItemDetails.serviceDateFrom = serviceInvoiceLineItem.getServiceDateFrom();
    providerSILItemDetails.serviceDateTo = serviceInvoiceLineItem.getServiceDateTo();
    providerSILItemDetails.serviceInvoiceID = serviceInvoiceLineItem.getServiceInvoice().getID();
    providerSILItemDetails.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
    providerSILItemDetails.status = serviceInvoiceLineItem.getStatus().toString();

    return providerSILItemDetails;
  }

  // BEGIN, CR00304623, SS
  /**
   * Gets the Service Invoice Line Item details.
   *
   * @param siliDetails
   * Contains service invoice line item details.
   *
   * @return The provider service invoice line item details.
   */
  protected ProviderSILItemDetails getServiceInvoiceDetails(
    final curam.cpm.sl.entity.struct.SILIDetails siliDetails) {
    final ProviderSILItemDetails providerSILItemDetails = new ProviderSILItemDetails();

    providerSILItemDetails.amountInvoiced = siliDetails.amountInvoiced;
    providerSILItemDetails.clientName = siliDetails.clientFirstName
      + GeneralConstants.kSpace + siliDetails.clientLastName;
    providerSILItemDetails.service = serviceOfferingDAO.get(siliDetails.serviceID).getName();
    providerSILItemDetails.serviceDateFrom = siliDetails.serviceDateFrom;
    providerSILItemDetails.serviceDateTo = siliDetails.serviceDateTo;
    providerSILItemDetails.serviceInvoiceID = siliDetails.serviceInvoiceID;
    providerSILItemDetails.serviceInvoiceLineItemID = siliDetails.serviceInvoiceLineItemID;
    providerSILItemDetails.status = siliDetails.status;
    return providerSILItemDetails;
  }

  // END, CR00304623

  /**
   * Sorts the list of service invoice by receipt date.
   *
   * @param unSortedlist
   * Unsorted list of service invoice.
   * @return List Sorted list of service invoice
   */
  // BEGIN, CR00177241, PM
  protected List<curam.financial.impl.ServiceInvoice> sortByRecieptDate(
    // END, CR00177241
    final Set<curam.financial.impl.ServiceInvoice> unSortedlist) {

    final List<curam.financial.impl.ServiceInvoice> serviceInvoice = new ArrayList<curam.financial.impl.ServiceInvoice>(
      unSortedlist);

    Collections.sort(serviceInvoice,
      new Comparator<curam.financial.impl.ServiceInvoice>() {
      public int compare(final curam.financial.impl.ServiceInvoice lhs,
        curam.financial.impl.ServiceInvoice rhs) {
        return rhs.getReceiptDate().compareTo(lhs.getReceiptDate());
      }
    });

    return serviceInvoice;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceInvoiceLineItemTransactionsList viewServiceInvoiceLineItemTransanctions(
    ServiceInvoiceLineItemKey key) {
    // Return Struct
    ServiceInvoiceLineItemTransactionsList serviceInvoiceLineItemTransactionsList = new ServiceInvoiceLineItemTransactionsList();

    final ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.serviceInvoiceLineItemID);
    // Get transaction list based on particular service invoice line item

    // BEGIN, CR00227968, RPB
    Set<ServiceInvoiceLineItemTransaction> unModifiableServiceInvoiceLineItemTransactions = siliTransactionHelper.getTransactions(
      serviceInvoiceLineItem);
    // END, CR00227968

    Set<ServiceInvoiceLineItemTransaction> serviceInvoiceLineItemTransactions = new HashSet<ServiceInvoiceLineItemTransaction>();

    serviceInvoiceLineItemTransactions.addAll(
      unModifiableServiceInvoiceLineItemTransactions);

    // BEGIN, CR00137716, ABS

    // BEGIN, CR00153049, AS

    // Sort service invoice line item transactions first by creation date and
    // then by transaction type.
    List<ServiceInvoiceLineItemTransaction> serviceInvoiceLineItemTransactionList = sortSILITransactionByTransactionType(
      sortSILITransactionByCreationDateTime(serviceInvoiceLineItemTransactions));

    // END, CR00153049

    for (ServiceInvoiceLineItemTransaction sILITransaction : serviceInvoiceLineItemTransactionList) {
      // END, CR00137716

      // Manipulation struct
      ServiceInvoiceLineItemTransactionDetails serviceInvoiceLineItemTransactionDetails = new ServiceInvoiceLineItemTransactionDetails();

      serviceInvoiceLineItemTransactionDetails.amount = sILITransaction.getAmount();
      serviceInvoiceLineItemTransactionDetails.creationDateTime = sILITransaction.getCreationDateTime();
      serviceInvoiceLineItemTransactionDetails.serviceInvoiceLineItemID = sILITransaction.getServiceInvoiceLineItem().getID();
      serviceInvoiceLineItemTransactionDetails.sILITransactionID = sILITransaction.getID();
      // START CR00094326, JSP
      serviceInvoiceLineItemTransactionDetails.transactionType = sILITransaction.getTransactionType().getCode();
      // END CR00094326
      serviceInvoiceLineItemTransactionDetails.adjustmentAmount = sILITransaction.getAdjustmentAmount();
      serviceInvoiceLineItemTransactionDetails.adjustmentReason = sILITransaction.getAdjustmentReason();

      // Setting adjustment factor based on adjustment reason
      if (serviceInvoiceLineItemTransactionDetails.adjustmentReason.equals(
        ServiceInvoiceLineItemAdjustmentReason.INCREASED_PER_PROVIDER_OFFERING_RATE)
          || (serviceInvoiceLineItemTransactionDetails.adjustmentReason.equals(
            ServiceInvoiceLineItemAdjustmentReason.REDUCED_PER_PROVIDER_OFFERING_RATE))) {
        serviceInvoiceLineItemTransactionDetails.adjustmentFactor = ServiceInvoiceLineItemAdjustmentfactor.PROVIDER_OFFERING_RATE;
      } else if (serviceInvoiceLineItemTransactionDetails.adjustmentReason.equals(
        ServiceInvoiceLineItemAdjustmentReason.INCREASED_PER_SERVICE_OFFERING_RATE)
          || (serviceInvoiceLineItemTransactionDetails.adjustmentReason.equals(
            ServiceInvoiceLineItemAdjustmentReason.REDUCED_PER_SERVICE_OFFERING_RATE))) {
        serviceInvoiceLineItemTransactionDetails.adjustmentFactor = ServiceInvoiceLineItemAdjustmentfactor.SERVICE_OFFERING_RATE;
      } else if (serviceInvoiceLineItemTransactionDetails.adjustmentReason.equals(
        ServiceInvoiceLineItemAdjustmentReason.INCREASED_PER_SERVICE_AUTHORIZATION_LINE_ITEM)
          || (serviceInvoiceLineItemTransactionDetails.adjustmentReason.equals(
            ServiceInvoiceLineItemAdjustmentReason.REDUCED_PER_SERVICE_AUTHORIZATION_LINE_ITEM))) {
        serviceInvoiceLineItemTransactionDetails.adjustmentFactor = ServiceInvoiceLineItemAdjustmentfactor.SERVICE_AUTHORIZATION_LINE_ITEM;
        // BEGIN CR00089352, SK
      } else if (serviceInvoiceLineItemTransactionDetails.adjustmentReason.equals(
        ServiceInvoiceLineItemAdjustmentReason.INCREASED_PER_ESTABLISHED_CONTRACT)
          || serviceInvoiceLineItemTransactionDetails.adjustmentReason.equals(
            ServiceInvoiceLineItemAdjustmentReason.REDUCED_PER_ESTABLISHED_CONTRACT)) {
        // END CR00089352
        serviceInvoiceLineItemTransactionDetails.adjustmentFactor = ServiceInvoiceLineItemAdjustmentfactor.UTILISATION_CONTRACT_RATE;
      }

      if (!serviceInvoiceLineItemTransactionDetails.adjustmentFactor.equals(
        GeneralConstants.kEmpty)) {
        serviceInvoiceLineItemTransactionDetails.adjustmentFactorInd = true;
      }

      serviceInvoiceLineItemTransactionsList.details.addRef(
        serviceInvoiceLineItemTransactionDetails);
    }

    // Get context description of Service invoice line item transaction page
    serviceInvoiceLineItemTransactionsList.desc = getServiceInvoiceLineItemContextDescription(
      key);

    return serviceInvoiceLineItemTransactionsList;
  }

  /**
   * Reads Related ID of service authorization line item or service offering or
   * provider offering due to which that the amount invoiced for a service
   * invoice line item is adjusted.
   *
   * @param key
   * Contains service invoice line item ID, service invoice line item
   * transaction ID and transaction type.
   *
   * @return ResolveSILIAdjustmentFactorDetails Contains Related ID.
   */
  public ResolveSILIAdjustmentFactorDetails resolveSILIAdjustmentFactor(
    ResolveSILIAdjustmentFactorKey key) {

    // Return Struct
    ResolveSILIAdjustmentFactorDetails resolveSILIAdjustmentFactorDetails = new ResolveSILIAdjustmentFactorDetails();

    // Based on service authorization line item
    ServiceInvoiceLineItemTransaction sILITransaction = siliTransactionDAO.get(
      key.sILITransactionID);
    ServiceInvoiceLineItem ServiceInvoiceLineItem = sILITransaction.getServiceInvoiceLineItem();

    resolveSILIAdjustmentFactorDetails.relatedID = ServiceInvoiceLineItem.getServiceAuthorizationLineItem().getID();

    return resolveSILIAdjustmentFactorDetails;
  }

  /**
   * {@inheritDoc}
   */
  public SILITransactionDetails viewServiceInvoiceLineItemTransanction(
    SILITransactionKey key) {

    // Return Struct
    SILITransactionDetails SILITransactionDetails = new SILITransactionDetails();
    ServiceInvoiceLineItemTransaction sILITransaction = siliTransactionDAO.get(
      key.siliTransactionID);

    // Assign the values from entity record
    SILITransactionDetails.saliUnitAmount = convertMoneyToString(
      sILITransaction.getServiceAuthorizationLineItemUnitAmount());

    SILITransactionDetails.serviceRateFixedAmount = convertMoneyToString(
      sILITransaction.getServiceFixedPayment());

    SILITransactionDetails.soFixedAmountPaymentOption = sILITransaction.getServiceFixedPaymentOption();

    SILITransactionDetails.serviceRateMinAmount = convertMoneyToString(
      sILITransaction.getServiceMinimumPayment());

    SILITransactionDetails.soMinAmountPaymentOption = sILITransaction.getServiceMinimumPaymentOption();

    SILITransactionDetails.serviceRateMaxAmount = convertMoneyToString(
      sILITransaction.getServiceMaximumPayment());

    SILITransactionDetails.soMaxAmountPaymentOption = sILITransaction.getServiceMaximumPaymentOption();

    SILITransactionDetails.providerOfferingRateFixAmount = convertMoneyToString(
      sILITransaction.getProviderFixedPayment());

    SILITransactionDetails.poFixedAmountPaymentOption = sILITransaction.getProviderFixedPaymentOption();

    SILITransactionDetails.providerOfferingRateMinAmount = convertMoneyToString(
      sILITransaction.getProviderMinimumPayment());

    SILITransactionDetails.poMinAmountPaymentOption = sILITransaction.getProviderMinimumPaymentOption();

    SILITransactionDetails.providerOfferingRateMaxAmount = convertMoneyToString(
      sILITransaction.getProviderMaximumPayment());

    SILITransactionDetails.poMaximumAmountPaymentOption = sILITransaction.getProviderMaximumPaymentOption();

    return SILITransactionDetails;
  }

  /**
   * Converts Money to string.
   *
   * @param value
   * Money.
   * @return String Money in string format.
   */
  // BEGIN, CR00177241, PM
  protected String convertMoneyToString(Money value) {
    // END, CR00177241
    String moneyInStringType = "";

    if (value.getValue() >= 0) {
      moneyInStringType = value.toString();
    }
    return moneyInStringType;
  }

  /**
   * Submits a list of Service Invoice Line Items for processing.
   *
   * @param keyList
   * Contains service invoice line item ID list.
   * @return InformationalMsgDtlsList The list of informational messages.
   * @throws InformationalException
   * {@link SERVICEINVOICE#ERR_SERVICEINVOICE_FV_ALTEAST_ONE_SILI_MUST_BE_SELECTED}
   * If none of the Service Invoice Line Item is selected for
   * processing.
   * {@link SERVICEINVOICELINEITEM#ERR_SERVICEINVOICELINEITEM_XFV_EXCEPTION_TASK_CREATED}
   * If exception task is created during processing of Service Invoice
   * Line Item.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationalMsgDtlsList submitServiceInvoiceLineItemsForProcessing(
    final ServiceInvoiceLineItemList keyList) throws AppException,
      InformationalException {

    final InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    String referenceNumbers = "";

    boolean errorWhileProcessing = false;
    // Create StringList from ServiceInvoiceLineItem IDs List
    final StringList sILIIDKeyList = StringUtil.delimitedText2StringList(
      keyList.ServiceInvoiceLineItemIDList, '\t');
    // Manipulating variable
    final curam.cpm.facade.struct.ServiceInvoiceLineItemKey serviceInvoiceLineItemKey = new curam.cpm.facade.struct.ServiceInvoiceLineItemKey();

    // At least one SILI must be selected on multiple selection to process SILI
    if (sILIIDKeyList.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICEExceptionCreator.ERR_SERVICEINVOICE_FV_ALTEAST_ONE_SILI_MUST_BE_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }

    String[] list;
    ServiceInvoiceLineItem serviceInvoiceLineItem;
    ServiceInvoiceLineItemCorrection siliCorrection;

    for (final String siliKeyID : sILIIDKeyList) {

      list = siliKeyID.split(GeneralConstants.kUnderScoreString);

      serviceInvoiceLineItemKey.key.serviceInvoiceLineItemID = Long.parseLong(
        list[0].replace(CuramConst.gkComma, ""));

      serviceInvoiceLineItemKey.versionNo = Integer.parseInt(list[1]);
      // Call facade layer method to process individual service invoice line
      // item
      serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
        serviceInvoiceLineItemKey.key.serviceInvoiceLineItemID);
      final SILICorrectionVersionKey siliCorrectionVersionKey = new SILICorrectionVersionKey();

      // BEGIN, CR00305409, SSK
      siliCorrectionVersionKey.SILICorrectionID = checkIfCorrectionExitsForSILI(
        serviceInvoiceLineItem);

      if (0 == siliCorrectionVersionKey.SILICorrectionID) {
        // END, CR00305409
        InformationalMsgDtlsList dtlsList = submitSILIForProcessing(
          serviceInvoiceLineItemKey);

        if (dtlsList.dtls.size() != 0
          && (ServiceInvoiceLineItemStatus.PENDINGAPPROVAL.equals(
            serviceInvoiceLineItem.getStatus().toString())
              || ServiceInvoiceLineItemStatus.DENIED.equals(
                serviceInvoiceLineItem.getStatus().toString())
                || ServiceInvoiceLineItemStatus.CANCELED.equals(
                  serviceInvoiceLineItem.getStatus().toString()))) {
          for (final InformationalMsgDtls informationalMsgDtls : dtlsList.dtls.items()) {

            informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
          }
        } else if (dtlsList.dtls.size() != 0) {
          referenceNumbers += serviceInvoiceLineItem.getReferenceNumber()
            + GeneralConstants.kComma + GeneralConstants.kSpace;
          errorWhileProcessing = true;
        }

      } else {
        // BEGIN, CR00305409, SSK
        siliCorrection = siliCorrectionDAO.get(
          siliCorrectionVersionKey.SILICorrectionID);
        siliCorrectionVersionKey.versionNo = siliCorrection.getVersionNo();
        siliCorrection.submit(siliCorrectionVersionKey.versionNo);
      }
      // END, CR00305409
    }

    if (true == errorWhileProcessing) {

      AppException ae = new AppException(SERVICEINVOICELINEITEM.ERR_SERVICEINVOICELINEITEM_XFV_EXCEPTION_TASK_CREATED).arg(
        referenceNumbers);

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      informationalManager.addInformationalMsg(ae,
        curam.core.impl.CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning);

      String[] messages = informationalManager.obtainInformationalAsString();

      InformationalMsgDtls dtls = new InformationalMsgDtls();

      dtls.informationMsgTxt = messages[0];

      informationalMsgDtlsList.dtls.addRef(dtls);
    }

    return informationalMsgDtlsList;
  }

  // BEGIN, CR00200393, SSK
  /**
   * Reads Service Invoice Line Item details from the history.
   *
   * @param key
   * Contains service invoice line item history ID.
   * @return ServiceInvoiceLineItemDetails Contains service invoice line item
   * details.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link ServiceInvoice#viewSILIAndCorrectionModifications(SILIHistoryKey)}
   * . As part of the merging service invoice line item and service
   * invoice line item correction changes has been done to maintain
   * correction clients in service invoice line item client and
   * maintain correction history in service invoice line item
   * history entity. See release note: CR00200393.
   */
  @Deprecated
  public ServiceInvoiceLineItemDetails viewServiceInvoiceLineItemModifications(
    SILIHistoryKey key) {
    // END, CR00200393

    ServiceInvoiceLineItemDetails serviceInvoiceLineItemDetails = new ServiceInvoiceLineItemDetails();
    curam.financial.impl.ServiceInvoiceLineItemHistory sILIHistory = sILIHistoryDAO.get(
      key.siliHistoryID);

    serviceInvoiceLineItemDetails.details.saReferenceNo = sILIHistory.getServiceAuthorizationReferenceNumber();
    serviceInvoiceLineItemDetails.details.serviceDateFrom = sILIHistory.getServiceDateFrom();
    serviceInvoiceLineItemDetails.details.serviceDateTo = sILIHistory.getServiceDateTo();
    serviceInvoiceLineItemDetails.details.noOfUnits = sILIHistory.getNumberOfUnits();
    serviceInvoiceLineItemDetails.details.amountInvoiced = sILIHistory.getAmountInvoiced();
    serviceInvoiceLineItemDetails.details.caseReferenceNo = sILIHistory.getCaseReferenceNumber();
    serviceInvoiceLineItemDetails.details.status = sILIHistory.getStatus().getCode();

    ServiceDetails serviceDetails = new ServiceDetails();

    serviceDetails = getServiceDetails(sILIHistory.getServiceOffering());

    serviceInvoiceLineItemDetails.dtls.service = serviceDetails.service;
    serviceInvoiceLineItemDetails.details.unitAmount = sILIHistory.getUnitAmount();

    serviceInvoiceLineItemDetails.details.payeeReferenceNo = sILIHistory.getPayeeReferenceNumber();
    serviceInvoiceLineItemDetails.details.payeeName = sILIHistory.getPayeeName();

    serviceInvoiceLineItemDetails.details.providerReferenceNo = sILIHistory.getProviderReferenceNumber();
    serviceInvoiceLineItemDetails.details.providerName = sILIHistory.getProviderName();

    serviceInvoiceLineItemDetails.details.clientReferenceNo = sILIHistory.getClientReferenceNumber();
    serviceInvoiceLineItemDetails.details.clientFirstName = sILIHistory.getClientFirstName();
    serviceInvoiceLineItemDetails.details.clientLastName = sILIHistory.getClientLastName();
    serviceInvoiceLineItemDetails.details.clientDOB = sILIHistory.getClientDateOfBirth();

    ServiceInvoiceLineItemKey silikey = new ServiceInvoiceLineItemKey();

    silikey.serviceInvoiceLineItemID = sILIHistory.getServiceInvoiceLineItem().getID();

    serviceInvoiceLineItemDetails.desc = getServiceInvoiceLineItemContextDescription(
      silikey);

    return serviceInvoiceLineItemDetails;
  }

  /**
   * Sorts the list of Service Invoice Line Item History in descending order on
   * start date.
   *
   * @param serviceInvoiceLineItemHistoryList
   * Unsorted list of service invoice line item History.
   * @return ServiceInvoiceLineItemHistoryList The list of service Invoice line
   * item history sorted in descending order.
   */

  // BEGIN, CR00177241, PM
  protected ServiceInvoiceLineItemHistoryList sortHistoryArray(
    // END, CR00177241
    ServiceInvoiceLineItemHistoryList serviceInvoiceLineItemHistoryList) {

    ServiceInvoiceLineItemHistory[] serviceInvoiceLineItemHistoryArray = new ServiceInvoiceLineItemHistory[serviceInvoiceLineItemHistoryList.dtlsList.size()];

    serviceInvoiceLineItemHistoryArray = (ServiceInvoiceLineItemHistory[]) serviceInvoiceLineItemHistoryList.dtlsList.toArray(
      serviceInvoiceLineItemHistoryArray);
    // Sort the rates in the ascending order by start date
    Arrays.sort(serviceInvoiceLineItemHistoryArray,
      new Comparator<ServiceInvoiceLineItemHistory>() {
      public int compare(final ServiceInvoiceLineItemHistory lhs,
        ServiceInvoiceLineItemHistory rhs) {
        return rhs.dtls.dateTimeChanged.compareTo(lhs.dtls.dateTimeChanged);
      }
    });
    serviceInvoiceLineItemHistoryList = new ServiceInvoiceLineItemHistoryList();
    for (ServiceInvoiceLineItemHistory hist : serviceInvoiceLineItemHistoryArray) {
      serviceInvoiceLineItemHistoryList.dtlsList.addRef(hist);
    }
    return serviceInvoiceLineItemHistoryList;
  }

  /**
   * Reads list of Service Invoice Line Item Transaction related to the service
   * invoice line item.
   *
   * @param key
   * Contains service invoice line item ID.
   *
   * @return ServiceInvoiceLineItemTransactionsList The list of service invoice
   * line item transaction.
   */
  public ServiceInvoiceLineItemTransactionsList viewSILITransactionsForProvider(
    ServiceInvoiceLineItemKey key) {
    // Return Struct
    ServiceInvoiceLineItemTransactionsList serviceInvoiceLineItemTransactionsList = new ServiceInvoiceLineItemTransactionsList();

    final ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.serviceInvoiceLineItemID);

    // Get transaction list based on particular service invoice line item

    for (ServiceInvoiceLineItemTransaction sILITransaction : serviceInvoiceLineItem.getTransactions()) {

      // Manipulation struct
      ServiceInvoiceLineItemTransactionDetails serviceInvoiceLineItemTransactionDetails = new ServiceInvoiceLineItemTransactionDetails();

      if (sILITransaction.getAdjustmentReason() != null
        && !GeneralConstants.kEmpty.equalsIgnoreCase(
          sILITransaction.getAdjustmentReason())) {

        serviceInvoiceLineItemTransactionDetails.serviceInvoiceLineItemID = sILITransaction.getServiceInvoiceLineItem().getID();
        serviceInvoiceLineItemTransactionDetails.sILITransactionID = sILITransaction.getID();
        serviceInvoiceLineItemTransactionDetails.adjustmentAmount = sILITransaction.getAdjustmentAmount();
        serviceInvoiceLineItemTransactionDetails.adjustmentReason = sILITransaction.getAdjustmentReason();

        serviceInvoiceLineItemTransactionsList.details.addRef(
          serviceInvoiceLineItemTransactionDetails);
      }
    }

    // Get context description of Service invoice line item transaction page
    serviceInvoiceLineItemTransactionsList.desc = getServiceInvoiceLineItemContextDescription(
      key);

    return serviceInvoiceLineItemTransactionsList;
  }

  /**
   * Updates the service invoice line item details with the service invoice line
   * item details passed from the exception task.
   *
   * @param details
   * Contains the service invoice line item details.
   * @throws InformationalException
   * {@link SERVICEINVOICELINEITEM#ERR_SERVICEINVOICELINEITEM_XRV_THIS_SERVICE_INVOICE_LINE_ITEM_IS_NOT_OPEN_IT_CANNOT_BE_MODIFIED}
   * If Service Invoice Line Item is not in 'Open' status.
   */

  public void updateEPServiceInvoiceLineItem(
    UpdateServiceInvoiceLineItemDetails details)
    throws InformationalException {
    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      details.details.serviceInvoiceLineItemID);

    if (serviceInvoiceLineItem.getStatus().getCode().equals(
      ServiceInvoiceLineItemStatus.OPEN)) {

      setServiceInvoiceLineItemFields(serviceInvoiceLineItem, details.details);

      serviceInvoiceLineItem.matchIdentifiers(true);
      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      informationalManager.failOperation();

      serviceInvoiceLineItem.modify(details.details.versionNo);

    } else {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICELINEITEM_XRV_THIS_SERVICE_INVOICE_LINE_ITEM_IS_NOT_OPEN_IT_CANNOT_BE_MODIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    ValidationHelper.failIfErrorsExist();
  }

  /**
   * Submits the service invoice line item for processing.
   *
   * @param key
   * Contains service invoice line item ID.
   * @return InformationalMsgDtlsList The list of informational message.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected InformationalMsgDtlsList submitSILIForProcessing(
    // END, CR00177241
    curam.cpm.facade.struct.ServiceInvoiceLineItemKey key)
    throws AppException, InformationalException {

    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.key.serviceInvoiceLineItemID);
    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    try {
      serviceInvoiceLineItem.submit(key.versionNo);
    } catch (AppException ae) {
      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      informationalManager.addInformationalMsg(ae,
        curam.core.impl.CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning);

      String[] messages = informationalManager.obtainInformationalAsString();

      InformationalMsgDtls dtls = new InformationalMsgDtls();

      dtls.informationMsgTxt = messages[0];
      informationalMsgDtlsList.dtls.addRef(dtls);
      TransactionInfo.setInformationalManager();
      return informationalMsgDtlsList;
    }

    // create event
    Event submitServiceInvoiceLI = new Event();

    submitServiceInvoiceLI.eventKey = NEWINVOICECREATED.INVOICESUBMITTED;
    submitServiceInvoiceLI.primaryEventData = serviceInvoiceLineItem.getServiceInvoice().getID();

    // The service invoice has been submitted
    // Raise event to close this workflow task.
    EventService.raiseEvent(submitServiceInvoiceLI);

    return informationalMsgDtlsList;
  }

  /**
   * Gets the confirmation messages after the service invoice line item is
   * submitted for processing.
   *
   * @return ViewServiceInvoiceLineItemDetails Contains service invoice line
   * item details.
   * @throws InformationalException
   * {@link SERVICEINVOICE#ERR_SERVICEINVOICE_XRV_RECEIPT_DATE_MUST_BE_TODAY_OR_EARLIER}
   * If Service Invoice To Date is before From Date.
   */
  public ViewServiceInvoiceLineItemDetails confirmSubmitForProcessing()
    throws InformationalException {

    ViewServiceInvoiceLineItemDetails details = new ViewServiceInvoiceLineItemDetails();
    AppException ae = new AppException(
      SERVICEINVOICE.ERR_SERVICEINVOICE_XRV_RECEIPT_DATE_MUST_BE_TODAY_OR_EARLIER);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
      ae, curam.core.impl.CuramConst.gkEmpty,
      InformationalElement.InformationalType.kWarning,
      curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

    String[] messages = informationalManager.obtainInformationalAsString();

    InformationalMsgDtls dtls = new InformationalMsgDtls();

    dtls.informationMsgTxt = messages[0];
    details.msgList.dtls.addRef(dtls);
    TransactionInfo.setInformationalManager();

    details.dtls.flag = true;

    return details;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceInvoiceDetails viewServiceInvoiceBySILI(
    ServiceInvoiceLineItemKey key) {

    // retrieve the instance of the entity
    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.serviceInvoiceLineItemID);
    // return to the client
    ServiceInvoiceLineItemDetails serviceInvoiceLineItemDetails = new ServiceInvoiceLineItemDetails();

    serviceInvoiceLineItemDetails.details.assign(
      getServiceInvoiceLineItemFields(serviceInvoiceLineItem));

    ServiceInvoiceDetails serviceInvoiceDetails = new ServiceInvoiceDetails();
    ServiceInvoiceDtls serviceInvoiceDtls = new ServiceInvoiceDtls();
    curam.cpm.sl.entity.struct.ServiceInvoiceKey serviceInvoiceKey = new curam.cpm.sl.entity.struct.ServiceInvoiceKey();

    serviceInvoiceKey.serviceInvoiceID = serviceInvoiceLineItemDetails.details.serviceInvoiceID;

    final curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
      serviceInvoiceKey.serviceInvoiceID);

    serviceInvoiceDtls = getServiceInvoiceFields(serviceInvoice);

    serviceInvoiceDetails.serviceInvoiceDtls.assign(serviceInvoiceDtls);

    if (!(serviceInvoice.getLifecycleState().getCode().equals(
      RECORDSTATUS.CANCELLED))) {
      // START CR00094326, JSP
      ServiceInvoiceDetails serviceInvoiceStatus = serviceInvoice.getServiceInvoiceDerivedStatus();

      // END CR00094326
      serviceInvoiceDetails.serviceInvoiceDerivedStatus = serviceInvoiceStatus.serviceInvoiceDerivedStatus;
    } else {
      serviceInvoiceDetails.serviceInvoiceDerivedStatus = ServiceInvoiceDerivedStatus.CANCELED;
    }
    serviceInvoiceDetails.desc = getServiceInvoiceContextDescription(
      serviceInvoiceKey);

    // return to the client
    return serviceInvoiceDetails;
  }

  // Begin CR00079491, ABS
  /**
   * Submits the Service Invoice Line Item for processing from the view service
   * invoice line item screen.
   *
   * @param key
   * Contains service invoice line item ID.
   * @throws InformationalException
   * {@link SERVICEINVOICELINEITEM#ERR_SERVICEINVOICELINEITEM_XRV_EXCEPTION_TASK_PRESENT_CANNOT_SUBMIT_FOR_PROCESSING}
   * If exception task is present for the Service Invoice Line Item.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void submitSILIForProcessingInView(
    curam.cpm.facade.struct.ServiceInvoiceLineItemKey key)
    throws AppException, InformationalException {
    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.key.serviceInvoiceLineItemID);

    // START CR00094326, JSP
    if (serviceInvoiceLineItem.isInExceptionProcessing() == true) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICELINEITEM_XRV_EXCEPTION_TASK_PRESENT_CANNOT_SUBMIT_FOR_PROCESSING(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();
    submitServiceInvoiceLineItemForProcessing(key);
  }

  /**
   * Denies the Service Invoice Line Item from the view service invoice line
   * item screen.
   *
   * @param siliKey
   * Contains service invoice line item ID.
   * @throws InformationalException
   * {@link SERVICEINVOICELINEITEM#ERR_SERVICEINVOICELINEITEM_XRV_CAN_BE_DENIED_THROUGH_EXCEPTIONTASK}
   * If Service Invoice Line Item is in 'Open' status and no exception
   * processing task is present.
   * @throws AppException
   * Generic Exception Signature.
   */
  // START CR00094504, JSP
  public void denySILIForProcessingInView(
    curam.cpm.facade.struct.ServiceInvoiceLineItemKey siliKey)
    throws AppException, InformationalException {
    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      siliKey.key.serviceInvoiceLineItemID);

    // END CR00094504
    if (ServiceInvoiceLineItemStatusEntry.OPEN.equals(
      serviceInvoiceLineItem.getStatus())
        && serviceInvoiceLineItem.isInExceptionProcessing() != true) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICELINEITEM_XRV_CAN_BE_DENIED_THROUGH_EXCEPTIONTASK(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();

    // START CR00094504, JSP
    denyServiceInvoiceLineItem(siliKey);
    // END CR00094504
  }

  /**
   * Cancels the Service Invoice Line Item from the view service invoice line
   * item screen.
   *
   * @param siliKey
   * Contains service invoice line item ID.
   * @throws InformationalException
   * {@link SERVICEINVOICELINEITEM#ERR_SERVICEINVOICELINEITEM_XRV_EXCEPTION_TASK_PRESENT_CANNOT_CANCEL}
   * If exception task is present for the Service Invoice Line Item.
   * @throws AppException
   * Generic Exception Signature.
   */
  // START CR00094504, JSP
  public void deleteSILIInView(
    curam.cpm.facade.struct.ServiceInvoiceLineItemKey siliKey)
    throws AppException, InformationalException {
    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      siliKey.key.serviceInvoiceLineItemID);

    // END CR00094504
    // START CR00094326, JSP
    if (serviceInvoiceLineItem.isInExceptionProcessing() == true) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICELINEITEM_XRV_EXCEPTION_TASK_PRESENT_CANNOT_CANCEL(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();
    curam.cpm.facade.struct.ServiceInvoiceLineItemKey lineItemKey = new curam.cpm.facade.struct.ServiceInvoiceLineItemKey();

    // START CR00094504, JSP
    lineItemKey.key = siliKey.key;
    cancelServiceInvoiceLineItem(siliKey);
    // END CR00094504
  }

  // Begin CR00079491, ABS
  /**
   * Allows the Service Invoice Line Item if it is a duplication of an existing
   * service invoice line item.
   *
   * @param key
   * Contains service invoice line item ID.
   * @throws InformationalException
   * {@link SERVICEINVOICELINEITEM#ERR_SERVICEINVOICELINEITEM_XRV_SERVICEINVOICELINEITEM_CANNOT_BE_ACCEPTED_AS_DUPLICATE}
   * If the Service Invoice Line Item is not duplicate.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void allowDuplicateServiceInvoiceLineItem(
    curam.cpm.facade.struct.ServiceInvoiceLineItemKey key)
    throws AppException, InformationalException {
    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.key.serviceInvoiceLineItemID);

    try {
      serviceInvoiceLineItem.submit(key.versionNo);
    } catch (AppException ae) {
      if (!(ae.getCatEntry().equals(
        SERVICEINVOICELINEITEM.ERR_SERVICEINVOICELINEITEM_XRV_DUPLICATE_SERVICE_INVOICE_LINE_ITEM))) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICELINEITEM_XRV_SERVICEINVOICELINEITEM_CANNOT_BE_ACCEPTED_AS_DUPLICATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

        ValidationHelper.failIfErrorsExist();
      }
    }

    serviceInvoiceLineItem.setAllowDuplicateSILI(true);

    submitServiceInvoiceLineItemForProcessing(key);

  }

  // BEGIN CR00097498, GP
  /**
   * Validates if the number of units of Service Invoice Line Item being
   * invoiced is less than or equal to number of units remaining of pending
   * approval Service Invoice Line Items.
   *
   * @param serviceInvoiceLineItemKey
   * Contains service invoice line item id.
   * @return InformationalMessageList Contains informational message.
   * @throws InformationalException
   * {@link SERVICEINVOICELINEITEM#INF_SERVICEINVOICELINEITEM_UNITS_REMAINING_NOT_SUFFICIENT}
   * If units invoiced is greater than units remaining after taking in
   * to account units invoiced of 'Pending Approval' service invoice
   * line items.
   */
  public InformationalMessageList validateSILIUnitsInvoiced(
    curam.cpm.facade.struct.ServiceInvoiceLineItemKey serviceInvoiceLineItemKey)
    throws InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();

    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      serviceInvoiceLineItemKey.key.serviceInvoiceLineItemID);

    if (serviceInvoiceLineItem.getStatus().getCode().equals(
      ServiceInvoiceLineItemStatus.PENDINGAPPROVAL)) {

      ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceInvoiceLineItem.getServiceAuthorizationLineItem();

      int noOfUnitsInvoiced = serviceInvoiceLineItem.getNumberOfUnits();

      // BEGIN CR00103785, JSP
      long noOfUnitsConsumedByPendingApprovalSILI = getUnitsConsumedByStatus(
        serviceAuthorizationLineItem,
        ServiceInvoiceLineItemStatusEntry.PENDINGAPPROVAL);

      long noOfUnitsRemaining = serviceAuthorizationLineItem.getUnitsAuthorized()
        - serviceAuthorizationLineItem.getUnitsConsumed();

      // Check if the number of authorized units remaining
      // is greater than or equal to number of units being invoiced
      if (noOfUnitsRemaining >= noOfUnitsInvoiced) {

        // Check if the number of authorized units remaining is less than
        // number of units consumed by pending SILIs
        if (noOfUnitsRemaining < noOfUnitsConsumedByPendingApprovalSILI) {
          // END CR00103785

          InformationalManager informationalManager = TransactionInfo.getInformationalManager();
          AppException appException = SERVICEINVOICELINEITEMExceptionCreator.INF_SERVICEINVOICELINEITEM_UNITS_REMAINING_NOT_SUFFICIENT();

          informationalManager.addInformationalMsg(appException,
            CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning);

          // Assign informational messages to return struct
          String warnings[] = informationalManager.obtainInformationalAsString();

          for (int i = 0; i < warnings.length; i++) {
            InformationalMessage infoMessage = new InformationalMessage();

            infoMessage.messageTest = warnings[i];
            informationalMessageList.dtls.addRef(infoMessage);
          }
        }
      }
    }
    return informationalMessageList;
  }

  /**
   * Gets the units consumed by the Service Invoice Line Items for a given
   * Service Authorization Line Item and Service Invoice Line Item status.
   *
   * @param serviceAuthorizationLineItem
   * Service Authorization Line Item details.
   * @param serviceInvoiceLineItemStatus
   * Status of Service Invoice Line Item.
   * @return long Number of units consumed.
   */
  // BEGIN, CR00177241, PM
  protected long getUnitsConsumedByStatus(
    // END, CR00177241
    ServiceAuthorizationLineItem serviceAuthorizationLineItem,
    ServiceInvoiceLineItemStatusEntry serviceInvoiceLineItemStatus) {

    long unitsConsumed = 0;

    // Read service invoice line item details from service authorization line
    // item ID
    final Set<ServiceInvoiceLineItem> serviceInvoiceLineItems = serviceInvoiceLineItemDAO.searchByServiceAuthorizationLineItem(
      serviceAuthorizationLineItem);

    int noOfserviceInvoiceLineItems = 0;

    for (final ServiceInvoiceLineItem serviceInvoiceLineItem : serviceInvoiceLineItems) {
      if (serviceInvoiceLineItem.getStatus().equals(
        serviceInvoiceLineItemStatus)) {
        unitsConsumed += serviceInvoiceLineItem.getNumberOfUnits();
        noOfserviceInvoiceLineItems++;
      }
    }

    // If it is the last Service Invoice Line Item then set the units consumed
    // to zero so that informational message is not thrown
    if (noOfserviceInvoiceLineItems == 1) {
      unitsConsumed = 0;
    }

    return unitsConsumed;
  }

  // END CR00097498, GP

  // BEGIN CR00103810, ABS
  /**
   * Approves a duplicate service invoice line item from the task page.
   *
   * @param serviceInvoiceLineItemKey
   * service invoice line item key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAINING#ERR_SERVICEINVOICELINEITEM_XRV_DUPLICATE_SERVICE_INVOICE_LINE_ITEM}
   * - If the service invoice line item is not a duplicate.
   */
  public void approveDuplicateSILI(
    curam.cpm.facade.struct.ServiceInvoiceLineItemKey serviceInvoiceLineItemKey)
    throws AppException, InformationalException {

    ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      serviceInvoiceLineItemKey.key.serviceInvoiceLineItemID);

    // Check if the exception task was created due to duplicate service invoice
    // line item
    try {
      // BEGIN, CR00350553, SS
      serviceInvoiceLineItem.validateLineItemAgainstAuthorization();
    } catch (AppException ae) {
      if (!(ae.getCatEntry().equals(
        SERVICEINVOICELINEITEM.ERR_SERVICEINVOICELINEITEM_XRV_DUPLICATE_SERVICE_INVOICE_LINE_ITEM))) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICELINEITEM_XRV_SERVICEINVOICELINEITEM_CANNOT_BE_ACCEPTED_AS_DUPLICATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

        ValidationHelper.failIfErrorsExist();
      }
    }

    // Set the allow duplicate service invoice line item indicator as true
    serviceInvoiceLineItem.setAllowDuplicateSILI(true);
    serviceInvoiceLineItem.setExceptionProcessingInd(false);

    // Approve the service invoice line item
    serviceInvoiceLineItem.approve(serviceInvoiceLineItemKey.versionNo);
    
    // Raises an event to clear the task which is created during
    // submission/approval of Service Invoice Line Item.
    final Event event = new Event();

    event.eventKey = PROVIDERMANAGEMENT.SILIPROCESSED;
    event.primaryEventData = serviceInvoiceLineItem.getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
    // END, CR00350553
  }

  // END CR00103810

  // Begin, CR00137716, ABS
  /**
   * Sorts the list of service invoice line items by client name.
   *
   * @param unsortedServiceInvoiceLineItems
   * Unsorted set of service invoice line items.
   * @return Sorted list of service invoice line items.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.financial.impl.ServiceInvoiceLineItem> sortSILIByClientName(
    // END, CR00177241
    Set<curam.financial.impl.ServiceInvoiceLineItem> unsortedServiceInvoiceLineItems) {

    final List<curam.financial.impl.ServiceInvoiceLineItem> serviceInvoiceLineItemList = new ArrayList<curam.financial.impl.ServiceInvoiceLineItem>(
      unsortedServiceInvoiceLineItems);

    Collections.sort(serviceInvoiceLineItemList,
      new Comparator<curam.financial.impl.ServiceInvoiceLineItem>() {
      public int compare(
        final curam.financial.impl.ServiceInvoiceLineItem lhs,
        curam.financial.impl.ServiceInvoiceLineItem rhs) {
        return (lhs.getClientFirstName() + CPMConstants.kSpace + lhs.getClientLastName()).compareTo(
          rhs.getClientFirstName() + CPMConstants.kSpace
          + rhs.getClientLastName());
      }
    });

    return serviceInvoiceLineItemList;
  }

  /**
   * Sorts the list of service invoice line item transactions by creation date
   * and time.
   *
   * @param unsortedSILITransactions
   * Unsorted set of service invoice line item transaction.
   * @return Sorted list of service invoice line item transaction.
   */
  // BEGIN, CR00177241, PM
  protected List<ServiceInvoiceLineItemTransaction> sortSILITransactionByCreationDateTime(
    // END, CR00177241
    Set<ServiceInvoiceLineItemTransaction> unsortedSILITransactions) {

    final List<ServiceInvoiceLineItemTransaction> serviceInvoiceLineItemTransactionList = new ArrayList<ServiceInvoiceLineItemTransaction>(
      unsortedSILITransactions);

    Collections.sort(serviceInvoiceLineItemTransactionList,
      new Comparator<ServiceInvoiceLineItemTransaction>() {
      public int compare(final ServiceInvoiceLineItemTransaction lhs,
        ServiceInvoiceLineItemTransaction rhs) {
        return (rhs.getCreationDateTime()).compareTo(lhs.getCreationDateTime());
      }
    });

    return serviceInvoiceLineItemTransactionList;
  }

  // END, CR00137716

  // BEGIN, CR00153049, AS
  /**
   * Sorts the list of service invoice line item transactions by transaction
   * type where the creation date and time is same.
   *
   * @param unsortedSILITransactions
   * The SILI transactions list unsorted by transaction type and sorted
   * by creation date.
   * @return The SILI transactions list sorted by transaction type where the
   * creation date and time is same.
   */
  // BEGIN, CR00177241, PM
  protected List<ServiceInvoiceLineItemTransaction> sortSILITransactionByTransactionType(
    // END, CR00177241
    List<ServiceInvoiceLineItemTransaction> unsortedSILITransactions) {

    final List<ServiceInvoiceLineItemTransaction> serviceInvoiceLineItemTransactionList = new ArrayList<ServiceInvoiceLineItemTransaction>(
      unsortedSILITransactions);

    // The sorting order to be achieved is Denied(TRAN2), Canceled(TRAN3),
    // Paid(TRAN4), FlatRateContract(TRAN5) and Invoiced(TRAN1). Except
    // Invoiced, the list needs to ordered just in ascending order. And Invoiced
    // to be ordered last.
    Collections.sort(serviceInvoiceLineItemTransactionList,
      new Comparator<ServiceInvoiceLineItemTransaction>() {
      public int compare(final ServiceInvoiceLineItemTransaction lhs,
        ServiceInvoiceLineItemTransaction rhs) {
        if (lhs.getCreationDateTime().equals(rhs.getCreationDateTime())) {
          int returnValue = (lhs.getTransactionType().getCode()).compareTo(
            rhs.getTransactionType().getCode());

          if ((returnValue < 0)
            && (lhs.getTransactionType().equals(
              ServiceInvoiceLineItemTransactionTypeEntry.INVOICED))) {
            // Swap the entries so that invoiced is ordered last.
            return Math.abs(returnValue);
          } else if ((returnValue > 0)
            && (rhs.getTransactionType().equals(
              ServiceInvoiceLineItemTransactionTypeEntry.INVOICED))) {
            // Entries are not altered if invoiced is already the last
            // entry.
            return 0;
          }
          return returnValue;
        }
        // Not changing the order when the creation date is not same.
        return 0;
      }
    });

    return serviceInvoiceLineItemTransactionList;
  }

  /**
   * Sorts the list of service invoice line item history by status where the
   * date time changed is the same.
   *
   * @param unsortedSILIHistory
   * The SILI history list unsorted by status and sorted by date time
   * changed.
   * @return The SILI history list sorted by status where the date time changed
   * is same.
   */
  // BEGIN, CR00177241, PM
  protected ServiceInvoiceLineItemHistoryList sortSILIHistoryByTransactionType(
    // END, CR00177241
    ServiceInvoiceLineItemHistoryList unsortedSILIHistory) {

    ArrayList<ServiceInvoiceLineItemHistory> serviceInvoiceLineItemHistoryArray = new ArrayList<ServiceInvoiceLineItemHistory>(
      unsortedSILIHistory.dtlsList);

    Collections.sort(serviceInvoiceLineItemHistoryArray,
      new Comparator<ServiceInvoiceLineItemHistory>() {
      public int compare(final ServiceInvoiceLineItemHistory lhs,
        ServiceInvoiceLineItemHistory rhs) {
        int returnValue = 0;

        if (lhs.dtls.dateTimeChanged.equals(rhs.dtls.dateTimeChanged)) {
          returnValue = (rhs.dtls.status).compareTo(lhs.dtls.status);
        }
        return returnValue;
      }
    });

    ServiceInvoiceLineItemHistoryList serviceInvoiceLineItemHistoryList = new ServiceInvoiceLineItemHistoryList();

    for (ServiceInvoiceLineItemHistory hist : serviceInvoiceLineItemHistoryArray) {
      serviceInvoiceLineItemHistoryList.dtlsList.addRef(hist);
    }
    return serviceInvoiceLineItemHistoryList;
  }

  // END, CR00153049

  // BEGIN, CR00158345, GP
  /**
   * {@inheritDoc}
   */
  public void addClientToServiceInvoiceLineItem(
    SILIClientDetails siliClientDetails) throws AppException,
      InformationalException {

    ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      siliClientDetails.serviceInvoiceLineItemID);

    ServiceInvoiceLineItemClient serviceInvoiceLineItemClient = serviceInvoiceLineItemClientDAO.newInstance();

    serviceInvoiceLineItemClient.setClientDOB(siliClientDetails.clientDOB);
    serviceInvoiceLineItemClient.setClientFirstName(
      siliClientDetails.clientFirstName);
    serviceInvoiceLineItemClient.setClientLastName(
      siliClientDetails.clientLastName);
    serviceInvoiceLineItemClient.setClientReferenceNo(
      siliClientDetails.clientReferenceNo);
    serviceInvoiceLineItemClient.setServiceInvoiceLineItem(
      serviceInvoiceLineItem);
    serviceInvoiceLineItemClient.insert();

  }

  /**
   * {@inheritDoc}
   */
  public SILIClientDetailsList listClientDetailsForServiceInvoiceLineItem(
    ServiceInvoiceLineItemKey serviceInvoiceLineItemKey) throws AppException,
      InformationalException {

    SILIClientDetailsList siliClientDetailsList = new SILIClientDetailsList();
    ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      serviceInvoiceLineItemKey.serviceInvoiceLineItemID);

    Set<ServiceInvoiceLineItemClient> serviceInvoiceLineItemClients = serviceInvoiceLineItem.getServiceInvoiceLineItemClients();

    for (ServiceInvoiceLineItemClient serviceInvoiceLineItemClient : serviceInvoiceLineItemClients) {

      SILIClientDetails siliClientDetails = new SILIClientDetails();

      siliClientDetails.clientDOB = serviceInvoiceLineItemClient.getClientDOB();
      siliClientDetails.clientFirstName = serviceInvoiceLineItemClient.getClientFirstName();
      siliClientDetails.clientLastName = serviceInvoiceLineItemClient.getClientLastName();
      siliClientDetails.clientReferenceNo = serviceInvoiceLineItemClient.getClientReferenceNo();

      if (null != serviceInvoiceLineItemClient.getID()) {
        siliClientDetails.siliClientID = serviceInvoiceLineItemClient.getID();
      }

      siliClientDetails.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
      // BEGIN, CR00200393, SSK
      if (null
        != serviceInvoiceLineItemClient.getServiceInvoiceLineItemCorrection()) {
        if (ServiceInvoiceLineItemCorrectionStatusEntry.APPROVED.getCode().equals(
          serviceInvoiceLineItemClient.getServiceInvoiceLineItemCorrection().getStatus().getCode())) {

          siliClientDetailsList.clientDetails.addRef(siliClientDetails);
        }
      } else {

        siliClientDetailsList.clientDetails.addRef(siliClientDetails);
      }
      // END, CR00200393
    }

    if (siliClientDetailsList.clientDetails.size() > 1) {
      siliClientDetailsList.multipleClientInd = true;
    }
    return siliClientDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public void removeClientFromServiceInvoiceLineItem(
    SILIAndClientKey siliAndClientKey) throws AppException,
      InformationalException {

    if (0 != siliAndClientKey.siliClientID) {

      ServiceInvoiceLineItemClient serviceInvoiceLineItemClient = serviceInvoiceLineItemClientDAO.get(
        siliAndClientKey.siliClientID);

      serviceInvoiceLineItemClient.remove();
    } else {

      ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
        siliAndClientKey.serviceInvoiceLineItemID);

      if (0
        == serviceInvoiceLineItemClientDAO.searchByServiceInvoiceLineItem(serviceInvoiceLineItem).size()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICELINEITEM_XRV_THIS_SERVICE_INVOICE_LINE_ITEM_MUST_HAVE_ATLEAST_ONE_CLIENT(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }

      serviceInvoiceLineItem.setClientReferenceNumber(CuramConst.gkEmpty);
      serviceInvoiceLineItem.setClientFirstName(CuramConst.gkEmpty);
      serviceInvoiceLineItem.setClientLastName(CuramConst.gkEmpty);
      serviceInvoiceLineItem.setClientDateOfBirth(Date.kZeroDate);
      serviceInvoiceLineItem.setClientID(0l);
      serviceInvoiceLineItem.modify(serviceInvoiceLineItem.getVersionNo());
    }

  }

  /**
   * Lists all the clients for a service invoice line item.
   *
   * @param siliHistoryKey
   * Contains service invoice line item history id.
   *
   * @return List of all the clients for a given service invoice line item
   * history id.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public SILIClientDetailsList listClientsForServiceInvoiceLineItemHistory(
    SILIHistoryKey siliHistoryKey) throws AppException,
      InformationalException {

    SILIClientDetailsList siliClientDetailsList = new SILIClientDetailsList();
    curam.financial.impl.ServiceInvoiceLineItemHistory serviceInvoiceLineItemHistory = serviceInvoiceLineItemHistoryDAO.get(
      siliHistoryKey.siliHistoryID);

    Set<SILIClientHistory> siliClientHistories = siliClientHistoryDAO.searchByServiceInvoiceLineItemHistory(
      serviceInvoiceLineItemHistory);

    for (SILIClientHistory siliClientHistory : siliClientHistories) {

      SILIClientDetails siliClientDetails = new SILIClientDetails();

      siliClientDetails.clientDOB = siliClientHistory.getClientDOB();
      siliClientDetails.clientFirstName = siliClientHistory.getClientFirstName();
      siliClientDetails.clientLastName = siliClientHistory.getClientLastName();
      siliClientDetails.clientReferenceNo = siliClientHistory.getClientReferenceNo();

      siliClientDetailsList.clientDetails.addRef(siliClientDetails);
    }

    SILIClientDetails siliClientDetails = new SILIClientDetails();

    if (!serviceInvoiceLineItemHistory.getClientDateOfBirth().isZero()) {
      siliClientDetails.clientDOB = serviceInvoiceLineItemHistory.getClientDateOfBirth();
    }

    if (null != serviceInvoiceLineItemHistory.getClientFirstName()
      && !CuramConst.gkEmpty.equals(
        serviceInvoiceLineItemHistory.getClientFirstName())) {
      siliClientDetails.clientFirstName = serviceInvoiceLineItemHistory.getClientFirstName();
    }

    if (null != serviceInvoiceLineItemHistory.getClientLastName()
      && !CuramConst.gkEmpty.equals(
        serviceInvoiceLineItemHistory.getClientLastName())) {
      siliClientDetails.clientLastName = serviceInvoiceLineItemHistory.getClientLastName();
    }

    if (null != serviceInvoiceLineItemHistory.getClientReferenceNumber()
      && !CuramConst.gkEmpty.equals(
        serviceInvoiceLineItemHistory.getClientReferenceNumber())) {
      siliClientDetails.clientReferenceNo = serviceInvoiceLineItemHistory.getClientReferenceNumber();
    }

    if (!siliClientDetails.clientDOB.isZero()
      || !CuramConst.gkEmpty.equals(siliClientDetails.clientFirstName)
      || !CuramConst.gkEmpty.equals(siliClientDetails.clientLastName)
      || !CuramConst.gkEmpty.equals(siliClientDetails.clientReferenceNo)) {

      siliClientDetailsList.clientDetails.addRef(siliClientDetails);
    }

    if (siliClientDetailsList.clientDetails.size() > 1) {
      siliClientDetailsList.multipleClientInd = true;
    }

    return siliClientDetailsList;
  }

  // BEGIN, CR00306731, ASN
  // BEGIN, CR00314240, SS
  /**
   * Updates the Service Invoice Line Item with the service invoice line item
   * details passed.For line items with exception task generated, closes the
   * tasks and remove the exception indicator if the line item is updated with
   * valid information.
   *
   * @param updateSILIDetails
   * Contains service invoice line item details to be updated.
   *
   * @throws InformationalException
   * {@link SERVICEINVOICELINEITEM#ERR_SERVICEINVOICELINEITEM_XRV_THIS_SERVICE_INVOICE_LINE_ITEM_IS_NOT_OPEN_IT_CANNOT_BE_MODIFIED}
   * If the Service Invoice Line Item is not in 'Open' status.
   * @throws InformationalException
   * {@link SERVICEINVOICELINEITEMExceptionCreator#ERR_SERVICEINVOICE_XFV_EITHER_CLIENT_REFNO_OR_OTHER_DTLS_MUST_BE_SPECIFIED}
   * If either of client reference number or other details is not
   * entered.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00306731
  // END, CR00314240
  public void updateSILI(UpdateSILIDetails updateSILIDetails)
    throws AppException, InformationalException {

    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      updateSILIDetails.details.serviceInvoiceLineItemID);

    if (ServiceInvoiceLineItemStatusEntry.OPEN.equals(
      serviceInvoiceLineItem.getStatus())) {

      setServiceInvoiceLineItemFields(serviceInvoiceLineItem,
        updateSILIDetails.details);

      try {

        SILIClientDetailsList clientDetailsList = WidgetHelper.convertXmlToServiceInvoiceLineItemClientDetailsList(
          updateSILIDetails.clientDetails);

        // BEGIN, CR00314240, SS
        for (final SILIClientDetails siliClientDetails : clientDetailsList.clientDetails.items()) {

          if (0 == siliClientDetails.siliClientID) {

            serviceInvoiceLineItem.setClientReferenceNumber(
              siliClientDetails.clientReferenceNo);
            serviceInvoiceLineItem.setClientFirstName(
              siliClientDetails.clientFirstName);
            serviceInvoiceLineItem.setClientLastName(
              siliClientDetails.clientLastName);
            serviceInvoiceLineItem.setClientDateOfBirth(
              siliClientDetails.clientDOB);
           
            if (GeneralConstants.kEmpty.equals(
              siliClientDetails.clientReferenceNo)
                && (GeneralConstants.kEmpty.equals(
                  siliClientDetails.clientFirstName)
                    || GeneralConstants.kEmpty.equals(
                      siliClientDetails.clientLastName)
                      || siliClientDetails.clientDOB.isZero())) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICE_XFV_EITHER_CLIENT_REFNO_OR_OTHER_DTLS_MUST_BE_SPECIFIED(),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                1);
              ValidationHelper.failIfErrorsExist();
            }
            // END, CR00314240

          } else {

            ServiceInvoiceLineItemClient serviceInvoiceLineItemClient = serviceInvoiceLineItemClientDAO.get(
              siliClientDetails.siliClientID);

            serviceInvoiceLineItemClient.setClientDOB(
              siliClientDetails.clientDOB);
            serviceInvoiceLineItemClient.setClientFirstName(
              siliClientDetails.clientFirstName);
            serviceInvoiceLineItemClient.setClientLastName(
              siliClientDetails.clientLastName);
            serviceInvoiceLineItemClient.setClientReferenceNo(
              siliClientDetails.clientReferenceNo);
            serviceInvoiceLineItemClient.modify(
              serviceInvoiceLineItemClient.getVersionNo());
          }
        }
      } catch (AppException appException) {

        ValidationHelper.addValidationError(appException);
        ValidationHelper.failIfErrorsExist();
      }

      serviceInvoiceLineItem.modify(updateSILIDetails.details.versionNo);
      
      // BEGIN, CR00306731, ASN
      if (true == serviceInvoiceLineItem.isInExceptionProcessing()) {
        String mismatchReason = serviceInvoiceLineItem.matchIdentifiers(false);

        if (mismatchReason.isEmpty()) {

          final Event event = new Event();

          event.eventKey = PROVIDERMANAGEMENT.SILIPROCESSED;
          event.primaryEventData = serviceInvoiceLineItem.getID();

          EventService.raiseEvent(event);

          serviceInvoiceLineItem.setExceptionProcessingInd(false);

          serviceInvoiceLineItem.modify(serviceInvoiceLineItem.getVersionNo());
        }

      }
      // END, CR00306731

    } else {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICELINEITEM_XRV_THIS_SERVICE_INVOICE_LINE_ITEM_IS_NOT_OPEN_IT_CANNOT_BE_MODIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();

  }

  /**
   * Reads the Service Invoice Line Item details for the service invoice line
   * item key passed.
   *
   * @param serviceInvoiceLineItemKey
   * Contains service invoice line item ID.
   *
   * @return The service invoice line item details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public SILIDetails viewSILI(
    ServiceInvoiceLineItemKey serviceInvoiceLineItemKey) throws AppException,
      InformationalException {

    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      serviceInvoiceLineItemKey.serviceInvoiceLineItemID);

    SILIDetails serviceInvoiceLineItemDetails = new SILIDetails();

    serviceInvoiceLineItemDetails.details.assign(
      getServiceInvoiceLineItemFields(serviceInvoiceLineItem));

    if (serviceInvoiceLineItemDetails.details.saReferenceNo == null
      || serviceInvoiceLineItemDetails.details.saReferenceNo.length() == 0) {
      serviceInvoiceLineItemDetails.derivedSA = true;
    } else {
      serviceInvoiceLineItemDetails.derivedSA = false;
    }

    serviceInvoiceLineItemDetails.details.expProInd = serviceInvoiceLineItem.isInExceptionProcessing();

    final ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceInvoiceLineItem.getServiceAuthorizationLineItem();

    boolean frcExist = false;

    try {
      frcExist = serviceInvoiceLineItem.matchAgainstFlatRateContract();
    } catch (Exception e) {// Suppress the exceptions
    }

    if (!serviceInvoiceLineItemDetails.details.status.equals(
      ServiceInvoiceLineItemStatusEntry.OPEN.toString())) {
      if (!frcExist) {
        if (serviceAuthorizationLineItem != null) {

          serviceInvoiceLineItemDetails.serviceAuthorizationID = serviceAuthorizationLineItem.getServiceAuthorization().getID();
        } else if (serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber()
          != null
            && !serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber().equals(
              GeneralConstants.kEmpty)) {
          curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.findByReferenceNumber(
            serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber());

          if (serviceAuthorization != null) {
            serviceInvoiceLineItemDetails.serviceAuthorizationID = serviceAuthorization.getID();
          }
        }
      }
    }

    ServiceDetails serviceDetails = new ServiceDetails();

    serviceDetails = getServiceDetails(
      serviceInvoiceLineItem.getServiceOffering());

    Double amountPaid = new Double(0);

    // Populate the calculated amount to amountPaid when
    // status of the service invoice line item is not CANCELED/DENIED
    if (!serviceInvoiceLineItemDetails.details.status.equals(
      ServiceInvoiceLineItemStatus.CANCELED)
        && !serviceInvoiceLineItemDetails.details.status.equals(
          ServiceInvoiceLineItemStatus.DENIED)) {

      for (ServiceInvoiceLineItemTransaction sILITransaction : serviceInvoiceLineItem.getTransactions()) {
        if (sILITransaction.getTransactionType().equals(
          ServiceInvoiceLineItemTransactionTypeEntry.PAID)
            && sILITransaction.getStatus().equals(
              ServiceInvoiceLineItemTransactionStatusEntry.ACTIVE)) {
          amountPaid += sILITransaction.getAmount().getValue();
        }
      }

    }

    if (serviceInvoiceLineItemDetails.details.status.equals(
      ServiceInvoiceLineItemStatusEntry.OPEN.toString())
        && serviceInvoiceLineItem.getServiceAuthorizationReferenceNumber().length()
          == 0) {
      curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = null;

      try {
        serviceAuthorization = serviceInvoiceLineItem.retrieveServiceAuthorization();
      } catch (AppException ap) {// suppress exception if occurred
      }
      if (serviceAuthorization != null && !frcExist) {
        serviceInvoiceLineItemDetails.details.saReferenceNo = serviceAuthorization.getReferenceNumber();
      }
    }

    serviceInvoiceLineItemDetails.dtls.amountPaid = new Money(amountPaid);

    serviceInvoiceLineItemDetails.dtls.service = serviceDetails.service;
    serviceInvoiceLineItemDetails.desc = getServiceInvoiceLineItemContextDescription(
      serviceInvoiceLineItemKey);

    if (serviceInvoiceLineItem.isInExceptionProcessing()) {
      serviceInvoiceLineItemDetails.exceptionTaskCreated = SERVICEINVOICELINEITEM.INF_SERVICEINVOICELINEITEM_EXCEPTIONTASKCREATED_YES.getMessageText(
        TransactionInfo.getProgramLocale());
    } else {
      serviceInvoiceLineItemDetails.exceptionTaskCreated = SERVICEINVOICELINEITEM.INF_SERVICEINVOICELINEITEM_EXCEPTIONTASKCREATED_NO.getMessageText(
        TransactionInfo.getProgramLocale());
    }

    if (ServiceInvoiceLineItemStatus.PENDINGAPPROVAL.equals(
      serviceInvoiceLineItemDetails.details.status)) {
      serviceInvoiceLineItemDetails.deleteSILIInd = false;
    } else {
      serviceInvoiceLineItemDetails.deleteSILIInd = true;
    }

    if (serviceInvoiceLineItemDetails.serviceAuthorizationID != 0
      && (serviceInvoiceLineItemDetails.details.saReferenceNo != null
        && !(GeneralConstants.kEmpty.equals(
          serviceInvoiceLineItemDetails.details.saReferenceNo)))) {
      serviceInvoiceLineItemDetails.flag = true;
    }

    serviceInvoiceLineItemDetails.excprocInd = serviceInvoiceLineItem.isInExceptionProcessing();

    // Determine whether the exception task is created during submission of
    // approval
    if (serviceInvoiceLineItemDetails.excprocInd == true
      && serviceInvoiceLineItem.getStatus().equals(
        ServiceInvoiceLineItemStatusEntry.PENDINGAPPROVAL)) {

      serviceInvoiceLineItemDetails.approvalExceptionTaskInd = true;
    }

    // Set allowDuplicateSILI flag if service invoice line item is a duplicate
    serviceInvoiceLineItem.matchIdentifiers(false);
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    InformationalException exception = informationalManager.obtainInformationalAsException();

    if (exception != null) {
      serviceInvoiceLineItemDetails.details.allowDuplicateSILI = ValidationHelper.informationalContains(
        exception,
        SERVICEINVOICELINEITEM.ERR_SERVICEINVOICELINEITEM_XRV_DUPLICATE_SERVICE_INVOICE_LINE_ITEM);
    }

    serviceInvoiceLineItemDetails.clientName = serviceInvoiceLineItemDetails.details.clientFirstName
      + GeneralConstants.kSpace
      + serviceInvoiceLineItemDetails.details.clientLastName;

    SILIClientDetailsList siliClientDetailsList = listClientDetailsForServiceInvoiceLineItem(
      serviceInvoiceLineItemKey);

    serviceInvoiceLineItemDetails.clientDetails = WidgetHelper.convertServiceInvoiceLineItemClientDetailsToXml(
      siliClientDetailsList);

    return serviceInvoiceLineItemDetails;
  }

  /**
   * Creates a Service Invoice Line Item using the details of an existing
   * service invoice line item.
   *
   * @param siliDetails
   * Contains service invoice line item details to be inserted.
   *
   * @return Service invoice line item ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceInvoiceLineItemKey createNewSILI(SILIDetails siliDetails)
    throws AppException, InformationalException {

    curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
      siliDetails.details.serviceInvoiceID);

    SILIClientDetailsList clientDetailsList = WidgetHelper.convertXmlToServiceInvoiceLineItemClientDetailsList(
      siliDetails.clientDetails);

    for (SILIClientDetails siliClientDetails : clientDetailsList.clientDetails.items()) {

      if (0 == siliClientDetails.siliClientID) {
        siliDetails.details.clientDOB = siliClientDetails.clientDOB;
        siliDetails.details.clientFirstName = siliClientDetails.clientFirstName;
        siliDetails.details.clientLastName = siliClientDetails.clientLastName;
        siliDetails.details.clientReferenceNo = siliClientDetails.clientReferenceNo;
      }
    }

    final ServiceInvoiceLineItemKey serviceInvoiceLineItemKey = serviceInvoice.addLineItem(
      siliDetails.details);

    ServiceInvoiceLineItem newServiceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      serviceInvoiceLineItemKey.serviceInvoiceLineItemID);

    for (SILIClientDetails siliClientDetails : clientDetailsList.clientDetails.items()) {

      if (0 != siliClientDetails.siliClientID) {

        ServiceInvoiceLineItemClient newServiceInvoiceLineItemClient = serviceInvoiceLineItemClientDAO.newInstance();

        newServiceInvoiceLineItemClient.setClientDOB(
          siliClientDetails.clientDOB);
        newServiceInvoiceLineItemClient.setClientFirstName(
          siliClientDetails.clientFirstName);
        newServiceInvoiceLineItemClient.setClientLastName(
          siliClientDetails.clientLastName);
        newServiceInvoiceLineItemClient.setClientReferenceNo(
          siliClientDetails.clientReferenceNo);
        newServiceInvoiceLineItemClient.setServiceInvoiceLineItem(
          newServiceInvoiceLineItem);
        newServiceInvoiceLineItemClient.insert();
      }
    }

    return serviceInvoiceLineItemKey;
  }

  /**
   * Sorts the list of service invoice line item clients by client name.
   *
   * @param unsortedServiceInvoiceLineItemClients
   * Unsorted set of service invoice line item clients.
   * @return Sorted list of service invoice line item clients.
   */
  protected List<ServiceInvoiceLineItemClient> sortSILIClientByClientName(
    Set<ServiceInvoiceLineItemClient> unsortedServiceInvoiceLineItemClients) {

    final List<ServiceInvoiceLineItemClient> serviceInvoiceLineItemClientList = new ArrayList<ServiceInvoiceLineItemClient>(
      unsortedServiceInvoiceLineItemClients);

    Collections.sort(serviceInvoiceLineItemClientList,
      new Comparator<ServiceInvoiceLineItemClient>() {
      public int compare(final ServiceInvoiceLineItemClient lhs,
        ServiceInvoiceLineItemClient rhs) {
        return (lhs.getClientFirstName() + CPMConstants.kSpace + lhs.getClientLastName()).compareTo(
          rhs.getClientFirstName() + CPMConstants.kSpace
          + rhs.getClientLastName());
      }
    });

    return serviceInvoiceLineItemClientList;
  }

  // END, CR00158345

  // BEGIN, CR00200393, SSK
  /**
   * {@inheritDoc}
   */
  public SILIDetailsList listAllServiceInvoiceLineItems(
    final ServiceInvoiceKey serviceInvoiceKey) throws AppException,
      InformationalException {

    SILIDetailsList siliDetailsList = new SILIDetailsList();

    if (serviceInvoiceKey.serviceInvoiceID != 0) {

      curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.get(
        serviceInvoiceKey.serviceInvoiceID);
      Set<ServiceInvoiceLineItem> serviceInvoiceLineItems = serviceInvoiceLineItemDAO.listServiceInvoiceLineItems(
        serviceInvoice);
      List<ServiceInvoiceLineItem> serviceInvoiceLineItemList = sortSILIByClientName(
        serviceInvoiceLineItems);
      // BEGIN, CR00205836, SSK
      List<SILIDetail> openServiceInvoiceLineItemList = new ArrayList<SILIDetail>();
      List<SILIDetail> pendingApprovalServiceInvoiceLineItemList = new ArrayList<SILIDetail>();
      List<SILIDetail> completeServiceInvoiceLineItemList = new ArrayList<SILIDetail>();
      List<SILIDetail> cancelServiceInvoiceLineItemList = new ArrayList<SILIDetail>();
      List<SILIDetail> deniedServiceInvoiceLineItemList = new ArrayList<SILIDetail>();

      // END, CR00205836
      for (ServiceInvoiceLineItem serviceInvoiceLineItem : serviceInvoiceLineItemList) {

        SILIDetail siliDetail = new SILIDetail();

        siliDetail.siliDetails.assign(
          getServiceInvoiceLineItemFields(serviceInvoiceLineItem));
        siliDetail.SILIIDVersionNo = serviceInvoiceLineItem.getID()
          + GeneralConstants.kUnderScoreString
          + serviceInvoiceLineItem.getVersionNo();
        siliDetail.versionNo = serviceInvoiceLineItem.getVersionNo();
        siliDetail.siliReferenceNo = serviceInvoiceLineItem.getReferenceNumber();
        // BEGIN, CR00205836, SSK
        siliDetail.status = serviceInvoiceLineItem.getStatus().toUserLocaleString();
        // END, CR00205836
        if (ServiceInvoiceLineItemStatusEntry.COMPLETE.getCode().equals(
          serviceInvoiceLineItem.getStatus().getCode())) {
          siliDetail.siliCompletedInd = true;
          siliDetail.siliCorrectionID = checkIfCorrectionExitsForSILI(
            serviceInvoiceLineItem);
          if (0 != siliDetail.siliCorrectionID) {
            ServiceInvoiceLineItemCorrection serviceInvoiceLineItemCorrection = siliCorrectionDAO.get(
              siliDetail.siliCorrectionID);

            siliDetail.siliReferenceNo = serviceInvoiceLineItemCorrection.getCorrection().getReferenceNumber();
            siliDetail.versionNo = serviceInvoiceLineItemCorrection.getCorrection().getVersionNo();
            siliDetail.hasCorrection = true;
            // BEGIN, CR00236073, SSK
            siliDetail.siliDetails.serviceDateFrom = serviceInvoiceLineItemCorrection.getServiceDateFrom();
            siliDetail.siliDetails.serviceDateTo = serviceInvoiceLineItemCorrection.getServiceDateTo();
            siliDetail.siliDetails.amountInvoiced = serviceInvoiceLineItemCorrection.getAmountInvoiced();
            // END, CR00236073

            siliDetail.status = serviceInvoiceLineItemCorrection.getCorrection().getStatus().toUserLocaleString();
            if (ServiceInvoiceLineItemCorrectionStatusEntry.OPEN.getCode().equals(
              serviceInvoiceLineItemCorrection.getCorrection().getStatus().getCode())) {
              siliDetail.siliOpenCorrectionInd = true;
            } else if (ServiceInvoiceLineItemCorrectionStatusEntry.PENDINGAPPROVAL.getCode().equals(
              serviceInvoiceLineItemCorrection.getCorrection().getStatus().getCode())) {
              siliDetail.siliInPendingApprovalCorrection = true;
            }
          }
        } else if (ServiceInvoiceLineItemStatusEntry.OPEN.getCode().equals(
          serviceInvoiceLineItem.getStatus().getCode())) {
          siliDetail.siliOpenInd = true;
        } else if (ServiceInvoiceLineItemStatusEntry.PENDINGAPPROVAL.getCode().equals(
          serviceInvoiceLineItem.getStatus().getCode())) {
          siliDetail.siliInPendingApprovalInd = true;
        }

        List<ServiceInvoiceLineItemClient> serviceInvoiceLineItemClients = sortSILIClientByClientName(
          serviceInvoiceLineItem.getServiceInvoiceLineItemClients());
        ServiceInvoiceLineItemClient serviceInvoiceLineItemClient = serviceInvoiceLineItemClients.iterator().next();

        if (!GeneralConstants.kEmpty.equals(
          serviceInvoiceLineItemClient.getClientFirstName())) {
          siliDetail.clientName = serviceInvoiceLineItemClient.getClientFirstName();
        }
        if (!GeneralConstants.kEmpty.equals(
          serviceInvoiceLineItemClient.getClientLastName())) {
          siliDetail.clientName = siliDetail.clientName + CuramConst.gkSpace
            + serviceInvoiceLineItemClient.getClientLastName();
        }
        Double amountPaid = serviceInvoiceLineItem.retrieveSILIAmountPaid();

        siliDetail.amountPaid = new Money(amountPaid);
        siliDetail.serviceDetails = getServiceDetails(
          serviceInvoiceLineItem.getServiceOffering());
        siliDetail.excprocInd = serviceInvoiceLineItem.isInExceptionProcessing();
        if ((siliDetail.siliOpenInd || siliDetail.siliOpenCorrectionInd)
          || (siliDetail.siliCompletedInd
            && !siliDetail.siliInPendingApprovalCorrection)
              && !siliDetail.excprocInd) {
          siliDetail.siliEditableInd = true;
        }
        // BEGIN, CR00205836, SSK
        if (ServiceInvoiceLineItemStatusEntry.COMPLETE.equals(
          serviceInvoiceLineItem.getStatus())) {
          completeServiceInvoiceLineItemList.add(siliDetail);
        } else if (ServiceInvoiceLineItemStatusEntry.OPEN.equals(
          serviceInvoiceLineItem.getStatus())) {
          openServiceInvoiceLineItemList.add(siliDetail);
        } else if (ServiceInvoiceLineItemStatusEntry.DENIED.equals(
          serviceInvoiceLineItem.getStatus())) {
          deniedServiceInvoiceLineItemList.add(siliDetail);
        } else if (ServiceInvoiceLineItemStatusEntry.CANCELED.equals(
          serviceInvoiceLineItem.getStatus())) {
          cancelServiceInvoiceLineItemList.add(siliDetail);
        } else if (ServiceInvoiceLineItemStatusEntry.PENDINGAPPROVAL.equals(
          serviceInvoiceLineItem.getStatus())) {
          siliDetail.siliInPendingApprovalInd = true;
          pendingApprovalServiceInvoiceLineItemList.add(siliDetail);
        }
        // BEGIN, CR00247586, PS

        if (siliDetail.siliOpenInd || siliDetail.siliOpenCorrectionInd) {

          siliDetail.newClientInd = true;
          siliDetail.submitInd = true;
        }
        if (siliDetail.siliInPendingApprovalInd
          || siliDetail.siliInPendingApprovalCorrection) {

          siliDetail.approveInd = true;
        }
        if (siliDetail.siliInPendingApprovalInd) {

          siliDetail.approveActionURL = CPMConstants.kApproveServiceInvoiceLineItemPendingApproval;
        } else if (siliDetail.siliInPendingApprovalCorrection) {

          siliDetail.approveActionURL = CPMConstants.kApproveServiceInvoiceLineItemPendingApprovalCorrection;
          siliDetail.restoreActionURL = CPMConstants.kRestoreOriginalDataForSILIPendingApprovalCorrection;
        } else if (siliDetail.siliOpenCorrectionInd) {

          siliDetail.restoreActionURL = CPMConstants.kRestoreOriginalDataForOpenSILICorrection;
          siliDetail.newClientActionURL = CPMConstants.kNewClientForOpenSILICorrection;
          siliDetail.submitActionURL = CPMConstants.kSubmitOpenSILICorrection;
        } else {
          if (siliDetail.siliOpenInd) {

            siliDetail.newClientActionURL = CPMConstants.kNewClientForOpenSILI;
            siliDetail.submitActionURL = CPMConstants.kSubmitOpenSILI;
          }
        }
        // END, CR00247586
      }
      siliDetailsList.details.addAll(openServiceInvoiceLineItemList);
      siliDetailsList.details.addAll(pendingApprovalServiceInvoiceLineItemList);
      siliDetailsList.details.addAll(completeServiceInvoiceLineItemList);
      siliDetailsList.details.addAll(deniedServiceInvoiceLineItemList);
      siliDetailsList.details.addAll(cancelServiceInvoiceLineItemList);
      // END, CR00205836
    }
    siliDetailsList.desc = getServiceInvoiceContextDescription(
      serviceInvoiceKey);
    return siliDetailsList;
  }

  /**
   * Reads Service Invoice Line Item History for the service invoice line item.
   *
   * @param serviceInvoiceLineItemKey
   * Contains service invoice line item ID.
   * @return ServiceInvoiceLineItemHistoryList The list of service invoice line
   * item history.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public SILIAndCorrectionHistoryDetailsList viewSILIAndCorrectionHistory(
    final ServiceInvoiceLineItemKey serviceInvoiceLineItemKey)
    throws AppException, InformationalException {

    SILIAndCorrectionHistoryDetailsList siliAndCorrectionHistoryDetailsList = new SILIAndCorrectionHistoryDetailsList();

    ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      serviceInvoiceLineItemKey.serviceInvoiceLineItemID);

    Set<curam.financial.impl.ServiceInvoiceLineItemHistory> sILIHistories = sILIHistoryDAO.searchByServiceInvoiceLineItem(
      serviceInvoiceLineItem);

    for (final curam.financial.impl.ServiceInvoiceLineItemHistory sILIHistory : sILIHistories) {

      SILIAndCorrectionHistoryDetails siliAndCorrectionHistoryDetails = new SILIAndCorrectionHistoryDetails();

      siliAndCorrectionHistoryDetails.siliHistoryDetails.siliHistoryID = sILIHistory.getID();
      siliAndCorrectionHistoryDetails.siliHistoryDetails.dateTimeChanged = sILIHistory.getDateTimeChanged();
      siliAndCorrectionHistoryDetails.siliHistoryDetails.serviceDateFrom = sILIHistory.getServiceDateFrom();
      siliAndCorrectionHistoryDetails.siliHistoryDetails.serviceDateTo = sILIHistory.getServiceDateTo();
      siliAndCorrectionHistoryDetails.siliHistoryDetails.serviceID = sILIHistory.getServiceOffering().getID();

      if (null != sILIHistory.getServiceInvoiceLineItemCorrection()) {
        siliAndCorrectionHistoryDetails.status = sILIHistory.getCorrectionStatus().toUserLocaleString();

        siliAndCorrectionHistoryDetails.isCorrectionHistoryInd = true;
        siliAndCorrectionHistoryDetails.siliHistoryDetails.siliCorrectionID = sILIHistory.getServiceInvoiceLineItemCorrection().getID();
      } else {
        siliAndCorrectionHistoryDetails.siliHistoryDetails.status = sILIHistory.getStatus().getCode();
        siliAndCorrectionHistoryDetails.status = sILIHistory.getStatus().toUserLocaleString();
      }

      siliAndCorrectionHistoryDetails.serviceDetails = getServiceDetails(
        sILIHistory.getServiceOffering());
      siliAndCorrectionHistoryDetails.desc = getServiceInvoiceLineItemContextDescription(
        serviceInvoiceLineItemKey);
      siliAndCorrectionHistoryDetailsList.details.addRef(
        siliAndCorrectionHistoryDetails);

    }

    Set<ServiceInvoiceLineItemCorrection> siliCorrections = siliCorrectionDAO.listSILICorrections(
      serviceInvoiceLineItem);

    for (ServiceInvoiceLineItemCorrection siliCorrection : siliCorrections) {

      Set<ServiceInvoiceLineItemCorrectionHistory> siliCorrectionHistList = siliCorrectionHistoryDAO.getHistoryForSILICorrection(
        siliCorrection);

      for (final ServiceInvoiceLineItemCorrectionHistory siliCorrectionHistory : siliCorrectionHistList) {
        SILIAndCorrectionHistoryDetails siliAndCorrectionHistoryDetails = new SILIAndCorrectionHistoryDetails();

        siliAndCorrectionHistoryDetails.siliHistoryDetails.dateTimeChanged = siliCorrectionHistory.getDateTime();
        siliAndCorrectionHistoryDetails.status = siliCorrectionHistory.getStatus().toUserLocaleString();
        siliAndCorrectionHistoryDetailsList.details.addRef(
          siliAndCorrectionHistoryDetails);
      }
    }

    SILIAndCorrectionHistoryDetailsList sortedSILIAndCorrectionHistoryDetailsList = filterSILIHistoryRecords(
      siliAndCorrectionHistoryDetailsList);

    return sortedSILIAndCorrectionHistoryDetailsList;
  }

  /**
   * Reads Service Invoice Line Item and correction details from the history.
   *
   * @param sILIHistoryKey
   * Contains service invoice line item history ID.
   *
   * @return ServiceInvoiceLineItemDetails Contains service invoice line item
   * details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public SILIDetail viewSILIAndCorrectionModifications(
    final SILIHistoryKey sILIHistoryKey) throws AppException,
      InformationalException {

    SILIDetail siliDetail = new SILIDetail();
    curam.financial.impl.ServiceInvoiceLineItemHistory sILIHistory = sILIHistoryDAO.get(
      sILIHistoryKey.siliHistoryID);

    siliDetail.siliDetails.saReferenceNo = sILIHistory.getServiceAuthorizationReferenceNumber();
    siliDetail.siliDetails.serviceDateFrom = sILIHistory.getServiceDateFrom();
    siliDetail.siliDetails.serviceDateTo = sILIHistory.getServiceDateTo();
    siliDetail.siliDetails.noOfUnits = sILIHistory.getNumberOfUnits();
    siliDetail.siliDetails.amountInvoiced = sILIHistory.getAmountInvoiced();
    siliDetail.siliDetails.caseReferenceNo = sILIHistory.getCaseReferenceNumber();

    if (null != sILIHistory.getServiceInvoiceLineItemCorrection()) {

      siliDetail.status = sILIHistory.getCorrectionStatus().toUserLocaleString();
      siliDetail.hasCorrection = true;
      siliDetail.siliCorrectionID = sILIHistory.getServiceInvoiceLineItemCorrection().getID();
    } else {

      siliDetail.status = sILIHistory.getStatus().toUserLocaleString();
      siliDetail.siliDetails.status = sILIHistory.getStatus().toString();
    }
    ServiceDetails serviceDetails = new ServiceDetails();

    serviceDetails = getServiceDetails(sILIHistory.getServiceOffering());

    siliDetail.serviceDetails.service = serviceDetails.service;
    siliDetail.siliDetails.unitAmount = sILIHistory.getUnitAmount();

    siliDetail.siliDetails.payeeReferenceNo = sILIHistory.getPayeeReferenceNumber();
    siliDetail.siliDetails.payeeName = sILIHistory.getPayeeName();

    siliDetail.siliDetails.providerReferenceNo = sILIHistory.getProviderReferenceNumber();
    siliDetail.siliDetails.providerName = sILIHistory.getProviderName();

    siliDetail.siliDetails.clientReferenceNo = sILIHistory.getClientReferenceNumber();
    siliDetail.siliDetails.clientFirstName = sILIHistory.getClientFirstName();
    siliDetail.siliDetails.clientLastName = sILIHistory.getClientLastName();
    siliDetail.siliDetails.clientDOB = sILIHistory.getClientDateOfBirth();

    ServiceInvoiceLineItemKey silikey = new ServiceInvoiceLineItemKey();

    silikey.serviceInvoiceLineItemID = sILIHistory.getServiceInvoiceLineItem().getID();

    siliDetail.desc = getServiceInvoiceLineItemContextDescription(silikey);

    return siliDetail;
  }

  /**
   * Sorts a set of contract performance measure records into a sorted list by
   * measure name for display.
   *
   * @param unSortedContractPerformanceMeasureLinks
   * The set of contract performance measure.
   *
   * @return Sorted list of contract performance measure records for display.
   */
  protected List<SILIAndCorrectionHistoryDetails> sortServiceInvoiceLineItemHistory(
    final SILIAndCorrectionHistoryDetailsList siliAndCorrectionHistoryDetailsList) {
    List<SILIAndCorrectionHistoryDetails> unsortedSILIAndCorrectionHistoryDetails = Arrays.asList(
      siliAndCorrectionHistoryDetailsList.details.items());

    Collections.sort(unsortedSILIAndCorrectionHistoryDetails,
      new Comparator<SILIAndCorrectionHistoryDetails>() {
      public int compare(final SILIAndCorrectionHistoryDetails lhs,
        final SILIAndCorrectionHistoryDetails rhs) {

        return lhs.siliHistoryDetails.dateTimeChanged.compareTo(
          rhs.siliHistoryDetails.dateTimeChanged);

      }
    });
    return unsortedSILIAndCorrectionHistoryDetails;
  }

  /**
   * Checks if the correction is denied.
   *
   * @param siliAndCorrectionHistoryDetails
   * Service invoice line item and correction history details.
   *
   * @return True if correction is denied otherwise false.
   */
  protected boolean isCorrectionDenied(
    final SILIAndCorrectionHistoryDetails siliAndCorrectionHistoryDetails) {
    ServiceInvoiceLineItemCorrection serviceInvoiceLineItemCorrection = siliCorrectionDAO.get(
      siliAndCorrectionHistoryDetails.siliHistoryDetails.siliCorrectionID);

    if (0
      != siliAndCorrectionHistoryDetails.siliHistoryDetails.siliCorrectionID
        && ServiceInvoiceLineItemCorrectionStatusEntry.DENIED.getCode().equals(
          serviceInvoiceLineItemCorrection.getStatus().getCode())) {
      return true;
    }
    return false;
  }

  // BEGIN, CR00205836, SSK
  /**
   * Checks if the SILI correction is canceled.
   *
   * @param siliAndCorrectionHistoryDetails
   * Service invoice line item and correction history details.
   *
   * @return True if correction is canceled otherwise false.
   */
  protected boolean isCorrectionCanceled(
    final SILIAndCorrectionHistoryDetails siliAndCorrectionHistoryDetails) {
    ServiceInvoiceLineItemCorrection serviceInvoiceLineItemCorrection = siliCorrectionDAO.get(
      siliAndCorrectionHistoryDetails.siliHistoryDetails.siliCorrectionID);

    if (0
      != siliAndCorrectionHistoryDetails.siliHistoryDetails.siliCorrectionID
        && ServiceInvoiceLineItemCorrectionStatusEntry.CANCELED.equals(
          serviceInvoiceLineItemCorrection.getStatus())) {
      return true;
    }
    return false;
  }

  // END, CR00205836

  /**
   * Checks if the service invoice line item has correction in open or pending
   * approval.
   *
   * @param serviceInvoiceLineItem
   * Service invoice line item details.
   *
   * @return Service invoice line item correction Id.
   */
  protected long checkIfCorrectionExitsForSILI(
    final ServiceInvoiceLineItem serviceInvoiceLineItem) {
    Set<ServiceInvoiceLineItemCorrection> siliCorrections = siliCorrectionDAO.listSILICorrections(
      serviceInvoiceLineItem);

    for (ServiceInvoiceLineItemCorrection siliCorrection : siliCorrections) {
      if (ServiceInvoiceLineItemCorrectionStatusEntry.OPEN.getCode().equals(
        siliCorrection.getStatus().getCode())
          || ServiceInvoiceLineItemCorrectionStatusEntry.PENDINGAPPROVAL.getCode().equals(
            siliCorrection.getStatus().getCode())) {

        return siliCorrection.getID();
      }
    }
    return 0;
  }

  /**
   * Filters the service invoice line item history to display valid history
   * records.
   *
   * @param siliAndCorrectionHistoryDetailsList
   * Service invoice line item and correction history details list.
   *
   * @return Filtered list of Service invoice line item and correction history
   * details list.
   */
  protected SILIAndCorrectionHistoryDetailsList filterSILIHistoryRecords(
    final SILIAndCorrectionHistoryDetailsList siliAndCorrectionHistoryDetailsList) {

    SILIAndCorrectionHistoryDetailsList sortedSILIAndCorrectionHistoryDetailsList = new SILIAndCorrectionHistoryDetailsList();
    boolean inCompleteHistory = false;
    boolean openSiliHistoryIncluded = false;
    // BEGIN, CR00205836, SSK
    SILIAndCorrectionHistoryDetails siliAndCorrectionCompletedHistoryDetails = null;

    // END, CR00205836

    for (SILIAndCorrectionHistoryDetails siliAndCorrectionHistoryDetails : sortServiceInvoiceLineItemHistory(
      siliAndCorrectionHistoryDetailsList)) {
      if (!ServiceInvoiceLineItemStatusEntry.COMPLETE.toUserLocaleString().equals(
        siliAndCorrectionHistoryDetails.status)) {
        if (!inCompleteHistory) {
          if (ServiceInvoiceLineItemStatusEntry.OPEN.toUserLocaleString().equals(
            siliAndCorrectionHistoryDetails.status)) {
            if (!openSiliHistoryIncluded) {
              sortedSILIAndCorrectionHistoryDetailsList.details.addRef(
                siliAndCorrectionHistoryDetails);
              openSiliHistoryIncluded = true;
            }
          } else {
            sortedSILIAndCorrectionHistoryDetailsList.details.addRef(
              siliAndCorrectionHistoryDetails);
          }
        } else {
          if (siliAndCorrectionHistoryDetails.isCorrectionHistoryInd) {

            if (ServiceInvoiceLineItemCorrectionStatusEntry.OPEN.toUserLocaleString().equals(
              siliAndCorrectionHistoryDetails.status)) {
              if (!isCorrectionCanceled(siliAndCorrectionHistoryDetails)) {
                sortedSILIAndCorrectionHistoryDetailsList.details.addRef(
                  siliAndCorrectionHistoryDetails);
              }
            } else if (ServiceInvoiceLineItemCorrectionStatusEntry.PENDINGAPPROVAL.toUserLocaleString().equals(
              siliAndCorrectionHistoryDetails.status)) {
              if (isCorrectionDenied(siliAndCorrectionHistoryDetails)) {
                siliAndCorrectionHistoryDetails.isDeniedCorrectionInd = true;
              }
              sortedSILIAndCorrectionHistoryDetailsList.details.addRef(
                siliAndCorrectionHistoryDetails);
              // BEGIN, CR00205836, SSK
              if (siliAndCorrectionHistoryDetails.isDeniedCorrectionInd
                && null != siliAndCorrectionCompletedHistoryDetails) {
                siliAndCorrectionCompletedHistoryDetails.siliHistoryDetails.dateTimeChanged = siliAndCorrectionHistoryDetails.siliHistoryDetails.dateTimeChanged;
                // END, CR00205836
                sortedSILIAndCorrectionHistoryDetailsList.details.addRef(
                  siliAndCorrectionCompletedHistoryDetails);
              }
            }
          }
        }
      } else {
        inCompleteHistory = true;
        // BEGIN, CR00205836, SSK
        siliAndCorrectionCompletedHistoryDetails = siliAndCorrectionHistoryDetails;
        // END, CR00205836
        sortedSILIAndCorrectionHistoryDetailsList.details.addRef(
          siliAndCorrectionHistoryDetails);
      }
    }
    return sortedSILIAndCorrectionHistoryDetailsList;
  }

  // END, CR00200393

  // BEGIN, CR00206225, SSK
  /**
   * {@inheritDoc}
   */
  public SILIDetailsList listAllOpenServiceInvoiceLineItems(
    final ServiceInvoiceKey serviceInvoiceKey) throws AppException,
      InformationalException {

    SILIDetailsList openSILIDetailsList = new SILIDetailsList();
    SILIDetailsList sILIDetailsList = listAllServiceInvoiceLineItems(
      serviceInvoiceKey);
    ServiceInvoiceLineItem serviceInvoiceLineItem = null;

    for (final SILIDetail siliDetail : sILIDetailsList.details.items()) {
      serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
        siliDetail.siliDetails.serviceInvoiceLineItemID);
      // BEGIN, CR00206225, SSK
      siliDetail.status = serviceInvoiceLineItem.getStatus().toUserLocaleString();
      // END, CR00206225
     
      if (ServiceInvoiceLineItemStatusEntry.COMPLETE.equals(
        serviceInvoiceLineItem.getStatus())) {

        siliDetail.siliCompletedInd = true;
        siliDetail.siliCorrectionID = checkIfCorrectionExitsForSILI(
          serviceInvoiceLineItem);

        if (0 != siliDetail.siliCorrectionID) {

          ServiceInvoiceLineItemCorrection serviceInvoiceLineItemCorrection = siliCorrectionDAO.get(
            siliDetail.siliCorrectionID);

          siliDetail.status = serviceInvoiceLineItemCorrection.getCorrection().getStatus().toUserLocaleString();

          // BEGIN, CR00247586, PS
          if (ServiceInvoiceLineItemCorrectionStatusEntry.OPEN.equals(
            serviceInvoiceLineItemCorrection.getLifecycleState())) {
            openSILIDetailsList.details.addRef(siliDetail);
          }
          // END, CR00247586
        }
      } else {
        if (ServiceInvoiceLineItemStatusEntry.OPEN.equals(
          serviceInvoiceLineItem.getStatus())) {
          openSILIDetailsList.details.addRef(siliDetail);
        }
      }
      // BEGIN, CR00247586, PS
      if (siliDetail.siliOpenInd || siliDetail.siliOpenCorrectionInd) {

        siliDetail.newClientInd = true;
        siliDetail.submitInd = true;
      }
      if (siliDetail.siliOpenCorrectionInd) {

        siliDetail.restoreActionURL = CPMConstants.kRestoreOriginalDataForOpenLineItemCorrection;
        siliDetail.newClientActionURL = CPMConstants.kNewClientForOpenLineItemCorrection;
        siliDetail.submitActionURL = CPMConstants.kSubmitOpenLineItemCorrection;
      } else {
        if (siliDetail.siliOpenInd) {

          siliDetail.newClientActionURL = CPMConstants.kNewClientForOpenLineItem;
          siliDetail.submitActionURL = CPMConstants.kSubmitOpenLineItem;
        }
      }
      // END, CR00247586
    }
    openSILIDetailsList.desc = getServiceInvoiceContextDescription(
      serviceInvoiceKey);
    
    return openSILIDetailsList;

  }

  // END, CR00206225
  
  // BEGIN, CR00314240, SS
  /**
   * {@inheritDoc}
   */
  public SILItemCorrectionDetails retrieveSILICorrectionDetails(
    final curam.cpm.facade.struct.ServiceInvoiceLineItemKey key)
    throws AppException, InformationalException {
    final ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      key.key.serviceInvoiceLineItemID);
    final SILItemCorrectionDetails siliCorrectionDetails = new SILItemCorrectionDetails();

    siliCorrectionDetails.siliCorrectionID = checkIfCorrectionExitsForSILI(
      serviceInvoiceLineItem);
    if (0 != siliCorrectionDetails.siliCorrectionID) {
      siliCorrectionDetails.hasCorrection = true;
    }
    return siliCorrectionDetails;
  }
  // END, CR00314240
 
}
