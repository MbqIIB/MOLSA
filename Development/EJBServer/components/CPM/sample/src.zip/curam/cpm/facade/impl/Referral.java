/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;
import curam.attachmentlink.impl.AttachmentLink;
import curam.attachmentlink.impl.AttachmentLinkDAO;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.ListAttachmentLinkDetails;
import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.StackContainerBuilder;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.PHONETYPEEntry;
import curam.codetable.impl.PROVISIONMETHODEntry;
import curam.codetable.impl.PROXIMITYDISTANCEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.REFERRALNOTIFICATIONTYPEEntry;
import curam.codetable.impl.REFERRALPROVIDERTYPEEntry;
import curam.codetable.impl.REFERRALRELATEDLINKTYPEEntry;
import curam.codetable.impl.REFERRALRELATEDROLETYPEEntry;
import curam.codetable.impl.REPRESENTATIVETYPEEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.codetable.impl.SOSINGLEORMULTIPLECLIENTSEntry;
import curam.core.fact.ConcernRoleEmailAddressFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.EmailAddressFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRoleEmailAddress;
import curam.core.intf.EmailAddress;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleEmailAddressDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EmailAddressDtls;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.cpm.facade.struct.CancelReferralKey;
import curam.cpm.facade.struct.ContextPanelDetails;
import curam.cpm.facade.struct.ListProviderDetailsKey;
import curam.cpm.facade.struct.ListReferralsKey;
import curam.cpm.facade.struct.ListServicesByTermKey1;
import curam.cpm.facade.struct.NotificationDocumentDetails;
import curam.cpm.facade.struct.NotificationDocumentDetailsList;
import curam.cpm.facade.struct.NotificationDocumentKey;
import curam.cpm.facade.struct.ParticipantRoleDetails;
import curam.cpm.facade.struct.ParticipantRoleDetailsList;
import curam.cpm.facade.struct.ProviderDetailsForRemove;
import curam.cpm.facade.struct.ProviderReferralRoleDetails;
import curam.cpm.facade.struct.ReadDetailsForProviderSearchKey;
import curam.cpm.facade.struct.ReadDetailsForProviderSearchResult;
import curam.cpm.facade.struct.ReadReferralDetails;
import curam.cpm.facade.struct.ReferralDetails;
import curam.cpm.facade.struct.ReferralList;
import curam.cpm.facade.struct.ReferralListDetails;
import curam.cpm.facade.struct.ReferralNotificationData;
import curam.cpm.facade.struct.ServiceOfferingDetailsList;
import curam.cpm.facade.struct.ServiceOfferingSummaryDetails;
import curam.cpm.facade.struct.ServiceReferralRoleDetails;
import curam.cpm.facade.struct.UpdateProviderDetails;
import curam.cpm.facade.struct.UpdateReferralDetails;
import curam.cpm.facade.struct.VersionNoKey;
import curam.cpm.sl.entity.struct.IndexedServiceOffering;
import curam.cpm.sl.entity.struct.IndexedServiceOfferings;
import curam.cpm.sl.entity.struct.ServiceOfferingDtls;
import curam.cpm.sl.struct.ReferralDtls;
import curam.cpm.sl.struct.ReferralKey;
import curam.cpm.sl.struct.ReferralRoleKey;
import curam.cpm.util.impl.ContextPanelConst;
import curam.cpm.util.impl.ServiceAndReferralContextPanelHelper;
import curam.cpm.util.impl.ServiceProviderSearchHelper;
import curam.message.REFERRAL;
import curam.message.impl.SERVICEDELIVERYExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.participant.impl.Individual;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.casemanager.impl.CaseParticipantRoleDAO;
import curam.piwrapper.impl.AddressDAO;
import curam.piwrapper.impl.ClientURI;
import curam.piwrapper.impl.EmailAddressDAO;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.impl.ProviderSpecialtyTypeEntry;
import curam.referral.impl.AttachmentReferralRole;
import curam.referral.impl.AttachmentReferralRoleDAO;
import curam.referral.impl.ReferralDAO;
import curam.referral.impl.ReferralRole;
import curam.referral.impl.ReferralRoleDAO;
import curam.referral.impl.ReferralRoleData;
import curam.servicedelivery.facade.impl.ServiceOfferingSummaryDetailsSortByName;
import curam.servicedelivery.facade.struct.ListServicesByTermResult;
import curam.servicedelivery.facade.struct.ServiceSearchKey;
import curam.servicedelivery.facade.struct.ServiceSearchResult;
import curam.serviceoffering.impl.CONTACTEDPROVIDERINDEntry;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.taxonomy.impl.TAXONOMY_SEARCH_OPTIONSEntry;
import curam.taxonomy.sl.search.impl.TaxonomySearch;
import curam.taxonomy.sl.search.struct.TaxonomyTermDetail;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Blob;
import curam.util.type.Date;
import curam.util.type.StringHelper;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;


/**
 * Facade class for Referral maintenance.
 *
 * @since 6.0
 */
public abstract class Referral extends curam.cpm.facade.base.Referral {

  /**
   * Reference to Attachment Link DAO instance.
   */
  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;

  /**
   * Reference to Referral DAO instance.
   */
  @Inject
  protected ReferralDAO referralDAO;

  /**
   * Reference to Concern Role DAO instance.
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Reference to Referral Role DAO instance.
   */
  @Inject
  protected ReferralRoleDAO referralRoleDAO;

  /**
   * Reference to Service Offering DAO instance.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Reference to Attachment Referral Role DAO instance.
   */
  @Inject
  protected AttachmentReferralRoleDAO attachmentReferralRoleDAO;

  /**
   * Reference to Email Address DAO instance.
   */
  @Inject
  protected EmailAddressDAO emailAddressDAO;

  /**
   * Reference to Address DAO instance.
   */
  @Inject
  protected AddressDAO addressDAO;

  /**
   * Provider instance of the Referral Role Data object.
   */
  @Inject
  protected Provider<ReferralRoleData> referralRoleData;

  /**
   * Reference to Case Participant Role DAO instance.
   */
  @Inject
  protected CaseParticipantRoleDAO caseParticipantRoleDAO;

  /**
   * Reference to Case Header DAO instance.
   */
  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  /**
   * Reference to User DAO instance.
   */
  @Inject
  protected UserDAO userDAO;

  /**
   * Provider instance of the Service Provider Search Helper object.
   */
  @Inject
  protected com.google.inject.Provider<ServiceProviderSearchHelper> serviceProviderSearchHelper;

  @Inject
  protected ServiceOfferingSummaryDetailsSortByName serviceOfferingSummaryDetailsSortByName;

  @Inject
  protected TaxonomySearch taxonomySearch;

  /**
   * Reference to a Referral Role Data list object.
   */
  protected List<ReferralRoleData> referralRoleDataList = new ArrayList<ReferralRoleData>();

  /**
   * Reference to the context panel helper class.
   */
  @Inject
  protected Provider<ServiceAndReferralContextPanelHelper> serviceReferralContextPanelHelperProvider;

  // BEGIN, CR00360398, CD
  @Inject
  private Provider<CMSMetadataInterface> cmsMetadataProvider;
  // END, CR00360398
  
  
  /**
   * Constructor.
   */
  protected Referral() {
    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public ServiceOfferingDetailsList listAllReferralServiceOfferings()
    throws AppException, InformationalException {
    ServiceOfferingDetailsList result = new ServiceOfferingDetailsList();

    Set<curam.serviceoffering.impl.ServiceOffering> serviceOfferingList = serviceOfferingDAO.searchActiveByProvisionMethod(
      PROVISIONMETHODEntry.REFERRAL);
    ServiceOfferingDtls serviceOfferingDtls;

    for (curam.serviceoffering.impl.ServiceOffering serviceOffering : serviceOfferingList) {
      serviceOfferingDtls = new ServiceOfferingDtls();
      serviceOfferingDtls.name = serviceOffering.getName();
      serviceOfferingDtls.serviceOfferingID = serviceOffering.getID();
      serviceOfferingDtls.description = serviceOffering.getDescription();
      result.serviceOfferingDtlsList.dtls.addRef(serviceOfferingDtls);
    }
    return result;
  }

  // BEGIN, CR00284521, POH
  /**
   * {@inheritDoc}
   */
  public ServiceSearchResult searchReferralServices(final ServiceSearchKey key)
    throws AppException, InformationalException {

    final boolean searchByNameInd = !StringHelper.isEmpty(key.serviceName);
    final boolean searchByKeywordInd = !StringHelper.isEmpty(key.keywords);

    if (!searchByNameInd && !searchByKeywordInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEDELIVERYExceptionCreator.ERR_FV_SERVICE_NAME_OR_KEYWORDS_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if (searchByNameInd && searchByKeywordInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEDELIVERYExceptionCreator.ERR_FV_ONLY_ONE_SERVICE_NAME_OR_KEYWORDS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();

    // Create the return value object
    final ServiceSearchResult serviceSearchResult = new ServiceSearchResult();

    if (searchByNameInd) {
      // Search for services by name
      final Set<curam.serviceoffering.impl.ServiceOffering> serviceOfferings = serviceOfferingDAO.searchBy(
        key.serviceName, key.unitOfMeasure);

      // Populate the return value list
      for (final curam.serviceoffering.impl.ServiceOffering serviceOffering : serviceOfferings) {
        if (serviceOffering.getProvisionMethod().equals(
          PROVISIONMETHODEntry.REFERRAL)) {
          final ServiceOfferingSummaryDetails serviceOfferingSummaryDetails = new ServiceOfferingSummaryDetails();

          assignServiceOfferingSummaryDetails(serviceOffering,
            serviceOfferingSummaryDetails);
          serviceSearchResult.services.add(serviceOfferingSummaryDetails);
        }
      }

      // Sort the results returned
      Collections.sort(serviceSearchResult.services,
        serviceOfferingSummaryDetailsSortByName);

      // Set the indicator to display the results
      serviceSearchResult.searchByNameResultsInd = true;

    } else if (searchByKeywordInd) {

      // Search for indexed taxonomy terms based on the keywords entered
      final curam.taxonomy.sl.search.struct.TaxonomySearchDetails taxonomySearchDetails = taxonomySearch.searchByKeywords(
        key.keywords, TransactionInfo.getProgramLocale(),
        TAXONOMY_SEARCH_OPTIONSEntry.get(key.keywordOptions));

      // Populate the return value list
      for (final TaxonomyTermDetail taxonomyTermDetail : taxonomySearchDetails.terms.term) {
        serviceSearchResult.terms.addRef(taxonomyTermDetail);
      }

      // Set the indicator to display the results
      serviceSearchResult.searchByKeywordResultsInd = true;
    }

    // BEGIN, CR00292877, IBM
    collectInformationalMessages(serviceSearchResult.informationalMsgDtlsOpt);
    // END, CR00292877

    return serviceSearchResult;

  }

  /**
   * {@inheritDoc}
   */
  public ListServicesByTermResult listReferralServicesByTerm(
    final ListServicesByTermKey1 key) throws AppException,
      InformationalException {

    // Create the return value object
    final ListServicesByTermResult listServicesByTermResult = new ListServicesByTermResult();

    final IndexedServiceOfferings nonReferralServices = taxonomySearch.searchIndexedReferralServices(
      key.taxonomyIDs, TransactionInfo.getProgramLocale());

    for (final IndexedServiceOffering serviceDetails : nonReferralServices.dtls) {
      final ServiceOfferingSummaryDetails serviceOfferingSummaryDetails = new ServiceOfferingSummaryDetails();
      final curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceOfferingDAO.get(
        serviceDetails.serviceOfferingID);

      assignServiceOfferingSummaryDetails(serviceOffering,
        serviceOfferingSummaryDetails);
      listServicesByTermResult.services.add(serviceOfferingSummaryDetails);
    }

    // Sort the results returned
    Collections.sort(listServicesByTermResult.services,
      serviceOfferingSummaryDetailsSortByName);

    return listServicesByTermResult;
  }

  /**
   * Assign the {@link ServiceOffering referral service} details into the
   * {@link ServiceOfferingSummaryDetails} value object.
   *
   * @param referralServiceOffering
   * The details to used when populating the value object.
   * @param referralServiceOfferingSummaryDetails
   * The value object to be populated.
   */
  protected void assignServiceOfferingSummaryDetails(
    final curam.serviceoffering.impl.ServiceOffering referralServiceOffering,
    final ServiceOfferingSummaryDetails referralServiceOfferingSummaryDetails) {
    referralServiceOfferingSummaryDetails.serviceOfferingID = referralServiceOffering.getID();
    referralServiceOfferingSummaryDetails.name = referralServiceOffering.getName();
    referralServiceOfferingSummaryDetails.serviceOfferingReference = referralServiceOffering.getReference();
    referralServiceOfferingSummaryDetails.unitOfMeasure = referralServiceOffering.getUnitOfMeasure().getCode();
    referralServiceOfferingSummaryDetails.startDate = referralServiceOffering.getDateRange().start();
    referralServiceOfferingSummaryDetails.endDate = referralServiceOffering.getDateRange().end();
  }

  // END, CR00284521


  /**
   * {@inheritDoc}
   */
  public ParticipantRoleDetailsList listClientsForCase(final CaseHeaderKey key)
    throws AppException, InformationalException {

    return listClientsForCase(caseHeaderDAO.get(key.caseID));

  }

  /**
   * {@inheritDoc}
   */
  public ParticipantRoleDetailsList listClientsForUpdate(final ReferralKey key)
    throws AppException, InformationalException {

    ParticipantRoleDetailsList participantRoleDetailsList = new ParticipantRoleDetailsList();

    curam.referral.impl.Referral referral = referralDAO.get(key.referralID);

    if (referral.getRelatedObjectLinkType().equals(
      REFERRALRELATEDLINKTYPEEntry.CASE)) {
      participantRoleDetailsList = listClientsForCase(
        caseHeaderDAO.get(referral.getRelatedObjectID()));
    }

    return participantRoleDetailsList;

  }

  /**
   * Retrieves a list of all participants that exist on the given
   * {@link CaseHeader}.
   *
   * @param caseHeader
   * the case header to retrieve all participants details from
   * @return the list of all participants for the case
   */
  protected ParticipantRoleDetailsList listClientsForCase(
    final CaseHeader caseHeader) {

    ParticipantRoleDetailsList participantRoleDetailsList = new ParticipantRoleDetailsList();

    List<CaseParticipantRole> listParticipants = caseParticipantRoleDAO.listActiveByCase(
      caseHeader);

    for (final CaseParticipantRole caseParticipantRole : listParticipants) {

      participantRoleDetailsList.list.addRef(
        getParticipantRoleDetails(caseParticipantRole));
    }

    return participantRoleDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ReferralKey createReferralForCase(final ReferralDetails details)
    throws AppException, InformationalException {

    ReferralKey referralKey = new ReferralKey();

    details.referralLinkDetails.relatedObjectLinkType = REFERRALRELATEDLINKTYPEEntry.CASE.getCode();

    referralKey.referralID = createReferral(details);

    return referralKey;

  }

  /**
   * Creates a Referral.
   *
   * @param details
   * The referral details for creation.
   * @return the unique identifier of the created referral
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Long createReferral(final ReferralDetails details)
    throws AppException, InformationalException {

    curam.referral.impl.Referral referral = referralDAO.newInstance();

    User user;

    if (details.loggedOnUserOwnerInd) {
      user = userDAO.get(TransactionInfo.getProgramUser());
    } else {
      user = userDAO.get(details.referralDtls.referredBy);
    }

    setProviderReferralRoleDetails(details.providerReferralRoleDetails);
    setProviderRepresentativeReferralRoleDetails(
      details.providerReferralRoleDetails);
    setServiceReferralRoleDetails(details.serviceReferralRoleDetails);
    setServiceNameReferralRoleDetails(details.serviceReferralRoleDetails);
    setClientsReferralRoleDetails(details.clientStringList);

    referral.setRelatedObjectID(details.referralLinkDetails.relatedObjectID);
    referral.setRelatedObjectType(
      REFERRALRELATEDLINKTYPEEntry.get(
        details.referralLinkDetails.relatedObjectLinkType));

    referral.setReferralDate(details.referralDtls.referralDate);
    referral.setReason(details.referralDtls.reason);
    referral.setClientContactedProvider(
      CONTACTEDPROVIDERINDEntry.get(
        details.referralDtls.clientContactedProviderInd));
    referral.setNotifyClientAutomatically(
      details.referralDtls.notifyClientAutomatically);
    referral.setFollowUpRequired(details.referralDtls.followUpRequiredInd);
    referral.setClientNotificationText(
      details.referralDtls.clientNotificationText);
    referral.setSensitivityCode(
      SENSITIVITYEntry.get(details.referralDtls.sensitivity));
    referral.setFollowUpWarningDays(details.referralDtls.followUpWarningDays);
    referral.setReferredBy(user);

    referral.insert(getReferralRoleDataList());

    return referral.getID();
  }

  /**
   * Sets the referral role details for each client that the referral is in
   * relation to.
   *
   * @param clientStringList
   * List of all clients that are to be related to the referral
   */
  protected void setClientsReferralRoleDetails(final String clientStringList) {

    if (clientStringList.length() > CuramConst.gkZero) {

      final String[] caseParticipantRoleList = clientStringList.split(
        CuramConst.gkTabDelimiter);

      for (String caseParticpantRole : caseParticipantRoleList) {
        setClientReferralRoleDetails(caseParticpantRole);
      }
    }
  }

  /**
   * Sets the referral role details for a client that the referral is in
   * relation to.
   *
   * @param caseParticpantRole
   * The participant role identifier for a client the referral is in
   * relation to
   */
  protected void setClientReferralRoleDetails(final String caseParticpantRole) {

    ReferralRoleData clientReferralRoleData = referralRoleData.get();

    clientReferralRoleData.setRelatedObjectID(
      Long.parseLong(caseParticpantRole));
    clientReferralRoleData.setRelatedObjectType(
      REFERRALRELATEDROLETYPEEntry.CLIENT);
    clientReferralRoleData.setRelatedObjectName(CuramConst.gkEmpty);
    setReferralRoleDataListItem(clientReferralRoleData);

  }

  /**
   * Sets the referral role details for a unregistered service that the referral
   * is in relation to.
   *
   * @param serviceReferralRoleDetails
   * The details that the unregistered service details are to be
   * extracted from
   */
  protected void setServiceNameReferralRoleDetails(
    final ServiceReferralRoleDetails serviceReferralRoleDetails) {

    ReferralRoleData serviceReferralRoleData = referralRoleData.get();

    if (serviceReferralRoleDetails.serviceName.length() != CuramConst.gkZero) {
      serviceReferralRoleData.setRelatedObjectName(
        serviceReferralRoleDetails.serviceName);
      serviceReferralRoleData.setRelatedObjectID(CuramConst.gkZero);
      serviceReferralRoleData.setRelatedObjectType(
        REFERRALRELATEDROLETYPEEntry.UNREGISTEREDSERVICEOFFERING);
      setReferralRoleDataListItem(serviceReferralRoleData);
    }

  }

  /**
   * Sets the referral role details for a service to be related to a referral.
   *
   * @param serviceReferralRoleDetails
   * The details that the service details are to be extracted from
   */
  protected void setServiceReferralRoleDetails(
    final ServiceReferralRoleDetails serviceReferralRoleDetails) {

    ReferralRoleData serviceReferralRoleData = referralRoleData.get();

    if (serviceReferralRoleDetails.serviceID != CuramConst.gkZero) {
      serviceReferralRoleData.setRelatedObjectID(
        serviceReferralRoleDetails.serviceID);
      serviceReferralRoleData.setRelatedObjectType(
        REFERRALRELATEDROLETYPEEntry.SERVICEOFFERING);
      serviceReferralRoleData.setRelatedObjectName(CuramConst.gkEmpty);
      setReferralRoleDataListItem(serviceReferralRoleData);
    }

  }

  /**
   * Sets the referral role details for a provider representative to be related
   * to a referral.
   *
   * @param providerReferralRoleDetails
   * The details that the provider representative details are to be
   * extracted from
   */
  protected void setProviderRepresentativeReferralRoleDetails(
    final ProviderReferralRoleDetails providerReferralRoleDetails)
    throws AppException, InformationalException {

    ReferralRoleData providerRepresentativeReferralRoleData = referralRoleData.get();

    if (providerReferralRoleDetails.providerName.length() != CuramConst.gkZero) {
      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      curam.core.sl.struct.RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = providerReferralRoleDetails.providerName;
      representativeRegistrationDetails.representativeDtls.representativeType = REPRESENTATIVETYPEEntry.CONTACT.getCode();
      representativeRegistrationDetails.representativeRegistrationDetails.addressData = providerReferralRoleDetails.providerAddressDetails;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = providerReferralRoleDetails.phoneAreaCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = providerReferralRoleDetails.phoneCountryCode;

      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = providerReferralRoleDetails.phoneNumber;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneType = PHONETYPEEntry.BUSINESS.getCode();
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();
      representativeRegistrationDetails.representativeRegistrationDetails.sensitivity = SENSITIVITYEntry.LOW.getCode();

      representativeObj.registerRepresentative(
        representativeRegistrationDetails);

      curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

      // create the email address
      if (!StringHelper.isEmpty(providerReferralRoleDetails.emailAddress)) {
        EmailAddress emailAddressObj = EmailAddressFactory.newInstance();
        EmailAddressDtls emailAddressDtls = new EmailAddressDtls();

        emailAddressDtls.emailAddressID = uniqueIDObj.getNextID();
        emailAddressDtls.statusCode = RECORDSTATUSEntry.NORMAL.getCode();
        emailAddressDtls.emailAddress = providerReferralRoleDetails.emailAddress;
        emailAddressObj.insert(emailAddressDtls);

        ConcernRoleEmailAddress concernRoleEmailAddress = ConcernRoleEmailAddressFactory.newInstance();
        ConcernRoleEmailAddressDtls concernRoleEmailAddressDtls = new ConcernRoleEmailAddressDtls();

        concernRoleEmailAddressDtls.concernRoleEmailAddressID = uniqueIDObj.getNextID();

        concernRoleEmailAddressDtls.concernRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
        concernRoleEmailAddressDtls.emailAddressID = emailAddressDtls.emailAddressID;
        concernRoleEmailAddress.insert(concernRoleEmailAddressDtls);

        ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = concernRoleEmailAddressDtls.concernRoleID;

        ConcernRoleDtls concernRoleDtls = ConcernRoleFactory.newInstance().read(
          concernRoleKey);

        concernRoleDtls.primaryEmailAddressID = concernRoleEmailAddressDtls.emailAddressID;
        curam.core.intf.ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

        concernRoleObj.modify(concernRoleKey, concernRoleDtls);
      }

      // representativeObj.modifyRepresentativeSummaryDetails(RepresentativeSummaryDetails)
      providerRepresentativeReferralRoleData.setRelatedObjectID(
        representativeRegistrationDetails.representativeDtls.concernRoleID);
      providerRepresentativeReferralRoleData.setRelatedObjectType(
        REFERRALRELATEDROLETYPEEntry.PROVIDERREPRESENTATIVE);
      providerRepresentativeReferralRoleData.setRelatedObjectName(
        CuramConst.gkEmpty);
      setReferralRoleDataListItem(providerRepresentativeReferralRoleData);
    }

  }

  /**
   * Sets the referral role details for a registered provider details (if any
   * entered) to be related to a referral.
   *
   * @param details
   * The details that the provider details are to be extracted from
   */
  protected void setProviderReferralRoleDetails(
    final ProviderReferralRoleDetails details) {

    ReferralRoleData providerReferralRoleData = referralRoleData.get();

    if (details.providerID != CuramConst.gkZero) {
      providerReferralRoleData.setRelatedObjectType(
        REFERRALRELATEDROLETYPEEntry.PROVIDER);
      providerReferralRoleData.setRelatedObjectID(details.providerID);
      providerReferralRoleData.setRelatedObjectName(CuramConst.gkEmpty);

      setReferralRoleDataListItem(providerReferralRoleData);
    }

  }

  /**
   * Retrieves the list of referral role data.
   *
   * @return the referral role data list
   */
  protected List<ReferralRoleData> getReferralRoleDataList() {
    return referralRoleDataList;
  }

  /**
   * Adds referral role data to the referral role data list.
   *
   * @param referralRoleDataItem
   * the referral role data item to be added to the referral role data
   * list
   */
  protected void setReferralRoleDataListItem(
    final ReferralRoleData referralRoleDataItem) {
    this.referralRoleDataList.add(referralRoleDataItem);
  }

  /**
   * {@inheritDoc}
   */
  public ReferralList listReferralsForCase(final ListReferralsKey key)
    throws AppException, InformationalException {

    return listReferrals(key.relatedObjectID, REFERRALRELATEDLINKTYPEEntry.CASE);

  }

  /**
   * Retrieves a list of referral details for the client that are related to the
   * given related object identifier and related type. If no
   * {@link curam.referral.impl.Referral} objects exist for the passed in
   * identifier an empty list is returned.
   *
   * @param relatedObjectID
   * the unique identifier of the object the retrieved referral details
   * are to be related to
   * @param referralRelatedLinkTypeEntry
   * the type of object the passed in unique identifier relates to
   * @return the list of referral details, or an empty list if no referrals
   * exist for the given details.
   * @throws AppException
   * Generic Application Exception
   * @throws InformationalException
   * Generic Information Exception.
   */
  protected ReferralList listReferrals(final Long relatedObjectID,
    final REFERRALRELATEDLINKTYPEEntry referralRelatedLinkTypeEntry)
    throws AppException, InformationalException {

    ReferralList referralList = new ReferralList();

    referralList.relatedID = relatedObjectID;
    referralList.relatedType = referralRelatedLinkTypeEntry.getCode();

    List<curam.referral.impl.Referral> referralLinkList = referralDAO.searchActiveByRelatedObjectIDAndType(
      relatedObjectID, referralRelatedLinkTypeEntry);

    for (curam.referral.impl.Referral referral : referralLinkList) {
      ReferralListDetails referralListDetails = getReferralListDetails(referral);

      referralList.referralDtls.addRef(referralListDetails);
    }

    referralList.context.context = caseHeaderDAO.get(relatedObjectID).getDescription();

    return referralList;
  }

  /**
   * {@inheritDoc}
   */
  public ReferralNotificationData viewNotificationDocument(
    final NotificationDocumentKey key) throws AppException,
      InformationalException {

    ReferralNotificationData referralNotificationData = new ReferralNotificationData();

    curam.referral.impl.Referral referral = referralDAO.get(key.referralID);

    ByteArrayOutputStream byteArrayOutputStream = referral.getReferralDocument(
      concernRoleDAO.get(key.concernRoleID),
      REFERRALNOTIFICATIONTYPEEntry.get(key.documentType));

    referralNotificationData.data = new Blob(
      byteArrayOutputStream.toByteArray());

    referralNotificationData.name = concernRoleDAO.get(key.concernRoleID).getName()
      + curam.servicedelivery.impl.CuramConst.kProFormaExtension;
    return referralNotificationData;
  }

  /**
   * Retrieves and formats the referral list details for a referral required for
   * displaying to the client.
   *
   * @param referral
   * the referral to retrieve the referral list details
   * @return the referral details require for the list
   */
  protected ReferralListDetails getReferralListDetails(
    final curam.referral.impl.Referral referral) {

    ReferralListDetails referralListDetailsItem = new ReferralListDetails();

    referralListDetailsItem.clientDetails = getReferralClients(referral);
    referralListDetailsItem.providerName = getProviderName(referral);
    referralListDetailsItem.referralID = referral.getID();
    referralListDetailsItem.referredBy = referral.getReferredBy().getFullName();
    referralListDetailsItem.referredDate = referral.getReferralDate();

    ReferralRole serviceReferralRole = getServiceReferralRole(referral);

    referralListDetailsItem.serviceName = serviceReferralRole.getName();
    referralListDetailsItem.serviceOfferingID = serviceReferralRole.getRelatedObjectID();

    // If a notification has been sent, set the correct edit page and indicate
    // if the referral can be deleted
    ClientURI editURI = null;

    if (referral.getNotifyClientAutomatically()
      || referral.getNotifyProviderAutomatically()) {
      editURI = new ClientURI(
        curam.servicedelivery.impl.CuramConst.REFERRAL_EDIT_PAGE_NOTIFICATION_SENT);
    } else {
      referralListDetailsItem.deleteEnabledInd = true;
      editURI = new ClientURI(
        curam.servicedelivery.impl.CuramConst.REFERRAL_EDIT_PAGE_NOTIFICATION_NOT_SENT);
    }
    editURI.appendParam(curam.servicedelivery.impl.CuramConst.kReferralID,
      referral.getID().toString());
    referralListDetailsItem.editURI = editURI.getURI();
    referralListDetailsItem.listSummaryURI = referral.getListSummaryURI().getURI();

    return referralListDetailsItem;
  }

  /**
   * Retrieves the entered service role for a referral.
   *
   * @param referral
   * The referral to get the service referral role from
   * @return the service referral role
   */
  protected ReferralRole getServiceReferralRole(
    final curam.referral.impl.Referral referral) {

    List<ReferralRole> serviceOfferingReferralRoleList = referralRoleDAO.searchActiveByReferralAndRelatedType(
      referral, REFERRALRELATEDROLETYPEEntry.SERVICEOFFERING);

    if (serviceOfferingReferralRoleList.size() > CuramConst.gkZero) {
      return serviceOfferingReferralRoleList.get(0);
    }

    List<ReferralRole> unregisteredServiceReferralRoleList = referralRoleDAO.searchActiveByReferralAndRelatedType(
      referral, REFERRALRELATEDROLETYPEEntry.UNREGISTEREDSERVICEOFFERING);

    return unregisteredServiceReferralRoleList.get(0);
  }

  /**
   * {@inheritDoc}
   */
  public ReadReferralDetails readReferralDetails(final ReferralKey key)
    throws AppException, InformationalException {

    ReadReferralDetails readReferralDetails = new ReadReferralDetails();
    curam.referral.impl.Referral referral = referralDAO.get(key.referralID);

    readReferralDetails.selectedClients = convertReferralRoleIdentifersIntoTabbedString(
      referralRoleDAO.searchActiveByReferralAndRelatedType(referral,
      REFERRALRELATEDROLETYPEEntry.CLIENT));

    readReferralDetails.referralDtls = getReferralDetails(referral);

    // BEGIN, CR00284521, POH
    getCreatedByDetails(readReferralDetails, referral);
    // END, CR00284521

    if (referredByCurrentUser(referral)) {
      readReferralDetails.referredByLoggedOnUserInd = true;
    } else {
      readReferralDetails.referralDtls.referredBy = referral.getReferredBy().getFullName();
    }

    if (null != referral.getProvider()) {
      readReferralDetails.providerRepresentativeInd = referral.getProviderType().equals(
        REFERRALRELATEDROLETYPEEntry.PROVIDERREPRESENTATIVE);
      readReferralDetails.providerCPMInd = referral.getProviderType().equals(
        REFERRALRELATEDROLETYPEEntry.PROVIDER);
      readReferralDetails.providerServiceOfferingID = referral.getService().getRelatedObjectID();
      ConcernRole provider = referral.getProvider();

      readReferralDetails.providerID = provider.getID();
      if (null != provider.getEmailAddress()) {
        readReferralDetails.providerEmailAddress = provider.getEmailAddress().getEmail();
      }
      readReferralDetails.providerName = provider.getName();
      if (null != provider.getPrimaryPhoneNumber()) {
        readReferralDetails.providerPhoneNumber = provider.getPrimaryPhoneNumber().getCountryCode()
          + CuramConst.gkSpace + provider.getPrimaryPhoneNumber().getAreaCode()
          + CuramConst.gkSpace + provider.getPrimaryPhoneNumber().getNumber();
      }

      readReferralDetails.providerAddress = addressDAO.get(provider.getPrimaryAddressID()).getOneLineAddressString();

    }

    readReferralDetails.multipleClientsSelectableInd = multipleClientReferralServiceSelected(
      referral);
    readReferralDetails.notificationDocumentDetailsList = getNotificationLetters(
      referral);

    return readReferralDetails;

  }

  /**
   * Retrieves or determines if the current user referred this
   * {@link curam.referral.impl.Referral}.
   *
   * @param referral
   * the referral to determine if the current user referred the
   * referral
   * @return true if the current user is the referrer of this referral,
   * otherwise false
   */
  protected Boolean referredByCurrentUser(
    final curam.referral.impl.Referral referral) {

    User user = userDAO.get(TransactionInfo.getProgramUser());

    if (referral.getReferredBy().getID().equals(user.getID())) {
      return true;
    }
    return false;

  }

  /**
   * Determines if the referral given is in relation to a service that is
   * configured to allow multiple clients to be selected.
   *
   * @param referral
   * the referral containing the service to be determined if multiple
   * clients are allowed to be selected for it
   * @return true if the referral service is configured to allow multiple
   * clients to be selected, otherwise false
   */
  protected boolean multipleClientReferralServiceSelected(
    final curam.referral.impl.Referral referral) {

    /*
     * if the service is an unregistered service multiple clients are allowed to
     * be selected
     */
    if (referral.getService().getRelatedObjectRoleType().equals(
      REFERRALRELATEDROLETYPEEntry.UNREGISTEREDSERVICEOFFERING)) {
      return true;
    }

    /*
     * if here, it means a service a from the service registry was selected.
     * Retrieve the service and determine if the service is configured for
     * multiple clients
     */
    if (serviceOfferingDAO.get(referral.getService().getRelatedObjectID()).getSingleOrMultipleClients().equals(
      SOSINGLEORMULTIPLECLIENTSEntry.MULTIPLE)) {
      return true;
    }

    /*
     * if here, it means a service from the service registry was selected that
     * is configured for a single client, return false.
     */
    return false;
  }

  /**
   * Retrieves the providers details for the passed in referral and populates
   * the {@link ProviderReferralRoleDetails} struct.
   *
   * @param referral
   * the referral to retrieve the provider details from
   * @return the struct populated with the provider details, or an empty struct
   * if no provider has being entered for the referral
   * @throws InformationalException
   * Generic Information Exception
   * @throws AppException
   * Generic Application Exception
   */
  protected ProviderReferralRoleDetails getProviderDetails(
    final curam.referral.impl.Referral referral)
    throws InformationalException, AppException {

    ProviderReferralRoleDetails providerReferralRoleDetails = new ProviderReferralRoleDetails();
    ConcernRole concernRole = referral.getProvider();

    if (null != concernRole) {

      providerReferralRoleDetails.providerID = concernRole.getID();
      providerReferralRoleDetails.providerName = concernRole.getName();

      if (CuramConst.gkZero != concernRole.getPrimaryEmailAddressID()) {
        providerReferralRoleDetails.emailAddress = emailAddressDAO.get(concernRole.getPrimaryEmailAddressID()).getEmail();
      }

      if (null != addressDAO.get(concernRole.getPrimaryAddressID())) {
        providerReferralRoleDetails.providerAddressDetails = addressDAO.get(concernRole.getPrimaryAddressID()).getFormattedAddressData();
      }

      providerReferralRoleDetails.providerType = REFERRALPROVIDERTYPEEntry.PROVIDER.getCode();

      if (null != concernRole.getPrimaryPhoneNumber()) {
        providerReferralRoleDetails.phoneAreaCode = concernRole.getPrimaryPhoneNumber().getAreaCode();
        providerReferralRoleDetails.phoneCountryCode = concernRole.getPrimaryPhoneNumber().getCountryCode();
        providerReferralRoleDetails.phoneNumber = concernRole.getPrimaryPhoneNumber().getNumber();
      }
    }

    return providerReferralRoleDetails;

  }

  // BEGIN, CR00284521, POH
  /**
   * Populates the {@link ReadReferralDetails#created} and
   * {@link ReadReferralDetails#createdByFullName} attributes for displaying to
   * the client with creation details from the given
   * {@link curam.referral.impl.Referral}.
   *
   * @param readReferralDetails
   * the {@link ReadReferralDetails} object containing the attributes
   * to be populated
   * @param referral
   * the referral the creation details are to be retrieved from
   */
  protected void getCreatedByDetails(
    final ReadReferralDetails readReferralDetails,
    final curam.referral.impl.Referral referral) {
    final LocalisableString addedString = new LocalisableString(
      REFERRAL.INF_DATE_BY);

    addedString.arg(referral.getCreationDate());
    readReferralDetails.createdOpt = addedString.toClientFormattedText();
    readReferralDetails.createdByFullNameOpt = referral.getCreatedBy().getFullName();
    readReferralDetails.referralDtls.createdBy = referral.getCreatedBy().getUsername();
  }

  // END, CR00284521

  /**
   * Retrieves the context description from when viewing or editing a
   * {@link Referral}.
   *
   * @param referral
   * The referral the context description is being retrieved for
   * @param caseHeader
   * The {@link CaseHeader} the referral is related to
   * @return the context description
   * @throws InformationalException
   * Generic Information Exception
   * @throws AppException
   * Generic Application Exception
   */
  protected String getContextDescription(
    final curam.referral.impl.Referral referral, final CaseHeader caseHeader)
    throws AppException, InformationalException {

    StringBuffer contextDescription = new StringBuffer();

    contextDescription.append(caseHeader.getDescription());

    REFERRAL.INF_MULTIPLE_CLIENT_REFERRAL.getMessageText();

    for (ReferralRole referralRole : referral.getReferralRoles()) {

      if (referralRole.getRelatedObjectRoleType().equals(
        REFERRALRELATEDROLETYPEEntry.SERVICEOFFERING)) {

        curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceOfferingDAO.get(
          referralRole.getRelatedObjectID());

        contextDescription.append(
          CuramConst.kSeparator + serviceOffering.getName()
          + CuramConst.kSeparator);
        if (serviceOfferingDAO.get(referralRole.getRelatedObjectID()).getSingleOrMultipleClients().equals(
          SOSINGLEORMULTIPLECLIENTSEntry.SINGLE)) {
          contextDescription.append(
            REFERRAL.INF_SINGLE_CLIENT_REFERRAL.getMessageText());
          break;
        } else {
          contextDescription.append(
            REFERRAL.INF_MULTIPLE_CLIENT_REFERRAL.getMessageText());
        }

      }

      if (referralRole.getRelatedObjectRoleType().equals(
        REFERRALRELATEDROLETYPEEntry.UNREGISTEREDSERVICEOFFERING)) {

        contextDescription.append(
          CuramConst.kSeparator + referralRole.getName()
          + CuramConst.kSeparator);

        contextDescription.append(
          REFERRAL.INF_MULTIPLE_CLIENT_REFERRAL.getMessageText());
      }
    }

    return contextDescription.toString();
  }

  /**
   * Retrieves and formats the referral details for display to the client.
   *
   * @param referral
   * the referral to retrieve the referral details from
   * @return the formatted referral details for display to the client
   */
  protected ReferralDtls getReferralDetails(
    final curam.referral.impl.Referral referral) {

    ReferralDtls referralDtls = new ReferralDtls();

    referralDtls.clientContactedProviderInd = referral.getClientContactedProvider().getCode();
    referralDtls.clientNotificationText = referral.getClientNotificationText();
    referralDtls.providerNotificationText = referral.getProviderNotificationText();
    referralDtls.creationDate = referral.getCreationDate();
    referralDtls.followUpRequiredInd = referral.getFollowUpRequired();
    referralDtls.followUpWarningDays = referral.getFollowUpWarningDays();
    referralDtls.notifyClientAutomatically = referral.getNotifyClientAutomatically();
    referralDtls.notifyProviderAutomatically = referral.getNotifyProviderAutomatically();

    referralDtls.reason = referral.getReason();
    referralDtls.recordStatus = referral.getLifecycleState().getCode();
    referralDtls.referralDate = referral.getReferralDate();
    referralDtls.referralID = referral.getID();
    referralDtls.sensitivity = referral.getSensitivityCode().getCode();
    referralDtls.versionNo = referral.getVersionNo();

    return referralDtls;
  }

  /**
   * Retrieves a list of clients that exist for a referral.
   *
   * @param referral
   * the referral to read the clients from
   * @return comma separated list containing the clients that exist for a
   * referral
   */
  protected String getReferralClients(
    final curam.referral.impl.Referral referral) {

    StringBuffer clientList = new StringBuffer();

    clientList.append(
      convertReferralRoleNamesIntoCommaString(
        referralRoleDAO.searchActiveByReferralAndRelatedType(referral,
        REFERRALRELATEDROLETYPEEntry.CLIENT)));

    return clientList.toString();
  }

  /**
   * Retrieves a the name of the providers that exist on the referral.
   *
   * @param referral
   * the referral to read the provider from
   * @return The providers that exist for a referral, or an empty string if no
   * provider exits
   */
  protected String getProviderName(final curam.referral.impl.Referral referral) {

    ConcernRole provider = referral.getProvider();

    if (null != provider) {
      return provider.getName();
    } else {
      return CuramConst.gkEmpty;
    }

  }

  /**
   * Converts a passed in list of referral role records of a particular type
   * into a comma separated list based on the name of the referral role..
   *
   * @param referralRoleList
   * The lit of referral roles to be converted into a comma separated
   * list
   * @return the comma separated list
   */
  protected String convertReferralRoleNamesIntoCommaString(
    final List<ReferralRole> referralRoleList) {

    StringBuffer multipleReferralRoleDetailsStringList = new StringBuffer();

    for (int i = 0; i < referralRoleList.size(); i++) {
      ReferralRole referralRole = referralRoleList.get(i);

      multipleReferralRoleDetailsStringList.append(referralRole.getName());

      if (i != referralRoleList.size() - 1) {
        multipleReferralRoleDetailsStringList.append(
          CuramConst.gkComma + CuramConst.gkSpace);
      }

    }
    return multipleReferralRoleDetailsStringList.toString();
  }

  /**
   * Converts a passed in list of referral role records of a particular type
   * into a tabbed separated list based on the identifier of the referral role..
   *
   * @param referralRoleList
   * The lit of referral roles to be converted into a tabbed separated
   * list
   * @return the tabbed separated list
   */
  protected String convertReferralRoleIdentifersIntoTabbedString(
    final List<ReferralRole> referralRoleList) {

    StringBuffer multipleReferralRoleDetailsStringList = new StringBuffer();

    for (int i = 0; i < referralRoleList.size(); i++) {
      ReferralRole referralRole = referralRoleList.get(i);

      multipleReferralRoleDetailsStringList.append(
        referralRole.getRelatedObjectID());

      if (i != referralRoleList.size() - 1) {
        multipleReferralRoleDetailsStringList.append(
          CuramConst.gkTabDelimiterChar);
      }

    }
    return multipleReferralRoleDetailsStringList.toString();
  }

  /**
   * {@inheritDoc}
   */
  public void updateReferral(final UpdateReferralDetails details)
    throws AppException, InformationalException {

    curam.referral.impl.Referral referral = referralDAO.get(
      details.referralDtls.referralID);

    setClientsReferralRoleDetails(details.clientStringList);

    referral.setReferralDate(details.referralDtls.referralDate);
    referral.setReason(details.referralDtls.reason);
    referral.setClientContactedProvider(
      CONTACTEDPROVIDERINDEntry.get(
        details.referralDtls.clientContactedProviderInd));
    referral.setNotifyClientAutomatically(
      details.referralDtls.notifyClientAutomatically);
    referral.setFollowUpRequired(details.referralDtls.followUpRequiredInd);
    referral.setClientNotificationText(
      details.referralDtls.clientNotificationText);
    referral.setSensitivityCode(
      SENSITIVITYEntry.get(details.referralDtls.sensitivity));
    referral.setFollowUpWarningDays(details.referralDtls.followUpWarningDays);

    referral.modify(getReferralRoleDataList(), details.referralDtls.versionNo);

  }

  /**
   * {@inheritDoc}
   */
  public void createAttachment(final AttachmentLinkDetails details)
    throws AppException, InformationalException {
    
    // create referral role record, linking the attachment to the referral
    curam.referral.impl.Referral referral = referralDAO.get(
      details.attachmentLinkDtls.relatedObjectID);
    
    // BEGIN, CR00360398, CD
    CaseHeader caseObj = referral.getCase();

    GuiceWrapper.getInjector().injectMembers(this); 
    CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

    cmsMetadata.add(CMSMetadataConst.kCaseID, Long.toString(caseObj.getID()));
    // END, CR00360398
    
    // create attachment and attachment link
    AttachmentLink attachmentLink = attachmentLinkDAO.newInstance();

    details.attachmentLinkDtls.relatedObjectType = ATTACHMENTOBJECTLINKTYPEEntry.REFERRAL.getCode();
    attachmentLink.insert(details);

    ReferralRoleData attachmentReferralRoleData = referralRoleData.get();

    attachmentReferralRoleData.setRelatedObjectID(attachmentLink.getID());
    attachmentReferralRoleData.setRelatedObjectType(
      REFERRALRELATEDROLETYPEEntry.ATTACHMENT);
    attachmentReferralRoleData.setRelatedObjectName(CuramConst.gkEmpty);
    referral.createReferralRole(attachmentReferralRoleData);
  }

  /**
   * {@inheritDoc}
   */
  public ListAttachmentLinkDetails listAttachments(final ReferralKey key)
    throws AppException, InformationalException {

    curam.referral.impl.Referral referral = referralDAO.get(key.referralID);

    ListAttachmentLinkDetails listAttachmentLinkDetails = new ListAttachmentLinkDetails();
    AttachmentLinkDetails attachmentLinkDetails;

    List<? extends AttachmentReferralRole> attachmentReferralRoleList = attachmentReferralRoleDAO.searchActiveByReferral(
      referral);

    for (AttachmentReferralRole attachmentReferralRole : attachmentReferralRoleList) {
      attachmentLinkDetails = new AttachmentLinkDetails();

      attachmentLinkDetails.attachmentDtls.receiptDate = attachmentReferralRole.getReceiptDate();
      attachmentLinkDetails.attachmentLinkDtls.attachmentLinkID = attachmentReferralRole.getRelatedObjectID();
      attachmentLinkDetails.attachmentLinkDtls.description = attachmentReferralRole.getDescription();

      listAttachmentLinkDetails.attachmentLinkDetails.addRef(
        attachmentLinkDetails);
    }

    return listAttachmentLinkDetails;
  }

  /**
   * Retrieves the participant details of an individual.
   *
   * @param caseParticipantRole
   * The case participant details of the individual to get the
   * participant details from
   * @return the participant role details
   */
  protected ParticipantRoleDetails getParticipantRoleDetails(
    final CaseParticipantRole caseParticipantRole) {

    ParticipantRoleDetails participantRoleDetails = new ParticipantRoleDetails();
    ConcernRole concernRole = caseParticipantRole.getConcernRole();

    participantRoleDetails.caseParticipantRoleID = caseParticipantRole.getID();
    participantRoleDetails.participantName = concernRole.getName();
    participantRoleDetails.participantRoleID = concernRole.getID();
    if (concernRole instanceof Individual) {
      Individual individual = (Individual) concernRole;

      participantRoleDetails.gender = individual.getGender().getCode();
      participantRoleDetails.age = individual.calculateAge(
        Date.getCurrentDate());
      LocalisableString ageLocalisableString = individual.getAge(
        Date.getCurrentDate());

      participantRoleDetails.ageLocalisableStringOpt = ageLocalisableString.toClientFormattedText();
      final StringBuffer participantDescription = new StringBuffer();

      participantDescription.append(individual.getName());
      participantDescription.append(CuramConst.gkSpace);
      participantDescription.append(CuramConst.gkRoundOpeningBracket);
      participantDescription.append(
        ageLocalisableString.getMessage(TransactionInfo.getProgramLocale()));
      participantDescription.append(CuramConst.gkRoundClosingBracket);
      participantRoleDetails.participantDescription = participantDescription.toString();
    }

    return participantRoleDetails;
  }

  /**
   * {@inheritDoc}
   */
  public NotificationDocumentDetailsList listNotificationLetters(
    final ReferralKey key) throws AppException, InformationalException {

    curam.referral.impl.Referral referral = referralDAO.get(key.referralID);

    return getNotificationLetters(referral);
  }

  /**
   * Retrieves the details of the notification letters that have been generated
   * for the given referral.
   *
   * @param referral
   * the referral the generated notification letters are to be
   * retrieved in relation to
   * @return the notification letters that have been generated for the referral
   */
  protected NotificationDocumentDetailsList getNotificationLetters(
    final curam.referral.impl.Referral referral) {
    NotificationDocumentDetailsList notificationDocumentDetailsList = new NotificationDocumentDetailsList();
    NotificationDocumentDetails notificationDocumentDetails;

    for (CaseParticipantRole caseParticipantRole : referral.listCaseParticipantRoles()) {
      notificationDocumentDetails = new NotificationDocumentDetails();
      notificationDocumentDetails.documentType = REFERRALNOTIFICATIONTYPEEntry.CLIENT.getCode();
      notificationDocumentDetails.concernRoleName = REFERRAL.INF_SENT_TO
        + CuramConst.gkSpace + caseParticipantRole.getConcernRole().getName();
      notificationDocumentDetails.concernRoleID = caseParticipantRole.getConcernRole().getID();
      notificationDocumentDetails.referralID = referral.getID();
      notificationDocumentDetailsList.notificationDocumentDetails.addRef(
        notificationDocumentDetails);
    }

    if (null != referral.getProvider()) {
      notificationDocumentDetails = new NotificationDocumentDetails();
      notificationDocumentDetails.documentType = REFERRALNOTIFICATIONTYPEEntry.PROVIDER.getCode();
      notificationDocumentDetails.concernRoleName = REFERRAL.INF_SENT_TO
        + CuramConst.gkSpace + referral.getProvider().getName();
      notificationDocumentDetails.concernRoleID = referral.getProvider().getID();
      notificationDocumentDetails.referralID = referral.getID();
      notificationDocumentDetailsList.notificationDocumentDetails.addRef(
        notificationDocumentDetails);
    }
    return notificationDocumentDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ReadDetailsForProviderSearchResult readProviderSearchCriteriaProviderListForUpdate(
    final ReadDetailsForProviderSearchKey key) throws AppException,
      InformationalException {

    ReadDetailsForProviderSearchResult readDetailsForProviderSearchResult = new ReadDetailsForProviderSearchResult();
    curam.referral.impl.Referral referral = referralDAO.get(key.referralID);

    readDetailsForProviderSearchResult.serviceOfferingID = referral.getService().getRelatedObjectID();
    readDetailsForProviderSearchResult.versionNo = referral.getVersionNo();
    readDetailsForProviderSearchResult.registeredProviderType = REFERRALPROVIDERTYPEEntry.PROVIDER.getCode();
    readDetailsForProviderSearchResult.representativeProviderType = REFERRALPROVIDERTYPEEntry.NOT_SPECIFIED.getCode();
    readDetailsForProviderSearchResult.caseClientNameDetails = serviceProviderSearchHelper.get().getCaseClientsNameList(
      caseHeaderDAO.get(referral.getRelatedObjectID()).listActiveCaseMembers());
    readDetailsForProviderSearchResult.specialties = serviceProviderSearchHelper.get().getProviderSpecialityCodesAsList();
    if ((key.addressID != 0)
      || (!StringHelper.isEmpty(key.providerSpecialtiesTabbedString))
      || (!StringHelper.isEmpty(key.providerName))) {

      List<ProviderSpecialtyTypeEntry> specialties = new ArrayList<ProviderSpecialtyTypeEntry>();

      if (!StringHelper.isEmpty(key.providerSpecialtiesTabbedString)) {
        String[] specialtyCodes = key.providerSpecialtiesTabbedString.split(
          CuramConst.gkTabDelimiter);

        for (String specialtyCode : specialtyCodes) {
          specialties.add(ProviderSpecialtyTypeEntry.get(specialtyCode));
        }
      }
      readDetailsForProviderSearchResult.searchedProviderDetails = serviceProviderSearchHelper.get().listProvidersForServiceOffering(
        serviceOfferingDAO.get(referral.getService().getRelatedObjectID()),
        addressDAO.get(key.addressID), specialties,
        PROXIMITYDISTANCEEntry.get(key.proximityDistance), key.providerName);
      readDetailsForProviderSearchResult.searchedProviderDetails.providerSearchCriteria.addressID = key.addressID;
      readDetailsForProviderSearchResult.searchedProviderDetails.providerSearchCriteria.providerSpecialtiesTabbedString = key.providerSpecialtiesTabbedString;
      readDetailsForProviderSearchResult.searchedProviderDetails.providerSearchCriteria.proximityDistance = key.proximityDistance;
      readDetailsForProviderSearchResult.searchedProviderDetails.providerSearchCriteria.providerName = key.providerName;
    }
    readDetailsForProviderSearchResult.proximityDistanceLabelDisplayString = CuramConst.gkRoundOpeningBracket
      + serviceProviderSearchHelper.get().getMeasurementDistance().toUserLocaleString()
      + CuramConst.gkRoundClosingBracket;

    return readDetailsForProviderSearchResult;
  }

  /**
   * {@inheritDoc}
   */
  public ListProviderDetailsKey updateProvider(final UpdateProviderDetails key)
    throws AppException, InformationalException {

    curam.referral.impl.Referral referral = referralDAO.get(key.referralID);

    if (!key.searchProviderPerformedInd) {
      setProviderReferralRoleDetails(key.providerReferralRoleDetails);
      setProviderRepresentativeReferralRoleDetails(
        key.providerReferralRoleDetails);
      referral.setProvider(getReferralRoleDataList());
    }

    return key.listProviderDetailsKey;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderDetailsForRemove readProviderDetailsForRemove(
    final ReferralKey referralKey) throws AppException,
      InformationalException {

    ProviderDetailsForRemove providerDetailsForRemove = new ProviderDetailsForRemove();
    curam.referral.impl.Referral referral = referralDAO.get(
      referralKey.referralID);

    // Retrieve the provider referral role
    ReferralRole providerReferralRole = referralRoleDAO.readActiveByReferralAndRelatedType(
      referral, REFERRALRELATEDROLETYPEEntry.PROVIDERREPRESENTATIVE);

    if (null == providerReferralRole) {
      providerReferralRole = referralRoleDAO.readActiveByReferralAndRelatedType(
        referral, REFERRALRELATEDROLETYPEEntry.PROVIDER);
    }

    // Populate the return details if provider was entered.
    if (null != providerReferralRole) {
      providerDetailsForRemove.providerReferralRoleID = providerReferralRole.getID();
      providerDetailsForRemove.versionNo = providerReferralRole.getVersionNo();
    }

    return providerDetailsForRemove;
  }

  /**
   * {@inheritDoc}
   */
  public void removeProvider(final ReferralRoleKey referralRoleKey,
    final VersionNoKey versionNoKey) throws AppException,
      InformationalException {

    ReferralRole referralRole = referralRoleDAO.get(
      referralRoleKey.referralRoleID);

    referralRole.cancel(versionNoKey.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void cancelReferral(final CancelReferralKey cancelKey)
    throws AppException, InformationalException {
    curam.referral.impl.Referral referral = referralDAO.get(
      cancelKey.referralID);

    referral.cancel(cancelKey.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public VersionNoKey readVersionNo(final ReferralKey key) throws AppException,
      InformationalException {
    curam.referral.impl.Referral referral = referralDAO.get(key.referralID);
    VersionNoKey versionNoKey = new VersionNoKey();

    versionNoKey.versionNo = referral.getVersionNo();
    return versionNoKey;
  }

  /**
   * {@inheritDoc}
   */
  public ContextPanelDetails readContextPanelDetails(final ReferralKey key)
    throws AppException, InformationalException {
    ContextPanelDetails contextPanelDetails = new ContextPanelDetails();
    curam.referral.impl.Referral referral = referralDAO.get(key.referralID);

    List<CaseParticipantRole> serviceClients = referral.listCaseParticipantRoles();

    contextPanelDetails.name = referral.getName();
    contextPanelDetails.clients = getReferralClients(referral);

    // Create a container content panel
    ContentPanelBuilder containerPanel = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleContainerPanelServiceOrReferral);

    ServiceAndReferralContextPanelHelper contextPanelHelper = serviceReferralContextPanelHelperProvider.get();

    if (serviceClients.size() > 1) { // multiple clients
      // Build and add left panel
      StackContainerBuilder stackContainerBuilder = contextPanelHelper.getCaseMemberThumbnailDetails(
        serviceClients);

      containerPanel.addWidgetItem(stackContainerBuilder, CuramConst.gkStyle,
        CuramConst.gkStyleStackContainer);

      // build and add right panel
      ContentPanelBuilder referralRightPanel = contextPanelHelper.getContextPanelDetails(
        referral);

      containerPanel.addWidgetItem(referralRightPanel, CuramConst.gkStyle,
        CuramConst.gkContentPanel,
        ContextPanelConst.kStyleContentPanelDetailServiceOrReferralContentPanelBlueFooter);
    } else { // single client
      // Build and add left panel
      ContentPanelBuilder contentPanelBuilder = contextPanelHelper.getCaseMemberThumbnailDetails(
        serviceClients.get(0));

      // Add the left panel to the container panel
      containerPanel.addWidgetItem(contentPanelBuilder, CuramConst.gkStyle,
        CuramConst.gkContentPanel, CuramConst.gkCaseParticipantPanel);

      // build and add right panel
      ContentPanelBuilder rightPanel = contextPanelHelper.getContextPanelDetails(
        referral);

      containerPanel.addWidgetItem(rightPanel, CuramConst.gkStyle,
        CuramConst.gkContentPanel,
        ContextPanelConst.kStyleContentPanelDetailServiceOrReferralContentPanelMediumBlueFooter);
    }

    contextPanelDetails.xmlPanelData = containerPanel.toString();
    return contextPanelDetails;
  }

  // BEGIN, CR00292877, IBM
  /**
   * Collects the list of informations from the informational manager and adds
   * them to the list parameter passed in.
   *
   * @param informationalMsgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMessages(
    final InformationalMsgDtlsList informationalMsgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }
  // END, CR00292877
}
