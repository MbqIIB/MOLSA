/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.core.struct.ConcernRoleKey;
import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ConcernAndServiceInvoiceKey;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.eua.facade.struct.SILIClientDetails;
import curam.cpm.eua.facade.struct.SILIClientDetailsList;
import curam.cpm.eua.facade.struct.ServiceInvoiceLineItemDetails;
import curam.cpm.facade.fact.SILICorrectionFactory;
import curam.cpm.facade.fact.ServiceInvoiceFactory;
import curam.cpm.facade.intf.SILICorrection;
import curam.cpm.facade.intf.ServiceInvoice;
import curam.cpm.facade.struct.SILIDetail;
import curam.cpm.facade.struct.SILIDetailsList;
import curam.cpm.facade.struct.ServiceInvoiceLineItemsDetailsList;
import curam.cpm.sl.entity.struct.ServiceInvoiceKey;
import curam.cpm.sl.entity.struct.ServiceInvoiceLineItemKey;
import curam.financial.impl.ServiceInvoiceDAO;
import curam.financial.impl.ServiceInvoiceLineItem;
import curam.financial.impl.ServiceInvoiceLineItemClient;
import curam.financial.impl.ServiceInvoiceLineItemDAO;
import curam.financial.impl.ServiceInvoiceLineItemStatusEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This process class provides the functionality for the External
 * Service Invoice Line Items
 */
public abstract class ExternalServiceInvoiceLineItem extends curam.cpm.eua.facade.base.ExternalServiceInvoiceLineItem {

  @Inject
  protected ServiceInvoiceDAO serviceInvoiceDAO;

  @Inject
  protected ServiceInvoiceLineItemDAO serviceInvoiceLineItemDAO;

  /**
   * Constructor
   */
  public ExternalServiceInvoiceLineItem() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * This method returns a list of service invoice line items for its
   * associated service invoice.
   *
   * @param key - contains the service invoice ID
   *
   * @return A list of service invoice line items
   *
   * @throws InformationalException
   *
   * @throws AppException
   */
  public ServiceInvoiceLineItemsDetailsList listServiceInvoiceLineItems(
    ConcernAndServiceInvoiceKey key) throws AppException,
      InformationalException {
    // BEGIN, CR00235365, SSK
    ServiceInvoiceKey serviceInvoiceKey = new ServiceInvoiceKey();

    // set the key
    serviceInvoiceKey.serviceInvoiceID = key.serviceInvoiceID.serviceInvoiceID;

    ServiceInvoiceLineItemsDetailsList serviceInvoiceLineItemsDetailsList = filterList(
      getServiceInvoiceLineItem(serviceInvoiceKey));

    // END, CR00235365
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // set the concern role key
    // START CR00094326, JSP
    concernRoleKey.concernRoleID = serviceInvoiceDAO.get(serviceInvoiceKey.serviceInvoiceID).getOriginator().getID();
    // END CR00094326

    // perform security checks
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    // return details
    return serviceInvoiceLineItemsDetailsList;

  }

  /**
   * This method filters the provider participants list removing all canceled
   * records from the list
   *
   * @param unfilteredList - this contains a list of provider participants
   * @return This contains a list of all provider participants except canceled
   */
  // BEGIN, CR00177241, PM
  protected ServiceInvoiceLineItemsDetailsList filterList(
    ServiceInvoiceLineItemsDetailsList unfilteredList) {
    // END, CR00177241

    ServiceInvoiceLineItemsDetailsList result = new ServiceInvoiceLineItemsDetailsList();

    for (int i = 0; i < unfilteredList.dtlsList.size(); i++) {

      if (!unfilteredList.dtlsList.item(i).details.status.equals(
        ServiceInvoiceLineItemStatusEntry.CANCELED.getCode())) {
        result.dtlsList.addRef(unfilteredList.dtlsList.item(i));
      }
    }

    return result;
  }

  /**
   * This method returns service invoice line item details
   * including correction details
   *
   * @param key - contains the service invoice Line Item ID
   *
   * @return The service invoice line item details
   *
   * @throws InformationalException
   *
   * @throws AppException
   */
  public ServiceInvoiceLineItemDetails viewServiceInvoiceLineItem(
    ServiceInvoiceLineItemKey key) throws AppException,
      InformationalException {

    // result variable
    ServiceInvoiceLineItemDetails serviceInvoiceLineItemDetails = new ServiceInvoiceLineItemDetails();

    // call the facade method
    ServiceInvoice serviceInvoiceFacade = ServiceInvoiceFactory.newInstance();
    SILICorrection sILICorrectionObj = SILICorrectionFactory.newInstance();

    // call the method to get service invoice line item details
    serviceInvoiceLineItemDetails.lineItemDetails = serviceInvoiceFacade.viewServiceInvoiceLineItem(
      key);

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // set the concern role key
    // START CR00094326, JSP
    concernRoleKey.concernRoleID = serviceInvoiceLineItemDAO.get(key.serviceInvoiceLineItemID).getServiceInvoice().getOriginator().getID();
    // END CR00094326

    // perform security checks
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    serviceInvoiceLineItemDetails.correctionDetails = sILICorrectionObj.listSILICorrections(
      key);

    return serviceInvoiceLineItemDetails;

  }

  // BEGIN, CR00158345, GP
  /**
   * Lists all the client details for a give service invoice line item. Client
   * information can be present in service invoice line item table or service
   * invoice line item client table. This method lists the client details
   * present in both the tables.
   *
   * @param serviceInvoiceLineItemKey
   * Contains service invoice line item ID for which client details are
   * to be retrieved.
   *
   * @return List of clients for the given service invoice line item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public SILIClientDetailsList listClientDetailsForServiceInvoiceLineItem(
    ServiceInvoiceLineItemKey serviceInvoiceLineItemKey) throws AppException,
      InformationalException {
    
    SILIClientDetailsList siliClientDetailsList = new SILIClientDetailsList();
    ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      serviceInvoiceLineItemKey.serviceInvoiceLineItemID);

    Set<ServiceInvoiceLineItemClient> serviceInvoiceLineItemClients = serviceInvoiceLineItem.getServiceInvoiceLineItemClients();

    for (ServiceInvoiceLineItemClient serviceInvoiceLineItemClient : serviceInvoiceLineItemClients) {

      SILIClientDetails siliClientDetails = new SILIClientDetails();

      siliClientDetails.clientDOB = serviceInvoiceLineItemClient.getClientDOB();
      siliClientDetails.clientFirstName = serviceInvoiceLineItemClient.getClientFirstName();
      siliClientDetails.clientLastName = serviceInvoiceLineItemClient.getClientLastName();
      siliClientDetails.clientReferenceNo = serviceInvoiceLineItemClient.getClientReferenceNo();

      if (null != serviceInvoiceLineItemClient.getID()) {
        siliClientDetails.siliClientID = serviceInvoiceLineItemClient.getID();
      }

      siliClientDetails.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();

      siliClientDetailsList.clientDetails.addRef(siliClientDetails);
    }

    return siliClientDetailsList;
  }

  // END, CR00158345
  
  // BEGIN, CR00235365, SSK
  /**
   * Retrieves the list of service invoice line items.
   *
   * @param serviceInvoiceKey
   * Contains the service invoice line ID.
   *
   * @return List of service invoice line items.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ServiceInvoiceLineItemsDetailsList getServiceInvoiceLineItem(final ServiceInvoiceKey serviceInvoiceKey)
    throws AppException,
      InformationalException {
    ServiceInvoiceLineItemsDetailsList serviceInvoiceLineItemsDetailsList = new ServiceInvoiceLineItemsDetailsList();
    curam.cpm.facade.struct.ServiceInvoiceLineItemDetails serviceInvoiceLineItemDetails = null;
    ServiceInvoice serviceInvoiceFacade = ServiceInvoiceFactory.newInstance();
    SILIDetailsList siliDetailsList = serviceInvoiceFacade.listAllServiceInvoiceLineItems(
      serviceInvoiceKey);

    for (SILIDetail siliDetails : siliDetailsList.details) {
      serviceInvoiceLineItemDetails = new curam.cpm.facade.struct.ServiceInvoiceLineItemDetails();
      serviceInvoiceLineItemDetails.dtls.amountPaid = siliDetails.amountPaid;
      serviceInvoiceLineItemDetails.dtls.service = siliDetails.serviceDetails.service;
      serviceInvoiceLineItemDetails.clientName = siliDetails.clientName;
      serviceInvoiceLineItemDetails.details.serviceInvoiceLineItemID = siliDetails.siliDetails.serviceInvoiceLineItemID;
      serviceInvoiceLineItemDetails.details.noOfUnits = siliDetails.siliDetails.noOfUnits;
      serviceInvoiceLineItemDetails.details.amountInvoiced = siliDetails.siliDetails.amountInvoiced;
      serviceInvoiceLineItemDetails.details.status = siliDetails.siliDetails.status;
      serviceInvoiceLineItemsDetailsList.dtlsList.addRef(
        serviceInvoiceLineItemDetails);
      
    }
    
    return serviceInvoiceLineItemsDetailsList;
  }
  // EDN, CR00235365
}
