/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import com.google.inject.Inject;

import curam.codetable.ADDRESSELEMENTTYPE;
import curam.codetable.CONCERNROLESTATUS;
import curam.codetable.LANGUAGE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.codetable.impl.CONTRACTTYPEEntry;
import curam.codetable.impl.CURRENCYEntry;
import curam.codetable.impl.INCIDENTSTATUSEntry;
import curam.codetable.impl.LANGUAGEEntry;
import curam.codetable.impl.METHODOFDELIVERYEntry;
import curam.codetable.impl.PREFERREDSERVICEENQUIRYMETHODEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SERVICEDELIVERYSTATUSEntry;
import curam.contracts.impl.ContractTerminationReasonEntry;
import curam.contracts.impl.ContractVersion;
import curam.core.facade.fact.PersonFactory;
import curam.core.facade.struct.CaseMenuData;
import curam.core.facade.struct.CaseParticipantRoleKey;
import curam.core.facade.struct.ICMemberMenuDataDetails;
import curam.core.facade.struct.InternationalBankAccountIndicator;
import curam.core.facade.struct.ListDeliveryMethodDetails;
import curam.core.facade.struct.PersonRegistrationResult;
import curam.core.facade.struct.PersonSearchResult;
import curam.core.facade.struct.ReadICDetailsKey;
import curam.core.facade.struct.UserSkillListKey;
import curam.core.facade.struct.UserSkills;
import curam.core.fact.AddressElementFactory;
import curam.core.fact.AddressFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ConcernRolePhoneNumberFactory;
import curam.core.fact.DeliveryMethodFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.ConcernRoleAdapter;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.ProductHookManager;
import curam.core.intf.Address;
import curam.core.intf.AddressElement;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.ConcernRolePhoneNumber;
import curam.core.intf.DeliveryMethod;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.UserSkillLanguagesFactory;
import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.UserSkillDetails;
import curam.core.sl.entity.struct.UserSkillLanguagesDtls;
import curam.core.sl.entity.struct.UserSkillLanguagesDtlsList;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.struct.AddressTabDetails;
import curam.core.sl.struct.UserSkillLanguageReadMultiKey;
import curam.core.struct.AddressDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressElementDtlsList;
import curam.core.struct.AddressKey;
import curam.core.struct.BankAccountDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRolePhoneDetails;
import curam.core.struct.ConcernRolePhoneNumberDtls;
import curam.core.struct.DeliveryMethodDtls;
import curam.core.struct.DeliveryMethodKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.IntegratedCaseKey;
import curam.core.struct.ListAllDeliveryMethodsIn;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PhoneForConcernRoleKey;
import curam.cpm.facade.fact.CompartmentFactory;
import curam.cpm.facade.fact.ContractManagementFactory;
import curam.cpm.facade.fact.PlaceFactory;
import curam.cpm.facade.intf.Compartment;
import curam.cpm.facade.intf.ContractManagement;
import curam.cpm.facade.intf.Place;
import curam.cpm.facade.struct.CompartmentDetails;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.ProviderCategoryDetails;
import curam.cpm.facade.struct.ProviderCategoryDetailsList;
import curam.cpm.facade.struct.ProviderEnquirySummaryDetails;
import curam.cpm.facade.struct.ProviderEnquirySummaryDetailsList;
import curam.cpm.facade.struct.ProviderEnrollmentDetails;
import curam.cpm.facade.struct.ProviderFlatRateContract;
import curam.cpm.facade.struct.ProviderPersonSearchKey;
import curam.cpm.facade.struct.ProviderReasonStatusUpdateDetails;
import curam.cpm.facade.struct.ProviderRegistrationAsPersonOptionDetails;
import curam.cpm.facade.struct.ProviderRegistrationOptionDetails;
import curam.cpm.facade.struct.ProviderRejectReasonUpdateDetails;
import curam.cpm.facade.struct.ProviderStatusHistoryDetailsList;
import curam.cpm.facade.struct.ProviderTypeDetails;
import curam.cpm.facade.struct.ReadICProviderDetails;
import curam.cpm.facade.struct.RegisterProviderPersonDetails;
import curam.cpm.facade.struct.SearchProviderAndEnquiryConfirmationDetails;
import curam.cpm.facade.struct.SearchProviderDetails;
import curam.cpm.facade.struct.SearchProviderDetailsList;
import curam.cpm.facade.struct.SearchProviderServiceOfferingResults;
import curam.cpm.facade.struct.SearchProviderServiceOfferingResultsList;
import curam.cpm.facade.struct.SearchProviderTypeResults;
import curam.cpm.facade.struct.SearchProviderTypeResultsList;
import curam.cpm.facade.struct.TerminateContractDetails;
import curam.cpm.facade.struct.UserNameDetails;
import curam.cpm.facade.struct.UserNameDetailsList;
import curam.cpm.facade.struct.ViewCompartmentKey;
import curam.cpm.facade.struct.ViewProviderCategoryDetails;
import curam.cpm.facade.struct.ViewProviderSummaryDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.fact.PlacementFactory;
import curam.cpm.sl.entity.fact.ProviderTypeFactory;
import curam.cpm.sl.entity.impl.ProviderAdapter;
import curam.cpm.sl.entity.intf.Placement;
import curam.cpm.sl.entity.intf.ProviderType;
import curam.cpm.sl.entity.struct.CompartmentDtls;
import curam.cpm.sl.entity.struct.CompartmentKey;
import curam.cpm.sl.entity.struct.PlacementDtlsList;
import curam.cpm.sl.entity.struct.ProviderCategoryPeriodKey;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderDtls;
import curam.cpm.sl.entity.struct.ProviderEnrollmentReferenceKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ProviderOfferingIDAndDateTimeKey;
import curam.cpm.sl.entity.struct.ProviderSearchDetailsList;
import curam.cpm.sl.entity.struct.ProviderSearchKey;
import curam.cpm.sl.entity.struct.ProviderServiceOfferingSearchKey;
import curam.cpm.sl.entity.struct.ProviderServiceOfferingSearchResultsList;
import curam.cpm.sl.entity.struct.ProviderStatusDetails;
import curam.cpm.sl.entity.struct.ProviderStatusHistoryDtls;
import curam.cpm.sl.entity.struct.ProviderStatusUpdateDetails;
import curam.cpm.sl.entity.struct.ProviderTypeDtls;
import curam.cpm.sl.entity.struct.ProviderTypeSearchResultsList;
import curam.cpm.sl.entity.struct.SearchProviderEnquiryKey;
import curam.cpm.sl.entity.struct.SearchProviderEnrollmentKey;
import curam.cpm.sl.entity.struct.providerTypeSearchKey;
import curam.cpm.sl.fact.ProviderNotificationFactory;
import curam.cpm.sl.fact.ServiceDeliveryFactory;
import curam.cpm.sl.fact.WMCreatePlaceDataFactory;
import curam.cpm.sl.intf.ProviderNotification;
import curam.cpm.sl.intf.ServiceDelivery;
import curam.cpm.sl.struct.ProviderNotificationKey;
import curam.cpm.sl.struct.SearchByProvider;
import curam.cpm.sl.struct.ServiceDeliveryDtls;
import curam.cpm.sl.struct.ServiceDeliveryDtlsList;
import curam.cpm.sl.struct.WMCreatePlaceDataDtls;
import curam.cpm.util.impl.TimeZoneUtil;
import curam.message.BPOINTEGRATEDCASE;
import curam.message.PROVIDER;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.PROVIDERCATEGORYExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.participant.impl.ConcernRoleDAO;
import curam.participant.impl.PhoneNumber;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.place.CompartmentStatus;
import curam.provider.ProviderNotificationEvent;
import curam.provider.ProviderStatus;
import curam.provider.impl.ProviderCategoryNameEntry;
import curam.provider.impl.ProviderCategoryPeriod;
import curam.provider.impl.ProviderCategoryPeriodDAO;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderEnquiryDAO;
import curam.provider.impl.ProviderIncident;
import curam.provider.impl.ProviderMemberDAO;
import curam.provider.impl.ProviderMemberRoleEntry;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.provider.impl.ProviderReferenceNumberStrategy;
import curam.provider.impl.ProviderStatusEntry;
import curam.provider.impl.ProviderStatusHistory;
import curam.provider.impl.ProviderStatusHistoryDAO;
import curam.provider.impl.ProviderTypeDAO;
import curam.provider.impl.ProviderTypeNameEntry;
import curam.providerservice.impl.ProviderOffering;
import curam.useradmin.impl.MaintainAdminConcernRole;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.fact.DeferredProcessingFactory;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateTime;
import curam.util.type.DateTimeRange;
import curam.util.type.FrequencyPattern;
import curam.util.type.StringHelper;
import curam.util.type.StringList;


/**
 * Facade layer class having API for managing Providers.
 */
public abstract class Provider extends curam.cpm.facade.base.Provider {

  /**
   * instance of Provider Member.
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  /**
   * instance of Provider.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * instance of Provider Enquiry.
   */
  @Inject
  protected ProviderEnquiryDAO providerEnquiryDAO;

  /**
   * instance of Provider Category Period.
   */
  @Inject
  protected ProviderCategoryPeriodDAO providerCategoryPeriodDAO;

  /**
   * instance of Provider Type.
   */
  @Inject
  protected ProviderTypeDAO providerTypeDAO;

  /**
   * instance of Provider Status History.
   */
  @Inject
  protected ProviderStatusHistoryDAO providerStatusHistoryDAO;

  /**
   * instance of Concern Role.
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * instance of provider Reference Number Strategy.
   */
  @Inject
  ProviderReferenceNumberStrategy providerReferenceNumberStrategy;

  /**
   * instance of Provider Organization.
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Constant for minimum physical and designated capacity.
   */
  protected static final int kMinimumCapacity = 0;

  /**
   * Constant for maximum physical capacity.
   */
  protected static final int kPRPhysicalCapacity = 1000;

  /**
   * Constant for maximum designated capacity.
   */
  protected static final int kMaximumCapacity = 1000;

  // BEGIN, CR00233823, PS
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;

  // END, CR00233823

  /**
   * Bootstrap dependency injection for this class
   */
  public Provider() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Enrolls Provider with the specified Provider details.
   *
   * @param details
   * Contains the Provider enrollment details.
   * @return ProviderEnrollmentReferenceKey Contains Concern Role ID and
   * reference number for a Provider.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderEnrollmentReferenceKey createProviderEnrollment(
    ProviderEnrollmentDetails details) throws AppException,
      InformationalException {

    // return key
    ProviderEnrollmentReferenceKey providerEnrollmentReferenceKey = new ProviderEnrollmentReferenceKey();

    // Provider object instance
    curam.provider.impl.Provider provider = providerDAO.newInstance();

    // Provider category period object instance
    ProviderCategoryPeriod providerCategoryPeriod = providerCategoryPeriodDAO.newInstance();

    // Provider type object instance
    curam.provider.impl.ProviderType providerType = providerTypeDAO.newInstance();

    // Provider status history object instance
    ProviderStatusHistory providerStatusHistory = providerStatusHistoryDAO.newInstance();

    // BEGIN, CR00137797, SG
    // BEGIN, CR00137938, SG
    // Set the provider enrollment date to current system date if not already
    // set.
    if (details.enrollmentDate.equals(Date.kZeroDate)) {
      details.enrollmentDate = Date.getCurrentDate();
    }
    // END, CR00137938
    // END, CR00137797

    // unique id generator class
    UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // BEGIN, CR00200254, RPB
    // Current date time to be set as the enrollment date time.
    provider.setDateTimeRange(
      new DateTimeRange(DateTime.getCurrentDateTime(), DateTime.kZeroDateTime));
    // END, CR00200254

    // create a UniqueID for the provider reference number.
    String alternateProdProvRefNo = providerReferenceNumberStrategy.generateReferenceNumber();

    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    concernRoleDtls.primaryAlternateID = alternateProdProvRefNo;
    setConcernRoleFields(details, concernRoleDtls);

    AddressDetails addressDetails = new AddressDetails();

    addressDetails.concernRoleAddressID = uniqueIDObj.getNextID();
    setAddressFields(details, addressDetails);

    ConcernRolePhoneDetails concernRolePhoneDetails = new ConcernRolePhoneDetails();

    setConcernRolePhoneFields(details, concernRolePhoneDetails);

    BankAccountDetails bankAccountDetails = new BankAccountDetails();

    setConcernRoleBankFields(details, bankAccountDetails);
    // BEGIN CR00102261 KR
    validateBankAccountDetails(details);
    // KR CR00102261
    provider.enroll(concernRoleDtls, addressDetails, concernRolePhoneDetails,
      bankAccountDetails);

    validateProviderPhysicalAndDesignatedCapacityDDetails(details);

    setProviderFields(details, provider);

    provider.insert();

    // Add provider category for this provider
    details.providerType = details.providerCategory;
    details.providerCategory = CodeTable.getParentCode(
      ProviderTypeNameEntry.TABLENAME, details.providerType);
    providerCategoryPeriod.setCategory(
      ProviderCategoryNameEntry.get(details.providerCategory));
    providerCategoryPeriod.setComments(CPMConstants.kEmptyString);
    providerCategoryPeriod.setPrimary(true);
    providerCategoryPeriod.setProvider(provider);

    // Check this if it assigns the correct end date for category period
    final DateRange dateRange = new DateRange(details.enrollmentDate, null);

    providerCategoryPeriod.setDateRange(dateRange);

    providerCategoryPeriod.insert();

    // Add provider types for this category
    providerType.setType(details.providerType);
    providerType.setProviderCategoryPeriod(providerCategoryPeriod);
    providerType.insert();

    // If the provider is enrolled from the enquiry, then close the enquiry
    if (details.providerEnquiryID != 0) {

      // Provider enquiry object
      curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.get(
        details.providerEnquiryID);

      // BEGIN, CR00097355, NRV
      providerEnquiry.transferEnquiryToProvider(details.versionNo);
      // END, CR00097355
    }

    // Add provider status history for this provider
    providerStatusHistory.setEffectiveDateTime(DateTime.getCurrentDateTime());
    String status = ProviderStatusEntry.OPEN.getCode();

    providerStatusHistory.setProviderRecordStatus(status.trim());
    providerStatusHistory.setUserName(TransactionInfo.getProgramUser());
    providerStatusHistory.setProvider(provider);

    providerStatusHistory.insert();

    // provider notification - code in the implementation class
    providerEnrollmentReferenceKey.concernRoleID = provider.getID();
    providerEnrollmentReferenceKey.referenceNumber = alternateProdProvRefNo;

    // Create Default compartment
    Compartment providerCompartment = CompartmentFactory.newInstance();
    CompartmentDtls dtls = new CompartmentDtls();

    dtls.providerConcernRoleID = providerEnrollmentReferenceKey.concernRoleID;
    dtls.name = details.providerName;
    dtls.parentCompartmentID = 0;
    dtls.recordStatus = CompartmentStatus.ACTIVE;
    dtls.dateCreated = Date.getCurrentDate();

    CompartmentKey compartmentKey = providerCompartment.createCompartment(dtls);

    createDesignatedPlaces(details, compartmentKey);

    // Send Provider Enrollment Notification
    // Physical capacity should be less than 1000
    int physicalCapacity = details.physicalCapacity;

    if (physicalCapacity != 0 && physicalCapacity > kPRPhysicalCapacity) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_PHYSICAL_CAPACITY_GREATER_THAN_LIMIT(
          kPRPhysicalCapacity),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();

    ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = providerEnrollmentReferenceKey.concernRoleID;
    providerNotificationKey.event = ProviderNotificationEvent.ENROLLMENT;

    providerNotification.sendNotification(providerNotificationKey);

    ValidationHelper.failIfErrorsExist();

    // return the enroll provider key
    return providerEnrollmentReferenceKey;
  }

  /**
   * Approves the Provider for offering the services to the agency clients.
   *
   * @param details
   * Contains Provider details.
   * @return ProviderKey Contains Concern Role ID for a Provider.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderKey approveProvider(ProviderStatusUpdateDetails details)
    throws AppException, InformationalException {

    ProviderKey providerKey = new ProviderKey();
    curam.provider.impl.Provider provider = providerDAO.get(
      details.providerConcernRoleID);

    // BEGIN, CR00246372, AK
    provider.approveWithSecurityCheck(details.versionNo);
    // END, CR00246372
    String status = ProviderStatusEntry.APPROVED.getCode();

    setProviderStatusHistory(provider, CPMConstants.kEmptyString, status);

    providerKey.providerConcernRoleID = details.providerConcernRoleID;
    return providerKey;
  }

  // BEGIN, CR00237197, GP
  /**
   * Returns a list of all Providers that are assigned to the resource manager .
   *
   * @return The list of Providers.
   *
   * @throws AppException
   * Generic Exception Signature.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link MaintainProvider#listProvidersForResourceManager()}.
   * This method is not useful for displaying user full name as well
   * as conditional display of links in list of providers for
   * resource manager. Hence this method is deprecated. The newly
   * added method will give the option to the user to display the
   * user full name as well as conditional display links. See
   * release note: CR00237197.
   */
  @Deprecated
  // END, CR00237197
  public SearchProviderDetailsList listProvidersForResourceManager()
    throws AppException, InformationalException {

    SearchProviderDetailsList searchProviderDetailList = new SearchProviderDetailsList();

    final Set<curam.provider.impl.Provider> providers = providerDAO.searchProvidersByUserName(
      TransactionInfo.getProgramUser());

    for (final curam.provider.impl.Provider provider : providers) {
      // get the owner of this provider
      MaintainAdminConcernRole maintainAdminConcernRole = new MaintainAdminConcernRole();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = provider.getID();
      String owner = maintainAdminConcernRole.getProviderOrganisationOwner(concernRoleKey).userName;

      if (owner.equals(TransactionInfo.getProgramUser())) {
        searchProviderDetailList.details.addRef(getProviderFields(provider));
      }

    }
    return sortProviders(searchProviderDetailList);
  }

  /**
   * Returns a list of all Providers that are assigned as a facility manager .
   *
   * @return SearchProviderDetailsList Contains the list of Providers.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchProviderDetailsList listProvidersForFacilityManager()
    throws AppException, InformationalException {

    SearchProviderDetailsList searchProviderDetailList = new SearchProviderDetailsList();

    final Set<curam.provider.impl.Provider> providers = providerDAO.searchProvidersByUserName(
      TransactionInfo.getProgramUser());

    for (final curam.provider.impl.Provider provider : providers) {
      MaintainAdminConcernRole maintainAdminConcernRole = new MaintainAdminConcernRole();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = provider.getID();
      String owner = maintainAdminConcernRole.getProviderOrganizationFacilityManager(concernRoleKey).userName;

      // BEGIN, CR00228013, GP
      if (owner.equals(TransactionInfo.getProgramUser().trim())) {
        // END, CR00228013

        searchProviderDetailList.details.addRef(
          getProviderFieldsForFacilityManager(provider));
      }

    }
    return sortProviders(searchProviderDetailList);
  }

  // BEGIN, CR00237197, GP
  /**
   * Returns a list of all Providers that are assigned to the resource manager
   * supervisor.
   *
   * @return The list of Providers.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link MaintainProvider#listProviderForResourceManagerSupervisor()}
   * . This method is not useful for displaying user full name in
   * list of providers for resource manager supervisor. Hence this
   * method is deprecated. The newly added method will give the
   * option to the user to display the user full name. See release
   * note: CR00237197.
   */
  @Deprecated
  // END, CR00237197
  public SearchProviderDetailsList listProviderForResourceManagerSupervisor()
    throws AppException, InformationalException {

    SearchProviderDetailsList searchProviderDetailList = new SearchProviderDetailsList();
    // BEGIN, CR00236420, ASN
    List<String> supervisorList = new ArrayList<String>();
    // END, CR00236420
    final Set<curam.provider.impl.Provider> providers = providerDAO.searchProvidersByUserName(
      TransactionInfo.getProgramUser());

    for (final curam.provider.impl.Provider provider : providers) {
      // get the owner of this provider
      MaintainAdminConcernRole maintainAdminConcernRole = new MaintainAdminConcernRole();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = provider.getID();
      String owner = maintainAdminConcernRole.getProviderOrganisationOwner(concernRoleKey).userName;

      // BEGIN, CR00236420, ASN
      UserNameDetailsList userNameDetailsList = maintainAdminConcernRole.listProviderOrganisationSupervisor(
        concernRoleKey);

      for (final UserNameDetails userNameDetails : userNameDetailsList.detailsList.items()) {
        supervisorList.add(userNameDetails.userName);

      }
      // END, CR00236420

      // BEGIN, CR00236420, ASN
      // BEGIN, CR00206674, RD
      if (owner.equals(TransactionInfo.getProgramUser())
        || supervisorList.contains(TransactionInfo.getProgramUser())) {
        searchProviderDetailList.details.addRef(getProviderFields(provider));
      }
      // END, CR00206674
      // END, CR00236420
    }
    return sortProviders(searchProviderDetailList);
  }

  /**
   * Searches for all the Providers based on search criteria.
   *
   * @param key
   * Contains the search criteria.
   * @return SearchProviderDetailsList Contains Provider search results.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00106777, SG
  public SearchProviderDetailsList searchProviders(ProviderSearchKey key)
    throws AppException, InformationalException {

    // Check if any search criteria entered.
    String providerName = key.name.trim();
    String providerType = key.providerCategoryType.trim();
    String referenceNumber = key.referenceNumber.trim();
    String ownerName = key.ownerName.trim();

    // Check if any of the search criteria is entered.
    if (referenceNumber.equalsIgnoreCase(CPMConstants.kEmptyString)
      && providerName.equalsIgnoreCase(CPMConstants.kEmptyString)
      && providerType.equalsIgnoreCase(CPMConstants.kEmptyString)
      && ownerName.equalsIgnoreCase(CPMConstants.kEmptyString)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_SOME_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

      // Check if reference number is entered then
      // no other criteria should be entered.
    } else if ((!referenceNumber.equalsIgnoreCase(CPMConstants.kEmptyString))
      && ((!providerName.equalsIgnoreCase(CPMConstants.kEmptyString))
        || (!providerType.equalsIgnoreCase(CPMConstants.kEmptyString))
        || (!ownerName.equalsIgnoreCase(CPMConstants.kEmptyString)))) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_REFERENCE_NO_IS_SPECIFIED_OTHER_SEARCH_CRITERIA_IS_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    ValidationHelper.failIfErrorsExist();

    ProviderSearchDetailsList providerSearchDetailsList = providerDAO.searchProvider(
      key.name, key.referenceNumber, key.providerCategoryType, key.ownerName);

    SearchProviderDetailsList searchProviderDetailsList = new SearchProviderDetailsList();
    SearchProviderDetails searchProviderDetails;

    for (int i = 0; i < providerSearchDetailsList.dtls.size(); i++) {

      searchProviderDetails = new SearchProviderDetails();

      curam.provider.impl.Provider provider = providerDAO.get(
        providerSearchDetailsList.dtls.item(i).providerConcernRoleID);

      searchProviderDetails.owner = providerSearchDetailsList.dtls.item(i).owner;
      searchProviderDetails.name = provider.getName();
      searchProviderDetails.referenceNumber = provider.getPrimaryAlternateID();
      searchProviderDetails.concernRoleID = provider.getID();
      searchProviderDetails.primaryCategory = provider.getPrimaryProviderCategoryPeriod().getCategory().getCode();
      searchProviderDetails.recordStatus = provider.getLifecycleState().getCode();

      searchProviderDetailsList.details.addRef(searchProviderDetails);
    }
    
    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(searchProviderDetailsList.informationalMsgDtlsOpt);
    // END, CR00292696

    // BEGIN, CR00121648, AS
    return sortProviders(searchProviderDetailsList);
  }

  // END,CR00121648

  // END, CR00106777

  /**
   * Modifies the Provider details.
   *
   * @param providerEnrollmentDetails
   * Contains Provider details to be modified.
   * @return ProviderKey Contains the Concern Role ID for a Provider.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderKey modifyProvider(
    ProviderEnrollmentDetails providerEnrollmentDetails) throws AppException,
      InformationalException {

    ProviderKey providerKey = new ProviderKey();

    providerKey.providerConcernRoleID = providerEnrollmentDetails.concernRoleID;

    curam.provider.impl.Provider provider = providerDAO.get(
      providerEnrollmentDetails.concernRoleID);

    // Reading the ConcernRoleDtls from database and setting the modified
    // values
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = providerEnrollmentDetails.concernRoleID;

    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    boolean physicalCapacityStored = provider.getPhysicalCapacity() == 0
      ? false
      : true;

    validateConcernRoleDetails(providerEnrollmentDetails);

    Compartment compartmentView = CompartmentFactory.newInstance();

    ViewCompartmentKey viewCompartmentKey = new ViewCompartmentKey();

    viewCompartmentKey.providerConcernRoleID = providerKey.providerConcernRoleID;

    // Getting the compartment details for the provider
    CompartmentDetails compartmentDetails = compartmentView.viewCompartment(
      viewCompartmentKey);

    // Setting the value of designated capacity from the compartment details
    // BEGIN, CR00093586, ABS
    if (compartmentDetails.designatedCapacity > 0
      && providerEnrollmentDetails.designatedCapacityString.length()
        == kMinimumCapacity) {
      // END, CR00093586
      providerEnrollmentDetails.designatedCapacity = compartmentDetails.designatedCapacity;
      providerEnrollmentDetails.designatedCapacityString = String.valueOf(
        compartmentDetails.designatedCapacity);
    }

    validateProviderPhysicalAndDesignatedCapacityDDetails(
      providerEnrollmentDetails);

    // Get the provider
    setProviderFields(providerEnrollmentDetails, provider);

    // Physical capacity should be less than 1000
    int physicalCapacity = providerEnrollmentDetails.physicalCapacity;

    if (physicalCapacity != 0 && physicalCapacity > kPRPhysicalCapacity) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_PHYSICAL_CAPACITY_GREATER_THAN_LIMIT(
          kPRPhysicalCapacity),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // modify provider
    concernRoleDtls.preferredLanguage = providerEnrollmentDetails.prefLanguage;
    concernRoleDtls.prefCommMethod = providerEnrollmentDetails.prefCommMethod;
    concernRoleDtls.comments = providerEnrollmentDetails.comments;
    concernRoleDtls.concernRoleName = providerEnrollmentDetails.providerName;
    provider.modify(providerEnrollmentDetails.versionNo);

    // Calling the method to update the changes to the database
    concernRoleObj.modify(concernRoleKey, concernRoleDtls);

    // BEGIN, CR00089570, DMC
    Set<curam.place.impl.Compartment> unModifiableProviderCompartments = provider.getCompartments();
    Set<curam.place.impl.Compartment> providerCompartments = new HashSet<curam.place.impl.Compartment>();

    providerCompartments.addAll(unModifiableProviderCompartments);

    for (curam.place.impl.Compartment compartment : providerCompartments) {

      // modify the compartment name if the provider name has been modified
      // BEGIN, CR00091063, KR
      // modify the root compartment name if the provider name has been modified
      if (compartment.getParentCompartment() == null) {
        // END, CR00091063
        int compartmentVersionNo = 0;

        compartment.setName(providerEnrollmentDetails.providerName);
        compartmentVersionNo = compartment.getVersionNo();
        compartment.modify(compartmentVersionNo);
      }
    }
    // END, CR00089570

    if (!physicalCapacityStored) {

      // Get the compartmentID for the provider
      long compartmentID = 0;

      // Get the root compartment for provider
      for (curam.place.impl.Compartment compartment : providerCompartments) {
        if (compartment.getParentCompartment() == null) {
          compartmentID = compartment.getID();
          break;
        }
      }

      // Root level compartment key
      CompartmentKey compartmentKey = new CompartmentKey();

      compartmentKey.compartmentID = compartmentID;

      // Create the places in the root level compartment
      createDesignatedPlaces(providerEnrollmentDetails, compartmentKey);

    }

    return providerKey;
  }

  /**
   * Reads the Provider details.
   *
   * @param providerKey
   * contains Concern Role ID for a Provider.
   * @return ProviderEnrollmentDetails Contains the Provider details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderEnrollmentDetails viewProvider(ProviderKey providerKey)
    throws AppException, InformationalException {

    ProviderEnrollmentDetails providerEnrollmentDetails = new ProviderEnrollmentDetails();

    // Creating an instance for sl process and calling the view method
    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    ProviderDtls providerDtls = new ProviderDtls();

    DeliveryMethod deliveryMethod = DeliveryMethodFactory.newInstance();
    DeliveryMethodKey deliveryMethodKey = new DeliveryMethodKey();

    deliveryMethodKey.deliveryMethodID = provider.getMethodOfPayment();
    DeliveryMethodDtls deliveryMethodDtls = deliveryMethod.read(
      deliveryMethodKey);

    providerDtls.methodOfPayment = provider.getMethodOfPayment();
    providerDtls.currencyType = provider.getCurrencyType().getCode();
    // BEGIN, CR00096779, ABS
    providerDtls.paymentFrequency = provider.getPaymentFrequency();
    // END CR00096779
    providerDtls.physicalCapacity = provider.getPhysicalCapacity();
    providerDtls.providerConcernRoleID = provider.getID();
    providerDtls.versionNo = provider.getVersionNo();
    providerDtls.recordStatus = provider.getLifecycleState().getCode();

    providerEnrollmentDetails.assign(providerDtls);

    // set the payment frequency to human readable string
    providerEnrollmentDetails.paymentFrequencyString = provider.getPaymentFrequency();

    providerEnrollmentDetails.methodOfPaymentString = CodeTable.getOneItemForUserLocale(
      METHODOFDELIVERYEntry.TABLENAME, deliveryMethodDtls.name);

    providerEnrollmentDetails.versionNo = providerDtls.versionNo;

    if (providerDtls.physicalCapacity > kMinimumCapacity) {
      // Begin CR00096779, ABS
      providerEnrollmentDetails.physicalCapacityString = CPMConstants.kEmptyString
        + providerDtls.physicalCapacity;
      // End CR00096779
    }

    if (providerEnrollmentDetails.designatedCapacity > kMinimumCapacity) {
      providerEnrollmentDetails.designatedCapacityString = CPMConstants.kEmptyString
        + providerEnrollmentDetails.designatedCapacity;

    }

    providerEnrollmentDetails.prefLanguage = provider.getPreferredLanguage().getCode();
    providerEnrollmentDetails.prefCommMethod = provider.getPreferredCommunicationMethod().getCode();
    providerEnrollmentDetails.comments = provider.getComments();
    providerEnrollmentDetails.providerName = provider.getName();
    providerEnrollmentDetails.enrollmentDate = provider.getRegistrationDate();
    providerEnrollmentDetails.endDate = provider.getEndDate();
    providerEnrollmentDetails.concernRoleID = provider.getID();
    providerEnrollmentDetails.pageContextDescription = provider.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + provider.getPrimaryAlternateID();
    // providerDtls.referenceNumber = concernRoleDtls.primaryAlternateID;
    providerEnrollmentDetails.referenceNumber = provider.getPrimaryAlternateID();
    Compartment compartment = CompartmentFactory.newInstance();

    ViewCompartmentKey viewCompartmentKey = new ViewCompartmentKey();

    viewCompartmentKey.providerConcernRoleID = providerKey.providerConcernRoleID;

    // Getting the compartment details for the provider
    CompartmentDetails compartmentDetails = compartment.viewCompartment(
      viewCompartmentKey);

    // Setting the value of designated capacity from the compartment details
    providerEnrollmentDetails.designatedCapacity = compartmentDetails.designatedCapacity;

    if (compartmentDetails.designatedCapacity > kMinimumCapacity) {
      // Begin CR00096779, ABS
      providerEnrollmentDetails.designatedCapacityString = CPMConstants.kEmptyString
        + compartmentDetails.designatedCapacity;
      // End CR00096779
      providerEnrollmentDetails.modifyDesignatedCapacity = false;
    } else {
      providerEnrollmentDetails.modifyDesignatedCapacity = true;
    }

    // Get primary provider category
    final ProviderCategoryPeriod providerCategoryPeriod = provider.getPrimaryProviderCategoryPeriod();

    providerEnrollmentDetails.category = ProviderCategoryNameEntry.get(providerCategoryPeriod.getCategory().getCode()).getCode();

    providerEnrollmentDetails.providerCategoryVersion = providerCategoryPeriod.getVersionNo();
    // Get provider types for this category

    Set<curam.provider.impl.ProviderType> unModifiableProviderTypes = providerCategoryPeriod.getProviderTypes();
    Set<curam.provider.impl.ProviderType> providerTypes = new HashSet<curam.provider.impl.ProviderType>();

    providerTypes.addAll(unModifiableProviderTypes);

    for (final curam.provider.impl.ProviderType providerType : providerTypes) {

      if (providerEnrollmentDetails.providerType.equals(GeneralConstants.kEmpty)) {

        providerEnrollmentDetails.providerType += CodeTable.getOneItem(
          ProviderTypeNameEntry.TABLENAME, providerType.getType());

      } else {

        providerEnrollmentDetails.providerType += GeneralConstants.kComma
          + CuramConst.gkTabDelimiter
          + CodeTable.getOneItem(ProviderTypeNameEntry.TABLENAME,
          providerType.getType());

      }
      providerEnrollmentDetails.typeVersion = providerType.getVersionNo();

    }

    // Get address details
    Address addressObj = AddressFactory.newInstance();
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = provider.getPrimaryAddressID();

    AddressDtls addressDtls = addressObj.read(addressKey);

    OtherAddressData formattedAddressData = new OtherAddressData();

    formattedAddressData.addressData = addressDtls.addressData;
    addressObj.getAddressStrings(formattedAddressData);

    providerEnrollmentDetails.formattedAddressData = formattedAddressData.addressData;
    providerEnrollmentDetails.addressData = addressDtls.addressData;

    // Get phone details
    final PhoneNumber phoneNumber = provider.getPrimaryPhoneNumber();

    if (phoneNumber != null) {

      ConcernRolePhoneNumber concernRolePhoneNumberObj = ConcernRolePhoneNumberFactory.newInstance();
      PhoneForConcernRoleKey phoneForConcernRoleKey = new PhoneForConcernRoleKey();

      phoneForConcernRoleKey.concernRoleID = provider.getID();
      phoneForConcernRoleKey.phoneNumberID = phoneNumber.getID();

      ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls = concernRolePhoneNumberObj.readPhoneForConcernRole(
        phoneForConcernRoleKey);

      providerEnrollmentDetails.phoneNumber = phoneNumber.getNumber();
      providerEnrollmentDetails.phoneAreaCode = phoneNumber.getAreaCode();
      providerEnrollmentDetails.phoneCountryCode = phoneNumber.getCountryCode();
      providerEnrollmentDetails.phoneExtension = phoneNumber.getExtension();
      providerEnrollmentDetails.phoneType = concernRolePhoneNumberDtls.typeCode;
    }

    // BEGIN, CR00097430, SG
    // Assign Provider Enquiry details if Provider is enrolled from an Enquiry.
    curam.provider.impl.ProviderEnquiry providerEnquiry = provider.getProviderEnquiry();

    if (providerEnquiry != null) {
      providerEnrollmentDetails.relatedEnquiryExist = true;
      providerEnrollmentDetails.providerEnquiryID = providerEnquiry.getID();
    }
    // END, CR00097430

    // BEGIN, CR00106630, JSP
    if (provider.getReservationGracePeriod() > CPMConstants.kZeroLong) {
      providerEnrollmentDetails.reservationGracePeriodString = CPMConstants.kEmptyString
        + provider.getReservationGracePeriod();
    }
    providerEnrollmentDetails.reservationGracePeriod = provider.getReservationGracePeriod();
    // END, CR00106630

    // BEGIN, CR00123182, GP
    // BEGIN, CR00132242, GP
    providerEnrollmentDetails.overrideMDRInd = provider.isOverrideMDR();
    // END, CR00132242
    // END, CR00123182

    return providerEnrollmentDetails;
  }

  /**
   * Suspends the Provider from providing the service to the clients.
   *
   * @param details
   * Contains the reason for suspension and Concern Role ID for a
   * provider.
   * @return ProviderReasonStatusUpdateDetails Contains the reason for
   * suspension and Concern Role ID for a Provider.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderReasonStatusUpdateDetails suspendProvider(
    ProviderReasonStatusUpdateDetails details) throws AppException,
      InformationalException {

    // Provider can be suspended only if the reason is entered
    if (StringHelper.isEmpty(details.reasonCode)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_REASON_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    ProviderKey providerKey = new ProviderKey();
    // Create instance of service layer Provider
    curam.provider.impl.Provider provider = providerDAO.get(
      details.providerConcernRoleID);

    if (details.liveContracts) {
      return details;
    }
    ContractManagement contractManagement = ContractManagementFactory.newInstance();

    for (ContractVersion contracts : provider.getContracts()) {
      if (contracts.getContractType().equals(CONTRACTTYPEEntry.FLATRATE)
        && contracts.getLifecycleState().equals(CONTRACTSTATUSEntry.LIVE)) {
        TerminateContractDetails terminateContractDetails = new TerminateContractDetails();

        terminateContractDetails.contractVersionID = contracts.getID();
        terminateContractDetails.versionNo = contracts.getVersionNo();
        // BEGIN, CR00304343, GA
        terminateContractDetails.terminationReason = ContractTerminationReasonEntry.PROVIDERSUSPENDED.getCode();
        contractManagement.terminateContract(terminateContractDetails);
        // END, CR00304343
      }
    }

    // suspend the provider and return the concernRoleID
    provider.suspend(details.reasonCode, details.versionNo);

    String status = ProviderStatusEntry.SUSPENDED.getCode();

    setProviderStatusHistory(provider, details.reasonCode, status);
    providerKey.providerConcernRoleID = details.providerConcernRoleID;

    ValidationHelper.failIfErrorsExist();

    return details;
  }

  /**
   * Rejects the Provider.
   *
   * @param details
   * Contains the reason for rejection and Provider Concern Role ID.
   * @return ProviderKey Contains the Concern Role ID for a Provider.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderKey rejectProvider(ProviderRejectReasonUpdateDetails details)
    throws AppException, InformationalException {

    // Provider can be rejected only if the reason is entered
    if (StringHelper.isEmpty(details.reasonCode)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_REASON_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

    }
    ProviderKey providerKey = new ProviderKey();
    // Create instance of service layer Provider
    curam.provider.impl.Provider provider = providerDAO.get(
      details.providerConcernRoleID);

    provider.reject(details.reasonCode, details.versionNo);

    String status = ProviderStatusEntry.REJECTED.getCode();

    setProviderStatusHistory(provider, details.reasonCode, status);

    providerKey.providerConcernRoleID = details.providerConcernRoleID;

    ValidationHelper.failIfErrorsExist();
    // suspend the provider and return the concernRoleID
    return providerKey;
  }

  // BEGIN, CR00407056, VT
  /**
   * Closes the Provider if no longer providing the service.
   *
   * @param details
   * Contains the Concern Role ID and status fields for a Provider.
   * @return ProviderKey Contains the Concern Role ID for a Provider.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0.5.4, 
   * replaced with {@link Provider#performCloseProvider(ProviderStatusDetails}
   */
  // END, CR00407056
  @Deprecated
  public ProviderKey closeProvider(ProviderStatusUpdateDetails details)
    throws AppException, InformationalException {

    ProviderKey providerKey = new ProviderKey();

    // Create instance of service layer Provider
    curam.provider.impl.Provider provider = providerDAO.get(
      details.providerConcernRoleID);

    for (ContractVersion contracts : provider.getContracts()) {
      if (contracts.getContractType().equals(CONTRACTTYPEEntry.FLATRATE)
        && contracts.getLifecycleState().equals(CONTRACTSTATUSEntry.LIVE)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_LIVE_CONTRACTS_PRESENT_PROVIDER_CANNOT_BE_CLOSED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }
    }
    
    // BEGIN, CR00406403, SS
    final Placement placement = PlacementFactory.newInstance();
    final ProviderOfferingIDAndDateTimeKey offeringIDAndDateTimeKey = new ProviderOfferingIDAndDateTimeKey();

    for (final ProviderOffering providerOffering : provider.getProviderOfferings()) {
      offeringIDAndDateTimeKey.providerOfferingID = providerOffering.getID();
      offeringIDAndDateTimeKey.currentDateTime = DateTime.getCurrentDateTime();
      offeringIDAndDateTimeKey.placementStatus = RECORDSTATUS.NORMAL;
      final PlacementDtlsList placementDtlsList = placement.searchPlacementsByProviderOffering(
        offeringIDAndDateTimeKey);

      if (0 < placementDtlsList.dtls.size()) {
        ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_ACTIVE_PLACEMENTS_PRESENT_CANNOT_BE_CLOSED(),
          ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }
    }

    final ServiceDelivery serviceDelivery = ServiceDeliveryFactory.newInstance();
    final SearchByProvider searchByProvider = new SearchByProvider();

    searchByProvider.providerID = provider.getID();
    final ServiceDeliveryDtlsList serviceDeliveryDtlsList = serviceDelivery.searchByProvider(
      searchByProvider);

    for (final ServiceDeliveryDtls serviceDeliveryDtls : serviceDeliveryDtlsList.dtls.items()) {
      final SERVICEDELIVERYSTATUSEntry servicedeliverystatusEntry = SERVICEDELIVERYSTATUSEntry.get(
        serviceDeliveryDtls.status);

      if (SERVICEDELIVERYSTATUSEntry.OPEN.equals(servicedeliverystatusEntry)
        || SERVICEDELIVERYSTATUSEntry.SUBMITTED.equals(
          servicedeliverystatusEntry)
          || SERVICEDELIVERYSTATUSEntry.INPROGRESS.equals(
            servicedeliverystatusEntry)
            || SERVICEDELIVERYSTATUSEntry.NOTSTARTED.equals(
              servicedeliverystatusEntry)) {
        ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_ACTIVE_SERVICEDELIVERIES_PRESENT_CANNOT_BE_CLOSED(),
          ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }
    }
    // END, CR00406403


    // BEGIN, CR00200254, RPB
    // Current date time should be set as the provider end
    // date.
    provider.setDateTimeRange(
      new DateTimeRange(provider.getDateTimeRange().start(),
      DateTime.getCurrentDateTime()));
    // END, CR00200254

    provider.close(details.versionNo);

    // Now read and set the end date of ConcernRole
    // variables for concern role manipulation
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    // Read Concern role
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.providerConcernRoleID;
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Enrollment Date Later Than End Date.
    if (!concernRoleDtls.creationDate.isZero()
      && concernRoleDtls.creationDate.after(Date.getCurrentDate())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new curam.util.exception.AppException(curam.message.PROVIDER.ERR_PROVIDER_XFV_ENDDATE_MUST_NOT_BE_EARLIER_THAN_ENROLLMENT_DATE).arg(Date.getCurrentDate()).arg(
          concernRoleDtls.creationDate),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Set the end date and status to closed and modify ConcernRole
    concernRoleDtls.endDate = Date.getCurrentDate();
    concernRoleDtls.statusCode = CONCERNROLESTATUS.CLOSED;
    concernRoleObj.modify(concernRoleKey, concernRoleDtls);

    String status = ProviderStatusEntry.CLOSED.getCode();

    setProviderStatusHistory(provider, CPMConstants.kEmptyString, status);
    providerKey.providerConcernRoleID = details.providerConcernRoleID;

    // Send Provider close Notification
    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();
    ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = provider.getID();
    providerNotificationKey.event = ProviderNotificationEvent.CLOSURE;
    providerNotification.sendNotification(providerNotificationKey);

    return providerKey;
  }

  /**
   * Reopens the Provider for providing the service to the clients.
   *
   * @param details
   * Contains the Concern Role ID and status fields for a Provider.
   * @return ProviderKey Contains the Concern Role ID for a Provider.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderKey reopenProvider(ProviderStatusUpdateDetails details)
    throws AppException, InformationalException {

    ProviderKey providerKey = new ProviderKey();

    // Create instance of service layer Provider
    curam.provider.impl.Provider provider = providerDAO.get(
      details.providerConcernRoleID);

    // BEGIN, CR00341713, GP
    provider.setDateTimeRange(
      provider.getDateTimeRange().newEndDate(DateTime.kZeroDateTime));
    // END, CR00341713
    
    provider.reopen(details.versionNo);

    // Now read and remove the end date of ConcernRole
    // variables for concern role manipulation
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    // Read Concern role
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.providerConcernRoleID;
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Remove the end date and status to open and modify ConcernRole
    concernRoleDtls.endDate = Date.kZeroDate;
    concernRoleDtls.statusCode = CONCERNROLESTATUS.CURRENT;

    concernRoleObj.modify(concernRoleKey, concernRoleDtls);

    String status = ProviderStatusEntry.OPEN.getCode();

    setProviderStatusHistory(provider, CPMConstants.kEmptyString, status);

    providerKey.providerConcernRoleID = details.providerConcernRoleID;

    return providerKey;
  }

  /**
   * Reads the status history of Provider life cycle.
   *
   * @param providerConcernRoleKey
   * Contains Concern Role ID for a Provider.
   * @return ProviderStatusHistoryDetailsList Contains Provider Status History
   * details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderStatusHistoryDetailsList viewProviderStatusHistory(
    ProviderConcernRoleKey providerConcernRoleKey) throws AppException,
      InformationalException {

    // Setting the values to facade layer struct
    ProviderStatusHistoryDetailsList providerStatusHistoryDetailsList = new ProviderStatusHistoryDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerConcernRoleKey.providerConcernRoleID);
    final Set<curam.provider.impl.ProviderStatusHistory> providerStatusHistories = providerStatusHistoryDAO.searchByProvider(
      provider);

    ProviderStatusHistoryDtls providerStatusHistoryDtls;
    // BEGIN, CR00206945, AS
    List<ProviderStatusHistoryDtls> providerStatusHistoryDtlslist = new ArrayList<ProviderStatusHistoryDtls>();

    // END, CR00206945
    for (final curam.provider.impl.ProviderStatusHistory providerStatusHistory : providerStatusHistories) {

      providerStatusHistoryDtls = new ProviderStatusHistoryDtls();

      providerStatusHistoryDtls.effectiveDateTime = providerStatusHistory.getEffectiveDateTime();
      providerStatusHistoryDtls.providerConcernRoleID = providerStatusHistory.getProvider().getID();
      providerStatusHistoryDtls.providerStatusHistoryID = providerStatusHistory.getID();
      providerStatusHistoryDtls.reason = providerStatusHistory.getReason();
      providerStatusHistoryDtls.recordStatus = providerStatusHistory.getProviderRecordStatus();

      // BEGIN, CR00233823, PS
      User user = userDAO.get(providerStatusHistory.getUserName());

      providerStatusHistoryDtls.userName = user.getFullName();
      // END, CR00233823

      // BEGIN, CR00206945, AS
      providerStatusHistoryDtlslist.add(providerStatusHistoryDtls);
      // END, CR00206945
    }
    // BEGIN, CR00206945, AS
    for (ProviderStatusHistoryDtls statusHistoryDtls : sortProviderStatusHistoryByDateTime(
      providerStatusHistoryDtlslist)) {
      providerStatusHistoryDetailsList.detailsList.dtls.addRef(
        statusHistoryDtls);
    }
    // END, CR00206945
    return providerStatusHistoryDetailsList;
  }

  /**
   * Searches the Providers and open Enquiries based on search criteria
   * specified.
   *
   * @param key
   * Contains search criteria.
   * @return SearchProviderAndEnquiryConfirmationDetails Contains Provider and
   * Enquiry search results.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchProviderAndEnquiryConfirmationDetails searchProvidersAndEnquiries(
    SearchProviderEnrollmentKey key) throws AppException,
      InformationalException {

    // Return struct
    SearchProviderAndEnquiryConfirmationDetails searchProviderAndEnquiryConfirmationDetails = new SearchProviderAndEnquiryConfirmationDetails();

    // Search key for provider enquiry
    SearchProviderEnquiryKey searchProviderEnquiryKey = new SearchProviderEnquiryKey();

    // assign the providerKey to providerEnquiry key
    searchProviderEnquiryKey.referenceNumber = key.referenceNumber;
    searchProviderEnquiryKey.name = key.name;
    searchProviderEnquiryKey.street1 = key.street1;
    searchProviderEnquiryKey.city = key.city;
    searchProviderEnquiryKey.enquiryStatus = ProviderStatus.OPEN;
    // Throw an exception if search criteria empty
    if (key.name.equals(CPMConstants.kEmptyString)
      && key.street1.equals(CPMConstants.kEmptyString)
      && key.city.equals(CPMConstants.kEmptyString)
      && key.referenceNumber.equals(CPMConstants.kEmptyString)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_SOME_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    if (!key.referenceNumber.equals(CPMConstants.kEmptyString)
      && (!key.name.equals(CPMConstants.kEmptyString)
        || !key.street1.equals(CPMConstants.kEmptyString)
        || !key.city.equals(CPMConstants.kEmptyString))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_REFERENCE_NO_IS_SPECIFIED_OTHER_SEARCH_CRITERIA_IS_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    SearchProviderDetailsList searchProviderDetailList = new SearchProviderDetailsList();

    final Set<curam.provider.impl.Provider> providers = providerDAO.searchByProviderEnrollment(
      key.name, key.referenceNumber, key.searchByName,
      key.searchByReferenceNumber, key.street1, key.city, key.searchByStreet1,
      key.searchByCity, key.addressTypeCode, key.cityTypeCode);

    for (final curam.provider.impl.Provider provider : providers) {
      searchProviderDetailList.details.addRef(getProviderSearchFields(provider));
    }
    searchProviderAndEnquiryConfirmationDetails.providerList = sortProviders(
      searchProviderDetailList);
    ProviderEnquirySummaryDetailsList list = new ProviderEnquirySummaryDetailsList();

    // populate facade layer ProviderEnquirySummaryDetailsList object
    final Set<curam.provider.impl.ProviderEnquiry> providerEnquiries = providerEnquiryDAO.searchBy(
      searchProviderEnquiryKey.name, key.referenceNumber,
      searchProviderEnquiryKey.street1, searchProviderEnquiryKey.city,
      searchProviderEnquiryKey.searchByName,
      searchProviderEnquiryKey.searchByReferenceNumber,
      searchProviderEnquiryKey.searchByStreet1,
      searchProviderEnquiryKey.searchByCity,
      searchProviderEnquiryKey.addressLine1Type,
      searchProviderEnquiryKey.cityTypeCode,
      searchProviderEnquiryKey.enquiryStatus);

    for (final curam.provider.impl.ProviderEnquiry providerEnquiry : providerEnquiries) {
      list.enquriySummaryDetails.addRef(
        getProviderEnquiryFields(providerEnquiry));
    }
    // Read the search results for provider enquiries
    searchProviderAndEnquiryConfirmationDetails.enquiryList = sortProviderEnquries(
      list);

    ValidationHelper.failIfErrorsExist();

    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(
      searchProviderAndEnquiryConfirmationDetails.providerList.informationalMsgDtlsOpt);
    // END, CR00292696
    
    return searchProviderAndEnquiryConfirmationDetails;

  }

  /**
   * Registers the Provider as Person and relate the person as provider member
   * with a role of Provider.
   *
   * @param details
   * Contains Person registration details.
   * @return PersonRegistrationResult Person registration result.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PersonRegistrationResult registerProviderPerson(
    RegisterProviderPersonDetails details) throws AppException,
      InformationalException {
    // return object
    PersonRegistrationResult personRegistrationResult = new PersonRegistrationResult();

    // create a person object
    curam.core.facade.intf.Person personObj = PersonFactory.newInstance();

    // BEGIN, CR00097531,SK
    // create a provider
    final curam.provider.impl.Provider provider = providerDAO.get(
      details.providerConcernRoleID);

    // BEGIN, CR00320064, SSK
    final Calendar serverEquivalentRegisterationCalendar = TimeZoneUtil.getEquivalentServerCalendar(
      details.details.personRegistrationDetails.registrationDate);
    final Date serverEquivalentRegisterationDate = new Date(
      serverEquivalentRegisterationCalendar);
   
    // the person registration date must be equals to Provider enrollment date.
    if (!serverEquivalentRegisterationDate.equals(provider.getStartDate())) {
      // END, CR00320064
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PERSON_REGISTRATION_DATE_EQUALS_PROVIDER_ENROLLMENT_DATE(
          details.details.personRegistrationDetails.registrationDate,
          provider.getStartDate(), provider.getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    ValidationHelper.failIfErrorsExist();
    
    // BEGIN, CR00320064, SSK
    details.details.personRegistrationDetails.registrationDate = provider.getStartDate();
    details.details.personRegistrationDetails.relatedConcernRoleID = details.providerConcernRoleID;
    // END, CR00320064
    // register a person
    personRegistrationResult = personObj.register(details.details);

    // insert the person as provider member with a role of Provider
    // create an provider member object
    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.newInstance();

    final curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
      personRegistrationResult.registrationIDDetails.concernRoleID);

    // populate the details.
    providerMember.setProviderOrganization(provider);
    providerMember.setParty(concernRole);
    providerMember.setRole(ProviderMemberRoleEntry.PROVIDER);
    
    // BEGIN, CR00320064, SSK
    providerMember.setDateRange(
      new DateRange(details.details.personRegistrationDetails.registrationDate,
      null));
    DateTime registerationDateTime = new DateTime(
      serverEquivalentRegisterationCalendar);

    providerMember.setDateTimeRange(
      new DateTimeRange(registerationDateTime, null));
    // END, CR00320064
    // END, CR00097531
    // insert the provider member record
    providerMember.insert();

    return personRegistrationResult;
  }
  
  /**
   * Adds the registered Person as Provider members with the role of Provider.
   *
   * @param details
   * Contains Provider registration option details
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addRegPersonAsProvider(ProviderRegistrationOptionDetails details)
    throws AppException, InformationalException {

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.newInstance();
    // BEGIN, CR00097531,SK
    final curam.provider.impl.Provider provider = providerDAO.get(
      details.key.providerConcernRoleID);

    final curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
      details.key.concernRoleID);

    // populate the details.
    providerMember.setProviderOrganization(provider);
    providerMember.setParty(concernRole);
    providerMember.setRole(ProviderMemberRoleEntry.PROVIDER);
    providerMember.setDateRange(new DateRange(provider.getStartDate(), null));
    // BEGIN, CR00320064, SSK
    final DateTimeRange providerMemberDateRange = new DateTimeRange(
      provider.getStartDate().getDateTime(), null);

    providerMember.setDateTimeRange(providerMemberDateRange);
    // END, CR00320064
    // END, CR00097531

    // insert the person as provider member with a role of Provider
    providerMember.insert();

  }

  /**
   * Returns the list of the Provider Categories for a Provider.
   *
   * @param key
   * Contains Concern Role ID for a Provider.
   *
   * @return ProviderCategoryDetailsList Contains a list of provider categories.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderCategoryDetailsList listProviderCategories(
    ProviderConcernRoleKey key) throws AppException, InformationalException {

    // return struct
    ProviderCategoryDetailsList providerCategoryDetailsList = new ProviderCategoryDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      key.providerConcernRoleID);
    final Set<curam.provider.impl.ProviderCategoryPeriod> providerCategoryPeriods = providerCategoryPeriodDAO.searchBy(
      provider);

    ProviderCategoryDetails providerCategoryDetails;

    for (final ProviderCategoryPeriod providerCategoryPeriod : providerCategoryPeriods) {

      providerCategoryDetails = new ProviderCategoryDetails();

      providerCategoryDetails.providerTypeCategory = ProviderCategoryNameEntry.get(providerCategoryPeriod.getCategory().getCode()).getCode();
      providerCategoryDetails.endDate = providerCategoryPeriod.getDateRange().end();
      // BEGIN, CR00305071, SS
      providerCategoryDetails.endReason = providerCategoryPeriod.getEndReason();
      // END, CR00305071
      providerCategoryDetails.primaryInd = providerCategoryPeriod.isPrimary();
      providerCategoryDetails.providerCategoryID = providerCategoryPeriod.getID();
      providerCategoryDetails.recordStatus = providerCategoryPeriod.getLifecycleState().getCode();
      providerCategoryDetails.startDate = providerCategoryPeriod.getDateRange().start();
      // BEGIN, CR00206743, AS
      providerCategoryDetails.versionNo = providerCategoryPeriod.getVersionNo();
      // END, CR00206743

      providerCategoryDetailsList.details.addRef(providerCategoryDetails);
    }
    return sortProviderCategories(providerCategoryDetailsList);
  }

  /**
   * Creates a Category for a Provider with the Category details specified.
   *
   * @param details
   * Contains the Provider Category details.
   *
   * @return ProviderCategoryPeriodKey Contains the Provider Category Period
   * key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderCategoryPeriodKey createProviderCategory(
    ProviderCategoryDetails details) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderCategoryPeriod providerCategoryPeriod = providerCategoryPeriodDAO.newInstance();

    setProviderCategoryPeriod(providerCategoryPeriod, details);

    final curam.provider.impl.Provider provider = providerDAO.get(
      details.providerConcernRoleID);

    providerCategoryPeriod.setProvider(provider);

    final ProviderCategoryPeriod primaryProviderCategoryPeriod = provider.getPrimaryProviderCategoryPeriod();

    if (details.primaryInd) {

      // Call to remove primary from provider category
      primaryProviderCategoryPeriod.removeAsPrimaryProviderCategory();

    }

    // Calling the entity method to insert the details
    providerCategoryPeriod.insertProviderCategoryPeriod();

    ProviderCategoryPeriodKey providerCategoryPeriodKey = new ProviderCategoryPeriodKey();

    providerCategoryPeriodKey.providerCategoryID = providerCategoryPeriod.getID();

    curam.provider.impl.ProviderType providerType = providerTypeDAO.newInstance();

    // Creating an instance for the Standard dtls struct and setting the
    // values
    providerType.setProviderCategoryPeriod(providerCategoryPeriod);
    providerType.setType(details.category);

    // Calling the entity method to insert the details
    providerType.insert();
    return providerCategoryPeriodKey;
  }

  /**
   * Cancels a Category for a Provider.
   *
   * @param key
   * Contains the Provider Category Period key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deleteProviderCategory(KeyVersionDetails key)
    throws AppException, InformationalException {

    final curam.provider.impl.ProviderCategoryPeriod providerCategoryPeriod = providerCategoryPeriodDAO.get(
      key.id);

    final Set<curam.provider.impl.ProviderType> providerTypes = providerTypeDAO.searchBy(
      providerCategoryPeriod);

    for (final curam.provider.impl.ProviderType providerType : providerTypes) {
      providerType.cancel(providerType.getVersionNo());
    }

    providerCategoryPeriod.cancel(key.version);

  }

  /**
   * Modifies a Provider Category details.
   *
   * @param details
   * Contains the Provider Category details to be modified.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyProviderCategory(ProviderCategoryDetails details)
    throws AppException, InformationalException {

    // Provider Types selected by the user
    final StringList providerTypeCodes = StringUtil.tabText2StringListWithTrim(
      details.targetProviderTypes);

    if (providerTypeCodes.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XRV_ATLEAST_ONE_PROVIDER_TYPE_MUST_BE_EXIST(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else {
      details.category = (String) providerTypeCodes.get(0);
    }

    final curam.provider.impl.ProviderCategoryPeriod providerCategoryPeriod = providerCategoryPeriodDAO.get(
      details.providerCategoryID);

    // Validation to be done in facade
    String category = curam.util.type.CodeTable.getParentCode(
      ProviderTypeNameEntry.TABLENAME, details.category);

    if (ProviderCategoryNameEntry.get(category) != null
      && !ProviderCategoryNameEntry.get(category).getCode().equals(
        ProviderCategoryNameEntry.get(providerCategoryPeriod.getCategory().getCode()).getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERCATEGORYExceptionCreator.ERR_PROVIDERCATEGORY_XRV_CATEGORY_CANNOT_BE_UPDATED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    ValidationHelper.failIfErrorsExist();

    setProviderCategoryPeriod(providerCategoryPeriod, details);

    final curam.provider.impl.Provider provider = providerDAO.get(
      details.providerConcernRoleID);

    ProviderCategoryPeriod primaryProviderCategoryPeriod = provider.getPrimaryProviderCategoryPeriod();

    providerCategoryPeriod.modifyProviderCategoryPeriod(
      primaryProviderCategoryPeriod);
    providerCategoryPeriod.modify(details.versionNo);
    if (details.primaryInd
      && primaryProviderCategoryPeriod.getID() != details.providerCategoryID) {

      // Call to remove primary from provider category
      primaryProviderCategoryPeriod.removeAsPrimaryProviderCategory();

    }

    for (final curam.provider.impl.ProviderType providerType : providerTypeDAO.searchBy(
      providerCategoryPeriod)) {
      if (!providerTypeCodes.contains(providerType.getType())) {
        // Types that are removed.
        providerType.remove(providerType.getVersionNo());
      } else {
        // Types that are already in the DB
        providerTypeCodes.remove(providerType.getType());
      }

    }

    curam.provider.impl.ProviderType providerType;

    for (final String providerTypeCode : providerTypeCodes.items()) {

      // Creating an instance for the Standard dtls struct and setting the
      // values
      providerType = providerTypeDAO.newInstance();

      providerType.setProviderCategoryPeriod(providerCategoryPeriod);
      providerType.setType(providerTypeCode);
      // Calling the entity method to insert the details
      providerType.insert();
    }

  }

  /**
   * Reads the Provider Category details and the details of provider types
   * selected for that category.
   *
   * @param key
   * Contains the Provider Category period key.
   *
   * @return ViewProviderCategoryDetails Contains the Provider Category and
   * types selected.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewProviderCategoryDetails viewProviderCategory(
    ProviderCategoryPeriodKey key) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderCategoryPeriod providerCategoryPeriod = providerCategoryPeriodDAO.get(
      key.providerCategoryID);

    final Set<curam.provider.impl.ProviderType> providerTypes = providerTypeDAO.searchBy(
      providerCategoryPeriod);

    ViewProviderCategoryDetails viewProviderCategoryDetails = new ViewProviderCategoryDetails();

    viewProviderCategoryDetails.providerCategory.comments = providerCategoryPeriod.getComments();
    viewProviderCategoryDetails.providerCategory.endDate = providerCategoryPeriod.getDateRange().end();
    viewProviderCategoryDetails.providerCategory.endReason = providerCategoryPeriod.getEndReason();
    viewProviderCategoryDetails.providerCategory.primaryInd = providerCategoryPeriod.isPrimary();
    viewProviderCategoryDetails.providerCategory.providerCategoryID = providerCategoryPeriod.getID();
    viewProviderCategoryDetails.providerCategory.providerConcernRoleID = providerCategoryPeriod.getProvider().getID();
    viewProviderCategoryDetails.providerCategory.recordStatus = providerCategoryPeriod.getLifecycleState().getCode();
    viewProviderCategoryDetails.providerCategory.startDate = providerCategoryPeriod.getDateRange().start();
    viewProviderCategoryDetails.providerCategory.versionNo = providerCategoryPeriod.getVersionNo();

    viewProviderCategoryDetails.category = ProviderCategoryNameEntry.get(providerCategoryPeriod.getCategory().getCode()).getCode();

    ProviderTypeDtls providerTypeDtls;

    for (final curam.provider.impl.ProviderType providerType : providerTypes) {

      providerTypeDtls = new ProviderTypeDtls();

      providerTypeDtls.providerCategoryID = providerCategoryPeriod.getID();
      providerTypeDtls.providerTypeID = providerType.getID();
      providerTypeDtls.recordStatus = providerType.getLifecycleState().getCode();
      providerTypeDtls.type = providerType.getType();
      providerTypeDtls.versionNo = providerType.getVersionNo();

      viewProviderCategoryDetails.providerCategory.category = providerType.getType();

      viewProviderCategoryDetails.providerTypes.addRef(providerTypeDtls);

      viewProviderCategoryDetails.selectedProviderTypes += providerType.getType()
        + GeneralConstants.kTab;

    }

    String locale = curam.util.transaction.TransactionInfo.getProgramLocale();
    String category;

    ProviderTypeDetails providerTypeDetails;

    LinkedHashMap enalbledProviderTypesMap = CodeTable.getAllEnabledItems(
      ProviderTypeNameEntry.TABLENAME, locale);
    // BEGIN, CR00279254, MV
    Iterator enalbledProviderTypesIterator = enalbledProviderTypesMap.keySet().iterator();

    while (enalbledProviderTypesIterator.hasNext()) {

      Object enalbledProviderTypeObj = enalbledProviderTypesIterator.next();

      category = curam.util.type.CodeTable.getParentCode(
        ProviderTypeNameEntry.TABLENAME, enalbledProviderTypeObj.toString());

      if (category != null
        && ProviderCategoryNameEntry.get(category).equals(
          ProviderCategoryNameEntry.get(
            providerCategoryPeriod.getCategory().getCode()))) {

        providerTypeDetails = new ProviderTypeDetails();
        providerTypeDetails.providerType = (String) enalbledProviderTypeObj;
        providerTypeDetails.providerTypeCodeString = (String) enalbledProviderTypeObj;

        viewProviderCategoryDetails.initialsTypes.addRef(providerTypeDetails);

      }
    }
    // END, CR00279254
    // return the details
    return viewProviderCategoryDetails;

  }

  /**
   * Reads the context details for a Provider.
   *
   * @param key
   * ProviderConcernRoleKey Contains the Provider concernroleID.
   *
   * @return ViewProviderSummaryDetails Contains the page context description.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewProviderSummaryDetails readProviderSummaryDetails(
    ProviderConcernRoleKey key) throws AppException, InformationalException {

    // creating viewProviderSummaryDetails struct
    ViewProviderSummaryDetails viewProviderSummaryDetails = new ViewProviderSummaryDetails();

    // Provider Entity
    curam.provider.impl.Provider provider = providerDAO.get(
      key.providerConcernRoleID);

    // Get the Provider Reference Number
    String refNumber = provider.getPrimaryAlternateID();

    // Set the summary details
    viewProviderSummaryDetails.details.concernRoleID = key.providerConcernRoleID;
    viewProviderSummaryDetails.details.providerName = provider.getName();
    viewProviderSummaryDetails.details.referenceNumber = refNumber;

    // construct the page context description
    viewProviderSummaryDetails.pageContextDescription = provider.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + refNumber;

    return viewProviderSummaryDetails;
  }

  /**
   * Populates city and address line 1 for the Provider.
   *
   * @param key
   * Contains Concern Role ID for a Provider.
   * @return SearchProviderDetails Contains Provider address line 1 and city.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchProviderDetails populateSearchData(ProviderConcernRoleKey key)
    throws AppException, InformationalException {

    // create instance of SearchProviderDetails
    SearchProviderDetails searchProviderDetails = new SearchProviderDetails();

    // create instance of providerKey
    ProviderKey providerKey = new ProviderKey();

    providerKey.providerConcernRoleID = key.providerConcernRoleID;

    // create the instance of concernRoleOBJ.
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = providerKey.providerConcernRoleID;

    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);
    // create instance of addressElementObj
    AddressElement addressElementObj = AddressElementFactory.newInstance();

    AddressKey addressKey = new AddressKey();

    addressKey.addressID = concernRoleDtls.primaryAddressID;
    AddressElementDtlsList addressElementDtlsList = addressElementObj.readAddressElementDetails(
      addressKey);

    int size = addressElementDtlsList.dtls.size();

    // loop the addressElmentdetailsList to fetch the city and addressLine1
    for (int i = 0; i < size; i++) {
      if (addressElementDtlsList.dtls.item(i).elementType.equals(
        ADDRESSELEMENTTYPE.CITY)) {
        searchProviderDetails.city = addressElementDtlsList.dtls.item(i).elementValue;
      } else if (addressElementDtlsList.dtls.item(i).elementType.equals(
        ADDRESSELEMENTTYPE.LINE1)) {
        searchProviderDetails.street1 = addressElementDtlsList.dtls.item(i).elementValue;
      }
    }

    return searchProviderDetails;
  }

  /**
   * Determines if a Provider has 'Live' flat rate contracts.
   *
   * @param providerKey
   * Contains Concern Role ID for a Provider.
   * @return ProviderFlatRateContract Contains the flat rate contract for a
   * Provider.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderFlatRateContract getFlatRateContractsForProvider(
    curam.cpm.facade.struct.ProviderKey providerKey) throws AppException,
      InformationalException {

    ProviderFlatRateContract flatRateContract = new ProviderFlatRateContract();

    curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerID);

    boolean liveContracts = false;

    for (ContractVersion contracts : provider.getContracts()) {
      if (contracts.getContractType().equals(CONTRACTTYPEEntry.FLATRATE)
        && contracts.getLifecycleState().equals(CONTRACTSTATUSEntry.LIVE)) {
        liveContracts = true;
      }
    }
    if (liveContracts) {
      flatRateContract.liveContracts = true;
    } else {
      flatRateContract.liveContracts = false;
    }

    return flatRateContract;
  }

  /**
   * Displays the informational message if the Provider's Preferred language
   * does not match any language in the user skills.
   *
   * @param providerKey
   * Contains Concern Role ID for a Provider.
   * @return InformationalMessageList Contains the list of informational
   * messages.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMessageList getProviderInformationals(
    ProviderKey providerKey) throws AppException, InformationalException {

    InformationalManager informationalManager = new InformationalManager();
    InformationalMessageList informationalMessageList = new InformationalMessageList();

    curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    // Read the skill types of organization user.
    curam.core.facade.intf.Organization organisationObj = curam.core.facade.fact.OrganizationFactory.newInstance();
    
    UserSkillListKey userSkillListKey = new UserSkillListKey();

    userSkillListKey.userSkillList.userName = TransactionInfo.getProgramUser();

    // BEGIN, CR00246086, SS
    // Find if the Preferred language of provider matches the any one of the
    // language of user if the skill type is "Languages".
    boolean isUserSkillLangMatched = false;

    // BEGIN, CR00332487, SK
    UserSkills listUserSkillDetails = organisationObj.getUserSkills(
      userSkillListKey);
    
    for (UserSkillDetails userSkillDetails : listUserSkillDetails.listUserSkillDetails.userSkillDtlsList.items()) {

      UserSkillLanguageReadMultiKey userSkillLanguageReadMultiKey = new UserSkillLanguageReadMultiKey();

      userSkillLanguageReadMultiKey.userSkillID = userSkillDetails.dtls.userSkillID;

      UserSkillLanguagesDtlsList userSkillLanguagesDtlsList = UserSkillLanguagesFactory.newInstance().searchByUserSkillID(
        userSkillLanguageReadMultiKey);

      if (RECORDSTATUSEntry.NORMAL.getCode().equals(
        userSkillDetails.dtls.recordStatus)) {
        // END, CR00332487
        
        for (UserSkillLanguagesDtls userSkillLanguagesDtls :
          userSkillLanguagesDtlsList.dtls) {

          if (CodeTable.getOneItemForUserLocale(LANGUAGE.TABLENAME, provider.getPreferredLanguage().getCode()).equals(
            CodeTable.getOneItemForUserLocale(LANGUAGE.TABLENAME,
            userSkillLanguagesDtls.languageCode))) {

            isUserSkillLangMatched = true;
            break;
          }
        }
      }
    }

    // BEGIN, CR00234402, GP
    if (!isUserSkillLangMatched) {
      // END, CR00234402
      // END, CR00246086
      AppException message = PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_PREFFERED_LANGUAGE_DOES_NOT_MATCH_USER_SKILLS_LANGUAGE(
        LANGUAGEEntry.get(provider.getPreferredLanguage().getCode()).getCodeTableItemIdentifier());

      informationalManager.addInformationalMsg(message,
        CPMConstants.kEmptyString,
        InformationalElement.InformationalType.kWarning);
    }

    String warnings[] = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMessage infoMessage = new InformationalMessage();

      infoMessage.messageTest = warnings[i];
      informationalMessageList.dtls.addRef(infoMessage);
    }

    return informationalMessageList;
  }

  // BEGIN, CR00124460, SK

  /**
   * Displays the informational message if the Provider has any open incidents
   * when the provider is closed.
   *
   *
   * @param providerKey
   * Contains Concern Role ID for a Provider.
   * @return The list of informational messages.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMessageList getCloseProviderInformational(
    ProviderKey providerKey) throws AppException, InformationalException {

    InformationalManager informationalManager = new InformationalManager();
    InformationalMessageList informationalMessageList = new InformationalMessageList();

    curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    // Show the informational if there are any open incidents recorded against
    // Provider.
    boolean showInformational = false;

    List<ProviderIncident> providerIncidents = provider.getIncidents();

    for (final ProviderIncident providerIncident : providerIncidents) {
      if (providerIncident.getIncident().getLifecycleState().equals(
        INCIDENTSTATUSEntry.OPEN)) {
        showInformational = true;
      }
    }
    // Assign informational messages to return struct
    if (showInformational) {
      AppException message = PROVIDERExceptionCreator.INF_PROVIDER_XRV_HAS_OPEN_PROVIDER_INCIDENTS();

      informationalManager.addInformationalMsg(message,
        CPMConstants.kEmptyString,
        InformationalElement.InformationalType.kWarning);
    }

    String warnings[] = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMessage infoMessage = new InformationalMessage();

      infoMessage.messageTest = warnings[i];
      informationalMessageList.dtls.addRef(infoMessage);
    }

    return informationalMessageList;
  }

  // END, CR00124460

  // BEGIN, CR00090700, SP
  /**
   * Lists the Delivery Methods.
   *
   * @return ListDeliveryMethodDetails Contains the list of Delivery Methods.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListDeliveryMethodDetails listDeliveryMethod() throws AppException,
      InformationalException {

    // AdminDeliveryMethod object.
    curam.core.intf.AdminDeliveryMethod AdminDeliveryMethodObj = curam.core.fact.AdminDeliveryMethodFactory.newInstance();

    // Details to be returned
    ListDeliveryMethodDetails listDeliveryMethodDetails = new ListDeliveryMethodDetails();

    // Struct to hold details
    ListAllDeliveryMethodsIn listAllDeliveryMethodsIn = new ListAllDeliveryMethodsIn();

    // Set Initial Details
    listAllDeliveryMethodsIn.productID = 0;
    listAllDeliveryMethodsIn.benefitMethodsInd = true;
    listAllDeliveryMethodsIn.allMethodsInd = false;

    // Read list of phone numbers
    listDeliveryMethodDetails.listAllDeliveryMethodsResult = AdminDeliveryMethodObj.listAllDeliveryMethods(
      listAllDeliveryMethodsIn);

    // Return Delivery Method Details list
    return listDeliveryMethodDetails;

  }

  // END, CR00090700

  // BEGIN, CR00236076, AK
  /**
   * Searches for a Person based on the search criteria.
   *
   * @param key
   * Contains the search criteria.
   * @return PersonSearchResult Contains the Person search results.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 as this method is not used anywhere.
   */
  @Deprecated
  // END, CR00236076
  public PersonSearchResult searchProviderPerson(ProviderPersonSearchKey key)
    throws AppException, InformationalException {
    // Person Search object and key.
    curam.core.facade.intf.Person personSearchObj = curam.core.facade.fact.PersonFactory.newInstance();

    // Details to be returned.
    curam.core.facade.struct.PersonSearchResult personSearchResult = new curam.core.facade.struct.PersonSearchResult();

    // call core person search
    personSearchResult = personSearchObj.search(key.providerPersonKey);

    final ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      key.providerConcernRoleID);

    PersonSearchResult filteredPersonSearchResult = new PersonSearchResult();

    for (int i = 0; i
      < personSearchResult.personSearchResult.details.dtls.size(); i++) {

      boolean isAlreadyRegAsProvider = false;

      for (final curam.provider.impl.ProviderMember providerMember : providerOrganization.getProviderMembers()) {

        if (personSearchResult.personSearchResult.details.dtls.item(i).concernRoleID
          == providerMember.getParty().getID()) {
          isAlreadyRegAsProvider = true;
          break;
        }
      }

      if (!isAlreadyRegAsProvider) {
        filteredPersonSearchResult.personSearchResult.details.dtls.addRef(
          personSearchResult.personSearchResult.details.dtls.item(i));
      }
    }

    // Return the details.
    return filteredPersonSearchResult;

  }

  // BEGIN, CR00141253, ABS
  /**
   * Retrieves the list of provider types for the primary category.
   *
   * @param providerConcernRoleKey
   * Contains provider ID.
   *
   * @return List of provider types for the provider category.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewProviderCategoryDetails viewTypesForPrimaryCategory(
    curam.cpm.facade.struct.ProviderConcernRoleKey providerConcernRoleKey) throws AppException, InformationalException {

    ViewProviderCategoryDetails viewProviderCategoryDetails = new ViewProviderCategoryDetails();

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerConcernRoleKey.providerKey.providerConcernRoleID);
    final curam.provider.impl.ProviderCategoryPeriod providerCategoryPeriod = providerCategoryPeriodDAO.readPrimaryCategoryFor(
      provider);

    ProviderCategoryPeriodKey providerCategoryPeriodKey = new ProviderCategoryPeriodKey();

    providerCategoryPeriodKey.providerCategoryID = providerCategoryPeriod.getID();
    viewProviderCategoryDetails = viewProviderCategory(
      providerCategoryPeriodKey);
    return viewProviderCategoryDetails;

  }

  // END, CR00141253

  /**
   * Validates concern role details of the provider for modify operation.
   *
   * @param providerEnrollmentDetails
   * contains provider enrollment details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void validateConcernRoleDetails(
    // END, CR00177241
    ProviderEnrollmentDetails providerEnrollmentDetails) throws AppException,
      InformationalException {

    if (StringHelper.isEmpty(providerEnrollmentDetails.providerName.trim())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_NAME_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (providerEnrollmentDetails.providerName.trim().length()
      > ProviderAdapter.kMaxLength_name) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_NAME_IS_TOO_LONG(
          ProviderAdapter.kMaxLength_name),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (StringHelper.isEmpty(providerEnrollmentDetails.prefLanguage.trim())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_PREFERRED_LANGUAGE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (StringHelper.isEmpty(providerEnrollmentDetails.prefCommMethod.trim())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_PREFERRED_COMMUICATION_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (providerEnrollmentDetails.comments.length()
      > ConcernRoleAdapter.kMaxLength_comments) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_COMMENT_IS_TOO_LONG(
          ConcernRoleAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * Validates the physical capacity and designated capacity.
   *
   * @param providerEnrollmentDetails
   * Contains provider enrollment details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void validateProviderPhysicalAndDesignatedCapacityDDetails(
    // END, CR00177241
    ProviderEnrollmentDetails providerEnrollmentDetails) throws AppException,
      InformationalException {
    // Manipulation variable
    int physicalCapacityIntType = kMinimumCapacity;
    int designatedCapacityIntType = kMinimumCapacity;
    String physicalCapacity = providerEnrollmentDetails.physicalCapacityString.trim();
    String designatedCapacity = providerEnrollmentDetails.designatedCapacityString.trim();

    if (physicalCapacity.length() > kMinimumCapacity) {
      try {
        // Convert physicalCapacity String to int
        physicalCapacityIntType = Integer.parseInt(physicalCapacity);

        providerEnrollmentDetails.physicalCapacity = physicalCapacityIntType;

      } catch (NumberFormatException exception) {
        throw PROVIDERExceptionCreator.ERR_PROVIDER_FV_PROVIDER_PHYSICAL_CAPACITY_INVALID();
      }

      // physicalCapacity cannot be less than zero
      if (physicalCapacityIntType <= kMinimumCapacity) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new curam.util.exception.AppException(
            curam.message.PROVIDER.ERR_PROVIDER_FV_PROVIDER_PHYSICAL_CAPACITY_GT_ZERO),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

    if (designatedCapacity.length() > kMinimumCapacity) {
      try {
        // Convert designatedCapacity String to int
        designatedCapacityIntType = Integer.parseInt(designatedCapacity);

        providerEnrollmentDetails.designatedCapacity = designatedCapacityIntType;

      } catch (NumberFormatException exception) {
        throw PROVIDERExceptionCreator.ERR_PROVIDER_FV_PROVIDER_DESIGNATED_CAPACITY_INVALID();
      }

      // designatedCapacity cannot be less than zero
      if (designatedCapacityIntType <= kMinimumCapacity) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new curam.util.exception.AppException(
            curam.message.PROVIDER.ERR_PROVIDER_FV_PROVIDER_DESIGNATED_CAPACITY_GT_ZERO),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);

      }
    }
  }

  /**
   * Sets the values for ProviderCategory for a provider. The general
   * classification for that provider. For example, a provider who provides a
   * foster care service may have a provider category of Foster Care.
   *
   * @param providerCategoryPeriod
   * Contains provider category period.
   * @param details
   * Contains provider category details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setProviderCategoryPeriod(
    // END, CR00177241
    curam.provider.impl.ProviderCategoryPeriod providerCategoryPeriod,
    ProviderCategoryDetails details) throws AppException,
      InformationalException {

    providerCategoryPeriod.setCategory(
      ProviderCategoryNameEntry.get(
        curam.util.type.CodeTable.getParentCode(ProviderTypeNameEntry.TABLENAME,
        details.category)));
    providerCategoryPeriod.setComments(details.comments);

    final DateRange dateRange = new DateRange(details.startDate,
      details.endDate);

    providerCategoryPeriod.setDateRange(dateRange);

    providerCategoryPeriod.setEndReason(details.endReason);
    providerCategoryPeriod.setPrimary(details.primaryInd);

  }

  /**
   * Returns the provider details like reference number,street 1 name,provider
   * category.
   *
   * @param provider
   * contains provider details.
   * @return SearchProviderDetails Contains the provider details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected SearchProviderDetails getProviderFields(
    // END, CR00177241
    curam.provider.impl.Provider provider) throws AppException,
      InformationalException {

    SearchProviderDetails searchProviderDetails = new SearchProviderDetails();

    searchProviderDetails.concernRoleID = provider.getID();
    searchProviderDetails.recordStatus = provider.getLifecycleState().getCode();
    ProviderCategoryPeriod providerCategoryPeriod = provider.getPrimaryProviderCategoryPeriod();

    searchProviderDetails.primaryCategory = ProviderCategoryNameEntry.get(providerCategoryPeriod.getCategory().getCode()).getCode();

    // assign the concernRoleName and Type from concernRole
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = provider.getPrimaryAddressID();

    // create instance of addressElementObj
    AddressElement addressElementObj = AddressElementFactory.newInstance();
    AddressElementDtlsList addressElementDtlsList = addressElementObj.readAddressElementDetails(
      addressKey);
    int size = addressElementDtlsList.dtls.size();

    // loop the addressElmentdetailsList to fetch the city and addressLine1
    for (int i = 0; i < size; i++) {
      if (addressElementDtlsList.dtls.item(i).elementType.equals(
        ADDRESSELEMENTTYPE.CITY)) {
        searchProviderDetails.city = addressElementDtlsList.dtls.item(i).elementValue;
      } else if (addressElementDtlsList.dtls.item(i).elementType.equals(
        ADDRESSELEMENTTYPE.LINE1)) {
        searchProviderDetails.street1 = addressElementDtlsList.dtls.item(i).elementValue;
      }
    }

    searchProviderDetails.name = provider.getName();
    searchProviderDetails.referenceNumber = provider.getPrimaryAlternateID();

    // get the owner of this provider
    MaintainAdminConcernRole maintainAdminConcernRole = new MaintainAdminConcernRole();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // set the key
    concernRoleKey.concernRoleID = provider.getID();
    searchProviderDetails.owner = maintainAdminConcernRole.getProviderOrganisationOwner(concernRoleKey).userName;

    return searchProviderDetails;
  }

  /**
   * Returns the provider details like reference number,street 1 name,provider
   * category.
   *
   * @param provider
   * contains provider details.
   * @return SearchProviderDetails Contains the provider details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected SearchProviderDetails getProviderFieldsForFacilityManager(
    // END, CR00177241
    curam.provider.impl.Provider provider) throws AppException,
      InformationalException {

    SearchProviderDetails searchProviderDetails = new SearchProviderDetails();

    searchProviderDetails.concernRoleID = provider.getID();
    searchProviderDetails.recordStatus = provider.getLifecycleState().getCode();
    ProviderCategoryPeriod providerCategoryPeriod = provider.getPrimaryProviderCategoryPeriod();

    searchProviderDetails.primaryCategory = ProviderCategoryNameEntry.get(providerCategoryPeriod.getCategory().getCode()).getCode();

    // assign the concernRoleName and Type from concernRole
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = provider.getPrimaryAddressID();
    // create instance of addressElementObj
    AddressElement addressElementObj = AddressElementFactory.newInstance();
    AddressElementDtlsList addressElementDtlsList = addressElementObj.readAddressElementDetails(
      addressKey);
    int size = addressElementDtlsList.dtls.size();

    // loop the addressElmentdetailsList to fetch the city and addressLine1
    for (int i = 0; i < size; i++) {
      if (addressElementDtlsList.dtls.item(i).elementType.equals(
        ADDRESSELEMENTTYPE.CITY)) {
        searchProviderDetails.city = addressElementDtlsList.dtls.item(i).elementValue;
      } else if (addressElementDtlsList.dtls.item(i).elementType.equals(
        ADDRESSELEMENTTYPE.LINE1)) {
        searchProviderDetails.street1 = addressElementDtlsList.dtls.item(i).elementValue;
      }
    }

    // BEGIN, CR00293652, ASN
    TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
    AddressTabDetails addressTabDetails = new AddressTabDetails();

    Address addressObj = AddressFactory.newInstance();

    if (0 != provider.getPrimaryAddressID()) {
      addressTabDetails.addressData = addressObj.read(addressKey).addressData;
    }

    if (!CuramConst.gkEmpty.equals(addressTabDetails.addressData)) {
      searchProviderDetails.addressStringOpt = tabDetailFormatterObj.formatAddress(addressTabDetails).addressString;
    }
    // END, CR00293652

    searchProviderDetails.name = provider.getName();
    searchProviderDetails.referenceNumber = provider.getPrimaryAlternateID();

    curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = provider.getID();
    searchProviderDetails.owner = maintainAdminConcernRole.getProviderOrganizationFacilityManager(concernRoleKey).userName;

    return searchProviderDetails;
  }

  /**
   * This method returns the provider search details like reference
   * number,street 1 name.
   *
   * @param provider
   * contains Provider details.
   *
   * @return SearchProviderDetails Contains the provider details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected SearchProviderDetails getProviderSearchFields(
    // END, CR00177241
    curam.provider.impl.Provider provider) throws AppException,
      InformationalException {

    SearchProviderDetails searchProviderDetails = new SearchProviderDetails();

    searchProviderDetails.concernRoleID = provider.getID();

    // assign the concernRoleName and Type from concernRole
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = provider.getPrimaryAddressID();
    // create instance of addressElementObj
    AddressElement addressElementObj = AddressElementFactory.newInstance();
    AddressElementDtlsList addressElementDtlsList = addressElementObj.readAddressElementDetails(
      addressKey);
    int size = addressElementDtlsList.dtls.size();

    // loop the addressElmentdetailsList to fetch the city and addressLine1
    for (int i = 0; i < size; i++) {
      if (addressElementDtlsList.dtls.item(i).elementType.equals(
        ADDRESSELEMENTTYPE.CITY)) {
        searchProviderDetails.city = addressElementDtlsList.dtls.item(i).elementValue;
      } else if (addressElementDtlsList.dtls.item(i).elementType.equals(
        ADDRESSELEMENTTYPE.LINE1)) {
        searchProviderDetails.street1 = addressElementDtlsList.dtls.item(i).elementValue;
      }
    }

    searchProviderDetails.name = provider.getName();
    searchProviderDetails.referenceNumber = provider.getPrimaryAlternateID();
    return searchProviderDetails;
  }

  /**
   * This method returns provider enquiry details like enquiry name,reference
   * number, address,status.
   *
   * @param providerEnquiry
   * contains provider enquiry details.
   * @return ProviderEnquirySummaryDetails provider enquiry summary details
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected ProviderEnquirySummaryDetails getProviderEnquiryFields(
    // END, CR00177241
    curam.provider.impl.ProviderEnquiry providerEnquiry) throws AppException,
      InformationalException {

    ProviderEnquirySummaryDetails enquirySummaryDetails = new ProviderEnquirySummaryDetails();

    enquirySummaryDetails.referenceNumber = providerEnquiry.getReferenceNumber();
    enquirySummaryDetails.providerEnquiryID = providerEnquiry.getID();
    enquirySummaryDetails.name = providerEnquiry.getName();
    enquirySummaryDetails.enquiryDate = providerEnquiry.getEnquiryDate();
    enquirySummaryDetails.statusCode = providerEnquiry.getRecordStatus().getCode();
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = providerEnquiry.getHomeAddressID();
    // create instance of addressElementObj
    curam.core.intf.AddressElement addressElementObj = AddressElementFactory.newInstance();
    AddressElementDtlsList addressElementDtlsList = addressElementObj.readAddressElementDetails(
      addressKey);
    int size = addressElementDtlsList.dtls.size();

    // loop the addressElmentdetailsList to fetch the city and addressLine1
    for (int i = 0; i < size; i++) {
      if (addressElementDtlsList.dtls.item(i).elementType.equals(
        ADDRESSELEMENTTYPE.CITY)) {
        enquirySummaryDetails.city = addressElementDtlsList.dtls.item(i).elementValue;
      } else if (addressElementDtlsList.dtls.item(i).elementType.equals(
        ADDRESSELEMENTTYPE.LINE1)) {
        enquirySummaryDetails.street1 = addressElementDtlsList.dtls.item(i).elementValue;
      }
    }

    return enquirySummaryDetails;
  }

  /**
   * Sorts a set of ProviderEnquiries name into a sorted list for display.
   *
   * @param unsortedProviderEnquries
   * the set of unsorted ProviderEnquiries.
   *
   * @return ProviderEnquirySummaryDetailsList contains sorted list of Provider
   * Enquiries by Enquiry name
   */

  @SuppressWarnings(CPMConstants.kUnchecked)
  // BEGIN, CR00177241, PM
  protected ProviderEnquirySummaryDetailsList sortProviderEnquries(
    // END, CR00177241
    ProviderEnquirySummaryDetailsList unsortedProviderEnquries) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    List<ProviderEnquirySummaryDetails> enquirySummaryDetailsList = new ArrayList<ProviderEnquirySummaryDetails>();
    int noOfEnquiries = unsortedProviderEnquries.enquriySummaryDetails.size();

    for (int i = 0; i < noOfEnquiries; i++) {
      enquirySummaryDetailsList.add(
        unsortedProviderEnquries.enquriySummaryDetails.item(i));
    }
    Collections.sort(enquirySummaryDetailsList,
      new Comparator<ProviderEnquirySummaryDetails>() {
      public int compare(final ProviderEnquirySummaryDetails lhs,
        ProviderEnquirySummaryDetails rhs) {
        return lhs.name.compareToIgnoreCase(rhs.name);
      }
    });

    ProviderEnquirySummaryDetailsList providerEnquirySummaryDetailsList = new ProviderEnquirySummaryDetailsList();

    providerEnquirySummaryDetailsList.enquriySummaryDetails.addAll(
      enquirySummaryDetailsList);

    return providerEnquirySummaryDetailsList;
  }

  /**
   * Sorts a set of ProviderCategories name into a sorted list for display.
   *
   * @param unsortedProviderCategories
   * the set of unsorted ProviderCategoryDetails
   *
   * @return ProviderCategoryDetailsList contains a sorted list of Provider
   * Categories by Category name
   */

  @SuppressWarnings(CPMConstants.kUnchecked)
  // BEGIN, CR00177241, PM
  protected ProviderCategoryDetailsList sortProviderCategories(
    // END, CR00177241
    ProviderCategoryDetailsList unsortedProviderCategories) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */

    List<ProviderCategoryDetails> providerCategoryDetailsList = new ArrayList<ProviderCategoryDetails>();
    int noOfEnquiries = unsortedProviderCategories.details.size();

    for (int i = 0; i < noOfEnquiries; i++) {
      providerCategoryDetailsList.add(
        unsortedProviderCategories.details.item(i));
    }
    Collections.sort(providerCategoryDetailsList,
      new Comparator<ProviderCategoryDetails>() {
      public int compare(final ProviderCategoryDetails lhs,
        ProviderCategoryDetails rhs) {
        return ProviderCategoryNameEntry.get(lhs.providerTypeCategory).toUserLocaleString().compareToIgnoreCase(
          ProviderCategoryNameEntry.get(rhs.providerTypeCategory).toUserLocaleString());
      }
    });

    ProviderCategoryDetailsList providerCategoryDetailsListSorted = new ProviderCategoryDetailsList();

    providerCategoryDetailsListSorted.details.addAll(
      providerCategoryDetailsList);
    return providerCategoryDetailsListSorted;
  }

  /**
   * Sorts a set of Providers into a sorted list for display.
   *
   * @param unsortedProviders
   * the set of unsorted Provider
   * @return SearchProviderDetailsList contains a list of Providers sorted by
   * name.
   */

  @SuppressWarnings(CPMConstants.kUnchecked)
  // BEGIN, CR00177241, PM
  protected SearchProviderDetailsList sortProviders(
    // END, CR00177241
    SearchProviderDetailsList unsortedProviders) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    List<SearchProviderDetails> searchProviderDetailsList = new ArrayList<SearchProviderDetails>();
    int noOfEnquiries = unsortedProviders.details.size();

    for (int i = 0; i < noOfEnquiries; i++) {
      searchProviderDetailsList.add(unsortedProviders.details.item(i));
    }

    Collections.sort(searchProviderDetailsList,
      new Comparator<SearchProviderDetails>() {
      public int compare(final SearchProviderDetails lhs,
        SearchProviderDetails rhs) {
        return lhs.referenceNumber.compareToIgnoreCase(rhs.referenceNumber);
      }
    });

    SearchProviderDetailsList searchProviderDetailsListSorted = new SearchProviderDetailsList();

    searchProviderDetailsListSorted.details.addAll(searchProviderDetailsList);

    return searchProviderDetailsListSorted;
  }

  /**
   * Creates the designated places in the root level compartment
   *
   * @param details
   * Contains the Provider details
   * @param compartmentKey
   * Contains the root level compartment key
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void createDesignatedPlaces(ProviderEnrollmentDetails details,
    // END, CR00177241
    CompartmentKey compartmentKey) throws AppException,
      InformationalException {

    long designatedCapacity;
    // START, CR00088333, SP
    int kMaxLimit = 1000;

    // END, CR00088333

    // Getting the value of designatedCapacity
    if (details.physicalCapacity > kMinimumCapacity
      && details.designatedCapacity == kMinimumCapacity) {
      designatedCapacity = details.physicalCapacity;
    } else {
      designatedCapacity = details.designatedCapacity;
    }

    if (designatedCapacity > kMaximumCapacity) {
      designatedCapacity = kMaximumCapacity;
    }

    // Creating Places for the provider under the root level compartment

    // If designatedCapacity is less then or equals the kMaxLimit create the
    // places on line otherwise create through a batch process
    if (designatedCapacity <= kMaxLimit) {
      // START, CR00088333, SP
      // Call new operation to create places repeatedly
      // only if designated capacity is greater than minimum capacity.
      if (designatedCapacity > kMinimumCapacity) {
        details.designatedCapacity = designatedCapacity;
        // Creating instance for the Place
        Place placeObj = PlaceFactory.newInstance();

        placeObj.createBatchPlaces(details, compartmentKey);
      }
      // END, CR00088333
    } else {

      curam.util.intf.DeferredProcessing deferredProcessingObj = DeferredProcessingFactory.newInstance();
      // WMCreatePlace object instance
      curam.cpm.sl.intf.WMCreatePlaceData WMCreatePlaceDataObj = WMCreatePlaceDataFactory.newInstance();
      WMCreatePlaceDataDtls createPlaceDataDtls = new WMCreatePlaceDataDtls();

      createPlaceDataDtls.compartmentID = compartmentKey.compartmentID;
      createPlaceDataDtls.designatedCapacity = designatedCapacity;
      createPlaceDataDtls.startDate = Date.getCurrentDate();
      // BEGIN, CR00186107, SS
      createPlaceDataDtls.name = new curam.util.exception.LocalisableString(curam.message.PLACE.PLACE_NAME).getMessage();
      // END, CR00186107
      WMCreatePlaceDataObj.insert(createPlaceDataDtls);

      deferredProcessingObj.startProcess(CPMConstants.kCreatePlacesForProvider,
        createPlaceDataDtls.wmCreatePlaceDataID);

    }
  }

  /**
   * Sets the provider concern role fields.
   *
   * @param details
   * Contains the provider enrollment details.
   * @param concernRoleDtls
   * Contains concern role details. the service layer struct into which
   * the user updateable fields must be mapped.
   */
  // BEGIN, CR00177241, PM
  protected void setConcernRoleFields(ProviderEnrollmentDetails details,
    // END, CR00177241
    ConcernRoleDtls concernRoleDtls) {

    concernRoleDtls.concernRoleType = CONCERNROLETYPEEntry.PROVIDER.getCode();
    concernRoleDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();
    concernRoleDtls.registrationDate = details.enrollmentDate;
    concernRoleDtls.startDate = details.enrollmentDate;
    concernRoleDtls.endDate = curam.util.type.Date.kZeroDate;
    concernRoleDtls.concernRoleName = details.providerName;

    concernRoleDtls.primaryEmailAddressID = 0;
    concernRoleDtls.regUserName = curam.util.transaction.TransactionInfo.getProgramUser();
    concernRoleDtls.comments = CPMConstants.kEmptyString;
    concernRoleDtls.preferredLanguage = details.prefLanguage;
    concernRoleDtls.prefCommMethod = details.prefCommMethod;

    if (details.prefCommMethod.length() != 0) {
      concernRoleDtls.prefCommFromDate = details.enrollmentDate;
    }
    concernRoleDtls.sensitivity = curam.codetable.SENSITIVITY.DEFAULTCODE;
    concernRoleDtls.statusCode = curam.codetable.CONCERNROLESTATUS.CURRENT;
  }

  /**
   * Sets the Provider fields, used in create and modify provider methods.
   *
   * @param details
   * provider enrollment struct contain fields set by the user
   * @param provider
   * the service layer object into which the user-updateable fields
   * must be mapped.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setProviderFields(ProviderEnrollmentDetails details,
    // END, CR00177241
    curam.provider.impl.Provider provider) throws AppException {

    provider.setCurrencyType(CURRENCYEntry.get(details.currencyType));
    provider.setMethodOfPayment(details.methodOfPayment);

    if (!details.paymentFrequency.equals(CPMConstants.kEmptyString)) {
      // FrequencyPattern frequencyPattern = new FrequencyPattern(
      // details.paymentFrequency);
      provider.setPaymentFrequency(details.paymentFrequency);
    } else {
      provider.setPaymentFrequency(
        FrequencyPattern.kZeroFrequencyPattern.toString());
    }
    if (details.physicalCapacity == kMinimumCapacity
      && details.designatedCapacity > kMinimumCapacity) {
      details.physicalCapacity = (int) details.designatedCapacity;
      provider.setPhysicalCapacity((int) details.designatedCapacity);
    } else {
      provider.setPhysicalCapacity(details.physicalCapacity);
    }

    // designatedCapacity cannot be greater than physical capacity
    if (details.designatedCapacity > details.physicalCapacity) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new curam.util.exception.AppException(curam.message.PROVIDER.ERR_PROVIDER_XFV_DESIGNATED_CAPACITY_MUST_BE_LESS_THAN_OR_EQUAL_TO_PHY_CAPACITY).arg(details.designatedCapacity).arg(
          details.physicalCapacity),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // if this provider has existing enquiry then set enquiry id
    if (details.providerEnquiryID != 0) {

      // Provider Enquiry object instance
      curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.get(
        details.providerEnquiryID);

      provider.setProviderEnquiry(providerEnquiry);
    }

    // BEGIN, CR00106630, JSP
    if (details.reservationGracePeriodString.length() > CPMConstants.kZeroLong) {
      try {
        // Convert grace period string to short
        details.reservationGracePeriod = Short.parseShort(
          details.reservationGracePeriodString);

      } catch (NumberFormatException exception) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_FV_PROVIDER_RESERVATION_GRACE_PERIOD_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }

      // grace period cannot be less than zero
      if (details.reservationGracePeriod <= CPMConstants.kZeroLong) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_FV_PROVIDER_RESERVATION_GRACE_PERIOD_GT_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }
    provider.setReservationGracePeriod(details.reservationGracePeriod);
    // END, CR00106630
    provider.setAcceptsCWReferral(details.acceptCWReferral);
    
    // BEGIN, CR00378940, SS
    provider.setPreferredServiceEnquiryMethod(
      PREFERREDSERVICEENQUIRYMETHODEntry.get(
        details.preferredServiceEnquiryMethodOpt));
    provider.getAreasServedInfo().addValue(details.areasServedInformationOpt);
    provider.getClientInfo().addValue(details.clientInformationOpt);
    // END, CR00378940

  }

  /**
   * Sets the provider bank fields.
   *
   * @param details
   * provider enrollment struct contain fields set by the user.
   * @param bankAccountDetails
   * Contains the provider bank details. the service layer struct into
   * which the user-updateable fields must be mapped.
   */
  // BEGIN, CR00177241, PM
  protected void setConcernRoleBankFields(ProviderEnrollmentDetails details,
    // END, CROO177241
    BankAccountDetails bankAccountDetails) {

    bankAccountDetails.name = details.bankAccountName;
    bankAccountDetails.typeCode = details.bankAccountType;
    bankAccountDetails.bankSortCode = details.bankSortCode;
    bankAccountDetails.accountNumber = details.bankAccountNumber;
    bankAccountDetails.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
    bankAccountDetails.startDate = details.enrollmentDate;
    bankAccountDetails.primaryBankInd = true;
    bankAccountDetails.jointAccountInd = details.bankJointAccount;
    // BEGIN, CR00379189, SS
    bankAccountDetails.bicOpt = details.bicOpt;
    bankAccountDetails.ibanOpt = details.ibanOpt;
    // END, CR00379189
  }

  /**
   * Sets the provider phone fields.
   *
   * @param details
   * provider enrollment struct contain fields set by the user.
   *
   * @param concernRolePhoneDetails
   * Contains the provider phone details. the service layer struct into
   * which the user-updateable fields must be mapped.
   */
  // BEGIN, CR00177241, PM
  protected void setConcernRolePhoneFields(ProviderEnrollmentDetails details,
    // END, CR00177241
    ConcernRolePhoneDetails concernRolePhoneDetails) {

    concernRolePhoneDetails.phoneNumber = details.phoneNumber;
    concernRolePhoneDetails.phoneExtension = details.phoneExtension;
    concernRolePhoneDetails.typeCode = details.phoneType;
    concernRolePhoneDetails.phoneAreaCode = details.phoneAreaCode;
    concernRolePhoneDetails.phoneCountryCode = details.phoneCountryCode;
    concernRolePhoneDetails.startDate = details.enrollmentDate;
    concernRolePhoneDetails.endDate = curam.util.type.Date.kZeroDate;

  }

  /**
   * Sets the address fields of the provider.
   *
   * @param details
   * provider enrollment struct contain fields set by the user.
   *
   * @param addressDetails
   * contains the provider address details. the service layer struct
   * into which the user-updateable fields must be mapped.
   */
  // BEGIN, CR00177241, PM
  protected void setAddressFields(ProviderEnrollmentDetails details,
    // END, CR00177241
    AddressDetails addressDetails) {

    addressDetails.typeCode = curam.codetable.CONCERNROLEADDRESSTYPE.BUSINESS;
    addressDetails.startDate = details.enrollmentDate;
    addressDetails.endDate = curam.util.type.Date.kZeroDate;
    addressDetails.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
    addressDetails.addressData = details.addressData;
    addressDetails.primaryAddressInd = true;

  }

  // BEGIN, CR00102261, KR
  // BEGIN, CR00143613, GP
  /**
   * Validates the bank account details if the bank account is joint account.
   *
   * @param details
   * Provider enrollment details which has bank account details to be
   * verified.
   */
  // END, CR00143613
  // BEGIN, CR00177241, PM
  protected void validateBankAccountDetails(ProviderEnrollmentDetails details)
    // END, CR00177241
    throws AppException {

    StringBuffer validationString = new StringBuffer();

    if (details.bankJointAccount) {

      // BEGIN, CR00143613, GP
      if (StringUtil.isNullOrEmpty(details.bankAccountName)) {
        // END, CR00143613

        validationString.append(CuramConst.gkNewLine).append(
          curam.message.GENERALADMIN.ERR_BANKACCOUNT_FV_NAME_EMPTY.getMessageText());
      }

      // BEGIN, CR00143613, GP
      if (StringUtil.isNullOrEmpty(details.bankAccountType)) {
        // END, CR00143613

        validationString.append(CuramConst.gkNewLine).append(
          curam.message.GENERALADMIN.ERR_BANKACCOUNT_FV_TYPE_EMPTY.getMessageText());

      }

      // BEGIN, CR00379189, SS
      final InternationalBankAccountIndicator internationalBankAccountIndicator = new InternationalBankAccountIndicator();

      internationalBankAccountIndicator.ibanInd = Configuration.getBooleanProperty(
        EnvVars.ENV_PARTICIPANT_ENABLE_IBAN_FUNCTIONALITY);
      if (!internationalBankAccountIndicator.ibanInd) {

        // BEGIN, CR00143613, GP
        if (StringUtil.isNullOrEmpty(details.bankSortCode)) {
          // END, CR00143613

          validationString.append(CuramConst.gkNewLine).append(
            curam.message.GENERALADMIN.ERR_BANKACCOUNT_FV_BANKBRANCH_EMPTY.getMessageText());
        }

        // BEGIN, CR00143613, GP
        if (StringUtil.isNullOrEmpty(details.bankAccountNumber)) {
          // END, CR00143613
          validationString.append(CuramConst.gkNewLine).append(
            curam.message.GENERALADMIN.ERR_BANKACCOUNT_FV_NUM_EMPTY.getMessageText());
        }
      }
      // END, CR00379189
      

      if (validationString.length() > 0) {

        AppException e = new AppException(
          curam.message.BPOBANKACCOUNT.ERR_JOINBANKACCOUNT_VALIDATION_FAILURE_LIST);

        e.arg(validationString);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
      }
    }

  }

  // END, CR00102261

  /**
   * Inserts a Provider Status History record each time there is a change in
   * Provider life cycle.
   *
   * @param provider
   * provider object contains the provider status information
   * @param reason
   * reason for the change in the provider status
   * @param status
   * The status of a provider. The status will change through the
   * lifecycle of the provider.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setProviderStatusHistory(
    // END, CR00177241
    final curam.provider.impl.Provider provider, String reason, String status)
    throws AppException, InformationalException {

    curam.provider.impl.ProviderStatusHistory providerStatusHistory = providerStatusHistoryDAO.newInstance();

    // Add provider status history for this provider
    providerStatusHistory.setEffectiveDateTime(DateTime.getCurrentDateTime());
    providerStatusHistory.setUserName(TransactionInfo.getProgramUser());
    providerStatusHistory.setProvider(provider);
    providerStatusHistory.setReason(reason);
    providerStatusHistory.setProviderRecordStatus(status);
    providerStatusHistory.insert();
  }

  /**
   * Method to search Provider Types
   *
   * @param key
   * Provider category type.
   * @return List of provider types.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchProviderTypeResultsList searchProviderTypes(
    providerTypeSearchKey key) throws AppException, InformationalException {

    SearchProviderTypeResultsList searchProviderTypeResultsList = new SearchProviderTypeResultsList();
    ProviderType providerTypeObj = ProviderTypeFactory.newInstance();

    ProviderTypeSearchResultsList providerTypeSearchResultsList;
    SearchProviderTypeResults searchProviderTypeResults;

    providerTypeSearchResultsList = providerTypeObj.searchProviderTypes(key);

    for (int i = 0; i < providerTypeSearchResultsList.dtls.size(); i++) {

      searchProviderTypeResults = new SearchProviderTypeResults();
      searchProviderTypeResults.category = CodeTable.getParentCode(
        ProviderTypeNameEntry.TABLENAME,
        providerTypeSearchResultsList.dtls.item(i).providerType);
      searchProviderTypeResults.providerType = providerTypeSearchResultsList.dtls.item(i).providerType;
      searchProviderTypeResults.providerTypeID = providerTypeSearchResultsList.dtls.item(i).providerTypeID;
      searchProviderTypeResults.recordStatus = providerTypeSearchResultsList.dtls.item(i).recordStatus;
      searchProviderTypeResultsList.detailsList.addRef(
        searchProviderTypeResults);
    }
    return searchProviderTypeResultsList;

  }

  // BEGIN CR00116062, PN

  /**
   * Method to search Providers for selected Service Offering
   *
   * @param providerServiceOfferingSearchKey
   * Contains provider type, provider category, provider name, address
   * @return List of providers.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchProviderServiceOfferingResultsList searchProviderServiceOffering(
    ProviderServiceOfferingSearchKey providerServiceOfferingSearchKey)
    throws AppException, InformationalException {

    // Manipulation variables
    SearchProviderServiceOfferingResultsList searchProviderServiceOfferingResultsList = new SearchProviderServiceOfferingResultsList();

    curam.cpm.sl.entity.intf.Provider providerObj = curam.cpm.sl.entity.fact.ProviderFactory.newInstance();

    ProviderServiceOfferingSearchResultsList providerServiceOfferingSearchResultsList = new ProviderServiceOfferingSearchResultsList();

    SearchProviderServiceOfferingResults searchProviderServiceOfferingResults;

    // Search the Service Offerings by Provider
    providerServiceOfferingSearchResultsList = providerObj.searchProviderServiceOffering(
      providerServiceOfferingSearchKey);

    for (int i = 0; i < providerServiceOfferingSearchResultsList.dtls.size(); i++) {

      searchProviderServiceOfferingResults = new SearchProviderServiceOfferingResults();

      searchProviderServiceOfferingResults.concernRoleName = providerServiceOfferingSearchResultsList.dtls.item(i).concernRoleName;

      searchProviderServiceOfferingResults.providerConcernRoleID = providerServiceOfferingSearchResultsList.dtls.item(i).providerConcernRoleID;
      searchProviderServiceOfferingResults.recordStatus = providerServiceOfferingSearchResultsList.dtls.item(i).recordStatus;
      searchProviderServiceOfferingResults.category = CodeTable.getParentCode(
        ProviderTypeNameEntry.TABLENAME,
        providerServiceOfferingSearchResultsList.dtls.item(i).providerType);
      searchProviderServiceOfferingResults.providerType = providerServiceOfferingSearchResultsList.dtls.item(i).providerType;
      searchProviderServiceOfferingResultsList.detailsList.addRef(
        searchProviderServiceOfferingResults);
    }

    return searchProviderServiceOfferingResultsList;
  }

  // END CR00116062

  // START CR00117630, ASB
  /**
   * Get the menu context description for the View Provider.
   *
   * @param providerKey
   * Internal system identifier of Provider record.
   *
   * @return Menu Context description.
   *
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  public CaseMenuData viewProviderMenuContextDescription(ProviderKey providerKey)
    throws AppException, InformationalException {

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    Element navigationMenuElement = new Element(
      XmlMetaDataConst.kNavigationMenu);
    Element linkElement = new Element(XmlMetaDataConst.kItem);
    Element paramElement = new Element(XmlMetaDataConst.kParam);

    // Set up node property values
    LocalisableString description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(provider.getName());

    // Set up node property values
    linkElement.setAttribute(XmlMetaDataConst.kPageID,
      CPMConstants.kViewProvider);
    linkElement.setAttribute(XmlMetaDataConst.kDesc,
      description.toClientFormattedText());
    linkElement.setAttribute(XmlMetaDataConst.kType, XmlMetaDataConst.kTypeCase);

    navigationMenuElement.addContent(linkElement);

    // set the parameter values
    paramElement = new Element(XmlMetaDataConst.kParam);
    paramElement.setAttribute(XmlMetaDataConst.kName,
      CPMConstants.kParamProviderConcernRoleID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(providerKey.providerConcernRoleID));

    linkElement.addContent(paramElement);

    XMLOutputter outputter = new XMLOutputter();
    CaseMenuData caseMenuData = new CaseMenuData();

    caseMenuData.menuData = outputter.outputString(navigationMenuElement);
    return caseMenuData;
  }

  // END CR00117630

  // BEGIN, CR00138625, AS
  /**
   * Accepts the user Option either 'Yes' or 'No' to register Provider as
   * Person.
   *
   * @param details
   * Contains ProviderRegistrationAsPersonOptionDetails.
   *
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  public void providerRegistrationAsPersonOption(
    ProviderRegistrationAsPersonOptionDetails details) throws AppException,
      InformationalException {// This is a dummy method used to pass the user selected option to the
    // next screen.
  }

  // END, CR00138625

  // BEGIN, CR00146426, GSP

  /**
   * Reads the Integrated case Provider details.
   *
   * @param key contains Case Participant Role ID for a Provider.
   *
   * @return the Integrated case Provider details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadICProviderDetails readICProviderdetails(CaseParticipantRoleKey key)
    throws AppException, InformationalException {

    // details to be returned
    ReadICProviderDetails readICProviderDetails = new ReadICProviderDetails();

    // MaintainCase manipulation variables
    CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();

    ReadICDetailsKey readICDetailsKey = new ReadICDetailsKey();

    curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    ProviderKey providerKey = new ProviderKey();

    // Read caseID & ConcernRoleID by searching on CaseParticipantRoleID
    // passed in.
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj.readCaseIDandParticipantID(
      caseParticipantRoleKey);

    // Assign caseID and concernRoleID details to the listICMemberTaskDetails
    // structure
    providerKey.providerConcernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    readICDetailsKey.caseID = caseIDAndParticipantRoleIDDetails.caseID;

    // Creating an instance for sl process and calling the view method
    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    readICProviderDetails.concernRoleID = providerKey.providerConcernRoleID;
    readICProviderDetails.referenceNumber = provider.getPrimaryAlternateID();
    readICProviderDetails.providerName = provider.getName();

    // Get address details
    Address addressObj = AddressFactory.newInstance();
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = provider.getPrimaryAddressID();

    AddressDtls addressDtls = addressObj.read(addressKey);

    OtherAddressData formattedAddressData = new OtherAddressData();

    formattedAddressData.addressData = addressDtls.addressData;
    addressObj.getAddressStrings(formattedAddressData);

    readICProviderDetails.formattedAddressData = formattedAddressData.addressData;

    readICProviderDetails.enrollmentDate = provider.getRegistrationDate();

    readICProviderDetails.description = provider.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + provider.getPrimaryAlternateID();

    // Get phone details
    final PhoneNumber phoneNumber = provider.getPrimaryPhoneNumber();

    if (phoneNumber != null) {

      PhoneForConcernRoleKey phoneForConcernRoleKey = new PhoneForConcernRoleKey();

      phoneForConcernRoleKey.concernRoleID = provider.getID();
      phoneForConcernRoleKey.phoneNumberID = phoneNumber.getID();

      readICProviderDetails.phoneNumber = phoneNumber.getNumber();
      readICProviderDetails.phoneAreaCode = phoneNumber.getAreaCode();
      readICProviderDetails.phoneCountryCode = phoneNumber.getCountryCode();
      readICProviderDetails.phoneExtension = phoneNumber.getExtension();
    }

    // Read menu data
    ICMemberMenuDataDetails icMemberMenuDataDetails = getCPMICMemberMenuData(
      key);

    // populate the menu data
    readICProviderDetails.providerMenuData.menuData = icMemberMenuDataDetails.menuData;

    return readICProviderDetails;
  }

  /**
   * Returns the Menu Data for an Integrated Case member.
   *
   * @param key Contains the case identifier.
   *
   * @return Menu Data for an Integrated Case member
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected ICMemberMenuDataDetails getCPMICMemberMenuData(
    CaseParticipantRoleKey key)
    throws AppException, InformationalException {
    // CaseHeader manipulation variables
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // MaintainCase manipulation variables
    CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();

    curam.core.sl.entity.struct.CaseIDCaseRefAndParticipantRoleIDDetails caseIDCaseRefAndParticipantRoleIDDetails;
    curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // Read caseID & ConcernRoleID by searching on CaseParticipantRoleID passed
    // in
    caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

    caseIDCaseRefAndParticipantRoleIDDetails = caseParticipantRoleObj.readCaseIDcaseRefandParticipantID(
      caseParticipantRoleKey);

    // Get the case's parent case ID - the Integrated case ID
    caseKey.caseID = caseIDCaseRefAndParticipantRoleIDDetails.caseID;
    IntegratedCaseKey integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(
      caseKey);

    // Assign integrated case ID to the listICMemberTaskDetails structure
    if (integratedCaseKey.integratedCaseID == 0) {
      caseHeaderKey.caseID = caseIDCaseRefAndParticipantRoleIDDetails.caseID;
    } else {
      caseHeaderKey.caseID = integratedCaseKey.integratedCaseID;
    }

    CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance().readCaseTypeCode(
      caseKey);

    ProductHookManager productHookManager = new ProductHookManager();
    curam.core.facade.intf.MenuData menuDataObj = productHookManager.getMenuDataHook(
      caseTypeCode.caseTypeCode);

    return menuDataObj.getICMemberMenuData(key, caseHeaderKey);

  }

  // END, CR00146426
  // BEGIN, CR00206945, AS
  /**
   * Sorts provider status history by date and time.
   *
   * @param providerStatusHistoryDtlslist
   * Contains provider status history details.
   *
   * @return List of sorted provider status history.
   */
  protected List<ProviderStatusHistoryDtls> sortProviderStatusHistoryByDateTime(
    List<ProviderStatusHistoryDtls> providerStatusHistoryDtlslist) {
    Collections.sort(providerStatusHistoryDtlslist,
      new Comparator<ProviderStatusHistoryDtls>() {
      public int compare(final ProviderStatusHistoryDtls lhs,
        final ProviderStatusHistoryDtls rhs) {
        return rhs.effectiveDateTime.compareTo(lhs.effectiveDateTime);
      }
    });

    return providerStatusHistoryDtlslist;
  }

  // END, CR00206945
  
  // BEGIN, CR00292696, IBM
  /**
   * Collects the list of informations from the informational manager and adds
   * them to the list parameter passed in.
   *
   * @param informationalMsgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList informationalMsgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }

  // END, CR00292696
  
  // BEGIN, CR00407056, VT
  /**
   * Closes the Provider if no longer providing the service.
   *
   * @param details
   * Contains the Concern Role ID and status fields for a Provider.
   * @return ProviderKey Contains the Concern Role ID for a Provider.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderKey performCloseProvider(final ProviderStatusDetails details)
    throws AppException, InformationalException {

    final ProviderKey providerKey = new ProviderKey();

    curam.provider.impl.Provider provider = providerDAO.get(
      details.providerConcernRoleID);

    for (final ContractVersion contracts : provider.getContracts()) {
      if (CONTRACTTYPEEntry.FLATRATE.equals(contracts.getContractType())
        && CONTRACTSTATUSEntry.LIVE.equals(contracts.getLifecycleState())) {
        ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_LIVE_CONTRACTS_PRESENT_PROVIDER_CANNOT_BE_CLOSED(),
          ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }
    }
  
    if (details.endDate.after(Date.getCurrentDate())) { 	
      ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          PROVIDER.ERR_PROVIDER_FV_PROVIDER_ENDDATE_MUST_BE_ON_OR_BEFORE_TODAY),
          ValidationManagerConst.kSetTwo,
          0);
    } 

    final Placement placement = PlacementFactory.newInstance();
    final ProviderOfferingIDAndDateTimeKey offeringIDAndDateTimeKey = new ProviderOfferingIDAndDateTimeKey();

    for (final ProviderOffering providerOffering : provider.getProviderOfferings()) {
      offeringIDAndDateTimeKey.providerOfferingID = providerOffering.getID();
      offeringIDAndDateTimeKey.currentDateTime = DateTime.getCurrentDateTime();
      offeringIDAndDateTimeKey.placementStatus = RECORDSTATUS.NORMAL;
      final PlacementDtlsList placementDtlsList = placement.searchPlacementsByProviderOffering(
        offeringIDAndDateTimeKey);

      if (CuramConst.gkZero < placementDtlsList.dtls.size()) {
        ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_ACTIVE_PLACEMENTS_PRESENT_CANNOT_BE_CLOSED(),
          ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }
    }

    final ServiceDelivery serviceDelivery = ServiceDeliveryFactory.newInstance();
    final SearchByProvider searchByProvider = new SearchByProvider();

    searchByProvider.providerID = provider.getID();
    final ServiceDeliveryDtlsList serviceDeliveryDtlsList = serviceDelivery.searchByProvider(
      searchByProvider);

    for (final ServiceDeliveryDtls serviceDeliveryDtls : serviceDeliveryDtlsList.dtls.items()) {
      final SERVICEDELIVERYSTATUSEntry servicedeliverystatusEntry = SERVICEDELIVERYSTATUSEntry.get(
        serviceDeliveryDtls.status);

      if (SERVICEDELIVERYSTATUSEntry.OPEN.equals(servicedeliverystatusEntry)
        || SERVICEDELIVERYSTATUSEntry.SUBMITTED.equals(
          servicedeliverystatusEntry)
          || SERVICEDELIVERYSTATUSEntry.INPROGRESS.equals(
            servicedeliverystatusEntry)
            || SERVICEDELIVERYSTATUSEntry.NOTSTARTED.equals(
              servicedeliverystatusEntry)) {
        ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_ACTIVE_SERVICEDELIVERIES_PRESENT_CANNOT_BE_CLOSED(),
          ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }
    }
 
    provider.setDateTimeRange(
      new DateTimeRange(provider.getDateTimeRange().start(),
      details.endDate.getTimeZoneAdjustedDateTime(
        TransactionInfo.getUserTimeZone())));

    provider.close(details.versionNo);

    // Now read and set the end date of ConcernRole
    // variables for concern role manipulation
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    // Read Concern role
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
  
    concernRoleKey.concernRoleID = details.providerConcernRoleID;
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Enrollment Date Later Than End Date.
    if (!concernRoleDtls.creationDate.isZero()
      && concernRoleDtls.creationDate.after(Date.getCurrentDate())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(curam.message.PROVIDER.ERR_PROVIDER_XFV_ENDDATE_MUST_NOT_BE_EARLIER_THAN_ENROLLMENT_DATE).arg(Date.getCurrentDate()).arg(
          concernRoleDtls.creationDate),
          ValidationManagerConst.kSetTwo,
          0);
    }

    // Set the end date and status to closed and modify ConcernRole
    concernRoleDtls.endDate = Date.getCurrentDate();
    concernRoleDtls.statusCode = CONCERNROLESTATUS.CLOSED;
    concernRoleObj.modify(concernRoleKey, concernRoleDtls);

    final String status = ProviderStatusEntry.CLOSED.getCode();

    setProviderStatusHistory(provider, CPMConstants.kEmptyString, status);
    providerKey.providerConcernRoleID = details.providerConcernRoleID;

    // Send Provider close Notification
    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();
    final ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = provider.getID();
    providerNotificationKey.event = ProviderNotificationEvent.CLOSURE;
    providerNotification.sendNotification(providerNotificationKey);

    return providerKey;
  }
  // END, CR00407056

}
