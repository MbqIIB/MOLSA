/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.DEDUCTIONCATEGORYCODE;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.DEDUCTIONACTIONTYPEEntry;
import curam.codetable.impl.DEDUCTIONCATEGORYCODEEntry;
import curam.codetable.impl.DEDUCTIONNAMEEntry;
import curam.codetable.impl.PRODUCTTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.struct.ActiveLiabilityDetails;
import curam.core.facade.struct.ActiveLiabilityDetails1;
import curam.core.facade.struct.CaseAppliedDeductionHistoryDetailsList;
import curam.core.facade.struct.CaseDeductionHistoryListKey;
import curam.core.facade.struct.CaseThirdPartyDeductionHistoryDetailsList;
import curam.core.facade.struct.CaseUnappliedDeductionHistoryDetailsList;
import curam.core.facade.struct.DeductionClientDetails;
import curam.core.facade.struct.DeductionNameList;
import curam.core.facade.struct.DeductionNameListDetails;
import curam.core.facade.struct.DefaultDeductionDetails;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.ListActiveLiabilitesForConcernKey;
import curam.core.facade.struct.ListActiveLiabilitesForConcernKeyStruct;
import curam.core.facade.struct.ListActiveLiabilityDetails;
import curam.core.facade.struct.ListActiveLiabilityDetails1;
import curam.core.facade.struct.ReadDeductionDtls;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CaseDeductionItemFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseRelationshipFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.ProductFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CachedCaseHeader;
import curam.core.intf.CaseDeductionItem;
import curam.core.intf.CaseHeader;
import curam.core.intf.CaseRelationship;
import curam.core.intf.ConcernRole;
import curam.core.intf.Product;
import curam.core.intf.ProductDelivery;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.DeductionIDNamePriorityCategory;
import curam.core.sl.entity.struct.DeductionIDNamePriorityCategoryList;
import curam.core.sl.entity.struct.ParticipantRoleIDAndTypeCodesKey;
import curam.core.sl.entity.struct.ProductIDCategoryKey;
import curam.core.sl.fact.DeductionFactory;
import curam.core.sl.intf.Deduction;
import curam.core.sl.struct.CaseDeductionHistoryDetails;
import curam.core.sl.struct.DeductionIDPriority;
import curam.core.sl.struct.DeductionIDPriorityList;
import curam.core.sl.struct.DeductionKey;
import curam.core.sl.struct.DeductionName;
import curam.core.sl.struct.Priority;
import curam.core.sl.struct.PriorityDetails;
import curam.core.sl.struct.ReadDeductionDetails;
import curam.core.sl.struct.ThirdPartyDeductionHistoryDetails;
import curam.core.struct.CaseDeductionItemDtls;
import curam.core.struct.CaseDeductionItemDtlsList;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHeaderKeyList;
import curam.core.struct.CaseHomePageNameAndType;
import curam.core.struct.CaseIDCategory;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseRelationshipCaseIDKey;
import curam.core.struct.CaseRelationshipDtls;
import curam.core.struct.CaseRelationshipDtlsList;
import curam.core.struct.ConcernRoleID;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.CuramInd;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryDtlsList;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryTypeClientIDIn;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductTypeCodeIn;
import curam.cpm.facade.struct.ProviderDeductionDetails;
import curam.cpm.facade.struct.ProviderDeductionDetailsList;
import curam.cpm.facade.struct.ProviderDeductionModifyDetails;
import curam.cpm.facade.struct.ProviderPaymentKey;
import curam.cpm.facade.struct.ProviderPaymentKeyList;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.fact.ProviderDeductionFactory;
import curam.cpm.sl.entity.struct.ProviderDeductionKey;
import curam.cpm.sl.entity.struct.ProviderDeductionPriorityDetails;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.message.PROVIDERDEDUCTION;
import curam.message.impl.BPODEDUCTIONExceptionCreator;
import curam.message.impl.PROVIDERDEDUCTIONExceptionCreator;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderDeduction;
import curam.provider.impl.ProviderDeductionDAO;
import curam.provider.impl.ProviderDeductionProductLink;
import curam.provider.impl.ProviderDeductionProductLinkDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.LifecycleHelper;
import curam.util.resources.StringUtil;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.DateRange;
import curam.util.type.StringList;


/**
 * Maintains all the processing required for provider deduction.
 */
public abstract class MaintainProviderDeduction extends curam.cpm.facade.base.MaintainProviderDeduction {

  /**
   * Reference to Provider Deduction
   */
  @Inject
  protected ProviderDeductionDAO providerDeductionDAO;

  /**
   * Reference to Provider
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to Provider Deduction Product Link
   */
  @Inject
  protected ProviderDeductionProductLinkDAO providerDeductionProductLinkDAO;

  /**
   * Reference to Provider
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Bootstrap dependency injection for this class
   */
  public MaintainProviderDeduction() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Lists all the active deductions for a provider.
   *
   * @param key
   * Provider key.
   * @return All the active deductions for a provider.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderDeductionDetailsList listActiveDeductionForProvider(
    ProviderKey key) throws AppException, InformationalException {

    ProviderDeductionDetailsList providerDeductionDetailsList = new ProviderDeductionDetailsList();

    // Get all the active deductions and sort it based on ascending order of the
    // priority
    
    // BEGIN, CR00323260, MR
    Set<ProviderDeduction> providerDeductions = LifecycleHelper.filter(
      providerDeductionDAO.searchByProvider(
        providerDAO.get(key.providerConcernRoleID)),
        RECORDSTATUSEntry.NORMAL);

    // END, CR00323260
    
    for (ProviderDeduction providerDeduction : sortProviderDeductions(
      providerDeductions)) {

      ProviderDeductionDetails providerDeductionDetails = new ProviderDeductionDetails();

      providerDeductionDetails.providerDeduction.providerDeductionID = providerDeduction.getID();
      providerDeductionDetails.providerDeduction.category = providerDeduction.getCategory().getCode();
      providerDeductionDetails.providerDeduction.deductionName = providerDeduction.getDeductionName().getCode();
      providerDeductionDetails.providerDeduction.priority = providerDeduction.getPriority();
      providerDeductionDetails.providerDeduction.rate = providerDeduction.getRate();
      providerDeductionDetails.providerDeduction.startDate = providerDeduction.getDateRange().start();
      providerDeductionDetails.providerDeduction.endDate = providerDeduction.getDateRange().end();
      providerDeductionDetails.providerDeduction.recordStatus = providerDeduction.getLifecycleState().getCode();
      providerDeductionDetails.providerDeduction.businessStatus = providerDeduction.getBusinessStatus().getCode();
      providerDeductionDetails.providerDeduction.versionNo = providerDeduction.getVersionNo();
      
      providerDeductionDetailsList.deductionDetails.addRef(
        providerDeductionDetails);

    }

    return providerDeductionDetailsList;
  }

  /**
   * Lists all active applied and un-applied deductions for a provider.
   *
   * @param key
   * Provider key.
   * @return All the active applied and un-applied deductions for a provider.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderDeductionDetailsList listAppliedAndUnappliedDeductionForProvider(
    ProviderKey key) throws AppException, InformationalException {

    ProviderDeductionDetailsList providerDeductionDetailsList = new ProviderDeductionDetailsList();

    // Get all the active deductions of type applied and un-applied and sort it
    // based on ascending order of the priority
    Set<ProviderDeduction> providerDeductions = LifecycleHelper.filter(
      providerDeductionDAO.searchByProvider(
        providerDAO.get(key.providerConcernRoleID)),
        RECORDSTATUSEntry.NORMAL);

    for (ProviderDeduction providerDeduction : sortProviderDeductions(
      providerDeductions)) {
      if (providerDeduction.getCategory().equals(
        DEDUCTIONCATEGORYCODEEntry.APPLIEDDEDUCTION)
          || providerDeduction.getCategory().equals(
            DEDUCTIONCATEGORYCODEEntry.UNAPPLIEDDEDUCTION)) {

        ProviderDeductionDetails providerDeductionDetails = new ProviderDeductionDetails();

        providerDeductionDetails.providerDeduction.providerDeductionID = providerDeduction.getID();
        providerDeductionDetails.providerDeduction.category = providerDeduction.getCategory().getCode();
        providerDeductionDetails.providerDeduction.deductionName = providerDeduction.getDeductionName().getCode();
        providerDeductionDetails.providerDeduction.priority = providerDeduction.getPriority();
        providerDeductionDetails.providerDeduction.rate = providerDeduction.getRate();
        providerDeductionDetails.providerDeduction.startDate = providerDeduction.getDateRange().start();
        providerDeductionDetails.providerDeduction.endDate = providerDeduction.getDateRange().end();
        providerDeductionDetails.providerDeduction.recordStatus = providerDeduction.getLifecycleState().getCode();
        providerDeductionDetails.providerDeduction.businessStatus = providerDeduction.getBusinessStatus().getCode();
        providerDeductionDetails.providerDeduction.versionNo = providerDeduction.getVersionNo();

        providerDeductionDetailsList.deductionDetails.addRef(
          providerDeductionDetails);
      }
    }

    return providerDeductionDetailsList;
  }

  /**
   * Lists all the payments types applicable for the provider.
   *
   * @return List of all the payment types.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderPaymentKeyList listProviderPaymentType() throws AppException,
      InformationalException {
    ProviderPaymentKeyList providerPaymentKeyList = new ProviderPaymentKeyList();

    ProviderPaymentKey providerPaymentKey = new ProviderPaymentKey();

    providerPaymentKey.paymentType = PRODUCTTYPEEntry.PROVIDERINVOICE.getCode();
    providerPaymentKeyList.paymentKey.addRef(providerPaymentKey);

    providerPaymentKey = new ProviderPaymentKey();
    providerPaymentKey.paymentType = PRODUCTTYPEEntry.PROVIDERCONTRACT.getCode();
    providerPaymentKeyList.paymentKey.addRef(providerPaymentKey);

    providerPaymentKey = new ProviderPaymentKey();
    providerPaymentKey.paymentType = PRODUCTTYPEEntry.PROVIDERATTENDANCE.getCode();
    providerPaymentKeyList.paymentKey.addRef(providerPaymentKey);

    providerPaymentKey = new ProviderPaymentKey();
    providerPaymentKey.paymentType = PRODUCTTYPEEntry.PROVIDERPLACEMENT.getCode();
    providerPaymentKeyList.paymentKey.addRef(providerPaymentKey);

    return providerPaymentKeyList;
  }

  /**
   * List all provider deductions with a category of 'third party' for a
   * provider.
   *
   * @param key
   * Provider key.
   * @return List of all the active third party deductions for a provider.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderDeductionDetailsList listThirdPartyDeductionForProvider(
    ProviderKey key) throws AppException, InformationalException {

    ProviderDeductionDetailsList providerDeductionDetailsList = new ProviderDeductionDetailsList();

    // Get all the active deductions of type third party and sort it
    // based on ascending order of the priority
    Set<ProviderDeduction> providerDeductions = LifecycleHelper.filter(
      providerDeductionDAO.searchByProvider(
        providerDAO.get(key.providerConcernRoleID)),
        RECORDSTATUSEntry.NORMAL);

    for (ProviderDeduction providerDeduction : sortProviderDeductions(
      providerDeductions)) {
      if (providerDeduction.getCategory().equals(
        DEDUCTIONCATEGORYCODEEntry.THIRDPARTYDEDUCTION)) {

        ProviderDeductionDetails providerDeductionDetails = new ProviderDeductionDetails();

        providerDeductionDetails.providerDeduction.providerDeductionID = providerDeduction.getID();
        providerDeductionDetails.providerDeduction.category = providerDeduction.getCategory().getCode();
        providerDeductionDetails.providerDeduction.deductionName = providerDeduction.getDeductionName().getCode();
        providerDeductionDetails.providerDeduction.priority = providerDeduction.getPriority();
        providerDeductionDetails.providerDeduction.rate = providerDeduction.getRate();
        providerDeductionDetails.providerDeduction.startDate = providerDeduction.getDateRange().start();
        providerDeductionDetails.providerDeduction.endDate = providerDeduction.getDateRange().end();
        providerDeductionDetails.providerDeduction.recordStatus = providerDeduction.getLifecycleState().getCode();
        providerDeductionDetails.providerDeduction.businessStatus = providerDeduction.getBusinessStatus().getCode();
        providerDeductionDetails.providerDeduction.versionNo = providerDeduction.getVersionNo();

        providerDeductionDetailsList.deductionDetails.addRef(
          providerDeductionDetails);
      }
    }

    return providerDeductionDetailsList;
  }

  /**
   * Lists all third party deduction names and their associated categories and
   * priorities.
   *
   * @param details
   * Provider deduction details.
   * @return All the third party deductions on provider.
   * @throws InformationalException
   * {@link PROVIDERDEDUCTION#INF_PROVIDERDEDUCTION_XRV_ASSOCIATED_PRODUCT} -
   * If there is no third party deduction is associated to a product.
   * @throws AppException
   * Generic Exception Signature.
   */
  public DeductionNameList listThirdPartyDeductionNameForProvider(
    ProviderDeductionDetails details) throws AppException,
      InformationalException {

    DeductionNameList deductionNameList = new DeductionNameList();
    DeductionIDNamePriorityCategoryList deductionIDNamePriorityCategoryList = new DeductionIDNamePriorityCategoryList();
    ProductIDCategoryKey productIDCategoryKey = new ProductIDCategoryKey();
    curam.core.sl.entity.intf.DeductionProductLink deductionProductLinkObj = curam.core.sl.entity.fact.DeductionProductLinkFactory.newInstance();
    // BEGIN, CR00121968, SSH
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();
    StringBuffer productNameString = new StringBuffer();
    // END, CR00121968
    StringList paymentTypeList = StringUtil.delimitedText2StringList(
      details.paymentType, '\t');

    for (String paymentType : paymentTypeList.items()) {

      ProductDtls productDtls = getProduct(paymentType);

      productIDCategoryKey.productID = productDtls.productID;
      productIDCategoryKey.category = DEDUCTIONCATEGORYCODE.THIRDPARTYDEDUCTION;

      // Search for deductions for a specified product delivery and a certain
      // category
      try {
        deductionIDNamePriorityCategoryList = deductionProductLinkObj.searchIDNamePriorityCategoryByProductIDCategory(
          productIDCategoryKey);
      } catch (RecordNotFoundException rnfe) {// do nothing for now
      }

      if (deductionIDNamePriorityCategoryList.dtls.size() == 0) {

        // BEGIN, CR00121968, SSH
        // Replace codetable value for english equivalent
        String productName = curam.util.type.CodeTable.getOneItem(
          PRODUCTTYPE.TABLENAME, paymentType);

        if (productNameString.length() == CPMConstants.kZeroLong) {
          productNameString.append(productName);
        } else {
          productNameString.append(CPMConstants.kComma).append(CPMConstants.kEmptyString).append(
            productName);
        }
        // END, CR00121968
      }

      // BEGIN CR00122067, MST
      for (DeductionIDNamePriorityCategory deductionIDNamePriorityCategory : deductionIDNamePriorityCategoryList.dtls.items()) {

        boolean hasDeduction = false;

        for (DeductionNameListDetails nameListDetails : deductionNameList.dtlsList.items()) {

          if (nameListDetails.dtls.dtls.deductionName.equals(
            deductionIDNamePriorityCategory.deductionName)) {
            hasDeduction = true;
            break;
          }
        }

        if (!hasDeduction) {

          curam.core.struct.CaseDeductionNameDetails caseDeductionNameDetails = new curam.core.struct.CaseDeductionNameDetails();

          caseDeductionNameDetails.dtls.assign(deductionIDNamePriorityCategory);

          DeductionNameListDetails deductionNameListDetails = new DeductionNameListDetails();

          deductionNameListDetails.dtls.assign(caseDeductionNameDetails);
          deductionNameList.dtlsList.addRef(deductionNameListDetails);
        }
      }
      // END CR00122067

    }

    // BEGIN, CR00121968, SSH
    if (productNameString.length() != CPMConstants.kZeroLong) {
      // Add the message to the informational manager
      AppException e = new AppException(
        PROVIDERDEDUCTION.INF_PROVIDERDEDUCTION_XRV_ASSOCIATED_PRODUCT);

      // Replace codetable value for english equivalent
      curam.util.type.CodeTableItemIdentifier category = new CodeTableItemIdentifier(
        DEDUCTIONCATEGORYCODE.TABLENAME,
        DEDUCTIONCATEGORYCODE.THIRDPARTYDEDUCTION);

      // Populate message placeholder with category of deduction
      e.arg(category).arg(productNameString);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // END, CR00121968

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      deductionNameList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return deductionNameList;
  }

  /**
   * Lists all the selected provider payment types.
   *
   * @param details
   * Provider deduction details.
   * @return Provider deduction details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderDeductionDetails listSelectedProviderPaymentType(
    ProviderDeductionDetails details) throws AppException,
      InformationalException {
    // Do nothing
    return details;
  }

  /**
   * Creates third party variable deduction for provider.
   *
   * @param details
   * Provider Deduction Details.
   * @return Information message list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationMsgDtlsList createThirdPartyVariableDeductionForProvider(
    ProviderDeductionDetails details) throws AppException,
      InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    ProviderDeduction providerDeduction = providerDeductionDAO.newInstance();

    providerDeduction.setComments(details.providerDeduction.comments);
    providerDeduction.setProvider(providerDAO.get(details.concernRoleID));
    providerDeduction.setDateRange(
      new DateRange(details.providerDeduction.startDate,
      details.providerDeduction.endDate));

    providerDeduction.setCustomerAccNumber(
      details.providerDeduction.customerAccNumber);

    // BEGIN, CR00323260, MR

    providerDeduction.setPriority(processPriority(details).dtls.priority);
    // END, CR00323260
    
    providerDeduction.setRate(details.providerDeduction.rate);
    providerDeduction.setCustomerAccName(
      details.providerDeduction.customerAccName);
    providerDeduction.setActionType(
      DEDUCTIONACTIONTYPEEntry.get(details.providerDeduction.actionType));
    providerDeduction.setThirdPartyConcernRoleID(
      details.providerDeduction.thirdPartyConcernRoleID);

    // BEGIN, CR00246209, GP
    providerDeduction.setDeductionName(
      DEDUCTIONNAMEEntry.get(details.deductionName));
    // END, CR00246209
    providerDeduction.setCategory(
      DEDUCTIONCATEGORYCODEEntry.get(details.providerDeduction.category));
    providerDeduction.insert();

    // Get all the provider payment types for which third party variable
    // deduction is applicable
    StringList paymentTypeList = StringUtil.delimitedText2StringList(
      details.paymentType, '\t');

    for (String paymentType : paymentTypeList.items()) {

      ProductIDCategoryKey productIDCategoryKey = new ProductIDCategoryKey();
      DeductionIDNamePriorityCategoryList deductionIDNamePriorityCategoryList = new DeductionIDNamePriorityCategoryList();
      curam.core.sl.entity.intf.DeductionProductLink deductionProductLinkObj = curam.core.sl.entity.fact.DeductionProductLinkFactory.newInstance();

      ProductDtls productDtls = getProduct(paymentType);

      productIDCategoryKey.productID = productDtls.productID;
      productIDCategoryKey.category = providerDeduction.getCategory().getCode();

      // Search for deductions for a specified product delivery and a certain
      // category
      try {
        deductionIDNamePriorityCategoryList = deductionProductLinkObj.searchIDNamePriorityCategoryByProductIDCategory(
          productIDCategoryKey);
      } catch (RecordNotFoundException rnfe) {// do nothing for now
      }

      if (deductionIDNamePriorityCategoryList.dtls.size() > 0) {

        // BEGIN CR00122067, MST
        for (DeductionIDNamePriorityCategory deductionIDNamePriorityCategory : deductionIDNamePriorityCategoryList.dtls.items()) {

          if (deductionIDNamePriorityCategory.deductionName.equals(
            details.providerDeduction.deductionName)) {

            Deduction deductionObj = DeductionFactory.newInstance();

            DeductionKey deductionKey = new DeductionKey();

            deductionKey.key.deductionID = deductionIDNamePriorityCategory.deductionID;

            ReadDeductionDetails readDeductionDetails = deductionObj.read(
              deductionKey);

            // BEGIN CR00127325, SS
            if (CPMConstants.kZeroLong
              != readDeductionDetails.dtls.maxPercentage) {
              if (details.providerDeduction.rate
                > readDeductionDetails.dtls.maxPercentage) {

                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                  PROVIDERDEDUCTIONExceptionCreator.ERR_PROVIDERDEDUCTION_XRV_PERCENTAGE_GREATER_THAN_MAXIMUM_PERCENTAGE(
                    details.providerDeduction.rate,
                    readDeductionDetails.dtls.maxPercentage),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                    1);
              }
            }
            // END CR00127325
          }
        }
        // END CR00122067

        ProviderDeductionProductLink providerDeductionProductLink = providerDeductionProductLinkDAO.newInstance();

        providerDeductionProductLink.setProductType(
          PRODUCTTYPEEntry.get(paymentType));
        providerDeductionProductLink.setProviderDeduction(providerDeduction);
        providerDeductionProductLink.insert();
      }
    }

    informationMsgDtlsList = providerDeduction.createDeductionForExistingCases();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // BEGIN, CR00323260, MR
  /**
   * Validates the priority details, then sets the next priority if specified
   * by user. If next priority is left blank then the new priority is set from
   * the priority entered by the user. Existing deduction priorities are
   * reordered if a deduction exists whose priority equals the new priority.
   *
   * @param providerDeductionDetails
   * Provider deduction details needed for processing existing
   * priorities if necessary.
   *
   * @return The priority of the deduction.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected Priority processPriority(
    final ProviderDeductionDetails providerDeductionDetails)
    throws AppException, InformationalException {
    final PriorityDetails priorityDetails = new PriorityDetails();

    priorityDetails.applyNextPriorityInd = providerDeductionDetails.applyNextPriorityInd;
    priorityDetails.priority = providerDeductionDetails.providerDeduction.priority;

    DeductionFactory.newInstance().validatePriority(priorityDetails);

    Priority newPriority = new Priority();

    newPriority.dtls.priority = providerDeductionDetails.providerDeduction.priority;
    boolean priorityAlreadyExists = true;

    // If the 'Assign Next Priority' indicator has been set to true
    // then set the next lowest priority.

    if (providerDeductionDetails.applyNextPriorityInd) {
      final curam.provider.impl.Provider provider = providerDAO.get(
        providerDeductionDetails.concernRoleID);

      newPriority.dtls.priority = providerDeductionDAO.getLowestPriority(
        provider);
    } else {

      // Check if the priority entered already exists for an active
      // deduction.
      final curam.provider.impl.Provider provider = providerDAO.get(
        providerDeductionDetails.concernRoleID);

      if (null
        == providerDeductionDAO.readActiveDeductionByProviderAndPriority(
          provider, providerDeductionDetails.providerDeduction.priority)) {
        priorityAlreadyExists = false;
      }

      // If the priority already exists then any existing deduction
      // priorities that are affected by the current deduction record
      // are reordered so that no duplicate priorities exist.
      if (priorityAlreadyExists) {

        // Reorder affected deductions.
        reorderPriority(providerDeductionDetails);
      }
    }
    return newPriority;
  }

  /**
   * Performs checks on the priority of a modified provider deduction to see
   * if further processing is required.
   *
   * @param providerDeductionDetails
   * Contains provider deduction details.
   *
   * @return The priority of the deduction.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected Priority processModifiedPriority(
    final ProviderDeductionDetails providerDeductionDetails)
    throws AppException, InformationalException {

    // Read the old priority to check if it has been modified.
    final Priority oldPriority = new Priority();

    oldPriority.dtls.priority = providerDeductionDAO.get(providerDeductionDetails.providerDeduction.providerDeductionID).getPriority();

    boolean priorityModified = false;

    // If the 'Assign Next Priority' indicator has been set to true then
    // need to check if the original priority of the record being
    // modified is already the lowest. If it is not then
    // the priority will be modified.
    if (providerDeductionDetails.applyNextPriorityInd) {

      // Get the current lowest priority in the provider deduction table.
      final curam.provider.impl.Provider provider = providerDAO.get(
        providerDeductionDetails.concernRoleID);
      final Priority lowestPriority = new Priority();

      lowestPriority.dtls.priority = providerDeductionDAO.getLowestPriority(
        provider);

      // Get the list of active deductions.
      final Set<ProviderDeduction> providerDeductions = LifecycleHelper.filter(
        providerDeductionDAO.searchByProvider(
          providerDAO.get(providerDeductionDetails.concernRoleID)),
          RECORDSTATUSEntry.NORMAL);

      // If only one deduction exists in the list and assign next priority
      // has been selected, return priority to have a value of 1.
      if (1 == providerDeductions.size()) {

        // Set priority to be one.
        providerDeductionDetails.providerDeduction.priority = 1;

      } // If the lowest is already the priority of this deduction
      // then the priority is not modified.
      else if (oldPriority.dtls.priority != lowestPriority.dtls.priority) {

        priorityModified = true;

      } else {

        // Need to reset the priority to the next lowest.
        final PriorityDetails priorityDetails = new PriorityDetails();

        priorityDetails.applyNextPriorityInd = providerDeductionDetails.applyNextPriorityInd;
        priorityDetails.priority = providerDeductionDetails.providerDeduction.priority;

        DeductionFactory.newInstance().validatePriority(priorityDetails);

        providerDeductionDetails.providerDeduction.priority = oldPriority.dtls.priority;

        // The current priority is disregarded as it is already the
        // lowest. The second lowest is then retrieved and incremented
        // by 1.
        final int secondLowestPriority = providerDeductions.size() - 2;

        // Increment the second lowest priority by 1.
        final List<ProviderDeduction> providerDeductionList = new ArrayList<ProviderDeduction>(
          providerDeductions);

        if (!providerDeductions.isEmpty()) {
          providerDeductionDetails.providerDeduction.priority = providerDeductionList.get(secondLowestPriority).getPriority()
            + 1;
        }
      }

    } // Check if the old priority is the same as the priority in the
    // modified deduction details.
    else if (oldPriority.dtls.priority
      != providerDeductionDetails.providerDeduction.priority) {
      priorityModified = true;
    }

    // If the priority has been modified then the value needs to
    // be checked and processed.
    if (priorityModified) {

      // Process the priority details.
      final Priority newPriority = processPriority(providerDeductionDetails);

      providerDeductionDetails.providerDeduction.priority = newPriority.dtls.priority;
    }

    final Priority processedPriority = new Priority();

    processedPriority.dtls.priority = providerDeductionDetails.providerDeduction.priority;
    return processedPriority;
  }

  /**
   * Updates an existing deduction priorities for a provider when adding or
   * modifying a priority whose value already exists.
   *
   * @param providerDeductionDetails
   * Contains provider deduction details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void reorderPriority(
    final ProviderDeductionDetails providerDeductionDetails)
    throws AppException, InformationalException {

    final DeductionIDPriorityList deductionIDPriorityList = new DeductionIDPriorityList();

    // Get the list of active deductions.
    final Set<ProviderDeduction> providerDeductions = LifecycleHelper.filter(
      providerDeductionDAO.searchByProvider(
        providerDAO.get(providerDeductionDetails.concernRoleID)),
        RECORDSTATUSEntry.NORMAL);

    for (final ProviderDeduction providerDeduction : sortProviderDeductions(
      providerDeductions)) {
      final curam.core.sl.entity.struct.DeductionIDPriority deductionIDPriority = new curam.core.sl.entity.struct.DeductionIDPriority();

      deductionIDPriority.deductionID = providerDeduction.getID();
      deductionIDPriority.priority = providerDeduction.getPriority();
      deductionIDPriorityList.list.dtls.addRef(deductionIDPriority);
    }

    final DeductionIDPriority dedctnIDPrty = new DeductionIDPriority();

    dedctnIDPrty.dtls.deductionID = providerDeductionDetails.providerDeduction.providerDeductionID;
    dedctnIDPrty.dtls.priority = providerDeductionDetails.providerDeduction.priority;

    // Sort the current list so that no duplicate priorities exist.
    // The list of deductions to be modified is returned. This list
    // contains the deduction id with the new priority value.
    final DeductionIDPriorityList deductionIDPriorityListToModify = DeductionFactory.newInstance().sortPriority(
      dedctnIDPrty, deductionIDPriorityList);

    for (final curam.core.sl.entity.struct.DeductionIDPriority deductionIDPriority : deductionIDPriorityListToModify.list.dtls) {

      // If the deduction id is 0 then the deduction is being created
      // and cannot be modified.

      if (deductionIDPriority.deductionID != 0) {

        final ProviderDeductionKey providerDeductionKey = new ProviderDeductionKey();

        providerDeductionKey.providerDeductionID = deductionIDPriority.deductionID;

        final ProviderDeductionPriorityDetails deductionPriorityDetails = new ProviderDeductionPriorityDetails();

        deductionPriorityDetails.priority = deductionIDPriority.priority;

        ProviderDeductionFactory.newInstance().modifyPriority(
          providerDeductionKey, deductionPriorityDetails);
      }
    }
  }

  // END, CR00323260
  
  /**
   * Returns the concern role id for the selected client.
   *
   * @param details
   * Client details.
   * @return Concern role id.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ConcernRoleID getDeductionClient(DeductionClientDetails details)
    throws AppException, InformationalException {
    ConcernRoleID concernRoleID = new ConcernRoleID();

    curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();

    maintainDeductionItemsObj.validateLiabilityClient(details.dtls);

    concernRoleID.concernRoleID = details.dtls.clientConcernRoleID;
    return concernRoleID;
  }

  /**
   * Returns initial data on the applied, fixed and variable deductions.
   *
   * @param details
   * Provider deduction details.
   * @return Initial display data for create deduction pages.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public DefaultDeductionDetails readDefaultDeductionDetailsForProvider(
    ProviderDeductionDetails details) throws AppException,
      InformationalException {

    DefaultDeductionDetails defaultDeductionDetails = new DefaultDeductionDetails();
    Deduction deductionObj = DeductionFactory.newInstance();
    ReadDeductionDtls readDeductionDtls = new ReadDeductionDtls();

    DeductionName deductionName = new DeductionName();

    deductionName.deductionName = details.deductionName;

    ReadDeductionDetails readDeductionDetails = deductionObj.readDeductionDetailsByName(
      deductionName);

    readDeductionDetails.dtls.priority = providerDeductionDAO.readMaxPriority()
      + 1;

    readDeductionDtls.dtls.assign(readDeductionDetails);

    defaultDeductionDetails.deductionDtls.assign(readDeductionDtls);

    if (details.liabilityConcernRoleID != 0) {
      ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = details.liabilityConcernRoleID;

      ConcernRoleNameDetails concernRoleNameDetails = concernRoleObj.readConcernRoleName(
        concernRoleKey);

      defaultDeductionDetails.liabilityConcernRoleName = concernRoleNameDetails.concernRoleName;
    }

    return defaultDeductionDetails;
  }

  /**
   * Creates variable deduction for a provider.
   *
   * @param details
   * Provider deduction details.
   * @return Information message list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationMsgDtlsList createVariableDeductionForProvider(
    ProviderDeductionDetails details) throws AppException,
      InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    ProviderDeduction providerDeduction = providerDeductionDAO.newInstance();

    providerDeduction.setProvider(providerDAO.get(details.concernRoleID));
    providerDeduction.setCategory(
      DEDUCTIONCATEGORYCODEEntry.get(details.providerDeduction.category));
    providerDeduction.setDeductionName(
      DEDUCTIONNAMEEntry.get(details.providerDeduction.deductionName));
    providerDeduction.setActionType(
      DEDUCTIONACTIONTYPEEntry.get(details.providerDeduction.actionType));
    providerDeduction.setRelatedCaseID(details.providerDeduction.relatedCaseID);

    providerDeduction.setDateRange(
      new DateRange(details.providerDeduction.startDate,
      details.providerDeduction.endDate));

    providerDeduction.setRate(details.providerDeduction.rate);

    // BEGIN, CR00323260, MR

    providerDeduction.setPriority(processPriority(details).dtls.priority);
    // END, CR00323260

    providerDeduction.setComments(details.providerDeduction.comments);
    providerDeduction.insert();

    // Get all the provider payment types for which applied and un-applied
    // variable deduction is applicable
    StringList paymentTypeList = StringUtil.delimitedText2StringList(
      details.paymentType, '\t');

    for (String paymentType : paymentTypeList.items()) {

      ProductIDCategoryKey productIDCategoryKey = new ProductIDCategoryKey();
      DeductionIDNamePriorityCategoryList deductionIDNamePriorityCategoryList = new DeductionIDNamePriorityCategoryList();
      curam.core.sl.entity.intf.DeductionProductLink deductionProductLinkObj = curam.core.sl.entity.fact.DeductionProductLinkFactory.newInstance();

      ProductDtls productDtls = getProduct(paymentType);

      productIDCategoryKey.productID = productDtls.productID;
      productIDCategoryKey.category = providerDeduction.getCategory().getCode();

      // Search for deductions for a specified product delivery and a certain
      // category
      try {
        deductionIDNamePriorityCategoryList = deductionProductLinkObj.searchIDNamePriorityCategoryByProductIDCategory(
          productIDCategoryKey);
      } catch (RecordNotFoundException rnfe) {// do nothing for now
      }

      if (deductionIDNamePriorityCategoryList.dtls.size() > 0) {

        // BEGIN CR00122067, MST
        for (DeductionIDNamePriorityCategory deductionIDNamePriorityCategory : deductionIDNamePriorityCategoryList.dtls.items()) {

          if (deductionIDNamePriorityCategory.deductionName.equals(
            details.providerDeduction.deductionName)) {

            Deduction deductionObj = DeductionFactory.newInstance();

            DeductionKey deductionKey = new DeductionKey();

            deductionKey.key.deductionID = deductionIDNamePriorityCategory.deductionID;

            ReadDeductionDetails readDeductionDetails = deductionObj.read(
              deductionKey);

            // BEGIN CR00127325, SS
            if (CPMConstants.kZeroLong
              != readDeductionDetails.dtls.maxPercentage) {
              if (details.providerDeduction.rate
                > readDeductionDetails.dtls.maxPercentage) {

                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                  PROVIDERDEDUCTIONExceptionCreator.ERR_PROVIDERDEDUCTION_XRV_PERCENTAGE_GREATER_THAN_MAXIMUM_PERCENTAGE(
                    details.providerDeduction.rate,
                    readDeductionDetails.dtls.maxPercentage),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                    0);
              }
            }
            // END CR00127325

          }
        }
        // END CR00122067
        // BEGIN, CR00260544, SSK
      }
      // END, CR00260544
      ProviderDeductionProductLink providerDeductionProductLink = providerDeductionProductLinkDAO.newInstance();

      providerDeductionProductLink.setProductType(
        PRODUCTTYPEEntry.get(paymentType));
      providerDeductionProductLink.setProviderDeduction(providerDeduction);
      providerDeductionProductLink.insert();
    
    }

    informationMsgDtlsList = providerDeduction.createDeductionForExistingCases();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  /**
   * Lists all un-applied deduction names and their associated categories and
   * priorities.
   *
   * @param details
   * @return Deduction name list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public DeductionNameList listUnappliedDeductionNameForProvider(
    ProviderDeductionDetails details) throws AppException,
      InformationalException {

    DeductionNameList deductionNameList = new DeductionNameList();
    DeductionIDNamePriorityCategoryList deductionIDNamePriorityCategoryList = new DeductionIDNamePriorityCategoryList();
    ProductIDCategoryKey productIDCategoryKey = new ProductIDCategoryKey();
    curam.core.sl.entity.intf.DeductionProductLink deductionProductLinkObj = curam.core.sl.entity.fact.DeductionProductLinkFactory.newInstance();
    // BEGIN, CR00121968, SSH
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();
    StringBuffer productNameString = new StringBuffer();
    // END, CR00121968

    // Get all the provider payment types for which un-applied
    // variable deduction is applicable
    StringList paymentTypeList = StringUtil.delimitedText2StringList(
      details.paymentType, '\t');

    for (String paymentType : paymentTypeList.items()) {

      ProductDtls productDtls = getProduct(paymentType);

      productIDCategoryKey.productID = productDtls.productID;
      productIDCategoryKey.category = DEDUCTIONCATEGORYCODE.UNAPPLIEDDEDUCTION;

      // Search for deductions for a specified product delivery and a certain
      // category
      try {
        deductionIDNamePriorityCategoryList = deductionProductLinkObj.searchIDNamePriorityCategoryByProductIDCategory(
          productIDCategoryKey);
      } catch (RecordNotFoundException rnfe) {// do nothing for now
      }

      if (deductionIDNamePriorityCategoryList.dtls.size() == 0) {

        // BEGIN, CR00121968, SSH
        // Replace codetable value for english equivalent
        String productName = curam.util.type.CodeTable.getOneItem(
          PRODUCTTYPE.TABLENAME, paymentType);

        if (productNameString.length() == CPMConstants.kZeroLong) {
          productNameString.append(productName);
        } else {
          productNameString.append(CPMConstants.kComma).append(CPMConstants.kEmptyString).append(
            productName);
        }
        // END, CR00121968
      }

      // BEGIN CR00122067, MST
      for (DeductionIDNamePriorityCategory deductionIDNamePriorityCategory : deductionIDNamePriorityCategoryList.dtls.items()) {

        boolean hasDeduction = false;

        for (DeductionNameListDetails nameListDetails : deductionNameList.dtlsList.items()) {

          if (nameListDetails.dtls.dtls.deductionName.equals(
            deductionIDNamePriorityCategory.deductionName)) {
            hasDeduction = true;
            break;
          }
        }

        if (!hasDeduction) {

          curam.core.struct.CaseDeductionNameDetails caseDeductionNameDetails = new curam.core.struct.CaseDeductionNameDetails();

          caseDeductionNameDetails.dtls.assign(deductionIDNamePriorityCategory);

          DeductionNameListDetails deductionNameListDetails = new DeductionNameListDetails();

          deductionNameListDetails.dtls.assign(caseDeductionNameDetails);
          deductionNameList.dtlsList.addRef(deductionNameListDetails);
        }
      }
      // END CR00122067

    }
    // BEGIN, CR00121968, SSH
    if (productNameString.length() != CPMConstants.kZeroLong) {
      // Add the message to the informational manager
      AppException e = new AppException(
        PROVIDERDEDUCTION.INF_PROVIDERDEDUCTION_XRV_ASSOCIATED_PRODUCT);

      // Replace codetable value for english equivalent
      curam.util.type.CodeTableItemIdentifier category = new CodeTableItemIdentifier(
        DEDUCTIONCATEGORYCODE.TABLENAME,
        DEDUCTIONCATEGORYCODE.UNAPPLIEDDEDUCTION);

      // Populate message placeholder with category of deduction
      e.arg(category).arg(productNameString);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }
    // END, CR00121968
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      deductionNameList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return deductionNameList;
  }

  /**
   * Lists all applied deduction names and their associated categories and
   * priorities.
   *
   * @param details
   * Provider deduction details.
   * @return Deduction name list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public DeductionNameList listAppliedDeductionNameForProvider(
    ProviderDeductionDetails details) throws AppException,
      InformationalException {

    DeductionNameList deductionNameList = new DeductionNameList();
    DeductionIDNamePriorityCategoryList deductionIDNamePriorityCategoryList = new DeductionIDNamePriorityCategoryList();
    ProductIDCategoryKey productIDCategoryKey = new ProductIDCategoryKey();
    curam.core.sl.entity.intf.DeductionProductLink deductionProductLinkObj = curam.core.sl.entity.fact.DeductionProductLinkFactory.newInstance();
    // BEGIN, CR00121968, SSH
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();
    StringBuffer productNameString = new StringBuffer();
    // END, CR00121968
    StringList paymentTypeList = StringUtil.delimitedText2StringList(
      details.paymentType, '\t');

    for (String paymentType : paymentTypeList.items()) {

      ProductDtls productDtls = getProduct(paymentType);

      productIDCategoryKey.productID = productDtls.productID;
      productIDCategoryKey.category = DEDUCTIONCATEGORYCODE.APPLIEDDEDUCTION;

      // Search for deductions for a specified product delivery and a certain
      // category
      try {
        deductionIDNamePriorityCategoryList = deductionProductLinkObj.searchIDNamePriorityCategoryByProductIDCategory(
          productIDCategoryKey);
      } catch (RecordNotFoundException rnfe) {// do nothing for now
      }

      if (deductionIDNamePriorityCategoryList.dtls.size() == 0) {

        // BEGIN, CR00121968, SSH
        // Replace codetable value for english equivalent
        String productName = curam.util.type.CodeTable.getOneItem(
          PRODUCTTYPE.TABLENAME, paymentType);

        if (productNameString.length() == CPMConstants.kZeroLong) {
          productNameString.append(productName);
        } else {
          productNameString.append(CPMConstants.kComma).append(CPMConstants.kEmptyString).append(
            productName);
        }
        // END, CR00121968
      }

      // BEGIN CR00122067, MST
      for (DeductionIDNamePriorityCategory deductionIDNamePriorityCategory : deductionIDNamePriorityCategoryList.dtls.items()) {

        boolean hasDeduction = false;

        for (DeductionNameListDetails nameListDetails : deductionNameList.dtlsList.items()) {

          if (nameListDetails.dtls.dtls.deductionName.equals(
            deductionIDNamePriorityCategory.deductionName)) {
            hasDeduction = true;
            break;
          }
        }

        if (!hasDeduction) {

          curam.core.struct.CaseDeductionNameDetails caseDeductionNameDetails = new curam.core.struct.CaseDeductionNameDetails();

          caseDeductionNameDetails.dtls.assign(deductionIDNamePriorityCategory);

          DeductionNameListDetails deductionNameListDetails = new DeductionNameListDetails();

          deductionNameListDetails.dtls.assign(caseDeductionNameDetails);
          deductionNameList.dtlsList.addRef(deductionNameListDetails);
        }
      }
      // END CR00122067

    }

    // BEGIN, CR00121968, SSH
    if (productNameString.length() != CPMConstants.kZeroLong) {
      // Add the message to the informational manager
      AppException e = new AppException(
        PROVIDERDEDUCTION.INF_PROVIDERDEDUCTION_XRV_ASSOCIATED_PRODUCT);

      // Replace codetable value for english equivalent
      curam.util.type.CodeTableItemIdentifier category = new CodeTableItemIdentifier(
        DEDUCTIONCATEGORYCODE.TABLENAME, DEDUCTIONCATEGORYCODE.APPLIEDDEDUCTION);

      // Populate message placeholder with category of deduction
      e.arg(category).arg(productNameString);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    // END, CR00121968

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      deductionNameList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return deductionNameList;
  }

  /**
   * Activates provider deduction.
   *
   * @param details
   * Provider deduction details.
   * @return Information message list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationMsgDtlsList activateProviderDeduction(
    ProviderDeductionModifyDetails details) throws AppException,
      InformationalException {

    ProviderDeduction providerDeduction = providerDeductionDAO.get(
      details.providerDeductionID);

    InformationMsgDtlsList informationMsgDtlsList = providerDeduction.activateProviderDeduction(
      details.versionNo);

    return informationMsgDtlsList;
  }

  /**
   * Cancels provider deduction.
   *
   * @param details
   * Provider deduction details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancelProviderDeduction(ProviderDeductionModifyDetails details)
    throws AppException, InformationalException {

    ProviderDeduction providerDeduction = providerDeductionDAO.get(
      details.providerDeductionID);

    providerDeduction.cancel(details.versionNo);

  }

  /**
   * Deactivated provider deduction.
   *
   * @param details
   * Provider deduction details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deactivateProviderDeduction(ProviderDeductionModifyDetails details)
    throws AppException, InformationalException {

    ProviderDeduction providerDeduction = providerDeductionDAO.get(
      details.providerDeductionID);

    providerDeduction.deactivateProviderDeduction(details.versionNo);
  }

  /**
   * Modifies provider deduction.
   *
   * @param details
   * Provider deduction details.
   * @return Information message list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationMsgDtlsList modifyProviderDeduction(
    ProviderDeductionDetails details) throws AppException,
      InformationalException {

    Deduction deduction = DeductionFactory.newInstance();

    PriorityDetails priorityDetails = new PriorityDetails();

    priorityDetails.applyNextPriorityInd = details.applyNextPriorityInd;
    priorityDetails.priority = details.providerDeduction.priority;
    deduction.validatePriority(priorityDetails);

    ProviderDeduction providerDeduction = providerDeductionDAO.get(
      details.providerDeduction.providerDeductionID);

    providerDeduction.setDateRange(
      new DateRange(details.providerDeduction.startDate,
      details.providerDeduction.endDate));
    providerDeduction.setRate(details.providerDeduction.rate);

    // BEGIN, CR00323260, MR
    
    details.concernRoleID = providerDeduction.getProvider().getID();
    providerDeduction.setPriority(
      processModifiedPriority(details).dtls.priority);
    // END, CR00323260

    providerDeduction.setComments(details.providerDeduction.comments);
    providerDeduction.setCustomerAccName(
      details.providerDeduction.customerAccName);
    providerDeduction.setCustomerAccNumber(
      details.providerDeduction.customerAccNumber);

    // BEGIN CR00122067, MST
    for (ProviderDeductionProductLink providerDeductionProductLink : providerDeductionProductLinkDAO.searchByProviderDeduction(
      providerDeduction)) {

      String paymentType = providerDeductionProductLink.getProductType().getCode();

      ProductIDCategoryKey productIDCategoryKey = new ProductIDCategoryKey();
      DeductionIDNamePriorityCategoryList deductionIDNamePriorityCategoryList = new DeductionIDNamePriorityCategoryList();
      curam.core.sl.entity.intf.DeductionProductLink deductionProductLinkObj = curam.core.sl.entity.fact.DeductionProductLinkFactory.newInstance();

      ProductDtls productDtls = getProduct(paymentType);

      productIDCategoryKey.productID = productDtls.productID;
      productIDCategoryKey.category = providerDeduction.getCategory().getCode();

      // Search for deductions for a specified product delivery and a certain
      // category
      try {
        deductionIDNamePriorityCategoryList = deductionProductLinkObj.searchIDNamePriorityCategoryByProductIDCategory(
          productIDCategoryKey);
      } catch (RecordNotFoundException rnfe) {// do nothing for now
      }

      if (deductionIDNamePriorityCategoryList.dtls.size() > 0) {

        for (DeductionIDNamePriorityCategory deductionIDNamePriorityCategory : deductionIDNamePriorityCategoryList.dtls.items()) {

          if (deductionIDNamePriorityCategory.deductionName.equals(
            providerDeduction.getDeductionName().getCode())) {

            Deduction deductionObj = DeductionFactory.newInstance();

            DeductionKey deductionKey = new DeductionKey();

            deductionKey.key.deductionID = deductionIDNamePriorityCategory.deductionID;

            ReadDeductionDetails readDeductionDetails = deductionObj.read(
              deductionKey);

            // BEGIN CR00127325, SS
            if (CPMConstants.kZeroLong
              != readDeductionDetails.dtls.maxPercentage) {
              if (details.providerDeduction.rate
                > readDeductionDetails.dtls.maxPercentage) {

                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                  PROVIDERDEDUCTIONExceptionCreator.ERR_PROVIDERDEDUCTION_XRV_PERCENTAGE_GREATER_THAN_MAXIMUM_PERCENTAGE(
                    details.providerDeduction.rate,
                    readDeductionDetails.dtls.maxPercentage),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                    2);
              }
            }
            // END CR00127325
          }
        }
      }
    }
    // END CR00122067
    
    // BEGIN, CR00129985, SK
    InformationMsgDtlsList informationMsgDtlsList = providerDeduction.modifyDeductionForExistingCases();    

    providerDeduction.modify(details.providerDeduction.versionNo);
    // END, CR00129985
    
    return informationMsgDtlsList;
  }

  /**
   * Views provider deduction.
   *
   * @param key
   * Provider deduction key.
   * @return Provider deduction details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderDeductionDetails viewProviderDeduction(ProviderDeductionKey key)
    throws AppException, InformationalException {

    ProviderDeductionDetails providerDeductionDetails = new ProviderDeductionDetails();

    ProviderDeduction providerDeduction = providerDeductionDAO.get(
      key.providerDeductionID);

    providerDeductionDetails.providerDeduction.versionNo = providerDeduction.getVersionNo();
    providerDeductionDetails.providerDeduction.deductionName = providerDeduction.getDeductionName().getCode();
    providerDeductionDetails.liabilityConcernRoleName = providerDeduction.getProvider().getName();
    providerDeductionDetails.liabilityConcernRoleID = providerDeduction.getProvider().getID();
    providerDeductionDetails.providerDeduction.startDate = providerDeduction.getDateRange().start();
    providerDeductionDetails.providerDeduction.endDate = providerDeduction.getDateRange().end();
    providerDeductionDetails.providerDeduction.rate = providerDeduction.getRate();
    providerDeductionDetails.providerDeduction.createdDate = providerDeduction.getCreatedDate();
    providerDeductionDetails.providerDeduction.actionType = providerDeduction.getActionType().getCode();
    providerDeductionDetails.providerDeduction.priority = providerDeduction.getPriority();

    if (providerDeduction.getRelatedCaseID() != 0) {
      CachedCaseHeader caseHeaderObj = CachedCaseHeaderFactory.newInstance();
      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = providerDeduction.getRelatedCaseID();

      CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      providerDeductionDetails.relatedCaseReference = caseHeaderDtls.caseReference;
    }

    providerDeductionDetails.providerDeduction.businessStatus = providerDeduction.getBusinessStatus().getCode();
    providerDeductionDetails.providerDeduction.recordStatus = providerDeduction.getLifecycleState().getCode();
    providerDeductionDetails.providerDeduction.comments = providerDeduction.getComments();
    providerDeductionDetails.providerDeduction.customerAccName = providerDeduction.getCustomerAccName();
    providerDeductionDetails.providerDeduction.customerAccNumber = providerDeduction.getCustomerAccNumber();
    providerDeductionDetails.providerDeduction.thirdPartyConcernRoleID = providerDeduction.getThirdPartyConcernRoleID();
    if (providerDeduction.getThirdPartyConcernRoleID() != 0) {
      curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
        providerDeduction.getThirdPartyConcernRoleID());

      providerDeductionDetails.thirdPartyConcernRoleType = concernRole.getConcernRoleType().getCode();
      providerDeductionDetails.liabilityConcernRoleName = concernRole.getName();
    }

    providerDeductionDetails.providerDeduction.providerDeductionID = key.providerDeductionID;
    providerDeductionDetails.providerDeduction.providerConcernRoleID = providerDeduction.getProvider().getID();

    Set<ProviderDeductionProductLink> providerDeductionProductLinks = providerDeductionProductLinkDAO.searchByProviderDeduction(
      providerDeduction);

    for (ProviderDeductionProductLink providerDeductionProductLink : providerDeductionProductLinks) {
      providerDeductionDetails.paymentType += CodeTable.getOneItem(
        PRODUCTTYPEEntry.TABLENAME,
        providerDeductionProductLink.getProductType().getCode())
          + ',';
    }

    if (providerDeductionDetails.paymentType.length() > 0) {
      providerDeductionDetails.paymentType = providerDeductionDetails.paymentType.substring(
        0, providerDeductionDetails.paymentType.length() - 1);
    }

    return providerDeductionDetails;
  }

  /**
   * Modifies provider payment type.
   *
   * @param details
   * Provider deduction details.
   * @return Information message list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationMsgDtlsList modifyPaymentType(
    ProviderDeductionDetails details) throws AppException,
      InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    CaseDeductionItem caseDeductionItem = CaseDeductionItemFactory.newInstance();
    curam.core.facade.intf.ProductDelivery productDelivery = curam.core.facade.fact.ProductDeliveryFactory.newInstance();

    ProviderDeduction providerDeduction = providerDeductionDAO.get(
      details.providerDeduction.providerDeductionID);

    // Get all the payment types for which provider deduction is applicable.
    // Compare it with the payment types from the input.
    StringList paymentTypeList = StringUtil.delimitedText2StringList(
      details.paymentType, '\t');

    for (String paymentType : paymentTypeList.items()) {

      boolean paymentTypeExist = false;

      Set<ProviderDeductionProductLink> providerDeductionProductLinks = providerDeductionProductLinkDAO.searchByProviderDeduction(
        providerDeduction);

      for (ProviderDeductionProductLink providerDeductionProductLink : providerDeductionProductLinks) {
        if (providerDeductionProductLink.getProductType().getCode().equals(
          paymentType)) {
          paymentTypeExist = true;
        }
      }

      // If it is a new payment type then create the deduction.
      if (!paymentTypeExist) {
        ProviderDeductionProductLink providerDeductionProductLink = providerDeductionProductLinkDAO.newInstance();

        providerDeductionProductLink.setProductType(
          PRODUCTTYPEEntry.get(paymentType));
        providerDeductionProductLink.setProviderDeduction(providerDeduction);
        providerDeductionProductLink.insert();

        providerDeduction.createVariableDeductionForModifiedPaymentType(
          informationMsgDtlsList, productDelivery, providerDeductionProductLink);

      }
    }

    Set<ProviderDeductionProductLink> providerDeductionProductLinks = providerDeductionProductLinkDAO.searchByProviderDeduction(
      providerDeduction);

    for (ProviderDeductionProductLink providerDeductionProductLink : providerDeductionProductLinks) {

      boolean paymentTypeExist = false;

      for (String paymentType : paymentTypeList.items()) {
        if (providerDeductionProductLink.getProductType().getCode().equals(
          paymentType)) {
          paymentTypeExist = true;
        }
      }

      // If a payment type is removed then remove it from provider deduction
      // product link.
      if (!paymentTypeExist) {

        providerDeduction.cancelVariableDeductionForModifiedPaymentType(
          caseDeductionItem, productDelivery, providerDeductionProductLink);

        providerDeductionProductLink.remove();
      }
    }

    return informationMsgDtlsList;
  }

  /**
   * Views payment type.
   *
   * @param key
   * Provider deduction key.
   * @return Provider deduction key.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @SuppressWarnings(CPMConstants.kUnused)
  public ProviderPaymentKey viewPaymentType(ProviderDeductionKey key)
    throws AppException, InformationalException {

    // Do nothing.
    return new ProviderPaymentKey();
  }

  /**
   * Modifies third party deduction.
   *
   * @param details
   * Provider deduction details.
   * @return Information message list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationMsgDtlsList modifyThirdPartyDeduction(
    ProviderDeductionDetails details) throws AppException,
      InformationalException {
    return modifyProviderDeduction(details);
  }

  /**
   * Sets the override max deduction rate indicator to true for a provider.
   *
   * @param key
   * Provider key.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void setOverrideMDRInd(curam.cpm.facade.struct.ProviderKey key)
    throws AppException, InformationalException {

    curam.core.facade.intf.ProductDelivery productDelivery = curam.core.facade.fact.ProductDeliveryFactory.newInstance();

    curam.provider.impl.Provider provider = providerDAO.get(key.providerID);

    if (provider.isOverrideMDR()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPODEDUCTIONExceptionCreator.ERR_DEDUCTION_XRV_OVERRIDEMDR_ALREADY_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }

    provider.setOverrideMDRInd(true);
    provider.modify(provider.getVersionNo());

    // If the override maximum deduction indicator is not set, set it for all
    // the
    // product deliveries for which deduction is applied
    Set<ProviderDeduction> providerDeductions = LifecycleHelper.filter(
      providerDeductionDAO.searchByProvider(providerDAO.get(key.providerID)),
      RECORDSTATUSEntry.NORMAL);

    for (ProviderDeduction providerDeduction : providerDeductions) {
      Set<ProviderDeductionProductLink> ProviderDeductionProductLinks = providerDeductionProductLinkDAO.searchByProviderDeduction(
        providerDeduction);

      for (ProviderDeductionProductLink providerDeductionProductLink : ProviderDeductionProductLinks) {

        ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
        ProductDeliveryTypeClientIDIn clientIDIn = new ProductDeliveryTypeClientIDIn();

        clientIDIn.productType = providerDeductionProductLink.getProductType().getCode();
        clientIDIn.recipConcernRoleID = providerDeduction.getProvider().getID().longValue();

        ProductDeliveryDtlsList deliveryDtlsList = productDeliveryObj.searchByTypeClientID(
          clientIDIn);

        for (ProductDeliveryDtls productDeliveryDtls : deliveryDtlsList.dtls.items()) {
          // If the maximum deduction rate is not overridden, override it.
          if (!productDeliveryDtls.overrideMDRInd) {
            CuramInd curamInd = new CuramInd();
            ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

            productDeliveryKey.caseID = productDeliveryDtls.caseID;

            curamInd.statusInd = true;
            productDelivery.setOverrideMDRInd(productDeliveryKey, curamInd);
          }
        }
      }
    }
  }

  /**
   * Sets the override max deduction rate indicator to false for a product
   * delivery.
   *
   * @param key
   * Provider key.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void unsetOverrideMDRInd(curam.cpm.facade.struct.ProviderKey key)
    throws AppException, InformationalException {

    curam.core.facade.intf.ProductDelivery productDelivery = curam.core.facade.fact.ProductDeliveryFactory.newInstance();

    curam.provider.impl.Provider provider = providerDAO.get(key.providerID);

    if (!provider.isOverrideMDR()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPODEDUCTIONExceptionCreator.ERR_DEDUCTION_XRV_OVERRIDEMDR_ALREADY_UNSET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }

    provider.setOverrideMDRInd(false);
    provider.modify(provider.getVersionNo());

    // If the override maximum deduction indicator is set, reset it for all the
    // product deliveries for which deduction is applied
    Set<ProviderDeduction> providerDeductions = LifecycleHelper.filter(
      providerDeductionDAO.searchByProvider(providerDAO.get(key.providerID)),
      RECORDSTATUSEntry.NORMAL);

    for (ProviderDeduction providerDeduction : providerDeductions) {
      Set<ProviderDeductionProductLink> ProviderDeductionProductLinks = providerDeductionProductLinkDAO.searchByProviderDeduction(
        providerDeduction);

      for (ProviderDeductionProductLink providerDeductionProductLink : ProviderDeductionProductLinks) {

        ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
        ProductDeliveryTypeClientIDIn clientIDIn = new ProductDeliveryTypeClientIDIn();

        clientIDIn.productType = providerDeductionProductLink.getProductType().getCode();
        clientIDIn.recipConcernRoleID = providerDeduction.getProvider().getID().longValue();

        ProductDeliveryDtlsList deliveryDtlsList = productDeliveryObj.searchByTypeClientID(
          clientIDIn);

        for (ProductDeliveryDtls productDeliveryDtls : deliveryDtlsList.dtls.items()) {

          // Reset the maximum deduction rate indicator if it is not reset.
          if (productDeliveryDtls.overrideMDRInd) {
            CuramInd curamInd = new CuramInd();
            ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

            productDeliveryKey.caseID = productDeliveryDtls.caseID;

            curamInd.statusInd = false;
            productDelivery.unsetOverrideMDRInd(productDeliveryKey, curamInd);
          }
        }
      }
    }
  }

  /**
   * Returns a list of deduction history records for an applied case deduction.
   *
   * @param key
   * Contains provider deduction ID.
   * @return The applied deduction history details list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public CaseAppliedDeductionHistoryDetailsList listAppliedDeductionHistoryForProvider(
    ProviderDeductionKey key) throws AppException, InformationalException {

    CaseAppliedDeductionHistoryDetailsList caseAppliedDeductionHistoryDetailsList = new CaseAppliedDeductionHistoryDetailsList();
    curam.core.facade.intf.ProductDelivery productDelivery = curam.core.facade.fact.ProductDeliveryFactory.newInstance();
    CaseDeductionItem caseDeductionItem = CaseDeductionItemFactory.newInstance();

    ProviderDeduction providerDeduction = providerDeductionDAO.get(
      key.providerDeductionID);

    Set<ProviderDeductionProductLink> ProviderDeductionProductLinks = providerDeductionProductLinkDAO.searchByProviderDeduction(
      providerDeduction);

    for (ProviderDeductionProductLink providerDeductionProductLink : ProviderDeductionProductLinks) {

      // Get all the product deliveries for the provider for which applied
      // deduction is applied and get the case deduction item. Get the history
      // details for each of the case deduction item.
      ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
      ProductDeliveryTypeClientIDIn clientIDIn = new ProductDeliveryTypeClientIDIn();

      clientIDIn.productType = providerDeductionProductLink.getProductType().getCode();
      clientIDIn.recipConcernRoleID = providerDeduction.getProvider().getID().longValue();

      ProductDeliveryDtlsList deliveryDtlsList = productDeliveryObj.searchByTypeClientID(
        clientIDIn);

      for (ProductDeliveryDtls productDeliveryDtls : deliveryDtlsList.dtls.items()) {

        CaseIDCategory caseIDCategory = new CaseIDCategory();

        caseIDCategory.caseID = productDeliveryDtls.caseID;
        caseIDCategory.category = providerDeduction.getCategory().getCode();
        CaseDeductionItemDtlsList caseDeductionItemDtlsList = caseDeductionItem.searchByCaseIDCategory(
          caseIDCategory);

        for (CaseDeductionItemDtls caseDeductionItemDtls : caseDeductionItemDtlsList.dtls.items()) {

          if (caseDeductionItemDtls.priority == providerDeduction.getPriority()) {

            CaseDeductionHistoryListKey caseDeductionHistoryListKey = new CaseDeductionHistoryListKey();

            caseDeductionHistoryListKey.key.caseDeductionItemID = caseDeductionItemDtls.caseDeductionItemID;

            CaseAppliedDeductionHistoryDetailsList appliedDeductionHistoryDetailsList = productDelivery.listAppliedDeductionHistory(
              caseDeductionHistoryListKey);

            for (CaseDeductionHistoryDetails caseDeductionHistoryDetails : appliedDeductionHistoryDetailsList.dtls.appliedList.dtlsList.items()) {
              caseAppliedDeductionHistoryDetailsList.dtls.appliedList.dtlsList.addRef(
                caseDeductionHistoryDetails);
            }

            caseAppliedDeductionHistoryDetailsList.dtls.caseILIDtls.assign(
              appliedDeductionHistoryDetailsList.dtls.caseILIDtls);
          }
        }
      }
    }

    return caseAppliedDeductionHistoryDetailsList;
  }

  /**
   * Returns a list of deduction history records for un-applied provider
   * deduction.
   *
   * @param key
   * Contains provider deduction ID.
   * @return The un-applied deduction history details list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public CaseUnappliedDeductionHistoryDetailsList listUnappliedDeductionHistoryForProvider(
    ProviderDeductionKey key) throws AppException, InformationalException {

    CaseUnappliedDeductionHistoryDetailsList caseUnappliedDeductionHistoryDetailsList = new CaseUnappliedDeductionHistoryDetailsList();
    curam.core.facade.intf.ProductDelivery productDelivery = curam.core.facade.fact.ProductDeliveryFactory.newInstance();
    CaseDeductionItem caseDeductionItem = CaseDeductionItemFactory.newInstance();

    ProviderDeduction providerDeduction = providerDeductionDAO.get(
      key.providerDeductionID);

    Set<ProviderDeductionProductLink> ProviderDeductionProductLinks = providerDeductionProductLinkDAO.searchByProviderDeduction(
      providerDeduction);

    for (ProviderDeductionProductLink providerDeductionProductLink : ProviderDeductionProductLinks) {

      // Get all the product deliveries for the provider for which un-applied
      // deduction is applied and get the case deduction item. Get the history
      // details for each of the case deduction item.
      ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
      ProductDeliveryTypeClientIDIn clientIDIn = new ProductDeliveryTypeClientIDIn();

      clientIDIn.productType = providerDeductionProductLink.getProductType().getCode();
      clientIDIn.recipConcernRoleID = providerDeduction.getProvider().getID().longValue();

      ProductDeliveryDtlsList deliveryDtlsList = productDeliveryObj.searchByTypeClientID(
        clientIDIn);

      for (ProductDeliveryDtls productDeliveryDtls : deliveryDtlsList.dtls.items()) {

        CaseIDCategory caseIDCategory = new CaseIDCategory();

        caseIDCategory.caseID = productDeliveryDtls.caseID;
        caseIDCategory.category = providerDeduction.getCategory().getCode();
        CaseDeductionItemDtlsList caseDeductionItemDtlsList = caseDeductionItem.searchByCaseIDCategory(
          caseIDCategory);

        for (CaseDeductionItemDtls caseDeductionItemDtls : caseDeductionItemDtlsList.dtls.items()) {

          if (caseDeductionItemDtls.priority == providerDeduction.getPriority()) {

            CaseDeductionHistoryListKey caseDeductionHistoryListKey = new CaseDeductionHistoryListKey();

            caseDeductionHistoryListKey.key.caseDeductionItemID = caseDeductionItemDtls.caseDeductionItemID;

            CaseUnappliedDeductionHistoryDetailsList unappliedDeductionHistoryDetailsList = productDelivery.listUnappliedDeductionHistory(
              caseDeductionHistoryListKey);

            for (CaseDeductionHistoryDetails caseDeductionHistoryDetails : unappliedDeductionHistoryDetailsList.dtls.dtlsList.items()) {

              caseUnappliedDeductionHistoryDetailsList.dtls.dtlsList.addRef(
                caseDeductionHistoryDetails);
            }
          }
        }
      }
    }

    return caseUnappliedDeductionHistoryDetailsList;
  }

  /**
   * Returns the list of deduction records for third party provider deduction.
   *
   * @param key
   * Contains provider deduction ID.
   * @return The third party deduction history details list.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public CaseThirdPartyDeductionHistoryDetailsList listThirdPartyDeductionHistoryForProvider(
    ProviderDeductionKey key) throws AppException, InformationalException {

    CaseThirdPartyDeductionHistoryDetailsList caseThirdPartyDeductionHistoryDetailsList = new CaseThirdPartyDeductionHistoryDetailsList();
    curam.core.facade.intf.ProductDelivery productDelivery = curam.core.facade.fact.ProductDeliveryFactory.newInstance();
    CaseDeductionItem caseDeductionItem = CaseDeductionItemFactory.newInstance();

    ProviderDeduction providerDeduction = providerDeductionDAO.get(
      key.providerDeductionID);

    Set<ProviderDeductionProductLink> ProviderDeductionProductLinks = providerDeductionProductLinkDAO.searchByProviderDeduction(
      providerDeduction);

    for (ProviderDeductionProductLink providerDeductionProductLink : ProviderDeductionProductLinks) {

      // Get all the product deliveries for the provider for which third party
      // deduction is applied and get the case deduction item. Get the history
      // details for each of the case deduction item.
      ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
      ProductDeliveryTypeClientIDIn clientIDIn = new ProductDeliveryTypeClientIDIn();

      clientIDIn.productType = providerDeductionProductLink.getProductType().getCode();
      clientIDIn.recipConcernRoleID = providerDeduction.getProvider().getID().longValue();

      ProductDeliveryDtlsList deliveryDtlsList = productDeliveryObj.searchByTypeClientID(
        clientIDIn);

      for (ProductDeliveryDtls productDeliveryDtls : deliveryDtlsList.dtls.items()) {

        CaseIDCategory caseIDCategory = new CaseIDCategory();

        caseIDCategory.caseID = productDeliveryDtls.caseID;
        caseIDCategory.category = providerDeduction.getCategory().getCode();
        CaseDeductionItemDtlsList caseDeductionItemDtlsList = caseDeductionItem.searchByCaseIDCategory(
          caseIDCategory);

        for (CaseDeductionItemDtls caseDeductionItemDtls : caseDeductionItemDtlsList.dtls.items()) {

          if (caseDeductionItemDtls.priority == providerDeduction.getPriority()) {
            CaseDeductionHistoryListKey caseDeductionHistoryListKey = new CaseDeductionHistoryListKey();

            caseDeductionHistoryListKey.key.caseDeductionItemID = caseDeductionItemDtls.caseDeductionItemID;
            CaseThirdPartyDeductionHistoryDetailsList thirdPartyDeductionHistoryDetailsList = productDelivery.listThirdPartyDeductionHistory(
              caseDeductionHistoryListKey);

            for (ThirdPartyDeductionHistoryDetails thirdPartyDeductionHistoryDetails : thirdPartyDeductionHistoryDetailsList.dtls.dtlsList.items()) {

              caseThirdPartyDeductionHistoryDetailsList.dtls.dtlsList.addRef(
                thirdPartyDeductionHistoryDetails);
            }
          }
        }
      }
    }

    return caseThirdPartyDeductionHistoryDetailsList;
  }

  // BEGIN, CR00128816, GP
  /**
   * Lists all the active liabilities for a provider and all the nominees
   * associated to the provider.
   *
   * @param activeLiabilitesForConcernKey
   * Contains concern role id of a provider.
   *
   * @return List of all the active liabilities for a provider and all the
   * nominees associated to the provider.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ListActiveLiabilityDetails listActiveLiabilitiesForProviderAndNominee(
    ListActiveLiabilitesForConcernKey activeLiabilitesForConcernKey) throws AppException,
      InformationalException {

    ListActiveLiabilityDetails listActiveLiabilityDetails = new ListActiveLiabilityDetails();

    curam.core.facade.intf.ProductDelivery productDelivery = curam.core.facade.fact.ProductDeliveryFactory.newInstance();

    // BEGIN, CR00311723, MR
    final ListActiveLiabilitesForConcernKeyStruct listActiveLiabilitesForConcernKey = new ListActiveLiabilitesForConcernKeyStruct();

    listActiveLiabilitesForConcernKey.concernRoleID = activeLiabilitesForConcernKey.concernRoleID;
    listActiveLiabilitesForConcernKey.concernRoleType = CONCERNROLETYPEEntry.PROVIDER.getCode();

    final ListActiveLiabilityDetails1 listActiveLiabilityDetails1 = new ListActiveLiabilityDetails1();
    final ListActiveLiabilityDetails1 activeLiabilityDetails = productDelivery.listActiveLiabilitiesForConcernRole(
      listActiveLiabilitesForConcernKey);

    for (final ActiveLiabilityDetails1 activeLiabilityDetails1 : activeLiabilityDetails.dtls.items()) {
      listActiveLiabilityDetails1.dtls.addRef(activeLiabilityDetails1);
    }

    // END, CR00311723
    CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();
    ParticipantRoleIDAndTypeCodesKey participantRoleIDAndTypeCodesKey = new ParticipantRoleIDAndTypeCodesKey();

    participantRoleIDAndTypeCodesKey.participantRoleID = activeLiabilitesForConcernKey.concernRoleID;
    participantRoleIDAndTypeCodesKey.typeCode1 = CONCERNROLETYPEEntry.PROVIDER.getCode();

    CaseHeaderKeyList caseHeaderKeyList = caseParticipantRole.searchCaseIDByParticipantRoleIDAndTypeCodes(
      participantRoleIDAndTypeCodesKey);

    for (CaseHeaderKey caseHeaderKey : caseHeaderKeyList.dtls.items()) {

      CaseHeader caseHeader = CaseHeaderFactory.newInstance();
      CaseHeaderDtls caseHeaderDtls = caseHeader.read(caseHeaderKey);

      // BEGIN, CR00311723, MR
      listActiveLiabilitesForConcernKey.concernRoleID = caseHeaderDtls.concernRoleID;

      final ListActiveLiabilityDetails1 activeLiabilityDetailsList = productDelivery.listActiveLiabilitiesForConcernRole(
        listActiveLiabilitesForConcernKey);

      for (final ActiveLiabilityDetails1 activeLiabilityDetails1 : activeLiabilityDetailsList.dtls.items()) {
        listActiveLiabilityDetails1.dtls.addRef(activeLiabilityDetails1);
      }
    }

    // BEGIN, CR00399934, PS
    for (final ActiveLiabilityDetails1 activeLiabilityDetails1 : listActiveLiabilityDetails1.dtls.items()) {
      final ActiveLiabilityDetails activeLiabilityDetail = new ActiveLiabilityDetails();

      activeLiabilityDetail.caseID = activeLiabilityDetails1.caseID;
      activeLiabilityDetail.caseReference = activeLiabilityDetails1.caseReference;
      activeLiabilityDetail.originalAmountOpt = activeLiabilityDetails1.originalAmount;
      activeLiabilityDetail.outstandingAmountOpt = activeLiabilityDetails1.outstandingAmount;
      activeLiabilityDetail.startDate = activeLiabilityDetails1.startDate;
      getProductType(activeLiabilityDetail);
      listActiveLiabilityDetails.dtls.add(activeLiabilityDetail);
    }
    // END, CR00399934

    // END, CR00311723
    return listActiveLiabilityDetails;
  }

  // END, CR00128816
  
  /**
   * Returns the Product Details for a product type.
   *
   * @param productType
   * Product type.
   * @return The Product details
   * @throws InformationalException
   * General Exception Signature.
   * @throws AppException
   * General Exception Signature.
   */
  protected ProductDtls getProduct(String productType) throws AppException,
      InformationalException {

    Product product = ProductFactory.newInstance();
    ProductTypeCodeIn codeIn = new ProductTypeCodeIn();

    codeIn.benefitInd = true;
    codeIn.statusCode = RECORDSTATUS.NORMAL;
    codeIn.typeCode = productType;
    ProductDtls productDtls = product.searchByType(codeIn).dtls.item(0);

    return productDtls;
  }
  
  // BEGIN, CR00399934, PS
  /**
   * Gets the product type associated with the product delivery case.
   *
   * @param caseID
   * Product delivery case ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void getProductType(
    final ActiveLiabilityDetails activeLiabilityDetail) throws AppException,
      InformationalException {
    final ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
    final CaseKey caseIDKey = new CaseKey();

    caseIDKey.caseID = activeLiabilityDetail.caseID;
    CaseHomePageNameAndType caseHomePageNameAndType = productDeliveryObj.readCaseHomePageNameAndType(
      caseIDKey);

    if (!PRODUCTTYPEEntry.PAYMENTCORRECTION.getCode().equals(
      caseHomePageNameAndType.typeCode)) {
      activeLiabilityDetail.productType = caseHomePageNameAndType.typeCode;
    } else {
      CaseRelationship caseRelationship = CaseRelationshipFactory.newInstance();
      CaseRelationshipCaseIDKey relationshipCaseIDKey = new CaseRelationshipCaseIDKey();

      relationshipCaseIDKey.caseID = activeLiabilityDetail.caseID;
      CaseRelationshipDtlsList dtlsList = caseRelationship.searchByCaseID(
        relationshipCaseIDKey);
      CaseRelationshipDtls caseRelationshipDtls = null;

      for (CaseRelationshipDtls relationshipDtls : dtlsList.dtls.items()) {
        caseRelationshipDtls = relationshipDtls;
      }
      if (null != caseRelationshipDtls) {

        caseIDKey.caseID = caseRelationshipDtls.relatedCaseID;
        CaseHomePageNameAndType caseHomePType = productDeliveryObj.readCaseHomePageNameAndType(
          caseIDKey);

        activeLiabilityDetail.productType = caseHomePType.typeCode;
      }
    }
  }

  // END, CR00399934


  /**
   * Sorts a set of provider deductions in the ascending order of the priority.
   *
   * @param unsortedProviderDeductions
   * The unsorted set of provider deductions.
   * @return A sorted list of provider deduction.
   */
  protected List<ProviderDeduction> sortProviderDeductions(
    final Set<ProviderDeduction> unsortedProviderDeductions) {

    final List<ProviderDeduction> providerDeductions = new ArrayList<ProviderDeduction>(
      unsortedProviderDeductions);

    Collections.sort(providerDeductions, new Comparator<ProviderDeduction>() {
      public int compare(final ProviderDeduction lhs, ProviderDeduction rhs) {
        return lhs.getPriority() - rhs.getPriority();
      }
    });

    return providerDeductions;
  }
}
