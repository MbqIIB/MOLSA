/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.attachment.impl.Attachment;
import curam.attachmentlink.impl.AttachmentLink;
import curam.attachmentlink.impl.AttachmentLinkDAO;
import curam.attachmentlink.struct.AttachmentLinkKey;
import curam.attachmentlink.struct.CancelAttachmentKey;
import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.cefwidgets.docbuilder.impl.ListBuilder;
import curam.cefwidgets.docbuilder.impl.helper.impl.CodeTableItemEntry;
import curam.cefwidgets.docbuilder.impl.helper.impl.DocBuilderHelperFactory;
import curam.cefwidgets.utilities.impl.RendererConfig;
import curam.codetable.ATTACHMENTOBJECTLINKTYPE;
import curam.codetable.CONTACTLOGLINKTYPE;
import curam.codetable.CONTACTLOGTYPE;
import curam.codetable.INCIDENTSEVERITY;
import curam.codetable.INCIDENTSTATUS;
import curam.codetable.INCIDENTTIMEOFDAY;
import curam.codetable.INCIDENTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.ACTIONCONTROLIDEntry;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.CONTACTLOGLINKTYPEEntry;
import curam.codetable.impl.INCIDENTCATEGORYEntry;
import curam.codetable.impl.INCIDENTCLOSUREREASONEntry;
import curam.codetable.impl.INCIDENTPARTICIPANTROLEEntry;
import curam.codetable.impl.INCIDENTREPORTMETHODEntry;
import curam.codetable.impl.INCIDENTSEVERITYEntry;
import curam.codetable.impl.INCIDENTSTATUSEntry;
import curam.codetable.impl.INCIDENTTIMEOFDAYEntry;
import curam.codetable.impl.INCIDENTTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.core.facade.struct.ContactLogWizardMenuDetails;
import curam.core.facade.struct.DefaultContactLogDetails;
import curam.core.fact.AddressDataFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.AddressData;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.struct.ContactLogKey;
import curam.core.sl.entity.struct.ContactLogListDtls1;
import curam.core.sl.entity.struct.ContactLogListDtls1List;
import curam.core.sl.entity.struct.LinkIDLinkTypeRecordStatusKey;
import curam.core.sl.entity.struct.LinkKey;
import curam.core.sl.fact.ContactLogFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.intf.ContactLog;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.struct.AddressTabDetails;
import curam.core.sl.struct.CancelContactLogDetails;
import curam.core.sl.struct.ContactLogLinkIDLinkTypeKey;
import curam.core.sl.struct.ContactLogTabDetails;
import curam.core.sl.struct.CreateContactLogAttendeeDetails1;
import curam.core.sl.struct.CreateContactLogDetails;
import curam.core.sl.struct.CreateContactLogDetails1;
import curam.core.sl.struct.FormatTimeDetails;
import curam.core.sl.struct.IncidentTabDtls;
import curam.core.sl.struct.ReadContactLogDetails;
import curam.core.sl.struct.ReadContactLogDetails1;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.sl.struct.TimeString;
import curam.core.sl.struct.WizardStateID;
import curam.core.struct.AttachmentKey;
import curam.core.struct.ConcernRoleContactDetails;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PhoneNumberKey;
import curam.core.struct.ReadParticipantRoleNameAndTypeDetails;
import curam.core.struct.UserContactDtls;
import curam.core.struct.UsersKey;
import curam.cpm.facade.struct.AttachmentLinkDetails;
import curam.cpm.facade.struct.CloseIncidentDetails;
import curam.cpm.facade.struct.CompartmentIDAndNameDetails;
import curam.cpm.facade.struct.CompartmentIDAndNameDetailsList;
import curam.cpm.facade.struct.ContactLogDetails;
import curam.cpm.facade.struct.ContactLogDetailsList;
import curam.cpm.facade.struct.ContactLogOwnerDetails;
import curam.cpm.facade.struct.ContactLogSearchKey;
import curam.cpm.facade.struct.ContactLogWizardDetails;
import curam.cpm.facade.struct.CreateProviderIncidentContactLogContactDetails;
import curam.cpm.facade.struct.CreateProviderIncidentContactLogDetails;
import curam.cpm.facade.struct.CreateProviderIncidentDetails;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.ListAttachmentLinkDetails;
import curam.cpm.facade.struct.ModifyProviderIncidentContactLogDetails;
import curam.cpm.facade.struct.ProviderIncidentContactLogDetails;
import curam.cpm.facade.struct.ProviderIncidentContactLogDetailsList;
import curam.cpm.facade.struct.ProviderIncidentDetails;
import curam.cpm.facade.struct.ProviderIncidentDetailsList;
import curam.cpm.facade.struct.ProviderIncidentMemberDetails;
import curam.cpm.facade.struct.ProviderIncidentMemberDetailsList;
import curam.cpm.facade.struct.ProviderIncidentParticipantDetails;
import curam.cpm.facade.struct.ProviderOrganizationAndIncidentDetails;
import curam.cpm.facade.struct.SearchContactLogDetails;
import curam.cpm.facade.struct.ViewProviderIncidentDetails;
import curam.cpm.facade.struct.ViewProviderIncidentTabDetails;
import curam.cpm.facade.struct.ViewProviderSummaryDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderIncidentKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.incident.entity.struct.IncidentDtls;
import curam.incident.entity.struct.IncidentKey;
import curam.incident.entity.struct.IncidentParticipantRoleKey;
import curam.incident.impl.Incident;
import curam.incident.impl.IncidentDAO;
import curam.incident.impl.IncidentParticipant;
import curam.incident.impl.IncidentParticipantDAO;
import curam.incident.impl.IncidentStatusHistory;
import curam.message.BPOINCIDENTTAB;
import curam.message.BPOINVESTIGATIONTAB;
import curam.message.BPOPARTICIPANT;
import curam.message.PROVIDERINCIDENT;
import curam.message.impl.PROVIDERINCIDENTExceptionCreator;
import curam.participant.impl.ConcernRoleDAO;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.place.impl.Compartment;
import curam.place.impl.CompartmentDAO;
import curam.place.impl.CompartmentStatusEntry;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderGroupAssociateDAO;
import curam.provider.impl.ProviderGroupDAO;
import curam.provider.impl.ProviderIncident;
import curam.provider.impl.ProviderIncidentDAO;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.provider.impl.ProviderPartyDAO;
import curam.provider.impl.ProviderServiceCenter;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.StringHelper;
import curam.util.type.StringList;
import curam.wizardpersistence.impl.WizardPersistentState;


/**
 * {@inheritDoc}
 */
public abstract class MaintainProviderIncident extends curam.cpm.facade.base.MaintainProviderIncident {

  /**
   * Reference to ProviderOrganizationDAO.
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Reference to ProviderDAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to ProviderGroupDAO.
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /**
   * Reference to ProviderIncidentDAO.
   */
  @Inject
  protected ProviderIncidentDAO providerIncidentDAO;

  /**
   * Reference to ProviderGroupAssociateDAO.
   */
  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;

  /**
   * Reference to CompartmentDAO.
   */
  @Inject
  protected CompartmentDAO compartmentDAO;

  /**
   * Reference to IncidentDAO.
   */
  @Inject
  protected IncidentDAO incidentDAO;

  /**
   * Reference to IncidentParticipantDAO.
   */
  @Inject
  protected IncidentParticipantDAO incidentParticipantDAO;

  /**
   * Reference to ConcernRoleDAO.
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Reference to AttachmentLink DAO
   */
  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;

  // BEGIN, CR00226594, FM
  @Inject
  protected Attachment attachmentObj;

  // END, CR00226594

  // BEGIN, CR00236233, GP
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;

  // END, CR00236233

  // BEGIN, CR00321585, SS
  /**
   * Reference to Provider Party DAO.
   */
  @Inject
  protected ProviderPartyDAO providerPartyDAO;
  // END, CR00321585

  /**
   * Constructor
   */
  public MaintainProviderIncident() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderIncidentMemberDetailsList listActiveProviderMember(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    final ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      concernRoleKey.concernRoleID);

    ProviderIncidentMemberDetailsList providerIncidentMemberDetailsList = new ProviderIncidentMemberDetailsList();

    for (final curam.provider.impl.ProviderMember providerMember : providerOrganization.getProviderMembers()) {

      // BEGIN, CR00127920, SK
      // Active provider member records associated to the provider, with no to
      // date recorded, or a to date recorded that is on or later than todays
      // date, will be added to the list.
      if (providerMember.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)
        && (!providerMember.getDateRange().isEnded()
          || !providerMember.getDateRange().endsInPast())) {
        // END, CR00127920
        final ProviderIncidentMemberDetails providerIncidentMemberDetails = new ProviderIncidentMemberDetails();

        providerIncidentMemberDetails.providerMemberID = providerMember.getID();
        providerIncidentMemberDetails.providerMemberName = providerMember.getParty().getName();
        providerIncidentMemberDetails.concernRoleID = providerMember.getParty().getID();
        providerIncidentMemberDetailsList.details.addRef(
          providerIncidentMemberDetails);

      }
    }

    return providerIncidentMemberDetailsList;

  }

  /**
   * {@inheritDoc}
   */
  public ProviderIncidentDetailsList listIncidentForProvider(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    ProviderIncidentDetailsList providerIncidentDetailsList = new ProviderIncidentDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      concernRoleKey.concernRoleID);

    List<ProviderIncident> providerIncidents = provider.getIncidents();

    for (final ProviderIncident providerIncident : providerIncidents) {
      providerIncidentDetailsList.details.addRef(
        getProviderIncidentDetails(providerIncident));
    }
    return providerIncidentDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderIncidentDetailsList listIncidentForProviderGroup(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    ProviderIncidentDetailsList providerIncidentDetailsList = new ProviderIncidentDetailsList();

    curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      concernRoleKey.concernRoleID);

    // Get a provider group associates list for a provider group.
    for (final curam.provider.impl.ProviderGroupAssociate providerGroupAssociate : providerGroupAssociateDAO.searchByProviderGroup(
      providerGroup)) {

      // Get active Provider group associate with no end date or end date in
      // future.
      if (providerGroupAssociate.getLifecycleState().equals(
        RECORDSTATUSEntry.NORMAL)
          && (!providerGroupAssociate.getDateRange().isEnded()
            || providerGroupAssociate.getDateRange().endsInFuture())) {

        curam.provider.impl.Provider provider = providerGroupAssociate.getProvider();

        // Read the incidents for each provider group associate.
        for (final ProviderIncident providerIncident : provider.getIncidents()) {
          if (!providerIncident.getIncident().getLifecycleState().equals(
            INCIDENTSTATUSEntry.CANCELLED)) {
            ProviderIncidentDetails providerIncidentDetails = getProviderIncidentDetails(
              providerIncident);

            providerIncidentDetails.providerName = provider.getName();
            providerIncidentDetails.providerConcernRoleID = provider.getID();
            providerIncidentDetailsList.details.addRef(providerIncidentDetails);
          }
        }
      }
    }
    return providerIncidentDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderIncidentDetailsList listIncidentForProviderMember(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    // BEGIN, CR00321585, SS
    final ProviderIncidentDetailsList providerIncidentDetailsList = new ProviderIncidentDetailsList();

    final List<ProviderIncident> providerIncidents = providerIncidentDAO.searchByParticipant(
      providerPartyDAO.get(concernRoleKey.concernRoleID).getParty().getID());

    // END, CR00321585

    // Read the active incidents for a provider member.
    for (final ProviderIncident providerIncident : providerIncidents) {
      if (!providerIncident.getIncident().getLifecycleState().equals(
        INCIDENTSTATUSEntry.CANCELLED)) {
        providerIncidentDetailsList.details.addRef(
          getProviderIncidentDetails(providerIncident));
      }
    }
    return providerIncidentDetailsList;

  }

  /**
   * {@inheritDoc}
   */
  public CompartmentIDAndNameDetailsList listActiveCompartmentForProvider(
    ProviderKey providerKey) throws AppException, InformationalException {

    CompartmentIDAndNameDetailsList compartmentIDAndNameDetailsList = new CompartmentIDAndNameDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    // Get the Service centers for a provider.
    Set<ProviderServiceCenter> providerServiceCenters = provider.getProviderServiceCenters();

    boolean displayCompartmentInd = false;

    for (ProviderServiceCenter providerServiceCenter : providerServiceCenters) {

      if (providerServiceCenter.getLifecycleState().equals(
        RECORDSTATUSEntry.NORMAL)
          && (!providerServiceCenter.getDateRange().isEnded()
            || providerServiceCenter.getDateRange().endsInFuture())) {
        displayCompartmentInd = true;
      }

    }
    // Read the active compartments only if the no active service centers are
    // present for a provider.
    if (!displayCompartmentInd) {
      Set<Compartment> totalCompartments = provider.getCompartments();

      for (final Compartment compartment : totalCompartments) {
        if (compartment.getLifecycleState().equals(
          CompartmentStatusEntry.ACTIVE)
            && (!compartment.getDateRange().isEnded()
              || compartment.getDateRange().endsInFuture())) {
          CompartmentIDAndNameDetails compartmentIDAndNameDetails = new CompartmentIDAndNameDetails();

          compartmentIDAndNameDetails.compartmentID = compartment.getID();
          compartmentIDAndNameDetails.compartmentName = compartment.getName();
          compartmentIDAndNameDetailsList.details.addRef(
            compartmentIDAndNameDetails);

        }
      }
    }

    return compartmentIDAndNameDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderIncidentKey createIncident(
    CreateProviderIncidentDetails details) throws AppException,
      InformationalException {

    // Validate the Provider Incident details.
    validateProviderIcident(details);

    // BEGIN, CR00321585, SS
    if ((0 != details.participantDetails.providerMemberConcernRoleID
      || !StringHelper.isEmpty(
        details.participantDetails.incidentParticipantDtls.userName))
          && StringUtil.isNullOrEmpty(
            details.participantDetails.incidentParticipantDtls.role)) {
      ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENT_PARTICIPANT_ROLE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // END, CR00321585

    // BEGIN, CR00234435, AK
    // BEGIN, CR00233623, ASN
    if (StringUtil.isNullOrEmpty(
      details.participantDetails.incidentParticipantDtls.role)) {

      boolean checkProviderRole = false;

      if (0 != details.participantDetails.incidentParticipantDtls.concernRoleID) {

        if (!details.incidentDtls.anonymousReportInd
          && details.participantDetails.incidentParticipantDtls.concernRoleID
            != details.concernRoleID) {

          checkProviderRole = true;
        }
      }
      // BEGIN, CR00247132, VR
      if ((!StringHelper.isEmpty(
        details.participantDetails.representativeRegDetails.representativeDtls.representativeName))) {
        checkProviderRole = true;
      }
      // END, CR00247132
      if (details.incidentDtls.anonymousReportInd || checkProviderRole) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENT_PARTICIPANT_ROLE_MUST_BE_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }

    ValidationHelper.failIfErrorsExist();
    // END, CR00233623
    // END, CR00234435

    ProviderIncident providerIncident = providerIncidentDAO.newInstance();

    providerIncident.setCompartmentID(
      details.providerIncidentDtls.compartmentID);
    providerIncident.setProviderFacility(
      details.providerIncidentDtls.providerFacilityInd);

    // Sets the Incidents details to the Incident instance.
    Incident incident = setIncidentDetails(details);

    providerIncident.insert(incident);

    // Insert the Incident Participant only if the incident is not reported
    // anonymously.
    if (!incident.isAnonymousReporter()) {
      IncidentParticipant incidentParticipant = incidentParticipantDAO.newInstance();

      incidentParticipant.setIncident(incident);
      incidentParticipant.setRole(INCIDENTPARTICIPANTROLEEntry.REPORTER);
      if (details.participantDetails.providerMemberConcernRoleID != 0) {
        incidentParticipant.setConcernRoleID(
          details.participantDetails.providerMemberConcernRoleID);
      } else if (details.participantDetails.incidentParticipantDtls.concernRoleID
        != 0) {
        incidentParticipant.setConcernRoleID(
          details.participantDetails.incidentParticipantDtls.concernRoleID);
      } else if (!StringHelper.isEmpty(
        details.participantDetails.incidentParticipantDtls.userName)) {
        incidentParticipant.setUserName(
          details.participantDetails.incidentParticipantDtls.userName);
      } else if (!StringHelper.isEmpty(
        details.participantDetails.representativeRegDetails.representativeDtls.representativeName)) {
        curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

        details.participantDetails.representativeRegDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();
        representativeObj.registerRepresentative(
          details.participantDetails.representativeRegDetails);
        incidentParticipant.setConcernRoleID(
          details.participantDetails.representativeRegDetails.representativeDtls.concernRoleID);

      }
      incidentParticipant.insert();

      // BEGIN, CR00233623, ASN
      if (!StringUtil.isNullOrEmpty(
        details.participantDetails.incidentParticipantDtls.role)) {
        IncidentParticipant incidentParticipantObj = incidentParticipantDAO.newInstance();

        incidentParticipantObj.setIncident(incident);
        incidentParticipantObj.setRole(
          INCIDENTPARTICIPANTROLEEntry.get(
            details.participantDetails.incidentParticipantDtls.role));
        incidentParticipantObj.setConcernRoleID(details.concernRoleID);

        incidentParticipantObj.insert();

      }
    } else {

      IncidentParticipant incidentParticipantObj = incidentParticipantDAO.newInstance();

      incidentParticipantObj.setIncident(incident);
      incidentParticipantObj.setRole(
        INCIDENTPARTICIPANTROLEEntry.get(
          details.participantDetails.incidentParticipantDtls.role));
      incidentParticipantObj.setConcernRoleID(details.concernRoleID);

      incidentParticipantObj.insert();

    }
    ProviderIncidentKey providerIncidentKey = new ProviderIncidentKey();

    providerIncidentKey.incidentID = providerIncident.getID();
    // END, CR00233623

    return providerIncidentKey;
  }

  /**
   * {@inheritDoc}
   */
  public void modifyIncident(CreateProviderIncidentDetails details)
    throws AppException, InformationalException {

    // Validate the Provider Incident details.
    validateProviderIcident(details);

    // BEGIN, CR00143771, SK
    if (details.participantDetails.incidentParticipantDtls.incidentParticipantRoleID
      != 0
        && details.incidentDtls.anonymousReportInd) {
      IncidentParticipant incidentParticipant = incidentParticipantDAO.get(
        details.participantDetails.incidentParticipantDtls.incidentParticipantRoleID);

      incidentParticipant.cancel(
        details.participantDetails.incidentParticipantDtls.versionNo);

    }
    // END, CR00143771
    Incident incident = setIncidentDetails(details);
    ProviderIncident providerIncident = providerIncidentDAO.get(
      details.incidentDtls.incidentID);

    // BEGIN, CR00258930, VR
    // check if provider incident details exist for incident
    try {
      providerIncident.setCompartmentID(
        details.providerIncidentDtls.compartmentID);
      providerIncident.setProviderFacility(
        details.providerIncidentDtls.providerFacilityInd);

      providerIncident.setIncident(incident);
      providerIncident.modify(incident);

    } catch (RecordNotFoundException e) {
      providerIncident = providerIncidentDAO.newInstance();
      providerIncident.setCompartmentID(
        details.providerIncidentDtls.compartmentID);
      providerIncident.setProviderFacility(
        details.providerIncidentDtls.providerFacilityInd);

      incident.modify(details.incidentDtls.versionNo);
      providerIncident.setIncident(incident);
      providerIncident.insert(incident);
    }
    // END, CR00258930

    // if the reporter is not anonymous and incident Participant Role record
    // exists for the incident.
    if (details.participantDetails.incidentParticipantDtls.incidentParticipantRoleID
      != 0
        && !details.incidentDtls.anonymousReportInd) {
      IncidentParticipant incidentParticipant = setIncidentParticipantDetails(
        details);

      incidentParticipant.modify(
        details.participantDetails.incidentParticipantDtls.versionNo);
    } else if (details.participantDetails.incidentParticipantDtls.incidentParticipantRoleID
      == 0
        && !details.incidentDtls.anonymousReportInd) {
      IncidentParticipant incidentParticipant = incidentParticipantDAO.newInstance();

      incidentParticipant.setIncident(incident);
      incidentParticipant.setRole(INCIDENTPARTICIPANTROLEEntry.REPORTER);
      if (details.participantDetails.incidentParticipantDtls.concernRoleID != 0) {
        incidentParticipant.setConcernRoleID(
          details.participantDetails.incidentParticipantDtls.concernRoleID);
      } else if (!StringHelper.isEmpty(
        details.participantDetails.representativeRegDetails.representativeDtls.representativeName)) {
        curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

        details.participantDetails.representativeRegDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();
        representativeObj.registerRepresentative(
          details.participantDetails.representativeRegDetails);
        incidentParticipant.setConcernRoleID(
          details.participantDetails.representativeRegDetails.representativeDtls.concernRoleID);

      }
      incidentParticipant.setUserName(
        details.participantDetails.incidentParticipantDtls.userName);
      incidentParticipant.insert();
    }

  }

  /**
   * {@inheritDoc}
   */
  public ViewProviderIncidentDetails viewIncident(ProviderIncidentKey key)
    throws AppException, InformationalException {

    ViewProviderIncidentDetails viewProviderIncidentDetails = new ViewProviderIncidentDetails();

    ProviderIncident providerIncident = providerIncidentDAO.get(key.incidentID);

    Incident incident = providerIncident.getIncident();

    // Populate the Provider Incident details.
    Compartment compartment = providerIncident.getCompartment();

    if (compartment != null) {
      viewProviderIncidentDetails.details.compartmentID = compartment.getID();
      viewProviderIncidentDetails.compartmentName = compartment.getName();
    }

    viewProviderIncidentDetails.details.incidentID = incident.getID();
    viewProviderIncidentDetails.details.providerFacilityInd = providerIncident.isProviderFacility();

    // Populate Incident details.
    viewProviderIncidentDetails.incidentDtls = getIncidentDetails(incident);
    if (providerIncident.isProviderFacility()) {
      viewProviderIncidentDetails.incidentDtls.location = CuramConst.gkEmpty;
    }
    viewProviderIncidentDetails.reporterDetails.reportedBy = getIncidentReporterDetails(
      incident);
    // BEGIN, CR00246372, AK
    if (!viewProviderIncidentDetails.incidentDtls.anonymousReportInd) {
      // END, CR00246372

      // BEGIN, CR00134515, SK
      Set<IncidentParticipant> incidentReporterParticipants = incidentParticipantDAO.searchByIncident(
        incident);

      // Read the Reporter details for Incident.
      for (final IncidentParticipant incidentParticipant : incidentReporterParticipants) {
        // BEGIN, CR00246372, NS
        if (incidentParticipant.getRole().equals(
          INCIDENTPARTICIPANTROLEEntry.REPORTER)
            && !incidentParticipant.getLifecycleState().getCode().equals(
              RECORDSTATUSEntry.CANCELLED.getCode())) {
          // END, CR00246372

          viewProviderIncidentDetails.reporterDetails.reporterIncidentParticipantID = incidentParticipant.getID();
          viewProviderIncidentDetails.reporterDetails.providerMemberConcernRoleID = incidentParticipant.getConcernRoleID();
          viewProviderIncidentDetails.reporterDetails.participantConcernRoleID = incidentParticipant.getConcernRoleID();
          long participantConcernRoleID = incidentParticipant.getConcernRoleID();

          if (participantConcernRoleID != 0) {
            curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
              participantConcernRoleID);

            viewProviderIncidentDetails.reporterDetails.reporterConcernRoleName = concernRole.getName();
            viewProviderIncidentDetails.reporterDetails.reporterConcernRoleTypeCode = concernRole.getConcernRoleType().getCode();
          }
          viewProviderIncidentDetails.reporterDetails.userName = incidentParticipant.getUserName();
          viewProviderIncidentDetails.reporterDetails.versionNo = incidentParticipant.getVersionNo();
        }
      }
    }
    // END, CR00134515

    // Read the Participant details for the Incident.
    Set<IncidentParticipant> incidentParticipants = incidentParticipantDAO.searchByIncident(
      incident);

    for (final IncidentParticipant incidentParticipant : incidentParticipants) {

      viewProviderIncidentDetails.participantList.details.addRef(
        getProviderIncidentParticipantDetails(incidentParticipant));

    }

    // BEGIN, CR00134515, SK
    // Read the participant details for whom the incident is being created.
    for (final IncidentParticipant participant : incidentParticipants) {
      if (participant.getRole().equals(INCIDENTPARTICIPANTROLEEntry.AGAINST)) {
        viewProviderIncidentDetails.concernRoleID = participant.getConcernRoleID();
      }
      // END, CR00134515
    }

    viewProviderIncidentDetails.pageDescription = providerIncident.getIncident().getType().toUserLocaleString();

    return viewProviderIncidentDetails;
  }

  /**
   * {@inheritDoc}
   */
  public void cancelIncident(KeyVersionDetails keyVersion) throws AppException,
      InformationalException {

    ProviderIncident providerIncident = providerIncidentDAO.get(keyVersion.id);

    providerIncident.cancel(keyVersion.version);

  }

  /**
   * {@inheritDoc}
   */
  public void closeIncident(CloseIncidentDetails details) throws AppException,
      InformationalException {

    ProviderIncident providerIncident = providerIncidentDAO.get(
      details.details.incidentID);

    providerIncident.close(details.details.comments,
      INCIDENTCLOSUREREASONEntry.get(details.details.closureReason),
      details.versionNo);

  }

  /**
   * {@inheritDoc}
   */
  public IncidentParticipantRoleKey addParticipant(
    ProviderIncidentParticipantDetails details) throws AppException,
      InformationalException {

    boolean isRegisteredParticipant = false;
    boolean isUser = false;
    boolean isUnRegisteredParticipant = false;
    boolean isProviderMember = false;

    if (!StringHelper.isEmpty(
      details.representativeRegDetails.representativeDtls.representativeName)) {
      isUnRegisteredParticipant = true;
    }
    if (details.incidentParticipantDtls.concernRoleID != 0) {
      isRegisteredParticipant = true;
    }
    if (details.providerMemberConcernRoleID != 0) {
      isProviderMember = true;
    }

    if (!StringHelper.isEmpty(details.incidentParticipantDtls.userName)) {
      isUser = true;
    }

    // One of either ProviderMember,User,Registered Participant or Unregistered
    // Participant is entered.
    if (!(isRegisteredParticipant || isUser || isUnRegisteredParticipant
      || isProviderMember)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENTPARTICIPANT_XRV_ONE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // Only one of either Provider Member, User, Registered Participant or
    // Unregistered Participant must be entered.
    if ((isProviderMember && isRegisteredParticipant)
      || (isProviderMember && isUser)
      || (isProviderMember && isUnRegisteredParticipant)
      || (isRegisteredParticipant && isUser)
      || (isRegisteredParticipant && isUnRegisteredParticipant)
      || (isUser && isUnRegisteredParticipant)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENTPARTICIPANT_XRV_ONLY_ONE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    ValidationHelper.failIfErrorsExist();

    IncidentParticipant incidentParticipant = incidentParticipantDAO.newInstance();

    incidentParticipant.setComments(details.incidentParticipantDtls.comments);
    Incident incident = incidentDAO.get(
      details.incidentParticipantDtls.incidentID);

    incidentParticipant.setIncident(incident);
    incidentParticipant.setRole(
      INCIDENTPARTICIPANTROLEEntry.get(details.incidentParticipantDtls.role));

    // If user is an unregistered participant, he/she will be registered as
    // a Representative.
    if (isUnRegisteredParticipant) {
      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      details.representativeRegDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();
      representativeObj.registerRepresentative(details.representativeRegDetails);
      incidentParticipant.setConcernRoleID(
        details.representativeRegDetails.representativeDtls.concernRoleID);

    }
    if (isRegisteredParticipant) {
      incidentParticipant.setConcernRoleID(
        details.incidentParticipantDtls.concernRoleID);
    }
    if (isProviderMember) {
      incidentParticipant.setConcernRoleID(details.providerMemberConcernRoleID);
    }
    if (isUser) {
      incidentParticipant.setUserName(details.incidentParticipantDtls.userName);
    }

    incidentParticipant.insert();

    IncidentParticipantRoleKey providerIncidentParticipantKey = new IncidentParticipantRoleKey();

    providerIncidentParticipantKey.incidentParticipantRoleID = incidentParticipant.getID();

    return providerIncidentParticipantKey;
  }

  /**
   * {@inheritDoc}
   */
  public void cancelParticipant(KeyVersionDetails key) throws AppException,
      InformationalException {

    IncidentParticipant incidentParticipant = incidentParticipantDAO.get(key.id);

    incidentParticipant.cancel(key.version);
  }

  /**
   * {@inheritDoc}
   */
  public void modifyParticipant(ProviderIncidentParticipantDetails details)
    throws AppException, InformationalException {

    IncidentParticipant incidentParticipant = incidentParticipantDAO.get(
      details.incidentParticipantDtls.incidentParticipantRoleID);

    incidentParticipant.setRole(
      INCIDENTPARTICIPANTROLEEntry.get(details.incidentParticipantDtls.role));
    incidentParticipant.setComments(details.incidentParticipantDtls.comments);
    incidentParticipant.modify(details.incidentParticipantDtls.versionNo);

  }

  /**
   * {@inheritDoc}
   */
  public ProviderIncidentParticipantDetails viewParticipant(
    IncidentParticipantRoleKey key) throws AppException,
      InformationalException {

    ProviderIncidentParticipantDetails providerIncidentParticipantDetails = new ProviderIncidentParticipantDetails();
    IncidentParticipant incidentParticipant = incidentParticipantDAO.get(
      key.incidentParticipantRoleID);

    providerIncidentParticipantDetails.incidentParticipantDtls.role = incidentParticipant.getRole().getCode();
    providerIncidentParticipantDetails.incidentParticipantDtls.comments = incidentParticipant.getComments();
    providerIncidentParticipantDetails.incidentParticipantDtls.versionNo = incidentParticipant.getVersionNo();
    providerIncidentParticipantDetails.incidentParticipantDtls.recordStatus = incidentParticipant.getLifecycleState().getCode();
    providerIncidentParticipantDetails.incidentParticipantDtls.incidentID = incidentParticipant.getIncident().getID();

    // If the participant is a user, participant name is nothing but user name.
    if (incidentParticipant.getUserName() != null
      && !StringHelper.isEmpty(incidentParticipant.getUserName())) {
      providerIncidentParticipantDetails.participantName = incidentParticipant.getUserName();
      providerIncidentParticipantDetails.userNameInd = true;
      providerIncidentParticipantDetails.incidentParticipantDtls.userName = incidentParticipant.getUserName();

    } // If the participant is not a user, the participant name and concern role
    // type are fetched based on the concern role id.
    else if (incidentParticipant.getConcernRoleID() != 0) {
      providerIncidentParticipantDetails.incidentParticipantDtls.concernRoleID = incidentParticipant.getConcernRoleID();

      // Indicator to check if the participant is a user or just a concern
      // role.
      // Depending on this indicator, view the link on the view page would
      // redirect either to the Participant_resolveRoleHome page or
      // Organization_userHome.
      providerIncidentParticipantDetails.userNameInd = false;

      curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
        incidentParticipant.getConcernRoleID());

      providerIncidentParticipantDetails.participantName = concernRole.getName();
      providerIncidentParticipantDetails.participantConcernRoleType = concernRole.getConcernRoleType().getCode();
    }
    return providerIncidentParticipantDetails;
  }

  /**
   * Reads the context description for a Provider Incident.
   *
   * @param key
   * Contains the ID of the Incident.
   * @return Context description details for the Provider Incident.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public ViewProviderSummaryDetails readIncidentContextDescription(
    ConcernRoleKey key) throws AppException, InformationalException {

    ViewProviderSummaryDetails viewProviderSummaryDetails = new ViewProviderSummaryDetails();

    curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
      key.concernRoleID);

    // Construct the page context description.
    viewProviderSummaryDetails.pageContextDescription = concernRole.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + concernRole.getPrimaryAlternateID();

    return viewProviderSummaryDetails;

  }

  // BEGIN, CR00313834, GA
  /**
   * Adds the contact for a contact log.
   *
   * @param details
   * Contains contact details to be added to the contact log.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.3.0, replaced by {@link MaintainProviderIncident#addContactLogAttendee()}.
   * This method is deprecated because the name of the method does not match its functionality and conveys a wrong meaning. It
   * adds an attendee for contact log, but the method name is addContactLogContact(). See release note : CR00313834.
   */
  @Deprecated
  // END, CR00313834
  public void addContactLogContact(
    CreateProviderIncidentContactLogContactDetails details)
    throws AppException, InformationalException {

    boolean isRegisteredParticipant = false;
    boolean isUser = false;
    boolean isUnRegisteredParticipant = false;
    boolean isProviderMember = false;

    if (!StringHelper.isEmpty(details.details.newConcernRoleName)) {
      isUnRegisteredParticipant = true;
    }

    if (details.details.contactDtls.concernRoleID != 0) {
      isRegisteredParticipant = true;
    }

    if (details.providerMemberConcernRoleID != 0) {
      isProviderMember = true;
    }

    if (!StringHelper.isEmpty(details.details.contactDtls.userName)) {
      isUser = true;
    }
    // Only one of either Provider Member, User, Registered Participant or
    // Unregistered Participant must be entered.
    if ((isProviderMember && isRegisteredParticipant)
      || (isProviderMember && isUser)
      || (isProviderMember && isUnRegisteredParticipant)
      || (isRegisteredParticipant && isUser)
      || (isRegisteredParticipant && isUnRegisteredParticipant)
      || (isUser && isUnRegisteredParticipant)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENT_CONTACTLOG_XFV_ONLY_ONE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    ValidationHelper.failIfErrorsExist();

    if (details.details.newConcernRoleName != null
      && !details.details.newConcernRoleName.equals(CuramConst.gkEmpty)) {
      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = details.details.newConcernRoleName;
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();
      // BEGIN, CR00225696, ASN
      AddressData addressData = AddressDataFactory.newInstance();
      OtherAddressData otherAddressData = addressData.getAddressDataForLocale();

      representativeRegistrationDetails.representativeRegistrationDetails.addressData = otherAddressData.addressData;
      // END, CR00225696
      representativeObj.registerRepresentative(
        representativeRegistrationDetails);

      details.details.contactDtls.concernRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
    } else if (details.providerMemberConcernRoleID != 0) {
      details.details.contactDtls.concernRoleID = details.providerMemberConcernRoleID;
    }
    // BEGIN, CR00154356,SK

    curam.core.facade.intf.ContactLog contactLogObj = curam.core.facade.fact.ContactLogFactory.newInstance();
    // BEGIN, CR00236076, AK
    CreateContactLogAttendeeDetails1 createContactLogAttendeeDetails = new CreateContactLogAttendeeDetails1();

    createContactLogAttendeeDetails.assign(details.details.contactDtls);
    contactLogObj.addContactLogAttendee1(createContactLogAttendeeDetails);
    // END, CR00236076

    // END, CR00154356
  }

  // BEGIN, CR00313834, GA
  /**
   * {@inheritDoc}
   */
  public void addContactLogAttendee(
    final CreateProviderIncidentContactLogContactDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00321084, GA
    curam.core.facade.intf.ContactLog contactLogObj = curam.core.facade.fact.ContactLogFactory.newInstance();
    CreateContactLogAttendeeDetails1 createContactLogAttendeeDtls;
    IncidentParticipant incidentParticipantObj = incidentParticipantDAO.newInstance();

    StringList incidentParticipantRoleIDList = StringUtil.tabText2StringListWithTrim(
      details.incidentParticipantRoleIDTabListOpt);

    for (final String incidentParticipantRoleID : incidentParticipantRoleIDList.items()) {

      createContactLogAttendeeDtls = new CreateContactLogAttendeeDetails1();
      createContactLogAttendeeDtls.contactLogID = details.details.contactDtls.contactLogID;

      incidentParticipantObj = incidentParticipantDAO.get(
        Long.parseLong(incidentParticipantRoleID));

      createContactLogAttendeeDtls.concernRoleID = incidentParticipantObj.getConcernRoleID();
      createContactLogAttendeeDtls.userName = incidentParticipantObj.getUserName();

      contactLogObj.addContactLogAttendee1(createContactLogAttendeeDtls);

    }
    createContactLogAttendeeDtls = new CreateContactLogAttendeeDetails1();
    createContactLogAttendeeDtls.contactLogID = details.details.contactDtls.contactLogID;

    if (null != details.details.newConcernRoleName
      && !CuramConst.gkEmpty.equals(details.details.newConcernRoleName)) {

      createContactLogAttendeeDtls.concernRoleName = details.details.newConcernRoleName;

    }

    if (details.currentUserIsAttendeeIndOpt) {

      createContactLogAttendeeDtls.currentUserIsAttendeeInd = details.currentUserIsAttendeeIndOpt;
    }
    if (0 != details.details.contactDtls.concernRoleID) {
      createContactLogAttendeeDtls.concernRoleID = details.details.contactDtls.concernRoleID;

    }
    if (!CuramConst.gkEmpty.equals(details.details.contactDtls.userName)) {
      createContactLogAttendeeDtls.userName = details.details.contactDtls.userName;
    }
    contactLogObj.addContactLogAttendee1(createContactLogAttendeeDtls);

    if (0 != details.providerMemberConcernRoleID) {

      createContactLogAttendeeDtls = new CreateContactLogAttendeeDetails1();
      createContactLogAttendeeDtls.contactLogID = details.details.contactDtls.contactLogID;
      createContactLogAttendeeDtls.concernRoleID = details.providerMemberConcernRoleID;
      contactLogObj.addContactLogAttendee1(createContactLogAttendeeDtls);
    }
    // END, CR00321084
  }

  // END, CR00313834

  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00321084, GA
  @Deprecated
  // END, CR00321084
  public void createContactLog(CreateProviderIncidentContactLogDetails details)
    throws AppException, InformationalException {

    // Validate the contact log details.
    validateContactLogAttendeeDetails(details);

    if (details.details.newConcernRoleName != null
      && !details.details.newConcernRoleName.equals(CuramConst.gkEmpty)) {
      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = details.details.newConcernRoleName;
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();
      // BEGIN, CR00225696, ASN
      AddressData addressData = AddressDataFactory.newInstance();
      OtherAddressData otherAddressData = addressData.getAddressDataForLocale();

      representativeRegistrationDetails.representativeRegistrationDetails.addressData = otherAddressData.addressData;
      // END, CR00225696
      representativeObj.registerRepresentative(
        representativeRegistrationDetails);

      details.details.contactLogDtls.attendeeDetails.concernRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
    } else if (details.providerMemberConcernRoleID != 0) {
      details.details.contactLogDtls.attendeeDetails.concernRoleID = details.providerMemberConcernRoleID;
    }

    details.details.contactLogDtls.contactLogDetails.author = TransactionInfo.getProgramUser();
    // BEGIN, CR00145224, VKR
    curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory.newInstance();

    CreateContactLogDetails createContantLogDetails = new CreateContactLogDetails();

    createContantLogDetails.contactLogDetails = details.details.contactLogDtls.contactLogDetails;

    // BEGIN, CR00146937, SK
    createContantLogDetails.linkType = CONTACTLOGLINKTYPE.INCIDENT;
    createContantLogDetails.linkID = details.details.contactLogDtls.linkID;
    createContantLogDetails.noteDetails = details.details.contactLogDtls.noteDetails;
    createContantLogDetails.attachmentDetails = details.details.contactLogDtls.attachmentDetails;
    createContantLogDetails.attendeeDetails = details.details.contactLogDtls.attendeeDetails;
    createContantLogDetails.concernConcernRoleTabList = details.details.contactLogDtls.concernConcernRoleTabList;

    // END, CR00146937

    // BEGIN, CR00236076, AK
    CreateContactLogDetails1 createContactLogDetails1 = new CreateContactLogDetails1();

    createContactLogDetails1.assign(createContantLogDetails);
    contactLogObj.create1(createContactLogDetails1);
    // END, CR00236076

    // END, CR00145224
  }

  // BEGIN, CR00321084, GA
  /**
   * {@inheritDoc}
   */
  public curam.cpm.facade.struct.ContactLogKey createIncidentContactLog(CreateProviderIncidentContactLogDetails details)
    throws AppException, InformationalException {

    if (null != details.details.newConcernRoleName
      && !CuramConst.gkEmpty.equals(details.details.newConcernRoleName)) {
      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = details.details.newConcernRoleName;
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();

      AddressData addressData = AddressDataFactory.newInstance();
      OtherAddressData otherAddressData = addressData.getAddressDataForLocale();

      representativeRegistrationDetails.representativeRegistrationDetails.addressData = otherAddressData.addressData;

      representativeObj.registerRepresentative(
        representativeRegistrationDetails);
      details.details.contactLogDtls.attendeeDetails.concernRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;

    } else if (0 != details.providerMemberConcernRoleID) {
      details.details.contactLogDtls.attendeeDetails.concernRoleID = details.providerMemberConcernRoleID;
    }

    details.details.contactLogDtls.contactLogDetails.author = TransactionInfo.getProgramUser();

    ContactLog contactLogObj = ContactLogFactory.newInstance();

    CreateContactLogDetails createContantLogDetails = new CreateContactLogDetails();

    createContantLogDetails.contactLogDetails = details.details.contactLogDtls.contactLogDetails;

    createContantLogDetails.linkType = CONTACTLOGLINKTYPEEntry.INCIDENT.getCode();
    createContantLogDetails.linkID = details.details.contactLogDtls.linkID;
    createContantLogDetails.noteDetails = details.details.contactLogDtls.noteDetails;
    createContantLogDetails.attachmentDetails = details.details.contactLogDtls.attachmentDetails;
    createContantLogDetails.attendeeDetails = details.details.contactLogDtls.attendeeDetails;
    createContantLogDetails.concernConcernRoleTabList = details.details.contactLogDtls.concernConcernRoleTabList;

    CreateContactLogDetails1 createContactLogDetails = new CreateContactLogDetails1();

    createContactLogDetails.assign(createContantLogDetails);
    curam.cpm.facade.struct.ContactLogKey contactLogKey = new curam.cpm.facade.struct.ContactLogKey();

    contactLogKey.contactLogID = contactLogObj.create1(createContactLogDetails).contactLogID;

    return contactLogKey;
  }

  // END, CR00321084

  /**
   * {@inheritDoc}
   */
  public void cancelContactLog(CancelContactLogDetails details)
    throws AppException, InformationalException {

    // Contact Log service object
    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    // cancel contact log
    contactLogObj.cancel(details);

  }

  /**
   * {@inheritDoc}
   */
  public ProviderIncidentContactLogDetailsList listContactLog(IncidentKey key)
    throws AppException, InformationalException {

    ProviderIncidentContactLogDetailsList providerIncidentContactLogDetailsList = new ProviderIncidentContactLogDetailsList();

    // Contact Log service object
    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();
    LinkKey linkKey = new LinkKey();

    linkKey.linkID = key.incidentID;
    // BEGIN, CR00145224, VKR
    ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new ContactLogLinkIDLinkTypeKey();

    contactLogLinkIDLinkTypeKey.linkID = key.incidentID;

    // BEGIN, CR00146937, SK
    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPE.INCIDENT;

    // list contact log details
    // BEGIN, CR00236076, AK
    ContactLogListDtls1List contactLogDetailsList = contactLogObj.list1(
      contactLogLinkIDLinkTypeKey);

    providerIncidentContactLogDetailsList.dtlsList.assign(contactLogDetailsList);
    // END, CR00236076

    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i
      < providerIncidentContactLogDetailsList.dtlsList.dtls.size(); i++) {

      readContactLogDetails.contactLogDetails.assign(
        providerIncidentContactLogDetailsList.dtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj.formatContactLogPurpose(
        readContactLogDetails);

      providerIncidentContactLogDetailsList.dtlsList.dtls.item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
      // BEGIN, CR00234497, PS
      providerIncidentContactLogDetailsList.dtlsList.dtls.item(i).contactLogID = readContactLogDetails.contactLogDetails.contactLogID;
      // END, CR00234497
    }
    // END, CR00146937

    Incident incident = incidentDAO.get(key.incidentID);

    providerIncidentContactLogDetailsList.pageDescription = incident.getType().toUserLocaleString();

    // BEGIN, CR00134515, SK
    Set<IncidentParticipant> incidentParticipantSet = incidentParticipantDAO.searchByIncident(
      incident);

    for (final IncidentParticipant incidentParticipant : incidentParticipantSet) {
      if (incidentParticipant.getRole().equals(
        INCIDENTPARTICIPANTROLEEntry.AGAINST)) {
        providerIncidentContactLogDetailsList.concernRoleID = incidentParticipant.getConcernRoleID();
      }
      // END, CR00134515
    }

    return providerIncidentContactLogDetailsList;
  }

  // BEGIN, CR00234644, GP
  /**
   * Lists the Contact Log details for a given incident.
   *
   * @param incidentKey
   * Incident for which contact log details are to be retrieved.
   *
   * @return The Contact Log details List.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ContactLogDetailsList listIncidentContactLog(IncidentKey incidentKey)
    throws AppException, InformationalException {

    ContactLogDetailsList contactLogDetailsList = new ContactLogDetailsList();

    ContactLog contactLogObj = ContactLogFactory.newInstance();
    LinkKey linkKey = new LinkKey();

    linkKey.linkID = incidentKey.incidentID;

    ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new ContactLogLinkIDLinkTypeKey();

    contactLogLinkIDLinkTypeKey.linkID = incidentKey.incidentID;

    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPE.INCIDENT;

    ContactLogListDtls1List contactLogListDtls1List = contactLogObj.list1(
      contactLogLinkIDLinkTypeKey);

    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    for (int i = 0; i < contactLogListDtls1List.dtls.size(); i++) {

      readContactLogDetails.contactLogDetails.assign(
        contactLogListDtls1List.dtls.item(i));

      readContactLogDetails = contactLogObj.formatContactLogPurpose(
        readContactLogDetails);
      ContactLogDetails contactLogDetails = new ContactLogDetails();

      contactLogDetails.purpose = readContactLogDetails.contactLogDetails.purpose;
      contactLogDetails.contactLogID = readContactLogDetails.contactLogDetails.contactLogID;
      contactLogDetails.versionNo = readContactLogDetails.contactLogDetails.versionNo;
      contactLogDetails.contactLogType = readContactLogDetails.contactLogDetails.contactLogType;
      contactLogDetails.location = readContactLogDetails.contactLogDetails.location;
      contactLogDetails.method = readContactLogDetails.contactLogDetails.method;
      // BEGIN, CR00321084, GA
      contactLogDetails.startDateTime = readContactLogDetails.contactLogDetails.startDateTime;
      contactLogDetails.endDateTimeOpt = readContactLogDetails.contactLogDetails.endDateTime;
      // END, CR00321084
      contactLogDetailsList.contactLogDetails.add(contactLogDetails);
    }

    Incident incident = incidentDAO.get(incidentKey.incidentID);

    Set<IncidentParticipant> incidentParticipantSet = incidentParticipantDAO.searchByIncident(
      incident);

    for (final IncidentParticipant incidentParticipant : incidentParticipantSet) {
      if (INCIDENTPARTICIPANTROLEEntry.AGAINST.equals(
        incidentParticipant.getRole())) {
        contactLogDetailsList.concernRoleID = incidentParticipant.getConcernRoleID();
      }
    }

    return contactLogDetailsList;
  }

  // END, CR00234644

  // BEGIN, CR00321084, GA
  /**
   * {@inheritDoc}
   */
  public SearchContactLogDetails searchContactLogs(
    final ContactLogSearchKey contactLogSearchKey) throws AppException,
      InformationalException {

    final SearchContactLogDetails searchContactLogDetails = new SearchContactLogDetails();
    final ContactLog contactLogObj = ContactLogFactory.newInstance();
    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    if (ACTIONCONTROLIDEntry.SEARCH.getCode().equals(
      contactLogSearchKey.actionControlID)) {

      contactLogSearchKey.key.key.linkType = CONTACTLOGLINKTYPEEntry.INCIDENT.getCode();

      searchContactLogDetails.dtlsList = ContactLogFactory.newInstance().searchContactLogs1(
        contactLogSearchKey.key);

    }

    for (final ContactLogListDtls1 contactLogListDtls : searchContactLogDetails.dtlsList.dtls.items()) {

      readContactLogDetails.contactLogDetails.assign(contactLogListDtls);

      readContactLogDetails = contactLogObj.formatContactLogPurpose(
        readContactLogDetails);

      contactLogListDtls.purpose = readContactLogDetails.contactLogDetails.purpose;
    }

    collectInformationalMsgs(searchContactLogDetails.informationalMsgDtlsList);

    Incident incident = incidentDAO.get(contactLogSearchKey.key.key.linkID);

    Set<IncidentParticipant> incidentParticipantSet = incidentParticipantDAO.searchByIncident(
      incident);

    for (final IncidentParticipant incidentParticipant : incidentParticipantSet) {
      if (INCIDENTPARTICIPANTROLEEntry.AGAINST.equals(
        incidentParticipant.getRole())) {
        searchContactLogDetails.concernRoleID = incidentParticipant.getConcernRoleID();
      }
    }

    return searchContactLogDetails;
  }

  // END, CR00321084

  /**
   * {@inheritDoc}
   */
  public void modifyContactLog(ModifyProviderIncidentContactLogDetails details)
    throws AppException, InformationalException {

    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    // BEGIN, CR00225696, ASN
    contactLogObj.modify1(details.details);
    // END, CR00225696
  }

  /**
   * {@inheritDoc}
   */
  public ProviderIncidentContactLogDetails viewContactLog(ContactLogKey key)
    throws AppException, InformationalException {

    ProviderIncidentContactLogDetails providerIncidentContactLogDetails = new ProviderIncidentContactLogDetails();

    // Contact Log service object
    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    // BEGIN, CR00236076, AK
    ReadContactLogDetails1 readContactLogDetails = contactLogObj.read1(key);

    providerIncidentContactLogDetails.details.assign(readContactLogDetails);
    // END, CR00236076

    // BEGIN, CR00279500, SS
    providerIncidentContactLogDetails.details.noteDetails.noteList.add(
      readContactLogDetails.noteDetails);
    // END, CR00279500

    // BEGIN, CR00146937, SK
    providerIncidentContactLogDetails.details = contactLogObj.formatContactLogPurpose(
      providerIncidentContactLogDetails.details);
    // END, CR00146937

    // read contact log details
    return providerIncidentContactLogDetails;
  }

  // BEGIN, CR00235506, PS
  /**
   * {@inheritDoc}
   */
  public ContactLogOwnerDetails viewContactLogOwnerDetails(
    final ContactLogKey contactLogKey) throws AppException,
      InformationalException {

    ContactLogOwnerDetails contactLogOwnerDetails = new ContactLogOwnerDetails();
    ContactLog contactLogObj = ContactLogFactory.newInstance();

    ReadContactLogDetails1 readContactLogDetails1 = contactLogObj.read1(
      contactLogKey);

    contactLogOwnerDetails.contactLogID = contactLogKey.contactLogID;
    contactLogOwnerDetails.author = readContactLogDetails1.contactLogDetails.author;
    contactLogOwnerDetails.authorFullName = readContactLogDetails1.authorFullName;
    contactLogOwnerDetails.createdBy = readContactLogDetails1.contactLogDetails.createdBy;
    contactLogOwnerDetails.createdByFullName = readContactLogDetails1.createdByFullName;

    // BEGIN, CR00247921, SG
    contactLogOwnerDetails.userDtlsList.assign(
      readContactLogDetails1.attendeeUserDetailsList);
    // END, CR00247921

    return contactLogOwnerDetails;
  }

  // END, CR00235506
  /**
   * {@inheritDoc}
   */
  public AttachmentLinkKey createAttachment(AttachmentLinkDetails details)
    throws AppException, InformationalException {
    AttachmentLinkKey attachmentLinkKey = new AttachmentLinkKey();
    AttachmentLink attachmentLink = attachmentLinkDAO.newInstance();
    curam.attachmentlink.struct.AttachmentLinkDetails attachmentLinkDetails = populateAttachmentLinkDetails(
      details);
    
    // BEGIN, CR00363447, KH
    /*
     * If no related object type is specified set it to INCIDENT
     */
    if (0 == details.details.attachmentLinkDtls.relatedObjectType.length()) {
      attachmentLinkDetails.attachmentLinkDtls.relatedObjectType = ATTACHMENTOBJECTLINKTYPE.INCIDENT;
    }
    // END, CR00363447

    attachmentLinkKey.attachmentLinkID = attachmentLink.insert(
      attachmentLinkDetails);
    return attachmentLinkKey;
  }

  /**
   * {@inheritDoc}
   */
  public ListAttachmentLinkDetails listAttachment(IncidentKey key)
    throws AppException, InformationalException {

    List<curam.attachmentlink.impl.AttachmentLink> attachmentLinks = attachmentLinkDAO.searchByRelatedIDAndType(
      key.incidentID, ATTACHMENTOBJECTLINKTYPEEntry.INCIDENT);

    ListAttachmentLinkDetails listAttachmentLinkDetails = new ListAttachmentLinkDetails();

    for (curam.attachmentlink.impl.AttachmentLink attachmentLink : attachmentLinks) {
      AttachmentLinkDetails attachmentLinkDetails = populateAttachmentLinkDetails(
        attachmentLink);

      listAttachmentLinkDetails.details.addRef(attachmentLinkDetails);
    }

    return listAttachmentLinkDetails;
  }

  /**
   * {@inheritDoc}
   */
  public AttachmentLinkDetails viewAttachment(AttachmentLinkKey key)
    throws AppException, InformationalException {

    AttachmentLink attachmentLink = attachmentLinkDAO.get(key.attachmentLinkID);
    AttachmentLinkDetails attachmentLinkDetails = populateAttachmentLinkDetails(
      attachmentLink);

    return attachmentLinkDetails;
  }

  /**
   * {@inheritDoc}
   */
  public void modifyAttachment(AttachmentLinkDetails details)
    throws AppException, InformationalException {
    AttachmentLink attachmentLink = attachmentLinkDAO.get(
      details.details.attachmentLinkDtls.attachmentLinkID);
    curam.attachmentlink.struct.AttachmentLinkDetails attachmentLinkDetails = populateAttachmentLinkDetails(
      details);

    attachmentLink.modify(attachmentLinkDetails);
  }

  /**
   * {@inheritDoc}
   */
  public void cancelAttachment(CancelAttachmentKey key) throws AppException,
      InformationalException {
    AttachmentLink attachmentLink = attachmentLinkDAO.get(key.attachmentLinkKey);

    attachmentLink.cancel(key.versionNo);

  }

  // BEGIN, CR00197371, GP
  // BEGIN, CR00237067, GP
  /**
   * Reads the provider incident tab details.
   *
   * @param providerOrganizationAndIncidentDetails
   * Provider or provider group and incident for which details are to
   * be read.
   *
   * @return Provider incident details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00237067
  public ViewProviderIncidentTabDetails readProviderIncidentTabDetails(
    final ProviderOrganizationAndIncidentDetails providerOrganizationAndIncidentDetails)
    throws AppException, InformationalException {

    ViewProviderIncidentTabDetails viewProviderIncidentTabDetails = new ViewProviderIncidentTabDetails();

    // BEGIN, CR00199708, GP
    IncidentTabDtls incidentTabDtls = new IncidentTabDtls();

    Incident incidentObj = incidentDAO.get(
      providerOrganizationAndIncidentDetails.incidentID);

    // BEGIN, CR00237067, GP
    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      providerOrganizationAndIncidentDetails.concernRoleID);

    // END, CR00237067

    incidentTabDtls.incidentID = incidentObj.getID();
    incidentTabDtls.anonymousReportInd = incidentObj.isAnonymousReporter();
    incidentTabDtls.status = incidentObj.getLifecycleState().getCode();
    incidentTabDtls.type = incidentObj.getType().getCode();
    incidentTabDtls.incidentDate = incidentObj.getIncidentDate();
    incidentTabDtls.incidentTime = incidentObj.getIncidentTime();
    incidentTabDtls.timeOfDay = incidentObj.getTimeOfDay().getCode();
    incidentTabDtls.recordedDate = incidentObj.getRecordedDate();
    incidentTabDtls.reportMethod = incidentObj.getReportMethod().getCode();
    incidentTabDtls.severity = incidentObj.getSeverity().getCode();

    List<IncidentStatusHistory> incidentStatusHistoryList = sortByDate(
      incidentObj.getStatusHistory());

    IncidentStatusHistory incidentStatusHistory = incidentStatusHistoryList.get(
      incidentStatusHistoryList.size() - CuramConst.gkOne);

    incidentTabDtls.incidentStatusDateTime = incidentStatusHistory.getEventDateTime();
    incidentTabDtls.incidentStatusUserName = incidentStatusHistory.getUserName();

    // Get the initial and the latest/last contact log for this incident. This
    // could be the same contact log.
    LinkIDLinkTypeRecordStatusKey linkIDLinkTypeRecordStatusKey = new LinkIDLinkTypeRecordStatusKey();

    linkIDLinkTypeRecordStatusKey.linkID = incidentObj.getID();
    linkIDLinkTypeRecordStatusKey.linkType = CONTACTLOGLINKTYPEEntry.INCIDENT.getCode();
    linkIDLinkTypeRecordStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    ContactLogListDtls1List contactLogListDtls1List = curam.core.sl.entity.fact.ContactLogFactory.newInstance().searchActiveByLinkIDLinkType1(
      linkIDLinkTypeRecordStatusKey);

    if (contactLogListDtls1List.dtls.size() > 0) {

      // contactLogListDtls1List is ordered by startDateTime
      // descending (latest first)
      ContactLogListDtls1 lastContactLogDtls = contactLogListDtls1List.dtls.item(
        0);
      ContactLogListDtls1 initialContactLogDtls = contactLogListDtls1List.dtls.item(
        contactLogListDtls1List.dtls.size() - CuramConst.gkOne);

      incidentTabDtls.initialContactType = initialContactLogDtls.contactLogType;
      incidentTabDtls.initialContactStartDateTime = initialContactLogDtls.startDateTime;

      incidentTabDtls.latestContactType = lastContactLogDtls.contactLogType;
      incidentTabDtls.latestContactStartDateTime = lastContactLogDtls.startDateTime;
    }

    // get incident participant role count
    Set<IncidentParticipant> incidentParticipantSet = incidentParticipantDAO.searchByIncident(
      incidentObj);

    Iterator<IncidentParticipant> incidentParticipantSetIterator = incidentParticipantSet.iterator();

    int participantCount = 0;

    // BEGIN, CR00237067, GP
    String providerRole = CuramConst.gkEmpty;
    String providerGroupRole = CuramConst.gkEmpty;

    // END, CR00237067

    while (incidentParticipantSetIterator.hasNext()) {

      IncidentParticipant incidentParticipantObj = incidentParticipantSetIterator.next();

      if (!RECORDSTATUSEntry.CANCELLED.equals(
        incidentParticipantObj.getLifecycleState())) {
        if (!INCIDENTPARTICIPANTROLEEntry.REPORTER.equals(
          incidentParticipantObj.getRole())) {

          participantCount++;

          // BEGIN, CR00237067, GP
          // Get the comma separated provider or provider group roles. Display
          // the roles if the provider or provider group is an incident
          // participant with a role other than reporter.
          if (incidentParticipantObj.getConcernRoleID()
            == providerOrganization.getID()) {

            if (CONCERNROLETYPEEntry.PROVIDER.equals(
              providerOrganization.getConcernRoleType())) {
              // BEGIN, CR00246961, GP
              if (!StringUtil.isNullOrEmpty(providerRole)) {
                providerRole += CuramConst.kCommaSeparator;
              }

              providerRole = CodeTable.getOneItem(
                INCIDENTPARTICIPANTROLEEntry.TABLENAME,
                incidentParticipantObj.getRole().getCode(),
                TransactionInfo.getProgramLocale());

            } else if (CONCERNROLETYPEEntry.PROVIDERGROUP.equals(
              providerOrganization.getConcernRoleType())) {

              if (!StringUtil.isNullOrEmpty(providerGroupRole)) {
                providerGroupRole += CuramConst.kCommaSeparator;
              }

              providerGroupRole = CodeTable.getOneItem(
                INCIDENTPARTICIPANTROLEEntry.TABLENAME,
                incidentParticipantObj.getRole().getCode(),
                TransactionInfo.getProgramLocale());
            }
          }
        } else {

          // Display the provider group role irrespective of the role.
          if (incidentParticipantObj.getConcernRoleID()
            == providerOrganization.getID()) {

            if (CONCERNROLETYPEEntry.PROVIDERGROUP.equals(
              providerOrganization.getConcernRoleType())) {

              if (!StringUtil.isNullOrEmpty(providerGroupRole)) {
                providerGroupRole += CuramConst.kCommaSeparator;
              }
              // END, CR00246961
              providerGroupRole = CodeTable.getOneItem(
                INCIDENTPARTICIPANTROLEEntry.TABLENAME,
                incidentParticipantObj.getRole().getCode(),
                TransactionInfo.getProgramLocale());
            }
          }
        }
        // END, CR00237067
      }

    }

    incidentTabDtls.participantCount = participantCount;

    Set<IncidentParticipant> reporterSet = incidentParticipantDAO.searchActiveByIncidentAndRole(
      incidentObj, INCIDENTPARTICIPANTROLEEntry.REPORTER);

    if (!reporterSet.isEmpty()) {

      IncidentParticipant incidentReporterObj = reporterSet.iterator().next();

      if (incidentReporterObj.getConcernRoleID() == 0) {

        incidentTabDtls.reporterUserName = incidentReporterObj.getUserName();

        UsersKey usersKey = new UsersKey();

        usersKey.userName = incidentTabDtls.reporterUserName;

        UserContactDtls userContactDtls = UsersFactory.newInstance().readUserContactDetails(
          usersKey);

        incidentTabDtls.assign(userContactDtls);

      } else {
        incidentTabDtls.reporterConcernRoleID = incidentReporterObj.getConcernRoleID();

        ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
        curam.core.struct.ConcernRoleKey concernRoleKey = new curam.core.struct.ConcernRoleKey();

        concernRoleKey.concernRoleID = incidentTabDtls.reporterConcernRoleID;

        ReadParticipantRoleNameAndTypeDetails reporterNameAndTypeDetails = concernRoleObj.readParticipantRoleNameAndType(
          concernRoleKey);

        incidentTabDtls.reporterConcernRoleName = reporterNameAndTypeDetails.concernRoleName;
        incidentTabDtls.reporterConcernRoleType = reporterNameAndTypeDetails.concernRoleType;

        ConcernRoleContactDetails concernRoleContactDetails = concernRoleObj.readConcernRoleContactDetails(
          concernRoleKey);

        incidentTabDtls.assign(concernRoleContactDetails);

      }

    }

    ContentPanelBuilder containerPanel = ContentPanelBuilder.createPanel(
      CPMConstants.gkProviderIncidentContainer);

    // BEGIN, CR00249624, GP
    ContentPanelBuilder incidentDetails = getIncidentDetails(incidentTabDtls,
      providerRole, providerGroupRole, providerOrganization);
    // END, CR00249624

    ContentPanelBuilder reportedDetails = getIncidentReporterDetails(
      incidentTabDtls);

    incidentDetails.addWidgetItem(reportedDetails, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    ContactLogTabDetails contactLogTabDetails = new ContactLogTabDetails();

    contactLogTabDetails.assign(incidentTabDtls);

    contactLogTabDetails.initialContactStartDate = new Date(
      incidentTabDtls.initialContactStartDateTime);
    contactLogTabDetails.latestContactStartDate = new Date(
      incidentTabDtls.latestContactStartDateTime);

    contactLogTabDetails.lastContactInd = INCIDENTSTATUS.CLOSED.equals(
      incidentTabDtls.status);

    incidentDetails.addWidgetItem(getContactDetails(contactLogTabDetails),
      CuramConst.gkStyle, CuramConst.gkContentPanel);

    containerPanel.addWidgetItem(incidentDetails, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CPMConstants.gkProviderIncidentContentPanel);

    viewProviderIncidentTabDetails.providerIncidentTabDetails = containerPanel.toString();

    viewProviderIncidentTabDetails.contextDescription = new LocalisableString(BPOINCIDENTTAB.INF_INCIDENT_NAME).arg(new CodeTableItemIdentifier(INCIDENTTYPE.TABLENAME, incidentTabDtls.type)).arg(incidentTabDtls.incidentDate).getMessage();
    // END, CR00199708

    // BEGIN, CR00226896, PS
    viewProviderIncidentTabDetails.incidentType = incidentTabDtls.type;
    viewProviderIncidentTabDetails.dateOccured = incidentTabDtls.incidentDate;
    // END, CR00226896

    return viewProviderIncidentTabDetails;
  }

  // END, CR00197371

  /**
   * Populates the Provider Incident Participant details from the Incident
   * Participant class instance.
   *
   * @param incidentParticipant
   * Class instance for the Incident Participant.
   * @return Provider Incident Participant details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ProviderIncidentParticipantDetails getProviderIncidentParticipantDetails(
    IncidentParticipant incidentParticipant) throws AppException,
      InformationalException {
    ProviderIncidentParticipantDetails incidentParticipantDetails = new ProviderIncidentParticipantDetails();

    incidentParticipantDetails.incidentParticipantDtls.comments = incidentParticipant.getComments();
    incidentParticipantDetails.incidentParticipantDtls.incidentID = incidentParticipant.getIncident().getID();
    incidentParticipantDetails.incidentParticipantDtls.incidentParticipantRoleID = incidentParticipant.getID();
    incidentParticipantDetails.incidentParticipantDtls.recordStatus = incidentParticipant.getLifecycleState().getCode();
    incidentParticipantDetails.incidentParticipantDtls.role = incidentParticipant.getRole().getCode();

    incidentParticipantDetails.incidentParticipantDtls.versionNo = incidentParticipant.getVersionNo();

    if (!StringHelper.isEmpty(incidentParticipant.getUserName())) {

      // BEGIN, CR00247921, SG
      User user = userDAO.get(incidentParticipant.getUserName());

      incidentParticipantDetails.participantName = user.getFullName();
      // END, CR00247921

    } else if (incidentParticipant.getConcernRoleID() != 0) {
      curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
        incidentParticipant.getConcernRoleID());

      incidentParticipantDetails.incidentParticipantDtls.concernRoleID = incidentParticipant.getConcernRoleID();
      incidentParticipantDetails.participantName = concernRole.getName();

      // BEGIN, CR00322348, SSK
      incidentParticipantDetails.participantConcernRoleType = concernRole.getConcernRoleType().getCode();
      // END, CR00322348
    }

    return incidentParticipantDetails;
  }

  /**
   * Populates the Provider Incident details from the Provider Incident class
   * instance.
   *
   * @param providerIncident
   * Class instance for the Provider Incident.
   * @return Provider Incident details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ProviderIncidentDetails getProviderIncidentDetails(
    ProviderIncident providerIncident) throws AppException,
      InformationalException {

    ProviderIncidentDetails providerIncidentDetails = new ProviderIncidentDetails();
    Incident incident = providerIncident.getIncident();
    Compartment compartment = providerIncident.getCompartment();

    if (compartment != null) {
      providerIncidentDetails.compartmentID = compartment.getID();
      providerIncidentDetails.compartmentName = compartment.getName();
    }
    providerIncidentDetails.providerIncidentDtls.incidentID = incident.getID();
    providerIncidentDetails.providerIncidentDtls.providerFacilityInd = providerIncident.isProviderFacility();
    providerIncidentDetails.dtls = getIncidentDetails(incident);
    providerIncidentDetails.reportedBy = getIncidentReporterDetails(incident);

    return providerIncidentDetails;

  }

  /**
   * Validates the Provider Incident details.
   *
   * @param details
   * Provider Incident details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void validateProviderIcident(CreateProviderIncidentDetails details)
    throws AppException, InformationalException {

    boolean isRegisteredParticipant = false;
    boolean isUser = false;
    boolean isUnRegisteredParticipant = false;
    boolean isProviderMember = false;

    if (!StringHelper.isEmpty(
      details.participantDetails.representativeRegDetails.representativeDtls.representativeName)) {
      isUnRegisteredParticipant = true;
    }

    if (details.participantDetails.incidentParticipantDtls.concernRoleID != 0) {
      isRegisteredParticipant = true;
    }

    if (details.participantDetails.providerMemberConcernRoleID != 0) {
      isProviderMember = true;
    }

    if (!StringHelper.isEmpty(
      details.participantDetails.incidentParticipantDtls.userName)) {
      isUser = true;
    }

    if ((details.providerIncidentDtls.compartmentID == 0
      && details.providerIncidentDtls.providerFacilityInd == false)
        && details.incidentDtls.location.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENT_XFV_EITHER_PROVIDER_FACILITY_OR_COMPARTMENT_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // If Compartment entered and provider facility not entered.
    if (details.providerIncidentDtls.compartmentID != 0
      && details.providerIncidentDtls.providerFacilityInd == false) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENT_XFV_PROVIDER_FACILITY_MUST_BE_ENTERED_IF_COMPARTMENT_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // One of either Provider Facility or Other Location must be entered.
    if (details.providerIncidentDtls.providerFacilityInd
      && !StringHelper.isEmpty(details.incidentDtls.location)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENT_XFV_EITHER_ONE_PROVIDER_FACILITY_OR_COMPARTMENT_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Either Anonymous Report or Reporter must be entered.
    if (!details.incidentDtls.anonymousReportInd
      && !(isRegisteredParticipant || isUser || isUnRegisteredParticipant
      || isProviderMember)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENT_XFV_EITHER_ANONYMOUSREPORT_OR_REPORTER_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Either Anonymous Report or Reporter must be entered.
    if (details.incidentDtls.anonymousReportInd
      && (isRegisteredParticipant || isUser || isUnRegisteredParticipant
      || isProviderMember)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENT_XFV_EITHER_ANONYMOUSREPORT_OR_REPORTER_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    // Call this validation while creation of provider incident.
    if (details.incidentDtls.incidentID == 0) {
      // Only one of either Provider Member, User, Registered Participant or
      // Unregistered Participant must be entered.
      if (!details.incidentDtls.anonymousReportInd
        && (isProviderMember && isRegisteredParticipant)
          || (isProviderMember && isUser)
          || (isProviderMember && isUnRegisteredParticipant)
          || (isRegisteredParticipant && isUser)
          || (isRegisteredParticipant && isUnRegisteredParticipant)
          || (isUser && isUnRegisteredParticipant)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENTPARTICIPANT_XRV_ONLY_ONE_MUST_BE_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
      // Call this validation while modification of provider incident.
    } else if (details.incidentDtls.incidentID != 0) {

      // Only one of either User, Registered Participant or
      // Unregistered Participant must be entered.
      if (!details.incidentDtls.anonymousReportInd
        && (isRegisteredParticipant && isUser)
          || (isRegisteredParticipant && isUnRegisteredParticipant)
          || (isUser && isUnRegisteredParticipant)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENTPARTICIPANT_XRV_ONLY_ONE_MUST_BE_ENTERED_WHEN_MODIFY(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }

    ValidationHelper.failIfErrorsExist();
  }

  /**
   * Sets the Incident class instance from the Provider Incident details.
   *
   * @param providerIncidentdetails
   * Contains the Provider Incident details.
   * @return The Incident class instance.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected Incident setIncidentDetails(
    CreateProviderIncidentDetails providerIncidentdetails)
    throws AppException, InformationalException {

    Incident incident = incidentDAO.newInstance();

    if (providerIncidentdetails.incidentDtls.incidentID != 0) {
      incident = incidentDAO.get(
        providerIncidentdetails.incidentDtls.incidentID);
    }

    incident.setAnonymousReporter(
      providerIncidentdetails.incidentDtls.anonymousReportInd);
    incident.setCategory(
      INCIDENTCATEGORYEntry.get(providerIncidentdetails.incidentDtls.category));
    incident.appendDescription(providerIncidentdetails.incidentDtls.description);
    // BEGIN, CR00225696, ASN
    incident.setIncidentDate(providerIncidentdetails.incidentDtls.incidentDate);
    incident.setIncidentTime(providerIncidentdetails.incidentDtls.incidentTime);
    // END, CR00225696
    if (providerIncidentdetails.providerIncidentDtls.providerFacilityInd
      && providerIncidentdetails.providerIncidentDtls.compartmentID == 0) {
      // BEGIN, CR00186270, PS
      incident.setLocation(
        new curam.util.exception.LocalisableString(curam.message.PROVIDERINCIDENT.TEXT_INCIDENT_PROVIDER_FACILITY).getMessage());
      // END, CR00186270
    } else if (providerIncidentdetails.providerIncidentDtls.providerFacilityInd
      && providerIncidentdetails.providerIncidentDtls.compartmentID != 0) {
      Compartment compartment = compartmentDAO.get(
        providerIncidentdetails.providerIncidentDtls.compartmentID);

      if (compartment != null) {
        // BEGIN, CR00186270, PS
        String incidentLocation = new curam.util.exception.LocalisableString(curam.message.PROVIDERINCIDENT.TEXT_INCIDENT_PROVIDER_FACILITY).getMessage()
          + CuramConst.gkSpace + CPMConstants.kHypen + CuramConst.gkSpace
          + compartment.getName();

        // END, CR00186270
        incident.setLocation(incidentLocation);
      }
    } else if (!providerIncidentdetails.providerIncidentDtls.providerFacilityInd
      && providerIncidentdetails.providerIncidentDtls.compartmentID == 0) {
      incident.setLocation(providerIncidentdetails.incidentDtls.location);
    }

    incident.setReportMethod(
      INCIDENTREPORTMETHODEntry.get(
        providerIncidentdetails.incidentDtls.reportMethod));
    incident.setSensitivity(
      SENSITIVITYEntry.get(providerIncidentdetails.incidentDtls.sensitivityCode));
    incident.setSeverity(
      INCIDENTSEVERITYEntry.get(providerIncidentdetails.incidentDtls.severity));
    incident.setTimeOfDay(
      INCIDENTTIMEOFDAYEntry.get(providerIncidentdetails.incidentDtls.timeOfDay));
    incident.setType(
      INCIDENTTYPEEntry.get(providerIncidentdetails.incidentDtls.type));
    return incident;
  }

  /**
   * Gets the Incident details from the Incident class instance.
   *
   * @param incident
   * Incident class instance.
   * @return Incident details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  protected IncidentDtls getIncidentDetails(Incident incident)
    throws AppException, InformationalException {

    IncidentDtls incidentDtls = new IncidentDtls();

    incidentDtls.anonymousReportInd = incident.isAnonymousReporter();
    incidentDtls.category = incident.getCategory().getCode();
    incidentDtls.closureComment = incident.getClosureComment();
    incidentDtls.closureDate = incident.getIncidentClosureDate();
    incidentDtls.closureReason = incident.getClosureReason().getCode();
    incidentDtls.description = incident.getDescription();
    // BEGIN, CR00225696, ASN
    incidentDtls.incidentDateTime = incident.getIncidentTime();
    incidentDtls.incidentDate = incident.getIncidentDate();
    // END, CR00225696
    // BEGIN, CR00234435, AK
    incidentDtls.incidentTime = incident.getIncidentTime();
    // END, CR00234435
    incidentDtls.incidentID = incident.getID();
    incidentDtls.location = incident.getLocation();
    incidentDtls.recordedBy = incident.getRecordedBy();
    incidentDtls.recordedDate = incident.getRecordedDate();
    incidentDtls.reportMethod = incident.getReportMethod().getCode();
    incidentDtls.sensitivityCode = incident.getSensitivity().getCode();
    incidentDtls.severity = incident.getSeverity().getCode();
    incidentDtls.status = incident.getLifecycleState().getCode();
    incidentDtls.timeOfDay = incident.getTimeOfDay().getCode();
    incidentDtls.type = incident.getType().getCode();
    incidentDtls.versionNo = incident.getVersionNo();

    return incidentDtls;

  }

  /**
   * Gets the reporter for an Incident.
   *
   * @param incident
   * Incident class instance.
   * @return The reporter of the Incident.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected String getIncidentReporterDetails(Incident incident)
    throws AppException, InformationalException {

    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    String reporterName = CuramConst.gkEmpty;

    if (!incident.isAnonymousReporter()) {

      Set<IncidentParticipant> incidentParticipantSet = incidentParticipantDAO.searchByIncident(
        incident);

      Iterator<IncidentParticipant> incidentParticipantSetIterator = incidentParticipantSet.iterator();

      while (incidentParticipantSetIterator.hasNext()) {

        IncidentParticipant incidentParticipantObj = incidentParticipantSetIterator.next();

        if (incidentParticipantObj.getRole().equals(
          INCIDENTPARTICIPANTROLEEntry.REPORTER)) {

          if (incidentParticipantObj.getConcernRoleID() != 0) {
            curam.core.struct.ConcernRoleKey concernRoleKey = new curam.core.struct.ConcernRoleKey();

            concernRoleKey.concernRoleID = incidentParticipantObj.getConcernRoleID();

            reporterName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
          } else {
            // BEGIN, CR00236233, GP
            User user = userDAO.get(incidentParticipantObj.getUserName());

            reporterName = user.getFullName();
            // END, CR00236233
          }
        }
      }
    } else {
      // BEGIN, CR00186270, PS
      reporterName = new curam.util.exception.LocalisableString(curam.message.PROVIDERINCIDENT.TEXT_INCIDENT_ANONYMOUS_REPORTER).getMessage();
      // END, CR00186270
    }

    return reporterName;

  }

  /**
   * Sets the Incident participant class instance from the Provider Incident
   * details.
   *
   * @param providerIncidentdetails
   * Contains the Provider Incident details.
   * @return The Incident class instance.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected IncidentParticipant setIncidentParticipantDetails(
    CreateProviderIncidentDetails details) throws AppException,
      InformationalException {

    IncidentParticipant incidentParticipant = incidentParticipantDAO.get(
      details.participantDetails.incidentParticipantDtls.incidentParticipantRoleID);

    if (!StringHelper.isEmpty(
      details.participantDetails.representativeRegDetails.representativeDtls.representativeName)) {
      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      details.participantDetails.representativeRegDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();
      representativeObj.registerRepresentative(
        details.participantDetails.representativeRegDetails);
      incidentParticipant.setConcernRoleID(
        details.participantDetails.representativeRegDetails.representativeDtls.concernRoleID);
      incidentParticipant.setUserName(
        details.participantDetails.incidentParticipantDtls.userName);

    } else if (details.participantDetails.incidentParticipantDtls.concernRoleID
      != 0) {
      incidentParticipant.setConcernRoleID(
        details.participantDetails.incidentParticipantDtls.concernRoleID);
      incidentParticipant.setUserName(
        details.participantDetails.incidentParticipantDtls.userName);
    } else if (!StringHelper.isEmpty(
      details.participantDetails.incidentParticipantDtls.userName)) {
      incidentParticipant.setConcernRoleID(
        details.participantDetails.incidentParticipantDtls.concernRoleID);
      incidentParticipant.setUserName(
        details.participantDetails.incidentParticipantDtls.userName);
    }

    return incidentParticipant;
  }

  /**
   * Populates the attachment and attachment link details from the attachment
   * link object to the attachment and attachment link details struct.
   *
   * @param attachmentLink
   * An attachmentLink object.
   * @return Attachment and attachment link details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected AttachmentLinkDetails populateAttachmentLinkDetails(
    curam.attachmentlink.impl.AttachmentLink attachmentLink)
    throws AppException, InformationalException {

    AttachmentLinkDetails attachmentLinkDetails = new AttachmentLinkDetails();
    AttachmentKey attachmentKey = new AttachmentKey();
    curam.attachmentlink.struct.AttachmentLinkDetails attachmentDetails = new curam.attachmentlink.struct.AttachmentLinkDetails();

    attachmentKey.attachmentID = attachmentLink.getAttachmentID();

    attachmentDetails.attachmentDtls = attachmentObj.read(attachmentKey);

    attachmentLinkDetails.details.attachmentLinkDtls.attachmentLinkID = attachmentLink.getID();
    attachmentLinkDetails.details.attachmentLinkDtls.description = attachmentLink.getDescription();
    attachmentLinkDetails.details.attachmentLinkDtls.versionNo = attachmentLink.getVersionNo();
    attachmentLinkDetails.details.attachmentLinkDtls.recordStatus = attachmentLink.getLifecycleState().getCode();
    attachmentLinkDetails.details.attachmentLinkDtls.sensitivityCode = attachmentLink.getSensitivityCode().getCode();
    attachmentLinkDetails.details.attachmentLinkDtls.creatorUserName = attachmentLink.getCreator();
    attachmentLinkDetails.details.attachmentDtls.assign(
      attachmentDetails.attachmentDtls);

    return attachmentLinkDetails;
  }

  /**
   * Populates the attachment and attachment link details from the attachment
   * and attachment link details sent from client.
   *
   * @param details
   * Attachment and attachment link details.
   * @return Attachment and attachment link details.
   */
  protected curam.attachmentlink.struct.AttachmentLinkDetails populateAttachmentLinkDetails(
    AttachmentLinkDetails details) {

    curam.attachmentlink.struct.AttachmentLinkDetails attachmentLinkDetails = new curam.attachmentlink.struct.AttachmentLinkDetails();

    attachmentLinkDetails.attachmentDtls.assign(details.details.attachmentDtls);
    attachmentLinkDetails.attachmentLinkDtls.assign(
      details.details.attachmentLinkDtls);
    attachmentLinkDetails.displayActionLinks = details.details.displayActionLinks;
    attachmentLinkDetails.sensitiveInd = details.details.sensitiveInd;

    return attachmentLinkDetails;
  }

  /**
   * Validates the Contact Log attendee details.
   *
   * @param details
   * Contact Log attendee details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void validateContactLogAttendeeDetails(
    CreateProviderIncidentContactLogDetails details) throws AppException,
      InformationalException {

    boolean isRegisteredParticipant = false;
    boolean isUser = false;
    boolean isUnRegisteredParticipant = false;
    boolean isProviderMember = false;

    if (!StringHelper.isEmpty(details.details.newConcernRoleName)) {
      isUnRegisteredParticipant = true;
    }

    if (details.details.contactLogDtls.attendeeDetails.concernRoleID != 0) {
      isRegisteredParticipant = true;
    }

    if (details.providerMemberConcernRoleID != 0) {
      isProviderMember = true;
    }

    if (!StringHelper.isEmpty(
      details.details.contactLogDtls.attendeeDetails.userName)) {
      isUser = true;
    }
    // Only one of either Provider Member, User, Registered Participant or
    // Unregistered Participant must be entered.
    if ((isProviderMember && isRegisteredParticipant)
      || (isProviderMember && isUser)
      || (isProviderMember && isUnRegisteredParticipant)
      || (isRegisteredParticipant && isUser)
      || (isRegisteredParticipant && isUnRegisteredParticipant)
      || (isUser && isUnRegisteredParticipant)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERINCIDENTExceptionCreator.ERR_PROVIDERINCIDENT_CONTACTLOG_XFV_ONLY_ONE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    ValidationHelper.failIfErrorsExist();
  }

  // BEGIN, CR00197371, GP
  /**
   * Sorts the list of status history records by date.
   *
   * @param unSortedlist
   * Unsorted list of status history records.
   * @return List Sorted list of status history records
   */
  protected List<IncidentStatusHistory> sortByDate(
    final Set<IncidentStatusHistory> unSortedlist) {

    final List<IncidentStatusHistory> incidentStatusHistory = new ArrayList<IncidentStatusHistory>(
      unSortedlist);

    Collections.sort(incidentStatusHistory,
      new Comparator<IncidentStatusHistory>() {
      public int compare(final IncidentStatusHistory lhs,
        IncidentStatusHistory rhs) {
        return rhs.getEventDateTime().compareTo(lhs.getEventDateTime());
      }
    });

    return incidentStatusHistory;
  }

  // END, CR00197371

  // BEGIN, CR00199708, GP
  // BEGIN, CR00249624, GP
  /**
   * Formats XML data for an Incident tab details.
   *
   * @param details
   * Incident details.
   * @param providerRole
   * Role of the provider.
   * @param providerGroupRole
   * Role of the provider group.
   * @param providerOrganization
   * Provider or provider group for which incident is created.
   *
   * @return Content panel builder.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ContentPanelBuilder getIncidentDetails(
    final IncidentTabDtls details, final String providerRole,
    final String providerGroupRole,
    final ProviderOrganization providerOrganization) throws AppException,
      InformationalException {
    // END, CR00249624

    ContentPanelBuilder contentPanelBuilder = ContentPanelBuilder.createPanel(
      CPMConstants.gkProviderIncidentTabDetails);

    contentPanelBuilder.addRoundedCorners();

    ContentPanelBuilder incidentDetail = ContentPanelBuilder.createPanel(
      CPMConstants.gkProviderIncidentDetails);
    CodeTableItemIdentifier type = new CodeTableItemIdentifier(
      INCIDENTTYPE.TABLENAME, details.type);
    CodeTableItemIdentifier severity = new CodeTableItemIdentifier(
      INCIDENTSEVERITY.TABLENAME, details.severity);

    LocalisableString incidentTypeSeverity = new LocalisableString(PROVIDERINCIDENT.TEXT_INCIDENT_TYPE_SEVERITY).arg(type).arg(
      severity);

    incidentDetail.addlocalisableStringItem(
      incidentTypeSeverity.toClientFormattedText(),
      CPMConstants.gkProviderIncidentType);

    // BEGIN, CR00237067, GP
    ProviderIncident providerIncident = providerIncidentDAO.get(
      details.incidentID);
    LocalisableString location = null;

    if (providerIncident.isProviderFacility()) {

      // Display compartment information when it is present otherwise display
      // only provider facility.
      if (null != providerIncident.getCompartment()) {

        // BEGIN, CR00260504, GP
        location = new LocalisableString(PROVIDERINCIDENT.TEXT_INCIDENT_PROVIDER_FACILITY_AND_COMPARTMENT).arg(
          CuramConst.kSeparator + providerIncident.getCompartment().getName());
        // END, CR00260504
      } else {

        location = new LocalisableString(
          PROVIDERINCIDENT.TEXT_INCIDENT_PROVIDER_FACILITY_TEXT);
      }
    }
    // END, CR00237067

    String occurence = null;

    // BEGIN, CR00387958, MR
    final TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();

    if (!details.incidentTime.isZero()) {

      final FormatTimeDetails formatTimeDetails = new FormatTimeDetails();

      formatTimeDetails.time = details.incidentTime;
      formatTimeDetails.format24hourInd = true;

      final TimeString time = tabDetailFormatterObj.formatTime(
        formatTimeDetails);

      occurence = new LocalisableString(BPOINCIDENTTAB.INF_OCCURRED_DATE_TIME).arg(details.incidentDate).toClientFormattedText();
      incidentDetail.addlocalisableStringItem(occurence,
        CPMConstants.gkProviderIncidentDate);
      incidentDetail.addlocalisableStringItem(time.time,
        CPMConstants.gkProviderIncidentTime);
    } else if (details.timeOfDay.length() != 0) {
      occurence = new LocalisableString(BPOINCIDENTTAB.INF_OCCURRED_DATE_TIME_OF_DAY).arg(details.incidentDate).arg(new CodeTableItemIdentifier(INCIDENTTIMEOFDAY.TABLENAME, details.timeOfDay)).toClientFormattedText();
      incidentDetail.addlocalisableStringItem(occurence,
        CPMConstants.gkProviderIncidentDate);
    } else {
      occurence = new LocalisableString(BPOINCIDENTTAB.INF_OCCURRED_DATE).arg(details.incidentDate).toClientFormattedText();
      incidentDetail.addlocalisableStringItem(occurence,
        CPMConstants.gkProviderIncidentDate);
    }
    // END, CR00387958
    
    String participants = new LocalisableString(BPOINCIDENTTAB.INF_NUM_PARTICIPANT).arg(details.participantCount).toClientFormattedText();

    // BEGIN, CR00249624, GP
    LinkBuilder participantLinkBuilder = LinkBuilder.createLocalizableLink(
      participants, CPMConstants.kIncidentParticipants);

    participantLinkBuilder.addParameter(CuramConst.gkPageParameterIncidentID,
      String.valueOf(details.incidentID));
    participantLinkBuilder.addParameter(CuramConst.kconcernRoleID,
      providerOrganization.getID().toString());
    // END, CR00249624

    incidentDetail.addWidgetItem(participantLinkBuilder, CuramConst.gkStyle,
      CuramConst.gkStyleLink, CPMConstants.gkProviderIncidentParticipants);

    ListBuilder detailsList = ListBuilder.createHorizontalList(2);

    detailsList.addRow();
    // BEGIN, CR00224728, JMA
    LocalisableString status = new LocalisableString(
      PROVIDERINCIDENT.TEXT_INCIDENT_STATUS);

    detailsList.addEntry(1, 1, status);

    CodeTableItemEntry codeTable = DocBuilderHelperFactory.getCodeTableItemEntry(
      details.status, CPMConstants.gkIncidentStatusDomain);

    detailsList.addEntry(2, 1, codeTable);

    detailsList.addRow();

    LocalisableString statusLabel = null;

    if (INCIDENTSTATUS.OPEN.equals(details.status)) {
      statusLabel = new LocalisableString(BPOINCIDENTTAB.INF_OPENED_LABEL);
    } else if (INCIDENTSTATUS.CLOSED.equals(details.status)) {
      statusLabel = new LocalisableString(BPOINCIDENTTAB.INF_CLOSED_LABEL);
    } else if (INCIDENTSTATUS.CANCELLED.equals(details.status)) {
      statusLabel = new LocalisableString(BPOINCIDENTTAB.INF_CANCELLED_LABEL);
    }

    detailsList.addEntry(1, 2, statusLabel);

    ContentPanelBuilder linkDetail = ContentPanelBuilder.createPanel(
      CPMConstants.gkLinkDetail);

    linkDetail.addlocalisableStringItem(
      new LocalisableString(BPOINCIDENTTAB.INF_STATUS_CHANGE).arg(new Date(details.incidentStatusDateTime)).toClientFormattedText(),
      CPMConstants.gkProviderIncStatusDate);

    UsersKey usersKey = new UsersKey();

    usersKey.userName = details.incidentStatusUserName;

    LinkBuilder userLinkBuilder = LinkBuilder.createLink(
      tabDetailFormatterObj.formatUserFullName(usersKey).fullName,
      CuramConst.gkUserDetailsPage);

    userLinkBuilder.openAsModal();
    userLinkBuilder.addParameter(CuramConst.gkPageParameterUserName,
      String.valueOf(details.incidentStatusUserName));

    linkDetail.addWidgetItem(userLinkBuilder, CuramConst.gkStyle,
      CuramConst.gkLink, CPMConstants.gkProviderIncStatusBy);

    RendererConfig contentPanelRendererConfig = new RendererConfig(
      RendererConfig.RendererConfigType.STYLE, CuramConst.gkContentPanel);

    detailsList.addEntry(2, 2, linkDetail, contentPanelRendererConfig);

    // variable to store row number as location may or may not be displayed
    // in the third row
    int rowCount = 3;

    if (providerRole.length() != 0) {
      detailsList.addRow();

      LocalisableString roleLabel = new LocalisableString(
        PROVIDERINCIDENT.TEXT_INCIDENT_PROVIDER_ROLE);

      detailsList.addEntry(1, rowCount, roleLabel);
      detailsList.addEntry(2, rowCount, providerRole);
      rowCount++;
    } else if (providerGroupRole.length() != 0) {
      detailsList.addRow();

      LocalisableString roleLabel = new LocalisableString(
        PROVIDERINCIDENT.TEXT_INCIDENT_PROVIDER_GROUP_ROLE);

      detailsList.addEntry(1, rowCount, roleLabel);
      detailsList.addEntry(2, rowCount, providerGroupRole);
      rowCount++;
    }

    if (location != null) {
      detailsList.addRow();

      LocalisableString locationLabel = new LocalisableString(
        PROVIDERINCIDENT.TEXT_INCIDENT_PROVIDER_LOCATION);

      detailsList.addEntry(1, rowCount, locationLabel);
      detailsList.addEntry(2, rowCount, location);

    }

    incidentDetail.addSingleListItem(detailsList,
      CPMConstants.gkProviderIncidentDetailsTable);
    // END, CR00224728
    contentPanelBuilder.addWidgetItem(incidentDetail, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    if (!INCIDENTSTATUS.OPEN.equals(details.status)) {

      String incidentStatus = null;

      if (INCIDENTSTATUS.CLOSED.equals(details.status)) {
        incidentStatus = new LocalisableString(BPOINCIDENTTAB.INF_CLOSED).arg(new Date(details.incidentStatusDateTime)).toClientFormattedText();
      } else if (INCIDENTSTATUS.CANCELLED.equals(details.status)) {
        incidentStatus = new LocalisableString(BPOINCIDENTTAB.INF_CANCELLED).arg(new Date(details.incidentStatusDateTime)).toClientFormattedText();
      }

      contentPanelBuilder.addlocalisableStringItem(incidentStatus,
        CuramConst.gkStyleWatermark);

    }

    return contentPanelBuilder;
  }

  /**
   * Formats XML data for an Incident tab reporter details.
   *
   * @param details
   * Incident details.
   *
   * @return ContentPanelBuilder.
   */
  protected ContentPanelBuilder getIncidentReporterDetails(
    final IncidentTabDtls details) throws AppException,
      InformationalException {

    TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();

    ContentPanelBuilder contentPanelBuilder = ContentPanelBuilder.createPanel(
      CPMConstants.gkProviderIncReportedDetails);

    if (details.anonymousReportInd) {
      contentPanelBuilder.addlocalisableStringItem(
        new LocalisableString(BPOINCIDENTTAB.INF_REPORTED_ANONYMOUSLY).arg(details.recordedDate).toClientFormattedText(),
        CPMConstants.gkProviderIncReportedBy);
    } else {

      contentPanelBuilder.addlocalisableStringItem(
        new LocalisableString(BPOINCIDENTTAB.INF_REPORTED_BY_LABEL).toClientFormattedText(),
        CPMConstants.gkProviderIncReportedBy);

      LinkBuilder reporterLinkBuilder = null;

      if (details.reporterUserName.length() > 0) {

        UsersKey usersKey = new UsersKey();

        usersKey.userName = details.reporterUserName;

        reporterLinkBuilder = LinkBuilder.createLink(
          tabDetailFormatterObj.formatUserFullName(usersKey).fullName,
          CuramConst.gkUserDetailsPage);
        reporterLinkBuilder.openAsModal();
        reporterLinkBuilder.addParameter(CuramConst.gkPageParameterUserName,
          String.valueOf(details.reporterUserName));

      } else {

        reporterLinkBuilder = LinkBuilder.createLink(
          details.reporterConcernRoleName, CuramConst.gkParticipantHomePage);
        reporterLinkBuilder.addParameter(
          CuramConst.gkPageParameterConcernRoleID,
          String.valueOf(details.reporterConcernRoleID));
      }

      // BEGIN, CR00262179, GP
      reporterLinkBuilder.addLinkTitle(
        new LocalisableString(
          PROVIDERINCIDENT.TEXT_PROVIDERINCIDENT_REPORTER_TITLE));
      // END, CR00262179

      contentPanelBuilder.addWidgetItem(reporterLinkBuilder, CuramConst.gkStyle,
        CuramConst.gkStyleLink, CPMConstants.gkProviderIncReportedByPerson);

      contentPanelBuilder.addlocalisableStringItem(
        new LocalisableString(BPOINCIDENTTAB.INF_REPORTED_ON_LABEL).arg(details.recordedDate).toClientFormattedText(),
        CPMConstants.gkProviderIncReportedByDate);
    }

    if (details.reporterAddressData.length() > 0) {

      AddressTabDetails addressTabDetails = new AddressTabDetails();

      addressTabDetails.addressData = details.reporterAddressData;

      contentPanelBuilder.addStringItem(
        tabDetailFormatterObj.formatAddress(addressTabDetails).addressString,
        CPMConstants.gkProviderIncReportedByAddress);
    } else {
      contentPanelBuilder.addlocalisableStringItem(
        new LocalisableString(BPOPARTICIPANT.INF_ADDRESS_NOT_RECORDED).toClientFormattedText(),
        CPMConstants.gkProviderIncReportedByAddress);
    }

    ListBuilder reportedBy = ListBuilder.createHorizontalList(2);

    reportedBy.addRow();

    LocalisableString reportMethodLabel = new LocalisableString(
      BPOINCIDENTTAB.INF_REPORT_METHOD_LABEL);

    reportedBy.addEntry(1, 1, reportMethodLabel);
    CodeTableItemEntry codeTable = DocBuilderHelperFactory.getCodeTableItemEntry(
      details.reportMethod, CuramConst.gkDomainIncidentReportMethod);

    reportedBy.addEntry(2, 1, codeTable);

    contentPanelBuilder.addSingleListItem(reportedBy,
      CPMConstants.gkProviderIncReportedByTable);

    ImageBuilder phoneImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconPhone, CuramConst.gkEmpty);

    phoneImageBuilder.setImageResource(CuramConst.gkRendererImages);

    // BEGIN, CR00262179, GP
    phoneImageBuilder.setImageAltText(
      new LocalisableString(PROVIDERINCIDENT.TEXT_PROVIDERINCIDENT_PHONE_NUMBER).toClientFormattedText());
    // END, CR00262179

    contentPanelBuilder.addImageItem(phoneImageBuilder,
      CPMConstants.gkProviderIncReportedByPhone);

    String phoneNumber = null;

    if (details.reporterPhoneNumberID == 0) {
      phoneNumber = new LocalisableString(BPOPARTICIPANT.INF_NOT_RECORDED).toClientFormattedText();

      contentPanelBuilder.addlocalisableStringItem(phoneNumber,
        CuramConst.gkReportedPhone);

    } else {
      PhoneNumberKey phoneNumberKey = new PhoneNumberKey();

      phoneNumberKey.phoneNumberID = details.reporterPhoneNumberID;

      phoneNumber = tabDetailFormatterObj.formatPhoneNumber(phoneNumberKey).phoneNumberString;

      contentPanelBuilder.addStringItem(phoneNumber, CuramConst.gkReportedPhone);
    }

    ImageBuilder emailImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconEmail, CuramConst.gkEmpty);

    emailImageBuilder.setImageResource(CuramConst.gkRendererImages);

    // BEGIN, CR00262179, GP
    emailImageBuilder.setImageAltText(
      new LocalisableString(PROVIDERINCIDENT.TEXT_PROVIDERINCIDENT_EMAIL_ADDRESS).toClientFormattedText());
    // END, CR00262179

    contentPanelBuilder.addImageItem(emailImageBuilder,
      CPMConstants.gkProviderIncReportedByEmail);

    String emailAddress = null;

    if (details.reporterEmailAddress.length() == 0) {
      emailAddress = new LocalisableString(BPOPARTICIPANT.INF_NOT_RECORDED).toClientFormattedText();

      contentPanelBuilder.addlocalisableStringItem(emailAddress,
        CuramConst.gkReportedEmail);
    } else {
      LinkBuilder emailLinkBuilder = LinkBuilder.createLink(
        details.reporterEmailAddress, details.reporterEmailAddress);

      // BEGIN, CR00262179, GP
      emailLinkBuilder.addLinkTitle(
        new LocalisableString(
          PROVIDERINCIDENT.TEXT_PROVIDERINCIDENT_EMAIL_TITLE));
      // END, CR00262179

      contentPanelBuilder.addWidgetItem(emailLinkBuilder, CuramConst.gkStyle,
        CuramConst.gkLink, CuramConst.gkReportedEmail);
    }

    return contentPanelBuilder;
  }

  /**
   * Formats XML data for a Contacts details.
   *
   * @param details
   * Contact tab details.
   *
   * @return ListBuilder with contacts details list XML data.
   */
  protected ContentPanelBuilder getContactDetails(
    final ContactLogTabDetails details) throws AppException,
      InformationalException {

    ContentPanelBuilder contactContent = ContentPanelBuilder.createPanel(
      CPMConstants.gkContactContent);

    ContentPanelBuilder contactContentDetail = ContentPanelBuilder.createPanel(
      CPMConstants.gkContactContentDetail);

    ImageBuilder initialContactImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconScheduleBlue, CuramConst.gkEmpty);

    initialContactImageBuilder.setImageResource(CuramConst.gkRendererImages);
    contactContentDetail.addImageItem(initialContactImageBuilder);

    ListBuilder initalContact = ListBuilder.createHorizontalList(2);

    initalContact.addRow();

    LocalisableString initialContactLabel = new LocalisableString(
      BPOINVESTIGATIONTAB.INF_INITIAL_CONTACT_LABEL);

    initalContact.addEntry(1, 1, initialContactLabel);
    LocalisableString initialContact = null;

    if (!details.initialContactStartDate.isZero()) {
      initialContact = new LocalisableString(BPOINVESTIGATIONTAB.INF_CONTACT_DATE_TYPE).arg(details.initialContactStartDate).arg(
        new CodeTableItemIdentifier(CONTACTLOGTYPE.TABLENAME,
        details.initialContactType));
    } else {
      initialContact = new LocalisableString(BPOPARTICIPANT.INF_NOT_RECORDED);
    }

    initalContact.addEntry(2, 1, initialContact);

    contactContentDetail.addSingleListItem(initalContact,
      CPMConstants.gkInitialContactTable);

    if (details.initialContactLogID != details.latestContactLogID) {

      ImageBuilder latestContactImageBuilder = ImageBuilder.createImage(
        CuramConst.gkIconScheduleBlue, CuramConst.gkEmpty);

      latestContactImageBuilder.setImageResource(CuramConst.gkRendererImages);
      contactContentDetail.addImageItem(latestContactImageBuilder);

      ListBuilder latestContact = ListBuilder.createList(2);

      latestContact.addRow();

      latestContact.addEntry(1, 1,
        new LocalisableString(BPOINVESTIGATIONTAB.INF_LATEST_CONTACT_LABEL));

      latestContact.addEntry(2, 1,
        new LocalisableString(BPOINVESTIGATIONTAB.INF_CONTACT_DATE_TYPE).arg(details.latestContactStartDate).arg(
        new CodeTableItemIdentifier(CONTACTLOGTYPE.TABLENAME,
        details.latestContactType)));

      contactContentDetail.addSingleListItem(latestContact,
        CPMConstants.gkLatestContactTable);
    }

    contactContent.addWidgetItem(contactContentDetail, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    return contactContent;

  }

  // END, CR00199708

  // BEGIN, CR00229103, NRK
  /**
   * Stores the contact details of the contact log wizard in the Wizard
   * persistence cache.
   *
   * @param incidentContactLogWizardDetails
   * Wizard details(contact details) to be cached in
   * WizardPersistentState.
   *
   * @return Resource ID in wizard persistence cache.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public WizardStateID createContact(final ContactLogWizardDetails contactLogDetails)
    throws AppException, InformationalException {
    // BEGIN, CR00321084, GA
    final ContactLog contactLogObj = ContactLogFactory.newInstance();
    // END, CR00321084
    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = contactLogDetails.wizardStateID;

    ContactLogWizardDetails wizardDetails = readWizardDetails(wizardStateID);

    contactLogDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.author = TransactionInfo.getProgramUser();
    contactLogDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.caseID = contactLogDetails.incidentContactLogWizardDetails.linkID;
    wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.assign(
      contactLogDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails);
    wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.wizardStateID = contactLogDetails.wizardStateID;
    if (CuramConst.kStoreAction.equals(contactLogDetails.actionString)) {
      // BEGIN, CR00321084, GA
      wizardStateID = storeContactDetails(wizardDetails);
      // END, CR00321084
    }
    return wizardStateID;
  }

  // BEGIN, CR00321084, GA
  /**
   * Stores the contact details of the contact log wizard in the Wizard
   * persistence cache.
   *
   * @param wizardDetails
   * The contact details to be cached in wizard persistent state.
   *
   * @return wizard ID in wizard persistence cache.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected WizardStateID storeContactDetails(
    final ContactLogWizardDetails wizardDetails) throws AppException,
      InformationalException {

    final ContactLog contactLogObj = ContactLogFactory.newInstance();

    contactLogObj.validateContactLogDetails(
      wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails);

    final WizardPersistentState wizardPersistentStateObj = new WizardPersistentState();
    final WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = wizardDetails.wizardStateID;
    if (0 == wizardStateID.wizardStateID) {
      wizardStateID.wizardStateID = wizardPersistentStateObj.create(
        wizardDetails);
    } else {
      wizardPersistentStateObj.modify(wizardStateID.wizardStateID,
        wizardDetails);
    }
    return wizardStateID;
  }

  // END, CR00321084

  /**
   * Retrieves Wizard details from the WizardPersistentState.
   *
   * @param wizardStateID
   * Wizard state ID.
   *
   * @return wizard details cached in the wizard persistent state.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ContactLogWizardDetails readWizardDetails(WizardStateID wizardStateID)
    throws AppException, InformationalException {
    ContactLogWizardDetails wizardDetails = new ContactLogWizardDetails();
    ContactLog contactLogObj = ContactLogFactory.newInstance();

    if (wizardStateID.wizardStateID != 0) {
      // BEGIN, CR00321084, GA
      WizardPersistentState wizardPersistentStateObj = new WizardPersistentState();

      wizardDetails = (ContactLogWizardDetails) wizardPersistentStateObj.read(
        wizardStateID.wizardStateID);
      // END, CR00321084
      wizardDetails.wizardDetails.details.concernRoleType = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.concernRoleType;
      wizardDetails.wizardDetails.details.newConcernRoleName = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.concernRoleName;

    }
    return wizardDetails;
  }

  /**
   * Stores Narrative text of the contact log wizard in the wizard persistence
   * cache.
   *
   * @param narrativeDetails
   * Wizard details updated with narrative details and cached in
   * WizardPersistentState.
   *
   * @return Resource ID in wizard persistence cache.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public WizardStateID storeNarrativeText(
    ContactLogWizardDetails narrativeDetails) throws AppException,
      InformationalException {

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = narrativeDetails.wizardStateID;
    ContactLogWizardDetails wizardDetails = readWizardDetails(wizardStateID);

    wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.narrativeDetails.assign(
      narrativeDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.narrativeDetails);
    wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.narrativeDetails.wizardStateID = narrativeDetails.wizardStateID;
    // BEGIN, CR00321084, GA
    if ((CuramConst.kNextAction.equals(narrativeDetails.actionString))
      || (CuramConst.kBackAction.equals(narrativeDetails.actionString))) {

      wizardStateID = storeContactLogNarrativeText(wizardDetails);
    } else if (CuramConst.kSaveAction.equals(narrativeDetails.actionString)) {
      storeContactLogNarrativeText(wizardDetails);
      insertContactLogWizardDetails(wizardStateID);
    }
    // END, CR00321084
    return wizardStateID;
  }

  // BEGIN, CR00321084, GA
  /**
   * Stores narrative text of the contact log wizard in the wizard persistence
   * cache.
   *
   *
   * @param wizardDetails
   * Wizard details updated with narrative details and cached in
   * WizardPersistentState.
   *
   * @return The wizard ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected WizardStateID storeContactLogNarrativeText(final ContactLogWizardDetails wizardDetails)
    throws AppException, InformationalException {

    final curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory.newInstance();
    final CreateContactLogDetails narrativeDetails = new CreateContactLogDetails();

    // Replace the pre-populated rich text editor value with empty string.
    narrativeDetails.noteDetails.notesText = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.narrativeDetails.notesText.replace(
      CPMConstants.kLineBreak, CuramConst.gkEmpty);
    contactLogObj.validateDetails(narrativeDetails);

    final WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.narrativeDetails.wizardStateID;
    WizardPersistentState wizardPersistentStateObj = new WizardPersistentState();

    wizardPersistentStateObj.modify(wizardStateID.wizardStateID, wizardDetails);
    return wizardStateID;
  }

  // END, CR00321084

  /**
   * Stores Participant details of the contact log wizard in the wizard
   * persistence cache.
   *
   * @param participantDetails
   * Wizard details updated with Participant details and cached in
   * WizardPersistentState.
   *
   * @return Resource ID in wizard persistence cache.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public WizardStateID storeParticipantsDetails(
    ContactLogWizardDetails participantDetails) throws AppException,
      InformationalException {
    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = participantDetails.wizardStateID;
    curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory.newInstance();
    ContactLogWizardDetails wizardDetails = readWizardDetails(wizardStateID);

    wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.assign(
      participantDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails);

    wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.wizardStateID = participantDetails.wizardStateID;
    // BEGIN, CR00321084, GA
    wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.concernRoleName = participantDetails.wizardDetails.details.newConcernRoleName;
    wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.caseParticipantRoleIDTabList = participantDetails.incidentContactLogWizardDetails.incidentParticipantRoleIDTabList;
    wizardDetails.wizardDetails.providerMemberConcernRoleID = participantDetails.wizardDetails.providerMemberConcernRoleID;

    if ((CuramConst.kNextAction.equals(participantDetails.actionString))
      || (CuramConst.kBackAction.equals(participantDetails.actionString))) {
      wizardStateID = storeContactLogParticipantsDetails(wizardDetails);

    } else if (CuramConst.kSaveAction.equals(participantDetails.actionString)) {
      storeContactLogParticipantsDetails(wizardDetails);
      insertContactLogWizardDetails(wizardStateID);
    }
    // END, CR00321084
    return wizardStateID;
  }

  // BEGIN, CR00321084, GA
  /**
   * Stores Participant details of the contact log wizard in the wizard
   * persistence cache.
   *
   * @param wizardDetails
   * Wizard details updated with participant details.
   *
   * @return The wizard state ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected WizardStateID storeContactLogParticipantsDetails(final ContactLogWizardDetails wizardDetails)
    throws AppException, InformationalException {
    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.wizardStateID;
    WizardPersistentState wizardPersistentStateObj = new WizardPersistentState();

    wizardPersistentStateObj.modify(wizardStateID.wizardStateID, wizardDetails);
    return wizardStateID;
  }

  // END, CR00321084

  /**
   * Stores Attachment details of the contact log wizard in the wizard
   * persistence cache.
   *
   * @param attachementDetails
   * Wizard details updated with Attachment details and cached in
   * WizardPersistentState.
   *
   * @return Resource ID in wizard persistence cache.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public WizardStateID storeAttachmentDetails(
    ContactLogWizardDetails attachementDetails) throws AppException,
      InformationalException {
    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = attachementDetails.wizardStateID;
    curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory.newInstance();
    ContactLogWizardDetails wizardDetails = readWizardDetails(wizardStateID);

    wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.assign(
      attachementDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails);
    wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.wizardStateID = attachementDetails.wizardStateID;
    // BEGIN, CR00321084, GA
    if (CuramConst.kBackAction.equals(attachementDetails.actionString)) {
      wizardStateID = storeContactLogAttachments(wizardDetails);
    } else if (CuramConst.kSaveAction.equals(attachementDetails.actionString)) {
      wizardStateID = storeContactLogAttachments(wizardDetails);
      insertContactLogWizardDetails(wizardStateID);
    }
    // END, CR00321084
    return wizardStateID;
  }

  // BEGIN, CR00321084, GA
  /**
   * Stores Attachment details of the contact log wizard in the wizard
   * persistence cache.
   *
   * @param attachementDetails
   * Wizard details updated with Attachment details and cached in
   * WizardPersistentState.
   *
   * @return The wizard ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected WizardStateID storeContactLogAttachments(final ContactLogWizardDetails wizardDetails)
    throws AppException, InformationalException {

    curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory.newInstance();

    if ((0
      != wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.fileContents.length())
        || (!CuramConst.gkEmpty.equals(
          wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.fileReference))

          || (!CuramConst.gkEmpty.equals(
            wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.fileLocation))) {
      contactLogObj.validateAttachmentDetails(
        wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails);
    }
    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.wizardStateID;
    WizardPersistentState wizardPersistentStateObj = new WizardPersistentState();

    wizardPersistentStateObj.modify(wizardStateID.wizardStateID, wizardDetails);
    return wizardStateID;
  }

  // END, CR00321084

  /**
   * Reads the wizard menu properties
   *
   * @param wizardStateID
   * WizardState ID.
   *
   * @return The wizard properties containing the wizard menu details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ContactLogWizardMenuDetails readWizardMenu(WizardStateID wizardStateID)
    throws AppException, InformationalException {
    ContactLogWizardMenuDetails contactLogWizardMenuDetails = new ContactLogWizardMenuDetails();

    if (wizardStateID.wizardStateID == 0) {
      contactLogWizardMenuDetails.wizardMenu = CPMConstants.kCreateIncidentContactLogWizard;
    } else {
      contactLogWizardMenuDetails.wizardMenu = CPMConstants.kModifyIncidentContactLogWizard;
    }
    return contactLogWizardMenuDetails;
  }

  /**
   * Saves the contact log details - contact details, participant details,
   * narrative text and attachment details in the respective entities.
   *
   * @param wizardStateID
   * WizardState ID to retrieve the information cached in
   * WizardPersistentState.
   *
   * @return The Contact log reference id.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void insertContactLogWizardDetails(WizardStateID wizardStateID)
    throws AppException, InformationalException {
    ContactLogWizardDetails wizardDetails = readWizardDetails(wizardStateID);
    CreateProviderIncidentContactLogDetails incidentContactLogDetails = new CreateProviderIncidentContactLogDetails();

    // Add Contact details
    incidentContactLogDetails.details.contactLogDtls.contactLogDetails.purpose = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.purpose;
    incidentContactLogDetails.details.contactLogDtls.contactLogDetails.location = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.location;
    incidentContactLogDetails.details.contactLogDtls.contactLogDetails.startDateTime = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.startDateTime;
    incidentContactLogDetails.details.contactLogDtls.contactLogDetails.endDateTime = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.endDateTime;
    incidentContactLogDetails.details.contactLogDtls.contactLogDetails.locationDescription = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.locationDescription;
    incidentContactLogDetails.details.contactLogDtls.contactLogDetails.contactLogType = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.contactLogType;
    incidentContactLogDetails.details.contactLogDtls.contactLogDetails.method = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.contactLogMethod;
    incidentContactLogDetails.details.contactLogDtls.linkID = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.contactDetails.caseID;
    // Add Narrative details
    incidentContactLogDetails.details.contactLogDtls.noteDetails.notesText = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.narrativeDetails.notesText;
    incidentContactLogDetails.details.contactLogDtls.attendeeDetails.concernRoleName = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.concernRoleName;
    // BEGIN, CR00321084, GA
    incidentContactLogDetails.providerMemberConcernRoleID = wizardDetails.wizardDetails.providerMemberConcernRoleID;

    // Save the contact details
    curam.cpm.facade.struct.ContactLogKey contactLogKey = createIncidentContactLog(
      incidentContactLogDetails);

    // Add incident participants.
    CreateProviderIncidentContactLogContactDetails details = new CreateProviderIncidentContactLogContactDetails();

    details.details.contactDtls.contactLogID = contactLogKey.contactLogID;
    details.details.concernRoleType = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.concernRoleType;
    details.details.contactDtls.concernRoleID = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.concernRoleID;
    details.currentUserIsAttendeeIndOpt = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.currentUserIsAttendeeInd;
    details.incidentParticipantRoleIDTabListOpt = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.caseParticipantRoleIDTabList;
    details.details.contactDtls.userName = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.userName;
    addContactLogAttendee(details);
    // END, CR00321084
    // Add Attachment details
    if ((wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.fileContents.length()
      != 0)
        || (!wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.fileReference.equals(
          CuramConst.gkEmpty))) {
      AttachmentLinkDetails attachmentLinkDetails = new AttachmentLinkDetails();

      attachmentLinkDetails.details.attachmentDtls.attachmentContents = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.fileContents;
      attachmentLinkDetails.details.attachmentDtls.attachmentName = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.fileName;
      attachmentLinkDetails.details.attachmentDtls.fileLocation = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.fileLocation;
      attachmentLinkDetails.details.attachmentDtls.fileReference = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.fileReference;
      attachmentLinkDetails.details.attachmentDtls.documentType = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.fileType;
      attachmentLinkDetails.details.attachmentLinkDtls.description = wizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.attachmentDetails.fileDescription;
      // BEGIN, CR00321084, GA
      attachmentLinkDetails.details.attachmentLinkDtls.relatedObjectID = contactLogKey.contactLogID;
      attachmentLinkDetails.details.attachmentLinkDtls.relatedObjectType = ATTACHMENTOBJECTLINKTYPEEntry.CONTACTLOG.getCode();
      // END, CR00321084
      createAttachment(attachmentLinkDetails);
    }
  }

  // END, CR00229103

  // BEGIN, CR00321084, GA
  /**
   * Collects the list of informations from the InformationalManager and adds
   * them to the msgDtlsList parameter passed in.
   *
   * @param msgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList msgDtlsList) {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    InformationalMsgDtls informationalMsgDtls;

    String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      msgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }

  // END, CR00321084
  
  // BEGIN, CR00377674, SS
  /**
   * Determines if the current user is a participant for the contact log or not. For the first time
   * it will be set as true and later on wards the value is set based on the user inputs.
   *
   * @param wizardStateID Contains the wizard state id.
   *
   * @return The value which indicates if the current user is participant.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public DefaultContactLogDetails getDefaultContactLogParticipant(curam.core.facade.struct.WizardStateID wizardStateID) throws AppException, InformationalException {

    final DefaultContactLogDetails defaultContactLogDetails = new DefaultContactLogDetails();
    final WizardPersistentState wizardPersistentStateobj = new WizardPersistentState();
    ContactLogWizardDetails contactLogWizardDetails = new ContactLogWizardDetails();

    contactLogWizardDetails = (ContactLogWizardDetails) wizardPersistentStateobj.read(
      wizardStateID.wizardStateID);

    if ((contactLogWizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.currentUserIsAttendeeInd
      == false
        && contactLogWizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.caseParticipantRoleIDTabList.isEmpty()
        && contactLogWizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.concernRoleName.isEmpty()
        && contactLogWizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.participantName.isEmpty()
        && contactLogWizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.userName.isEmpty())
          || (contactLogWizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.currentUserIsAttendeeInd
            == true)) {
      defaultContactLogDetails.currentUserIsAttendeeInd = true;
    } else if (!(contactLogWizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.caseParticipantRoleIDTabList.isEmpty()
      || contactLogWizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.concernRoleName.isEmpty()
      || contactLogWizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.participantName.isEmpty()
      || contactLogWizardDetails.incidentContactLogWizardDetails.incidentWizardDetails.wizardDetails.participantDetails.userName.isEmpty())) {
      defaultContactLogDetails.currentUserIsAttendeeInd = false;
    }

    return defaultContactLogDetails;
  }
  // END, CR00377674
}
