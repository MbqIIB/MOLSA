/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import com.google.inject.Inject;

import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.ContractVersionDAO;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.sl.entity.struct.ProviderOfferingPlaceLimitDtls;
import curam.cpm.sl.entity.struct.ProviderOfferingPlaceLimitKey;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingPlaceLimitDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.DateRange;


/**
 * Facade layer class having API for managing place limit for provider offering.
 *
 */

public abstract class ProviderOfferingPlaceLimit extends curam.cpm.facade.base.ProviderOfferingPlaceLimit {

  /**
   * Provider offering place limit DAO object.
   */
  @Inject
  protected ProviderOfferingPlaceLimitDAO providerOfferingPlaceLimitDAO;

  /**
   * Provider offering DAO object.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Contract version DAO object.
   */
  @Inject
  protected ContractVersionDAO contractVersionDAO;

  /**
   * Default Constructor.
   */
  public ProviderOfferingPlaceLimit() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Logically deletes a Provider Offering Place Limit given the provider
   * offering place limit ID.
   *
   * @param keyVersionDetails
   * Struct containing the ID and version of the entity to be logically
   * deleted.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancelProviderOfferingPlaceLimit(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {
    final curam.providerservice.impl.ProviderOfferingPlaceLimit providerOfferingPlaceLimit = providerOfferingPlaceLimitDAO.get(
      keyVersionDetails.id);

    providerOfferingPlaceLimit.cancel(keyVersionDetails.version);

  }

  /**
   * Create a Provider Offering Place Limit given the provider offering place
   * limit details.
   *
   * @param providerOfferingPlaceLimitDtls
   * Struct containing the details for the Provider Offering Place
   * Limit to be created.
   * @return ProviderOfferingPlaceLimitKey The key for the new
   * ProviderOfferingPlaceLimit created.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderOfferingPlaceLimitKey createProviderOfferingPlaceLimit(
    ProviderOfferingPlaceLimitDtls providerOfferingPlaceLimitDtls)
    throws AppException, InformationalException {
    curam.providerservice.impl.ProviderOfferingPlaceLimit providerOfferingPlaceLimit = providerOfferingPlaceLimitDAO.newInstance();

    // map details passed from client
    setProviderOfferingPlaceLimitFields(providerOfferingPlaceLimit,
      providerOfferingPlaceLimitDtls);

    providerOfferingPlaceLimit.insert();

    ProviderOfferingPlaceLimitKey providerOfferingPlaceLimitKey = new ProviderOfferingPlaceLimitKey();

    providerOfferingPlaceLimitKey.providerOfferingPlaceLimitID = providerOfferingPlaceLimit.getID();
    return providerOfferingPlaceLimitKey;
  }

  /**
   * Modifies a Provider Offering Place Limit given the provider offering place
   * limit details.
   *
   * @param providerOfferingPlaceLimitDtls
   * Struct containing the details for the Provider Offering Place
   * Limit to be modified.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyProviderOfferingPlaceLimit(
    ProviderOfferingPlaceLimitDtls providerOfferingPlaceLimitDtls)
    throws AppException, InformationalException {
    curam.providerservice.impl.ProviderOfferingPlaceLimit providerOfferingPlaceLimit = providerOfferingPlaceLimitDAO.get(
      providerOfferingPlaceLimitDtls.providerOfferingPlaceLimitID);

    setProviderOfferingPlaceLimitFields(providerOfferingPlaceLimit,
      providerOfferingPlaceLimitDtls);

    providerOfferingPlaceLimit.modify(providerOfferingPlaceLimitDtls.versionNo);

  }

  /**
   * Retrieves the Provider Offering Place Limit details given the provider
   * offering place limit ID.
   *
   * @param providerOfferingPlaceLimitKey
   * The key for the Provider Offering Place Limit.
   * @return ProviderOfferingPlaceLimitDtls The struct containing the Provider
   * Offering Place Limit Details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderOfferingPlaceLimitDtls viewProviderOfferingPlaceLimit(
    ProviderOfferingPlaceLimitKey providerOfferingPlaceLimitKey)
    throws AppException, InformationalException {
    final curam.providerservice.impl.ProviderOfferingPlaceLimit providerOfferingPlaceLimit = providerOfferingPlaceLimitDAO.get(
      providerOfferingPlaceLimitKey.providerOfferingPlaceLimitID);

    ProviderOfferingPlaceLimitDtls providerOfferingPlaceLimitDtls = getProviderOfferingPlaceLimitFields(
      providerOfferingPlaceLimit);

    return providerOfferingPlaceLimitDtls;
  }

  // ___________________________________________________________________________
  /**
   * Maps the fields updateable by the user to the fields on the service layer
   * object.
   *
   * @param providerOfferingPlaceLimit
   * The service layer object into which the user-updateable fields
   * must be mapped.
   * @param providerOfferingPlaceLimitDtls
   * Struct contain fields set by the user (as well as other fields
   * which will be ignored).
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setProviderOfferingPlaceLimitFields(
    // END, CR00177241
    final curam.providerservice.impl.ProviderOfferingPlaceLimit providerOfferingPlaceLimit,
    final ProviderOfferingPlaceLimitDtls providerOfferingPlaceLimitDtls)
    throws AppException, InformationalException {

    final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
      providerOfferingPlaceLimitDtls.providerOfferingID);

    providerOfferingPlaceLimit.setProviderOffering(providerOffering);
    providerOfferingPlaceLimit.setComments(
      providerOfferingPlaceLimitDtls.comments);

    final DateRange dateRange = new DateRange(
      providerOfferingPlaceLimitDtls.startDate,
      providerOfferingPlaceLimitDtls.endDate);

    providerOfferingPlaceLimit.setDateRange(dateRange);

    providerOfferingPlaceLimit.setPlaceLimit(
      providerOfferingPlaceLimitDtls.placeLimit);

  }

  /**
   * Maps the fields on the service layer to those presented to the user on the
   * screen.
   *
   * @param providerOfferingPlaceLimit
   * The service layer object from which the user-displayable fields
   * must be mapped.
   * @return ProviderOfferingPlaceLimitDtls The details struct containing the
   * fields for display.
   */
  // BEGIN, CR00177241, PM
  protected ProviderOfferingPlaceLimitDtls getProviderOfferingPlaceLimitFields(
    // END, CR00177241
    final curam.providerservice.impl.ProviderOfferingPlaceLimit providerOfferingPlaceLimit) {
    final ProviderOfferingPlaceLimitDtls providerOfferingPlaceLimitDtls = new ProviderOfferingPlaceLimitDtls();

    providerOfferingPlaceLimitDtls.providerOfferingPlaceLimitID = providerOfferingPlaceLimit.getID();
    providerOfferingPlaceLimitDtls.providerOfferingID = providerOfferingPlaceLimit.getProviderOffering().getID();
    providerOfferingPlaceLimitDtls.startDate = providerOfferingPlaceLimit.getDateRange().start();
    providerOfferingPlaceLimitDtls.endDate = providerOfferingPlaceLimit.getDateRange().end();
    providerOfferingPlaceLimitDtls.placeLimit = providerOfferingPlaceLimit.getPlaceLimit();
    providerOfferingPlaceLimitDtls.comments = providerOfferingPlaceLimit.getComments();
    providerOfferingPlaceLimitDtls.recordStatus = providerOfferingPlaceLimit.getLifecycleState().getCode();
    providerOfferingPlaceLimitDtls.versionNo = providerOfferingPlaceLimit.getVersionNo();

    return providerOfferingPlaceLimitDtls;
  }

  /**
   * Creates a Contract Provider Offering Place Limit given the provider
   * offering place limit details.
   *
   * @param providerOfferingPlaceLimitDtls
   * Struct containing the details for the Provider Offering Place
   * Limit to be created.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void createContractProviderOfferingPlaceLimit(
    ProviderOfferingPlaceLimitDtls providerOfferingPlaceLimitDtls)
    throws AppException, InformationalException {

    curam.providerservice.impl.ProviderOfferingPlaceLimit providerOfferingPlaceLimit = providerOfferingPlaceLimitDAO.newInstance();

    ContractVersion contractVersion = contractVersionDAO.get(
      providerOfferingPlaceLimitDtls.contractVersionID);

    // map details passed from client
    setProviderOfferingPlaceLimitFields(providerOfferingPlaceLimit,
      providerOfferingPlaceLimitDtls);

    providerOfferingPlaceLimit.setContract(contractVersion);

    providerOfferingPlaceLimit.insert();

  }

}
