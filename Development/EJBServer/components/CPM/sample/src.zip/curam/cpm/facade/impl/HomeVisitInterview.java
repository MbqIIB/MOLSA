/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.REPRESENTATIVETYPE;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.fact.AddressFactory;
import curam.core.impl.CuramConst;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.struct.OtherAddressData;
import curam.cpm.facade.fact.ContextDescriptionFactory;
import curam.cpm.facade.struct.ContextDescriptionDetails;
import curam.cpm.facade.struct.CreateProviderParticipantDetails;
import curam.cpm.facade.struct.HomeStudyHomeVisitKey;
import curam.cpm.facade.struct.HomeStudyKey;
import curam.cpm.facade.struct.HomeVisitInterviewCancelKey;
import curam.cpm.facade.struct.HomeVisitInterviewDetails;
import curam.cpm.facade.struct.HomeVisitInterviewDetailsList;
import curam.cpm.facade.struct.HomeVisitInterviewKey;
import curam.cpm.facade.struct.HomeVisitInterviewSearchByHomeStudyHomeVisitKey;
import curam.cpm.facade.struct.InitialDate;
import curam.cpm.facade.struct.InitialDateTime;
import curam.cpm.facade.struct.InterviewAttendeeDetails;
import curam.cpm.facade.struct.InterviewAttendeeDtlsList;
import curam.cpm.facade.struct.ProviderConcernRoleKey;
import curam.cpm.facade.struct.ProviderKey;
import curam.cpm.facade.struct.ProviderSummaryDetails;
import curam.cpm.facade.struct.ProviderSummaryDetailsList;
import curam.cpm.sl.entity.struct.ProviderPartyKey;
import curam.homestudy.impl.HomeStudyDAO;
import curam.homestudy.impl.HomeStudyHomeVisit;
import curam.homestudy.impl.HomeStudyHomeVisitDAO;
import curam.homestudy.impl.HomeVisitInterviewDAO;
import curam.homestudy.impl.HomeVisitInterviewTypeEntry;
import curam.homestudy.impl.HomeVisitInterviewlocationEntry;
import curam.homestudy.impl.HomeVisitMethodEntry;
import curam.homestudy.impl.InterviewAttendeeDAO;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.HOMEVISITINTERVIEWExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderParticipantDAO;
import curam.provider.impl.ProviderParticipantTypeEntry;
import curam.provider.impl.ProviderParty;
import curam.provider.impl.ProviderPartyDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateTime;
import curam.util.type.StringHelper;


/**
 * This process class provides the functionality for Home Visit Interview facade
 * layer.
 */
// Start CR00096126, JSP
public abstract class HomeVisitInterview extends curam.cpm.facade.base.HomeVisitInterview {
  // End CR00096126

  /**
   * Guice no argument Constructor
   */
  public HomeVisitInterview() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }
  
  @Inject
  protected HomeStudyDAO homeStudyDAO;

  @Inject
  protected HomeStudyHomeVisitDAO homeStudyHomeVisitDAO;

  @Inject
  protected HomeVisitInterviewDAO homeVisitInterviewDAO;

  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  @Inject
  protected InterviewAttendeeDAO interviewAttendeeDAO;

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected ProviderParticipantDAO providerParticipantDAO;

  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Returns a list of home visit interviews for the home study home visit.
   *
   * @param key
   * the key specifying the home study home visit to list by
   * @return list of home visit interviews and the context description.
   * @throws AppException
   * @throws InformationalException
   */
  public HomeVisitInterviewDetailsList listByHomeStudyHomeVisit(
    HomeVisitInterviewSearchByHomeStudyHomeVisitKey key)
    throws AppException, InformationalException {
    // return struct
    HomeVisitInterviewDetailsList homeVisitInterviewList = new HomeVisitInterviewDetailsList();

    // Home Study Home Visit entity
    final HomeStudyHomeVisit homeStudyHomeVisitEnt = homeStudyHomeVisitDAO.get(
      key.key.homeStudyHomeVisitID);

    // Retrieve a Set of Home Visit Interview instances
    // by Home Study Home Visit
    final Set<curam.homestudy.impl.HomeVisitInterview> homeVisitInterviewSet = homeVisitInterviewDAO.searchByHomeStudyHomeVisit(
      homeStudyHomeVisitEnt);

    for (curam.homestudy.impl.HomeVisitInterview homeVisitInterview : homeVisitInterviewSet) {
      HomeVisitInterviewDetails homeVisitInterviewDetails = this.getHomeVisitInterviewDetails(
        homeVisitInterview);

      homeVisitInterviewList.dtls.dtls.addRef(
        homeVisitInterviewDetails.homeVisitInterviewDtls);
    }

    homeVisitInterviewList.contextDescription = this.getContextDescription(
      homeStudyHomeVisitEnt);

    return homeVisitInterviewList;
  }

  /**
   * Creates a new home visit interview.
   *
   * @param details
   * the home visit interview creation details
   * @return key the home visit interview that was created.
   * @throws AppException
   * @throws InformationalException
   */
  public HomeVisitInterviewKey createHomeVisitInterview(
    HomeVisitInterviewDetails details) throws AppException,
      InformationalException {
    HomeVisitInterviewKey key = new HomeVisitInterviewKey();
	  
    // home study document entity
    final curam.homestudy.impl.HomeVisitInterview homeVisitInterviewEnt = homeVisitInterviewDAO.newInstance();

    // set the details
    homeVisitInterviewEnt.setStartDateTime(
      details.homeVisitInterviewDtls.startDateTime);
    homeVisitInterviewEnt.setEndDateTime(
      details.homeVisitInterviewDtls.endDateTime);
    homeVisitInterviewEnt.setLocation(
      HomeVisitInterviewlocationEntry.get(
        details.homeVisitInterviewDtls.location));
    homeVisitInterviewEnt.setMethod(
      HomeVisitMethodEntry.get(details.homeVisitInterviewDtls.method));
    homeVisitInterviewEnt.setNarrative(details.homeVisitInterviewDtls.narrative);
    homeVisitInterviewEnt.setType(
      HomeVisitInterviewTypeEntry.get(details.homeVisitInterviewDtls.type));

    // Home Study Home Visit entity
    final HomeStudyHomeVisit homeStudyHomeVisitEnt = homeStudyHomeVisitDAO.get(
      details.homeVisitInterviewDtls.homeStudyHomeVisitID);

    // Set Home Study home visit
    homeVisitInterviewEnt.setHomeStudyHomeVisit(homeStudyHomeVisitEnt);

    // BEGIN, CR00206945, AS
    final Provider provider = homeStudyDAO.get((homeVisitInterviewEnt.getHomeStudyHomeVisit().getHomeStudy().getID())).getProvider();
    curam.provider.impl.ProviderOrganization providerOrganization;

    providerOrganization = providerDAO.get(provider.getID());
    Set<ProviderParty> providerParty = providerPartyDAO.searchBy(
      providerOrganization);

    if (0 == providerParty.size()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_XRV_INTERVIEW_MUST_HAVE_ATTENDEES_BEFORE_CREATION(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00206945

    // insert the record
    homeVisitInterviewEnt.insert();

    // Populate the return value
    key.key.homeVisitInterviewID = homeVisitInterviewEnt.getID();

    // Use the returned ID and the list passed in from the facade to
    // create the Interview Attendee List
    addAttendeesToInterview(details.attendeeList, key.key.homeVisitInterviewID);

    return key;
  }

  /**
   * Reads a home visit interview.
   *
   * @param key
   * the key identifying the home visit interview to be read
   * @return the home visit interview.
   * @throws AppException
   * @throws InformationalException
   */
  public HomeVisitInterviewDetails viewHomeVisitInterview(
    HomeVisitInterviewKey key) throws AppException,
      InformationalException {

    curam.homestudy.impl.HomeVisitInterview homeVisitInterview = homeVisitInterviewDAO.get(
      key.key.homeVisitInterviewID);

    HomeVisitInterviewDetails homeVisitInterviewDetails = this.getHomeVisitInterviewDetails(
      homeVisitInterview);

    homeVisitInterviewDetails.attendeeList = getInterviewAttendeesAsTabbedList(
      homeVisitInterview);

    homeVisitInterviewDetails.contextDescription = this.getContextDescription(
      homeVisitInterview.getHomeStudyHomeVisit());

    return homeVisitInterviewDetails;
  }

  /**
   * Modifies an existing home visit interview.
   *
   * @param details
   * the modified home visit interview details
   * @throws AppException
   * @throws InformationalException
   */
  public void modifyHomeVisitInterview(HomeVisitInterviewDetails details)
    throws AppException, InformationalException {
    curam.homestudy.impl.HomeVisitInterview homeVisitInterview = homeVisitInterviewDAO.get(
      details.homeVisitInterviewDtls.homeVisitInterviewID);

    homeVisitInterview.setStartDateTime(
      details.homeVisitInterviewDtls.startDateTime);
    homeVisitInterview.setEndDateTime(
      details.homeVisitInterviewDtls.endDateTime);
    homeVisitInterview.setLocation(
      HomeVisitInterviewlocationEntry.get(
        details.homeVisitInterviewDtls.location));
    homeVisitInterview.setMethod(
      HomeVisitMethodEntry.get(details.homeVisitInterviewDtls.method));
    homeVisitInterview.setNarrative(details.homeVisitInterviewDtls.narrative);
    homeVisitInterview.setHomeStudyHomeVisit(
      homeStudyHomeVisitDAO.get(
        details.homeVisitInterviewDtls.homeStudyHomeVisitID));

    // Modify the record using the version number from the facade.
    homeVisitInterview.modify(details.homeVisitInterviewDtls.versionNo);

    // Remove all of the 'old' attendees
    removeAttendeesFromInterview(homeVisitInterview);

    // Add the attendees currently in the list
    addAttendeesToInterview(details.attendeeList,
      details.homeVisitInterviewDtls.homeVisitInterviewID);

  }

  /**
   * Logically deletes a home visit interview.
   *
   * @param key
   * the key identifying the home visit interview to delete
   * @throws AppException
   * @throws InformationalException
   */
  public void deleteHomeVisitInterview(HomeVisitInterviewCancelKey key)
    throws AppException, InformationalException {

    curam.homestudy.impl.HomeVisitInterview homeVisitInterview = homeVisitInterviewDAO.get(
      key.key.homeVisitInterviewID);

    // Remove the interview attendee children
    removeAttendeesFromInterview(
      homeVisitInterviewDAO.get(key.key.homeVisitInterviewID));

    // Call cancel and pass in the version number from the facade
    homeVisitInterview.cancel(key.versionNo);

  }

  /**
   * Returns the default date time that is on the same date as the parent home
   * study home visit.
   *
   * @param key
   * the key identifying the home study home visit
   * @return the initial date time from the home study home visit.
   */
  public InitialDateTime getInitialDateTime(HomeStudyHomeVisitKey key) {
    HomeStudyHomeVisit homeStudyHomeVisit = homeStudyHomeVisitDAO.get(
      key.homeStudyHomeVisitKey.homeStudyHomeVisitID);

    InitialDateTime initialDateTime = new InitialDateTime();

    initialDateTime.initialDateTime = new DateTime(
      homeStudyHomeVisit.getDateOfVisit().getCalendar());

    return initialDateTime;
  }

  /**
   * Returns the default date that is on the same date as the parent home
   * study home visit.
   *
   * @param key
   * the key identifying the home study home visit
   * @return the initial date time from the home study home visit.
   */
  public InitialDate getInitialDateForAttendee(HomeStudyHomeVisitKey key) {
    HomeStudyHomeVisit homeStudyHomeVisit = homeStudyHomeVisitDAO.get(
      key.homeStudyHomeVisitKey.homeStudyHomeVisitID);

    InitialDate initialDate = new InitialDate();

    initialDate.initialDate = new Date(
      homeStudyHomeVisit.getDateOfVisit().getCalendar());

    return initialDate;
  }

  /**
   * Returns a list of interview attendees for a given home visit interview.
   *
   * @param key
   * the key identifying the home visit interview
   * @return list of interview attendees for the home visit interview.
   * @throws AppException
   * @throws InformationalException
   */
  public InterviewAttendeeDtlsList listAttendeesForInterview(
    HomeVisitInterviewKey key) throws AppException,
      InformationalException {

    InterviewAttendeeDtlsList interviewAttendeeDtlsList = new InterviewAttendeeDtlsList();

    curam.homestudy.impl.HomeVisitInterview homeVisitInterview = homeVisitInterviewDAO.get(
      key.key.homeVisitInterviewID);

    Set<curam.homestudy.impl.InterviewAttendee> interviewAttendees = interviewAttendeeDAO.searchByHomeVisitInterview(
      homeVisitInterview);

    InterviewAttendeeDetails interviewAttendeeDetails;

    for (curam.homestudy.impl.InterviewAttendee attendee : interviewAttendees) {
      interviewAttendeeDetails = new InterviewAttendeeDetails();

      interviewAttendeeDetails.interviewAttendeeDtls.homeVisitInterviewID = attendee.getHomeVisitInterview().getID();
      interviewAttendeeDetails.interviewAttendeeDtls.interviewAttendeeID = attendee.getID();
      interviewAttendeeDetails.interviewAttendeeDtls.providerPartyID = attendee.getProviderParty().getID();

      interviewAttendeeDetails.attendeeName = attendee.getProviderParty().getParty().getName();

      interviewAttendeeDtlsList.attendeeListDtls.addRef(
        interviewAttendeeDetails);
    }
    return interviewAttendeeDtlsList;
  }

  /**
   * Inserts a new provider participant for a provider.
   *
   * @param details
   * the details of the participant to be inserted
   * @return key identifying the provider party that was created.
   * @throws AppException
   * @throws InformationalException
   */
  public ProviderPartyKey registerProviderParticpantInterviewAttendee(
    CreateProviderParticipantDetails details) throws AppException,
      InformationalException {

    // validate provider participant details for insert
    validateInsert(details);

    final ProviderPartyKey providerParticipantKey = new ProviderPartyKey();

    // If person is already not registered with the agency,
    // then create a person record
    if (0 == details.searchConcernRoleID) {
      // Recording the representative details
      // Struct passed to Representative::registerRepresentative
      // Representative maintenance object
      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      if (StringHelper.isEmpty(details.name)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new curam.util.exception.AppException(
            curam.message.CPMCOMMONMESSAGES.ERR_CPMCOMMONMSG_FV_NAME_NOT_ENTERED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            6);
      }

      RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = details.name;

      representativeRegistrationDetails.representativeRegistrationDetails.addressData = details.addressData;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = details.phoneCountryCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = details.phoneAreaCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = details.phoneNumber;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension = details.phoneExtension;
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();

      representativeRegistrationDetails.representativeDtls.representativeType = REPRESENTATIVETYPE.CONTACT;

      // Call registerRepresentative
      representativeObj.registerRepresentative(
        representativeRegistrationDetails);
      details.participantID = representativeRegistrationDetails.representativeDtls.concernRoleID;
    } else {
      details.participantID = details.searchConcernRoleID;
    }

    // Service layer
    curam.provider.impl.ProviderParticipant providerParticipant = providerParticipantDAO.newInstance();

    providerParticipant.setProviderOrganization(
      providerDAO.get(details.providerID));
    providerParticipant.setDateRange(
      new DateRange(details.fromDate, details.toDate));
    // When a participant is added to be used as an interview attendee their
    // type should be set to interview attendee.
    providerParticipant.setParticipantType(
      ProviderParticipantTypeEntry.INTERVIEWEE);
    final ConcernRole concernRole = concernRoleDAO.get(details.participantID);

    providerParticipant.setParty(concernRole);

    providerParticipant.insert();

    providerParticipantKey.providerPartyID = providerParticipant.getID();

    return providerParticipantKey;
  }

  /**
   * Returns a list of all the active provider parties registered to the
   * current provider.
   *
   * @param key
   * the home study key used to retrieve the provider to list
   * provider parties by
   * @return the list of provider parties.
   * @throws AppException
   * @throws InformationalException
   */
  public ProviderSummaryDetailsList listProviderPartysForCurrentProvider(
    HomeStudyKey key) throws AppException, InformationalException {

    final curam.provider.impl.Provider provider = homeStudyDAO.get((key.key.homeStudyID)).getProvider();

    ProviderConcernRoleKey providerConcernRoleKey = new ProviderConcernRoleKey();

    providerConcernRoleKey.providerKey.providerConcernRoleID = provider.getID();

    ProviderSummaryDetailsList providerSummaryDetailsList = new ProviderSummaryDetailsList();

    // get the instance of the provider
    curam.provider.impl.ProviderOrganization providerOrganization;

    providerOrganization = providerDAO.get(
      providerConcernRoleKey.providerKey.providerConcernRoleID);

    ProviderSummaryDetails providerSummaryDetails;

    for (final curam.provider.impl.ProviderParty providerParty : providerPartyDAO.searchBy(
      providerOrganization)) {
      if (!providerParty.getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {

        providerSummaryDetails = new ProviderSummaryDetails();

        providerSummaryDetails.providerPartyID = providerParty.getID();
        providerSummaryDetails.providerPartyName = providerParty.getParty().getName();

        providerSummaryDetailsList.providerDtlsList.addRef(
          providerSummaryDetails);
      }
    }

    // Also return the identifier for the provider
    providerSummaryDetailsList.providerConcernRoleKey.providerKey.providerConcernRoleID = provider.getID();

    return providerSummaryDetailsList;
  }

  /**
   * Returns details struct for use by client.
   *
   * @param homeVisitInterview
   * the home visit interview to be returned
   * @return home visit interview details for use by the client
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected HomeVisitInterviewDetails getHomeVisitInterviewDetails(
    // END, CR00177241
    curam.homestudy.impl.HomeVisitInterview homeVisitInterview)
    throws AppException, InformationalException {
    // Set valid values for the service offering and service rate record
    HomeVisitInterviewDetails homeVisitInterviewDetails = new HomeVisitInterviewDetails();

    homeVisitInterviewDetails.homeVisitInterviewDtls.homeVisitInterviewID = homeVisitInterview.getID();
    homeVisitInterviewDetails.homeVisitInterviewDtls.homeStudyHomeVisitID = homeVisitInterview.getHomeStudyHomeVisit().getID();
    homeVisitInterviewDetails.homeVisitInterviewDtls.startDateTime = homeVisitInterview.getStartDateTime();
    homeVisitInterviewDetails.homeVisitInterviewDtls.endDateTime = homeVisitInterview.getEndDateTime();
    homeVisitInterviewDetails.homeVisitInterviewDtls.location = homeVisitInterview.getLocation().getCode();
    homeVisitInterviewDetails.homeVisitInterviewDtls.method = homeVisitInterview.getMethod().getCode();
    homeVisitInterviewDetails.homeVisitInterviewDtls.narrative = homeVisitInterview.getNarrative();
    homeVisitInterviewDetails.homeVisitInterviewDtls.type = homeVisitInterview.getType().getCode();
    homeVisitInterviewDetails.homeVisitInterviewDtls.recordStatus = homeVisitInterview.getRecordStatus().getCode();
    homeVisitInterviewDetails.homeVisitInterviewDtls.versionNo = homeVisitInterview.getVersionNo();

    return homeVisitInterviewDetails;
  }

  /**
   * Returns the context description for the home visit interview.
   *
   * @param homeStudyHomeVisit
   * the parent homeStudyHomeVisit of the interview
   * @return the context description
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00177241, PM
  protected ContextDescriptionDetails getContextDescription(
    // END, CR00177241
    HomeStudyHomeVisit homeStudyHomeVisit) throws AppException,
      InformationalException {
    // Add the context description
    // Start CR00096126, JSP
    curam.cpm.facade.intf.ContextDescription contextDescription = ContextDescriptionFactory.newInstance();
    // End CR00096126

    // get the provider from the home study through
    // the home study home visit parent
    ProviderKey providerKey = new ProviderKey();

    providerKey.providerID = homeStudyHomeVisit.getHomeStudy().getProvider().getID();

    // get the context description details and return them
    return contextDescription.getContextDescription(providerKey);
  }

  /**
   * Adds a list of interview attendees to a home visit interview.
   *
   * @param attendeesList
   * The tabbed list of IDs for each attendee to add.
   * @param homeVisitInterviewID
   * The ID for the interview that each attendee should be added
   * to.
   *
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void addAttendeesToInterview(final String attendeesList,
    // END, CR00177241
    long homeVisitInterviewID) throws AppException,
      InformationalException {

    // Get the provider for the home study
    curam.homestudy.impl.InterviewAttendee interviewAttendee = interviewAttendeeDAO.newInstance();

    // Add the attendees in the list to the current interview
    final String[] providerPartyIDs = StringUtil.tabText2StringListWithTrim(attendeesList).items();

    if (providerPartyIDs.length <= 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_XRV_INTERVIEW_MUST_HAVE_ATTENDEES(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }

    for (final String providerPartyConcernRoleID : providerPartyIDs) {

      interviewAttendee = interviewAttendeeDAO.newInstance();

      interviewAttendee.setProviderParty(
        providerPartyDAO.get(Long.parseLong(providerPartyConcernRoleID)));
      interviewAttendee.setHomeVisitInterview(
        homeVisitInterviewDAO.get(homeVisitInterviewID));

      interviewAttendee.insert();
    }

  }

  /**
   * Remove the current records that refer to this interview.
   *
   * @param interview
   * the interview to remove the attendees for
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void removeAttendeesFromInterview(
    // END, CR00177241
    curam.homestudy.impl.HomeVisitInterview interview)
    throws InformationalException {

    curam.homestudy.impl.HomeVisitInterview homeVisitInterview = homeVisitInterviewDAO.get(
      interview.getID());

    // Remove the old attendee list for this interview
    curam.homestudy.impl.InterviewAttendee interviewAttendee = interviewAttendeeDAO.newInstance();

    Set<curam.homestudy.impl.InterviewAttendee> interviewAttendees = interviewAttendeeDAO.searchByHomeVisitInterview(
      homeVisitInterview);

    for (final curam.homestudy.impl.InterviewAttendee attendee : interviewAttendees) {
      interviewAttendee.remove(attendee);
    }
  }

  /**
   * Reads the list of interview attendee's and returns them as a tabbed list.
   *
   * @param homeVisitInterview
   * the home visit interview
   * @return the list of interview attendee's as a tabbed list.
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00177241, PM
  protected String getInterviewAttendeesAsTabbedList(
    // END, CR00177241
    curam.homestudy.impl.HomeVisitInterview homeVisitInterview)
    throws AppException, InformationalException {

    HomeVisitInterviewKey homeVisitInterviewKey = new HomeVisitInterviewKey();

    homeVisitInterviewKey.key.homeVisitInterviewID = homeVisitInterview.getID();

    InterviewAttendeeDtlsList interviewAttendeeDtlsList = listAttendeesForInterview(
      homeVisitInterviewKey);

    StringBuffer interviewAttendeeTabbedString = new StringBuffer();

    for (int i = 0; i < interviewAttendeeDtlsList.attendeeListDtls.size(); i++) {
      interviewAttendeeTabbedString.append(
        Long.toString(
          interviewAttendeeDtlsList.attendeeListDtls.item(i).interviewAttendeeDtls.providerPartyID)
            + CuramConst.gkTabDelimiter);
    }

    return interviewAttendeeTabbedString.toString();
  }

  /**
   * Validates the insert of a provider participant.
   *
   * @param createProviderParticipantDetails
   * provider participant details to be inserted
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void validateInsert(
    // END, CR00177241
    CreateProviderParticipantDetails createProviderParticipantDetails)
    throws AppException, InformationalException {

    StringBuffer representativeDetails = new StringBuffer();
    OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = createProviderParticipantDetails.addressData;
    curam.core.intf.Address addressObj = AddressFactory.newInstance();

    addressObj.getAddressStrings(otherAddressData);
    representativeDetails.append(createProviderParticipantDetails.name);
    representativeDetails.append(otherAddressData.addressData.trim());
    representativeDetails.append(createProviderParticipantDetails.phoneAreaCode);
    representativeDetails.append(
      createProviderParticipantDetails.phoneCountryCode);
    representativeDetails.append(
      createProviderParticipantDetails.phoneExtension);
    representativeDetails.append(createProviderParticipantDetails.phoneNumber);

    if (0 != createProviderParticipantDetails.searchConcernRoleID
      && 0 != representativeDetails.toString().length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new curam.util.exception.AppException(
          curam.message.CPMCOMMONMESSAGES.ERR_CPMCOMMONMSG_XRV_REGISTERED_PERSON_OR_REGISTRATION_DETAILS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          4);
    }
  }
}
