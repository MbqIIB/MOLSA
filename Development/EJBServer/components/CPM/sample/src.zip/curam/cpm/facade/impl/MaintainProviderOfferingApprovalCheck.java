/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.ListIterator;

import com.google.inject.Inject;

import curam.approvalcheck.entity.struct.ApprovalCheckDtls;
import curam.approvalcheck.impl.ApprovalCheck;
import curam.approvalcheck.impl.ApprovalCheckDAO;
import curam.codetable.impl.APPROVALCHECKTYPEEntry;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.facade.struct.ApprovalCheckDetails;
import curam.cpm.facade.struct.ApprovalCheckDetailsList;
import curam.cpm.facade.struct.ApprovalCheckKey;
import curam.cpm.facade.struct.CreateApprovalCheckDetails;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.ModifyApprovalCheckDetails;
import curam.cpm.facade.struct.ProviderOfferingKey;
import curam.cpm.facade.struct.ViewApprovalCheckKey;
import curam.cpm.impl.CPMConstants;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderSecurity;
import curam.provider.impl.SERVICEDELIVERYAPPROVALSEntry;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;


/**
 * Facade layer class having APIs for managing Approval Check for the Provider
 * Offering.
 */
public class MaintainProviderOfferingApprovalCheck extends curam.cpm.facade.base.MaintainProviderOfferingApprovalCheck {

  /**
   * Reference to approval check DAO.
   */
  @Inject
  protected ApprovalCheckDAO approvalCheckDAO;

  /**
   * Reference to approval check.
   */
  @Inject
  protected ApprovalCheck approvalCheck;

  /**
   * Reference to provider security.
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * Reference to provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to provider offering DAO.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Constructor for the class.
   */
  public MaintainProviderOfferingApprovalCheck() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates approval check for the provider offering.
   *
   * @param createApprovalCheckDetails
   * Approval check details for the provider offering.
   *
   * @return The approval check ID of the created approval check.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckKey createProviderOfferingApprovalCheck(
    CreateApprovalCheckDetails createApprovalCheckDetails)
    throws AppException, InformationalException {

    providerSecurity.checkProviderSecurity(
      providerOfferingDAO.get(createApprovalCheckDetails.providerOfferingID).getProvider());

    approvalCheck = approvalCheckDAO.newInstance();
    approvalCheck.setComments(createApprovalCheckDetails.comments);
    approvalCheck.setPercentage(createApprovalCheckDetails.percentage);

    approvalCheck.createApprovalCheck(APPROVALRELATEDTYPEEntry.PROVIDEROFFERING,
      createApprovalCheckDetails.providerOfferingID,
      APPROVALCHECKTYPEEntry.RELATEDTYPE);

    ApprovalCheckKey approvalCheckKey = new ApprovalCheckKey();

    approvalCheckKey.approvalCheckID = approvalCheck.getID();

    return approvalCheckKey;
  }

  /**
   * Creates provider offering approval check for an organization unit.
   *
   * @param createApprovalCheckDetails
   * Approval check details for the provider offering.
   *
   * @return The approval check ID of the created approval check.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckKey createProviderOfferingApprovalCheckForOrganisationUnit(
    CreateApprovalCheckDetails createApprovalCheckDetails)
    throws AppException, InformationalException {

    approvalCheck = approvalCheckDAO.newInstance();
    approvalCheck.setComments(createApprovalCheckDetails.comments);
    approvalCheck.setPercentage(createApprovalCheckDetails.percentage);
    approvalCheck.setOrganisationUnitID(
      createApprovalCheckDetails.organisationUnitID);

    if (createApprovalCheckDetails.searchProviderOfferingID != 0) {

      approvalCheck.createApprovalCheck(
        APPROVALRELATEDTYPEEntry.PROVIDEROFFERING,
        createApprovalCheckDetails.searchProviderOfferingID,
        APPROVALCHECKTYPEEntry.ORGANISATIONUNIT);
    } else {
      approvalCheck.createApprovalCheck(
        APPROVALRELATEDTYPEEntry.ALLPROVIDEROFFERINGSFORPROVIDER,
        createApprovalCheckDetails.providerID,
        APPROVALCHECKTYPEEntry.ORGANISATIONUNIT);
    }
    ApprovalCheckKey approvalCheckKey = new ApprovalCheckKey();

    approvalCheckKey.approvalCheckID = approvalCheck.getID();

    return approvalCheckKey;
  }

  /**
   * Creates provider offering approval check for an user.
   *
   * @param createApprovalCheckDetails
   * Approval check details for the provider offering.
   *
   * @return The approval check ID of the created approval check.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckKey createProviderOfferingApprovalCheckForUser(
    CreateApprovalCheckDetails createApprovalCheckDetails)
    throws AppException, InformationalException {

    approvalCheck = approvalCheckDAO.newInstance();
    approvalCheck.setComments(createApprovalCheckDetails.comments);
    approvalCheck.setPercentage(createApprovalCheckDetails.percentage);
    approvalCheck.setUsername(createApprovalCheckDetails.userName);

    if (createApprovalCheckDetails.searchProviderOfferingID != 0) {

      approvalCheck.createApprovalCheck(
        APPROVALRELATEDTYPEEntry.PROVIDEROFFERING,
        createApprovalCheckDetails.searchProviderOfferingID,
        APPROVALCHECKTYPEEntry.USER);
    } else {
      approvalCheck.createApprovalCheck(
        APPROVALRELATEDTYPEEntry.ALLPROVIDEROFFERINGSFORPROVIDER,
        createApprovalCheckDetails.providerID, APPROVALCHECKTYPEEntry.USER);
    }
    ApprovalCheckKey approvalCheckKey = new ApprovalCheckKey();

    approvalCheckKey.approvalCheckID = approvalCheck.getID();

    return approvalCheckKey;
  }

  /**
   * Deletes the approval check for the provider offering.
   *
   * @param approvalCheckKeyVersionDetails
   * Contains the version detail of the provider offering approval
   * check to be deleted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deleteProviderOfferingApprovalCheck(
    KeyVersionDetails approvalCheckKeyVersionDetails) throws AppException,
      InformationalException {

    ApprovalCheck approvalCheck = approvalCheckDAO.get(
      approvalCheckKeyVersionDetails.id);

    providerSecurity.checkProviderSecurity(
      providerOfferingDAO.get(approvalCheck.getRelatedID()).getProvider());

    approvalCheck.cancel(approvalCheckKeyVersionDetails.version);
  }

  /**
   * Lists the approval checks for the provider offering.
   *
   * @param providerOfferingKey
   * Contains the provider offering ID.
   *
   * @return The list of approval check details for the provider offering.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckDetailsList listProviderOfferingApprovalChecks(
    ProviderOfferingKey providerOfferingKey) throws AppException,
      InformationalException {

    ApprovalCheckDetailsList approvalCheckDetailsList = new ApprovalCheckDetailsList();

    List<ApprovalCheck> approvalChecks = new ArrayList<ApprovalCheck>();
    ApprovalCheckDetails approvalCheckDtls;

    List<ApprovalCheck> activeApprovalChecks = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.RELATEDTYPE,
      APPROVALRELATEDTYPEEntry.PROVIDEROFFERING,
      providerOfferingKey.providerOfferingKey.providerOfferingID,
      RECORDSTATUSEntry.NORMAL);

    List<ApprovalCheck> canceledApprovalChecks = approvalCheckDAO.searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.RELATEDTYPE,
      APPROVALRELATEDTYPEEntry.PROVIDEROFFERING,
      providerOfferingKey.providerOfferingKey.providerOfferingID,
      RECORDSTATUSEntry.CANCELLED);

    approvalChecks.addAll(activeApprovalChecks);

    List<ApprovalCheck> sortedCanceledApprovalChecks = new ArrayList<ApprovalCheck>();

    // Sort the list canceled approval checks into reverse order as the list
    // of approval checks should be sorted by latest created first.
    for (int i = canceledApprovalChecks.size() - 1; i >= 0; i--) {
      sortedCanceledApprovalChecks.add(canceledApprovalChecks.get(i));
    }
    approvalChecks.addAll(sortedCanceledApprovalChecks);

    ListIterator<ApprovalCheck> approvalChecksIterator = approvalChecks.listIterator();

    while (approvalChecksIterator.hasNext()) {

      approvalCheckDtls = new ApprovalCheckDetails();
      approvalCheck = approvalChecksIterator.next();
      approvalCheckDtls.approvalCheckDtls.approvalCheckID = approvalCheck.getID();
      approvalCheckDtls.approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
      approvalCheckDtls.approvalCheckDtls.percentage = approvalCheck.getPercentage();
      approvalCheckDtls.approvalCheckDtls.versionNo = approvalCheck.getVersionNo();
      approvalCheckDetailsList.approvalCheckDtls.addRef(approvalCheckDtls);
    }

    return approvalCheckDetailsList;
  }

  /**
   * Lists the provider offering approval checks for organization unit.
   *
   * @param viewApprovalCheckKey
   * Contains the organization unit ID.
   *
   * @return The list of provider offering approval check details for the
   * organization unit.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckDetailsList listProviderOfferingApprovalChecksForOrganisationUnit(
    ViewApprovalCheckKey viewApprovalCheckKey) throws AppException,
      InformationalException {

    ApprovalCheckDetailsList approvalCheckDetailsList = new ApprovalCheckDetailsList();

    List<ApprovalCheck> approvalChecks = new ArrayList<ApprovalCheck>();
    ApprovalCheckDetails approvalCheckDetails;

    List<ApprovalCheck> activeApprovalChecks = approvalCheckDAO.searchByTypeOrganisationUnitAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.PROVIDEROFFERING,
      viewApprovalCheckKey.organisationUnitID, RECORDSTATUSEntry.NORMAL);

    List<ApprovalCheck> canceledApprovalChecks = approvalCheckDAO.searchByTypeOrganisationUnitAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.PROVIDEROFFERING,
      viewApprovalCheckKey.organisationUnitID, RECORDSTATUSEntry.CANCELLED);

    List<ApprovalCheck> allProviderActiveApprovalChecks = approvalCheckDAO.searchByTypeOrganisationUnitAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.ALLPROVIDEROFFERINGSFORPROVIDER,
      viewApprovalCheckKey.organisationUnitID, RECORDSTATUSEntry.NORMAL);

    List<ApprovalCheck> allProviderServiceCanceledApprovalChecks = approvalCheckDAO.searchByTypeOrganisationUnitAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT,
      APPROVALRELATEDTYPEEntry.ALLPROVIDEROFFERINGSFORPROVIDER,
      viewApprovalCheckKey.organisationUnitID, RECORDSTATUSEntry.CANCELLED);
    
    approvalChecks.addAll(activeApprovalChecks);
    approvalChecks.addAll(canceledApprovalChecks);
    approvalChecks.addAll(allProviderActiveApprovalChecks);
    approvalChecks.addAll(allProviderServiceCanceledApprovalChecks);   
    
    ListIterator<ApprovalCheck> approvalChecksIterator = approvalChecks.listIterator();

    while (approvalChecksIterator.hasNext()) {
      approvalCheckDetails = new ApprovalCheckDetails();
      approvalCheck = approvalChecksIterator.next();
      approvalCheckDetails.approvalCheckDtls.approvalCheckID = approvalCheck.getID();
      approvalCheckDetails.approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
      approvalCheckDetails.approvalCheckDtls.percentage = approvalCheck.getPercentage();
      approvalCheckDetails.approvalCheckDtls.versionNo = approvalCheck.getVersionNo();

      try {
        approvalCheckDetails.serviceOfferingName = providerOfferingDAO.get(approvalCheck.getRelatedID()).getServiceOffering().getName();
        approvalCheckDetails.providerName = providerOfferingDAO.get(approvalCheck.getRelatedID()).getProvider().getName();
      } catch (RecordNotFoundException recordNotFoundException) {

        approvalCheckDetails.serviceOfferingName = SERVICEDELIVERYAPPROVALSEntry.ALLPROVIDERSERVICES.toUserLocaleString();
        approvalCheckDetails.providerName = providerDAO.get(approvalCheck.getRelatedID()).getName();
      }

      approvalCheckDetailsList.approvalCheckDtls.addRef(approvalCheckDetails);
    }

    return sortApprovalChecksByName(approvalCheckDetailsList);
  }

  /**
   * Lists the provider offering approval checks for a user.
   *
   * @param viewApprovalCheckKey
   * Contains the user name.
   *
   * @return The list of provider offering approval check details for the
   * organization unit.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckDetailsList listProviderOfferingApprovalChecksForUser(
    ViewApprovalCheckKey viewApprovalCheckKey) throws AppException,
      InformationalException {

    ApprovalCheckDetailsList approvalCheckDetailsList = new ApprovalCheckDetailsList();

    List<ApprovalCheck> approvalChecks = new ArrayList<ApprovalCheck>();
    ApprovalCheckDetails approvalCheckDetails;

    List<ApprovalCheck> activeApprovalChecks = approvalCheckDAO.searchByTypeUsernameAndStatus(
      APPROVALCHECKTYPEEntry.USER, APPROVALRELATEDTYPEEntry.PROVIDEROFFERING,
      viewApprovalCheckKey.userName, RECORDSTATUSEntry.NORMAL);

    List<ApprovalCheck> canceledApprovalChecks = approvalCheckDAO.searchByTypeUsernameAndStatus(
      APPROVALCHECKTYPEEntry.USER, APPROVALRELATEDTYPEEntry.PROVIDEROFFERING,
      viewApprovalCheckKey.userName, RECORDSTATUSEntry.CANCELLED);

    List<ApprovalCheck> allProviderServiceActiveApprovalChecksFor = approvalCheckDAO.searchByTypeUsernameAndStatus(
      APPROVALCHECKTYPEEntry.USER,
      APPROVALRELATEDTYPEEntry.ALLPROVIDEROFFERINGSFORPROVIDER,
      viewApprovalCheckKey.userName, RECORDSTATUSEntry.NORMAL);

    List<ApprovalCheck> allProviderServiceCanceledApprovalChecks = approvalCheckDAO.searchByTypeUsernameAndStatus(
      APPROVALCHECKTYPEEntry.USER,
      APPROVALRELATEDTYPEEntry.ALLPROVIDEROFFERINGSFORPROVIDER,
      viewApprovalCheckKey.userName, RECORDSTATUSEntry.CANCELLED);

    approvalChecks.addAll(activeApprovalChecks);

    approvalChecks.addAll(canceledApprovalChecks);
    approvalChecks.addAll(allProviderServiceActiveApprovalChecksFor);

    approvalChecks.addAll(allProviderServiceCanceledApprovalChecks);

    ListIterator<ApprovalCheck> approvalChecksIterator = approvalChecks.listIterator();

    while (approvalChecksIterator.hasNext()) {
      approvalCheckDetails = new ApprovalCheckDetails();
      approvalCheck = approvalChecksIterator.next();
      approvalCheckDetails.approvalCheckDtls.approvalCheckID = approvalCheck.getID();
      approvalCheckDetails.approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
      approvalCheckDetails.approvalCheckDtls.percentage = approvalCheck.getPercentage();
      approvalCheckDetails.approvalCheckDtls.versionNo = approvalCheck.getVersionNo();

      try {
        approvalCheckDetails.serviceOfferingName = providerOfferingDAO.get(approvalCheck.getRelatedID()).getServiceOffering().getName();
        approvalCheckDetails.providerName = providerOfferingDAO.get(approvalCheck.getRelatedID()).getProvider().getName();
      } catch (RecordNotFoundException recordNotFoundException) {

        approvalCheckDetails.serviceOfferingName = SERVICEDELIVERYAPPROVALSEntry.ALLPROVIDERSERVICES.toUserLocaleString();
        approvalCheckDetails.providerName = providerDAO.get(approvalCheck.getRelatedID()).getName();
      }

      approvalCheckDetailsList.approvalCheckDtls.addRef(approvalCheckDetails);
    }

    return sortApprovalChecksByName(approvalCheckDetailsList);
  }

  /**
   * Modifies the approval check details for the provider offering.
   *
   * @param modifyApprovalCheckDetails
   * Details of the provider offering approval check.
   *
   * @return The approval check ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckKey modifyProviderOfferingApprovalCheck(
    ModifyApprovalCheckDetails modifyApprovalCheckDetails)
    throws AppException, InformationalException {

    ApprovalCheck approvalCheck = approvalCheckDAO.get(
      modifyApprovalCheckDetails.approvalCheckID);

    providerSecurity.checkProviderSecurity(
      providerOfferingDAO.get(approvalCheck.getRelatedID()).getProvider());

    approvalCheck.setComments(
      modifyApprovalCheckDetails.approvalCheckDtls.comments);
    approvalCheck.setPercentage(
      modifyApprovalCheckDetails.approvalCheckDtls.percentage);
    approvalCheck.modifyApprovalCheck(modifyApprovalCheckDetails.versionNo);
    ApprovalCheckKey approvalCheckKey = new ApprovalCheckKey();

    approvalCheckKey.approvalCheckID = modifyApprovalCheckDetails.approvalCheckID;

    return approvalCheckKey;
  }

  /**
   * Modifies the provider offering approval check details for the organization
   * unit.
   *
   * @param modifyApprovalCheckDetails
   * Details of the provider offering approval check.
   *
   * @return The approval check ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckKey modifyProviderOfferingApprovalCheckForOrganisationUnit(
    ModifyApprovalCheckDetails modifyApprovalCheckDetails)
    throws AppException, InformationalException {

    ApprovalCheck approvalCheck = approvalCheckDAO.get(
      modifyApprovalCheckDetails.approvalCheckID);

    approvalCheck.setComments(
      modifyApprovalCheckDetails.approvalCheckDtls.comments);
    approvalCheck.setPercentage(
      modifyApprovalCheckDetails.approvalCheckDtls.percentage);
    approvalCheck.modifyApprovalCheck(modifyApprovalCheckDetails.versionNo);
    ApprovalCheckKey approvalCheckKey = new ApprovalCheckKey();

    approvalCheckKey.approvalCheckID = modifyApprovalCheckDetails.approvalCheckID;

    return approvalCheckKey;
  }

  /**
   * Reads the approval check details for the provider offering.
   *
   * @param viewApprovalCheckKey
   * Contains the approval check ID for the provider offering.
   *
   * @return The approval check details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckDetails viewProviderOfferingApprovalCheck(
    ViewApprovalCheckKey viewApprovalCheckKey) throws AppException,
      InformationalException {

    approvalCheck = approvalCheckDAO.get(viewApprovalCheckKey.approvalCheckID);
    ApprovalCheckDtls approvalCheckDtls = new ApprovalCheckDtls();

    approvalCheckDtls.comments = approvalCheck.getComments();
    approvalCheckDtls.percentage = approvalCheck.getPercentage();
    approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
    approvalCheckDtls.approvalCheckID = approvalCheck.getID();
    approvalCheckDtls.versionNo = approvalCheck.getVersionNo();
    approvalCheckDtls.relatedID = approvalCheck.getRelatedID();
    ApprovalCheckDetails approvalCheckDetails = new ApprovalCheckDetails();

    approvalCheckDetails.approvalCheckDtls.assign(approvalCheckDtls);

    return approvalCheckDetails;
  }

  /**
   * Deletes the provider offering approval check for the organization unit.
   *
   * @param approvalCheckKeyVersionDetails
   * Contains the version detail of the provider offering approval
   * check to be deleted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deleteProviderOfferingApprovalCheckForOrganisationUnit(
    KeyVersionDetails approvalCheckKeyVersionDetails) throws AppException,
      InformationalException {

    ApprovalCheck approvalCheck = approvalCheckDAO.get(
      approvalCheckKeyVersionDetails.id);

    approvalCheck.cancel(approvalCheckKeyVersionDetails.version);
  }

  /**
   * Reads the provider offering approval check details for the organization
   * unit.
   *
   * @param approvalCheckKey
   * Contains the approval check ID for the provider offering.
   *
   * @return The approval check details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckDetails viewProviderOfferingApprovalCheckForOrganisationUnit(
    ApprovalCheckKey approvalCheckKey) throws AppException,
      InformationalException {

    approvalCheck = approvalCheckDAO.get(approvalCheckKey.approvalCheckID);
    ApprovalCheckDetails approvalCheckDetails = new ApprovalCheckDetails();

    approvalCheckDetails.approvalCheckDtls.comments = approvalCheck.getComments();
    approvalCheckDetails.approvalCheckDtls.percentage = approvalCheck.getPercentage();
    approvalCheckDetails.approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
    approvalCheckDetails.approvalCheckDtls.approvalCheckID = approvalCheck.getID();
    approvalCheckDetails.approvalCheckDtls.versionNo = approvalCheck.getVersionNo();
    approvalCheckDetails.approvalCheckDtls.relatedID = approvalCheck.getRelatedID();
    approvalCheckDetails.approvalCheckDtls.organisationUnitID = approvalCheck.getOrganisationUnitID();
    approvalCheckDetails.approvalCheckDtls.relatedType = approvalCheck.getRelatedType().getCode();
    approvalCheckDetails.approvalCheckDtls.typeCode = approvalCheck.getType().getCode();

    try {
      approvalCheckDetails.serviceOfferingName = providerOfferingDAO.get(approvalCheck.getRelatedID()).getServiceOffering().getName();
      approvalCheckDetails.providerName = providerOfferingDAO.get(approvalCheck.getRelatedID()).getProvider().getName();
    } catch (RecordNotFoundException recordNotFoundException) {

      approvalCheckDetails.serviceOfferingName = SERVICEDELIVERYAPPROVALSEntry.ALLPROVIDERSERVICES.toUserLocaleString();
      approvalCheckDetails.providerName = providerDAO.get(approvalCheck.getRelatedID()).getName();
    }

    return approvalCheckDetails;
  }

  /**
   * Deletes the provider offering approval check for a user.
   *
   * @param approvalCheckKeyVersionDetails
   * Contains the version detail of the provider offering approval
   * check to be deleted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deleteProviderOfferingApprovalChecksForUser(
    KeyVersionDetails approvalCheckKeyVersionDetails) throws AppException,
      InformationalException {

    ApprovalCheck approvalCheck = approvalCheckDAO.get(
      approvalCheckKeyVersionDetails.id);

    approvalCheck.cancel(approvalCheckKeyVersionDetails.version);
  }

  /**
   * Modifies the provider offering approval check details for a user.
   *
   * @param modifyApprovalCheckDetails
   * Details of the provider offering approval check.
   *
   * @return The approval check ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckKey modifyProviderOfferingApprovalChecksForUser(
    ModifyApprovalCheckDetails modifyApprovalCheckDetails)
    throws AppException, InformationalException {

    ApprovalCheck approvalCheck = approvalCheckDAO.get(
      modifyApprovalCheckDetails.approvalCheckID);

    approvalCheck.setComments(
      modifyApprovalCheckDetails.approvalCheckDtls.comments);
    approvalCheck.setPercentage(
      modifyApprovalCheckDetails.approvalCheckDtls.percentage);
    approvalCheck.modifyApprovalCheck(modifyApprovalCheckDetails.versionNo);
    ApprovalCheckKey approvalCheckKey = new ApprovalCheckKey();

    approvalCheckKey.approvalCheckID = modifyApprovalCheckDetails.approvalCheckID;

    return approvalCheckKey;
  }

  /**
   * Reads the provider offering approval check details for the user.
   *
   * @param approvalCheckKey
   * Contains the approval check ID for the provider offering.
   *
   * @return The approval check details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ApprovalCheckDetails viewProviderOfferingApprovalChecksForUser(
    ApprovalCheckKey approvalCheckKey) throws AppException,
      InformationalException {

    approvalCheck = approvalCheckDAO.get(approvalCheckKey.approvalCheckID);
    ApprovalCheckDetails approvalCheckDetails = new ApprovalCheckDetails();

    approvalCheckDetails.approvalCheckDtls.comments = approvalCheck.getComments();
    approvalCheckDetails.approvalCheckDtls.percentage = approvalCheck.getPercentage();
    approvalCheckDetails.approvalCheckDtls.recordStatus = approvalCheck.getLifecycleState().getCode();
    approvalCheckDetails.approvalCheckDtls.approvalCheckID = approvalCheck.getID();
    approvalCheckDetails.approvalCheckDtls.versionNo = approvalCheck.getVersionNo();
    approvalCheckDetails.approvalCheckDtls.relatedID = approvalCheck.getRelatedID();
    approvalCheckDetails.approvalCheckDtls.username = approvalCheck.getUsername();
    approvalCheckDetails.approvalCheckDtls.relatedType = approvalCheck.getRelatedType().getCode();
    approvalCheckDetails.approvalCheckDtls.typeCode = approvalCheck.getType().getCode();

    try {
      approvalCheckDetails.serviceOfferingName = providerOfferingDAO.get(approvalCheck.getRelatedID()).getServiceOffering().getName();
      approvalCheckDetails.providerName = providerOfferingDAO.get(approvalCheck.getRelatedID()).getProvider().getName();
    } catch (RecordNotFoundException recordNotFoundException) {

      approvalCheckDetails.serviceOfferingName = SERVICEDELIVERYAPPROVALSEntry.ALLPROVIDERSERVICES.toUserLocaleString();
      approvalCheckDetails.providerName = providerDAO.get(approvalCheck.getRelatedID()).getName();
    }

    return approvalCheckDetails;
  }

  /**
   * Retrieves the create approval check details which is passed by input
   * screen.
   *
   * @param createApprovalCheckDetails
   * Approval check details for provider offering.
   *
   * @return Approval check details which is passed by input screen.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public CreateApprovalCheckDetails retrieveProviderOfferingApprovalDetailsByClient(
    CreateApprovalCheckDetails createApprovalCheckDetails)
    throws AppException, InformationalException {

    Provider provider = providerDAO.get(createApprovalCheckDetails.providerID);

    createApprovalCheckDetails.providerName = provider.getName();
    // BEGIN, CR00213945, AS
    approvalCheck = approvalCheckDAO.newInstance();
    approvalCheck.setPercentage(createApprovalCheckDetails.percentage);
    ValidationHelper.failIfErrorsExist();
    // END, CR00213945
    return createApprovalCheckDetails;
  }

  /**
   * Sorts a set of approval checks based on provider offering name into a
   * sorted list for display.
   *
   * @param unsortedApprovalChecks
   * the set of unsorted approval checks.
   *
   * @return The sorted list of provider offering approval checks for an
   * organization unit.
   */

  @SuppressWarnings(CPMConstants.kUnchecked)
  protected ApprovalCheckDetailsList sortApprovalChecksByName(
    ApprovalCheckDetailsList unsortedApprovalChecks) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    List<ApprovalCheckDetails> approvalCheckDetailsList = new ArrayList<ApprovalCheckDetails>();
    int noOfEnquiries = unsortedApprovalChecks.approvalCheckDtls.size();

    for (int i = 0; i < noOfEnquiries; i++) {
      approvalCheckDetailsList.add(
        unsortedApprovalChecks.approvalCheckDtls.item(i));
    }

    Collections.sort(approvalCheckDetailsList,
      new Comparator<ApprovalCheckDetails>() {
      public int compare(final ApprovalCheckDetails lhs,
        ApprovalCheckDetails rhs) {
        return lhs.serviceOfferingName.compareToIgnoreCase(
          rhs.serviceOfferingName);
      }
    });

    ApprovalCheckDetailsList sortedApprovalCheckDetailsList = new ApprovalCheckDetailsList();

    sortedApprovalCheckDetailsList.approvalCheckDtls.addAll(
      approvalCheckDetailsList);

    return sortedApprovalCheckDetailsList;
  }

}
