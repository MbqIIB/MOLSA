/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008,2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.eua.facade.impl;
 

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.struct.ConcernRoleKey;
import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.eua.facade.struct.ProviderMemberDetailsList;
import curam.cpm.facade.fact.ContextDescriptionFactory;
import curam.cpm.facade.fact.ProviderMemberFactory;
import curam.cpm.facade.intf.ContextDescription;
import curam.cpm.facade.struct.ProviderMemberSummaryDetails;
import curam.cpm.facade.struct.ProviderMemberSummaryDetailsList;
import curam.cpm.facade.struct.ViewProviderMemberDetails;
import curam.cpm.sl.entity.struct.ProviderPartyKey;
import curam.provider.impl.ProviderPartyDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This process class provides the functionality for the External
 * Provider Member facade layer
 */
public abstract class ExternalProviderMember extends curam.cpm.eua.facade.base.ExternalProviderMember {

  /*
   * Inject providerPartyDAO
   */
  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  /**
   * Constructor
   */
  public ExternalProviderMember() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * This method returns a list of members for a provider
   *
   * @param concernRoleKey - Contains the concernRoleID for the provider
   * @return a list of provider members
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ProviderMemberDetailsList listMembersByConcernRole(
    ConcernRoleKey concernRoleKey) throws AppException, InformationalException {

    // Create instance of provider member facade
    curam.cpm.facade.intf.ProviderMember providerMemberObj = ProviderMemberFactory.newInstance();

    ProviderMemberDetailsList providerMemberDetailsList = new ProviderMemberDetailsList();

    // call method to ensure that the logged in user has access
    // to view this information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    // variables for reading the context description
    ContextDescription contextDescription = ContextDescriptionFactory.newInstance();

    providerMemberDetailsList.pageContextDescription.description = contextDescription.getContextDescriptionForConcern(concernRoleKey).description;

    // remove all canceled records
    providerMemberDetailsList.providerMemberList = filterList(
      providerMemberObj.listMembersByConcernRole(concernRoleKey));

    // BEGIN, CR00090210, GD
    // Sort returned list by name
    providerMemberDetailsList = sortProviderMembersByName(
      providerMemberDetailsList);
    // END, CR00090210

    // invoke facade layer method
    return providerMemberDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Sorts a set of provider members into a sorted list by name.
   *
   * @param unsortedProviderMembers the set of provider members to sort
   * @return sorted list of provider members for display
   */
  // BEGIN, CR00177241, PM
  protected ProviderMemberDetailsList sortProviderMembersByName(
    final ProviderMemberDetailsList unsortedProviderMembers) {
    // END, CR00177241

    /*
     * Sort by name for display - using a list.
     */
    final List<ProviderMemberSummaryDetails> providerMemberSummaryDetails = new ArrayList<ProviderMemberSummaryDetails>();

    // Copy items for sorting
    for (int i = 0, j = unsortedProviderMembers.providerMemberList.providerMemberSummaryDetailsList.size(); i
      < j; i++) {

      providerMemberSummaryDetails.add(
        unsortedProviderMembers.providerMemberList.providerMemberSummaryDetailsList.item(
          i));

    }

    Collections.sort(providerMemberSummaryDetails,
      new Comparator<ProviderMemberSummaryDetails>() {

      public int compare(final ProviderMemberSummaryDetails lhs,
        ProviderMemberSummaryDetails rhs) {

        return lhs.memberName.compareTo(rhs.memberName);

      }

    });

    // return structure
    ProviderMemberDetailsList providerMemberDetailsList = new ProviderMemberDetailsList();

    // Copy sorted entries into return list structure
    for (int m = 0, n = providerMemberSummaryDetails.size(); m < n; m++) {

      providerMemberDetailsList.providerMemberList.providerMemberSummaryDetailsList.addRef(
        providerMemberSummaryDetails.get(m));

    }

    return providerMemberDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * This method filters the provider members list removing all canceled
   * records from the list
   *
   * @param unfilteredList - this contains a list of provider members
   * @return This contains a list of all provider members except canceled
   */
  // BEGIN, CR00177241, PM
  protected ProviderMemberSummaryDetailsList filterList(
    ProviderMemberSummaryDetailsList unfilteredList) {
    // END, CR00177241

    ProviderMemberSummaryDetailsList result = new ProviderMemberSummaryDetailsList();

    for (int i = 0; i < unfilteredList.providerMemberSummaryDetailsList.size(); i++) {

      // add only non-canceled records to the list
      if (!unfilteredList.providerMemberSummaryDetailsList.item(i).recordStatus.equals(
        RECORDSTATUSEntry.CANCELLED.getCode())) {
        result.providerMemberSummaryDetailsList.addRef(
          unfilteredList.providerMemberSummaryDetailsList.item(i));
      }
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * This method returns details for a provider member
   *
   * @param providerMemberKey - contains the provider party ID
   * @return contains details for a provider member
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ViewProviderMemberDetails viewMember(
    ProviderPartyKey providerMemberKey) throws AppException, InformationalException {

    // Create instance of provider member facade
    curam.cpm.facade.intf.ProviderMember providerMemberObj = ProviderMemberFactory.newInstance();

    ViewProviderMemberDetails viewProviderMemberDetails = providerMemberObj.viewMember(
      providerMemberKey);

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // set the concern role ID
    concernRoleKey.concernRoleID = providerPartyDAO.get(providerMemberKey.providerPartyID).getProviderOrganization().getID();
    // call method to ensure that the logged in user has access
    // to view this information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    // invoke facade layer method
    return viewProviderMemberDetails;

  }

}
