/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import com.google.inject.Inject;

import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.ContractVersionDAO;
import curam.core.impl.CuramConst;
import curam.cpm.facade.fact.MaintainProviderGroupAssociatePaymentConfigurationFactory;
import curam.cpm.facade.intf.MaintainProviderGroupAssociatePaymentConfiguration;
import curam.cpm.facade.struct.CreatePGAssociatePaymentConfigDetails;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.ProviderGroupAssociateSummaryDetails;
import curam.cpm.facade.struct.ProviderGroupAssociateSummaryInformationDetails;
import curam.cpm.sl.entity.struct.ProviderGroupAssociateDtls;
import curam.cpm.sl.entity.struct.ProviderGroupAssociateKey;
import curam.message.impl.PROVIDERGROUPASSOCIATEExceptionCreator;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderGroupAssociateDAO;
import curam.provider.impl.ProviderGroupAssociatePaymentConfiguration;
import curam.provider.impl.ProviderGroupAssociatePaymentConfigurationDAO;
import curam.provider.impl.ProviderGroupDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.DateRange;


/**
 * Facade layer class having API's for managing the Providers Associate.
 */
public abstract class ProviderGroupAssociate extends curam.cpm.facade.base.ProviderGroupAssociate {

  /**
   * Reference to Provider Group Associate DAO.
   */
  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;

  /**
   * Reference to Provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to Provider Group DAO.
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  // BEGIN, CR00168459, SG
  /**
   * Reference to Contract Version DAO.
   */
  @Inject
  protected ContractVersionDAO contractVersionDAO;

  /**
   * Constructor for the class.
   */
  public ProviderGroupAssociate() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00185290, SSK
  /**
   * Reference to ProviderGroupAssociatePaymentConfigurationDAO.
   */
  @Inject
  protected ProviderGroupAssociatePaymentConfigurationDAO providerGroupAssociatePaymentConfigurationDAO;
  // END, CR00185290

  
  /**
   * Modifies Provider Group Association details.
   *
   * @param dtls
   * Contains provider group association details.
   *
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyProviderGroupAssociate(ProviderGroupAssociateDtls dtls)
    throws AppException, InformationalException {

    curam.provider.impl.ProviderGroupAssociate providerGroupAssociate = providerGroupAssociateDAO.get(
      dtls.providerGroupAssociateID);

    setModifyProviderGroupAssociateFields(providerGroupAssociate, dtls);

    providerGroupAssociate.modify(dtls.versionNo);

  }

  /**
   * Reads the Provider Group Association details.
   *
   * @param key
   * Contains Provider Group Association key.
   *
   * @return Details of Provider Group Association.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link #viewProviderGroupAssociateDetails}. The new method
   * returns provider group associate details along with the
   * provider status.
   */
  public ProviderGroupAssociateSummaryDetails viewProviderGroupAssociate(
    ProviderGroupAssociateKey key) throws AppException,
      InformationalException {

    curam.provider.impl.ProviderGroupAssociate providerGroupAssociate = providerGroupAssociateDAO.get(
      key.providerGroupAssociateID);

    ProviderGroupAssociateSummaryDetails summaryDetails = new ProviderGroupAssociateSummaryDetails();

    ProviderGroupAssociateDtls associateDetails = new ProviderGroupAssociateDtls();

    associateDetails = getProviderGroupAssociateDetails(providerGroupAssociate);

    curam.provider.impl.Provider provider = providerGroupAssociate.getProvider();

    summaryDetails.providerName = provider.getName();
    summaryDetails.assign(associateDetails);

    return summaryDetails;
  }

  /**
   * Reads the Provider Group Association details along with provider status.
   *
   * @param providerGroupAssociateKey
   * Contains Provider Group Association key.
   *
   * @return Details of Provider Group Association.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderGroupAssociateSummaryInformationDetails viewProviderGroupAssociateDetails(
    ProviderGroupAssociateKey providerGroupAssociateKey) throws AppException,
      InformationalException {

    curam.provider.impl.ProviderGroupAssociate providerGroupAssociate = providerGroupAssociateDAO.get(
      providerGroupAssociateKey.providerGroupAssociateID);

    ProviderGroupAssociateSummaryInformationDetails summaryDetails = new ProviderGroupAssociateSummaryInformationDetails();

    ProviderGroupAssociateDtls associateDetails = new ProviderGroupAssociateDtls();

    associateDetails = getProviderGroupAssociateDetails(providerGroupAssociate);

    curam.provider.impl.Provider provider = providerGroupAssociate.getProvider();

    summaryDetails.providerName = provider.getName();
    summaryDetails.providerStatus = provider.getLifecycleState().getCode();
    summaryDetails.assign(associateDetails);

    return summaryDetails;
  }

  /**
   * Adds a Provider to Provider Group with the specified Provider Group
   * Association details.
   *
   * @param dtls
   * Contains Provider Group Association details.
   *
   * @return The key of the Provider Group Association record created.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderGroupAssociateKey createProviderGroupAssociate(
    ProviderGroupAssociateDtls dtls) throws AppException,
      InformationalException {

    ProviderGroupAssociateKey providerGroupAssociateKey = new ProviderGroupAssociateKey();

    curam.provider.impl.ProviderGroupAssociate providerGroupAssociate = providerGroupAssociateDAO.newInstance();

    setCreateProviderGroupAssociateFields(providerGroupAssociate, dtls);

    providerGroupAssociate.insert();

    providerGroupAssociateKey.providerGroupAssociateID = providerGroupAssociate.getID();

    // BEGIN, CR00185290, SSK
    if (dtls.groupToReceivePayments) {

      ProviderGroupAssociatePaymentConfiguration providerGroupAssociatePaymentConfiguration = providerGroupAssociatePaymentConfigurationDAO.newInstance();

      providerGroupAssociatePaymentConfiguration.setProviderGroupAssociate(
        providerGroupAssociate);
      providerGroupAssociatePaymentConfiguration.setEffectiveDate(
        dtls.startDate);
      providerGroupAssociatePaymentConfiguration.setGroupToReceivePaymentsInd(
        dtls.groupToReceivePayments);

      providerGroupAssociatePaymentConfiguration.insert();

    }
    // END, CR00185290

    return providerGroupAssociateKey;

  }

  /**
   * Cancels the association between the Provider and Provider Group.
   *
   * @param keyDetails
   * Contains the Provider Group Association ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deleteProviderGroupAssociate(KeyVersionDetails keyDetails)
    throws AppException, InformationalException {

    curam.provider.impl.ProviderGroupAssociate providerGroupAssociate = providerGroupAssociateDAO.get(
      keyDetails.id);

    providerGroupAssociate.cancel(keyDetails.version);

  }

  // BEGIN, CR00093345, GD
  /**
   * Removes the Provider from the Provider Group.
   *
   * @param keyDetails
   * Contains the Provider Group Association ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void removeProviderFromProviderGroup(KeyVersionDetails keyDetails)
    throws AppException, InformationalException {

    curam.provider.impl.ProviderGroupAssociate providerGroupAssociate = providerGroupAssociateDAO.get(
      keyDetails.id);

    // Begin CR00096779, ABS
    providerGroupAssociate.removeProviderFromProviderGroup(
      Integer.valueOf(keyDetails.version));
    // End CR00096779

  }

  // END, CR00093345

  // BEGIN, CR00168459, SG
  /**
   * Verifies if there are any 'In Edit' or 'Issued' flat-rate or utilization
   * contracts for the provider group, on which this provider is included. If
   * there are any such contracts a warning message is returned.
   *
   * @param pgAssociateKey
   * Contains provider group associate ID.
   *
   * @return Struct containing informational message.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationalMessageList validateProviderGroupAssociateForContracts(
    ProviderGroupAssociateKey pgAssociateKey) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    InformationalMessage informationalMessage;

    curam.provider.impl.ProviderGroupAssociate providerGroupAssociate = providerGroupAssociateDAO.get(
      pgAssociateKey.providerGroupAssociateID);

    for (ContractVersion contractVersion : contractVersionDAO.searchBy(
      providerGroupAssociate.getProviderGroup())) {
      if (contractVersion.getLifecycleState().equals(CONTRACTSTATUSEntry.INEDIT)
        || contractVersion.getLifecycleState().equals(
          CONTRACTSTATUSEntry.ISSUED)) {

        for (curam.provider.impl.Provider provider : contractVersion.getProviders()) {
          if (provider.equals(providerGroupAssociate.getProvider())) {

            informationalMessage = new InformationalMessage();
            AppException appException = PROVIDERGROUPASSOCIATEExceptionCreator.INF_PROVIDERGROUPASSOCIATE_XRV_PART_OF_CONTRACT(
              providerGroupAssociate.getProvider().getName(),
              contractVersion.getName());

            informationalManager.addInformationalMsg(appException,
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kWarning);
          }
        }

        String warnings[] = informationalManager.obtainInformationalAsString();
        
        for (int i = 0; i < warnings.length; i++) {
          informationalMessage = new InformationalMessage();
          informationalMessage.messageTest = warnings[i];
          informationalMessageList.dtls.addRef(informationalMessage);
        }
      }
    }
    return informationalMessageList;
  }

  // END, CR00168459

  /**
   * Sets Provider Group Association fields for modifying the Provider Group
   * Association.
   *
   * @param providerGroupAssociate
   * Contains Provider Group Associate Object.
   * @param dtls
   * Contains the Provider Group Association details.
   */
  protected void setModifyProviderGroupAssociateFields(
    curam.provider.impl.ProviderGroupAssociate providerGroupAssociate,
    ProviderGroupAssociateDtls dtls) {

    providerGroupAssociate.setComments(dtls.comments);

    final DateRange dateRange = new DateRange(dtls.startDate, dtls.endDate);

    providerGroupAssociate.setDateRange(dateRange);

  }

  /**
   * Gets the Provider Group Association details for View.
   *
   * @param providerGroupAssociate
   * Contains Provider Group Associate object.
   *
   * @return Provider Group Association details.
   */
  protected ProviderGroupAssociateDtls getProviderGroupAssociateDetails(
    curam.provider.impl.ProviderGroupAssociate providerGroupAssociate) {

    final ProviderGroupAssociateDtls providerGroupAssociateDtls = new ProviderGroupAssociateDtls();

    providerGroupAssociateDtls.contractedAssociateInd = providerGroupAssociate.isPartOfContract();
    providerGroupAssociateDtls.endDate = providerGroupAssociate.getDateRange().end();
    providerGroupAssociateDtls.providerConcernRoleID = providerGroupAssociate.getProvider().getID();
    providerGroupAssociateDtls.providerGroupAssociateID = providerGroupAssociate.getID();
    providerGroupAssociateDtls.providerGroupConcernRoleID = providerGroupAssociate.getProviderGroup().getID();
    providerGroupAssociateDtls.recordStatus = providerGroupAssociate.getLifecycleState().getCode();
    providerGroupAssociateDtls.startDate = providerGroupAssociate.getDateRange().start();
    providerGroupAssociateDtls.versionNo = providerGroupAssociate.getVersionNo();
    providerGroupAssociateDtls.comments = providerGroupAssociate.getComments();
    return providerGroupAssociateDtls;
  }

  /**
   * Sets Provider Group Association fields for creation of Provider Group
   * Association record.
   *
   * @param providerGroupAssociate
   * Contains Provider Group Associate Object.
   * @param dtls
   * Contains the Provider Group Association details.
   */
  protected void setCreateProviderGroupAssociateFields(
    curam.provider.impl.ProviderGroupAssociate providerGroupAssociate,
    ProviderGroupAssociateDtls dtls) {

    providerGroupAssociate.setComments(dtls.comments);

    final DateRange dateRange = new DateRange(dtls.startDate, dtls.endDate);

    providerGroupAssociate.setDateRange(dateRange);

    final curam.provider.impl.Provider provider = providerDAO.get(
      dtls.providerConcernRoleID);

    providerGroupAssociate.setProvider(provider);

    final curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      dtls.providerGroupConcernRoleID);

    providerGroupAssociate.setProviderGroup(providerGroup);

  }

}
