/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.eua.facade.impl;


import com.google.inject.Inject;

import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.core.struct.ConcernRoleKey;
import curam.cpm.eua.facade.fact.ExternalParticipantFactory;
import curam.cpm.eua.facade.intf.ExternalParticipant;
import curam.cpm.eua.facade.struct.ExternalParticipantIDAppCode;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.message.impl.EXTERNALUSERSECURITYExceptionCreator;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.ProviderGroup;
import curam.provider.impl.ProviderGroupAssociate;
import curam.provider.impl.ProviderGroupAssociateDAO;
import curam.provider.impl.ProviderGroupDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;


/**
 * This process class provides the functionality for retrieving information
 * on Service Invoices for a provider/provider group.
 */
public abstract class ExternalUserSecurity extends curam.cpm.eua.facade.base.ExternalUserSecurity {

  /*
   * Inject providerGroupAssociateDAO
   */
  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;

  /*
   * Inject  providerGroupDAO
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /*
   * Inject concernRoleDAO
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Constructor
   */
  public ExternalUserSecurity() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * This method checks to see if the provider group has access to the
   * selected provider Concern Role ID
   *
   * @param externalSecurityKey - external Security Key
   *
   * @throws AppException
   * @throws InformationalException
   */
  public void checkProviderGroupSecurity(ExternalSecurityKey externalSecurityKey)
    throws AppException, InformationalException {

    // get the concernRoleID of the logged in user.
    ExternalParticipant externalParticipantObj = ExternalParticipantFactory.newInstance();

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // set the provider Organization, the logged in user may be the
    // provider, provider member, provider group, provider group member,
    // however a provider member can see all of the provider details
    // and a provider group member can see all of the provider group details
    // so only need to validate against the provider and provider group
    ExternalParticipantIDAppCode externalParticipantIDAppCode = externalParticipantObj.readProviderProviderGroupID();

    concernRoleKey.concernRoleID = externalParticipantIDAppCode.participantRoleID;
    // the logged in user can be either the provider, provider group,
    // provider member, provider group member,

    // if the logged in user is the same as the concernRoleID passed in
    // then the user has access
    if (externalSecurityKey.concernRoleKey.concernRoleID
      == externalParticipantIDAppCode.participantRoleID) {
      return;
    }

    // if the type is a provider group, then retrieve all providers for
    // the provider group,
    if (concernRoleDAO.get(concernRoleKey.concernRoleID).getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDERGROUP)) {
      ProviderGroup providerGroup = providerGroupDAO.get(
        concernRoleKey.concernRoleID);

      // get a list of the providers for this provider group.
      for (final ProviderGroupAssociate providerGroupAssociates:
        providerGroupAssociateDAO.searchByProviderGroup(providerGroup)) {

        if (providerGroupAssociates.getProvider().getID()
          == externalSecurityKey.concernRoleKey.concernRoleID) {
          // the provider concern is part of the provider group
          return;
        }
      }
    } else if (concernRoleDAO.get(concernRoleKey.concernRoleID).getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)
        && externalSecurityKey.viewProviderGroupDetailsInd == true) {

      // check if the concern details that the provider is trying to read
      // is a provider group.
      if (concernRoleDAO.get(externalSecurityKey.concernRoleKey.concernRoleID).getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDERGROUP)) {

        ProviderGroup providerGroup = providerGroupDAO.get(
          externalSecurityKey.concernRoleKey.concernRoleID);

        // get a list of the providers for this provider group.
        for (final ProviderGroupAssociate providerGroupAssociates:
          providerGroupAssociateDAO.searchByProviderGroup(providerGroup)) {

          if (providerGroupAssociates.getProvider().getID()
            == concernRoleKey.concernRoleID) {
            // the provider concern is part of the provider group
            return;
          }
        }
      }
    }

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
      EXTERNALUSERSECURITYExceptionCreator.ERR_INSUFFICIENT_PRILILEGES(),
      curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    ValidationHelper.failIfErrorsExist();

  }

}
