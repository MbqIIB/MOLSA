/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.sl.entity.impl;


import curam.codetable.ADDRESSELEMENTTYPE;
import curam.core.impl.CuramConst;
import curam.core.struct.UserNameKey;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ListProviderUserNameKey;
import curam.cpm.sl.entity.struct.ProviderGroupDtls;
import curam.cpm.sl.entity.struct.SearchProviderGroupKey;
import curam.provider.ProviderGroupStatus;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.GeneralConstants;


/**
 * This class is to set the values for entity operation.
 */

public abstract class ProviderGroup extends curam.cpm.sl.entity.base.ProviderGroup {

  // ___________________________________________________________________________
  /**
   * Pre insert method for provider group
   *
   * @param details contains ProviderGroupDtls
   */
  protected void preinsert(ProviderGroupDtls details) throws AppException, InformationalException {

    details.recordStatus = ProviderGroupStatus.ACTIVE;

  }

  // ___________________________________________________________________________
  /**
   * Pre search method for provider group
   *
   * @param key contains SearchProviderGroupKey
   */
  protected void presearchAllProviderGroup(SearchProviderGroupKey key) throws AppException, InformationalException {

    // Initialize the search parameters
    key.searchByReferenceNumber = key.referenceNumber.length() > 0;
    key.searchByName = key.name.length() > 0;
    key.searchByStreet1 = key.street1.length() > 0;
    key.searchByCity = key.city.length() > 0;
    key.addressLine1Type = ADDRESSELEMENTTYPE.LINE1;
    key.cityTypeCode = ADDRESSELEMENTTYPE.CITY;

    if (!key.name.equalsIgnoreCase(GeneralConstants.kEmpty)) {
      key.name = CuramConst.gkSqlWildcard + key.name.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

    if (!key.street1.equalsIgnoreCase(GeneralConstants.kEmpty)) {
      key.street1 = CuramConst.gkSqlWildcard + key.street1.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

    if (!key.city.equalsIgnoreCase(GeneralConstants.kEmpty)) {
      key.city = CuramConst.gkSqlWildcard + key.city.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

  }

  // ___________________________________________________________________________
  /**
   * Pre List Provider Groups for Resource Manager
   *
   * @param userNameKey contains UserNameKey
   */
  @SuppressWarnings(CPMConstants.kUnused)
  protected void prelistProviderGroupsForResourceManager(UserNameKey userNameKey) 
    throws AppException, InformationalException {// Uses default implementation
  }

  // ___________________________________________________________________________
  /**
   * Pre List Provider Groups for Resource Manager
   *
   * @param userNameKey contains ListProviderUserNameKey
   */
  protected void prelistProviderGroupsForResourceManager(
    ListProviderUserNameKey userNameKey) throws AppException,
      InformationalException {
    userNameKey.addressLine1Type = ADDRESSELEMENTTYPE.LINE1;

  }

}
