/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2010, 2013
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office 
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.impl;


/**
 * Pods constants class which has the constants used in pods.
 */
public abstract class PodsConst {

  /**
   * Constant used for representing the resource properties for my requests pod. 
   */
  public static final String kMyRequestsProperties = "cpm.widget.renderer.i18n.MyRequests";

  /**
   * Constant used for representing the my requests pod title.
   */
  public static final String kMyRequestsPodTitle = "MyRequests.Pod.Title";
  
  /**
   * Constant used for representing the my open requests pod title.
   */
  public static final String kMyOpenRequestsPodTitle = "MyRequests.Pod.Title.Open";

  /**
   * Constant used for representing the first column title of my requests pod.
   */
  public static final String kMyRequestsListCol1Title = "MyRequests.List.Col.Provider";

  /**
   * Constant used for representing the second column title of my requests pod.
   */
  public static final String kMyRequestsListCol2Title = "MyRequests.List.Col.RequestType";

  /**
   * Constant used for representing the third column title of my requests pod.
   */
  public static final String kMyRequestsListCol3Title = "MyRequests.List.Col.DateSubmitted";

  /**
   * Constant used for representing the date created column title of my requests pod.
   */
  public static final String kMyRequestsListDateCreatedTitle = "MyRequests.List.Col.DateCreated";
  
  /**
   * Constant used for representing view all link of my requests pod.
   */
  public static final String kMyRequestsPodHomePageText = "home.link.text";

  /**
   * Constant used for representing domain of date range for which details are to be retrieved.
   */
  public static final String kPodRangeDomainString = "RETURN_INVOICES_RECEIVED";

  // BEGIN, CR00386789, SS
  /**
   * Constant used for representing domain of date range.
   */
  public static final String kDATE_RANGE = "DATE_RANGE_STRING";

  // END, CR00386789

  
  /**
   * Constant used for representing my requests pod ID.
   */
  public static final String kMyRequestsPodID = "my-requests";

  /**
   * Constant used for representing my requests list ID.
   */
  public static final String kMyRequestsPodListID = "my-requests-list";
  
  /**
   * Constant used for representing my requests home page link.
   */
  public static final String kMyRequestsPodHomePageLink = "ProviderManagement_listExternalAccessRequestsForResMgrPage.do";
  
  // BEGIN, CR00270741, GP
  /**
   * Constant used for representing my recent requests home page link.
   */
  public static final String kMyRecentRequestsPodHomePageLink = "PME_listRequestsPage.do?concernRoleID=";
  // END, CR00270741
  
  /**
   * Constant used for representing submit request page link.
   */
  public static final String kSubmitRequestPageLink = "PME_submitRequestPage.do";
  
  /**
   * Constant used for representing cancel request page link.
   */
  public static final String kCancelRequestPageLink = "PME_cancelRequestPage.do";
  
  /**
   * Constant used for representing provider group home page link.
   */
  public static final String kProviderGroupHomeLink = "ProviderManagement_providerGroupHomePage.do";
  
  /**
   * Constant used for representing provider home page link.
   */
  public static final String kProviderHomeLink = "ProviderManagement_providerHomePage.do";
  
  /**
   * Constant used for representing request type page link.
   */
  public static final String kRequestTypeLink = "ProviderManagement_resolveViewExtAccRequestPage.do";
  
  /**
   * Constant used for representing request id page parameter.
   */
  public static final String var_requestID = "requestID";
  
  /**
   * Constant used for representing request category page parameter.
   */
  public static final String var_requestCategory = "requestCategory";
  
  /**
   * Constant used for representing the resource properties for my open enquiries pod. 
   */
  public static final String kMyOpenEnquiriesProperties = "cpm.widget.renderer.i18n.MyOpenEnquiries";

  /**
   * Constant used for representing the my open enquiries pod title.
   */
  public static final String kMyOpenEnquiriesPodTitle = "MyOpenEnquiries.Pod.Title";

  /**
   * Constant used for representing the first column title of my open enquiries pod.
   */
  public static final String kMyOpenEnquiriesListCol1Title = "MyOpenEnquiries.List.Col.Reference";

  /**
   * Constant used for representing the second column title of my open enquiries pod.
   */
  public static final String kMyOpenEnquiriesListCol2Title = "MyOpenEnquiries.List.Col.Name";

  /**
   * Constant used for representing the third column title of my open enquiries pod.
   */
  public static final String kMyOpenEnquiriesListCol3Title = "MyOpenEnquiries.List.Col.EnquiryDate";

  /**
   * Constant used for representing view all link of my open enquiries pod.
   */
  public static final String kMyOpenEnquiriesPodHomePageText = "home.link.text";
  
  /**
   * Constant used for representing my open enquiries pod ID.
   */
  public static final String kMyOpenEnquiriesPodID = "my-open-enquiries";

  /**
   * Constant used for representing my open enquiries list ID.
   */
  public static final String kMyOpenEnquiriesPodListID = "my-open-enquiries-list";
  
  /**
   * Constant used for representing enquiries list page link.
   */
  public static final String kMyEnquiriesListPageLink = "ProviderManagement_listEnquiriesForResourceManagerPage.do";
  
  /**
   * Constant used for representing view enquiry page link.
   */
  public static final String kViewEnquiryPageLink = "ProviderManagement_viewProviderEnquiryPage.do";
  
  /**
   * Constant used for representing provider enquiry ID page parameter.
   */
  public static final String var_providerEnquiryID = "providerEnquiryID";
  
  /**
   * Constant used for representing the resource properties for pending home studies pod. 
   */
  public static final String kPendingHomeStudiesProperties = "cpm.widget.renderer.i18n.PendingHomeStudies";

  /**
   * Constant used for representing the pending home studies pod title.
   */
  public static final String kPendingHomeStudiesPodTitle = "PendingHomeStudies.Pod.Title";

  /**
   * Constant used for representing the first column title of pending home studies pod.
   */
  public static final String kPendingHomeStudiesListCol1Title = "PendingHomeStudies.List.Col.Provider";

  /**
   * Constant used for representing the second column title of pending home studies pod.
   */
  public static final String kPendingHomeStudiesListCol2Title = "PendingHomeStudies.List.Col.Type";

  /**
   * Constant used for representing the third column title of pending home studies pod.
   */
  public static final String kPendingHomeStudiesListCol3Title = "PendingHomeStudies.List.Col.DateInitiated";

  /**
   * Constant used for representing pending home studies pod ID.
   */
  public static final String kPendingHomeStudiesPodID = "pending-home-studies";

  /**
   * Constant used for representing pending home studies list ID.
   */
  public static final String kPendingHomeStudiesPodListID = "pending-home-studies-list";
  
  /**
   * Constant used for representing the resource properties for reservations pod. 
   */
  public static final String kReservationsProperties = "cpm.widget.renderer.i18n.Reservations";

  /**
   * Constant used for representing the reservations pod title.
   */
  public static final String kReservationsPodTitle = "Reservations.Pod.Title";

  /**
   * Constant used for representing the first column title of reservations pod.
   */
  public static final String kReservationsListCol1Title = "Reservations.List.Col.Client";

  /**
   * Constant used for representing the second column title of reservations pod.
   */
  public static final String kReservationsListCol2Title = "Reservations.List.Col.Provider";

  /**
   * Constant used for representing the third column title of reservations pod.
   */
  public static final String kReservationsListCol3Title = "Reservations.List.Col.From";

  /**
   * Constant used for representing reservations pod ID.
   */
  public static final String kReservationsPodID = "reservations";

  /**
   * Constant used for representing reservations list ID.
   */
  public static final String kReservationsPodListID = "reservations-list";

  /**
   * Constant used for representing the column title service of reservations pod.
   */
  public static final String kReservationsListColServiceTitle = "Reservations.List.Col.Service";
  
  /**
   * Constant used for representing confirm reservations page link.
   */
  public static final String kReservationsConfirmPageLink = "ProviderManagement_modifyResPeriodDuringConfirmationPage.do";
  
  /**
   * Constant used for representing remove reservation page link.
   */
  public static final String kReservationsRemovePageLink = "ProviderManagement_cancelReservationPage.do";
  
  /**
   * Constant used for representing page context description page parameter.
   */
  public static final String var_pageContextDescription = "pageContextDescription";
 
  /**
   * Constant used for representing reservation ID page parameter.
   */
  public static final String var_reservationID = "reservationID";
  
  /**
   * Constant used for representing version number page parameter.
   */
  public static final String var_versionNo = "versionNo";
  
  /**
   * Constant used for representing domain of future date range for which details are to be retrieved.
   */
  public static final String kPodWeeklyFutureRangeDomainString = "WEEKLY_FUTURE_RANGE";
  
  /**
   * Constant used for representing the resource properties for service invoices pod. 
   */
  public static final String kServiceInvoicesProperties = "cpm.widget.renderer.i18n.ServiceInvoices";

  /**
   * Constant used for representing the service invoices pod title.
   */
  public static final String kServiceInvoicesPodTitle = "ServiceInvoices.Pod.Title";

  /**
   * Constant used for representing the first column title of service invoices pod.
   */
  public static final String kServiceInvoicesListCol1Title = "ServiceInvoices.List.Col.Reference";

  /**
   * Constant used for representing the second column title of service invoices pod.
   */
  public static final String kServiceInvoicesListCol2Title = "ServiceInvoices.List.Col.Originator";

  /**
   * Constant used for representing the third column title of service invoices pod.
   */
  public static final String kServiceInvoicesListCol3Title = "ServiceInvoices.List.Col.ReceiptDate";

  /**
   * Constant used for representing service invoices pod ID.
   */
  public static final String kServiceInvoicesPodID = "service-invoices";

  /**
   * Constant used for representing service invoices list ID.
   */
  public static final String kServiceInvoicesPodListID = "service-invoices-list";
  
  /**
   * Constant used for representing view all link of service invoices pod.
   */
  public static final String kServiceInvoicesHomePageText = "home.link.text";
  
  /**
   * Constant used for representing search service invoices page link.
   */
  public static final String kSearchServiceInvoicesPageLink = "ProviderManagement_searchServiceInvoicePage.do";
  
  /**
   * Constant used for representing view service invoice page link.
   */
  public static final String kViewServiceInvoicePageLink = "ProviderManagement_viewServiceInvoicePage.do";
  
  /**
   * Constant used for representing service invoice id page parameter.
   */
  public static final String var_serviceInvoiceID = "serviceInvoiceID";
  
  /**
   * Constant used for representing the resource properties for rosters due for submission pod. 
   */
  public static final String kRostersDueForSubmissionProperties = "cpm.widget.renderer.i18n.RostersDueForSubmission";

  /**
   * Constant used for representing the rosters due for submission pod title.
   */
  public static final String kRostersDueForSubmissionPodTitle = "RostersDueForSubmission.Pod.Title";

  /**
   * Constant used for representing the first column title of rosters due for submission pod.
   */
  public static final String kRostersDueForSubmissionListCol1Title = "RostersDueForSubmission.List.Col.Period";

  /**
   * Constant used for representing the second column title of rosters due for submission pod.
   */
  public static final String kRostersDueForSubmissionListCol2Title = "RostersDueForSubmission.List.Col.Service";

  /**
   * Constant used for representing the third column title of rosters due for submission pod.
   */
  public static final String kRostersDueForSubmissionListCol3Title = "RostersDueForSubmission.List.Col.DueOn";

  /**
   * Constant used for representing view all link of rosters due for submission pod.
   */
  public static final String kRostersDueForSubmissionPodHomePageText = "home.link.text";

  /**
   * Constant used for representing rosters due for submission list ID.
   */
  public static final String kRostersDueForSubmissionPodListID = "rosters-due-for-submission";
  
  /**
   * Constant used for representing list roster for external provider page link.
   */
  // BEGIN, CR00261914, ASN
  public static final String kListRosterPageLink = "PME_listRosterPage.do?concernRoleID=";

  // END, CR00261914
  /**
   * Constant used for representing the resource properties for wait list entries pod. 
   */
  public static final String kWaitListEntriesProperties = "cpm.widget.renderer.i18n.WaitListEntries";

  /**
   * Constant used for representing the wait list entries pod title.
   */
  public static final String kWaitListEntriesPodTitle = "WaitListEntries.Pod.Title";

  /**
   * Constant used for representing the first column title of wait list entries pod.
   */
  public static final String kWaitListEntriesListCol1Title = "WaitListEntries.List.Col.Client";

  /**
   * Constant used for representing the second column title of wait list entries pod.
   */
  public static final String kWaitListEntriesListCol2Title = "WaitListEntries.List.Col.Resource";

  /**
   * Constant used for representing the third column title of wait list entries pod.
   */
  public static final String kWaitListEntriesListCol3Title = "WaitListEntries.List.Col.ReviewDate";

  /**
   * Constant used for representing wait list entries pod ID.
   */
  public static final String kWaitListEntriesPodID = "waitlistentries";

  /**
   * Constant used for representing wait list entries list ID.
   */
  public static final String kWaitListEntriesPodListID = "waitlistentries-list";

  /**
   * Constant used for representing view provider wait list page link.
   */
  public static final String kProviderWaitListPageLink = "ProviderManagement_listWaitListEntryForProviderPage.do";
  
  /**
   * Constant used for representing home study list page link.
   */
  public static final String kHomeStudyListLink = "HomeStudy_listHomeStudiesPage.do";
  
  /**
   * Constant used for representing provider wait list entry page link.
   */
  public static final String kProviderWaitListLink = "ProviderManagement_listWaitListEntryForProviderPage.do";

  /**
   * Constant used for representing provider reservations list page link.
   */
  public static final String kProviderReservationListLink = "ProviderManagement_listReservationPage.do";
  
  // BEGIN, CR00280874, GP
  /**
   * Constant used for representing view all link of wait list entries pod.
   */
  public static final String kWaitListEntriesPodHomePageText = "home.link.text";
  
  /**
   * Constant used for representing recent wait list entries due for review page link.
   */
  public static final String kRecentWaitListEntriesPageLink = "ProviderManagement_listRecentWaitListEntryDueForReviewPage.do";
  // END, CR00280874
}
