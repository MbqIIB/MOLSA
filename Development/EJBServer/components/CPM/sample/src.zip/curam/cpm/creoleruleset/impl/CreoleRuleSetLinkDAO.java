/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.creoleruleset.impl;


import java.util.List;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.CREOLERULESETTYPEEntry;
import curam.codetable.impl.RELATEDTYPEEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;
import curam.util.type.DateRange;


/**
 * Data access for {@linkplain curam.cpm.creoleruleset.impl.CreoleRuleSetLink}.
 */
@ImplementedBy(CreoleRuleSetLinkDAOImpl.class)
public interface CreoleRuleSetLinkDAO extends StandardDAO<CreoleRuleSetLink> {

  /**
   * Searches based on related ID, related type,rule set type and date range.
   *
   * @param relatedID
   * The related ID.
   * @param relatedType
   * The related type.
   * @param type
   * The rule set type.
   * @param dateRange
   * The association life time.
   *
   * @return List of associated creole rule set.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  List<CreoleRuleSetLink> searchBy(final long relatedID,
    final RELATEDTYPEEntry relatedType, final CREOLERULESETTYPEEntry type,
    final DateRange dateRange) throws AppException, InformationalException;

  /**
   * Reads data store using creole rule set link.
   *
   * @param creoleRuleSetLink
   * The creole rule set link using which data store will be retrieved.
   *
   * @return The creole rule set link details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  CreoleRuleSetLink readDataStoreByRuleID(
    final CreoleRuleSetLink creoleRuleSetLink) throws AppException,
      InformationalException;

  /**
   * Gets the rule set configuration for a service offering.
   *
   * @param serviceOffering
   * The service offering using which rule set configuration details
   * will be retrieved.
   * @param type
   * The rule set type.
   *
   * @return The details of rule set configuration.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  CreoleRuleSetLink readByServiceOfferingAndRuleSetType(
    final ServiceOffering serviceOffering, final CREOLERULESETTYPEEntry type)
    throws AppException, InformationalException;
}
