/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 - 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import com.google.inject.Inject;

import curam.core.struct.ConcernRoleKey;
import curam.cpm.facade.struct.ContextDescriptionDetails;
import curam.cpm.facade.struct.HomeStudyKey;
import curam.cpm.facade.struct.ProviderKey;
import curam.cpm.facade.struct.ViewProviderSummaryDetails;
import curam.homestudy.impl.HomeStudyDAO;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.ProviderDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.GeneralConstants;


/**
 * Gives the Home study pages access to a context description.
 */
// Start CR00096126, JSP
public abstract class ContextDescription extends curam.cpm.facade.base.ContextDescription {
  // End CR00096126
  /**
   * Inject ProviderDAO
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Inject HomeStudyDAO
   */
  @Inject
  protected HomeStudyDAO homeStudyDAO;
  
  /**
   * Inject ConcernRoleDAO
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;
  
  /**
   * Constructor
   */
  public ContextDescription() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  // ___________________________________________________________________________
  /**
   * This method to determines the context description for provider pages
   *
   * @param key
   * The provider key holding the providerID
   *
   * @return Context description containing the context description
   * @throws InformationalException 
   *
   * @throws AppException 
   */
  public ContextDescriptionDetails getContextDescription(ProviderKey key)
    throws AppException, InformationalException {
    ContextDescriptionDetails contextDescriptionDetails = new ContextDescriptionDetails();

    // creating viewProviderSummaryDetails struct
    ViewProviderSummaryDetails viewProviderSummaryDetails = new ViewProviderSummaryDetails();

    // Provider Entity
    final curam.provider.impl.Provider provider = providerDAO.get(
      key.providerID);

    // Get the Provider Reference Number
    String refNumber = provider.getPrimaryAlternateID();

    // Set the summary details
    viewProviderSummaryDetails.details.concernRoleID = key.providerID;
    viewProviderSummaryDetails.details.providerName = provider.getName();
    viewProviderSummaryDetails.details.referenceNumber = refNumber;

    // construct the page context description
    viewProviderSummaryDetails.pageContextDescription = provider.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + refNumber;
    contextDescriptionDetails.description = viewProviderSummaryDetails.details.providerName
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace
      + viewProviderSummaryDetails.details.referenceNumber;

    return contextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method to determines the context description for provider pages
   *
   * @param key
   * The provider key holding the providerID
   *
   * @return Context description containing the context description
   * @throws InformationalException
   *
   * @throws AppException
   */
  public ContextDescriptionDetails getContextDescriptionFromHomeStudyKey(
    HomeStudyKey key) throws AppException, InformationalException {
    ContextDescriptionDetails contextDescriptionDetails = new ContextDescriptionDetails();

    // creating viewProviderSummaryDetails struct
    ViewProviderSummaryDetails viewProviderSummaryDetails = new ViewProviderSummaryDetails();

    // Provider Entity
    curam.provider.impl.Provider provider = homeStudyDAO.get(key.key.homeStudyID).getProvider();

    // Get the Provider Reference Number
    String refNumber = provider.getPrimaryAlternateID();

    // Set the summary details
    viewProviderSummaryDetails.details.concernRoleID = provider.getID();
    viewProviderSummaryDetails.details.providerName = provider.getName();
    viewProviderSummaryDetails.details.referenceNumber = refNumber;

    // construct the page context description
    viewProviderSummaryDetails.pageContextDescription = provider.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + refNumber;
    contextDescriptionDetails.description = viewProviderSummaryDetails.details.providerName
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace
      + viewProviderSummaryDetails.details.referenceNumber;

    return contextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method to determines the context description for a concern
   *
   * @param key - contains the concern Role ID
   *
   * @return Context description containing the context description
   *
   * @throws InformationalException
   *
   * @throws AppException
   */
  public ContextDescriptionDetails getContextDescriptionForConcern(
    ConcernRoleKey key) throws AppException, InformationalException {
    
    final ConcernRole concernRole = concernRoleDAO.get(key.concernRoleID);
    
    ContextDescriptionDetails contextDescriptionDetails = new ContextDescriptionDetails();
    
    contextDescriptionDetails.description = concernRole.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + concernRole.getPrimaryAlternateID();
    
    return contextDescriptionDetails;
  }

}
