/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.sl.entity.impl;


import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ProviderSpecialtyDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * */
public abstract class ProviderSpecialty extends curam.cpm.sl.entity.base.ProviderSpecialty {

  /**
   * @param arg0 provider key
   * @return ProviderSpecialtyDtls
   * @throws InformationalException
   * @throws AppException
   */
  @SuppressWarnings(CPMConstants.kUnused)
  public ProviderSpecialtyDtls listSpecialtiesByProvider(final ProviderKey arg0)
    throws AppException, InformationalException {

    return null;
  }

}
