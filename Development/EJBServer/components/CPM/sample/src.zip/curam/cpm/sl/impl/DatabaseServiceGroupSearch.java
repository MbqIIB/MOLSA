/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.sl.impl;


import com.google.inject.Inject;
import curam.cpm.sl.entity.struct.SearchServiceGroupKey;
import curam.cpm.sl.entity.struct.ServiceGroupDtls;
import curam.cpm.sl.struct.SearchServiceGroupResults;
import curam.message.impl.SERVICEOFFERINGExceptionCreator;
import curam.serviceoffering.impl.ServiceGroup;
import curam.serviceoffering.impl.ServiceGroupDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.type.StringHelper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;


/**
 * Database search implementation class for service group search.
 *
 */
public class DatabaseServiceGroupSearch extends curam.cpm.sl.base.DatabaseServiceGroupSearch {

  /**
   * Service Group DAO
   */
  @Inject
  protected ServiceGroupDAO serviceGroupDAO;

  /**
   * Constructor
   */
  public DatabaseServiceGroupSearch() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * Performs a database search for service groups using the specified search
   * criteria.
   *
   * @param serviceGroupKey
   * Contains the data on which the searched will be performed.
   *
   * @return The service group search results.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchServiceGroupResults search(SearchServiceGroupKey serviceGroupKey)
    throws AppException, InformationalException {

    SearchServiceGroupResults searchServiceGroupResults = new SearchServiceGroupResults();

    // If search criteria is empty
    if (StringHelper.isEmpty(serviceGroupKey.reference)
      && StringHelper.isEmpty(serviceGroupKey.name)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEOFFERINGExceptionCreator.ERR_SERVICEROFFERING_XRV_MUST_SPECIFY_SEARCH_CRITERIA(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
      ValidationHelper.failIfErrorsExist();

    } else {
      final List<curam.serviceoffering.impl.ServiceGroup> serviceGroups = sortServiceGroups(
        serviceGroupDAO.searchByNameAndReference(serviceGroupKey.name,
        serviceGroupKey.reference));

      for (final curam.serviceoffering.impl.ServiceGroup serviceGroup : serviceGroups) {
        searchServiceGroupResults.dtlsList.dtls.addRef(
          getServiceGroupFields(serviceGroup));
      }
    }

    return searchServiceGroupResults;
  }

  /**
   * Maps the fields on the service layer to those presented to the user on the
   * screen.
   *
   * @param serviceGroup
   * The service layer object from which the user-displayable fields
   * must be mapped.
   * @return ServiceGroupDtls The service group details.
   */
  protected ServiceGroupDtls getServiceGroupFields(final ServiceGroup serviceGroup) {
    final ServiceGroupDtls serviceGroupDtls = new ServiceGroupDtls();

    serviceGroupDtls.serviceGroupID = serviceGroup.getID();
    serviceGroupDtls.name = serviceGroup.getName();
    serviceGroupDtls.reference = serviceGroup.getReference();
    serviceGroupDtls.comments = serviceGroup.getComments();
    serviceGroupDtls.description = serviceGroup.getDescription();
    serviceGroupDtls.recordStatus = serviceGroup.getLifecycleState().getCode();
    serviceGroupDtls.versionNo = serviceGroup.getVersionNo();
    ServiceGroup parentServiceGroup = serviceGroup.getParentServiceGroup();

    if (parentServiceGroup != null) {
      serviceGroupDtls.parentServiceGroupID = parentServiceGroup.getID();
    }

    return serviceGroupDtls;
  }

  /**
   * Sorts a set of service groups into a sorted list for display.
   *
   * @param unsortedServiceGroups
   * The set of service groups.
   *
   * @return a sorted list of service groups for display.
   */
  protected List<curam.serviceoffering.impl.ServiceGroup> sortServiceGroups(
    final Set<curam.serviceoffering.impl.ServiceGroup> unsortedServiceGroups) {

    // Sort by name for display - using a list (instead of a set) in case there
    // are duplicate names.
    final List<curam.serviceoffering.impl.ServiceGroup> serviceGroups = new ArrayList<curam.serviceoffering.impl.ServiceGroup>(
      unsortedServiceGroups);

    Collections.sort(serviceGroups,
      new Comparator<curam.serviceoffering.impl.ServiceGroup>() {
      public int compare(final curam.serviceoffering.impl.ServiceGroup lhs,
        curam.serviceoffering.impl.ServiceGroup rhs) {
        return lhs.getName().compareTo(rhs.getName());
      }
    });
    return serviceGroups;
  }
}
