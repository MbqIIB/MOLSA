/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedHashMap;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import net.fortuna.ical4j.model.Dur;
import net.fortuna.ical4j.model.Period;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import com.google.inject.Inject;
import curam.codetable.TIMEOFDAY;
import curam.codetable.impl.PROVIDERENQUIRYRESPONSEEntry;
import curam.codetable.impl.SERVICEDELENQUIRYMETHODEntry;
import curam.codetable.impl.TIMEOFDAYEntry;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.cpm.facade.struct.ProviderServiceEnquiriesSummaryDetails;
import curam.cpm.facade.struct.ServiceEnquiryCancelKey;
import curam.cpm.facade.struct.ServiceEnquiryCommentDetails;
import curam.cpm.facade.struct.ServiceEnquiryDetails;
import curam.cpm.facade.struct.ServiceEnquiryListDetails;
import curam.cpm.facade.struct.ServiceEnquiryListDetailsList;
import curam.cpm.facade.struct.ServiceEnquiryResponse;
import curam.cpm.facade.struct.ServiceEnquiryResponseDetails;
import curam.cpm.facade.struct.ServiceEnquiryResponseList;
import curam.cpm.facade.struct.ServiceEnquiryViewDetails;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.struct.ServiceDeliveryKey;
import curam.cpm.sl.struct.ServiceEnquiryKey;
import curam.cpm.util.impl.EmailUtility;
import curam.cpm.util.impl.ServiceEnquiryFacadeUtil;
import curam.message.SERVICEENQUIRY;
import curam.message.impl.SERVICEENQUIRYEMAILExceptionCreator;
import curam.piwrapper.impl.EmailAddress;
import curam.piwrapper.impl.EmailAddressDAO;
import curam.piwrapper.organization.impl.OrganisationDAO;
import curam.piwrapper.user.impl.ExternalUserParticipantLink;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.servicedelivery.impl.ServiceDelivery;
import curam.servicedelivery.impl.ServiceDeliveryDAO;
import curam.serviceenquiry.impl.ServiceEnquiryDAO;
import curam.serviceoffering.impl.PROVIDERANDTYPESELECTIONEntry;
import curam.serviceoffering.impl.ServiceDeliveryConfigurationAccessor;
import curam.serviceoffering.impl.ServiceOfferingSecurity;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringHelper;


/**
 * Facade class for Service Enquiry maintenance.
 */
public class ServiceEnquiry extends curam.cpm.facade.base.ServiceEnquiry {

  /**
   * Reference to Provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to Service Enquiry DAO.
   */
  @Inject
  protected ServiceEnquiryDAO serviceEnquiryDAO;

  /**
   * Reference to Service Delivery DAO.
   */
  @Inject
  protected ServiceDeliveryDAO serviceDeliveryDAO;

  /**
   * Reference to Email Address DAO.
   */
  @Inject
  protected EmailAddressDAO emailAddressDAO;

  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;

  /**
   * Reference to Organization DAO.
   */
  @Inject
  protected OrganisationDAO organisationDAO;

  /**
   * Reference to Service Enquiry facade util helper instance.
   */
  @Inject
  protected com.google.inject.Provider<ServiceEnquiryFacadeUtil> serviceEnquiryFacadeUtilProvider;
  
  /**
   * Reference to Service Offering Security instance.
   */
  @Inject
  protected ServiceOfferingSecurity serviceOfferingSecurity;

  /**
   * Reference to Email Utility instance.
   */
  @Inject
  protected com.google.inject.Provider<EmailUtility> emailUtilityProvider;

  /**
   * Constructor.
   */
  protected ServiceEnquiry() {
    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryKey createEmailEnquiry(
    final ServiceEnquiryDetails details) throws AppException,
      InformationalException {
    ServiceEnquiryKey serviceEnquiryKey = new ServiceEnquiryKey();

    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.newInstance();

    serviceEnquiry.setEnquiryMethod(SERVICEDELENQUIRYMETHODEntry.EMAIL);
    serviceEnquiryKey.serviceEnquiryID = createServiceEnquiry(details,
      serviceEnquiry);

    if (0 != serviceEnquiry.getProvider().getPrimaryEmailAddressID()) {
      buildAndSendNewServiceEnquiryEmail(details, serviceEnquiry);
    }
    return serviceEnquiryKey;
  }

  /**
   * Constructs an email message for the new service enquiry and sends the email
   * to the providers email address.
   *
   * @param details
   * details of the service enquiry
   * @param serviceEnquiry
   * object instance of the newly created service enquiry
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  protected void buildAndSendNewServiceEnquiryEmail(
    final ServiceEnquiryDetails details,
    final curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry)
    throws AppException, InformationalException {

    String caseWorkerUserFullname = userDAO.get(TransactionInfo.getProgramUser()).getFullName();
    EmailAddress emailAddress = emailAddressDAO.get(
      serviceEnquiry.getProvider().getPrimaryEmailAddressID());

    ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      details.dtls.serviceDeliveryID);

    // view service security check
    serviceOfferingSecurity.checkViewRights(
      serviceDelivery.getServiceOffering());
    
    String emailSubject = SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_EMAIL_SUBJECT(serviceDelivery.getServiceOffering().getName()).getLocalizedMessage();

    StringBuffer emailBody = new StringBuffer();

    if (!StringHelper.isEmpty(details.dtls.frequency)) {
      if (!StringHelper.isEmpty(details.dtls.timeOfDay)) {
        emailBody.append(
          SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_LINE_ONE_WITH_FREQUENCY_TIME_OF_DAY(caseWorkerUserFullname, organisationDAO.get().getName(), serviceDelivery.getServiceOffering().getName(), serviceDelivery.listCaseParticipantRoles().size(), details.dtls.frequency, CodeTable.getOneItemForUserLocale(TIMEOFDAY.TABLENAME, details.dtls.timeOfDay), details.dtls.fromDate).getLocalizedMessage());
        if (!details.dtls.toDate.isZero()) {
          emailBody.append(
            SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_TO_DATE(details.dtls.toDate).getLocalizedMessage());
        }
        emailBody.append(curam.servicedelivery.impl.CuramConst.gkSkipOneLine);
      } else {
        emailBody.append(
          SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_LINE_ONE_FREQUENCY__NO_TIME_OF_DAY(caseWorkerUserFullname, organisationDAO.get().getName(), serviceDelivery.getServiceOffering().getName(), serviceDelivery.listCaseParticipantRoles().size(), details.dtls.frequency, details.dtls.fromDate).getLocalizedMessage());
        if (!details.dtls.toDate.isZero()) {
          emailBody.append(
            SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_TO_DATE(details.dtls.toDate).getLocalizedMessage());
        }
        emailBody.append(curam.servicedelivery.impl.CuramConst.gkSkipOneLine);
      }
    } else {
      if ((!StringHelper.isEmpty(details.dtls.timeOfDay))
        && (!(TIMEOFDAYEntry.get(details.dtls.timeOfDay).equals(
          TIMEOFDAYEntry.ALL)))) {
        emailBody.append(
          SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_LINE_ONE_NO_FREQUENCY_TIME_OF_DAY(caseWorkerUserFullname, organisationDAO.get().getName(), serviceDelivery.getServiceOffering().getName(), serviceDelivery.listCaseParticipantRoles().size(), CodeTable.getOneItemForUserLocale(TIMEOFDAY.TABLENAME, details.dtls.timeOfDay), details.dtls.fromDate).getLocalizedMessage());
        if (!details.dtls.toDate.isZero()) {
          emailBody.append(
            SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_TO_DATE(details.dtls.toDate).getLocalizedMessage());
        }
        emailBody.append(curam.servicedelivery.impl.CuramConst.gkSkipOneLine);
      } else {
        emailBody.append(
          SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_LINE_ONE_NO_FREQUENCY_NO_TIME_OF_DAY(caseWorkerUserFullname, organisationDAO.get().getName(), serviceDelivery.getServiceOffering().getName(), serviceDelivery.listCaseParticipantRoles().size(), details.dtls.fromDate).getLocalizedMessage());
        if (!details.dtls.toDate.isZero()) {
          emailBody.append(
            SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_TO_DATE(details.dtls.toDate).getLocalizedMessage());
        }
        emailBody.append(curam.servicedelivery.impl.CuramConst.gkSkipOneLine);
      }
    }

    if (details.dtls.urgencyInd) {
      emailBody.append(
        SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_LINE_TWO().getLocalizedMessage()
          + curam.servicedelivery.impl.CuramConst.gkSkipOneLine);
    }

    // Removed the link to the application from the email

    // ExternalUserParticipantLink externalUserParticipantLink =
    // serviceEnquiryFacadeUtilProvider
    // .get().getproviderExternalLink(serviceEnquiry.getProvider());

    // if (null == externalUserParticipantLink) {
    // // add the request portal access details
    // emailBody.append(SERVICEENQUIRYEMAILExceptionCreator
    // .INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_REQUEST_ACCESS_LINE_ONE(
    // serviceEnquiryFacadeUtilProvider.get().buildRequestAccessLink())
    // .getLocalizedMessage()
    // + curam.servicedelivery.impl.CuramConst.gkSkipOneLine
    // + SERVICEENQUIRYEMAILExceptionCreator
    // .INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_REQUEST_ACCESS_LINE_TWO(
    // serviceEnquiryFacadeUtilProvider.get().buildProviderViewLink(
    // serviceEnquiryFacadeUtilProvider.get()
    // .getServiceEnquiryProviderViewLink(serviceEnquiry)))
    // .getLocalizedMessage());
    // } else {
    // emailBody.append(SERVICEENQUIRYEMAILExceptionCreator
    // .INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_LINE_THREE(
    // serviceEnquiryFacadeUtilProvider.get().buildProviderViewLink(
    // serviceEnquiryFacadeUtilProvider.get()
    // .getServiceEnquiryProviderViewLink(serviceEnquiry)))
    // .getLocalizedMessage());
    // }

    sendEmail(serviceEnquiry, emailAddress, emailSubject, emailBody);
  }

  /**
   * Determine if email notifications are to be sent, and send them if
   * appropriate.
   *
   * @param serviceEnquiry
   * @param emailAddress
   * @param emailSubject
   * @param emailBody
   * @throws InformationalException
   * @throws AppException
   */
  protected void sendEmail(
    final curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry,
    final EmailAddress emailAddress, final String emailSubject,
    final StringBuffer emailBody) throws AppException, InformationalException {
    // determine if an email notifications are to be sent
    if (!emailUtilityProvider.get().determineSendEmail(
      EnvVars.ENV_SERVICE_ENQUIRY_SEND_PROVIDER_EMAIL_NOTIFICATIONS,
      EnvVars.ENV_SERVICE_ENQUIRY_SEND_PROVIDER_EMAIL_NOTIFICATIONS_DEFAULT)) {
      return;
    }

    emailUtilityProvider.get().sendEmail(
      emailUtilityProvider.get().getSMTPMessage(emailSubject,
      emailBody.toString(), emailAddress.getEmail()),
      serviceEnquiry.getProvider().getName());
  }

  /**
   * Constructs an email message for the service enquiry which the case worker
   * has updated and sends the email to the providers email address.
   *
   * @param serviceEnquiry
   * object instance of the updated service enquiry
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  protected void buildAndSendServiceEnquiryUpdatedEmail(
    final curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry)
    throws AppException, InformationalException {

    EmailAddress emailAddress = emailAddressDAO.get(
      serviceEnquiry.getProvider().getPrimaryEmailAddressID());

    ExternalUserParticipantLink externalUserParticipantLink = serviceEnquiryFacadeUtilProvider.get().getproviderExternalLink(
      serviceEnquiry.getProvider());

    String caseWorkerUserFullname = userDAO.get(TransactionInfo.getProgramUser()).getFullName();

    String emailSubject = SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY__RESPONSE_EMAIL_SUBJECT(serviceEnquiry.getServiceOffering().getName()).getLocalizedMessage();

    StringBuffer emailBody = new StringBuffer();

    if (null == externalUserParticipantLink) {
      // add the request portal access details
      emailBody.append(
        SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_NOTIFICATION_EMAIL_REQUEST_ACCESS_LINE_ONE(serviceEnquiryFacadeUtilProvider.get().buildRequestAccessLink()).getLocalizedMessage()
          + curam.servicedelivery.impl.CuramConst.gkSkipOneLine);
    }

    emailBody.append(
      SERVICEENQUIRYEMAILExceptionCreator.INF_SERVICE_ENQUIRY_CASE_WORKER_RESPONSE_EMAIL_BODY(caseWorkerUserFullname, organisationDAO.get().getName(), serviceEnquiry.getServiceOffering().getName()).getLocalizedMessage());

    sendEmail(serviceEnquiry, emailAddress, emailSubject, emailBody);
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryKey createMailEnquiry(final ServiceEnquiryDetails details)
    throws AppException, InformationalException {
    ServiceEnquiryKey serviceEnquiryKey = new ServiceEnquiryKey();
    // TODO: (JG) generate document and queue for printing via batch job
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.newInstance();

    serviceEnquiry.setEnquiryMethod(SERVICEDELENQUIRYMETHODEntry.POST);
    serviceEnquiryKey.serviceEnquiryID = createServiceEnquiry(details,
      serviceEnquiry);
    return serviceEnquiryKey;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryKey createPhoneEnquiry(
    final ServiceEnquiryDetails details) throws AppException,
      InformationalException {
    ServiceEnquiryKey serviceEnquiryKey = new ServiceEnquiryKey();

    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.newInstance();

    serviceEnquiry.setCreationDateTime(details.dtls.creationDateTime);
    serviceEnquiry.setProviderResponse(
      PROVIDERENQUIRYRESPONSEEntry.get(details.dtls.providerResponse));
    serviceEnquiry.setEnquiryMethod(SERVICEDELENQUIRYMETHODEntry.PHONE);
    serviceEnquiryKey.serviceEnquiryID = createServiceEnquiry(details,
      serviceEnquiry);
    return serviceEnquiryKey;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryKey createWebEnquiry(final ServiceEnquiryDetails details)
    throws AppException, InformationalException {

    ServiceEnquiryKey serviceEnquiryKey = new ServiceEnquiryKey();
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.newInstance();

    serviceEnquiry.setEnquiryMethod(SERVICEDELENQUIRYMETHODEntry.WEB);
    serviceEnquiryKey.serviceEnquiryID = createServiceEnquiry(details,
      serviceEnquiry);
    if (0 != serviceEnquiry.getProvider().getPrimaryEmailAddressID()) {
      buildAndSendNewServiceEnquiryEmail(details, serviceEnquiry);
    }
    return serviceEnquiryKey;
  }

  /**
   * Creates an {@link ServiceEnquiry} of the specified type.
   *
   * @param details
   * details of the service enquiry
   * @param serviceEnquiry
   * object instance of the {@link ServiceEnquiry} to insert
   * @return unique identifier of the newly created {@link ServiceEnquiry}
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  protected long createServiceEnquiry(final ServiceEnquiryDetails details,
    final curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry)
    throws AppException, InformationalException {

    if (details.dtls.creationDateTime.isZero()) {
      serviceEnquiry.setCreationDateTime(DateTime.getCurrentDateTime());
    }
    serviceEnquiry.setFromDate(details.dtls.fromDate);
    serviceEnquiry.setToDate(details.dtls.toDate);
    serviceEnquiry.setFrequency(details.dtls.frequency);
    serviceEnquiry.setNote(details.comments);
    serviceEnquiry.setProvider(
      providerDAO.get(details.dtls.providerConcernRoleID));
    serviceEnquiry.setServiceDelivery(
      serviceDeliveryDAO.get(details.dtls.serviceDeliveryID));
    serviceEnquiry.setTimeOfDay(TIMEOFDAYEntry.get(details.dtls.timeOfDay));

    serviceEnquiry.insert();

    return serviceEnquiry.getID();
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryListDetailsList listProviderEnquiries(
    final ProviderConcernRoleKey key) {
    Provider provider = providerDAO.get(key.providerConcernRoleID);
    List<curam.serviceenquiry.impl.ServiceEnquiry> serviceEnquiries = serviceEnquiryDAO.searchActiveServiceEnquiriesForProvider(
      provider);

    return serviceEnquiryFacadeUtilProvider.get().assignServiceEnquiryListDetails(
      serviceEnquiries);
  }

  /**
   * Calculates the percentage of service enquiries which the provider has
   * responded to.
   *
   * @param allServiceEnquiriesForProvider
   * list of service enquiries objects for the provider
   * @return percentage of enquiries responded to
   */
  protected int calculatePercentageResponses(
    final List<curam.serviceenquiry.impl.ServiceEnquiry> allServiceEnquiriesForProvider) {

    if (0 == allServiceEnquiriesForProvider.size()) {
      return 0;
    }
    int enquiriesWithResponse = allServiceEnquiriesForProvider.size();

    for (curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry : allServiceEnquiriesForProvider) {
      if ((serviceEnquiry.getProviderResponse().equals(
        PROVIDERENQUIRYRESPONSEEntry.PENDING))
          || (serviceEnquiry.getProviderResponse().equals(
            PROVIDERENQUIRYRESPONSEEntry.NORESPONSERECEIVED))) {
        enquiriesWithResponse--;
      }
    }
    return (enquiriesWithResponse * CuramConst.gkOneHundredPercent)
      / allServiceEnquiriesForProvider.size();
  }

  /**
   * Calculates the average response time in hours for all web-based
   * {@link ServiceEnquiry} records for a provider.
   *
   * @param webServiceEnquiries
   * list of web-based {@link ServiceEnquiry} records
   * @return average response time in minutes
   */
  protected double calculateAverageResponseHours(
    final List<curam.serviceenquiry.impl.ServiceEnquiry> webServiceEnquiries) {
    int numberServiceEnquiriesWithResponse = webServiceEnquiries.size();
    long totalMinutes = 0;

    for (curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry : webServiceEnquiries) {

      DateTime creationDateTime = serviceEnquiry.getCreationDateTime();

      DateTime earliestResponseTime = determineEarliestProviderResponseTime(
        serviceEnquiry);

      if (earliestResponseTime.isZero()) {
        // no provider response for this service enquiry, exclude from average
        // response calculation
        numberServiceEnquiriesWithResponse--;
        // continue;
      } else {

        net.fortuna.ical4j.model.DateTime newCreationDateTime = new net.fortuna.ical4j.model.DateTime(
          creationDateTime.asLong());

        net.fortuna.ical4j.model.DateTime newEarliestResponseTime = new net.fortuna.ical4j.model.DateTime(
          earliestResponseTime.asLong());
        Period p = new Period(newCreationDateTime, newEarliestResponseTime);

        Dur duration = p.getDuration();
        int days = duration.getDays();
        int hours = duration.getHours();
        int minutes = duration.getMinutes();

        totalMinutes += minutes
          + (hours
            * curam.servicedelivery.impl.CuramConst.gkNumberOfMinutesInHour)
            + (days * hours
            * curam.servicedelivery.impl.CuramConst.gkNumberOfMinutesInHour);
      }
    }
    double averageResponseTimeInHours = 0;

    if (0 != numberServiceEnquiriesWithResponse) {
      // calculate the average response time of the providers enquiries
      averageResponseTimeInHours = (double) (totalMinutes
        / numberServiceEnquiriesWithResponse)
          / curam.servicedelivery.impl.CuramConst.gkNumberOfMinutesInHour;
    }
    return averageResponseTimeInHours;
  }

  /**
   * Populates the formatted phone number and sets the indicator for a phone
   * number to true.
   *
   * @param summaryDetails
   * the details to update
   * @param provider
   * instance of the provider object to read the details from
   */
  protected void populatePhoneNumber(
    final ProviderServiceEnquiriesSummaryDetails summaryDetails,
    final Provider provider) {
    if (null != provider.getPrimaryPhoneNumber()) {
      String phoneNumberString = formatPhoneNumber(
        provider.getPrimaryPhoneNumber().getCountryCode(),
        provider.getPrimaryPhoneNumber().getAreaCode(),
        provider.getPrimaryPhoneNumber().getNumber(),
        provider.getPrimaryPhoneNumber().getExtension());

      summaryDetails.phoneNumber = phoneNumberString;
    }
  }

  /**
   * Returns the earliest response time of the provider for the specified
   * {@link curam.serviceenquiry.impl.ServiceEnquiry}. If a 'No Response
   * Received' value was entered for the the provider response, it returns a
   * blank date time.
   *
   * @param serviceEnquiry
   * object instance of the
   * {@link curam.serviceenquiry.impl.ServiceEnquiry}
   * @return the earliest response time of the provider for the service enquiry,
   * or a blank date if there was no response. i.e. a provider response
   * of 'No Response Received' value was recorded or the last updated
   * time is blank.
   */
  protected DateTime determineEarliestProviderResponseTime(
    final curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry) {

    if (serviceEnquiry.getProviderResponse().equals(
      PROVIDERENQUIRYRESPONSEEntry.NORESPONSERECEIVED)) {
      return DateTime.kZeroDateTime;
    } else if (null != serviceEnquiry.getNote()) {
      DateTime earliestProviderReponseComment = determineProvidersEarliestComment(
        serviceEnquiry.getProvider(), serviceEnquiry.getNote().getNotesText());

      if ((!earliestProviderReponseComment.isZero()
        && (!serviceEnquiry.getLastUpdateDateTime().isZero()))
          && (earliestProviderReponseComment.before(
            serviceEnquiry.getLastUpdateDateTime()))) {
        return earliestProviderReponseComment;
      }
    }
    return serviceEnquiry.getLastUpdateDateTime();
  }

  /**
   * Iterates over the note text xml string, to find the earliest comment
   * entered by the provider, if any comment from the provider exists.
   *
   * @param provider
   * object instance of the {@link Provider}
   * @param notesText
   * the xml note history text
   * @return the date time of the earliest provider comment, or a blank date
   * time if no comment from the provider exists.
   */
  protected DateTime determineProvidersEarliestComment(final Provider provider,
    final String notesText) {

    DateTime earliestResponseTime = DateTime.kZeroDateTime;
    Document document = null;

    try {
      DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
      StringReader stringReader = new StringReader(notesText);
      InputSource inputSource = new InputSource(stringReader);

      docBuilder = docBuilderFactory.newDocumentBuilder();
      document = docBuilder.parse(inputSource);

      Node rootNode = document.getFirstChild();

      Node noteNode = rootNode.getFirstChild();

      while (noteNode != null) {
        NodeList notesNodesList = noteNode.getChildNodes();
        String date = CuramConst.gkEmpty;
        String username = CuramConst.gkEmpty;

        for (int i = 0; i < notesNodesList.getLength(); i++) {
          if (notesNodesList.item(i).getNodeName().equals(CuramConst.gkDate)) {
            date = notesNodesList.item(i).getTextContent();

          } else if (notesNodesList.item(i).getNodeName().equals(
            curam.servicedelivery.impl.CuramConst.kAUTHOR)) {
            NamedNodeMap attributes = notesNodesList.item(i).getAttributes();

            username = attributes.getNamedItem(CuramConst.gkUsername).getNodeValue();

          } else {
            continue;
          }

        }
        ExternalUserParticipantLink externalUserParticipantLink = serviceEnquiryFacadeUtilProvider.get().getproviderExternalLink(
          provider);

        if (null != externalUserParticipantLink) {
          // only proceed to process the time of note, if this provider has
          // external user access, as the portal is the only method a provider
          // has to
          // comment on a service enquiry
          earliestResponseTime = updateEarliestResponseTime(
            externalUserParticipantLink.getUsername(), earliestResponseTime,
            date, username);
        }
        noteNode = noteNode.getNextSibling();
      }

    } catch (SAXException e) {//
    } catch (ParserConfigurationException pce) {//
    } catch (IOException ioe) {//
    }
    return earliestResponseTime;
  }

  /**
   * Determines if the provider response time should be updated - if the note
   * was entered by the provider, and the date and time the note was entered is
   * earlier than the current earliest provider response time update the
   * response time to the current note time.
   *
   * @param providerUsername
   * registered username of the provider - this is the username that
   * will identify the note as a note entered by the provider
   * @param earliestResponseTime
   * the current earliest response time
   * @param noteCreationDate
   * date the specified note was entered
   * @param noteCreatedByUsername
   * username of the user who entered the specified note
   * @return a date time object representing the earliest response time, or a
   * blank date time if no responses recorded for the providers
   * web-based enquiries
   */
  protected DateTime updateEarliestResponseTime(final String providerUsername,
    final DateTime earliestResponseTime, final String noteCreationDate,
    final String noteCreatedByUsername) {
    DateTime currentNoteDateTime;

    if (noteCreatedByUsername.equals(providerUsername)) {
      currentNoteDateTime = DateTime.fromISO8601(noteCreationDate);
      if (earliestResponseTime.isZero()) {
        return currentNoteDateTime;
      } else if ((!earliestResponseTime.isZero())
        && (currentNoteDateTime.before(earliestResponseTime))) {
        return currentNoteDateTime;
      }
    }
    // return unmodified response time as it is still the earliest time
    return earliestResponseTime;
  }

  /**
   * Returns a phone number in its long format from the details passed in.
   *
   * @param phoneCountryCode
   * the country code of the number to format
   * @param phoneAreaCode
   * the area code of the number to format
   * @param phoneNumber
   * the phone number of the number to format
   * @param phoneExtension
   * the extension of the number to format
   * @return the formatted number
   */
  protected static String formatPhoneNumber(final String phoneCountryCode,
    final String phoneAreaCode, final String phoneNumber,
    final String phoneExtension) {

    // Combine the business phone number
    StringBuffer sb = new StringBuffer();

    // Check if the country code is populated
    if (!StringHelper.isEmpty(phoneCountryCode)) {
      sb.append(StringHelper.trim(phoneCountryCode)).append(CuramConst.gkSpace);
    }

    // Check if the area code is populated
    if (!StringHelper.isEmpty(phoneAreaCode)) {
      sb.append(StringHelper.trim(phoneAreaCode)).append(CuramConst.gkSpace);
    }

    // Append the number
    sb.append(StringHelper.trim(phoneNumber)).append(CuramConst.gkSpace);

    // Check if the extension is populated
    if (!StringHelper.isEmpty(phoneExtension)) {
      sb.append(StringHelper.trim(phoneExtension));
    }

    return StringHelper.trim(sb.toString());
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryViewDetails viewServiceEnquiry(
    final ServiceEnquiryKey key) throws AppException, InformationalException {
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.get(
      key.serviceEnquiryID);
    ServiceEnquiryViewDetails serviceEnquiryViewDetails = serviceEnquiryFacadeUtilProvider.get().viewServiceEnquiry(
      serviceEnquiry);

    return serviceEnquiryViewDetails;
  }

  /**
   * {@inheritDoc}
   */
  public void addComment(final ServiceEnquiryCommentDetails commentDetails)
    throws AppException, InformationalException {
    serviceEnquiryFacadeUtilProvider.get().addComment(
      commentDetails.serviceEnquiryID, commentDetails.comments,
      commentDetails.versionNo);

    notifyProvider(commentDetails.serviceEnquiryID);
  }

  /**
   * Notifies the provider that a service enquiry has been updated by the
   * caseworker. If the enquiry method is 'Email' an email is sent to the
   * provider. If the enquiry method is 'Web' , an email is sent to the provider
   * if an email address exists for them, otherwise an alert is posted on the
   * providers portal. If the enquiry method is 'Post', a batch job is queued
   * for printing.
   *
   * @param serviceEnquiryID
   * unique identifier for the service enquiry
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  protected void notifyProvider(final long serviceEnquiryID)
    throws AppException, InformationalException {
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.get(
      serviceEnquiryID);

    if ((serviceEnquiry.getEnquiryMethod().equals(
      SERVICEDELENQUIRYMETHODEntry.EMAIL))
        || (serviceEnquiry.getEnquiryMethod().equals(
          SERVICEDELENQUIRYMETHODEntry.WEB))) {
      if (0 != serviceEnquiry.getProvider().getPrimaryEmailAddressID()) {
        buildAndSendServiceEnquiryUpdatedEmail(serviceEnquiry);
      } else {// TODO: (JG) alert processing for provider portal
      }
    } else if (serviceEnquiry.getEnquiryMethod().equals(
      SERVICEDELENQUIRYMETHODEntry.POST)) {// TODO: (JG) queue batch job for printing
    }

  }

  /**
   * {@inheritDoc}
   */
  public void updateEnquiryResponse(
    final ServiceEnquiryResponseDetails responseDetails) throws AppException,
      InformationalException {
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.get(
      responseDetails.serviceEnquiryID);

    serviceEnquiryFacadeUtilProvider.get().submitEnquiryResponse(
      responseDetails.versionNo, serviceEnquiry,
      PROVIDERENQUIRYRESPONSEEntry.get(responseDetails.providerResponse),
      responseDetails.comment);

    notifyProvider(responseDetails.serviceEnquiryID);
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryListDetailsList listEnquiriesForServiceDelivery(
    final ServiceDeliveryKey key) throws AppException, InformationalException {

    ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
      key.serviceDeliveryID);
    List<curam.serviceenquiry.impl.ServiceEnquiry> serviceEnquiriesForServiceDelivery = serviceEnquiryDAO.searchActiveServiceEnquiriesForServiceDelivery(
      serviceDelivery);

    ServiceEnquiryListDetailsList serviceEnquiryListDetailsList = serviceEnquiryFacadeUtilProvider.get().assignServiceEnquiryListDetails(
      serviceEnquiriesForServiceDelivery);
    // check if a provider is selectable for the service delivery
    ServiceDeliveryConfigurationAccessor serviceDeliveryConfiguration = serviceDelivery.getServiceOffering().getServiceDeliveryConfiguration();

    if ((serviceDeliveryConfiguration != null)
      && (!serviceDeliveryConfiguration.getProviderAndProviderTypeSelection().equals(
        PROVIDERANDTYPESELECTIONEntry.PROVIDERTYPEMANDATORY))
        && (serviceDelivery.getProvider() == null)) {
      serviceEnquiryListDetailsList.providerSelectableInd = true;
    }
    return serviceEnquiryListDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryResponseList getResponseListForEnquiryUpdate(
    final ServiceEnquiryKey serviceEnquiryKey) throws AppException,
      InformationalException {
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.get(
      serviceEnquiryKey.serviceEnquiryID);
    ServiceEnquiryResponseList responses = new ServiceEnquiryResponseList();

    ServiceEnquiryResponse serviceEnquiryResponse;

    responses.serviceEnquiryResponse = serviceEnquiry.getProviderResponse().getCode();
    LinkedHashMap<String, String> codes = CodeTable.getAllEnabledItems(
      PROVIDERENQUIRYRESPONSEEntry.TABLENAME,
      TransactionInfo.getProgramLocale());

    for (String code : codes.keySet()) {
      if ((code.equals(PROVIDERENQUIRYRESPONSEEntry.CALLNOTANSWERED.getCode()))
        || (code.equals(PROVIDERENQUIRYRESPONSEEntry.PENDING.getCode()))) {
        continue;
      }
      serviceEnquiryResponse = new ServiceEnquiryResponse();
      serviceEnquiryResponse.responseCode = code;
      serviceEnquiryResponse.responseDescription = codes.get(code);
      responses.response.addRef(serviceEnquiryResponse);
    }

    return responses;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEnquiryResponseList getResponseListForPhoneEnquiry()
    throws AppException, InformationalException {
    ServiceEnquiryResponseList responses = new ServiceEnquiryResponseList();

    ServiceEnquiryResponse serviceEnquiryResponse;

    LinkedHashMap<String, String> codes = CodeTable.getAllEnabledItems(
      PROVIDERENQUIRYRESPONSEEntry.TABLENAME,
      TransactionInfo.getProgramLocale());

    for (String code : codes.keySet()) {
      if ((code.equals(PROVIDERENQUIRYRESPONSEEntry.UNDECIDED.getCode()))
        || (code.equals(
          PROVIDERENQUIRYRESPONSEEntry.NORESPONSERECEIVED.getCode()))) {
        continue;
      }
      serviceEnquiryResponse = new ServiceEnquiryResponse();
      serviceEnquiryResponse.responseCode = code;
      serviceEnquiryResponse.responseDescription = codes.get(code);
      responses.response.addRef(serviceEnquiryResponse);
    }

    return responses;
  }

  /**
   * Assigns the common view details for a {@link ServiceEnquiry} record.
   *
   * @param serviceEnquiryListDetails
   * the data is populated here
   * @param serviceEnquiry
   * the {@link ServiceEnquiry} object instance
   */
  protected void assignStandardViewDetails(
    final ServiceEnquiryListDetails serviceEnquiryListDetails,
    final curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry) {
    java.util.Date serviceEnquiryDate = serviceEnquiry.getCreationDateTime().getCalendar().getTime();

    serviceEnquiryListDetails.serviceEnquiryDate = Date.getFromJavaUtilDate(
      serviceEnquiryDate);
    serviceEnquiryListDetails.dtls.serviceEnquiryID = serviceEnquiry.getID();
    serviceEnquiryListDetails.dtls.providerResponse = serviceEnquiry.getProviderResponse().getCode();
    serviceEnquiryListDetails.dtls.enquiryMethod = serviceEnquiry.getEnquiryMethod().getCode();
    serviceEnquiryListDetails.dtls.versionNo = serviceEnquiry.getVersionNo();
  }

  /**
   * {@inheritDoc}
   */
  public ProviderServiceEnquiriesSummaryDetails viewProviderServiceEnquiriesOverview(
    final ProviderConcernRoleKey key) throws AppException,
      InformationalException {
    ProviderServiceEnquiriesSummaryDetails summaryDetails = new ProviderServiceEnquiriesSummaryDetails();

    Provider provider = providerDAO.get(key.providerConcernRoleID);

    summaryDetails.preferredContact = provider.getPreferredServiceEnquiryMethod().getCode();

    // get all active service enquiries for the provider
    List<curam.serviceenquiry.impl.ServiceEnquiry> activeServiceEnquiriesForProvider = serviceEnquiryDAO.searchActiveServiceEnquiriesForProvider(
      provider);
    ServiceEnquiryListDetails serviceEnquiryListDetails;

    for (curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry : activeServiceEnquiriesForProvider) {
      serviceEnquiryListDetails = new ServiceEnquiryListDetails();
      serviceEnquiryListDetails.serviceName = serviceEnquiry.getServiceOffering().getName();
      assignStandardViewDetails(serviceEnquiryListDetails, serviceEnquiry);
      summaryDetails.serviceEnquiries.listDetails.addRef(
        serviceEnquiryListDetails);
    }

    // get number of web based service enquiries
    List<curam.serviceenquiry.impl.ServiceEnquiry> webServiceEnquiriesForProvider = serviceEnquiryDAO.searchActiveWebServiceEnquiriesForProvider(
      provider);

    if (0 < webServiceEnquiriesForProvider.size()) {
      summaryDetails.webStatisticsInd = true;
      // get the average initial response time of the provider
      int percentageResponse = calculatePercentageResponses(
        webServiceEnquiriesForProvider);

      summaryDetails.percentageResponseDescription = new LocalisableString(SERVICEENQUIRY.INF_SERVICE_ENQUIRY_PERCENTAGE_RESPONSE).arg(percentageResponse).arg(webServiceEnquiriesForProvider.size()).getMessage();

      double averageResponseHours = calculateAverageResponseHours(
        webServiceEnquiriesForProvider);

      if (0 == averageResponseHours) {
        summaryDetails.averageResponseDescription = new LocalisableString(SERVICEENQUIRY.INF_SERVICE_ENQUIRY_NO_PROVIDER_DATA).getMessage();
      } else if (averageResponseHours < CuramConst.gkNumberOfHoursInADay) {
        summaryDetails.averageResponseDescription = new LocalisableString(SERVICEENQUIRY.INF_SERVICE_ENQUIRY_AVERAGE_RESPONSE_TIME_LESS_THAN_1_DAY).getMessage();
      } else if (averageResponseHours
        < curam.servicedelivery.impl.CuramConst.gkFortyEight) {
        summaryDetails.averageResponseDescription = new LocalisableString(SERVICEENQUIRY.INF_SERVICE_ENQUIRY_AVERAGE_RESPONSE_TIME_1_DAY).getMessage();
      } else {
        summaryDetails.averageResponseDescription = new LocalisableString(SERVICEENQUIRY.INF_SERVICE_ENQUIRY_AVERAGE_RESPONSE_TIME).arg(averageResponseHours / CuramConst.gkNumberOfHoursInADay).getMessage();
      }
    }

    summaryDetails.providerConcernRoleID = provider.getID();
    populatePhoneNumber(summaryDetails, provider);

    return summaryDetails;
  }

  /**
   * {@inheritDoc}
   */
  public void deletePhoneEnquiry(ServiceEnquiryCancelKey cancelKey)
    throws AppException, InformationalException {
   
    curam.serviceenquiry.impl.ServiceEnquiry serviceEnquiry = serviceEnquiryDAO.get(
      cancelKey.serviceEnquiryID);

    serviceEnquiry.cancel(cancelKey.versionNo);
  }
}
