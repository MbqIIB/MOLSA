/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.sl.impl;


import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.CASEDECISIONRESULTCODE;
import curam.codetable.impl.SERVICEDELRELATEDTYPEEntry;
import curam.core.sl.infrastructure.assessment.event.impl.AssessmentEngineEvent;
import curam.core.struct.CompleteDecisionCreationList;
import curam.cpm.sl.entity.struct.ConcernRoleKey;
import curam.cpm.sl.entity.struct.ServiceAuthorizationLineItemDtls;
import curam.cpm.sl.fact.ServiceDeliveryFactory;
import curam.cpm.sl.struct.DeliveryTypeRelatedIDKey;
import curam.cpm.sl.struct.SearchByCaseKey;
import curam.cpm.sl.struct.SearchByServiceDeliveryKey;
import curam.cpm.util.impl.FrequencyPatternUtil;
import curam.cpm.util.impl.FrequencyPatternUtilImpl;
import curam.piwrapper.caseheader.impl.ProductDeliveryDAO;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.casemanager.impl.CaseParticipantRoleDAO;
import curam.provider.impl.ProviderTypeNameEntry;
import curam.serviceauthorization.impl.ServiceAuthorizationDAO;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItemDAO;
import curam.servicedelivery.impl.ServiceDelivery;
import curam.servicedelivery.impl.ServiceDeliveryDAO;
import curam.servicedelivery.impl.ServiceDeliveryLink;
import curam.servicedelivery.impl.ServiceDeliveryLinkDAO;
import curam.serviceoffering.impl.SODELIVERYTYPEEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.NotFoundIndicator;


/**
 * An event listener for the {@link AssessmentEngineEvent} class.
 */
public class CPMAssessmentEngineEventListener extends AssessmentEngineEvent {

  /**
   * Reference to Service Delivery DAO.
   */
  @Inject
  protected ServiceDeliveryDAO serviceDeliveryDAO;

  /**
   * Reference to Service Delivery Link DAO.
   */
  @Inject
  protected ServiceDeliveryLinkDAO serviceDeliveryLinkDAO;

  /**
   * Reference to Case Participant Role DAO.
   */
  @Inject
  protected CaseParticipantRoleDAO caseParticipantRoleDAO;

  /**
   * Reference to Service Authorization DAO.
   */
  @Inject
  protected ServiceAuthorizationDAO serviceAuthorizationDAO;

  /**
   * Reference to Service Authorization Line Item DAO.
   */
  @Inject
  protected ServiceAuthorizationLineItemDAO serviceAuthorizationLineItemDAO;

  /**
   * Reference to Product Delivery DAO.
   */
  @Inject
  protected ProductDeliveryDAO productDeliveryDAO;

  /**
   * An event listener implementation for the {@link AssessmentEngineEvent}
   * class which is used to create service authorization and service
   * authorization line items.
   *
   * @param newCaseDecisions
   * the list of new decisions made for this case
   * @param existingCaseDecisions
   * the list of existing decisions for the case
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void postInsertExamineDecisions(
    final CompleteDecisionCreationList newCaseDecisions,
    final CompleteDecisionCreationList existingCaseDecisions)
    throws AppException, InformationalException {

    if (!newCaseDecisions.dtls.isEmpty()) {

      SearchByCaseKey searchByCaseKey = new SearchByCaseKey();

      searchByCaseKey.caseID = newCaseDecisions.dtls.item(0).details.caseID;
      DeliveryTypeRelatedIDKey deliveryTypeRelatedIDKey = new DeliveryTypeRelatedIDKey();

      deliveryTypeRelatedIDKey.deliveryTypeRelatedID = newCaseDecisions.dtls.item(0).details.caseID;

      NotFoundIndicator nfIndicator = new NotFoundIndicator();
      SearchByServiceDeliveryKey searchByServiceDeliveryKey = ServiceDeliveryFactory.newInstance().readByDeliveryTypeRelatedID(
        nfIndicator, deliveryTypeRelatedIDKey);

      if (!nfIndicator.isNotFound()) {
        ServiceDelivery serviceDelivery = serviceDeliveryDAO.get(
          searchByServiceDeliveryKey.serviceDeliveryID);

        if (SODELIVERYTYPEEntry.PDWITHINVOICING.getCode().equals(
          serviceDelivery.getServiceOffering().getDeliveryType().getCode())
            || SODELIVERYTYPEEntry.SDWITHELIGIBILITY.getCode().equals(
              serviceDelivery.getServiceOffering().getDeliveryType().getCode())) {
          
          if (null == serviceDelivery.getServiceAuthorization()) {
            
            for (int i = 0; i < newCaseDecisions.dtls.size(); i++) {
              
              // Check for an eligible decision
              if (newCaseDecisions.dtls.item(i).details.resultCode.equals(
                CASEDECISIONRESULTCODE.ELIGIBLE)) {

                createServiceAuthorization(serviceDelivery);
                break;
              }
            }                     
          }
        }
      }
    }
  }

  /**
   * Invokes Service Authorization creation. This operation is called 1) on
   * submission of a service delivery, if no approval checks exist, or 2) on
   * approval of an approval request for the service delivery.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void createServiceAuthorization(
    final ServiceDelivery serviceDelivery) throws AppException,
      InformationalException {

    List<ServiceDeliveryLink> serviceDeliveryLinks = serviceDeliveryLinkDAO.searchByServiceDeliveryAndRelatedType(
      serviceDelivery, SERVICEDELRELATEDTYPEEntry.CASEPARTICIPANTROLE);

    Set<CaseParticipantRole> caseParticipants = new HashSet<CaseParticipantRole>();

    for (ServiceDeliveryLink serviceDeliveryLink : serviceDeliveryLinks) {

      caseParticipants.add(
        caseParticipantRoleDAO.get(serviceDeliveryLink.getRelatedID()));
    }
    // invoking CPM service authorization from here for now
    curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.newInstance();

    serviceAuthorization.createServiceAuthorization(caseParticipants);

    // call creation of the line items catering for frequency
    if (!serviceDelivery.getServiceFrequencyPattern().isZeroPattern()) {
      ServiceAuthorizationLineItemDtls authorizationLineItemDtls = new ServiceAuthorizationLineItemDtls();

      authorizationLineItemDtls.fromDate = serviceDelivery.getCoverPeriodStartDate();
      authorizationLineItemDtls.toDate = serviceDelivery.getCoverPeriodEndDate();
      authorizationLineItemDtls.serviceID = serviceDelivery.getServiceOffering().getID();
      if (null != serviceDelivery.getProvider()) {
        authorizationLineItemDtls.providerID = serviceDelivery.getProvider().getID();
      } else {
        authorizationLineItemDtls.providerType = serviceDelivery.getProviderType().getCode();
      }
      if (null != serviceDelivery.getNomineeConcernRole()) {
        authorizationLineItemDtls.nomineeID = serviceDelivery.getNomineeConcernRole().getID();
      }
      authorizationLineItemDtls.serviceAuthorizationID = serviceAuthorization.getID();
      authorizationLineItemDtls.unitAmount = serviceDelivery.getAuthorizedRate();
      if (serviceDelivery.getAuthorizedRate().isPositive()) {
        authorizationLineItemDtls.unitAmountFixedInd = true;
      } else {
        authorizationLineItemDtls.unitAmountFixedInd = false;
      }
      FrequencyPatternUtil frequencyPatternUtil = new FrequencyPatternUtilImpl();
      Date anchorDate = frequencyPatternUtil.getAnchorDateAfterReferenceDate(
        serviceDelivery.getCoverPeriodStartDate(),
        serviceDelivery.getServiceFrequencyPattern());

      if (0 != serviceDelivery.getUnitsAuthorized()) {
        authorizationLineItemDtls.unitsAuthorized = serviceDelivery.getUnitsAuthorized();
      } else {
        authorizationLineItemDtls.unitsAuthorized = 1;
      }
      serviceAuthorization.addSALIToSAUsingFrequencyAndAnchorDate(
        serviceAuthorization, serviceDelivery.getServiceFrequencyPattern(),
        authorizationLineItemDtls, anchorDate);
    } else {
      curam.serviceauthorization.impl.ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceAuthorizationLineItemDAO.newInstance();
      DateRange authorizedPeriod = new DateRange(
        serviceDelivery.getCoverPeriodStartDate(),
        serviceDelivery.getCoverPeriodEndDate());

      serviceAuthorizationLineItem.setDateRange(authorizedPeriod);
      serviceAuthorizationLineItem.setProvider(serviceDelivery.getProvider());
      serviceAuthorizationLineItem.setProviderType(
        serviceDelivery.getProviderType());
      serviceAuthorizationLineItem.setServiceAuthorization(serviceAuthorization);
      serviceAuthorizationLineItem.setUnitAmount(
        serviceDelivery.getAuthorizedRate());

      if (serviceDelivery.getAuthorizedRate().isPositive()) {

        serviceAuthorizationLineItem.setUnitAmountFixed(true);
      } else {
        serviceAuthorizationLineItem.setUnitAmountFixed(false);
      }

      ProviderTypeNameEntry providerTypeNameEntry = serviceDelivery.getProviderType();
      ConcernRoleKey nomineeConcernRoleKey = new ConcernRoleKey();

      if (null != serviceDelivery.getNomineeConcernRole()) {
        nomineeConcernRoleKey.concernRoleID = serviceDelivery.getNomineeConcernRole().getID();
      }
      serviceAuthorizationLineItem.setProviderType(providerTypeNameEntry);

      serviceAuthorizationLineItem.setServiceOffering(
        serviceDelivery.getServiceOffering());
      if (0 != serviceDelivery.getUnitsAuthorized()) {
        serviceAuthorizationLineItem.setUnitsAuthorized(
          serviceDelivery.getUnitsAuthorized());
      } else {
        serviceAuthorizationLineItem.setUnitsAuthorized(1);

      }
      
      serviceAuthorizationLineItem.setNominee(nomineeConcernRoleKey);
      serviceAuthorizationLineItem.insertServiceAuthorizationLineItem();
    }
    
    // Set the service authorization on service delivery record.
    serviceDelivery.setServiceAuthorization(serviceAuthorization);
    serviceDelivery.modify(serviceDelivery.getVersionNo());    
  }
}
