/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd..
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.INJURYSEVERITYTYPEEntry;
import curam.codetable.impl.INJURYSOURCEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.struct.CreateIncidentInjuryDetails;
import curam.core.facade.struct.IncidentAndInjuryKey;
import curam.core.facade.struct.IncidentInjuryDetails;
import curam.core.facade.struct.IncidentInjuryDetailsList;
import curam.core.facade.struct.IncidentInjuryIDAndVersionNoDetails;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRole;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.UsersKey;
import curam.incident.impl.Incident;
import curam.incident.impl.IncidentDAO;
import curam.incidentinjury.impl.IncidentInjury;
import curam.incidentinjury.impl.IncidentInjuryDAO;
import curam.incidentinjury.impl.IncidentInjuryResponsibility;
import curam.incidentinjury.impl.IncidentInjuryResponsibilityDAO;
import curam.incident.impl.IncidentParticipant;
import curam.incident.impl.IncidentParticipantDAO;
import curam.message.impl.BPOINCIDENTINJURYExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;
import curam.util.type.StringList;
import curam.util.type.StringHelper;


/**
 * {@inheritDoc}
 */
public abstract class MaintainProviderIncidentInjury extends curam.cpm.facade.base.MaintainProviderIncidentInjury {

  /**
   * Reference to incident DAO.
   */
  @Inject
  protected IncidentDAO incidentDAO;

  /**
   * Reference to incident injury DAO.
   */
  @Inject
  protected IncidentInjuryDAO incidentInjuryDAO;

  /**
   * Reference to incident injury responsibility DAO.
   */
  @Inject
  protected IncidentInjuryResponsibilityDAO incidentInjuryResponsibilityDAO;

  /**
   * Reference to incident participant DAO.
   */
  @Inject
  protected IncidentParticipantDAO incidentParticipantDAO;

  /**
   * Constructor for the class.
   */
  public MaintainProviderIncidentInjury() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public IncidentAndInjuryKey createIncidentInjury(
    final CreateIncidentInjuryDetails details) throws AppException,
      InformationalException {

    IncidentAndInjuryKey incidentInjuryKey = new IncidentAndInjuryKey();
    IncidentInjury incidentInjuryObj = incidentInjuryDAO.newInstance();

    Incident incidentObj = incidentDAO.get(details.dtls.incidentID);

    StringList responsibleParticipantIDList = StringUtil.tabText2StringListWithTrim(
      details.responsibleParticipantTab);

    incidentInjuryObj.setIncident(incidentObj);
    incidentInjuryObj.setInjuredParticipant(details.dtls.injuredParticipant);
    incidentInjuryObj.setInjurySeverity(
      INJURYSEVERITYTYPEEntry.get(details.dtls.injurySeverity));
    incidentInjuryObj.setSourceOfInjury(
      INJURYSOURCEEntry.get(details.dtls.sourceOfInjury));
    incidentInjuryObj.setActionTaken(details.dtls.actionTaken);
    incidentInjuryObj.setDescription(details.dtls.description);

    incidentInjuryObj.setInjuryDueToRestrntInd(
      details.dtls.injuryDueToRestrntInd);
    incidentInjuryObj.insert();

    for (int i = 0; i < responsibleParticipantIDList.size(); i++) {

      if (0 < responsibleParticipantIDList.item(i).length()) {
        IncidentInjuryResponsibility incidentInjuryRespObj = incidentInjuryResponsibilityDAO.newInstance();

        incidentInjuryRespObj.setPersonResponsible(
          Long.parseLong(responsibleParticipantIDList.item(i)));
        incidentInjuryRespObj.setIncidentInjury(incidentInjuryObj);
        incidentInjuryRespObj.insert();
      }
    }

    incidentInjuryKey.incidentInjuryID = incidentInjuryObj.getID();

    return incidentInjuryKey;
  }

  /**
   * {@inheritDoc}
   */
  public void deleteIncidentInjury(IncidentInjuryIDAndVersionNoDetails details)
    throws AppException, InformationalException {

    IncidentInjury incidentInjuryObj = incidentInjuryDAO.get(
      details.incidentInjuryID);

    incidentInjuryObj.cancel(details.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void modifyIncidentInjury(IncidentInjuryDetails details)
    throws AppException, InformationalException {

    IncidentInjury incidentInjuryObj = incidentInjuryDAO.get(
      details.dtls.incidentInjuryID);

    if (StringHelper.isEmpty(details.dtls.description)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOINCIDENTINJURYExceptionCreator.ERR_INCIDENTINJURY_FV_DESCRIPTION_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if (StringHelper.isEmpty(details.dtls.actionTaken)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOINCIDENTINJURYExceptionCreator.ERR_INCIDENTINJURY_FV_ACTIONTAKEN_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    Incident incidentObj = incidentDAO.get(details.dtls.incidentID);

    incidentInjuryObj.setIncident(incidentObj);
    incidentInjuryObj.setInjuredParticipant(details.dtls.injuredParticipant);
    incidentInjuryObj.setInjurySeverity(
      INJURYSEVERITYTYPEEntry.get(details.dtls.injurySeverity));
    incidentInjuryObj.setSourceOfInjury(
      INJURYSOURCEEntry.get(details.dtls.sourceOfInjury));
    incidentInjuryObj.setActionTaken(details.dtls.actionTaken);
    incidentInjuryObj.setDescription(details.dtls.description);

    incidentInjuryObj.setInjuryDueToRestrntInd(
      details.dtls.injuryDueToRestrntInd);
    incidentInjuryObj.modify(details.dtls.versionNo);

    Set<IncidentInjuryResponsibility> incidentInjuryResponsibilitySet = incidentInjuryResponsibilityDAO.searchByIncidentInjury(
      incidentInjuryObj);

    StringList responsibleParticipantIDList = StringUtil.tabText2StringListWithTrim(
      details.responsibleParticipantTab);

    ArrayList<String> newIDList = new ArrayList<String>();

    for (IncidentInjuryResponsibility incidentInjuryResponsibility : incidentInjuryResponsibilitySet) {

      String responsible = Long.toString(
        incidentInjuryResponsibility.getPersonResponsible());

      if (!responsibleParticipantIDList.contains(responsible)) {
        IncidentInjuryResponsibility incidentInjuryRespObj = incidentInjuryResponsibilityDAO.get(
          incidentInjuryResponsibility.getID());

        if (!RECORDSTATUSEntry.CANCELLED.equals(
          incidentInjuryResponsibility.getStatus())) {
          incidentInjuryRespObj.cancel(
            incidentInjuryResponsibility.getVersionNo());
        }
      } else if (!RECORDSTATUSEntry.CANCELLED.equals(
        incidentInjuryResponsibility.getStatus())) {
        newIDList.add(
          String.valueOf(incidentInjuryResponsibility.getPersonResponsible()));
      }
    }

    for (int i = 0; i < responsibleParticipantIDList.size(); i++) {

      if (!newIDList.contains(responsibleParticipantIDList.get(i))) {
        IncidentInjuryResponsibility incidentInjuryRespObj = incidentInjuryResponsibilityDAO.newInstance();

        incidentInjuryRespObj.setPersonResponsible(
          Long.parseLong(responsibleParticipantIDList.get(i)));
        incidentInjuryRespObj.setIncidentInjury(
          incidentInjuryDAO.get(details.dtls.incidentInjuryID));
        incidentInjuryRespObj.insert();
      }
    }
  }

  /**
   * {@inheritDoc}
   */
  public IncidentInjuryDetailsList listIncidentInjury(IncidentAndInjuryKey key)
    throws AppException, InformationalException {

    IncidentInjuryDetailsList incidentInjuryDetailsList = new IncidentInjuryDetailsList();
    Incident incidentObj = incidentDAO.get(key.incidentID);

    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    Set<IncidentInjury> incidentInjurySet = incidentInjuryDAO.searchByIncident(
      incidentObj);
    Iterator<IncidentInjury> incidentInjurySetIterator = incidentInjurySet.iterator();

    while (incidentInjurySetIterator.hasNext()) {
      IncidentInjuryDetails incidentInjuryDetails = new IncidentInjuryDetails();
      IncidentInjury incidentInjuryObj = incidentInjurySetIterator.next();

      incidentInjuryDetails.dtls.incidentID = key.incidentID;
      incidentInjuryDetails.dtls.incidentInjuryID = incidentInjuryObj.getID();
      incidentInjuryDetails.dtls.injuredParticipant = incidentInjuryObj.getInjuredParticipant();
      incidentInjuryDetails.dtls.injurySeverity = incidentInjuryObj.getInjurySeverity().getCode();
      incidentInjuryDetails.dtls.sourceOfInjury = incidentInjuryObj.getSourceOfInjury().getCode();
      incidentInjuryDetails.dtls.versionNo = incidentInjuryObj.getVersionNo();
      incidentInjuryDetails.dtls.recordStatus = incidentInjuryObj.getStatus().getCode();
      incidentInjuryDetails.dtls.injuryDueToRestrntInd = incidentInjuryObj.isInjuryDueToRestrntInd();

      if (RECORDSTATUSEntry.CANCELLED.getCode().equals(
        incidentInjuryDetails.dtls.recordStatus)) {
        incidentInjuryDetails.statusInd = true;
      }
      IncidentParticipant incidentParticipantObj = incidentParticipantDAO.get(
        incidentInjuryObj.getInjuredParticipant());

      if (0 == incidentParticipantObj.getConcernRoleID()) {
        usersKey.userName = incidentParticipantObj.getUserName();
        incidentInjuryDetails.injuredParticipantName = userAccessObj.getFullName(usersKey).fullname;
      } else {
        concernRoleKey.concernRoleID = incidentParticipantObj.getConcernRoleID();
        incidentInjuryDetails.injuredParticipantName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
      }

      Set<IncidentInjuryResponsibility> incidentInjuryResponsibilitySet = incidentInjuryResponsibilityDAO.searchByIncidentInjury(
        incidentInjuryObj);

      StringBuffer personResponsibleBuf = new StringBuffer();

      for (IncidentInjuryResponsibility incidentInjuryResponsibility : incidentInjuryResponsibilitySet) {

        if (!RECORDSTATUSEntry.CANCELLED.equals(
          incidentInjuryResponsibility.getStatus())) {
          incidentParticipantObj = incidentParticipantDAO.get(
            incidentInjuryResponsibility.getPersonResponsible());

          if (0 == incidentParticipantObj.getConcernRoleID()) {
            usersKey.userName = incidentParticipantObj.getUserName();
            personResponsibleBuf.append(
              userAccessObj.getFullName(usersKey).fullname);
          } else {
            concernRoleKey.concernRoleID = incidentParticipantObj.getConcernRoleID();
            personResponsibleBuf.append(
              concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName);
          }
          personResponsibleBuf.append(CuramConst.gkComma);
          personResponsibleBuf.append(CuramConst.gkSpace);

        }
      }
      if (personResponsibleBuf.length() > 0) {
        personResponsibleBuf.deleteCharAt(personResponsibleBuf.length() - 2);
        incidentInjuryDetails.responsibleParticipantTab = personResponsibleBuf.toString();
      }
      incidentInjuryDetailsList.dtls.addRef(incidentInjuryDetails);
    }
    return incidentInjuryDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public IncidentInjuryDetails viewIncidentInjury(IncidentAndInjuryKey key)
    throws AppException, InformationalException {
    IncidentInjuryDetails incidentInjuryDetails = new IncidentInjuryDetails();

    IncidentInjury incidentInjuryObj = incidentInjuryDAO.get(
      key.incidentInjuryID);

    incidentInjuryDetails.dtls.incidentID = key.incidentID;
    incidentInjuryDetails.dtls.incidentInjuryID = key.incidentInjuryID;

    incidentInjuryDetails.dtls.actionTaken = incidentInjuryObj.getActionTaken();
    incidentInjuryDetails.dtls.description = incidentInjuryObj.getDescription();

    incidentInjuryDetails.dtls.injuredParticipant = incidentInjuryObj.getInjuredParticipant();
    incidentInjuryDetails.dtls.injurySeverity = incidentInjuryObj.getInjurySeverity().getCode();
    incidentInjuryDetails.dtls.recordStatus = incidentInjuryObj.getStatus().getCode();
    incidentInjuryDetails.dtls.sourceOfInjury = incidentInjuryObj.getSourceOfInjury().getCode();
    incidentInjuryDetails.dtls.userName = incidentInjuryObj.getUserName();
    incidentInjuryDetails.dtls.versionNo = incidentInjuryObj.getVersionNo();

    incidentInjuryDetails.dtls.injuryDueToRestrntInd = incidentInjuryObj.isInjuryDueToRestrntInd();

    Set<IncidentInjuryResponsibility> incidentInjuryResponsibilitySet = incidentInjuryResponsibilityDAO.searchByIncidentInjury(
      incidentInjuryObj);

    StringBuffer tabList = new StringBuffer();

    for (IncidentInjuryResponsibility incidentInjuryResponsibility : incidentInjuryResponsibilitySet) {

      if (!RECORDSTATUSEntry.CANCELLED.equals(
        incidentInjuryResponsibility.getStatus())) {
        tabList.append(Long.toString(incidentInjuryResponsibility.getPersonResponsible())).append(
          CuramConst.gkTabDelimiter);
      }
    }

    incidentInjuryDetails.responsibleParticipantTab = tabList.toString();

    return incidentInjuryDetails;
  }

}
