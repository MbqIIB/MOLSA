/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2014. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 */

/*
 * Copyright 2007-2013 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import com.google.inject.Inject;

import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.cefwidgets.docbuilder.impl.ImagePanelBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.cefwidgets.docbuilder.impl.ListBuilder;
import curam.codetable.RECORDSTATUS;
import curam.codetable.REPRESENTATIVETYPE;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.GENDEREntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.struct.CaseMenuData;
import curam.core.fact.AddressFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.EmploymentFactory;
import curam.core.fact.PersonFactory;
import curam.core.fact.ProspectPersonFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.Address;
import curam.core.intf.Employment;
import curam.core.sl.fact.ConcernRoleImageFactory;
import curam.core.sl.fact.RepresentativeFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.fact.TabDetailsHelperFactory;
import curam.core.sl.impl.CaseTabDetailsHelper;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.intf.TabDetailsHelper;
import curam.core.sl.struct.AddressTabDetails;
import curam.core.sl.struct.ContextDescription;
import curam.core.sl.struct.IncidentAndRoleTabDetailsList;
import curam.core.sl.struct.InvestigationAndRoleTabDetailsList;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.EmploymentAndStatusReadMultiKey;
import curam.core.struct.EmploymentReadMultiDtlsList;
import curam.core.struct.EmploymentSnapshotListDtls;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PersonKey;
import curam.core.struct.PhoneForConcernRoleKey;
import curam.core.struct.PhoneNumberKey;
import curam.core.struct.ProspectPersonKey;
import curam.core.struct.ReadEmploymentHistoryList;
import curam.cpm.facade.struct.CreateProviderMemberDetails;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.ProviderMemberAndContextDetails;
import curam.cpm.facade.struct.ProviderMemberCreateDetails;
import curam.cpm.facade.struct.ProviderMemberCreationDetails;
import curam.cpm.facade.struct.ProviderMemberDetails;
import curam.cpm.facade.struct.ProviderMemberOfferingCreationDetails;
import curam.cpm.facade.struct.ProviderMemberOfferingDetails;
import curam.cpm.facade.struct.ProviderMemberOfferingDetailsList;
import curam.cpm.facade.struct.ProviderMemberSummaryDetails;
import curam.cpm.facade.struct.ProviderMemberSummaryDetailsList;
import curam.cpm.facade.struct.ProviderMemberSummaryVersionDetails;
import curam.cpm.facade.struct.ProviderMemberSummaryVersionDetailsList;
import curam.cpm.facade.struct.ProviderMembershipHistory;
import curam.cpm.facade.struct.ProviderMembershipHistoryList;
import curam.cpm.facade.struct.ProviderOfferingLinkDetails;
import curam.cpm.facade.struct.ProviderOfferingLinkDetailsList;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetails;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetailsList;
import curam.cpm.facade.struct.SearchPersonAndRepresentativeDetailsList;
import curam.cpm.facade.struct.SearchPersonDetails;
import curam.cpm.facade.struct.SearchPersonDetailsList;
import curam.cpm.facade.struct.SearchPersonKey;
import curam.cpm.facade.struct.VersionNo;
import curam.cpm.facade.struct.ViewProviderMemberDetails;
import curam.cpm.facade.struct.ViewProviderMemberTabDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.fact.ProviderFactory;
import curam.cpm.sl.entity.fact.ProviderPartyFactory;
import curam.cpm.sl.entity.intf.Provider;
import curam.cpm.sl.entity.struct.ConcernRoleIDCategory;
import curam.cpm.sl.entity.struct.PartyConcernRoleDetails;
import curam.cpm.sl.entity.struct.ProviderConcernRoleDetails;
import curam.cpm.sl.entity.struct.ProviderGroupKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ProviderMemberOfferingKey;
import curam.cpm.sl.entity.struct.ProviderPartyDetails;
import curam.cpm.sl.entity.struct.ProviderPartyDetailsList;
import curam.cpm.sl.entity.struct.ProviderPartyKey;
import curam.cpm.sl.entity.struct.SearchPersonDetails1;
import curam.cpm.sl.entity.struct.SearchRepresentativeDetails;
import curam.cpm.util.impl.TimeZoneUtil;
import curam.incident.impl.IncidentDAO;
import curam.message.BPOINTEGRATEDCASE;
import curam.message.BPOPARTICIPANT;
import curam.message.CPMCOMMONMESSAGES;
import curam.message.PROVIDERMEMBER;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.PERSONExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.participant.impl.PhoneNumber;
import curam.provider.impl.PROVIDERMEMBERPOSITIONEntry;
import curam.provider.impl.PersonDAO;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderGroup;
import curam.provider.impl.ProviderGroupDAO;
import curam.provider.impl.ProviderMemberDAO;
import curam.provider.impl.ProviderMemberOffering;
import curam.provider.impl.ProviderMemberOfferingDAO;
import curam.provider.impl.ProviderMemberRoleEntry;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.provider.impl.ProviderParty;
import curam.provider.impl.ProviderPartyCategoryEntry;
import curam.provider.impl.ProviderPartyDAO;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateTime;
import curam.util.type.StringHelper;


/**
 * Facade layer class having API for provider member.
 *
 */
public class ProviderMember extends curam.cpm.facade.base.ProviderMember {

  // BEGIN, CR00139244, AK
  /**
   * Provider Group DAO object
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /**
   * Provider Member DAO object
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  /**
   * Provider Organization DAO object
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Concern Role DAO object
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Provider DAO object
   */
  // BEGIN, CR00118010, MST
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Provider Offering DAO object
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Provider Member Offering DAO object
   */
  @Inject
  protected ProviderMemberOfferingDAO providerMemberOfferingDAO;

  // END, CR00118010

  /**
   * Person DAO object
   */
  // BEGIN, CR00121367, ABS
  @Inject
  protected PersonDAO personDAO;

  // END, CR00121367

  /**
   * Provider Party DAO object
   */
  // BEGIN, CR00128037, JSP
  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  // END, CR00128037
  // END, CR00139244

  // BEGIN, CR00186342, GP
  /**
   * Reference to Incident DAO.
   */
  @Inject
  protected IncidentDAO incidentDAO;

  // END, CR00186342

  /**
   * Constructor
   */
  public ProviderMember() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Cancels the Provider Member.
   *
   * @param keyVersionDetails
   * Contains version number and providerMemberID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deleteMember(KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      keyVersionDetails.id);

    providerMember.cancel(keyVersionDetails.version);
  }

  /**
   * Retrieves the list of Provider Group Member belongs to the particular
   * provider or provider group.
   *
   * @param concernRoleKey
   * Contains concernRoleId.
   *
   * @return The list of provider member summary details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderMemberSummaryDetailsList listMembersByConcernRole(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    final ProviderMemberSummaryDetailsList providerMemberSummaryDetailsList = new ProviderMemberSummaryDetailsList();

    // BEGIN, CR00291561, SS
    // BEGIN, CR00292956, SS
    final ConcernRoleIDCategory concernRoleIDCategory = new ConcernRoleIDCategory();

    concernRoleIDCategory.providerConcernRoleID = concernRoleKey.concernRoleID;
    concernRoleIDCategory.category = ProviderPartyCategoryEntry.MEMBER.getCode();
    // END, CR00292956
    curam.cpm.sl.entity.intf.ProviderParty providerParty = ProviderPartyFactory.newInstance();
    // BEGIN, CR00292956, SS
    ProviderPartyDetailsList providerPartyDetailsList = providerParty.searchProviderMember(
      concernRoleIDCategory);

    // END, CR00292956

    for (ProviderPartyDetails providerPartyDetails : providerPartyDetailsList.dtls.items()) {
      final ProviderMemberSummaryDetails providerMemberSummaryDetails = new ProviderMemberSummaryDetails();

      providerMemberSummaryDetails.providerMemberID = providerPartyDetails.providerMemberID;
      providerMemberSummaryDetails.memberConcernRoleID = providerPartyDetails.memberConcernRoleID;
      providerMemberSummaryDetails.concernRoleType = providerPartyDetails.concernRoleType;
      providerMemberSummaryDetails.providerConcernRoleID = providerPartyDetails.providerConcernRoleID;
      providerMemberSummaryDetails.fromDate = providerPartyDetails.fromDate;
      providerMemberSummaryDetails.toDate = providerPartyDetails.toDate;
      providerMemberSummaryDetails.recordStatus = providerPartyDetails.recordStatus;
      providerMemberSummaryDetails.role = providerPartyDetails.role;
      providerMemberSummaryDetails.position = providerPartyDetails.position;
      providerMemberSummaryDetails.memberName = providerPartyDetails.memberName;
      providerMemberSummaryDetailsList.providerMemberSummaryDetailsList.addRef(
        providerMemberSummaryDetails);
    }
    // END, CR00291561
    return providerMemberSummaryDetailsList;
  }

  /**
   * Updates the provider group member details with the provider member details
   * passed.
   *
   * @param providerMemberDtls
   * Contains the details of Provider group member.
   *
   * @return The provider party ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderPartyKey modifyProviderGroupMember(
    ProviderMemberDetails providerMemberDtls) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerMemberDtls.providerPartyID);

    providerMember.setDateRange(
      new DateRange(providerMemberDtls.startDate, providerMemberDtls.endDate));
    providerMember.setRole(
      ProviderMemberRoleEntry.get(providerMemberDtls.memberRole));
    // BEGIN, CR00117581, MST
    providerMember.setPosition(
      PROVIDERMEMBERPOSITIONEntry.get(providerMemberDtls.position));
    // END, CR00117581

    providerMember.modify(providerMemberDtls.versionNo);

    final ProviderPartyKey providerPartyKey = new ProviderPartyKey();

    providerPartyKey.providerPartyID = providerMember.getID();

    return providerPartyKey;
  }

  /**
   * Reads the Provider or Provider Group Member details.
   *
   * @param providerPartyKey
   * Contains provider party ID.
   *
   * @return The provider member details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public ViewProviderMemberDetails viewMember(ProviderPartyKey providerPartyKey)
    throws AppException, InformationalException {

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerPartyKey.providerPartyID);

    final ViewProviderMemberDetails viewProviderMemberDetails = new ViewProviderMemberDetails();

    final ConcernRole party = providerMember.getParty();

    viewProviderMemberDetails.name = party.getName();
    viewProviderMemberDetails.concernRoleType = party.getConcernRoleType().getCode();

    viewProviderMemberDetails.memberConcernRoleID = providerMember.getParty().getID();
    viewProviderMemberDetails.fromDate = providerMember.getDateRange().start();
    viewProviderMemberDetails.toDate = providerMember.getDateRange().end();
    viewProviderMemberDetails.recordStatus = providerMember.getLifecycleState().getCode();
    viewProviderMemberDetails.role = providerMember.getRole().getCode();
    // BEGIN, CR00117581, MST
    viewProviderMemberDetails.position = providerMember.getPosition().getCode();
    // END, CR00117581

    viewProviderMemberDetails.versionNo = providerMember.getVersionNo();

    return viewProviderMemberDetails;

  }

  /**
   * Updates the Provider Member with the provider member details passed.
   *
   * @param providerMemberDetails
   * Contains the details of Provider member.
   *
   * @return The provider party ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderPartyKey modifyProviderMember(
    ProviderMemberDetails providerMemberDetails) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerMemberDetails.providerPartyID);

    providerMember.setDateRange(
      new DateRange(providerMemberDetails.startDate,
      providerMemberDetails.endDate));
    providerMember.setRole(
      ProviderMemberRoleEntry.get(providerMemberDetails.memberRole));
    // BEGIN, CR00117581, MST
    providerMember.setPosition(
      PROVIDERMEMBERPOSITIONEntry.get(providerMemberDetails.position));
    // END, CR00117581

    providerMember.modify(providerMemberDetails.versionNo);

    // BEGIN, CR00118010, MST
    for (ProviderMemberOffering providerMemberOffering : providerMemberOfferingDAO.searchByProviderParty(
      providerMember.getID())) {

      if (providerMemberOffering.getLifecycleState().equals(
        RECORDSTATUSEntry.NORMAL)) {

        providerMemberOffering.setDateRange(
          new DateRange(providerMemberDetails.startDate,
          providerMemberDetails.endDate));

        providerMemberOffering.modify(providerMemberOffering.getVersionNo());
      }
    }
    // END, CR00118010

    final ProviderPartyKey providerPartyKey = new ProviderPartyKey();

    providerPartyKey.providerPartyID = providerMember.getID();

    return providerPartyKey;
  }

  /**
   * Creates Provider Group Member with the provider group member details
   * passed.
   *
   * @param createProviderMemberDetails
   * Contains the provider group member details.
   *
   * @return The provider party ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_NAME_NOT_ENTERED}
   * - If name is not entered.
   */
  public ProviderPartyKey createProviderGroupMember(
    CreateProviderMemberDetails createProviderMemberDetails)
    throws AppException, InformationalException {

    validateInsert(createProviderMemberDetails);

    if (0 == createProviderMemberDetails.searchConcernRoleID) {

      if (StringHelper.isEmpty(createProviderMemberDetails.name)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_NAME_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
      }

      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = createProviderMemberDetails.name;

      representativeRegistrationDetails.representativeRegistrationDetails.addressData = createProviderMemberDetails.addressData;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = createProviderMemberDetails.phoneCountryCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = createProviderMemberDetails.phoneAreaCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = createProviderMemberDetails.phoneNumber;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension = createProviderMemberDetails.phoneExtension;
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();

      representativeRegistrationDetails.representativeDtls.representativeType = REPRESENTATIVETYPE.CONTACT;

      representativeObj.registerRepresentative(
        representativeRegistrationDetails);

      createProviderMemberDetails.memberID = representativeRegistrationDetails.representativeDtls.concernRoleID;

    } else {
      createProviderMemberDetails.memberID = createProviderMemberDetails.searchConcernRoleID;
    }

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.newInstance();

    final curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
      createProviderMemberDetails.memberID);

    providerMember.setParty(concernRole);

    final ProviderGroup providerGroup = providerGroupDAO.get(
      createProviderMemberDetails.providerID);

    providerMember.setProviderOrganization(providerGroup);
    // BEGIN, CR00229065, PS
    providerMember.setRole(ProviderMemberRoleEntry.EMPLOYEE);
    // END, CR00229065
    // BEGIN, CR00117581, MST
    providerMember.setPosition(
      PROVIDERMEMBERPOSITIONEntry.get(createProviderMemberDetails.position));
    // END, CR00117581

    providerMember.setDateRange(
      new DateRange(createProviderMemberDetails.fromDate,
      createProviderMemberDetails.toDate));
    
    providerMember.insert();

    final ProviderPartyKey providerMemberKey = new ProviderPartyKey();

    providerMemberKey.providerPartyID = providerMember.getID();

    ValidationHelper.failIfErrorsExist();

    return providerMemberKey;
  }

  // BEGIN, CR00118010, MST
  // BEGIN, CR00273435, GYH
  /**
   * Creates Provider Member with the provider member details passed.
   *
   * @param createProviderMemberDetails
   * Contains the details of the member.
   *
   * @return The information message list and the internal identifier for
   * provider party.
   *
   * @throws AppException
   * Generic Exception Signature.
   *
   * @throws InformationalException
   * {@link curam.message.CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_NAME_NOT_ENTERED}
   * - If name is not entered.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ProviderMember#createProviderMemberDetails(CreateProviderMemberDetails)}
   * . This method has been deprecated because this is not returning
   * the parameter 'memberConcernRoleID' which is required for
   * provider member tab. See release note: CR00273435.
   */
  @Deprecated
  // END, CR00273435
  public ProviderMemberCreationDetails createProviderMember(
    CreateProviderMemberDetails createProviderMemberDetails)
    throws AppException, InformationalException {

    validateInsert(createProviderMemberDetails);

    if (0 == createProviderMemberDetails.searchConcernRoleID) {

      if (StringHelper.isEmpty(createProviderMemberDetails.name)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_NAME_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }

      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = createProviderMemberDetails.name;

      representativeRegistrationDetails.representativeRegistrationDetails.addressData = createProviderMemberDetails.addressData;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = createProviderMemberDetails.phoneCountryCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = createProviderMemberDetails.phoneAreaCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = createProviderMemberDetails.phoneNumber;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension = createProviderMemberDetails.phoneExtension;
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();

      representativeRegistrationDetails.representativeDtls.representativeType = REPRESENTATIVETYPE.CONTACT;

      representativeObj.registerRepresentative(
        representativeRegistrationDetails);

      createProviderMemberDetails.searchConcernRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;

    }
    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.newInstance();

    final curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
      createProviderMemberDetails.searchConcernRoleID);

    providerMember.setParty(concernRole);

    final ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      createProviderMemberDetails.providerID);

    providerMember.setProviderOrganization(providerOrganization);
    providerMember.setRole(
      ProviderMemberRoleEntry.get(createProviderMemberDetails.role));
    // BEGIN, CR00117581, MST
    providerMember.setPosition(
      PROVIDERMEMBERPOSITIONEntry.get(createProviderMemberDetails.position));
    // END, CR00117581

    providerMember.setDateRange(
      new DateRange(createProviderMemberDetails.fromDate,
      createProviderMemberDetails.toDate));

    // BEGIN, CR00205270, ASN
    providerMember.setCategory(ProviderPartyCategoryEntry.MEMBER);
    // END, CR00205270
    providerMember.insert();

    final ProviderPartyKey providerMemberKey = new ProviderPartyKey();

    providerMemberKey.providerPartyID = providerMember.getID();

    ValidationHelper.failIfErrorsExist();

    ProviderMemberCreationDetails providerMemberCreationDetails = new ProviderMemberCreationDetails();

    InformationalMessageList informationalMessageList = providerMember.validateTrainingProgramsForProviderMember(
      createProviderMemberDetails.providerOfferings);

    // BEGIN, CR00123721, CMB
    providerMemberCreationDetails.providerPartyID = providerMemberKey.providerPartyID;
    // END, CR00123721
    providerMemberCreationDetails.infoMsgList.assign(informationalMessageList);

    // Split the selected provider offerings into a string array
    final String[] providerOfferings = StringUtil.tabText2StringList(createProviderMemberDetails.providerOfferings).items();

    // For each provider offering create a provider member offering record
    for (final String providerOfferingString : providerOfferings) {

      final ProviderMemberOffering providerMemberOffering = providerMemberOfferingDAO.newInstance();

      providerMemberOffering.setProviderOffering(
        providerOfferingDAO.get(Long.parseLong(providerOfferingString)));

      providerMemberOffering.setProviderParty(
        providerMemberDAO.get(providerMemberKey.providerPartyID));

      // Takes the membership date range and service offering date range and
      // set the provider member offering date range to fall within
      // both of them.
      providerMemberOffering.setDateRangeAndAdjustForValidRange(
        new DateRange(createProviderMemberDetails.fromDate,
        createProviderMemberDetails.toDate));

      providerMemberOffering.insert();
    }

    return providerMemberCreationDetails;
  }

  // END, CR00118010

  /**
   * This method is used to get all the provider offering for the provider for
   * linking with provider member.
   *
   * @param providerKey
   * Contains the internal identifier for the provider.
   *
   * @return The list of Provider offerings.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderOfferingLinkDetailsList listProviderOfferings(
    ProviderKey providerKey) throws AppException, InformationalException {

    final ProviderOfferingLinkDetailsList providerOfferingLinkDetailsList = new ProviderOfferingLinkDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    for (final ProviderOffering providerOffering : providerOfferingDAO.searchBy(
      provider)) {

      // BEGIN, CR00121727, KR
      // Only provider offerings which are Active and have an End Date in the
      // future or do not have an End Date can be listed to a Provider Member.
      if ((providerOffering.getLifecycleState().equals(
        ProviderOfferingStatusEntry.PENDINGAPPROVAL)
          || providerOffering.getLifecycleState().equals(
            ProviderOfferingStatusEntry.APPROVED))
              && providerOffering.getDateRange().endsInFuture()) {
        // END, CR00121727

        final ProviderOfferingLinkDetails providerOfferingLinkDetails = new ProviderOfferingLinkDetails();

        providerOfferingLinkDetails.description = providerOffering.getServiceOffering().getName();
        providerOfferingLinkDetails.code = providerOffering.getID();

        providerOfferingLinkDetailsList.details.addRef(
          providerOfferingLinkDetails);
      }
    }

    return providerOfferingLinkDetailsList;
  }

  // BEGIN, CR00118010, MST
  /**
   * Method used to add provider member offering for a provider member. Active
   * membership for a person with a provider will be considered for date range
   * of linking provider member and provider offering.
   *
   * @param providerMemberOfferingDetails
   * Details of the link between provider member and provider offering.
   *
   * @return The information message list and the internal identifier for the
   * provider member offering.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderMemberOfferingCreationDetails createProviderMemberOffering(
    ProviderMemberOfferingDetails providerMemberOfferingDetails)
    throws AppException, InformationalException {

    final ProviderMemberOfferingCreationDetails providerMemberOfferingCreationDetails = new ProviderMemberOfferingCreationDetails();

    final curam.provider.impl.ProviderMemberOffering providerMemberOffering = providerMemberOfferingDAO.newInstance();

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerMemberOfferingDetails.dtls.providerPartyID);

    providerMemberOffering.setProviderOffering(
      providerOfferingDAO.get(
        providerMemberOfferingDetails.dtls.providerOfferingID));
    providerMemberOffering.setProviderParty(providerMember);
    // Set the date range after setting provider offering and provider party
    // as these entities will be used for validation on setting the date range.
    providerMemberOffering.setDateRange(
      new DateRange(providerMemberOfferingDetails.dtls.startDate,
      providerMemberOfferingDetails.dtls.endDate));

    providerMemberOffering.setComments(
      providerMemberOfferingDetails.dtls.comments);

    providerMemberOffering.insert();

    providerMemberOfferingCreationDetails.providerMemberOfferingID = providerMemberOffering.getID();

    // Check the training required for the service offering that is associated
    // to the provider member and display as informational message.
    InformationalMessageList informationalMessageList = providerMember.validateTrainingProgramsForProviderMember(
      Long.toString(providerMemberOfferingDetails.dtls.providerOfferingID));

    providerMemberOfferingCreationDetails.infoMsgList.assign(
      informationalMessageList);

    return providerMemberOfferingCreationDetails;
  }

  /**
   * Method used to delete a provider member offering for a provider member.
   *
   * @param providerMemberOfferingKey
   * Contains the internal identifier for the provider member offering.
   * @param versionNo
   * Contains the version number of the entity that is to be deleted.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deleteProviderMemberOffering(
    ProviderMemberOfferingKey providerMemberOfferingKey, VersionNo versionNo)
    throws AppException, InformationalException {

    final curam.provider.impl.ProviderMemberOffering providerMemberOffering = providerMemberOfferingDAO.get(
      providerMemberOfferingKey.providerMemberOfferingID);

    providerMemberOffering.cancel(versionNo.versionNo);
  }

  /**
   * Method used to retrieve all the provider member offering for a provider
   * member.
   *
   * @param providerPartyKey
   * Contains the internal identifier for the provider member.
   *
   * @return The list of provider offering details that the person offers.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderMemberOfferingDetailsList listProviderMemberOfferings(
    ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    final ProviderMemberOfferingDetailsList providerMemberOfferingDetailsList = new ProviderMemberOfferingDetailsList();

    for (curam.provider.impl.ProviderMemberOffering providerMemberOffering : sortProviderMemberOfferings(
      providerMemberOfferingDAO.searchByProviderParty(
        providerPartyKey.providerPartyID))) {

      final ProviderMemberOfferingDetails providerMemberOfferingDetails = getProviderMemberOfferingDetails(
        providerMemberOffering);

      providerMemberOfferingDetails.serviceOfferingName = providerMemberOffering.getProviderOffering().getServiceOffering().getName();

      providerMemberOfferingDetailsList.details.addRef(
        providerMemberOfferingDetails);
    }

    return providerMemberOfferingDetailsList;
  }

  // BEGIN, CR00121367, ABS
  /**
   * Method used to modify provider member offering details.
   *
   * @param providerMemberOfferingDetails
   * Details of the link between provider member and provider offering.
   * @param versionNo
   * Version number the entity that is to be modified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00121367
  public void modifyProviderMemberOffering(
    ProviderMemberOfferingDetails providerMemberOfferingDetails,
    VersionNo versionNo) throws AppException, InformationalException {

    // Get the instance for the ProviderMemberOffering and set the values that
    // can be modified from the client.
    final curam.provider.impl.ProviderMemberOffering providerMemberOffering = providerMemberOfferingDAO.get(
      providerMemberOfferingDetails.dtls.providerMemberOfferingID);

    providerMemberOffering.setDateRange(
      new DateRange(providerMemberOfferingDetails.dtls.startDate,
      providerMemberOfferingDetails.dtls.endDate));
    providerMemberOffering.setComments(
      providerMemberOfferingDetails.dtls.comments);

    providerMemberOffering.modify(versionNo.versionNo);
  }

  /**
   * Method used to view the details of provider member offering.
   *
   * @param providerMemberOfferingKey
   * Contains the internal identifier for provider member offering.
   *
   * @return The provider member offering details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderMemberOfferingDetails viewProviderMemberOffering(
    ProviderMemberOfferingKey providerMemberOfferingKey) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderMemberOffering providerMemberOffering = providerMemberOfferingDAO.get(
      providerMemberOfferingKey.providerMemberOfferingID);

    final ProviderMemberOfferingDetails providerMemberOfferingDetails = getProviderMemberOfferingDetails(
      providerMemberOffering);

    providerMemberOfferingDetails.serviceOfferingName = providerMemberOffering.getProviderOffering().getServiceOffering().getName();

    return providerMemberOfferingDetails;
  }

  /**
   * Lists all the active provider offerings for a given provider.
   *
   * @param providerKey
   * Contains internal identifier for provider.
   *
   * @return List of active Provider offerings for the given provider.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderOfferingSummaryDetailsList listActiveProviderOfferingsByProvider(
    ProviderKey providerKey) throws AppException, InformationalException {

    ProviderOfferingSummaryDetailsList providerOfferingSummaryDetailsList = new ProviderOfferingSummaryDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    // Loop through the provider offering and include only those in
    // PENDING APPROVAL or APPROVED status.
    Set<ProviderOffering> unModifiableProviderOfferings = provider.getProviderOfferings();
    Set<ProviderOffering> providerOfferings = new HashSet<ProviderOffering>();

    providerOfferings.addAll(unModifiableProviderOfferings);

    for (final curam.providerservice.impl.ProviderOffering providerOffering : sortProviderOfferings(
      providerOfferings)) {

      if ((providerOffering.getLifecycleState().equals(
        ProviderOfferingStatusEntry.PENDINGAPPROVAL)
          || providerOffering.getLifecycleState().equals(
            ProviderOfferingStatusEntry.APPROVED))
              && providerOffering.getDateRange().endsInFuture()) {

        ProviderOfferingSummaryDetails providerOfferingSummaryDetails = new ProviderOfferingSummaryDetails();

        providerOfferingSummaryDetails.serviceOfferingID = providerOffering.getServiceOffering().getID();
        providerOfferingSummaryDetails.providerOfferingID = providerOffering.getID();
        providerOfferingSummaryDetails.startDate = providerOffering.getDateRange().start();
        providerOfferingSummaryDetails.endDate = providerOffering.getDateRange().end();
        providerOfferingSummaryDetails.name = providerOffering.getServiceOffering().getName();
        providerOfferingSummaryDetails.recordStatus = providerOffering.getLifecycleState().getCode();

        providerOfferingSummaryDetailsList.providerOfferingSummaryDetails.addRef(
          providerOfferingSummaryDetails);
      }
    }

    return providerOfferingSummaryDetailsList;
  }

  // END, CR00118010

  // BEGIN, CR00117630, ASB
  /**
   * Get the menu context description for the View Member for a Provider
   *
   * @param providerPartyKey
   * Internal system identifier of Member record.
   * @param providerKey
   * Internal system identifier of Provider record.
   *
   * @return The menu context description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CaseMenuData viewProviderMemberContextDescription(
    ProviderPartyKey providerPartyKey, ProviderKey providerKey)
    throws AppException, InformationalException {

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerPartyKey.providerPartyID);

    final ConcernRole party = providerMember.getParty();

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    Element navigationMenuElement = new Element(
      XmlMetaDataConst.kNavigationMenu);
    Element linkElement = new Element(XmlMetaDataConst.kItem);
    Element paramElement = new Element(XmlMetaDataConst.kParam);

    // Set up node property values
    LocalisableString description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(provider.getName());

    // Set up node property values
    linkElement.setAttribute(XmlMetaDataConst.kPageID,
      CPMConstants.kViewProvider);
    linkElement.setAttribute(XmlMetaDataConst.kDesc,
      description.toClientFormattedText());
    linkElement.setAttribute(XmlMetaDataConst.kType, XmlMetaDataConst.kTypeCase);

    navigationMenuElement.addContent(linkElement);

    // set the parameter values
    paramElement.setAttribute(XmlMetaDataConst.kName,
      CPMConstants.kParamProviderConcernRoleID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(providerKey.providerConcernRoleID));

    linkElement.addContent(paramElement);

    // second link element
    linkElement = new Element(XmlMetaDataConst.kItem);
    description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);
    description.arg(party.getName());

    // Set up node property values
    linkElement.setAttribute(XmlMetaDataConst.kPageID,
      CPMConstants.kViewProviderMember);
    linkElement.setAttribute(XmlMetaDataConst.kDesc,
      description.toClientFormattedText());
    linkElement.setAttribute(XmlMetaDataConst.kType, XmlMetaDataConst.kTypeCase);

    navigationMenuElement.addContent(linkElement);

    // set the parameter values
    paramElement = new Element(XmlMetaDataConst.kParam);
    paramElement.setAttribute(XmlMetaDataConst.kName,
      CPMConstants.kParamProviderPartyID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(providerPartyKey.providerPartyID));

    linkElement.addContent(paramElement);

    // set the parameter values
    paramElement = new Element(XmlMetaDataConst.kParam);
    paramElement.setAttribute(XmlMetaDataConst.kName,
      CPMConstants.kParamProviderConcernRoleID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(providerKey.providerConcernRoleID));

    linkElement.addContent(paramElement);

    XMLOutputter outputter = new XMLOutputter();
    CaseMenuData caseMenuData = new CaseMenuData();

    caseMenuData.menuData = outputter.outputString(navigationMenuElement);
    return caseMenuData;
  }

  /**
   * Get the menu context description for the View Member for Provider Group.
   *
   * @param providerPartyKey
   * Internal system identifier of Member record.
   * @param providerGroupKey
   * Internal system identifier of Provider Group record.
   *
   * @return The menu context description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CaseMenuData viewProviderGroupMemberContextDescription(
    ProviderPartyKey providerPartyKey, ProviderGroupKey providerGroupKey)
    throws AppException, InformationalException {

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerPartyKey.providerPartyID);

    final ConcernRole party = providerMember.getParty();

    final curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      providerGroupKey.providerGroupConcernRoleID);

    Element navigationMenuElement = new Element(
      XmlMetaDataConst.kNavigationMenu);
    Element linkElement = new Element(XmlMetaDataConst.kItem);
    Element paramElement = new Element(XmlMetaDataConst.kParam);

    // Set up node property values
    LocalisableString description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(providerGroup.getName());

    // Set up node property values
    linkElement.setAttribute(XmlMetaDataConst.kPageID,
      CPMConstants.kViewProviderGroupHome);
    linkElement.setAttribute(XmlMetaDataConst.kDesc,
      description.toClientFormattedText());
    linkElement.setAttribute(XmlMetaDataConst.kType, XmlMetaDataConst.kTypeCase);

    navigationMenuElement.addContent(linkElement);

    // set the parameter values
    paramElement.setAttribute(XmlMetaDataConst.kName,
      CPMConstants.kParamProviderGroupConcernRoleID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(providerGroupKey.providerGroupConcernRoleID));

    linkElement.addContent(paramElement);

    // second link element
    linkElement = new Element(XmlMetaDataConst.kItem);
    description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);
    description.arg(party.getName());

    // Set up node property values
    linkElement.setAttribute(XmlMetaDataConst.kPageID,
      CPMConstants.kViewProviderGroupMember);
    linkElement.setAttribute(XmlMetaDataConst.kDesc,
      description.toClientFormattedText());
    linkElement.setAttribute(XmlMetaDataConst.kType, XmlMetaDataConst.kTypeCase);

    navigationMenuElement.addContent(linkElement);

    // set the parameter values
    paramElement = new Element(XmlMetaDataConst.kParam);
    paramElement.setAttribute(XmlMetaDataConst.kName,
      CPMConstants.kParamProviderPartyID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(providerPartyKey.providerPartyID));

    linkElement.addContent(paramElement);

    // set the parameter values
    paramElement = new Element(XmlMetaDataConst.kParam);
    paramElement.setAttribute(XmlMetaDataConst.kName,
      CPMConstants.kParamProviderGroupConcernRoleID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(providerGroupKey.providerGroupConcernRoleID));

    linkElement.addContent(paramElement);

    XMLOutputter outputter = new XMLOutputter();
    CaseMenuData caseMenuData = new CaseMenuData();

    caseMenuData.menuData = outputter.outputString(navigationMenuElement);
    return caseMenuData;
  }

  // END, CR00117630

  // BEGIN, CR00121367, ABS
  /**
   * Retrieves list of person and representatives that satisfies the search
   * criteria.
   *
   * @param searchPersonKey
   * Search criteria.
   *
   * @return The list of person details that satisfies the search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PERSON#ERR_PERSON_FV_SEARCH_CRITERIA_NOT_ENTERED}
   * - If search criteria is not entered.
   * @deprecated Since Curam 6.0, this method has been replaced by
   * {@link #searchPersonAndRepresentative1()}. The new method
   * returns the details like address line and city in the search
   * results.
   */
  @Deprecated
  public SearchPersonDetailsList searchPersonAndRepresentative(
    SearchPersonKey searchPersonKey) throws AppException,
      InformationalException {

    String searchPerson = searchPersonKey.searchKey.addressLine1.trim()
      + searchPersonKey.searchKey.firstName.trim()
      + searchPersonKey.searchKey.lastName.trim()
      + searchPersonKey.searchKey.referenceNo.trim();

    // BEGIN, CR00154489, ASEN
    if (searchPerson.equals(GeneralConstants.kEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PERSONExceptionCreator.ERR_PERSON_FV_SEARCH_CRITERIA_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 4);
      // BEGIN, CR00154489, ASEN
      ValidationHelper.failIfErrorsExist();
      // END, CR00154489
    }

    SearchPersonDetailsList personDetailsList = new SearchPersonDetailsList();

    // Retrieve the list of persons that satisfies the search criteria
    curam.cpm.sl.entity.struct.SearchPersonDetailsList searchPersonDetailsList = personDAO.searchPersonByNameAndAddress(
      searchPersonKey.searchKey.referenceNo,
      searchPersonKey.searchKey.addressLine1,
      searchPersonKey.searchKey.firstName, searchPersonKey.searchKey.lastName,
      false, false);

    for (int i = 0; i < searchPersonDetailsList.dtls.size(); i++) {
      SearchPersonDetails searchPersonDetails = new SearchPersonDetails();

      searchPersonDetails.searchDetails = searchPersonDetailsList.dtls.item(i);
      personDetailsList.details.addRef(searchPersonDetails);

    }
    // Retrieve the list of representatives that satisfies the search criteria
    searchPersonDetailsList = personDAO.searchRepresentativeByNameAndAddress(
      searchPersonKey.searchKey.referenceNo,
      searchPersonKey.searchKey.addressLine1,
      searchPersonKey.searchKey.firstName, searchPersonKey.searchKey.lastName,
      false, false);
    for (int i = 0; i < searchPersonDetailsList.dtls.size(); i++) {
      // BEGIN, CR00136547, ASN
      SearchRepresentativeDetails searchRepresentativeDetails = new SearchRepresentativeDetails();

      searchRepresentativeDetails.concernRoleID = searchPersonDetailsList.dtls.item(i).concernRoleID;
      searchRepresentativeDetails.concernRoleName = searchPersonDetailsList.dtls.item(i).concernRoleName;
      searchRepresentativeDetails.referenceNo = searchPersonDetailsList.dtls.item(i).referenceNo;
      personDetailsList.representative.addRef(searchRepresentativeDetails);
      // END, CR00136547
    }
    return personDetailsList;
  }

  // END, CR00121367

  /**
   * Retrieves the employment history for a provider member or provider group
   * member.
   *
   * @param providerPartyKey
   * Provider party key.
   *
   * @return The list containing a summary of employment snapshot details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadEmploymentHistoryList listEmploymentHistory(
    ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    ReadEmploymentHistoryList readEmploymentHistoryList = new ReadEmploymentHistoryList();

    ProviderParty providerPartyObj = providerPartyDAO.get(
      providerPartyKey.providerPartyID);

    Employment employmentObj = EmploymentFactory.newInstance();
    EmploymentAndStatusReadMultiKey employmentAndStatusReadMultiKey = new EmploymentAndStatusReadMultiKey();

    employmentAndStatusReadMultiKey.concernRoleID = providerPartyObj.getParty().getID();
    employmentAndStatusReadMultiKey.status = RECORDSTATUS.NORMAL;
    EmploymentReadMultiDtlsList employmentReadMultiDtlsList = employmentObj.searchActiveEmploymentsByConcernRole(
      employmentAndStatusReadMultiKey);

    for (int i = 0; i < employmentReadMultiDtlsList.dtls.size(); i++) {

      EmploymentSnapshotListDtls employmentSnapshotListDtls = new EmploymentSnapshotListDtls();

      employmentSnapshotListDtls.employerName = employmentReadMultiDtlsList.dtls.item(i).employerName;
      employmentSnapshotListDtls.employerType = employmentReadMultiDtlsList.dtls.item(i).employerType;
      employmentSnapshotListDtls.employerConcernRoleID = employmentReadMultiDtlsList.dtls.item(i).employerConcernRoleID;
      employmentSnapshotListDtls.fromDate = employmentReadMultiDtlsList.dtls.item(i).fromDate;
      employmentSnapshotListDtls.toDate = employmentReadMultiDtlsList.dtls.item(i).toDate;
      employmentSnapshotListDtls.occupationType = employmentReadMultiDtlsList.dtls.item(i).occupationType;
      employmentSnapshotListDtls.status = employmentReadMultiDtlsList.dtls.item(i).status;
      employmentSnapshotListDtls.employmentSnapshotID = employmentReadMultiDtlsList.dtls.item(i).employmentID;
      employmentSnapshotListDtls.primaryCurrentInd = employmentReadMultiDtlsList.dtls.item(i).primaryCurrentInd;

      readEmploymentHistoryList.listDtls.addRef(employmentSnapshotListDtls);
    }

    return readEmploymentHistoryList;
  }

  // BEGIN, CR00128037, JSP
  /**
   * Retrieves the membership history for a provider member or provider group
   * member.
   *
   * @param providerPartyKey
   * Provider party key.
   *
   * @return The provider member details list.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderMembershipHistoryList listMembershipHistory(
    ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    ProviderMembershipHistoryList providerMembershipHistoryList = new ProviderMembershipHistoryList();
    ProviderParty providerPartyObj = providerPartyDAO.get(
      providerPartyKey.providerPartyID);

    // Retrieve the membership details of the concern role
    Set<curam.provider.impl.ProviderMember> providerMemberList = providerMemberDAO.listPersonMembershipHistory(
      providerPartyObj.getParty().getID(), ProviderPartyCategoryEntry.MEMBER,
      RECORDSTATUSEntry.NORMAL);

    for (curam.provider.impl.ProviderMember providerMember : providerMemberList) {

      ProviderMembershipHistory providerMembershipHistory = new ProviderMembershipHistory();

      providerMembershipHistory.fromDate = providerMember.getDateRange().start();
      providerMembershipHistory.toDate = providerMember.getDateRange().end();
      providerMembershipHistory.providerName = providerOrganizationDAO.get(providerMember.getProviderOrganization().getID()).getName();
      providerMembershipHistory.role = providerMember.getType();
      providerMembershipHistory.status = providerMember.getLifecycleState().getCode();
      providerMembershipHistory.providerID = providerMember.getProviderOrganization().getID();
      providerMembershipHistory.concernRoleType = providerMember.getProviderOrganization().getConcernRoleType().getCode();

      providerMembershipHistoryList.historyDetails.addRef(
        providerMembershipHistory);
    }

    return providerMembershipHistoryList;
  }

  // END, CR00128037

  // BEGIN, CR00128578, JSP
  /**
   * Method returns the page context description for a Provider Member or
   * Provider Group Member.
   *
   * @param providerPartyKey
   * Contains provider member or provider group member id.
   *
   * @return Page context description for the provider member or provider group
   * member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ContextDescription readProviderPartySummaryDetails(
    ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    ContextDescription contextDescription = new ContextDescription();

    contextDescription.description = providerPartyDAO.get(providerPartyKey.providerPartyID).getParty().getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace
      + providerPartyDAO.get(providerPartyKey.providerPartyID).getParty().getPrimaryAlternateID();

    return contextDescription;
  }

  // END, CR00128578

  // BEGIN, CR00199066, GP
  /**
   * Retrieves the list of members for a given concern role.
   *
   * @param concernRoleKey
   * Concern role for which members are to be retrieved.
   *
   * @return The list of member summary details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderMemberSummaryVersionDetailsList listMembersForConcernRole(
    final ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    final ProviderMemberSummaryVersionDetailsList providerMemberSummaryVersionDetailsList = new ProviderMemberSummaryVersionDetailsList();

    // BEGIN, CR00291561, SS
    // BEGIN, CR00292956, SS
    final ConcernRoleIDCategory concernRoleIDCategory = new ConcernRoleIDCategory();

    concernRoleIDCategory.providerConcernRoleID = concernRoleKey.concernRoleID;
    concernRoleIDCategory.category = ProviderPartyCategoryEntry.MEMBER.getCode();
    // END, CR00292956
    curam.cpm.sl.entity.intf.ProviderParty providerParty = ProviderPartyFactory.newInstance();
    // BEGIN, CR00292956, SS
    ProviderPartyDetailsList providerPartyDetailsList = providerParty.searchProviderMember(
      concernRoleIDCategory);

    // END, CR00292956

    for (ProviderPartyDetails providerPartyDetails : providerPartyDetailsList.dtls.items()) {
      final ProviderMemberSummaryVersionDetails providerMemberSummaryVersionDetails = new ProviderMemberSummaryVersionDetails();

      providerMemberSummaryVersionDetails.versionDetails.providerMemberID = providerPartyDetails.providerMemberID;
      providerMemberSummaryVersionDetails.versionDetails.memberConcernRoleID = providerPartyDetails.memberConcernRoleID;
      providerMemberSummaryVersionDetails.versionDetails.concernRoleType = providerPartyDetails.concernRoleType;
      providerMemberSummaryVersionDetails.versionDetails.providerConcernRoleID = providerPartyDetails.providerConcernRoleID;
      
      // BEGIN, CR00320064, SSK
      providerMemberSummaryVersionDetails.versionDetails.fromDate = new Date(
        TimeZoneUtil.convertToClientTimeZone(
          providerPartyDetails.startDateTimeOpt.getCalendar()));
      
      if (!DateTime.kZeroDateTime.equals(providerPartyDetails.endDateTimeOpt)) {
        providerMemberSummaryVersionDetails.versionDetails.toDate = new Date(
          TimeZoneUtil.convertToClientTimeZone(
            providerPartyDetails.endDateTimeOpt.getCalendar()));
      }
      
      // END, CR00320064
      providerMemberSummaryVersionDetails.versionDetails.recordStatus = providerPartyDetails.recordStatus;
      providerMemberSummaryVersionDetails.versionDetails.role = providerPartyDetails.role;
      providerMemberSummaryVersionDetails.versionDetails.position = providerPartyDetails.position;
      providerMemberSummaryVersionDetails.versionDetails.memberName = providerPartyDetails.memberName;
      providerMemberSummaryVersionDetails.versionNo = providerPartyDetails.versionNo;
      providerMemberSummaryVersionDetailsList.detailsList.addRef(
        providerMemberSummaryVersionDetails);
    }
    // END, CR00291561
    return providerMemberSummaryVersionDetailsList;
  }

  // END, CR00199066

  // BEGIN, CR00184531, GP
  /**
   * Reads the provider member details that are required to be shown on provider
   * member tab details.
   *
   * @param providerMemberKey
   * Provider member for which details are to be returned.
   *
   * @return Provider member details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00199066, GP
  public ViewProviderMemberTabDetails viewProviderMemberTabDetails(
    final ProviderPartyKey providerMemberKey) throws AppException,
      InformationalException {
    // END, CR00199066

    ViewProviderMemberTabDetails viewProviderMemberTabDetails = new ViewProviderMemberTabDetails();

    curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerMemberKey.providerPartyID);

    ViewProviderMemberDetails viewProviderMemberDetails = viewMember(
      providerMemberKey);

    viewProviderMemberTabDetails.concernRoleType = viewProviderMemberDetails.concernRoleType;
    viewProviderMemberTabDetails.fromDate = viewProviderMemberDetails.fromDate;
    viewProviderMemberTabDetails.memberConcernRoleID = viewProviderMemberDetails.memberConcernRoleID;
    viewProviderMemberTabDetails.memberName = viewProviderMemberDetails.name;
    viewProviderMemberTabDetails.position = viewProviderMemberDetails.position;
    viewProviderMemberTabDetails.role = viewProviderMemberDetails.role;
    viewProviderMemberTabDetails.status = viewProviderMemberDetails.recordStatus;
    viewProviderMemberTabDetails.providerConcernRoleID = providerMember.getProviderOrganization().getID();
    viewProviderMemberTabDetails.providerName = providerMember.getProviderOrganization().getName();

    Address addressObj = AddressFactory.newInstance();
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = providerMember.getParty().getPrimaryAddressID();
    AddressDtls addressDtls = addressObj.read(addressKey);

    OtherAddressData formattedAddressData = new OtherAddressData();

    formattedAddressData.addressData = addressDtls.addressData;
    addressObj.getAddressStrings(formattedAddressData);

    viewProviderMemberTabDetails.address = formattedAddressData.addressData;

    final PhoneNumber phoneNumber = providerMember.getParty().getPrimaryPhoneNumber();

    if (null != phoneNumber) {

      PhoneForConcernRoleKey phoneForConcernRoleKey = new PhoneForConcernRoleKey();

      phoneForConcernRoleKey.concernRoleID = viewProviderMemberDetails.memberConcernRoleID;
      phoneForConcernRoleKey.phoneNumberID = phoneNumber.getID();

      viewProviderMemberTabDetails.phoneNumber = phoneNumber.getNumber();
      viewProviderMemberTabDetails.phoneAreaCode = phoneNumber.getAreaCode();
      viewProviderMemberTabDetails.phoneCountryCode = phoneNumber.getCountryCode();
      viewProviderMemberTabDetails.phoneExtension = phoneNumber.getExtension();
    }

    if (CONCERNROLETYPEEntry.PERSON.getCode().equals(
      viewProviderMemberTabDetails.concernRoleType)) {
      viewProviderMemberTabDetails.isPerson = true;
    } else {
      viewProviderMemberTabDetails.isPerson = false;
    }

    // BEGIN, CR00197239, DRS
    // BEGIN, CR00199066, GP
    ContentPanelBuilder containerPanel = ContentPanelBuilder.createPanel(
      CPMConstants.gkProviderMemContainer);

    // END, CR00199066

    // BEGIN, CR00304013, MR
    containerPanel = getMemberImagePanel(containerPanel,
      viewProviderMemberTabDetails, providerMemberKey);

    containerPanel = getMemberDetailsPanel(containerPanel, providerMember);

    // END, CR00304013
    viewProviderMemberTabDetails.providerMemberTabDetails = containerPanel.toString();
    // END, CR00199066

    return viewProviderMemberTabDetails;
  }

  // END, CR00224728

  // END, CR00184531

  // BEGIN, CR00205270, ASN
  /**
   * Updates the Unassigned Provider Member with the unassigned provider member
   * details passed.
   *
   * @param providerMemberDetails
   * Contains the details of Unassigned Provider Member.
   *
   * @return The provider party ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderPartyKey modifyUnassignedProviderMember(
    final ProviderMemberDetails providerMemberDetails) throws AppException,
      InformationalException {
    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerMemberDetails.providerPartyID);

    providerMemberDetails.memberRole = ProviderMemberRoleEntry.NOT_SPECIFIED.getCode();

    providerMember.setRole(
      ProviderMemberRoleEntry.get(providerMemberDetails.memberRole));
    providerMember.setDateRange(
      new DateRange(providerMemberDetails.startDate,
      providerMemberDetails.endDate));

    providerMember.modify(providerMemberDetails.versionNo);

    for (ProviderMemberOffering providerMemberOffering : providerMemberOfferingDAO.searchByProviderParty(
      providerMember.getID())) {

      if (providerMemberOffering.getLifecycleState().equals(
        RECORDSTATUSEntry.NORMAL)) {

        providerMemberOffering.setDateRange(
          new DateRange(providerMemberDetails.startDate,
          providerMemberDetails.endDate));

        providerMemberOffering.modify(providerMemberOffering.getVersionNo());
      }
    }

    final ProviderPartyKey providerPartyKey = new ProviderPartyKey();

    providerPartyKey.providerPartyID = providerMember.getID();

    return providerPartyKey;
  }

  // END, CR00205270

  /**
   * Method used to set the values from entity to facade struct for provider
   * member offering.
   *
   * @param providerMemberOffering
   * Provider member offering entity.
   *
   * @return Provider member offering details.
   */
  protected ProviderMemberOfferingDetails getProviderMemberOfferingDetails(
    curam.provider.impl.ProviderMemberOffering providerMemberOffering) {

    final ProviderMemberOfferingDetails providerMemberOfferingDetails = new ProviderMemberOfferingDetails();

    providerMemberOfferingDetails.dtls.providerMemberOfferingID = providerMemberOffering.getID();
    providerMemberOfferingDetails.dtls.providerOfferingID = providerMemberOffering.getProviderOffering().getID();
    providerMemberOfferingDetails.dtls.providerPartyID = providerMemberOffering.getProviderParty().getID();
    providerMemberOfferingDetails.dtls.startDate = providerMemberOffering.getDateRange().start();
    providerMemberOfferingDetails.dtls.endDate = providerMemberOffering.getDateRange().end();
    providerMemberOfferingDetails.dtls.comments = providerMemberOffering.getComments();
    providerMemberOfferingDetails.dtls.recordStatus = providerMemberOffering.getLifecycleState().getCode();
    providerMemberOfferingDetails.dtls.versionNo = providerMemberOffering.getVersionNo();

    return providerMemberOfferingDetails;
  }

  /**
   * This method is to validate provider member before insert to check whether
   * the member is a person or representative.
   *
   * @param createProviderMemberDetails
   * Contains the details of the provider member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_XRV_REGISTERED_PERSON_OR_REGISTRATION_DETAILS}
   * - If both registered person and registration details are entered.
   */
  // BEGIN, CR00177241, PM
  protected void validateInsert(
    CreateProviderMemberDetails createProviderMemberDetails)
    throws AppException, InformationalException {
    // END, CR00177241

    StringBuffer representativeDetails = new StringBuffer();
    OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = createProviderMemberDetails.addressData;
    curam.core.intf.Address addressObj = AddressFactory.newInstance();

    representativeDetails.append(createProviderMemberDetails.name);

    // BEGIN, CR00129731, SK
    if (!(addressObj.isEmpty(otherAddressData)).emptyInd) {
      addressObj.getAddressStrings(otherAddressData);
      representativeDetails.append(otherAddressData.addressData.trim());
    }
    // END, CR00129731

    representativeDetails.append(createProviderMemberDetails.phoneAreaCode);
    representativeDetails.append(createProviderMemberDetails.phoneCountryCode);
    representativeDetails.append(createProviderMemberDetails.phoneExtension);
    representativeDetails.append(createProviderMemberDetails.phoneNumber);

    if (0 != createProviderMemberDetails.searchConcernRoleID
      && 0 != representativeDetails.toString().length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_REGISTERED_PERSON_OR_REGISTRATION_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }

  }

  /**
   * Sorts a set of provider offerings into a sorted list for display.
   *
   * @param unsortedProviderOfferings
   * The set of provider offerings.
   *
   * @return The sorted list of provider offerings for display.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.providerservice.impl.ProviderOffering> sortProviderOfferings(
    final Set<curam.providerservice.impl.ProviderOffering> unsortedProviderOfferings) {
    // END, CR00177241
    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    final List<curam.providerservice.impl.ProviderOffering> providerOfferings = new ArrayList<curam.providerservice.impl.ProviderOffering>(
      unsortedProviderOfferings);

    Collections.sort(providerOfferings,
      new Comparator<curam.providerservice.impl.ProviderOffering>() {
      public int compare(
        final curam.providerservice.impl.ProviderOffering lhs,
        curam.providerservice.impl.ProviderOffering rhs) {
        return lhs.getServiceOffering().getName().compareTo(
          rhs.getServiceOffering().getName());
      }
    });
    return providerOfferings;
  }

  /**
   * Sorts a set of provider member offerings into a sorted list for display
   * based on the service offering name.
   *
   * @param unsortedProviderMemberOfferings
   * The set of provider member offerings.
   *
   * @return The sorted list of provider member offerings for display.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.provider.impl.ProviderMemberOffering> sortProviderMemberOfferings(
    final Set<curam.provider.impl.ProviderMemberOffering> unsortedProviderMemberOfferings) {
    // END, CR00177241
    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    final List<curam.provider.impl.ProviderMemberOffering> sortedProviderMemberOfferings = new ArrayList<curam.provider.impl.ProviderMemberOffering>(
      unsortedProviderMemberOfferings);

    Collections.sort(sortedProviderMemberOfferings,
      new Comparator<curam.provider.impl.ProviderMemberOffering>() {
      public int compare(
        final curam.provider.impl.ProviderMemberOffering lhs,
        curam.provider.impl.ProviderMemberOffering rhs) {
        return lhs.getProviderOffering().getServiceOffering().getName().compareTo(
          rhs.getProviderOffering().getServiceOffering().getName());
      }
    });
    return sortedProviderMemberOfferings;
  }

  /**
   * Retrieves list of person and representatives that satisfies the search
   * criteria.
   *
   * @param searchPersonKey
   * Search criteria.
   *
   * @return The list of person details that satisfies the search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PERSON#ERR_PERSON_FV_SEARCH_CRITERIA_NOT_ENTERED}
   * - If search criteria is not entered.
   */
  public SearchPersonAndRepresentativeDetailsList searchPersonAndRepresentative1(
    SearchPersonKey searchPersonKey) throws AppException,
      InformationalException {

    String searchPerson = searchPersonKey.searchKey.addressLine1.trim()
      + searchPersonKey.searchKey.firstName.trim()
      + searchPersonKey.searchKey.lastName.trim()
      + searchPersonKey.searchKey.referenceNo.trim();

    if (searchPerson.equals(GeneralConstants.kEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PERSONExceptionCreator.ERR_PERSON_FV_SEARCH_CRITERIA_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
      ValidationHelper.failIfErrorsExist();
    }

    SearchPersonAndRepresentativeDetailsList personDetailsList = new SearchPersonAndRepresentativeDetailsList();

    // Retrieve the list of persons that satisfies the search criteria
    curam.cpm.sl.entity.struct.SearchPersonDetails1List searchPersonDetailsList = personDAO.searchPersonByNameAndAddress1(
      searchPersonKey.searchKey.referenceNo,
      searchPersonKey.searchKey.addressLine1,
      searchPersonKey.searchKey.firstName, searchPersonKey.searchKey.lastName,
      false, false);
    
    // BEGIN, CR00417548, SS
    final OtherAddressData otherAddressData = new OtherAddressData();
    curam.cpm.facade.struct.SearchPersonDetails1 searchPersonDetails;

    for (final SearchPersonDetails1 searchPersonDetails1 : searchPersonDetailsList.dtls.items()) {
      searchPersonDetails = new curam.cpm.facade.struct.SearchPersonDetails1();
      if (!searchPersonDetails1.addressOpt.isEmpty()) {
        otherAddressData.addressData = searchPersonDetails1.addressOpt;
        searchPersonDetails1.addressOpt = ParticipantFactory.newInstance().displaySingleLineAddress(otherAddressData).addressString;
      }
      searchPersonDetails.searchDetails.assign(searchPersonDetails1);
      personDetailsList.personDetails.addRef(searchPersonDetails);
    }
    // END, CR00417548
    
    // Retrieve the list of representatives that satisfies the search criteria
    searchPersonDetailsList = personDAO.searchRepresentativeByNameAndAddress1(
      searchPersonKey.searchKey.referenceNo,
      searchPersonKey.searchKey.addressLine1,
      searchPersonKey.searchKey.firstName, searchPersonKey.searchKey.lastName,
      false, false);
    
    // BEGIN, CR00417548, SS
    SearchRepresentativeDetails searchRepresentativeDetails;

    for (final SearchPersonDetails1 searchPersonDetails1 : searchPersonDetailsList.dtls.items()) {
      searchRepresentativeDetails = new SearchRepresentativeDetails();
      searchRepresentativeDetails.addressLine1 = searchPersonDetails1.addressLine1;
      searchRepresentativeDetails.city = searchPersonDetails1.city;
      searchRepresentativeDetails.concernRoleID = searchPersonDetails1.concernRoleID;
      searchRepresentativeDetails.concernRoleName = searchPersonDetails1.concernRoleName;
      searchRepresentativeDetails.referenceNo = searchPersonDetails1.referenceNo;
      searchRepresentativeDetails.dateOfBirthOpt = searchPersonDetails1.dateOfBirthOpt;
      if (!searchPersonDetails1.addressOpt.isEmpty()) {
        otherAddressData.addressData = searchPersonDetails1.addressOpt;
        searchRepresentativeDetails.addressOpt = ParticipantFactory.newInstance().displaySingleLineAddress(otherAddressData).addressString;
      }
      personDetailsList.representative.addRef(searchRepresentativeDetails);
    }
    // END, CR00417548
    
    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(personDetailsList.informationalMsgDtlsOpt);
    // END, CR00292696
    
    return personDetailsList;
  }

  // BEGIN, CR00273435, GYH
  /**
   * Creates a provider member and provider member offerings for a given
   * provider.
   *
   * @param createProviderMemberDetails
   * Contains the details of the provider member to be created.
   *
   * @return The information message list and the internal identifiers related
   * to provider member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_NAME_NOT_ENTERED} -
   * If name is not entered.
   */
  public ProviderMemberCreateDetails createProviderMemberDetails(
    CreateProviderMemberDetails createProviderMemberDetails)
    throws AppException, InformationalException {

    validateInsert(createProviderMemberDetails);

    if (0 == createProviderMemberDetails.searchConcernRoleID) {
      if (StringHelper.isEmpty(createProviderMemberDetails.name)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_NAME_NOT_ENTERED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
        ValidationHelper.failIfErrorsExist();
      }

      RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = createProviderMemberDetails.name;
      representativeRegistrationDetails.representativeRegistrationDetails.addressData = createProviderMemberDetails.addressData;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = createProviderMemberDetails.phoneCountryCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = createProviderMemberDetails.phoneAreaCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = createProviderMemberDetails.phoneNumber;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension = createProviderMemberDetails.phoneExtension;
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();
      representativeRegistrationDetails.representativeDtls.representativeType = REPRESENTATIVETYPE.CONTACT;

      RepresentativeFactory.newInstance().registerRepresentative(
        representativeRegistrationDetails);
      createProviderMemberDetails.searchConcernRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
    }
    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.newInstance();
    final ConcernRole concernRole = concernRoleDAO.get(
      createProviderMemberDetails.searchConcernRoleID);

    providerMember.setParty(concernRole);
    final ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      createProviderMemberDetails.providerID);

    providerMember.setProviderOrganization(providerOrganization);
    providerMember.setRole(
      ProviderMemberRoleEntry.get(createProviderMemberDetails.role));
    providerMember.setPosition(
      PROVIDERMEMBERPOSITIONEntry.get(createProviderMemberDetails.position));
    providerMember.setDateRange(
      new DateRange(createProviderMemberDetails.fromDate,
      createProviderMemberDetails.toDate));
    providerMember.setCategory(ProviderPartyCategoryEntry.MEMBER);
    providerMember.insert();

    final ProviderPartyKey providerMemberKey = new ProviderPartyKey();

    providerMemberKey.providerPartyID = providerMember.getID();
    ValidationHelper.failIfErrorsExist();
    ProviderMemberCreateDetails providerMemberCreationDetails = new ProviderMemberCreateDetails();

    InformationalMessageList informationalMessageList = providerMember.validateTrainingProgramsForProviderMember(
      createProviderMemberDetails.providerOfferings);

    providerMemberCreationDetails.infoMsgList.assign(informationalMessageList);

    providerMemberCreationDetails.providerPartyID = providerMemberKey.providerPartyID;
    providerMemberCreationDetails.memberConcernRoleID = providerMember.getParty().getID();

    // Split the selected provider offerings into a string array
    final String[] providerOfferings = StringUtil.tabText2StringList(createProviderMemberDetails.providerOfferings).items();

    // For each provider offering create a provider member offering record
    for (final String providerOfferingString : providerOfferings) {
      final ProviderMemberOffering providerMemberOffering = providerMemberOfferingDAO.newInstance();

      providerMemberOffering.setProviderOffering(
        providerOfferingDAO.get(Long.parseLong(providerOfferingString)));
      providerMemberOffering.setProviderParty(
        providerMemberDAO.get(providerMemberKey.providerPartyID));

      // Takes the membership date range and service offering date range and
      // set the provider member offering date range to fall within
      // both of them.
      providerMemberOffering.setDateRangeAndAdjustForValidRange(
        new DateRange(createProviderMemberDetails.fromDate,
        createProviderMemberDetails.toDate));

      providerMemberOffering.insert();
    }
    return providerMemberCreationDetails;
  }

  // END, CR00273435
  
  // BEGIN, CR00292696, IBM
  /**
   * Collects the list of informations from the informational manager and adds
   * them to the list parameter passed in.
   *
   * @param informationalMsgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList informationalMsgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }

  // END, CR00292696
  
  // BEGIN, CR00304013, MR
  /**
   * Gets provider member image panel details that are required to be shown on
   * provider member tab details section.
   *
   * @param contentPanelBuilder
   * Contains content panel builder to build provider member context
   * panel.
   * @param viewProviderMemberTabDetails
   * Contains provider member details.
   * @param providerPartyKey
   * Contains provider party ID.
   *
   * @return Provider member image context panel information.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ContentPanelBuilder getMemberImagePanel(
    final ContentPanelBuilder contentPanelBuilder,
    final ViewProviderMemberTabDetails viewProviderMemberTabDetails,
    final ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    final ImagePanelBuilder imagePanelBuilder = ImagePanelBuilder.createPanel();
    String memberImage;
    String imageResource;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    if (viewProviderMemberTabDetails.isPerson) {

      // Check to see if person has an image.
      concernRoleKey.concernRoleID = viewProviderMemberTabDetails.memberConcernRoleID;

      if (ConcernRoleImageFactory.newInstance().hasImage(concernRoleKey).statusInd) {
        memberImage = CuramConst.gkPersonFileDownLoadLink
          + String.valueOf(concernRoleKey.concernRoleID);
        imageResource = CuramConst.gkEmpty;

      } else {
        final ConcernRoleTypeDetails concernRoleTypeDetails = ConcernRoleFactory.newInstance().readConcernRoleType(
          concernRoleKey);

        // BEGIN, CR00370472, PS
        if (CONCERNROLETYPEEntry.PERSON.toString().equals(
          concernRoleTypeDetails.concernRoleType.toString())) {
          // END, CR00370472
        	
          final PersonKey personKey = new PersonKey();

          personKey.concernRoleID = concernRoleKey.concernRoleID;

          if (GENDEREntry.MALE.equals(
            PersonFactory.newInstance().readGender(personKey).gender)) {
            memberImage = CuramConst.gkGenericMale;
          } else {
            memberImage = CuramConst.gkGenericFemale;
          }

          // BEGIN, CR00370472, PS
        } else if (CONCERNROLETYPEEntry.PROSPECTPERSON.toString().equals(
          concernRoleTypeDetails.concernRoleType.toString())) {
          // END, CR00370472
        	
          final ProspectPersonKey prospectPersonKey = new ProspectPersonKey();

          prospectPersonKey.concernRoleID = concernRoleKey.concernRoleID;

          if (GENDEREntry.MALE.equals(
            ProspectPersonFactory.newInstance().readProspectPersonGender(prospectPersonKey).gender)) {
            memberImage = CuramConst.gkGenericMale;
          } else {
            memberImage = CuramConst.gkGenericFemale;
          }
        } else {
          memberImage = CuramConst.gkEmpty;
          imageResource = CuramConst.gkEmpty;
        }
        imageResource = CuramConst.gkRendererImages;
      }
      imagePanelBuilder.addParticipantImage(memberImage, CuramConst.gkEmpty,
        imageResource);
    } else {
      imagePanelBuilder.addParticipantImage(CPMConstants.gkIconRepresentative,
        CuramConst.gkEmpty, CPMConstants.kRendererImages);
    }

    imagePanelBuilder.addNameAsLink(
      providerMemberDAO.get(providerPartyKey.providerPartyID).getParty().getName(),
      CuramConst.gkEmpty, viewProviderMemberTabDetails.memberConcernRoleID);

    imagePanelBuilder.addRelationshipCodetableValue(
      viewMember(providerPartyKey).role, CPMConstants.gkDomainRoleType);

    final TabDetailsHelper tabDetailsHelperObj = TabDetailsHelperFactory.newInstance();

    concernRoleKey.concernRoleID = providerPartyKey.providerPartyID;

    final IncidentAndRoleTabDetailsList incidentAndRoleTabDetailsList = tabDetailsHelperObj.readIncidentTabDetails(
      concernRoleKey);

    if (incidentAndRoleTabDetailsList.dtls.size() > 0) {
      CaseTabDetailsHelper.getMemberIncidentDetailsForImagePanel(concernRoleKey,
        incidentAndRoleTabDetailsList, imagePanelBuilder);
    }

    final InvestigationAndRoleTabDetailsList investigationAndRoleTabDetailsList = tabDetailsHelperObj.readInvestigationTabDetails(
      concernRoleKey);

    if (investigationAndRoleTabDetailsList.dtls.size() > 0) {
      CaseTabDetailsHelper.getMemberInvestigationDetailsForImagePanel(
        concernRoleKey, investigationAndRoleTabDetailsList, imagePanelBuilder);
    }

    contentPanelBuilder.addWidgetItem(imagePanelBuilder.getImagePanel(),
      CuramConst.gkStyle, CuramConst.gkContentPanel,
      CPMConstants.gkMemberImagePanel);

    return contentPanelBuilder;
  }

  /**
   * Gets provider member details panel information that are required to be
   * shown on provider member tab details section.
   *
   * @param contentPanelBuilder
   * Contains content panel builder to build provider member context
   * panel.
   * @param providerMember
   * Contains individual(provider member) associated to the provider.
   *
   * @return Provider member details panel information.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ContentPanelBuilder getMemberDetailsPanel(
    final ContentPanelBuilder contentPanelBuilder,
    final curam.provider.impl.ProviderMember providerMember)
    throws AppException, InformationalException {

    final ContentPanelBuilder memberDetailsPanel = ContentPanelBuilder.createPanel(
      CuramConst.gkTabDetails);

    memberDetailsPanel.addRoundedCorners();
    memberDetailsPanel.addStringItem(providerMember.getParty().getName(),
      CuramConst.gkContentParticipantName);

    final AddressKey addressKey = new AddressKey();

    addressKey.addressID = providerMember.getParty().getPrimaryAddressID();

    final AddressTabDetails addressTabDetails = new AddressTabDetails();

    addressTabDetails.addressData = AddressFactory.newInstance().read(addressKey).addressData;

    memberDetailsPanel.addStringItem(
      TabDetailFormatterFactory.newInstance().formatAddress(addressTabDetails).addressString,
      CuramConst.gkContentAddress);

    String mapEnabled = Configuration.getProperty(EnvVars.ENV_GEOCODE_ENABLED);

    if (null == mapEnabled) {
      mapEnabled = EnvVars.ENV_GEOCODE_ENABLED_DEFAULT;
    }

    if (EnvVars.ENV_VALUE_YES.equalsIgnoreCase(mapEnabled)) {

      final LocalisableString mapString = new LocalisableString(
        BPOPARTICIPANT.INF_MAP);

      final LinkBuilder googleLinkBuilder = LinkBuilder.createLocalizableLink(
        mapString.toClientFormattedText(), CuramConst.gkAddressMapPage);

      googleLinkBuilder.addParameter(CuramConst.gkAddressID,
        String.valueOf(addressKey.addressID));
      googleLinkBuilder.openAsModal();
      googleLinkBuilder.setTextResource(CuramConst.gkRendererImages);
      googleLinkBuilder.addImage(CuramConst.gkIconMap, CuramConst.gkEmpty);

      memberDetailsPanel.addWidgetItem(googleLinkBuilder, CuramConst.gkStyle,
        CuramConst.gkLink, CuramConst.gkContentMap);
    }

    if (providerMember.getDateRange().end().isZero()) {
      memberDetailsPanel.addlocalisableStringItem(
        new LocalisableString(PROVIDERMEMBER.TEXT_PROVIDERMEMBER_PROVIDERMEMBER_SINCE).arg(providerMember.getDateRange().start()).toClientFormattedText(),
        CPMConstants.gkMemberDuration);
    } else {
      memberDetailsPanel.addlocalisableStringItem(
        new LocalisableString(PROVIDERMEMBER.TEXT_PROVIDERMEMBER_PROVIDERMEMBER_DURATIOn).arg(providerMember.getDateRange().start()).arg(providerMember.getDateRange().end()).toClientFormattedText(),
        CPMConstants.gkMemberDuration);
    }

    final ListBuilder memberDetailsList = ListBuilder.createHorizontalList(2);

    memberDetailsList.addRow();
    memberDetailsList.addEntry(1, 1,
      new LocalisableString(PROVIDERMEMBER.TEXT_PROVIDERMEMBER_PROVIDER));
    memberDetailsList.addEntry(2, 1,
      providerMember.getProviderOrganization().getName());
    memberDetailsList.addRow();
    memberDetailsList.addEntry(1, 2,
      new LocalisableString(PROVIDERMEMBER.TEXT_PROVIDERMEMBER_POSITION));

    if (!PROVIDERMEMBERPOSITIONEntry.NOT_SPECIFIED.equals(
      providerMember.getPosition())) {
      memberDetailsList.addEntry(2, 2,
        CodeTable.getOneItem(providerMember.getPosition().getTableName(),
        providerMember.getPosition().getCode(),
        TransactionInfo.getProgramLocale()));
    }

    memberDetailsPanel.addSingleListItem(memberDetailsList,
      CPMConstants.gkMemberDetailsTable);

    memberDetailsPanel.addWidgetItem(getMemberContactDetails(providerMember),
      CuramConst.gkStyle, CuramConst.gkContentPanel);
    contentPanelBuilder.addWidgetItem(memberDetailsPanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CPMConstants.gkMemberDetailsPanel);

    return contentPanelBuilder;
  }

  /**
   * Gets provider member contact details information that are required to be
   * shown on provider member tab details section.
   *
   * @param providerMember
   * Contains individual(provider member) associated to the provider.
   *
   * @return Provider member contact details information.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ContentPanelBuilder getMemberContactDetails(
    final curam.provider.impl.ProviderMember providerMember)
    throws AppException, InformationalException {

    final ContentPanelBuilder contactContents = ContentPanelBuilder.createPanel(
      CuramConst.gkContentContacts);

    // Create a image builder for a phone icon.
    final ImageBuilder phoneIconImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconPhone, CuramConst.gkEmpty);

    phoneIconImageBuilder.setImageResource(CuramConst.gkRendererImages);
    phoneIconImageBuilder.setImageAltText(
      new LocalisableString(PROVIDERMEMBER.TEXT_PROVIDERMEMBER_PHONE_NUMBER).toClientFormattedText());
    contactContents.addImageItem(phoneIconImageBuilder);

    if (null != providerMember.getParty().getPrimaryPhoneNumber()) {

      final PhoneNumberKey phoneNumberKey = new PhoneNumberKey();

      phoneNumberKey.phoneNumberID = providerMember.getParty().getPrimaryPhoneNumber().getID();
      contactContents.addStringItem(
        TabDetailFormatterFactory.newInstance().formatPhoneNumber(phoneNumberKey).phoneNumberString,
        CuramConst.gkPhoneNumber);
    } else {

      final LocalisableString detailsNotRecorded = new LocalisableString(
        BPOPARTICIPANT.INF_NOT_RECORDED);

      contactContents.addlocalisableStringItem(
        detailsNotRecorded.toClientFormattedText(), CuramConst.gkPhoneNumber);
    }
    return contactContents;
  }

  // END, CR00304013
  
  // BEGIN, CR00304715, RPB
  /**
   * Gets provider member details and the context details.
   *
   * @param providerKey
   * Contains provider details.
   * @param providerPartyKey
   * Contains provider party details.
   *
   * @return Provider member and context details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderMemberAndContextDetails readProviderMemberDetailsAndContext(
    final ProviderKey providerKey, final ProviderPartyKey providerPartyKey)
    throws AppException, InformationalException {

    ProviderMemberAndContextDetails providerMemberAndContextDetails = new ProviderMemberAndContextDetails();

    curam.cpm.sl.entity.intf.ProviderParty providerParty = ProviderPartyFactory.newInstance();
    ProviderPartyKey key = new ProviderPartyKey();

    key.providerPartyID = providerPartyKey.providerPartyID;
    PartyConcernRoleDetails partyConcernRoleDetails = providerParty.readPartyConcernRoleDetails(
      key);

    Provider providerObj = ProviderFactory.newInstance();

    ProviderConcernRoleDetails providerConcernRoleDetails = providerObj.readProviderConcernRoleDetails(
      providerKey);

    Element navigationMenuElement = new Element(
      XmlMetaDataConst.kNavigationMenu);
    Element linkElement = new Element(XmlMetaDataConst.kItem);
    Element paramElement = new Element(XmlMetaDataConst.kParam);

    // Set up node property values.
    LocalisableString description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(providerConcernRoleDetails.providerName);
    // Set up node property values.
    linkElement.setAttribute(XmlMetaDataConst.kPageID,
      CPMConstants.kViewProvider);
    linkElement.setAttribute(XmlMetaDataConst.kDesc,
      description.toClientFormattedText());
    linkElement.setAttribute(XmlMetaDataConst.kType, XmlMetaDataConst.kTypeCase);
    navigationMenuElement.addContent(linkElement);
    // Set the parameter values.
    paramElement.setAttribute(XmlMetaDataConst.kName,
      CPMConstants.kParamProviderConcernRoleID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(providerKey.providerConcernRoleID));
    linkElement.addContent(paramElement);
    // Second link element.
    linkElement = new Element(XmlMetaDataConst.kItem);
    description = new LocalisableString(
      BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);
    description.arg(partyConcernRoleDetails.name);
    // Set up node property values.
    linkElement.setAttribute(XmlMetaDataConst.kPageID,
      CPMConstants.kViewProviderMember);
    linkElement.setAttribute(XmlMetaDataConst.kDesc,
      description.toClientFormattedText());
    linkElement.setAttribute(XmlMetaDataConst.kType, XmlMetaDataConst.kTypeCase);
    navigationMenuElement.addContent(linkElement);

    // Set the parameter values.
    paramElement = new Element(XmlMetaDataConst.kParam);
    paramElement.setAttribute(XmlMetaDataConst.kName,
      CPMConstants.kParamProviderPartyID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(providerPartyKey.providerPartyID));
    linkElement.addContent(paramElement);
    // Set the parameter values.
    paramElement = new Element(XmlMetaDataConst.kParam);
    paramElement.setAttribute(XmlMetaDataConst.kName,
      CPMConstants.kParamProviderConcernRoleID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(providerKey.providerConcernRoleID));
    linkElement.addContent(paramElement);
    XMLOutputter outputter = new XMLOutputter();
    CaseMenuData caseMenuData = new CaseMenuData();

    caseMenuData.menuData = outputter.outputString(navigationMenuElement);

    providerMemberAndContextDetails.caseMenuData = caseMenuData;
    final ViewProviderMemberDetails viewProviderMemberDetails = new ViewProviderMemberDetails();

    viewProviderMemberDetails.name = partyConcernRoleDetails.name;
    viewProviderMemberDetails.concernRoleType = partyConcernRoleDetails.concernRoleType;
    viewProviderMemberDetails.memberConcernRoleID = partyConcernRoleDetails.memberConcernRoleID;
    viewProviderMemberDetails.fromDate = partyConcernRoleDetails.fromDate;
    viewProviderMemberDetails.toDate = partyConcernRoleDetails.toDate;
    viewProviderMemberDetails.recordStatus = partyConcernRoleDetails.recordStatus;
    viewProviderMemberDetails.role = partyConcernRoleDetails.role;
    viewProviderMemberDetails.position = partyConcernRoleDetails.position;
    viewProviderMemberDetails.versionNo = partyConcernRoleDetails.versionNo;
    providerMemberAndContextDetails.providerMemberDetails = viewProviderMemberDetails;

    providerMemberAndContextDetails.contextDescription.description = partyConcernRoleDetails.name
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + partyConcernRoleDetails.primaryAlternateID;

    return providerMemberAndContextDetails;
  }

  // END, CR00304715
  


}
