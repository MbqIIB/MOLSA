/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.REASSESSMENTRESULTEntry;
import curam.core.impl.CuramConst;
import curam.core.struct.InstructionLineItemDtls;
import curam.cpm.facade.struct.SILIClientDetails;
import curam.cpm.facade.struct.SILIClientDetailsList;
import curam.cpm.facade.struct.SILICorrectionAndClientKey;
import curam.cpm.facade.struct.SILICorrectionDetails;
import curam.cpm.facade.struct.SILICorrectionDetailsList;
import curam.cpm.facade.struct.SILICorrectionHistoryList;
import curam.cpm.facade.struct.SILICorrectionVersionKey;
import curam.cpm.facade.struct.ServiceInvoiceLineItemCorrectionDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ServiceInvoiceLineItemKey;
import curam.cpm.sl.fact.FinancialNotificationFactory;
import curam.cpm.sl.fact.SILICorrectionFactory;
import curam.cpm.sl.intf.FinancialNotification;
import curam.cpm.sl.struct.FinancialNotificationKey;
import curam.cpm.sl.struct.OverUnderPaymentDetails;
import curam.cpm.sl.struct.OverUnderPaymentDetailsList;
import curam.cpm.sl.struct.RelatedReferenceID;
import curam.cpm.sl.struct.SILICorrectionDtls;
import curam.cpm.sl.struct.SILICorrectionHistoryDtls;
import curam.cpm.sl.struct.SILICorrectionKey;
import curam.cpm.util.impl.WidgetHelper;
import curam.events.PROVIDERMANAGEMENT;
import curam.financial.FinancialNotificationEvent;
import curam.financial.ServiceInvoiceLineItemStatus;
import curam.financial.impl.PaymentProcessing;
import curam.financial.impl.PaymentProcessingImpl;
import curam.financial.impl.SILICorrectionClient;
import curam.financial.impl.SILICorrectionClientDAO;
import curam.financial.impl.ServiceInvoiceLineItem;
import curam.financial.impl.ServiceInvoiceLineItemClient;
import curam.financial.impl.ServiceInvoiceLineItemClientDAO;
import curam.financial.impl.ServiceInvoiceLineItemCorrection;
import curam.financial.impl.ServiceInvoiceLineItemCorrectionDAO;
import curam.financial.impl.ServiceInvoiceLineItemCorrectionHistoryDAO;
import curam.financial.impl.ServiceInvoiceLineItemDAO;
import curam.financial.impl.ServiceInvoiceLineItemStatusEntry;
import curam.message.impl.SERVICEINVOICELINEITEMExceptionCreator;
import curam.message.impl.SILICORRECTIONExceptionCreator;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.type.Date;
import curam.util.type.Money;


/**
 * {@inheritDoc}
 */
public abstract class SILICorrection extends curam.cpm.facade.base.SILICorrection {

  /**
   * Service Invoice LineItem Correction DAO object
   */
  @Inject
  protected ServiceInvoiceLineItemCorrectionDAO siliCorrectionDAO;

  /**
   * Service Invoice Line Item Correction DAO object
   */
  @Inject
  protected ServiceInvoiceLineItemDAO serviceInvoiceLineItemDAO;

  /**
   * Service Invoice Line Item DAO object
   */
  @Inject
  protected ServiceInvoiceLineItemCorrectionHistoryDAO siliCorrectionHistoryDAO;

  /**
   * Service Offering DAO object
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  // BEGIN, CR00158345, GP
  /**
   * Reference to Service Invoice Line Item Correction DAO.
   */
  @Inject
  protected ServiceInvoiceLineItemCorrectionDAO serviceInvoiceLineItemCorrectionDAO;

  /**
   * Reference to Service Invoice Line Item Correction Client DAO.
   */
  @Inject
  protected SILICorrectionClientDAO siliCorrectionClientDAO;

  /**
   * Reference to Service Invoice Line Item Client DAO.
   */
  @Inject
  protected ServiceInvoiceLineItemClientDAO serviceInvoiceLineItemClientDAO;
  // END, CR00158345

  /**
   * Guice constructor to create instance
   *
   */
  public SILICorrection() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00200393, SSK

  /**
   * Creates a Service Invoice Line Item with the service invoice line item
   * correction details passed.
   *
   * @param siliCorrectionDtls
   * Contains the service invoice line item correction details
   *
   * @return SILICorrectionKey contains SILICorrection ID
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link SILICorrection#createNewServiceInvoiceLineItemCorrection(ServiceInvoiceLineItemCorrectionDetails)}
   * . As part of the merging service invoice line item and service
   * invoice line item correction changes has been done to maintain
   * correction clients in service invoice line item client and
   * maintain correction history in service invoice line item
   * history entity. See release note: CR00200393.
   */
  @Deprecated
  public SILICorrectionKey createSILICorrection(
    SILICorrectionDtls siliCorrectionDtls) throws AppException,
      InformationalException {

    // END, CR00200393

    // Create instance of SILICorrection
    curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.newInstance();

    setSILICorrectionDetails(siliCorrectionDtls, siliCorrection);

    // Insert the siliCorrectionDetails into the database
    siliCorrection.insert();

    // Create SILICorrection History
    createSILICorrectionHistory(siliCorrection);

    SILICorrectionKey siliCorrectionKey = new SILICorrectionKey();

    siliCorrectionKey.siliCorrectionID = siliCorrection.getID();

    return siliCorrectionKey;

  }

  /**
   * Reads the list the status history for the Service Invoice Line Item Correction.
   *
   * @param key Contains SILICorrection ID.
   * @return SILICorrectionHistoryList The list of service invoice line item
   * correction history.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public SILICorrectionHistoryList listSILICorrectionHistory(
    SILICorrectionKey key) throws AppException, InformationalException {

    SILICorrectionHistoryList siliCorrectionHistoryList = new SILICorrectionHistoryList();

    if (key.siliCorrectionID != 0) {
      // Retrieve the status history for service invoice line item correction
      // START CR00094326, JSP
      ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
        key.siliCorrectionID);
      final Set<curam.financial.impl.ServiceInvoiceLineItemCorrectionHistory> siliCorrectionHistList = siliCorrectionHistoryDAO.getHistoryForSILICorrection(
        siliCorrection);

      // END CR00094326

      for (final curam.financial.impl.ServiceInvoiceLineItemCorrectionHistory siliCorrectionHistory : siliCorrectionHistList) {
        SILICorrectionHistoryDtls siliCorrectionHistoryDtls = new SILICorrectionHistoryDtls();

        siliCorrectionHistoryDtls.dateTime = siliCorrectionHistory.getDateTime();
        siliCorrectionHistoryDtls.recordStatus = siliCorrectionHistory.getStatus().toString();
        siliCorrectionHistoryDtls.userName = siliCorrectionHistory.getUserName();
        siliCorrectionHistoryList.historyList.addRef(siliCorrectionHistoryDtls);
      }
    }
    return siliCorrectionHistoryList;
  }

  /**
   * {@inheritDoc}
   */
  public SILICorrectionKey modifySILICorrection(
    SILICorrectionDtls siliCorrectionDtls) throws AppException,
      InformationalException {
    final curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
      siliCorrectionDtls.siliCorrectionID);

    setSILICorrectionDetails(siliCorrectionDtls, siliCorrection);
    // Update the changed values to the database

    siliCorrection.modify(siliCorrectionDtls.versionNo);
    SILICorrectionKey siliCorrectionKey = new SILICorrectionKey();

    siliCorrectionKey.siliCorrectionID = siliCorrection.getID();

    return siliCorrectionKey;

  }

  /**
   * {@inheritDoc}
   */
  public SILICorrectionDetails viewSILICorrection(SILICorrectionKey key)
    throws AppException, InformationalException {
    SILICorrectionDetails siliCorrectionDetails = new SILICorrectionDetails();
    // Retrieve the Correction Details
    final curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
      key.siliCorrectionID);

    siliCorrectionDetails.details.amountInvoiced = siliCorrection.getAmountInvoiced();
    siliCorrectionDetails.details.caseRefNo = siliCorrection.getCaseReferenceNumber();
    siliCorrectionDetails.details.clientDOB = siliCorrection.getClientDateOfBirth();
    siliCorrectionDetails.details.clientFirstName = siliCorrection.getClientFirstName();
    siliCorrectionDetails.details.clientLastName = siliCorrection.getClientLastName();
    siliCorrectionDetails.details.clientRefNo = siliCorrection.getClientReferenceNumber();
    siliCorrectionDetails.details.externalRefNo = siliCorrection.getExternalReferenceNumber();
    siliCorrectionDetails.details.numberOfUnits = siliCorrection.getNumberOfUnits();
    siliCorrectionDetails.details.payeeName = siliCorrection.getPayeeName();
    siliCorrectionDetails.details.payeeRefNo = siliCorrection.getPayeeReferenceNumber();
    siliCorrectionDetails.details.providerName = siliCorrection.getProviderName();
    siliCorrectionDetails.details.providerRefNo = siliCorrection.getProviderReferenceNumber();
    siliCorrectionDetails.details.reason = siliCorrection.getReason();
    siliCorrectionDetails.details.saRefNo = siliCorrection.getServiceAuthorizationReferenceNumber();
    siliCorrectionDetails.details.serviceFromDate = siliCorrection.getServiceDateFrom();
    siliCorrectionDetails.details.serviceID = siliCorrection.getServiceOffering().getID();
    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = siliCorrection.getServiceInvoiceLineItem();

    siliCorrectionDetails.details.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
    siliCorrectionDetails.details.serviceToDate = siliCorrection.getServiceDateTo();
    siliCorrectionDetails.details.unitAmount = siliCorrection.getUnitAmount();
    siliCorrectionDetails.details.recordStatus = siliCorrection.getStatus().toString();
    siliCorrectionDetails.details.referenceNo = siliCorrection.getReferenceNumber();
    siliCorrectionDetails.details.siliCorrectionID = siliCorrection.getID();
    ServiceOffering serviceOffering = siliCorrection.getServiceOffering();

    siliCorrectionDetails.nameDetails.serviceName = serviceOffering.getName();
    siliCorrectionDetails.details.versionNo = siliCorrection.getVersionNo();

    return siliCorrectionDetails;
  }

  /**
   * Sets the Service Invoice Line Item Correction details using
   * Service Invoice Line Item Correction object.
   *
   * @param siliCorrectionDtls Service invoice line item correction details.
   *
   * @param siliCorrection Service invoice line item correction object.
   */
  // BEGIN, CR00177241, PM
  protected void setSILICorrectionDetails(SILICorrectionDtls siliCorrectionDtls,
    // END, CR00177241
    curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection) {
    // Update the service layer object with the details struct
    siliCorrection.setAmountInvoiced(siliCorrectionDtls.amountInvoiced);
    siliCorrection.setCaseReferenceNumber(siliCorrectionDtls.caseRefNo);
    siliCorrection.setClientDateOfBirth(siliCorrectionDtls.clientDOB);
    siliCorrection.setClientFirstName(siliCorrectionDtls.clientFirstName);
    siliCorrection.setClientLastName(siliCorrectionDtls.clientLastName);
    siliCorrection.setAmountInvoiced(siliCorrectionDtls.amountInvoiced);
    siliCorrection.setClientReferenceNumber(siliCorrectionDtls.clientRefNo);
    siliCorrection.setExternalReferenceNumber(siliCorrectionDtls.externalRefNo);
    siliCorrection.setNumberOfUnits(siliCorrectionDtls.numberOfUnits);
    siliCorrection.setPayeeName(siliCorrectionDtls.payeeName);
    siliCorrection.setPayeeReferenceNumber(siliCorrectionDtls.payeeRefNo);
    siliCorrection.setProviderName(siliCorrectionDtls.providerName);
    siliCorrection.setProviderReferenceNumber(siliCorrectionDtls.providerRefNo);
    siliCorrection.setReason(siliCorrectionDtls.reason);
    siliCorrection.setServiceAuthorizationReferenceNumber(
      siliCorrectionDtls.saRefNo);
    siliCorrection.setServiceDateFrom(siliCorrectionDtls.serviceFromDate);
    siliCorrection.setServiceDateTo(siliCorrectionDtls.serviceToDate);
    siliCorrection.setUnitAmount(siliCorrectionDtls.unitAmount);
    siliCorrection.setServiceOffering(
      serviceOfferingDAO.get(siliCorrectionDtls.serviceID));
    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      siliCorrectionDtls.serviceInvoiceLineItemID);

    siliCorrection.setServiceInvoiceLineItem(serviceInvoiceLineItem);
  }

  /**
   * {@inheritDoc}
   */
  public SILICorrectionDetailsList listSILICorrections(
    ServiceInvoiceLineItemKey key) throws AppException,
      InformationalException {
    SILICorrectionDetailsList siliCorrectionList = new SILICorrectionDetailsList();

    if (key.serviceInvoiceLineItemID != 0) {
      // Retrieve the corrections for the service invoice line item
      // START CR00094326, JSP
      ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
        key.serviceInvoiceLineItemID);

      final List<curam.financial.impl.ServiceInvoiceLineItemCorrection> siliCorrections = sortSILICorrections(
        siliCorrectionDAO.listSILICorrections(serviceInvoiceLineItem));

      // END CR00094326
      
      for (final curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection : siliCorrections) {
        SILICorrectionDetails siliCorrectionDetails = new SILICorrectionDetails();

        siliCorrectionDetails = getSILICorrectionDetails(siliCorrection);
        siliCorrectionList.dtlsList.addRef(siliCorrectionDetails);
      }
    }

    return siliCorrectionList;
  }

  /**
   * Gets the Service Invoice Line Item Correction details.
   *
   * @param siliCorrection Service invoice line item correction object.
   * @return SILICorrectionDetails Service invoice line item correction details.
   */
  // BEGIN, CR00177241, PM
  protected SILICorrectionDetails getSILICorrectionDetails(
    // END, CR00177241
    curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection) {
    SILICorrectionDetails siliCorrectionDetails = new SILICorrectionDetails();

    siliCorrectionDetails.details.amountInvoiced = siliCorrection.getAmountInvoiced();
    siliCorrectionDetails.details.caseRefNo = siliCorrection.getCaseReferenceNumber();
    siliCorrectionDetails.details.clientDOB = siliCorrection.getClientDateOfBirth();
    // BEGIN, CR00235365, SSK
    // BEGIN, CR00158345, GP
    SILIClientDetailsList siliCorrectionClients = sortServiceInvoiceLineItemCorrectionClientByClientName(
      siliCorrection.getSILICorrectionClients());

    // BEGIN, CR00200393, SSK
    if (0 != siliCorrectionClients.clientDetails.size()) {
      SILIClientDetails correctionClient = siliCorrectionClients.clientDetails.iterator().next();

      siliCorrectionDetails.details.clientFirstName = correctionClient.clientFirstName;
      siliCorrectionDetails.details.clientLastName = correctionClient.clientLastName;
    }
    // END, CR00235365
    // END, CR00200393
    // END, CR00158345


    siliCorrectionDetails.details.clientRefNo = siliCorrection.getClientReferenceNumber();
    siliCorrectionDetails.details.externalRefNo = siliCorrection.getExternalReferenceNumber();
    siliCorrectionDetails.details.numberOfUnits = siliCorrection.getNumberOfUnits();
    siliCorrectionDetails.details.payeeName = siliCorrection.getPayeeName();
    siliCorrectionDetails.details.payeeRefNo = siliCorrection.getPayeeReferenceNumber();
    siliCorrectionDetails.details.providerName = siliCorrection.getProviderName();
    siliCorrectionDetails.details.providerRefNo = siliCorrection.getProviderReferenceNumber();
    siliCorrectionDetails.details.reason = siliCorrection.getReason();
    siliCorrectionDetails.details.saRefNo = siliCorrection.getServiceAuthorizationReferenceNumber();
    siliCorrectionDetails.details.serviceFromDate = siliCorrection.getServiceDateFrom();
    siliCorrectionDetails.details.serviceID = siliCorrection.getServiceOffering().getID();
    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = siliCorrection.getServiceInvoiceLineItem();

    siliCorrectionDetails.details.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
    siliCorrectionDetails.details.serviceToDate = siliCorrection.getServiceDateTo();
    siliCorrectionDetails.details.unitAmount = siliCorrection.getUnitAmount();
    siliCorrectionDetails.details.recordStatus = siliCorrection.getStatus().toString();
    siliCorrectionDetails.details.referenceNo = siliCorrection.getReferenceNumber();
    siliCorrectionDetails.details.siliCorrectionID = siliCorrection.getID();
    ServiceOffering serviceOffering = siliCorrection.getServiceOffering();

    siliCorrectionDetails.nameDetails.serviceName = serviceOffering.getName();
    siliCorrectionDetails.details.versionNo = siliCorrection.getVersionNo();

    return siliCorrectionDetails;
  }

  // BEGIN, CR00200393, SSK
  /**
   * Approves a Service Invoice Line Item Correction.
   *
   * @param arg0
   * Service invoice line item correction.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link SILICorrection#approveServiceInvoiceLineItemCorrection(SILICorrectionVersionKey)}
   * . As part of the merging service invoice line item and service
   * invoice line item correction changes has been done to maintain
   * correction clients in service invoice line item client and
   * maintain correction history in service invoice line item
   * history entity. See release note: CR00200393.
   */
  @Deprecated
  public void approveSILICorrection(SILICorrectionVersionKey arg0)
    throws AppException, InformationalException {
    // END, CR00200393

    // Start CR00098525,JSP
    Money paidAmt = Money.kZeroMoney;
    Money newPaymentAmt = Money.kZeroMoney;
    boolean isPayeeChanged = false;
    // End CR00098525
    PaymentProcessing paymentProcessing = PaymentProcessingImpl.newInstance();

    // variables used during creating notification
    FinancialNotification notification = FinancialNotificationFactory.newInstance();
    FinancialNotificationKey notificationKey = new FinancialNotificationKey();

    // get SILI correction details
    curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
      arg0.SILICorrectionID);

    // call service layer approve method
    siliCorrection.approve(arg0.versionNo);

    // set the status of the SILI from 'Completed' to 'Open'
    // SILI Correction can be approved only when SILI is in 'Completed' state
    updateSILIStatus(siliCorrection.getServiceInvoiceLineItem());

    // create SILI Correction History
    createSILICorrectionHistory(siliCorrection);

    // retrieve old SILI details
    ServiceInvoiceLineItem serviceInvoiceLineItem = siliCorrection.getServiceInvoiceLineItem();

    // Start CR00098525, JSP
    // get the already paid amount to the payee
    InstructionLineItemDtls itemDtls = paymentProcessing.getILIforSILI(
      serviceInvoiceLineItem);

    paidAmt = itemDtls.amount;

    // if oldPayee is not equal to new payee, then notification to the old payee
    // has to be sent before SILIC overwrites SILI with latest values
    // also, ensure that notification is sent only the amount is already paid to the payee
    // START CR00094326, JSP
    // BEGIN, CR00137813, SK
    // BEGIN, CR00157056, GP
    if (null != serviceInvoiceLineItem.getPayee()
      && null != siliCorrection.getConcernRolePayee()
      && (!serviceInvoiceLineItem.getPayee().getID().equals(
        siliCorrection.getConcernRolePayee().getID()))
        && 0 != itemDtls.instructLineItemID) {
      // END, CR00157056
      // END, CR00137813
      // END CR00094326

      // Start CR00098525, JSP
      isPayeeChanged = true;
      // End CR00098525

      // send notification to the old payee regarding the amount he owes
      // (liability)
      notificationKey.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
      notificationKey.event = FinancialNotificationEvent.SILIC_OVERPAYMENT;
      notificationKey.amount = paidAmt;
      // End CR00098525
      // create financial notification
      notification.createNotification(notificationKey);

    }

    // Start CR00098525, JSP
    // set new SILI fields
    setSILIFields(serviceInvoiceLineItem, siliCorrection);

    // automatic approval of SILI -- call 1) submit for approval 2) approval
    // BEGIN CR00086034, SG
    serviceInvoiceLineItem.submitAndApproveSILIForCorrection(
      serviceInvoiceLineItem.getVersionNo());
    // END CR00086034

    // BEGIN, CR00158345, GP
    serviceInvoiceLineItemClientDAO.copySILICorrectionClientDetailsToSILI(
      siliCorrection, serviceInvoiceLineItem);
    // END, CR00158345

    // get the new payment amount to the payee
    newPaymentAmt = paymentProcessing.getPaymentAmountForSILI(
      serviceInvoiceLineItem);

    // End CR00098525

    // if payee has changed, send a notification for payment to the new payee
    if (isPayeeChanged) {

      notificationKey.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
      // Start CR00095491, JSP
      notificationKey.event = FinancialNotificationEvent.SILIC_PAYMENT;
      // End CR00095491
      notificationKey.amount = newPaymentAmt;

      // create financial notification
      notification.createNotification(notificationKey);

    } else {

      // send notification for the payee regarding change in amount only if the amount is already paid out
      // if paidAmt > newPaymentAmt, then send notification for amount old
      // payee owes (liability)
      // if paidAmt < newPaymentAmt, then send notification for new
      // payment
      // if paidAmt == newPaymentAmt, do nothing

      if (paidAmt.getValue() > newPaymentAmt.getValue()
        && itemDtls.instructLineItemID != 0) {

        notificationKey.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
        notificationKey.event = FinancialNotificationEvent.SILIC_OVERPAYMENT;
        notificationKey.amount = new Money(
          Math.abs(paidAmt.getValue() - newPaymentAmt.getValue()));

        notification.createNotification(notificationKey);

      } else if (paidAmt.getValue() < newPaymentAmt.getValue()
        && itemDtls.instructLineItemID != 0) {

        notificationKey.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
        notificationKey.event = FinancialNotificationEvent.SILIC_UNDERPAYMENT;
        notificationKey.amount = new Money(
          Math.abs(paidAmt.getValue() - newPaymentAmt.getValue()));

        notification.createNotification(notificationKey);

      }
    }
    // BEGIN, CR00139222, RPB

    // Raise the event to close the ServiceInvoiceLineItemApproval
    final Event event = new Event();

    event.eventKey = PROVIDERMANAGEMENT.SILICORRECTIONAPPROVED;
    event.primaryEventData = arg0.SILICorrectionID;

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
    // END, CR00139222


  }

  /**
   * Updates the Service Invoice Line Item status to 'Open' state and adds an entry
   * in service invoice line item history.
   *
   * @param serviceInvoiceLineItem Service invoice line item object.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void updateSILIStatus(
    // END, CR00177241
    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem)
    throws AppException, InformationalException {

    if (serviceInvoiceLineItem.getStatus().toString().equalsIgnoreCase(
      ServiceInvoiceLineItemStatusEntry.COMPLETE.toString())) {
      // set the status to open and modify the SILI
      // Begin CR00096779, ABS
      serviceInvoiceLineItem.setStatus(
        ServiceInvoiceLineItemStatusEntry.get(ServiceInvoiceLineItemStatus.OPEN));
      // End CR00096779
      // Start CR00098525, JSP
      serviceInvoiceLineItem.modify(serviceInvoiceLineItem.getVersionNo());
      // End CR00098525

    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SILICORRECTIONExceptionCreator.ERR_SILICORRECTION_XRV_SERVICEINVOICELINEITEM_IS_NOT_COMPLETE_CANNOT_BE_CORRECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  /**
   * Sets the values that are needed for creation of a SILI History.
   *
   * @param serviceInvoiceLineItem Service invoice line item object.
   * @param siliCorrection Service invoice line item correction object.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setSILIFields(
    // END, CR00177241
    final curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem,
    final curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection)
    throws AppException, InformationalException {

    serviceInvoiceLineItem.setAmountInvoiced(siliCorrection.getAmountInvoiced());
    serviceInvoiceLineItem.setCaseID(siliCorrection.getCaseID());
    serviceInvoiceLineItem.setCaseReferenceNumber(
      siliCorrection.getCaseReferenceNumber());
    serviceInvoiceLineItem.setClientDateOfBirth(
      siliCorrection.getClientDateOfBirth());
    serviceInvoiceLineItem.setClientFirstName(
      siliCorrection.getClientFirstName());
    serviceInvoiceLineItem.setClientID(siliCorrection.getClientID());
    serviceInvoiceLineItem.setClientLastName(siliCorrection.getClientLastName());
    serviceInvoiceLineItem.setClientReferenceNumber(
      siliCorrection.getClientReferenceNumber());
    serviceInvoiceLineItem.setExternalReferenceNumber(
      siliCorrection.getExternalReferenceNumber());
    serviceInvoiceLineItem.setNumberOfUnits(siliCorrection.getNumberOfUnits());
    // BEGIN CR00098525, JSP
    // BEGIN, CR00137813, SK
    // BEGIN, CR00157056, GP
    if (null != siliCorrection.getConcernRolePayee()
      && !serviceInvoiceLineItem.getPayee().getID().equals(
        siliCorrection.getConcernRolePayee().getID())) {
      serviceInvoiceLineItem.setOldPayeeID(
        serviceInvoiceLineItem.getPayee().getID());
      serviceInvoiceLineItem.setPayee(siliCorrection.getConcernRolePayee());
      // END, CR00157056
    }
    // END, CR00137813
    // END, CR00098525
    serviceInvoiceLineItem.setPayeeName(siliCorrection.getPayeeName());
    serviceInvoiceLineItem.setPayeeReferenceNumber(
      siliCorrection.getPayeeReferenceNumber());
    serviceInvoiceLineItem.setProvider(siliCorrection.getProvider());
    serviceInvoiceLineItem.setProviderName(siliCorrection.getProviderName());
    serviceInvoiceLineItem.setProviderReferenceNumber(
      siliCorrection.getProviderReferenceNumber());
    serviceInvoiceLineItem.setServiceAuthorizationLineItem(
      siliCorrection.getServiceAuthorizationLineItem());
    serviceInvoiceLineItem.setServiceAuthorizationReferenceNumber(
      siliCorrection.getServiceAuthorizationReferenceNumber());
    serviceInvoiceLineItem.setServiceDateFrom(
      siliCorrection.getServiceDateFrom());
    serviceInvoiceLineItem.setServiceDateTo(siliCorrection.getServiceDateTo());
    serviceInvoiceLineItem.setServiceOffering(
      siliCorrection.getServiceOffering());
    serviceInvoiceLineItem.setUnitAmount(siliCorrection.getUnitAmount());

  }

  // BEGIN, CR00235365, SSK
  /**
   * Creates SILI Correction History Entry when the service invoice line item
   * status changes.
   *
   * @param siliCorrection
   * Service invoice line item correction object.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, As part of the merging service invoice line
   * item and service invoice line item correction changes has been
   * done to maintain correction clients in service invoice line
   * item client and maintain correction history in service invoice
   * line item history entity. See release note: CR00200393.
   */
  @Deprecated
  // BEGIN, CR00177241, PM
  protected void createSILICorrectionHistory(
    // END, CR00235365
    // END, CR00177241
    curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection)
    throws AppException, InformationalException {

    curam.financial.impl.ServiceInvoiceLineItemCorrectionHistory siliCorrectionHistory = siliCorrectionHistoryDAO.newInstance();

    curam.financial.impl.ServiceInvoiceLineItemCorrection serviceInvoicLineItemCorrection = siliCorrectionDAO.get(
      siliCorrection.getID());

    siliCorrectionHistory.setSILICorrection(serviceInvoicLineItemCorrection);

    siliCorrectionHistory.insert();

  }

  // BEGIN, CR00200393, SSK
  /**
   * Cancels a Service Invoice Line Item Correction.
   *
   * @param arg0 Service invoice line item correction ID.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link SILICorrection#cancelServiceInvoiceLineItemCorrection(SILICorrectionVersionKey)}
   * . As part of the merging service invoice line item and service
   * invoice line item correction changes has been done to maintain
   * correction clients in service invoice line item client and
   * maintain correction history in service invoice line item
   * history entity. See release note: CR00200393.
   */
  @Deprecated
  public void cancelSILICorrection(SILICorrectionVersionKey arg0) throws AppException,
      InformationalException {
    // END, CR00200393
    curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
      arg0.SILICorrectionID);

    // Update the status to canceled
    siliCorrection.cancel(arg0.versionNo);

    // create SILI Correction History
    createSILICorrectionHistory(siliCorrection);

  }

  // BEGIN, CR00200393, SSK
  /**
   * Denies a Service Invoice Line Item Correction.
   *
   * @param arg0 Service invoice line item correction ID.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link SILICorrection#denyServiceInvoiceLineItemCorrection(SILICorrectionVersionKey)}
   * . As part of the merging service invoice line item and service
   * invoice line item correction changes has been done to maintain
   * correction clients in service invoice line item client and
   * maintain correction history in service invoice line item
   * history entity. See release note: CR00200393.
   */
  @Deprecated
  public void denySILICorrection(SILICorrectionVersionKey arg0) throws AppException,
      InformationalException {
    // END, CR00200393
    curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
      arg0.SILICorrectionID);

    // Update the status to deny
    siliCorrection.deny(arg0.versionNo);

    // create SILI Correction History
    createSILICorrectionHistory(siliCorrection);

  }

  // BEGIN, CR00200393, SSK
  /**
   * Submits a Service Invoice Line Item Correction for processing.
   *
   * @param arg0
   * Service invoice line item correction.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link SILICorrection#submitServiceInvoiceLineItemCorrectionForApproval(SILICorrectionVersionKey)}
   * . As part of the merging service invoice line item and service
   * invoice line item correction changes has been done to maintain
   * correction clients in service invoice line item client and
   * maintain correction history in service invoice line item
   * history entity. See release note: CR00200393.
   */
  @Deprecated
  public void submitSILICorrectionForApproval(SILICorrectionVersionKey arg0)
    throws AppException, InformationalException {
    // END, CR00200393
    curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
      arg0.SILICorrectionID);

    // Update the status to PendingApproval
    // START CR00094326, JSP
    siliCorrection.submit(arg0.versionNo);
    // END CR00094326

    // create SILI Correction History
    createSILICorrectionHistory(siliCorrection);

  }

  /**
   * Sorts the set of Service Invoice Line Item Correction by creation date.
   *
   * @param unsortedSILICorrections Unsorted list of service invoice line item correction.
   * @return List Sorted list of service invoice line item correction.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.financial.impl.ServiceInvoiceLineItemCorrection> sortSILICorrections(
    // END, CR00177241
    Set<curam.financial.impl.ServiceInvoiceLineItemCorrection> unsortedSILICorrections) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    final List<curam.financial.impl.ServiceInvoiceLineItemCorrection> siliCorrections = new ArrayList<curam.financial.impl.ServiceInvoiceLineItemCorrection>(
      unsortedSILICorrections);

    // Sort the corrections in the descending order by creation date
    Collections.sort(siliCorrections,
      new Comparator<curam.financial.impl.ServiceInvoiceLineItemCorrection>() {
      public int compare(
        final curam.financial.impl.ServiceInvoiceLineItemCorrection lhs,
        curam.financial.impl.ServiceInvoiceLineItemCorrection rhs) {
        return rhs.getCorrection().getCreationDateTime().compareTo(
          lhs.getCorrection().getCreationDateTime());
      }
    });
    return siliCorrections;
  }

  // BEGIN, CR00158345, GP
  // BEGIN, CR00200393, SSK
  /**
   * Adds a client to service invoice line item correction. Client details are
   * matched to see if they match with the registered person.
   *
   * @param siliClientDetails
   * The details of the client to be added to service invoice line item
   * correction.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link SILICorrection#addClientToServiceInvoiceLineItemCorrection(SILIClientDetails)}
   * . As part of the merging service invoice line item and service
   * invoice line item correction changes has been done to maintain
   * correction clients in service invoice line item client and
   * maintain correction history in service invoice line item
   * history entity. See release note: CR00200393.
   */
  @Deprecated
  public void addClientToSILICorrection(SILIClientDetails siliClientDetails)
    throws AppException, InformationalException {

    // END, CR00200393
    ServiceInvoiceLineItemCorrection serviceInvoiceLineItemcorrection = serviceInvoiceLineItemCorrectionDAO.get(
      siliClientDetails.siliCorrectionID);

    SILICorrectionClient siliCorrectionClient = siliCorrectionClientDAO.newInstance();

    siliCorrectionClient.setClientDOB(siliClientDetails.clientDOB);
    siliCorrectionClient.setClientFirstName(siliClientDetails.clientFirstName);
    siliCorrectionClient.setClientLastName(siliClientDetails.clientLastName);
    siliCorrectionClient.setClientReferenceNo(
      siliClientDetails.clientReferenceNo);
    siliCorrectionClient.setServiceInvoiceLineItemCorrection(
      serviceInvoiceLineItemcorrection);
    siliCorrectionClient.insert();

  }

  /**
   * {@inheritDoc}
   */
  public SILIClientDetailsList listClientsForSILICorrection(
    SILICorrectionKey siliCorrectionKey) throws AppException,
      InformationalException {

    ServiceInvoiceLineItemCorrection serviceInvoiceLineItemCorrection = serviceInvoiceLineItemCorrectionDAO.get(
      siliCorrectionKey.siliCorrectionID);
    // BEGIN, CR00235365, SSL
    SILIClientDetailsList siliClientDetailsList = serviceInvoiceLineItemCorrection.getSILICorrectionClients();

    // END, CR00235365

    return siliClientDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public void removeClientFromSILICorrection(
    SILICorrectionAndClientKey siliCorrectionAndClientKey)
    throws AppException, InformationalException {

    if (0 != siliCorrectionAndClientKey.siliCorrectionClientID) {
      // BEGIN, CR00200393, SSK
      ServiceInvoiceLineItemClient serviceInvoiceLineItemClient = serviceInvoiceLineItemClientDAO.get(
        siliCorrectionAndClientKey.siliCorrectionClientID);

      if (null != serviceInvoiceLineItemClient.getID()) {
        serviceInvoiceLineItemClient.remove();
      } else {
        // END, CR00200393
        SILICorrectionClient siliCorrectionClient = siliCorrectionClientDAO.get(
          siliCorrectionAndClientKey.siliCorrectionClientID);

        if (null
          != siliCorrectionClient.getServiceInvoiceLineItemCorrection().getID()) {
          siliCorrectionClient.remove();
        }
      }

    } else {

      ServiceInvoiceLineItemCorrection serviceInvoiceLineItemCorrection = serviceInvoiceLineItemCorrectionDAO.get(
        siliCorrectionAndClientKey.siliCorrectionID);

      // BEGIN, CR00200393, SSK
      if (0
        == siliCorrectionClientDAO.searchByServiceInvoiceLineItemCorrection(serviceInvoiceLineItemCorrection).size()
          && 0
            == serviceInvoiceLineItemClientDAO.searchBySILIAndCorrection(serviceInvoiceLineItemCorrection).size()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          SILICORRECTIONExceptionCreator.ERR_SILICORRECTION_XRV_THIS_SILICORRECTION_MUST_HAVE_ATLEAST_ONE_CLIENT(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }

      serviceInvoiceLineItemCorrection.setClientReferenceNumber(
        CuramConst.gkEmpty);
      serviceInvoiceLineItemCorrection.setClientFirstName(CuramConst.gkEmpty);
      serviceInvoiceLineItemCorrection.setClientLastName(CuramConst.gkEmpty);
      serviceInvoiceLineItemCorrection.setClientDateOfBirth(Date.kZeroDate);
      serviceInvoiceLineItemCorrection.setClientID(0l);
      serviceInvoiceLineItemCorrection.modify(
        serviceInvoiceLineItemCorrection.getVersionNo());
    }
  }

  // BEGIN, CR00200393, SSK
  /**
   * Creates a Service Invoice Line Item with the service invoice line item
   * correction details passed. If the service invoice line item client id is
   * present then client record will be added to service invoice line item
   * correction client table. Otherwise, client details resides in service
   * invoice line item correction table.
   *
   * @param serviceInvoiceLineItemCorrectionDetails
   * The service invoice line item correction details to be created.
   *
   * @return Primary key of service invoice line item correction that was
   * created.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link SILICorrection#createNewServiceInvoiceLineItemCorrection(ServiceInvoiceLineItemCorrectionDetails)}
   * . As part of the merging service invoice line item and service
   * invoice line item correction changes has been done to maintain
   * correction clients in service invoice line item client and
   * maintain correction history in service invoice line item
   * history entity. See release note: CR00200393.
   */
  @Deprecated
  public SILICorrectionKey createServiceInvoiceLineItemCorrection(
    ServiceInvoiceLineItemCorrectionDetails serviceInvoiceLineItemCorrectionDetails)
    throws AppException, InformationalException {

    // END, CR00200393
    curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.newInstance();

    setSILICorrectionDetails(serviceInvoiceLineItemCorrectionDetails,
      siliCorrection);

    SILIClientDetailsList siliClientDetailsList = WidgetHelper.convertXmlToServiceInvoiceLineItemClientDetailsList(
      serviceInvoiceLineItemCorrectionDetails.clientDetails);

    for (SILIClientDetails siliClientDetails : siliClientDetailsList.clientDetails.items()) {

      if (0 == siliClientDetails.siliClientID) {

        siliCorrection.setClientDateOfBirth(siliClientDetails.clientDOB);
        siliCorrection.setClientFirstName(siliClientDetails.clientFirstName);
        siliCorrection.setClientLastName(siliClientDetails.clientLastName);
        siliCorrection.setClientReferenceNumber(
          siliClientDetails.clientReferenceNo);
        break;
      }
    }

    siliCorrection.insert();

    for (SILIClientDetails siliClientDetails : siliClientDetailsList.clientDetails.items()) {

      if (0 != siliClientDetails.siliClientID) {

        SILICorrectionClient siliCorrectionClient = siliCorrectionClientDAO.newInstance();

        siliCorrectionClient.setClientDOB(siliClientDetails.clientDOB);
        siliCorrectionClient.setClientFirstName(
          siliClientDetails.clientFirstName);
        siliCorrectionClient.setClientLastName(siliClientDetails.clientLastName);
        siliCorrectionClient.setClientReferenceNo(
          siliClientDetails.clientReferenceNo);
        siliCorrectionClient.setServiceInvoiceLineItemCorrection(siliCorrection);
        siliCorrectionClient.insert();
      }
    }

    createSILICorrectionHistory(siliCorrection);

    SILICorrectionKey siliCorrectionKey = new SILICorrectionKey();

    siliCorrectionKey.siliCorrectionID = siliCorrection.getID();

    return siliCorrectionKey;
  }

  // BEGIN, CR00314240, SS
  /**
   * Updates the Service Invoice Line Item Correction details with the service
   * invoice line item correction details passed. If the service invoice line
   * item correction client id is present then client information present in
   * service invoice line item correction client will be updated. Otherwise,
   * client details present on service invoice line item correction will be
   * modified.
   *
   * @param serviceInvoiceLineItemCorrectionDetails
   * Service invoice line item correction details to be modified.
   *
   * @return Primary key of the service invoice line item correction that was
   * corrected.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link SERVICEINVOICELINEITEMExceptionCreator#ERR_SERVICEINVOICE_XFV_EITHER_CLIENT_REFNO_OR_OTHER_DTLS_MUST_BE_SPECIFIED}
   * -If either of client reference number or other details is not
   * entered.
   */
  // END, CR00314240
  public SILICorrectionKey modifyServiceInvoiceLineItemCorrection(
    ServiceInvoiceLineItemCorrectionDetails serviceInvoiceLineItemCorrectionDetails)
    throws AppException, InformationalException {

    final curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
      serviceInvoiceLineItemCorrectionDetails.details.siliCorrectionID);

    setSILICorrectionDetails(serviceInvoiceLineItemCorrectionDetails,
      siliCorrection);

    SILIClientDetailsList siliClientDetailsList = WidgetHelper.convertXmlToServiceInvoiceLineItemClientDetailsList(
      serviceInvoiceLineItemCorrectionDetails.clientDetails);

    for (SILIClientDetails siliClientDetails : siliClientDetailsList.clientDetails.items()) {

      if (0 != siliClientDetails.siliCorrectionClientID) {
        // BEGIN, CR00235365, SSK
        try {
          ServiceInvoiceLineItemClient serviceInvoiceLineItemClient = serviceInvoiceLineItemClientDAO.get(
            siliClientDetails.siliCorrectionClientID);

          if (0 != serviceInvoiceLineItemClient.getID()) {
            serviceInvoiceLineItemClient.setClientDOB(
              siliClientDetails.clientDOB);
            serviceInvoiceLineItemClient.setClientFirstName(
              siliClientDetails.clientFirstName);
            serviceInvoiceLineItemClient.setClientLastName(
              siliClientDetails.clientLastName);
            serviceInvoiceLineItemClient.setClientReferenceNo(
              siliClientDetails.clientReferenceNo);
            serviceInvoiceLineItemClient.modify(
              serviceInvoiceLineItemClient.getVersionNo());
          }
        } catch (RecordNotFoundException e) {// No client present in service invoice line item client entity
        }

        try {

          SILICorrectionClient siliCorrectionClient = siliCorrectionClientDAO.get(
            siliClientDetails.siliCorrectionClientID);

          ServiceInvoiceLineItemClient serviceInvoiceLineItemClient = serviceInvoiceLineItemClientDAO.newInstance();

          serviceInvoiceLineItemClient.setClientDOB(siliClientDetails.clientDOB);
          serviceInvoiceLineItemClient.setClientFirstName(
            siliClientDetails.clientFirstName);
          serviceInvoiceLineItemClient.setClientLastName(
            siliClientDetails.clientLastName);
          serviceInvoiceLineItemClient.setClientReferenceNo(
            siliClientDetails.clientReferenceNo);
          serviceInvoiceLineItemClient.setServiceInvoiceLineItemCorrection(
            siliCorrectionClient.getServiceInvoiceLineItemCorrection());
          serviceInvoiceLineItemClient.setServiceInvoiceLineItem(
            siliCorrectionClient.getServiceInvoiceLineItemCorrection().getServiceInvoiceLineItem());
          serviceInvoiceLineItemClient.insert();

          siliCorrectionClient.remove();

        } catch (RecordNotFoundException e) {// No client present in service invoice line item correction client
        }
        // END, CR00235365
      } else {
        // BEGIN, CR00314240, SS
        siliCorrection.setClientDateOfBirth(siliClientDetails.clientDOB);
        siliCorrection.setClientFirstName(siliClientDetails.clientFirstName);
        siliCorrection.setClientLastName(siliClientDetails.clientLastName);
        siliCorrection.setClientReferenceNumber(
          siliClientDetails.clientReferenceNo);

        if (GeneralConstants.kEmpty.equals(siliClientDetails.clientReferenceNo)
          && (GeneralConstants.kEmpty.equals(siliClientDetails.clientFirstName)
            || GeneralConstants.kEmpty.equals(siliClientDetails.clientLastName)
            || siliClientDetails.clientDOB.isZero())) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICE_XFV_EITHER_CLIENT_REFNO_OR_OTHER_DTLS_MUST_BE_SPECIFIED(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
          ValidationHelper.failIfErrorsExist();
          // END, CR00314240
        }     
      }
    }

    siliCorrection.modify(
      serviceInvoiceLineItemCorrectionDetails.details.versionNo);

    SILICorrectionKey siliCorrectionKey = new SILICorrectionKey();

    siliCorrectionKey.siliCorrectionID = siliCorrection.getID();

    return siliCorrectionKey;
  }

  /**
   * Reads Service Invoice Line Item Correction details for the input service
   * invoice line item correction.
   *
   * @param siliCorrectionKey
   * Contains the service invoice line item Correction ID.
   *
   * @return Details of the correction.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ServiceInvoiceLineItemCorrectionDetails viewServiceInvoiceLineItemCorrection(
    SILICorrectionKey siliCorrectionKey) throws AppException,
      InformationalException {

    ServiceInvoiceLineItemCorrectionDetails serviceInvoiceLineItemCorrectionDetails = new ServiceInvoiceLineItemCorrectionDetails();

    final curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
      siliCorrectionKey.siliCorrectionID);

    serviceInvoiceLineItemCorrectionDetails.details.amountInvoiced = siliCorrection.getAmountInvoiced();
    serviceInvoiceLineItemCorrectionDetails.details.caseRefNo = siliCorrection.getCaseReferenceNumber();
    serviceInvoiceLineItemCorrectionDetails.details.clientDOB = siliCorrection.getClientDateOfBirth();
    serviceInvoiceLineItemCorrectionDetails.details.clientFirstName = siliCorrection.getClientFirstName();
    serviceInvoiceLineItemCorrectionDetails.details.clientLastName = siliCorrection.getClientLastName();
    serviceInvoiceLineItemCorrectionDetails.details.clientRefNo = siliCorrection.getClientReferenceNumber();
    serviceInvoiceLineItemCorrectionDetails.details.externalRefNo = siliCorrection.getExternalReferenceNumber();
    serviceInvoiceLineItemCorrectionDetails.details.numberOfUnits = siliCorrection.getNumberOfUnits();
    serviceInvoiceLineItemCorrectionDetails.details.payeeName = siliCorrection.getPayeeName();
    serviceInvoiceLineItemCorrectionDetails.details.payeeRefNo = siliCorrection.getPayeeReferenceNumber();
    serviceInvoiceLineItemCorrectionDetails.details.providerName = siliCorrection.getProviderName();
    serviceInvoiceLineItemCorrectionDetails.details.providerRefNo = siliCorrection.getProviderReferenceNumber();
    serviceInvoiceLineItemCorrectionDetails.details.reason = siliCorrection.getReason();
    serviceInvoiceLineItemCorrectionDetails.details.saRefNo = siliCorrection.getServiceAuthorizationReferenceNumber();
    serviceInvoiceLineItemCorrectionDetails.details.serviceFromDate = siliCorrection.getServiceDateFrom();
    serviceInvoiceLineItemCorrectionDetails.details.serviceID = siliCorrection.getServiceOffering().getID();
    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = siliCorrection.getServiceInvoiceLineItem();

    serviceInvoiceLineItemCorrectionDetails.details.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
    serviceInvoiceLineItemCorrectionDetails.details.serviceToDate = siliCorrection.getServiceDateTo();
    serviceInvoiceLineItemCorrectionDetails.details.unitAmount = siliCorrection.getUnitAmount();
    serviceInvoiceLineItemCorrectionDetails.details.recordStatus = siliCorrection.getStatus().toString();
    serviceInvoiceLineItemCorrectionDetails.details.referenceNo = siliCorrection.getReferenceNumber();
    serviceInvoiceLineItemCorrectionDetails.details.siliCorrectionID = siliCorrection.getID();
    ServiceOffering serviceOffering = siliCorrection.getServiceOffering();

    serviceInvoiceLineItemCorrectionDetails.nameDetails.serviceName = serviceOffering.getName();
    serviceInvoiceLineItemCorrectionDetails.details.versionNo = siliCorrection.getVersionNo();

    SILIClientDetailsList siliClientDetailsList = listClientsForSILICorrection(
      siliCorrectionKey);

    serviceInvoiceLineItemCorrectionDetails.clientDetails = WidgetHelper.convertServiceInvoiceLineItemClientDetailsToXml(
      siliClientDetailsList);

    return serviceInvoiceLineItemCorrectionDetails;
  }

  /**
   * Sets the Service Invoice Line Item Correction details using Service Invoice
   * Line Item Correction object.
   *
   * @param siliCorrectionDetails
   * Service invoice line item correction details to be set.
   * @param siliCorrection
   * Service invoice line item correction to which details are to be
   * set.
   */
  protected void setSILICorrectionDetails(
    ServiceInvoiceLineItemCorrectionDetails serviceInvoiceLineItemCorrectionDetails,
    curam.financial.impl.ServiceInvoiceLineItemCorrection siliCorrection) {

    siliCorrection.setAmountInvoiced(
      serviceInvoiceLineItemCorrectionDetails.details.amountInvoiced);
    siliCorrection.setCaseReferenceNumber(
      serviceInvoiceLineItemCorrectionDetails.details.caseRefNo);
    siliCorrection.setClientDateOfBirth(
      serviceInvoiceLineItemCorrectionDetails.details.clientDOB);
    siliCorrection.setClientFirstName(
      serviceInvoiceLineItemCorrectionDetails.details.clientFirstName);
    siliCorrection.setClientLastName(
      serviceInvoiceLineItemCorrectionDetails.details.clientLastName);
    siliCorrection.setAmountInvoiced(
      serviceInvoiceLineItemCorrectionDetails.details.amountInvoiced);
    siliCorrection.setClientReferenceNumber(
      serviceInvoiceLineItemCorrectionDetails.details.clientRefNo);
    siliCorrection.setExternalReferenceNumber(
      serviceInvoiceLineItemCorrectionDetails.details.externalRefNo);
    siliCorrection.setNumberOfUnits(
      serviceInvoiceLineItemCorrectionDetails.details.numberOfUnits);
    siliCorrection.setPayeeName(
      serviceInvoiceLineItemCorrectionDetails.details.payeeName);
    siliCorrection.setPayeeReferenceNumber(
      serviceInvoiceLineItemCorrectionDetails.details.payeeRefNo);
    siliCorrection.setProviderName(
      serviceInvoiceLineItemCorrectionDetails.details.providerName);
    siliCorrection.setProviderReferenceNumber(
      serviceInvoiceLineItemCorrectionDetails.details.providerRefNo);
    siliCorrection.setReason(
      serviceInvoiceLineItemCorrectionDetails.details.reason);
    siliCorrection.setServiceAuthorizationReferenceNumber(
      serviceInvoiceLineItemCorrectionDetails.details.saRefNo);
    siliCorrection.setServiceDateFrom(
      serviceInvoiceLineItemCorrectionDetails.details.serviceFromDate);
    siliCorrection.setServiceDateTo(
      serviceInvoiceLineItemCorrectionDetails.details.serviceToDate);
    siliCorrection.setUnitAmount(
      serviceInvoiceLineItemCorrectionDetails.details.unitAmount);
    siliCorrection.setServiceOffering(
      serviceOfferingDAO.get(
        serviceInvoiceLineItemCorrectionDetails.details.serviceID));
    curam.financial.impl.ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      serviceInvoiceLineItemCorrectionDetails.details.serviceInvoiceLineItemID);

    siliCorrection.setServiceInvoiceLineItem(serviceInvoiceLineItem);
  }

  /**
   * Sorts the list of service invoice line item correction clients by client
   * name.
   *
   * @param unsortedSILICorrectionClients
   * Unsorted set of service invoice line item correction clients.
   * @return Sorted list of service invoice line item correction clients.
   */
  protected List<SILICorrectionClient> sortSILICorrectionClientByClientName(
    Set<SILICorrectionClient> unsortedSILICorrectionClients) {

    final List<SILICorrectionClient> siliCorrectionClientList = new ArrayList<SILICorrectionClient>(
      unsortedSILICorrectionClients);

    Collections.sort(siliCorrectionClientList,
      new Comparator<SILICorrectionClient>() {
      public int compare(final SILICorrectionClient lhs,
        SILICorrectionClient rhs) {
        return (lhs.getClientFirstName() + CPMConstants.kSpace + lhs.getClientLastName()).compareTo(
          rhs.getClientFirstName() + CPMConstants.kSpace
          + rhs.getClientLastName());
      }
    });

    return siliCorrectionClientList;
  }

  // END, CR00158345


  // BEGIN, CR00200393, SSK
  // BEGIN, CR00314240, SS
  /**
   * Creates a Service Invoice Line Item with the service invoice line item
   * correction details passed. If the service invoice line item client id is
   * present then client record will be added to service invoice line item
   * client table. Otherwise, client details resides in service invoice line
   * item correction table.
   *
   * @param serviceInvoiceLineItemCorrectionDetails
   * The service invoice line item correction details to be created.
   *
   * @return Primary key of service invoice line item correction that was
   * created.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link SERVICEINVOICELINEITEMExceptionCreator#ERR_SERVICEINVOICE_XFV_EITHER_CLIENT_REFNO_OR_OTHER_DTLS_MUST_BE_SPECIFIED}
   * -If either of client reference number or other details is not
   * entered.
   */
  // END, CR00314240
  public SILICorrectionKey createNewServiceInvoiceLineItemCorrection(
    final ServiceInvoiceLineItemCorrectionDetails serviceInvoiceLineItemCorrectionDetails)
    throws AppException, InformationalException {

    ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.newInstance();

    setSILICorrectionDetails(serviceInvoiceLineItemCorrectionDetails,
      siliCorrection);

    SILIClientDetailsList siliClientDetailsList = WidgetHelper.convertXmlToServiceInvoiceLineItemClientDetailsList(
      serviceInvoiceLineItemCorrectionDetails.clientDetails);

    // BEGIN, CR00314240, SS
    for (final SILIClientDetails siliClientDetails : siliClientDetailsList.clientDetails.items()) {

      if (0 == siliClientDetails.siliClientID) {
        siliCorrection.setClientDateOfBirth(siliClientDetails.clientDOB);
        siliCorrection.setClientFirstName(siliClientDetails.clientFirstName);
        siliCorrection.setClientLastName(siliClientDetails.clientLastName);
        siliCorrection.setClientReferenceNumber(
          siliClientDetails.clientReferenceNo);
        
        if (siliClientDetails.clientReferenceNo.equals(GeneralConstants.kEmpty)
          && (siliClientDetails.clientFirstName.equals(GeneralConstants.kEmpty)
            || siliClientDetails.clientLastName.equals(GeneralConstants.kEmpty)
            || siliClientDetails.clientDOB.isZero())) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICE_XFV_EITHER_CLIENT_REFNO_OR_OTHER_DTLS_MUST_BE_SPECIFIED(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
          ValidationHelper.failIfErrorsExist();
        }
        break;
      }
    }

    siliCorrection.insert();

    for (final SILIClientDetails siliClientDetails : siliClientDetailsList.clientDetails.items()) {

      if (0 != siliClientDetails.siliClientID) {

        final ServiceInvoiceLineItemClient serviceInvoiceLineItemClient = serviceInvoiceLineItemClientDAO.get(
          siliClientDetails.siliClientID);

        serviceInvoiceLineItemClient.setClientDOB(siliClientDetails.clientDOB);
        serviceInvoiceLineItemClient.setClientFirstName(
          siliClientDetails.clientFirstName);
        serviceInvoiceLineItemClient.setClientLastName(
          siliClientDetails.clientLastName);
        serviceInvoiceLineItemClient.setClientReferenceNo(
          siliClientDetails.clientReferenceNo);
        serviceInvoiceLineItemClient.setServiceInvoiceLineItemCorrection(
          siliCorrection);
    
        serviceInvoiceLineItemClient.modify(
          serviceInvoiceLineItemClient.getVersionNo());
        // END, CR00314240

      }
    }

    SILICorrectionKey siliCorrectionKey = new SILICorrectionKey();

    siliCorrectionKey.siliCorrectionID = siliCorrection.getID();

    return siliCorrectionKey;
  }

  /**
   * {@inheritDoc}
   */
  public void approveServiceInvoiceLineItemCorrection(
    final SILICorrectionVersionKey siliCorrectionVersionKey)
    throws AppException, InformationalException {

    Money paidAmt = Money.kZeroMoney;
    Money newPaymentAmt = Money.kZeroMoney;
    boolean isPayeeChanged = false;
    PaymentProcessing paymentProcessing = PaymentProcessingImpl.newInstance();

    FinancialNotification notification = FinancialNotificationFactory.newInstance();
    FinancialNotificationKey notificationKey = new FinancialNotificationKey();

    ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
      siliCorrectionVersionKey.SILICorrectionID);

    siliCorrection.approve(siliCorrectionVersionKey.versionNo);

    // set the status of the SILI from 'Completed' to 'Open'
    // SILI Correction can be approved only when SILI is in 'Completed' state
    updateSILIStatus(siliCorrection.getServiceInvoiceLineItem());

    ServiceInvoiceLineItem serviceInvoiceLineItem = siliCorrection.getServiceInvoiceLineItem();

    InstructionLineItemDtls itemDtls = paymentProcessing.getILIforSILI(
      serviceInvoiceLineItem);

    paidAmt = itemDtls.amount;

    // BEGIN, CR00305754, GYH
    // Check if there are any over/under payments made for this service invoice
    // line item and consider these over/under payment's amounts also.
    RelatedReferenceID relatedReferenceID = new RelatedReferenceID();

    relatedReferenceID.relatedReference = serviceInvoiceLineItem.getID().toString();
    OverUnderPaymentDetailsList overUnderPaymentDetailsList = SILICorrectionFactory.newInstance().searchOverUnderPaymentsByRelatedReference(
      relatedReferenceID);

    for (final OverUnderPaymentDetails underPaymentDetails : overUnderPaymentDetailsList.dtls.items()) {
      if (REASSESSMENTRESULTEntry.OVERPAYMENT.getCode().equals(
        underPaymentDetails.reassessmentResultType)) {
        paidAmt = new Money(
          paidAmt.getValue() - underPaymentDetails.amount.getValue());
      } else {
        paidAmt = new Money(
          paidAmt.getValue() + underPaymentDetails.amount.getValue());
      }
    }
    // END, CR00305754

    // if oldPayee is not equal to new payee, then notification to the old payee
    // has to be sent before SILIC overwrites SILI with latest values
    // also, ensure that notification is sent only the amount is already paid to
    // the payee
    if (null != serviceInvoiceLineItem.getPayee()
      && null != siliCorrection.getConcernRolePayee()
      && (!serviceInvoiceLineItem.getPayee().getID().equals(
        siliCorrection.getConcernRolePayee().getID()))
        && 0 != itemDtls.instructLineItemID) {

      isPayeeChanged = true;

      // send notification to the old payee regarding the amount he owes
      // (liability)
      notificationKey.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
      notificationKey.event = FinancialNotificationEvent.SILIC_OVERPAYMENT;
      notificationKey.amount = paidAmt;
      notification.createNotification(notificationKey);

    }

    setSILIFields(serviceInvoiceLineItem, siliCorrection);

    // automatic approval of SILI -- call 1) submit for approval 2) approval
    serviceInvoiceLineItem.submitAndApproveSILIForCorrection(
      serviceInvoiceLineItem.getVersionNo());

    serviceInvoiceLineItemClientDAO.copySILICorrectionClientDetailsToSILI(
      siliCorrection, serviceInvoiceLineItem);

    newPaymentAmt = paymentProcessing.getPaymentAmountForSILI(
      serviceInvoiceLineItem);

    // if payee has changed, send a notification for payment to the new payee
    if (isPayeeChanged) {

      notificationKey.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
      notificationKey.event = FinancialNotificationEvent.SILIC_PAYMENT;
      notificationKey.amount = newPaymentAmt;

      notification.createNotification(notificationKey);

    } else {

      // send notification for the payee regarding change in amount only if the
      // amount is already paid out
      // if paidAmt > newPaymentAmt, then send notification for amount old
      // payee owes (liability)
      // if paidAmt < newPaymentAmt, then send notification for new
      // payment
      // if paidAmt == newPaymentAmt, do nothing

      if (paidAmt.getValue() > newPaymentAmt.getValue()
        && itemDtls.instructLineItemID != 0) {

        notificationKey.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
        notificationKey.event = FinancialNotificationEvent.SILIC_OVERPAYMENT;
        notificationKey.amount = new Money(
          Math.abs(paidAmt.getValue() - newPaymentAmt.getValue()));

        notification.createNotification(notificationKey);
      } else if (paidAmt.getValue() < newPaymentAmt.getValue()
        && itemDtls.instructLineItemID != 0) {

        notificationKey.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
        notificationKey.event = FinancialNotificationEvent.SILIC_UNDERPAYMENT;
        notificationKey.amount = new Money(
          Math.abs(paidAmt.getValue() - newPaymentAmt.getValue()));
        
        notification.createNotification(notificationKey);
      }
    }

    final Event event = new Event();

    event.eventKey = PROVIDERMANAGEMENT.SILICORRECTIONAPPROVED;
    event.primaryEventData = siliCorrectionVersionKey.SILICorrectionID;

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

  }

  /**
   * {@inheritDoc}
   */
  public void cancelServiceInvoiceLineItemCorrection(
    final SILICorrectionVersionKey siliCorrectionVersionKey)
    throws AppException, InformationalException {
    ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
      siliCorrectionVersionKey.SILICorrectionID);

    siliCorrection.cancel(siliCorrectionVersionKey.versionNo);

  }

  /**
   * {@inheritDoc}
   */
  public void denyServiceInvoiceLineItemCorrection(
    final SILICorrectionVersionKey siliCorrectionVersionKey)
    throws AppException, InformationalException {
    ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
      siliCorrectionVersionKey.SILICorrectionID);

    siliCorrection.deny(siliCorrectionVersionKey.versionNo);

  }

  /**
   * {@inheritDoc}
   */
  public void submitServiceInvoiceLineItemCorrectionForApproval(
    final SILICorrectionVersionKey siliCorrectionVersionKey)
    throws AppException, InformationalException {

    ServiceInvoiceLineItemCorrection siliCorrection = siliCorrectionDAO.get(
      siliCorrectionVersionKey.SILICorrectionID);

    siliCorrection.submit(siliCorrectionVersionKey.versionNo);

  }
  
  /**
   * {@inheritDoc}
   */
  public void addClientToServiceInvoiceLineItemCorrection(
    final SILIClientDetails siliClientDetails) throws AppException,
      InformationalException {

    ServiceInvoiceLineItemCorrection serviceInvoiceLineItemCorrection = serviceInvoiceLineItemCorrectionDAO.get(
      siliClientDetails.siliCorrectionID);

    ServiceInvoiceLineItemClient serviceInvoiceLineItemClient = serviceInvoiceLineItemClientDAO.newInstance();

    serviceInvoiceLineItemClient.setClientDOB(siliClientDetails.clientDOB);
    serviceInvoiceLineItemClient.setClientFirstName(
      siliClientDetails.clientFirstName);
    serviceInvoiceLineItemClient.setClientLastName(
      siliClientDetails.clientLastName);
    serviceInvoiceLineItemClient.setClientReferenceNo(
      siliClientDetails.clientReferenceNo);
    serviceInvoiceLineItemClient.setServiceInvoiceLineItem(
      serviceInvoiceLineItemCorrection.getServiceInvoiceLineItem());
    serviceInvoiceLineItemClient.setServiceInvoiceLineItemCorrection(
      serviceInvoiceLineItemCorrection);
    serviceInvoiceLineItemClient.insert();

  }

  // END, CR00200393

  // BEGIN, CR00235365, SSK
  /**
   * Sorts the list of service invoice line item correction clients by client
   * name.
   *
   * @param unsortedSILICorrectionClients
   * Unsorted set of service invoice line item correction clients.
   *
   * @return Sorted list of service invoice line item correction clients.
   */
  protected SILIClientDetailsList sortServiceInvoiceLineItemCorrectionClientByClientName(
    final SILIClientDetailsList unsortedSILICorrectionClients) {

    SILIClientDetailsList siliClientDetailsList = unsortedSILICorrectionClients;

    Collections.sort(siliClientDetailsList.clientDetails,
      new Comparator<SILIClientDetails>() {
      public int compare(final SILIClientDetails lhs, SILIClientDetails rhs) {
        return (lhs.clientFirstName + CPMConstants.kSpace + lhs.clientLastName).compareTo(
          rhs.clientFirstName + CPMConstants.kSpace + rhs.clientLastName);
      }
    });

    return siliClientDetailsList;
  }
  // END, CR00235365
}
