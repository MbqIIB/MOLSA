/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.sl.impl;


import curam.codetable.TERMTYPE;
import curam.core.fact.SearchServiceFactory;
import curam.core.impl.LuceneHelper;
import curam.core.impl.SearchServiceConnector;
import curam.core.impl.util.CuramDocToResultStruct;
import curam.core.struct.CuramDocument;
import curam.core.struct.CuramField;
import curam.core.struct.CuramQuery;
import curam.core.struct.CuramTerm;
import curam.core.struct.SearchServerResults;
import curam.core.struct.SearchServiceKey;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.SearchServiceGroupKey;
import curam.cpm.sl.entity.struct.ServiceGroupDtls;
import curam.cpm.sl.struct.SearchServiceGroupResults;
import curam.message.impl.SERVICEOFFERINGExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.type.StringHelper;
import java.util.HashMap;


/**
 * This class creates the search query and performs the search for service group
 * lucene index search
 */
public class IndexServiceGroupSearch extends curam.cpm.sl.base.IndexServiceGroupSearch {

  // dictionary used for matching the entity attribute names
  // with the return struct name for output display
  protected final static HashMap<String, String> dictionary = new HashMap<String, String>();
  static {
    dictionary.put(CPMConstants.kServiceGroupName,
      CPMConstants.kServiceGroupName);
    dictionary.put(CPMConstants.kServiceGroupCode,
      CPMConstants.kServiceGroupCode);
    dictionary.put(CPMConstants.kServiceGroupID, CPMConstants.kServiceGroupID);
  }

  public SearchServiceGroupResults search(
    SearchServiceGroupKey searchServiceGroupKey) throws AppException,
      InformationalException {

    // If search criteria is empty
    if (StringHelper.isEmpty(searchServiceGroupKey.reference)
      && StringHelper.isEmpty(searchServiceGroupKey.name)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEOFFERINGExceptionCreator.ERR_SERVICEROFFERING_XRV_MUST_SPECIFY_SEARCH_CRITERIA(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
      ValidationHelper.failIfErrorsExist();

    }

    final SearchServiceGroupResults result = new SearchServiceGroupResults();
    final CuramQuery curamQuery = new CuramQuery();

    final LuceneHelper luceneHelper = new LuceneHelper();

    // add the terms to the curam query if they exist
    addTermIfExists(
      luceneHelper.createStandardTerm(CPMConstants.kServiceGroupName,
      searchServiceGroupKey.name, true),
      curamQuery);

    addTermIfExists(
      luceneHelper.createStandardTerm(CPMConstants.kServiceGroupReference,
      searchServiceGroupKey.reference, true),
      curamQuery);

    final SearchServiceKey searchServiceKey = new SearchServiceKey();

    searchServiceKey.searchServiceId = CPMConstants.kServiceGroupSearch;

    curamQuery.searchServiceId = SearchServiceFactory.newInstance().read(searchServiceKey).searchServiceId;

    // add field data to the search query
    curamQuery.fields.dtls.addRef(
      createResultField(CPMConstants.kServiceGroupName));
    curamQuery.fields.dtls.addRef(
      createResultField(CPMConstants.kServiceGroupCode));
    curamQuery.fields.dtls.addRef(
      createResultField(CPMConstants.kServiceGroupID));

    final SearchServerResults searchResults = SearchServiceConnector.search(
      curamQuery);

    // For each field in the CuramDocument, the method attempts
    // to find an attribute in the struct of the same name and data type
    // A dictionary is passed to resolve attribute names that do not match
    // A struct containing all mapped values is returned.
    for (int i = 0; i < searchResults.documents.dtls.size(); i++) {

      ServiceGroupDtls serviceGroupDtls = new ServiceGroupDtls();
      final CuramDocument document = searchResults.documents.dtls.item(i);

      serviceGroupDtls = (ServiceGroupDtls) CuramDocToResultStruct.convert(
        document, serviceGroupDtls, dictionary);

      result.dtlsList.dtls.addRef(serviceGroupDtls);
    }

    return result;
  }

  /**
   * Adds a term to the curam query if the term exists
   *
   * @param term
   * the curam term type
   * @param curamQuery
   * the curam query
   */
  protected void addTermIfExists(final CuramTerm term, final CuramQuery curamQuery) {

    if (term.termType.equals(TERMTYPE.STANDARD)) {
      if (term.stdTerm.value.length() > 0) {
        curamQuery.terms.dtls.addRef(term);
      }
    } else if (term.termType.equals(TERMTYPE.DATE)) {
      if (!term.dtTerm.value.isZero()) {
        curamQuery.terms.dtls.addRef(term);
      }
    }
  }

  /**
   * Creates a result field for the curam query
   *
   * @param field
   * the field name
   *
   * @return CuramField the curam field
   */
  protected CuramField createResultField(final String field) {
    final CuramField result = new CuramField();

    result.name = field;
    return result;
  }
}
