/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.intf.Participant;
import curam.core.facade.struct.ParticipantContextKey;
import curam.cpm.facade.struct.ExternalPersonHomePageResults;
import curam.cpm.facade.struct.ExternalUserParticipantLinkKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Process class used to read and maintain External Person data
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is no longer used. See release note:
 * CR00226000.
 */
@Deprecated
public abstract class CPMExternalLinkedPerson extends curam.cpm.facade.base.CPMExternalLinkedPerson {

  // ___________________________________________________________________________
  /**
   * Method to return the person details for External User linked to the person.
   * @param key
   *
   * @return The External Person home page details
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam V6.0.
   * This method is deprecated as it is no longer used. See release note:
   * CR00226000.
   */
  @Deprecated
  public ExternalPersonHomePageResults readHomePageDetails(
    ExternalUserParticipantLinkKey key) throws AppException,
      InformationalException {
    // Return object
    ExternalPersonHomePageResults externalPersonHomePageResults = new ExternalPersonHomePageResults();

    // External person home page value objects
    // BEGIN, CR00236076, AK
    curam.cpm.sl.intf.CPMExternalLinkedPerson externalLinkedPersonObj = curam.cpm.sl.fact.CPMExternalLinkedPersonFactory.newInstance();
    // END, CR00236076
    curam.cpm.sl.struct.ReadPersonPageDetails readPersonPageDetails = new  curam.cpm.sl.struct.ReadPersonPageDetails();

    // Read the person home page details
    readPersonPageDetails = externalLinkedPersonObj.readHomePage(key.key);

    // Assign the details to the return value object
    externalPersonHomePageResults.personHomePageDetails.assign(
      readPersonPageDetails);

    externalPersonHomePageResults.participantRoleIDDtls.participantRoleID = readPersonPageDetails.roleAndRelTypeDetails.participantRoleID;

    // Context Objects
    Participant participantObj = ParticipantFactory.newInstance();
    ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = readPersonPageDetails.roleAndRelTypeDetails.participantRoleID;

    // Get the context description for the concern role
    externalPersonHomePageResults.contextDescriptionDtls = participantObj.readContextDescription(participantContextKey).participantContextDescriptionDetails;

    return externalPersonHomePageResults;
  }

}
