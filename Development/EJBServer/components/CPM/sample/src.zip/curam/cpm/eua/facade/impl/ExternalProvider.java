/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.eua.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.cefwidgets.docbuilder.impl.ImagePanelBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.fact.AddressFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.Address;
import curam.core.sl.fact.ParticipantTabFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.struct.AddressTabDetails;
import curam.core.sl.struct.PhoneFaxDetails;
import curam.core.struct.AddressKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.OtherAddressData;
import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ExtProviderDetails;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.eua.facade.struct.LicenseDetails;
import curam.cpm.eua.facade.struct.LicenseDetailsList;
import curam.cpm.eua.facade.struct.LicenseSummaryList;
import curam.cpm.eua.facade.struct.PlaceSummaryDetailsList;
import curam.cpm.eua.facade.struct.PlacementInformationDetails;
import curam.cpm.eua.facade.struct.ProviderCategoryDetails;
import curam.cpm.eua.facade.struct.ProviderOrganizationTabDetails;
import curam.cpm.facade.fact.ContextDescriptionFactory;
import curam.cpm.facade.fact.LicenseFactory;
import curam.cpm.facade.fact.ProviderFactory;
import curam.cpm.facade.fact.ProviderGroupFactory;
import curam.cpm.facade.intf.ContextDescription;
import curam.cpm.facade.intf.License;
import curam.cpm.facade.intf.Provider;
import curam.cpm.facade.struct.LicenseIDProviderKey;
import curam.cpm.facade.struct.LicenseServiceOfferingsSummaryDetailsList;
import curam.cpm.facade.struct.LicenseSummaryDetails;
import curam.cpm.facade.struct.LicenseSummaryDetailsList;
import curam.cpm.facade.struct.PlaceAndPlacementDetails;
import curam.cpm.facade.struct.PlaceAndPlacementDetailsList;
import curam.cpm.facade.struct.PlaceLocationDetails;
import curam.cpm.facade.struct.ProviderCategoryDetailsList;
import curam.cpm.facade.struct.ViewProviderCategoryDetails;
import curam.cpm.facade.struct.ViewProviderGroupDetails;
import curam.cpm.facade.struct.ViewProviderSummaryDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.CompartmentKey;
import curam.cpm.sl.entity.struct.CompartmentKeyList;
import curam.cpm.sl.entity.struct.LicenseKey;
import curam.cpm.sl.entity.struct.PlaceKey;
import curam.cpm.sl.entity.struct.ProviderCategoryPeriodKey;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderGroupKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.message.BPOPARTICIPANT;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.place.impl.Compartment;
import curam.place.impl.CompartmentDAO;
import curam.place.impl.Place;
import curam.place.impl.PlaceDAO;
import curam.place.impl.Placement;
import curam.place.impl.PlacementDAO;
import curam.provider.impl.LicenseStatusEntry;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderGroupAssociate;
import curam.provider.impl.ProviderGroupAssociateDAO;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;
import curam.util.type.DateTime;


/**
 * This process class provides the functionality for the Provider 
 * through the External User Access application
 */
public abstract class ExternalProvider extends curam.cpm.eua.facade.base.ExternalProvider {

  // variables injected by guice
  /**
   * Inject compartmentDAO
   */
  @Inject
  protected CompartmentDAO compartmentDAO;
  
  /**
   * Inject placeDAO
   */
  @Inject
  protected PlaceDAO placeDAO;
  
  /**
   * Inject providerGroupAssociateDAO
   */
  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;
  
  /**
   * Placement DAO object
   */
  @Inject
  protected PlacementDAO placementDAO;
  
  /**
   * Provider DAO object
   */
  @Inject
  protected ProviderDAO providerDAO;

  // BEGIN, CR00197371, GP
  /**
   * Reference to Provider Organization DAO.
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;
  // END, CR00197371
  

  // BEGIN, CR00235511, GP
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;
  // END, CR00235511
  
  /**
   * Constructor
   */
  public ExternalProvider() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * View details for external Provider details page
   *
   * @param concernRoleKey -
   * contains the concernRoleID for the provider
   * @return This contains the details for the provider.
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ExtProviderDetails viewProvider(ConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {
   
    Provider providerFacade = ProviderFactory.newInstance();
    ProviderKey providerKey = new ProviderKey();
    ExtProviderDetails extProviderDetails = new ExtProviderDetails();
    
    providerKey.providerConcernRoleID = concernRoleKey.concernRoleID;

    // call security method to ensure the logged in user has the
    // rights to view this information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();
    
    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    extProviderDetails.providerDetails = providerFacade.viewProvider(
      providerKey);
   
    extProviderDetails.contextDescription.description = ContextDescriptionFactory.newInstance().getContextDescriptionForConcern(concernRoleKey).description;
    
    return extProviderDetails;
  }

  /**
   * List all licenses for the selected provider
   *
   * @param concernRoleKey -
   * contains a concernRoleID
   * @return This contains a list of licenses for the provider
   *
   * @throws AppException
   * @throws InformationalException
   * <<< difference resolved - line(s) deleted >>>
   */
  public LicenseDetailsList listLicensesForProvider(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    LicenseDetailsList licenseList = new LicenseDetailsList();
    ProviderConcernRoleKey providerConcernRoleKey = new ProviderConcernRoleKey();
    LicenseSummaryDetailsList tempLicenseList = new LicenseSummaryDetailsList();

    providerConcernRoleKey.providerConcernRoleID = concernRoleKey.concernRoleID;

    // call security check to ensure that the user accessing
    // this page has the rights to view the information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();
    
    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    License licenseFacade = LicenseFactory.newInstance();

    tempLicenseList = licenseFacade.listLicenses(providerConcernRoleKey);

    // filter the list, only want licenses that are not canceled.
    for (int i = 0; i < tempLicenseList.licenseSummaryDetails.size(); i++) {

      if (!tempLicenseList.licenseSummaryDetails.item(i).dtls.licenseStatus.equals(
        LicenseStatusEntry.CANCELED.getCode())) {
        licenseList.licenseDtlsList.licenseSummaryDetails.addRef(
          tempLicenseList.licenseSummaryDetails.item(i));
      }
    }

    // call method to get the context description
    Provider providerObj = ProviderFactory.newInstance();

    licenseList.contextDescription = providerObj.readProviderSummaryDetails(
      providerConcernRoleKey);
    
    return licenseList;
  }
  
  // BEGIN, CR00235511, GP
  /**
   * Lists the licenses for a provider.
   *
   * @param concernRoleKey
   * Provider for which licenses are to be retrieved.
   *
   * @return A list of licenses for a provider.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public LicenseSummaryList listLicenseDetailsForProvider(
    final ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    LicenseSummaryList licenseSummaryList = new LicenseSummaryList();

    LicenseDetailsList licenseDetailsList = listLicensesForProvider(
      concernRoleKey);
    
    for (final LicenseSummaryDetails licenseSummaryDetails : licenseDetailsList.licenseDtlsList.licenseSummaryDetails.items()) {
      LicenseDetails licenseDetails = new LicenseDetails();

      licenseDetails.createdBy = licenseSummaryDetails.dtls.createdBy;
      licenseDetails.dateIssued = licenseSummaryDetails.dtls.dateIssued;
      licenseDetails.expirationDate = licenseSummaryDetails.dtls.expirationDate;
      licenseDetails.licenseID = licenseSummaryDetails.dtls.licenseID;
      licenseDetails.licenseNumber = licenseSummaryDetails.dtls.licenseNumber;
      licenseDetails.licenseStatus = licenseSummaryDetails.dtls.licenseStatus;
      licenseDetails.licenseType = licenseSummaryDetails.dtls.licenseType;
      licenseDetails.pageContextDescription = licenseSummaryDetails.pageContextDescription;
      licenseDetails.providerConcernRoleID = licenseSummaryDetails.dtls.providerConcernRoleID;
      licenseDetails.renewedInd = licenseSummaryDetails.dtls.renewedInd;
      licenseDetails.versionNo = licenseSummaryDetails.dtls.versionNo;
      
      User user = userDAO.get(licenseDetails.createdBy);

      licenseDetails.createdByFullName = user.getFullName();
      
      licenseSummaryList.licenseDetails.addRef(licenseDetails);
    }
    
    return licenseSummaryList;
  }

  // END, CR00235511
  
  /**
   * This method returns license details for the selected license ID
   *
   * @param key -
   * contains the license ID
   * @return This contains license details
   *
   * @throws AppException
   * @throws InformationalException
   * <<< difference resolved - line(s) deleted >>>
   */
  public LicenseSummaryDetails viewLicenseForProvider(LicenseKey key)
    throws AppException, InformationalException {

    License licenseFacade = LicenseFactory.newInstance();
    LicenseSummaryDetails licenseSummaryDetails = new LicenseSummaryDetails();
    
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    
    // set the license details
    licenseSummaryDetails = licenseFacade.viewLicense(key);
    
    // set the concern Role ID
    concernRoleKey.concernRoleID = licenseSummaryDetails.dtls.providerConcernRoleID;
    // call security check to ensure that the user accessing
    // this page has the rights to view the information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();
    
    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);
    
    return licenseSummaryDetails;
  }

  /**
   * List all place/placement details for a provider
   *
   * @param concernRoleKey -
   * this contains the concernRoleID
   * @return This contains a list of place/placement details for a provider
   *
   * @throws AppException
   * @throws InformationalException
   * <<< difference resolved - line(s) deleted >>>
   */
  public PlaceSummaryDetailsList listPlaceSummaryDetails(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    // result variable
    PlaceSummaryDetailsList placeSummaryDetailsList = new PlaceSummaryDetailsList();

    ProviderKey providerKey = new ProviderKey();

    providerKey.providerConcernRoleID = concernRoleKey.concernRoleID;

    // call method to ensure that the user has access to page
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();
    
    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    // variables for reading the context description
    ContextDescription contextDescription = ContextDescriptionFactory.newInstance();

    placeSummaryDetailsList.contextDescription.pageContextDescription = contextDescription.getContextDescriptionForConcern(concernRoleKey).description;
 
    long compartmentID = 0;

    if (providerKey.providerConcernRoleID != 0) {
      final curam.provider.impl.Provider provider = providerDAO.get(
        providerKey.providerConcernRoleID);
      Set<curam.place.impl.Compartment> providerCompartments = provider.getCompartments();

      // Get the root compartment for provider
      for (curam.place.impl.Compartment compartment : providerCompartments) {
        if (compartment.getParentCompartment() == null) {
          compartmentID = compartment.getID();
          break;
        }
      }
    }

    final curam.place.impl.Compartment compartment = compartmentDAO.get(
      compartmentID);

    // BEGIN, CR00294258, GP
    final CompartmentKey parentCompartmentKey = new CompartmentKey();

    parentCompartmentKey.compartmentID = compartment.getID();
    final CompartmentKeyList childCompartmentIDs = compartmentDAO.getChildCompartmentIDs(
      parentCompartmentKey);
    
    // Places should be computed including the Parent,hence parent added
    // to the list.
    childCompartmentIDs.dtls.add(parentCompartmentKey);
    curam.place.impl.Compartment childCompartment;

    // Iterate through each child to get the place details
    for (final CompartmentKey compartmentKey : childCompartmentIDs.dtls) {
      
      childCompartment = compartmentDAO.get(compartmentKey.compartmentID);

      // END, CR00294258
      
      // Read details from place entity
      for (final curam.place.impl.Place place : sortPlaces(placeDAO// Begin CR00098993,CR00099001 KR
        .searchForAllPlacesByCompartment(childCompartment))) {
        // .searchAllPlacesByCompartment(childCompartment))) {
        // End CR00098993,CR00099001 KR
        PlaceAndPlacementDetails placementDetails = new PlaceAndPlacementDetails();

        placementDetails.placeName = place.getName();
        PlaceKey placeKey = new PlaceKey();

        placeKey.placeID = place.getID();

        // Get the location details in specified format
        PlaceLocationDetails placeLocationDetails = getLocationForPlace(
          placeKey);

        placementDetails.placeLocation = placeLocationDetails.location;
        placementDetails.placeType = place.getType().getCode();
        placementDetails.placeID = place.getID();
        // get placement details for place

        placementDetails.placeStatus = place.getLifecycleState().getCode();
        // BEGIN, CR00117391, SS
        Set<Placement> placePlacementList = placementDAO.searchPlacementForPlace(
          place, DateTime.getCurrentDateTime(), RECORDSTATUSEntry.NORMAL);

        // END, CR00117391
        // iterate through individual placement for place
        for (curam.place.impl.Placement placement : placePlacementList) {

          placementDetails.clientName = placement.getClient().getName();
          placementDetails.placementStartDate = placement.getDateTimeRange().start();
          placementDetails.placementEndDate = placement.getDateTimeRange().end();
          placementDetails.placementID = placement.getID();
          placementDetails.versionNo = placement.getVersionNo();

        }
        // Add place and client details to place list
        placeSummaryDetailsList.placeDetailsList.detailsList.addRef(
          placementDetails);
      }
    }

    return placeSummaryDetailsList;
  }

  /**
   * This returns a list of categories for a provider
   *
   * @param concernRoleKey -
   * contains the concernRoleID for a provider
   * @return This contains a list of category details for a provider
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ProviderCategoryDetails listProviderCategories(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    // Create instance of provider facade
    curam.cpm.facade.intf.Provider providerObj = ProviderFactory.newInstance();
    ProviderConcernRoleKey providerConcernRoleKey = new ProviderConcernRoleKey();

    providerConcernRoleKey.providerConcernRoleID = concernRoleKey.concernRoleID;

    // call method to ensure that the user has access to view information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();
    
    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);
    
    ViewProviderSummaryDetails viewProviderSummaryDetails = providerObj.readProviderSummaryDetails(
      providerConcernRoleKey);
    
    ProviderCategoryDetails providerCategoryDetails = new ProviderCategoryDetails();
    
    // set the context description
    providerCategoryDetails.pageContextDescription = viewProviderSummaryDetails.pageContextDescription;

    providerCategoryDetails.dtls = filterCategories(
      providerObj.listProviderCategories(providerConcernRoleKey));

    return providerCategoryDetails;

  }

  /**
   * This method removes all canceled records from the list passed in.
   *
   * @param unfilteredList
   * @return This contains a list of all records except canceled ones.
   */
  // BEGIN, CR00177241, PM
  protected ProviderCategoryDetailsList filterCategories(
    ProviderCategoryDetailsList unfilteredList) {
    // END, CR00177241

    ProviderCategoryDetailsList result = new ProviderCategoryDetailsList();

    for (int i = 0; i < unfilteredList.details.size(); i++) {

      if (!unfilteredList.details.item(i).recordStatus.equals(
        RECORDSTATUSEntry.CANCELLED.getCode())) {

        // add to result list
        result.details.addRef(unfilteredList.details.item(i));
      }
    }
    return result;

  }

  /**
   * This reads provider category details
   *
   * @param providerCategoryPeriodKey -
   * contains the provider category ID
   * @return This contains details for the provider category
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ViewProviderCategoryDetails viewProviderCategory(
    ProviderCategoryPeriodKey providerCategoryPeriodKey) throws AppException,
      InformationalException {

    // Create instance of provider facade
    curam.cpm.facade.intf.Provider providerObj = ProviderFactory.newInstance();
    
    ViewProviderCategoryDetails details = providerObj.viewProviderCategory(
      providerCategoryPeriodKey);
    
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    
    concernRoleKey.concernRoleID = details.providerCategory.providerConcernRoleID;
    
    // call method to ensure that the user has access to view information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();
    
    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);
    
    return details;

  }

  /**
   * This returns a list of service offerings for a license
   *
   * @param key -
   * contains the license ID and concernRoleID
   * @return This contains a list of service offerings for a license
   *
   * @throws AppException
   * @throws InformationalException
   */
  public LicenseServiceOfferingsSummaryDetailsList listLicenseServiceOfferings(
    LicenseIDProviderKey key) throws AppException, InformationalException {

    License licenseFacade = LicenseFactory.newInstance();
    LicenseServiceOfferingsSummaryDetailsList details = new LicenseServiceOfferingsSummaryDetailsList();
    
    details = licenseFacade.listLicenseServiceOfferings(key);
    
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    
    concernRoleKey.concernRoleID = details.viewProviderSummaryDetails.details.concernRoleID;
    
    // call method to ensure that the user has access to view information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();
    
    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);
    
    return details;
  }

  /**
   * This returns placement information for a provider.
   *
   * @param key
   * Contains the provider concern Role ID.
   *
   * @return The placement information details for a provider.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PlacementInformationDetails viewPlacementInformationForProvider(
    ProviderKey key) throws AppException, InformationalException {

    // result variable
    PlacementInformationDetails placementInformationDetails = new PlacementInformationDetails();

    // the ID that we get from the client is providerGroupAssociateID,
    ProviderGroupAssociate providerGroupAssociate = providerGroupAssociateDAO.get(
      key.providerConcernRoleID);
    
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    
    // set the concern role key
    concernRoleKey.concernRoleID = providerGroupAssociate.getProvider().getID();
    
    // call method to ensure that the user has access to view information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);    
    final curam.provider.impl.Provider provider = providerGroupAssociate.getProvider();

    // get all compartments for provider
    for (final Compartment compartments : compartmentDAO.searchAllCompartments(
      provider)) {

      // BEGIN, CR00177555, NS
      // Get number of available places.
      placementInformationDetails.numberAvailablePlaces += placeDAO.searchAvailablePlacesForCompartmentInDateTime(compartments, DateTime.getCurrentDateTime()).size();
      // END, CR00177555

      // Get number of occupied places.
      placementInformationDetails.numberOccupiedPlaces += placeDAO.searchOccupiedPlacesForCompartment(compartments, DateTime.getCurrentDateTime()).size();

      // BEGIN, CR00177555, NS
      // Get number of out of use places.
      placementInformationDetails.numberOutOfUsePlaces += placeDAO.searchOutOfUsePlacesForCompartmentInDateTime(compartments, DateTime.getCurrentDateTime()).size();
      // END, CR00177555

      // Get number of emergency places.
      placementInformationDetails.numberEmergencyPlaces += placeDAO.searchEmergencyPlacesForCompartment(compartments).size();
    }

    // call facade method to get places for provider
    ProviderKey providerPlaceKey = new ProviderKey();

    providerPlaceKey.providerConcernRoleID = provider.getID();
    
    PlaceAndPlacementDetailsList placeAndPlacementDetailsList = listPlaceSummaryDetails(concernRoleKey).placeDetailsList;

    // need to filter the list to only contain placement Details
    for (int i = 0; i < placeAndPlacementDetailsList.detailsList.size(); i++) {

      if (placeAndPlacementDetailsList.detailsList.item(i).placementID != 0) {

        // add to the return list
        placementInformationDetails.placementDtlsList.detailsList.addRef(
          placeAndPlacementDetailsList.detailsList.item(i));
      }
    }
    // variables for reading the context description
    ContextDescription contextDescription = ContextDescriptionFactory.newInstance();

    // set the key
    concernRoleKey.concernRoleID = provider.getID();   

    placementInformationDetails.contextDescription.description = contextDescription.getContextDescriptionForConcern(concernRoleKey).description;
    return placementInformationDetails;
  }

  /**
   * This method reads provider group details.
   *
   * @param key - contains the provider group concern Role ID
   * @return This contains the provider group details
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ViewProviderGroupDetails viewProviderGroupDetails(
    ProviderGroupKey key) throws AppException, InformationalException {

    // call method to ensure that the user has access to view page
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();
    
    // set the key
    externalSecurityKey.concernRoleKey.concernRoleID = key.providerGroupConcernRoleID;
    externalSecurityKey.viewProviderGroupDetailsInd = true;
    
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);
    
    // Create instance of provider group facade
    curam.cpm.facade.intf.ProviderGroup providerGroupObj = ProviderGroupFactory.newInstance();

    // invoke facade layer method
    return providerGroupObj.viewProviderGroup(key);
  }

  /**
   * Private method for sorting the set
   *
   * @param places -
   * contains set of places
   *
   * @return List
   */
  // BEGIN, CR00177241, PM
  protected List<Place> sortPlaces(Set<Place> places) {
    // END, CR00177241
    final List<Place> placesList = new ArrayList<Place>(places);

    Collections.sort(placesList, new Comparator<Place>() {
      public int compare(final Place lhs, Place rhs) {
        return lhs.getName().compareTo(rhs.getName());
      }
    });
    return placesList;
  }

  /**
   * Method to find the parent compartment for the child compartment.
   *
   * @param key -
   * Contains PlaceKey
   *
   * @return PlaceLocationDetails
   * @throws AppException
   * @throws InformationalException
   */
  public PlaceLocationDetails getLocationForPlace(PlaceKey key)
    throws AppException, InformationalException {
    PlaceLocationDetails locationDetails = new PlaceLocationDetails();
    curam.place.impl.Place place = placeDAO.get(key.placeID);
    Compartment currentCompartment = place.getCompartment();
    Compartment parentCompartment = null;
    String location = CPMConstants.kEmptyString;

    parentCompartment = place.getCompartment().getParentCompartment();
    if (parentCompartment != null) {
      location = buildLocation(parentCompartment, location);
    }
    location += currentCompartment.getName();
    locationDetails.location = location;
    return locationDetails;
  }

  /**
   * Method to find the location of the compartment and concatenate it.
   *
   * @param parentCompartment -
   * Compartment contains parent comaprtmentID
   * @param location -
   * contains the location of the place
   *
   * @return String - location of the place after concatenate all the related
   * locations.
   */
  // BEGIN, CR00177241, PM
  protected String buildLocation(Compartment parentCompartment, String location) {
    // END, CR00177241
    if (parentCompartment != null) {
      Compartment currentCompartment = compartmentDAO.get(
        parentCompartment.getID());

      location = buildLocation(currentCompartment.getParentCompartment(),
        location);
      location += currentCompartment.getName() + CPMConstants.kGreaterThan;
    }
    return location;
  }

  /**
   * Reads the context details for a Provider.
   *
   * @param key
   * ProviderConcernRoleKey Contains the Provider concernroleID.
   *
   * @return ViewProviderSummaryDetails Contains the page context description.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewProviderSummaryDetails readProviderSummaryDetails(
    ProviderConcernRoleKey key) throws AppException, InformationalException {

    // creating viewProviderSummaryDetails struct
    ViewProviderSummaryDetails viewProviderSummaryDetails = new ViewProviderSummaryDetails();

    // Provider Entity
    curam.provider.impl.Provider provider = providerDAO.get(
      key.providerConcernRoleID);

    // Get the Provider Reference Number
    String refNumber = provider.getPrimaryAlternateID();

    // Set the summary details
    viewProviderSummaryDetails.details.concernRoleID = key.providerConcernRoleID;
    viewProviderSummaryDetails.details.providerName = provider.getName();
    viewProviderSummaryDetails.details.referenceNumber = refNumber;

    // construct the page context description
    viewProviderSummaryDetails.pageContextDescription = provider.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + refNumber;

    return viewProviderSummaryDetails;
  }

  // BEGIN, CR00197371, GP
  /**
   * Reads the provider or provider group tab details.
   *
   * @param providerOrganizationKey
   * Provider or provider group id for which details are to be read.
   *
   * @return Provider or provider group tab details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProviderOrganizationTabDetails readProviderOrganizationTabDetails(
    final ConcernRoleKey providerOrganizationKey) throws AppException,
      InformationalException {

    ProviderOrganizationTabDetails providerOrganizationTabDetails = new ProviderOrganizationTabDetails();

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      providerOrganizationKey.concernRoleID);

    Address address = AddressFactory.newInstance();
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = providerOrganization.getPrimaryAddressID();
    OtherAddressData addressData = address.readAddressData(addressKey);

    providerOrganizationTabDetails.providerOrganizationName = providerOrganization.getName();

    ContentPanelBuilder containerPanel = ContentPanelBuilder.createPanel(
      CuramConst.gkContainerPanel);

    // BEGIN, CR00246277, NS
    ImagePanelBuilder imagePanelBuilder = ImagePanelBuilder.createPanel();

    imagePanelBuilder.addParticipantImage(CPMConstants.kIconProvider,
      CuramConst.gkEmpty, CPMConstants.kRendererImages);
    
    ContentPanelBuilder imagePanel = imagePanelBuilder.getImagePanel();
    // END, CR00246277

    // BEGIN, CR00245989, GP
    ContentPanelBuilder centerPanel = ContentPanelBuilder.createPanel(
      CuramConst.gkTabDetails);

    centerPanel.addRoundedCorners();

    centerPanel.addStringItem(providerOrganization.getName(),
      CuramConst.gkContentParticipantName);
    centerPanel.addStringItem(providerOrganization.getPrimaryAlternateID(),
      CuramConst.gkContentParticipantID);

    TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
    AddressTabDetails addressTabDetails = new AddressTabDetails();

    addressTabDetails.addressData = addressData.addressData;

    centerPanel.addStringItem(
      tabDetailFormatterObj.formatAddress(addressTabDetails).addressString,
      CuramConst.gkContentAddress);

    centerPanel.addStringItem(CuramConst.gkNewLine);

    ContentPanelBuilder contactContents = ContentPanelBuilder.createPanel(
      CuramConst.gkContentContacts);

    ImageBuilder phoneIconImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconPhone, CuramConst.gkEmpty);

    phoneIconImageBuilder.setImageResource(CuramConst.gkRendererImages);

    contactContents.addImageItem(phoneIconImageBuilder);

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = providerOrganization.getID();
    PhoneFaxDetails phoneFaxDetails = ParticipantTabFactory.newInstance().getPhoneFaxDetails(
      concernRoleKey);

    if (phoneFaxDetails.phoneNumberString.length() != 0) {

      contactContents.addStringItem(phoneFaxDetails.phoneNumberString,
        CuramConst.gkPhoneNumber);
    } else {
      LocalisableString detailsNotRecorded = new LocalisableString(
        BPOPARTICIPANT.INF_NOT_RECORDED);

      contactContents.addlocalisableStringItem(
        detailsNotRecorded.toClientFormattedText(), CuramConst.gkPhoneNumber);
    }

    ImageBuilder emailIconImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconEmail, CuramConst.gkEmpty);

    emailIconImageBuilder.setImageResource(CuramConst.gkRendererImages);

    contactContents.addImageItem(emailIconImageBuilder);

    if (null != providerOrganization.getEmailAddress()) {

      LinkBuilder emailLinkBuilder = LinkBuilder.createLink(
        providerOrganization.getEmailAddress().getEmail(),
        CuramConst.gkMailto + providerOrganization.getEmailAddress().getEmail());

      contactContents.addWidgetItem(emailLinkBuilder, CuramConst.gkStyle,
        CuramConst.gkLink, CuramConst.gkEmail);
    } else {
      LocalisableString detailsNotRecorded = new LocalisableString(
        BPOPARTICIPANT.INF_NOT_RECORDED);

      contactContents.addlocalisableStringItem(
        detailsNotRecorded.toClientFormattedText(), CuramConst.gkEmail);
    }

    centerPanel.addWidgetItem(contactContents, CuramConst.gkStyle,
      CuramConst.gkContentPanel);
    // END, CR00245989
    
    // BEGIN, CR00246277, NS
    containerPanel.addWidgetItem(imagePanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CPMConstants.gkProviderImagePanel);
    // END, CR00246277

    containerPanel.addWidgetItem(centerPanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CuramConst.gkPersonDetailsPanelNoLinks);

    providerOrganizationTabDetails.providerOrganizationTabDetails = containerPanel.toString();
    return providerOrganizationTabDetails;
  }
  // END, CR00197371
}
