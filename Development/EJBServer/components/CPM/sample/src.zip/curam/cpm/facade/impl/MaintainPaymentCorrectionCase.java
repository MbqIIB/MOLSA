/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012, 2014
 *
 * The source code for this program is not published or otherwise divested 
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office 
 */

/*
 * Copyright 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import com.google.inject.Inject;

import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrection;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.OverpaymentCaseTabDetail;
import curam.core.sl.struct.PaymentCorrectionCaseTabResult;
import curam.core.sl.struct.UnderpaymentCaseTabDetail;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.InformationalMsgDtls;
import curam.cpm.sl.impl.FinancialCaseTab;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;


/**
 * {@inheritDoc}
 */
public class MaintainPaymentCorrectionCase extends curam.cpm.facade.base.MaintainPaymentCorrectionCase {
  
  /**
   * Reference to Payment Correction interface.
   */
  @Inject
  protected PaymentCorrection paymentCorrection;
  
  /**
   * Constructor of the class.
   */
  public MaintainPaymentCorrectionCase() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Read the details for the payment correction case tab details panel.
   *
   * @param CaseIDKey the unique identifier for the payment correction case
   *
   * @return payment correction case tab details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public PaymentCorrectionCaseTabResult readPaymentCorrectionCaseTabResult(
    final CaseIDKey caseIDKey) throws AppException, InformationalException {

    PaymentCorrectionCaseTabResult paymentCorrectionCaseTabResult = new PaymentCorrectionCaseTabResult();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseIDKey.caseID;
    final FinancialCaseTab financialCaseTab = new FinancialCaseTab();

    if (paymentCorrection.isOverPaymentPaymentCorrection(caseHeaderKey)) {

      paymentCorrectionCaseTabResult.dtls = financialCaseTab.readOverPaymentCorrectionCaseTabDetail(
        caseIDKey);
    } else if (paymentCorrection.isUnderPaymentPaymentCorrection(caseHeaderKey)) {
      paymentCorrectionCaseTabResult.dtls = financialCaseTab.readUnderPaymentCorrectionCaseTabDetail(
        caseIDKey);
    }

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      paymentCorrectionCaseTabResult.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }
    return paymentCorrectionCaseTabResult;
  }
  
  // BEGIN, CR00417706, SS
  /**
   * Read the details for the Overpayment case tab details panel.
   *
   * @param caseIDKey
   * The unique identifier for the overpayment case.
   *
   * @return The overpayment case tab details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public OverpaymentCaseTabDetail readOverPaymentCaseTabDetail(
    final CaseIDKey caseIDKey) throws AppException, InformationalException {
    final FinancialCaseTab financialCaseTab = new FinancialCaseTab();

    return financialCaseTab.readOverPaymentCaseTabDetail(caseIDKey);
  }

  /**
   * Read the details for the Underpayment case tab details panel.
   *
   * @param caseIDKey The unique identifier for the Underpayment case.
   *
   * @return The Underpayment case tab details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public UnderpaymentCaseTabDetail readUnderPaymentCaseTabDetail(final CaseIDKey caseIDKey)
    throws AppException, InformationalException {
    final FinancialCaseTab financialCaseTab = new FinancialCaseTab();

    return financialCaseTab.readUnderPaymentCaseTabDetail(caseIDKey);
  }  
  // END, CR00417706
}
