/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import com.google.inject.Inject;
import curam.attendance.impl.PRLIClient;
import curam.attendance.impl.PRLIClientDAO;
import curam.attendance.impl.ProviderRosterLineItem;
import curam.attendance.impl.ProviderRosterLineItemDAO;

import curam.core.impl.CuramConst;
import curam.core.struct.AddressDtls;
import curam.cpm.facade.struct.PRLIClientDetails;
import curam.cpm.facade.struct.PRLIClientDetailsList;
import curam.cpm.facade.struct.PRLIClientKeyVersionDetails;
import curam.cpm.sl.entity.struct.ProviderRosterLineItemKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import java.util.Set;


/**
 * Contains methods to manage provider roster line item clients.
 */
public abstract class MaintainPRLIClient extends curam.cpm.facade.base.MaintainPRLIClient {

  /**
   * Reference to provider roster line item client DAO.
   */
  @Inject
  protected PRLIClientDAO prliClientDAO;

  /**
   * Reference to provider roster line item DAO.
   */
  @Inject
  protected ProviderRosterLineItemDAO providerRosterLineItemDAO;

  /**
   * Default constructor that does Guice instantiation.
   */
  protected MaintainPRLIClient() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Associates the input client with the provider roster line item.
   *
   * @param prliClientDetails
   * Provider roster line item client details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void addPRLIClient(PRLIClientDetails prliClientDetails)
    throws AppException, InformationalException {
    PRLIClient prliClient = prliClientDAO.newInstance();

    prliClient.setClientFirstName(prliClientDetails.dtls.clientFirstName);
    prliClient.setClientLastName(prliClientDetails.dtls.clientLastName);
    prliClient.setClientReferenceNo(prliClientDetails.dtls.clientReferenceNo);
    prliClient.setClientDOB(prliClientDetails.dtls.clientDOB);
    AddressDtls addressDtls = new AddressDtls();

    addressDtls.addressData = prliClientDetails.addressData;
    prliClient.setAddress(addressDtls);
    prliClient.setProviderRosterLineItem(
      providerRosterLineItemDAO.get(
        prliClientDetails.dtls.providerRosterLineItemID));
    prliClient.setConcernRoleIfExists();
    prliClient.insert();
  }

  /**
   * Logically deletes the client identified by the input key from the provider
   * roster line item.
   *
   * @param keyVersionDetails
   * Contains the provider roster line item client ID and the version
   * number.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancelPRLIClient(PRLIClientKeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {
    if (keyVersionDetails.prliClientId != CuramConst.gkZero) {
      PRLIClient prliClient = prliClientDAO.get(keyVersionDetails.prliClientId);

      prliClient.cancel(keyVersionDetails.prliClientVersionNo);
    } else {
      ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
        keyVersionDetails.providerRosterLineItemID);

      providerRosterLineItem.deleteClient(keyVersionDetails.prliVersionNo);
    }
  }

  /**
   * Updates the client associated with the provider roster line item with the
   * input details.
   *
   * @param prliClientDetails
   * Provider roster line item client details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyPRLIClient(PRLIClientDetails prliClientDetails)
    throws AppException, InformationalException {
    if (prliClientDetails.dtls.prliClientId != CuramConst.gkZero) {
      PRLIClient prliClient = prliClientDAO.get(
        prliClientDetails.dtls.prliClientId);

      prliClient.setClientFirstName(prliClientDetails.dtls.clientFirstName);
      prliClient.setClientLastName(prliClientDetails.dtls.clientLastName);
      prliClient.setClientReferenceNo(prliClientDetails.dtls.clientReferenceNo);
      prliClient.setClientDOB(prliClientDetails.dtls.clientDOB);
      prliClient.setProviderRosterLineItem(
        providerRosterLineItemDAO.get(
          prliClientDetails.dtls.providerRosterLineItemID));

      AddressDtls addressDtls = new AddressDtls();

      addressDtls.addressData = prliClientDetails.addressData;
      prliClient.setAddress(addressDtls);

      prliClient.setConcernRoleIfExists();
      prliClient.modify(prliClientDetails.dtls.versionNo);
    } else {
      ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
        prliClientDetails.dtls.providerRosterLineItemID);

      providerRosterLineItem.setClientFirstName(
        prliClientDetails.dtls.clientFirstName);
      providerRosterLineItem.setClientLastName(
        prliClientDetails.dtls.clientLastName);
      providerRosterLineItem.setClientReferenceNo(
        prliClientDetails.dtls.clientReferenceNo);
      providerRosterLineItem.setClientDOB(prliClientDetails.dtls.clientDOB);

      AddressDtls addressDtls = new AddressDtls();

      addressDtls.addressData = prliClientDetails.addressData;
      providerRosterLineItem.setAddress(addressDtls);

      providerRosterLineItem.modifyRosterLineItem();
    }
  }

  /**
   * Retrieves the roster line item client details.
   *
   * @param prliClientKey
   * Contains provider roster line item client ID.
   *
   * @return The provider roster line item client details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLIClientDetails viewPRLIClient(
    curam.cpm.facade.struct.PRLIClientKey prliClientKey) throws AppException,
      InformationalException {
    PRLIClientDetails prliClientDetails = new PRLIClientDetails();

    if (prliClientKey.prliClientId != CuramConst.gkZero) {
      PRLIClient prliClient = prliClientDAO.get(prliClientKey.prliClientId);

      prliClientDetails.dtls.clientFirstName = prliClient.getClientFirstName();
      prliClientDetails.dtls.clientLastName = prliClient.getClientLastName();
      prliClientDetails.dtls.clientReferenceNo = prliClient.getClientReferenceNo();
      prliClientDetails.dtls.clientDOB = prliClient.getClientDOB();
      prliClientDetails.dtls.prliClientId = prliClient.getID();
      prliClientDetails.dtls.providerRosterLineItemID = prliClient.getProviderRosterLineItem().getID();
      prliClientDetails.prliVersionNo = prliClient.getProviderRosterLineItem().getVersionNo();
      prliClientDetails.dtls.versionNo = prliClient.getVersionNo();
      prliClientDetails.addressData = prliClient.getAddressData();
      prliClientDetails.dtls.addressID = prliClient.getAddressID();
    } else {
      ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
        prliClientKey.providerRosterLineItemID);

      prliClientDetails.dtls.clientFirstName = providerRosterLineItem.getClientFirstName();
      prliClientDetails.dtls.clientLastName = providerRosterLineItem.getClientLastName();
      prliClientDetails.dtls.clientReferenceNo = providerRosterLineItem.getClientReferenceNo();
      prliClientDetails.dtls.clientDOB = providerRosterLineItem.getClientDOB();
      prliClientDetails.dtls.providerRosterLineItemID = providerRosterLineItem.getID();
      prliClientDetails.prliVersionNo = providerRosterLineItem.getVersionNo();
      prliClientDetails.addressData = providerRosterLineItem.getAddressData();
      prliClientDetails.dtls.addressID = providerRosterLineItem.getAddressID();
    }
    return prliClientDetails;
  }

  /**
   * Returns the list of all clients associated with the given roster line item.
   *
   * @param providerRosterLineItemKey
   * Contains provider roster line item ID.
   *
   * @return List of clients associated with the provider roster line item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLIClientDetailsList listClientsForPRLI(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {
    PRLIClientDetailsList prliClientDetailsList = new PRLIClientDetailsList();
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    if (providerRosterLineItem.isClientAttached()) {

      PRLIClientDetails prliClientDetails = new PRLIClientDetails();

      prliClientDetails.addressData = providerRosterLineItem.getAddressData();

      prliClientDetails.dtls.clientFirstName = providerRosterLineItem.getClientFirstName();
      prliClientDetails.dtls.clientLastName = providerRosterLineItem.getClientLastName();
      prliClientDetails.dtls.clientReferenceNo = providerRosterLineItem.getClientReferenceNo();
      prliClientDetails.dtls.clientDOB = providerRosterLineItem.getClientDOB();
      prliClientDetails.dtls.addressID = providerRosterLineItem.getAddressID();
      prliClientDetails.dtls.versionNo = providerRosterLineItem.getVersionNo();

      if (providerRosterLineItem.getClient() != null) {
        prliClientDetails.isRegisteredClientInd = true;
        prliClientDetails.prliVersionNo = providerRosterLineItem.getVersionNo();
      }
      prliClientDetailsList.clientDtls.addRef(prliClientDetails);
    }

    Set<PRLIClient> clientList = prliClientDAO.listClientsForPRLI(
      providerRosterLineItem);

    for (PRLIClient client : clientList) {
      PRLIClientDetails prliClientDetails = new PRLIClientDetails();

      prliClientDetails.addressData = client.getAddressData();

      prliClientDetails.dtls.clientFirstName = client.getClientFirstName();
      prliClientDetails.dtls.clientLastName = client.getClientLastName();
      prliClientDetails.dtls.clientReferenceNo = client.getClientReferenceNo();
      prliClientDetails.dtls.clientDOB = client.getClientDOB();
      prliClientDetails.dtls.addressID = client.getAddressID();
      prliClientDetails.dtls.versionNo = client.getVersionNo();
      prliClientDetails.dtls.prliClientId = client.getID();

      if (client.getClient() != null) {
        prliClientDetails.isRegisteredClientInd = true;
        prliClientDetails.prliVersionNo = providerRosterLineItem.getVersionNo();
      }
      prliClientDetailsList.clientDtls.addRef(prliClientDetails);
    }

    return prliClientDetailsList;
  }

}
