/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.util.impl;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import curam.core.impl.CuramConst;
import curam.util.exception.AppRuntimeException;
import curam.util.type.Blob;


/**
 * Contains helper methods to processing XML Dom objects.
 */
public abstract class DomUtils {

  /**
   * Creates an empty DOM document.
   *
   * @return The DOM document.
   */
  public static Document createNewDocument() {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder docBuilder;

    try {
      docBuilder = factory.newDocumentBuilder();
    } catch (ParserConfigurationException e) {
      throw new AppRuntimeException(e);
    }

    Document doc = docBuilder.newDocument();

    return doc;
  }

  /**
   * Returns the given Document as a blob.
   *
   * @param document
   * The Document to convert
   * @return The Blob with the Document data
   */
  public static Blob getDataBlob(final Document document) {
    Blob blob = null;

    try {
      ByteArrayOutputStream baos = new ByteArrayOutputStream();
      ObjectOutputStream oos = new ObjectOutputStream(baos);

      oos.writeObject(document);
      oos.flush();
      oos.close();
      byte[] data = baos.toByteArray();

      blob = new Blob(data);
    } catch (IOException e) {
      throw new AppRuntimeException(e);
    }
    return blob;

  }

  /**
   * Converts a DOM document to plain XML text.
   *
   * @param doc
   * The DOM document
   * @return XML text.
   */
  public static String convertDocumentToText(final Document doc) {
    TransformerFactory transfac = TransformerFactory.newInstance();
    Transformer trans;

    try {
      trans = transfac.newTransformer();
    } catch (TransformerConfigurationException e) {
      throw new AppRuntimeException(e);
    }

    trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, CuramConst.gkYes);

    StringWriter sw = new StringWriter();
    StreamResult result = new StreamResult(sw);
    DOMSource source = new DOMSource(doc);

    try {
      trans.transform(source, result);
    } catch (TransformerException e) {
      throw new AppRuntimeException(e);
    }

    String xmlString = sw.toString();

    return xmlString;
  }

  /**
   * Parses XML text to create a DOM document.
   *
   * @param value
   * The XML text to be parsed.
   * @return The DOM document.
   */
  public static Document parseXmlText(final String value) {
    Document xmlDoc = null;

    try {
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      InputSource source = new InputSource();

      source.setCharacterStream(new StringReader(value));

      xmlDoc = documentBuilder.parse(source);

    } catch (SAXException e) {
      throw new AppRuntimeException(e);
    } catch (IOException e) {
      throw new AppRuntimeException(e);
    } catch (ParserConfigurationException e) {
      throw new AppRuntimeException(e);
    }
    return xmlDoc;
  }

  /**
   * Parses XML to create a DOM document.
   *
   * @param inputStream
   * The input stream to be parsed.
   * @return The DOM document.
   */
  public static Document parseXml(final InputStream inputStream) {
    Document xmlDoc = null;

    try {
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

      xmlDoc = documentBuilder.parse(inputStream);

    } catch (SAXException e) {
      throw new AppRuntimeException(e);
    } catch (IOException e) {
      throw new AppRuntimeException(e);
    } catch (ParserConfigurationException e) {
      throw new AppRuntimeException(e);
    }
    return xmlDoc;
  }

  /**
   * Retrieves a child element by name if one exists with the tag name passed
   * in. It returns null if none are found, if more than one are found the first
   * one is returned. Only a single level deep is searched.
   *
   * @param parentElement
   * The parent element.
   * @param tagName
   * The tag name to search for.
   * @return An element matching the tag name, or null if none exists.
   */
  public static Element getChildByName(final Element parentElement,
    final String tagName) {
    return getChildByName(parentElement, tagName, 0);
  }

  /**
   * Retrieves a child element by name if one exists with the tag name passed
   * in. It returns null if none are found. The first element matched is not
   * returned, rather the node at the position specified by the index is
   * returned. Only a single level deep is searched.
   *
   * @param parentElement
   * The parent element.
   * @param tagName
   * The tag name to search for.
   * @param index
   * The index of the tag to be returned, rather than returning the
   * first matching tag. It is zero-based.
   * @return An element matching the tag name, or <code>null</code> if none
   * exists.
   */
  public static Element getChildByName(final Element parentElement,
    final String tagName, final int index) {
    final NodeList nodeList = parentElement.getChildNodes();
    int counter = 0;

    for (int i = 0; i < nodeList.getLength(); i++) {
      if (nodeList.item(i).getNodeName().equals(tagName)) {
        if (counter == index) {
          return (Element) nodeList.item(i);
        }
        counter++;
      }
    }

    return null;
  }

  /**
   * Retrieves one or more direct child elements by name. Only a single level
   * deep is searched.
   *
   * @param parentElement
   * The parent element.
   * @param tagName
   * The tag name to search for.
   * @return An list of elements matching the tag name, or an empty list if none
   * exists.
   */
  public static List<Element> getChildrenByName(final Element parentElement,
    final String tagName) {
    final List<Element> list = new ArrayList<Element>();
    NodeList nodeList = parentElement.getChildNodes();

    for (int i = 0; i < nodeList.getLength(); i++) {
      if (nodeList.item(i).getNodeName().equals(tagName)) {
        list.add((Element) nodeList.item(i));
      }
    }

    return list;
  }

  /**
   * Retrieves a child element by name if one exists with the tag name passed
   * in. It returns null if none are found, if more than one are found the first
   * one is returned.
   *
   * @param parentElement
   * The parent element.
   * @param tagName
   * The tag name to search for.
   * @return An element matching the tag name, or null if none exists.
   */
  public static Element getElementByName(final Element parentElement,
    final String tagName) {
    Element title = null;
    NodeList titleList = parentElement.getElementsByTagName(tagName);

    if (titleList.getLength() > 0) {
      title = (Element) titleList.item(0);
    }
    return title;
  }

  /**
   * Returns the text value of the first child node with the given tag name.
   * Only a single level is searched.
   *
   * @param parentElement
   * The parent node whose child nodes are searched.
   * @param tagName
   * The tag name to search for.
   * @return The text value, or <code>null</code> if the text values isn't
   * found.
   */
  public static String getChildTextValue(final Element parentElement,
    final String tagName) {
    return DomUtils.getTextValue(
      DomUtils.getChildByName(parentElement, tagName));
  }

  /**
   * Retrieves the text value of a node.
   *
   * @param node
   * The node from which to retrieve the text value.
   * @return The string value, or null if not found.
   */
  public static String getTextValue(final Node node) {
    String value = null;

    if (node != null) {
      Node text = node.getLastChild();

      if (text != null) {
        value = text.getNodeValue();
      }
    }
    return value;
  }

  /**
   * Appends a new comment node to the parent node. If the text is
   * <code>null</code>, an empty string will be used instead.
   *
   * @param parentNode
   * The node to which to append the comment.
   * @param text
   * The comment text.
   */
  public static void appendComment(final Node parentNode, final String text) {
    final String commentText = text != null ? text : "";

    parentNode.appendChild(
      parentNode.getOwnerDocument().createComment(commentText));
  }
}
