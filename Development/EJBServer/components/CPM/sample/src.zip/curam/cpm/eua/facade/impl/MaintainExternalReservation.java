/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008,2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.google.inject.Inject;

import curam.codetable.impl.RESERVATIONSTATUSEntry;
import curam.cpm.facade.struct.PlaceLocationDetails;
import curam.cpm.facade.struct.ProviderKey;
import curam.cpm.facade.struct.ReservationKey;
import curam.cpm.facade.struct.ReservationSummaryDetails;
import curam.cpm.facade.struct.ReservationSummaryDetailsList;
import curam.cpm.facade.struct.ReservationViewSummaryDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.PlaceKey;
import curam.cpm.sl.entity.struct.ProviderOfferingIDAndDateTimeKey;
import curam.place.impl.Compartment;
import curam.place.impl.CompartmentDAO;
import curam.place.impl.PlaceDAO;
import curam.provider.impl.ProviderDAO;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.reservation.impl.Reservation;
import curam.reservation.impl.ReservationDAO;
import curam.serviceoffering.impl.UnitOfMeasureEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * Facade class having API's for managing external reservations.
 */
public abstract class MaintainExternalReservation extends curam.cpm.eua.facade.base.MaintainExternalReservation {

  /**
   * Default constructor for guice
   */
  public MaintainExternalReservation() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Place DAO object
   */
  @Inject
  protected PlaceDAO placeDAO;

  /**
   * Compartment DAO object
   */
  @Inject
  protected CompartmentDAO compartmentDAO;

  /**
   * Reservation DAO object
   */
  @Inject
  protected ReservationDAO reservationDAO;

  /**
   * Provider DAO object.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * List all active reservation for provider.
   *
   * @param providerKey
   * Contains providerID
   * @return ReservationSummaryDetailsList contains list of reservation for
   * provider.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReservationSummaryDetailsList listReservations(ProviderKey providerKey)
    throws AppException, InformationalException {
    curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerID);
    ReservationSummaryDetailsList reservationSummaryList = new ReservationSummaryDetailsList();

    for (final curam.providerservice.impl.ProviderOffering providerOffering : provider.getProviderOfferings()) {

      ProviderOfferingIDAndDateTimeKey providerOfferingKey = new ProviderOfferingIDAndDateTimeKey();

      providerOfferingKey.providerOfferingID = providerOffering.getID();

      // Reservation can be done only for service offering of type 'Place'
      // and for approved provider offering.
      if (providerOffering.getServiceOffering().getUnitOfMeasure().equals(
        UnitOfMeasureEntry.PLACE)
          && providerOffering.getLifecycleState().equals(
            ProviderOfferingStatusEntry.APPROVED)) {

        // Retrieve list of active reservation for provider offering.
        List<curam.reservation.impl.Reservation> reservations = reservationDAO.listReservationByProviderOfferingAndStatus(
          providerOffering, RESERVATIONSTATUSEntry.ACTIVE);

        for (final curam.reservation.impl.Reservation reservation : reservations) {
          ReservationSummaryDetails reservationSummary = new ReservationSummaryDetails();

          reservationSummary.clientID = reservation.getClient().getID();
          reservationSummary.clientName = reservation.getClient().getName();
          reservationSummary.from = reservation.getDateTimeRange().start();
          reservationSummary.to = reservation.getDateTimeRange().end();
          if (reservation.getPlace() != null) {
            reservationSummary.placeName = reservation.getPlace().getName();
          }
          reservationSummary.reservationID = reservation.getID();
          reservationSummary.versionNo = reservation.getVersionNo();

          reservationSummaryList.summaryList.addRef(reservationSummary);

        }
      }

    }

    return sortListReservations(reservationSummaryList);

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the reservation details.
   *
   * @param reservationKey
   * Contains Reservation ID.
   * @return ReservationViewSummaryDetails Contains reservation details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReservationViewSummaryDetails viewReservation(
    ReservationKey reservationKey) throws AppException,
      InformationalException {

    Reservation reservation = reservationDAO.get(
      reservationKey.key.reservationID);

    ReservationViewSummaryDetails details = getReservationFields(reservation);

    if (reservation.getLifecycleState().equals(RESERVATIONSTATUSEntry.FULFILLED)) {
      details.isFulfilled = true;
      if (reservation.getPlacement() != null) {
        details.placementID = reservation.getPlacement().getID();
      }
    } else {
      details.isFulfilled = false;
    }

    return details;
  }

  // ___________________________________________________________________________
  /**
   * Sorts a set of Reservations in the ascending order of from date of
   * Reservation
   *
   * @param unsortedReservations
   * The set of unsorted Reservations
   * @return ReservationSummaryDetailsList contains a list of Reservations
   * sorted by from date in Ascending order.
   */

  @SuppressWarnings(CPMConstants.kUnchecked)
  // BEGIN, CR00177241, PM
  protected ReservationSummaryDetailsList sortListReservations(
    ReservationSummaryDetailsList unsortedReservations) {
    // END, CR00177241

    List<ReservationSummaryDetails> ReservationSummaryDetailsList = new ArrayList<ReservationSummaryDetails>();
    int countOfUnsortedReservations = unsortedReservations.summaryList.size();

    for (int i = 0; i < countOfUnsortedReservations; i++) {
      ReservationSummaryDetailsList.add(
        unsortedReservations.summaryList.item(i));
    }

    // Sort the unsorted reservations
    Collections.sort(ReservationSummaryDetailsList,
      new Comparator<ReservationSummaryDetails>() {
      public int compare(final ReservationSummaryDetails lhs,
        ReservationSummaryDetails rhs) {
        return lhs.from.compareTo(rhs.from);
      }
    });

    ReservationSummaryDetailsList ReservationDetailsListSorted = new ReservationSummaryDetailsList();

    ReservationDetailsListSorted.summaryList.addAll(
      ReservationSummaryDetailsList);

    return ReservationDetailsListSorted;
  }

  // ___________________________________________________________________________
  /**
   * Gets the reservation details into the facade struct from the entity object.
   *
   * @param reservation
   * The reservation entity.
   * @return ReservationViewSummaryDetails the facade struct with reservation
   * details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected ReservationViewSummaryDetails getReservationFields(
    Reservation reservation) throws AppException, InformationalException {
    // END, CR00177241

    ReservationViewSummaryDetails details = new ReservationViewSummaryDetails();

    details.clientName = reservation.getClient().getName();
    details.serviceOfferingName = reservation.getProviderOffering().getServiceOffering().getName();
    details.from = reservation.getDateTimeRange().start();
    details.to = reservation.getDateTimeRange().end();
    details.dateOfExpiry = reservation.getExpiryDateTime();
    if (reservation.getPlace() != null) {
      details.placeID = reservation.getPlace().getID();
      details.placeName = reservation.getPlace().getName();
      PlaceKey placeKey = new PlaceKey();

      placeKey.placeID = details.placeID;
      details.placeLocation = getLocationForPlace(placeKey).location;
    }

    details.Status = reservation.getLifecycleState().toString();
    details.comments = reservation.getComments();
    details.reservationID = reservation.getID();
    details.versionNo = reservation.getVersionNo();

    return details;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves location for a specified Place.
   *
   * @param key
   * Contains Place ID.
   * @return PlaceLocationDetails Contains Place location details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public PlaceLocationDetails getLocationForPlace(PlaceKey key)
    throws AppException, InformationalException {
    PlaceLocationDetails locationDetails = new PlaceLocationDetails();
    curam.place.impl.Place place = placeDAO.get(key.placeID);
    Compartment currentCompartment = place.getCompartment();
    Compartment parentCompartment = currentCompartment.getParentCompartment();
    String location = "";

    if (parentCompartment != null) {
      location = buildLocation(parentCompartment, location);
    }
    location += currentCompartment.getName();
    locationDetails.location = location;
    return locationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Gets the location of the compartment and concatenates it.
   *
   * @param parentCompartment
   * Compartment contains parent Compartment ID.
   * @param location
   * Contains the location of the place.
   * @return String location of the place after concatenate all the related
   * locations.
   */
  // BEGIN, CR00177241, PM
  protected String buildLocation(Compartment parentCompartment, String location) {
    // END, CR00177241
    if (parentCompartment != null) {
      Compartment currentCompartment = compartmentDAO.get(
        parentCompartment.getID());

      location = buildLocation(currentCompartment.getParentCompartment(),
        location);
      location += currentCompartment.getName() + CPMConstants.kGreaterThan;
    }
    return location;
  }

}
