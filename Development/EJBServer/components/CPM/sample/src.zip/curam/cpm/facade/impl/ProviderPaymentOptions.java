/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import com.google.inject.Inject;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.PaymentOptionsDetails;
import curam.cpm.facade.struct.PaymentOptionsDetailsList;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.struct.OfferingKey;
import curam.cpm.sl.struct.PaymentOptionsDtls;
import curam.cpm.sl.struct.PaymentOptionsKey;
import curam.provider.impl.PaymentOptions;
import curam.provider.impl.PaymentOptionsDAO;
import curam.provider.impl.ProviderDAO;
import curam.serviceoffering.impl.FixedAmountPaymentOptionEntry;
import curam.serviceoffering.impl.MaximumAmountPaymentOptionEntry;
import curam.serviceoffering.impl.MinimumAmountPaymentOptionEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.DateRange;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;


/**
 * {@inheritDoc}
 */
public abstract class ProviderPaymentOptions extends curam.cpm.facade.base.ProviderPaymentOptions {

  /**
   * PaymentOptions DAO object.
   */
  @Inject
  protected PaymentOptionsDAO paymentOptionsDAO;

  /**
   * Provider DAO object.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Constructor for the class
   */
  public ProviderPaymentOptions() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00313834, GA
  /**
   * Cancels the payment options for a Provider.
   *
   * @param keyVersionDetails
   * Contains the key and version ID.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0.3.0, replaced by {@link ProviderPaymentOptions#removeProviderPaymentOption()}.
   * This method is deprecated because the name of the method does not match its functionality and conveys a wrong 
   * meaning. It performs a hard delete operation, but the method name is cancelProviderPaymentOption() which 
   * looks like logical delete operation. See release note : CR00313834.
   */
  public void cancelProviderPaymentOption(KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    // Getting the instance from persistence layer
    final PaymentOptions paymentOptions = paymentOptionsDAO.get(
      keyVersionDetails.id);

    paymentOptions.remove(keyVersionDetails.version);

  }

  // END, CR00313834
  
  /**
   * {@inheritDoc}
   */
  public void removeProviderPaymentOption(final KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    // Getting the instance from persistence layer.
    final PaymentOptions paymentOptions = paymentOptionsDAO.get(
      keyVersionDetails.id);

    paymentOptions.remove(keyVersionDetails.version);

  }

  /**
   * {@inheritDoc}
   */
  public void updateProviderPaymentOptions(
    PaymentOptionsDetails paymentOptionsDetails) throws AppException,
      InformationalException {

    // Getting the instance from persistence layer
    final PaymentOptions paymentOptions = paymentOptionsDAO.get(
      paymentOptionsDetails.paymentOptionDtls.paymentOptionID);

    final PaymentOptionsDtls paymentOptionsDtls = new PaymentOptionsDtls();

    paymentOptionsDtls.startDate = paymentOptions.getDateRange().start();
    paymentOptionsDtls.endDate = paymentOptions.getDateRange().end();
    paymentOptionsDtls.fixedAmtPayOption = paymentOptions.getFixedAmountPaymentOption().getCode();
    paymentOptionsDtls.maxAmtPayOption = paymentOptions.getMaxAmountPaymentOption().getCode();
    paymentOptionsDtls.minAmtPayOption = paymentOptions.getMinAmountPaymentOption().getCode();

    // Setting the payment options value from the user entered details
    setPaymentOptionsField(paymentOptions, paymentOptionsDetails);

    // Modifying the payment options
    paymentOptions.modify(paymentOptionsDetails.paymentOptionDtls.versionNo);

  }

  /**
   * {@inheritDoc}
   */
  public PaymentOptionsKey createProviderPaymentOptions(
    PaymentOptionsDetails paymentOptionsDetails) throws AppException,
      InformationalException {

    // Creating instance for payment options
    final PaymentOptions paymentOptions = paymentOptionsDAO.newInstance();

    // Setting the payment options value from the user entered details
    setPaymentOptionsField(paymentOptions, paymentOptionsDetails);

    // Inserting the payment options
    paymentOptions.insert();

    // Setting the key value
    PaymentOptionsKey paymentOptionsKey = new PaymentOptionsKey();

    paymentOptionsKey.paymentOptionID = paymentOptions.getID();

    // Returning the key
    return paymentOptionsKey;
  }

  /**
   * {@inheritDoc}
   */
  public PaymentOptionsDetailsList listProviderPaymentOptions(
    ProviderConcernRoleKey key) throws AppException, InformationalException {
    PaymentOptionsDetailsList paymentOptionsDetailsList = new PaymentOptionsDetailsList();

    // Creating the key for search option
    OfferingKey offeringKey = new OfferingKey();

    offeringKey.providerSOID = key.providerConcernRoleID;

    PaymentOptionsDtls paymentOptionsDtls;

    // Getting the payment options for service offering and iterating through
    // that
    for (PaymentOptions paymentOptions : sortPaymentOptions(
      paymentOptionsDAO.searchBy(offeringKey))) {

      paymentOptionsDtls = new PaymentOptionsDtls();

      // Setting the values to dtls struct
      setPaymentOptionsDtls(paymentOptionsDtls, paymentOptions);

      // Adding to the list
      paymentOptionsDetailsList.paymentOptionDtls.addRef(paymentOptionsDtls);

    }

    // Returning the list
    return paymentOptionsDetailsList;
  }

  /**
   * This method is used to set the fields of PaymentOptions while creation and
   * modification
   *
   * @param paymentOptions -
   * instance to be inserted or modified
   * @param paymentOptionsDetails -
   * contains the user entered data
   */
  // BEGIN, CR00177241, PM
  protected void setPaymentOptionsField(PaymentOptions paymentOptions,
    // END, CR00177241
    PaymentOptionsDetails paymentOptionsDetails) {

    // Setting the payment options value
    paymentOptions.setFixedAmountPaymentOption(
      FixedAmountPaymentOptionEntry.get(
        paymentOptionsDetails.paymentOptionDtls.fixedAmtPayOption));
    paymentOptions.setMinimumAmountPaymentOption(
      MinimumAmountPaymentOptionEntry.get(
        paymentOptionsDetails.paymentOptionDtls.minAmtPayOption));
    paymentOptions.setMaximumAmountPaymentOption(
      MaximumAmountPaymentOptionEntry.get(
        paymentOptionsDetails.paymentOptionDtls.maxAmtPayOption));

    DateRange dateRange = new DateRange(
      paymentOptionsDetails.paymentOptionDtls.startDate,
      paymentOptionsDetails.paymentOptionDtls.endDate);

    paymentOptions.setDateRange(dateRange);

    // Setting the provider details(ID)
    final curam.provider.impl.Provider provider = providerDAO.get(
      paymentOptionsDetails.paymentOptionDtls.providerSOID);

    paymentOptions.setProvider(provider);

  }

  /**
   * This method is used to set the facade layer struct with the persistence
   * layer instance
   *
   * @param paymentOptionsDtls -
   * PaymentOptionsDtls
   * @param paymentOptions -
   * PaymentOptions
   */
  // BEGIN, CR00177241, PM
  protected void setPaymentOptionsDtls(PaymentOptionsDtls paymentOptionsDtls,
    // END, CR00177241
    PaymentOptions paymentOptions) {

    paymentOptionsDtls.fixedAmtPayOption = paymentOptions.getFixedAmountPaymentOption().getCode();
    paymentOptionsDtls.minAmtPayOption = paymentOptions.getMinAmountPaymentOption().getCode();
    paymentOptionsDtls.maxAmtPayOption = paymentOptions.getMaxAmountPaymentOption().getCode();
    paymentOptionsDtls.startDate = paymentOptions.getDateRange().start();
    paymentOptionsDtls.endDate = paymentOptions.getDateRange().end();
    paymentOptionsDtls.paymentOptionID = paymentOptions.getID();
    paymentOptionsDtls.providerSOID = paymentOptions.getProvider().getID();
    paymentOptionsDtls.versionNo = paymentOptions.getVersionNo();

  }

  /**
   * {@inheritDoc}
   */
  public PaymentOptionsDetails viewPaymentOptions(
    PaymentOptionsKey paymentOptionsKey) throws AppException,
      InformationalException {

    PaymentOptionsDetails paymentOptionsDetails = new PaymentOptionsDetails();

    // Getting the instance from persistence layer
    final PaymentOptions paymentOptions = paymentOptionsDAO.get(
      paymentOptionsKey.paymentOptionID);

    // Setting the values to the facade struct
    paymentOptionsDetails.paymentOptionDtls.fixedAmtPayOption = paymentOptions.getFixedAmountPaymentOption().getCode();
    paymentOptionsDetails.paymentOptionDtls.minAmtPayOption = paymentOptions.getMinAmountPaymentOption().getCode();
    paymentOptionsDetails.paymentOptionDtls.maxAmtPayOption = paymentOptions.getMaxAmountPaymentOption().getCode();
    paymentOptionsDetails.paymentOptionDtls.startDate = paymentOptions.getDateRange().start();
    paymentOptionsDetails.paymentOptionDtls.endDate = paymentOptions.getDateRange().end();
    paymentOptionsDetails.paymentOptionDtls.paymentOptionID = paymentOptions.getID();
    paymentOptionsDetails.paymentOptionDtls.providerSOID = paymentOptions.getProvider().getID();
    paymentOptionsDetails.paymentOptionDtls.versionNo = paymentOptions.getVersionNo();

    // Returning the struct
    return paymentOptionsDetails;
  }

  /**
   * Sorts a set of payment options into a sorted list.
   *
   * @param unsortedPaymentOptions
   * the set of payment options
   * @return a sorted list of payment options for display.
   */
  // BEGIN, CR00177241, PM
  protected List<PaymentOptions> sortPaymentOptions(
    // END, CR00177241
    final Set<PaymentOptions> unsortedPaymentOptions) {

    /*
     * Sort by startDate for display
     */
    final List<PaymentOptions> paymentOptions = new ArrayList<PaymentOptions>(
      unsortedPaymentOptions);

    Collections.sort(paymentOptions,
      new Comparator<PaymentOptions>() {
      public int compare(final PaymentOptions lhs, PaymentOptions rhs) {
        return lhs.getDateRange().start().compareTo(rhs.getDateRange().start());
      }
    });
    return paymentOptions;
  }

}
