/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.google.inject.Inject;

import curam.attendance.impl.ProviderRosterLineItem;
import curam.attendance.impl.ProviderRosterLineItemDAO;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.FINANCIALINSTRUCTION;
import curam.codetable.ILISTATUS;
import curam.codetable.ILITYPE;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.ILISTATUSEntry;
import curam.codetable.impl.ILITYPEEntry;
import curam.codetable.impl.NOMINEERELATIONSHIPEntry;
import curam.codetable.impl.PRODUCTDELIVERYCATEGORYEntry;
import curam.codetable.impl.PRODUCTTYPEEntry;
import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.ContractVersionDAO;
import curam.contracts.impl.ContractVersionProviderOffering;
import curam.contracts.impl.ContractVersionProviderOfferingDAO;
import curam.contracts.impl.FlatRateContract;
import curam.contracts.impl.FlatRateContractDAO;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.intf.Participant;
import curam.core.facade.struct.ListParticipantFinancials;
import curam.core.facade.struct.ListParticipantFinancials1;
import curam.core.facade.struct.ListParticipantFinancialsKey;
import curam.core.facade.struct.ParticipantFinancials;
import curam.core.facade.struct.ParticipantFinancials1;
import curam.core.fact.CaseDecisionFinancialCompFactory;
import curam.core.fact.CaseDecisionObjectiveFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseRelationshipFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.MaintainProductDeliveryFactory;
import curam.core.fact.PaymentInstructionFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.ProductDeliveryPatternFactory;
import curam.core.fact.ProductDeliveryPatternInfoFactory;
import curam.core.fact.ProductFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseDecisionFinancialComp;
import curam.core.intf.CaseDecisionObjective;
import curam.core.intf.CaseHeader;
import curam.core.intf.CaseRelationship;
import curam.core.intf.ConcernRole;
import curam.core.intf.InstructionLineItem;
import curam.core.intf.MaintainProductDelivery;
import curam.core.intf.PaymentInstruction;
import curam.core.intf.Product;
import curam.core.intf.ProductDelivery;
import curam.core.intf.ProductDeliveryPattern;
import curam.core.intf.ProductDeliveryPatternInfo;
import curam.core.sl.entity.fact.CaseNomineeFactory;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseNominee;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseIDAndFromDateDtls;
import curam.core.sl.entity.struct.CaseNomineeCaseIDKey;
import curam.core.sl.entity.struct.CaseNomineeForCaseDetails;
import curam.core.sl.entity.struct.CaseNomineeForCaseDetailsList;
import curam.core.sl.entity.struct.CaseNomineeKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.ReadByParticipantRoleIDTypeDetails;
import curam.core.sl.entity.struct.ReadByParticipantRoleIDTypeKey;
import curam.core.struct.CaseAndConcernRoleKey;
import curam.core.struct.CaseDecisionFinancialCompDtls;
import curam.core.struct.CaseDecisionObjectiveDtls;
import curam.core.struct.CaseDecisionObjectiveDtlsList;
import curam.core.struct.CaseDecisionObjectiveKey;
import curam.core.struct.CaseHomePageNameAndType;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseRelationshipCaseIDKey;
import curam.core.struct.CaseRelationshipDtls;
import curam.core.struct.CaseRelationshipDtlsList;
import curam.core.struct.CaseRelationshipRelatedCaseIDKey;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.FinInstructionID;
import curam.core.struct.FinInstructionIDConcernRoleID;
import curam.core.struct.FinInstructionIDConcernRoleIDList;
import curam.core.struct.FinancialCompIDKey;
import curam.core.struct.ILIEffectiveDate;
import curam.core.struct.ILIFinInstructID;
import curam.core.struct.InstructionLineItemDtls;
import curam.core.struct.InstructionLineItemDtlsList;
import curam.core.struct.InstructionLineItemKey;
import curam.core.struct.PaymentInstrumentDtls;
import curam.core.struct.PaymentInstrumentDtlsList;
import curam.core.struct.PaymentInstrumentKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryDtlsList;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryPatternDtls;
import curam.core.struct.ProductDeliveryPatternInfoDtls;
import curam.core.struct.ProductDeliveryTypeClientIDIn;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductTypeCodeIn;
import curam.core.struct.StatusFinInstructID;
import curam.core.struct.UpdateProductDeliveryPatternKey;
import curam.cpm.facade.fact.ServiceInvoiceFactory;
import curam.cpm.facade.struct.PlacementFrequencyDetails;
import curam.cpm.facade.struct.PlacementFrequencyDetailsList;
import curam.cpm.facade.struct.ProviderFinancialInstructionDetail;
import curam.cpm.facade.struct.ProviderFinancialInstructionDetails;
import curam.cpm.facade.struct.RetrieveContractDetails;
import curam.cpm.facade.struct.RetrieveContractDetailsList;
import curam.cpm.facade.struct.RetrievePaymentHistoryDetails;
import curam.cpm.facade.struct.RetrievePaymentHistoryDetailsList;
import curam.cpm.facade.struct.ServiceInvoiceDetails;
import curam.cpm.facade.struct.ServiceInvoiceLineItemDetails;
import curam.cpm.facade.struct.ViewAttendancePaymentDetails;
import curam.cpm.facade.struct.ViewAttendancePaymentHistoryDetails;
import curam.cpm.facade.struct.ViewContractPaymentDetails;
import curam.cpm.facade.struct.ViewFinancialTransactionDetail;
import curam.cpm.facade.struct.ViewFinancialTransactionDetailKey;
import curam.cpm.facade.struct.ViewFinancialTransactionDetails;
import curam.cpm.facade.struct.ViewFinancialTransactionKey;
import curam.cpm.facade.struct.ViewPaymentHistoryDetails;
import curam.cpm.facade.struct.ViewPlacementPaymentDetails;
import curam.cpm.facade.struct.ViewSILIPaymentDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.fact.ProviderFactory;
import curam.cpm.sl.entity.struct.ContractVersionKey;
import curam.cpm.sl.entity.struct.FinancialInstructionDetail;
import curam.cpm.sl.entity.struct.FinancialInstructionDetailList;
import curam.cpm.sl.entity.struct.PlacementKey;
import curam.cpm.sl.entity.struct.ProviderFinancialDetail;
import curam.cpm.sl.entity.struct.ProviderFinancialDetailList;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ProviderRosterLineItemKey;
import curam.cpm.sl.entity.struct.SearchByFIAndILITypeKey;
import curam.cpm.sl.entity.struct.ServiceInvoiceKey;
import curam.cpm.sl.entity.struct.ServiceInvoiceLineItemKey;
import curam.financial.impl.PlacementPaymentCoverPattern;
import curam.financial.impl.PlacementPaymentFrequency;
import curam.financial.impl.PlacementPaymentFrequencyDAO;
import curam.financial.impl.PlacementPaymentPatternInfoOffset;
import curam.financial.impl.ServiceInvoiceLineItem;
import curam.financial.impl.ServiceInvoiceLineItemDAO;
import curam.message.impl.PLACEMENTExceptionCreator;
import curam.place.impl.Compartment;
import curam.place.impl.CompartmentDAO;
import curam.place.impl.Place;
import curam.place.impl.PlaceDAO;
import curam.place.impl.Placement;
import curam.place.impl.PlacementDAO;
import curam.provider.PAYMENTTYPES;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderGroupAssociateDAO;
import curam.provider.impl.ProviderGroupDAO;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItem;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.Money;
import curam.util.type.StringHelper;
import curam.util.type.UniqueID;


/**
 * {@inheritDoc}
 */
public abstract class ProviderFinancial extends curam.cpm.facade.base.ProviderFinancial {

  /**
   * Injecting the Data Access Object for ServiceInvoiceLineItem class
   */
  // BEGIN, CR00229264, VR
  @Inject
  protected FlatRateContractDAO flatRateContractDAO;

  // END, CR00229264
  /**
   * Injecting the Data Access Object for Compartment class
   */
  @Inject
  protected CompartmentDAO compartmentDAO;

  /**
   * Injecting the Data Access Object for ContractVersionProviderOffering class
   */
  @Inject
  protected ContractVersionProviderOfferingDAO contractProviderOfferingLinkDAO;

  /**
   * Injecting the Data Access Object for ContractVersion class
   */
  @Inject
  protected ContractVersionDAO contractVersionDAO;

  /**
   * Injecting the Data Access Object for Place class
   */
  @Inject
  protected PlaceDAO placeDAO;

  /**
   * Injecting the Data Access Object for Placement class
   */
  @Inject
  protected PlacementDAO placementDAO;

  /**
   * Injecting the Data Access Object for PlacementPaymentFrequency class
   */
  @Inject
  protected PlacementPaymentFrequencyDAO placementPaymentFrequencyDAO;

  /**
   * Injecting the Data Access Object for Provider class
   */
  @Inject
  protected ProviderDAO providerDAO;

  // BEGIN, CR00186917, SG
  // BEGIN, CR00186978, SG
  /**
   * Reference to provider group associate DAO.
   */
  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;

  /**
   * Reference to provider group DAO.
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  // END, CR00186978
  // END, CR00186917

  /**
   * Injecting the Data Access Object for ProviderOrganization class
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Injecting the Data Access Object for Provider roster line item class
   */
  @Inject
  protected ProviderRosterLineItemDAO providerRosterLineItemDAO;

  /**
   * Injecting the Data Access Object for ServiceInvoiceLineItem class
   */
  @Inject
  protected ServiceInvoiceLineItemDAO serviceInvoiceLineItemDAO;

  // BEGIN, CR00304532, GP
  /**
   * Reference to placement payment cover pattern.
   */
  @Inject
  protected PlacementPaymentCoverPattern placementPaymentCoverPattern;

  /**
   * Reference to placement payment pattern info offset.
   */
  @Inject
  protected PlacementPaymentPatternInfoOffset placementPaymentPatternInfoOffset;

  // END, CR00304532
  
  /**
   * Constructor for the class.
   */
  public ProviderFinancial() {

    // Bootstrap dependency injection for this class.
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * This method is used to create new placement frequency
   *
   * @param details
   * placement frequency details
   * @throws AppException
   * @throws InformationalException
   */
  public void createPlacementPaymentFrequency(PlacementFrequencyDetails details)
    throws AppException, InformationalException {

    // Create the new placement frequency and re-assess the existing providers
    PlacementPaymentFrequency placementPaymentFrequency = placementPaymentFrequencyDAO.newInstance();

    placementPaymentFrequency.setEffectiveDate(details.effectiveDate);
    placementPaymentFrequency.setFrequencyPattern(details.frequencyPattern);
    placementPaymentFrequency.insert();

    reAssessExistingProvidersForNewFrequency(details);
  }

  // BEGIN, CR00114790, GP
  /**
   * {@inheritDoc}
   */
  public RetrievePaymentHistoryDetailsList listAttendancePaymentTypeForProvider(
    PaymentInstrumentKey key) throws AppException, InformationalException {

    RetrievePaymentHistoryDetailsList retrievePaymentHistoryDetailsList = new RetrievePaymentHistoryDetailsList();

    // Get the payment instructions for a payment instrument
    PaymentInstruction paymentInstruction = PaymentInstructionFactory.newInstance();
    FinInstructionIDConcernRoleIDList finInstructionIDConcernRoleIDList = paymentInstruction.searchByPmtInstrumentID(
      key);

    int finInstructionSize = finInstructionIDConcernRoleIDList.dtls.size();

    for (int j = 0; j < finInstructionSize; j++) {

      FinInstructionIDConcernRoleID finInstructionIDConcernRoleID = finInstructionIDConcernRoleIDList.dtls.item(
        j);

      InstructionLineItem instructionLineItem = InstructionLineItemFactory.newInstance();
      StatusFinInstructID statusFinInstructID = new StatusFinInstructID();

      statusFinInstructID.finInstructionID = finInstructionIDConcernRoleID.finInstructionID;
      statusFinInstructID.statusCode = ILISTATUS.PROCESSED;
      InstructionLineItemDtlsList instructionLineItemDtlsList = instructionLineItem.searchByFinInstructStatus(
        statusFinInstructID);

      int size = instructionLineItemDtlsList.dtls.size();

      for (int i = 0; i < size; i++) {
        InstructionLineItemDtls instructionLineItemDtls = instructionLineItemDtlsList.dtls.item(
          i);

        // BEGIN, CR00153581, GP
        // BEGIN, CR00113395, GP
        if (ILITYPEEntry.ATTENDANCEPAYMENT.getCode().equals(
          instructionLineItemDtls.instructionLineItemType)) {
          // END, CR00113395
          // END, CR00153581

          curam.cpm.sl.entity.intf.Provider provider = ProviderFactory.newInstance();

          FinancialCompIDKey financialCompIdKey = new FinancialCompIDKey();

          financialCompIdKey.financialCompID = instructionLineItemDtls.financialCompID;

          CaseDecisionObjectiveDtlsList caseDecisionObjectiveDtlsList = provider.searchRelatedReferenceByILI(
            financialCompIdKey);

          RetrievePaymentHistoryDetails retrievePaymentHistoryDetails = new RetrievePaymentHistoryDetails();

          if (caseDecisionObjectiveDtlsList.dtls.size() > 0) {

            String relatedReference = caseDecisionObjectiveDtlsList.dtls.item(0).relatedReference;

            if (!GeneralConstants.kEmpty.equals(relatedReference)) {

              long providerRosterLineItemID = Long.valueOf(relatedReference);

              ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
                providerRosterLineItemID);

              retrievePaymentHistoryDetails.clientName = getClientNameFromProviderRosterLineItem(
                providerRosterLineItem);
              retrievePaymentHistoryDetails.serviceName = providerRosterLineItem.getRoster().getServiceOffering().getName();
              retrievePaymentHistoryDetails.serviceFrom = providerRosterLineItem.getServiceDateFrom();
              retrievePaymentHistoryDetails.serviceTo = providerRosterLineItem.getServiceDateTo();
              retrievePaymentHistoryDetails.providerRosterLineItemID = providerRosterLineItem.getID();

              // BEGIN, CR00113395, GP
              retrievePaymentHistoryDetails.relatedReference = providerRosterLineItem.getID();
              // END, CR00113395

            }
          }
          // BEGIN, CR00127671, GP

          retrievePaymentHistoryDetails.amount = instructionLineItemDtls.amount;

          // END, CR00127671
          retrievePaymentHistoryDetails.instructionLineItemID = instructionLineItemDtls.instructLineItemID;
          retrievePaymentHistoryDetails.finInstructionID = instructionLineItemDtls.finInstructionID;

          // BEGIN, CR00113395, GP
          retrievePaymentHistoryDetails.instructionLineItemType = instructionLineItemDtls.instructionLineItemType;
          // END, CR00113395

          retrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
            retrievePaymentHistoryDetails);
        }
      }
    }

    return retrievePaymentHistoryDetailsList;
  }

  // END, CR00114790

  // BEGIN, CR00228239, VR
  /**
   * {@inheritDoc}
   */
  public ProviderFinancialInstructionDetails listFinancialTransactions(
    final ProviderKey providerKey) throws AppException,
      InformationalException {
    ProviderFinancialInstructionDetails details = new ProviderFinancialInstructionDetails();
    ProviderFinancialDetailList financialDetailList = providerDAO.searchFinancialsByConcernRole(
      providerKey.providerConcernRoleID);
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();

    for (ProviderFinancialDetail financialDetail : financialDetailList.dtls.items()) {
      ProviderFinancialInstructionDetail instructionDetail = new ProviderFinancialInstructionDetail();
      StatusFinInstructID statusFinInstructID = new StatusFinInstructID();

      statusFinInstructID.finInstructionID = financialDetail.finInstructionID;
      statusFinInstructID.statusCode = ILISTATUS.PROCESSED;
      InstructionLineItemDtlsList instructionLineItemDtlsList = instructionLineItemObj.searchByFinInstructStatus(
        statusFinInstructID);
      
      // BEGIN, CR00311723, MR
      if (!instructionLineItemDtlsList.dtls.isEmpty()) {
        instructionDetail.amount = financialDetail.amount;
        instructionDetail.caseNomineeID = financialDetail.caseNomineeID;
        instructionDetail.concernRoleID = financialDetail.concernRoleID;
        instructionDetail.typeCode = financialDetail.typeCode;
        instructionDetail.dueDate = instructionLineItemDtlsList.dtls.item(0).dueDate;
        instructionDetail.instructionLineItemType = instructionLineItemDtlsList.dtls.item(0).instructionLineItemType;
        instructionDetail.finInstructionID = financialDetail.finInstructionID;
        instructionDetail.deliveryMethodType = financialDetail.deliveryMethodType;
        details.dtls.addRef(instructionDetail);
      }
      // END, CR00311723

    }

    ProviderFinancialDetailList liabiltiesList = providerDAO.searchLiabilitiesByConcernRole(
      providerKey.providerConcernRoleID);

    for (ProviderFinancialDetail financialDetail : liabiltiesList.dtls.items()) {
      
      StatusFinInstructID statusFinInstructID = new StatusFinInstructID();

      statusFinInstructID.finInstructionID = financialDetail.finInstructionID;
      statusFinInstructID.statusCode = ILISTATUS.PROCESSED;
      
      // BEGIN, CR00311723, MR

      // List all processed liability instruction line items.
      InstructionLineItemDtlsList instructionLineItemDtlsList = new InstructionLineItemDtlsList();

      instructionLineItemDtlsList = instructionLineItemObj.searchByFinInstructStatus(
        statusFinInstructID);
      if (!instructionLineItemDtlsList.dtls.isEmpty()) {
        final ProviderFinancialInstructionDetail providerFinancialInstructionDetail = new ProviderFinancialInstructionDetail();

        providerFinancialInstructionDetail.amount = financialDetail.amount;
        providerFinancialInstructionDetail.caseNomineeID = financialDetail.caseNomineeID;
        providerFinancialInstructionDetail.concernRoleID = financialDetail.concernRoleID;
        providerFinancialInstructionDetail.typeCode = financialDetail.typeCode;
        providerFinancialInstructionDetail.dueDate = instructionLineItemDtlsList.dtls.item(0).dueDate;
        providerFinancialInstructionDetail.instructionLineItemType = instructionLineItemDtlsList.dtls.item(0).instructionLineItemType;
        providerFinancialInstructionDetail.finInstructionID = financialDetail.finInstructionID;
        providerFinancialInstructionDetail.deliveryMethodType = instructionLineItemDtlsList.dtls.item(0).deliveryMethodType;
        details.dtls.addRef(providerFinancialInstructionDetail);
      }

      // List all allocated liability instruction line items.
      statusFinInstructID.statusCode = ILISTATUS.ALLOCATED;
      instructionLineItemDtlsList = instructionLineItemObj.searchByFinInstructStatus(
        statusFinInstructID);

      if (!instructionLineItemDtlsList.dtls.isEmpty()) {
        final ProviderFinancialInstructionDetail providerFinancialInstructionDetail = new ProviderFinancialInstructionDetail();

        providerFinancialInstructionDetail.amount = financialDetail.amount;
        providerFinancialInstructionDetail.caseNomineeID = financialDetail.caseNomineeID;
        providerFinancialInstructionDetail.concernRoleID = financialDetail.concernRoleID;
        providerFinancialInstructionDetail.typeCode = financialDetail.typeCode;
        providerFinancialInstructionDetail.dueDate = instructionLineItemDtlsList.dtls.item(0).dueDate;
        providerFinancialInstructionDetail.instructionLineItemType = instructionLineItemDtlsList.dtls.item(0).instructionLineItemType;
        providerFinancialInstructionDetail.finInstructionID = financialDetail.finInstructionID;
        providerFinancialInstructionDetail.deliveryMethodType = instructionLineItemDtlsList.dtls.item(0).deliveryMethodType;
        details.dtls.addRef(providerFinancialInstructionDetail);
      }

      // END, CR00311723
    }
	
    // BEGIN, CR00386728, RPB
    // If the transactions are for deduction, they have to be retrieved
    // based on the transactions for the provider as a participant.
    if (0 == details.dtls.size()) {
      Participant participant = ParticipantFactory.newInstance();
      ListParticipantFinancialsKey listParticipantFinancialsKey = new ListParticipantFinancialsKey();

      listParticipantFinancialsKey.concernRoleID = providerKey.providerConcernRoleID;
      ListParticipantFinancials1 listParticipantFinancials1 = participant.listParticipantFinancial1(
        listParticipantFinancialsKey);

      for (final ParticipantFinancials1 participantFinancials1 : listParticipantFinancials1.participantFinancialsList.dtls.items()) {
        final ProviderFinancialInstructionDetail providerFinancialInstructionDetail = new ProviderFinancialInstructionDetail();

        providerFinancialInstructionDetail.amount = participantFinancials1.amount;
        providerFinancialInstructionDetail.typeCode = participantFinancials1.typeCode;
        providerFinancialInstructionDetail.deliveryMethodType = participantFinancials1.deliveryMethodType;
        providerFinancialInstructionDetail.dueDate = participantFinancials1.dueDate;
        providerFinancialInstructionDetail.finInstructionID = participantFinancials1.finInstructionID;
        providerFinancialInstructionDetail.instructionLineItemType = participantFinancials1.instructionLineItemType;
        details.dtls.addRef(providerFinancialInstructionDetail);
      }
    }
    // END, CR00386728

    return details;
  }

  // END, CR00228239
  
  /**
   * {@inheritDoc}
   */
  public RetrieveContractDetailsList listFRCPaymentTypeForProvider(
    PaymentInstrumentKey key) throws AppException, InformationalException {

    RetrieveContractDetailsList retrieveContractDetailsList = new RetrieveContractDetailsList();

    PaymentInstruction paymentInstruction = PaymentInstructionFactory.newInstance();

    FinInstructionIDConcernRoleIDList finInstructionIDConcernRoleIDList = paymentInstruction.searchByPmtInstrumentID(
      key);

    int finInstructionSize = finInstructionIDConcernRoleIDList.dtls.size();

    for (int j = 0; j < finInstructionSize; j++) {

      FinInstructionIDConcernRoleID finInstructionIDConcernRoleID = finInstructionIDConcernRoleIDList.dtls.item(
        j);
      InstructionLineItem instructionLineItem = InstructionLineItemFactory.newInstance();
      StatusFinInstructID statusFinInstructID = new StatusFinInstructID();

      statusFinInstructID.finInstructionID = finInstructionIDConcernRoleID.finInstructionID;
      statusFinInstructID.statusCode = ILISTATUS.PROCESSED;
      InstructionLineItemDtlsList instructionLineItemDtlsList = instructionLineItem.searchByFinInstructStatus(
        statusFinInstructID);

      int size = instructionLineItemDtlsList.dtls.size();

      for (int i = 0; i < size; i++) {

        InstructionLineItemDtls instructionLineItemDtls = instructionLineItemDtlsList.dtls.item(
          i);

        // BEGIN, CR00153581, GP
        // BEGIN, CR00113395, GP
        if (ILITYPEEntry.CONTRACTPAYMENT.getCode().equals(
          instructionLineItemDtls.instructionLineItemType)) {
          // END, CR00113395
          // END, CR00153581

          curam.cpm.sl.entity.intf.Provider provider = ProviderFactory.newInstance();

          FinancialCompIDKey financialCompIdKey = new FinancialCompIDKey();

          financialCompIdKey.financialCompID = instructionLineItemDtls.financialCompID;

          CaseDecisionObjectiveDtlsList caseDecisionObjectiveDtlsList = provider.searchRelatedReferenceByILI(
            financialCompIdKey);

          RetrieveContractDetails retrieveContractDetails = new RetrieveContractDetails();

          if (caseDecisionObjectiveDtlsList.dtls.size() > 0) {

            String relatedReference = caseDecisionObjectiveDtlsList.dtls.item(0).relatedReference;

            if (!GeneralConstants.kEmpty.equals(relatedReference)) {

              long contractVersionID = Long.valueOf(relatedReference);

              ContractVersion contractVersion = contractVersionDAO.get(
                contractVersionID);

              retrieveContractDetails.contractVersionID = contractVersion.getID();
              // BEGIN, CR00127671, GP
              retrieveContractDetails.amount = instructionLineItemDtls.amount;

              retrieveContractDetails.contractName = contractVersion.getName();

              // BEGIN, CR00153581, GP
              retrieveContractDetails.contractStartDate = instructionLineItemDtls.coverPeriodFrom;
              retrieveContractDetails.contractEndDate = instructionLineItemDtls.coverPeriodTo;
              // END, CR00153581

              retrieveContractDetails.creationDate = instructionLineItemDtls.creationDate;
              retrieveContractDetails.instructionLineItemID = instructionLineItemDtls.instructLineItemID;
              retrieveContractDetails.finInstructionID = instructionLineItemDtls.finInstructionID;
            } else {

              retrieveContractDetails.amount = instructionLineItemDtls.amount;

              // BEGIN, CR00148759, GP
              retrieveContractDetails.contractStartDate = instructionLineItemDtls.coverPeriodFrom;
              retrieveContractDetails.contractEndDate = instructionLineItemDtls.coverPeriodTo;
              // END, CR00148759

              retrieveContractDetails.creationDate = instructionLineItemDtls.creationDate;
              retrieveContractDetails.instructionLineItemID = instructionLineItemDtls.instructLineItemID;
              retrieveContractDetails.finInstructionID = instructionLineItemDtls.finInstructionID;
            }

          } else {

            retrieveContractDetails.amount = instructionLineItemDtls.amount;

            // BEGIN, CR00148759, GP
            retrieveContractDetails.contractStartDate = instructionLineItemDtls.coverPeriodFrom;
            retrieveContractDetails.contractEndDate = instructionLineItemDtls.coverPeriodTo;
            // END, CR00148759

            // END, CR00127671
            retrieveContractDetails.creationDate = instructionLineItemDtls.creationDate;
            retrieveContractDetails.instructionLineItemID = instructionLineItemDtls.instructLineItemID;
            retrieveContractDetails.finInstructionID = instructionLineItemDtls.finInstructionID;
          }

          // BEGIN, CR00113395, GP
          retrieveContractDetails.instructionLineItemType = instructionLineItemDtls.instructionLineItemType;
          // END, CR00113395

          retrieveContractDetailsList.contractDetails.addRef(
            retrieveContractDetails);
        }
      }
    }

    return retrieveContractDetailsList;
  }

  // END, CR00113395

  // BEGIN, CR00113395, GP
  /**
   * {@inheritDoc}
   */
  public RetrievePaymentHistoryDetailsList listILIPaymentDetailsForProvider(
    PaymentInstrumentKey paymentInstrumentKey) throws AppException,
      InformationalException {

    RetrievePaymentHistoryDetailsList retrievePaymentHistoryDetailsList = new RetrievePaymentHistoryDetailsList();

    RetrievePaymentHistoryDetailsList retrieveInvoicePaymentHistoryDetailsList = listSIPaymentTypeForProvider(
      paymentInstrumentKey);

    for (RetrievePaymentHistoryDetails retrieveInvoicePaymentHistoryDetails : retrieveInvoicePaymentHistoryDetailsList.paymentHistoryDetails.items()) {

      if (ILITYPEEntry.INVOICEPAYMENT.getCode().equals(
        retrieveInvoicePaymentHistoryDetails.instructionLineItemType)) {
        retrieveInvoicePaymentHistoryDetails.paymentType = PRODUCTTYPEEntry.PROVIDERINVOICE.getCode();
      } else if (ILITYPEEntry.BENEFITUNDERPAYMENT.getCode().equals(
        retrieveInvoicePaymentHistoryDetails.instructionLineItemType)) {
        retrieveInvoicePaymentHistoryDetails.paymentType = PRODUCTTYPEEntry.BENEFITUNDERPAYMENT.getCode();
      }

      retrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
        retrieveInvoicePaymentHistoryDetails);
    }

    RetrievePaymentHistoryDetailsList retrieveAttendancePaymentHistoryDetailsList = listAttendancePaymentTypeForProvider(
      paymentInstrumentKey);

    for (RetrievePaymentHistoryDetails retrieveAttendancePaymentHistoryDetails : retrieveAttendancePaymentHistoryDetailsList.paymentHistoryDetails.items()) {

      if (ILITYPEEntry.ATTENDANCEPAYMENT.getCode().equals(
        retrieveAttendancePaymentHistoryDetails.instructionLineItemType)) {
        retrieveAttendancePaymentHistoryDetails.paymentType = PRODUCTTYPEEntry.PROVIDERATTENDANCE.getCode();
      } else if (ILITYPEEntry.BENEFITUNDERPAYMENT.getCode().equals(
        retrieveAttendancePaymentHistoryDetails.instructionLineItemType)) {
        retrieveAttendancePaymentHistoryDetails.paymentType = PRODUCTTYPEEntry.BENEFITUNDERPAYMENT.getCode();
      }

      retrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
        retrieveAttendancePaymentHistoryDetails);
    }

    RetrievePaymentHistoryDetailsList retrievePlacementPaymentHistoryDetailsList = listPlacementPaymentTypeForProvider(
      paymentInstrumentKey);

    for (RetrievePaymentHistoryDetails retrievePlacementPaymentHistoryDetails : retrievePlacementPaymentHistoryDetailsList.paymentHistoryDetails.items()) {

      if (ILITYPEEntry.PLACEMENTPAYMENT.getCode().equals(
        retrievePlacementPaymentHistoryDetails.instructionLineItemType)) {
        retrievePlacementPaymentHistoryDetails.paymentType = PRODUCTTYPEEntry.PROVIDERPLACEMENT.getCode();
      } else if (ILITYPEEntry.BENEFITUNDERPAYMENT.getCode().equals(
        retrievePlacementPaymentHistoryDetails.instructionLineItemType)) {
        retrievePlacementPaymentHistoryDetails.paymentType = PRODUCTTYPEEntry.BENEFITUNDERPAYMENT.getCode();
      }

      retrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
        retrievePlacementPaymentHistoryDetails);
    }

    RetrieveContractDetailsList retrieveContractDetailsList = listFRCPaymentTypeForProvider(
      paymentInstrumentKey);

    for (RetrieveContractDetails retrieveContractDetails : retrieveContractDetailsList.contractDetails.items()) {
      RetrievePaymentHistoryDetails retrievePaymentHistoryDetails = new RetrievePaymentHistoryDetails();

      retrievePaymentHistoryDetails.serviceFrom = retrieveContractDetails.contractStartDate;
      retrievePaymentHistoryDetails.serviceTo = retrieveContractDetails.contractEndDate;
      retrievePaymentHistoryDetails.amount = retrieveContractDetails.amount;
      retrievePaymentHistoryDetails.deductionAmount = retrieveContractDetails.deductionAmount;
      retrievePaymentHistoryDetails.instructionLineItemID = retrieveContractDetails.instructionLineItemID;
      retrievePaymentHistoryDetails.finInstructionID = retrieveContractDetails.finInstructionID;
      retrievePaymentHistoryDetails.relatedReference = retrieveContractDetails.contractVersionID;
      retrievePaymentHistoryDetails.instructionLineItemType = retrieveContractDetails.instructionLineItemType;

      if (ILITYPEEntry.CONTRACTPAYMENT.getCode().equals(
        retrieveContractDetails.instructionLineItemType)) {
        retrievePaymentHistoryDetails.paymentType = PRODUCTTYPEEntry.PROVIDERCONTRACT.getCode();
      } else if (ILITYPEEntry.BENEFITUNDERPAYMENT.getCode().equals(
        retrieveContractDetails.instructionLineItemType)) {
        retrievePaymentHistoryDetails.paymentType = PRODUCTTYPEEntry.BENEFITUNDERPAYMENT.getCode();
      }

      retrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
        retrievePaymentHistoryDetails);
    }

    return retrievePaymentHistoryDetailsList;
  }

  // END, CR00186978
  // END, CR00186917

  // BEGIN, CR00186917, SG
  // BEGIN, CR00186978, SG
  /**
   * {@inheritDoc}
   */
  public RetrievePaymentHistoryDetailsList listPaymentsForProvider(
    final ProviderKey providerOrganizationKey) throws AppException,
      InformationalException {

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      providerOrganizationKey.providerConcernRoleID);

    if (providerOrganization.getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {

      return getPaymentsForProvider(
        providerDAO.get(providerOrganizationKey.providerConcernRoleID), false);
    } else {

      RetrievePaymentHistoryDetailsList allRetrievePaymentHistoryDetailsList = new RetrievePaymentHistoryDetailsList();
      Set<curam.provider.impl.ProviderGroupAssociate> providerGroupAssociates = providerGroupAssociateDAO.searchByProviderGroup(
        providerGroupDAO.get(providerOrganizationKey.providerConcernRoleID));

      // For all the providers associated with the group, get the payments.
      for (final curam.provider.impl.ProviderGroupAssociate providerGroupAssociate : providerGroupAssociates) {

        RetrievePaymentHistoryDetailsList retrievePaymentHistoryDetailsList = getPaymentsForProvider(
          providerGroupAssociate.getProvider(), true);

        for (final RetrievePaymentHistoryDetails retrievePaymentHistoryDetails : retrievePaymentHistoryDetailsList.paymentHistoryDetails.items()) {

          allRetrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
            retrievePaymentHistoryDetails);
        }
      }

      allRetrievePaymentHistoryDetailsList.pageContextDescription = getPageContextDescription(
        providerOrganizationKey.providerConcernRoleID);
      return allRetrievePaymentHistoryDetailsList;
    }
  }

  /**
   * This method lists all the placement payment frequencies
   *
   * @return PlacementFrequencyDetailsList list of all payment frequency
   * @throws AppException
   * @throws InformationalException
   */
  public PlacementFrequencyDetailsList listPlacementPaymentFrequency()
    throws AppException, InformationalException {

    PlacementFrequencyDetailsList placementFrequencyDetailsList = new PlacementFrequencyDetailsList();

    // Get all the placement frequencies
    Set<PlacementPaymentFrequency> placementPaymentFrequencies = placementPaymentFrequencyDAO.readAll();

    PlacementPaymentFrequency[] placementPaymentFrequencyArray = new PlacementPaymentFrequency[placementPaymentFrequencies.size()];

    placementPaymentFrequencyArray = placementPaymentFrequencies.toArray(
      placementPaymentFrequencyArray);

    // Sort the frequencies in the ascending order of effective date.
    sortPlacementPaymentFrequencyArray(placementPaymentFrequencyArray);

    int size = placementPaymentFrequencies.size();

    for (int index = 0; index < size; index++) {

      PlacementFrequencyDetails placementFrequencyDetails = new PlacementFrequencyDetails();

      placementFrequencyDetails.effectiveDate = placementPaymentFrequencyArray[index].getEffectiveDate();
      placementFrequencyDetails.frequencyID = placementPaymentFrequencyArray[index].getID();
      // Begin CR00096779, ABS
      placementFrequencyDetails.frequencyPattern = placementPaymentFrequencyArray[index].getFrequencyPattern();
      // End CR00096779
      placementFrequencyDetails.versionNo = placementPaymentFrequencyArray[index].getVersionNo();

      placementFrequencyDetailsList.detailsList.addRef(
        placementFrequencyDetails);
    }

    return placementFrequencyDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public RetrievePaymentHistoryDetailsList listPlacementPaymentTypeForProvider(
    PaymentInstrumentKey key) throws AppException, InformationalException {

    RetrievePaymentHistoryDetailsList retrievePaymentHistoryDetailsList = new RetrievePaymentHistoryDetailsList();

    PaymentInstruction paymentInstruction = PaymentInstructionFactory.newInstance();

    FinInstructionIDConcernRoleIDList finInstructionIDConcernRoleIDList = paymentInstruction.searchByPmtInstrumentID(
      key);

    int finInstructionSize = finInstructionIDConcernRoleIDList.dtls.size();

    for (int j = 0; j < finInstructionSize; j++) {

      FinInstructionIDConcernRoleID finInstructionIDConcernRoleID = finInstructionIDConcernRoleIDList.dtls.item(
        j);
      InstructionLineItem instructionLineItem = InstructionLineItemFactory.newInstance();
      StatusFinInstructID statusFinInstructID = new StatusFinInstructID();

      statusFinInstructID.finInstructionID = finInstructionIDConcernRoleID.finInstructionID;
      statusFinInstructID.statusCode = ILISTATUS.PROCESSED;
      InstructionLineItemDtlsList instructionLineItemDtlsList = instructionLineItem.searchByFinInstructStatus(
        statusFinInstructID);

      int size = instructionLineItemDtlsList.dtls.size();

      for (int i = 0; i < size; i++) {

        InstructionLineItemDtls instructionLineItemDtls = instructionLineItemDtlsList.dtls.item(
          i);

        // BEGIN, CR00113395, GP
        if (ILITYPEEntry.PLACEMENTPAYMENT.getCode().equals(
          instructionLineItemDtls.instructionLineItemType)
            || ILITYPEEntry.DEDUCTIONITEM.getCode().equals(
              instructionLineItemDtls.instructionLineItemType)) {
          // END, CR00113395

          curam.cpm.sl.entity.intf.Provider provider = ProviderFactory.newInstance();

          FinancialCompIDKey financialCompIdKey = new FinancialCompIDKey();

          financialCompIdKey.financialCompID = instructionLineItemDtls.financialCompID;

          CaseDecisionObjectiveDtlsList caseDecisionObjectiveDtlsList = provider.searchRelatedReferenceByILI(
            financialCompIdKey);

          RetrievePaymentHistoryDetails retrievePaymentHistoryDetails = new RetrievePaymentHistoryDetails();

          if (caseDecisionObjectiveDtlsList.dtls.size() > 0) {

            String relatedReference = caseDecisionObjectiveDtlsList.dtls.item(0).relatedReference;

            if (!GeneralConstants.kSpace.equals(relatedReference)) {

              long placementID = Long.valueOf(relatedReference);

              curam.place.impl.Placement placement = placementDAO.get(
                placementID);

              retrievePaymentHistoryDetails.creationDate = instructionLineItemDtls.creationDate;
              retrievePaymentHistoryDetails.clientName = placement.getClient().getName();
              retrievePaymentHistoryDetails.serviceName = placement.getProviderOffering().getServiceOffering().getName();
              retrievePaymentHistoryDetails.serviceFrom = instructionLineItemDtls.coverPeriodFrom;
              retrievePaymentHistoryDetails.serviceTo = instructionLineItemDtls.coverPeriodTo;
              // BEGIN, CR00127671, GP
              if (instructionLineItemDtls.instructionLineItemType.equals(
                ILITYPEEntry.DEDUCTIONITEM.getCode())) {
                retrievePaymentHistoryDetails.deductionAmount = instructionLineItemDtls.amount;
              } else {
                retrievePaymentHistoryDetails.amount = instructionLineItemDtls.amount;
              }

              retrievePaymentHistoryDetails.instructionLineItemID = instructionLineItemDtls.instructLineItemID;
              retrievePaymentHistoryDetails.placementID = placement.getID();

              // BEGIN, CR00113395, GP
              retrievePaymentHistoryDetails.relatedReference = placement.getID();
              // END, CR00113395

              retrievePaymentHistoryDetails.finInstructionID = instructionLineItemDtls.finInstructionID;

            } else {
              retrievePaymentHistoryDetails.creationDate = instructionLineItemDtls.creationDate;
              retrievePaymentHistoryDetails.serviceFrom = instructionLineItemDtls.coverPeriodFrom;
              retrievePaymentHistoryDetails.serviceTo = instructionLineItemDtls.coverPeriodTo;
              if (instructionLineItemDtls.instructionLineItemType.equals(
                ILITYPEEntry.DEDUCTIONITEM.getCode())) {
                retrievePaymentHistoryDetails.deductionAmount = instructionLineItemDtls.amount;
              } else {
                retrievePaymentHistoryDetails.amount = instructionLineItemDtls.amount;
              }
              retrievePaymentHistoryDetails.instructionLineItemID = instructionLineItemDtls.instructLineItemID;
              retrievePaymentHistoryDetails.finInstructionID = instructionLineItemDtls.finInstructionID;
            }

          } else {
            retrievePaymentHistoryDetails.creationDate = instructionLineItemDtls.creationDate;
            retrievePaymentHistoryDetails.serviceFrom = instructionLineItemDtls.coverPeriodFrom;
            retrievePaymentHistoryDetails.serviceTo = instructionLineItemDtls.coverPeriodTo;
            if (instructionLineItemDtls.instructionLineItemType.equals(
              ILITYPEEntry.DEDUCTIONITEM.getCode())) {
              retrievePaymentHistoryDetails.deductionAmount = instructionLineItemDtls.amount;
            } else {
              retrievePaymentHistoryDetails.amount = instructionLineItemDtls.amount;
            }
            // END, CR00127671
            retrievePaymentHistoryDetails.instructionLineItemID = instructionLineItemDtls.instructLineItemID;
            retrievePaymentHistoryDetails.finInstructionID = instructionLineItemDtls.finInstructionID;
          }

          // BEGIN, CR00113395, GP
          retrievePaymentHistoryDetails.instructionLineItemType = instructionLineItemDtls.instructionLineItemType;
          // END, CR00113395

          retrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
            retrievePaymentHistoryDetails);
        }
      }
    }
    return retrievePaymentHistoryDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ListParticipantFinancials listProviderLiabilities(
    ListParticipantFinancialsKey key) throws AppException,
      InformationalException {
    ListParticipantFinancials listParticipantFinancialsForLiability = new ListParticipantFinancials();
    // Create a participant instance(facade layer)
    curam.core.facade.intf.Participant participant = ParticipantFactory.newInstance();
    ListParticipantFinancialsKey financialsKey = new ListParticipantFinancialsKey();

    financialsKey.concernRoleID = key.concernRoleID;
    // BEGIN, CR00236076, AK
    // Retrieve all the financial for the concernroleID
    ListParticipantFinancials listParticipantFinancials = new ListParticipantFinancials();
    ListParticipantFinancials1 listParticipantFinancials1 = participant.listParticipantFinancial1(
      financialsKey);

    listParticipantFinancials.concernRoleName = listParticipantFinancials1.concernRoleName;
    listParticipantFinancials.contextDescription = listParticipantFinancials1.contextDescription;
    listParticipantFinancials.renderXML = listParticipantFinancials1.renderXML;
    listParticipantFinancials.ind = listParticipantFinancials1.ind;
    ParticipantFinancials newParticipantFinancials;

    for (int j = 0; j
      < listParticipantFinancials1.participantFinancialsList.dtls.size(); j++) {
      newParticipantFinancials = new ParticipantFinancials();
      newParticipantFinancials.assign(
        listParticipantFinancials1.participantFinancialsList.dtls.item(j));
      listParticipantFinancials.participantFinancialsList.dtls.addRef(
        newParticipantFinancials);
    }
    // END, CR00236076

    listParticipantFinancialsForLiability.concernRoleName = listParticipantFinancials.concernRoleName;
    listParticipantFinancialsForLiability.contextDescription = listParticipantFinancials.contextDescription;
    // Loop through the financial
    for (int i = 0; i
      < listParticipantFinancials.participantFinancialsList.dtls.size(); i++) {
      // Retrieve financial details
      ParticipantFinancials participantFinancials = listParticipantFinancials.participantFinancialsList.dtls.get(
        i);

      // If the financial is of type liability
      if (FINANCIALINSTRUCTION.LIABILITY.equals(participantFinancials.typeCode)) {
        listParticipantFinancialsForLiability.participantFinancialsList.dtls.addRef(
          participantFinancials);
      }
    }
    return listParticipantFinancialsForLiability;
  }

  // END, CR00186978

  // BEGIN, CR00186978, SG
  /**
   * {@inheritDoc}
   */
  public RetrievePaymentHistoryDetailsList listSIPaymentTypeForProvider(
    final PaymentInstrumentKey paymentInstrumentKey) throws AppException,
      InformationalException {

    RetrievePaymentHistoryDetailsList retrievePaymentHistoryDetailsList = new RetrievePaymentHistoryDetailsList();
    PaymentInstruction paymentInstructionObj = PaymentInstructionFactory.newInstance();
    FinInstructionIDConcernRoleIDList finInstructionIDConcernRoleIDList = paymentInstructionObj.searchByPmtInstrumentID(
      paymentInstrumentKey);

    for (final FinInstructionIDConcernRoleID finInstructionIDConcernRoleID : finInstructionIDConcernRoleIDList.dtls.items()) {

      InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();

      StatusFinInstructID statusFinInstructID = new StatusFinInstructID();

      statusFinInstructID.finInstructionID = finInstructionIDConcernRoleID.finInstructionID;
      statusFinInstructID.statusCode = ILISTATUSEntry.PROCESSED.getCode();

      InstructionLineItemDtlsList instructionLineItemDtlsList = instructionLineItemObj.searchByFinInstructStatus(
        statusFinInstructID);

      for (final InstructionLineItemDtls instructionLineItemDtls : instructionLineItemDtlsList.dtls.items()) {

        // BEGIN, CR00153581, GP
        // BEGIN, CR00113395, GP
        if (ILITYPEEntry.INVOICEPAYMENT.getCode().equals(
          instructionLineItemDtls.instructionLineItemType)
            || ILITYPEEntry.BENEFITUNDERPAYMENT.getCode().equals(
              instructionLineItemDtls.instructionLineItemType)) {
          // END, CR00113395
          // END, CR00153581

          FinancialCompIDKey financialCompIdKey = new FinancialCompIDKey();

          financialCompIdKey.financialCompID = instructionLineItemDtls.financialCompID;

          CaseDecisionFinancialComp caseDecisionFinancialCompObj = CaseDecisionFinancialCompFactory.newInstance();

          CaseDecisionFinancialCompDtls caseDecisionFinancialCompDtls = new CaseDecisionFinancialCompDtls();

          // BEGIN, CR00187692, SG
          boolean decisionFound = true;

          try {
            caseDecisionFinancialCompDtls = caseDecisionFinancialCompObj.readByFinancialCompID(
              financialCompIdKey);
          } catch (RecordNotFoundException rnfe) {

            decisionFound = false;
          }

          RetrievePaymentHistoryDetails retrievePaymentHistoryDetails = new RetrievePaymentHistoryDetails();
          String relatedReference = GeneralConstants.kEmpty;

          if (decisionFound) {
            // END, CR00187692
            CaseDecisionObjectiveKey caseDecisionObjectiveKey = new CaseDecisionObjectiveKey();

            caseDecisionObjectiveKey.caseDecisionObjectiveID = caseDecisionFinancialCompDtls.caseDecisionObjectiveID;
            CaseDecisionObjective caseDecisionObjectiveObj = CaseDecisionObjectiveFactory.newInstance();
            CaseDecisionObjectiveDtls caseDecisionObjectiveDtls = caseDecisionObjectiveObj.read(
              caseDecisionObjectiveKey);

            relatedReference = caseDecisionObjectiveDtls.relatedReference;
          }

          if (!GeneralConstants.kEmpty.equals(relatedReference)) {

            long serviceInvoiceLineItemID = Long.valueOf(relatedReference);

            ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
              serviceInvoiceLineItemID);

            // BEGIN, CR00114790, GP
            curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceInvoiceLineItem.getServiceOffering();

            // END, CR00114790
            // BEGIN, CR00127671, GP

            retrievePaymentHistoryDetails.amount = instructionLineItemDtls.amount;
            retrievePaymentHistoryDetails.instructionLineItemID = instructionLineItemDtls.instructLineItemID;
            retrievePaymentHistoryDetails.clientName = getClientNameFromSILI(
              serviceInvoiceLineItemID);
            retrievePaymentHistoryDetails.serviceName = serviceOffering.getName();
            retrievePaymentHistoryDetails.serviceFrom = serviceInvoiceLineItem.getServiceDateFrom();
            retrievePaymentHistoryDetails.serviceTo = serviceInvoiceLineItem.getServiceDateTo();
            retrievePaymentHistoryDetails.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
            // BEGIN, CR00113395, GP
            retrievePaymentHistoryDetails.relatedReference = serviceInvoiceLineItem.getID();
            // END, CR00113395
            retrievePaymentHistoryDetails.finInstructionID = instructionLineItemDtls.finInstructionID;

          } else {

            retrievePaymentHistoryDetails.amount = instructionLineItemDtls.amount;
            // BEGIN, CR00153581, GP
            retrievePaymentHistoryDetails.serviceFrom = instructionLineItemDtls.coverPeriodFrom;
            retrievePaymentHistoryDetails.serviceTo = instructionLineItemDtls.coverPeriodTo;
            // END, CR00153581
            // END, CR00127671
            retrievePaymentHistoryDetails.instructionLineItemID = instructionLineItemDtls.instructLineItemID;
            retrievePaymentHistoryDetails.finInstructionID = instructionLineItemDtls.finInstructionID;
          }

          // BEGIN, CR00113395, GP
          retrievePaymentHistoryDetails.instructionLineItemType = instructionLineItemDtls.instructionLineItemType;
          // END, CR00113395
          retrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
            retrievePaymentHistoryDetails);
        }
      }
    }
    return retrievePaymentHistoryDetailsList;
  }

  /**
   * This method is used to modify the placement frequency
   *
   * @param details
   * placement frequency details
   * @throws AppException
   * @throws InformationalException
   */
  public void modifyPlacementPaymentFrequency(PlacementFrequencyDetails details)
    throws AppException, InformationalException {

    PlacementPaymentFrequency placementPaymentFrequency = placementPaymentFrequencyDAO.get(
      details.frequencyID);

    if (!(details.effectiveDate.equals(
      placementPaymentFrequency.getEffectiveDate())
        && details.frequencyPattern.equals(
          placementPaymentFrequency.getFrequencyPattern()))) {

      if (details.effectiveDate.equals(// Modify the placement frequency
        placementPaymentFrequency.getEffectiveDate())) {

        placementPaymentFrequency.setEffectiveDate(details.effectiveDate);
        placementPaymentFrequency.setFrequencyPattern(details.frequencyPattern);
        placementPaymentFrequency.modify(details.versionNo);

        reAssessExistingProvidersForNewFrequency(details);
      } else {

        if (!compareModifiedFrequencyWithTheLatestFrequency(details)) {
          // Create the new frequency
          createPlacementPaymentFrequency(details);
        }

      }
    }

  }

  // BEGIN, CR00229264, VR
  /**
   * {@inheritDoc}
   */
  public ViewAttendancePaymentDetails viewAttendancePaymentTransaction(
    ViewFinancialTransactionDetailKey key) throws AppException,
      InformationalException {
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ViewAttendancePaymentDetails attendancePaymentDetails = new ViewAttendancePaymentDetails();
    Long rosterLineItemID = Long.valueOf(key.relatedReference);
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      rosterLineItemID);

    attendancePaymentDetails.amount = providerRosterLineItem.getActualAmountPaid();
    attendancePaymentDetails.clientName = providerRosterLineItem.getClientName();
    attendancePaymentDetails.serviceName = providerRosterLineItem.getServiceOfferingName();
    attendancePaymentDetails.referenceNumber = providerRosterLineItem.getReferenceNumber();
    concernRoleKey.concernRoleID = key.concernRoleID;
    ConcernRoleDtls providerNameDtls = concernRoleObj.read(concernRoleKey);

    attendancePaymentDetails.providerName = providerNameDtls.concernRoleName;
    return attendancePaymentDetails;
  }

  /**
   * {@inheritDoc}
   */
  public ViewFinancialTransactionDetails viewFinancialTransactionForProvider(
    final ViewFinancialTransactionKey key) 
    throws AppException, InformationalException {
  
    ViewFinancialTransactionDetails details = new ViewFinancialTransactionDetails();
    
    // BEGIN, CR00297030, KH
    // An empty ILI type should be treated as an overpayment
    if (CuramConst.gkEmpty.equals(key.iliType)) {
      key.iliType = ILITYPEEntry.BENEFITOVERPAYMENT.getCode();
    }
    
    // Overpayment and Underpayment ILIs are a special case
    if (ILITYPEEntry.BENEFITOVERPAYMENT.getCode().equals(key.iliType)
      || ILITYPEEntry.BENEFITUNDERPAYMENT.getCode().equals(key.iliType)) {
      getTranscationForOverUnderPayment(details, key);
    } else {
      getTransactionDetailsForCPMPaymentTypes(details, key);
    }
    // END, CR00297030

    return details;
  }

  /**
   * {@inheritDoc}
   */
  public ViewContractPaymentDetails viewFRContractPaymentTransaction(
    ViewFinancialTransactionDetailKey key) throws AppException,
      InformationalException {
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ViewContractPaymentDetails contractPaymentDetails = new ViewContractPaymentDetails();
    Long contractVersionID = Long.valueOf(key.relatedReference);
    FlatRateContract flatRateContract = flatRateContractDAO.get(
      contractVersionID);

    final Set<ContractVersionProviderOffering> contractProviderOfferingLinks = contractProviderOfferingLinkDAO.searchBy(
      flatRateContract);

    String serviceName = GeneralConstants.kSpace;

    for (ContractVersionProviderOffering contractProviderOfferingLink : contractProviderOfferingLinks) {
      serviceName = contractProviderOfferingLink.getProviderOffering().getServiceOffering().getName()
        + GeneralConstants.kSpace;
    }
    if (!flatRateContract.getRegularPaymentAmt().isZero()) {
      contractPaymentDetails.amount = flatRateContract.getRegularPaymentAmt();
    } else {
      contractPaymentDetails.amount = flatRateContract.getTotalContractAmt();
    }
    // BEGIN, CR00261636, GYH
    contractPaymentDetails.contractStartDate = flatRateContract.getDateRange().start();
    contractPaymentDetails.contractEndDate = flatRateContract.getDateRange().end();
    // END, CR00261636
    contractPaymentDetails.contractName = flatRateContract.getName();
    contractPaymentDetails.contractVersionID = flatRateContract.getID();
    contractPaymentDetails.serviceName = serviceName;
    concernRoleKey.concernRoleID = key.concernRoleID;
    ConcernRoleDtls providerNameDtls = concernRoleObj.read(concernRoleKey);

    contractPaymentDetails.providerName = providerNameDtls.concernRoleName;

    return contractPaymentDetails;
  }

  // END, CR00229264
  /**
   * {@inheritDoc}
   */
  public ViewAttendancePaymentHistoryDetails viewPaymentItemForAttendanceBasedPayment(
    ProviderRosterLineItemKey providerRosterLineItemKey,
    InstructionLineItemKey ILIKey) throws AppException,
      InformationalException {

    ViewAttendancePaymentHistoryDetails viewAttendancePaymentHistoryDetails = new ViewAttendancePaymentHistoryDetails();

    InstructionLineItem instructionLineItem = InstructionLineItemFactory.newInstance();
    InstructionLineItemDtls instructionLineItemDtls = instructionLineItem.read(
      ILIKey);

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    viewAttendancePaymentHistoryDetails.amount = instructionLineItemDtls.amount;
    viewAttendancePaymentHistoryDetails.caseReferenceNumber = providerRosterLineItem.getCaseReferenceNo();
    viewAttendancePaymentHistoryDetails.clientName = getClientNameFromProviderRosterLineItem(
      providerRosterLineItem);
    viewAttendancePaymentHistoryDetails.clientReferenceNumber = providerRosterLineItem.getClientReferenceNo();
    viewAttendancePaymentHistoryDetails.providerName = providerRosterLineItem.getProvider().getName();
    // BEGIN, CR00120516, RD
    viewAttendancePaymentHistoryDetails.concernRoleID = providerRosterLineItem.getProvider().getID().longValue();
    // END, CR00120516
    viewAttendancePaymentHistoryDetails.providerReferenceNo = providerRosterLineItem.getProvider().getPrimaryAlternateID();
    viewAttendancePaymentHistoryDetails.saReferenceNo = providerRosterLineItem.getSAReferenceNo();
    viewAttendancePaymentHistoryDetails.serviceDateFrom = providerRosterLineItem.getServiceDateFrom();
    viewAttendancePaymentHistoryDetails.serviceDateTo = providerRosterLineItem.getServiceDateTo();
    viewAttendancePaymentHistoryDetails.rosterLineItemReferenceNo = providerRosterLineItem.getReferenceNumber();
    viewAttendancePaymentHistoryDetails.rosterSubmissionDate = providerRosterLineItem.getRoster().getDateSubmitted();
    viewAttendancePaymentHistoryDetails.rosterReferenceNo = providerRosterLineItem.getRoster().getReferenceNumber();
    viewAttendancePaymentHistoryDetails.serviceName = providerRosterLineItem.getRoster().getServiceOffering().getName();

    return viewAttendancePaymentHistoryDetails;
  }

  /**
   * {@inheritDoc}
   */
  public ViewContractPaymentDetails viewPaymentItemForContractBasedPayment(
    ContractVersionKey key, InstructionLineItemKey ILIKey)
    throws AppException, InformationalException {

    ViewContractPaymentDetails viewContractPaymentDetails = new ViewContractPaymentDetails();

    InstructionLineItem instructionLineItem = InstructionLineItemFactory.newInstance();
    InstructionLineItemDtls instructionLineItemDtls = instructionLineItem.read(
      ILIKey);

    ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);

    ProviderOrganization providerOrganization = contractVersion.getProviderOrganization();

    final Set<ContractVersionProviderOffering> contractProviderOfferingLinks = contractProviderOfferingLinkDAO.searchBy(
      contractVersion);

    String serviceName = GeneralConstants.kSpace;

    for (ContractVersionProviderOffering contractProviderOfferingLink : contractProviderOfferingLinks) {
      serviceName = contractProviderOfferingLink.getProviderOffering().getServiceOffering().getName()
        + GeneralConstants.kSpace;
    }

    serviceName = StringHelper.trim(serviceName);

    viewContractPaymentDetails.serviceName = serviceName;
    viewContractPaymentDetails.amount = instructionLineItemDtls.amount;
    viewContractPaymentDetails.contractEndDate = contractVersion.getDateRange().end();
    viewContractPaymentDetails.contractName = contractVersion.getName();
    viewContractPaymentDetails.contractStartDate = contractVersion.getDateRange().start();
    viewContractPaymentDetails.contractVersionID = key.contractVersionID;
    viewContractPaymentDetails.providerName = providerOrganization.getName();
    viewContractPaymentDetails.providerReferenceNumber = providerOrganization.getPrimaryAlternateID();
    viewContractPaymentDetails.paymentDate = instructionLineItemDtls.effectiveDate;

    return viewContractPaymentDetails;
  }

  /**
   * {@inheritDoc}
   */
  public ViewPaymentHistoryDetails viewPaymentItemForInvoiceBasedPayment(
    ServiceInvoiceLineItemKey key, InstructionLineItemKey ILIKey)
    throws AppException, InformationalException {

    ViewPaymentHistoryDetails viewPaymentHistoryDetails = new ViewPaymentHistoryDetails();

    InstructionLineItem instructionLineItem = InstructionLineItemFactory.newInstance();
    InstructionLineItemDtls instructionLineItemDtls = instructionLineItem.read(
      ILIKey);

    curam.cpm.facade.intf.ServiceInvoice serviceInvoice = ServiceInvoiceFactory.newInstance();

    ServiceInvoiceLineItemDetails serviceInvoiceLineItemDetails = serviceInvoice.viewServiceInvoiceLineItem(
      key);

    ServiceInvoiceKey serviceInvoiceKey = new ServiceInvoiceKey();

    serviceInvoiceKey.serviceInvoiceID = serviceInvoiceLineItemDetails.details.serviceInvoiceID;
    ServiceInvoiceDetails serviceInvoiceDetails = serviceInvoice.viewServiceInvoice(
      serviceInvoiceKey);

    viewPaymentHistoryDetails.amount = instructionLineItemDtls.amount;
    viewPaymentHistoryDetails.caseReferenceNumber = serviceInvoiceLineItemDetails.details.caseReferenceNo;
    viewPaymentHistoryDetails.clientName = getClientNameFromSILI(
      serviceInvoiceLineItemDetails.details.serviceInvoiceLineItemID);
    viewPaymentHistoryDetails.clientReferenceNumber = serviceInvoiceLineItemDetails.details.clientReferenceNo;
    viewPaymentHistoryDetails.providerName = providerOrganizationDAO.get(serviceInvoiceLineItemDetails.details.providerID).getName();
    viewPaymentHistoryDetails.providerReferenceNo = serviceInvoiceLineItemDetails.details.providerReferenceNo;
    viewPaymentHistoryDetails.saReferenceNo = serviceInvoiceLineItemDetails.details.saReferenceNo;
    viewPaymentHistoryDetails.serviceDateFrom = serviceInvoiceLineItemDetails.details.serviceDateFrom;
    viewPaymentHistoryDetails.serviceDateTo = serviceInvoiceLineItemDetails.details.serviceDateTo;
    viewPaymentHistoryDetails.serviceInvoiceLineItemRefNo = serviceInvoiceLineItemDetails.details.referenceNo;
    viewPaymentHistoryDetails.serviceInvoiceReceiptDate = serviceInvoiceDetails.serviceInvoiceDtls.receiptDate;
    viewPaymentHistoryDetails.serviceInvoiceRefNo = serviceInvoiceDetails.serviceInvoiceDtls.referenceNo;
    viewPaymentHistoryDetails.serviceName = serviceInvoiceLineItemDetails.dtls.service;

    return viewPaymentHistoryDetails;
  }

  /**
   * {@inheritDoc}
   */
  public ViewPaymentHistoryDetails viewPaymentItemForUtilizationBasedPayment(
    PlacementKey placementKey, InstructionLineItemKey ILIKey)
    throws AppException, InformationalException {

    ViewPaymentHistoryDetails viewPaymentHistoryDetails = new ViewPaymentHistoryDetails();

    curam.place.impl.Placement placement = placementDAO.get(
      placementKey.placementID);

    Place place = placeDAO.get(placement.getPlace().getID());

    Compartment compartment = compartmentDAO.get(place.getCompartment().getID());

    curam.providerservice.impl.ProviderOffering providerOffering = placement.getProviderOffering();

    curam.provider.impl.Provider provider = compartment.getProvider();

    CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = placement.getCaseParticipantRoleID();
    CaseParticipantRoleDtls caseParticipantRoleDtls = caseParticipantRole.read(
      caseParticipantRoleKey);

    CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    
    // BEGIN, CR00303986, SG
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = caseParticipantRoleDtls.caseID;
    final CaseReference caseReference = caseHeader.readCaseReferenceByCaseID(
      caseSearchKey);
    // END, CR00303986

    InstructionLineItem instructionLineItem = InstructionLineItemFactory.newInstance();
    InstructionLineItemDtls instructionLineItemDtls = instructionLineItem.read(
      ILIKey);

    viewPaymentHistoryDetails.clientName = placement.getClient().getName();
    viewPaymentHistoryDetails.clientReferenceNumber = placement.getClient().getPrimaryAlternateID();
    viewPaymentHistoryDetails.serviceDateFrom = instructionLineItemDtls.coverPeriodFrom;
    viewPaymentHistoryDetails.serviceDateTo = instructionLineItemDtls.coverPeriodTo;
    viewPaymentHistoryDetails.providerReferenceNo = provider.getPrimaryAlternateID();
    viewPaymentHistoryDetails.providerName = provider.getName();
    viewPaymentHistoryDetails.amount = instructionLineItemDtls.amount;
    viewPaymentHistoryDetails.serviceName = providerOffering.getServiceOffering().getName();
    
    // BEGIN, CR00303986, SG
    viewPaymentHistoryDetails.caseReferenceNumber = caseReference.caseReference;
    // END, CR00303986
    
    return viewPaymentHistoryDetails;
  }

  // END, CR00186978
  // END, CR00186917

  /**
   * This method is used to view the placement frequency
   *
   * @param details
   * placement frequency details
   * @return PlacementFrequencyDetails placement frequency details
   * @throws AppException
   * @throws InformationalException
   */
  public PlacementFrequencyDetails viewPlacementFrequency(
    PlacementFrequencyDetails details) throws AppException,
      InformationalException {

    PlacementPaymentFrequency placementPaymentFrequency = placementPaymentFrequencyDAO.get(
      details.frequencyID);

    PlacementFrequencyDetails placementFrequencyDetails = new PlacementFrequencyDetails();

    placementFrequencyDetails.effectiveDate = placementPaymentFrequency.getEffectiveDate();
    placementFrequencyDetails.frequencyID = placementPaymentFrequency.getID();
    // Begin CR00096779, ABS
    placementFrequencyDetails.frequencyPattern = placementPaymentFrequency.getFrequencyPattern();
    // End CR00096779
    placementFrequencyDetails.versionNo = placementPaymentFrequency.getVersionNo();

    return placementFrequencyDetails;
  }

  // BEGIN, CR00229264, VR
  /**
   * Retrieves placement details based on the placement id.
   *
   * @param key
   * Unique Identifier Placement ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewPlacementPaymentDetails viewPlacementPaymentTransaction(
    ViewFinancialTransactionDetailKey key) throws AppException,
      InformationalException {
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ViewPlacementPaymentDetails placementPaymentDetails = new ViewPlacementPaymentDetails();
    Long placementID = Long.valueOf(key.relatedReference);
    Placement placement = placementDAO.get(placementID);

    // BEGIN, CR00235496, VR
    String serviceName = placement.getProviderOffering().getServiceOffering().getNameText().getValue();

    if (null == serviceName) {
      serviceName = placement.getProviderOffering().getServiceOffering().getName();
    }
    // END, CR00235496

    placementPaymentDetails.fromDate = new Date(
      placement.getDateTimeRange().start());
    placementPaymentDetails.toDate = new Date(
      placement.getDateTimeRange().end());
    placementPaymentDetails.serviceName = serviceName;
    placementPaymentDetails.clientName = placement.getClient().getName();
    concernRoleKey.concernRoleID = key.concernRoleID;
    ConcernRoleDtls providerNameDtls = concernRoleObj.read(concernRoleKey);

    placementPaymentDetails.providerName = providerNameDtls.concernRoleName;
    return placementPaymentDetails;
  }

  /**
   * {@inheritDoc}
   */
  public ViewSILIPaymentDetails viewSILIPaymentTransaction(
    ViewFinancialTransactionDetailKey key) throws AppException,
      InformationalException {
    Long siliID = Long.valueOf(key.relatedReference);
    ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      siliID);
    ViewSILIPaymentDetails paymentDetails = new ViewSILIPaymentDetails();
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = serviceInvoiceLineItem.getClientID();
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    paymentDetails.numberOfUnits = serviceInvoiceLineItem.getNumberOfUnits();
    paymentDetails.clientName = concernRoleDtls.concernRoleName;
    paymentDetails.serviceInvoiceLineItemID = serviceInvoiceLineItem.getID();
    paymentDetails.referenceNumber = serviceInvoiceLineItem.getReferenceNumber();
    paymentDetails.serviceName = serviceInvoiceLineItem.getServiceOffering().getNameText().getValue();
    paymentDetails.amountPaid = serviceInvoiceLineItem.getAmountPaid();
    paymentDetails.amountInvoiced = serviceInvoiceLineItem.getAmountInvoiced();
    concernRoleKey.concernRoleID = key.concernRoleID;
    ConcernRoleDtls providerNameDtls = concernRoleObj.read(concernRoleKey);

    paymentDetails.providerName = providerNameDtls.concernRoleName;

    return paymentDetails;
  }

  // END, CR00229264
  /**
   * This method compares the modified frequency pattern with the
   *
   * @param details
   * placement frequency details
   * @return boolean if it is the same frequency
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00177241, PM
  protected boolean compareModifiedFrequencyWithTheLatestFrequency(
    // END, CR00177241
    PlacementFrequencyDetails details) throws InformationalException,
      AppException {

    boolean sameFrequencyPatternInd = false;

    // Get all the frequencies
    Set<PlacementPaymentFrequency> placementPaymentFrequencies = placementPaymentFrequencyDAO.readAll();

    PlacementPaymentFrequency[] placementPaymentFrequencyArray = new PlacementPaymentFrequency[placementPaymentFrequencies.size()];

    placementPaymentFrequencyArray = placementPaymentFrequencies.toArray(
      placementPaymentFrequencyArray);

    // sort it in the ascending order of the effective date.
    sortPlacementPaymentFrequencyArray(placementPaymentFrequencyArray);

    int size = placementPaymentFrequencies.size();
    boolean frequencyFoundInd = false;

    for (int index = 0; index < size; index++) {

      if (!placementPaymentFrequencyArray[index].getEffectiveDate().after(
        details.effectiveDate)
          && index + 1 < size
          && placementPaymentFrequencyArray[index + 1].getEffectiveDate().after(
            details.effectiveDate)) {

        frequencyFoundInd = true;

        if (placementPaymentFrequencyArray[index].getEffectiveDate().equals(
          details.effectiveDate)
            && !placementPaymentFrequencyArray[index].getFrequencyPattern().equals(
              details.frequencyPattern)) {

          // modify the frequency and re-assess the providers
          sameFrequencyPatternInd = true;

          PlacementPaymentFrequency placementPaymentFrequency = placementPaymentFrequencyDAO.get(
            details.frequencyID);

          placementPaymentFrequency.setEffectiveDate(details.effectiveDate);
          placementPaymentFrequency.setFrequencyPattern(
            details.frequencyPattern);
          placementPaymentFrequency.modify(details.versionNo);

          reAssessExistingProvidersForNewFrequency(details);

          break;
        }

        if (placementPaymentFrequencyArray[index].getFrequencyPattern().equals(
          details.frequencyPattern)) {

          sameFrequencyPatternInd = true;
          break;
        }
      }
    }

    if (!frequencyFoundInd) {
      if (placementPaymentFrequencyArray[size - 1].getFrequencyPattern().equals(
        details.frequencyPattern)) {

        sameFrequencyPatternInd = true;

      } else if (placementPaymentFrequencyArray[size - 1].getEffectiveDate().equals(
        details.effectiveDate)) {

        // modify the frequency and re-assess the providers
        sameFrequencyPatternInd = true;

        PlacementPaymentFrequency placementPaymentFrequency = placementPaymentFrequencyDAO.get(
          details.frequencyID);

        placementPaymentFrequency.setEffectiveDate(details.effectiveDate);
        placementPaymentFrequency.setFrequencyPattern(details.frequencyPattern);
        placementPaymentFrequency.modify(details.versionNo);

        reAssessExistingProvidersForNewFrequency(details);
      }
    }

    return sameFrequencyPatternInd;
  }

  /**
   * This method is used to return the ProductDeliveryPatternDetails for the
   * Provider Placement(Utilization) product
   *
   * @param providerOrganization
   * - The Provider or the Provider Group
   * @param productDtls
   * - The product details for the Provider or the Provider Group.
   * @param deliveryFrequency
   * - delivery frequency
   *
   * @return ProductDeliveryPatternDtls - The delivery pattern details
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected ProductDeliveryPatternDtls createProductDeliveryPatternForProvider(
    // END, CR00177241
    ProviderOrganization providerOrganization, ProductDtls productDtls,
    String deliveryFrequency) throws AppException, InformationalException {

    ProductDeliveryPattern deliveryPattern = ProductDeliveryPatternFactory.newInstance();
    ProductDeliveryPatternDtls deliveryPatternDtls = new ProductDeliveryPatternDtls();

    deliveryPatternDtls.productDeliveryPatternID = UniqueID.nextUniqueID();
    deliveryPatternDtls.productID = productDtls.productID;
    deliveryPattern.insert(deliveryPatternDtls);

    ProductDeliveryPatternInfo deliveryPatternInfo = ProductDeliveryPatternInfoFactory.newInstance();
    ProductDeliveryPatternInfoDtls patternInfoDtls = new ProductDeliveryPatternInfoDtls();

    // BEGIN, CR00304532, GP
    patternInfoDtls.coverPattern = placementPaymentCoverPattern.determineCoverPattern().getCode();
    // END, CR00304532

    if (deliveryFrequency != null && deliveryFrequency.length() == 9) {
      patternInfoDtls.deliveryFrequency = deliveryFrequency;
    } else {
      patternInfoDtls.deliveryFrequency = CPMConstants.kProviderPlacementProductDeliveryFrequency;
    }

    patternInfoDtls.deliveryMethodID = providerOrganization.getMethodOfPayment();
    patternInfoDtls.fromDate = providerOrganization.getRegistrationDate().addDays(
      -1);
    patternInfoDtls.maximumAmount = new Money(CPMConstants.kMaximumAmount);
    patternInfoDtls.name = CPMConstants.kProviderPlacementDeliveryPattern;
    
    // BEGIN, CR00304532, GP
    patternInfoDtls.offset = placementPaymentPatternInfoOffset.determinePatternInfoOffset();
    // END, CR00304532
    
    patternInfoDtls.productDeliveryPatternID = deliveryPatternDtls.productDeliveryPatternID;
    patternInfoDtls.productDeliveryPatternInfoID = UniqueID.nextUniqueID();
    patternInfoDtls.recordStatus = RECORDSTATUS.NORMAL;
    patternInfoDtls.versionNo = 1;
    deliveryPatternInfo.insert(patternInfoDtls);

    return deliveryPatternDtls;
  }

  // END, CR00114790

  /**
   * This returns the client name for a given roster line item ID.
   *
   * @param providerRosterLineItem
   * provider roster line item.
   * @return Client name
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected String getClientNameFromProviderRosterLineItem(
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {

    // BEGIN, CR00116872, AS
    curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = providerRosterLineItem.getServiceAuthorization();
    // END, CR00116872

    long concernRoleID = serviceAuthorization.getConcernRoleID();

    ConcernRole concernRole = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = concernRoleID;
    ConcernRoleDtls concernRoleDtls = concernRole.read(concernRoleKey);

    return concernRoleDtls.concernRoleName;
  }

  /**
   * This returns the client name given the service invoice line item ID
   *
   * @param sILIID
   * - service invoice line item ID
   * @return String
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected String getClientNameFromSILI(long sILIID) throws AppException,
      // END, CR00177241
      InformationalException {

    ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      sILIID);

    ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceInvoiceLineItem.getServiceAuthorizationLineItem();

    curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = serviceAuthorizationLineItem.getServiceAuthorization();

    long concernRoleID = serviceAuthorization.getConcernRoleID();

    ConcernRole concernRole = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = concernRoleID;
    ConcernRoleDtls concernRoleDtls = concernRole.read(concernRoleKey);

    return concernRoleDtls.concernRoleName;
  }

  /**
   * This method returns the Instruction line item ID
   *
   * @param paymentInstrumentID
   * - payment instrumentID
   * @return long
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected long getInstructionLineItem(long paymentInstrumentID)
    // END, CR00177241
    throws AppException, InformationalException {

    long instructionLineItemID = 0;

    PaymentInstrumentKey key = new PaymentInstrumentKey();

    key.pmtInstrumentID = paymentInstrumentID;

    // Get the payment instructions
    PaymentInstruction paymentInstruction = PaymentInstructionFactory.newInstance();
    FinInstructionIDConcernRoleIDList finInstructionIDConcernRoleIDList = paymentInstruction.searchByPmtInstrumentID(
      key);

    int finInstructionSize = finInstructionIDConcernRoleIDList.dtls.size();

    for (int j = 0; j < finInstructionSize; j++) {

      FinInstructionIDConcernRoleID finInstructionIDConcernRoleID = finInstructionIDConcernRoleIDList.dtls.item(
        j);

      // Get the ILI
      InstructionLineItem instructionLineItem = InstructionLineItemFactory.newInstance();
      StatusFinInstructID statusFinInstructID = new StatusFinInstructID();

      statusFinInstructID.finInstructionID = finInstructionIDConcernRoleID.finInstructionID;
      statusFinInstructID.statusCode = ILISTATUS.PROCESSED;
      InstructionLineItemDtlsList instructionLineItemDtlsList = instructionLineItem.searchByFinInstructStatus(
        statusFinInstructID);

      int size = instructionLineItemDtlsList.dtls.size();

      for (int i = 0; i < size; i++) {
        instructionLineItemID = instructionLineItemDtlsList.dtls.item(i).instructLineItemID;
      }
    }

    return instructionLineItemID;
  }

  /**
   * This method returns the page context description Provider or Provider Group
   * based on the concernRoleID
   *
   * @param concernRoleID
   * - concern role id of provider or provider organization
   * @return String
   */
  // BEGIN, CR00177241, PM
  protected String getPageContextDescription(Long concernRoleID) {
    // END, CR00177241
    String pageContextDescription = "";

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      concernRoleID);

    CONCERNROLETYPEEntry concernRoleTypeEntry = providerOrganization.getConcernRoleType();

    if (concernRoleTypeEntry.equals(CONCERNROLETYPEEntry.PROVIDER)
      || concernRoleTypeEntry.equals(CONCERNROLETYPEEntry.PROVIDERGROUP)) {

      pageContextDescription = providerOrganization.getName()
        + GeneralConstants.kSpace + GeneralConstants.kMinus
        + GeneralConstants.kSpace
        + providerOrganization.getPrimaryAlternateID();

    }

    return pageContextDescription;
  }

  // BEGIN, CR00186917, SG
  // BEGIN, CR00186978, SG
  /**
   * Gets the payments made for the provider.
   *
   * @param provider
   * The provider for whom the payments are retrieved.
   * @param isGroupToReceivePayments
   * Indicates whether provider group has received the payments on
   * behalf of provider.
   *
   * @return The list of payments.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected RetrievePaymentHistoryDetailsList getPaymentsForProvider(
    final curam.provider.impl.Provider provider,
    final boolean isGroupToReceivePayments) throws AppException,
      InformationalException {

    RetrievePaymentHistoryDetailsList retrievePaymentHistoryDetailsList = new RetrievePaymentHistoryDetailsList();
    RetrievePaymentHistoryDetails retrievePaymentHistoryDetails;

    // For service invoice payment type.
    String productDeliveryType = PRODUCTTYPE.PROVIDERINVOICE;
    PaymentInstrumentDtlsList serviceInvoicePIDtlsList = searchFinancialsForProvOrgProductDeliveryType(
      productDeliveryType, provider, isGroupToReceivePayments);

    for (final PaymentInstrumentDtls paymentInstrumentDtls : serviceInvoicePIDtlsList.dtls.items()) {

      retrievePaymentHistoryDetails = setRetrievePaymentHistoryDetails(
        paymentInstrumentDtls);
      retrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
        retrievePaymentHistoryDetails);
    }

    // BEGIN, CR00208316, RD
    // For payment correction - under and over payment type.
    productDeliveryType = PRODUCTTYPE.PAYMENTCORRECTION;
    PaymentInstrumentDtlsList paymentCorrectionPIDtlsList = searchFinancialsForProvOrgProductDeliveryType(
      productDeliveryType, provider, isGroupToReceivePayments);

    for (final PaymentInstrumentDtls paymentInstrumentDtls : paymentCorrectionPIDtlsList.dtls.items()) {

      retrievePaymentHistoryDetails = setRetrievePaymentHistoryDetails(
        paymentInstrumentDtls);
      retrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
        retrievePaymentHistoryDetails);
    }
    // END, CR00208316

    // For Placement payment type.
    productDeliveryType = PRODUCTTYPE.PROVIDERPLACEMENT;
    PaymentInstrumentDtlsList placementPIDtlsList = searchFinancialsForProvOrgProductDeliveryType(
      productDeliveryType, provider, isGroupToReceivePayments);

    for (final PaymentInstrumentDtls paymentInstrumentDtls : placementPIDtlsList.dtls.items()) {

      retrievePaymentHistoryDetails = setRetrievePaymentHistoryDetails(
        paymentInstrumentDtls);
      retrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
        retrievePaymentHistoryDetails);
    }

    // For contract based payments.
    productDeliveryType = PRODUCTTYPE.PROVIDERCONTRACT;
    PaymentInstrumentDtlsList flatRateContractPIDtlsList = searchFinancialsForProvOrgProductDeliveryType(
      productDeliveryType, provider, isGroupToReceivePayments);

    for (final PaymentInstrumentDtls paymentInstrumentDtls : flatRateContractPIDtlsList.dtls.items()) {

      retrievePaymentHistoryDetails = setRetrievePaymentHistoryDetails(
        paymentInstrumentDtls);
      retrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
        retrievePaymentHistoryDetails);
    }

    // For attendance based payments.
    productDeliveryType = PRODUCTTYPE.PROVIDERATTENDANCE;
    PaymentInstrumentDtlsList attendancePaymentPIDtlsList = searchFinancialsForProvOrgProductDeliveryType(
      productDeliveryType, provider, isGroupToReceivePayments);

    for (final PaymentInstrumentDtls paymentInstrumentDtls : attendancePaymentPIDtlsList.dtls.items()) {

      retrievePaymentHistoryDetails = setRetrievePaymentHistoryDetails(
        paymentInstrumentDtls);
      retrievePaymentHistoryDetailsList.paymentHistoryDetails.addRef(
        retrievePaymentHistoryDetails);
    }

    return retrievePaymentHistoryDetailsList;
  }

  /**
   * This method is used to return the ProductDetails for the Provider
   * Placement(Utilization) product.
   *
   * @return ProductDtls - The Product details
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected ProductDtls getProduct() throws AppException,
      InformationalException {
    // END, CR00177241

    Product product = ProductFactory.newInstance();
    ProductTypeCodeIn codeIn = new ProductTypeCodeIn();

    codeIn.benefitInd = true;
    codeIn.statusCode = RECORDSTATUS.NORMAL;
    codeIn.typeCode = PRODUCTTYPE.PROVIDERPLACEMENT;
    ProductDtls productDtls = product.searchByType(codeIn).dtls.item(0);

    return productDtls;
  }

  /**
   * This method is to get the ProductDelivery details from the
   * PaymentInstrumentDtls
   *
   * @param paymentInstrumentDtls
   * - PaymentInstrumentDtls
   * @return ProductDeliveryDtls
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected ProductDeliveryDtls getProductDeliveryDetails(
    // END, CR00177241
    PaymentInstrumentDtls paymentInstrumentDtls) throws AppException,
      InformationalException {
    CaseNominee caseNomineeObj = CaseNomineeFactory.newInstance();
    CaseNomineeKey caseNomineeKey = new CaseNomineeKey();

    caseNomineeKey.caseNomineeID = paymentInstrumentDtls.caseNomineeID;
    CaseIDAndFromDateDtls caseIDAndFromDateDtls = caseNomineeObj.readCaseID(
      caseNomineeKey);
    ProductDelivery delivery = ProductDeliveryFactory.newInstance();
    ProductDeliveryKey deliveryKey = new ProductDeliveryKey();

    deliveryKey.caseID = caseIDAndFromDateDtls.caseID;
    ProductDeliveryDtls deliveryDtls = delivery.read(deliveryKey);

    return deliveryDtls;
  }

  // BEGIN, CR00229264, VR
  /**
   * Get the product type associated with the product delivery case.
   *
   * @param caseID
   * product delivery case ID.
   * @return Product type of the product delivery.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected String getProductType(final long caseID) throws AppException,
      InformationalException {

    ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
    CaseKey caseIDKey = new CaseKey();

    caseIDKey.caseID = caseID;
    CaseHomePageNameAndType caseHomePageNameAndType = productDeliveryObj.readCaseHomePageNameAndType(
      caseIDKey);

    if (!caseHomePageNameAndType.typeCode.equals(
      PRODUCTTYPEEntry.PAYMENTCORRECTION.getCode())) {
      return caseHomePageNameAndType.typeCode;
    } else {
      CaseRelationship caseRelationship = CaseRelationshipFactory.newInstance();
      CaseRelationshipCaseIDKey relationshipCaseIDKey = new CaseRelationshipCaseIDKey();

      relationshipCaseIDKey.caseID = caseID;
      CaseRelationshipDtlsList dtlsList = caseRelationship.searchByCaseID(
        relationshipCaseIDKey);
      CaseRelationshipDtls caseRelationshipDtls = null;

      for (CaseRelationshipDtls relationshipDtls : dtlsList.dtls.items()) {
        caseRelationshipDtls = relationshipDtls;
      }
      if (caseRelationshipDtls != null) {

        caseIDKey.caseID = caseRelationshipDtls.relatedCaseID;
        CaseHomePageNameAndType caseHomePType = productDeliveryObj.readCaseHomePageNameAndType(
          caseIDKey);

        return caseHomePType.typeCode;
      }
    }

    return null;
  }

  /**
   * Retrieves the Financial transaction details associated with financial
   * instruction for a CPM payment types.
   *
   * @param details
   * List of Financial transactions associated with financial
   * transaction.
   * @param key
   * Financial transaction ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void getTransactionDetailsForCPMPaymentTypes(
    ViewFinancialTransactionDetails details,
    ViewFinancialTransactionKey key) throws AppException,
      InformationalException {
	   
    InstructionLineItem instructionLineItem = InstructionLineItemFactory.newInstance();
    StatusFinInstructID statusFinInstructID = new StatusFinInstructID();

    statusFinInstructID.finInstructionID = key.financialInstructionID;
    statusFinInstructID.statusCode = ILISTATUS.PROCESSED;
    InstructionLineItemDtlsList instructionLineItemDtlsList = instructionLineItem.searchByFinInstructStatus(
      statusFinInstructID);
    List<String> relatedReferenceList = new ArrayList<String>();

    Map<Long, String> relatedRefMap = new HashMap<Long, String>();
    // BEGIN CR00249345, VR

    // BEGIN, CR00292717, GP
    Map<Long, List<ViewFinancialTransactionDetail>> transactionDetailMap = new HashMap<Long, List<ViewFinancialTransactionDetail>>();

    // END, CR00292717

    for (InstructionLineItemDtls instructionLineItemDtls : instructionLineItemDtlsList.dtls.items()) {
      // BEGIN, CR00248594, VR
      // Added to check the whether instruction line item is deduction
      // line
      // item.If it is not deduction line item it adds to the list of
      // payments
      // otherwise add the amount to deduction
      if (!ILITYPEEntry.DEDUCTIONITEM.getCode().equals(
        instructionLineItemDtls.instructionLineItemType)) {
        // END, CR00248594
        ViewFinancialTransactionDetail transactionDetail = new ViewFinancialTransactionDetail();

        transactionDetail.ILIID = instructionLineItemDtls.instructLineItemID;
        transactionDetail.coverperiodFrom = instructionLineItemDtls.coverPeriodFrom;
        transactionDetail.coverperiodTo = instructionLineItemDtls.coverPeriodTo;
        transactionDetail.instructionLineItemType = instructionLineItemDtls.instructionLineItemType;
        transactionDetail.instructLineItemCategory = instructionLineItemDtls.instructLineItemCategory;
        transactionDetail.deductedAmount = new Money(0);
        transactionDetail.paymentTypeCode = PAYMENTTYPES.PAYMENT;       

        // BEGIN, CR00280674, SK
        // BEGIN, CR00291780, GP
        transactionDetail.breakdownDispIndOpt = true;
        // END, CR00291780
        // END, CR00280674
		
        // BEGIN, CR00386728, RPB
        if (0 == instructionLineItemDtls.caseID
          && ILITYPEEntry.DEDUCTIONPAYMENT.getCode().equals(
            instructionLineItemDtls.instructionLineItemType)) {
          CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();
          ReadByParticipantRoleIDTypeKey readByParticipantRoleIDTypeKey = new ReadByParticipantRoleIDTypeKey();

          readByParticipantRoleIDTypeKey.participantRoleID = instructionLineItemDtls.concernRoleID;
          readByParticipantRoleIDTypeKey.typeCode = CASEPARTICIPANTROLETYPE.THIRDPARTYDEDRECIPIENT;
          readByParticipantRoleIDTypeKey.recordStatus = RECORDSTATUS.NORMAL;
          ReadByParticipantRoleIDTypeDetails readByParticipantRoleIDTypeDetails = caseParticipantRoleObj.readByParticipantRoleIDType(
            readByParticipantRoleIDTypeKey);
          curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

          caseParticipantRoleKey.caseParticipantRoleID = readByParticipantRoleIDTypeDetails.caseParticipantRoleID;
          instructionLineItemDtls.caseID = caseParticipantRoleObj.read(caseParticipantRoleKey).caseID;
          transactionDetail.breakdownDispIndOpt = false;
        }    
        
        transactionDetail.productType = getProductType(
          instructionLineItemDtls.caseID);      
        // END, CR00386728

        FinInstructionID finInstructionID = new FinInstructionID();

        finInstructionID.finInstructionID = key.financialInstructionID;
        transactionDetail.amount = instructionLineItemDtls.amount;

        curam.cpm.sl.entity.intf.Provider provider = ProviderFactory.newInstance();

        FinancialCompIDKey financialCompIdKey = new FinancialCompIDKey();

        financialCompIdKey.financialCompID = instructionLineItemDtls.financialCompID;

        CaseDecisionObjectiveDtlsList caseDecisionObjectiveDtlsList = provider.searchRelatedReferenceByILI(
          financialCompIdKey);

        for (CaseDecisionObjectiveDtls objectiveDtls : caseDecisionObjectiveDtlsList.dtls.items()) {
          if (!relatedReferenceList.contains(objectiveDtls.relatedReference)) {
            relatedReferenceList.add(objectiveDtls.relatedReference);
          }
          transactionDetail.relatedReference = objectiveDtls.relatedReference;
        }
        details.dtls.add(transactionDetail);

        // BEGIN, CR00292717, GP
        relatedRefMap.put(instructionLineItemDtls.caseID,
          transactionDetail.relatedReference);
        // END, CR00292717

      } // BEGIN, CR00248594, VR
      else {
        ViewFinancialTransactionDetail transactionDetail = new ViewFinancialTransactionDetail();

        transactionDetail.ILIID = instructionLineItemDtls.instructLineItemID;
        transactionDetail.coverperiodFrom = instructionLineItemDtls.coverPeriodFrom;
        transactionDetail.coverperiodTo = instructionLineItemDtls.coverPeriodTo;
        transactionDetail.instructionLineItemType = instructionLineItemDtls.instructionLineItemType;
        transactionDetail.instructLineItemCategory = instructionLineItemDtls.instructLineItemCategory;
        transactionDetail.deductedAmount = instructionLineItemDtls.amount;
        transactionDetail.paymentTypeCode = PAYMENTTYPES.PAYMENT;
        transactionDetail.productType = getProductType(
          instructionLineItemDtls.caseID);

        transactionDetail.amount = new Money(0);

        // BEGIN, CR00280674, SK
        // BEGIN, CR00291780, GP
        transactionDetail.breakdownDispIndOpt = true;
        // END, CR00291780
        // END, CR00280674

        FinancialCompIDKey financialCompIdKey = new FinancialCompIDKey();

        financialCompIdKey.financialCompID = instructionLineItemDtls.financialCompID;

        // BEGIN, CR00292717, GP

        if (!transactionDetailMap.containsKey(instructionLineItemDtls.caseID)) {
          List<ViewFinancialTransactionDetail> listDeductionItems = new ArrayList<ViewFinancialTransactionDetail>();

          listDeductionItems.add(transactionDetail);
          transactionDetailMap.put(instructionLineItemDtls.caseID,
            listDeductionItems);
        } else {

          List<ViewFinancialTransactionDetail> listDeductionItems = transactionDetailMap.get(
            instructionLineItemDtls.caseID);

          listDeductionItems.add(transactionDetail);
          transactionDetailMap.put(instructionLineItemDtls.caseID,
            listDeductionItems);
        }
        // END, CR00292717
      }

    }

    // BEGIN, CR00292717, GP
    final Iterator<Entry<Long, List<ViewFinancialTransactionDetail>>> transactionIterator = transactionDetailMap.entrySet().iterator();

    while (transactionIterator.hasNext()) {
      final Long transactionID = transactionIterator.next().getKey();
      List<ViewFinancialTransactionDetail> transactionDetails = transactionDetailMap.get(
        transactionID);

      for (final ViewFinancialTransactionDetail transactionDetail : transactionDetails) {
        transactionDetail.relatedReference = relatedRefMap.get(transactionID);
        details.dtls.add(transactionDetail);
      }
    }
    // END, CR00292717
    // END, CR00249345
    // END, CR00248594
  }

  /**
   * Retrieves the Financial transaction details associated with financial
   * instruction for over/under payment types.
   *
   * @param details
   * List of Financial transactions associated with financial
   * transaction.
   * @param key
   * Financial transaction ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void getTranscationForOverUnderPayment(
    ViewFinancialTransactionDetails details, ViewFinancialTransactionKey key)
    throws AppException, InformationalException {
    // BEGIN, CR00280674, SK
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();
    ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID = key.financialInstructionID;
    InstructionLineItemDtlsList instructionLineItemDtlsList = instructionLineItemObj.searchByFinInstructID(
      iliFinInstructID);
    ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
    CaseKey caseIDKey = new CaseKey();

    SearchByFIAndILITypeKey searchByFIAndILITypeKey = new SearchByFIAndILITypeKey();

    searchByFIAndILITypeKey.financialInstructionID = key.financialInstructionID;
    searchByFIAndILITypeKey.iliType = key.iliType;
    FinancialInstructionDetailList detailList = providerDAO.searchByFinancialInstructionAndILIType(
      searchByFIAndILITypeKey);

    // BEGIN, CR00282068, GP
    // If Use Rolled Up Reassessment check box is checked for a CPM product,
    // then the payments
    // will roll up and drill down details of payments are not available. In
    // such cases detailList will be empty. If detailList is empty, it means
    // payment correction product is not responsible for
    // over payment/under payment(if there are any).
    if (!detailList.dtls.isEmpty()) {

      ViewFinancialTransactionDetail transactionDetail;

      for (final FinancialInstructionDetail detail : detailList.dtls.items()) {

        transactionDetail = new ViewFinancialTransactionDetail();

        transactionDetail.ILIID = detail.instructionLineItemID;
        transactionDetail.coverperiodFrom = detail.coverperiodFrom;
        transactionDetail.coverperiodTo = detail.coverperiodTo;
        transactionDetail.instructionLineItemType = detail.iliType;
        transactionDetail.instructLineItemCategory = detail.iliCategory;

        transactionDetail.deductedAmount = new Money(0);
        transactionDetail.relatedReference = detail.relatedReference;
        transactionDetail.productType = getProductType(detail.caseID);
        // BEGIN, CR00250182, PF
        // The amount has to be retrieved from the ILI, because where the
        // payment has been rolled up the amount on the financial/payment
        // instruction will be the total for all the ILIs issued.
        // InstructionLineItem instructionLineItemObj =
        // InstructionLineItemFactory.newInstance();
        InstructionLineItemKey instructionLineItemKey = new InstructionLineItemKey();

        instructionLineItemKey.instructLineItemID = detail.instructionLineItemID;
        InstructionLineItemDtls instructionLineItemDtls = instructionLineItemObj.read(
          instructionLineItemKey);

        transactionDetail.amount = instructionLineItemDtls.amount;
        // BEGIN, CR00291780, GP
        transactionDetail.breakdownDispIndOpt = true;
        // END, CR00291780

        if (ILITYPE.BENEFITOVERPAYMENT.equals(
          transactionDetail.instructionLineItemType)) {
          transactionDetail.paymentTypeCode = PAYMENTTYPES.OVERPAYMENT;
        } else if (ILITYPE.BENEFITUNDERPAYMENT.equals(
          transactionDetail.instructionLineItemType)) {
          transactionDetail.paymentTypeCode = PAYMENTTYPES.UNDERPAYMENT;
        } else {
          transactionDetail.paymentTypeCode = PAYMENTTYPES.PAYMENT;
        }
        details.dtls.addRef(transactionDetail);
      }
    } // END, CR00250182
    else {

      ViewFinancialTransactionDetail transactionDetail;

      for (final InstructionLineItemDtls instructionLineItemDtls : instructionLineItemDtlsList.dtls) {
        caseIDKey.caseID = instructionLineItemDtls.caseID;
        CaseHomePageNameAndType caseHomePageNameAndType = productDeliveryObj.readCaseHomePageNameAndType(
          caseIDKey);

        if (!PRODUCTTYPE.PAYMENTCORRECTION.equals(
          caseHomePageNameAndType.typeCode)) {

          transactionDetail = new ViewFinancialTransactionDetail();

          transactionDetail.ILIID = instructionLineItemDtls.instructLineItemID;
          transactionDetail.coverperiodFrom = instructionLineItemDtls.coverPeriodFrom;
          transactionDetail.coverperiodTo = instructionLineItemDtls.coverPeriodTo;
          transactionDetail.instructionLineItemType = instructionLineItemDtls.instructionLineItemType;
          transactionDetail.instructLineItemCategory = instructionLineItemDtls.instructLineItemCategory;
          transactionDetail.deductedAmount = new Money(0);
          transactionDetail.productType = getProductType(
            instructionLineItemDtls.caseID);
          transactionDetail.amount = instructionLineItemDtls.amount;
          // BEGIN, CR00291780, GP
          transactionDetail.breakdownDispIndOpt = false;
          // END, CR00291780

          if (ILITYPE.BENEFITOVERPAYMENT.equals(
            transactionDetail.instructionLineItemType)) {
            transactionDetail.paymentTypeCode = PAYMENTTYPES.OVERPAYMENT;
          } else if (ILITYPE.BENEFITUNDERPAYMENT.equals(
            transactionDetail.instructionLineItemType)) {
            transactionDetail.paymentTypeCode = PAYMENTTYPES.UNDERPAYMENT;
          } else {
            transactionDetail.paymentTypeCode = PAYMENTTYPES.PAYMENT;
          }

          details.dtls.addRef(transactionDetail);
        }
      }
    }
    // END, CR00282068
    // END, CR00280674

  }

  // END, CR00229264
  /**
   * This method re assesses the existing providers with the new or modified
   * frequency
   *
   * @param details
   * - PlacementFrequencyDetails
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void reAssessExistingProvidersForNewFrequency(
    // END, CR00177241
    PlacementFrequencyDetails details) throws AppException,
      InformationalException {

    // Get all the providers
    Set<curam.provider.impl.Provider> providers = providerDAO.readAll();
    ProductDelivery placementProductDelivery = ProductDeliveryFactory.newInstance();

    for (curam.provider.impl.Provider provider : providers) {

      // Filter providers and select only providers that have placements
      ProductDeliveryTypeClientIDIn productDeliveryTypeClientIDIn = new ProductDeliveryTypeClientIDIn();

      productDeliveryTypeClientIDIn.recipConcernRoleID = provider.getID();
      productDeliveryTypeClientIDIn.productType = curam.codetable.PRODUCTTYPE.PROVIDERPLACEMENT;

      ProductDeliveryDtlsList productDeliveryDtlsList = placementProductDelivery.searchByTypeClientID(
        productDeliveryTypeClientIDIn);

      for (ProductDeliveryDtls productDeliveryDtls : productDeliveryDtlsList.dtls.items()) {

        boolean bCanModifyInd = true;
        Date dueDate = TransactionInfo.getSystemDate();

        // Get the ILI to see till when the payments are paid out
        InstructionLineItem instructionLineItem = InstructionLineItemFactory.newInstance();
        CaseAndConcernRoleKey caseAndConcernRoleKey = new CaseAndConcernRoleKey();

        caseAndConcernRoleKey.caseID = productDeliveryDtls.caseID;
        caseAndConcernRoleKey.concernRoleID = provider.getID();
        caseAndConcernRoleKey.statusCode = ILISTATUS.PROCESSED;
        ILIEffectiveDate lastPaymentDateForProcessedILIs = instructionLineItem.readLastPaymentDate(
          caseAndConcernRoleKey);

        caseAndConcernRoleKey.statusCode = ILISTATUS.UNPROCESSED;
        ILIEffectiveDate lastPaymentDateForUnProcessedILIs = instructionLineItem.readLastPaymentDate(
          caseAndConcernRoleKey);

        if (!lastPaymentDateForProcessedILIs.effectiveDate.isZero()) {
          if (dueDate.before(lastPaymentDateForProcessedILIs.effectiveDate)) {
            dueDate = lastPaymentDateForProcessedILIs.effectiveDate;
          }
        }

        if (!lastPaymentDateForUnProcessedILIs.effectiveDate.isZero()) {
          if (dueDate.before(lastPaymentDateForUnProcessedILIs.effectiveDate)) {
            dueDate = lastPaymentDateForUnProcessedILIs.effectiveDate;
          }
        }

        if (dueDate.after(details.effectiveDate)) {
          bCanModifyInd = false;
        }

        if (!bCanModifyInd) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            PLACEMENTExceptionCreator.ERR_PLACEMENT_XRV_PLACEMENT_FREQUENCY_CANNOT_BE_CHANGED(
              dueDate),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);

          ValidationHelper.failIfErrorsExist();
        }

        // Create new delivery pattern
        ProductDeliveryPatternDtls newProductDeliveryPatternDtls = createProductDeliveryPatternForProvider(
          provider, getProduct(), details.frequencyPattern);

        // Update the previous Delivery pattern details
        MaintainProductDelivery productDelivery = MaintainProductDeliveryFactory.newInstance();
        UpdateProductDeliveryPatternKey deliveryPatternKey = new UpdateProductDeliveryPatternKey();

        deliveryPatternKey.caseID = productDeliveryDtls.caseID;
        deliveryPatternKey.effectiveDate = details.effectiveDate;
        deliveryPatternKey.productDeliveryPatternID = newProductDeliveryPatternDtls.productDeliveryPatternID;
        productDelivery.updateProductDeliveryPattern(deliveryPatternKey);

      }
    }
  }

  /**
   * Searches the payment instruments for a provider/provider group based on the
   * product delivery type.
   *
   * @param productDeliveryType
   * Contains the product delivery type.
   * @param provider
   * The provider for whom the payments are retrieved.
   * @param isGroupToReceivePayments
   * Indicates whether provider group has received the payments on
   * behalf of provider.
   *
   * @return The list of payment instruments matching the search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected PaymentInstrumentDtlsList searchFinancialsForProvOrgProductDeliveryType(
    final String productDeliveryType,
    final curam.provider.impl.Provider provider,
    final boolean isGroupToReceivePayments) throws AppException,
      InformationalException {

    PaymentInstrumentDtlsList paymentInstrumentDtlsList = new PaymentInstrumentDtlsList();
    ProductDeliveryTypeClientIDIn productDeliveryTypeClientIDIn = new ProductDeliveryTypeClientIDIn();
    ProductDelivery productDelivery = ProductDeliveryFactory.newInstance();
    CaseNomineeKey caseNomineeKey = new CaseNomineeKey();
    CaseNominee caseNominee = CaseNomineeFactory.newInstance();
    curam.cpm.sl.entity.intf.Provider providerObj = ProviderFactory.newInstance();
    CaseRelationship caseRelationshipObj = CaseRelationshipFactory.newInstance();
    NOMINEERELATIONSHIPEntry nomineeRelationship;

    if (!isGroupToReceivePayments) {

      nomineeRelationship = NOMINEERELATIONSHIPEntry.SELF;
    } else {

      nomineeRelationship = NOMINEERELATIONSHIPEntry.PROVIDERGROUP;
    }

    productDeliveryTypeClientIDIn.recipConcernRoleID = provider.getID();
    productDeliveryTypeClientIDIn.productType = productDeliveryType;

    ProductDeliveryDtlsList productDeliveryDtlsList = productDelivery.searchByTypeClientID(
      productDeliveryTypeClientIDIn);

    for (final ProductDeliveryDtls productDeliveryDtls : productDeliveryDtlsList.dtls.items()) {

      CaseNomineeCaseIDKey caseNomineeCaseIDKey = new CaseNomineeCaseIDKey();

      caseNomineeCaseIDKey.caseID = productDeliveryDtls.caseID;
      CaseNomineeForCaseDetailsList caseNomineeForCaseDetailsList = caseNominee.searchByCaseID(
        caseNomineeCaseIDKey);

      for (final CaseNomineeForCaseDetails caseNomineeForCaseDetails : caseNomineeForCaseDetailsList.dtls.items()) {

        if (caseNomineeForCaseDetails.nomineeRelationship.equals(
          nomineeRelationship.getCode())) {

          caseNomineeKey.caseNomineeID = caseNomineeForCaseDetails.caseNomineeID;
          PaymentInstrumentDtlsList instrumentDtlsList = providerObj.searchPaymentInstrumentByCaseNominee(
            caseNomineeKey);

          for (final PaymentInstrumentDtls paymentInstrumentDtls : instrumentDtlsList.dtls.items()) {
            paymentInstrumentDtls.caseNomineeID = caseNomineeForCaseDetails.caseNomineeID;
            paymentInstrumentDtlsList.dtls.addRef(paymentInstrumentDtls);
          }
        }
      }

      CaseRelationshipRelatedCaseIDKey relatedCaseIDKey = new CaseRelationshipRelatedCaseIDKey();

      relatedCaseIDKey.relatedCaseID = productDeliveryDtls.caseID;
      CaseRelationshipDtlsList relationshipDtlsList = caseRelationshipObj.searchByRelatedCaseID(
        relatedCaseIDKey);

      for (final CaseRelationshipDtls caseRelationshipDtls : relationshipDtlsList.dtls.items()) {

        ProductDeliveryKey deliveryKey = new ProductDeliveryKey();

        deliveryKey.caseID = caseRelationshipDtls.caseID;
        ProductDeliveryDtls deliveryDtls = productDelivery.read(deliveryKey);

        if (deliveryDtls.categoryCode.equals(PRODUCTDELIVERYCATEGORYEntry.CLAIM)) {

          caseNomineeCaseIDKey.caseID = deliveryDtls.caseID;
          caseNomineeForCaseDetailsList = caseNominee.searchByCaseID(
            caseNomineeCaseIDKey);

          for (final CaseNomineeForCaseDetails caseNomineeForCaseDetails : caseNomineeForCaseDetailsList.dtls.items()) {

            if (caseNomineeForCaseDetails.nomineeRelationship.equals(
              nomineeRelationship)) {

              caseNomineeKey.caseNomineeID = caseNomineeForCaseDetails.caseNomineeID;
              PaymentInstrumentDtlsList instrumentDtlsList = providerObj.searchPaymentInstrumentByCaseNominee(
                caseNomineeKey);

              for (final PaymentInstrumentDtls paymentInstrumentDtls : instrumentDtlsList.dtls.items()) {
                paymentInstrumentDtls.caseNomineeID = caseNomineeForCaseDetails.caseNomineeID;
                paymentInstrumentDtlsList.dtls.addRef(paymentInstrumentDtls);
              }
            }
          }
        }
      }
    }

    return paymentInstrumentDtlsList;
  }

  /**
   * This method is to set the RetrievePaymentHistoryDetails object from the
   * PaymentInstrumentDtls
   *
   * @param paymentInstrumentDtls
   * - PaymentInstrumentDtls
   * @return RetrievePaymentHistoryDetails
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected RetrievePaymentHistoryDetails setRetrievePaymentHistoryDetails(
    // END, CR00177241
    PaymentInstrumentDtls paymentInstrumentDtls) throws AppException,
      InformationalException {
    RetrievePaymentHistoryDetails retrievePaymentHistoryDetails = new RetrievePaymentHistoryDetails();

    ProductDeliveryDtls deliveryDtls = getProductDeliveryDetails(
      paymentInstrumentDtls);

    retrievePaymentHistoryDetails.creationDate = paymentInstrumentDtls.creationDate;
    retrievePaymentHistoryDetails.amount = paymentInstrumentDtls.amount;
    retrievePaymentHistoryDetails.paymentType = deliveryDtls.productType;
    retrievePaymentHistoryDetails.status = paymentInstrumentDtls.reconcilStatusCode;
    retrievePaymentHistoryDetails.currency = paymentInstrumentDtls.currencyTypeCode;
    retrievePaymentHistoryDetails.pmtInstrumentID = paymentInstrumentDtls.pmtInstrumentID;
    retrievePaymentHistoryDetails.instructionLineItemID = getInstructionLineItem(
      paymentInstrumentDtls.pmtInstrumentID);
    return retrievePaymentHistoryDetails;
  }

  /**
   * Sorts a set of placement Payment Frequency in ascending order based on
   * effective date
   *
   * @param placementPaymentFrequencyArray
   * the set of placement Payment Frequency
   */

  protected void sortPlacementPaymentFrequencyArray(
    // END, CR00177241
    PlacementPaymentFrequency[] placementPaymentFrequencyArray) {

    // Sort the frequencies in the ascending order by effective date
    Arrays.sort(placementPaymentFrequencyArray,
      new Comparator<PlacementPaymentFrequency>() {
      public int compare(final PlacementPaymentFrequency lhs,
        PlacementPaymentFrequency rhs) {
        return lhs.getEffectiveDate().compareTo(rhs.getEffectiveDate());
      }
    });
  }
}
