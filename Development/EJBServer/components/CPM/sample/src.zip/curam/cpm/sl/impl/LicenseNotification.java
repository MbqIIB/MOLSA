/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.sl.impl;


import java.io.ByteArrayOutputStream;

import com.google.inject.Inject;

import curam.codetable.COMMUNICATIONFORMAT;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONSTATUS;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.codetable.impl.CMISNAMINGTYPEEntry;
import curam.codetable.impl.CMSLINKRELATEDTYPEEntry;
import curam.core.fact.ConcernRoleCommunicationFactory;
import curam.core.fact.ConcernRoleDocumentsFactory;
import curam.core.fact.OrganisationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.EnvVars;
import curam.core.intf.ConcernRoleCommunication;
import curam.core.intf.ConcernRoleDocuments;
import curam.core.intf.Organisation;
import curam.core.intf.SystemUser;
import curam.core.intf.UniqueID;
import curam.core.sl.infrastructure.cmis.impl.CMISAccessInterface;
import curam.core.sl.struct.DataSetData;
import curam.core.sl.struct.GenerateDocumentDetailsLocal;
import curam.core.sl.struct.LanguageLocaleMapDetails;
import curam.core.struct.ConcernRoleCommunicationDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.OrganisationID;
import curam.core.struct.OrganisationKey;
import curam.core.struct.OrganisationNameAndAddressDetails;
import curam.core.struct.SystemUserDtls;
import curam.cpm.facade.struct.LicenseDocumentKey;
import curam.cpm.facade.struct.LicenseNotificationDetails;
import curam.cpm.facade.struct.LicenseNotificationKey;
import curam.cpm.impl.CPMConstants;
import curam.message.BPOPROFORMADOCUMENTGENERATION;
import curam.message.GENERALCONCERN;
import curam.provider.LicenseNotificationEvent;
import curam.provider.LicenseRejectionReason;
import curam.provider.LicenseSuspensionReason;
import curam.provider.impl.CommunicationLicenseLink;
import curam.provider.impl.CommunicationLicenseLinkDAO;
import curam.provider.impl.License;
import curam.provider.impl.LicenseDAO;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.internal.xml.fact.XSLTemplateFactory;
import curam.util.internal.xml.intf.XSLTemplate;
import curam.util.internal.xml.struct.XSLTemplateDtls;
import curam.util.internal.xml.struct.XSLTemplateKey;
import curam.util.message.CURAMXML;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.Locale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.impl.XMLDocument;
import curam.util.xml.impl.XMLEncodingConstants;
import curam.util.xml.impl.XMLPrintStream;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;


/**
 * This class holds the API for sending the license notifications.
 */
public class LicenseNotification {
  
  // BEGIN, CR00292749, MR
  /**
   * Reference to CMIS Access Interface.
   */
  @Inject
  protected CMISAccessInterface cmisAccessInterface;
  // END, CR00292749
    
  
  // BEGIN, CR00281474, MR
  /**
   * Reference to license DAO.
   */
  @Inject
  protected LicenseDAO licenseDAO;

  /**
   * Reference to communication license link DAO.
   */
  @Inject
  protected CommunicationLicenseLinkDAO communicationLicenseLinkDAO;

  /**
   * Default Constructor.
   */
  public LicenseNotification() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00281474

  
  /**
   * Sends the notifications by either using the XSL or XML templates for a
   * particular event.
   * <p>
   * Notification events include license approval, suspension, rejection and
   * renewal.
   *
   * @param key the License notification key
   * @param license the license details
   * @throws InformationalException
   * @throws AppException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public void sendNotification(LicenseNotificationKey key,
    curam.provider.impl.License license) throws AppException,
      InformationalException {

    DataSetData dataSetData = new DataSetData();
    final LicenseDocumentKey licenseDocumentKey = new LicenseDocumentKey();

    dataSetData = generateDocument(license);

    // approve license
    if (key.event.equals(LicenseNotificationEvent.APPROVELICENSE)) {

      licenseDocumentKey.licenseDocumentType = TEMPLATEIDCODE.LICENSEAPPROVALNOTIFICATION;
      createDocumentFromDetails(dataSetData, licenseDocumentKey, license);

    } // suspend license
    else if (key.event.equals(LicenseNotificationEvent.SUSPENDLICENSE)) {

      licenseDocumentKey.licenseDocumentType = TEMPLATEIDCODE.LICENSESUSPENSIONNOTIFICATION;
      createDocumentFromDetails(dataSetData, licenseDocumentKey, license);

    } // reject license
    else if (key.event.equals(LicenseNotificationEvent.REJECTLICENSE)) {

      licenseDocumentKey.licenseDocumentType = TEMPLATEIDCODE.LICENSEREJECTIONNOTIFICATION;
      createDocumentFromDetails(dataSetData, licenseDocumentKey, license);

    } // renew license
    else if (key.event.equals(LicenseNotificationEvent.RENEWLICENSE)) {

      licenseDocumentKey.licenseDocumentType = TEMPLATEIDCODE.LICENSERENEWALNOTIFICATION;
      createDocumentFromDetails(dataSetData, licenseDocumentKey, license);

    }
  }

  // BEGIN, CR00281474, MR
  /**
   * Reads the license notification details.
   *
   * @param license Contains the license details.
   *
   * @return The license notification details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  public LicenseNotificationDetails getLicenseDetails(
    final curam.provider.impl.License license) throws AppException,
      InformationalException {
    // END, CR00281474
    // END, CR00177241

    final LicenseNotificationDetails licenseNotificationDetails = new LicenseNotificationDetails();

    final OrganisationNameAndAddressDetails organisationNameAndAddressDetails = getOrganisationDetails();

    licenseNotificationDetails.organizationName = organisationNameAndAddressDetails.name;
    licenseNotificationDetails.providerName = license.getProvider().getName();

    licenseNotificationDetails.eventDate = Locale.getFormattedDate(
      Date.getCurrentDate(), Locale.Date_mdy_ext);

    // translate codes for template display
    licenseNotificationDetails.rejectionReason = curam.util.type.CodeTable.getOneItemForUserLocale(
      LicenseRejectionReason.TABLENAME, license.getRejectionReason().getCode());
    licenseNotificationDetails.suspensionReason = curam.util.type.CodeTable.getOneItemForUserLocale(
      LicenseSuspensionReason.TABLENAME,
      license.getSuspensionReason().getCode());
    licenseNotificationDetails.expirationDate = Locale.getFormattedDate(
      license.getDateRange().end(), Locale.Date_mdy_ext);

    return licenseNotificationDetails;
  }

  /**
   * Generates the notification document.
   *
   * @param license the license details
   * @return the data generated for the document.
   * @throws InformationalException
   * @throws AppException
   */
  public DataSetData generateDocument(curam.provider.impl.License license)
    throws AppException, InformationalException {

    final DataSetData dataSetData = new DataSetData();

    final LicenseNotificationDetails licenseNotificationDetails = getLicenseDetails(
      license);

    // Add all the receipt data to XML document object
    final XMLDocument documentObj = new XMLDocument(
      XMLEncodingConstants.kEncodeUTF8);

    documentObj.add(licenseNotificationDetails);

    // Retrieve XML stream for data set and return
    dataSetData.dataSetData = documentObj.toString();

    return dataSetData;
  }

  // BEGIN, CR00292749, MR
  /**
   * Generates an XML document from the specified XSL template and prints that
   * document. It also inserts license communication and stores the document
   * content to the content management system.
   *
   * @param dataSetData
   * Contains the data to be entered into the document.
   * @param key
   * Contains the document type.
   * @param license
   * Contains the details of the license.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  // END, CR00292749
  public void createDocumentFromDetails(DataSetData dataSetData,
    LicenseDocumentKey key, curam.provider.impl.License license)
    throws AppException, InformationalException {

    // BEGIN, CR00178508, SK
    final long concernRoleID = license.getProvider().getID();
    final ConcernRoleDocuments concernRoleDocumentsObj = ConcernRoleDocumentsFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = concernRoleID;

    // Get the locale information
    final LanguageLocaleMapDetails languageLocaleMapDetails = concernRoleDocumentsObj.getLocaleInfo(
      concernRoleKey);
    // END, CR00178508
    // XSLTemplate objects
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    // Document details
    final GenerateDocumentDetailsLocal generateDocumentDetailsLocal = new GenerateDocumentDetailsLocal();

    // Set code key
    xslTemplateIDCodeKey.templateIDCode = key.licenseDocumentType;

    // Read template details
    final XSLTemplateUtility xslTemplateUtilityObj = XSLTemplateUtilityFactory.newInstance();

    // BEGIN, CR00178508, SK
    xslTemplateIDCodeKey.localeIdentifier = languageLocaleMapDetails.dtls.localeIdentifier;

    XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    try {
      xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);
    } catch (final RecordNotFoundException recordNotFoundException) {
      final AppException appException = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE);
      final String codeItemDescription = CodeTable.getOneItem(
        TEMPLATEIDCODE.TABLENAME, xslTemplateIDCodeKey.templateIDCode,
        TransactionInfo.getProgramLocale());

      appException.arg(codeItemDescription);
      throw appException;
    }
    // END, CR00178508
    // Set document details
    generateDocumentDetailsLocal.dataSetData = dataSetData.dataSetData;
    generateDocumentDetailsLocal.documentID = xslTemplateInstanceKey.templateID;
    generateDocumentDetailsLocal.documentVersion = xslTemplateInstanceKey.templateVersion;

    // Generate the specified document
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // BEGIN, CR00235681, PM
    // Create XMLPrintStream object
    final XMLPrintStream printStreamObj = new XMLPrintStream();

    // END, CR00235681

    // BEGIN, CR00408986, KRK
    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS_DEFAULT))) {
      // open print stream
      try {
        // BEGIN, CR00235681, PM
        printStreamObj.open(xslTemplateInstanceKey);
        // END, CR00235681


      } catch (final AppException ex) {

        // an error occurred - was the document not in valid XML format?
        if (ex.getCatEntry().equals(CURAMXML.ERR_PRINT_STREAM_BAD_RESPONSE)) {

          // the pro-forma form is not a valid XML document -
          // convert this to a more meaningful message for the user
          throw new AppException(
            BPOPROFORMADOCUMENTGENERATION.ERR_INVALID_FORMAT_NOT_PRINTABLE, ex);

        } else {

          // we can't do anything with it -
          // just pass it on up to the calling method
          throw ex;

        }
      }

      final XMLDocument documentObj = new XMLDocument(
        printStreamObj.getStream(), XMLEncodingConstants.kEncodeUTF8);

      // Set data to print the document
      systemUserDtls = systemUserObj.getUserDetails();
      final String userName = systemUserDtls.userName;
      final String generatedDate = curam.util.type.Date.getCurrentDate().toString();
      final String versionNo = String.valueOf(
        xslTemplateInstanceKey.templateVersion);
      final String comments = "";

      // Open document
      documentObj.open(userName, generatedDate, versionNo, comments);

      // Add data to document
      documentObj.addFromXML(dataSetData.dataSetData);

      // Close document and print stream objects
      documentObj.close();
      printStreamObj.close();      
    }
    // END, CR00408986

    // BEGIN, CR00292749, MR
    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls = insertLicenseCommunication(
      license, key);
    
    storeDocumentContent(concernRoleCommunicationDtls, xslTemplateInstanceKey,
      dataSetData);
    // END, CR00292749
  }

  // BEGIN, CR00292749, MR
  /**
   * Stores the document content to the content management system.
   *
   * @param concernRoleCommunicationDtls
   * Contains the details of the communication.
   * @param xslTemplateInstanceKey
   * Contains key to a stored XSL template.
   * @param dataSetData
   * Contains the data to be entered into the document.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void storeDocumentContent(
    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls,
    final XSLTemplateInstanceKey xslTemplateInstanceKey,
    final DataSetData dataSetData) throws AppException,
      InformationalException {

    // BEGIN, CR00408986, KRK
    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS_DEFAULT))) {
      if (COMMUNICATIONSTATUS.SENT.equals(
        concernRoleCommunicationDtls.communicationStatus)
          && cmisAccessInterface.isCMISEnabledFor(
            CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {
        final XMLPrintStream xmlPrintStreamObj = new XMLPrintStream();
        final ByteArrayOutputStream byteArrayOutputStreamObj = new ByteArrayOutputStream();

        xmlPrintStreamObj.setPreviewStream(byteArrayOutputStreamObj);

        try {
          xmlPrintStreamObj.open(xslTemplateInstanceKey);
        } catch (AppException e) {

          if (e.getCatEntry().equals(CURAMXML.ERR_PRINT_STREAM_BAD_RESPONSE)) {
            throw new AppException(
              BPOPROFORMADOCUMENTGENERATION.ERR_INVALID_FORMAT_NOT_PRINTABLE, e);
          } else {

            // We can't do anything with it -
            // just pass it on up to the calling method.
            throw e;
          }
        }

        XMLDocument xmlDocumentObj = new XMLDocument(
          xmlPrintStreamObj.getStream(), XMLEncodingConstants.kEncodeUTF8);

        xmlDocumentObj.open(
          SystemUserFactory.newInstance().getUserDetails().userName,
          Date.getCurrentDate().toString(),
          String.valueOf(xslTemplateInstanceKey.templateVersion),
          concernRoleCommunicationDtls.comments);
        xmlDocumentObj.addFromXML(dataSetData.dataSetData);
        xmlDocumentObj.close();
        xmlPrintStreamObj.close();

        StringBuilder fileName = new StringBuilder();

        fileName.append(concernRoleCommunicationDtls.subjectText);
        fileName.append(CPMConstants.kpdfExtension);

        // Save the contents to the content management system.
        cmisAccessInterface.create(concernRoleCommunicationDtls.communicationID,
          CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION,
          byteArrayOutputStreamObj.toByteArray(), fileName.toString(),
          CMISNAMINGTYPEEntry.PROFORMA_GENERIC, null);
      }
      // END, CR00408986      
    }   
  } 

  // END, CR00292749
  
  
  
  // BEGIN, CR00292749, MR
  /**
   * Inserts the communication details for a new communication.
   *
   * @param license
   * Contains the details of the license.
   * @param key
   * Key that contains the license document type.
   *
   * @throws AppException
   * Generic Exception Signature.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced by
   * {@link #insertLicenseCommunication(License, LicenseDocumentKey)}
   * . This method is deprecated because it is not returning
   * concern role communication details which is required while
   * storing the document content to the content management
   * system. See release note: CR00292749.
   */
  @Deprecated
  
  // END, CR00292749
  public void insertCommunication(curam.provider.impl.License license,
    LicenseDocumentKey key) throws AppException, InformationalException {

    // based on domain CURAM_DATE
    final Date currentDate = Date.getCurrentDate();

    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // BEGIN, CR00178508, SK
    final long concernRoleID = license.getProvider().getID();
    final curam.core.intf.ConcernRoleDocuments concernRoleDocumentsObj = curam.core.fact.ConcernRoleDocumentsFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = concernRoleID;

    // Get the locale information.
    final LanguageLocaleMapDetails languageLocaleMapDetails = concernRoleDocumentsObj.getLocaleInfo(
      concernRoleKey);

    // END, CR00178508
    // ConcernRoleComm manipulation variables
    final ConcernRoleCommunication concernRoleCommunicationObj = ConcernRoleCommunicationFactory.newInstance();
    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls = new ConcernRoleCommunicationDtls();

    long concernRoleCommunicationID = 0;

    // XSLTemplate manipulation variables.
    final XSLTemplate xslTemplateObj = XSLTemplateFactory.newInstance();
    final XSLTemplateKey xslTemplateKey = new XSLTemplateKey();
    XSLTemplateDtls xslTemplateDtls;

    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    final XSLTemplateUtility xslTemplateUtilityObj = XSLTemplateUtilityFactory.newInstance();

    // Generate unique id for ConcernRoleCommunication.
    concernRoleCommunicationID = uniqueIDObj.getNextID();

    concernRoleCommunicationDtls.attachmentInd = false;

    concernRoleCommunicationDtls.typeCode = COMMUNICATIONTYPE.LETTER;

    concernRoleCommunicationDtls.communicationID = concernRoleCommunicationID;
    concernRoleCommunicationDtls.statusCode = RECORDSTATUS.NORMAL;

    concernRoleCommunicationDtls.proFormaInd = true;

    // BEGIN, CR00178508, SK
    xslTemplateIDCodeKey.localeIdentifier = languageLocaleMapDetails.dtls.localeIdentifier;

    xslTemplateIDCodeKey.templateIDCode = key.licenseDocumentType;
    try {
      xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);
    } catch (final RecordNotFoundException recordNotFoundException) {
      final AppException appException = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE);
      final String codeItemDescription = CodeTable.getOneItem(
        TEMPLATEIDCODE.TABLENAME, xslTemplateIDCodeKey.templateIDCode,
        TransactionInfo.getProgramLocale());

      appException.arg(codeItemDescription);
      throw appException;
    }
    // Copy the proforma document type to the subject
    xslTemplateKey.templateID = xslTemplateInstanceKey.templateID;

    xslTemplateKey.localeIdentifier = xslTemplateInstanceKey.locale;
    // END, CR00178508

    try {
      xslTemplateDtls = xslTemplateObj.read(xslTemplateKey);
    } catch (final RecordNotFoundException e) {
      xslTemplateDtls = null;
    }

    if (xslTemplateDtls != null) {
      concernRoleCommunicationDtls.subjectText = xslTemplateDtls.templateName;
    } else {
      final AppException e = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE);

      e.arg(xslTemplateInstanceKey.templateID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 9);
    }

    final SystemUser user = SystemUserFactory.newInstance();

    concernRoleCommunicationDtls.concernRoleID = license.getProvider().getID();
    concernRoleCommunicationDtls.proFormaVersionNo = xslTemplateInstanceKey.templateVersion;
    concernRoleCommunicationDtls.userName = user.getUserDetails().userName;
    concernRoleCommunicationDtls.correspondentConcernRoleID = license.getProvider().getID();

    concernRoleCommunicationDtls.addressID = license.getProvider().getPrimaryAddressID();
    concernRoleCommunicationDtls.correspondentName = license.getProvider().getName();
    concernRoleCommunicationDtls.communicationDate = currentDate;
    concernRoleCommunicationDtls.communicationStatus = COMMUNICATIONSTATUS.SENT;
    concernRoleCommunicationDtls.communicationFormat = COMMUNICATIONFORMAT.PROFORMA;
    concernRoleCommunicationDtls.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
    concernRoleCommunicationDtls.correspondentTypeCode = CORRESPONDENT.CLIENT;
    concernRoleCommunicationDtls.documentTemplateID = xslTemplateIDCodeKey.templateIDCode;
    // BEGIN, CR00178508, SK
    concernRoleCommunicationDtls.localeIdentifier = xslTemplateIDCodeKey.localeIdentifier;
    // END, CR00178508
    // Insert new communication entry
    concernRoleCommunicationObj.insert(concernRoleCommunicationDtls);
    
    // BEGIN, CR00281474, MR
    createCommunicationLicenseLink(concernRoleCommunicationDtls.communicationID,
      license.getID());
    // END, CR00281474
  }
  
  // BEGIN, CR00292749, MR
  /**
   * Inserts the license communication details for a new communication.
   *
   * @param license
   * Contains the details of the license
   * @param licenseDocumentKey
   * Contains the license document type.
   *
   * @return Details of concern role communication.
   *
   * @throws AppException
   * {@link curam.message.GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE}
   * - If the pro forma template is not found.
   * @throws AppException
   * {@link curam.message.GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE}
   * - If the pro forma template ID is not found.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ConcernRoleCommunicationDtls insertLicenseCommunication(
    final curam.provider.impl.License license,
    final LicenseDocumentKey licenseDocumentKey) throws AppException,
      InformationalException {
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = license.getProvider().getID();

    final LanguageLocaleMapDetails languageLocaleMapDetails = ConcernRoleDocumentsFactory.newInstance().getLocaleInfo(
      concernRoleKey);

    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls = new ConcernRoleCommunicationDtls();

    concernRoleCommunicationDtls.attachmentInd = false;
    concernRoleCommunicationDtls.typeCode = COMMUNICATIONTYPE.LETTER;
    concernRoleCommunicationDtls.communicationID = UniqueIDFactory.newInstance().getNextID();
    concernRoleCommunicationDtls.statusCode = RECORDSTATUS.NORMAL;
    concernRoleCommunicationDtls.proFormaInd = true;

    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.localeIdentifier = languageLocaleMapDetails.dtls.localeIdentifier;
    xslTemplateIDCodeKey.templateIDCode = licenseDocumentKey.licenseDocumentType;

    XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    try {
      xslTemplateInstanceKey = XSLTemplateUtilityFactory.newInstance().getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);
    } catch (final RecordNotFoundException e) {
      final AppException appException = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE);
      final String codeItemDescription = CodeTable.getOneItem(
        TEMPLATEIDCODE.TABLENAME, xslTemplateIDCodeKey.templateIDCode,
        TransactionInfo.getProgramLocale());

      appException.arg(codeItemDescription);
      throw appException;
    }

    final XSLTemplateKey xslTemplateKey = new XSLTemplateKey();

    xslTemplateKey.templateID = xslTemplateInstanceKey.templateID;
    xslTemplateKey.localeIdentifier = xslTemplateInstanceKey.locale;

    XSLTemplateDtls xslTemplateDtls = new XSLTemplateDtls();

    try {
      xslTemplateDtls = XSLTemplateFactory.newInstance().read(xslTemplateKey);
    } catch (final RecordNotFoundException e) {
      xslTemplateDtls = null;
    }

    if (null != xslTemplateDtls) {
      concernRoleCommunicationDtls.subjectText = xslTemplateDtls.templateName;
    } else {
      final AppException e = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE);

      e.arg(xslTemplateInstanceKey.templateID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 8);
    }

    concernRoleCommunicationDtls.concernRoleID = license.getProvider().getID();
    concernRoleCommunicationDtls.proFormaVersionNo = xslTemplateInstanceKey.templateVersion;
    concernRoleCommunicationDtls.userName = SystemUserFactory.newInstance().getUserDetails().userName;
    concernRoleCommunicationDtls.correspondentConcernRoleID = license.getProvider().getID();
    concernRoleCommunicationDtls.addressID = license.getProvider().getPrimaryAddressID();
    concernRoleCommunicationDtls.correspondentName = license.getProvider().getName();
    concernRoleCommunicationDtls.communicationDate = Date.getCurrentDate();
    concernRoleCommunicationDtls.communicationStatus = COMMUNICATIONSTATUS.SENT;
    concernRoleCommunicationDtls.communicationFormat = COMMUNICATIONFORMAT.PROFORMA;
    concernRoleCommunicationDtls.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
    concernRoleCommunicationDtls.correspondentTypeCode = CORRESPONDENT.CLIENT;
    concernRoleCommunicationDtls.documentTemplateID = xslTemplateIDCodeKey.templateIDCode;
    concernRoleCommunicationDtls.localeIdentifier = xslTemplateIDCodeKey.localeIdentifier;
    ConcernRoleCommunicationFactory.newInstance().insert(
      concernRoleCommunicationDtls);

    createCommunicationLicenseLink(concernRoleCommunicationDtls.communicationID,
      license.getID());
    return concernRoleCommunicationDtls;
  }

  // END, CR00292749

  
  /**
   * Returns the organization name and address.
   * <p>
   * By default there is one organization and function fetches the name of
   * that from database.
   *
   * @return the organization name and the address details.
   * @throws InformationalException
   * @throws AppException
   */

  // BEGIN, CR00177241, PM
  protected OrganisationNameAndAddressDetails getOrganisationDetails()
    throws AppException, InformationalException {
    // END, CR00177241
    final Organisation organisation = OrganisationFactory.newInstance();
    final OrganisationID organisationID = organisation.readOrganisationID();
    final OrganisationKey organisationKey = new OrganisationKey();

    organisationKey.organisationID = organisationID.organisationID;
    final OrganisationNameAndAddressDetails details = organisation.readNameAndAddress(
      organisationKey);

    return details;
  }

  // BEGIN, CR00281474, MR
  /**
   * Creates an association between communication and license.
   *
   * @param communicationID
   * Contains concern role communication ID for which notification is created.
   * @param licenseID
   * Contains license associated with communication.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void createCommunicationLicenseLink(
    final long communicationID,
    final long licenseID) throws AppException, InformationalException {
    final CommunicationLicenseLink communicationLicenseLink = communicationLicenseLinkDAO.newInstance();

    communicationLicenseLink.setCommunicationID(communicationID);
    final License license = licenseDAO.get(licenseID);

    communicationLicenseLink.setLicense(license);
    communicationLicenseLink.insert();
  }
  // END, CR00281474
}
