/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.sl.impl;


import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.INFORMATIONPROVIDERTYPE;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.INFORMATIONPROVIDERTYPEEntry;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.fact.AddressFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EmployerSearch;
import curam.core.impl.PersonSearch;
import curam.core.intf.Address;
import curam.core.intf.ConcernRole;
import curam.core.sl.struct.AllParticipantSearchDetails;
import curam.core.sl.struct.AllParticipantSearchDtls;
import curam.core.sl.struct.ParticipantSearchDtls;
import curam.core.struct.ConcernRoleIDType;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameAndAlternateID;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.ConcernRoleTypeDetailsList;
import curam.core.struct.DisableLinkIndicatorDetails;
import curam.core.struct.EmployerSearchDtls1;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PersonSearchDtls1;
import curam.message.BPOPARTICIPANT;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;


/**
 * This class is the overridden class from the core class
 * {@linkplain curam.core.sl.impl.ParticipantSearch ParticipantSearch}.
 *
 */
public class ParticipantSearch extends curam.core.sl.impl.ParticipantSearch {

  /**
   * Applies common logic to all participant search details.
   *
   * @param details
   * Contains participant search result details.
   *
   * @return All participants search result details for display.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public AllParticipantSearchDetails processAllSearchDetails(
    final AllParticipantSearchDtls details) throws AppException,
      InformationalException {
    final ParticipantSearchDtls participantSearchDtls = new ParticipantSearchDtls();

    participantSearchDtls.assign(details);

    final ParticipantTab participantTab = new ParticipantTab();
    final ConcernRoleIDType concernRoleIDType = new ConcernRoleIDType();
    final AllParticipantSearchDetails allParticipantSearchDetails = new AllParticipantSearchDetails();

    concernRoleIDType.concernRoleID = details.concernRoleID;
    concernRoleIDType.concernRoleType = details.concernRoleType;
    allParticipantSearchDetails.participantTabDetailsURL = participantTab.resolveParticipantTabPageURL(concernRoleIDType).pageURL;
    restrictResults(participantSearchDtls);

    if (null == participantSearchDtls.concernRoleName) {
      return null;
    }
    allParticipantSearchDetails.assign(details);

    if (!participantSearchDtls.restricted) {
      final Address addressObj = AddressFactory.newInstance();
      final OtherAddressData otherAddressData = new OtherAddressData();

      otherAddressData.addressData = details.address;

      if (addressObj.isEmpty(otherAddressData).emptyInd) {
        otherAddressData.addressData = details.primaryAddress;
      }
      allParticipantSearchDetails.formattedAddress = ParticipantFactory.newInstance().displaySingleLineAddress(otherAddressData).addressString;

      if (1 == details.roleTypeCount) {
        if (INFORMATIONPROVIDERTYPEEntry.EDUINSTITUTE.getCode().equals(
          details.subtype)) {
          allParticipantSearchDetails.roleTypeList = CodeTable.getOneItem(
            INFORMATIONPROVIDERTYPE.TABLENAME, details.subtype,
            TransactionInfo.getProgramLocale());
        } else {
          allParticipantSearchDetails.roleTypeList = CodeTable.getOneItem(
            CONCERNROLETYPE.TABLENAME, details.concernRoleType,
            TransactionInfo.getProgramLocale());
        }
      } else {
        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = details.concernRoleID;
        final ConcernRoleTypeDetailsList concernRoleTypeDetailsList = concernRoleObj.searchConcernRoleType(
          concernRoleKey);

        for (final ConcernRoleTypeDetails concernRoleTypeDetails : concernRoleTypeDetailsList.dtls.items()) {
          allParticipantSearchDetails.roleTypeList += CodeTable.getOneItem(
            CONCERNROLETYPE.TABLENAME, concernRoleTypeDetails.concernRoleType,
            TransactionInfo.getProgramLocale())
              + CuramConst.kCommaSeparator;
        }

        // Remove the last comma separator.
        allParticipantSearchDetails.roleTypeList = allParticipantSearchDetails.roleTypeList.substring(
          CuramConst.gkZero,
          allParticipantSearchDetails.roleTypeList.length()
            - CuramConst.kCommaSeparator.length());

      }
      allParticipantSearchDetails.xmlParticipantData = getParticipantNameDetails(details).toString();
    } else {
      allParticipantSearchDetails.xmlParticipantData = ParticipantTab.getRestrictedDetails().toString();
      allParticipantSearchDetails.formattedAddress = CuramConst.gkRestricted;
      allParticipantSearchDetails.concernRoleName = CuramConst.gkRestricted;
      allParticipantSearchDetails.dateOfBirth = Date.kZeroDate;
    }
    return allParticipantSearchDetails;
  }

  /**
   * Gets the participant name details in a XML format.
   *
   * @param details
   * Contains participant search result details.
   *
   * @return Content panel builder.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected static ContentPanelBuilder getParticipantNameDetails(
    final AllParticipantSearchDtls details) throws AppException,
      InformationalException {
    final ContentPanelBuilder contentPanelBuilder = ContentPanelBuilder.createPanel(
      CuramConst.gkContentPanel);

    final DisableLinkIndicatorDetails disableLinkIndicatorDetails = new DisableLinkIndicatorDetails();

    disableLinkIndicatorDetails.disableLinkInd = false;

    if (CONCERNROLETYPEEntry.PERSON.getCode().equals(details.concernRoleType)
      || CONCERNROLETYPEEntry.PROSPECTPERSON.getCode().equals(
        details.concernRoleType)) {

      final PersonSearchDtls1 personSearchDtls1 = new PersonSearchDtls1();

      personSearchDtls1.assign(details);

      if (details.originalConcernRoleID != 0) {
        final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = details.originalConcernRoleID;

        final ConcernRoleNameAndAlternateID concernRoleNameAndAlternateID = concernRoleObj.readConcernRoleNameAndAlternateID(
          concernRoleKey);

        personSearchDtls1.originalConcernRoleName = concernRoleNameAndAlternateID.concernRoleName;
        personSearchDtls1.originalPrimaryAlternateID = concernRoleNameAndAlternateID.primaryAlternateID;
      }
      return PersonSearch.getPersonNameDetails(personSearchDtls1,
        disableLinkIndicatorDetails);
    } else if (CONCERNROLETYPEEntry.EMPLOYER.getCode().equals(
      details.concernRoleType)
        || CONCERNROLETYPEEntry.PROSPECTEMPLOYER.getCode().equals(
          details.concernRoleType)) {

      final EmployerSearchDtls1 employerSearchDtls1 = new EmployerSearchDtls1();

      employerSearchDtls1.assign(details);
      return EmployerSearch.getEmployerPrimaryNameDetails(employerSearchDtls1,
        disableLinkIndicatorDetails);
    } else {
      LocalisableString localisableString = new LocalisableString(
        BPOPARTICIPANT.INF_PARTICIPANT_DETAILS);

      localisableString.arg(details.primaryConcernRoleName);

      if (details.alternateID.length() > 0) {
        localisableString.arg(details.alternateID);
      } else {
        localisableString.arg(details.primaryAlternateID);
      }

      final LinkBuilder linkBuilder = LinkBuilder.createLocalizableLink(
        localisableString.toClientFormattedText(),
        CuramConst.gkParticipantHomePage);

      linkBuilder.addParameter(CuramConst.gkPageParameterConcernRoleID,
        String.valueOf(details.concernRoleID));
      contentPanelBuilder.addLinkItem(linkBuilder);
    }
    return contentPanelBuilder;
  }
}
