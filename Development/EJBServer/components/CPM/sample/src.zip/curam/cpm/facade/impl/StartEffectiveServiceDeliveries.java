/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import com.google.inject.Inject;
import curam.codetable.impl.SERVICEDELIVERYSTATUSEntry;
import curam.servicedelivery.impl.ServiceDeliveryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;
import java.util.List;


/**
 * Batch job to check if any of the Service Delivery records with a state of
 * 'Not Started' have a cover period start date which is now effective. Any
 * Service Delivery satisfying this check will have its state updated to 'In
 * Progress'.
 */
public class StartEffectiveServiceDeliveries extends curam.cpm.facade.base.StartEffectiveServiceDeliveries {

  @Inject
  protected ServiceDeliveryDAO serviceDeliveryDAO;

  /**
   * Default constructor for generating rosters.
   */
  public StartEffectiveServiceDeliveries() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public void startEffectiveServiceDeliveries() throws AppException,
      InformationalException {
    List<curam.servicedelivery.impl.ServiceDelivery> serviceDeliveriesToStart = serviceDeliveryDAO.searchByStatus(
      SERVICEDELIVERYSTATUSEntry.NOTSTARTED);

    // check if these records have an effective start date. (i.e. a start date
    // on or before
    // the current date.
    for (curam.servicedelivery.impl.ServiceDelivery serviceDelivery : serviceDeliveriesToStart) {
      if (!Date.getCurrentDate().before(
        serviceDelivery.getCoverPeriodStartDate())) {
        serviceDelivery.start(serviceDelivery.getVersionNo());
      }
    }
  }

}
