/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


/**
 * This constant class assigns values to common xml element and domain values
 * used for CPM widgets.
 */
public class CPMWidgetHelperConstants {

  /**
   * Training Element
   */
  public static final String kTrainingElement = "Training";

  /**
   * TrainingProgram Element
   */
  public static final String kTrainingProgramElement = "TrainingProgram";

  /**
   * TrainingName Element
   */
  public static final String kTrainingNameElement = "trainingName";

  /**
   * ServiceofferingName Element
   */
  public static final String kServiceofferingNameElement = "serviceOfferingName";

  /**
   * UnitAmount Element
   */
  public static final String kUnitAmountElement = "unitAmount";

  /**
   * AuthorizedFrom Element
   */
  public static final String kAuthorizedFromElement = "authorizedFrom";

  /**
   * ToBeCompletedBy Element
   */
  public static final String kToBeCompletedByElement = "toBeCompletedBy";

  /**
   * ServiceofferingID Element
   */
  public static final String kServiceofferingIDElement = "serviceOfferingID";

  /**
   * TrainingID Element
   */
  public static final String kTrainingIDElement = "trainingID";

  /**
   * Concern Member TrainingProgram Element
   */
  public static final String kConcernMemberTrainingProgramElement = "ConcernMemberTrainingProgram";

  /**
   * Concern Member Element
   */
  public static final String kConcernMemberElement = "ConcernMember";

  /**
   * Concern RoleID Element
   */
  public static final String kConcernRoleIDElement = "concernRoleID";

  /**
   * PartyID Element
   */
  public static final String kPartyIDElement = "partyConcernRoleID";

  /**
   * PartyName Element
   */
  public static final String kPartyNameElement = "partyName";

  /**
   * TrainingProgram MemberID Element
   */
  public static final String kTrainingProgramMemberIDElement = "trainingProgramMemberID";

  /**
   * ProgramMember Name Element
   */
  public static final String kProgramMemberNameElement = "programMemberName";

  /**
   * Role Element
   */
  public static final String kRoleElement = "role";

  /**
   * Completion Element
   */
  public static final String kCompletionElement = "completion";

  /**
   * Type Attribute
   */
  public static final String kTypeAttribute = "TYPE";

  /**
   * CodeTable Attribute
   */
  public static final String kCodeTableAttribute = "CODETABLE";

  /**
   * SubType Attribute
   */
  public static final String kSubTypeAttribute = "SUB_TYPE";

  /**
   * UnitsRequired Element
   */
  public static final String kUnitsRequiredElement = "unitsRequired";

  /**
   * Member TrainingProgram Element
   */
  public static final String kMemberTrainingProgramElement = "MemberTrainingProgram";

  /**
   * Member Element
   */
  public static final String kMemberElement = "Member";

  /**
   * Record CompletedTraining Element
   */
  public static final String kRecordCompletedTrainingElement = "RecordCompletedTraining";

  /**
   * Units Completed Element
   */
  public static final String kUnitsCompletedElement = "unitsCompleted";

  /**
   * Units completed default value.
   */
  public static final int kUnitsCompletedDefault = 1;

  /**
   * Date Completed Element
   */
  public static final String kDateCompletedElement = "dateCompleted";

  /**
   * Marking Training Complete Element
   */
  public static final String kMarkingTrainingCompleteElement = "MarkingTrainingComplete";

  /**
   * Provider Member Element
   */
  public static final String kProviderMemberElement = "ProviderMember";

  /**
   * Credits Achieved Element
   */
  public static final String kCreditsAchievedElement = "creditsAchieved";

  /**
   * Default Value Attribute
   */
  public static final String kDomainValueAttribute = "DOMAIN";

  /**
   * Concern Member Daily Attendance XML Element for Daily Attendance widget.
   */
  public static final String kConcernMemberDailyAttendanceElement = "ConcernMemberDailyAttendance";

  /**
   * Daily Attendance XML Element for Daily Attendance widget.
   */
  public static final String kDailyAttendanceElement = "DailyAttendance";

  /**
   * Daily Attendance ID XML Element for Daily Attendance widget.
   */
  public static final String kAttendanceIDElement = "attendanceID";

  /**
   * Date Attendance XML Element for Daily Attendance widget.
   */
  public static final String kAttendanceDateElement = "date";

  /**
   * Service Date Attendance XML Element for Daily Attendance widget.
   */
  public static final String kServiceDateElement = "servicedate";

  /**
   * Attendance XML Element for Daily Attendance widget.
   */
  public static final String kAttendanceElement = "attendance";

  /**
   * Absence Reason XML Element for Daily Attendance widget.
   */
  public static final String kAbsenceReasonElement = "absenceReason";

  /**
   * ExpectedUnits XML Element for Daily Attendance widget.
   */
  public static final String kExpectedUnitsElement = "expectedUnits";

  /**
   * Units Attended XML Element for Daily Attendance widget.
   */
  public static final String kUnitsAttendedElement = "unitsAttended";

  /**
   * Units UnAttended XML Element for Daily Attendance widget.
   */
  public static final String kUnitsUnAttendedElement = "unitsUnAttended";

  // BEGIN, CR00176474, AS
  /**
   * Hours Attended XML Element for Daily Attendance widget.
   */
  public static final String kHoursAttendedElement = "hoursAttended";

  /**
   * Hours not Attended XML Element for Daily Attendance widget.
   */
  public static final String kHoursUnAttendedElement = "hoursUnAttended";

  /**
   * Minutes Attended XML Element for Daily Attendance widget.
   */
  public static final String kMinutesAttendedElement = "minutesAttended";

  /**
   * Minutes not Attended XML Element for Daily Attendance widget.
   */
  public static final String kMinutesUnAttendedElement = "minutesUnAttended";
  // END, CR00176474

  /**
   * Case Reference Number XML Element for Update Roster widget.
   */
  public static final String kCaseReferenceNoElement = "caseReferenceNo";

  /**
   * Domain value of Attendance ID XML Element for Daily Attendance widget.
   */
  public static final String kAttendanceIDDomainValueAttribute = "CPM_WIDGET_DA_ATTENDANCEID";

  /**
   * Domain value of Attendance Date XML Element for Daily Attendance widget.
   */
  public static final String kAttendanceDateDomainValueAttribute = "CPM_WIDGET_DA_DATE";

  /**
   * Domain value of Attendance XML Element for Daily Attendance widget.
   */
  public static final String kAttendanceDomainValueAttribute = "CPM_WIDGET_DA_ATTENDANCE";

  /**
   * Domain value of Absence Reason XML Element for Daily Attendance widget.
   */
  public static final String kAbsenceReasonDomainValueAttribute = "CPM_WIDGET_DA_ABSENCEREASON";

  /**
   * Domain value of Expected Units XML Element for Daily Attendance widget.
   */
  public static final String kExpectedUnitsDomainValueAttribute = "CPM_WIDGET_DA_EXPECTEDUNITS";

  /**
   * Domain value of Units Attended XML Element for Daily Attendance widget.
   */
  public static final String kUnitsAttendedDomainValueAttribute = "CPM_WIDGET_DA_UNITSATTENDED";

  /**
   * Domain value of Units UnAttended XML Element for Daily Attendance widget.
   */
  public static final String kUnitsUnAttendedDomainValueAttribute = "CPM_WIDGET_DA_UNITSUNATTENDED";

  // BEGIN, CR00176474, AS
  /**
   * Domain value of Hours Attended XML Element for Daily Attendance widget.
   */
  public static final String kHoursAttendedDomainValueAttribute = "CPM_WIDGET_DA_HOURSATTENDED";

  /**
   * Domain value of Hours UnAttended XML Element for Daily Attendance widget.
   */
  public static final String kHoursUnAttendedDomainValueAttribute = "CPM_WIDGET_DA_HOURSUNATTENDED";

  /**
   * Domain value of Minutes Attended XML Element for Daily Attendance widget.
   */
  public static final String kMinutesAttendedDomainValueAttribute = "CPM_WIDGET_DA_MINUTESATTENDED";

  /**
   * Domain value of Minutes UnAttended XML Element for Daily Attendance widget.
   */
  public static final String kMinutesUnAttendedDomainValueAttribute = "CPM_WIDGET_DA_MINUTESUNATTENDED";
  // END, CR00176474

  /**
   * Update Roster XML Element for Update Roster widget.
   */
  public static final String kUpdateRosterElement = "UpdateRoster";

  /**
   * Roster XML Element for Update Roster widget.
   */
  public static final String kRosterElement = "ProviderRosterLineItem";

  /**
   * Provider Roster Line Item ID XML Element for Update Roster widget.
   */
  public static final String kProviderRosterLineItemIDElement = "providerRosterLineItemID";

  /**
   * Client XML Element for Update Roster widget.
   */
  public static final String kClientElement = "client";

  /**
   * Service From XML Element for Update Roster widget.
   */
  public static final String kServicefromElement = "serviceFrom";

  /**
   * Service To XML Element for Update Roster widget.
   */
  public static final String kServicetoElement = "serviceTo";

  /**
   * Authorization Reference Number XML Element for Update Roster widget.
   */
  public static final String kAuthorizationReferenceNumberElement = "authrefNo";

  /**
   * Voucher Number XML Element for Update Roster widget.
   */
  public static final String kVoucherNumberElement = "voucherNo";

  /**
   * Actual units XML Element for Update Roster widget.
   */
  public static final String kActualunitsElement = "actualUnits";

  /**
   * Domain value of Reference Number XML Element for Update Roster widget.
   */
  public static final String kReferenceNoDomainValueAttribute = "CPM_WIDGET_UR_REFERENCENO";

  /**
   * Domain value of Provider Roster Line Item XML Element for Update Roster
   * widget.
   */
  public static final String kProviderRosterLineItemIDDomainValueAttribute = "CPM_WIDGET_UR_PROVIDERROSTERLINEITEMID";

  /**
   * Domain value of Concern Role ID XML Element for Update Roster widget.
   */
  public static final String kConcernRoleIDDomainValueAttribute = "CPM_WIDGET_UR_CONCERNROLEID";

  /**
   * Domain value of Client XML Element for Update Roster widget.
   */
  public static final String kClientElementDomainValueAttribute = "CPM_WIDGET_UR_CLIENT";

  /**
   * Domain value of Service From XML Element for Update Roster widget.
   */
  public static final String kServiceFromDomainValueAttribute = "CPM_WIDGET_UR_SERVICEFROM";

  /**
   * Domain value of Service To XML Element for Update Roster widget.
   */
  public static final String kServiceToDomainValueAttribute = "CPM_WIDGET_UR_SERVICETO";

  /**
   * Domain value of Authorization Reference Number XML Element for Update
   * Roster widget.
   */
  public static final String kAuthRefNoDomainValueAttribute = "CPM_WIDGET_UR_AUTHREFNO";

  /**
   * Domain value of Voucher Number XML Element for Update Roster widget.
   */
  public static final String kVoucherNoDomainValueAttribute = "CPM_WIDGET_UR_VOUCHERNO";

  /**
   * Domain value of Actual Units XML Element for Update Roster widget.
   */
  public static final String kActualUnitsDomainValueAttribute = "CPM_WIDGET_UR_ACTUALUNITS";

  /**
   * Version number for every record in the widget for modification.
   */
  public static final String kDailyAttendanceVersionNumberElement = "versionNo";

  /**
   * Daily Attendance record Version number domain definition attribute.
   */
  public static final String kDailyAttendanceVersionNumberDomainValueAttribute = "CPM_WIDGET_DA_VERSIONNO";

  /**
   * Version number for every record of Provider Roster Line Item in the widget
   * for modification.
   */
  public static final String kPRLIVersionNumberElement = "prliVersionNo";

  /**
   * Provider Roster Line Item Version number domain definition attribute.
   */
  public static final String kPRLIVersionNumberDomainValueAttribute = "CPM_WIDGET_UR_PRLIVERSIONNO";

  /**
   * Version number for every record of Roster Line Item in the widget for
   * modification.
   */
  public static final String kRLIVersionNumberElement = "rliVersionNo";

  /**
   * Roster Line Item Version number domain definition attribute.
   */
  public static final String kRLIVersionNumberDomainValueAttribute = "CPM_WIDGET_UR_RLIVERSIONNO";

  /**
   * Attribute used in the widgets to determine whether the element is read
   * only.
   */
  public static final String kreadOnlyAttribute = "readonly";

  /**
   * Party Concern Role ID element in the Concern member widget.
   */
  public static final String kPartyConcernRoleIDElement = "partyConcernRoleID";

  /**
   * Domain definition value for Party ID element for Training Program widget.
   */
  public static final String kPartyIDDomainValueAttribute = "CPM_WIDGET_TP_PARTYCONCERNROLEID";

  /**
   * Domain definition value for Training Program member element for Training
   * Program widget.
   */
  public static final String kTrainingProgramMemberDomainValueAttribute = "CPM_WIDGET_TPMEMBERID";

  /**
   * Domain definition value for Party Name element for Training Program widget.
   */
  public static final String kPartyNameDomainValueAttribute = "CPM_WIDGET_TP_PARTYNAME";

  /**
   * Domain definition value for Role element for Training Program widget.
   */
  public static final String kRoleDomainValueAttribute = "CPM_WIDGET_TP_ROLE";

  /**
   * Domain definition value for Completion element for Training Program widget.
   */
  public static final String kCompletionDomainValueAttribute = "CPM_WIDGET_TP_COMPLETION";

  /**
   * Domain definition value for Units Required element for Training Program
   * widget.
   */
  public static final String kUnitsRequiredDomainValueAttribute = "CPM_WIDGET_TP_UNITSREQUIRED";

  /**
   * Domain definition value for Training ID element for Training Program
   * widget.
   */
  public static final String kTrainingIDDomainValueAttribute = "CPM_WIDGET_TP_TRAININGID";

  /**
   * Domain definition value for Training Name element for Training Program
   * widget.
   */
  public static final String kTrainingNameDomainValueAttribute = "CPM_WIDGET_TP_TRAINING_NAME";

  /**
   * Domain definition value for Unit Amount element for Training Program
   * widget.
   */
  public static final String kUnitAmountDomainValueAttribute = "CPM_WIDGET_TP_UNITAMOUNT";

  /**
   * Domain definition value for Authorized From element for Training Program
   * widget.
   */
  public static final String kAuthorizedFromDomainValueAttribute = "CPM_WIDGET_TP_AUTHORIZEDFROM";

  /**
   * Domain definition value for To Be Completed By element for Training Program
   * widget.
   */
  public static final String ktoBeCompletedByDomainValueAttribute = "CPM_WIDGET_TP_TOBECOMPLETEDBY";

  /**
   * Domain definition value for Units Completed element for Record Completed
   * Training Program widget.
   */
  public static final String kUnitsCompletedDomainValueAttribute = "CPM_WIDGET_RC_UNITSCOMPLETED";

  /**
   * Domain definition value for Date Completed element for Record Completed
   * Training Program widget.
   */
  public static final String kDateCompletedDomainValueAttribute = "CPM_WIDGET_RC_DATECOMPLETED";

  // BEGIN , CR00159419 , SK
  /**
   * Criterion Response Scores XML Element for Add scores widget.
   */
  public static final String kCriterionResponseScoreElement = "CriterionResponseScoresElement";

  /**
   * Response Score XML Element for Add scores widget.
   */
  public static final String kResponseScoreElement = "ResponseScore";

  /**
   * Service Evaluation Criterion ID element for Add scores widget.
   */
  public static final String kServiceEvaluationCriterionIDElement = "serviceEvaluationCriterionID";

  /**
   * Domain definition value for Service Evaluation Criterion ID element for Add
   * scores widget.
   */
  public static final String kServiceEvaluationCriterionIDDomainValueAttribute = "CPM_WIDGET_SEC_SEREVALCRTONID";

  /**
   * Response code element for Add scores widget.
   */
  public static final String kResponseCodeElement = "responsecode";

  /**
   * Response code description element for Add scores widget.
   */
  public static final String kResponseCodeDescriptionElement = "responsecodedescription";

  /**
   * Domain definition value for response code element for Add scores widget.
   */
  public static final String kResponseCodeDomainValueAttribute = "CPM_WIDGET_SEC_RESPONSE_CODE";

  /**
   * Domain definition value for response code description element for Add
   * scores widget.
   */
  public static final String kResponseCodeDescriptionDomainValueAttribute = "CPM_WIDGET_RESPONSE_DESCRIPTION";

  /**
   * Score element for Add scores widget.
   */
  public static final String kScoreElement = "score";

  /**
   * Domain definition value for score element for Add scores widget.
   */
  public static final String kScoreDomainValueAttribute = "CPM_WIDGET_SEC_SCORE";

  // END , CR00159419
  
  // BEGIN, CR00158345, GP
  /**
   * Service invoice line item client Element
   */
  public static final String kServiceInvoiceLineItemClientElement = "ServiceInvoiceLineItemClient";

  /**
   * Client details Element
   */
  public static final String kClientDetailsElement = "ClientDetails";

  /**
   * Client first name Element
   */
  public static final String kClientFirstNameElement = "clientFirstName";

  /**
   * Client last name Element
   */
  public static final String kClientLastNameElement = "clientLastName";

  /**
   * Client reference number Element
   */
  public static final String kClientReferenceNoElement = "clientReferenceNo";

  /**
   * Client date of birth Element
   */
  public static final String kClientDOBElement = "clientDOB";

  /**
   * Service Invoice Line Item Client ID
   */
  public static final String kSILIClientIDElement = "siliClientID";

  /**
   * Service Invoice Line Item ID
   */
  public static final String kServiceInvoiceLineItemIDElement = "serviceInvoiceLineItemID";

  /**
   * Service Invoice Line Item Correction Client ID
   */
  public static final String kSILICorrectionClientIDElement = "siliCorrectionClientID";

  /**
   * Service Invoice Line Item Correction ID
   */
  public static final String kSILICorrectionIDElement = "siliCorrectionID";

  /**
   * Service invoice request line item client Element
   */
  public static final String kServiceInvoiceRequestLineItemClientElement = "ServiceInvoiceRequestLineItemClient";
  
  /**
   * Service Invoice Request Line Item Client ID
   */
  public static final String kServiceInvReqLineItemClientIDElement = "serviceInvReqLineItemClientID";

  /**
   * Service Invoice Request Line Item ID
   */
  public static final String kServiceInvReqLineItemIDElement = "serviceInvReqLineItemID";

  /**
   * Domain definition value for Client Reference Number element for Service Invoice Line Item widget.
   */
  public static final String kClientReferenceNumberDomainValueAttribute = "CPM_WIDGET_SILI_CLIENTREFERENCENO";

  /**
   * Domain definition value for Client First Name element for Service Invoice Line Item widget.
   */
  public static final String kClientFirstNameDomainValueAttribute = "CPM_WIDGET_SILI_CLIENTFIRSTNAME";

  /**
   * Domain definition value for Client Last Name element for Service Invoice Line Item widget.
   */
  public static final String kClientLastNameDomainValueAttribute = "CPM_WIDGET_SILI_CLIENTLASTNAME";

  /**
   * Domain definition value for Client Date Of Birth element for Service Invoice Line Item widget.
   */
  public static final String kClientDateOfBirthDomainValueAttribute = "CPM_WIDGET_SILI_CLIENTDOB";

  /**
   * Domain definition value for Service Invoice Line Item ID element for Service Invoice Line Item widget.
   */
  public static final String kServiceInvoiceLineItemIDDomainValueAttribute = "CPM_WIDGET_SILI_SERVICEINVOICELINEITEMID";

  /**
   * Domain definition value for Service Invoice Line Item Client ID element for Service Invoice Line Item widget.
   */
  public static final String kSILIClientIDDomainValueAttribute = "CPM_WIDGET_SILI_SILICLIENTID";

  /**
   * Domain definition value for Service Invoice Line Item Correction Client ID element for Service Invoice Line Item Correction widget.
   */
  public static final String kSILICorrectionClientIDDomainValueAttribute = "CPM_WIDGET_SILI_SILICORRECTIONCLIENTID";

  /**
   * Domain definition value for Service Invoice Line Item Correction ID element for Service Invoice Line Item Correction widget.
   */
  public static final String kSILICorrectionIDDomainValueAttribute = "CPM_WIDGET_SILI_SILICORRECTIONID";

  /**
   * Domain definition value for Service Invoice Request Line Item Correction Client ID element for Service Invoice Request Line Item widget.
   */
  public static final String kServiceInvReqLineItemClientIDDomainValueAttribute = "CPM_WIDGET_SILIREQUEST_SERVINVREQLICLIENTID";

  /**
   * Domain definition value for Service Invoice Request Line Item Correction ID element for Service Invoice Request Line Item widget.
   */
  public static final String kServiceInvReqLineItemIDDomainValueAttribute = "CPM_WIDGET_SILIREQUEST_SERVINVREQLIID";
  // END, CR00158345
}
