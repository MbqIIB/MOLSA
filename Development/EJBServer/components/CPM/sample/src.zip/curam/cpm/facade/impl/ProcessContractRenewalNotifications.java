/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 - 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.CONTRACTSTATUS;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.contracts.ContractNotificationEvent;
import curam.contracts.impl.ContractNotification;
import curam.contracts.impl.ContractVersionDAO;
import curam.core.impl.EnvVars;
import curam.cpm.facade.struct.ContractNotificationKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;


/**
 * This class holds the API for sending the provider notifications.
 *
 */
// Start CR00096126, JSP
public abstract class ProcessContractRenewalNotifications extends curam.cpm.facade.base.ProcessContractRenewalNotifications {
  // End CR00096126

  /**
   * Constructor
   */
  public ProcessContractRenewalNotifications() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected ContractVersionDAO contractVersionDAO;

  // ___________________________________________________________________________
  /**
   * Processes renewal notifications for contracts.
   *
   * @throws AppException
   * @throws InformationalException
   */
  public void processContractRenewalNotifications()
    throws AppException, InformationalException {

    Set<curam.contracts.impl.ContractVersion> allContracts = contractVersionDAO.readAll();

    // number of Event days
    int numberOfEventDays;
    int remainingContractDays;
    String numberOfEventDaysStr;

    // Set the date to specified number of days
    numberOfEventDaysStr = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_NO_OFDAYS_EVENTS);
    try {
      numberOfEventDays = Integer.parseInt(numberOfEventDaysStr);
    } catch (NumberFormatException e) {
      // any problem, use the default.
      numberOfEventDays = EnvVars.ENV_NO_OFDAYS_EVENTS_DEFAULT;
    }

    for (final curam.contracts.impl.ContractVersion contract : allContracts) {

      remainingContractDays = contract.getDateRange().end().subtract(
        Date.getCurrentDate());

      if ((contract.getLifecycleState().getCode().equals(CONTRACTSTATUS.LIVE))
        && (remainingContractDays <= numberOfEventDays)) {

        // Send Notification
        ContractNotification contractNotification = new ContractNotification();
        ContractNotificationKey contractNotificationKey = new ContractNotificationKey();

        // Provider
        if (contract.getProviderOrganization().getConcernRoleType().equals(
          CONCERNROLETYPEEntry.PROVIDER)) {

          contractNotificationKey.contractVersionID = contract.getID();
          contractNotificationKey.event = ContractNotificationEvent.RENEWPROVIDERCONTRACT;
        } // Provider Group
        else if (contract.getProviderOrganization().getConcernRoleType().equals(
          CONCERNROLETYPEEntry.PROVIDERGROUP)) {

          contractNotificationKey.contractVersionID = contract.getID();
          contractNotificationKey.event = ContractNotificationEvent.RENEWPGCONTRACT;
        }

        contractNotification.createNotification(contractNotificationKey);

      }
    }
  }

}
