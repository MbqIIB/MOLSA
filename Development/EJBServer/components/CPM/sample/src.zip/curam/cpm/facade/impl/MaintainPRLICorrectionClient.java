/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import com.google.inject.Inject;
import curam.attendance.impl.PRLICorrection;
import curam.attendance.impl.PRLICorrectionClient;
import curam.attendance.impl.PRLICorrectionClientDAO;
import curam.attendance.impl.PRLICorrectionDAO;

import curam.core.impl.CuramConst;
import curam.core.struct.AddressDtls;
import curam.cpm.facade.struct.PRLICorrectionClientDetails;
import curam.cpm.facade.struct.PRLICorrectionClientDetailsList;
import curam.cpm.facade.struct.PRLICorrectionClientKeyVersionDetails;
import curam.cpm.sl.entity.struct.PRLICorrectionKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;

import java.util.Set;


/**
 * Contains methods to manage the provider roster line item correction client.
 *
 */
public abstract class MaintainPRLICorrectionClient extends curam.cpm.facade.base.MaintainPRLICorrectionClient {

  /**
   * Reference to provider roster line item correction client DAO.
   */
  @Inject
  protected PRLICorrectionClientDAO prliCorrectionClientDAO;

  /**
   * Reference to provider roster line item correction DAO.
   */
  @Inject
  protected PRLICorrectionDAO prliCorrectionDAO;

  /**
   * Default constructor that does Guice injections.
   */
  protected MaintainPRLICorrectionClient() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Associate the input client with the provider roster line item correction.
   *
   * @param prliCorrectionClientDetails
   * Provider roster line item correction client details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void addPRLICorrectionClient(
    PRLICorrectionClientDetails prliCorrectionClientDetails)
    throws AppException, InformationalException {
    PRLICorrectionClient prliCorrectionClient = prliCorrectionClientDAO.newInstance();

    prliCorrectionClient.setClientFirstName(
      prliCorrectionClientDetails.dtls.clientFirstName);
    prliCorrectionClient.setClientLastName(
      prliCorrectionClientDetails.dtls.clientLastName);
    prliCorrectionClient.setClientReferenceNo(
      prliCorrectionClientDetails.dtls.clientReferenceNo);
    prliCorrectionClient.setClientDOB(
      prliCorrectionClientDetails.dtls.clientDOB);
    prliCorrectionClient.setPRLICorrection(
      prliCorrectionDAO.get(prliCorrectionClientDetails.dtls.prliCorrectionID));
    AddressDtls addressDtls = new AddressDtls();

    addressDtls.addressData = prliCorrectionClientDetails.addressData;
    prliCorrectionClient.setClientAddress(addressDtls);

    prliCorrectionClient.insert();
  }

  /**
   * Logically removes the client identified by the input key from the provider
   * roster line item correction.
   *
   * @param keyVersionDetails
   * Contains the provider roster line item correction ID and the
   * version number.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancelPRLICorrectionClient(
    PRLICorrectionClientKeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {
    if (keyVersionDetails.prliCorrectionClientID != CuramConst.gkZero) {
      PRLICorrectionClient prliCorrectionClient = prliCorrectionClientDAO.get(
        keyVersionDetails.prliCorrectionClientID);

      prliCorrectionClient.cancel(
        keyVersionDetails.prliCorrectionClientVersionNo);
    } else {
      PRLICorrection prliCorrection = prliCorrectionDAO.get(
        keyVersionDetails.prliCorrectionID);

      prliCorrection.deleteClient(keyVersionDetails.prliCorrectionVersionNo);
    }
  }

  /**
   * Updates the client associated with the provider roster line item correction
   * with the input details.
   *
   * @param prliCorrectionClientDetails
   * Provider roster line item correction client details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyPRLICorrectionClient(
    PRLICorrectionClientDetails prliCorrectionClientDetails)
    throws AppException, InformationalException {
    if (prliCorrectionClientDetails.dtls.prliCorrectionClientID
      != CuramConst.gkZero) {
      PRLICorrectionClient prliCorrectionClient = prliCorrectionClientDAO.get(
        prliCorrectionClientDetails.dtls.prliCorrectionClientID);

      prliCorrectionClient.setClientFirstName(
        prliCorrectionClientDetails.dtls.clientFirstName);
      prliCorrectionClient.setClientLastName(
        prliCorrectionClientDetails.dtls.clientLastName);
      prliCorrectionClient.setClientReferenceNo(
        prliCorrectionClientDetails.dtls.clientReferenceNo);
      prliCorrectionClient.setClientDOB(
        prliCorrectionClientDetails.dtls.clientDOB);

      AddressDtls addressDtls = new AddressDtls();

      addressDtls.addressData = prliCorrectionClientDetails.addressData;
      prliCorrectionClient.setClientAddress(addressDtls);

      prliCorrectionClient.modify(prliCorrectionClientDetails.dtls.versionNo);
    } else {
      PRLICorrection prliCorrection = prliCorrectionDAO.get(
        prliCorrectionClientDetails.dtls.prliCorrectionID);

      prliCorrection.setClientFirstName(
        prliCorrectionClientDetails.dtls.clientFirstName);
      prliCorrection.setClientLastName(
        prliCorrectionClientDetails.dtls.clientLastName);
      prliCorrection.setClientReferenceNo(
        prliCorrectionClientDetails.dtls.clientReferenceNo);
      prliCorrection.setClientDOB(prliCorrectionClientDetails.dtls.clientDOB);

      AddressDtls addressDtls = new AddressDtls();

      addressDtls.addressData = prliCorrectionClientDetails.addressData;
      prliCorrection.setClientAddress(addressDtls);

      prliCorrection.modify(prliCorrectionClientDetails.prliCorrectionVersionNo);
    }
  }

  /**
   * Returns the roster line item correction client details for view.
   *
   * @param prliCorrectionClientKey
   * Contains provider roster line item correction client ID.
   *
   * @return The roster line item correction client details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLICorrectionClientDetails viewPRLICorrectionClient(
    curam.cpm.facade.struct.PRLICorrectionClientKey prliCorrectionClientKey)
    throws AppException, InformationalException {
    PRLICorrectionClientDetails prliCorrectionClientDetails = new PRLICorrectionClientDetails();

    if (prliCorrectionClientKey.prliCorrectionClientID != CuramConst.gkZero) {
      PRLICorrectionClient prliCorrectionClient = prliCorrectionClientDAO.get(
        prliCorrectionClientKey.prliCorrectionClientID);

      prliCorrectionClientDetails.dtls.clientFirstName = prliCorrectionClient.getClientFirstName();
      prliCorrectionClientDetails.dtls.clientLastName = prliCorrectionClient.getClientLastName();
      prliCorrectionClientDetails.dtls.clientReferenceNo = prliCorrectionClient.getClientReferenceNo();
      prliCorrectionClientDetails.dtls.clientDOB = prliCorrectionClient.getClientDOB();
      prliCorrectionClientDetails.dtls.prliCorrectionID = prliCorrectionClient.getID();

      prliCorrectionClientDetails.dtls.versionNo = prliCorrectionClient.getVersionNo();
      prliCorrectionClientDetails.addressData = prliCorrectionClient.getClientAddressData();
      prliCorrectionClientDetails.dtls.clientAddressID = prliCorrectionClient.getClientAddressID();
    } else {
      PRLICorrection prliCorrection = prliCorrectionDAO.get(
        prliCorrectionClientKey.prliCorrectionID);

      prliCorrectionClientDetails.dtls.clientFirstName = prliCorrection.getClientFirstName();
      prliCorrectionClientDetails.dtls.clientLastName = prliCorrection.getClientLastName();
      prliCorrectionClientDetails.dtls.clientReferenceNo = prliCorrection.getClientReferenceNo();
      prliCorrectionClientDetails.dtls.clientDOB = prliCorrection.getClientDOB();
      prliCorrectionClientDetails.dtls.prliCorrectionID = prliCorrection.getID();

      prliCorrectionClientDetails.prliCorrectionVersionNo = prliCorrection.getVersionNo();
      prliCorrectionClientDetails.addressData = prliCorrection.getClientAddressData();
      prliCorrectionClientDetails.dtls.clientAddressID = prliCorrection.getClientAddressID();

    }
    return prliCorrectionClientDetails;
  }

  /**
   * Returns the list of all clients associated with the given roster line item
   * correction.
   *
   * @param prliCorrectionKey
   * Contains provider roster line item correction ID.
   *
   * @return List of provider roster line item correction clients.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLICorrectionClientDetailsList listClientsForPRLICorrection(
    PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {
    PRLICorrectionClientDetailsList prliCorrectionClientDetailsList = new PRLICorrectionClientDetailsList();
    PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliCorrectionKey.prliCorrectionID);
    PRLICorrectionClientDetails prliCorrectionClientDetails = new PRLICorrectionClientDetails();

    if (prliCorrection.isClientAttached()) {

      prliCorrectionClientDetails.addressData = prliCorrection.getClientAddressData();
      prliCorrectionClientDetails.prliCorrectionVersionNo = prliCorrection.getVersionNo();

      prliCorrectionClientDetails.dtls.clientFirstName = prliCorrection.getClientFirstName();
      prliCorrectionClientDetails.dtls.clientLastName = prliCorrection.getClientLastName();
      prliCorrectionClientDetails.dtls.clientReferenceNo = prliCorrection.getClientReferenceNo();
      prliCorrectionClientDetails.dtls.clientDOB = prliCorrection.getClientDOB();
      prliCorrectionClientDetails.dtls.clientAddressID = prliCorrection.getClientAddressID();

      prliCorrectionClientDetailsList.clientDtls.addRef(
        prliCorrectionClientDetails);
    }
    Set<PRLICorrectionClient> clientList = prliCorrectionClientDAO.listClientsForPRLICorrection(
      prliCorrection);

    for (PRLICorrectionClient client : clientList) {
      prliCorrectionClientDetails = new PRLICorrectionClientDetails();
      prliCorrectionClientDetails.addressData = client.getClientAddressData();
      prliCorrectionClientDetails.prliCorrectionVersionNo = prliCorrection.getVersionNo();

      prliCorrectionClientDetails.dtls.clientFirstName = client.getClientFirstName();
      prliCorrectionClientDetails.dtls.clientLastName = client.getClientLastName();
      prliCorrectionClientDetails.dtls.clientReferenceNo = client.getClientReferenceNo();
      prliCorrectionClientDetails.dtls.clientDOB = client.getClientDOB();
      prliCorrectionClientDetails.dtls.versionNo = client.getVersionNo();
      prliCorrectionClientDetails.dtls.prliCorrectionClientID = client.getID();
      prliCorrectionClientDetails.dtls.prliCorrectionID = client.getPRLICorrection().getID();
      prliCorrectionClientDetails.dtls.clientAddressID = client.getClientAddressID();
      prliCorrectionClientDetails.dtls.concernRoleID = client.getClient().getID();
      prliCorrectionClientDetailsList.clientDtls.addRef(
        prliCorrectionClientDetails);
    }
    return prliCorrectionClientDetailsList;
  }
}
