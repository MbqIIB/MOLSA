/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.eua.facade.impl;


import com.google.inject.Inject;
import curam.core.impl.CuramConst;
import curam.core.struct.InformationalMsgDtls;
import curam.cpm.eua.entity.struct.ServiceInvoiceRequestLineItemKey;
import curam.cpm.eua.entity.struct.ServiceInvoiceRequestLineItemReadmultiKey;
import curam.cpm.eua.facade.struct.SIRequestInvoiceLineItemDetails;
import curam.cpm.eua.facade.struct.SIRequestLIVersionIDKey;
import curam.cpm.eua.facade.struct.ServiceInvReqLineItemDetails;
import curam.cpm.eua.facade.struct.ServiceInvoiceKeyAndInformationals;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestLISummaryDetails;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestLISummaryDetailsList;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestLISummaryVersionDetails;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestLISummaryVersionDetailsList;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestLineItemAndClientKey;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestLineItemClientDetails;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestLineItemClientDetailsList;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestLineItemDetails;
import curam.cpm.eua.facade.struct.ViewServiceInvReqLineItemDetails;
import curam.cpm.eua.facade.struct.ViewServiceInvoiceRequestLineItem;
import curam.cpm.impl.CPMConstants;
import curam.cpm.message.SERVICEINVOICEREQUESTLINEITEM;
import curam.cpm.message.impl.SERVICEINVOICEREQUESTLINEITEMExceptionCreator;
import curam.cpm.util.impl.WidgetHelper;
import curam.externaluseraccess.impl.ServiceInvoiceRequest;
import curam.externaluseraccess.impl.ServiceInvoiceRequestLineItem;
import curam.externaluseraccess.impl.ServiceInvoiceRequestLineItemClient;
import curam.externaluseraccess.impl.ServiceInvoiceRequestLineItemClientDAO;
import curam.financial.impl.ServiceInvoiceRequestLineItemStatusEntry;
import curam.message.impl.SERVICEINVOICELINEITEMExceptionCreator;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;


/**
 * This process class provides the functionality for  External Service 
 * Invoice Request Line Items facade layer
 */
public abstract class ExternalServiceInvoiceRequestLineItem extends curam.cpm.eua.facade.base.ExternalServiceInvoiceRequestLineItem {

  /**
   * Constructor
   */
  public ExternalServiceInvoiceRequestLineItem() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * Inject ServiceInvoiceRequestLineItemDAO
   */
  @Inject
  protected curam.externaluseraccess.impl.ServiceInvoiceRequestLineItemDAO serviceInvoiceRequestLineItemDAO;

  /**
   * Inject serviceInvoiceRequestDAO
   */
  @Inject
  protected curam.externaluseraccess.impl.ServiceInvoiceRequestDAO serviceInvoiceRequestDAO;
  
  /**
   * Inject ServiceOfferingDAO
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;
  
  // BEGIN, CR00158345, GP
  /**
   * Reference to Service Invoice Request Line Item Client DAO.
   */
  @Inject
  protected ServiceInvoiceRequestLineItemClientDAO serviceInvoiceRequestLineItemClientDAO;
  // END, CR00158345
  

  /**
   * This facade method creates a new Service Invoice Request Line Item record
   *
   * @param details - contains the details for creating a new Service Invoice
   * Request Line Item record
   *
   * @return The key containing the unique ID for the newly created record and
   * a list of warning informationals
   *
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam 6.0 , replaced with
   * {@link curam.cpm.eua.facade.impl.ExternalServiceInvoiceRequestLineItem#addServiceInvoiceRequestLineItem(SIRequestInvoiceLineItemDetails)}
   * . In order to search service offering specific to client using
   * search criteria. See release note: CR00199005.
   */
  @Deprecated
  public ServiceInvoiceKeyAndInformationals createServiceInvoiceRequestLineItem(
    ServiceInvoiceRequestLineItemDetails details) throws AppException,
      InformationalException {

    ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.newInstance();

    ServiceInvoiceKeyAndInformationals result = new ServiceInvoiceKeyAndInformationals();
    
    setServiceInvoiceRequestLineItemDetails(serviceInvoiceRequestLineItem,
      details);
    
    // BEGIN CR00090268, PDN    
    ServiceOffering serviceOffering = serviceOfferingDAO.get(
      details.details.serviceID);
    
    if (serviceOffering.getPlacementPaymentInd()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICELINEITEM_XRV_SERVICEOFFERING_WITH_PLACEMENTPAYMENT(
          serviceOffering.getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END CR00090268
    
    // fail if any errors exist
    InformationalManager info = TransactionInfo.getInformationalManager();

    info.failOperation();
    
    // call method to match the details entered with what is 
    // currently on the system. 
    serviceInvoiceRequestLineItem.matchDetailsEntered(
      serviceInvoiceRequestLineItem, true);
    
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();
    
    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      result.informationalList.dtls.addRef(informationalMsgDtls);

    }

    // reset the informational manager
    TransactionInfo.setInformationalManager();
    
    // insert the service invoice request line item record
    serviceInvoiceRequestLineItem.insert();

    result.key.serviceInvReqLineItemID = serviceInvoiceRequestLineItem.getID();

    return result;
  }

  /**
   * This method sets the details for the service invoice request record
   *
   * @param serviceInvoiceRequestLineItem - the service invoice request line item
   * object that needs to be set
   * @param details - contains the details for setting the Service Invoice
   * Request Line Item record
   *
   * @return The Service Invoice Request Line Item object containing
   * all details set
   */
  // BEGIN, CR00177241, PM
  protected ServiceInvoiceRequestLineItem setServiceInvoiceRequestLineItemDetails(
    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem,
    ServiceInvoiceRequestLineItemDetails details) {
    // END, CR00177241

    serviceInvoiceRequestLineItem.setCaseReferenceNumber(
      details.details.caseRefNum);
    serviceInvoiceRequestLineItem.setClientDateOfBirth(
      details.details.clientDateOfBirth);
    serviceInvoiceRequestLineItem.setClientFirstName(
      details.details.clientFirstName);
    serviceInvoiceRequestLineItem.setClientLastName(
      details.details.clientLastName);
    serviceInvoiceRequestLineItem.setClientReferenceNumber(
      details.details.clientRefNum);
    serviceInvoiceRequestLineItem.setInvoiceAmount(
      details.details.invoiceAmount);
    serviceInvoiceRequestLineItem.setNumberOfUnits(
      details.details.numberOfUnits);
    serviceInvoiceRequestLineItem.setPayeeName(details.details.payeeName);
    serviceInvoiceRequestLineItem.setPayeeReferenceNumber(
      details.details.payeeRefNum);
    serviceInvoiceRequestLineItem.setProviderName(details.details.providerName);
    serviceInvoiceRequestLineItem.setProviderReferenceNumber(
      details.details.providerRefNum);
    serviceInvoiceRequestLineItem.setServiceAuthorizationReferenceNumber(
      details.details.serviceAuthRefNum);
    serviceInvoiceRequestLineItem.setUnitAmount(details.details.unitAmount);
    serviceInvoiceRequestLineItem.setExternalReferenceNumber(
      details.details.externalRefNum);
    
    final ServiceOffering serviceOffering = serviceOfferingDAO.get(
      details.details.serviceID);
    
    serviceInvoiceRequestLineItem.setService(serviceOffering);
    
    final ServiceInvoiceRequest serviceInvoiceRequest = serviceInvoiceRequestDAO.get(
      details.details.serviceInvoiceRequestID);

    serviceInvoiceRequestLineItem.setServiceInvoiceRequest(
      serviceInvoiceRequest);
    DateRange dateRange = new DateRange(details.details.serviceStartDate,
      details.details.serviceEndDate);

    serviceInvoiceRequestLineItem.setDateRange(dateRange);

    return serviceInvoiceRequestLineItem;
  }

  /**
   * The client facing method to modify the Service Invoice Request Line
   * Item details
   *
   * @param details - contains the service Invoice Request Line Item details
   * @return A list of informational warnings to be displayed on the client
   *
   * @throws AppException
   * @throws InformationalException 
   */
  public ServiceInvoiceKeyAndInformationals modifyServiceInvoiceRequestLineItem(
    ServiceInvoiceRequestLineItemDetails details) throws AppException,
      InformationalException {
    
    ServiceInvoiceKeyAndInformationals result = new ServiceInvoiceKeyAndInformationals();
    
    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.get(
      details.details.serviceInvReqLineItemID);
    
    setServiceInvoiceRequestLineItemDetails(serviceInvoiceRequestLineItem,
      details);
    
    serviceInvoiceRequestLineItem.matchDetailsEntered(
      serviceInvoiceRequestLineItem, true);
    
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();
    
    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      result.informationalList.dtls.addRef(informationalMsgDtls);

    }

    // reset the informational manager
    TransactionInfo.setInformationalManager();
    
    if (serviceInvoiceRequestLineItem.getLifecycleState().equals(
      ServiceInvoiceRequestLineItemStatusEntry.CANCELED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICEREQUESTLINEITEMExceptionCreator.ERR_CANNOT_MODIFY_CANCELLED_RECORD(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    serviceInvoiceRequestLineItem.modify(details.details.versionNo);
    
    return result;
  }

  /**
   * The client facing method to view Service Invoice Request Line Item details
   *
   * @param key - contains the service Invoice Request Line Item ID
   *
   * @return - the details for Service Invoice Request record
   *
   * @throws AppException
   * @throws InformationalException
   */
  // CR00099017 KR changed the return type struct
  public ViewServiceInvoiceRequestLineItem viewServiceInvoiceRequestLineItem(
    ServiceInvoiceRequestLineItemKey key) throws AppException,
      InformationalException {

    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.get(
      key.serviceInvReqLineItemID);

    serviceInvoiceRequestLineItem.matchDetailsEntered(
      serviceInvoiceRequestLineItem, true);
    // Begin   CR00099017 KR Added the information messages.
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();
          
    ViewServiceInvoiceRequestLineItem viewServiceInvoiceRequestLineItemDetails = new ViewServiceInvoiceRequestLineItem();
          
    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();
    viewServiceInvoiceRequestLineItemDetails = getServiceInvoiceRequestLineItemDetails(
      serviceInvoiceRequestLineItem);
    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      viewServiceInvoiceRequestLineItemDetails.infoMessageList.dtls.addRef(
        informationalMsgDtls);

    }

    // reset the informational manager
    TransactionInfo.setInformationalManager();
    // End  CR00099017 KR Added the information messages.
      
    return viewServiceInvoiceRequestLineItemDetails;

  }

  /**
   * This method cancels a Service Invoice Request Line Item record by setting
   * its status to canceled.
   *
   * @param details - contains the service Invoice Request Line Item ID and
   * the versionNO
   *
   * @throws AppException
   * @throws InformationalException
   */
  public void cancelServiceInvoiceRequestLineItem(
    SIRequestLIVersionIDKey details) throws AppException, InformationalException {
    
    ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.get(
      details.serviceInvoiceRequestLineItemID);
    
    serviceInvoiceRequestLineItem.cancel(details.versionNo);
  }

  /**
   * This method retrieves all service invoice request line items for an
   * associated service Invoice Request record
   *
   * @param key - contains the service Invoice Request ID
   *
   * @return - the list of service invoice request line item records for a
   * service invoice request.
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ServiceInvoiceRequestLISummaryDetailsList listSIRequestLineItemsBySIRequestID(
    ServiceInvoiceRequestLineItemReadmultiKey key) throws AppException, InformationalException {

    // get the service invoice request
    ServiceInvoiceRequest serviceInvoiceRequest = serviceInvoiceRequestDAO.get(
      key.serviceInvoiceRequestID);

    // result variable
    ServiceInvoiceRequestLISummaryDetailsList serviceInvoiceRequestLISummaryDetailsList = new ServiceInvoiceRequestLISummaryDetailsList();

    // retrieve list of service invoice request line items
    for (final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItems:
      serviceInvoiceRequestLineItemDAO.searchByServiceInvoiceRequest(
      serviceInvoiceRequest)) {

      ServiceInvoiceRequestLISummaryDetails serviceInvoiceRequestLISummaryDetails = new ServiceInvoiceRequestLISummaryDetails();

      setInvoiceRequestLineItemDetails(serviceInvoiceRequestLineItems,
        serviceInvoiceRequestLISummaryDetails);

      serviceInvoiceRequestLISummaryDetailsList.details.addRef(
        serviceInvoiceRequestLISummaryDetails);
    
    }

    return serviceInvoiceRequestLISummaryDetailsList;
  }

  // BEGIN, CR00228977, GP
  /**
   * Lists all the service invoice request line items for a service invoice
   * request.
   *
   * @param ServiceInvoiceRequestLineItemReadmultiKey
   * Contains service invoice request id.
   *
   * @return List of all the service invoice request line items for a service
   * invoice request.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ServiceInvoiceRequestLISummaryVersionDetailsList listSIRequestLineItemsForServiceInvoiceRequest(
    ServiceInvoiceRequestLineItemReadmultiKey ServiceInvoiceRequestLineItemReadmultiKey)
    throws AppException, InformationalException {

    ServiceInvoiceRequest serviceInvoiceRequest = serviceInvoiceRequestDAO.get(
      ServiceInvoiceRequestLineItemReadmultiKey.serviceInvoiceRequestID);

    ServiceInvoiceRequestLISummaryVersionDetailsList serviceInvoiceRequestLISummaryVersionDetailsList = new ServiceInvoiceRequestLISummaryVersionDetailsList();

    for (final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItems : serviceInvoiceRequestLineItemDAO.searchByServiceInvoiceRequest(
      serviceInvoiceRequest)) {

      ServiceInvoiceRequestLISummaryVersionDetails serviceInvoiceRequestLISummaryVersionDetails = new ServiceInvoiceRequestLISummaryVersionDetails();

      setInvoiceRequestLineItemVersionDetails(serviceInvoiceRequestLineItems,
        serviceInvoiceRequestLISummaryVersionDetails);

      serviceInvoiceRequestLISummaryVersionDetailsList.serviceInvoiceRequestLISummaryVersionDetails.addRef(
        serviceInvoiceRequestLISummaryVersionDetails);

    }

    return serviceInvoiceRequestLISummaryVersionDetailsList;
  }

  // END, CR00228977

  /**
   * This method sets all of the request line item details
   *
   * N.B. This cannot be modeled as one of the arguments is not
   * generated
   *
   * @param serviceInvoiceRequestLineItem - contains the service invoice
   * Request line item object
   * @param serviceInvoiceRequestLISummaryDetails - contains all the details
   */
  // BEGIN, CR00177241, PM
  protected void setInvoiceRequestLineItemDetails(
    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem,
    ServiceInvoiceRequestLISummaryDetails serviceInvoiceRequestLISummaryDetails) {
    // END, CR00177241

    // set the details
    serviceInvoiceRequestLISummaryDetails.amountInvoiced = serviceInvoiceRequestLineItem.getInvoiceAmount();
    serviceInvoiceRequestLISummaryDetails.clientName = serviceInvoiceRequestLineItem.getClientFirstName()
      + CuramConst.gkSpace + serviceInvoiceRequestLineItem.getClientLastName();
    serviceInvoiceRequestLISummaryDetails.numberOfUnits = serviceInvoiceRequestLineItem.getNumberOfUnits(); 
    serviceInvoiceRequestLISummaryDetails.serviceInvoiceRequestLineItemID = serviceInvoiceRequestLineItem.getID();
    serviceInvoiceRequestLISummaryDetails.amountInvoiced = serviceInvoiceRequestLineItem.getInvoiceAmount();
    
    // BEGIN, CR00158345, GP 
    List<ServiceInvoiceRequestLineItemClient> serviceInvoiceRequestLineItemClients = sortSILIRequestClientByClientName(
      serviceInvoiceRequestLineItem.getServiceInvoiceRequestLineItemClients());

    ServiceInvoiceRequestLineItemClient serviceInvoiceRequestLineItemClient = serviceInvoiceRequestLineItemClients.iterator().next();

    serviceInvoiceRequestLISummaryDetails.clientName = serviceInvoiceRequestLineItemClient.getClientFirstName()
      + CuramConst.gkSpace
      + serviceInvoiceRequestLineItemClient.getClientLastName();
    // END, CR00158345
    
    serviceInvoiceRequestLISummaryDetails.numberOfUnits = serviceInvoiceRequestLineItem.getNumberOfUnits(); 
    serviceInvoiceRequestLISummaryDetails.service = serviceInvoiceRequestLineItem.getService().getName();
    serviceInvoiceRequestLISummaryDetails.serviceInvoiceRequestLineItemID = serviceInvoiceRequestLineItem.getID();
    serviceInvoiceRequestLISummaryDetails.status = serviceInvoiceRequestLineItem.getLifecycleState().getCode();
    
  }

  // BEGIN, CR00228977, GP
  /**
   * Sets all of the request line item details.
   *
   * @param serviceInvoiceRequestLineItem
   * The service invoice request line item details.
   * @param serviceInvoiceRequestLISummaryVersionDetails
   * Service invoice request line struct which has to be populated.
   */
  protected void setInvoiceRequestLineItemVersionDetails(
    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem,
    ServiceInvoiceRequestLISummaryVersionDetails serviceInvoiceRequestLISummaryVersionDetails) {

    serviceInvoiceRequestLISummaryVersionDetails.amountInvoiced = serviceInvoiceRequestLineItem.getInvoiceAmount();
    serviceInvoiceRequestLISummaryVersionDetails.clientName = serviceInvoiceRequestLineItem.getClientFirstName()
      + CuramConst.gkSpace + serviceInvoiceRequestLineItem.getClientLastName();
    serviceInvoiceRequestLISummaryVersionDetails.numberOfUnits = serviceInvoiceRequestLineItem.getNumberOfUnits();
    serviceInvoiceRequestLISummaryVersionDetails.serviceInvoiceRequestLineItemID = serviceInvoiceRequestLineItem.getID();
    serviceInvoiceRequestLISummaryVersionDetails.amountInvoiced = serviceInvoiceRequestLineItem.getInvoiceAmount();

    List<ServiceInvoiceRequestLineItemClient> serviceInvoiceRequestLineItemClients = sortSILIRequestClientByClientName(
      serviceInvoiceRequestLineItem.getServiceInvoiceRequestLineItemClients());

    ServiceInvoiceRequestLineItemClient serviceInvoiceRequestLineItemClient = serviceInvoiceRequestLineItemClients.iterator().next();

    serviceInvoiceRequestLISummaryVersionDetails.clientName = serviceInvoiceRequestLineItemClient.getClientFirstName()
      + CuramConst.gkSpace
      + serviceInvoiceRequestLineItemClient.getClientLastName();

    serviceInvoiceRequestLISummaryVersionDetails.numberOfUnits = serviceInvoiceRequestLineItem.getNumberOfUnits();
    serviceInvoiceRequestLISummaryVersionDetails.service = serviceInvoiceRequestLineItem.getService().getName();
    serviceInvoiceRequestLISummaryVersionDetails.serviceInvoiceRequestLineItemID = serviceInvoiceRequestLineItem.getID();
    serviceInvoiceRequestLISummaryVersionDetails.status = serviceInvoiceRequestLineItem.getLifecycleState().getCode();
    serviceInvoiceRequestLISummaryVersionDetails.versionNo = serviceInvoiceRequestLineItem.getVersionNo();
  }

  // END, CR00228977
  
  /**
   * This method sets all of the request line item details
   *
   * N.B. This cannot be modeled as one of the arguments is not
   * generated
   *
   * @param serviceInvoiceRequestLineItem - contains the service invoice
   * Request line item object
   * @return serviceInvoiceRequestLineItemDtls - contains all the details
   */
  // CR00099017 KR changed the return type struct
  // BEGIN, CR00177241, PM
  protected ViewServiceInvoiceRequestLineItem getServiceInvoiceRequestLineItemDetails(
    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem) {
    // END, CR00177241

    final ViewServiceInvoiceRequestLineItem serviceInvoiceRequestLineItemDetails = new ViewServiceInvoiceRequestLineItem();

    // get the details
    serviceInvoiceRequestLineItemDetails.viewDetails.details.caseRefNum = serviceInvoiceRequestLineItem.getCaseReferenceNumber();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.clientDateOfBirth = serviceInvoiceRequestLineItem.getClientDateOfBirth();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.clientFirstName = serviceInvoiceRequestLineItem.getClientFirstName();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.clientLastName = serviceInvoiceRequestLineItem.getClientLastName();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.clientRefNum = serviceInvoiceRequestLineItem.getClientReferenceNumber();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.externalRefNum = serviceInvoiceRequestLineItem.getExternalReferenceNumber();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.invoiceAmount = serviceInvoiceRequestLineItem.getInvoiceAmount();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.numberOfUnits = serviceInvoiceRequestLineItem.getNumberOfUnits();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.payeeName = serviceInvoiceRequestLineItem.getPayeeName();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.payeeRefNum = serviceInvoiceRequestLineItem.getPayeeReferenceNumber();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.providerName = serviceInvoiceRequestLineItem.getProviderName();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.providerRefNum = serviceInvoiceRequestLineItem.getProviderReferenceNumber();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.referenceNumber = serviceInvoiceRequestLineItem.getReferenceNumber();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.serviceAuthRefNum = serviceInvoiceRequestLineItem.getServiceAuthorizationReferenceNumber();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.serviceEndDate = serviceInvoiceRequestLineItem.getDateRange().end();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.serviceInvoiceRequestID = serviceInvoiceRequestLineItem.getServiceInvoiceRequest().getID();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.serviceInvReqLineItemID = serviceInvoiceRequestLineItem.getID();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.serviceStartDate = serviceInvoiceRequestLineItem.getDateRange().start();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.status = serviceInvoiceRequestLineItem.getLifecycleState().getCode();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.unitAmount = serviceInvoiceRequestLineItem.getUnitAmount();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.versionNo = serviceInvoiceRequestLineItem.getVersionNo();
    serviceInvoiceRequestLineItemDetails.viewDetails.service = serviceInvoiceRequestLineItem.getService().getName();
    serviceInvoiceRequestLineItemDetails.viewDetails.details.serviceID = serviceInvoiceRequestLineItem.getService().getID();
      
    return serviceInvoiceRequestLineItemDetails;
  }

  // BEGIN, CR00158345, GP
  /**
   * Adds a client to service invoice request line item. Client details are matched to
   * see if they match with the registered person.
   *
   * @param serviceInvoiceRequestLineItemClientDetails
   * The details of the client to be added to service invoice request line
   * item.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addClientToServiceInvoiceRequestLineItem(
    ServiceInvoiceRequestLineItemClientDetails serviceInvoiceRequestLineItemClientDetails)
    throws AppException, InformationalException {

    ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.get(
      serviceInvoiceRequestLineItemClientDetails.serviceInvRequestLineItemID);

    ServiceInvoiceRequestLineItemClient serviceInvoiceRequestLineItemClient = serviceInvoiceRequestLineItemClientDAO.newInstance();

    serviceInvoiceRequestLineItemClient.setClientDateOfBirth(
      serviceInvoiceRequestLineItemClientDetails.clientDateOfBirth);
    serviceInvoiceRequestLineItemClient.setClientFirstName(
      serviceInvoiceRequestLineItemClientDetails.clientFirstName);
    serviceInvoiceRequestLineItemClient.setClientLastName(
      serviceInvoiceRequestLineItemClientDetails.clientLastName);
    serviceInvoiceRequestLineItemClient.setClientReferenceNo(
      serviceInvoiceRequestLineItemClientDetails.clientReferenceNo);
    serviceInvoiceRequestLineItemClient.setServiceInvoiceRequestLineItem(
      serviceInvoiceRequestLineItem);
    serviceInvoiceRequestLineItemClient.insert();

  }

  /**
   * Lists all the client details for a give service invoice request line item.
   * Client information can be present in service invoice request line item
   * table or service invoice request line item client table. This method lists
   * the client details present in both the tables.
   *
   * @param serviceInvoiceRequestLineItemKey
   * Contains service invoice request line item ID for which client
   * details are to be retrieved.
   *
   * @return List of clients for the given service invoice request line item.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ServiceInvoiceRequestLineItemClientDetailsList listClientsForServiceInvReqLineItem(
    ServiceInvoiceRequestLineItemKey serviceInvoiceRequestLineItemKey)
    throws AppException, InformationalException {

    ServiceInvoiceRequestLineItemClientDetailsList serviceInvoiceRequestLineItemClientDetailsList = new ServiceInvoiceRequestLineItemClientDetailsList();
    ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.get(
      serviceInvoiceRequestLineItemKey.serviceInvReqLineItemID);

    Set<ServiceInvoiceRequestLineItemClient> serviceInvoiceRequestLineItemClients = serviceInvoiceRequestLineItem.getServiceInvoiceRequestLineItemClients();

    for (ServiceInvoiceRequestLineItemClient serviceInvoiceRequestLineItemClient : serviceInvoiceRequestLineItemClients) {

      ServiceInvoiceRequestLineItemClientDetails serviceInvoiceRequestLineItemClientDetails = new ServiceInvoiceRequestLineItemClientDetails();

      serviceInvoiceRequestLineItemClientDetails.clientDateOfBirth = serviceInvoiceRequestLineItemClient.getClientDateOfBirth();
      serviceInvoiceRequestLineItemClientDetails.clientFirstName = serviceInvoiceRequestLineItemClient.getClientFirstName();
      serviceInvoiceRequestLineItemClientDetails.clientLastName = serviceInvoiceRequestLineItemClient.getClientLastName();
      serviceInvoiceRequestLineItemClientDetails.clientReferenceNo = serviceInvoiceRequestLineItemClient.getClientReferenceNo();

      if (null != serviceInvoiceRequestLineItemClient.getID()) {
        serviceInvoiceRequestLineItemClientDetails.serviceInvReqLineItemClientID = serviceInvoiceRequestLineItemClient.getID();
      }

      serviceInvoiceRequestLineItemClientDetails.serviceInvRequestLineItemID = serviceInvoiceRequestLineItem.getID();

      serviceInvoiceRequestLineItemClientDetailsList.clientDetails.addRef(
        serviceInvoiceRequestLineItemClientDetails);
    }

    return serviceInvoiceRequestLineItemClientDetailsList;
  }

  /**
   * Removes the given client from a service invoice request line item.
   *
   * @param serviceInvoiceRequestLineItemAndClientKey
   * Contains service invoice request line item id and service invoice
   * request line item client id. If the service invoice request line
   * item client id is zero then client is present in service invoice
   * request line item table. service invoice request line item table
   * will be modified to enter blank/null in client details field. If
   * the service invoice request line item client id is not zero that
   * means client is present in service invoice request line item
   * client table. Row with service invoice request line item client id
   * will be removed from service invoice request line item client
   * table.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link SERVICEINVOICEREQUESTLINEITEM#ERR_SERVICEINVOICEREQLINEITEM_XRV_THIS_SERVICE_INVOICE_REQUEST_LINE_ITEM_MUST_HAVE_ATLEAST_ONE_CLIENT} -
   * If the client to be removed is the last client of service invoice
   * request line item.
   */
  public void removeClientFromServiceInvReqLineItem(
    ServiceInvoiceRequestLineItemAndClientKey serviceInvoiceRequestLineItemAndClientKey)
    throws AppException, InformationalException {

    if (0
      != serviceInvoiceRequestLineItemAndClientKey.serviceInvReqLineItemClientID) {

      ServiceInvoiceRequestLineItemClient serviceInvoiceRequestLineItemClient = serviceInvoiceRequestLineItemClientDAO.get(
        serviceInvoiceRequestLineItemAndClientKey.serviceInvReqLineItemClientID);

      serviceInvoiceRequestLineItemClient.remove();
    } else {

      ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.get(
        serviceInvoiceRequestLineItemAndClientKey.serviceInvReqLineItemID);

      if (0
        == serviceInvoiceRequestLineItemClientDAO.searchByServiceInvoiceRequestLineItem(serviceInvoiceRequestLineItem).size()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          SERVICEINVOICEREQUESTLINEITEMExceptionCreator.ERR_SERVICEINVOICEREQLINEITEM_XRV_THIS_SERVICE_INVOICE_REQUEST_LINE_ITEM_MUST_HAVE_ATLEAST_ONE_CLIENT(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }

      serviceInvoiceRequestLineItem.setClientReferenceNumber(CuramConst.gkEmpty);
      serviceInvoiceRequestLineItem.setClientFirstName(CuramConst.gkEmpty);
      serviceInvoiceRequestLineItem.setClientLastName(CuramConst.gkEmpty);
      serviceInvoiceRequestLineItem.setClientDateOfBirth(Date.kZeroDate);
      serviceInvoiceRequestLineItem.setClientID(0l);
      serviceInvoiceRequestLineItem.modify(
        serviceInvoiceRequestLineItem.getVersionNo());
    }

  }

  // BEGIN, CR00208353, AS
  /**
   * Modifies the service invoice request line item record. It also matches the
   * details entered on the screen and shows the informational message if there
   * is any validation failure.
   *
   * @param sIRequestInvoiceLineItemDetails
   * Service invoice request line item details to be modified.
   *
   * @return Contains service invoice ID to which this service invoice line item
   * belongs and informationals, if there are any validation failures.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ServiceInvoiceKeyAndInformationals updateServiceInvoiceRequestLineItem(
    SIRequestInvoiceLineItemDetails sIRequestInvoiceLineItemDetails)
    throws AppException, InformationalException {

    ServiceInvoiceKeyAndInformationals serviceInvoiceKeyAndInformationals = new ServiceInvoiceKeyAndInformationals();

    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.get(
      sIRequestInvoiceLineItemDetails.details.serviceInvReqLineItemID);

    setServiceInvoiceRequestLineItemDetails(serviceInvoiceRequestLineItem,
      sIRequestInvoiceLineItemDetails);

    ServiceInvoiceRequestLineItemClientDetailsList serviceInvoiceRequestLineItemClientDetailsList = WidgetHelper.convertXmlToServiceInvoiceRequestLineItemClientDetailsList(
      sIRequestInvoiceLineItemDetails.clientDetails);

    for (final ServiceInvoiceRequestLineItemClientDetails serviceInvoiceRequestLineItemClientDetails : serviceInvoiceRequestLineItemClientDetailsList.clientDetails.items()) {
      if (0
        == serviceInvoiceRequestLineItemClientDetails.serviceInvReqLineItemClientID) {
        serviceInvoiceRequestLineItem.setClientReferenceNumber(
          serviceInvoiceRequestLineItemClientDetails.clientReferenceNo);
        serviceInvoiceRequestLineItem.setClientDateOfBirth(
          serviceInvoiceRequestLineItemClientDetails.clientDateOfBirth);
        serviceInvoiceRequestLineItem.setClientFirstName(
          serviceInvoiceRequestLineItemClientDetails.clientFirstName);
        serviceInvoiceRequestLineItem.setClientLastName(
          serviceInvoiceRequestLineItemClientDetails.clientLastName);

      } else {
        ServiceInvoiceRequestLineItemClient serviceInvoiceRequestLineItemClient = serviceInvoiceRequestLineItemClientDAO.get(
          serviceInvoiceRequestLineItemClientDetails.serviceInvReqLineItemClientID);

        serviceInvoiceRequestLineItemClient.setClientDateOfBirth(
          serviceInvoiceRequestLineItemClientDetails.clientDateOfBirth);
        serviceInvoiceRequestLineItemClient.setClientFirstName(
          serviceInvoiceRequestLineItemClientDetails.clientFirstName);
        serviceInvoiceRequestLineItemClient.setClientLastName(
          serviceInvoiceRequestLineItemClientDetails.clientLastName);
        serviceInvoiceRequestLineItemClient.setClientReferenceNo(
          serviceInvoiceRequestLineItemClientDetails.clientReferenceNo);
        serviceInvoiceRequestLineItemClient.setServiceInvoiceRequestLineItem(
          serviceInvoiceRequestLineItem);
        serviceInvoiceRequestLineItemClient.modify(
          serviceInvoiceRequestLineItemClient.getVersionNo());
      }
    }
    serviceInvoiceRequestLineItem.matchDetailsEntered(
      serviceInvoiceRequestLineItem, true);

    serviceInvoiceRequestLineItem.modify(
      sIRequestInvoiceLineItemDetails.details.versionNo);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    String[] matchedResults = null;

    matchedResults = informationalManager.obtainInformationalAsString();

    InformationalMsgDtls informationalMsgDtls = null;

    for (String matchResults : matchedResults) {

      informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchResults;

      serviceInvoiceKeyAndInformationals.informationalList.dtls.addRef(
        informationalMsgDtls);
    }

    TransactionInfo.setInformationalManager();

    return serviceInvoiceKeyAndInformationals;
  }

  // END, CR00208353

  /**
   * Modifies the service invoice request line item. It also matches the details
   * entered on the screen and shows the informational message if there is any
   * validation failure.
   *
   * @param serviceInvReqLineItemDetails
   * Service invoice request line item details to be modified.
   *
   * @return Contains service invoice ID to which this service invoice line item
   * belongs and informationals, if there are any validation failures.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 , replaced with
   * {@link curam.cpm.eua.facade.impl.ExternalServiceInvoiceRequestLineItem#updateServiceInvoiceRequestLineItem(SIRequestInvoiceLineItemDetails)}
   * . Previously the size of the external reference number had 20
   * characters, in order to allow maximum of 18 characters, a new
   * domain definition of size 18, struct and method are created.
   * See release note: CR00208353.
   */
  @Deprecated
  public ServiceInvoiceKeyAndInformationals modifyServiceInvReqLineItem(
    ServiceInvReqLineItemDetails serviceInvReqLineItemDetails)
    throws AppException, InformationalException {

    ServiceInvoiceKeyAndInformationals result = new ServiceInvoiceKeyAndInformationals();

    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.get(
      serviceInvReqLineItemDetails.details.serviceInvReqLineItemID);

    setServiceInvoiceRequestLineItemDetails(serviceInvoiceRequestLineItem,
      serviceInvReqLineItemDetails);

    ServiceInvoiceRequestLineItemClientDetailsList serviceInvoiceRequestLineItemClientDetailsList = WidgetHelper.convertXmlToServiceInvoiceRequestLineItemClientDetailsList(
      serviceInvReqLineItemDetails.clientDetails);

    for (ServiceInvoiceRequestLineItemClientDetails serviceInvoiceRequestLineItemClientDetails : serviceInvoiceRequestLineItemClientDetailsList.clientDetails.items()) {
      if (0
        == serviceInvoiceRequestLineItemClientDetails.serviceInvReqLineItemClientID) {
        serviceInvoiceRequestLineItem.setClientReferenceNumber(
          serviceInvoiceRequestLineItemClientDetails.clientReferenceNo);
        serviceInvoiceRequestLineItem.setClientDateOfBirth(
          serviceInvoiceRequestLineItemClientDetails.clientDateOfBirth);
        serviceInvoiceRequestLineItem.setClientFirstName(
          serviceInvoiceRequestLineItemClientDetails.clientFirstName);
        serviceInvoiceRequestLineItem.setClientLastName(
          serviceInvoiceRequestLineItemClientDetails.clientLastName);

      } else {
        ServiceInvoiceRequestLineItemClient serviceInvoiceRequestLineItemClient = serviceInvoiceRequestLineItemClientDAO.get(
          serviceInvoiceRequestLineItemClientDetails.serviceInvReqLineItemClientID);

        serviceInvoiceRequestLineItemClient.setClientDateOfBirth(
          serviceInvoiceRequestLineItemClientDetails.clientDateOfBirth);
        serviceInvoiceRequestLineItemClient.setClientFirstName(
          serviceInvoiceRequestLineItemClientDetails.clientFirstName);
        serviceInvoiceRequestLineItemClient.setClientLastName(
          serviceInvoiceRequestLineItemClientDetails.clientLastName);
        serviceInvoiceRequestLineItemClient.setClientReferenceNo(
          serviceInvoiceRequestLineItemClientDetails.clientReferenceNo);
        serviceInvoiceRequestLineItemClient.setServiceInvoiceRequestLineItem(
          serviceInvoiceRequestLineItem);
        serviceInvoiceRequestLineItemClient.modify(
          serviceInvoiceRequestLineItemClient.getVersionNo());
      }
    }
    
    serviceInvoiceRequestLineItem.matchDetailsEntered(
      serviceInvoiceRequestLineItem, true);

    serviceInvoiceRequestLineItem.modify(
      serviceInvReqLineItemDetails.details.versionNo);
    
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();
    
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      result.informationalList.dtls.addRef(informationalMsgDtls);

    }

    TransactionInfo.setInformationalManager();

    return result;
  }

  /**
   * Views the service invoice request line item details and shows the
   * informationals if there are any validation failures.
   *
   * @param serviceInvoiceRequestLineItemKey
   * Primary key of the service invoice request line item to be viewed.
   *
   * @return Service invoice request line item details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewServiceInvReqLineItemDetails viewServiceInvReqLineItem(
    ServiceInvoiceRequestLineItemKey serviceInvoiceRequestLineItemKey)
    throws AppException, InformationalException {

    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.get(
      serviceInvoiceRequestLineItemKey.serviceInvReqLineItemID);

    serviceInvoiceRequestLineItem.matchDetailsEntered(
      serviceInvoiceRequestLineItem, true);
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    ViewServiceInvReqLineItemDetails viewServiceInvReqLineItemDetails = new ViewServiceInvReqLineItemDetails();

    matchedResults = informationalManager.obtainInformationalAsString();
    viewServiceInvReqLineItemDetails = getServiceInvReqLineItemDetails(
      serviceInvoiceRequestLineItem);
    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      viewServiceInvReqLineItemDetails.infoMessageList.dtls.addRef(
        informationalMsgDtls);

    }

    TransactionInfo.setInformationalManager();

    ServiceInvoiceRequestLineItemClientDetailsList serviceInvoiceRequestLineItemClientDetailsList = listClientsForServiceInvReqLineItem(
      serviceInvoiceRequestLineItemKey);

    viewServiceInvReqLineItemDetails.viewDetails.clientDetails = WidgetHelper.convertServiceInvoiceRequestLineItemClientDetailsToXml(
      serviceInvoiceRequestLineItemClientDetailsList);

    return viewServiceInvReqLineItemDetails;
  }  
  
  /**
   * Creates a copy of the service invoice request line item from the existing
   * service invoice request line item.
   *
   * @param serviceInvReqLineItemDetails
   * Details of service invoice request line item to be created.
   *
   * @return service invoice ID to which this service invoice line item belongs
   * and informationals, if there are any validation failures.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ServiceInvoiceKeyAndInformationals createDuplicateServiceInvoiceRequestLineItem(
    ServiceInvReqLineItemDetails serviceInvReqLineItemDetails)
    throws AppException, InformationalException {

    ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.newInstance();

    ServiceInvoiceKeyAndInformationals result = new ServiceInvoiceKeyAndInformationals();

    setServiceInvoiceRequestLineItemDetails(serviceInvoiceRequestLineItem,
      serviceInvReqLineItemDetails);

    ServiceOffering serviceOffering = serviceOfferingDAO.get(
      serviceInvReqLineItemDetails.details.serviceID);

    if (serviceOffering.getPlacementPaymentInd()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICELINEITEM_XRV_SERVICEOFFERING_WITH_PLACEMENTPAYMENT(
          serviceOffering.getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }

    InformationalManager info = TransactionInfo.getInformationalManager();

    info.failOperation();

    ServiceInvoiceRequestLineItemClientDetailsList serviceInvoiceRequestLineItemClientDetailsList = WidgetHelper.convertXmlToServiceInvoiceRequestLineItemClientDetailsList(
      serviceInvReqLineItemDetails.clientDetails);

    for (ServiceInvoiceRequestLineItemClientDetails serviceInvoiceRequestLineItemClientDetails : serviceInvoiceRequestLineItemClientDetailsList.clientDetails.items()) {
      if (0
        == serviceInvoiceRequestLineItemClientDetails.serviceInvReqLineItemClientID) {
        serviceInvoiceRequestLineItem.setClientReferenceNumber(
          serviceInvoiceRequestLineItemClientDetails.clientReferenceNo);
        serviceInvoiceRequestLineItem.setClientDateOfBirth(
          serviceInvoiceRequestLineItemClientDetails.clientDateOfBirth);
        serviceInvoiceRequestLineItem.setClientFirstName(
          serviceInvoiceRequestLineItemClientDetails.clientFirstName);
        serviceInvoiceRequestLineItem.setClientLastName(
          serviceInvoiceRequestLineItemClientDetails.clientLastName);

      }
    }

    // Call method to match the details entered with what is
    // currently on the system.
    serviceInvoiceRequestLineItem.matchDetailsEntered(
      serviceInvoiceRequestLineItem, true);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      result.informationalList.dtls.addRef(informationalMsgDtls);

    }

    // Reset the informational manager
    TransactionInfo.setInformationalManager();

    serviceInvoiceRequestLineItem.insert();

    for (ServiceInvoiceRequestLineItemClientDetails serviceInvoiceRequestLineItemClientDetails : serviceInvoiceRequestLineItemClientDetailsList.clientDetails.items()) {

      if (0
        != serviceInvoiceRequestLineItemClientDetails.serviceInvReqLineItemClientID) {
        ServiceInvoiceRequestLineItemClient serviceInvoiceRequestLineItemClient = serviceInvoiceRequestLineItemClientDAO.newInstance();

        serviceInvoiceRequestLineItemClient.setClientDateOfBirth(
          serviceInvoiceRequestLineItemClientDetails.clientDateOfBirth);
        serviceInvoiceRequestLineItemClient.setClientFirstName(
          serviceInvoiceRequestLineItemClientDetails.clientFirstName);
        serviceInvoiceRequestLineItemClient.setClientLastName(
          serviceInvoiceRequestLineItemClientDetails.clientLastName);
        serviceInvoiceRequestLineItemClient.setClientReferenceNo(
          serviceInvoiceRequestLineItemClientDetails.clientReferenceNo);
        serviceInvoiceRequestLineItemClient.setServiceInvoiceRequestLineItem(
          serviceInvoiceRequestLineItem);
        serviceInvoiceRequestLineItemClient.insert();
      }
    }

    result.key.serviceInvReqLineItemID = serviceInvoiceRequestLineItem.getID();

    return result;
  }
  
  /**
   * Gets the service invoice request line item details.
   *
   * @param serviceInvoiceRequestLineItem
   * Service invoice request line item details.
   *
   * @return Service invoice request line item details to be viewed.
   */
  protected ViewServiceInvReqLineItemDetails getServiceInvReqLineItemDetails(
    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem) {

    final ViewServiceInvReqLineItemDetails viewServiceInvReqLineItemDetails = new ViewServiceInvReqLineItemDetails();

    viewServiceInvReqLineItemDetails.viewDetails.details.caseRefNum = serviceInvoiceRequestLineItem.getCaseReferenceNumber();
    viewServiceInvReqLineItemDetails.viewDetails.details.clientDateOfBirth = serviceInvoiceRequestLineItem.getClientDateOfBirth();
    viewServiceInvReqLineItemDetails.viewDetails.details.clientFirstName = serviceInvoiceRequestLineItem.getClientFirstName();
    viewServiceInvReqLineItemDetails.viewDetails.details.clientLastName = serviceInvoiceRequestLineItem.getClientLastName();
    viewServiceInvReqLineItemDetails.viewDetails.details.clientRefNum = serviceInvoiceRequestLineItem.getClientReferenceNumber();
    viewServiceInvReqLineItemDetails.viewDetails.details.externalRefNum = serviceInvoiceRequestLineItem.getExternalReferenceNumber();
    viewServiceInvReqLineItemDetails.viewDetails.details.invoiceAmount = serviceInvoiceRequestLineItem.getInvoiceAmount();
    viewServiceInvReqLineItemDetails.viewDetails.details.numberOfUnits = serviceInvoiceRequestLineItem.getNumberOfUnits();
    viewServiceInvReqLineItemDetails.viewDetails.details.payeeName = serviceInvoiceRequestLineItem.getPayeeName();
    viewServiceInvReqLineItemDetails.viewDetails.details.payeeRefNum = serviceInvoiceRequestLineItem.getPayeeReferenceNumber();
    viewServiceInvReqLineItemDetails.viewDetails.details.providerName = serviceInvoiceRequestLineItem.getProviderName();
    viewServiceInvReqLineItemDetails.viewDetails.details.providerRefNum = serviceInvoiceRequestLineItem.getProviderReferenceNumber();
    viewServiceInvReqLineItemDetails.viewDetails.details.referenceNumber = serviceInvoiceRequestLineItem.getReferenceNumber();
    viewServiceInvReqLineItemDetails.viewDetails.details.serviceAuthRefNum = serviceInvoiceRequestLineItem.getServiceAuthorizationReferenceNumber();
    viewServiceInvReqLineItemDetails.viewDetails.details.serviceEndDate = serviceInvoiceRequestLineItem.getDateRange().end();
    viewServiceInvReqLineItemDetails.viewDetails.details.serviceInvoiceRequestID = serviceInvoiceRequestLineItem.getServiceInvoiceRequest().getID();
    viewServiceInvReqLineItemDetails.viewDetails.details.serviceInvReqLineItemID = serviceInvoiceRequestLineItem.getID();
    viewServiceInvReqLineItemDetails.viewDetails.details.serviceStartDate = serviceInvoiceRequestLineItem.getDateRange().start();
    viewServiceInvReqLineItemDetails.viewDetails.details.status = serviceInvoiceRequestLineItem.getLifecycleState().getCode();
    viewServiceInvReqLineItemDetails.viewDetails.details.unitAmount = serviceInvoiceRequestLineItem.getUnitAmount();
    viewServiceInvReqLineItemDetails.viewDetails.details.versionNo = serviceInvoiceRequestLineItem.getVersionNo();
    viewServiceInvReqLineItemDetails.viewDetails.service = serviceInvoiceRequestLineItem.getService().getName();
    viewServiceInvReqLineItemDetails.viewDetails.details.serviceID = serviceInvoiceRequestLineItem.getService().getID();
      
    return viewServiceInvReqLineItemDetails;
  }
  
  /**
   * Sets the service invoice request line item details.
   *
   * @param serviceInvoiceRequestLineItem
   * Service invoice request line item to which the details are to be
   * set.
   * @param serviceInvReqLineItemDetails
   * Service invoice request line item details that have to be set.
   *
   * @return Service invoice request line item to which the details are set.
   */
  protected ServiceInvoiceRequestLineItem setServiceInvoiceRequestLineItemDetails(
    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem,
    ServiceInvReqLineItemDetails serviceInvReqLineItemDetails) {

    serviceInvoiceRequestLineItem.setCaseReferenceNumber(
      serviceInvReqLineItemDetails.details.caseRefNum);
    serviceInvoiceRequestLineItem.setClientDateOfBirth(
      serviceInvReqLineItemDetails.details.clientDateOfBirth);
    serviceInvoiceRequestLineItem.setClientFirstName(
      serviceInvReqLineItemDetails.details.clientFirstName);
    serviceInvoiceRequestLineItem.setClientLastName(
      serviceInvReqLineItemDetails.details.clientLastName);
    serviceInvoiceRequestLineItem.setClientReferenceNumber(
      serviceInvReqLineItemDetails.details.clientRefNum);
    serviceInvoiceRequestLineItem.setInvoiceAmount(
      serviceInvReqLineItemDetails.details.invoiceAmount);
    serviceInvoiceRequestLineItem.setNumberOfUnits(
      serviceInvReqLineItemDetails.details.numberOfUnits);
    serviceInvoiceRequestLineItem.setPayeeName(
      serviceInvReqLineItemDetails.details.payeeName);
    serviceInvoiceRequestLineItem.setPayeeReferenceNumber(
      serviceInvReqLineItemDetails.details.payeeRefNum);
    serviceInvoiceRequestLineItem.setProviderName(
      serviceInvReqLineItemDetails.details.providerName);
    serviceInvoiceRequestLineItem.setProviderReferenceNumber(
      serviceInvReqLineItemDetails.details.providerRefNum);
    serviceInvoiceRequestLineItem.setServiceAuthorizationReferenceNumber(
      serviceInvReqLineItemDetails.details.serviceAuthRefNum);
    serviceInvoiceRequestLineItem.setUnitAmount(
      serviceInvReqLineItemDetails.details.unitAmount);
    serviceInvoiceRequestLineItem.setExternalReferenceNumber(
      serviceInvReqLineItemDetails.details.externalRefNum);

    final ServiceOffering serviceOffering = serviceOfferingDAO.get(
      serviceInvReqLineItemDetails.details.serviceID);

    serviceInvoiceRequestLineItem.setService(serviceOffering);

    final ServiceInvoiceRequest serviceInvoiceRequest = serviceInvoiceRequestDAO.get(
      serviceInvReqLineItemDetails.details.serviceInvoiceRequestID);

    serviceInvoiceRequestLineItem.setServiceInvoiceRequest(
      serviceInvoiceRequest);
    DateRange dateRange = new DateRange(
      serviceInvReqLineItemDetails.details.serviceStartDate,
      serviceInvReqLineItemDetails.details.serviceEndDate);

    serviceInvoiceRequestLineItem.setDateRange(dateRange);

    return serviceInvoiceRequestLineItem;
  }  
  
  /**
   * Sorts the list of service invoice request line item clients by client name.
   *
   * @param unsortedServiceInvoiceRequestLineItemClients
   * Unsorted set of service invoice request line item clients.
   * @return Sorted list of service invoice request line item clients.
   */
  protected List<ServiceInvoiceRequestLineItemClient> sortSILIRequestClientByClientName(
    Set<ServiceInvoiceRequestLineItemClient> unsortedServiceInvoiceRequestLineItemClients) {

    final List<ServiceInvoiceRequestLineItemClient> serviceInvoiceRequestLineItemClientList = new ArrayList<ServiceInvoiceRequestLineItemClient>(
      unsortedServiceInvoiceRequestLineItemClients);

    Collections.sort(serviceInvoiceRequestLineItemClientList,
      new Comparator<ServiceInvoiceRequestLineItemClient>() {
      public int compare(final ServiceInvoiceRequestLineItemClient lhs,
        ServiceInvoiceRequestLineItemClient rhs) {
        return (lhs.getClientFirstName() + CPMConstants.kSpace + lhs.getClientLastName()).compareTo(
          rhs.getClientFirstName() + CPMConstants.kSpace
          + rhs.getClientLastName());
      }
    });

    return serviceInvoiceRequestLineItemClientList;
  }

  // END, CR00158345
  
  // BEGIN, CR00199005, SSK
  /**
   * Creates a new service invoice request line item record.
   *
   * @param serviceInvoiceRequestInvoiceLineItemDetails
   * Contains the details for creating a new Service Invoice request
   * Line Item record.
   *
   * @return The key containing the unique ID for the newly created record and a
   * list of warning messages.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ServiceInvoiceKeyAndInformationals addServiceInvoiceRequestLineItem(
    SIRequestInvoiceLineItemDetails serviceInvoiceRequestInvoiceLineItemDetails)
    throws AppException, InformationalException {

    ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.newInstance();

    ServiceInvoiceKeyAndInformationals result = new ServiceInvoiceKeyAndInformationals();

    setServiceInvoiceRequestLineItemDetails(serviceInvoiceRequestLineItem,
      serviceInvoiceRequestInvoiceLineItemDetails);

    // BEGIN, CR00208353, AS
    ServiceOffering serviceOffering = serviceOfferingDAO.get(
      serviceInvoiceRequestInvoiceLineItemDetails.details.serviceID);

    // END, CR00208353

    if (serviceOffering.getPlacementPaymentInd()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICELINEITEMExceptionCreator.ERR_SERVICEINVOICELINEITEM_XRV_SERVICEOFFERING_WITH_PLACEMENTPAYMENT(
          serviceOffering.getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }
    InformationalManager info = TransactionInfo.getInformationalManager();

    info.failOperation();
    serviceInvoiceRequestLineItem.matchDetailsEntered(
      serviceInvoiceRequestLineItem, true);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] matchedResults = informationalManager.obtainInformationalAsString();

    matchedResults = informationalManager.obtainInformationalAsString();
    
    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      result.informationalList.dtls.addRef(informationalMsgDtls);

    }

    TransactionInfo.setInformationalManager();

    serviceInvoiceRequestLineItem.insert();

    result.key.serviceInvReqLineItemID = serviceInvoiceRequestLineItem.getID();

    return result;

  }

  /**
   * This method sets the details for the service invoice request record.
   *
   * @param serviceInvoiceRequestLineItem
   * The service invoice request line item object that needs to be
   * set
   * @param serviceInvoiceRequestInvoiceLineItemDetails
   * Contains the details for setting the Service Invoice Request
   * Line Item record
   *
   * @return The Service Invoice Request Line Item object containing all details
   * set
   */
  protected ServiceInvoiceRequestLineItem setServiceInvoiceRequestLineItemDetails(
    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem,
    final SIRequestInvoiceLineItemDetails serviceInvoiceRequestInvoiceLineItemDetails) {

    serviceInvoiceRequestLineItem.setCaseReferenceNumber(
      serviceInvoiceRequestInvoiceLineItemDetails.details.caseRefNum);
    serviceInvoiceRequestLineItem.setClientDateOfBirth(
      serviceInvoiceRequestInvoiceLineItemDetails.details.clientDateOfBirth);
    serviceInvoiceRequestLineItem.setClientFirstName(
      serviceInvoiceRequestInvoiceLineItemDetails.details.clientFirstName);
    serviceInvoiceRequestLineItem.setClientLastName(
      serviceInvoiceRequestInvoiceLineItemDetails.details.clientLastName);
    serviceInvoiceRequestLineItem.setClientReferenceNumber(
      serviceInvoiceRequestInvoiceLineItemDetails.details.clientRefNum);
    serviceInvoiceRequestLineItem.setInvoiceAmount(
      serviceInvoiceRequestInvoiceLineItemDetails.details.invoiceAmount);
    serviceInvoiceRequestLineItem.setNumberOfUnits(
      serviceInvoiceRequestInvoiceLineItemDetails.details.numberOfUnits);
    serviceInvoiceRequestLineItem.setPayeeName(
      serviceInvoiceRequestInvoiceLineItemDetails.details.payeeName);
    serviceInvoiceRequestLineItem.setPayeeReferenceNumber(
      serviceInvoiceRequestInvoiceLineItemDetails.details.payeeRefNum);
    serviceInvoiceRequestLineItem.setProviderName(
      serviceInvoiceRequestInvoiceLineItemDetails.details.providerName);
    serviceInvoiceRequestLineItem.setProviderReferenceNumber(
      serviceInvoiceRequestInvoiceLineItemDetails.details.providerRefNum);
    serviceInvoiceRequestLineItem.setServiceAuthorizationReferenceNumber(
      serviceInvoiceRequestInvoiceLineItemDetails.details.serviceAuthRefNum);
    serviceInvoiceRequestLineItem.setUnitAmount(
      serviceInvoiceRequestInvoiceLineItemDetails.details.unitAmount);
    // BEGIN, CR00208353, AS
    serviceInvoiceRequestLineItem.setExternalReferenceNumber(
      serviceInvoiceRequestInvoiceLineItemDetails.externalReferenceNo);

    final ServiceOffering serviceOffering = serviceOfferingDAO.get(
      serviceInvoiceRequestInvoiceLineItemDetails.details.serviceID);

    // END, CR00208353

    serviceInvoiceRequestLineItem.setService(serviceOffering);

    final ServiceInvoiceRequest serviceInvoiceRequest = serviceInvoiceRequestDAO.get(
      serviceInvoiceRequestInvoiceLineItemDetails.details.serviceInvoiceRequestID);

    serviceInvoiceRequestLineItem.setServiceInvoiceRequest(
      serviceInvoiceRequest);
    final DateRange dateRange = new DateRange(
      serviceInvoiceRequestInvoiceLineItemDetails.details.serviceStartDate,
      serviceInvoiceRequestInvoiceLineItemDetails.details.serviceEndDate);

    serviceInvoiceRequestLineItem.setDateRange(dateRange);

    return serviceInvoiceRequestLineItem;
  }
  
  // END, CR00199005
}
