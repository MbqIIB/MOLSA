/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.RECORDSTATUS;
import curam.codetable.SYSTEMTICKET;
import curam.codetable.TASKPRIORITY;
import curam.codetable.TICKETTYPE;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.RESERVATIONCANCELREASONEntry;
import curam.codetable.impl.RESERVATIONSTATUSEntry;
import curam.codetable.impl.SYSTEMTICKETEntry;
import curam.codetable.impl.TASKPRIORITYEntry;
import curam.codetable.impl.TICKETTYPEEntry;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.NotificationFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.TimeZoneUtility;
import curam.core.intf.CaseHeader;
import curam.core.intf.Notification;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.NotificationDetails;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.ModifyPlacementCommentsAndPeriodDetails;
import curam.cpm.facade.struct.ModifyPlacementDetails;
import curam.cpm.facade.struct.PlaceLocationDetails;
import curam.cpm.facade.struct.PlacementInformation;
import curam.cpm.facade.struct.PlacementPeriodDetails;
import curam.cpm.facade.struct.PlacementsList;
import curam.cpm.facade.struct.ProviderKey;
import curam.cpm.facade.struct.TransferClientPlacementDetails;
import curam.cpm.facade.struct.TransferPlacementDetails;
import curam.cpm.facade.struct.ViewPlacementTransferSummaryDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.PlaceByDateRange;
import curam.cpm.sl.entity.struct.PlaceKey;
import curam.cpm.sl.entity.struct.PlacementKey;
import curam.cpm.sl.entity.struct.ProviderOfferingIDAndDateTimeKey;
import curam.cpm.sl.entity.struct.ReservationKey;
import curam.message.PLACEMENT;
import curam.message.impl.PLACEMENTExceptionCreator;
import curam.message.impl.RESERVATIONExceptionCreator;
import curam.place.impl.Compartment;
import curam.place.impl.CompartmentDAO;
import curam.place.impl.Place;
import curam.place.impl.PlaceDAO;
import curam.place.impl.PlacementAPI;
import curam.place.impl.PlacementAPIImpl;
import curam.place.impl.PlacementDAO;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderSecurity;
import curam.providerservice.impl.ProviderOffering;
import curam.reservation.impl.Reservation;
import curam.reservation.impl.ReservationDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.LifecycleHelper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.DateTimeRange;


/**
 * {@inheritDoc}
 */
public abstract class Placement extends curam.cpm.facade.base.Placement {

  /**
   * Placement DAO object.
   */
  @Inject
  protected PlacementDAO placementDAO;

  /**
   * Place DAO object.
   */
  @Inject
  protected PlaceDAO placeDAO;

  /**
   * providerSecurity type of ProviderSecurity.
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * Compartment DAO object.
   */
  @Inject
  protected CompartmentDAO compartmentDAO;

  /**
   * Provider DAO object.
   */
  @Inject
  protected ProviderDAO providerDAO;

  // BEGIN, CR00103966, RPB
  /**
   * Reservation DAO object.
   */
  @Inject
  protected ReservationDAO reservationDAO;

  // END, CR00103966

  /**
   * Constructor for the class.
   */
  public Placement() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00293856, IBM
  /**
   * Resolves whether a Placement is to be transferred into new Placement or a
   * Reservation based on the transfer date time.
   *
   * @param transferPlacementDetails
   * Contains Placement transfer details.
   * @return The placement transfer details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 5.2 SP5, replaced with {@link 
   * Placement#solveTransferClient(TransferPlacementDetails)}
   *
   * This method is deprecated as informational messages are not returned. 
   * This method is replaced by solveTransferClient(TransferPlacementDetails) 
   * which returns the informational message along with place details as well. 
   * See release note: CS-09152/CR00293856.         
   */
  // BEGIN, CR00098327, SG
  @Deprecated
  public TransferPlacementDetails resolveTransferClient(
    TransferPlacementDetails transferPlacementDetails) throws AppException,
      InformationalException {
    // END, CR00293856
     
    // Get the old Placement.
    curam.place.impl.Placement oldPlacement = placementDAO.get(
      transferPlacementDetails.placementID);

    // Validate transfer details.
    validateTransfer(transferPlacementDetails, oldPlacement);
    ValidationHelper.failIfErrorsExist();

    // Check if the transfer placement date time is entered.
    boolean startDateTimeZero = transferPlacementDetails.startDate.isZero();

    // Get the current date time without seconds.
    Calendar calendar = DateTime.getCurrentDateTime().getCalendar();

    calendar.set(Calendar.SECOND, 0);
    DateTime currentDateTime = new DateTime(calendar);

    // If transfer placement date time is not entered or it is entered as
    // current date time then transfer the current Placement into new
    // Placement with new Place.
    // BEGIN, CR00132299, SS
    if (startDateTimeZero
      || transferPlacementDetails.startDate.equals(currentDateTime)
      || transferPlacementDetails.startDate.before(currentDateTime)) {
      // END, CR00132299
      // Transfer the client into new Place.
      PlacementKey placementKey = transferClient(transferPlacementDetails);

      // Set the Placement ID and Placement created indicator to true.
      transferPlacementDetails.placementID = placementKey.placementID;
      transferPlacementDetails.placementTransferred = true;
    } else {

      // Set the Placement created indicator to false.
      transferPlacementDetails.placementTransferred = false;
    }
    return transferPlacementDetails;
  }

  // END, CR00098327

  // BEGIN, CR00120678, SS
  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00098327, SG
  public PlacementKey transferClient(
    TransferPlacementDetails transferPlacementDetails) throws AppException,
      InformationalException {

    // Get the old Placement.

    curam.place.impl.Placement oldPlacement = placementDAO.get(
      transferPlacementDetails.placementID);
    Place place = placeDAO.get(transferPlacementDetails.placeID);

    PlacementKey placementKey = new PlacementKey();

    placementKey.placementID = oldPlacement.transferClient(
      transferPlacementDetails.startDate, place,
      transferPlacementDetails.placementVersionNo);

    return placementKey;
  }

  // END, CR00098327

  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00098327, SG
  public ReservationKey transferClientToReservation(
    TransferPlacementDetails transferPlacementDetails) throws AppException,
      InformationalException {

    // Get the old Placement.
    curam.place.impl.Placement oldPlacement = placementDAO.get(
      transferPlacementDetails.placementID);
    Place place = placeDAO.get(transferPlacementDetails.placeID);
    ReservationKey reservationKey = new ReservationKey();

    reservationKey.reservationID = oldPlacement.transferClientToReservation(
      transferPlacementDetails.startDate, place,
      transferPlacementDetails.placementVersionNo);

    return reservationKey;
  }

  // END, CR00098327
  // END, CR00120678

  // BEGIN, CR00236076, AK
  /**
   * Modifies the Placement period for an existing placement of a client.
   *
   * @param placementDetails
   * Contains Placement details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link PLACEMENT# ERR_PLACEMENT_XRV_NO_PLACEMENT_EXISTS_FOR_THE_SELECTED_PLACE}
   * - If no Placement exists for selected Place.
   *
   * @throws InformationalException
   * {@link PLACEMENT# ERR_PLACEMENT_RV_PLACEMENT_ALREADY_ENDED_CANNOT_BE_MODIFIED}
   * - If Placement is already ended it cannot be modified.
   * @deprecated Since Curam 6.0 replaced by {@link #modifyPlacementDetails}.
   * This method cannot be useful for providing an option to cancel
   * an active reservation on a placement, if exists for the given
   * period. Hence this method is deprecated. The newly added method
   * 'modifyPlacementDetails' will give this option to the user. See
   * release note: CR00169295.
   */
  @Deprecated
  // END, CR00236076
  public void modifyPlacementInformation(PlacementPeriodDetails placementDetails)
    throws AppException, InformationalException {

    curam.place.impl.Place placeEntity = placeDAO.get(placementDetails.placeID);

    // Check provider security
    providerSecurity.checkProviderSecurity(
      placeEntity.getCompartment().getProvider());

    if (placementDetails.placementID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new curam.util.exception.AppException(curam.message.PLACEMENT.ERR_PLACEMENT_XRV_NO_PLACEMENT_EXISTS_FOR_THE_SELECTED_PLACE).arg(
          placeEntity.getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }
    PlacementAPI placementAPI = new PlacementAPIImpl();

    DateTimeRange dateTime = new DateTimeRange(placementDetails.startDate,
      placementDetails.endDate);

    // BEGIN, CR00096779, ABS
    Integer versionNo = Integer.valueOf(placementDetails.versionNo);

    Integer placeVersionNo = Integer.valueOf(placementDetails.placeVersionNo);

    // END, CR00096779
    placementAPI.updatePlacementPeriod(placementDetails.placementID, dateTime,
      versionNo, placeVersionNo);

    // Notification manipulation variables
    Notification notificationObj = NotificationFactory.newInstance();
    NotificationDetails notificationDtls = new NotificationDetails();

    // Set up the alternative subject and msg
    AppException reasonMsg = new AppException(
      PLACEMENT.PLACEMENT_MODIFICATION_NOTIFICATION_MESSAGE);

    // Get the Server Locale.
    String serverLocale = ProgramLocale.getDefaultServerLocale();

    curam.place.impl.Placement placement = placementDAO.get(
      placementDetails.placementID);
    // reasonMsg.arg(processName);
    // The mechanism to get the value will be included in a future SDE
    Place place = placeDAO.get(placement.getPlace().getID());
    String unavailable = place.getName();

    reasonMsg.arg(unavailable);

    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = placement.getCaseParticipantRoleID();
    CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleDtls caseParticipantRoleDtls = caseParticipantRole.read(
      caseParticipantRoleKey);

    // CaseHeader manipulation variables
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    caseHeaderKey.caseID = caseParticipantRoleDtls.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    notificationDtls.concernRoleID = caseHeaderDtls.concernRoleID;
    notificationDtls.caseID = caseParticipantRoleDtls.caseID;
    notificationDtls.subject = PLACEMENT.PLACEMENT_MODIFICATION_NOTIFICATION_SUBJECT.getMessageText(
      serverLocale);
    notificationDtls.reasonText = reasonMsg.toString();

    notificationDtls.currPriority = TASKPRIORITY.NORMAL;
    notificationDtls.ticketType = TICKETTYPE.USERNOTIFICATION;
    notificationDtls.ticketGenInd = SYSTEMTICKET.GENDEFERREDPROCESSINGFAILEDTICKET;

    // create notification
    notificationObj.createNotification(notificationDtls);

  }

  // BEGIN, CR00169295, AK
  /**
   * {@inheritDoc}
   */
  public ModifyPlacementDetails modifyPlacementDetails(
    ModifyPlacementDetails placementDetails) throws AppException,
      InformationalException {

    Place placeEntity = placeDAO.get(
      placementDetails.placementPeriodDtls.placeID);

    // Check provider security
    providerSecurity.checkProviderSecurity(
      placeEntity.getCompartment().getProvider());

    if (placementDetails.placementPeriodDtls.placementID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new curam.util.exception.AppException(curam.message.PLACEMENT.ERR_PLACEMENT_XRV_NO_PLACEMENT_EXISTS_FOR_THE_SELECTED_PLACE).arg(
          placeEntity.getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    PlacementAPI placementAPI = new PlacementAPIImpl();

    DateTimeRange dateTime = new DateTimeRange(
      placementDetails.placementPeriodDtls.startDate,
      placementDetails.placementPeriodDtls.endDate);

    Integer versionNo = Integer.valueOf(
      placementDetails.placementPeriodDtls.versionNo);

    Integer placeVersionNo = Integer.valueOf(
      placementDetails.placementPeriodDtls.placeVersionNo);

    long placementID = placementDetails.placementPeriodDtls.placementID;

    DateTimeRange placementPeriod = new DateTimeRange(
      placementDetails.placementPeriodDtls.startDate,
      placementDetails.placementPeriodDtls.endDate);

    Place placeObj = placementDAO.get(placementID).getPlace();

    List<Reservation> activeReservations = reservationDAO.searchOverlappingActiveReservationsForPlace(
      placeObj, placementPeriod);

    if (activeReservations.size() > 0
      && !placementDetails.reservationIndicatorDtls.cancelActiveReservationInd) {

      placementDetails.reservationIndicatorDtls.activeReservationExistsInd = true;
      return placementDetails;

    } else if (placementDetails.reservationIndicatorDtls.cancelActiveReservationInd) {

      for (Reservation reservation : activeReservations) {
        reservation.cancel(reservation.getVersionNo(),
          RESERVATIONCANCELREASONEntry.OVERRRIDENBYPLACEMENT);
      }

      placementDetails.reservationIndicatorDtls.activeReservationExistsInd = false;
    }

    placementAPI.updatePlacementPeriod(
      placementDetails.placementPeriodDtls.placementID, dateTime, versionNo,
      placeVersionNo);

    Notification notificationObj = NotificationFactory.newInstance();
    NotificationDetails notificationDtls = new NotificationDetails();

    // Set up the alternative subject and msg
    AppException reasonMsg = new AppException(
      PLACEMENT.PLACEMENT_MODIFICATION_NOTIFICATION_MESSAGE);

    String serverLocale = ProgramLocale.getDefaultServerLocale();

    curam.place.impl.Placement placement = placementDAO.get(
      placementDetails.placementPeriodDtls.placementID);

    // The mechanism to get the value will be included in a future SDE
    Place place = placeDAO.get(placement.getPlace().getID());
    String unavailable = place.getName();

    reasonMsg.arg(unavailable);

    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = placement.getCaseParticipantRoleID();
    CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleDtls caseParticipantRoleDtls = caseParticipantRole.read(
      caseParticipantRoleKey);

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    caseHeaderKey.caseID = caseParticipantRoleDtls.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    notificationDtls.concernRoleID = caseHeaderDtls.concernRoleID;
    notificationDtls.caseID = caseParticipantRoleDtls.caseID;
    notificationDtls.subject = PLACEMENT.PLACEMENT_MODIFICATION_NOTIFICATION_SUBJECT.getMessageText(
      serverLocale);
    notificationDtls.reasonText = reasonMsg.toString();

    notificationDtls.currPriority = TASKPRIORITY.NORMAL;
    notificationDtls.ticketType = TICKETTYPE.USERNOTIFICATION;
    notificationDtls.ticketGenInd = SYSTEMTICKET.GENDEFERREDPROCESSINGFAILEDTICKET;

    notificationObj.createNotification(notificationDtls);

    return placementDetails;
  }

  // END, CR00169295

  // BEGIN, CR00155774, AK
  /**
   * {@inheritDoc}
   */
  public InformationalMessageList searchReservationByPlaceAndDateTimeRange(
    PlacementPeriodDetails placementDetails) throws AppException,
      InformationalException {

    InformationalMessageList messageList = new InformationalMessageList();

    long placementID = placementDetails.placementID;

    DateTimeRange placementPeriod = new DateTimeRange(
      placementDetails.startDate, placementDetails.endDate);

    Place placeObj = placementDAO.get(placementID).getPlace();

    List<Reservation> reservations = reservationDAO.searchOverlappingActiveReservationsForPlace(
      placeObj, placementPeriod);

    if (reservations.size() > 0) {
      for (Reservation reservation : reservations) {

        AppException appException = RESERVATIONExceptionCreator.INF_PLACE_XRV_ACTIVE_RESERVATION_EXISTS_CONFIRM_CANCEL_RESERVATION(
          getUserTimzoneDate(reservation.getDateTimeRange().start()),
          getUserTimzoneDate(reservation.getDateTimeRange().end()));

        InformationalManager informationalManager = TransactionInfo.getInformationalManager();

        informationalManager.addInformationalMsg(appException,
          CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning);

        String warnings[] = informationalManager.obtainInformationalAsString();

        for (int i = 0; i < warnings.length; i++) {
          InformationalMessage infoMessage = new InformationalMessage();

          infoMessage.messageTest = warnings[i];
          messageList.dtls.addRef(infoMessage);
        }
      }
    }

    return messageList;
  }

  // END, CR00155774

  /**
   * {@inheritDoc}
   */
  public PlacementInformation viewPlacement(PlacementKey key)
    throws AppException, InformationalException {

    PlacementInformation placementInformation = new PlacementInformation();

    if (key.placementID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PLACEMENTExceptionCreator.ERR_PLACEMENT_XRV_NO_PLACEMENT_EXISTS_FOR_THE_PLACE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else {
      curam.place.impl.Placement placement = placementDAO.get(key.placementID);

      // BEGIN, CR00097331, GYH
      // populate the placement details to the return struct
      placementInformation = populatePlacementDetails(placement);
      // END, CR00097331
    }
    return placementInformation;
  }

  /**
   * {@inheritDoc}
   */
  public PlacementsList listPlacementsForProvider(ProviderKey key)
    throws AppException, InformationalException {

    PlacementsList placementsList = new PlacementsList();

    if (key.providerID != 0) {
      final curam.provider.impl.Provider provider = providerDAO.get(
        key.providerID);

      for (final ProviderOffering providerOffering : provider.getProviderOfferings()) {

        ProviderOfferingIDAndDateTimeKey providerOfferingKey = new ProviderOfferingIDAndDateTimeKey();

        providerOfferingKey.providerOfferingID = providerOffering.getID();
        providerOfferingKey.currentDateTime = DateTime.getCurrentDateTime();
        providerOfferingKey.placementStatus = RECORDSTATUS.NORMAL;

        Set<curam.place.impl.Placement> placements = placementDAO.searchPlacementsByProviderOffering(
          providerOfferingKey);

        for (final curam.place.impl.Placement placement : sortPlacementsByStartDate(
          placements)) {
          placementsList.details.addRef(populatePlacementDetails(placement));
        }
      }
    }
    return placementsList;

  }

  /**
   * Retrieves location for a specified Place.
   *
   * @param key
   * Contains Place ID.
   * @return The place location details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PlaceLocationDetails getLocationForPlace(PlaceKey key)
    throws AppException, InformationalException {
    PlaceLocationDetails locationDetails = new PlaceLocationDetails();
    curam.place.impl.Place place = placeDAO.get(key.placeID);
    Compartment currentCompartment = place.getCompartment();
    Compartment parentCompartment = currentCompartment.getParentCompartment();
    String location = "";

    if (parentCompartment != null) {
      location = buildLocation(parentCompartment, location);
    }
    location += currentCompartment.getName();
    locationDetails.location = location;
    return locationDetails;
  }

  /**
   * Converts the DateTime to Date according to the User TimeZone.
   *
   * @param dateTime
   * DateTime to be converted.
   * @return The converted date.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected Date getUserTimzoneDate(DateTime dateTime) throws AppException,
      InformationalException {
    // END, CR00177241
    Date userTimeZoneDate;

    if (dateTime.isZero()) {
      userTimeZoneDate = new Date(dateTime);
    } else {
      userTimeZoneDate = new Date(
        TimeZoneUtility.getTimeZoneAdjustedDateTime(dateTime,
        TransactionInfo.getUserTimeZone()));
    }
    return userTimeZoneDate;
  }

  /**
   * Gets the location of the Compartment and concatenates it.
   *
   * @param parentCompartment
   * Compartment contains parent Compartment ID.
   * @param location
   * Contains the location of the Place.
   * @return The location of the place after concatenate all the related
   * locations.
   */
  // BEGIN, CR00177241, PM
  protected String buildLocation(Compartment parentCompartment, String location) {
    // END, CR00177241
    if (parentCompartment != null) {
      Compartment currentCompartment = compartmentDAO.get(
        parentCompartment.getID());

      location = buildLocation(currentCompartment.getParentCompartment(),
        location);
      location += currentCompartment.getName() + CPMConstants.kGreaterThan;
    }
    return location;
  }

  /**
   * Populates the Placement details to the facade layer return struct.
   *
   * @param placement
   * Contains the placement details.
   * @return The placement details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected PlacementInformation populatePlacementDetails(
    curam.place.impl.Placement placement) throws AppException,
      InformationalException {
    // END, CR00177241

    PlacementInformation placementInformation = new PlacementInformation();

    // Populate Placement details.
    placementInformation.placementID = placement.getID();
    placementInformation.clientName = placement.getClient().getName();

    // BEGIN, CR00120983, GYH
    placementInformation.concernRoleID = placement.getClient().getID();
    placementInformation.concernRoleType = placement.getClient().getConcernRoleType().getCode();
    // BEGIN, CR00120983
    placementInformation.fromDate = placement.getDateTimeRange().start();
    placementInformation.toDate = placement.getDateTimeRange().end();
    placementInformation.serviceName = placement.getProviderOffering().getServiceOffering().getName();
    placementInformation.versionNo = placement.getVersionNo();

    PlaceKey placeKey = new PlaceKey();

    placeKey.placeID = placement.getPlace().getID();
    placementInformation.placeName = placement.getPlace().getName();
    placementInformation.placeID = placement.getPlace().getID();
    placementInformation.placeVersionNo = placement.getPlace().getVersionNo();
    placementInformation.comments = placement.getComments();

    // BEGIN, CR00103966, RPB
    // Get the fulfilled reservation for the Place.
    Set<Reservation> reservations = LifecycleHelper.filter(
      reservationDAO.searchReservationByPlace(
        placeDAO.get(placement.getPlace().getID())),
        RESERVATIONSTATUSEntry.FULFILLED);

    if (reservations.size() != 0) {
      placementInformation.relatedReservationInd = true;
      for (Reservation reservation : reservations) {
        placementInformation.relatedReservationID = reservation.getID();
      }
    } else {
      placementInformation.relatedReservationInd = false;
    }
    // END, CR00103966

    // Get the location details in specified format
    PlaceLocationDetails placeLocationDetails = getLocationForPlace(placeKey);

    placementInformation.placeLocation = placeLocationDetails.location;

    return placementInformation;
  }

  /**
   * Sorts the list of Placements for a Provider.
   *
   * @param unSortedlist
   * Contains the unsorted list of Placements.
   * @return The sorted list of Placements.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.place.impl.Placement> sortPlacementsByStartDate(
    final Set<curam.place.impl.Placement> unSortedlist) {
    // END, CR00177241

    final List<curam.place.impl.Placement> placement = new ArrayList<curam.place.impl.Placement>(
      unSortedlist);

    // BEGIN, CR00103963, RPB
    // The list is ordered by From date, earliest first
    Collections.sort(placement,
      new Comparator<curam.place.impl.Placement>() {
      public int compare(final curam.place.impl.Placement lhs,
        curam.place.impl.Placement rhs) {
        return lhs.getDateTimeRange().start().compareTo(
          rhs.getDateTimeRange().start());
      }
    });
    // END, CR00103963

    return placement;
  }

  // BEGIN, CR00200425, DRS
  /**
   * Validates the placement details for the transfer of client.
   *
   * @param transferPlacementDetails
   * Contains placement transfer details.
   * @param oldPlacement
   * Existing placement details.
   * @throws InformationalException
   * {@link PLACEMENT# ERR_PLACEMENT_XRV_NO_PLACEMENT_EXISTS_FOR_THE_PLACE}
   * - If old placement does not exist.
   * @throws InformationalException
   * {@link PLACEMENT# ERR_PLACEMENT_FV_PLACEMENT_STATUS_CANCELED} -
   * Only placements which are active can be transferred.
   * @throws InformationalException
   * {@link PLACEMENT# ERR_TRANSFER_XRV_PLACEMENT_FROMDATE_AFTER_PLACEMENT_TODATETIME}
   * - If from date of transfer is greater than to date of current
   * placement.
   * @throws InformationalException
   * {@link PLACEMENT# ERR_PLACEMENT_XRV_PLACE_NOT_AVAILABLE_PLACEMENT_CANOT_BE_DONE}
   * - If place is not available placement cannot be done.
   * @throws InformationalException
   * {@link PLACEMENT# ERR_PLACEMENT_FV_PLACEMENT_TODATETIME_AFTER_CURRENTDATETIME}
   * - Only placements which have a to date in the future or no to
   * date can be transferred.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00200425
  // BEGIN, CR00177241, PM
  protected void validateTransfer(
    TransferPlacementDetails transferPlacementDetails,
    curam.place.impl.Placement oldPlacement) throws AppException,
      InformationalException {
    // END, CR00177241

    if (transferPlacementDetails.placementID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PLACEMENTExceptionCreator.ERR_PLACEMENT_XRV_NO_PLACEMENT_EXISTS_FOR_THE_PLACE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      return;
    }

    // BEGIN, CR00138070, ABS
    // If the placement status is not active.
    if (!oldPlacement.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PLACEMENTExceptionCreator.ERR_PLACEMENT_FV_PLACEMENT_STATUS_CANCELED(
          RECORDSTATUSEntry.CANCELLED.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
      ValidationHelper.failIfErrorsExist();
    }

    // If the to date of the placement is before the current date time.
    if (!oldPlacement.getDateTimeRange().end().isZero()
      && oldPlacement.getDateTimeRange().end().before(
        DateTime.getCurrentDateTime())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PLACEMENTExceptionCreator.ERR_PLACEMENT_FV_PLACEMENT_TODATETIME_AFTER_CURRENTDATETIME(
          oldPlacement.getDateTimeRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END, CR00138070

    // BEGIN, CR00200425, DRS
    if (!transferPlacementDetails.startDate.isZero()
      && !oldPlacement.getDateTimeRange().end().isZero()
      && transferPlacementDetails.startDate.after(
        oldPlacement.getDateTimeRange().end())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PLACEMENTExceptionCreator.ERR_TRANSFER_XRV_PLACEMENT_FROMDATE_AFTER_PLACEMENT_TODATETIME(
          transferPlacementDetails.startDate,
          oldPlacement.getDateTimeRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END, CR00200425

    // BEGIN, CR00089220, NP
    boolean pastDate = false;

    // BEGIN, CR00200425, DRS
    if (!transferPlacementDetails.startDate.isZero()
      && !transferPlacementDetails.startDate.after(
        oldPlacement.getDateTimeRange().start())) {

      pastDate = true;
    }
    // END, CR00200425
    // END, CR00089220

    // Check if the place is available in the placement date range.
    PlaceByDateRange placeByDateRange = new PlaceByDateRange();

    curam.place.impl.Placement placement = placementDAO.get(
      transferPlacementDetails.placementID);

    placeByDateRange.placeID = transferPlacementDetails.placeID;
    // If from date not mentioned then search start date should be placement
    // start date.
    if (!transferPlacementDetails.startDate.isZero()) {
      placeByDateRange.startDate = getUserTimzoneDate(
        transferPlacementDetails.startDate);
      placeByDateRange.placementStartDateTime = transferPlacementDetails.startDate;
    } else {
      placeByDateRange.startDate = getUserTimzoneDate(
        placement.getDateTimeRange().start());
      placeByDateRange.placementStartDateTime = placement.getDateTimeRange().start();
    }

    // BEGIN, CR00177555, NS
    placeByDateRange.recordStatus = RECORDSTATUSEntry.CANCELLED.getCode();
    placeByDateRange.placementStatus = RECORDSTATUSEntry.NORMAL.getCode();
    // END, CR00177555

    // Search till the end date of current placement.
    placeByDateRange.endDate = getUserTimzoneDate(
      placement.getDateTimeRange().end());
    placeByDateRange.endDateEntered = !placeByDateRange.endDate.isZero();
    placeByDateRange.placementEndDateTime = placement.getDateTimeRange().end();

    boolean available = false;

    // BEGIN, CR00177555, NS
    for (Place availablePlace : placeDAO.searchPlaceStatusByDateTimeRange(
      placeByDateRange)) {
      // END, CR00177555
      if (availablePlace.getID() == transferPlacementDetails.placeID) {
        available = true;
      }
    }
    // BEGIN, CR00089220, NP
    if (!available && !pastDate) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PLACEMENTExceptionCreator.ERR_PLACEMENT_XRV_PLACE_NOT_AVAILABLE_PLACEMENT_CANOT_BE_DONE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();
    // END, CR00089220
  }

  // BEGIN, CR00188227, SSK
  /**
   * {@inheritDoc}
   */
  public ModifyPlacementCommentsAndPeriodDetails modifyPlacementCommentsAndPeriodDetails(
    final ModifyPlacementCommentsAndPeriodDetails modifyPlacementCommentsAndPeriodDetails)
    throws AppException, InformationalException {

    Place placeEntity = placeDAO.get(
      modifyPlacementCommentsAndPeriodDetails.placementPeriodDtls.placeID);

    providerSecurity.checkProviderSecurity(
      placeEntity.getCompartment().getProvider());

    if (CPMConstants.kZeroLong
      == modifyPlacementCommentsAndPeriodDetails.placementPeriodDtls.placementID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new curam.util.exception.AppException(curam.message.PLACEMENT.ERR_PLACEMENT_XRV_NO_PLACEMENT_EXISTS_FOR_THE_SELECTED_PLACE).arg(
          placeEntity.getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }
    PlacementAPI placementAPI = new PlacementAPIImpl();

    DateTimeRange dateTime = new DateTimeRange(
      modifyPlacementCommentsAndPeriodDetails.placementPeriodDtls.startDate,
      modifyPlacementCommentsAndPeriodDetails.placementPeriodDtls.endDate);

    Integer versionNo = Integer.valueOf(
      modifyPlacementCommentsAndPeriodDetails.placementPeriodDtls.versionNo);

    Integer placeVersionNo = Integer.valueOf(
      modifyPlacementCommentsAndPeriodDetails.placementPeriodDtls.placeVersionNo);

    long placementID = modifyPlacementCommentsAndPeriodDetails.placementPeriodDtls.placementID;

    DateTimeRange placementPeriod = new DateTimeRange(
      modifyPlacementCommentsAndPeriodDetails.placementPeriodDtls.startDate,
      modifyPlacementCommentsAndPeriodDetails.placementPeriodDtls.endDate);

    Place placeObj = placementDAO.get(placementID).getPlace();

    List<Reservation> activeReservations = reservationDAO.searchOverlappingActiveReservationsForPlace(
      placeObj, placementPeriod);

    if (activeReservations.size() > 0
      && !modifyPlacementCommentsAndPeriodDetails.reservationIndicatorDtls.cancelActiveReservationInd) {

      modifyPlacementCommentsAndPeriodDetails.reservationIndicatorDtls.activeReservationExistsInd = true;
      return modifyPlacementCommentsAndPeriodDetails;

    } else if (modifyPlacementCommentsAndPeriodDetails.reservationIndicatorDtls.cancelActiveReservationInd) {

      for (Reservation reservation : activeReservations) {
        reservation.cancel(reservation.getVersionNo(),
          RESERVATIONCANCELREASONEntry.OVERRRIDENBYPLACEMENT);
      }

      modifyPlacementCommentsAndPeriodDetails.reservationIndicatorDtls.activeReservationExistsInd = false;
    }

    placementAPI.updatePlacementPeriodAndComments(
      modifyPlacementCommentsAndPeriodDetails.placementPeriodDtls.placementID,
      dateTime, modifyPlacementCommentsAndPeriodDetails.comments, versionNo,
      placeVersionNo);

    Notification notificationObj = NotificationFactory.newInstance();
    NotificationDetails notificationDtls = new NotificationDetails();

    AppException reasonMsg = new AppException(
      PLACEMENT.PLACEMENT_MODIFICATION_NOTIFICATION_MESSAGE);

    String serverLocale = ProgramLocale.getDefaultServerLocale();

    curam.place.impl.Placement placement = placementDAO.get(
      modifyPlacementCommentsAndPeriodDetails.placementPeriodDtls.placementID);

    Place place = placeDAO.get(placement.getPlace().getID());
    String unavailable = place.getName();

    reasonMsg.arg(unavailable);

    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = placement.getCaseParticipantRoleID();
    CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleDtls caseParticipantRoleDtls = caseParticipantRole.read(
      caseParticipantRoleKey);

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    caseHeaderKey.caseID = caseParticipantRoleDtls.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    notificationDtls.concernRoleID = caseHeaderDtls.concernRoleID;
    notificationDtls.caseID = caseParticipantRoleDtls.caseID;
    notificationDtls.subject = PLACEMENT.PLACEMENT_MODIFICATION_NOTIFICATION_SUBJECT.getMessageText(
      serverLocale);
    notificationDtls.reasonText = reasonMsg.toString();

    notificationDtls.currPriority = TASKPRIORITYEntry.NORMAL.getCode();
    notificationDtls.ticketType = TICKETTYPEEntry.USERNOTIFICATION.getCode();
    notificationDtls.ticketGenInd = SYSTEMTICKETEntry.GENDEFERREDPROCESSINGFAILEDTICKET.getCode();

    notificationObj.createNotification(notificationDtls);

    return modifyPlacementCommentsAndPeriodDetails;

  }

  /**
   * {@inheritDoc}
   */
  public ViewPlacementTransferSummaryDetails viewPlacementTransferSummary(
    final TransferPlacementDetails transferPlacementDetails)
    throws AppException, InformationalException {

    curam.place.impl.Placement placement = placementDAO.get(
      transferPlacementDetails.placementID);
  
    ViewPlacementTransferSummaryDetails viewPlacementTransferSummaryDetails = new ViewPlacementTransferSummaryDetails();
    // BEGIN, CR00247132, VR 
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
  
    AppException appException = PLACEMENTExceptionCreator.TEXT_PLACEMENT_TRANSFER_CONFIRMATION_MESSAGE(
      placement.getClient().getName(),
      TimeZoneUtility.getTimeZoneAdjustedDateTime(
        transferPlacementDetails.startDate, TransactionInfo.getUserTimeZone()));

    informationalManager.addInformationalMsg(appException, CuramConst.gkEmpty,
      InformationalElement.InformationalType.kWarning);

    String warnings[] = informationalManager.obtainInformationalAsString();

    for (final String warning : warnings) {
      InformationalMsgDtls infoMessage = new InformationalMsgDtls();

      infoMessage.informationMsgTxt = warning;
      viewPlacementTransferSummaryDetails.msg.dtls.addRef(infoMessage);
    }
    viewPlacementTransferSummaryDetails.startDate = transferPlacementDetails.startDate;
    // END, CR00247132
    
    return viewPlacementTransferSummaryDetails;
  }

  // END, CR00188227
  
  // BEGIN, CR00293856, IBM
  /**
   * {@inheritDoc}
   */
  public TransferClientPlacementDetails solveTransferClient(
    final TransferPlacementDetails transferPlacementDetails)
    throws AppException, InformationalException {

    curam.place.impl.Placement oldPlacement = placementDAO.get(
      transferPlacementDetails.placementID);

    TransferClientPlacementDetails clientPlacementDetails = new TransferClientPlacementDetails();

    validateTransfer(transferPlacementDetails, oldPlacement);
    ValidationHelper.failIfErrorsExist();

    boolean startDateTimeZero = transferPlacementDetails.startDate.isZero();

    Calendar calendar = DateTime.getCurrentDateTime().getCalendar();

    calendar.set(Calendar.SECOND, 0);
    DateTime currentDateTime = new DateTime(calendar);

    if (startDateTimeZero
      || transferPlacementDetails.startDate.equals(currentDateTime)
      || transferPlacementDetails.startDate.before(currentDateTime)) {
      PlacementKey placementKey = transferClient(transferPlacementDetails);

      transferPlacementDetails.placementID = placementKey.placementID;
      transferPlacementDetails.placementTransferred = true;
    } else {
      transferPlacementDetails.placementTransferred = false;
    }

    clientPlacementDetails.placementID = transferPlacementDetails.placementID;
    clientPlacementDetails.placeID = transferPlacementDetails.placeID;
    clientPlacementDetails.startDate = transferPlacementDetails.startDate;
    clientPlacementDetails.placementVersionNo = transferPlacementDetails.placementVersionNo;
    clientPlacementDetails.placementTransferred = transferPlacementDetails.placementTransferred;

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    String[] infoMsgs = informationalManager.obtainInformationalAsString();

    for (String infoMsg : infoMsgs) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = infoMsg;
      clientPlacementDetails.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }
      
    return clientPlacementDetails;
  }
  // END, CR00293856
}
