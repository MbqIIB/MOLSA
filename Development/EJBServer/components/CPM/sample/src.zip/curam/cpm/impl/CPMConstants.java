/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2013
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.impl;


/**
 * This class assigns values to the CPM constants
 */
public abstract class CPMConstants {

  /**
   * String constant for %.
   */
  public static final String kPercentage = "%";

  // BEGIN, CR00121968, SSH
  /**
   * String constant for ,.
   */
  public static final String kComma = ",";

  // END, CR00121968

  // BEGIN, CR00304013, MR
  /**
   * Character constant for ,.
   */
  public static final char kCommaChar = ',';

  // END, CR00304013

  /**
   * Key Set used for generating Service invoice reference number.
   */
  public static final String kKeySetName = "SIREFNO";

  /**
   * KeySet used for generating service authorization reference number
   */
  public static final String kSAKeySetName = "SAREF";

  /**
   * KeySet used for generating service invoice line item reference number.
   */
  public static final String kSILIKeySetName = "SILIREFNO";

  // BEGIN, CR00314817, GYH
  /**
   * KeySet used for generating provider reference number.
   */
  public static final String kProviderKeySetName = "PREFNO";

  /**
   * KeySet used for generating provider group reference number.
   */
  public static final String kProviderGroupKeySetName = "PGREFNO";

  /**
   * KeySet used for generating provider enquiry reference number.
   */
  public static final String kProviderEnquiryKeySetName = "PENQREFNO";

  /**
   * KeySet used for generating service invoice request line item reference number.
   */
  public static final String kSIRequestLineItemKeySetName = "SIRLIRNO";

  // END, CR00314817


  // BEGIN, CR00306412, MR
  /**
   * Specifies the default port that the SMTP server listens on.
   */
  public static final int kSMTPServerPortDefault = 25;

  // END, CR00306412

  /**
   * String constant for from field.
   */
  public static final String kFromField = "from";

  /**
   * Value for unit authorized
   */
  public static final int kUnitAuthorized = 365;

  /**
   * number of days in year.
   */
  public static final int kdaysInYear = 365;

  // BEGIN CR00124186, KK
  /**
   * One day.
   */
  public static final int KOneDay = 1;

  /**
   * number of days in a week.
   */
  public static final int kdaysInWeek = 7;

  // BEGIN CR00121067, PDN
  /**
   * number of days in a month.
   */
  public static final int kdaysInMonth = 30;

  // END CR00121067, PDN

  // END CR00124186, KK

  /**
   * String constant for leap year
   */
  public static final int kLeapYears = 4;

  /**
   * Contract notification name.
   */
  public static final String kContractNotificationName = "ProviderManagementContract.pdf";

  /**
   * String constant to field.
   */
  public static final String kToField = "to";

  /**
   * Fixed string value.
   */
  public static final String kFixedString = "(Fixed)";

  /**
   * Min max string constant.
   */
  public static final String kMinMax = "(Min-Max)";

  /**
   * Max string value.
   */
  public static final String kMax = "(Max)";

  /**
   * unused string constant.
   */
  public static final String kUnused = "unused";

  /**
   * days representation.
   */
  public static final String kDD = "dd";

  /**
   * Month representation.
   */
  public static final String kMM = "MM";

  /**
   * Monthly formatted frequency pattern.
   */
  public static final String kMonthlyFormattedPattern = "2001000";

  /**
   * Quarterly formated frequency pattern.
   */
  public static final String kQuarterlyFormattedPattern = "2003000";

  /**
   * Daily formatted frequency pattern.
   */
  public static final String kDailyFormattedPattern = "000100000";

  /**
   * Day portion for Sunday.
   */
  public static final String kDayPortionSunday = "64";

  /**
   * Day portion for Monday.
   */
  public static final String kDayPortionMonday = "01";

  /**
   * Day portion for Tuesday.
   */
  public static final String kDayPortionTuesday = "02";

  /**
   * Day portion for Wednesday.
   */
  public static final String kDayPortionWednesday = "04";

  /**
   * Day portion for Thursday.
   */
  public static final String kDayPortionThursday = "08";

  /**
   * Day portion for Friday.
   */
  public static final String kDayPortionFriday = "16";

  /**
   * Day portion for Saturday.
   */
  public static final String kDayPortionSaturday = "32";

  /**
   * Empty String representation.
   */
  public static final String kEmptyString = "";

  /**
   * Week one value.
   */
  public static final String kWeekOne = "1";

  /**
   * Week two value.
   */
  public static final String kWeekTwo = "2";

  /**
   * Standard formatted frequency pattern.
   */
  public static final String kStandardFormattedPattern = "100100100";

  /**
   * Double zero value.
   */
  public static final String kDoubleZero = "00";

  /**
   * Treble zero value.
   */
  public static final String kTrebleZero = "000";

  /**
   * Name space value path.
   */
  public static final String kNameSpace = "http://www.curamsoftware.com/curam/jde/client/widget/nd";

  /**
   * Compartment tree name.
   */
  public static final String kTreeName = "CompartmentTree";

  /**
   * Node set string value.
   */
  public static final String kNodeSet = "node-set";

  /**
   * Node string value.
   */
  public static final String kNode = "node";

  /**
   * Id string value.
   */
  public static final String kId = "id";

  /**
   * Compartment type.
   */
  public static final String kType = "type";

  /**
   * Compartment xml view tag.
   */
  public static final String kView = "view";

  /**
   * Compartment title.
   */
  public static final String kTitle = "title";

  /**
   * Compartment xml name space.
   */
  public static final String kParamValue = "param-value";

  /**
   * Compartment xml node information tag.
   */
  public static final String kNodeInfo = "node-info";

  /**
   * Compartment xml node types tag.
   */
  public static final String kNodeTypes = "node-types";

  /**
   * Compartment xml node type tag.
   */
  public static final String kNodeType = "node-type";

  /**
   * Compartment xml actions tag.
   */
  public static final String kActions = "actions";

  /**
   * Compartment xml action tag.
   */
  public static final String kAction = "action";

  /**
   * Compartment xml key tag.
   */
  public static final String kKey = "key";

  /**
   * Default value.
   */
  public static final String kDefault = "default";

  /**
   * compartment id prefix.
   */
  public static final String kIDPrefix = "compartmentID-";

  /**
   * Name string constant.
   */
  public static final String kName = "name";

  /**
   * Top level compartment attribute.
   */
  public static final String kTopLevelCompartment = "top-compartment";

  /**
   * Compartment String representation.
   */
  public static final String kCompartment = "compartment";

  /**
   * Compartment id representation.
   */
  public static final String kCompartmentID = "compartmentID";

  /**
   * Start node id.
   */
  public static final String kStartNode = "start-node-id";

  /**
   * Value to compare same type.
   */
  public static final String kSame = "same";

  /**
   * String value of yes.
   */
  public static final String kYes = "Yes";

  /**
   * String value of no.
   */
  public static final String kNo = "No";

  /**
   * Greater than string value.
   */
  public static final String kGreaterThan = ">";

  /**
   * Place string value.
   */
  public static final String kPlace = "Place";

  /**
   * supersession of java warning.
   */
  public static final String kUnchecked = "unchecked";

  /**
   * Constant value for create places for provider.
   */
  public static final String kCreatePlacesForProvider = "CREATEPLACESFORPROVIDER";

  /**
   * Closing square bracket string value.
   */
  public static final String kClosingSquareBracket = "]";

  /**
   * Opening square bracket string value.
   */
  public static final String kOpeningSquareBracket = "[";

  /**
   * To represent paid string.
   */
  public static final String kStPaid = "Paid:";

  /**
   * Value four String representation.
   */
  public static final String kFour = "4";

  /**
   * default mail id.
   */
  public static final String kDefaultEmail = "cpm@default.com";

  /**
   * external user role representation.
   */
  public static final String kExternalUserSecure = "EXTERNALUSERSECUREROLE";

  /**
   * Secure algorithm name.
   */
  public static final String kSecureAlgorithmName = "SHA1PRNG";

  /**
   * Alphabet string value.
   */
  public static final String kAlphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

  /**
   * KeySet name for service invoice reference number.
   */
  public static final String kSetName = "SIREFNO";

  /**
   * KeySet unique id for service invoice line item reference number.
   */
  public static final String kUniquesIDKEySetName = "SILIREFNO";

  /**
   * Age value.
   */
  public static final int kEighteenAge = 18;

  // BEGIN, CR00116240, SSH
  /**
   * Number of characters.
   */
  public static final int kEighteen = 18;

  // END, CR00116240

  /**
   * Number of hour for a day.
   */
  public static final int kHoursInDay = 24;

  /**
   * Zero representation in long.
   */
  public static final long kZeroLong = 0;

  /**
   * Delivery frequency pattern for provider placement.
   */
  public static final String kProviderPlacementProductDeliveryFrequency = "200120101";

  // BEGIN, CR00234484, RPB
  /**
   * Provider location id.
   */
  public static final int kProviderLocationID = 2701;

  // END, CR00234484

  /**
   * Maximum amount.
   */
  public static final long kMaximumAmount = 100000;

  /**
   * Delivery frequency pattern for provider placement string.
   */
  public static final String kProviderPlacementDeliveryPattern = "Provider Placement Delivery Pattern";

  /**
   * String value of service invoice exception processing.
   */
  public static final String kServiceInvoiceExceptionProcessing = "SERVICEINVOICEEXCEPTIONPROCESSING";

  /**
   * False representation in lower case.
   */
  public static final String kLowerCaseFalse = "false";

  /**
   * False representation in upper case.
   */
  public static final String kUpperCaseFalse = "FALSE";

  /**
   * Service invoice line item manual property.
   */
  public static final String kSILIManualApprovalProperty = "curam.sili.manual.approval";

  /**
   * Document file extension.
   */
  public static final String kFileNameExtension = ".doc";

  /**
   * Provider name string constant.
   */
  public static final String kProviderName = "providerName";

  /**
   * Provider member entry value is used in home study.
   */
  public static final String kProviderMemberEntry = "providerMemberEntry";

  /**
   * Provider member entry size.
   */
  public static final int kProviderMemberEntrySize = 128;

  /**
   * Maximum value of provider members
   */
  public static final int kMaxNumberOfProviderMembers = 5;

  /**
   * Entity insert operation.
   */
  public static final String kINSERT = "insert";

  /**
   * Entity modify operation.
   */
  public static final String kMODIFY = "modify";

  /**
   * To represent provider party role.
   */
  public static final String kOfType = "of type";

  /**
   * Provider party associated role.
   */
  public static final String kWithRole = "with role";

  /**
   * Entity cancel operation.
   */
  public static final String kCANCEL = "cancel";

  /**
   * Default optional double string representation.
   */
  public static final String kDefaultOptionalDoubleString = "-10,000,000,000,000.00";

  /**
   * synthetic-access constant.
   */
  public static final String kSyntheticAccess = "synthetic-access";

  /**
   * default referenceNumber.
   */
  public static final String kReferenceNumber = "CustomizedNumber";

  /**
   * default referenceNumber.
   */
  public static final String kDateTimeFormatString = "yyMMddHHmmssSSS";

  /**
   * String constant for -
   */
  public static final String kHypen = "-";

  /**
   * String constant representing the owner type 'MEMBER' for a Training
   * Program.
   */
  public static final String kMember = "MEMBER";

  /**
   * String constant representing the owner type 'PROVIDER' for a Training
   * Program.
   */
  public static final String kProvider = "PROVIDER";

  /**
   * String constant representing the owner type 'PROVIDER GROUP' for a Training
   * Program.
   */
  public static final String kProviderGroup = "PROVIDERGROUP";

  /**
   * String constant representing the participant type 'PROVIDER GROUP MEMBER'
   * involved in a Training Program.
   */
  public static final String kProviderGroupMember = "PROVIDERGROUPMEMBER";

  /**
   * String constant representing the participant type 'PROVIDER MEMBER'
   * involved in a Training Program.
   */
  public static final String kProviderMember = "PROVIDERMEMBER";

  /**
   * String constant representing the participant type 'PERSON' involved in a
   * Training Program.
   */
  public static final String kPerson = "PERSON";

  /**
   * String constant which indicates the Work Queue process number.
   */
  public static final String kWorkQueueProcessSix = "6";

  // BEGIN, CR00115543, SK
  /**
   * String constant which indicates the file name of the Paper Roster Document.
   */
  public static final String kPaperRosterDocumentName = "ProviderManagementPaperRoster.pdf";

  // END, CR00115543

  // BEGIN, CR00115506, JSP
  /**
   * String constant representing the environment property entry. The value
   * retrieved from environment property entry represents if the roster line
   * item's units delivered should be defaulted to planned units.
   */
  public static final String kRosterLineItemPlannedUnits = "curam.cpm.attendance.service.plannedunitsdefaulted";

  // END, CR00115506

  // BEGIN, CR00120180, JSP
  /**
   * String constant representing the environment property entry. Roster
   * submission reminder notification would be generated if the value retrieved
   * from the environment property variable is True.
   */
  public static final String kRosterSubmissionReminder = "curam.cpm.attendance.service.submissionreminderrequired";

  // END, CR00120180

  // BEGIN, CR00170137, AS
  /**
   * String constant representing the environment property entry. The reporting
   * method on the service offering attendance configuration would be treated as
   * mandatory if the value retrieved from the environment property variable is
   * true.
   */
  public static final String kAttendanceReportingConfiguration = "curam.cpm.attendance.service.reporting.configured";

  // END, CR00170137

  // BEGIN, CR00120997, JMA
  /**
   * String constant which indicates the file name of the Provider list
   * investigation page.
   */
  public static final String kProviderListInvestigation = "ProviderManagement_listInvestigation";

  // END, CR00120997

  // BEGIN, CR00186270, PS
  // BEGIN, CR00187207, PS
  /**
   * String constant representing the Incident is reported anonymously.
   *
   * @deprecated Since Curam 5.2 SP3, replaced with
   * curam.util.exception.LocalisableString
   * (curam.message.PROVIDERINCIDENT
   * .TEXT_INCIDENT_ANONYMOUS_REPORTER).getMessage(). Earlier it was
   * not possible to get the localized text for Anonymous.Now to
   * localize the text, is added in the message file,
   * PROVIDERINCIDENT.xml. See release note: CR00186330.
   */
  @Deprecated
  public static final String kIncidentAnonymousReporter = "Anonymous";

  /**
   * String constant representing the Incident happened at the provider
   * facility.
   *
   * @deprecated Since Curam 5.2 SP3, replaced with
   * curam.util.exception.LocalisableString
   * (curam.message.PROVIDERINCIDENT
   * .TEXT_INCIDENT_PROVIDER_FACILITY).getMessage(). Earlier it was
   * not possible to get the localized text for Provider
   * Facility.Now to localize the text, is added in the message
   * file, PROVIDERINCIDENT.xml. See release note: CR00186330.
   */
  @Deprecated
  // END, CR00187207
  public static final String kIncidentProviderFacility = "Provider Facility";

  // END, CR00186270

  // START CR00117630, ASB
  /**
   * String constant representing the List Service Offering UIM page
   */
  public static final String kListServiceOfferings = "ProviderManagement_listServiceOffering";

  // START CR00131289, AS
  /**
   * String constant representing the View Service Offering UIM page
   */
  public static final String kViewServiceOffering = "ProviderManagement_resolveServiceOffering";

  // END CR00131289

  /**
   * String constant representing the internal system identifier for Service
   * Offering
   */
  public static final String kParamServiceOfferingID = "serviceOfferingID";

  // BEGIN, CR00186270, PS
  // BEGIN, CR00187207, PS
  /**
   * String constant representing the tab name Service Offerings
   *
   * @deprecated Since Curam 5.2 SP3, replaced with
   * LocalisableString(curam.message
   * .SERVICEOFFERING.TEXT_SERVICE_OFFERINGS).getMessage(). Earlier
   * it was not possible to get the localized text for Service
   * Offerings.Now to localize the text, is added in the message
   * file, SERVICEOFFERING.xml. See release note: CR00186330.
   */
  @Deprecated
  // END, CR00187207
  public static final String kTabServiceOfferings = "Service Offerings";

  // END, CR00186270
  /**
   * String constant representing the List Service Group UIM page
   */
  public static final String kListServiceGroups = "ProviderManagement_listServiceGroup";

  /**
   * String constant representing the View Service Group UIM page
   */
  public static final String kViewServiceGroup = "ProviderManagement_viewServiceGroupFrmList";

  /**
   * String constant representing the internal system identifier for Service
   * Group
   */
  public static final String kParamServiceGroupID = "serviceGroupID";

  // BEGIN, CR00186762, PS
  // BEGIN, CR00187207, PS
  /**
   * String constant representing the tab name Service Groups.
   *
   * @deprecated Since Curam 5.2 SP3, replaced with
   * LocalisableString(curam.message
   * .SERVICEGROUP.TEXT_SERVICE_GROUPS).getMessage(). Earlier it was
   * not possible to get the localized text for Service Groups.Now
   * to localize the text, is added in the message file,
   * SERVICEGROUP.xml. See release note: CR00186290.
   */
  @Deprecated
  // END, CR00187207
  public static final String kTabServiceGroups = "Service Groups";

  // END, CR00186762
  /**
   * String constant representing the View Provider UIM page
   */
  public static final String kViewProvider = "ProviderManagement_providerHome";

  /**
   * String constant representing the internal system identifier for Provider
   */
  public static final String kParamProviderConcernRoleID = "concernRoleID";

  /**
   * String constant representing the View Provider Group UIM page
   */
  public static final String kViewProviderGroupHome = "ProviderManagement_providerGroupHome";

  /**
   * String constant representing the internal system identifier for Provider
   * Group
   */
  public static final String kParamProviderGroupConcernRoleID = "concernRoleID";

  /**
   * String constant representing the View Provider Member UIM page
   */
  public static final String kViewProviderMember = "ProviderManagement_viewProviderMember";

  /**
   * String constant representing the View Provider Group Member UIM page
   */
  public static final String kViewProviderGroupMember = "ProviderManagement_viewProviderGroupMember";

  /**
   * String constant representing the internal system identifier for Provider
   * Member
   */
  public static final String kParamProviderPartyID = "providerPartyID";

  // END CR00117630

  // BEGIN, CR00124475, KR
  /**
   * String constant for CPMEXTERNALSECURE to check the external secure access.
   */
  public static final String kCPMEXTERNALSECURE = "CPMEXTERNALSECURE";

  /**
   * String constant for CPMEXTERNALNONSECURE to check the external non secure
   * access.
   */
  public static final String kCPMEXTERNALNONSECURE = "CPMEXTERNALNONSECURE";

  // END, CR00124475

  // BEGIN, CR00125626, AS
  /**
   * Used to identify the action with the string set to select.
   */
  public static final String kSearchAction = "Select";

  // END, CR00125626

  // BEGIN CR00127289 KR
  /**
   * Used to insert empty space between the two words
   */
  public static final String kSpace = " ";

  // END CR00127289

  // BEGIN, CR00131272, ABS
  /**
   * String constant representing the environment property entry. The value
   * retrieved from environment property entry represents if agency wish to
   * prevent raising an event when an contract based payment is withheld.
   */
  public static final String kWithholdContractPayments = "curam.financial.RaisewithholdcontractpaymentNotificationEvent";

  /**
   * String constant representing the environment property entry. The value
   * retrieved from environment property entry represents if agency wish to
   * prevent raising an event when an invoice based payment is withheld.
   */
  public static final String kWithholdInvoicePayments = "curam.financial.RaiseWithholdInvoicepaymentNotificationEvent";

  // END, CR00131272

  // BEGIN, CR00128227, RPB
  /**
   * String constant representing the process payments deferred processing.
   */
  public static final String kProcessPayments = "PROCESSPAYMENTS";

  // END, CR00128227

  // BEGIN, CR00146426, GSP
  /**
   * String constant for IC provider homepage.
   */
  public static final String kICPROVIDERHOMEPAGENAME = "ICSample_CPMProviderHome";

  // END, CR00146426

  // BEGIN, CR00154005, KR
  /**
   * String constant for unique id generator.
   */
  public static final String kRECNUMBER = "RECNUMBER";

  // END, CR00154005

  /**
   * Constant for Service Group Name.
   */
  public static final String kServiceGroupName = "name";

  /**
   * Constant for Service Group code.
   */
  public static final String kServiceGroupCode = "code";

  // BEGIN, CR00198654, DRS
  /**
   * Constant for Service Group reference.
   */
  public static final String kServiceGroupReference = "reference";

  // END, CR00198654

  /**
   * Constant for Service Group ID.
   */
  public static final String kServiceGroupID = "serviceGroupID";

  /**
   * Constant for Service Group Search.
   */
  public static final String kServiceGroupSearch = "ServiceGroupSearch";

  // BEGIN, CR00158578, ASN

  /**
   * Constant for XML attributes.
   */
  public static final String attributes = "attributes";

  /**
   * Constant for XML attribute.
   */
  public static final String attribute = "attribute";

  /**
   * Constant for XML name attribute.
   */
  public static final String name = "name";

  /**
   * Constant for XML value attribute.
   */
  public static final String value = "value";

  /**
   * Constant for XML unit attribute.
   */
  public static final String unitName = "unit";

  /**
   * Constant for XML unit amount attribute.
   */
  public static final String unitAmountName = "unitamount";

  /**
   * Constant for Data Store Child entity.
   */
  public static final String CHILD_ENTITIES_PREFIX = "childEntities_";

  /**
   * Constant for estimatedCost.
   */
  public static final String estimatedCost = "estimatedCost";

  /**
   * Constant for escapeCharacter.
   */
  public static final String escapeCharacter = "//";

  /**
   * Constant for xsd element.
   */
  public static final String xsdElement = "xsd:element";

  /**
   * Constant for xsd attribute.
   */
  public static final String xsdAttribute = "xsd:attribute";

  /**
   * Constant for xml type attribute.
   */
  public static final String type = "type";

  /**
   * Constant for parent entity.
   */
  public static final String parentEntity = "parentEntity";

  /**
   * Constant for null.
   */
  public static final String nullValue = "<null>";

  // END, CR00158578

  // BEGIN, CR00158932, JSP
  /**
   * Used to identify the action with the string set to Search.
   */
  public static final String kSearchActionStr = "Search";

  // END, CR00158932

  // BEGIN, CR00168337, JSP
  /**
   * Used to identify the action with the string set to Finish.
   */
  public static final String kFinishActionStr = "Finish";

  // END, CR00168337

  // BEGIN, CR00169295, AK
  /**
   * Used to suppress warnings related to deprecation of methods.
   */
  public static final String kDeprecation = "deprecation";

  // END, CR00169295

  // BEGIN, CR00168982, SK
  /**
   * Used to identify the action with the string set to Select.
   */
  public static final String kSelectActionString = "Select";

  // END, CR00168982

  // BEGIN, CR00170638, GP
  /**
   * KeySet used for generating training program reference number.
   */
  public static final String kTPKeySetName = "TPREF";

  /**
   * KeySet used for generating training program reference number.
   */
  public static final String kCPMCONTRACTKeySetName = "CPMCONREF";

  /**
   * KeySet used for generating service invoice line item correction reference
   * number.
   */
  public static final String kSILICorrrectionKeySetName = "SILICRNREF";

  /**
   * KeySet used for generating roster reference number.
   */
  public static final String kRosterKeySetName = "ROSTERREF";

  /**
   * KeySet used for generating roster line item reference number.
   */
  public static final String kRLIKeySetName = "RLIREF";

  /**
   * Code name used for generating continuous provider reference number.
   */
  public static final String kProviderCodeName = "PRVREF";

  /**
   * Code name used for generating continuous provider group reference number.
   */
  public static final String kProviderGroupCodeName = "PRVGRPREF";

  /**
   * Code name used for generating continuous provider enquiry reference number.
   */
  public static final String kProviderEnquiryCodeName = "PRVENQREF";

  /**
   * Code name used for generating continuous Service Invoice reference number.
   */
  public static final String kServiceInvoiceCodeName = "SIREF";

  /**
   * Code name used for generating continuous Service Invoice Line Item
   * reference number.
   */
  public static final String kServiceInvoiceLineItemCodeName = "SILIREF";

  /**
   * Code name used for generating continuous Service Invoice Request Line Item
   * reference number.
   */
  public static final String kServiceInvoiceRequestLineItemCodeName = "SIRLIREF";

  // END, CR00170638

  // BEGIN, CR00185107, GP
  /**
   * KeySet used for generating license number.
   */
  public static final String kLicenseKeySetName = "LICENSENO";

  // END, CR00185107

  // BEGIN, CR00186299, ASN
  /**
   * Integer constant to decide maximum permitted length of the localizable
   * 'description' column value.
   */
  public static final int kMaxLengthLocalizableDescription = 400;

  // END, CR00186299

  // BEGIN, CR00187099, SSK
  /**
   * String constant for :.
   */
  public static final String kColon = ":";

  /**
   * String constant for half an hour.
   */
  public static final String khalfAnHour = ".5";

  /**
   * String constant for char Zero.
   */
  public static final char kZeroChar = '0';

  /**
   * String constant for index of first char.
   */
  public static final int kFirstCharIndex = 0;

  /**
   * String constant for index of second char.
   */
  public static final int kSecondCharIndex = 1;

  /**
   * String constant for minutes length.
   */
  public static final int kMinturesLength = 2;

  // END, CR00187099

  // BEGIN, CR00186342, GP
  /**
   * Constant used for defining the properties file required for displaying the
   * images.
   */
  public static final String kRendererImages = "cpm.widget.renderer.i18n.Image";

  /**
   * Constant used for defining provider icon.
   */
  public static final String kIconProvider = "IconProvider";

  /**
   * Constant used for defining provider icon.
   */
  public static final String kIconProviderGroup = "IconProviderGroup";

  /**
   * Constant used for defining contracts in review icon.
   */
  public static final String kIconContractReview = "IconContractReview";

  /**
   * Constant used for defining service wait list review icon.
   */
  public static final String kIconServiceWaitlistReview = "IconServiceWaitlist";

  /**
   * Constant used for defining provider wait list review icon.
   */
  public static final String kIconProviderWaitlistReview = "IconProviderWaitlist";

  /**
   * Constant used for defining provider type category code table.
   */
  public static final String kProviderTypeCategory = "PROVIDER_TYPE_CATEGORY";

  /**
   * Constant used for defining the content address table style.
   */
  public static final String kContentAddressTable = "content-address-table";

  // BEGIN, CR00204908, GP
  /**
   * Constant used for defining the link to be opened on click on investigation.
   */
  public static final String kListInvestigationPage = "ProviderManagement_listInvestigationPage.do";

  // END, CR00204908

  /**
   * Constant used for defining content panel's image panel width style.
   */
  public static final String kContentPanelImagePanelWidth = "content-panel image-panel-width";

  /**
   * Constant used for defining content panel's link panel width style.
   */
  public static final String kContentPanelLinkPanelWidth = "content-panel links-panel-width";

  /**
   * Constant used for defining left table style.
   */
  public static final String kLeftTable = "left-table";

  /**
   * Constant used for defining relationship style.
   */
  public static final String kRelationship = "relationship";

  // END, CR00186342

  // BEGIN, CR00196974, SK
  /**
   * The resource ID of the mapping file stored on AppResource table.
   */
  public static final long kMappingResourceID = 3999;

  // END, CR00196974

  // BEGIN, CR00198515, DRS
  /**
   * Constant used for defining regular expression for empty space.
   */
  public static final String kRegexForEmptySpace = "\\s+";

  // END, CR00198515

  // BEGIN, CR00198722, SSK

  /**
   * String constant to represent "All"
   */
  public static final String kAll = "All";

  // END, CR00198722

  // BEGIN, CR00198982, SSK
  /**
   * String constant to represent PDF extension
   */
  public static final String kpdfExtension = ".pdf";

  // END, CR00198982

  // BEGIN, CR00199708, GP
  /**
   * Constant used for defining contact content style.
   */
  public static final String gkContactContent = "contact-content";

  /**
   * Constant used for defining contact content detail style.
   */
  public static final String gkContactContentDetail = "contact-content-detail";

  /**
   * Constant used for defining initial contact label style.
   */
  public static final String gkInitialContactLabel = "initial-contact-label";

  /**
   * Constant used for defining initial contact style.
   */
  public static final String gkInitialContact = "initial-contact";

  /**
   * Constant used for defining latest contact label style.
   */
  public static final String gkLatestContactLabel = "latest-contact-label";

  /**
   * Constant used for defining latest contact style.
   */
  public static final String gkLatestContact = "latest-contact";

  /**
   * Constant used for defining relationship style.
   */
  public static final String gkRelationship = "relationship";

  /**
   * Constant used for defining image links style.
   */
  public static final String gkImageLinks = "image-links";

  /**
   * Constant used for defining investigation links panel style.
   */
  public static final String gkInvestigationLinksPanel = "content-panel-detail investigation-links-panel";

  /**
   * Constant used for defining investigation case owner panel style.
   */
  public static final String gkInvCaseOwnerPanel = "inv-case-owner-panel";

  /**
   * Constant used for defining investigation case owner icon style.
   */
  public static final String gkInvCaseOwnerIcon = "inv-case-owner-icon";

  /**
   * Constant used for defining investigation case owner style.
   */
  public static final String gkInvCaseOwner = "inv-case-owner";

  /**
   * Constant used for defining link detail style.
   */
  public static final String gkLinkDetail = "link-detail";

  /**
   * Constant used for defining incident details table style.
   */
  public static final String gkIncidentDetailsTable = "incident-details-table";

  /**
   * Constant used for defining reported by style.
   */
  public static final String gkReportedBy = "reported-by";

  /**
   * Constant used for defining initial contact table style.
   */
  public static final String gkInitialContactTable = "inital-contact-table";

  /**
   * Constant used for defining latest contact table style.
   */
  public static final String gkLatestContactTable = "latest-contact-table";

  /**
   * Constant used for defining reported by table style.
   */
  public static final String gkReportedByTable = "reported-by-table";

  public static final String gkIncidentStatusDomain = "INCIDENT_STATUS";

  // BEGIN, CR00224728, JMA
  /**
   * Constants for CPM context panels *
   */

  /**
   * Provider context panel styles **/
  public static final String gkProviderContainer = "provider-container";
  public static final String gkProviderImagePanel = "content-panel-detail provider-image-panel";
  public static final String gkProviderDetailsPanel = "content-panel-detail provider-details-panel";
  public static final String gkProviderLinksPanel = "content-panel-detail provider-links-panel";
  public static final String gkProviderContractsPanel = "content-panel-detail provider-contracts-panel";
  public static final String gkProviderTabDetails = "provider-tab-details";
  public static final String gkContractsPanelDetails = "contract-panel-details";
  public static final String gkProviderCategory = "provider-category";
  public static final String gkProviderWebAddress = "provider-webaddress";
  public static final String gkProviderDetailsTable = "provider-details-table";
  public static final String gkProviderContractTable = "provider-contract-table";
  public static final String gkProviderContractContent = "provider-contract-content";
  public final static String gkProviderStatus = "provider-status";
  public static final String gkProviderInvestigationDetails = "provider-investigation-details";
  public static final String gkFiller = "filler-div";
  public static final String gkStaticDiv = "static-div";

  /**
   * Facility Manager Provider context panel styles *
   */
  public static final String gkFMProviderContainer = "fm-provider-container";
  public static final String gkFMProviderImagePanel = "content-panel-detail fm-provider-image-panel";
  public static final String gkFMProviderDetailsPanel = "content-panel-detail fm-provider-details-panel";
  public static final String gkFMProviderLinksPanel = "content-panel-detail fm-provider-links-panel";
  public static final String gkFMProviderTabDetails = "fm-provider-tab-details";
  public static final String gkFMProviderDetailsTable = "fm-provider-details-table";

  public final static String gkFMProviderStatus = "fm-provider-status";

  /**
   * Provider Group context panel styles *
   */
  public static final String gkProviderGroupContainer = "providergroup-container";
  public static final String gkProviderGroupImagePanel = "content-panel-detail providergroup-image-panel";
  public static final String gkProviderGroupDetailsPanel = "content-panel-detail providergroup-details-panel";
  public static final String gkProviderGroupContractPanel = "content-panel-detail providergroup-contract-panel";
  public static final String gkProviderGroupTabDetails = "providergroup-tab-details";
  public static final String gkProviderGroupDetailsTable = "providergroup-details-table";
  public static final String gkProviderGroupContractContent = "providergroup-contract-content";
  public static final String gkContractContentDetails = "contract-content-details";
  public static final String gkProviderGroupContractTable = "providergroup-contract-table";
  public final static String gkContractTitle = "contract-title";
  public static final String gkIconWeb = "IconWeb";
  public static final String gkWebAddress = "webaddress";
  public static final String gkDominProviderGroupStatus = "PROVIDER_GROUP_STATUS";

  /**
   * Provider Member context panel styles *
   */
  public static final String gkProviderMemContainer = "provider-mem-container";
  public static final String gkMemberImagePanel = "content-panel-detail member-image-panel";
  public static final String gkMemberDetailsPanel = "content-panel-detail member-details-panel";
  public static final String gkMemberDuration = "member-duration";
  public static final String gkMemberDetailsTable = "member-details-table";
  public final static String gkDomainRoleType = "PROVIDER_MEMBER_ROLE";
  public static final String kIconPerson = "IconAttention";

  /**
   * Provider Incidents context panel styles *
   */
  public static final String gkProviderIncidentContentPanel = "content-panel-detail prov-incident-content-panel";
  public static final String gkProviderIncidentContainer = "prov-incident-container-panel";
  public static final String gkProviderIncidentTabDetails = "prov-incident-tab-details";
  public static final String gkProviderIncidentDetails = "prov-incident-details";
  public static final String gkProviderIncidentType = "prov-content-incident-type";
  public static final String gkProviderIncidentDate = "prov-incident-date";
  public static final String gkProviderIncidentTime = "prov-incident-time";
  public static final String gkProviderIncidentParticipants = "prov-incident-participants";
  public static final String gkProviderLinkDetail = "link-detail";
  public static final String gkProviderIncidentDetailsTable = "prov-incident-details-table";
  public static final String gkProviderIncStatusDate = "prov-incident-opened-date";
  public static final String gkProviderIncStatusBy = "prov-incident-opened-by";
  public static final String gkProviderIncReportedDetails = "prov-reported-details";
  public static final String gkProviderIncReportedBy = "prov-reported-by";
  public static final String gkProviderIncReportedByPerson = "prov-reported-by-person";
  public static final String gkProviderIncReportedByDate = "prov-reported-by-date";
  public static final String gkProviderIncReportedByAddress = "prov-reported-by-address";
  public static final String gkProviderIncReportedByClear = "prov-reported-by-clear";
  public static final String gkProviderIncReportedByPhone = "prov-reported-by-phone";
  public static final String gkProviderIncReportedPhone = "prov-phonenumber";
  public static final String gkProviderIncReportedByEmail = "prov-reported-by-email";
  public static final String gkProviderIncReportedByTable = "prov-reported-by-table";
  public static final String gkProviderIncReportedEmail = "prov-email";

  // Provider Investigation context panel constants
  public static final String gkContainerPanelProviderInvestigation = "prov-investigation-container-panel";
  public static final String gkProviderInvestigationReference = "provider-investigation-reference";
  // END, CR00224728
  // END, CR00199708

  // BEGIN, CR00200254, RPB
  /**
   * Constant used for representing the last hour of day.
   */
  public static final int kLastHourOfDay = 23;

  /**
   * Constant used for representing the last minute of hour.
   */
  public static final int kLastMinuteOfHour = 59;

  /**
   * Constant used for representing the last second of minute.
   */
  public static final int kLastSecondOfMinute = 59;

  // END, CR00200254

  // BEGIN, CR00204908, GP
  /**
   * Constant used for defining the link to be opened on click on incidents.
   */
  public static final String kListIncidentsPage = "ProviderManagement_listIncidentForProviderPage.do";

  // END, CR00204908

  // BEGIN, CR00205041, GP
  /**
   * Constant used for defining the view roster link.
   */
  public static final String kViewRosterPage = "ProviderManagement_viewRoster";

  /**
   * Constant used for defining the view attendance roster link.
   */
  public static final String kViewAttendanceRosterPage = "ProviderManagement_viewAttendanceRoster";

  // END, CR00205041

  // BEGIN, CR00206755, GP
  /**
   * Constant used for defining number of days in a week.
   */
  public static final int kNoOfDaysInAWeek = 7;

  /**
   * Constant used for defining number of days in two weeks.
   */
  public static final int kNoOfDaysInTwoWeeks = 14;

  /**
   * Constant used for defining number of days in three weeks.
   */
  public static final int kNoOfDaysInThreeWeeks = 21;

  // END, CR00206755

  // BEGIN, CR00207677, AS
  /**
   * Constant used for defining maximum length of the user name.
   */
  public static final int kUserNameMaxLength = 30;

  // END, CR00207677

  // # BEGIN, CR00210636, JG

  /**
   * Constant for magic number 20
   */
  public static final String k20 = "20";

  /**
   * Constant for the string "height"
   */
  public static final String kHEIGHT = "height";

  /**
   * Constant for the string "width"
   */
  public static final String kWIDTH = "width";

  /**
   * Constant for the string "true"
   */
  public static final String kTRUE = "true";

  /**
   * Constant for the string "showDirections"
   */
  public static final String kSHOW_DIRECTIONS = "showDirections";

  /**
   * Constant for magic number 16
   */
  public static final String k16 = "16";

  /**
   * Constant for the string "zoom-level"
   */
  public static final String kZOOM_LEVEL = "zoom-level";

  /**
   * Constant for the string "config"
   */
  public static final String kCONFIG = "config";

  /**
   * Constant for the string "displayValue"
   */
  public static final String kDISPLAY_VALUE = "displayValue";

  /**
   * Constant for the string "hiddenValue"
   */
  public static final String kHIDDEN_VALUE = "hiddenValue";

  /**
   * Constant for the string "clientAddress"
   */
  public static final String kCLIENT_ADDRESS = "clientAddress";

  /**
   * Constant for the string "root"
   */
  public static final String KROOT = "root";

  // # END, CR00210636

  // BEGIN, CR00213398, SSK
  /**
   * Constant used for defining the related concept preview page link.
   */
  public static final String kRelatedConceptPreviewPage = "ProviderManagement_addRelatedConceptToPublisedInEditTermPage.do";

  /**
   * Constant used for defining the related concept element preview page link.
   */
  public static final String kRelatedConceptElementPreviewPage = "ProviderManagement_addRelatedConceptToInEditTermPage.do";

  /**
   * Constant used for adding the related concept to publish term link.
   */
  public static final String kAddRelatedTermToPublishedTermPage = "ProviderManagement_addRelatedTermsToPublishedInEditTermPage.do";

  /**
   * Constant used for adding the related concept to in edit term link.
   */
  public static final String kAddRelatedTermToInEditTermPage = "ProviderManagement_addRelatedTermToInEditTermPage.do";

  // END, CR00213398

  // BEGIN, CR00213911, RPB
  /**
   * Constant used for assigning taxonomy tasks.
   */
  public static final String kResourceManagerUserName = "cpmmanager";
  // END, CR00213911

  // BEGIN, CR00273521, MR
  /**
   * Constant used for facility manager specific requirements.
   */
  public static final String kFacilityManagerUserName = "cpmfacilitymanager";
  // END, CR00273521

  public static final String kTaxonomySearchChunkProcessor = "TAXONOMYSEARCHCHUNKPROCESSOR";
  public static final String kTaxonomySearchStatusChecker = "TAXONOMYSEARCHSTATUSCHECKER";
  public static final String kTaxonomySearchChunker = "TAXONOMYSEARCHCHUNKER";

  // BEGIN, CR00225596, RPB
  /**
   * Constant used for GMT time zone representation.
   */
  public static final String kGMTTimezone = "GMT";
  // END, CR00225596

  // BEGIN, CR00226620, NRK
  /**
   * String constant with reference to the CPM Incidents Contact log wizard menu
   * properties, used when the user invoked clicks the link to invoke the
   * contact log wizard.
   *
   */
  public static final String kCreateIncidentContactLogWizard = "ProviderManagementCreateContactLogWizard.properties";

  /**
   * String constant with reference to the CPM Incidents Contact log wizard menu
   * properties, used when the user navigates through the steps in wizard.
   *
   */
  public static final String kModifyIncidentContactLogWizard = "ProviderManagementModifyContactLogWizard.properties";
  // END, CR00226620,NRK

  // BEGIN, CR00228443, GP
  /**
   * String constant with reference to the CPM create service offering wizard menu
   * properties, used when the user navigates through the steps in wizard.
   */
  public static final String kCreateServiceOfferingWizard = "ServiceOfferingCreateWizard.properties";
  // END, CR00228443

  // BEGIN, CR00228146, ASN
  /**
   * Constant used for defining the edit roster for reporting method of
   * attendance link page.
   */
  public static final String kEditAttendanceRosterPage = "ProviderManagement_updateAttendanceRosterPage.do";

  /**
   * Constant used for defining the edit roster for reporting method of
   * utilization link page.
   */
  public static final String kEditUtilizationRosterPage = "ProviderManagement_updateRosterPage.do";

  // BEGIN, CR00273521, MR
  /**
   * Constant used for defining the edit roster for reporting method of
   * utilization link page for the facility manager.
   */
  public static final String kEditUtilizationRosterPageForFM = "ProviderManagement_updateRosterForFacilityManagerPage.do";

  // END, CR00273521

  // BEGIN, CR00306259, MR
  /**
   * Constant used for defining the modify training program for provider page.
   */
  public static final String kModifyTrainingProgramForProviderPage = "ProviderManagement_modifyTrainingProgramForProviderPage.do";

  /**
   * Constant used for defining the update completed training program for provider page.
   */
  public static final String kUpdateCompletedTrainingForProviderPage = "ProviderManagement_updateCompletedTrainingForProviderPage.do";

  /**
   * Constant used for defining the modify training program for provider group page.
   */
  public static final String kModifyTrainingProgramForProviderGroupPage = "ProviderManagement_modifyTrainingProgramForProviderGroupPage.do";

  /**
   * Constant used for defining the update completed training program for provider group page.
   */
  public static final String kUpdateCompletedTrainingForProviderGroupPage = "ProviderManagement_updateCompletedTrainingForProviderGroupPage.do";

  // END, CR00306259
  /**
   * Constant used for calculating percentage value.
   */
  public static final double kHundred = 100;

  /**
   * Constant used for defining the roster submission page.
   */
  public static final String kSubmitRosterPage = "ProviderManagement_submitRosterPage.do";

  /**
   * Constant used for defining the confirmed roster submission page.
   */
  public static final String kConfirmSubmitRosterPage = "ProviderManagement_confirmSubmitRosterPage.do";

  // BEGIN, CR00273521, MR
  /**
   * Constant used for defining the roster submission page for the facility manager.
   */
  public static final String kSubmitRosterPageForFM = "ProviderManagement_submitRosterForFacilityManagerPage.do";

  /**
   * Constant used for defining the confirmed roster submission page for the facility manager.
   */
  public static final String kConfirmSubmitRosterPageForFM = "ProviderManagement_confirmSubmitRosterForFacilityManagerPage.do";

  // END, CR00273521
  /**
   * Constant used for the string "0"
   */
  public static final String KZero = "0";

  /**
   * Constant used for maximum number of minutes.
   */
  public static final int KMaxMinutes = 59;

  /**
   * Constant used for maximum number of hours.
   */
  public static final int KMaxHours = 24;

  /**
   * Constant used for number nine.
   */
  public static final int KNumberNine = 9;
  // END, CR00228146


  // BEGIN, CR00228703, GP
  /**
   * String constant with reference to the CPM create training service offering
   * wizard menu properties, used when the user navigates through the steps in
   * wizard.
   */
  public static final String kCreateTrainingServiceOfferingWizard = "TrainingServiceOfferingCreateWizard.properties";
  // END, CR00228703
  // BEGIN, CR00233623, ASN
  /**
   * Constant used for defining the external edit roster for reporting method of
   * attendance link page.
   */
  public static final String kEditExternalAttendanceRosterPage = "PME_updateAttendanceRosterPage.do";

  /**
   * Constant used for defining the external edit roster for reporting method of
   * utilization link page.
   */
  public static final String kEditExternalUtilizationRosterPage = "PME_updateRosterPage.do";

  /**
   * Constant used for defining the external roster submission page.
   */
  public static final String kSubmitExternalRosterPage = "PME_submitRosterPage.do";

  /**
   * Constant used for defining the external confirmed roster submission page.
   */
  public static final String kConfirmExternalSubmitRosterPage = "PME_confirmSubmitRosterPage.do";

  // BEGIN, CR00234082, GP
  /**
   * String constant with reference to the enroll provider wizard menu
   * properties, used when the user navigates through the steps in wizard.
   */
  public static final String kEnrollProviderWizard = "ProviderEnrollmentWizard.properties";

  /**
   * String constant with reference to the enroll provider group wizard menu
   * properties, used when the user navigates through the steps in wizard.
   */
  public static final String kEnrollProviderGroupWizard = "ProviderGroupEnrollmentWizard.properties";

  /**
   * String constant with reference to the CPM create provider enquiry wizard
   * menu properties, used when the user navigates through the steps in wizard.
   */
  public static final String kCreateProviderEnquiryWizard = "ProviderEnquiryWizard.properties";
  // END, CR00234082

  // BEGIN, CR00235784, GP
  /**
   * Constant used for defining the update provider attendance tracking page.
   */
  public static final String kUpdateProviderAttendanceTrackingPage = "ProviderManagement_updateProviderAttendanceTrackingPage.do";

  /**
   * Constant used for defining the modify provider attendance tracking page.
   */
  public static final String kModifyProviderAttendanceTrackingPage = "ProviderManagement_modifyProviderAttendanceTrackingPage.do";

  // BEGIN, CR00273521, MR
  /**
   * Constant used for defining the update provider attendance tracking page for the facility manager.
   */
  public static final String kUpdateProviderAttendanceTrackingPageForFM = "ProviderManagement_updateProviderAttendanceTrackingForFacilityManagerPage.do";

  /**
   * Constant used for defining the modify provider attendance tracking page for the facility manager.
   */
  public static final String kModifyProviderAttendanceTrackingPageForFM = "ProviderManagement_modifyProviderAttendanceTrackingForFacilityManagerPage.do";
  // END, CR00273521

  /**
   * Constant used for defining the add areas served information translation page.
   */
  public static final String kAddAreasServedInfoPage = "ProviderManagement_addAreasServedInfoTranslationPage.do";

  /**
   * Constant used for defining the add localizable text translation page.
   */
  public static final String kAddLocalizableTextPage = "ProviderManagement_addLocalizableTextTranslationPage.do";

  /**
   * Constant used for defining the view localizable text translation page.
   */
  public static final String kViewLocalizableTextPage = "ProviderManagement_viewLocalizableTextTranslationPage.do";

  /**
   * Constant used for defining the add client information translation page.
   */
  public static final String kAddClientInformationPage = "ProviderManagement_addClientInfoTranslationPage.do";

  /**
   * String constant with reference to the register provider as person wizard menu
   * properties, used when the user navigates through the steps in wizard.
   */
  public static final String kRegisterProviderAsPersonWizard = "RegisterAsPersonWizard.properties";
  // END, CR00235784

  /**
   * Constant for the integer "2".
   */
  public static final int gkTwo = 2;

  // BEGIN, CR00246084, GP
  /**
   * Constant used for defining the list contracts for provider page.
   */
  public static final String kProviderContractListPage = "ProviderManagement_listContractsForProviderPage.do";

  /**
   * Constant used for defining the list wait list entries for provider page.
   */
  public static final String kProviderWaitListEntryPage = "ProviderManagement_listWaitListEntryForProviderPage.do";

  /**
   * Constant used for defining the list wait list entries for provider offering page.
   */
  public static final String kProviderOfferingWaitListEntryPage = "ProviderManagement_listProviderOfferingWaitListForProviderPage.do";
  // END, CR00246084

  // BEGIN, CR00250690, JMA
  /**
   * String constant representing the internal system identifier for Provider
   */
  public static final String kProviderConcernRoleID = "providerConcernRoleID";
  // END, CR00250690


  // BEGIN, CR00246961, GP
  /**
   * Constant used for defining the edit provider group member training program
   * page.
   */
  public static final String kEditProviderGroupMemberTrainingProgram = "ProviderManagement_editTrainingProgramForProviderGroupMemberPage.do";

  /**
   * Constant used for defining the delete provider group member training program
   * page.
   */
  public static final String kDeleteProviderGroupMemberTrainingProgram = "ProviderManagement_deleteTrainingProgramForProviderGroupMemberPage.do";

  /**
   * Constant used for defining the view provider group member training program
   * page.
   */
  public static final String kViewProviderGroupMemberTrainingProgram = "ProviderManagement_resolveViewTrainingProgramForPGMemberPage.do";

  /**
   * Constant used for defining the edit completed provider group member
   * training program page.
   */
  public static final String kEditCompletedProviderGroupMemberTrainingProgram = "ProviderManagement_editCompletedTrainingProgramForProviderGroupMemberPage.do";

  /**
   * Constant used for defining the view completed provider group member
   * training program page.
   */
  public static final String kViewCompletedProviderGroupMemberTrainingProgram = "ProviderManagement_viewCompletedProviderGroupMemberTrainingPage.do";
  // END, CR00246961


  // BEGIN, CR00247606, GP
  /**
   * Constant used for defining the provider group ID page parameter.
   */
  public static final String var_providerGroupID = "providerGroupID";
  // END, CR00247606

  // BEGIN, CR00247586, PS
  /**
   * Constant used for defining the approve service invoice line item page for
   * line item pending approval.
   */
  public static final String kApproveServiceInvoiceLineItemPendingApproval = "ProviderManagement_approveSILIPage.do";

  /**
   * Constant used for defining the approve service invoice line item page for
   * line item pending approval correction.
   */
  public static final String kApproveServiceInvoiceLineItemPendingApprovalCorrection = "ProviderManagement_approveLineItemCorrectionsPage.do";

  /**
   * Constant used for defining the restore original data page for line item
   * open for correction.
   */
  public static final String kRestoreOriginalDataForOpenSILICorrection = "ProviderManagement_cancelLineItemCorrectionsPage.do";

  /**
   * Constant used for defining the restore original data page for line item
   * pending approval correction.
   */
  public static final String kRestoreOriginalDataForSILIPendingApprovalCorrection = "ProviderManagement_denyLineItemCorrectionsPage.do";

  /**
   * Constant used for defining the restore original data page for line item
   * open for correction.
   */
  public static final String kRestoreOriginalDataForOpenLineItemCorrection = "ProviderManagement_cancelOpenLineItemCorrectionsPage.do";

  /**
   * Constant used for defining the restore original data page for line item
   * pending approval correction.
   */
  public static final String kRestoreOriginalDataForLineItemPendingApprovalCorrection = "ProviderManagement_denyOpenLineItemCorrectionsPage.do";

  /**
   * Constant used for defining the new client data page for open service
   * invoice line item.
   */
  public static final String kNewClientForOpenSILI = "ProviderManagement_addClientToSILIPage.do";

  /**
   * Constant used for defining the new client data page for line item open for
   * correction.
   */
  public static final String kNewClientForOpenSILICorrection = "ProviderManagement_addClientToLineItemCorrectionPage.do";

  /**
   * Constant used for defining the new client data page for open service
   * invoice line item.
   */
  public static final String kNewClientForOpenLineItem = "ProviderManagement_addClientToOpenSILIPage.do";

  /**
   * Constant used for defining the new client data page for line item open for
   * correction.
   */
  public static final String kNewClientForOpenLineItemCorrection = "ProviderManagement_addClientToOpenLineItemCorrectionPage.do";

  /**
   * Constant used for defining the submit for approval data page for open
   * service invoice line item.
   */

  public static final String kSubmitOpenSILI = "ProviderManagement_submitSILIPage.do";

  /**
   * Constant used for defining the submit for approval data page for line item
   * open for correction.
   */
  public static final String kSubmitOpenSILICorrection = "ProviderManagement_submitSILICorrectionsForApprovalPage.do";

  /**
   * Constant used for defining the submit for approval data page for open
   * service invoice line item.
   */
  public static final String kSubmitOpenLineItem = "ProviderManagement_submitOpenSILIForProcessingPage.do";

  /**
   * Constant used for defining the submit for approval data page for line item
   * open for correction.
   */
  public static final String kSubmitOpenLineItemCorrection = "ProviderManagement_submitOpenSILICorrectionsForApprovalPage.do";

  // END, CR00247586

  // BEGIN, CR00248112, PS
  /**
   * Constant used for defining the approve service invoice line item page for
   * line item pending approval.
   */
  public static final String kApproveSILIPendingApproval = "ProviderManagement_approvePendingSILIPage.do";

  /**
   * Constant used for defining the approve service invoice line item page for
   * line item pending approval correction.
   */
  public static final String kApproveSILIPendingApprovalCorrection = "ProviderManagement_approvePendingSILICorrectionsPage.do";
  // END, CR00248112


  // BEGIN, CR00249624, GP
  /**
   * Constant used for defining the incidents participants page.
   */
  public static final String kIncidentParticipants = "ProviderManagement_IncidentParticipantsPage.do";
  // END, CR00249624

  // BEGIN, CR00261445, GP
  /**
   * Constant used for defining the ServiceInvoice Line Item Approval Work Queue ID.
   */
  public static final String kServiceInvoiceLineItemApprovalWorkQueueID = "5";

  /**
   * Constant used for defining the Roster Line Item Approval Work Queue ID.
   */
  public static final String kRosterLineItemApprovalWorkQueueID = "7";
  // END, CR00261445

  // BEGIN, CR00273516, SS
  /**
   * String constant representing the environment property entry. The value
   * retrieved from environment property entry represents if an agency wishes to
   * have unlimited payable amount. If it is set to true, there is no
   * restriction on how much amount can be paid. If it is set to false, the
   * payable amount will be suspended if it is more than a specified limit.
   */
  public static final String kUnlimitedAmountRequired = "curam.financial.cpm.UnlimitedAmountRequired";
  // END, CR00273516

  // BEGIN, CR00280340, RPB

  /**
   * String constant representing the environment property entry. The value
   * retrieved from environment property entry represents if an agency wishes to
   * allow the submission of rosters and roster line items containing future
   * dated services. If it is set to true, users can submit rosters and roster
   * line items with a future service date. They can also enter absence or
   * attendance details for future dates. If it is set to false, users will be
   * prevented from submitting rosters and roster line items with a future
   * service date and from entering absence or attendance details for future
   * dates.
   */
  public static final String kFutureDatedRostersEnabled = "curam.financial.FutureDatedRostersEnabled";

  /**
   * String constant representing the environment property entry. The value
   * retrieved from environment property entry represents if an agency wishes to
   * allow the submission of invoices for future dated services. If it is set to
   * true, users can submit invoices with a future service date. If it is set to
   * false, users will be prevented from submitting invoices with a future
   * service date.
   */
  public static final String kFutureDatedSILIEnabled = "curam.financial.FutureDatedSILIEnabled";
  // END, CR00280340


  // BEGIN, CR00280874, GP
  /**
   * Constant used for defining the number of days till which wait list entries
   * due for renewal should be displayed.
   */
  public static final int kWaitListEntriesRenewalDays = 22;
  // END, CR00280874
  // BEGIN, CR00280390, GP
  /**
   * Constant used for defining the SILIOfflineException Object.
   */
  public static final String kSILIOfflineException = "SILIOfflineException";

  /**
   * Constant used for defining the PRLIOfflineException Object.
   */
  public static final String kPRLIOfflineException = "PRLIOfflineException";
  // END, CR00280390

  // BEGIN, CR00282026, SSK
  /**
   * Constant used for defining new managed training menu id.
   */
  public static final String kNewManagedTrainingMenuID = "NewManagedTraining";

  /**
   * Constant used for defining non managed training menu id.
   */
  public static final String kNonManagedTrainingMenuID = "NonManagedTraining";

  /**
   * Constant used for defining new training menu id.
   */
  public static final String kNewTrainingMenuID = "NewTraining";

  // END, CR00282026

  // BEGIN, CR00282506, MR
  /**
   * Constants for the provider tab details page.
   */
  public static final String gkProviderTabDetailsPage = new String(
    "ProviderManagement_providerHomeTabDetailsPreviewPage.do");

  /**
   * Constants for the provider group tab details page.
   */
  public static final String gkProviderGroupTabDetailsPage = new String(
    "ProviderManagement_providerGroupHomeTabDetailsPreviewPage.do");
  // END, CR00282506


  // BEGIN, CR00291801, ASN
  // BEGIN, CR00292830, ASN
  /**
   * Constant used for allegation role type.
   */
  public static final String KAllegationRoleType = new String("ART");

  // END, CR00291801


  /**
   * Constant used for defining representative icon.
   */
  public static final String gkIconRepresentative = new String(
    "IconRepresentative");

  // END, CR00292830

  // BEGIN, CR00281323, RPB
  /**
   * Constant used to indicate the default product delivery pattern id.
   */
  public static final int kDefaultProductDeliveryPatternID = 769;

  // END, CR00281323

  // BEGIN, CR00303745, SSK

  /**
   * Constant used to indicate the ampersand.
   */
  public static final String kAmpersand = "&";

  /**
   * Constant used to indicate the ampersand.
   */
  public static final String kEquals = "=";

  /**
   * Constant used to indicate the compartment string.
   */
  public static final String kCompartments = "compartments";

  /**
   * Constant used to indicate the top compartment string.
   */
  public static final String kTopCompartment = "top-compartment";

  /**
   * Constant used to indicate the compartment loader.
   */
  public static final String kCompartmentLoader = "curam.place.impl.CompartmentLoader";

  /**
   * Constant used to indicate the tree node ID.
   */
  public static final String kTreeNodeID = "nodeId";
  // END, CR00303745

  // BEGIN, CR00334137, SSK
  /**
   * Constant used to represent rate cell sentinel value.
   */
  public static final double kRateCellSentinelValue = -1.0e13;
  // END, CR00334137

  // BEGIN, CR00321084, GA
  /**
   * Constant used to represent a line break.
   */
  public static final String kLineBreak = "<br />";
  // END, CR00321084


  // BEGIN, CR00358830, SS
  /**
   * Constant used to represent content type for xml.
   */
  public static final String kCONTENT_TYPE = "text/xml;charset=utf-8";
  // END, CR00358830


  // BEGIN, CR00380509, SS
  /**
   * Constant used to represent maximum physical capacity.
   */
  public static final int kPRPhysicalCapacity = 1000;

  /**
   * Constant used to represent maximum designated capacity.
   */
  public static final int kMaximumCapacity = 1000;

  /**
   * Constant used to represent minimum physical and designated capacity.
   */
  public static final int kMinimumCapacity = 0;
  // END, CR00380509

  // BEGIN, CR00385446, PS
  /**
   * String constant representing the internal system identifier for Provider Enquiry
   */
  public static final String kProviderEnquiryID = "providerEnquiryID";

  /**
   * Constant used for defining new transfer to enroll provider menu id.
   */
  public static final String kTransferToEnrolledProviderMenuID = "TransferToEnrolledProvider";
  // END, CR00385446


}
// END, CR00233623