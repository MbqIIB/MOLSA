/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.creoleruleset.impl;


import curam.codetable.impl.CREOLERULESETTYPEEntry;
import curam.codetable.impl.RELATEDTYPEEntry;
import curam.serviceoffering.impl.ServiceOfferingAccessor;
import curam.util.persistence.OptimisticLockable;
import curam.util.persistence.StandardEntity;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;


/**
 * Accessor interface for Creole Rule Set Link
 * {@linkplain curam.cpm.creoleruleset.impl.CreoleRuleSetLink}.
 *
 */
public interface CreoleRuleSetLinkAccessor extends StandardEntity, DateRanged, OptimisticLockable {

  /**
   * Gets the unique system generated identifier for the creole rule set record.
   *
   * @return Unique ID of the creole rule set record.
   */
  long getCreoleRuleSetID();

  /**
   * Gets the unique system generated identifier for the related entity. For
   * example service Offering ID.
   *
   * @return Unique ID of the related entity record.
   */
  long getRelatedID();

  /**
   * Gets the related type for which rule set is associated. For example Service
   * Offering.
   *
   * @return Related type for which rule set is associated.
   */
  RELATEDTYPEEntry getRelatedType();

  /**
   * Gets rule set type associated with related type. For example Estimated Cost
   * rule set for Service Offering.
   *
   * @return Rule set type.
   */
  CREOLERULESETTYPEEntry getRuleSetType();

  /**
   * Gets the name of the rule set class.
   *
   * @return Rule set class name.
   */
  String getRuleSetClassName();
  
  /**
   * Gets the name of data store.
   *
   * @return DataStore schema name.
   */
  String getDataStoreName();

  /**
   * Gets the service offering for the service delivery configuration.
   *
   * @return The service offering associated with service delivery
   * configuration.
   */
  ServiceOfferingAccessor getServiceOffering();
}
