/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import curam.codetable.CASETYPECODE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.SCREENINGNAMECODE;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.intf.Participant;
import curam.core.facade.struct.ListParticipantFinancialsKey;
import curam.core.facade.struct.ParticipantContextDetails;
import curam.core.facade.struct.ParticipantContextKey;
import curam.core.facade.struct.ParticipantFinancials;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.MaintainCaseFactory;
import curam.core.fact.MaintainConcernRoleAddressFactory;
import curam.core.fact.MaintainConcernRoleEmailFactory;
import curam.core.fact.MaintainConcernRolePhoneFactory;
import curam.core.fact.ViewConcernAccountFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.intf.MaintainCase;
import curam.core.intf.MaintainConcernRoleAddress;
import curam.core.intf.MaintainConcernRoleEmail;
import curam.core.intf.MaintainConcernRolePhone;
import curam.core.intf.ViewConcernAccount;
import curam.core.sl.entity.fact.ScreeningFactory;
import curam.core.sl.entity.intf.Screening;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.ScreeningName;
import curam.core.sl.fact.ExternalUserParticipantLinkFactory;
import curam.core.sl.intf.ExternalUserParticipantLink;
import curam.core.sl.struct.ExternalUsersRoleAndRelTypeDetails;
import curam.core.struct.CaseHeaderConcernRoleDetails;
import curam.core.struct.CaseHeaderConcernRoleDetailsList;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CasesByConcernRoleIDKey;
import curam.core.struct.FinancialAccountIdentifier;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.MaintainAddressKey;
import curam.core.struct.MaintainEmailKey;
import curam.core.struct.MaintainPhoneNumberKey;
import curam.core.struct.ViewConcAccountSummaryResult;
import curam.cpm.facade.struct.ExternalUserParticipantLinkKey;
import curam.cpm.facade.struct.ListAddressResult;
import curam.cpm.facade.struct.ListCaseResult;
import curam.cpm.facade.struct.ListEmailAddressResult;
import curam.cpm.facade.struct.ListFinancialResult;
import curam.cpm.facade.struct.ListInteractionResult;
import curam.cpm.facade.struct.ListPhoneNumberResult;
import curam.core.sl.entity.fact.ClientInteractionFactory;
import curam.core.sl.entity.struct.ListInteractionKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * Process class used to read the linked participant details
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is no longer used. See release note:
 * CR00226000.
 */
@Deprecated
public abstract class CPMExternalLinkedParticipant extends curam.cpm.facade.base.CPMExternalLinkedParticipant {

  // ___________________________________________________________________________
  /**
   * Method to return a list of address for an External User linked to a
   * participant.
   *
   * @param key Contains an External User Participant Link entity key
   * @return A list of addresses
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam V6.0.
   * This method is deprecated as it is no longer used. See release note:
   * CR00226000.
   */
  @Deprecated
  public ListAddressResult listAddresses(ExternalUserParticipantLinkKey key)
    throws AppException, InformationalException {
    // Return object
    ListAddressResult listAddressResult = new ListAddressResult();

    // Address maintenance objects
    MaintainConcernRoleAddress maintainConcernRoleAddressObj = MaintainConcernRoleAddressFactory.newInstance();
    MaintainAddressKey maintainAddressKey = new MaintainAddressKey();

    // Get the participantRoleID from the external users participant link table
    ExternalUserParticipantLink externalUserParticipantLink = ExternalUserParticipantLinkFactory.newInstance();

    ExternalUsersRoleAndRelTypeDetails roleAndRelTypeDetails = externalUserParticipantLink.readParticipantRoleID(
      key.key);

    // set the participantRoleID
    long participantRoleID = roleAndRelTypeDetails.participantRoleID;

    // Return the ParticipantRoleID
    listAddressResult.participantRoleIDDetails.participantRoleID = participantRoleID;

    maintainAddressKey.concernRoleID = participantRoleID;

    // Read list of addresses
    listAddressResult.readMultiByConcRoleIDResult = maintainConcernRoleAddressObj.readmultiByConcernRoleID(
      maintainAddressKey);

    // Context Objects
    Participant participantObj = ParticipantFactory.newInstance();
    ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = participantRoleID;

    // Get the context description for the concern role
    listAddressResult.participantContextDescriptionDetails = participantObj.readContextDescription(participantContextKey).participantContextDescriptionDetails;

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      listAddressResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return listAddressResult;
  }

  // ___________________________________________________________________________
  /**
   * Method to return a list of cases for an External User linked to a
   * participant.
   *
   * @param key Contains an External User Participant Link entity key
   * @return A list of cases
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam V6.0.
   * This method is deprecated as it is no longer used. See release note:
   * CR00226000.
   */
  @Deprecated
  public ListCaseResult listCases(ExternalUserParticipantLinkKey key)
    throws AppException, InformationalException {
    // Return object
    ListCaseResult listCaseResult = new ListCaseResult();

    // Case Search object
    MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();
    CaseHeaderConcernRoleDetailsList caseHeaderConcernRoleDetailsList;
    CasesByConcernRoleIDKey casesByConcernRoleIDKey = new CasesByConcernRoleIDKey();

    // Context objects
    ParticipantContextKey participantContextKey = new ParticipantContextKey();
    Participant participantObj = ParticipantFactory.newInstance();

    // Get the participantRoleID from the external users participant link table
    ExternalUserParticipantLink externalUserParticipantLinkObj = ExternalUserParticipantLinkFactory.newInstance();

    ExternalUsersRoleAndRelTypeDetails roleAndRelTypeDetails = externalUserParticipantLinkObj.readParticipantRoleID(
      key.key);

    // set the participantRoleID
    long participantRoleID = roleAndRelTypeDetails.participantRoleID;

    // Return the ParticipantRoleID
    listCaseResult.participantRoleIDDetails.participantRoleID = participantRoleID;

    participantContextKey.participantContextDescriptionKey.concernRoleID = participantRoleID;

    // Get the context description for the concern role
    listCaseResult.participantContextDescriptionDetails = participantObj.readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Set status code for search
    casesByConcernRoleIDKey.concernRoleID = participantRoleID;
    casesByConcernRoleIDKey.statusCode = curam.codetable.CASESTATUSSEARCH.ALL;

    // Perform case search
    caseHeaderConcernRoleDetailsList = maintainCaseObj.getCasesByConcernRoleID(
      casesByConcernRoleIDKey);

    // Check if the list is populated
    if (!caseHeaderConcernRoleDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listCaseResult.caseHeaderConcernRoleDetailsList.dtls.ensureCapacity(
        caseHeaderConcernRoleDetailsList.dtls.size());

      CaseHeaderConcernRoleDetails caseHeaderConcernRoleDetails;

      // Iterate through the list returned
      for (int i = 0; i < caseHeaderConcernRoleDetailsList.dtls.size(); i++) {

        caseHeaderConcernRoleDetails = new CaseHeaderConcernRoleDetails();

        // Assign details
        caseHeaderConcernRoleDetails.assign(
          caseHeaderConcernRoleDetailsList.dtls.item(i));

        String productTypeDesc = CuramConst.gkEmpty;
        String caseTypeCode = caseHeaderConcernRoleDetailsList.dtls.item(i).caseTypeCode;

        // Check if the case is a product delivery, liability,
        // integrated case
        // or screening case
        if ((caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY))
          || (caseTypeCode.equals(CASETYPECODE.LIABILITY))) {

          productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
            caseHeaderConcernRoleDetailsList.dtls.item(i).productType);

        } else if (caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {

          // CaseHeader manipulation variables
          CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
          CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
          CaseHeaderDtls caseHeaderDtls;

          // Set key to read caseHeader
          caseHeaderKey.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

          caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

          productTypeDesc = CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
            caseHeaderDtls.integratedCaseType);

        } else if (caseTypeCode.equals(CASETYPECODE.SCREENINGCASE)) {

          // Screening manipulation variables
          Screening screeningObj = ScreeningFactory.newInstance();
          CaseKeyStruct caseKeyStruct = new CaseKeyStruct();
          ScreeningName screeningName;

          // Set key to read read Screening entity
          caseKeyStruct.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

          // Read Screening
          screeningName = screeningObj.readName(caseKeyStruct);

          productTypeDesc = CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME,
            screeningName.name);
        }

        if (productTypeDesc == null || productTypeDesc.length() == 0) {

          productTypeDesc = CodeTable.getOneItem(CASETYPECODE.TABLENAME,
            caseTypeCode);
        }

        caseHeaderConcernRoleDetails.productTypeDesc = productTypeDesc;

        // Add to return object
        listCaseResult.caseHeaderConcernRoleDetailsList.dtls.addRef(
          caseHeaderConcernRoleDetails);
      }

    }

    // Return details
    return listCaseResult;
  }

  // ___________________________________________________________________________
  /**
   * Method to return a list of email addresses for an External User linked to
   * a participant.
   *
   * @param key Contains an External User Participant Link entity key
   * @return A list of email addresses
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam V6.0.
   * This method is deprecated as it is no longer used. See release note:
   * CR00226000.
   */
  @Deprecated
  public ListEmailAddressResult listEmailAddresses(
    ExternalUserParticipantLinkKey key) throws AppException,
      InformationalException {
    // Return object
    ListEmailAddressResult listEmailAddressResult = new ListEmailAddressResult();

    // Email address maintenance object
    MaintainConcernRoleEmail maintainConcernRoleEmailObj = MaintainConcernRoleEmailFactory.newInstance();
    MaintainEmailKey maintainEmailKey = new MaintainEmailKey();

    // Get the participantRoleID from the external users participant link table
    curam.core.sl.intf.ExternalUserParticipantLink externalUserParticipantLink = ExternalUserParticipantLinkFactory.newInstance();

    ExternalUsersRoleAndRelTypeDetails roleAndRelTypeDetails = externalUserParticipantLink.readParticipantRoleID(
      key.key);

    // Set the participantRoleID
    long participantRoleID = roleAndRelTypeDetails.participantRoleID;

    // Return the ParticipantRoleID
    listEmailAddressResult.participantRoleIDDetails.participantRoleID = participantRoleID;

    maintainEmailKey.concernRoleID = participantRoleID;

    // Read list of email addresses
    listEmailAddressResult.readMultiByConcernRoleEmailResult = maintainConcernRoleEmailObj.readmultiByConcernRole(
      maintainEmailKey);

    // Context Objects
    Participant participantObj = ParticipantFactory.newInstance();
    ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = participantRoleID;

    // Get the context description for the concern role
    listEmailAddressResult.participantContextDescriptionDetails = participantObj.readContextDescription(participantContextKey).participantContextDescriptionDetails;

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      listEmailAddressResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return listEmailAddressResult;
  }

  // ___________________________________________________________________________
  /**
   * Method to return a list of financials for an External User linked to a
   * participant.
   *
   * @param key Contains an External User Participant Link entity key
   * @return A list of financials
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam V6.0.
   * This method is deprecated as it is no longer used. See release note:
   * CR00226000.
   */
  @Deprecated
  public ListFinancialResult listFinancials(ExternalUserParticipantLinkKey key)
    throws AppException, InformationalException {
    // Return object
    ListFinancialResult listFinancialResult = new ListFinancialResult();

    // ViewConcernAccount manipulation variables
    ViewConcernAccount viewConcernAccountObj = ViewConcernAccountFactory.newInstance();
    ViewConcAccountSummaryResult viewConcernRoleAccountSummary;
    FinancialAccountIdentifier financialAccountIdentifier = new FinancialAccountIdentifier();

    // Get the participantRoleID from the external users participant link table
    ExternalUserParticipantLink externalUserParticipantLinkObj = ExternalUserParticipantLinkFactory.newInstance();

    ExternalUsersRoleAndRelTypeDetails roleAndRelTypeDetails = externalUserParticipantLinkObj.readParticipantRoleID(
      key.key);

    // Set the participantRoleID
    long participantRoleID = roleAndRelTypeDetails.participantRoleID;

    // Return the ParticipantRoleID
    listFinancialResult.participantRoleIDDetails.participantRoleID = participantRoleID;

    // Set up the key value object
    ListParticipantFinancialsKey listParticipantFinancialsKey = new ListParticipantFinancialsKey();

    listParticipantFinancialsKey.concernRoleID = participantRoleID;

    // Assign key details to search for the concern's financials
    financialAccountIdentifier.assign(listParticipantFinancialsKey);

    // Call ViewConcernAccount BPO to return the concern's financial records
    viewConcernRoleAccountSummary = viewConcernAccountObj.viewConcernRoleAccountSummary(
      financialAccountIdentifier);

    // Iterate through the list if it's populated
    if (!viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.isEmpty()) {

      // Reserve space in the output object
      listFinancialResult.participantFinancialsList.dtls.ensureCapacity(
        viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.size());

      // ConcernFinancials object
      ParticipantFinancials participantFinancials;

      for (int i = 0; i
        < viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.size(); i++) {

        participantFinancials = new ParticipantFinancials();

        participantFinancials.assign(
          viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.item(i));

        /*
         * Amounts are always stored on the database in the base
         * currency and always read back as such. The base currency is
         * returned here for display purposes. The amounts in the money
         * field(s) on each row will be shown in the following format:
         * "USD 1000"
         */
        participantFinancials.currencyType = viewConcernRoleAccountSummary.concernRoleAccSummHeader.currencyType;

        // Add details to the list
        listFinancialResult.participantFinancialsList.dtls.addRef(
          participantFinancials);
      }

    }

    // Context objects
    Participant participantObj = ParticipantFactory.newInstance();
    ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = participantRoleID;
    ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    // Get the context description for the concern role
    participantContextDetails = participantObj.readContextDescription(
      participantContextKey);

    listFinancialResult.participantContextDescriptionDetails.description = participantContextDetails.participantContextDescriptionDetails.description;

    return listFinancialResult;
  }

  // ___________________________________________________________________________
  /**
   * Method to return a list of interactions for an External User linked to a
   * participant.
   *
   * @param key Contains an External User Participant Link entity key
   * @return A list of interactions
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam V6.0.
   * This method is deprecated as it is no longer used. See release note:
   * CR00226000.
   */
  @Deprecated
  public ListInteractionResult listInteractions(
    ExternalUserParticipantLinkKey key) throws AppException,
      InformationalException {
    // Return object
    ListInteractionResult listInteractionResult = new ListInteractionResult();
    ListInteractionKey listInteractionKey = new ListInteractionKey();

    // BEGIN, CR00205134, DRS
    // ParticipantInteractions object.
    curam.core.sl.entity.intf.ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();
    // END, CR00205134

    // Get the participantRoleID from the external users participant link table
    ExternalUserParticipantLink externalUserParticipantLinkObj = ExternalUserParticipantLinkFactory.newInstance();

    ExternalUsersRoleAndRelTypeDetails roleAndRelTypeDetails = externalUserParticipantLinkObj.readParticipantRoleID(
      key.key);

    // set the participantRoleID
    long participantRoleID = roleAndRelTypeDetails.participantRoleID;

    // Return the ParticipantRoleID
    listInteractionResult.participantRoleIDDetails.participantRoleID = participantRoleID;

    listInteractionKey.concernRoleID = participantRoleID;

    // BEGIN, CR00205134, DRS
    // read the list of interaction records.
    listInteractionResult.listInteractionDetails.details.detailsList = clientInteractionObj.list(
      listInteractionKey);
    // END, CR00205134

    // context objects
    Participant participantObj = ParticipantFactory.newInstance();
    ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = participantRoleID;
    ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    // get the context description for the concern role
    participantContextDetails = participantObj.readContextDescription(
      participantContextKey);

    listInteractionResult.participantContextDescriptionDetails.description = participantContextDetails.participantContextDescriptionDetails.description;

    return listInteractionResult;
  }

  // ___________________________________________________________________________
  /**
   * Method to return a list of phone numbers for an External User linked to
   * a participant.
   *
   * @param key Contains an External User Participant Link entity key
   * @return A list of phone numbers
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam V6.0.
   * This method is deprecated as it is no longer used. See release note:
   * CR00226000.
   */
  @Deprecated
  public ListPhoneNumberResult listPhoneNumbers(
    ExternalUserParticipantLinkKey key) throws AppException,
      InformationalException {
    // Return object
    ListPhoneNumberResult listPhoneNumberResult = new ListPhoneNumberResult();

    // Phone number maintenance object
    MaintainConcernRolePhone maintainConcernRolePhoneObj = MaintainConcernRolePhoneFactory.newInstance();
    MaintainPhoneNumberKey maintainPhoneNumberKey = new MaintainPhoneNumberKey();

    // Get the participantRoleID from the external users participant link table
    ExternalUserParticipantLink externalUserParticipantLinkObj = ExternalUserParticipantLinkFactory.newInstance();

    ExternalUsersRoleAndRelTypeDetails roleAndRelTypeDetails = externalUserParticipantLinkObj.readParticipantRoleID(
      key.key);

    // set the participantRoleID
    long participantRoleID = roleAndRelTypeDetails.participantRoleID;

    // Return the ParticipantRoleID
    listPhoneNumberResult.participantRoleIDDetails.participantRoleID = participantRoleID;

    maintainPhoneNumberKey.concernRoleID = participantRoleID;

    // Read list of phone numbers
    listPhoneNumberResult.readMultiByConcernRoleIDPhoneResult = maintainConcernRolePhoneObj.readmultiByConcernRole(
      maintainPhoneNumberKey);

    // Context key
    Participant participantObj = ParticipantFactory.newInstance();
    ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = participantRoleID;

    // Get the context description for the concern role
    listPhoneNumberResult.participantContextDescriptionDetails = participantObj.readContextDescription(participantContextKey).participantContextDescriptionDetails;

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      listPhoneNumberResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return listPhoneNumberResult;
  }

}
