/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.attachment.impl.Attachment;
import curam.attachmentlink.impl.AttachmentLink;
import curam.attachmentlink.impl.AttachmentLinkDAO;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkKey;
import curam.attachmentlink.struct.ListAttachmentLinkDetails;
import curam.codetable.ATTACHMENTOBJECTLINKTYPE;
import curam.codetable.CONTRACTSTATUS;
import curam.codetable.SENSITIVITY;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.codetable.impl.CONTRACTTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.contracts.ContractNotificationEvent;
import curam.contracts.impl.ContractContact;
import curam.contracts.impl.ContractContactDAO;
import curam.contracts.impl.ContractGenerationReasonEntry;
import curam.contracts.impl.ContractNotification;
import curam.contracts.impl.ContractStatusHistory;
import curam.contracts.impl.ContractTerminationReasonEntry;
import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.ContractVersionDAO;
import curam.contracts.impl.ContractVersionProviderGroupAssociate;
import curam.contracts.impl.ContractVersionProviderGroupAssociateDAO;
import curam.contracts.impl.ContractVersionProviderOffering;
import curam.contracts.impl.ContractVersionProviderOfferingDAO;
import curam.contracts.impl.FlatRateContractDAO;
import curam.contracts.impl.UtilizationContract;
import curam.contracts.impl.UtilizationContractDAO;
import curam.core.impl.CuramConst;
import curam.core.struct.AttachmentKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.cpm.facade.struct.ActivateContractDetails;
import curam.cpm.facade.struct.ContractContactDetails;
import curam.cpm.facade.struct.ContractContactDetailsList;
import curam.cpm.facade.struct.ContractNotificationKey;
import curam.cpm.facade.struct.ContractOwnerDetails;
import curam.cpm.facade.struct.ContractReturnDocDetails;
import curam.cpm.facade.struct.ContractStatusHistoryDetails;
import curam.cpm.facade.struct.ContractStatusHistoryDetailsList;
import curam.cpm.facade.struct.ContractViewDetails;
import curam.cpm.facade.struct.ContractViewDetailsList;
import curam.cpm.facade.struct.ContractedPlaceLimitDetails;
import curam.cpm.facade.struct.CreateContactDetails;
import curam.cpm.facade.struct.DeleteContactKey;
import curam.cpm.facade.struct.GenerateContractDetails;
import curam.cpm.facade.struct.ModifyContractContactDetails;
import curam.cpm.facade.struct.PlaceLimitContractDetails;
import curam.cpm.facade.struct.ProviderContractKey;
import curam.cpm.facade.struct.ProviderDetails;
import curam.cpm.facade.struct.ProviderDetailsList;
import curam.cpm.facade.struct.ProviderOfferingContactsList;
import curam.cpm.facade.struct.ProviderOfferingDetails;
import curam.cpm.facade.struct.ProviderOfferingDetailsList;
import curam.cpm.facade.struct.ProviderOfferingPlaceLimitInformationalDtls;
import curam.cpm.facade.struct.ProviderOfferingRateDetails;
import curam.cpm.facade.struct.ProviderOfferingTabbedList;
import curam.cpm.facade.struct.ReadContactKey;
import curam.cpm.facade.struct.RenewContractDetails;
import curam.cpm.facade.struct.TerminateContractDetails;
import curam.cpm.facade.struct.ViewContractContactDtls;
import curam.cpm.facade.struct.ViewContractStatusHistoryDetails;
import curam.cpm.facade.struct.ViewContractStatusHistoryDetailsList;
import curam.cpm.facade.struct.ViewProviderOfferingDetails;
import curam.cpm.facade.struct.ViewRenewContractDetails;
import curam.cpm.message.impl.CONTRACTVERSIONExceptionCreator;
import curam.cpm.sl.entity.struct.ContractPOLinkKey;
import curam.cpm.sl.entity.struct.ContractVersionKey;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderGroupKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ProviderOfferingPlaceLimitDtls;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderGroupAssociate;
import curam.provider.impl.ProviderGroupAssociateDAO;
import curam.provider.impl.ProviderGroupDAO;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.provider.impl.ProviderParty;
import curam.provider.impl.ProviderPartyDAO;
import curam.providerservice.ProviderOfferingStatus;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingPlaceLimit;
import curam.providerservice.impl.ProviderOfferingPlaceLimitDAO;
import curam.providerservice.impl.ProviderOfferingRate;
import curam.providerservice.impl.ProviderOfferingRateDAO;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.SODELIVERYTYPEEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * {@inheritDoc}
 */
public abstract class ContractManagement extends curam.cpm.facade.base.ContractManagement {

  /**
   * Constructor.
   */
  public ContractManagement() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected ContractVersionDAO contractVersionDAO;

  @Inject
  protected FlatRateContractDAO flatRateContractDAO;

  @Inject
  protected UtilizationContractDAO utilizationContractDAO;

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  @Inject
  protected ContractVersionProviderOfferingDAO contractProviderOfferingLinkDAO;

  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;

  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  @Inject
  protected ContractContactDAO contractContactDAO;

  @Inject
  protected ContractVersionProviderGroupAssociateDAO contractVersionProviderGroupAssociateDAO;

  @Inject
  protected ProviderOfferingRateDAO providerOfferingRateDAO;

  @Inject
  protected ProviderOfferingPlaceLimitDAO providerOfferingPlaceLimitDAO;

  // BEGIN CR00096014, MST
  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;

  // END CR00096014

  // BEGIN, CR00226594, FM
  @Inject
  protected Attachment attachmentObj;

  // END, CR00226594

  // BEGIN, CR00234487, GP
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;

  // END, CR00234487

  /**
   * {@inheritDoc}
   */
  public void activateContract(ActivateContractDetails details)
    throws AppException, InformationalException {

    final curam.contracts.impl.ContractVersion contractVersion = contractVersionDAO.get(
      details.contractVersionID);

    ContractNotification contractNotification = new ContractNotification();
    ContractNotificationKey contractNotificationKey = new ContractNotificationKey();

    // FLAT-RATE contract
    if (contractVersion.getContractType().equals(CONTRACTTYPEEntry.FLATRATE)) {

      final curam.contracts.impl.FlatRateContract flatRateContract = flatRateContractDAO.get(
        details.contractVersionID);

      flatRateContract.setDateSigned(details.dateSigned);
      flatRateContract.activate(details.versionNo);
    } // UTILIZATION contract
    else if (contractVersion.getContractType().equals(
      CONTRACTTYPEEntry.UTILIZATION)) {

      final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
        details.contractVersionID);

      utilizationContract.setDateSigned(details.dateSigned);
      utilizationContract.activate(details.versionNo);

    }

    // Activation Notification

    // Provider
    if (contractVersion.getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {

      // Send Notification
      contractNotificationKey.contractVersionID = details.contractVersionID;
      contractNotificationKey.event = ContractNotificationEvent.ACTIVATEPROVIDERCONTRACT;
      contractNotification.createNotification(contractNotificationKey);
    } // Provider Group
    else if (contractVersion.getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDERGROUP)) {
      contractNotificationKey.contractVersionID = details.contractVersionID;
      contractNotificationKey.event = ContractNotificationEvent.ACTIVATEPGCONTRACT;
      contractNotification.createNotification(contractNotificationKey);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void createContractContact(CreateContactDetails details)
    throws AppException, InformationalException {

    ContractContact contractContact = contractContactDAO.newInstance();

    ProviderParty providerParty = providerPartyDAO.get(details.providerPartyID);
    ContractVersion contractVersion = contractVersionDAO.get(
      details.contractVersionID);

    final DateRange dateRange = new DateRange(details.startDate,
      details.endDate);

    contractContact.setProviderParty(providerParty);
    contractContact.setContactPeriod(dateRange);
    contractContact.setContractVersion(contractVersion);

    contractContact.insert();
  }

  /**
   * {@inheritDoc}
   */
  public void deleteContractContact(DeleteContactKey key) throws AppException,
      InformationalException {

    ContractContact contractContact = contractContactDAO.get(
      key.contractContactID);

    contractContact.cancel(key.versionNo);

  }

  /**
   * {@inheritDoc}
   */
  public void generateContract(GenerateContractDetails details)
    throws AppException, InformationalException {

    final curam.contracts.impl.ContractVersion contractVersion = contractVersionDAO.get(
      details.contractVersionID);

    // If its a Flat-Rate contract
    if (contractVersion.getContractType().equals(CONTRACTTYPEEntry.FLATRATE)) {

      final curam.contracts.impl.FlatRateContract flatRateContract = flatRateContractDAO.get(
        details.contractVersionID);

      flatRateContract.setGenerationReason(
        (ContractGenerationReasonEntry.get(details.generationReason)));
      flatRateContract.setGenerationDate(Date.getCurrentDate());
      flatRateContract.generate(details.versionNo);
    } // If its a Utilization contract
    else if (contractVersion.getContractType().equals(
      CONTRACTTYPEEntry.UTILIZATION)) {

      final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
        details.contractVersionID);

      utilizationContract.setGenerationReason(
        (ContractGenerationReasonEntry.get(details.generationReason)));
      utilizationContract.setGenerationDate(Date.getCurrentDate());
      utilizationContract.generate(details.versionNo);
    }

    ValidationHelper.failIfErrorsExist();

    // Send Notification
    ContractNotification contractNotification = new ContractNotification();
    ContractVersionKey contractVersionKey = new ContractVersionKey();

    contractVersionKey.contractVersionID = details.contractVersionID;

    // Determine appropriate notification event
    ContractNotificationKey contractNotificationKey = getGenerationNotificationEvent(
      contractVersionKey);

    contractNotification.createNotification(contractNotificationKey);

  }

  /**
   * Returns the appropriate event required for the contract at this stage.
   *
   * @param key
   * Contains the contractVersionID of the flat-rate/utilization
   * contract.
   *
   * @return The contractVersionID and the notification event.
   */
  // BEGIN, CR00177241, PM
  protected ContractNotificationKey getGenerationNotificationEvent(
    // END, CR00177214
    ContractVersionKey key) {

    ContractNotificationKey contractNotificationKey = new ContractNotificationKey();

    final curam.contracts.impl.ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);

    // Flat-Rate Contract
    if (contractVersion.getContractType().equals(CONTRACTTYPEEntry.FLATRATE)) {

      final curam.contracts.impl.FlatRateContract flatRateContract = flatRateContractDAO.get(
        key.contractVersionID);

      // Provider
      if (flatRateContract.getProviderOrganization().getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDER)) {

        // Provider Flat-Rate Contract (Regular)
        if (!flatRateContract.getRegularPaymentAmt().isZero()) {
          contractNotificationKey.contractVersionID = key.contractVersionID;
          contractNotificationKey.event = ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTREG;
        } // Provider Flat-Rate Contract (Total)
        else if (!flatRateContract.getTotalContractAmt().isZero()) {
          contractNotificationKey.contractVersionID = key.contractVersionID;
          contractNotificationKey.event = ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTTOTAL;
        }
      } // Provider Group
      else if (flatRateContract.getProviderOrganization().getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDERGROUP)) {

        // PG Flat-Rate Contract (Regular)
        if (!flatRateContract.getRegularPaymentAmt().isZero()) {
          contractNotificationKey.contractVersionID = key.contractVersionID;
          contractNotificationKey.event = ContractNotificationEvent.NEWPGFLATRATECONTRACTREG;
        } // PG Flat-Rate Contract (Total)
        else if (!flatRateContract.getTotalContractAmt().isZero()) {
          contractNotificationKey.contractVersionID = key.contractVersionID;
          contractNotificationKey.event = ContractNotificationEvent.NEWPGFLATRATECONTRACTTOTAL;
        }
      }
    }

    // Utilization Contract
    if (contractVersion.getContractType().equals(CONTRACTTYPEEntry.UTILIZATION)) {

      final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
        key.contractVersionID);

      // Provider Utilization Contract
      if (utilizationContract.getProviderOrganization().getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDER)) {

        contractNotificationKey.contractVersionID = key.contractVersionID;
        contractNotificationKey.event = ContractNotificationEvent.NEWPROVIDERUTILIZATIONCONTRACT;
      } // Provider Group Utilization Contract
      else if (utilizationContract.getProviderOrganization().getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDERGROUP)) {

        contractNotificationKey.contractVersionID = key.contractVersionID;
        contractNotificationKey.event = ContractNotificationEvent.NEWPGUTILIZATIONCONTRACT;
      }
    }

    return contractNotificationKey;
  }

  // BEGIN, CR00237197, GP
  /**
   * Lists the Status History records of a
   * {@linkplain curam.contracts.impl.ContractVersion}.
   *
   * @param key
   * Contains the contractVersionID of the flat-rate/utilization
   * contract.
   *
   * @return ViewContractStatusHistoryDetailsList contains a list of status
   * history details for the contract.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listContractStatusHistoryDetails(ContractVersionKey)}.
   * This method is not useful for displaying user full name. Hence
   * this method is deprecated. The newly added method will give the
   * option to the user to display the user full name as well as
   * conditional display links. See release note: CR00237197.
   */
  @Deprecated
  // END, CR00237197
  public ViewContractStatusHistoryDetailsList listContractStatusHistory(
    ContractVersionKey key) throws AppException, InformationalException {

    // return struct
    ViewContractStatusHistoryDetailsList viewContractStatusHistoryDetailsList = new ViewContractStatusHistoryDetailsList();

    final ContractVersion contract = contractVersionDAO.get(
      key.contractVersionID);

    List<curam.contracts.impl.ContractStatusHistory> unModifiableContractStatusHistories = contract.getStatusHistory();
    List<curam.contracts.impl.ContractStatusHistory> unsortedContractStatusHistories = new ArrayList<curam.contracts.impl.ContractStatusHistory>();

    unsortedContractStatusHistories.addAll(unModifiableContractStatusHistories);

    // Retrieve ContractStatusHistory records for this contract
    for (final curam.contracts.impl.ContractStatusHistory contractStatusHistory : sortLicenses(
      unsortedContractStatusHistories)) {

      ViewContractStatusHistoryDetails viewContractStatusHistoryDetails = new ViewContractStatusHistoryDetails();

      // Assign the details from ContractStatusHistory to return struct
      viewContractStatusHistoryDetails.contractStatusHistoryID = contractStatusHistory.getID();
      viewContractStatusHistoryDetails.contractVersionID = key.contractVersionID;
      viewContractStatusHistoryDetails.lastModifiedBy = contractStatusHistory.getLastModifiedBy();
      viewContractStatusHistoryDetails.status = contractStatusHistory.getStatus().getCode();
      viewContractStatusHistoryDetails.statusDate = contractStatusHistory.getEventDateTime();

      if (contractStatusHistory.getStatus().equals(
        CONTRACTSTATUSEntry.TERMINATED)) {

        viewContractStatusHistoryDetails.reason = contractStatusHistory.getContractVersion().getTerminationReason().getCode();
      }

      if (contractStatusHistory.getStatus().equals(CONTRACTSTATUSEntry.ISSUED)) {

        viewContractStatusHistoryDetails.reason = contractStatusHistory.getStatusHistoryGenerationReason().getCode();
      }

      viewContractStatusHistoryDetailsList.viewContractStatusHistoryDetails.addRef(
        viewContractStatusHistoryDetails);
    }

    return viewContractStatusHistoryDetailsList;

  }

  /**
   * {@inheritDoc}
   */
  public ProviderOfferingContactsList listProviderOfferingsContacts(
    ProviderKey key) throws AppException, InformationalException {

    ProviderOfferingContactsList providerOfferingContactsList = new ProviderOfferingContactsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      key.providerConcernRoleID);

    for (final ProviderOffering providerOffering : providerOfferingDAO.searchBy(
      provider)) {

      if (providerOffering.getLifecycleState().getCode().equals(
        ProviderOfferingStatus.APPROVED)
          && !providerOffering.getDateRange().endsInPast()) {

        final ProviderOfferingDetails providerOfferingDetails = new ProviderOfferingDetails();

        // retrieve matching Service Offering name
        providerOfferingDetails.description = providerOffering.getServiceOffering().getName();
        providerOfferingDetails.code = providerOffering.getID();

        // BEGIN, CR00115627, GP
        // Only a provider offering for which 'Pay based on Placement'
        // and
        // 'Pay based on attendance' is set to false can be selected for
        // flat
        // rate contract
        // BEGIN, CR00132242, GP
        
        // BEGIN, CR00280602, GYH
        ServiceOffering serviceOffering = providerOffering.getServiceOffering();

        if (!serviceOffering.getPlacementPaymentInd()
          && !serviceOffering.isPayBasedOnAttendance()) {

          // Only a provider offering for which the service offering delivery
          // type is not of type 'Product Delivery'
          // or 'Product Delivery - PD financials' can be selected for
          // flat rate contract.
          if (!SODELIVERYTYPEEntry.PRODUCTDELIVERY.getCode().equals(
            serviceOffering.getDeliveryType().getCode())
              && !SODELIVERYTYPEEntry.PDWITHINVOICING.getCode().equals(
                serviceOffering.getDeliveryType().getCode())) {

            providerOfferingContactsList.providerOfferingDetailsList.providerOfferingDetails.addRef(
              providerOfferingDetails);
          }
        }
        // END, CR00280602
        // END, CR00132242
        // END, CR00115627

      }
    }

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = provider.getID();

    providerOfferingContactsList.contractContactDetailsList = listProviderParties(
      concernRoleKey);

    return providerOfferingContactsList;

  }

  /**
   * {@inheritDoc}
   */
  public InformationalMsgDtlsList renewContract(RenewContractDetails details)
    throws AppException, InformationalException {

    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final curam.contracts.impl.ContractVersion contractVersion = contractVersionDAO.get(
      details.contractVersionID);

    // If its a Flat-Rate contract
    if (contractVersion.getContractType().equals(CONTRACTTYPEEntry.FLATRATE)) {

      final curam.contracts.impl.FlatRateContract flatRateContract = flatRateContractDAO.get(
        details.contractVersionID);

      DateRange dateRange = new DateRange(details.startDate, details.endDate);

      flatRateContract.renew(details.versionNo, dateRange);
    } // If its a Utilization contract
    else if (contractVersion.getContractType().equals(
      CONTRACTTYPEEntry.UTILIZATION)) {

      final UtilizationContract utilizationContract = utilizationContractDAO.get(
        details.contractVersionID);

      DateRange dateRange = new DateRange(details.startDate, details.endDate);

      utilizationContract.renew(details.versionNo, dateRange);

    }

    // BEGIN, CR00281474, MR
    final ContractNotificationKey contractNotificationKey = new ContractNotificationKey();
    final ContractNotification contractNotification = new ContractNotification();

    if (CONCERNROLETYPEEntry.PROVIDER.equals(
      contractVersion.getProviderOrganization().getConcernRoleType())) {
      contractNotificationKey.contractVersionID = details.contractVersionID;
      contractNotificationKey.event = ContractNotificationEvent.RENEWPROVIDERCONTRACT;
      contractNotification.createNotification(contractNotificationKey);

    } else if (CONCERNROLETYPEEntry.PROVIDERGROUP.equals(
      contractVersion.getProviderOrganization().getConcernRoleType())) {
      contractNotificationKey.contractVersionID = details.contractVersionID;
      contractNotificationKey.event = ContractNotificationEvent.RENEWPGCONTRACT;
      contractNotification.createNotification(contractNotificationKey);
    }
    // END, CR00281474

    informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);

    }

    return informationalMsgDtlsList;
  }

  /**
   * {@inheritDoc}
   */
  public void terminateContract(TerminateContractDetails details)
    throws AppException, InformationalException {

    final curam.contracts.impl.ContractVersion contractVersion = contractVersionDAO.get(
      details.contractVersionID);

    ContractNotification contractNotification = new ContractNotification();
    ContractNotificationKey contractNotificationKey = new ContractNotificationKey();

    // FLAT-RATE contract
    if (contractVersion.getContractType().equals(CONTRACTTYPEEntry.FLATRATE)) {

      final curam.contracts.impl.FlatRateContract flatRateContract = flatRateContractDAO.get(
        details.contractVersionID);

      flatRateContract.setTerminationReason(
        ContractTerminationReasonEntry.get(details.terminationReason));
      flatRateContract.terminate(details.versionNo);

    } // UTILIZATION contract
    else if (contractVersion.getContractType().equals(
      CONTRACTTYPEEntry.UTILIZATION)) {

      final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
        details.contractVersionID);

      utilizationContract.setTerminationReason(
        ContractTerminationReasonEntry.get(details.terminationReason));
      utilizationContract.terminate(details.versionNo);
    }

    // Termination Notification

    // Provider
    if (contractVersion.getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {

      // Send Notification
      contractNotificationKey.contractVersionID = details.contractVersionID;
      contractNotificationKey.event = ContractNotificationEvent.TERMINATEPROVIDERCONTRACT;
      contractNotification.createNotification(contractNotificationKey);
    } // Provider Group
    else if (contractVersion.getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDERGROUP)) {

      // Send Notification
      contractNotificationKey.contractVersionID = details.contractVersionID;
      contractNotificationKey.event = ContractNotificationEvent.TERMINATEPGCONTRACT;
      contractNotification.createNotification(contractNotificationKey);
    }

  }

  /**
   * {@inheritDoc}
   */
  public ProviderOfferingDetailsList viewProviderOfferingsForProviderContract(
    ProviderContractKey key) throws AppException, InformationalException {

    // Get the ContractVersion
    ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);

    Provider provider = providerDAO.get(key.providerID);

    // Returns the set of ProviderOfferings offered by the Provider
    Set<ProviderOffering> availableProviderOfferingSet = providerOfferingDAO.searchBy(
      provider);

    // Add each ProviderOffering's ID and service name to the return struct
    ProviderOfferingDetailsList providerOfferingDetailsList = new ProviderOfferingDetailsList();
    ProviderOfferingDetails providerOfferingDetails;

    for (final ProviderOffering providerOffering : availableProviderOfferingSet) {

      // If the ProviderOffering is approved, its period covers the period
      // of
      // the contract add it to the list

      if (providerOffering.getLifecycleState().equals(
        ProviderOfferingStatusEntry.APPROVED)
          && providerOffering.getDateRange().contains(
            contractVersion.getDateRange())) {

        providerOfferingDetails = new ProviderOfferingDetails();
        providerOfferingDetails.code = providerOffering.getID();
        providerOfferingDetails.description = providerOffering.getServiceOffering().getName();

        // BEGIN, CR00115627, GP
        // Only a provider offering for which 'Pay based on Placement'
        // and
        // 'Pay based on attendance is set to false can be selected for
        // flat
        // rate contract
        // BEGIN, CR00132242, GP
        if (contractVersion.getContractType().equals(CONTRACTTYPEEntry.FLATRATE)) {
          if (!providerOffering.getServiceOffering().getPlacementPaymentInd()
            && !providerOffering.getServiceOffering().isPayBasedOnAttendance()) {
            
            // BEGIN, CR00281035, GYH
            // Only a provider offering for which the service offering
            // delivery
            // type is not of type 'Product Delivery'
            // or 'Product Delivery - PD financials' can be selected for
            // flat rate contract.
            if (!SODELIVERYTYPEEntry.PRODUCTDELIVERY.getCode().equals(
              providerOffering.getServiceOffering().getDeliveryType().getCode())
                && !SODELIVERYTYPEEntry.PDWITHINVOICING.getCode().equals(
                  providerOffering.getServiceOffering().getDeliveryType().getCode())) {
              providerOfferingDetailsList.providerOfferingDetails.addRef(
                providerOfferingDetails);
            }
            // END, CR00281035

          }
        } else {
          providerOfferingDetailsList.providerOfferingDetails.addRef(
            providerOfferingDetails);
        }
        // END, CR00132242
        // END, CR00115627
      }
    }

    // Construct a tabbed list of ProviderOfferings currently associated
    // with
    // the Contract
    StringBuffer stringBuffer = new StringBuffer();

    for (final ContractVersionProviderOffering contractProviderOfferingLink : contractProviderOfferingLinkDAO.searchBy(
      contractVersion)) {

      stringBuffer.append(
        contractProviderOfferingLink.getProviderOffering().getID().toString()
          + CuramConst.gkTabDelimiter);
    }

    providerOfferingDetailsList.currentProviderOfferingTabbedList = stringBuffer.toString();

    return providerOfferingDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderDetailsList listProviderGroupAssociatesForProviderGroup(
    ProviderGroupKey providerGroupKey) throws AppException,
      InformationalException {

    ProviderDetailsList providerDetailsList = new ProviderDetailsList();

    // for each ProviderGroupAssociate for the Provider
    for (final ProviderGroupAssociate providerGroupAssociate : providerGroupAssociateDAO.searchByProviderGroup(
      providerGroupDAO.get(providerGroupKey.providerGroupConcernRoleID))) {

      final ProviderDetails providerDetails = new ProviderDetails();

      // BEGIN, CR00159227, ASN
      if (!(RECORDSTATUSEntry.CANCELLED.equals(
        providerGroupAssociate.getLifecycleState()))
          && (!(providerGroupAssociate.getDateRange().endsInPast()))) {

        providerDetails.code = providerGroupAssociate.getID();

        providerDetails.description = providerGroupAssociate.getProvider().getName();

        providerDetailsList.providerDetails.addRef(providerDetails);
      }
      // END, CR00159227
    }
    return providerDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public void modifyContractContact(ModifyContractContactDetails details)
    throws AppException, InformationalException {

    ContractContact contractContact = contractContactDAO.get(
      details.contractContactID);
    ProviderParty providerParty = providerPartyDAO.get(
      details.contactConcernRoleID);
    final DateRange dateRange = new DateRange(details.startDate,
      details.endDate);

    contractContact.setProviderParty(providerParty);
    contractContact.setContactPeriod(dateRange);

    contractContact.modify(details.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public ViewContractContactDtls readContractContact(ReadContactKey key)
    throws AppException, InformationalException {

    // Return struct
    ViewContractContactDtls viewContractContactDtls = new ViewContractContactDtls();

    ContractContact contractContact = contractContactDAO.get(
      key.contractContactID);

    viewContractContactDtls.viewContractContactDetails.contactConcernRoleID = contractContact.getProviderParty().getID();
    viewContractContactDtls.viewContractContactDetails.contactName = contractContact.getProviderParty().getParty().getName();
    viewContractContactDtls.viewContractContactDetails.contractContactID = contractContact.getID();
    viewContractContactDtls.viewContractContactDetails.startDate = contractContact.getDateRange().start();
    viewContractContactDtls.viewContractContactDetails.endDate = contractContact.getDateRange().end();
    viewContractContactDtls.viewContractContactDetails.versionNo = contractContact.getVersionNo();

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      key.concernRoleID);

    for (final ProviderParty providerParty : providerPartyDAO.searchBy(
      providerOrganization)) {

      // BEGIN, CR00272183, SS
      if (RECORDSTATUSEntry.NORMAL.equals(providerParty.getLifecycleState())) {

        final ContractContactDetails contractContactDetails = new ContractContactDetails();

        contractContactDetails.providerPartyID = providerParty.getID();
        contractContactDetails.providerPartyName = providerParty.getParty().getName();

        viewContractContactDtls.contractContactDetailsList.contractContactDetails.addRef(
          contractContactDetails);

      }
      // END, CR00272183
    }

    return viewContractContactDtls;
  }

  /**
   * {@inheritDoc}
   */
  public ContractContactDetailsList listProviderParties(ConcernRoleKey key)
    throws AppException, InformationalException {

    ContractContactDetailsList contractContactDetailsList = new ContractContactDetailsList();

    final ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      key.concernRoleID);

    for (final ProviderParty providerParty : providerPartyDAO.searchBy(
      providerOrganization)) {

      // Only active provider participants or members with no end date or
      // an end
      // date
      // in the future will be available to select as a contact.
      if (providerParty.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)
        && (!providerParty.getDateRange().isEnded()
          || providerParty.getDateRange().endsInFuture())) {

        final ContractContactDetails contractContactDetails = new ContractContactDetails();

        contractContactDetails.providerPartyID = providerParty.getID();
        contractContactDetails.providerPartyName = providerParty.getParty().getName();

        contractContactDetailsList.contractContactDetails.addRef(
          contractContactDetails);

      }
    }

    return contractContactDetailsList;

  }

  // BEGIN, CR00205476, GP
  /**
   * {@inheritDoc}
   */
  public ContractViewDetailsList listProviderContracts(
    final ProviderConcernRoleKey providerKey) throws AppException,
      InformationalException {

    ContractViewDetailsList contractViewDetailsList = new ContractViewDetailsList();

    final Provider provider = providerDAO.get(providerKey.providerConcernRoleID);

    Set<ContractVersion> unModifiableContractVersions = provider.getContracts();
    Set<ContractVersion> unsortedContractVersions = new HashSet<ContractVersion>();

    unsortedContractVersions.addAll(unModifiableContractVersions);

    for (final ContractVersion contractVersion : sortContracts(
      unsortedContractVersions)) {

      // BEGIN, CR00208430, PS
      getContractDetails(contractViewDetailsList, contractVersion);
      // END, CR00208430
    }

    return contractViewDetailsList;
  }

  // END, CR00205476

  // BEGIN, CR00208430, PS
  /**
   * {@inheritDoc}
   */
  public ContractViewDetailsList listProviderGroupContracts(
    final ProviderGroupKey providerGroupKey) throws AppException,
      InformationalException {

    ContractViewDetailsList contractViewDetailsList = new ContractViewDetailsList();

    final curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      providerGroupKey.providerGroupConcernRoleID);

    for (final ContractVersion contractVersion : providerGroup.getContracts()) {

      getContractDetails(contractViewDetailsList, contractVersion);

    }

    return contractViewDetailsList;
  }

  /**
   * Retrieves the contract details for provider/provider group.
   *
   * @param contractViewDetailsList
   * Contract details for a provider/provider group.
   * @param contractVersion
   * Contract version details.
   */
  protected void getContractDetails(
    ContractViewDetailsList contractViewDetailsList,
    final ContractVersion contractVersion) {
    ContractViewDetails contractViewDetails = new ContractViewDetails();

    contractViewDetails.contractVersionID = contractVersion.getID();
    contractViewDetails.contractServicesType = contractVersion.getContractServicesType().getCode();
    contractViewDetails.contractType = contractVersion.getContractType().getCode();

    contractViewDetails.startDate = contractVersion.getDateRange().start();
    contractViewDetails.endDate = contractVersion.getDateRange().end();

    contractViewDetails.versionNo = contractVersion.getVersionNo();
    if (CONTRACTSTATUSEntry.LIVE.equals(contractVersion.getLifecycleState())) {
      contractViewDetails.displayLinkInd = true;
    }

    contractViewDetails.name = contractVersion.getName();

    contractViewDetails.referenceNumber = contractVersion.getCPMContract().getReferenceNumber();

    if (Date.getCurrentDate().after(contractVersion.getDateRange().end())
      && CONTRACTSTATUSEntry.LIVE.equals(contractVersion.getLifecycleState())) {

      contractViewDetails.status = CONTRACTSTATUS.EXPIRED;
    } else {
      contractViewDetails.status = contractVersion.getLifecycleState().getCode();
    }

    // BEGIN, CR00234497, PS
    if (CONTRACTSTATUSEntry.INEDIT.getCode().equals(contractViewDetails.status)) {

      contractViewDetails.inEditIndicator = true;
      contractViewDetails.editIndicator = true;
      contractViewDetails.deleteIndicator = true;
      contractViewDetails.addContactIndicator = true;
      contractViewDetails.addServiceIndicator = true;

    } else if (CONTRACTSTATUSEntry.ISSUED.getCode().equals(
      contractViewDetails.status)) {

      contractViewDetails.issuedIndicator = true;
      contractViewDetails.editIndicator = true;
      contractViewDetails.deleteIndicator = true;
      contractViewDetails.addServiceIndicator = true;
      contractViewDetails.addContactIndicator = true;
      contractViewDetails.previewContractIndicator = true;
      contractViewDetails.printContractIndicator = true;

    } else if (CONTRACTSTATUSEntry.LIVE.getCode().equals(
      contractViewDetails.status)) {

      contractViewDetails.liveIndicator = true;

      if (CONTRACTTYPEEntry.UTILIZATION.getCode().equals(
        contractViewDetails.contractType)) {
        contractViewDetails.amendContractIndicator = true;
      }

      contractViewDetails.previewContractIndicator = true;
      contractViewDetails.printContractIndicator = true;

    } else if (CONTRACTSTATUSEntry.AMENDED.getCode().equals(
      contractViewDetails.status)
        || CONTRACTSTATUSEntry.TERMINATED.getCode().equals(
          contractViewDetails.status)) {

      contractViewDetails.amendOrTerminateIndicator = true;
      contractViewDetails.previewContractIndicator = true;
      contractViewDetails.printContractIndicator = true;
    }
    // END, CR00234497

    if (CONTRACTTYPEEntry.UTILIZATION.getCode().equals(
      contractViewDetails.contractType)) {

      contractViewDetails.utilizatiionContractIndicator = true;
    }

    contractViewDetailsList.contractViewDetails.addRef(contractViewDetails);
  }

  // END, CR00208430
  /**
   * {@inheritDoc}
   */
  public InformationalMsgDtlsList modifyContractProviderOfferings(
    ContractVersionKey contractVersionKey,
    ProviderOfferingTabbedList providerOfferingTabbedList)
    throws AppException, InformationalException {

    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();
    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    // Get the ContractVersion
    ContractVersion contractVersion = contractVersionDAO.get(
      contractVersionKey.contractVersionID);

    // Get the modified Set of ProviderOfferings
    Set<ProviderOffering> newProviderOfferingSet = new HashSet<ProviderOffering>();

    for (final String providerOfferingID : StringUtil.tabText2StringList(providerOfferingTabbedList.tabbedList).items()) {

      newProviderOfferingSet.add(
        providerOfferingDAO.get(Long.parseLong(providerOfferingID)));
    }

    // Delete the ContractVersionProviderOffering for any ProviderOfferings
    // removed from the contract
    for (final ContractVersionProviderOffering contractProviderOfferingLink : contractProviderOfferingLinkDAO.searchBy(
      contractVersion)) {
      if (!newProviderOfferingSet.contains(
        contractProviderOfferingLink.getProviderOffering())) {

        contractProviderOfferingLink.remove();
      }
    }

    // Get the current set of ProviderOfferings for the Contract
    Set<ProviderOffering> currentProviderOfferingSet = new HashSet<ProviderOffering>();

    for (final ContractVersionProviderOffering contractProviderOfferingLink : contractProviderOfferingLinkDAO.searchBy(
      contractVersion)) {

      currentProviderOfferingSet.add(
        contractProviderOfferingLink.getProviderOffering());
    }

    // Create a new ContractVersionProviderOffering for any
    // ProviderOfferings
    // added to the contract
    ContractVersionProviderOffering newContractVersionProviderOffering;

    for (final ProviderOffering providerOffering : newProviderOfferingSet) {
      if (!currentProviderOfferingSet.contains(providerOffering)) {

        newContractVersionProviderOffering = contractProviderOfferingLinkDAO.newInstance();

        newContractVersionProviderOffering.setContractVersion(contractVersion);
        newContractVersionProviderOffering.setProviderOffering(providerOffering);

        if (contractVersion.getContractType().equals(
          CONTRACTTYPEEntry.UTILIZATION)) {

          newContractVersionProviderOffering.createDefaultRate();

        }

        newContractVersionProviderOffering.insert();

        informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

        // Obtain the informational(s) to be returned to the client
        matchedResults = informationalManager.obtainInformationalAsString();

        informationalMsgDtls = new InformationalMsgDtls();

        for (int i = 0; i < matchedResults.length; i++) {

          informationalMsgDtls.informationMsgTxt = matchedResults[i];

          informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);

        }

        TransactionInfo.setInformationalManager();

      }
    }

    return informationalMsgDtlsList;

  }

  /**
   * {@inheritDoc}  
   */
  public ProviderOfferingDetailsList viewProviderOfferingsForProviderGroupContract(
    ProviderContractKey key) throws AppException, InformationalException {

    // Get the ContractVersion
    ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);

    // Set of ProviderOfferings containing services which all Providers on
    // the
    // contract are approved to deliver - a service name can only occur once
    // in
    // this list, e.g. if Provider A and B both have approved
    // ProviderOfferings
    // containing Service C, only one of those ProviderOfferings will be
    // added
    // to the final list

    Set<ProviderOffering> availableProviderOfferingSet = new HashSet<ProviderOffering>();

    // Set of ServiceOfferings offered by all Providers on the contract
    Set<ServiceOffering> serviceOfferingSet = new HashSet<ServiceOffering>();

    // Populate the set of available ProviderOfferings
    for (final ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : contractVersionProviderGroupAssociateDAO.searchBy(
      contractVersion)) {

      // For each ProviderOffering offered by the contracted Provider
      Set<curam.providerservice.impl.ProviderOffering> unModifiableProviderOfferings = contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getProviderOfferings();
      Set<curam.providerservice.impl.ProviderOffering> providerOfferings = new HashSet<curam.providerservice.impl.ProviderOffering>();

      providerOfferings.addAll(unModifiableProviderOfferings);
      for (final ProviderOffering providerOffering : providerOfferings) {

        // If the ProviderOffering is approved, its period covers the
        // period of
        // the contract and the set of ServiceOfferings does not already
        // contain
        // this ProviderOffering's ServiceOffering

        if (providerOffering.getLifecycleState().equals(
          ProviderOfferingStatusEntry.APPROVED)
            && providerOffering.getDateRange().contains(
              contractVersion.getDateRange())
              && (serviceOfferingSet.add(providerOffering.getServiceOffering()))) {

          // If all contracted Providers are approved to offer the
          // ServiceOffering referenced by this ProviderOffering, add
          // it to the
          // set of ProviderOfferings

          if (allContractedProvidersAreApprovedToOfferServiceOffering(
            contractVersion, providerOffering.getServiceOffering())) {

            // BEGIN, CR00115627, GP
            // Only a provider offering for which 'Pay based on
            // Placement' and
            // 'Pay based on attendance' is set to false can be
            // selected for
            // flat
            // rate contract
            // BEGIN, CR00132242, GP
            if (contractVersion.getContractType().equals(
              CONTRACTTYPEEntry.FLATRATE)) {
              if (!providerOffering.getServiceOffering().getPlacementPaymentInd()
                && !providerOffering.getServiceOffering().isPayBasedOnAttendance()) {

                // BEGIN, CR00281035, GYH
                // Only a provider offering for which the service offering
                // delivery
                // type is not of type 'Product Delivery'
                // or 'Product Delivery - PD financials' can be selected for
                // flat rate contract.
                if (!SODELIVERYTYPEEntry.PRODUCTDELIVERY.getCode().equals(
                  providerOffering.getServiceOffering().getDeliveryType().getCode())
                    && !SODELIVERYTYPEEntry.PDWITHINVOICING.getCode().equals(
                      providerOffering.getServiceOffering().getDeliveryType().getCode())) {
                  availableProviderOfferingSet.add(providerOffering);
                }
                // END, CR00281035
              }
            } else {
              availableProviderOfferingSet.add(providerOffering);
            }
            // END, CR00132242
            // END, CR00115627
          }
        }
      }
    }

    // Add each ProviderOffering's ID and service name to the return struct
    ProviderOfferingDetailsList providerOfferingDetailsList = new ProviderOfferingDetailsList();
    ProviderOfferingDetails providerOfferingDetails;
    StringBuffer stringBuffer = new StringBuffer();

    for (final ProviderOffering providerOffering : availableProviderOfferingSet) {

      providerOfferingDetails = new ProviderOfferingDetails();
      providerOfferingDetails.code = providerOffering.getID();
      providerOfferingDetails.description = providerOffering.getServiceOffering().getName();
      providerOfferingDetailsList.providerOfferingDetails.addRef(
        providerOfferingDetails);

      // If this ProviderOffering is already on the contract, add its ID
      // to the
      // tabbed list of ProviderOfferings currently associated with the
      // Contract. A ServiceOffering should only occur once in this list,
      // so
      // only one ProviderOffering will appear for each Service on the
      // contract

      if (providerOfferingIsAlreadyOnContract(providerOffering, contractVersion)) {

        if (stringBuffer.length() > 0) {
          stringBuffer.append(CuramConst.gkTabDelimiterChar);
        }
        stringBuffer.append(providerOffering.getID().toString());
      }
    }

    providerOfferingDetailsList.currentProviderOfferingTabbedList = stringBuffer.toString();

    return providerOfferingDetailsList;
  }

  /**
   * {@inheritDoc}  
   */
  public ContractReturnDocDetails previewContract(ContractVersionKey key)
    throws AppException, InformationalException {

    ContractReturnDocDetails contractReturnDocDetails = new ContractReturnDocDetails();

    final curam.contracts.impl.ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);

    // determine appropriate notification event
    ContractNotificationKey contractNotificationKey = getGenerationNotificationEvent(
      key);

    contractReturnDocDetails = contractVersion.previewContract(
      contractNotificationKey);

    return contractReturnDocDetails;
  }

  /**
   * {@inheritDoc}
   */
  public void printContract(ContractVersionKey key) throws AppException,
      InformationalException {

    final curam.contracts.impl.ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);

    // determine appropriate notification event
    ContractNotificationKey contractNotificationKey = getGenerationNotificationEvent(
      key);

    contractVersion.printContract(contractNotificationKey);

  }

  /**
   * {@inheritDoc}  
   */
  public ViewProviderOfferingDetails viewProviderOfferingByContractVersionProviderOffering(
    ContractPOLinkKey key) throws AppException, InformationalException {

    ViewProviderOfferingDetails viewProviderOfferingDetails = new ViewProviderOfferingDetails();

    // Read the ProviderOffering details
    ContractVersionProviderOffering contractProviderOfferingLink = contractProviderOfferingLinkDAO.get(
      key.contractPOLinkID);

    final ProviderOffering providerOffering = contractProviderOfferingLink.getProviderOffering();

    final ContractVersion contractVersion = contractProviderOfferingLink.getContractVersion();

    viewProviderOfferingDetails.providerOfferingDtls.providerConcernRoleID = providerOffering.getProvider().getID();
    viewProviderOfferingDetails.providerOfferingDtls.startDate = providerOffering.getDateRange().start();
    viewProviderOfferingDetails.providerOfferingDtls.endDate = providerOffering.getDateRange().end();
    viewProviderOfferingDetails.providerOfferingDtls.providerOfferingID = providerOffering.getID();
    viewProviderOfferingDetails.providerOfferingDtls.endReason = providerOffering.getEndReason().getCode();
    viewProviderOfferingDetails.providerOfferingDtls.denialReason = providerOffering.getDenialReason().getCode();
    viewProviderOfferingDetails.providerOfferingDtls.comments = providerOffering.getComments();

    viewProviderOfferingDetails.providerOfferingDtls.recordStatus = providerOffering.getLifecycleState().getCode();

    viewProviderOfferingDetails.providerOfferingDtls.versionNo = providerOffering.getVersionNo();

    // Read the Service name and ID
    ServiceOffering serviceOffering = providerOffering.getServiceOffering();

    viewProviderOfferingDetails.providerOfferingDtls.serviceOfferingID = serviceOffering.getID();
    viewProviderOfferingDetails.serviceOfferingName = serviceOffering.getName();

    for (final ProviderOfferingRate providerOfferingRate : sortProviderOfferingRates(
      providerOfferingRateDAO.searchBy(providerOffering, contractVersion))) {

      // If the rate's date range overlaps the contract's date range, add
      // it to
      // the list
      if (providerOfferingRate.getDateRange().overlapsWith(
        contractVersion.getDateRange())) {

        viewProviderOfferingDetails.providerOfferingRateDetailsList.addRef(
          getProviderOfferingRateFieldsForList(providerOfferingRate));
      }
    }

    for (final ProviderOfferingPlaceLimit providerOfferingPlaceLimit : sortProviderOfferingPlaceLimit(
      providerOfferingPlaceLimitDAO.searchBy(providerOffering, contractVersion))) {
      viewProviderOfferingDetails.providerOfferingPlaceLimitDtlsList.addRef(
        getProviderOfferingPlaceLimitFields(providerOfferingPlaceLimit));
    }

    return viewProviderOfferingDetails;
  }

  /**
   * {@inheritDoc}  
   */
  public void deleteProviderOfferingFromContract(final ContractPOLinkKey key)
    throws AppException, InformationalException {

    // Get the ContractVersionProviderOffering
    ContractVersionProviderOffering contractProviderOfferingLink = contractProviderOfferingLinkDAO.get(
      key.contractPOLinkID);

    // BEGIN CR00100121,SK
    ContractVersion contract = contractProviderOfferingLink.getContractVersion();

    // if the contract is flat-rate contract for a provider group
    if (contract.getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDERGROUP)
        && contract.getContractType().equals(CONTRACTTYPEEntry.FLATRATE)) {

      // get the service
      ServiceOffering serviceOffering = contractProviderOfferingLink.getProviderOffering().getServiceOffering();

      // For each of the contract's ContractVersionProviderOfferings
      for (ContractVersionProviderOffering link : contractProviderOfferingLinkDAO.searchBy(
        contract)) {

        // If the ContractVersionProviderOffering's ServiceOffering is
        // the same
        // as
        // the ServiceOffering to be removed from the contract
        if (link.getProviderOffering().getServiceOffering().equals(
          serviceOffering)) {
          // Delete the ContractVersionProviderOffering
          link.remove();
        }
      }

      // if the contract is for a provider
    } else {
      // END CR00100121
      // Remove any contracted ProviderOfferingRates
      for (ProviderOfferingRate rate : providerOfferingRateDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion())) {

        rate.remove(rate.getVersionNo());
      }

      // Remove any ProviderOfferingPlaceLimits associated with the
      // ProviderOffering if they were created through the contract
      for (ProviderOfferingPlaceLimit placeLimit : providerOfferingPlaceLimitDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering())) {

        // If the ProviderOfferingPlaceLimit was created through this
        // contract
        if (contractProviderOfferingLink.getContractVersion().equals(
          placeLimit.getContractVersion())) {

          placeLimit.remove(placeLimit.getVersionNo());
        }
      }

      // Delete the ContractVersionProviderOffering
      contractProviderOfferingLink.remove();
    }
  }

  // BEGIN, CR00234487, GP
  /**
   * Retrieves a list of contract status history details.
   *
   * @param ContractVersionKey
   * Contract for which status history details have to be retrieved.
   *
   * @return List of contract status history.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ContractStatusHistoryDetailsList listContractStatusHistoryDetails(
    final ContractVersionKey ContractVersionKey) throws AppException,
      InformationalException {

    ContractStatusHistoryDetailsList contractStatusHistoryDetailsList = new ContractStatusHistoryDetailsList();

    final ContractVersion contract = contractVersionDAO.get(
      ContractVersionKey.contractVersionID);

    List<ContractStatusHistory> unModifiableContractStatusHistories = contract.getStatusHistory();
    List<ContractStatusHistory> unsortedContractStatusHistories = new ArrayList<ContractStatusHistory>();

    unsortedContractStatusHistories.addAll(unModifiableContractStatusHistories);

    for (final ContractStatusHistory contractStatusHistory : sortLicenses(
      unsortedContractStatusHistories)) {

      ContractStatusHistoryDetails contractStatusHistoryDetails = new ContractStatusHistoryDetails();

      contractStatusHistoryDetails.contractStatusHistoryID = contractStatusHistory.getID();
      contractStatusHistoryDetails.contractVersionID = ContractVersionKey.contractVersionID;
      contractStatusHistoryDetails.lastModifiedBy = contractStatusHistory.getLastModifiedBy();

      User user = userDAO.get(contractStatusHistory.getLastModifiedBy());

      contractStatusHistoryDetails.lastModifiedByFullName = user.getFullName();

      contractStatusHistoryDetails.status = contractStatusHistory.getStatus().getCode();
      contractStatusHistoryDetails.statusDate = contractStatusHistory.getEventDateTime();

      if (CONTRACTSTATUSEntry.TERMINATED.equals(
        contractStatusHistory.getStatus())) {

        contractStatusHistoryDetails.reason = contractStatusHistory.getContractVersion().getTerminationReason().getCode();
      }

      if (CONTRACTSTATUSEntry.ISSUED.equals(contractStatusHistory.getStatus())) {

        contractStatusHistoryDetails.reason = contractStatusHistory.getStatusHistoryGenerationReason().getCode();
      }

      contractStatusHistoryDetailsList.contractStatusHistiryDetails.addRef(
        contractStatusHistoryDetails);
    }

    return contractStatusHistoryDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ContractOwnerDetails getContractOwnerDetails(
    final ContractVersionKey contractVersionKey) throws AppException,
      InformationalException {

    ContractOwnerDetails contractOwnerDetails = new ContractOwnerDetails();

    ContractVersion contractVersion = contractVersionDAO.get(
      contractVersionKey.contractVersionID);

    contractOwnerDetails.contractVersionID = contractVersionKey.contractVersionID;
    contractOwnerDetails.createdBy = contractVersion.getCreatedBy();
    User user = userDAO.get(contractVersion.getCreatedBy());

    contractOwnerDetails.createdByFullName = user.getFullName();

    return contractOwnerDetails;
  }

  // END, CR00234487

  /**
   * Sorts a set of provider offering rates into a sorted list for display.
   *
   * @param unsortedProviderOfferingRates
   * The list with the unsorted provider offering rates.
   *
   * @return A sorted list of provider offerings for display.
   */
  // BEGIN, CR00177214, PM
  protected List<curam.providerservice.impl.ProviderOfferingRate> sortProviderOfferingRates(
    // END, CR00177214
    final Set<curam.providerservice.impl.ProviderOfferingRate> unsortedProviderOfferingRates) {

    // Sort by Start Date descending order for display - using a list
    // (instead
    // of a set)

    final List<curam.providerservice.impl.ProviderOfferingRate> providerOfferingRates = new ArrayList<curam.providerservice.impl.ProviderOfferingRate>(
      unsortedProviderOfferingRates);

    Collections.sort(providerOfferingRates,
      new Comparator<curam.providerservice.impl.ProviderOfferingRate>() {
      public int compare(
        final curam.providerservice.impl.ProviderOfferingRate lhs,
        curam.providerservice.impl.ProviderOfferingRate rhs) {
        return rhs.getDateRange().start().compareTo(lhs.getDateRange().start());
      }
    });
    return providerOfferingRates;

  }

  /**
   * Returns a {@linkplain ProviderOfferingRateDetails} for a given
   * {@linkplain curam.providerservice.impl.ProviderOfferingRate provider
   * offering rate}.
   *
   * @param providerOfferingRateDetails
   * The provider offering date details.
   *
   * @return Provider offering rate.
   */
  // BEGIN, CR00177214, PM
  protected ProviderOfferingRateDetails getProviderOfferingRateFieldsForList(
    // END, CR00177214
    final curam.providerservice.impl.ProviderOfferingRate providerOfferingRate) {

    final ProviderOfferingRateDetails providerOfferingRateDetails = new ProviderOfferingRateDetails();

    providerOfferingRateDetails.providerOfferingRateID = providerOfferingRate.getID();
    providerOfferingRateDetails.startDate = providerOfferingRate.getDateRange().start();
    providerOfferingRateDetails.endDate = providerOfferingRate.getDateRange().end();
    providerOfferingRateDetails.versionNo = providerOfferingRate.getVersionNo();

    if (providerOfferingRate.getMinAmount().isNegative()) {
      providerOfferingRateDetails.minAmountString = "";
    } else {
      providerOfferingRateDetails.minAmountString = providerOfferingRate.getMinAmount().toString();
    }

    if (providerOfferingRate.getMaxAmount().isNegative()) {
      providerOfferingRateDetails.maxAmountString = "";
    } else {
      providerOfferingRateDetails.maxAmountString = providerOfferingRate.getMaxAmount().toString();
    }

    if (providerOfferingRate.getFixedAmount().isNegative()) {
      providerOfferingRateDetails.fixedAmountString = "";
    } else {
      providerOfferingRateDetails.fixedAmountString = providerOfferingRate.getFixedAmount().toString();
    }

    return providerOfferingRateDetails;
  }

  /**
   * Sorts a set of provider offering place limits into a sorted list for
   * display.
   *
   * @param unsortedProviderOfferingPlaceLimits
   * The set of provider offering place limits.
   *
   * @return A sorted list of provider offering place limits for display.
   */
  // BEGIN, CR00177214, PM
  protected List<ProviderOfferingPlaceLimit> sortProviderOfferingPlaceLimit(
    // CR00177214
    final Set<ProviderOfferingPlaceLimit> unsortedProviderOfferingPlaceLimits) {

    // Sort by Start Date descending order for display - using a list
    // (instead
    // of a set)
    final List<ProviderOfferingPlaceLimit> providerOfferingPlaceLimits = new ArrayList<ProviderOfferingPlaceLimit>(
      unsortedProviderOfferingPlaceLimits);

    Collections.sort(providerOfferingPlaceLimits,
      new Comparator<ProviderOfferingPlaceLimit>() {
      public int compare(final ProviderOfferingPlaceLimit lhs,
        ProviderOfferingPlaceLimit rhs) {
        return rhs.getDateRange().start().compareTo(lhs.getDateRange().start());
      }
    });
    return providerOfferingPlaceLimits;
  }

  /**
   * Maps the fields on the service layer to those presented to the user on the
   * screen.
   *
   * @param providerOfferingPlaceLimit
   * The service layer object from which the user-displayable fields.
   * must be mapped.
   *
   * @return The dtls struct containing the fields for display.
   */
  // BEGIN, CR00177214, PM
  protected ProviderOfferingPlaceLimitDtls getProviderOfferingPlaceLimitFields(
    // END, CR00177214
    final curam.providerservice.impl.ProviderOfferingPlaceLimit providerOfferingPlaceLimit) {
    final ProviderOfferingPlaceLimitDtls providerOfferingPlaceLimitDtls = new ProviderOfferingPlaceLimitDtls();

    providerOfferingPlaceLimitDtls.providerOfferingPlaceLimitID = providerOfferingPlaceLimit.getID();
    providerOfferingPlaceLimitDtls.providerOfferingID = providerOfferingPlaceLimit.getProviderOffering().getID();
    providerOfferingPlaceLimitDtls.startDate = providerOfferingPlaceLimit.getDateRange().start();
    providerOfferingPlaceLimitDtls.endDate = providerOfferingPlaceLimit.getDateRange().end();
    providerOfferingPlaceLimitDtls.placeLimit = providerOfferingPlaceLimit.getPlaceLimit();
    providerOfferingPlaceLimitDtls.recordStatus = providerOfferingPlaceLimit.getLifecycleState().getCode();
    providerOfferingPlaceLimitDtls.versionNo = providerOfferingPlaceLimit.getVersionNo();

    return providerOfferingPlaceLimitDtls;
  }

  /**
   * {@inheritDoc}
   */
  public ViewRenewContractDetails viewRenewContractDetails(
    ContractVersionKey key) throws AppException, InformationalException {

    ViewRenewContractDetails viewRenewContractDetails = new ViewRenewContractDetails();

    ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);

    viewRenewContractDetails.startDate = contractVersion.getDateRange().end().addDays(
      1);

    return viewRenewContractDetails;
  }

  /**
   * Sorts a set of {@linkplain curam.contracts.impl.ContractStatusHistory}
   * records by date.
   *
   * @param unsortedContractStatusHistories
   * The set of Contract Status History records.
   *
   * @return A sorted list of Contract Status History records for display.
   */
  // BEGIN, CR00177214, PM
  protected List<curam.contracts.impl.ContractStatusHistory> sortLicenses(
    // END, CR00177214
    final List<curam.contracts.impl.ContractStatusHistory> unsortedContractStatusHistories) {

    // Sort by date (newest first)

    Collections.sort(unsortedContractStatusHistories,
      new Comparator<ContractStatusHistory>() {
      public int compare(final ContractStatusHistory lhs,
        ContractStatusHistory rhs) {
        return rhs.getEventDateTime().compareTo(lhs.getEventDateTime());
      }
    });

    return unsortedContractStatusHistories;
  }

  /**
   * @param contractVersion
   * Contains the contract version.
   * @param serviceOffering
   * Contains the service offering details.
   *
   * @return True if all {@link curam.provider.impl.Provider}s associated with
   * the {@link curam.contracts.impl.ContractVersion} are approved to
   * offer the specified
   * {@link curam.serviceoffering.impl.ServiceOffering}.
   */
  // BEGIN, CR00177214, PM
  protected boolean allContractedProvidersAreApprovedToOfferServiceOffering(
    // END, CR00177214
    final ContractVersion contractVersion,
    final ServiceOffering serviceOffering) {

    // Set of Providers associated with the contract
    Set<ContractVersionProviderGroupAssociate> contractedProviders = contractVersionProviderGroupAssociateDAO.searchBy(
      contractVersion);

    // Set of contracted Providers who are approved to offer the specified
    // ServiceOffering

    Set<ContractVersionProviderGroupAssociate> approvedProviders = new HashSet<ContractVersionProviderGroupAssociate>();

    // For each Provider in the set of contracted Providers
    for (final ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : contractedProviders) {

      // For each of the Provider's ProviderOfferings
      for (ProviderOffering providerOffering : contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getProviderOfferings()) {

        // If the ProviderOffering is for the specified ServiceOffering,
        // and the
        // ProviderOffering is approved

        if (providerOffering.getLifecycleState().equals(
          ProviderOfferingStatusEntry.APPROVED)
            && providerOffering.getServiceOffering().equals(serviceOffering)) {

          // The Provider is approved to offer the service, add it to
          // the set of
          // approved Providers

          approvedProviders.add(contractVersionProviderGroupAssociate);
          break;
        }
      }
    }

    return approvedProviders.containsAll(contractedProviders);
  }

  /**
   * Returns the contract start and end date so the provider offering place
   * limit page defaults to those dates.
   *
   * @param key
   * Contains the contract version id.
   *
   * @return Start and end date of the contract.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PlaceLimitContractDetails viewPlaceLimitContractDetails(
    ContractVersionKey key) throws AppException, InformationalException {

    // return struct
    PlaceLimitContractDetails placeLimitContractDetails = new PlaceLimitContractDetails();

    final curam.contracts.impl.ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);

    placeLimitContractDetails.startDate = contractVersion.getDateRange().start();
    placeLimitContractDetails.endDate = contractVersion.getDateRange().end();

    return placeLimitContractDetails;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderOfferingPlaceLimitInformationalDtls addContractedPlaceLimitForProvider(
    ContractedPlaceLimitDetails details,
    ContractPOLinkKey contractProviderOfferingLinkKey) throws AppException,
      InformationalException {

    // Return struct
    ProviderOfferingPlaceLimitInformationalDtls providerOfferingPlaceLimitInformationalDtls = new ProviderOfferingPlaceLimitInformationalDtls();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    ProviderOfferingPlaceLimit providerOfferingPlaceLimit = providerOfferingPlaceLimitDAO.newInstance();

    ContractVersionProviderOffering contractProviderOfferingLink = contractProviderOfferingLinkDAO.get(
      contractProviderOfferingLinkKey.contractPOLinkID);

    ContractVersion contractVersion = contractProviderOfferingLink.getContractVersion();

    if (contractVersion.getContractType().equals(CONTRACTTYPEEntry.UTILIZATION)) {

      UtilizationContract utilizationContract = (UtilizationContract) contractVersion;

      utilizationContract.reEdit(utilizationContract.getVersionNo());
    } else if (contractVersion.getContractType().equals(
      CONTRACTTYPEEntry.FLATRATE)) {

      curam.contracts.impl.FlatRateContract flatRateContract = (curam.contracts.impl.FlatRateContract) contractVersion;

      flatRateContract.reEdit(flatRateContract.getVersionNo());

    }

    ProviderOffering providerOffering = contractProviderOfferingLink.getProviderOffering();

    providerOfferingPlaceLimit.setPlaceLimit(details.placeLimit);
    providerOfferingPlaceLimit.setProviderOffering(providerOffering);
    providerOfferingPlaceLimit.setContract(contractVersion);
    // BEGIN, CR00090012, CPD
    providerOfferingPlaceLimit.setDateRangeForContractPlaceLimit(
      new DateRange(details.startDate, details.endDate));
    // END, CR00090012
    providerOfferingPlaceLimit.setComments(details.comments);

    providerOfferingPlaceLimit.insert();

    contractVersion.validateContractedProviderOfferingPlaceLimits();

    providerOfferingPlaceLimitInformationalDtls.providerOfferingPlaceLimitKey.providerOfferingPlaceLimitID = providerOfferingPlaceLimit.getID();

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      providerOfferingPlaceLimitInformationalDtls.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    return providerOfferingPlaceLimitInformationalDtls;
  }

  /**
   * {@inheritDoc}
   */
  public InformationalMsgDtlsList modifyContractProviderOfferingsForProviderGroupContract(
    ContractVersionKey contractVersionKey,
    ProviderOfferingTabbedList providerOfferingTabbedList)
    throws AppException, InformationalException {

    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Get the ContractVersion
    ContractVersion contractVersion = contractVersionDAO.get(
      contractVersionKey.contractVersionID);

    // Get the modified Set of ProviderOfferings
    Set<ProviderOffering> newProviderOfferingSet = new HashSet<ProviderOffering>();

    // BEGIN, CR00090007, GP

    final String[] providerOfferings = StringUtil.tabText2StringList(providerOfferingTabbedList.tabbedList).items();

    // If no Providers were added to the contract
    if (providerOfferings.length == 0) {

      // Raise informational message
      AppException appException = CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_NO_SERVICES();

      informationalManager.addInformationalMsg(appException,
        curam.core.impl.CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning);
    }

    for (final String providerOfferingID : providerOfferings) {

      // END, CR00090007

      newProviderOfferingSet.add(
        providerOfferingDAO.get(Long.parseLong(providerOfferingID)));
    }

    // Get the modified Set of ServiceOfferings
    Set<ServiceOffering> newServiceOfferingSet = new HashSet<ServiceOffering>();

    for (final ProviderOffering providerOffering : newProviderOfferingSet) {

      newServiceOfferingSet.add(providerOffering.getServiceOffering());
    }

    // Delete all existing ContractVersionProviderOfferings containing any
    // ServiceOfferings removed from the contract

    for (ContractVersionProviderOffering contractProviderOfferingLink : contractProviderOfferingLinkDAO.searchBy(
      contractVersion)) {
      if (!newServiceOfferingSet.contains(
        contractProviderOfferingLink.getProviderOffering().getServiceOffering())) {

        contractProviderOfferingLink.remove();
      }
    }

    // Get the current set of ServiceOfferings for the Contract
    Set<ServiceOffering> currentServiceOfferingSet = new HashSet<ServiceOffering>();

    for (final ContractVersionProviderOffering contractProviderOfferingLink : contractProviderOfferingLinkDAO.searchBy(
      contractVersion)) {

      currentServiceOfferingSet.add(
        contractProviderOfferingLink.getProviderOffering().getServiceOffering());
    }

    // For each Provider on the contract, create a new
    // ContractVersionProviderOffering for any new ServiceOfferings added to
    // the
    // contract.

    ContractVersionProviderOffering newContractVersionProviderOffering;
    ProviderOffering providerProviderOffering;

    for (final ProviderOffering providerOffering : newProviderOfferingSet) {
      // If all providers on the contract are approved to offer the
      // service
      if (!currentServiceOfferingSet.contains(
        providerOffering.getServiceOffering())
          && allContractedProvidersAreApprovedToOfferServiceOffering(
            contractVersion, providerOffering.getServiceOffering())) {

        for (final Provider provider : contractVersion.getProviders()) {

          newContractVersionProviderOffering = contractProviderOfferingLinkDAO.newInstance();

          newContractVersionProviderOffering.setContractVersion(contractVersion);

          // Get the ProviderOffering which covers this Provider and
          // Service
          providerProviderOffering = getProviderOffering(provider,
            providerOffering.getServiceOffering());

          newContractVersionProviderOffering.setProviderOffering(
            providerProviderOffering);
          // BEGIN CR00096311, SK
          if (contractVersion.getContractType().equals(
            CONTRACTTYPEEntry.UTILIZATION)) {
            newContractVersionProviderOffering.createDefaultRate();
          }
          // END CR00096311
          newContractVersionProviderOffering.insert();

          // BEGIN, CR00090007, GP
        }
      }
    }

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

    for (int i = 0; i < matchedResults.length; i++) {

      informationalMsgDtls.informationMsgTxt = matchedResults[i];

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);

    }

    // END, CR00090007

    return informationalMsgDtlsList;

  }

  /**
   * Returns the provider offering.
   *
   * @param provider
   * Contains the provider information.
   *
   * @return The ProviderOffering for the specified Provider and
   * ServiceOffering, or null if not found.
   *
   * @see curam.provider.Provider
   */
  // BEGIN, CR00177214, PM
  protected ProviderOffering getProviderOffering(final Provider provider,
    // END, CR00177214
    final ServiceOffering serviceOffering) {

    ProviderOffering returnProviderOffering = null;

    for (final ProviderOffering providerOffering : providerOfferingDAO.searchBy(
      provider)) {

      if (providerOffering.getServiceOffering().equals(serviceOffering)) {

        returnProviderOffering = providerOffering;
        break;
      }
    }

    return returnProviderOffering;
  }

  /**
   * Read contract provider date range for a Contract Provider Offering Link.
   *
   * @param key
   * Contains the contact provider offering link id.
   *
   * @return Contract start/end date.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PlaceLimitContractDetails readContractDateRangeByContractProviderOfferingLink(
    ContractPOLinkKey key) throws InformationalException {

    PlaceLimitContractDetails placeLimitContractDetails = new PlaceLimitContractDetails();

    final ContractVersionProviderOffering contractProviderOfferingLink = contractProviderOfferingLinkDAO.get(
      key.contractPOLinkID);

    final curam.contracts.impl.ContractVersion contractVersion = contractProviderOfferingLink.getContractVersion();

    placeLimitContractDetails.startDate = contractVersion.getDateRange().start();
    placeLimitContractDetails.endDate = contractVersion.getDateRange().end();

    return placeLimitContractDetails;
  }

  /**
   * Checks if a provider offering is already on contract.
   *
   * @param providerOffering
   * Contains provider offering details.
   * @param contractVersion
   * Contains Contract version details.
   *
   * @return True if a ContractVersionProviderOffering exists for the specified
   * ProviderOffering and ContractVersion.
   */
  // BEGIN, CR00177214, PM
  protected boolean providerOfferingIsAlreadyOnContract(
    // END, CR00177214
    ProviderOffering providerOffering, ContractVersion contractVersion) {

    for (final ContractVersionProviderOffering link : contractProviderOfferingLinkDAO.searchBy(
      contractVersion)) {
      if (link.getProviderOffering().equals(providerOffering)) {
        return true;
      }
    }
    return false;
  }

  // BEGIN CR00096014, MST
  /**
   * {@inheritDoc}
   */
  public AttachmentLinkKey createContractAttachment(
    AttachmentLinkDetails attachmentLinkDetails) throws AppException,
      InformationalException {

    AttachmentLinkKey attachmentLinkKey = new AttachmentLinkKey();

    AttachmentLink attachmentLink = attachmentLinkDAO.newInstance();

    attachmentLinkDetails.attachmentLinkDtls.relatedObjectType = ATTACHMENTOBJECTLINKTYPE.CONTRACT;
    attachmentLinkDetails.attachmentLinkDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;

    attachmentLinkKey.attachmentLinkID = attachmentLink.insert(
      attachmentLinkDetails);

    return attachmentLinkKey;
  }

  /**
   * {@inheritDoc}
   */
  public ListAttachmentLinkDetails listContractAttachment(
    ContractVersionKey contractVersionKey) throws AppException,
      InformationalException {

    ListAttachmentLinkDetails listAttachmentLinkDetails = new ListAttachmentLinkDetails();

    List<AttachmentLink> attachmentLinks = attachmentLinkDAO.searchByRelatedIDAndType(
      contractVersionKey.contractVersionID,
      ATTACHMENTOBJECTLINKTYPEEntry.CONTRACT);

    // Loop through all the attachment link object and populate the values
    // to
    // facade struct.
    for (curam.attachmentlink.impl.AttachmentLink attachmentLink : attachmentLinks) {

      AttachmentLinkDetails attachmentLinkDetails = populateAttachmentLinkDetails(
        attachmentLink);

      listAttachmentLinkDetails.attachmentLinkDetails.addRef(
        attachmentLinkDetails);
    }

    return listAttachmentLinkDetails;
  }

  /**
   * Populates the attachment and attachment link details from the entity struct
   * to facade struct for display.
   *
   * @param attachmentLink
   * An attachmentLink object.
   *
   * @return Attachment link details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected AttachmentLinkDetails populateAttachmentLinkDetails(
    curam.attachmentlink.impl.AttachmentLink attachmentLink)
    throws AppException, InformationalException {

    AttachmentLinkDetails attachmentLinkDetails = new AttachmentLinkDetails();
    AttachmentKey attachmentKey = new AttachmentKey();
    curam.attachmentlink.struct.AttachmentLinkDetails attachmentDetails = new curam.attachmentlink.struct.AttachmentLinkDetails();

    attachmentKey.attachmentID = attachmentLink.getAttachmentID();
    attachmentDetails.attachmentDtls = attachmentObj.read(attachmentKey);

    attachmentLinkDetails.attachmentLinkDtls.attachmentLinkID = attachmentLink.getID();
    attachmentLinkDetails.attachmentLinkDtls.description = attachmentLink.getDescription();
    attachmentLinkDetails.attachmentLinkDtls.versionNo = attachmentLink.getVersionNo();
    attachmentLinkDetails.attachmentLinkDtls.recordStatus = attachmentLink.getLifecycleState().getCode();
    attachmentLinkDetails.attachmentLinkDtls.sensitivityCode = attachmentLink.getSensitivityCode().getCode();
    attachmentLinkDetails.attachmentLinkDtls.creatorUserName = attachmentLink.getCreator();
    attachmentLinkDetails.attachmentDtls.assign(
      attachmentDetails.attachmentDtls);

    return attachmentLinkDetails;
  }

  // END CR00096014

  // BEGIN, CR00120238, NK
  // BEGIN, CR00313834, GA
  /**
   * Lists the Provider Offerings for a Provider for Utilization Contract.
   *
   * @param key
   * The unique identifier for a provider.
   *
   * @return Provider offering contract details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0.3.0, replaced by {@link ContractManagement#listProviderServicesAndContactsForUtilizationContract()}.
   * This method is deprecated because the name of the method does not match its functionality and conveys a wrong meaning. It
   * returns a list of provider services and contracts, but the method name is listProviderOfferingsForUtilizationContract(). See release note : CR00313834.
   */
  @Deprecated
  // END, CR00313834
  public ProviderOfferingContactsList listProviderOfferingsForUtilizationContract(
    ProviderKey key) throws AppException, InformationalException {

    ProviderOfferingContactsList providerOfferingContactsList = new ProviderOfferingContactsList();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    final curam.provider.impl.Provider provider = providerDAO.get(
      key.providerConcernRoleID);

    for (final ProviderOffering providerOffering : providerOfferingDAO.searchBy(
      provider)) {

      if (providerOffering.getLifecycleState().getCode().equals(
        ProviderOfferingStatus.APPROVED)
          && !providerOffering.getDateRange().endsInPast()) {

        final ProviderOfferingDetails providerOfferingDetails = new ProviderOfferingDetails();

        // retrieve matching Service Offering name
        providerOfferingDetails.description = providerOffering.getServiceOffering().getName();
        providerOfferingDetails.code = providerOffering.getID();

        providerOfferingContactsList.providerOfferingDetailsList.providerOfferingDetails.addRef(
          providerOfferingDetails);
      }
    }

    concernRoleKey.concernRoleID = provider.getID();

    providerOfferingContactsList.contractContactDetailsList = listProviderParties(
      concernRoleKey);

    return providerOfferingContactsList;
  }

  // BEGIN, CR00313834, GA
  /**
   * {@inheritDoc}
   */
  public ProviderOfferingContactsList listProviderServicesAndContactsForUtilizationContract(
    final ProviderKey key) throws AppException, InformationalException {

    final ProviderOfferingContactsList providerOfferingContactsList = new ProviderOfferingContactsList();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    final curam.provider.impl.Provider provider = providerDAO.get(
      key.providerConcernRoleID);

    for (final ProviderOffering providerOffering : providerOfferingDAO.searchBy(
      provider)) {

      if (providerOffering.getLifecycleState().getCode().equals(
        ProviderOfferingStatus.APPROVED)
          && !providerOffering.getDateRange().endsInPast()) {

        final ProviderOfferingDetails providerOfferingDetails = new ProviderOfferingDetails();

        // Retrieve matching Service Offering name.
        providerOfferingDetails.description = providerOffering.getServiceOffering().getName();
        providerOfferingDetails.code = providerOffering.getID();

        providerOfferingContactsList.providerOfferingDetailsList.providerOfferingDetails.addRef(
          providerOfferingDetails);
      }
    }

    concernRoleKey.concernRoleID = provider.getID();

    providerOfferingContactsList.contractContactDetailsList = listProviderParties(
      concernRoleKey);

    return providerOfferingContactsList;
  }

  // END, CR00313834
  
  // END CR00120238

  // BEGIN, CR00205476, GP
  /**
   * Sorts a set of contract versions by start date.
   *
   * @param unsortedContracts
   * The set of unsorted contracts.
   *
   * @return Sorted list of contracts for display.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected List<ContractVersion> sortContracts(
    final Set<ContractVersion> unsortedContracts) {

    final List<ContractVersion> contractVersions = new ArrayList<ContractVersion>(
      unsortedContracts);

    Collections.sort(contractVersions,
      new Comparator<ContractVersion>() {
      public int compare(final ContractVersion rhs, ContractVersion lhs) {
        return lhs.getDateRange().start().compareTo(rhs.getDateRange().start());
      }
    });

    return contractVersions;
  }
  // END, CR00205476
}
