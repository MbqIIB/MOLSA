/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import com.google.inject.Inject;

import curam.codetable.EXTERNALUSERSPARTRELTYPE;
import curam.core.sl.entity.fact.ExternalUserFactory;
import curam.core.sl.entity.intf.ExternalUser;
import curam.core.sl.entity.struct.ExternalUserKey;
import curam.core.sl.entity.struct.ExternalUserParticipantLinkDetails;
import curam.core.sl.fact.ExternalUserParticipantLinkFactory;
import curam.core.sl.intf.ExternalUserParticipantLink;
import curam.core.sl.struct.ExternalUserParticipantLinkDetailsList;
import curam.cpm.eua.facade.struct.ExternalParticipantIDAppCode;
import curam.cpm.sl.entity.struct.SearchRefNumDetails;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.ProviderMember;
import curam.provider.impl.ProviderMemberDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;


/**
 * This process class provides the functionality for retrieving
 * information on an External logged in user. This external user
 * must also be a registered Concern.
 */
public abstract class ExternalParticipant extends curam.cpm.eua.facade.base.ExternalParticipant {
  
  /*
   * Inject concernRoleDAO
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;
  
  /*
   * Inject providerMemberDAO
   */
  @Inject 
  protected ProviderMemberDAO providerMemberDAO;

  /**
   * Constructor
   */
  public ExternalParticipant() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  // ___________________________________________________________________________
  /**
   * This method is called from the client to determine the concern role
   * details of the logged in external user.
   *
   * @return Contains the concern Role ID, type and application code
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ExternalParticipantIDAppCode readParticipantIDAppCodeByExternalUser()
    throws AppException, InformationalException {
    
    // result struct
    ExternalParticipantIDAppCode externalParticipantDetails = new ExternalParticipantIDAppCode();
    
    ExternalUser externalUserObj = ExternalUserFactory.newInstance();

    ExternalUserKey externalUserKey = new ExternalUserKey();
    
    // get the user name
    externalUserKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();
    
    // Begin CR00096779, ABS
    // set the application code
    externalParticipantDetails.applicationCode = externalUserObj.read(externalUserKey).applicationCode;
    // End CR00096779
    
    // get all linked participant details for the userName
    ExternalUserParticipantLink adminExternalUserParticipantLink = ExternalUserParticipantLinkFactory.newInstance();
    
    curam.core.sl.struct.ExternalUserKey externalUserCoreKey = new curam.core.sl.struct.ExternalUserKey();
    
    // set the key 
    externalUserCoreKey.userKey.userName = externalUserKey.userName;
    
    ExternalUserParticipantLinkDetailsList externalUserParticipantLinkDetailsList = adminExternalUserParticipantLink.searchLinkByUsername(
      externalUserCoreKey);

    // find which record is an alias for the user
    int numRecords = externalUserParticipantLinkDetailsList.details.dtls.size();

    for (int i = 0; i < numRecords; i++) {
      ExternalUserParticipantLinkDetails currentRecord = externalUserParticipantLinkDetailsList.details.dtls.item(
        i);
       
      // only Provider, Provider Group, Provider/Provider Group Member are valid
      if (currentRecord.externalUserParticipantLinkDtls.extUserPartRelType.equals(
        EXTERNALUSERSPARTRELTYPE.PROVIDER)
          || currentRecord.externalUserParticipantLinkDtls.extUserPartRelType.equals(
            EXTERNALUSERSPARTRELTYPE.PROVIDERGROUP)
            || currentRecord.externalUserParticipantLinkDtls.extUserPartRelType.equals(
              EXTERNALUSERSPARTRELTYPE.PROVIDERMEMBEROF)) {
  
        externalParticipantDetails.participantRoleID = currentRecord.externalUserParticipantLinkDtls.participantRoleID;
        break;
      }
    }
    
    // return the concernRoleType.
    ConcernRole concernRole = concernRoleDAO.get(
      externalParticipantDetails.participantRoleID);
    
    externalParticipantDetails.concernRoleType = concernRole.getConcernRoleType().getCode();

    return externalParticipantDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method determines the concern Role ID of the provider or provider
   * group. This is based on the logged in user. If the logged in user
   * is a provider member or provider group member, then this method 
   * determines the provider or provider group concern role id to whom
   * the member belongs.
   *
   * @return This contains the provider or provider group concern Role ID
   * and the concern role type
   * @throws InformationalException
   * @throws AppException
   */
  public ExternalParticipantIDAppCode readProviderProviderGroupID()
    throws AppException, InformationalException {
    // result struct
    ExternalParticipantIDAppCode externalParticipantDetails = new ExternalParticipantIDAppCode();
    
    ExternalUser externalUserObj = ExternalUserFactory.newInstance();

    ExternalUserKey externalUserKey = new ExternalUserKey();
    
    // get the user name
    externalUserKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // set the application code
    // Begin CR00096779, ABS
    externalParticipantDetails.applicationCode = externalUserObj.read(externalUserKey).applicationCode;
    // End CR00096779
    
    // get all linked participant details for the userName
    ExternalUserParticipantLink adminExternalUserParticipantLink = ExternalUserParticipantLinkFactory.newInstance();
    
    curam.core.sl.struct.ExternalUserKey externalUserCoreKey = new curam.core.sl.struct.ExternalUserKey();
    
    // set the key 
    externalUserCoreKey.userKey.userName = externalUserKey.userName;
    
    // get the participant link details
    ExternalUserParticipantLinkDetailsList externalUserParticipantLinkDetailsList = adminExternalUserParticipantLink.searchLinkByUsername(
      externalUserCoreKey);

    // find which record is an alias for the user
    int numRecords = externalUserParticipantLinkDetailsList.details.dtls.size();

    for (int i = 0; i < numRecords; i++) {
      ExternalUserParticipantLinkDetails currentRecord = externalUserParticipantLinkDetailsList.details.dtls.item(
        i);
       
      // if provider or provider group, set the ID
      if (currentRecord.externalUserParticipantLinkDtls.extUserPartRelType.equals(
        EXTERNALUSERSPARTRELTYPE.PROVIDER)
          || currentRecord.externalUserParticipantLinkDtls.extUserPartRelType.equals(
            EXTERNALUSERSPARTRELTYPE.PROVIDERGROUP)) {
  
        externalParticipantDetails.participantRoleID = currentRecord.externalUserParticipantLinkDtls.participantRoleID;
        break;
      }
      
      // if the logged in user is a member,then we need to get the concernRoleID 
      // of the concernRole to whom the member belongs.
      if (currentRecord.externalUserParticipantLinkDtls.extUserPartRelType.equals(
        EXTERNALUSERSPARTRELTYPE.PROVIDERMEMBEROF)) {
        
        ConcernRole memberConcernRole = concernRoleDAO.get(
          currentRecord.externalUserParticipantLinkDtls.participantRoleID);
        
        SearchRefNumDetails searchRefNumDetails = new SearchRefNumDetails();
        
        // set the details
        searchRefNumDetails.referenceNumber = memberConcernRole.getPrimaryAlternateID();
        searchRefNumDetails.category = curam.provider.impl.ProviderPartyCategoryEntry.MEMBER.getCode();
        searchRefNumDetails.currentDate = Date.getCurrentDate();
        
        ProviderMember providerMember = providerMemberDAO.searchByReferenceNumber(
          searchRefNumDetails);
        
        // set the concern Role ID to be the provider group or providers ID
        externalParticipantDetails.participantRoleID = providerMember.getProviderOrganization().getID();
        break;
      }

    }
    
    // return the concernRoleType.
    ConcernRole concernRole = concernRoleDAO.get(
      externalParticipantDetails.participantRoleID);
    
    externalParticipantDetails.concernRoleType = concernRole.getConcernRoleType().getCode();
    
    return externalParticipantDetails;
  }
  
}
