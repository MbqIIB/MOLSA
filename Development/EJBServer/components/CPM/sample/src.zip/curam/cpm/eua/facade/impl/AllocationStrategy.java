/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import curam.core.fact.ConcernRoleFactory;
import curam.core.intf.ConcernRole;
import curam.core.sl.struct.AllocationTargetDetails;
import curam.core.sl.struct.AllocationTargetList;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.GetCurrentOwnerKey;
import curam.core.struct.MaintainAdminConcernRoleRMDtlsList;
import curam.cpm.eua.facade.struct.AllocationStrategyReturnDtls;
import curam.cpm.eua.facade.struct.AllocationStrategySearchDetails;
import curam.cpm.eua.facade.struct.ExternalUserCreatedDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Workflow allocation functions.
 */
public abstract class AllocationStrategy extends curam.cpm.eua.facade.base.AllocationStrategy {
    
  // ___________________________________________________________________________
  /**
   * Resource Manager allocation function.
   *
   * @param dtls - containing a concernRoleID and userName
   *
   * @return A list of Allocation Targets objects.
   *
   * @throws InformationalException 
   * @throws AppException
   */
  public AllocationTargetList resourceManagerAllocationStrategy(
    ExternalUserCreatedDetails dtls)
    throws AppException, InformationalException {
    
    AllocationTargetList allocationTargetList = new AllocationTargetList();
    AllocationTargetDetails allocationTargetDetails = new AllocationTargetDetails();

    // administration concern role entity, key and details list
    curam.core.intf.AdministrationConcernRole administrationConcernRoleObj = curam.core.fact.AdministrationConcernRoleFactory.newInstance();
    GetCurrentOwnerKey getCurrentOwnerKey = new GetCurrentOwnerKey();
    MaintainAdminConcernRoleRMDtlsList maintainAdminConcernRoleRMDtlsList;

    // Get the ConcernRole owner.
    getCurrentOwnerKey.concernRoleID = dtls.concernRoleID;
    getCurrentOwnerKey.currentDate = curam.util.type.Date.getCurrentDate();

    maintainAdminConcernRoleRMDtlsList = administrationConcernRoleObj.searchCurrentOwner(
      getCurrentOwnerKey);
      
    // If there is no current Owner, use the currently logged in user.
    if (maintainAdminConcernRoleRMDtlsList.dtls.isEmpty()) {

      allocationTargetDetails.name = dtls.username;

    } else {

      allocationTargetDetails.name = maintainAdminConcernRoleRMDtlsList.dtls.item(0).userName;

    }

    allocationTargetDetails.type = curam.codetable.TARGETITEMTYPE.USER;
      
    // Add spec to the list
    allocationTargetList.dtls.addRef(allocationTargetDetails);    
   
    return allocationTargetList;
  }

  // ___________________________________________________________________________
  /**
   * Read Concern Role Type function.
   *
   * @param key - containing a concernRoleID
   *
   * @return Contains the concern role type
   *
   * @throws InformationalException
   * @throws AppException
   */
  public AllocationStrategyReturnDtls readConcernRoleType(AllocationStrategySearchDetails key) throws AppException, InformationalException {
    
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;
    ConcernRoleTypeDetails concernRoleTypeDetails = concernRoleObj.readConcernRoleType(
      concernRoleKey);
    AllocationStrategyReturnDtls allocationStrategyReturnDtls = new AllocationStrategyReturnDtls();

    allocationStrategyReturnDtls.concernRoleType = concernRoleTypeDetails.concernRoleType;
    return allocationStrategyReturnDtls;
    
  }

}  

