/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.google.inject.Inject;

import curam.certification.impl.Certification;
import curam.certification.impl.CertificationDAO;
import curam.codetable.CERTIFICATIONTYPE;
import curam.codetable.EXTERNALISSUER;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.fact.OrganisationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.intf.Organisation;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.struct.OrganisationDtls;
import curam.core.struct.OrganisationID;
import curam.core.struct.OrganisationKey;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.MemberCertificationDetails;
import curam.cpm.facade.struct.MemberCertificationDetails1;
import curam.cpm.facade.struct.MemberCertificationDetailsList;
import curam.cpm.facade.struct.MemberCertificationDetailsList1;
import curam.cpm.facade.struct.VersionNo;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ProviderPartyKey;
import curam.cpm.sl.struct.MemberCertificationDtls;
import curam.cpm.sl.struct.MemberCertificationKey;
import curam.cpm.sl.struct.PartyConcernRoleIDKey;
import curam.message.impl.MEMBERCERTIFICATIONExceptionCreator;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.impl.MemberCertification;
import curam.provider.impl.MemberCertificationChangeHistory;
import curam.provider.impl.MemberCertificationChangeHistoryDAO;
import curam.provider.impl.MemberCertificationDAO;
import curam.provider.impl.ProviderParty;
import curam.provider.impl.ProviderPartyDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.type.CodeTable;
import curam.util.type.DateTime;


/**
 * Facade layer class having API for Certification which is issued to an
 * provider, provider group and unassigned provider member.
 */
public abstract class MaintainMemberCertification extends curam.cpm.facade.base.MaintainMemberCertification {

  /**
   * Member Certification DAO
   */
  @Inject
  protected MemberCertificationDAO memberCertificationDAO;

  /**
   * Member Certification Change History DAO
   */
  @Inject
  protected MemberCertificationChangeHistoryDAO memberCertificationChangeHistoryDAO;

  /**
   * Certification DAO
   */
  @Inject
  protected CertificationDAO certificationDAO;

  /**
   * Provider Party DAO
   */
  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  // BEGIN, CR00246961, GP
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;
  // END, CR00246961
  
  /**
   * Constructor
   */
  public MaintainMemberCertification() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * This method create the certifications that are achieved by a provider
   * member, provider group member or unassigned provider member and also based
   * on the date of issue mentioned the date of expiry is populated.
   *
   * @param memberCertificationDtls
   * Contains the details of member certification to be inserted
   *
   * @return contains the system generated identifier for the maintain
   * certification created
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public MemberCertificationKey createMemberCertification(
    MemberCertificationDetails memberCertificationDtls) throws AppException,
      InformationalException {

    SystemUser systemUserObj = SystemUserFactory.newInstance();
    MemberCertificationKey memberCertificationKey = new MemberCertificationKey();
    final MemberCertification memberCertification = memberCertificationDAO.newInstance();
    final MemberCertificationChangeHistory memberCertificationChangeHistory = memberCertificationChangeHistoryDAO.newInstance();

    // BEGIN, CR00121578, NRV
    if (memberCertificationDtls.providerPartyID != 0) {
      ProviderParty providerParty = providerPartyDAO.get(
        memberCertificationDtls.providerPartyID);

      if (RECORDSTATUSEntry.CANCELLED.equals(providerParty.getLifecycleState())) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          MEMBERCERTIFICATIONExceptionCreator.ERR_MEMBERCERTFICATION_FV_PROVIDER_MEMBER_NOT_ACTIVE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }
    }
    // END, CR00121578

    memberCertification.setCertification(
      certificationDAO.get(memberCertificationDtls.certificationID));
    memberCertification.setPartyconcernRoleID(
      memberCertificationDtls.partyConcernRoleID);
    memberCertification.setDateOfIssue(memberCertificationDtls.dateofIssue);

    memberCertification.setDateOfExpiry(memberCertificationDtls.dateofExpiry);

    memberCertification.setComments(memberCertificationDtls.comments);
    memberCertification.insert();

    memberCertificationChangeHistory.setCertification(
      certificationDAO.get(memberCertificationDtls.certificationID));
    memberCertificationChangeHistory.setMemberCertificationID(
      memberCertification.getID());
    memberCertificationChangeHistory.setDateTime(DateTime.getCurrentDateTime());
    memberCertificationChangeHistory.setDateOfIssue(
      memberCertificationDtls.dateofIssue);
    memberCertificationChangeHistory.setDateOfExpiry(
      memberCertification.getDateOfExpiry());
    memberCertificationChangeHistory.setPartyconcernRoleID(
      memberCertificationDtls.partyConcernRoleID);
    memberCertificationChangeHistory.setUserName(
      systemUserObj.getUserDetails().userName);
    memberCertificationChangeHistory.insert();

    memberCertificationKey.memberCertificationID = memberCertification.getID();
    return memberCertificationKey;
  }

  // BEGIN, CR00127684, NK
  /**
   * Method updates the member certification which is issued to a provider,
   * provider group or unassigned provider member. If date of issue is modified
   * then have to check for the date of expiry is also updated.
   *
   * @param memberCertificationDtls
   * Contains the modified details of the member certification
   *
   * @return List of informational message.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMessageList updateMemberCertification(
    MemberCertificationDtls memberCertificationDtls) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();
    SystemUser systemUserObj = SystemUserFactory.newInstance();
    final MemberCertification memberCertification = memberCertificationDAO.get(
      memberCertificationDtls.memberCertificationID);
    final MemberCertificationChangeHistory memberCertificationChangeHistory = memberCertificationChangeHistoryDAO.newInstance();

    memberCertification.setCertification(
      certificationDAO.get(memberCertificationDtls.certificationID));
    memberCertification.setDateOfIssue(memberCertificationDtls.dateOfIssue);
    memberCertification.setPartyconcernRoleID(
      memberCertificationDtls.partyConcernRoleID);

    memberCertification.setDateOfExpiry(memberCertificationDtls.dateOfExpiry);
    memberCertification.setComments(memberCertificationDtls.comments);
    // BEGIN, CR00127684, NK
    informationalMessageList = memberCertification.modifyCertification(
      memberCertificationDtls.versionNo);
    // END, CR00127684
    memberCertificationChangeHistory.setMemberCertificationID(
      memberCertificationDtls.memberCertificationID);
    memberCertificationChangeHistory.setCertification(
      certificationDAO.get(memberCertificationDtls.certificationID));
    memberCertificationChangeHistory.setDateTime(DateTime.getCurrentDateTime());
    memberCertificationChangeHistory.setDateOfIssue(
      memberCertificationDtls.dateOfIssue);
    memberCertificationChangeHistory.setDateOfExpiry(
      memberCertificationDtls.dateOfExpiry);
    memberCertificationChangeHistory.setPartyconcernRoleID(
      memberCertificationDtls.partyConcernRoleID);
    memberCertificationChangeHistory.setUserName(
      systemUserObj.getUserDetails().userName);
    memberCertificationChangeHistory.insert();

    return informationalMessageList;
  }

  // END, CR00127684
  /**
   * This method is to get the particular member certification details which are
   * assigned to an provider, provider group or unassigned provider member.
   *
   * @param memberCertificationKey
   * Contains the system identifier for the member certification
   *
   * @return contains the member certification details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public MemberCertificationDetails viewMemberCertification(
    MemberCertificationKey memberCertificationKey) throws AppException,
      InformationalException {

    final MemberCertification memberCertification = memberCertificationDAO.get(
      memberCertificationKey.memberCertificationID);
    final Certification certification = memberCertification.getCertification();
    MemberCertificationDetails memberCertificationDetails = new MemberCertificationDetails();

    memberCertificationDetails.comments = memberCertification.getComments();
    memberCertificationDetails.certificationID = certification.getID();
    memberCertificationDetails.dateofIssue = memberCertification.getDateOfIssue();
    memberCertificationDetails.partyConcernRoleID = memberCertification.getPartyConcernRoleID();
    memberCertificationDetails.dateofExpiry = memberCertification.getDateOfExpiry();
    // BEGIN CR00128529, KK
    memberCertificationDetails.derivedStatus = memberCertification.getDerivedStstus().getCode();
    // END CR00128529, KK
    memberCertificationDetails.certificationType = certification.getCertificationType().getCode();
    memberCertificationDetails.versionNo = memberCertification.getVersionNo();

    if (certification.isIssuedByAgency()) {
      Organisation organisationObj = OrganisationFactory.newInstance();
      OrganisationKey organisationKey = new OrganisationKey();
      OrganisationID organisationID = new OrganisationID();

      organisationID = organisationObj.readOrganisationID();
      organisationKey.organisationID = organisationID.organisationID;
      OrganisationDtls organisationDtls = new OrganisationDtls();

      organisationDtls = organisationObj.read(organisationKey);
      memberCertificationDetails.issuer = organisationDtls.name;

    } else if (!(certification.getOrganisationUnitId()
      == CPMConstants.kZeroLong)) {
      OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

      OrganisationUnitKey key = new OrganisationUnitKey();

      key.organisationUnitID = certification.getOrganisationUnitId();

      memberCertificationDetails.issuer = organisationUnitObj.read(key).name;

    } else {

      // BEGIN CR00121516 KR
      memberCertificationDetails.issuer = CodeTable.getOneItem(
        EXTERNALISSUER.TABLENAME, certification.getExternalIssuer().getCode());
      // END CR00121516

    }
    return memberCertificationDetails;
  }

  /**
   * This method is to logically delete an particular member certification
   * assigned to an provider, provider group or unassigned provider member.
   *
   * @param memberCertificationKey
   * Contains the system identifier for the member certification
   * @param versionNo
   * Contains the versionNo
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deleteMemberCertification(
    MemberCertificationKey memberCertificationKey, VersionNo versionNo)
    throws AppException, InformationalException {

    final MemberCertification memberCertification = memberCertificationDAO.get(
      memberCertificationKey.memberCertificationID);

    memberCertification.cancel(versionNo.versionNo);

  }

  /**
   * This method is to list all the active member certifications assigned to an
   * provider, provider member or unassigned provider member
   *
   * @param providerPartyKey
   * COntains the provider party id.
   *
   * @return contains the list of all the maintain configurations
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public MemberCertificationDetailsList listMemberCertification(
    ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    MemberCertificationDetailsList memberCertificationDetailsList = new MemberCertificationDetailsList();

    ProviderParty providerParty = providerPartyDAO.get(
      providerPartyKey.providerPartyID);

    for (MemberCertification memberCertification : memberCertificationDAO.searchActiveMemberCertificationByParty(
      providerParty.getParty().getID())) {

      final Certification certification = memberCertification.getCertification();
      final MemberCertificationDetails memberCertificationDetails = new MemberCertificationDetails();

      memberCertificationDetails.memberCertificationID = memberCertification.getID();
      memberCertificationDetails.certificationType = certification.getCertificationType().getCode();
      memberCertificationDetails.partyConcernRoleID = memberCertification.getPartyConcernRoleID();
      memberCertificationDetails.dateofIssue = memberCertification.getDateOfIssue();
      memberCertificationDetails.dateofExpiry = memberCertification.getDateOfExpiry();
      // BEGIN CR00127709, KK
      memberCertificationDetails.derivedStatus = memberCertification.getDerivedStstus().getCode();
      // END CR00127709, KK
      // BEGIN, CR00236589, ASN
      memberCertificationDetails.versionNo = memberCertification.getVersionNo();
      // END, CR00236589, ASN

      if (certification.isIssuedByAgency()) {
        Organisation organisationObj = OrganisationFactory.newInstance();
        OrganisationKey organisationKey = new OrganisationKey();
        OrganisationID organisationID = new OrganisationID();

        organisationID = organisationObj.readOrganisationID();
        organisationKey.organisationID = organisationID.organisationID;
        OrganisationDtls organisationDtls = new OrganisationDtls();

        organisationDtls = organisationObj.read(organisationKey);
        memberCertificationDetails.issuer = organisationDtls.name;

      } else if (!(certification.getOrganisationUnitId()
        == CPMConstants.kZeroLong)) {
        OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

        OrganisationUnitKey key = new OrganisationUnitKey();

        key.organisationUnitID = certification.getOrganisationUnitId();

        memberCertificationDetails.issuer = organisationUnitObj.read(key).name;

      } else {
        // BEGIN CR00121516 KR
        memberCertificationDetails.issuer = CodeTable.getOneItem(
          EXTERNALISSUER.TABLENAME, certification.getExternalIssuer().getCode());
        // END CR00121516
      }
      memberCertificationDetailsList.dtlsList.addRef(memberCertificationDetails);
    }

    // BEGIN CR00122449, KR
    // Sort the member certification list based on the certification type for
    // display
    MemberCertificationDetailsList sortedmemberCertificationDetailsList = new MemberCertificationDetailsList();

    sortedmemberCertificationDetailsList.dtlsList.addAll(
      sortMemberCertification(memberCertificationDetailsList));

    sortedmemberCertificationDetailsList.contextdescription = providerParty.getParty().getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace
      + providerParty.getParty().getPrimaryAlternateID();

    return sortedmemberCertificationDetailsList;
    // END CR00122449
  }

  // BEGIN CR00122449, KR
  /**
   * Sort the list of member certification details based on the certification
   * type
   *
   * @param unsortedMemberCertificationList
   * Contains the unsorted list of member certification
   *
   * @return Contains the list of sorted member certification
   */
  // BEGIN, CR00177241, PM
  protected List<MemberCertificationDetails> sortMemberCertification(
    // END, CR00177241
    final MemberCertificationDetailsList unsortedMemberCertificationList) {

    List<MemberCertificationDetails> memberCertificationDetailsList = new ArrayList<MemberCertificationDetails>();

    int noOfMemberCertification = unsortedMemberCertificationList.dtlsList.size();

    for (int i = 0; i < noOfMemberCertification; i++) {
      memberCertificationDetailsList.add(
        unsortedMemberCertificationList.dtlsList.item(i));
    }

    Collections.sort(memberCertificationDetailsList,
      new Comparator<MemberCertificationDetails>() {
      public int compare(final MemberCertificationDetails lhs,
        MemberCertificationDetails rhs) {

        String lhsType = null;
        String rhsType = null;

        try {
          lhsType = CodeTable.getOneItem(CERTIFICATIONTYPE.TABLENAME,
            lhs.certificationType);
          rhsType = CodeTable.getOneItem(CERTIFICATIONTYPE.TABLENAME,
            rhs.certificationType);
        } catch (AppException e) {// Ignore AppException
        } catch (InformationalException e) {// Ignore InformationalException
        }
        return lhsType.compareToIgnoreCase(rhsType);
      }
    });

    return memberCertificationDetailsList;
  }

  // END CR00122449

  // BEGIN, CR00246961, GP
  /**
   * Lists all the change history of the member certification which is assigned
   * to an provider, provider member or unassigned provider member
   *
   * @param memberCertificationKey
   * Contains the system identifier for the member certification.
   *
   * @return The list of all maintain certification change history details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listMemberCertificationChangeHistory1(MemberCertificationKey)}
   * . This method is not useful for displaying user full name in
   * the list of member certification change history. Hence this
   * method is deprecated. The newly added method will give the
   * option to the user to display the user full name. See release
   * note: CR00246961.
   */
  @Deprecated
  // END, CR00246961
  public MemberCertificationDetailsList listMemberCertificationChangeHistory(
    MemberCertificationKey memberCertificationKey) throws AppException,
      InformationalException {

    MemberCertificationDetailsList memberCertificationDetailsList = new MemberCertificationDetailsList();

    for (MemberCertificationChangeHistory memberCertificationChangeHistory : memberCertificationChangeHistoryDAO.SearchByMemberCertification(
      memberCertificationKey.memberCertificationID)) {

      final Certification certification = memberCertificationChangeHistory.getCertification();

      final MemberCertificationDetails memberCertificationDetails = new MemberCertificationDetails();

      // BEGIN CR00121465, KR
      memberCertificationDetails.dateTime = memberCertificationChangeHistory.getDateTime();
      // END CR00121465
      memberCertificationDetails.certificationType = certification.getCertificationType().getCode();
      memberCertificationDetails.userName = memberCertificationChangeHistory.getUserName();
      memberCertificationDetails.dateofIssue = memberCertificationChangeHistory.getDateOfIssue();
      memberCertificationDetails.dateofExpiry = memberCertificationChangeHistory.getDateOfExpiry();
      // BEGIN CR00128529, KK
      memberCertificationDetails.derivedStatus = memberCertificationChangeHistory.getDerivedStatus().getCode();
      // END CR00128529, KK
      memberCertificationDetailsList.dtlsList.addRef(memberCertificationDetails);
    }
    return sortMemberCertificationHistoryByDateTimeChanged(
      memberCertificationDetailsList);
  }

  // BEGIN, CR00246961, GP
  /**
   * Lists all the change history of the member certification which is assigned
   * to an provider, provider member or unassigned provider member
   *
   * @param memberCertificationKey
   * Contains the system identifier for the member certification.
   *
   * @return The list of all maintain certification change history details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public MemberCertificationDetailsList1 listMemberCertificationChangeHistory1(
    final MemberCertificationKey memberCertificationKey) throws AppException, InformationalException {
    
    MemberCertificationDetailsList1 memberCertificationDetailsList1 = new MemberCertificationDetailsList1();

    for (MemberCertificationChangeHistory memberCertificationChangeHistory : memberCertificationChangeHistoryDAO.SearchByMemberCertification(
      memberCertificationKey.memberCertificationID)) {

      final Certification certification = memberCertificationChangeHistory.getCertification();

      final MemberCertificationDetails1 memberCertificationDetails1 = new MemberCertificationDetails1();

      memberCertificationDetails1.dateTime = memberCertificationChangeHistory.getDateTime();
      memberCertificationDetails1.certificationType = certification.getCertificationType().getCode();
      memberCertificationDetails1.userName = memberCertificationChangeHistory.getUserName();
      
      User user = userDAO.get(memberCertificationChangeHistory.getUserName());

      memberCertificationDetails1.userFullName = user.getFullName();
      
      memberCertificationDetails1.dateofIssue = memberCertificationChangeHistory.getDateOfIssue();
      memberCertificationDetails1.dateofExpiry = memberCertificationChangeHistory.getDateOfExpiry();
      memberCertificationDetails1.derivedStatus = memberCertificationChangeHistory.getDerivedStatus().getCode();
      memberCertificationDetailsList1.memberCertificationDetails.addRef(
        memberCertificationDetails1);
    }
    
    return sortMemberCertificationHistoryByDateTimeChanged1(
      memberCertificationDetailsList1);
  }

  // END, CR00246961
  
  // BEGIN, CR00121578, NRV
  /**
   * This method is to list all the active member certifications assigned to
   * unassigned provider member.
   *
   * @param partyConcernRoleIDKey
   * Contains the party concern role id.
   *
   * @return contains the list of all the maintain configurations
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public MemberCertificationDetailsList listUnassignedMemberCertification(
    PartyConcernRoleIDKey partyConcernRoleIDKey) throws AppException,
      InformationalException {

    MemberCertificationDetailsList memberCertificationDetailsList = new MemberCertificationDetailsList();

    for (MemberCertification memberCertification : memberCertificationDAO.searchActiveMemberCertificationByParty(
      partyConcernRoleIDKey.partyConcernRoleID)) {

      final Certification certification = memberCertification.getCertification();
      final MemberCertificationDetails memberCertificationDetails = new MemberCertificationDetails();

      memberCertificationDetails.memberCertificationID = memberCertification.getID();
      memberCertificationDetails.certificationType = certification.getCertificationType().getCode();
      memberCertificationDetails.partyConcernRoleID = memberCertification.getPartyConcernRoleID();
      memberCertificationDetails.dateofIssue = memberCertification.getDateOfIssue();
      memberCertificationDetails.dateofExpiry = memberCertification.getDateOfExpiry();
      // BEGIN CR00127709, KK
      memberCertificationDetails.derivedStatus = memberCertification.getDerivedStstus().getCode();
      // END CR00127709, KK

      if (certification.isIssuedByAgency()) {
        Organisation organisationObj = OrganisationFactory.newInstance();
        OrganisationKey organisationKey = new OrganisationKey();
        OrganisationID organisationID = new OrganisationID();

        organisationID = organisationObj.readOrganisationID();
        organisationKey.organisationID = organisationID.organisationID;
        OrganisationDtls organisationDtls = new OrganisationDtls();

        organisationDtls = organisationObj.read(organisationKey);
        memberCertificationDetails.issuer = organisationDtls.name;

      } else if (!(certification.getOrganisationUnitId()
        == CPMConstants.kZeroLong)) {
        OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();

        OrganisationUnitKey key = new OrganisationUnitKey();

        key.organisationUnitID = certification.getOrganisationUnitId();

        memberCertificationDetails.issuer = organisationUnitObj.read(key).name;

      } else {

        // BEGIN CR00121516 KR
        memberCertificationDetails.issuer = CodeTable.getOneItem(
          EXTERNALISSUER.TABLENAME, certification.getExternalIssuer().getCode());
        // END CR00121516
      }
      memberCertificationDetailsList.dtlsList.addRef(memberCertificationDetails);
    }
    // BEGIN CR00122449 KR
    MemberCertificationDetailsList sortedmemberCertificationDetailsList = new MemberCertificationDetailsList();

    sortedmemberCertificationDetailsList.dtlsList.addAll(
      sortMemberCertification(memberCertificationDetailsList));
    return sortedmemberCertificationDetailsList;
    // END CR00122449
  }

  // END, CR00121578

  /**
   * Sorts the member certifications history list by Date and Time Changed,
   * latest first.
   *
   * @param memberCertificationsHistoryDetailsList
   * Contains unsorted member certifications details list.
   * @return Sorted List of Member Certifications based on date time changed,
   * latest first.
   */
  protected MemberCertificationDetailsList sortMemberCertificationHistoryByDateTimeChanged(
    MemberCertificationDetailsList memberCertificationsHistoryDetailsList) {

    MemberCertificationDetailsList memberCertificationHistoryDetailsSortedList = new MemberCertificationDetailsList();
    List<MemberCertificationDetails> memberCertificationHistoryDetailsSortableList = new ArrayList<MemberCertificationDetails>();

    for (int i = 0; i < memberCertificationsHistoryDetailsList.dtlsList.size(); i++) {
      memberCertificationHistoryDetailsSortableList.add(
        memberCertificationsHistoryDetailsList.dtlsList.item(i));
    }
    // Sorting the member certification history list by Date and
    // Time Changed, latest first.
    if (memberCertificationHistoryDetailsSortableList.size() > 0) {
      Collections.sort(memberCertificationHistoryDetailsSortableList,
        new Comparator<MemberCertificationDetails>() {
        public int compare(final MemberCertificationDetails lhs,
          final MemberCertificationDetails rhs) {
          return lhs.dateTime.compareTo(rhs.dateTime);
        }
      });
    }

    for (int i = memberCertificationHistoryDetailsSortableList.size(); i > 0; i--) {
      memberCertificationHistoryDetailsSortedList.dtlsList.addRef(
        memberCertificationHistoryDetailsSortableList.get(i - 1));
    }

    return memberCertificationHistoryDetailsSortedList;
  }

  // BEGIN, CR00246961, GP
  /**
   * Sorts the member certifications history list by Date and Time Changed,
   * latest first.
   *
   * @param memberCertificationsHistoryDetailsList1
   * Contains unsorted member certifications details list.
   *
   * @return Sorted List of Member Certifications based on date time changed,
   * latest first.
   */
  protected MemberCertificationDetailsList1 sortMemberCertificationHistoryByDateTimeChanged1(
    MemberCertificationDetailsList1 memberCertificationsHistoryDetailsList1) {

    MemberCertificationDetailsList1 memberCertificationHistoryDetailsSortedList1 = new MemberCertificationDetailsList1();
    List<MemberCertificationDetails1> memberCertificationHistoryDetailsSortableList1 = new ArrayList<MemberCertificationDetails1>();

    for (final MemberCertificationDetails1 memberCertificationDetails1 : memberCertificationsHistoryDetailsList1.memberCertificationDetails.items()) {
      memberCertificationHistoryDetailsSortableList1.add(
        memberCertificationDetails1);
    }

    // Sorting the member certification history list by Date and
    // Time Changed, latest first.
    if (memberCertificationHistoryDetailsSortableList1.size() > 0) {
      Collections.sort(memberCertificationHistoryDetailsSortableList1,
        new Comparator<MemberCertificationDetails1>() {
        public int compare(final MemberCertificationDetails1 lhs,
          final MemberCertificationDetails1 rhs) {
          return lhs.dateTime.compareTo(rhs.dateTime);
        }
      });
    }

    for (int i = memberCertificationHistoryDetailsSortableList1.size(); i > 0; i--) {
      memberCertificationHistoryDetailsSortedList1.memberCertificationDetails.addRef(
        memberCertificationHistoryDetailsSortableList1.get(i - 1));
    }

    return memberCertificationHistoryDetailsSortedList1;
  }

  // END, CR00246961
}
