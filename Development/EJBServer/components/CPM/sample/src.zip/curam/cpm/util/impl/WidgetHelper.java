/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.util.impl;


import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;

import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;

import curam.codetable.impl.ATTENDANCEEntry;
import curam.core.facade.struct.CodeTableName;
import curam.core.facade.struct.ReadCodeTableItemKey;
import curam.core.impl.CuramConst;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestLineItemClientDetails;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestLineItemClientDetailsList;
import curam.cpm.facade.struct.ConcernRoleMemberDetails;
import curam.cpm.facade.struct.CreateResponseScoreDetails;
import curam.cpm.facade.struct.DailyAttendanceDetails;
import curam.cpm.facade.struct.DailyAttendanceDetailsList;
import curam.cpm.facade.struct.ProviderRosterLineItemDetails;
import curam.cpm.facade.struct.ProviderRosterLineItemDetailsList;
import curam.cpm.facade.struct.ResponseScoreDetails;
import curam.cpm.facade.struct.ResponseScoreDetailsList;
import curam.cpm.facade.struct.SILIClientDetails;
import curam.cpm.facade.struct.SILIClientDetailsList;
import curam.cpm.facade.struct.TrainingPartyCreateDetails;
import curam.cpm.facade.struct.TrainingPartyCreateDetailsList;
import curam.cpm.facade.struct.TrainingProgramPartyDetails;
import curam.cpm.facade.struct.TrainingProgramPartyDetailsList;
import curam.cpm.impl.CPMConstants;
import curam.message.RESPONSESCORE;
import curam.message.ROSTER;
import curam.message.TRAININGPROGRAM;
import curam.message.WIDGET;
import curam.message.impl.RESPONSESCOREExceptionCreator;
import curam.message.impl.ROSTERExceptionCreator;
import curam.message.impl.TRAININGPROGRAMExceptionCreator;
import curam.serviceevaluationcriterion.impl.SECRESPONSEDATATYPEEntry;
import curam.util.administration.fact.CodeTableAdminFactory;
import curam.util.administration.intf.CodeTableAdmin;
import curam.util.administration.struct.CodeTableAdminListAllItemsAndDefaultOut;
import curam.util.administration.struct.CodeTableHeaderDetails;
import curam.util.administration.struct.CodeTableItemDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.Locale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.Money;
import curam.util.type.StringHelper;


/**
 * Helper class for converting xml to string and string to xml required for
 * widgets.
 *
 */
public class WidgetHelper {

  // BEGIN, CR00186180, PS
  /*
   * Date constant in the yyyy-MM-dd format.
   */
  protected final static String kDateFormat = Locale.Date_ymd_ext;
  // END, CR00186180
  
 
  /**
   * Converts the list of Training Program Party Details to a xml. Domain
   * definitions of each xml element is also populated. The widget uses the xml
   * data to display these details.
   *
   * @param trainingProgramPartyDetailsList
   * This struct contains the details which needs to be provided to the
   * widget for display.
   * @return Parsed Xml string.
   */
  
  public static String convertConcernMemberTrainingProgramToXml(
    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList) {

    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    Element rootElement = new Element(
      CPMWidgetHelperConstants.kConcernMemberTrainingProgramElement);

    // Check if the input list is empty and then form an xml with null
    // values.
    // Else if the input list is not empty then form an xml with the details
    // of the input list. The domain definition of each attribute in the
    // details struct is also populated in the xml.
    int size = trainingProgramPartyDetailsList.partyDetails.size();

    if (size == 0) {
      Element concernMemberElement = new Element(
        CPMWidgetHelperConstants.kConcernMemberElement);

      Element partyConcernRoleIDElement = new Element(
        CPMWidgetHelperConstants.kPartyConcernRoleIDElement);
      Attribute partyConcernRoleIDDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kPartyIDDomainValueAttribute);

      partyConcernRoleIDElement.setAttribute(
        partyConcernRoleIDDomainValueAttribute);

      Element partyNameElement = new Element(
        CPMWidgetHelperConstants.kPartyNameElement);
      Attribute partyNameDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kPartyNameDomainValueAttribute);

      partyNameElement.setAttribute(partyNameDefaultValueAttribute);

      Element roleElement = new Element(CPMWidgetHelperConstants.kRoleElement);
      Attribute roleDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kRoleDomainValueAttribute);

      roleElement.setAttribute(roleDefaultValueAttribute);

      Element completionElement = new Element(
        CPMWidgetHelperConstants.kCompletionElement);
      Attribute completionAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kCompletionDomainValueAttribute);

      completionElement.setAttribute(completionAttribute);

      Element unitsRequiredElement = new Element(
        CPMWidgetHelperConstants.kUnitsRequiredElement);
      Attribute unitsRequiredAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kUnitsRequiredDomainValueAttribute);

      unitsRequiredElement.setAttribute(unitsRequiredAttribute);

      concernMemberElement.addContent(partyConcernRoleIDElement);
      concernMemberElement.addContent(partyNameElement);
      concernMemberElement.addContent(roleElement);
      concernMemberElement.addContent(completionElement);
      concernMemberElement.addContent(unitsRequiredElement);
      rootElement.addContent(concernMemberElement);
    } else {

      Iterator trainingProgramIter = trainingProgramPartyDetailsList.partyDetails.iterator();

      while (trainingProgramIter.hasNext()) {
        TrainingProgramPartyDetails trainingProgramPartyDetails = (TrainingProgramPartyDetails) trainingProgramIter.next();

        if (trainingProgramPartyDetails != null) {

          Element concernMemberElement = new Element(
            CPMWidgetHelperConstants.kConcernMemberElement);

          Element partyConcernRoleIDElement = new Element(
            CPMWidgetHelperConstants.kPartyConcernRoleIDElement);
          Attribute partyConcernRoleIDDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kPartyIDDomainValueAttribute);

          partyConcernRoleIDElement.setAttribute(
            partyConcernRoleIDDomainValueAttribute);
          partyConcernRoleIDElement.setText(
            String.valueOf(trainingProgramPartyDetails.partyConcernRoleID));

          Element partyNameElement = new Element(
            CPMWidgetHelperConstants.kPartyNameElement);
          Attribute partyNameDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kPartyNameDomainValueAttribute);

          partyNameElement.setAttribute(partyNameDefaultValueAttribute);
          partyNameElement.setText(trainingProgramPartyDetails.partyName);

          Element roleElement = new Element(
            CPMWidgetHelperConstants.kRoleElement);
          Attribute roleDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kRoleDomainValueAttribute);

          roleElement.setAttribute(roleDefaultValueAttribute);
          roleElement.setText(trainingProgramPartyDetails.role);

          Element completionElement = new Element(
            CPMWidgetHelperConstants.kCompletionElement);
          Attribute completionAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kCompletionDomainValueAttribute);

          completionElement.setAttribute(completionAttribute);
          completionElement.setText(trainingProgramPartyDetails.completion);

          Element unitsRequiredElement = new Element(
            CPMWidgetHelperConstants.kUnitsRequiredElement);
          Attribute unitsRequiredAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kUnitsRequiredDomainValueAttribute);

          unitsRequiredElement.setAttribute(unitsRequiredAttribute);
          unitsRequiredElement.setText(
            String.valueOf(trainingProgramPartyDetails.unitsRequired));

          concernMemberElement.addContent(partyConcernRoleIDElement);
          concernMemberElement.addContent(partyNameElement);
          concernMemberElement.addContent(roleElement);
          concernMemberElement.addContent(completionElement);
          concernMemberElement.addContent(unitsRequiredElement);
          rootElement.addContent(concernMemberElement);
        }
      }
    }

    Document document = new Document(rootElement);
    XMLOutputter xmlOutputter = new XMLOutputter();

    return xmlOutputter.outputString(document);

  }

  /**
   * Populates the concern member training program xml data received from widget
   * to concern member training program details list.
   *
   * @param trainingProgram
   * This struct contains details of the Concern Member Training
   * Program.
   * @return Training Program Party Details list.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_UNITSREQUIRED_INVALID}
   * If the units required entered is invalid.
   */
  public static TrainingProgramPartyDetailsList convertXmlToConcernMemberTrainingProgram(
    curam.cpm.facade.struct.TrainingProgram trainingProgram)
    throws AppException, InformationalException {
    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList = new TrainingProgramPartyDetailsList();

    String strTrainingEditorXml = trainingProgram.memberDetails;

    InputStream inputStream = new ByteArrayInputStream(
      strTrainingEditorXml.getBytes());

    SAXBuilder sAXBuilder = new SAXBuilder();
    Document document = null;

    try {
      document = sAXBuilder.build(inputStream);
      Element rootElement = document.getRootElement();
      List providerGroupDetailsElements = rootElement.getChildren();
      Iterator providerGroupDetailsIter = providerGroupDetailsElements.iterator();

      while (providerGroupDetailsIter.hasNext()) {

        Element concernMemberElement = (Element) providerGroupDetailsIter.next();

        String strPartyID = concernMemberElement.getChild(CPMWidgetHelperConstants.kPartyIDElement).getText();

        String strPartyName = concernMemberElement.getChild(CPMWidgetHelperConstants.kPartyNameElement).getText();

        String strRole = concernMemberElement.getChild(CPMWidgetHelperConstants.kRoleElement).getText();

        String strCompletion = concernMemberElement.getChild(CPMWidgetHelperConstants.kCompletionElement).getText();

        String strUnitsRequired = concernMemberElement.getChild(CPMWidgetHelperConstants.kUnitsRequiredElement).getText();

        TrainingProgramPartyDetails trainingProgramPartyDetails = new TrainingProgramPartyDetails();

        trainingProgramPartyDetails.partyConcernRoleID = Long.parseLong(
          strPartyID);
        trainingProgramPartyDetails.partyName = strPartyName;
        trainingProgramPartyDetails.role = strRole;
        trainingProgramPartyDetails.completion = strCompletion;
        try {
          trainingProgramPartyDetails.unitsRequired = Integer.parseInt(
            strUnitsRequired);
        } catch (NumberFormatException numberFormatException) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_UNITSREQUIRED_INVALID(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        }

        trainingProgramPartyDetailsList.partyDetails.addRef(
          trainingProgramPartyDetails);

      }

      ValidationHelper.failIfErrorsExist();

    } catch (JDOMException e) {
      throw new AppException(WIDGET.ERR_JDOM_EXCEPTION, e);
    } catch (IOException e) {
      throw new AppException(WIDGET.ERR_IO_EXCEPTION, e);
    }

    return trainingProgramPartyDetailsList;
  }

  /**
   * Converts the list of Member Training Program to a xml. Domain definitions
   * of each xml element is also populated. The widget uses the xml data to
   * display these details.
   *
   * @param trainingPartyCreateDetailsList
   * This struct contains the details which needs to be provided to the
   * widget for display.
   * @return Xml containing Training Program details.
   */
  public static String convertMemberTrainingProgramToXml(
    TrainingPartyCreateDetailsList trainingPartyCreateDetailsList) {

    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    Element rootElement = new Element(
      CPMWidgetHelperConstants.kMemberTrainingProgramElement);

    // Check if the input list is empty and then form an xml with null
    // values.
    // Else if the input list is not empty then form an xml with the details
    // of the input list. The domain definition of each attribute in the
    // details struct is also populated in the xml.
    int size = trainingPartyCreateDetailsList.detailsList.size();

    if (size == 0) {
      Element trainingElement = new Element(
        CPMWidgetHelperConstants.kTrainingElement);

      Element trainingIDElement = new Element(
        CPMWidgetHelperConstants.kTrainingIDElement);
      Attribute serviceOfferingIDDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kTrainingIDDomainValueAttribute);

      trainingIDElement.setAttribute(serviceOfferingIDDefaultValueAttribute);

      Element trainingNameElement = new Element(
        CPMWidgetHelperConstants.kTrainingNameElement);
      Attribute serviceOfferingNameDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kTrainingNameDomainValueAttribute);

      trainingNameElement.setAttribute(serviceOfferingNameDefaultValueAttribute);

      Element unitAmountElement = new Element(
        CPMWidgetHelperConstants.kUnitAmountElement);
      Attribute unitAmountDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kUnitAmountDomainValueAttribute);

      unitAmountElement.setAttribute(unitAmountDefaultValueAttribute);

      Element authorizedFromElement = new Element(
        CPMWidgetHelperConstants.kAuthorizedFromElement);
      Attribute authorizedFromDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kAuthorizedFromDomainValueAttribute);

      authorizedFromElement.setAttribute(authorizedFromDefaultValueAttribute);
      authorizedFromElement.setText(Date.getCurrentDate().toString());

      Element toBeCompletedByElement = new Element(
        CPMWidgetHelperConstants.kToBeCompletedByElement);
      Attribute toBeCompletedByDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.ktoBeCompletedByDomainValueAttribute);

      toBeCompletedByElement.setAttribute(toBeCompletedByDefaultValueAttribute);

      trainingElement.addContent(trainingIDElement);
      trainingElement.addContent(trainingNameElement);
      trainingElement.addContent(unitAmountElement);
      trainingElement.addContent(authorizedFromElement);
      trainingElement.addContent(toBeCompletedByElement);

      rootElement.addContent(trainingElement);
    } else {

      Iterator trainingProgramIter = trainingPartyCreateDetailsList.detailsList.iterator();

      while (trainingProgramIter.hasNext()) {
        TrainingPartyCreateDetails trainingPartyCreateDetails = (TrainingPartyCreateDetails) trainingProgramIter.next();

        if (trainingPartyCreateDetails != null) {

          Element trainingElement = new Element(
            CPMWidgetHelperConstants.kTrainingElement);

          Element trainingIDElement = new Element(
            CPMWidgetHelperConstants.kTrainingIDElement);
          Attribute serviceOfferingIDDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kTrainingIDDomainValueAttribute);

          trainingIDElement.setAttribute(serviceOfferingIDDefaultValueAttribute);
          trainingIDElement.setText(
            String.valueOf(trainingPartyCreateDetails.trainingID));

          Element trainingNameElement = new Element(
            CPMWidgetHelperConstants.kTrainingNameElement);
          Attribute serviceOfferingNameDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kTrainingNameDomainValueAttribute);

          trainingNameElement.setAttribute(
            serviceOfferingNameDefaultValueAttribute);
          trainingNameElement.setText(trainingPartyCreateDetails.trainingName);

          Element unitAmountElement = new Element(
            CPMWidgetHelperConstants.kUnitAmountElement);
          Attribute unitAmountDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kUnitAmountDomainValueAttribute);

          unitAmountElement.setAttribute(unitAmountDefaultValueAttribute);
          unitAmountElement.setText(
            trainingPartyCreateDetails.unitAmount.toString());

          Element authorizedFromElement = new Element(
            CPMWidgetHelperConstants.kAuthorizedFromElement);
          Attribute authorizedFromDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kAuthorizedFromDomainValueAttribute);

          authorizedFromElement.setAttribute(
            authorizedFromDefaultValueAttribute);
          // BEGIN, CR00322912, GYH
          authorizedFromElement.setText(
            Locale.getFormattedDate(Date.getCurrentDate(), Locale.Date_ymd).toString());
          // END, CR00322912

          Element toBeCompletedByElement = new Element(
            CPMWidgetHelperConstants.kToBeCompletedByElement);
          Attribute toBeCompletedByDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.ktoBeCompletedByDomainValueAttribute);

          toBeCompletedByElement.setAttribute(
            toBeCompletedByDefaultValueAttribute);
          // BEGIN, CR00322912, GYH
          toBeCompletedByElement.setText(
            Locale.getFormattedDate(trainingPartyCreateDetails.toBeCompletedBy, Locale.Date_ymd).toString());
          // END, CR00322912
          
          trainingElement.addContent(trainingIDElement);
          trainingElement.addContent(trainingNameElement);
          trainingElement.addContent(unitAmountElement);
          trainingElement.addContent(authorizedFromElement);
          trainingElement.addContent(toBeCompletedByElement);

          rootElement.addContent(trainingElement);
        }
      }
    }

    Document document = new Document(rootElement);
    XMLOutputter xmlOutputter = new XMLOutputter();

    return xmlOutputter.outputString(document);

  }

  /**
   * Populates the member training program xml data received from widget to
   * Training Party Details list.
   *
   * @param concernRoleMemberDetails
   * This struct contains the details which needs to be provided to the
   * widget for display.
   * @return Training party create details List got from xml conversion.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_AUTHORIZED_DATE_IS_MANDATORY}
   * If the Authorized From Date is not entered.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_AUTHORIZEDFROMDATE_INVALID}
   * If the Authorized From Date entered is invalid.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_TOBECOMPLETEDBY_INVALID}
   * If the To Be Completed By Date entered is invalid.
   */
  public static TrainingPartyCreateDetailsList convertXmlToMemberTrainingProgram(
    ConcernRoleMemberDetails concernRoleMemberDetails) throws AppException,
      InformationalException {
    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    TrainingPartyCreateDetailsList trainingPartyCreateDetailsList = new TrainingPartyCreateDetailsList();

    String strTrainingEditorXml = concernRoleMemberDetails.memberTrainingWidget;

    InputStream inputStream = new ByteArrayInputStream(
      strTrainingEditorXml.getBytes());

    SAXBuilder sAXBuilder = new SAXBuilder();
    Document document = null;

    try {
      document = sAXBuilder.build(inputStream);
      Element rootElement = document.getRootElement();
      List trainingDetailsElements = rootElement.getChildren();
      Iterator trainingDetailsIter = trainingDetailsElements.iterator();

      while (trainingDetailsIter.hasNext()) {

        Element trainingDetailsElement = (Element) trainingDetailsIter.next();

        String trainingID = trainingDetailsElement.getChild(CPMWidgetHelperConstants.kTrainingIDElement).getText();

        String trainingName = trainingDetailsElement.getChild(CPMWidgetHelperConstants.kTrainingNameElement).getText();

        String strUnitAmount = trainingDetailsElement.getChild(CPMWidgetHelperConstants.kUnitAmountElement).getText();

        String strAuthorizedFrom = trainingDetailsElement.getChild(CPMWidgetHelperConstants.kAuthorizedFromElement).getText();

        String strToBeCompletedBy = trainingDetailsElement.getChild(CPMWidgetHelperConstants.kToBeCompletedByElement).getText();

        TrainingPartyCreateDetails trainingPartyCreateDetails = new TrainingPartyCreateDetails();

        trainingPartyCreateDetails.trainingID = Long.parseLong(trainingID);
        trainingPartyCreateDetails.trainingName = trainingName;

        if (strUnitAmount != null) {
          trainingPartyCreateDetails.unitAmount = new Money(strUnitAmount);
        }
        try {
          if (strAuthorizedFrom != null
            && !CPMConstants.kEmptyString.equals(strAuthorizedFrom)) {
            trainingPartyCreateDetails.authorizedFrom = Date.getDate(
              strAuthorizedFrom);
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_AUTHORIZED_DATE_IS_MANDATORY(),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
          }
        } catch (NumberFormatException numberFormatException) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_AUTHORIZEDFROMDATE_INVALID(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        }

        try {
          if (strToBeCompletedBy != null
            && !CPMConstants.kEmptyString.equals(strToBeCompletedBy)) {
            trainingPartyCreateDetails.toBeCompletedBy = Date.getDate(
              strToBeCompletedBy);
          } else {
            trainingPartyCreateDetails.toBeCompletedBy = Date.kZeroDate;
          }
        } catch (NumberFormatException numberFormatException) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_TOBECOMPLETEDBY_INVALID(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        }
        trainingPartyCreateDetailsList.detailsList.addRef(
          trainingPartyCreateDetails);

      }
      ValidationHelper.failIfErrorsExist();

    } catch (JDOMException e) {
      throw new AppException(WIDGET.ERR_JDOM_EXCEPTION, e);
    } catch (IOException e) {
      throw new AppException(WIDGET.ERR_IO_EXCEPTION, e);
    }

    return trainingPartyCreateDetailsList;
  }

  /**
   * Converts the list of Completed Training Program which are not managed
   * through agency to a xml. Domain definitions of each xml element is also
   * populated. The widget uses the xml data to display these details.
   *
   * @param trainingProgramPartyDetailsList
   * This struct contains the details which needs to be provided to the
   * widget for display.
   * @return String Xml containing list of Training Program details.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public static String convertRecordCompletedTrainingToXml(
    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList)
    throws InformationalException {

    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    Element rootElement = new Element(
      CPMWidgetHelperConstants.kRecordCompletedTrainingElement);

    // Check if the input list is empty and then form an xml with null
    // values.
    // Else if the input list is not empty then form an xml with the details
    // of the input list. The domain definition of each attribute in the
    // details struct is also populated in the xml.
    int size = trainingProgramPartyDetailsList.partyDetails.size();

    if (size == 0) {
      Element concernMemberElement = new Element(
        CPMWidgetHelperConstants.kConcernMemberElement);

      Element partyIDElement = new Element(
        CPMWidgetHelperConstants.kPartyIDElement);
      Attribute partyIDDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kPartyIDDomainValueAttribute);

      partyIDElement.setAttribute(partyIDDefaultValueAttribute);

      Element partyNameElement = new Element(
        CPMWidgetHelperConstants.kPartyNameElement);
      Attribute partyNameDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kPartyNameDomainValueAttribute);

      partyNameElement.setAttribute(partyNameDefaultValueAttribute);

      Element roleElement = new Element(CPMWidgetHelperConstants.kRoleElement);
      Attribute roleDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kRoleDomainValueAttribute);

      roleElement.setAttribute(roleDefaultValueAttribute);

      Element unitsCompletedElement = new Element(
        CPMWidgetHelperConstants.kUnitsCompletedElement);
      Attribute unitsCompletedDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kUnitsCompletedDomainValueAttribute);

      unitsCompletedElement.setAttribute(unitsCompletedDefaultValueAttribute);

      Element dateCompletedElement = new Element(
        CPMWidgetHelperConstants.kDateCompletedElement);
      Attribute dateCompletedDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kDateCompletedDomainValueAttribute);

      dateCompletedElement.setAttribute(dateCompletedDefaultValueAttribute);

      concernMemberElement.addContent(partyIDElement);
      concernMemberElement.addContent(partyNameElement);
      concernMemberElement.addContent(roleElement);
      concernMemberElement.addContent(unitsCompletedElement);
      concernMemberElement.addContent(dateCompletedElement);
      rootElement.addContent(concernMemberElement);
    } else {

      Iterator trainingProgramIter = trainingProgramPartyDetailsList.partyDetails.iterator();

      while (trainingProgramIter.hasNext()) {
        TrainingProgramPartyDetails trainingProgramPartyDetails = (TrainingProgramPartyDetails) trainingProgramIter.next();

        if (trainingProgramPartyDetails != null) {

          Element concernMemberElement = new Element(
            CPMWidgetHelperConstants.kConcernMemberElement);

          Element partyIDElement = new Element(
            CPMWidgetHelperConstants.kPartyIDElement);
          Attribute partyIDDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kPartyIDDomainValueAttribute);

          partyIDElement.setAttribute(partyIDDefaultValueAttribute);
          partyIDElement.setText(
            String.valueOf(trainingProgramPartyDetails.partyConcernRoleID));

          Element partyNameElement = new Element(
            CPMWidgetHelperConstants.kPartyNameElement);
          Attribute partyNameDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kPartyNameDomainValueAttribute);

          partyNameElement.setAttribute(partyNameDefaultValueAttribute);
          partyNameElement.setText(trainingProgramPartyDetails.partyName);

          Element roleElement = new Element(
            CPMWidgetHelperConstants.kRoleElement);
          Attribute roleDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kRoleDomainValueAttribute);

          roleElement.setAttribute(roleDefaultValueAttribute);
          roleElement.setText(trainingProgramPartyDetails.role);

          Element unitsCompletedElement = new Element(
            CPMWidgetHelperConstants.kUnitsCompletedElement);
          Attribute unitsCompletedDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kUnitsCompletedDomainValueAttribute);

          unitsCompletedElement.setAttribute(
            unitsCompletedDefaultValueAttribute);

          if (trainingProgramPartyDetails.unitsCompleted > 0) {
            unitsCompletedElement.setText(
              String.valueOf(trainingProgramPartyDetails.unitsCompleted));
          } else {
            unitsCompletedElement.setText(
              String.valueOf(CPMWidgetHelperConstants.kUnitsCompletedDefault));
          }

          Element dateCompletedElement = new Element(
            CPMWidgetHelperConstants.kDateCompletedElement);
          Attribute dateCompletedDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kDateCompletedDomainValueAttribute);

          dateCompletedElement.setAttribute(dateCompletedDefaultValueAttribute);
          if (!Date.kZeroDate.equals(trainingProgramPartyDetails.dateCompleted)) {
            // BEGIN, CR00322912, GYH
            dateCompletedElement.setText(
              Locale.getFormattedDate(trainingProgramPartyDetails.dateCompleted, Locale.Date_ymd).toString());
            // END, CR00322912
          }

          concernMemberElement.addContent(partyIDElement);
          concernMemberElement.addContent(partyNameElement);
          concernMemberElement.addContent(roleElement);
          concernMemberElement.addContent(unitsCompletedElement);
          concernMemberElement.addContent(dateCompletedElement);
          rootElement.addContent(concernMemberElement);
        }
      }
    }

    Document document = new Document(rootElement);
    XMLOutputter xmlOutputter = new XMLOutputter();

    return xmlOutputter.outputString(document);

  }

  /**
   * Populates the completed training program xml data received from widget to
   * training program party details list.
   *
   * @param strTrainingEditorXml
   * The xml which is returned from the widget and which has to be
   * parsed into list of Training Program Party Details objects.
   *
   * @return List containing the Training Program Party Details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_UNITSCOMPLETED_INVALID}
   * If the Units Completed entered is invalid.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_DATECOMPLETED_INVALID}
   * If the Date Completed entered is invalid.
   */
  public static TrainingProgramPartyDetailsList convertXmlToRecordCompletedTraining(
    String strTrainingEditorXml) throws AppException, InformationalException {
    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList = new TrainingProgramPartyDetailsList();

    InputStream inputStream = new ByteArrayInputStream(
      strTrainingEditorXml.getBytes());

    SAXBuilder sAXBuilder = new SAXBuilder();
    Document document = null;

    try {
      document = sAXBuilder.build(inputStream);
      Element rootElement = document.getRootElement();
      List trainingProgramElements = rootElement.getChildren();
      Iterator trainingProgramIter = trainingProgramElements.iterator();

      while (trainingProgramIter.hasNext()) {

        Element concernMemberElement = (Element) trainingProgramIter.next();

        String partyID = concernMemberElement.getChild(CPMWidgetHelperConstants.kPartyIDElement).getText();

        String partyName = concernMemberElement.getChild(CPMWidgetHelperConstants.kPartyNameElement).getText();

        String role = concernMemberElement.getChild(CPMWidgetHelperConstants.kRoleElement).getText();

        String unitsCompleted = concernMemberElement.getChild(CPMWidgetHelperConstants.kUnitsCompletedElement).getText();

        String dateCompleted = concernMemberElement.getChild(CPMWidgetHelperConstants.kDateCompletedElement).getText();

        TrainingProgramPartyDetails trainingProgramPartyDetails = new TrainingProgramPartyDetails();

        trainingProgramPartyDetails.partyConcernRoleID = Long.parseLong(partyID);
        trainingProgramPartyDetails.partyName = partyName;
        trainingProgramPartyDetails.role = role;
        try {
          trainingProgramPartyDetails.unitsCompleted = Short.parseShort(
            unitsCompleted);
        } catch (NumberFormatException numberFormatException) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_UNITSCOMPLETED_INVALID(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
        }
        try {
          if (dateCompleted != null
            && !CPMConstants.kEmptyString.equals(dateCompleted)) {
            trainingProgramPartyDetails.dateCompleted = Date.getDate(
              dateCompleted);
          } else {
            trainingProgramPartyDetails.dateCompleted = Date.kZeroDate;
          }
        } catch (NumberFormatException numberFormatException) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_DATECOMPLETED_INVALID(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
        }

        trainingProgramPartyDetailsList.partyDetails.addRef(
          trainingProgramPartyDetails);

      }

      ValidationHelper.failIfErrorsExist();

    } catch (JDOMException e) {
      throw new AppException(WIDGET.ERR_JDOM_EXCEPTION, e);
    } catch (IOException e) {
      throw new AppException(WIDGET.ERR_IO_EXCEPTION, e);
    }

    return trainingProgramPartyDetailsList;
  }

  /**
   * Converts the list of Daily Attendance Details to a xml. Domain definitions
   * of each xml element is also populated. The widget uses the xml data to
   * display these details.
   *
   * @param dailyAttendanceDetailsList
   * List containing the daily attendance details.
   * @return Xml string containing the data of the list of Daily Attendance
   * details.
   */
  public static String convertDailyAttendanceToXml(
    DailyAttendanceDetailsList dailyAttendanceDetailsList) {

    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    Element rootElement = new Element(
      CPMWidgetHelperConstants.kConcernMemberDailyAttendanceElement);

    // Check if the input list is empty and then form an xml with null
    // values.
    // Else if the input list is not empty then form an xml with the details
    // of
    // the input list. The domain definition of each attribute in the
    // details
    // struct is also populated in the xml.
    int size = dailyAttendanceDetailsList.details.size();

    if (size == 0) {
      Element dailyAttendanceMemberElement = new Element(
        CPMWidgetHelperConstants.kDailyAttendanceElement);

      Element attendanceIDElement = new Element(
        CPMWidgetHelperConstants.kAttendanceIDElement);
      Attribute attendanceIDDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kAttendanceIDDomainValueAttribute);

      attendanceIDElement.setAttribute(attendanceIDDomainValueAttribute);

      Element versionNumberElement = new Element(
        CPMWidgetHelperConstants.kDailyAttendanceVersionNumberElement);
      Attribute versionNumberDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kDailyAttendanceVersionNumberDomainValueAttribute);

      versionNumberElement.setAttribute(versionNumberDomainValueAttribute);

      Element attendanceDateElement = new Element(
        CPMWidgetHelperConstants.kAttendanceDateElement);
      Attribute attendanceDateDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kAttendanceDateDomainValueAttribute);

      attendanceDateElement.setAttribute(attendanceDateDomainValueAttribute);

      Element attendanceElement = new Element(
        CPMWidgetHelperConstants.kAttendanceElement);
      Attribute attendanceDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kAttendanceDomainValueAttribute);

      attendanceElement.setAttribute(attendanceDomainValueAttribute);

      Element absenceReasonElement = new Element(
        CPMWidgetHelperConstants.kAbsenceReasonElement);
      Attribute absenceReasonDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kAbsenceReasonDomainValueAttribute);

      absenceReasonElement.setAttribute(absenceReasonDefaultValueAttribute);

      Element expectedUnitsElement = new Element(
        CPMWidgetHelperConstants.kExpectedUnitsElement);
      Attribute expectedUnitsDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kExpectedUnitsDomainValueAttribute);

      expectedUnitsElement.setAttribute(expectedUnitsDomainValueAttribute);

      Element unitsAttendedElement = new Element(
        CPMWidgetHelperConstants.kUnitsAttendedElement);
      Attribute unitsAttendedDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kUnitsAttendedDomainValueAttribute);

      unitsAttendedElement.setAttribute(unitsAttendedDomainValueAttribute);

      Element unitsUnAttendedElement = new Element(
        CPMWidgetHelperConstants.kUnitsUnAttendedElement);
      Attribute unitsUnAttendedDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kUnitsUnAttendedDomainValueAttribute);

      unitsUnAttendedElement.setAttribute(unitsUnAttendedDomainValueAttribute);

      dailyAttendanceMemberElement.addContent(attendanceIDElement);
      dailyAttendanceMemberElement.addContent(versionNumberElement);
      dailyAttendanceMemberElement.addContent(attendanceDateElement);
      dailyAttendanceMemberElement.addContent(attendanceElement);
      dailyAttendanceMemberElement.addContent(absenceReasonElement);
      dailyAttendanceMemberElement.addContent(expectedUnitsElement);
      dailyAttendanceMemberElement.addContent(unitsAttendedElement);
      dailyAttendanceMemberElement.addContent(unitsUnAttendedElement);
      rootElement.addContent(dailyAttendanceMemberElement);
    } else {

      Iterator dailyAttendanceIter = dailyAttendanceDetailsList.details.iterator();

      while (dailyAttendanceIter.hasNext()) {
        DailyAttendanceDetails dailyAttendanceDetails = (DailyAttendanceDetails) dailyAttendanceIter.next();

        if (dailyAttendanceDetails != null) {

          Element dailyAttendanceMemberElement = new Element(
            CPMWidgetHelperConstants.kDailyAttendanceElement);

          Element attendanceIDElement = new Element(
            CPMWidgetHelperConstants.kAttendanceIDElement);
          Attribute attendanceIDDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kAttendanceIDDomainValueAttribute);

          attendanceIDElement.setAttribute(attendanceIDDomainValueAttribute);
          attendanceIDElement.setText(
            String.valueOf(dailyAttendanceDetails.dtls.dailyAttendanceID));

          Element versionNumberElement = new Element(
            CPMWidgetHelperConstants.kDailyAttendanceVersionNumberElement);
          Attribute versionNumberDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kDailyAttendanceVersionNumberDomainValueAttribute);

          versionNumberElement.setAttribute(versionNumberDomainValueAttribute);
          versionNumberElement.setText(
            String.valueOf(dailyAttendanceDetails.dtls.versionNo));

          Element attendanceDateElement = new Element(
            CPMWidgetHelperConstants.kAttendanceDateElement);
          Attribute attendanceDateDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kAttendanceDateDomainValueAttribute);

          attendanceDateElement.setAttribute(attendanceDateDomainValueAttribute);
          attendanceDateElement.setText(
            String.valueOf(dailyAttendanceDetails.serviceDateString));

          Element attendanceElement = new Element(
            CPMWidgetHelperConstants.kAttendanceElement);
          Attribute attendanceDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kAttendanceDomainValueAttribute);

          attendanceElement.setAttribute(attendanceDomainValueAttribute);
          attendanceElement.setText(dailyAttendanceDetails.dtls.attendance);

          Element absenceReasonElement = new Element(
            CPMWidgetHelperConstants.kAbsenceReasonElement);
          Attribute absenceReasonDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kAbsenceReasonDomainValueAttribute);

          absenceReasonElement.setAttribute(absenceReasonDefaultValueAttribute);
          absenceReasonElement.setText(
            dailyAttendanceDetails.dtls.absenceReason);

          Element expectedUnitsElement = new Element(
            CPMWidgetHelperConstants.kExpectedUnitsElement);
          Attribute expectedUnitsDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kExpectedUnitsDomainValueAttribute);

          expectedUnitsElement.setAttribute(expectedUnitsDomainValueAttribute);
          expectedUnitsElement.setText(
            dailyAttendanceDetails.expectedUnitsString);

          Element unitsAttendedElement = new Element(
            CPMWidgetHelperConstants.kUnitsAttendedElement);
          Attribute unitsAttendedDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kUnitsAttendedDomainValueAttribute);

          unitsAttendedElement.setAttribute(unitsAttendedDomainValueAttribute);
          unitsAttendedElement.setText(
            dailyAttendanceDetails.unitsAttendedString);

          Element unitsUnAttendedElement = new Element(
            CPMWidgetHelperConstants.kUnitsUnAttendedElement);
          Attribute unitsUnAttendedDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kUnitsUnAttendedDomainValueAttribute);

          unitsUnAttendedElement.setAttribute(
            unitsUnAttendedDomainValueAttribute);
          unitsUnAttendedElement.setText(
            dailyAttendanceDetails.unitsUnAttendedString);

          dailyAttendanceMemberElement.addContent(attendanceIDElement);
          dailyAttendanceMemberElement.addContent(versionNumberElement);
          dailyAttendanceMemberElement.addContent(attendanceDateElement);
          dailyAttendanceMemberElement.addContent(attendanceElement);
          dailyAttendanceMemberElement.addContent(absenceReasonElement);
          dailyAttendanceMemberElement.addContent(expectedUnitsElement);
          dailyAttendanceMemberElement.addContent(unitsAttendedElement);
          dailyAttendanceMemberElement.addContent(unitsUnAttendedElement);
          rootElement.addContent(dailyAttendanceMemberElement);
        }
      }
    }

    Document document = new Document(rootElement);
    XMLOutputter xmlOutputter = new XMLOutputter();
    
    return xmlOutputter.outputString(document);

  }

  /**
   * Parses the xml containing attendance details list received from Daily
   * Attendance widget to Daily Attendance details List.
   *
   * @param dailyAttendanceDetailsList
   * xml containing the data of list of daily attendance details.
   * @return DailyAttendanceDetailsList List containing the Attendance Details.
   *
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_FV_UNITS_UNATTENDED_MUST_BE_WHOLE_NUMBER}
   * If the Units Not Attended is not a whole number.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT}
   * Units Not Attended must not be entered if Attendance is Present.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_ABSENT}
   * Units Attended must not be entered if the Attendance is entered
   * as Absent.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_FV_INVALID_UNITS_NOT_ATTENDED}
   * If the Units Not Attended are invalid.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_BE_GREATER_THAN_ZERO_IF_ATTENDANCE_IS_PRESENT_OR_PARTIALLY_PRESENT}
   * Units Attended must be greater than zero if Attendance is either
   * Present or Partially Present.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_FV_UNITS_ATTENDED_MUST_BE_WHOLE_NUMBER}
   * Units Attended must be a whole number.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_FV_INVALID_UNITS_ATTENDED} If
   * the Units Attended are invalid.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_BE_GREATER_THAN_ZERO_IF_ATTENDANCE_IS_ABSENT_OR_PARTIALLY_PRESENT}
   * Units Not Attended must be greater than zero if Attendance is
   * Absent or Partially Present.
   */
  public static DailyAttendanceDetailsList convertXmlToAttendanceDetailsList(
    String dailyAttendanceDetailsList) throws AppException,
      InformationalException {
    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    DailyAttendanceDetailsList attendanceDetailsList = new DailyAttendanceDetailsList();

    String strDailyAttendanceXml = dailyAttendanceDetailsList;

    InputStream inputStream = new ByteArrayInputStream(
      strDailyAttendanceXml.getBytes());

    SAXBuilder sAXBuilder = new SAXBuilder();
    Document document = null;

    // The xml string which is received from the Daily Attendance widget is
    // parsed
    // using the SAX parser and the modified values of the daily attendance
    // records are
    // populated into a list of daily attendance details.
    try {
      document = sAXBuilder.build(inputStream);
      Element rootElement = document.getRootElement();
      List dailyAttendanceElements = rootElement.getChildren();
      Iterator dailyAttendanceIter = dailyAttendanceElements.iterator();

      while (dailyAttendanceIter.hasNext()) {

        // long keyValue = UniqueID.nextUniqueID();
        Element dailyAttendanceElement = (Element) dailyAttendanceIter.next();

        String attendanceID = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kAttendanceIDElement).getText();

        String versionNo = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kDailyAttendanceVersionNumberElement).getText();

        String attendance = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kAttendanceElement).getText();

        String absenceReason = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kAbsenceReasonElement).getText();

        String unitsAttended = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kUnitsAttendedElement).getText();

        String unitsUnAttended = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kUnitsUnAttendedElement).getText();

        String serviceDateString = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kAttendanceDateElement).getText();

        DailyAttendanceDetails attendanceDetails = new DailyAttendanceDetails();

        attendanceDetails.dtls.dailyAttendanceID = Long.parseLong(attendanceID);
        attendanceDetails.dtls.versionNo = Integer.parseInt(versionNo);
        attendanceDetails.dtls.attendance = attendance.trim();
        attendanceDetails.dtls.absenceReason = absenceReason.trim();

        // BEGIN, CR00148197, RD
        if (!CPMConstants.kEmptyString.equals(unitsAttended)) {
          String trimmedUnitsAttended = unitsAttended.trim();

          try {
            if (Short.parseShort(trimmedUnitsAttended) <= 0
              && ATTENDANCEEntry.ABSENT.getCode().equals(
                attendanceDetails.dtls.attendance)) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_ABSENT(),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                3);
            } else if (Short.parseShort(trimmedUnitsAttended) <= 0) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_BE_GREATER_THAN_ZERO_IF_ATTENDANCE_IS_PRESENT_OR_PARTIALLY_PRESENT(),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
            } else {
              attendanceDetails.dtls.unitsAttended = Short.parseShort(
                trimmedUnitsAttended);
            }
          } catch (NumberFormatException numberFormatException) {
            if (ATTENDANCEEntry.ABSENT.getCode().equals(
              attendanceDetails.dtls.attendance)) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_ABSENT(),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                2);
            } else {

              int indexOfDot = -1;

              indexOfDot = trimmedUnitsAttended.indexOf(CuramConst.gkDotChar);

              if ((trimmedUnitsAttended.length() > 5) && (indexOfDot >= 0)) {
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                  ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_ATTENDED_MUST_BE_WHOLE_NUMBER(
                    trimmedUnitsAttended),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                    1);
              } else if (trimmedUnitsAttended.length() > 5) {
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                  ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_INVALID_UNITS_ATTENDED(
                    trimmedUnitsAttended),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                    1);
              } else if ((trimmedUnitsAttended.length() <= 5)
                && (indexOfDot >= 0)) {
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                  ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_ATTENDED_MUST_BE_WHOLE_NUMBER(
                    trimmedUnitsAttended),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                    0);
              } else {
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                  ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_INVALID_UNITS_ATTENDED(
                    trimmedUnitsAttended),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                    0);
              }
            }
          }
        }

        if (!CPMConstants.kEmptyString.equals(unitsUnAttended)) {
          String trimUnitsUnAttended = unitsUnAttended.trim();

          try {

            if (Short.parseShort(trimUnitsUnAttended) <= 0
              && ATTENDANCEEntry.PRESENT.getCode().equals(
                attendanceDetails.dtls.attendance)) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT(),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                3);
            } else if (Short.parseShort(trimUnitsUnAttended) <= 0) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_BE_GREATER_THAN_ZERO_IF_ATTENDANCE_IS_ABSENT_OR_PARTIALLY_PRESENT(),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
            } else {
              attendanceDetails.dtls.unitsUnattended = Short.parseShort(
                trimUnitsUnAttended);
            }
          } catch (NumberFormatException numberFormatException) {
            if (ATTENDANCEEntry.PRESENT.getCode().equals(
              attendanceDetails.dtls.attendance)) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_UNITS_NOT_ATTENDED_MUST_NOT_BE_ENTERED_IF_ATTENDANCE_IS_PRESENT(),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                2);

            } else {

              int indexOfDot = -1;

              indexOfDot = trimUnitsUnAttended.indexOf(CuramConst.gkDotChar);

              if ((trimUnitsUnAttended.length() > 5) && (indexOfDot >= 0)) {
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                  ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_UNATTENDED_MUST_BE_WHOLE_NUMBER(
                    trimUnitsUnAttended),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                    0);
              } else if (trimUnitsUnAttended.length() > 5) {
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                  ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_INVALID_UNITS_NOT_ATTENDED(
                    trimUnitsUnAttended),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                    0);
              } else if ((trimUnitsUnAttended.length() <= 5)
                && (indexOfDot >= 0)) {
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                  ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_UNATTENDED_MUST_BE_WHOLE_NUMBER(
                    trimUnitsUnAttended),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                    1);
              } else {
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                  ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_INVALID_UNITS_NOT_ATTENDED(
                    trimUnitsUnAttended),
                    curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                    1);
              }
            }
            // END, CR00148197
            ValidationHelper.failIfErrorsExist();
          }
        }
        // BEGIN, CR00303745, SSK
        attendanceDetails.dtls.serviceDate = curam.util.type.Date.fromISO8601(
          serviceDateString);
        // END, CR00303745


        attendanceDetailsList.details.addRef(attendanceDetails);

      }
      ValidationHelper.failIfErrorsExist();

    } catch (JDOMException e) {
      throw new AppException(WIDGET.ERR_JDOM_EXCEPTION, e);
    } catch (IOException e) {
      throw new AppException(WIDGET.ERR_IO_EXCEPTION, e);
    }

    return attendanceDetailsList;
  }

  /**
   * Converts the list of provider roster line item details to xml and this xml
   * forms the input to the Update Roster widget.
   *
   * @param providerRosterLineItemDetailsList
   * List of provider roster line item details.
   * @return Xml string containing the data of list of provider roster line item
   * details.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public static String convertUpdateRosterToXml(
    ProviderRosterLineItemDetailsList providerRosterLineItemDetailsList)
    throws InformationalException {

    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    Element rootElement = new Element(
      CPMWidgetHelperConstants.kUpdateRosterElement);

    // Check if the input list is empty and then form an xml with null values.
    // Else if the input list is not empty then form an xml with the details of
    // the input list. The domain definition of each attribute in the details
    // struct is also populated in the xml.
    int size = providerRosterLineItemDetailsList.details.size();

    if (size == 0) {
      Element rosterElement = new Element(
        CPMWidgetHelperConstants.kRosterElement);

      Element providerRosterLineItemIDElement = new Element(
        CPMWidgetHelperConstants.kProviderRosterLineItemIDElement);
      Attribute providerRosterLineItemIDDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kProviderRosterLineItemIDDomainValueAttribute);

      providerRosterLineItemIDElement.setAttribute(
        providerRosterLineItemIDDomainValueAttribute);
      Attribute readOnlyAttribute = new Attribute(
        CPMWidgetHelperConstants.kreadOnlyAttribute, GeneralConstants.kFalse);

      providerRosterLineItemIDElement.setAttribute(readOnlyAttribute);

      Element caseReferenceNoElement = new Element(
        CPMWidgetHelperConstants.kCaseReferenceNoElement);
      Attribute referenceNoDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kReferenceNoDomainValueAttribute);

      caseReferenceNoElement.setAttribute(referenceNoDomainValueAttribute);
      Attribute caseReferenceNoreadOnlyAttribute = new Attribute(
        CPMWidgetHelperConstants.kreadOnlyAttribute, GeneralConstants.kFalse);

      caseReferenceNoElement.setAttribute(caseReferenceNoreadOnlyAttribute);

      Element prliVersionNumberElement = new Element(
        CPMWidgetHelperConstants.kPRLIVersionNumberElement);
      Attribute prliVersionNumberDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kPRLIVersionNumberDomainValueAttribute);

      prliVersionNumberElement.setAttribute(
        prliVersionNumberDomainValueAttribute);
      Attribute prliVersionNumberreadOnlyAttribute = new Attribute(
        CPMWidgetHelperConstants.kreadOnlyAttribute, GeneralConstants.kFalse);

      prliVersionNumberElement.setAttribute(prliVersionNumberreadOnlyAttribute);

      Element rliVersionNumberElement = new Element(
        CPMWidgetHelperConstants.kRLIVersionNumberElement);
      Attribute rliVersionNumberDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kRLIVersionNumberDomainValueAttribute);

      rliVersionNumberElement.setAttribute(rliVersionNumberDomainValueAttribute);
      Attribute rliVersionNumberreadOnlyAttribute = new Attribute(
        CPMWidgetHelperConstants.kreadOnlyAttribute, GeneralConstants.kFalse);

      rliVersionNumberElement.setAttribute(rliVersionNumberreadOnlyAttribute);

      Element concernRoleIDElement = new Element(
        CPMWidgetHelperConstants.kConcernRoleIDElement);
      Attribute concernRoleIDDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kConcernRoleIDDomainValueAttribute);

      concernRoleIDElement.setAttribute(concernRoleIDDomainValueAttribute);
      Attribute concernRoleIDreadOnlyAttribute = new Attribute(
        CPMWidgetHelperConstants.kreadOnlyAttribute, GeneralConstants.kFalse);

      concernRoleIDElement.setAttribute(concernRoleIDreadOnlyAttribute);

      Element clientElement = new Element(
        CPMWidgetHelperConstants.kClientElement);
      Attribute clientDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kClientElementDomainValueAttribute);

      clientElement.setAttribute(clientDomainValueAttribute);
      Attribute clientreadOnlyAttribute = new Attribute(
        CPMWidgetHelperConstants.kreadOnlyAttribute, GeneralConstants.kFalse);

      clientElement.setAttribute(clientreadOnlyAttribute);

      Element serviceFromElement = new Element(
        CPMWidgetHelperConstants.kServicefromElement);
      Attribute serviceFromDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kServiceFromDomainValueAttribute);

      serviceFromElement.setAttribute(serviceFromDomainValueAttribute);
      Attribute serviceFromreadOnlyAttribute = new Attribute(
        CPMWidgetHelperConstants.kreadOnlyAttribute, GeneralConstants.kFalse);

      serviceFromElement.setAttribute(serviceFromreadOnlyAttribute);

      Element serviceToElement = new Element(
        CPMWidgetHelperConstants.kServicetoElement);
      Attribute serviceToDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kServiceToDomainValueAttribute);

      serviceToElement.setAttribute(serviceToDomainValueAttribute);
      Attribute serviceToreadOnlyAttribute = new Attribute(
        CPMWidgetHelperConstants.kreadOnlyAttribute, GeneralConstants.kFalse);

      serviceToElement.setAttribute(serviceToreadOnlyAttribute);

      Element authRefNoElement = new Element(
        CPMWidgetHelperConstants.kAuthorizationReferenceNumberElement);
      Attribute authRefNoDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kAuthRefNoDomainValueAttribute);

      authRefNoElement.setAttribute(authRefNoDomainValueAttribute);
      Attribute authRefNoreadOnlyAttribute = new Attribute(
        CPMWidgetHelperConstants.kreadOnlyAttribute, GeneralConstants.kFalse);

      authRefNoElement.setAttribute(authRefNoreadOnlyAttribute);

      Element voucherNumberElement = new Element(
        CPMWidgetHelperConstants.kVoucherNumberElement);
      Attribute unitsAttendedDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kVoucherNoDomainValueAttribute);

      voucherNumberElement.setAttribute(unitsAttendedDomainValueAttribute);
      Attribute voucherNumberreadOnlyAttribute = new Attribute(
        CPMWidgetHelperConstants.kreadOnlyAttribute, GeneralConstants.kFalse);

      voucherNumberElement.setAttribute(voucherNumberreadOnlyAttribute);

      Element expectedUnitsElement = new Element(
        CPMWidgetHelperConstants.kExpectedUnitsElement);
      Attribute expectedUnitsDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kExpectedUnitsDomainValueAttribute);

      expectedUnitsElement.setAttribute(expectedUnitsDomainValueAttribute);
      Attribute expectedUnitsreadOnlyAttribute = new Attribute(
        CPMWidgetHelperConstants.kreadOnlyAttribute, GeneralConstants.kFalse);

      expectedUnitsElement.setAttribute(expectedUnitsreadOnlyAttribute);

      Element actualUnitsElement = new Element(
        CPMWidgetHelperConstants.kActualunitsElement);
      Attribute actualUnitsDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kActualUnitsDomainValueAttribute);

      actualUnitsElement.setAttribute(actualUnitsDomainValueAttribute);
      Attribute actualUnitsreadOnlyAttribute = new Attribute(
        CPMWidgetHelperConstants.kreadOnlyAttribute, GeneralConstants.kFalse);

      actualUnitsElement.setAttribute(actualUnitsreadOnlyAttribute);

      rosterElement.addContent(providerRosterLineItemIDElement);
      rosterElement.addContent(caseReferenceNoElement);
      rosterElement.addContent(prliVersionNumberElement);
      rosterElement.addContent(rliVersionNumberElement);
      rosterElement.addContent(concernRoleIDElement);
      rosterElement.addContent(clientElement);
      rosterElement.addContent(serviceFromElement);
      rosterElement.addContent(serviceToElement);
      rosterElement.addContent(authRefNoElement);
      rosterElement.addContent(voucherNumberElement);
      rosterElement.addContent(expectedUnitsElement);
      rosterElement.addContent(actualUnitsElement);
      rootElement.addContent(rosterElement);
    } else {

      Iterator updateRosterIter = providerRosterLineItemDetailsList.details.iterator();

      while (updateRosterIter.hasNext()) {
        ProviderRosterLineItemDetails updateRosterDetails = (ProviderRosterLineItemDetails) updateRosterIter.next();

        if (updateRosterDetails != null) {

          Element rosterElement = new Element(
            CPMWidgetHelperConstants.kRosterElement);

          Element providerRosterLineItemIDElement = new Element(
            CPMWidgetHelperConstants.kProviderRosterLineItemIDElement);
          Attribute providerRosterLineItemIDDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kProviderRosterLineItemIDDomainValueAttribute);

          providerRosterLineItemIDElement.setAttribute(
            providerRosterLineItemIDDomainValueAttribute);
          Attribute providerRosterLineItemIDReadOnlyAttribute = new Attribute(
            CPMWidgetHelperConstants.kreadOnlyAttribute,
            GeneralConstants.kFalse);

          providerRosterLineItemIDElement.setText(
            String.valueOf(
              updateRosterDetails.providerRosterLineItemDtls.providerRosterLineItemID));
          providerRosterLineItemIDElement.setAttribute(
            providerRosterLineItemIDReadOnlyAttribute);

          Element caseReferenceNoElement = new Element(
            CPMWidgetHelperConstants.kCaseReferenceNoElement);
          Attribute referenceNoDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kReferenceNoDomainValueAttribute);

          caseReferenceNoElement.setAttribute(referenceNoDomainValueAttribute);
          caseReferenceNoElement.setText(
            updateRosterDetails.providerRosterLineItemDtls.caseReferenceNo);
          Attribute caseRefNoReadOnlyAttribute = new Attribute(
            CPMWidgetHelperConstants.kreadOnlyAttribute,
            String.valueOf(
              updateRosterDetails.providerRosterLineItemDtls.autoGeneratedInd));

          caseReferenceNoElement.setAttribute(caseRefNoReadOnlyAttribute);

          Element prliVersionNumberElement = new Element(
            CPMWidgetHelperConstants.kPRLIVersionNumberElement);
          Attribute prliVersionNumberDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kPRLIVersionNumberDomainValueAttribute);

          prliVersionNumberElement.setAttribute(
            prliVersionNumberDomainValueAttribute);
          Attribute prliVersionNumberReadOnlyAttribute = new Attribute(
            CPMWidgetHelperConstants.kreadOnlyAttribute,
            GeneralConstants.kFalse);

          prliVersionNumberElement.setAttribute(
            prliVersionNumberReadOnlyAttribute);
          prliVersionNumberElement.setText(
            String.valueOf(
              updateRosterDetails.providerRosterLineItemDtls.versionNo));

          Element rliVersionNumberElement = new Element(
            CPMWidgetHelperConstants.kRLIVersionNumberElement);
          Attribute rliVersionNumberDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kRLIVersionNumberDomainValueAttribute);

          rliVersionNumberElement.setAttribute(
            rliVersionNumberDomainValueAttribute);
          Attribute rliVersionNumberReadOnlyAttribute = new Attribute(
            CPMWidgetHelperConstants.kreadOnlyAttribute,
            GeneralConstants.kFalse);

          rliVersionNumberElement.setText(
            String.valueOf(updateRosterDetails.rosterLineItemDtls.versionNo));
          rliVersionNumberElement.setAttribute(
            rliVersionNumberReadOnlyAttribute);

          Element concernRoleIDElement = new Element(
            CPMWidgetHelperConstants.kConcernRoleIDElement);
          Attribute concernRoleIDDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kConcernRoleIDDomainValueAttribute);

          concernRoleIDElement.setAttribute(concernRoleIDDomainValueAttribute);
          Attribute concernRoleIDReadOnlyAttribute = new Attribute(
            CPMWidgetHelperConstants.kreadOnlyAttribute,
            GeneralConstants.kFalse);

          concernRoleIDElement.setText(
            String.valueOf(updateRosterDetails.rosterLineItemDtls.concernRoleID));
          concernRoleIDElement.setAttribute(concernRoleIDReadOnlyAttribute);

          Element clientElement = new Element(
            CPMWidgetHelperConstants.kClientElement);
          Attribute clientDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kClientElementDomainValueAttribute);

          clientElement.setAttribute(clientDomainValueAttribute);
          Attribute clientReadOnlyAttribute = new Attribute(
            CPMWidgetHelperConstants.kreadOnlyAttribute,
            GeneralConstants.kFalse);

          clientElement.setText(updateRosterDetails.clientName);
          clientElement.setAttribute(clientReadOnlyAttribute);

          Element serviceFromElement = new Element(
            CPMWidgetHelperConstants.kServicefromElement);
          Attribute serviceFromDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kServiceFromDomainValueAttribute);

          serviceFromElement.setAttribute(serviceFromDomainValueAttribute);
          Attribute serviceFromReadOnlyAttribute = new Attribute(
            CPMWidgetHelperConstants.kreadOnlyAttribute,
            GeneralConstants.kFalse);
          
          // BEGIN, CR00322912, GYH
          serviceFromElement.setText(
            Locale.getFormattedDate(updateRosterDetails.rosterLineItemDtls.serviceFrom, Locale.Date_ymd).toString());
          // END, CR00322912

          serviceFromElement.setAttribute(serviceFromReadOnlyAttribute);
          
          Element serviceToElement = new Element(
            CPMWidgetHelperConstants.kServicetoElement);
          Attribute serviceToDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kServiceToDomainValueAttribute);

          serviceToElement.setAttribute(serviceToDomainValueAttribute);
          Attribute serviceToReadOnlyAttribute = new Attribute(
            CPMWidgetHelperConstants.kreadOnlyAttribute,
            GeneralConstants.kFalse);

          // BEGIN, CR00322912, GYH
          serviceToElement.setText(
            Locale.getFormattedDate(updateRosterDetails.rosterLineItemDtls.serviceTo, Locale.Date_ymd).toString());
          // END, CR00322912
          
          serviceToElement.setAttribute(serviceToReadOnlyAttribute);

          Element authRefNoElement = new Element(
            CPMWidgetHelperConstants.kAuthorizationReferenceNumberElement);
          Attribute authRefNoDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kAuthRefNoDomainValueAttribute);

          authRefNoElement.setAttribute(authRefNoDomainValueAttribute);
          authRefNoElement.setText(
            updateRosterDetails.providerRosterLineItemDtls.saReferenceNo);
          Attribute authRefNoReadOnlyAttribute = new Attribute(
            CPMWidgetHelperConstants.kreadOnlyAttribute,
            String.valueOf(
              updateRosterDetails.providerRosterLineItemDtls.autoGeneratedInd));

          authRefNoElement.setAttribute(authRefNoReadOnlyAttribute);

          Element voucherNumberElement = new Element(
            CPMWidgetHelperConstants.kVoucherNumberElement);
          Attribute unitsAttendedDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kVoucherNoDomainValueAttribute);

          voucherNumberElement.setAttribute(unitsAttendedDomainValueAttribute);
          Attribute voucherNumberReadOnlyAttribute = new Attribute(
            CPMWidgetHelperConstants.kreadOnlyAttribute,
            GeneralConstants.kFalse);

          voucherNumberElement.setText(
            updateRosterDetails.providerRosterLineItemDtls.voucherNumber);
          voucherNumberElement.setAttribute(voucherNumberReadOnlyAttribute);

          Element expectedUnitsElement = new Element(
            CPMWidgetHelperConstants.kExpectedUnitsElement);
          Attribute expectedUnitsDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kExpectedUnitsDomainValueAttribute);

          expectedUnitsElement.setAttribute(expectedUnitsDomainValueAttribute);
          Attribute expectedUnitsReadOnlyAttribute = new Attribute(
            CPMWidgetHelperConstants.kreadOnlyAttribute,
            GeneralConstants.kFalse);

          expectedUnitsElement.setText(
            String.valueOf(updateRosterDetails.rosterLineItemDtls.expectedUnits));
          expectedUnitsElement.setAttribute(expectedUnitsReadOnlyAttribute);

          Element actualUnitsElement = new Element(
            CPMWidgetHelperConstants.kActualunitsElement);
          Attribute actualUnitsDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kActualUnitsDomainValueAttribute);

          actualUnitsElement.setAttribute(actualUnitsDomainValueAttribute);
          Attribute actualUnitsReadOnlyAttribute = new Attribute(
            CPMWidgetHelperConstants.kreadOnlyAttribute,
            GeneralConstants.kFalse);

          // BEGIN, CR00127676, NK
          if (updateRosterDetails.rosterLineItemDtls.totalUnitsDelivered > 0) {
            actualUnitsElement.setText(
              String.valueOf(
                updateRosterDetails.rosterLineItemDtls.totalUnitsDelivered));
          }
          // END, CR00127676
          actualUnitsElement.setAttribute(actualUnitsReadOnlyAttribute);

          rosterElement.addContent(providerRosterLineItemIDElement);
          rosterElement.addContent(caseReferenceNoElement);
          rosterElement.addContent(prliVersionNumberElement);
          rosterElement.addContent(rliVersionNumberElement);
          rosterElement.addContent(concernRoleIDElement);
          rosterElement.addContent(clientElement);
          rosterElement.addContent(serviceFromElement);
          rosterElement.addContent(serviceToElement);
          rosterElement.addContent(authRefNoElement);
          rosterElement.addContent(voucherNumberElement);
          rosterElement.addContent(expectedUnitsElement);
          rosterElement.addContent(actualUnitsElement);
          rootElement.addContent(rosterElement);
        }
      }
    }

    Document document = new Document(rootElement);
    XMLOutputter xmlOutputter = new XMLOutputter();

    return xmlOutputter.outputString(document);

  }

  /**
   * Parses the xml data which is received from the Update Roster Widget to
   * Provider Roster Line Item Details List.
   *
   * @param updateProviderRosterLineItemString
   * xml which is received from the Update Roster widget.
   * @return ProviderRosterLineItemDetailsList List of Provider Roster Line Item
   * Details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_FV_INVALID_ACTUAL_UNITS} If
   * the Actual Units are invalid.
   *
   * {@link ROSTER#ERR_ROSTER_FV_ACTUAL_UNITS_MUST_BE_WHOLE_NUMBER} If
   * the Actual Units entered is not a whole number.
   *
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_MUST_BE_GT_ZERO} If
   * the Actual Units entered is not greater than zero.
   */
  public static ProviderRosterLineItemDetailsList convertXmlToProviderRosterLineItemDetailsList(
    String updateProviderRosterLineItemString) throws AppException,
      InformationalException {
    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    ProviderRosterLineItemDetailsList updateRosterList = new ProviderRosterLineItemDetailsList();

    String strDailyAttendanceXml = updateProviderRosterLineItemString;

    InputStream inputStream = new ByteArrayInputStream(
      strDailyAttendanceXml.getBytes());

    SAXBuilder sAXBuilder = new SAXBuilder();
    Document document = null;

    // The xml string which is received from the Update Roster widget is
    // parsed
    // using the SAX parser and the modified values of the roster line items
    // are
    // populated into a list of roster line item details.
    try {
      document = sAXBuilder.build(inputStream);
      Element rootElement = document.getRootElement();
      List updateRosterElements = rootElement.getChildren();
      Iterator updateRosterIter = updateRosterElements.iterator();
      
      while (updateRosterIter.hasNext()) {

        Element updateRosterElement = (Element) updateRosterIter.next();

        String providerrosterlineitemID = updateRosterElement.getChild(CPMWidgetHelperConstants.kProviderRosterLineItemIDElement).getText();

        String caseReferenceNo = updateRosterElement.getChild(CPMWidgetHelperConstants.kCaseReferenceNoElement).getText();

        String prliVersionNo = updateRosterElement.getChild(CPMWidgetHelperConstants.kPRLIVersionNumberElement).getText();

        String rliVersionNo = updateRosterElement.getChild(CPMWidgetHelperConstants.kRLIVersionNumberElement).getText();

        String concernRoleID = updateRosterElement.getChild(CPMWidgetHelperConstants.kConcernRoleIDElement).getText();

        String serviceFrom = updateRosterElement.getChild(CPMWidgetHelperConstants.kServicefromElement).getText();

        String serviceTo = updateRosterElement.getChild(CPMWidgetHelperConstants.kServicetoElement).getText();

        String authorizationReferenceNo = updateRosterElement.getChild(CPMWidgetHelperConstants.kAuthorizationReferenceNumberElement).getText();

        String voucherNo = updateRosterElement.getChild(CPMWidgetHelperConstants.kVoucherNumberElement).getText();

        // BEGIN, CR00279292, GP
        String expectedUnits = updateRosterElement.getChild(CPMWidgetHelperConstants.kExpectedUnitsElement).getText();

        String actualUnits = updateRosterElement.getChild(CPMWidgetHelperConstants.kActualunitsElement).getText();
        // END, CR00279292      

        ProviderRosterLineItemDetails updateRosterDetails = new ProviderRosterLineItemDetails();

        updateRosterDetails.providerRosterLineItemDtls.providerRosterLineItemID = Long.parseLong(
          providerrosterlineitemID);
        updateRosterDetails.providerRosterLineItemDtls.caseReferenceNo = caseReferenceNo;
        updateRosterDetails.providerRosterLineItemDtls.versionNo = Integer.parseInt(
          prliVersionNo);
        updateRosterDetails.rosterLineItemDtls.versionNo = Integer.parseInt(
          rliVersionNo);
        updateRosterDetails.rosterLineItemDtls.concernRoleID = Long.parseLong(
          concernRoleID);
        updateRosterDetails.rosterLineItemDtls.serviceFrom = Date.getDate(
          serviceFrom);
        updateRosterDetails.rosterLineItemDtls.serviceTo = Date.getDate(
          serviceTo);
        updateRosterDetails.providerRosterLineItemDtls.saReferenceNo = authorizationReferenceNo;

        updateRosterDetails.providerRosterLineItemDtls.voucherNumber = voucherNo;
        
        // BEGIN, CR00279292, GP
        updateRosterDetails.rosterLineItemDtls.expectedUnits = Short.parseShort(
          expectedUnits);

        // BEGIN, CR00127676 NK
        try {
          if (null != actualUnits && !StringHelper.isEmpty(actualUnits)) {
            updateRosterDetails.rosterLineItemDtls.totalUnitsDelivered = Short.parseShort(
              actualUnits);

            if (0 > updateRosterDetails.rosterLineItemDtls.totalUnitsDelivered) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_MUST_BE_GT_ZERO(),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                7);
            }

          }
          // END, CR00127676
        } catch (NumberFormatException numberFormatException) {

          // BEGIN, CR00148197, RD
          int indexOfDot = -1;

          indexOfDot = actualUnits.indexOf(CuramConst.gkDotChar);

          if ((5 <= actualUnits.length()) && (0 < indexOfDot)) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              ROSTERExceptionCreator.ERR_ROSTER_FV_ACTUAL_UNITS_MUST_BE_WHOLE_NUMBER(
                actualUnits),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                1);
          } else if (5 <= actualUnits.length()) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_INVALID_ACTUAL_UNITS(
                actualUnits),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                1);
          } else if ((5 > actualUnits.length()) && (0 < indexOfDot)) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              ROSTERExceptionCreator.ERR_ROSTER_FV_ACTUAL_UNITS_MUST_BE_WHOLE_NUMBER(
                actualUnits),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_INVALID_ACTUAL_UNITS(
                actualUnits),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
          }
          // END, CR00148197
        }
        // END, CR00279292
        
        updateRosterList.details.addRef(updateRosterDetails);

      }
      ValidationHelper.failIfErrorsExist();

    } catch (JDOMException e) {
      throw new AppException(WIDGET.ERR_JDOM_EXCEPTION, e);
    } catch (IOException e) {
      throw new AppException(WIDGET.ERR_IO_EXCEPTION, e);
    }

    return updateRosterList;
  }

  // BEGIN, CR00158345, GP  
  /**
   * Converts the list of service invoice line item details to xml and this xml
   * forms the input to the editable client details list widget.
   *
   * @param siliClientDetailsList
   * List of service invoice line item client details.
   *
   * @return Xml string containing the data of list of service invoice line item
   * details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public static String convertServiceInvoiceLineItemClientDetailsToXml(
    SILIClientDetailsList siliClientDetailsList) {

    TransactionInfo.setInformationalManager();

    Element rootElement = new Element(
      CPMWidgetHelperConstants.kServiceInvoiceLineItemClientElement);

    // Check if the input list is empty and then form an xml with null
    // values.
    // Else if the input list is not empty then form an xml with the details
    // of the input list. The domain definition of each attribute in the
    // details struct is also populated in the xml.
    int size = siliClientDetailsList.clientDetails.size();

    if (0 == size) {
      
      Element clientDetailsElement = new Element(
        CPMWidgetHelperConstants.kClientDetailsElement);

      Element clientReferenceNoElement = new Element(
        CPMWidgetHelperConstants.kClientReferenceNoElement);
      Attribute clientReferenceNoDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kClientReferenceNumberDomainValueAttribute);

      clientReferenceNoElement.setAttribute(
        clientReferenceNoDefaultValueAttribute);

      Element clientFirstNameElement = new Element(
        CPMWidgetHelperConstants.kClientFirstNameElement);
      Attribute clientFirstNameDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kClientFirstNameDomainValueAttribute);

      clientFirstNameElement.setAttribute(clientFirstNameDefaultValueAttribute);

      Element clientLastNameElement = new Element(
        CPMWidgetHelperConstants.kClientLastNameElement);
      Attribute clientLastNameDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kClientLastNameDomainValueAttribute);

      clientLastNameElement.setAttribute(clientLastNameDefaultValueAttribute);

      Element clientDOBElement = new Element(
        CPMWidgetHelperConstants.kClientDOBElement);
      Attribute clientDOBDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kClientDateOfBirthDomainValueAttribute);

      clientDOBElement.setAttribute(clientDOBDefaultValueAttribute);
      clientDOBElement.setText(Date.getCurrentDate().toString());
      
      Element siliClientIDElement = new Element(
        CPMWidgetHelperConstants.kSILIClientIDElement);
      Attribute siliClientIDDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kSILIClientIDDomainValueAttribute);

      siliClientIDElement.setAttribute(siliClientIDDefaultValueAttribute);
      
      Element serviceInvoiceLineItemIDElement = new Element(
        CPMWidgetHelperConstants.kServiceInvoiceLineItemIDElement);
      Attribute serviceInvoiceLineItemIDDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kServiceInvoiceLineItemIDDomainValueAttribute);

      serviceInvoiceLineItemIDElement.setAttribute(
        serviceInvoiceLineItemIDDefaultValueAttribute);

      Element siliCorrectionClientIDElement = new Element(
        CPMWidgetHelperConstants.kSILICorrectionClientIDElement);
      Attribute siliCorrectionClientIDDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kSILICorrectionClientIDDomainValueAttribute);

      siliCorrectionClientIDElement.setAttribute(
        siliCorrectionClientIDDefaultValueAttribute);
      
      Element siliCorrectionIDElement = new Element(
        CPMWidgetHelperConstants.kSILICorrectionIDElement);
      Attribute siliCorrectionIDDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kSILICorrectionIDDomainValueAttribute);

      siliCorrectionIDElement.setAttribute(
        siliCorrectionIDDefaultValueAttribute);
      
      clientDetailsElement.addContent(clientReferenceNoElement);
      clientDetailsElement.addContent(clientFirstNameElement);
      clientDetailsElement.addContent(clientLastNameElement);
      clientDetailsElement.addContent(clientDOBElement);
      clientDetailsElement.addContent(siliClientIDElement);
      clientDetailsElement.addContent(serviceInvoiceLineItemIDElement);
      clientDetailsElement.addContent(siliCorrectionClientIDElement);
      clientDetailsElement.addContent(siliCorrectionIDElement);

      rootElement.addContent(clientDetailsElement);
    } else {

      Iterator clientDetailsIter = siliClientDetailsList.clientDetails.iterator();

      while (clientDetailsIter.hasNext()) {
        SILIClientDetails siliClientDetails = (SILIClientDetails) clientDetailsIter.next();

        if (siliClientDetails != null) {

          Element clientDetailsElement = new Element(
            CPMWidgetHelperConstants.kClientDetailsElement);

          Element clientReferenceNoElement = new Element(
            CPMWidgetHelperConstants.kClientReferenceNoElement);
          Attribute clientReferenceNoDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kClientReferenceNumberDomainValueAttribute);

          clientReferenceNoElement.setAttribute(
            clientReferenceNoDefaultValueAttribute);
          clientReferenceNoElement.setText(siliClientDetails.clientReferenceNo);

          Element clientFirstNameElement = new Element(
            CPMWidgetHelperConstants.kClientFirstNameElement);
          Attribute clientFirstNameDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kClientFirstNameDomainValueAttribute);

          clientFirstNameElement.setAttribute(
            clientFirstNameDefaultValueAttribute);
          clientFirstNameElement.setText(siliClientDetails.clientFirstName);
          
          Element clientLastNameElement = new Element(
            CPMWidgetHelperConstants.kClientLastNameElement);
          Attribute clientLastNameDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kClientLastNameDomainValueAttribute);

          clientLastNameElement.setAttribute(
            clientLastNameDefaultValueAttribute);
          clientLastNameElement.setText(siliClientDetails.clientLastName);
          
          Element clientDOBElement = new Element(
            CPMWidgetHelperConstants.kClientDOBElement);
          Attribute clientDOBDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kClientDateOfBirthDomainValueAttribute);

          clientDOBElement.setAttribute(clientDOBDefaultValueAttribute);

          // BEGIN, CR00322912, GYH
          clientDOBElement.setText(
            Locale.getFormattedDate(siliClientDetails.clientDOB, Locale.Date_ymd).toString());
          // END, CR00322912
          
          Element siliClientIDElement = new Element(
            CPMWidgetHelperConstants.kSILIClientIDElement);
          Attribute siliClientIDDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kSILIClientIDDomainValueAttribute);

          siliClientIDElement.setAttribute(siliClientIDDefaultValueAttribute);
          siliClientIDElement.setText(
            String.valueOf(siliClientDetails.siliClientID));
          
          Element serviceInvoiceLineItemIDElement = new Element(
            CPMWidgetHelperConstants.kServiceInvoiceLineItemIDElement);
          Attribute serviceInvoiceLineItemIDDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kServiceInvoiceLineItemIDDomainValueAttribute);

          serviceInvoiceLineItemIDElement.setAttribute(
            serviceInvoiceLineItemIDDefaultValueAttribute);
          serviceInvoiceLineItemIDElement.setText(
            String.valueOf(siliClientDetails.serviceInvoiceLineItemID));
          
          Element siliCorrectionClientIDElement = new Element(
            CPMWidgetHelperConstants.kSILICorrectionClientIDElement);
          Attribute siliCorrectionClientIDDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kSILICorrectionClientIDDomainValueAttribute);

          siliCorrectionClientIDElement.setAttribute(
            siliCorrectionClientIDDefaultValueAttribute);
          siliCorrectionClientIDElement.setText(
            String.valueOf(siliClientDetails.siliCorrectionClientID));

          Element siliCorrectionIDElement = new Element(
            CPMWidgetHelperConstants.kSILICorrectionIDElement);
          Attribute siliCorrectionIDDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kSILICorrectionIDDomainValueAttribute);

          siliCorrectionIDElement.setAttribute(
            siliCorrectionIDDefaultValueAttribute);
          siliCorrectionIDElement.setText(
            String.valueOf(siliClientDetails.siliCorrectionID));
    
          clientDetailsElement.addContent(clientReferenceNoElement);
          clientDetailsElement.addContent(clientFirstNameElement);
          clientDetailsElement.addContent(clientLastNameElement);
          clientDetailsElement.addContent(clientDOBElement);
          clientDetailsElement.addContent(siliClientIDElement);
          clientDetailsElement.addContent(serviceInvoiceLineItemIDElement);
          clientDetailsElement.addContent(siliCorrectionClientIDElement);
          clientDetailsElement.addContent(siliCorrectionIDElement);
          
          rootElement.addContent(clientDetailsElement);
        }
        
      }
    }

    Document document = new Document(rootElement);
    XMLOutputter xmlOutputter = new XMLOutputter();

    return xmlOutputter.outputString(document);

  }
  
  /**
   * Parses the xml data which is received from the editable client details list
   * Widget to Service Invoice Line Item Client Details List.
   *
   * @param siliClientDetailsString
   * XML which is received from the editable client details list
   * widget.
   *
   * @return List of Service Invoice Line Item Client Details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public static SILIClientDetailsList convertXmlToServiceInvoiceLineItemClientDetailsList(
    String siliClientDetailsString) throws AppException, InformationalException {

    TransactionInfo.setInformationalManager();

    SILIClientDetailsList siliClientDetailsList = new SILIClientDetailsList();

    InputStream inputStream = new ByteArrayInputStream(
      siliClientDetailsString.getBytes());

    SAXBuilder sAXBuilder = new SAXBuilder();
    Document document = null;

    try {
      
      document = sAXBuilder.build(inputStream);
      Element rootElement = document.getRootElement();
      List siliClientElements = rootElement.getChildren();
      Iterator siliClientIter = siliClientElements.iterator();

      while (siliClientIter.hasNext()) {

        Element clientDetailsElement = (Element) siliClientIter.next();

        String siliClientID = clientDetailsElement.getChild(CPMWidgetHelperConstants.kSILIClientIDElement).getText();

        String serviceInvoiceLineItemID = clientDetailsElement.getChild(CPMWidgetHelperConstants.kServiceInvoiceLineItemIDElement).getText();

        String clientReferenceNo = clientDetailsElement.getChild(CPMWidgetHelperConstants.kClientReferenceNoElement).getText();

        String clientFirstName = clientDetailsElement.getChild(CPMWidgetHelperConstants.kClientFirstNameElement).getText();

        String clientLastName = clientDetailsElement.getChild(CPMWidgetHelperConstants.kClientLastNameElement).getText();

        String clientDOB = clientDetailsElement.getChild(CPMWidgetHelperConstants.kClientDOBElement).getText();
        
        String siliCorrectionClientID = clientDetailsElement.getChild(CPMWidgetHelperConstants.kSILICorrectionClientIDElement).getText();

        String siliCorrectionID = clientDetailsElement.getChild(CPMWidgetHelperConstants.kSILICorrectionIDElement).getText();
        
        SILIClientDetails siliClientDetails = new SILIClientDetails();

        siliClientDetails.siliClientID = Long.parseLong(siliClientID);
        siliClientDetails.serviceInvoiceLineItemID = Long.parseLong(
          serviceInvoiceLineItemID);
        siliClientDetails.clientReferenceNo = clientReferenceNo;
        siliClientDetails.clientFirstName = clientFirstName;
        siliClientDetails.clientLastName = clientLastName;
        siliClientDetails.siliCorrectionClientID = Long.parseLong(
          siliCorrectionClientID);
        siliClientDetails.siliCorrectionID = Long.parseLong(siliCorrectionID);
        
        try {
          if (clientDOB != null && !CPMConstants.kEmptyString.equals(clientDOB)) {
            siliClientDetails.clientDOB = Date.getDate(clientDOB);
          } else {
            siliClientDetails.clientDOB = Date.kZeroDate;
          }
        } catch (NumberFormatException numberFormatException) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_DATECOMPLETED_INVALID(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
        }

        siliClientDetailsList.clientDetails.addRef(siliClientDetails);

      }

      ValidationHelper.failIfErrorsExist();

    } catch (JDOMException e) {
      throw new AppException(WIDGET.ERR_JDOM_EXCEPTION, e);
    } catch (IOException e) {
      throw new AppException(WIDGET.ERR_IO_EXCEPTION, e);
    }

    return siliClientDetailsList;
  }
  
  /**
   * Converts the list of service invoice request line item details to xml and
   * this xml forms the input to the editable client details list widget.
   *
   * @param serviceInvoiceRequestLineItemClientDetailsList
   * List of service invoice request line item client details.
   *
   * @return Xml string containing the data of list of service invoice line item
   * details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public static String convertServiceInvoiceRequestLineItemClientDetailsToXml(
    ServiceInvoiceRequestLineItemClientDetailsList serviceInvoiceRequestLineItemClientDetailsList) {

    TransactionInfo.setInformationalManager();

    Element rootElement = new Element(
      CPMWidgetHelperConstants.kServiceInvoiceRequestLineItemClientElement);

    // Check if the input list is empty and then form an xml with null
    // values. Else if the input list is not empty then form an xml with the details
    // of the input list. The domain definition of each attribute in the
    // details struct is also populated in the xml.
    int size = serviceInvoiceRequestLineItemClientDetailsList.clientDetails.size();

    if (0 == size) {

      Element clientDetailsElement = new Element(
        CPMWidgetHelperConstants.kClientDetailsElement);

      Element clientReferenceNoElement = new Element(
        CPMWidgetHelperConstants.kClientReferenceNoElement);
      Attribute clientReferenceNoDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kClientReferenceNumberDomainValueAttribute);

      clientReferenceNoElement.setAttribute(
        clientReferenceNoDefaultValueAttribute);

      Element clientFirstNameElement = new Element(
        CPMWidgetHelperConstants.kClientFirstNameElement);
      Attribute clientFirstNameDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kClientFirstNameDomainValueAttribute);

      clientFirstNameElement.setAttribute(clientFirstNameDefaultValueAttribute);

      Element clientLastNameElement = new Element(
        CPMWidgetHelperConstants.kClientLastNameElement);
      Attribute clientLastNameDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kClientLastNameDomainValueAttribute);

      clientLastNameElement.setAttribute(clientLastNameDefaultValueAttribute);

      Element clientDOBElement = new Element(
        CPMWidgetHelperConstants.kClientDOBElement);
      Attribute clientDOBDefaultValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kClientDateOfBirthDomainValueAttribute);

      clientDOBElement.setAttribute(clientDOBDefaultValueAttribute);
      clientDOBElement.setText(Date.getCurrentDate().toString());

      Element serviceInvReqLineItemClientIDElement = new Element(
        CPMWidgetHelperConstants.kServiceInvReqLineItemClientIDElement);
      Attribute serviceInvReqLineItemClientIDDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kServiceInvReqLineItemClientIDDomainValueAttribute);

      serviceInvReqLineItemClientIDElement.setAttribute(
        serviceInvReqLineItemClientIDDomainValueAttribute);

      Element serviceInvReqLineItemIDElement = new Element(
        CPMWidgetHelperConstants.kServiceInvReqLineItemIDElement);
      Attribute serviceInvReqLineItemIDDomainValueAttribute = new Attribute(
        CPMWidgetHelperConstants.kDomainValueAttribute,
        CPMWidgetHelperConstants.kServiceInvReqLineItemIDDomainValueAttribute);

      serviceInvReqLineItemIDElement.setAttribute(
        serviceInvReqLineItemIDDomainValueAttribute);

      clientDetailsElement.addContent(clientReferenceNoElement);
      clientDetailsElement.addContent(clientFirstNameElement);
      clientDetailsElement.addContent(clientLastNameElement);
      clientDetailsElement.addContent(clientDOBElement);
      clientDetailsElement.addContent(serviceInvReqLineItemClientIDElement);
      clientDetailsElement.addContent(serviceInvReqLineItemIDElement);

      rootElement.addContent(clientDetailsElement);
    } else {

      Iterator clientDetailsIter = serviceInvoiceRequestLineItemClientDetailsList.clientDetails.iterator();

      while (clientDetailsIter.hasNext()) {
        ServiceInvoiceRequestLineItemClientDetails serviceInvoiceRequestLineItemClientDetails = (ServiceInvoiceRequestLineItemClientDetails) clientDetailsIter.next();

        if (serviceInvoiceRequestLineItemClientDetails != null) {

          Element clientDetailsElement = new Element(
            CPMWidgetHelperConstants.kClientDetailsElement);

          Element clientReferenceNoElement = new Element(
            CPMWidgetHelperConstants.kClientReferenceNoElement);
          Attribute clientReferenceNoDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kClientReferenceNumberDomainValueAttribute);

          clientReferenceNoElement.setAttribute(
            clientReferenceNoDefaultValueAttribute);
          clientReferenceNoElement.setText(
            serviceInvoiceRequestLineItemClientDetails.clientReferenceNo);

          Element clientFirstNameElement = new Element(
            CPMWidgetHelperConstants.kClientFirstNameElement);
          Attribute clientFirstNameDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kClientFirstNameDomainValueAttribute);

          clientFirstNameElement.setAttribute(
            clientFirstNameDefaultValueAttribute);
          clientFirstNameElement.setText(
            serviceInvoiceRequestLineItemClientDetails.clientFirstName);

          Element clientLastNameElement = new Element(
            CPMWidgetHelperConstants.kClientLastNameElement);
          Attribute clientLastNameDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kClientLastNameDomainValueAttribute);

          clientLastNameElement.setAttribute(
            clientLastNameDefaultValueAttribute);
          clientLastNameElement.setText(
            serviceInvoiceRequestLineItemClientDetails.clientLastName);

          Element clientDOBElement = new Element(
            CPMWidgetHelperConstants.kClientDOBElement);
          Attribute clientDOBDefaultValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kClientDateOfBirthDomainValueAttribute);

          clientDOBElement.setAttribute(clientDOBDefaultValueAttribute);
          // BEGIN, CR00322912, GYH
          clientDOBElement.setText(
            Locale.getFormattedDate(serviceInvoiceRequestLineItemClientDetails.clientDateOfBirth, Locale.Date_ymd).toString());
          // END, CR00322912

          Element serviceInvReqLineItemClientIDElement = new Element(
            CPMWidgetHelperConstants.kServiceInvReqLineItemClientIDElement);
          Attribute serviceInvReqLineItemClientIDDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kServiceInvReqLineItemClientIDDomainValueAttribute);

          serviceInvReqLineItemClientIDElement.setAttribute(
            serviceInvReqLineItemClientIDDomainValueAttribute);
          serviceInvReqLineItemClientIDElement.setText(
            String.valueOf(
              serviceInvoiceRequestLineItemClientDetails.serviceInvReqLineItemClientID));

          Element serviceInvReqLineItemIDElement = new Element(
            CPMWidgetHelperConstants.kServiceInvReqLineItemIDElement);
          Attribute serviceInvReqLineItemIDDomainValueAttribute = new Attribute(
            CPMWidgetHelperConstants.kDomainValueAttribute,
            CPMWidgetHelperConstants.kServiceInvReqLineItemIDDomainValueAttribute);

          serviceInvReqLineItemIDElement.setAttribute(
            serviceInvReqLineItemIDDomainValueAttribute);
          serviceInvReqLineItemIDElement.setText(
            String.valueOf(
              serviceInvoiceRequestLineItemClientDetails.serviceInvRequestLineItemID));

          clientDetailsElement.addContent(clientReferenceNoElement);
          clientDetailsElement.addContent(clientFirstNameElement);
          clientDetailsElement.addContent(clientLastNameElement);
          clientDetailsElement.addContent(clientDOBElement);
          clientDetailsElement.addContent(serviceInvReqLineItemClientIDElement);
          clientDetailsElement.addContent(serviceInvReqLineItemIDElement);

          rootElement.addContent(clientDetailsElement);
        }

      }
    }

    Document document = new Document(rootElement);
    XMLOutputter xmlOutputter = new XMLOutputter();

    return xmlOutputter.outputString(document);

  }

  /**
   * Parses the xml data which is received from the editable client details list
   * Widget to Service Invoice Request Line Item Client Details List.
   *
   * @param serviceInvoiceRequestLineItemClientDetailsString
   * XML which is received from the editable client details list
   * widget.
   *
   * @return List of Service Invoice Request Line Item Client Details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public static ServiceInvoiceRequestLineItemClientDetailsList convertXmlToServiceInvoiceRequestLineItemClientDetailsList(
    String serviceInvoiceRequestLineItemClientDetailsString)
    throws AppException, InformationalException {

    TransactionInfo.setInformationalManager();

    ServiceInvoiceRequestLineItemClientDetailsList serviceInvoiceRequestLineItemClientDetailsList = new ServiceInvoiceRequestLineItemClientDetailsList();

    InputStream inputStream = new ByteArrayInputStream(
      serviceInvoiceRequestLineItemClientDetailsString.getBytes());

    SAXBuilder sAXBuilder = new SAXBuilder();
    Document document = null;

    try {

      document = sAXBuilder.build(inputStream);
      Element rootElement = document.getRootElement();
      List siliClientElements = rootElement.getChildren();
      Iterator siliClientIter = siliClientElements.iterator();

      while (siliClientIter.hasNext()) {

        Element clientDetailsElement = (Element) siliClientIter.next();

        String serviceInvReqLineItemClientID = clientDetailsElement.getChild(CPMWidgetHelperConstants.kServiceInvReqLineItemClientIDElement).getText();

        String serviceInvReqLineItemID = clientDetailsElement.getChild(CPMWidgetHelperConstants.kServiceInvReqLineItemIDElement).getText();

        String clientReferenceNo = clientDetailsElement.getChild(CPMWidgetHelperConstants.kClientReferenceNoElement).getText();

        String clientFirstName = clientDetailsElement.getChild(CPMWidgetHelperConstants.kClientFirstNameElement).getText();

        String clientLastName = clientDetailsElement.getChild(CPMWidgetHelperConstants.kClientLastNameElement).getText();

        String clientDOB = clientDetailsElement.getChild(CPMWidgetHelperConstants.kClientDOBElement).getText();

        ServiceInvoiceRequestLineItemClientDetails serviceInvoiceRequestLineItemClientDetails = new ServiceInvoiceRequestLineItemClientDetails();

        serviceInvoiceRequestLineItemClientDetails.serviceInvReqLineItemClientID = Long.parseLong(
          serviceInvReqLineItemClientID);
        serviceInvoiceRequestLineItemClientDetails.serviceInvRequestLineItemID = Long.parseLong(
          serviceInvReqLineItemID);
        serviceInvoiceRequestLineItemClientDetails.clientReferenceNo = clientReferenceNo;
        serviceInvoiceRequestLineItemClientDetails.clientFirstName = clientFirstName;
        serviceInvoiceRequestLineItemClientDetails.clientLastName = clientLastName;

        try {
          if (clientDOB != null && !CPMConstants.kEmptyString.equals(clientDOB)) {
            serviceInvoiceRequestLineItemClientDetails.clientDateOfBirth = Date.getDate(
              clientDOB);
          } else {
            serviceInvoiceRequestLineItemClientDetails.clientDateOfBirth = Date.kZeroDate;
          }
        } catch (NumberFormatException numberFormatException) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_DATECOMPLETED_INVALID(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        }

        serviceInvoiceRequestLineItemClientDetailsList.clientDetails.addRef(
          serviceInvoiceRequestLineItemClientDetails);

      }

      ValidationHelper.failIfErrorsExist();

    } catch (JDOMException e) {
      throw new AppException(WIDGET.ERR_JDOM_EXCEPTION, e);
    } catch (IOException e) {
      throw new AppException(WIDGET.ERR_IO_EXCEPTION, e);
    }

    return serviceInvoiceRequestLineItemClientDetailsList;
  }

  // END, CR00158345
  
  // BEGIN, CR00322912, GYH
  /**
   * Formats the Date String to required format. The date string is tokenized
   * and the date string is converted to the required format.
   *
   * @param recievedDate
   * This string containing received Date value.
   * @return String Date String in the required format
   *
   * @deprecated Since Curam 6.0.4.0 because this method is no longer referenced
   * in the application. See release note : CR00322912
   */
  // BEGIN, CR00177241, PM
  @Deprecated
  protected static String formatStringToReqDateTypeForDisplay(String recievedDate) {
    // END, CR00177241
    StringTokenizer st = new StringTokenizer(recievedDate, CPMConstants.kHypen);

    if (st.countTokens() == 1) {
      return recievedDate;
    }

    StringBuffer buf = new StringBuffer();
    String[] dateArray = new String[3];

    for (int i = 0; st.hasMoreTokens(); i++) {
      dateArray[i] = st.nextToken();
    }
    String year = dateArray[0];
    String month = dateArray[1];

    if (month != null && month.length() == 1) {
      month = CuramConst.gkStringZero + month;
    }
    String date = dateArray[2];

    if (date != null && date.length() == 1) {
      date = CuramConst.gkStringZero + date;
    }
    buf.append(year);
    buf.append(month);
    buf.append(date);

    return buf.toString();
  }

  // END, CR00322912


  // ______________________________________________________________________________
  /**
   * Converts the list of Response Score details to a xml. Domain definitions of
   * each xml element is also populated. The widget uses the xml data to display
   * these details.
   *
   * @param createResponseScoreDetails
   * This struct contains the details which needs to be provided to the
   * widget for display.
   * @param responseType
   * The response type of the criterion for which the scores to be
   * added.
   *
   * @return Parsed Xml string.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public static String convertResponseScoreToXml(
    CreateResponseScoreDetails createResponseScoreDetails,
    SECRESPONSEDATATYPEEntry responseType) throws AppException,
      InformationalException {

    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    Element rootElement = new Element(
      CPMWidgetHelperConstants.kCriterionResponseScoreElement);

    ReadCodeTableItemKey readCodeTableItemKey = new ReadCodeTableItemKey();

    readCodeTableItemKey.code = responseType.getCode();
    readCodeTableItemKey.name = responseType.getTableName();

    // BEGIN, CR00305116, SSK
    final CodeTableAdmin codeTableAdminObj = CodeTableAdminFactory.newInstance();
    final CodeTableHeaderDetails codeTableHeaderDetails = codeTableAdminObj.readChildCodeTable(
      readCodeTableItemKey.name);
    
    // BEGIN, CR00340596, MR
    final CodeTableName codeTableName = new CodeTableName();

    codeTableName.name = codeTableHeaderDetails.tableName;

    final CodeTableAdminListAllItemsAndDefaultOut codeTableAdminListAllItemsAndDefaultOut = listEnabledItemsInCodetableForLocale(
      codeTableName);

    // END, CR00340596
    final List<CodeTableItemDetails> codeDetailsList = new ArrayList<CodeTableItemDetails>();

    for (final CodeTableItemDetails codeDetails : codeTableAdminListAllItemsAndDefaultOut.dtls.items()) {
      codeDetailsList.add(codeDetails);
    }
    
    Collections.sort(codeDetailsList,
      new Comparator<CodeTableItemDetails>() {
      public int compare(final CodeTableItemDetails lhs, CodeTableItemDetails rhs) {
        return lhs.code.compareToIgnoreCase(rhs.code);
      }
    });

    for (final CodeTableItemDetails codeTableItemDetails : codeDetailsList) {

      if (codeTableItemDetails.parentCode.equals(responseType.getCode())) {
        // END, CR00305116
        Element responseScoreElement = new Element(
          CPMWidgetHelperConstants.kResponseScoreElement);

        Element serviceEvaluationCriterionElement = new Element(
          CPMWidgetHelperConstants.kServiceEvaluationCriterionIDElement);
        Attribute ServiceEvaluationCriterionIDDomainValueAttribute = new Attribute(
          CPMWidgetHelperConstants.kDomainValueAttribute,
          CPMWidgetHelperConstants.kServiceEvaluationCriterionIDDomainValueAttribute);

        serviceEvaluationCriterionElement.setAttribute(
          ServiceEvaluationCriterionIDDomainValueAttribute);
        serviceEvaluationCriterionElement.setText(
          String.valueOf(
            createResponseScoreDetails.serviceEvaluationCriterionID));

        Element responseCodeElement = new Element(
          CPMWidgetHelperConstants.kResponseCodeElement);
        Attribute responseAttribute = new Attribute(
          CPMWidgetHelperConstants.kDomainValueAttribute,
          CPMWidgetHelperConstants.kResponseCodeDomainValueAttribute);

        responseCodeElement.setAttribute(responseAttribute);
        responseCodeElement.setText(String.valueOf(codeTableItemDetails.code));

        Element responseCodeDescriptionElement = new Element(
          CPMWidgetHelperConstants.kResponseCodeDescriptionElement);
        Attribute responseCodeDescription = new Attribute(
          CPMWidgetHelperConstants.kDomainValueAttribute,
          CPMWidgetHelperConstants.kResponseCodeDescriptionDomainValueAttribute);

        responseCodeDescriptionElement.setAttribute(responseCodeDescription);
        responseCodeDescriptionElement.setText(
          String.valueOf(codeTableItemDetails.description));

        Element scoreElement = new Element(
          CPMWidgetHelperConstants.kScoreElement);
        Attribute scoreAttribute = new Attribute(
          CPMWidgetHelperConstants.kDomainValueAttribute,
          CPMWidgetHelperConstants.kScoreDomainValueAttribute);

        scoreElement.setAttribute(scoreAttribute);
        scoreElement.setText(CuramConst.gkEmpty);

        responseScoreElement.addContent(serviceEvaluationCriterionElement);
        responseScoreElement.addContent(responseCodeElement);
        responseScoreElement.addContent(responseCodeDescriptionElement);
        responseScoreElement.addContent(scoreElement);
        rootElement.addContent(responseScoreElement);
      }
    
    }

    // Check if the input list is empty and then form an xml with null
    // values.
    // Else if the input list is not empty then form an xml with the details
    // of the input list. The domain definition of each attribute in the
    // details struct is also populated in the xml.
    Document document = new Document(rootElement);
    XMLOutputter xmlOutputter = new XMLOutputter();

    return xmlOutputter.outputString(document);

  }

  // BEGIN, CR00340596, MR
  /**
   * Lists all the enabled codetable items for the logged in user locale.
   *
   * @param codeTableName
   * Name of the codetable.
   *
   * @return List of codetable items contains code, description and parent code
   * for the locale.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected static CodeTableAdminListAllItemsAndDefaultOut listEnabledItemsInCodetableForLocale(
    final CodeTableName codeTableName) throws AppException,
      InformationalException {

    final String locale = TransactionInfo.getProgramLocale();

    // Read all the enabled items for the locale.
    LinkedHashMap<String, String> codetableCodesHashMap = CodeTable.getAllEnabledItems(
      codeTableName.name, locale);

    final CodeTableAdminListAllItemsAndDefaultOut codeTableAdminListAllItemsAndDefaultOut = new CodeTableAdminListAllItemsAndDefaultOut();

    CodeTableItemDetails codeTableItemDetails;

    if (!codetableCodesHashMap.isEmpty()) {

      final Set<Entry<String, String>> codeSet = codetableCodesHashMap.entrySet();

      final Iterator<Entry<String, String>> iterator = codeSet.iterator();

      while (iterator.hasNext()) {

        codeTableItemDetails = new CodeTableItemDetails();
        final Map.Entry entry = iterator.next();

        codeTableItemDetails.code = entry.getKey().toString();
        codeTableItemDetails.description = entry.getValue().toString();
        codeTableItemDetails.parentCode = CodeTable.getParentCode(
          codeTableName.name, codeTableItemDetails.code);
        codeTableAdminListAllItemsAndDefaultOut.dtls.add(codeTableItemDetails);
      }
    }
    return codeTableAdminListAllItemsAndDefaultOut;
  }

  // END, CR00340596
  
  /**
   * Populates the Response Score xml data received from widget to Response
   * Score details list
   *
   * @param createResponseScoreDetails
   * Contains the Response Score details returned by the widget.
   *
   * @return The Response Score details list from xml conversion.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link RESPONSESCORE#ERR_RESPONSESCORE_XFV_ATLEAST_ONE_RESPONSE_SCORE_REQUIRED_TO_CREATE}
   * If at least one score is not entered.
   */
  public static ResponseScoreDetailsList convertXmlToResponseScore(
    CreateResponseScoreDetails createResponseScoreDetails)
    throws AppException, InformationalException {
    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    ResponseScoreDetailsList responseScoreDetailsList = new ResponseScoreDetailsList();

    String strResponseScoreEditorXml = createResponseScoreDetails.responseScoreDetails;

    InputStream inputStream = new ByteArrayInputStream(
      strResponseScoreEditorXml.getBytes());

    SAXBuilder sAXBuilder = new SAXBuilder();
    Document document = null;

    try {
      document = sAXBuilder.build(inputStream);
      Element rootElement = document.getRootElement();
      List responseScoreDetailsElements = rootElement.getChildren();
      Iterator responseScoreDetailsIter = responseScoreDetailsElements.iterator();

      boolean isScoreEntered = false;

      while (responseScoreDetailsIter.hasNext()) {

        Element responseScoreDetailsElement = (Element) responseScoreDetailsIter.next();

        String score = responseScoreDetailsElement.getChild(CPMWidgetHelperConstants.kScoreElement).getText();

        if (!StringHelper.isEmpty(score)) {

          isScoreEntered = true;
          String strServiceEvaluationCriterionID = responseScoreDetailsElement.getChild(CPMWidgetHelperConstants.kServiceEvaluationCriterionIDElement).getText();

          String responseCode = responseScoreDetailsElement.getChild(CPMWidgetHelperConstants.kResponseCodeElement).getText();

          ResponseScoreDetails responseScoreDetails = new ResponseScoreDetails();

          try {
            responseScoreDetails.dtls.score = Integer.parseInt(score);
          } catch (NumberFormatException numberFormatException) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              RESPONSESCOREExceptionCreator.ERR_RESPONSESCORE_FV_RESPONSE_SCORE_IS_INVALID(),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
          }

          responseScoreDetails.dtls.serviceEvaluationCriterionID = Long.parseLong(
            strServiceEvaluationCriterionID);
          createResponseScoreDetails.serviceEvaluationCriterionID = responseScoreDetails.dtls.serviceEvaluationCriterionID;
          responseScoreDetails.dtls.response = responseCode;
          responseScoreDetailsList.details.addRef(responseScoreDetails);
        }
      }

      // If at least one score is not entered.
      if (!isScoreEntered) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          RESPONSESCOREExceptionCreator.ERR_RESPONSESCORE_XFV_ATLEAST_ONE_RESPONSE_SCORE_REQUIRED_TO_CREATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
      ValidationHelper.failIfErrorsExist();

    } catch (JDOMException e) {
      throw new AppException(WIDGET.ERR_JDOM_EXCEPTION, e);
    } catch (IOException e) {
      throw new AppException(WIDGET.ERR_IO_EXCEPTION, e);
    }

    return responseScoreDetailsList;
  }
  
  // BEGIN, CR00198730, ASN
  /**
   * Parses the xml containing attendance details list for reporting method
   * 'Attendance'received from Daily Attendance widget to Daily Attendance
   * details List.
   *
   * @param dailyAttendanceDetailsList
   * xml containing the data of list of daily attendance details.
   * @param isHoursEnabled
   * Checks 'Hours Enabled' indicator is set or not.
   *
   *
   * @return List containing the Attendance Details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.                  
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  public static DailyAttendanceDetailsList convertAttendanceXmlToAttendanceDetailsList(
    final String dailyAttendanceDetailsList, final boolean isHoursEnabled) throws AppException,
      InformationalException {
    TransactionInfo.setInformationalManager();

    DailyAttendanceDetailsList attendanceDetailsList = new DailyAttendanceDetailsList();

    String strDailyAttendanceXml = dailyAttendanceDetailsList;

    InputStream inputStream = new ByteArrayInputStream(
      strDailyAttendanceXml.getBytes());

    SAXBuilder sAXBuilder = new SAXBuilder();
    Document document = null;

    // The xml string which is received from the Daily Attendance widget is
    // parsed
    // using the SAX parser and the modified values of the daily attendance
    // records are
    // populated into a list of daily attendance details.
    try {
      document = sAXBuilder.build(inputStream);
      Element rootElement = document.getRootElement();
      
      List<Element> dailyAttendanceElements = rootElement.getChildren();
      
      Iterator<Element> dailyAttendanceIter = dailyAttendanceElements.iterator();

      while (dailyAttendanceIter.hasNext()) {

        Element dailyAttendanceElement = dailyAttendanceIter.next();

        String attendanceID = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kAttendanceIDElement).getText();

        String versionNo = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kDailyAttendanceVersionNumberElement).getText();

        String attendance = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kAttendanceElement).getText();

        String absenceReason = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kAbsenceReasonElement).getText();

        String serviceDateString = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kAttendanceDateElement).getText();
        
        DailyAttendanceDetails attendanceDetails = new DailyAttendanceDetails();

        attendanceDetails.dtls.dailyAttendanceID = Long.parseLong(attendanceID);
        attendanceDetails.dtls.versionNo = Integer.parseInt(versionNo);
        attendanceDetails.dtls.attendance = attendance.trim();
        attendanceDetails.dtls.absenceReason = absenceReason.trim();
        
        if (isHoursEnabled) {
          String hoursAttendedString = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kHoursAttendedElement).getText();

          String minutesAttendedString = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kMinutesAttendedElement).getText();

          String hoursAbsentString = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kHoursUnAttendedElement).getText();

          String minutesAbsenString = dailyAttendanceElement.getChild(CPMWidgetHelperConstants.kMinutesUnAttendedElement).getText();
          
          // BEGIN, CR00228146, ASN
          if (!StringUtil.isNullOrEmpty(hoursAttendedString.trim())) {
            attendanceDetails.dtls.numHoursAttended = Integer.parseInt(
              hoursAttendedString.trim());
          } else {
            attendanceDetails.dtls.numHoursAttended = 0;
          }

          if (!StringUtil.isNullOrEmpty(minutesAttendedString.trim())) {
            attendanceDetails.dtls.numMinutesAttended = Integer.parseInt(
              minutesAttendedString.trim());
          } else {
            attendanceDetails.dtls.numMinutesAttended = 0;
          }
          if (!StringUtil.isNullOrEmpty(hoursAbsentString.trim())) {
            attendanceDetails.dtls.numHoursAbsent = Integer.parseInt(
              hoursAbsentString.trim());
          } else {
            attendanceDetails.dtls.numHoursAbsent = 0;
          }
          if (!StringUtil.isNullOrEmpty(minutesAbsenString.trim())) {
            attendanceDetails.dtls.numMinutesAbsent = Integer.parseInt(
              minutesAbsenString.trim());
          } else {
            attendanceDetails.dtls.numMinutesAbsent = 0;
          }
        }
        // END, CR00228146
        // BEGIN, CR00303745, SSK
        attendanceDetails.dtls.serviceDate = curam.util.type.Date.fromISO8601(
          serviceDateString);
        // END, CR00303745
        
        attendanceDetailsList.details.addRef(attendanceDetails);

      }
      ValidationHelper.failIfErrorsExist();

    } catch (JDOMException e) {
      throw new AppException(WIDGET.ERR_JDOM_EXCEPTION, e);
    } catch (IOException e) {
      throw new AppException(WIDGET.ERR_IO_EXCEPTION, e);
    }

    return attendanceDetailsList;
  }
  // END, CR00198730
}
