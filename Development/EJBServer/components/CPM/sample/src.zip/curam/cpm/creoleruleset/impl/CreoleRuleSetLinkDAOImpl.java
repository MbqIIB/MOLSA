/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.creoleruleset.impl;


import java.util.List;

import com.google.inject.Singleton;

import curam.codetable.impl.CREOLERULESETTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.RELATEDTYPEEntry;
import curam.cpm.sl.entity.impl.CreoleRuleSetLinkAdapter;
import curam.cpm.sl.entity.struct.CreoleRuleSetLinkDtls;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.persistence.StandardDAOImpl;
import curam.util.type.DateRange;


/**
 * Standard implementation of
 * {@linkplain curam.cpm.creoleruleset.impl.CreoleRuleSetLinkDAO}.
 */
@Singleton
public class CreoleRuleSetLinkDAOImpl extends StandardDAOImpl<CreoleRuleSetLink, CreoleRuleSetLinkDtls> implements
  CreoleRuleSetLinkDAO {

  /**
   * Instance of creole rule set Link adapter.
   */
  protected static final CreoleRuleSetLinkAdapter creoleRuleSetLinkAdapter = new CreoleRuleSetLinkAdapter();

  /**
   * Constructor for the class.
   */
  protected CreoleRuleSetLinkDAOImpl() {
    super(creoleRuleSetLinkAdapter, CreoleRuleSetLink.class);
  }

  /**
   * {@inheritDoc}
   */
  public List<CreoleRuleSetLink> searchBy(final long relatedID,
    final RELATEDTYPEEntry relatedType, final CREOLERULESETTYPEEntry type,
    final DateRange dateRange) {

    return newList(
      creoleRuleSetLinkAdapter.searchBy(relatedID, relatedType.getCode(),
      type.getCode(), dateRange.start(), dateRange.end(),
      RECORDSTATUSEntry.NORMAL.getCode()));
  }

  /**
   * {@inheritDoc}
   */
  public CreoleRuleSetLink readDataStoreByRuleID(final CreoleRuleSetLink creoleRuleSetLink) {

    final CreoleRuleSetLink creoleRuleSetDataStoreName = getEntity(
      creoleRuleSetLinkAdapter.readDataStoreByRuleID(
        creoleRuleSetLink.getCreoleRuleSetID()));

    return creoleRuleSetDataStoreName;
  }

  /**
   * {@inheritDoc}
   */
  public CreoleRuleSetLink readByServiceOfferingAndRuleSetType(final ServiceOffering serviceOffering, final CREOLERULESETTYPEEntry type) {

    return getEntity(
      creoleRuleSetLinkAdapter.readByServiceOfferingAndRuleSetType(
        serviceOffering.getID(), type.getCode()));
  }

}
