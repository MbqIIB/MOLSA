/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.util.impl;


import com.google.inject.Singleton;
import curam.core.impl.EnvVars;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.impl.SequentialContinuousRefNumberAdapter;
import curam.cpm.sl.entity.struct.SequentialContinuousRefNumberDtls;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of {@linkplain SequentialContinuousRefNumberDAO}.
 */
@Singleton
public class SequentialContinuousRefNumberDAOImpl extends StandardDAOImpl<SequentialContinuousRefNumber, SequentialContinuousRefNumberDtls>
  implements SequentialContinuousRefNumberDAO {

  /**
   * Sequential Continuous Reference Number Adapter object.
   */
  protected static final SequentialContinuousRefNumberAdapter adapter = new SequentialContinuousRefNumberAdapter();

  /**
   * Constructor for the class.
   */
  protected SequentialContinuousRefNumberDAOImpl() {
    super(adapter, SequentialContinuousRefNumber.class);
  }

  /**
   * {@inheritDoc}
   */
  public long generateSequentialContinuousReferenceNumber(
    String referenceNumberCodeName) throws InformationalException {

    long nextReferenceNumber = 0;

    SequentialContinuousRefNumber sequentialContinuousRefNumber = getEntity(
      adapter.readByReferenceNumberCodeName(referenceNumberCodeName));

    if (null != sequentialContinuousRefNumber) {

      nextReferenceNumber = sequentialContinuousRefNumber.getNextReferenceNumber();

      sequentialContinuousRefNumber.setNextReferenceNumber(
        nextReferenceNumber + 1);
      sequentialContinuousRefNumber.modify(
        sequentialContinuousRefNumber.getVersionNo());

    } else {

      SequentialContinuousRefNumber newSequentialContinuousRefNumber = newInstance();

      if (CPMConstants.kProviderCodeName.equals(referenceNumberCodeName)) {

        nextReferenceNumber = Long.valueOf(
          curam.util.resources.Configuration.getProperty(
            EnvVars.ENV_PROVIDER_SEQUENTIAL_CONTINUOUS_REF_NUMBER_START));

      } else if (CPMConstants.kProviderGroupCodeName.equals(
        referenceNumberCodeName)) {

        nextReferenceNumber = Long.valueOf(
          curam.util.resources.Configuration.getProperty(
            EnvVars.ENV_PROVIDERGROUP_SEQUENTIAL_CONTINUOUS_REF_NUMBER_START));

      } else if (CPMConstants.kProviderEnquiryCodeName.equals(
        referenceNumberCodeName)) {

        nextReferenceNumber = Long.valueOf(
          curam.util.resources.Configuration.getProperty(
            EnvVars.ENV_PROVIDERENQUIRY_SEQUENTIAL_CONTINUOUS_REF_NUMBER_START));

      } else if (CPMConstants.kServiceInvoiceCodeName.equals(
        referenceNumberCodeName)) {

        nextReferenceNumber = Long.valueOf(
          curam.util.resources.Configuration.getProperty(
            EnvVars.ENV_SERVICEINVOICE_SEQUENTIAL_CONTINUOUS_REF_NUMBER_START));

      } else if (CPMConstants.kServiceInvoiceLineItemCodeName.equals(
        referenceNumberCodeName)) {

        nextReferenceNumber = Long.valueOf(
          curam.util.resources.Configuration.getProperty(
            EnvVars.ENV_SERVICEINVOICELINEITEM_SEQUENTIAL_CONTINUOUS_REF_NUMBER_START));

      } else if (CPMConstants.kServiceInvoiceRequestLineItemCodeName.equals(
        referenceNumberCodeName)) {

        nextReferenceNumber = Long.valueOf(
          curam.util.resources.Configuration.getProperty(
            EnvVars.ENV_SERVICEINVOICEREQUESTLINEITEM_SEQUENTIAL_CONTINUOUS_REF_NUMBER_START));

      }

      newSequentialContinuousRefNumber.setReferenceNumberCodeName(
        referenceNumberCodeName);
      newSequentialContinuousRefNumber.setNextReferenceNumber(
        nextReferenceNumber + 1);
      newSequentialContinuousRefNumber.insert();
    }

    return nextReferenceNumber;
  }
}
