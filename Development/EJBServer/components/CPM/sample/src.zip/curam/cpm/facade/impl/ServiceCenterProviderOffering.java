/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import com.google.inject.Inject;

import curam.cpm.facade.struct.ServiceCenterProviderOfferingDtls;
import curam.cpm.facade.struct.ServiceCenterProviderOfferingKey;
import curam.cpm.facade.struct.ServiceCenterProviderOfferingVersionedKey;
import curam.provider.impl.ProviderServiceCenterDAO;
import curam.provider.impl.ServiceCenterProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.DateRange;


/**
 * Facade layer class providing the functionality for Service Center Provider
 * Offering.
 */
public abstract class ServiceCenterProviderOffering extends curam.cpm.facade.base.ServiceCenterProviderOffering {

  /**
   * instance of service center provider offering DAO
   */
  @Inject
  protected ServiceCenterProviderOfferingDAO serviceCenterProviderOfferingDAO;

  /**
   * instance of provider offering DAO
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * instance of provider service center DAO
   */
  @Inject
  protected ProviderServiceCenterDAO providerServiceCenterDAO;

  /**
   * Constructor
   */
  public ServiceCenterProviderOffering() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  // ___________________________________________________________________________
  /**
   * Cancels a Service Center Provider Offering.
   *
   * @param key
   * ID and version no of the Service Center Provider Offering to be
   * canceled.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancelServiceCenterProviderOffering(
    ServiceCenterProviderOfferingVersionedKey key) throws AppException,
      InformationalException {

    curam.provider.impl.ServiceCenterProviderOffering serviceCenterProviderOffering = serviceCenterProviderOfferingDAO.get(
      key.key.servCenterProviderOfferingID);

    // cancel the Service Center Provider Offering
    serviceCenterProviderOffering.cancel(key.versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Creates a Service Center Provider Offering.
   *
   * @param details
   * The details of the Service Center Provider Offering.
   * @return ServiceCenterProviderOfferingKey The ID of the Service Center
   * Provider Offering that has been created.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceCenterProviderOfferingKey createServiceCenterProviderOffering(
    ServiceCenterProviderOfferingDtls details) throws AppException,
      InformationalException {

    ServiceCenterProviderOfferingKey serviceCenterProviderOfferingKey = new ServiceCenterProviderOfferingKey();
    curam.provider.impl.ServiceCenterProviderOffering serviceCenterProviderOffering = serviceCenterProviderOfferingDAO.newInstance();

    // set field values sent in by client
    setServiceCenterProviderOfferingFields(serviceCenterProviderOffering,
      details);

    // insert the Service Center Provider Offering
    serviceCenterProviderOffering.insert();

    // set and return key
    serviceCenterProviderOfferingKey.key.servCenterProviderOfferingID = serviceCenterProviderOffering.getID();
    return serviceCenterProviderOfferingKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies a Service Center Provider Offering.
   *
   * @param details
   * The details of the Service Center Provider Offering to be updated.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void updateServiceCenterProviderOffering(
    ServiceCenterProviderOfferingDtls details) throws AppException,
      InformationalException {

    curam.provider.impl.ServiceCenterProviderOffering serviceCenterProviderOffering = serviceCenterProviderOfferingDAO.get(
      details.dtls.servCenterProviderOfferingID);

    // set field values sent in by client
    setServiceCenterProviderOfferingFields(serviceCenterProviderOffering,
      details);

    // call modify
    serviceCenterProviderOffering.modify(details.dtls.versionNo);

  }

  // ___________________________________________________________________________
  /**
   * Views a Service Center Provider Offering.
   *
   * @param key
   * The ID of the Service Center Provider Offering to view
   * @return ServiceCenterProviderOfferingDtls The details of the Service Center
   * Provider Offering.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceCenterProviderOfferingDtls viewServiceCenterProviderOffering(
    ServiceCenterProviderOfferingKey key) throws AppException,
      InformationalException {
    ServiceCenterProviderOfferingDtls serviceCenterProviderOfferingDtls;

    // Read the Home Study
    curam.provider.impl.ServiceCenterProviderOffering serviceCenterProviderOffering = serviceCenterProviderOfferingDAO.get(
      key.key.servCenterProviderOfferingID);

    // set the details on the return struct
    serviceCenterProviderOfferingDtls = setServiceCenterProviderOfferingDetails(
      serviceCenterProviderOffering);

    return serviceCenterProviderOfferingDtls;
  }

  // ___________________________________________________________________________
  /**
   * Private method to set the fields on a Service Center Provider Offering.
   *
   * @param serviceCenterProviderOffering
   * The ID of the Service Center Provider Offering to view.
   * @param details
   * The details of the Service Center Provider Offering.
   */
  // BEGIN, CR00177241, PM
  protected void setServiceCenterProviderOfferingFields(
    // END, CR00177241
    curam.provider.impl.ServiceCenterProviderOffering serviceCenterProviderOffering,
    ServiceCenterProviderOfferingDtls details) {
    DateRange dateRange = new DateRange(details.dtls.startDate,
      details.dtls.endDate);

    serviceCenterProviderOffering.setDateRange(dateRange);
    serviceCenterProviderOffering.setProviderOffering(
      providerOfferingDAO.get(details.dtls.providerOfferingID));
    serviceCenterProviderOffering.setProviderServiceCenter(
      providerServiceCenterDAO.get(details.dtls.providerServiceCenterID));
    serviceCenterProviderOffering.setComments(details.dtls.comments);
  }

  // ___________________________________________________________________________
  /**
   * Private method to set Service Center Provider Offering details struct for use by client.
   *
   * @param serviceCenterProviderOffering
   * The Service Center Provider Offering to be returned.
   *
   * @return ServiceCenterProviderOfferingDtls Service Center Provider Offering
   * details.
   */
  // BEGIN, CR00177241, PM
  protected ServiceCenterProviderOfferingDtls setServiceCenterProviderOfferingDetails(
    // END, CR00177241
    curam.provider.impl.ServiceCenterProviderOffering serviceCenterProviderOffering) {
    ServiceCenterProviderOfferingDtls serviceCenterProviderOfferingDtls = new ServiceCenterProviderOfferingDtls();

    serviceCenterProviderOfferingDtls.dtls.comments = serviceCenterProviderOffering.getComments();

    DateRange dateRange = serviceCenterProviderOffering.getDateRange();

    serviceCenterProviderOfferingDtls.dtls.endDate = dateRange.end();
    serviceCenterProviderOfferingDtls.dtls.startDate = dateRange.start();

    serviceCenterProviderOfferingDtls.dtls.providerOfferingID = serviceCenterProviderOffering.getProviderOffering().getID();
    serviceCenterProviderOfferingDtls.dtls.providerServiceCenterID = serviceCenterProviderOffering.getProviderServiceCenter().getID();
    serviceCenterProviderOfferingDtls.dtls.recordStatus = serviceCenterProviderOffering.getLifecycleState().getCode();
    serviceCenterProviderOfferingDtls.dtls.servCenterProviderOfferingID = serviceCenterProviderOffering.getID();
    serviceCenterProviderOfferingDtls.dtls.versionNo = serviceCenterProviderOffering.getVersionNo();

    // set the service name
    serviceCenterProviderOfferingDtls.serviceName = serviceCenterProviderOffering.getProviderOffering().getServiceOffering().getName();

    return serviceCenterProviderOfferingDtls;
  }

}
