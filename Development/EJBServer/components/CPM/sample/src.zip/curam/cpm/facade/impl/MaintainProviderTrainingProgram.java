/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl; 


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.TRAININGPROGRAMPARTYSTATUSEntry;
import curam.core.impl.CuramConst;
import curam.cpm.facade.struct.ConcernRoleMemberDetails;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.MemberTrainingSummaryDetails;
import curam.cpm.facade.struct.PartyDetails;
import curam.cpm.facade.struct.PartyDetailsList;
import curam.cpm.facade.struct.TrainingAndConcernRolekey;
import curam.cpm.facade.struct.TrainingPartyCreateDetails;
import curam.cpm.facade.struct.TrainingPartyCreateDetailsList;
import curam.cpm.facade.struct.TrainingPartyDetails;
import curam.cpm.facade.struct.TrainingProgram;
import curam.cpm.facade.struct.TrainingProgramAndConcernRoleKey;
import curam.cpm.facade.struct.TrainingProgramAndPartyCompletedDetails;
import curam.cpm.facade.struct.TrainingProgramAndPartyDetails;
import curam.cpm.facade.struct.TrainingProgramCompleteDetails;
import curam.cpm.facade.struct.TrainingProgramCompletedDetails;
import curam.cpm.facade.struct.TrainingProgramConcernRoleVersionKey;
import curam.cpm.facade.struct.TrainingProgramList;
import curam.cpm.facade.struct.TrainingProgramMemberAddDetails;
import curam.cpm.facade.struct.TrainingProgramMemberList;
import curam.cpm.facade.struct.TrainingProgramMemberUpdateDetails;
import curam.cpm.facade.struct.TrainingProgramPartyCompletedDetails;
import curam.cpm.facade.struct.TrainingProgramPartyDetails;
import curam.cpm.facade.struct.TrainingProgramPartyDetailsList;
import curam.cpm.facade.struct.TrainingProgramPartyWaiverDetails;
import curam.cpm.facade.struct.TrainingProgramStatusHistoryDetails;
import curam.cpm.facade.struct.TrainingProgramStatusHistoryDetailsList;
import curam.cpm.facade.struct.TrainingProgramSummaryDetails;
import curam.cpm.facade.struct.TrainingProgramSummaryDetailsList;
import curam.cpm.facade.struct.TrainingProgramUpdateDetails;
import curam.cpm.facade.struct.TrainingProviderDetails;
import curam.cpm.facade.struct.TrainingRequirementSummaryDetails;
import curam.cpm.facade.struct.TrainingSummaryDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderPartyKey;
import curam.cpm.sl.entity.struct.TrainingKey;
import curam.cpm.sl.entity.struct.TrainingProgramKey;
import curam.cpm.sl.entity.struct.TrainingProgramMemberKey;
import curam.cpm.sl.entity.struct.TrainingServiceOfferingDtls;
import curam.cpm.util.impl.WidgetHelper;
import curam.message.TRAININGPROGRAM;
import curam.message.impl.TRAININGPROGRAMExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.impl.LicenseTrainingRequirement;
import curam.provider.impl.LicenseTrainingRequirementDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderMember;
import curam.provider.impl.ProviderMemberDAO;
import curam.provider.impl.ProviderMemberRoleEntry;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.provider.impl.ProviderSecurity;
import curam.provider.impl.ProviderStatusEntry;
import curam.provider.impl.TrainingCompletionEntry;
import curam.serviceoffering.impl.SOTrainingRequirement;
import curam.serviceoffering.impl.SOTrainingRequirementDAO;
import curam.serviceoffering.impl.TrainingServiceOfferingDAO;
import curam.training.impl.ProviderMemberTrainingProgram;
import curam.training.impl.Training;
import curam.training.impl.TrainingCredit;
import curam.training.impl.TrainingCreditDAO;
import curam.training.impl.TrainingDAO;
import curam.training.impl.TrainingProgramDAO;
import curam.training.impl.TrainingProgramMember;
import curam.training.impl.TrainingProgramMemberDAO;
import curam.training.impl.TrainingStatusHistory;
import curam.training.impl.TrainingStatusHistoryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.StringHelper;
import curam.util.type.StringList;


/**
 * Facade layer class having API for managing Provider training program.
 *
 */
public abstract class MaintainProviderTrainingProgram extends curam.cpm.facade.base.MaintainProviderTrainingProgram {

  /**
   * Reference to Training Program DAO
   */
  @Inject
  protected TrainingProgramDAO trainingProgramDAO;

  /**
   * Reference to Training DAO
   */
  @Inject
  protected TrainingDAO trainingDAO;

  /**
   * Reference to Provider DAO
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to Provider Member DAO
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  /**
   * Reference to Training Program Member DAO
   */
  @Inject
  protected TrainingProgramMemberDAO trainingProgramMemberDAO;

  /**
   * Reference to Provider Security
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * Reference to Provider Organization DAO
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Reference to Concern Role DAO
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Reference to Training Service Offering DAO
   */
  @Inject
  protected TrainingServiceOfferingDAO trainingServiceOfferingDAO;

  /**
   * Reference to Service Offering Training Requirement DAO
   */
  @Inject
  protected SOTrainingRequirementDAO soTrainingRequirementDAO;

  /**
   * Reference to License Training Requirement DAO
   */
  @Inject
  protected LicenseTrainingRequirementDAO licenseTrainingRequirementDAO;

  /**
   * Reference to Approve Provider Member Training Program Strategy
   */
  @Inject
  protected ProviderMemberTrainingProgram providerMemberTrainingProgram;

  /**
   * Reference to Training Credit DAO.
   */
  @Inject
  protected TrainingCreditDAO trainingCreditDAO;

  // BEGIN, CR00234644, GP
  /**
   * Reference to Training Status History DAO
   */
  @Inject
  protected TrainingStatusHistoryDAO trainingStatusHistoryDAO;
  
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;
  // END, CR00234644
  
  /**
   * Default constructor
   */
  public MaintainProviderTrainingProgram() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Adds a new provider member to a training program.
   *
   * @param details
   * New training program member details.
   * @return Training program key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramKey addProviderMemberToTrainingProgram(
    TrainingProgramMemberAddDetails details) throws AppException,
      InformationalException {

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProgramID);

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.providerOrganizationID);

    // Check for provider security and check if provider is closed
    trainingProgram.validateProviderOrganization(providerOrganization);

    TrainingProgramKey trainingProgramKey = new TrainingProgramKey();

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();
    ConcernRole concernRole = concernRoleDAO.get(details.partyConcernRoleID);

    trainingProgramMember.setPartyConcernRole(concernRole);
    trainingProgramMember.setCompletion(
      TrainingCompletionEntry.get(details.completion));
    trainingProgramMember.setTrainingProgram(trainingProgram);
    trainingProgramMember.setUnitsRequired(details.unitsRequired);
    trainingProgramMember.setMemberType(CPMConstants.kProvider);

    // Create training program member record.
    trainingProgramMember.insert();

    trainingProgramKey.trainingProgramID = details.trainingProgramID;

    return trainingProgramKey;
  }

  /**
   * Creates training program for a Provider. Training Program Member details
   * are inserted for each Provider Member under the Provider.
   *
   * @param trainingProgram
   * Contains training details, training provider and party details.
   * @return Training program key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_PROVIDER_IS_CLOSED_TRAINING_CANNOT_BE_CREATED_FOR_PROVIDER_MEMBER} -
   * if the provider is closed.
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_ATLEAST_ONE_PROVIDERMEMBER_MUST_BE_SELECTED_FOR_TRAINING_PROGRAM} -
   * if there are no provider members selected for the training.
   */
  public TrainingProgramKey createTrainingProgramForProvider(
    TrainingProgram trainingProgram) throws AppException,
      InformationalException {

    TrainingProgramKey trainingProgramKey = new TrainingProgramKey();

    curam.provider.impl.Provider provider = providerDAO.get(
      trainingProgram.concernRoleID);

    // check appropriate security privileges
    providerSecurity.checkProviderSecurity(provider);

    // Validate if the Provider is closed.
    if ((provider.getLifecycleState().equals(ProviderStatusEntry.CLOSED))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_PROVIDER_IS_CLOSED_TRAINING_CANNOT_BE_CREATED_FOR_PROVIDER_MEMBER(
          provider.getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    // Convert the xml to Training Program Party List
    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList = WidgetHelper.convertXmlToConcernMemberTrainingProgram(
      trainingProgram);

    // Validate that at least one member is selected for the training
    // program.
    if (trainingProgramPartyDetailsList.partyDetails.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_ATLEAST_ONE_PROVIDERMEMBER_MUST_BE_SELECTED_FOR_TRAINING_PROGRAM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

    }
    ConcernRoleMemberDetails concernRoleMemberDetails = new ConcernRoleMemberDetails();

    concernRoleMemberDetails.memberTrainingWidget = trainingProgram.trainingDetails;

    TrainingPartyCreateDetailsList trainingPartyCreateDetailsList = WidgetHelper.convertXmlToMemberTrainingProgram(
      concernRoleMemberDetails);
    // BEGIN CR00113504, SS
    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      trainingProgram.concernRoleID);

    // Validate the provider members selected for the training program
    validateMembers(trainingPartyCreateDetailsList,
      sortPartyDetailsList(trainingProgramPartyDetailsList),
      providerOrganization);
    // END CR00113504
    for (TrainingPartyCreateDetails trainingPartyCreateDetails : trainingPartyCreateDetailsList.detailsList.items()) {

      curam.training.impl.TrainingProgram trainingProgramImpl = setTrainingProgram(
        trainingPartyCreateDetails, trainingProgram.providerID,
        trainingProgram.concernRoleID);

      // Security check for Provider.
      trainingProgramImpl.validateProviderOrganization(providerOrganization);

      // Create training program record.
      trainingProgramImpl.insert();

      trainingProgramKey.trainingProgramID = trainingProgramImpl.getID();

      for (TrainingProgramPartyDetails trainingProgramPartyDetails : trainingProgramPartyDetailsList.partyDetails.items()) {

        TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();

        ConcernRole concernRole = concernRoleDAO.get(
          trainingProgramPartyDetails.partyConcernRoleID);

        trainingProgramMember.setPartyConcernRole(concernRole);
        trainingProgramMember.setCompletion(
          TrainingCompletionEntry.get(trainingProgramPartyDetails.completion));
        trainingProgramMember.setTrainingProgram(trainingProgramImpl);
        trainingProgramMember.setUnitsRequired(
          trainingProgramPartyDetails.unitsRequired);
        trainingProgramMember.setMemberType(CPMConstants.kProvider);

        // Create training program member record.
        trainingProgramMember.insert();
      }
    }

    return trainingProgramKey;
  }

  /**
   * Creates training program for a provider member.
   *
   * @param details
   * Contains training program details and training provider.
   *
   * @return Training program key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramKey createTrainingProgramForProviderMember(
    TrainingPartyCreateDetails details) throws AppException,
      InformationalException {

    TrainingProgramKey trainingProgramKey = new TrainingProgramKey();

    curam.training.impl.TrainingProgram trainingProgram = setTrainingProgram(
      details);

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.providerOrganizationID);

    // Check for provider security and check if provider is closed
    trainingProgram.validateProviderOrganization(providerOrganization);

    // Create training program record.
    trainingProgram.insert();

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();
    ConcernRole concernRole = concernRoleDAO.get(details.concernRoleID);

    trainingProgramMember.setPartyConcernRole(concernRole);
    trainingProgramMember.setCompletion(
      TrainingCompletionEntry.get(details.completion));
    trainingProgramMember.setTrainingProgram(trainingProgram);
    trainingProgramMember.setUnitsRequired(details.unitsRequired);
    trainingProgramMember.setMemberType(CPMConstants.kProviderMember);

    // Create training program member record.
    trainingProgramMember.insert();

    // set the training program id in the return struct
    trainingProgramKey.trainingProgramID = trainingProgram.getID();

    return trainingProgramKey;

  }

  /**
   * Deletes the specified Provider Member Training Program.
   *
   * @param trainingProgramConcernRoleVersionKey
   * Contains Training Program Member ID, Provider Concern Role ID,
   * version number
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_TRAININGPROGRAM_IS_NOT_ACTIVE_CANNOT_BE_CANCELED} -
   * If training program for provider member is already deleted.
   */
  public void deleteProviderMemberTrainingProgram(
    TrainingProgramConcernRoleVersionKey trainingProgramConcernRoleVersionKey)
    throws AppException, InformationalException {

    boolean hasActiveMembers = false;

    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      trainingProgramConcernRoleVersionKey.trainingProgramMemberID);

    // check appropriate security privileges
    curam.provider.impl.Provider provider = providerDAO.get(
      trainingProgramConcernRoleVersionKey.concernRoleID);

    providerSecurity.checkProviderSecurity(provider);

    if (trainingProgramMember.getLifecycleState().equals(
      TRAININGPROGRAMPARTYSTATUSEntry.CANCELED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_TRAININGPROGRAM_IS_NOT_ACTIVE_CANNOT_BE_CANCELED(
          trainingProgramMember.getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          3);
    }

    // Cancel the Training Program Member.
    trainingProgramMember.cancel(
      trainingProgramConcernRoleVersionKey.trainingProgramMemberVersionNo);

    // now retrieve all the training program members and check if all are
    // canceled.
    // if yes, cancel the training program also
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramMember.getTrainingProgram();

    Set<TrainingProgramMember> trainingProgramMemberList = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
      trainingProgram.getID());

    for (TrainingProgramMember trainingProgMember : trainingProgramMemberList) {
      // if one of the members is not in canceled state
      // set the boolean flag
      if (!trainingProgMember.getLifecycleState().equals(
        TRAININGPROGRAMPARTYSTATUSEntry.CANCELED)) {
        hasActiveMembers = true;
      }
    }

    if (!hasActiveMembers) {
      trainingProgram.cancel(
        trainingProgramConcernRoleVersionKey.trainingProgramVersionNo);
    }

  }

  /**
   * Deletes the specified Provider Training Program.
   *
   * @param trainingProgramAndConcernRoleKey
   * Contains Training Program ID, Provider Concern Role ID, version
   * number
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_TRAININGPROGRAM_IS_NOT_ACTIVE_CANNOT_BE_CANCELED} -
   * If training program for provider is already deleted.
   */
  public void deleteProviderTrainingProgram(
    TrainingProgramAndConcernRoleKey trainingProgramAndConcernRoleKey)
    throws AppException, InformationalException {

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      trainingProgramAndConcernRoleKey.trainingProgramID);

    // check appropriate security privileges
    curam.provider.impl.Provider provider = providerDAO.get(
      trainingProgramAndConcernRoleKey.concernRoleID);

    providerSecurity.checkProviderSecurity(provider);

    if (trainingProgram.getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_TRAININGPROGRAM_IS_NOT_ACTIVE_CANNOT_BE_CANCELED(
          trainingProgram.getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }

    // Fetch all Member Training Programs for the Training Program
    Set<curam.training.impl.TrainingProgramMember> trainingProgramMembers = trainingProgramMemberDAO.getTrainingProgramMembersForConcernRole(
      trainingProgramAndConcernRoleKey.trainingProgramID,
      trainingProgram.getTrainingProgramOwner().getID());

    // Cancel all the member training programs for the training program
    for (final curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMembers) {
      trainingProgramMember.cancel(trainingProgramMember.getVersionNo());
    }

    // Cancel the training program
    trainingProgram.cancel(trainingProgram.getVersionNo());

  }

  /**
   * Lists the member based on concern role id.
   *
   * @param key
   * Contains the concern role id.
   * @return ConcernRoleMemberDetails Contains the member details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ConcernRoleMemberDetails listProviderMembers(ConcernRoleKey key)
    throws AppException, InformationalException {
    ConcernRoleMemberDetails concernRoleMemberDetails = new ConcernRoleMemberDetails();

    curam.provider.impl.Provider provider = providerDAO.get(key.concernRoleID);

    Set<curam.provider.impl.ProviderMember> providerMembers = provider.getProviderMembers();
    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList = new TrainingProgramPartyDetailsList();

    // get the all active provider members
    for (curam.provider.impl.ProviderMember providerMember : providerMembers) {

      if (providerMember.getLifecycleState().getCode().equals(
        RECORDSTATUSEntry.NORMAL.getCode())) {
        TrainingProgramPartyDetails trainingProgramPartyDetails = new TrainingProgramPartyDetails();

        trainingProgramPartyDetails.partyConcernRoleID = providerMember.getParty().getID();
        trainingProgramPartyDetails.partyName = providerMember.getParty().getName();
        trainingProgramPartyDetails.role = ProviderMemberRoleEntry.get(providerMember.getRole().getCode()).toUserLocaleString();
        trainingProgramPartyDetailsList.partyDetails.addRef(
          trainingProgramPartyDetails);
      }
    }

    if (trainingProgramPartyDetailsList.partyDetails.size() > 0) {
      String strMemberDetails = WidgetHelper.convertRecordCompletedTrainingToXml(
        sortPartyDetailsList(trainingProgramPartyDetailsList));

      concernRoleMemberDetails.memberTrainingWidget = strMemberDetails;
    }
    concernRoleMemberDetails.providerOrganizationID = key.concernRoleID;
    return concernRoleMemberDetails;
  }

  /**
   * Marks the provider member training program to complete.
   *
   * @param details
   * Contains the training program complete details.
   * TrainingProgramMemberKey Returns the training program member key.
   * @return TrainingProgramMemberKey returns the training program member key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramMemberKey markProviderMemberTrainingProgramComplete(
    TrainingProgramCompleteDetails details) throws AppException,
      InformationalException {

    TrainingProgramMemberKey trainingProgramMemberKey = new TrainingProgramMemberKey();

    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    // set the training member data
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setCreditsAchieved(details.creditsAchieved);
    trainingProgramMember.setUnitsCompleted(details.unitsCompleted);
    // call the interface method to mark
    trainingProgramMember.markTrainingMemberProgramComplete(
      details.partyVersionNo);

    return trainingProgramMemberKey;
  }

  /**
   * Records a training program for a provider member that was completed outside
   * the agency.
   *
   * @param details
   * Contains the training program completed details for recording.
   * @return TrainingProgramMemberKey Contains the training program member key
   * which is recorded.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramMemberKey recordCompletedProviderMemberTrainingProgram(
    TrainingProgramCompletedDetails details) throws AppException,
      InformationalException {

    // training program instance
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.newInstance();
    // training program member instance
    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.providerOrganizationID);

    // set the provider program details
    setRecordCompletedProviderProgramDetails(details, trainingProgram);

    trainingProgram.recordCompletedTrainingProgram(providerOrganization);

    details.trainingProviderDetails.trainingProgramID = trainingProgram.getID();
    // set the provider program member details
    setRecordCompletedProviderProgramMemberDetails(details,
      trainingProgramMember);
    trainingProgramMember.recordCompletedTrainingMemberProgram();

    TrainingProgramMemberKey trainingProgramMemberKey = new TrainingProgramMemberKey();

    trainingProgramMemberKey.trainingProgramMemberID = trainingProgramMember.getID();

    return trainingProgramMemberKey;
  }

  /**
   * Records a training program for a provider that was completed outside the
   * agency.
   *
   * @param details
   * Contains the training program completed details for recording.
   * @return TrainingProgramKey Contains the training program key which is
   * recorded.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramKey recordCompletedTrainingProgramForProvider(
    TrainingProgramAndPartyCompletedDetails details) throws AppException,
      InformationalException {

    TrainingProgramKey trainingProgramKey = new TrainingProgramKey();

    // training program instance
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.newInstance();
    // Provider Organization instance
    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.providerOrganizationID);

    // set the provider program details
    setRecordCompletedTrainingProgramDetails(details, trainingProgram);

    trainingProgram.recordCompletedTrainingProgram(providerOrganization);

    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList;

    trainingProgramPartyDetailsList = WidgetHelper.convertXmlToRecordCompletedTraining(
      details.trainingDetails);

    // Validate that at least one member is selected for the training
    // program.
    if (trainingProgramPartyDetailsList.partyDetails.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_ATLEAST_ONE_PROVIDERMEMBER_MUST_BE_SELECTED_FOR_TRAINING_PROGRAM(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);

    }
    ValidationHelper.failIfErrorsExist();

    if (trainingProgramPartyDetailsList.partyDetails.size() > 0) {
      validateRecordCompleted(
        sortPartyDetailsList(trainingProgramPartyDetailsList));

      for (TrainingProgramPartyDetails trainingProgramPartyDetails : trainingProgramPartyDetailsList.partyDetails.items()) {
        // training program member instance
        curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();

        setRecordCompletedProgramMemberDetails(trainingProgramPartyDetails,
          trainingProgramMember, trainingProgram);
        trainingProgramMember.recordCompletedTrainingMemberProgram();
      }
    }
    trainingProgramKey.trainingProgramID = trainingProgram.getID();
    return trainingProgramKey;
  }

  /**
   * Retrieves the provider member details based on training service offering.
   *
   * @param key
   * Contains service offering trainings.
   * @return Training program party details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingPartyCreateDetails retrieveProviderMemberTrainingProgram(
    TrainingKey key) throws AppException, InformationalException {

    TrainingPartyCreateDetails trainingPartyCreateDetails = new TrainingPartyCreateDetails();

    Training training = trainingDAO.get(key.trainingID);

    trainingPartyCreateDetails.trainingID = training.getID();
    trainingPartyCreateDetails.trainingName = training.getName();
    trainingPartyCreateDetails.authorizedFrom = Date.getCurrentDate();

    TrainingKey trainingKey = new TrainingKey();

    trainingKey.trainingID = key.trainingID;

    TrainingServiceOfferingDtls trainingServiceOfferingDtls = trainingServiceOfferingDAO.readByTraining(
      trainingKey);

    if (trainingServiceOfferingDtls != null
      && trainingServiceOfferingDtls.trainingServiceOfferingID != 0) {
      trainingPartyCreateDetails.unitsRequired = trainingServiceOfferingDtls.unitsRequired;
    }

    return trainingPartyCreateDetails;
  }

  /**
   * Retrieves the training programs for the provider members under a Provider.
   *
   * @param trainingAndConcernRolekey
   * Contains service offering trainings and concern role ID of
   * Provider.
   * @return Training program party widget details in xml format.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgram retrieveProviderTrainingProgram(
    TrainingAndConcernRolekey trainingAndConcernRolekey) throws AppException,
      InformationalException {

    TrainingProgram trainingProgram = new TrainingProgram();

    // Create StringList from training IDs List
    StringList trainingIDList = StringUtil.delimitedText2StringList(
      trainingAndConcernRolekey.training, '\t');

    ArrayList<TrainingServiceOfferingDtls> unitsRequiredList = new ArrayList<TrainingServiceOfferingDtls>();

    for (String trainingIDString : trainingIDList.items()) {

      StringList completionList = StringUtil.delimitedText2StringList(
        trainingIDString, '|');

      TrainingKey trainingKey = new TrainingKey();

      trainingKey.trainingID = Long.parseLong(completionList.item(0));

      TrainingServiceOfferingDtls trainingServiceOfferingDtls = trainingServiceOfferingDAO.readByTraining(
        trainingKey);

      unitsRequiredList.add(trainingServiceOfferingDtls);
    }

    int unitsRequiredCounter = 0;
    int unitsRequired = 0;

    Iterator<TrainingServiceOfferingDtls> unitsRequiredItr = unitsRequiredList.iterator();

    while (unitsRequiredItr.hasNext()) {

      TrainingServiceOfferingDtls trainingServiceOfferingDtls = unitsRequiredItr.next();

      if (trainingServiceOfferingDtls != null) {
        if (unitsRequiredCounter == 0) {
          unitsRequired = trainingServiceOfferingDtls.unitsRequired;
          unitsRequiredCounter++;
        } else {
          if (trainingServiceOfferingDtls.unitsRequired == unitsRequired) {
            unitsRequiredCounter++;
          }
        }
      }
    }

    TrainingPartyCreateDetailsList trainingPartyCreateDetailsList = new TrainingPartyCreateDetailsList();

    // Populate the training details into a list
    for (String trainingIDString : trainingIDList.items()) {

      TrainingPartyCreateDetails trainingPartyCreateDetails = new TrainingPartyCreateDetails();

      StringList completionList = StringUtil.delimitedText2StringList(
        trainingIDString, '|');

      curam.training.impl.Training training = null;

      if (completionList.size() > 1) {
        training = trainingDAO.get(Long.valueOf(completionList.item(0)));
        trainingPartyCreateDetails.completion = completionList.item(1);
      } else {
        training = trainingDAO.get(Long.valueOf(completionList.item(0)));
      }

      trainingPartyCreateDetails.trainingID = training.getID();
      trainingPartyCreateDetails.trainingName = training.getName();
      trainingPartyCreateDetails.authorizedFrom = Date.getCurrentDate();

      trainingPartyCreateDetailsList.detailsList.addRef(
        trainingPartyCreateDetails);
    }

    // Convert the training details to an xml.
    String strTrainingDetails = WidgetHelper.convertMemberTrainingProgramToXml(
      trainingPartyCreateDetailsList);

    trainingProgram.trainingDetails = strTrainingDetails;

    // Populate the Active Provider members under a provider
    curam.provider.impl.Provider provider = providerDAO.get(
      trainingAndConcernRolekey.concernRoleID);

    Set<ProviderMember> providerMembers = provider.getProviderMembers();

    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList = new TrainingProgramPartyDetailsList();

    for (ProviderMember providerMember : providerMembers) {

      if (providerMember.getLifecycleState().getCode().equals(
        RECORDSTATUSEntry.NORMAL.getCode())) {
        TrainingProgramPartyDetails trainingProgramPartyDetails = new TrainingProgramPartyDetails();

        trainingProgramPartyDetails.partyConcernRoleID = providerMember.getParty().getID();
        trainingProgramPartyDetails.partyName = providerMember.getParty().getName();
        trainingProgramPartyDetails.role = ProviderMemberRoleEntry.get(providerMember.getRole().getCode()).toUserLocaleString();

        if (unitsRequiredList.size() == unitsRequiredCounter) {
          trainingProgramPartyDetails.unitsRequired = unitsRequired;
        }
        trainingProgramPartyDetailsList.partyDetails.addRef(
          trainingProgramPartyDetails);
      }
    }

    // Convert the active provider members list to an xml.
    String strMemberDetails = WidgetHelper.convertConcernMemberTrainingProgramToXml(
      sortPartyDetailsList(trainingProgramPartyDetailsList));

    trainingProgram.memberDetails = strMemberDetails;

    return trainingProgram;
  }

  /**
   * Updates the completed training program for provider member.
   *
   * @param details
   * Training program details to be updated.
   * @return Training program member key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramMemberKey updateCompletedProviderMemberTrainingProgram(
    TrainingProgramCompleteDetails details) throws AppException,
      InformationalException {

    // Check appropriate security privileges
    curam.provider.impl.Provider provider = providerDAO.get(
      details.providerOrganizationID);

    providerSecurity.checkProviderSecurity(provider);

    // Update the training program member
    TrainingProgramMemberKey trainingProgramMemberKey = new TrainingProgramMemberKey();

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    trainingProgramMember.setCreditsAchieved(details.creditsAchieved);
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setUnitsCompleted(details.unitsCompleted);

    trainingProgramMember.modify(details.partyVersionNo);

    trainingProgramMemberKey.trainingProgramMemberID = details.trainingProgramMemberID;

    return trainingProgramMemberKey;
  }

  /**
   * Updates the completed training program details for a provider.
   *
   * @param details
   * Training program details to be updated.
   * @return Training program key.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramKey updateCompletedProviderTrainingProgram(
    TrainingProviderDetails details) throws AppException,
      InformationalException {

    TrainingProgramKey trainingProgramKey = new TrainingProgramKey();

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProgramID);

    // Check appropriate security privileges
    curam.provider.impl.Provider provider = providerDAO.get(
      details.concernRoleID);

    providerSecurity.checkProviderSecurity(provider);

    if (details.trainingID == 0) {
      trainingProgram.setTraining(null);
    } else {
      Training training = trainingDAO.get(details.trainingID);

      trainingProgram.setTraining(training);
    }
    trainingProgram.setTrainingName(details.trainingName);

    if (details.trainingProviderID == 0) {
      trainingProgram.setTrainingProvider(null);
    } else {
      Provider trainingProvider = providerDAO.get(details.trainingProviderID);

      trainingProgram.setTrainingProvider(trainingProvider);
    }
    trainingProgram.setTrainingProviderDetails(details.trainingProviderDetails);

    trainingProgram.updateCompletedTrainingProgram(details.versionNo);

    return trainingProgramKey;
  }

  /**
   * Updates Provider Training Program.
   *
   * @param trainingProgramUpdateDetails
   * Contains Training Program details to update.
   * @return TrainingProgramKey Contains Training Program ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramKey updateProviderTrainingProgram(
    TrainingProgramUpdateDetails trainingProgramUpdateDetails)
    throws AppException, InformationalException {

    // Return key struct.
    TrainingProgramKey trainingProgramKey = new TrainingProgramKey();

    // Get the instance of the Training Program to be modified.
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      trainingProgramUpdateDetails.trainingProgramID);

    // Check appropriate security privileges.
    curam.provider.impl.Provider provider = providerDAO.get(
      trainingProgram.getTrainingProgramOwner().getID());

    providerSecurity.checkProviderSecurity(provider);

    // Set the updated details for Training Program.
    trainingProgram.setDateRange(
      new DateRange(trainingProgramUpdateDetails.authorizedFrom,
      trainingProgramUpdateDetails.toBeCompletedBy));

    trainingProgram.setUnitAmount(trainingProgramUpdateDetails.unitAmount);

    // Modify the Training Program.
    trainingProgram.modify(trainingProgramUpdateDetails.versionNo);

    // Assign value to the return key.
    trainingProgramKey.trainingProgramID = trainingProgram.getID();
    return trainingProgramKey;
  }

  /**
   * Reads the Training Program details for update.
   *
   * @param trainingProgramKey
   * Contains Training Program ID.
   * @return TrainingProgramUpdateDetails Contains Training Program details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramUpdateDetails readTrainingProgramForUpdate(
    TrainingProgramKey trainingProgramKey) throws AppException,
      InformationalException {

    // Return struct.
    TrainingProgramUpdateDetails trainingProgramUpdateDetails = new TrainingProgramUpdateDetails();

    // Get the instance of the Training Program.
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      trainingProgramKey.trainingProgramID);

    // Assign the details to return struct.
    trainingProgramUpdateDetails.trainingProgramID = trainingProgram.getID();
    if (trainingProgram.getTraining() == null) {
      trainingProgramUpdateDetails.trainingName = trainingProgram.getTrainingName();
    } else {
      trainingProgramUpdateDetails.trainingName = trainingProgram.getTraining().getName();
    }
    trainingProgramUpdateDetails.unitAmount = trainingProgram.getUnitAmount();
    trainingProgramUpdateDetails.authorizedFrom = trainingProgram.getDateRange().start();
    trainingProgramUpdateDetails.toBeCompletedBy = trainingProgram.getDateRange().end();
    trainingProgramUpdateDetails.versionNo = trainingProgram.getVersionNo();

    return trainingProgramUpdateDetails;
  }

  /**
   * Retrieves the training details for a provider member.
   *
   * @param key
   * Training program member key.
   * @return Training details for a provider member.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingPartyDetails viewCompletedProviderMemberTrainingProgram(
    TrainingProgramMemberKey key) throws AppException, InformationalException {

    TrainingPartyDetails trainingPartyDetails = new TrainingPartyDetails();

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      key.trainingProgramMemberID);

    // Get the name of the program member based on his concern role id.
    Long concernRoleID = new Long(
      trainingProgramMember.getPartyConcernRole().getID());
    ConcernRole concernRole = concernRoleDAO.get(concernRoleID);

    trainingPartyDetails.partyName = concernRole.getName();
    trainingPartyDetails.status = trainingProgramMember.getLifecycleState().getCode();
    trainingPartyDetails.dateCompleted = trainingProgramMember.getDateCompleted();
    trainingPartyDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
    trainingPartyDetails.trainingProgramMemberID = trainingProgramMember.getID();
    trainingPartyDetails.partyVersionNo = trainingProgramMember.getVersionNo();
    trainingPartyDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
    trainingPartyDetails.trainingProgramID = trainingProgramMember.getTrainingProgram().getID();
    trainingPartyDetails.partyConcernRoleID = trainingProgramMember.getPartyConcernRole().getID();
    trainingPartyDetails.trainingProgramDetails.versionNo = trainingProgramMember.getTrainingProgram().getVersionNo();

    return trainingPartyDetails;
  }

  /**
   * Retrieves training program details not managed through agency for a
   * provider.
   *
   * @param key
   * Training program key.
   * @return Training program details for a provider.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramAndPartyDetails viewCompletedTrainingNotManagedByAgency(
    TrainingProgramKey key) throws AppException, InformationalException {

    TrainingProgramAndPartyDetails trainingProgramAndPartyDetails = new TrainingProgramAndPartyDetails();

    // Get the training program for the given training program id.
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      key.trainingProgramID);

    trainingProgramAndPartyDetails.trainingProgramDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();
    if (trainingProgram.getTraining() == null) {
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingName = trainingProgram.getTrainingName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingNameDisplayString = trainingProgram.getTrainingName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingRegisteredInd = false;
    } else {
      trainingProgramAndPartyDetails.trainingProgramDetails.registeredTrainingName = trainingProgram.getTraining().getName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingNameDisplayString = trainingProgram.getTraining().getName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingID = trainingProgram.getTraining().getID();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingRegisteredInd = true;
    }
    trainingProgramAndPartyDetails.trainingProgramDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();
    trainingProgramAndPartyDetails.trainingProgramDetails.versionNo = trainingProgram.getVersionNo();

    if (trainingProgram.getTrainingProvider() != null) {
      trainingProgramAndPartyDetails.trainingProgramDetails.registeredTrainingProviderName = trainingProgram.getTrainingProvider().getName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingProviderID = trainingProgram.getTrainingProvider().getID();
    } else {
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
    }

    Set<curam.training.impl.TrainingProgramMember> trainingProgramMembers = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
      key.trainingProgramID);

    // Set the provider member training program details.
    for (curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMembers) {

      TrainingProgramPartyDetails trainingProgramPartyDetails = new TrainingProgramPartyDetails();

      trainingProgramPartyDetails.status = trainingProgramMember.getLifecycleState().getCode();
      trainingProgramPartyDetails.trainingProgramMemberID = trainingProgramMember.getID();
      trainingProgramPartyDetails.versionNo = trainingProgramMember.getVersionNo();
      trainingProgramPartyDetails.partyConcernRoleID = trainingProgramMember.getPartyConcernRole().getID();

      // Get the name of the program member based on his concern role id.
      Long concernRoleID = new Long(
        trainingProgramMember.getPartyConcernRole().getID());
      ConcernRole concernRole = concernRoleDAO.get(concernRoleID);

      trainingProgramPartyDetails.partyName = concernRole.getName();
      // BEGIN, CR00233952, SSK
      trainingProgramPartyDetails.dateCompleted = trainingProgramMember.getDateCompleted();
      trainingProgramPartyDetails.unitsCompleted = Short.valueOf(
        Integer.toString(trainingProgramMember.getUnitsCompleted()));
      // END, CR00233952

      
      trainingProgramAndPartyDetails.partyDetailsList.partyDetails.addRef(
        trainingProgramPartyDetails);
    }

    return trainingProgramAndPartyDetails;
  }

  /**
   * Retrieves training program details not managed through agency for a
   * provider member.
   *
   * @param key
   * Training program key.
   * @return Training program details for a provider member.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramPartyCompletedDetails viewMemberCompletedTrainingNotManagedByAgency(
    TrainingProgramKey key) throws AppException, InformationalException {

    TrainingProgramPartyCompletedDetails trainingProgramPartyCompletedDetails = new TrainingProgramPartyCompletedDetails();

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      key.trainingProgramID);

    Set<curam.training.impl.TrainingProgramMember> trainingProgramMembers = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
      key.trainingProgramID);

    // Set the provider member training program details.
    for (curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMembers) {
      trainingProgramPartyCompletedDetails.status = trainingProgramMember.getLifecycleState().getCode();
      trainingProgramPartyCompletedDetails.dateCompleted = trainingProgramMember.getDateCompleted();
      trainingProgramPartyCompletedDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
      trainingProgramPartyCompletedDetails.trainingProgramMemberID = trainingProgramMember.getID();
      trainingProgramPartyCompletedDetails.trainingProgramMemberVersionNo = trainingProgramMember.getVersionNo();
      trainingProgramPartyCompletedDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
    }

    trainingProgramPartyCompletedDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();

    if (trainingProgram.getTraining() == null) {
      trainingProgramPartyCompletedDetails.trainingName = trainingProgram.getTrainingName();
      trainingProgramPartyCompletedDetails.trainingRegisteredInd = false;
    } else {
      trainingProgramPartyCompletedDetails.trainingName = trainingProgram.getTraining().getName();
      trainingProgramPartyCompletedDetails.trainingID = trainingProgram.getTraining().getID();
      trainingProgramPartyCompletedDetails.trainingRegisteredInd = true;
    }
    trainingProgramPartyCompletedDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();

    if (trainingProgram.getTrainingProvider() != null) {
      trainingProgramPartyCompletedDetails.trainingProviderName = trainingProgram.getTrainingProvider().getName();
    } else {
      trainingProgramPartyCompletedDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
    }
    trainingProgramPartyCompletedDetails.trainingProgramID = trainingProgram.getID();
    trainingProgramPartyCompletedDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();

    return trainingProgramPartyCompletedDetails;
  }

  /**
   * Retrieves training program details for a provider member.
   *
   * @param key
   * contains training program ID.
   *
   * @return TrainingPartyDetails contains training program details for a
   * provider member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingPartyDetails viewProviderMemberTrainingProgram(
    TrainingProgramKey key) throws AppException, InformationalException {
    TrainingPartyDetails partyDetails = new TrainingPartyDetails();

    curam.training.impl.TrainingProgram trainingProgram = null;

    Set<curam.training.impl.TrainingProgramMember> trainingProgramMemberDetails = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
      key.trainingProgramID);

    // set training program member details
    for (curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMemberDetails) {
      partyDetails.completion = trainingProgramMember.getCompletion().toString();
      partyDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
      if (trainingProgramMember.getCreditsAchieved() > 0) {
        partyDetails.creditsAchievedString = String.valueOf(
          trainingProgramMember.getCreditsAchieved());
      }
      Date completedDate = trainingProgramMember.getDateCompleted();

      partyDetails.dateCompleted = completedDate;
      partyDetails.partyConcernRoleID = trainingProgramMember.getPartyConcernRole().getID();
      partyDetails.partyVersionNo = trainingProgramMember.getVersionNo();
      partyDetails.status = trainingProgramMember.getLifecycleState().toString();
      partyDetails.trainingProgramID = trainingProgramMember.getTrainingProgram().getID();
      partyDetails.trainingProgramMemberID = trainingProgramMember.getID();
      partyDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
      if (trainingProgramMember.getUnitsCompleted() > 0) {
        partyDetails.unitsCompletedString = String.valueOf(
          trainingProgramMember.getUnitsCompleted());
      }
      partyDetails.unitsRemaining = trainingProgramMember.getUnitsRequired()
        - trainingProgramMember.getUnitsCompleted();
      partyDetails.unitsRequired = trainingProgramMember.getUnitsRequired();

      // get training program details
      trainingProgram = trainingProgramMember.getTrainingProgram();

      // validTill needs to be calculated for members whose training
      // program
      // are in complete state.
      if (trainingProgramMember.getLifecycleState().equals(
        TRAININGPROGRAMPARTYSTATUSEntry.COMPLETE)) {
        // BEGIN CR00112382, NK
        // Get a list of Training Credit records for this training program
        // member.
        List<TrainingCredit> trainingCredits = trainingCreditDAO.searchBy(
          trainingProgramMember.getTrainingProgram().getTraining());

        // END CR00112382
        // Check if training has training credits associated to
        // it, then calculate valid till field.
        if (trainingCredits.size() > 0) {
          int days = trainingProgram.getTrainingValidDays();

          if (days > 0) {
            partyDetails.validTill = completedDate.addDays(days);
          }
        }
      }
      partyDetails.waiverExpiryDate = trainingProgramMember.getWaiverExpiryDate();
    }

    // set training program details
    partyDetails.trainingProgramDetails.authorizedFrom = trainingProgram.getDateRange().start();
    partyDetails.trainingProgramDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();
    partyDetails.trainingProgramDetails.toBeCompletedBy = trainingProgram.getDateRange().end();
    if (trainingProgram.getTraining() == null) {
      partyDetails.trainingProgramDetails.trainingName = trainingProgram.getTrainingName();
      partyDetails.trainingProgramDetails.trainingRegisteredInd = false;
    } else {
      partyDetails.trainingProgramDetails.trainingName = trainingProgram.getTraining().getName();
      partyDetails.trainingProgramDetails.trainingID = trainingProgram.getTraining().getID();
      partyDetails.trainingProgramDetails.trainingRegisteredInd = true;
    }
    partyDetails.trainingProgramDetails.trainingProgramID = trainingProgram.getID();
    partyDetails.trainingProgramDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();
    if (trainingProgram.getTrainingProvider() != null) {
      partyDetails.trainingProgramDetails.trainingProvider = trainingProgram.getTrainingProvider().getName();
    }
    partyDetails.trainingProgramDetails.unitAmount = trainingProgram.getUnitAmount();
    partyDetails.trainingProgramDetails.versionNo = trainingProgram.getVersionNo();

    return partyDetails;
  }

  /**
   * Retrieves training program details and list of members for a training
   * program.
   *
   * @param key
   * contains training program ID.
   *
   * @return TrainingProgramAndPartyDetails contains training program details
   * and the list of members for the training program.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public TrainingProgramAndPartyDetails viewProviderTrainingProgram(
    TrainingProgramKey key) throws AppException, InformationalException {
    TrainingProgramAndPartyDetails trainingProgramAndPartyDetails = new TrainingProgramAndPartyDetails();

    // get the training program for the given training program id.
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      key.trainingProgramID);

    // set all the training program details in the return struct.
    trainingProgramAndPartyDetails.trainingProgramDetails.authorizedFrom = trainingProgram.getDateRange().start();
    trainingProgramAndPartyDetails.trainingProgramDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();
    trainingProgramAndPartyDetails.trainingProgramDetails.toBeCompletedBy = trainingProgram.getDateRange().end();
    if (trainingProgram.getTraining() == null) {
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingName = trainingProgram.getTrainingName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingRegisteredInd = false;
    } else {
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingName = trainingProgram.getTraining().getName();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingID = trainingProgram.getTraining().getID();
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingRegisteredInd = true;
    }
    trainingProgramAndPartyDetails.trainingProgramDetails.trainingProgramID = trainingProgram.getID();
    trainingProgramAndPartyDetails.trainingProgramDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();
    if (trainingProgram.getTrainingProvider() != null) {
      trainingProgramAndPartyDetails.trainingProgramDetails.trainingProvider = trainingProgram.getTrainingProvider().getName();
    }
    trainingProgramAndPartyDetails.trainingProgramDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
    trainingProgramAndPartyDetails.trainingProgramDetails.unitAmount = trainingProgram.getUnitAmount();
    trainingProgramAndPartyDetails.trainingProgramDetails.versionNo = trainingProgram.getVersionNo();

    // get the members for the given training program id
    Set<TrainingProgramMember> trainingProgramMembers = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
      key.trainingProgramID);

    // set the training member details in the return struct
    for (TrainingProgramMember trainingProgramMember : trainingProgramMembers) {

      TrainingProgramPartyDetails trainingProgramPartyDetails = new TrainingProgramPartyDetails();

      trainingProgramPartyDetails.completion = trainingProgramMember.getCompletion().getCode();
      trainingProgramPartyDetails.dateCompleted = trainingProgramMember.getDateCompleted();
      trainingProgramPartyDetails.partyConcernRoleID = trainingProgramMember.getPartyConcernRole().getID();
      trainingProgramPartyDetails.status = trainingProgramMember.getLifecycleState().toString();
      trainingProgramPartyDetails.versionNo = trainingProgramMember.getVersionNo();
      trainingProgramPartyDetails.trainingProgramMemberID = trainingProgramMember.getID();
      trainingProgramPartyDetails.unitsCompleted = Short.parseShort(
        (String.valueOf(trainingProgramMember.getUnitsCompleted())));
      trainingProgramPartyDetails.unitsRequired = trainingProgramMember.getUnitsRequired();
      // get the name of the program member based on his concern role id.
      Long concernRoleID = new Long(
        trainingProgramMember.getPartyConcernRole().getID());
      ConcernRole concernRole = concernRoleDAO.get(concernRoleID);

      trainingProgramPartyDetails.partyName = concernRole.getName();
      trainingProgramAndPartyDetails.partyDetailsList.partyDetails.addRef(
        trainingProgramPartyDetails);
    }

    return trainingProgramAndPartyDetails;
  }

  /**
   * Retrieves the list of Completed Training Programs for a Provider Member.
   *
   * @param providerPartyKey
   * Contains the party ID of the Provider Member.
   * @return List of Completed Training Programs.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramList listCompletedTrainingProgramForProviderMember(
    ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerPartyKey.providerPartyID);

    TrainingProgramList trainingProgramList = new TrainingProgramList();

    curam.training.impl.TrainingProgram trainingProgram = null;

    String status = TRAININGPROGRAMPARTYSTATUSEntry.CANCELED.toString();
    Set<curam.training.impl.TrainingProgramMember> trainingProgramMemberDetails = trainingProgramMemberDAO.retrieveMemberTrainingPrograms(
      status, providerMember.getParty().getID());

    // Populate the list of Completed Training Programs for a member
    for (final curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMemberDetails) {
      trainingProgram = trainingProgramMember.getTrainingProgram();
      if (trainingProgram.isManagedThroughAgency() == false) {

        TrainingSummaryDetails trainingSummaryDetails = new TrainingSummaryDetails();

        trainingSummaryDetails.trainingProgramMemberID = trainingProgramMember.getID();
        trainingSummaryDetails.trainingProgramMemberVersionNo = trainingProgramMember.getVersionNo();
        trainingSummaryDetails.referenceNumber = trainingProgram.getReferenceNumber();
        trainingSummaryDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();
        trainingSummaryDetails.trainingProgramID = trainingProgram.getID();
        // BEGIN CR00113139, PDN
        trainingSummaryDetails.trainingProgramDateCompleted = trainingProgramMember.getDateCompleted();
        // END CR00113139
        // BEGIN, CR00247455, PS
        trainingSummaryDetails.trainingProgramStatus = trainingProgram.getLifecycleState().getCode();
        // END, CR00247455
        if (trainingProgram.getTraining() == null) {
          trainingSummaryDetails.trainingName = trainingProgram.getTrainingName();
          trainingSummaryDetails.trainingRegisteredInd = false;
        } else {
          trainingSummaryDetails.trainingName = trainingProgram.getTraining().getName();
          trainingSummaryDetails.trainingID = trainingProgram.getTraining().getID();
          trainingSummaryDetails.trainingRegisteredInd = true;
        }
        trainingProgramList.trainingSummaryList.addRef(trainingSummaryDetails);
      }
    }
    trainingProgramList = sortListTrainingPrograms(trainingProgramList);

    ConcernRole concernRole = concernRoleDAO.get(
      providerMember.getParty().getID());

    trainingProgramList.pageContextDescription = concernRole.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + concernRole.getPrimaryAlternateID();

    trainingProgramList.memberConcernRoleID = providerMember.getParty().getID();

    return trainingProgramList;
  }

  /**
   * Retrieves the list of Managed Training Programs for a Provider Member.
   *
   * @param providerPartyKey
   * Contains the party ID of the Provider Member.
   * @return List of Managed Training Programs.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link MaintainProviderTrainingProgram#listManagedTrainingProgramsForAProviderMember(ProviderPartyKey)
   * . The status which was displayed in list Managed Training
   * Program For Provider Member was improper. Changes have been
   * made to display proper status. See release note: CR00208091.
   */
  @Deprecated
  public TrainingProgramList listManagedTrainingProgramForProviderMember(
    ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerPartyKey.providerPartyID);

    TrainingProgramList trainingProgramList = new TrainingProgramList();

    curam.training.impl.TrainingProgram trainingProgram = null;

    String status = TRAININGPROGRAMPARTYSTATUSEntry.CANCELED.toString();
    Set<curam.training.impl.TrainingProgramMember> trainingProgramMemberDetails = trainingProgramMemberDAO.retrieveMemberTrainingPrograms(
      status, providerMember.getParty().getID());

    // Populate the list of Managed Training Programs for a member
    for (final curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMemberDetails) {
      trainingProgram = trainingProgramMember.getTrainingProgram();
      if (trainingProgram.isManagedThroughAgency() == true) {

        TrainingSummaryDetails trainingSummaryDetails = new TrainingSummaryDetails();

        trainingSummaryDetails.trainingProgramMemberID = trainingProgramMember.getID();
        trainingSummaryDetails.trainingProgramMemberVersionNo = trainingProgramMember.getVersionNo();
        trainingSummaryDetails.referenceNumber = trainingProgram.getReferenceNumber();
        trainingSummaryDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();
        trainingSummaryDetails.trainingProgramID = trainingProgram.getID();
        // BEGIN CR00113139, PDN
        trainingSummaryDetails.trainingProgramDateCompleted = trainingProgramMember.getDateCompleted();
        trainingSummaryDetails.trainingProgramStatus = trainingProgram.getLifecycleState().getCode();
        // END CR00113139
        if (trainingProgram.getTraining() == null) {
          trainingSummaryDetails.trainingName = trainingProgram.getTrainingName();
        } else {
          trainingSummaryDetails.trainingName = trainingProgram.getTraining().getName();
          trainingSummaryDetails.trainingID = trainingProgram.getTraining().getID();
        }
        trainingSummaryDetails.trainingProgramOwnerType = trainingProgramMember.getTrainingProgramOwnerType();

        if (trainingSummaryDetails.trainingProgramOwnerType.equals(
          CPMConstants.kProvider)) {
          trainingSummaryDetails.trainingProgramOwnerIsProvider = true;
          // BEGIN, CR00154962, ASN
          trainingSummaryDetails.trainingProgramOwnerID = trainingProgram.getTrainingProgramOwner().getID();
          // END, CR00154962
        } else if (trainingSummaryDetails.trainingProgramOwnerType.equals(
          CPMConstants.kProviderGroup)) {
          trainingSummaryDetails.trainingProgramOwnerIsProviderGroup = true;
          // BEGIN, CR00154962, ASN
          trainingSummaryDetails.trainingProgramOwnerID = trainingProgram.getTrainingProgramOwner().getID();
          // END, CR00154962
        } else {
          trainingSummaryDetails.trainingProgramOwnerIsMember = true;
          // BEGIN, CR00154962, ASN
          trainingSummaryDetails.trainingProgramOwnerID = trainingProgram.getTrainingProgramOwner().getID();
          // END, CR00154962
        }
        trainingProgramList.trainingSummaryList.addRef(trainingSummaryDetails);
      }
    }
    trainingProgramList = sortListTrainingPrograms(trainingProgramList);

    ConcernRole concernRole = concernRoleDAO.get(
      providerMember.getParty().getID());

    trainingProgramList.pageContextDescription = concernRole.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + concernRole.getPrimaryAlternateID();

    trainingProgramList.memberConcernRoleID = providerMember.getParty().getID();

    return trainingProgramList;
  }

  // BEGIN, CR00208091, RD  
  /**
   * Retrieves the list of Managed Training Programs for a Provider Member
   * displaying the status of the training program member.
   *
   * @param providerPartyKey
   * Contains the party ID of the Provider Member.
   *
   * @return List of Managed Training Programs.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramMemberList listManagedTrainingProgramsForAProviderMember(
    ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerPartyKey.providerPartyID);

    TrainingProgramMemberList trainingProgramMemberList = new TrainingProgramMemberList();

    Set<curam.training.impl.TrainingProgramMember> trainingProgramMemberDetails = trainingProgramMemberDAO.retrieveMemberTrainingPrograms(
      TRAININGPROGRAMPARTYSTATUSEntry.CANCELED.toString(),
      providerMember.getParty().getID());

    for (final curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMemberDetails) {
      curam.training.impl.TrainingProgram trainingProgram = trainingProgramMember.getTrainingProgram();

      if (trainingProgram.isManagedThroughAgency()) {

        MemberTrainingSummaryDetails memberTrainingSummaryDetails = new MemberTrainingSummaryDetails();

        memberTrainingSummaryDetails.trainingProgramMemberID = trainingProgramMember.getID();
        memberTrainingSummaryDetails.trainingProgramMemberVersionNo = trainingProgramMember.getVersionNo();
        memberTrainingSummaryDetails.referenceNumber = trainingProgram.getReferenceNumber();
        memberTrainingSummaryDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();
        memberTrainingSummaryDetails.trainingProgramID = trainingProgram.getID();
        memberTrainingSummaryDetails.trainingProgramDateCompleted = trainingProgramMember.getDateCompleted();
        memberTrainingSummaryDetails.trainingProgramMemberStatus = trainingProgramMember.getLifecycleState().getCode();

        if (null == trainingProgram.getTraining()) {
          memberTrainingSummaryDetails.trainingName = trainingProgram.getTrainingName();
        } else {
          memberTrainingSummaryDetails.trainingName = trainingProgram.getTraining().getName();
          memberTrainingSummaryDetails.trainingID = trainingProgram.getTraining().getID();

          // BEGIN CR00279651, MR
          memberTrainingSummaryDetails.trainingRegisteredInd = true;
          // END CR00279651
        }
        memberTrainingSummaryDetails.trainingProgramOwnerType = trainingProgramMember.getTrainingProgramOwnerType();

        memberTrainingSummaryDetails.trainingProgramOwnerID = trainingProgram.getTrainingProgramOwner().getID();

        if (CPMConstants.kProvider.equals(
          memberTrainingSummaryDetails.trainingProgramOwnerType)) {
          memberTrainingSummaryDetails.trainingProgramOwnerIsProvider = true;
        } else if (CPMConstants.kProviderGroup.equals(
          memberTrainingSummaryDetails.trainingProgramOwnerType)) {
          memberTrainingSummaryDetails.trainingProgramOwnerIsProviderGroup = true;
        } else {
          memberTrainingSummaryDetails.trainingProgramOwnerIsMember = true;
        }
        trainingProgramMemberList.memberTrainingSummaryList.addRef(
          memberTrainingSummaryDetails);
      }
    }
    trainingProgramMemberList = sortListMemberTrainingPrograms(
      trainingProgramMemberList);

    ConcernRole concernRole = concernRoleDAO.get(
      providerMember.getParty().getID());

    trainingProgramMemberList.pageContextDescription = concernRole.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + concernRole.getPrimaryAlternateID();

    trainingProgramMemberList.memberConcernRoleID = providerMember.getParty().getID();

    return trainingProgramMemberList;
  }

  // END, CR00208091

  // BEGIN, CR00234644, GP
  /**
   * Lists the training programs for a given provider.
   *
   * @param concernRoleKey
   * Provider for which training programs are to be retrieved.
   *
   * @return List of training programs for provider.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_NO_PROVIDERMEMBERS_FOR_PROVIDER_TRAINING_PROGRAM_CANNOT_BE_CREATED}
   * If there are no active provider members under the provider then
   * training program cannot be created.
   */
  public TrainingProgramSummaryDetailsList listTrainingProgramForProvider(
    final ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    TrainingProgramSummaryDetailsList trainingProgramSummaryDetailsList = new TrainingProgramSummaryDetailsList();
    Provider provider = providerDAO.get(concernRoleKey.concernRoleID);

    TrainingProgramList completedTrainingProgramList = listCompletedTrainingProgramForProvider(
      concernRoleKey);

    setTrainingProgramDetails(completedTrainingProgramList,
      trainingProgramSummaryDetailsList, Boolean.FALSE);

    TrainingProgramList managedTrainingProgramList = listManagedTrainingProgramForProvider(
      concernRoleKey);

    setTrainingProgramDetails(managedTrainingProgramList,
      trainingProgramSummaryDetailsList, Boolean.TRUE);

    sortTrainingPrograms(trainingProgramSummaryDetailsList);

    int countOfActiveProviderMembers = 0;

    Set<ProviderMember> providerMemberSet = provider.getProviderMembers();

    for (final ProviderMember providerMember : providerMemberSet) {

      if (RECORDSTATUSEntry.NORMAL.equals(providerMember.getLifecycleState())
        && (providerMember.getDateRange().end().isZero()
          || providerMember.getDateRange().endsInFuture())) {

        countOfActiveProviderMembers++;
      }
    }

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // No training program can be created if there are no provider members under
    // the provider.
    if (0 == countOfActiveProviderMembers) {

      trainingProgramSummaryDetailsList.createTrainingProgramInd = true;

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          TRAININGPROGRAM.ERR_TRAININGPROGRAM_FV_NO_PROVIDERMEMBERS_FOR_PROVIDER_TRAINING_PROGRAM_CANNOT_BE_CREATED),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

      String warnings[] = informationalManager.obtainInformationalAsString();

      for (final String messageText : warnings) {
        InformationalMessage informationalMessage = new InformationalMessage();

        informationalMessage.messageTest = messageText;
        trainingProgramSummaryDetailsList.informationalMessageList.dtls.add(
          informationalMessage);
      }
    } else {
      trainingProgramSummaryDetailsList.createTrainingProgramInd = false;
    }
              
    return trainingProgramSummaryDetailsList;
  }

  /**
   * Lists the training programs for provider members.
   *
   * @param providerPartyKey
   * Provider member for which training programs are to be retrieved.
   *
   * @return List of training programs for a provider member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramSummaryDetailsList listTrainingProgramForProviderMember(
    final ProviderPartyKey providerPartyKey) throws AppException,
      InformationalException {

    TrainingProgramSummaryDetailsList trainingProgramSummaryDetailsList = new TrainingProgramSummaryDetailsList();

    TrainingProgramList trainingProgramList = listCompletedTrainingProgramForProviderMember(
      providerPartyKey);
    TrainingProgramMemberList trainingProgramMemberList = listManagedTrainingProgramsForAProviderMember(
      providerPartyKey);

    setCompletedTrainingProgramList(trainingProgramList,
      trainingProgramSummaryDetailsList);
    setManagedTrainingProgramList(trainingProgramMemberList,
      trainingProgramSummaryDetailsList);

    sortTrainingPrograms(trainingProgramSummaryDetailsList);
    trainingProgramSummaryDetailsList.memberConcernRoleID = trainingProgramMemberList.memberConcernRoleID;
    trainingProgramSummaryDetailsList.createTrainingProgramInd = trainingProgramMemberList.createTrainingProgramInd;
    trainingProgramSummaryDetailsList.informationalMessageList = trainingProgramMemberList.list;
    
    return trainingProgramSummaryDetailsList;
  }

  /**
   * Retrieves status history of training program for a member.
   *
   * @param trainingProgramMemberKey
   * contains the training program ID of Provider Member/Provider Group
   * Member/ Person.
   *
   * @return Status history of training program for a member.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramStatusHistoryDetailsList viewTrainingProgramMemberStatusHistory(
    final TrainingProgramMemberKey trainingProgramMemberKey)
    throws AppException, InformationalException {

    TrainingProgramStatusHistoryDetailsList trainingProgramStatusHistoryDetailsList = new TrainingProgramStatusHistoryDetailsList();
    Set<TrainingStatusHistory> trainingStatusHistoryList = trainingStatusHistoryDAO.getTrainingStatusHistory(
      trainingProgramMemberKey.trainingProgramMemberID);

    for (final TrainingStatusHistory trainingStatusHistory : trainingStatusHistoryList) {
      TrainingProgramStatusHistoryDetails trainingProgramStatusHistoryDetails = new TrainingProgramStatusHistoryDetails();

      trainingProgramStatusHistoryDetails.dateTime = trainingStatusHistory.getStatusDateTime();
      trainingProgramStatusHistoryDetails.status = trainingStatusHistory.getStatus().toString();
      trainingProgramStatusHistoryDetails.userName = trainingStatusHistory.getUserName();

      User user = userDAO.get(trainingStatusHistory.getUserName());

      trainingProgramStatusHistoryDetails.userFullName = user.getFullName();

      trainingProgramStatusHistoryDetailsList.trainingProgramStatusHistoryDetails.addRef(
        trainingProgramStatusHistoryDetails);
    }

    return sortListTrainingProgramHistory(
      trainingProgramStatusHistoryDetailsList);
  }

  // END, CR00234644
  
  /**
   * Waive a provider member training program.
   *
   * @param details
   * Contains the Training Program Waiver details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void waiveProviderPartyTrainingProgram(
    TrainingProgramPartyWaiverDetails details) throws AppException,
      InformationalException {

    // Read the Training Program Member record.
    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.concernRoleID);

    // Perform the Provider security check.
    trainingProgramMember.validateProviderOrganization(providerOrganization);

    // Sets the waiver expiry date.
    trainingProgramMember.setWaiverExpiryDate(details.waiverExpiryDate);

    // waive of the training program.
    trainingProgramMember.waiveTrainingMemberProgram(details.partyVersionNo);

  }

  /**
   * Retrieves the list of Completed Training Programs for a Provider.
   *
   * @param concernRoleKey
   * Contains the ConcernRole ID of the Provider Member.
   * @return List of Completed Training Programs.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramList listCompletedTrainingProgramForProvider(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {
    TrainingProgramList trainingProgramList = new TrainingProgramList();

    Provider provider = providerDAO.get(concernRoleKey.concernRoleID);

    int countOfActiveProviderMembers = 0;

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    Set<curam.training.impl.TrainingProgram> trainingPrograms = trainingProgramDAO.searchBy(
      concernRoleKey.concernRoleID, Boolean.FALSE, RECORDSTATUSEntry.NORMAL);

    // Populate the list of Completed Training Programs
    for (final curam.training.impl.TrainingProgram trainingProgram : trainingPrograms) {
      TrainingSummaryDetails trainingSummaryDetails = new TrainingSummaryDetails();

      trainingSummaryDetails.referenceNumber = trainingProgram.getReferenceNumber();

      trainingSummaryDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();

      trainingSummaryDetails.trainingProgramID = trainingProgram.getID();

      if (trainingProgram.getTraining() == null) {
        trainingSummaryDetails.trainingName = trainingProgram.getTrainingName();
        trainingSummaryDetails.trainingRegisteredInd = false;
      } else {
        trainingSummaryDetails.trainingName = trainingProgram.getTraining().getName();
        trainingSummaryDetails.trainingID = trainingProgram.getTraining().getID();
        trainingSummaryDetails.trainingRegisteredInd = true;
      }

      trainingProgramList.trainingSummaryList.addRef(trainingSummaryDetails);

    }

    trainingProgramList = sortListTrainingPrograms(trainingProgramList);

    // Get the count of the active provider members.
    Set<ProviderMember> providerMemberSet = provider.getProviderMembers();

    for (ProviderMember providerMember : providerMemberSet) {
      if (RECORDSTATUSEntry.NORMAL.equals(providerMember.getLifecycleState())
        && (providerMember.getDateRange().end().isZero()
          || providerMember.getDateRange().endsInFuture())) {
        countOfActiveProviderMembers++;
      }
    }

    // No training program can be created if there are no provider members under
    // the provider.
    if ((countOfActiveProviderMembers == 0)) {
      trainingProgramList.createTrainingProgramInd = true;

    } else {
      trainingProgramList.createTrainingProgramInd = false;
    }
    return trainingProgramList;
  }

  /**
   * Retrieves the list of Managed Training Programs for a Provider.
   *
   * @param concernRoleKey
   * Contains the ConcernRole ID of the Provider Member.
   * @return List of Managed Training Programs.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramList listManagedTrainingProgramForProvider(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    TrainingProgramList trainingProgramList = new TrainingProgramList();

    Set<curam.training.impl.TrainingProgram> trainingPrograms = trainingProgramDAO.searchBy(
      concernRoleKey.concernRoleID, Boolean.TRUE, RECORDSTATUSEntry.NORMAL);

    // Populate the list of Managed Training Programs
    for (final curam.training.impl.TrainingProgram trainingProgram : trainingPrograms) {

      TrainingSummaryDetails trainingSummaryDetails = new TrainingSummaryDetails();

      trainingSummaryDetails.referenceNumber = trainingProgram.getReferenceNumber();

      trainingSummaryDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();

      trainingSummaryDetails.trainingProgramID = trainingProgram.getID();

      // BEGIN CR00113139, PDN
      trainingSummaryDetails.trainingProgramStatus = trainingProgram.getLifecycleState().getCode();
      // END CR00113139

      if (trainingProgram.getTraining() == null) {
        trainingSummaryDetails.trainingName = trainingProgram.getTrainingName();
      } else {
        trainingSummaryDetails.trainingName = trainingProgram.getTraining().getName();
        trainingSummaryDetails.trainingID = trainingProgram.getTraining().getID();
        
        // BEGIN CR00279651, MR
        trainingSummaryDetails.trainingRegisteredInd = true;
        // END CR00279651
      }

      trainingProgramList.trainingSummaryList.addRef(trainingSummaryDetails);

    }

    return sortListTrainingPrograms(trainingProgramList);
  }

  // BEGIN, CR00112653, SK

  /**
   * Method used by Resource Manager and Resource Manager Supervisor to update
   * the details of a training program for a provider member.
   *
   * @param details
   * Contains the details of the Training Program and Training Program
   * Member.
   * @return The list of informational messages.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMessageList updateProviderMemberTrainingProgram(
    TrainingProgramMemberUpdateDetails details) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();

    setTrainingProgram(details);
    setTrainingProgramMember(details);

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProgramID);

    // Check appropriate security privileges
    curam.provider.impl.Provider provider = providerDAO.get(
      details.providerOrganizationID);

    providerSecurity.checkProviderSecurity(provider);

    trainingProgram.modify(details.trainingProgramVersionNo);

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    if (!details.dateCompleted.equals(Date.kZeroDate)
      || details.creditsAchieved != 0 || details.unitsCompleted != 0) {

      // mark training program complete
      informationalMessageList = trainingProgramMember.markTrainingMemberProgramComplete(
        trainingProgramMember.getVersionNo());
    } else {
      trainingProgramMember.modify(details.trainingProgramMemberVersionNo);
    }

    return informationalMessageList;
  }

  /**
   * Method used by Resource Manager and Resource Manager Supervisor to update
   * the details of a training program for a member of a Provider.
   *
   * @param details
   * Contains the details of the Training Program and Training Program
   * Member.
   * @return The list of informational messages.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMessageList updateMemberTrainingProgramForProvider(
    TrainingProgramMemberUpdateDetails details) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();

    setTrainingProgramMember(details);

    // Check appropriate security privileges
    curam.provider.impl.Provider provider = providerDAO.get(
      details.providerOrganizationID);

    providerSecurity.checkProviderSecurity(provider);

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    if (!details.dateCompleted.equals(Date.kZeroDate)
      || details.creditsAchieved != 0 || details.unitsCompleted != 0) {

      // mark training program complete
      informationalMessageList = trainingProgramMember.markTrainingMemberProgramComplete(
        trainingProgramMember.getVersionNo());
    } else {
      trainingProgramMember.modify(details.trainingProgramMemberVersionNo);
    }

    return informationalMessageList;
  }

  // END, CR00112653

  /**
   * Populates the training credits achieved for the training.
   *
   * @param key
   * Contains training program key.
   * @return TrainingProgramCompletedDetails Contains the credits achieved.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramCompletedDetails viewProviderMemberTrainingForMarkComplete(
    TrainingProgramKey key) throws AppException, InformationalException {

    TrainingProgramCompletedDetails trainingProgramCompletedDetails = new TrainingProgramCompletedDetails();
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      key.trainingProgramID);

    trainingProgram.populateTrainingCredit();

    return trainingProgramCompletedDetails;
  }

  /**
   * Lists all the members for a given concern role.
   *
   * @param key
   * Contains Provider/provider group concern role id.
   * @return All the members for a given concern role.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PartyDetailsList listProviderMembersForAConcernRole(ConcernRoleKey key)
    throws AppException, InformationalException {

    PartyDetailsList partyDetailsList = new PartyDetailsList();

    curam.provider.impl.Provider provider = providerDAO.get(key.concernRoleID);

    Set<curam.provider.impl.ProviderMember> providerMembers = provider.getProviderMembers();

    for (curam.provider.impl.ProviderMember providerMember : providerMembers) {

      if (providerMember.getLifecycleState().getCode().equals(
        RECORDSTATUSEntry.NORMAL.getCode())) {

        PartyDetails partyDetails = new PartyDetails();

        partyDetails.partyConcernRoleID = providerMember.getParty().getID();
        partyDetails.partyName = providerMember.getParty().getName();

        partyDetailsList.partyDetails.addRef(partyDetails);
      }
    }

    return partyDetailsList;
  }

  /**
   * Retrieves the provider member details based on service offering training
   * requirement.
   *
   * @param key
   * Contains service offering training requirement ID or license
   * training requirement ID.
   * @return Training party details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingPartyCreateDetails retrieveProviderMemberTrainingProgramBasedOnTrainingRequirement(
    TrainingRequirementSummaryDetails key) throws AppException,
      InformationalException {

    TrainingPartyCreateDetails trainingPartyCreateDetails = new TrainingPartyCreateDetails();

    if (key.licenseTrainingRequirementID == 0) {
      SOTrainingRequirement soTrainingRequirement = soTrainingRequirementDAO.get(
        key.serviceOfferingTrainingRequirementID);

      trainingPartyCreateDetails.trainingID = soTrainingRequirement.getTraining().getID();
      trainingPartyCreateDetails.trainingName = soTrainingRequirement.getTraining().getName();
      trainingPartyCreateDetails.completion = soTrainingRequirement.getCompletion().getCode();
    } else {

      LicenseTrainingRequirement licenseTrainingRequirement = licenseTrainingRequirementDAO.get(
        key.licenseTrainingRequirementID);

      trainingPartyCreateDetails.trainingID = licenseTrainingRequirement.getTraining().getID();
      trainingPartyCreateDetails.trainingName = licenseTrainingRequirement.getTraining().getName();
      trainingPartyCreateDetails.completion = licenseTrainingRequirement.getCompletion().getCode();
    }

    trainingPartyCreateDetails.authorizedFrom = Date.getCurrentDate();

    TrainingKey trainingKey = new TrainingKey();

    trainingKey.trainingID = trainingPartyCreateDetails.trainingID;

    TrainingServiceOfferingDtls trainingServiceOfferingDtls = trainingServiceOfferingDAO.readByTraining(
      trainingKey);

    if (trainingServiceOfferingDtls != null
      && trainingServiceOfferingDtls.trainingServiceOfferingID != 0) {
      trainingPartyCreateDetails.unitsRequired = trainingServiceOfferingDtls.unitsRequired;
    }

    return trainingPartyCreateDetails;
  }

  /**
   * Approves the Provider Member Training Program.
   *
   * @param trainingProgramConcernRoleVersionKey
   * Contains the details required to approve the training program for
   * provider member.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public void approveProviderMemberTrainingProgram(
    TrainingProgramConcernRoleVersionKey trainingProgramConcernRoleVersionKey)
    throws AppException, InformationalException {

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      trainingProgramConcernRoleVersionKey.trainingProgramMemberID);

    KeyVersionDetails keyVersionDetails = new KeyVersionDetails();

    keyVersionDetails.id = trainingProgramConcernRoleVersionKey.concernRoleID;
    keyVersionDetails.version = trainingProgramConcernRoleVersionKey.trainingProgramMemberVersionNo;

    providerMemberTrainingProgram.approveProviderMemberTrainingProgram(
      keyVersionDetails, trainingProgramMember);

  }

  /**
   * View Training Program details for member
   *
   * @param key
   * contains Training Program Member ID
   * @return TrainingPartyDetails contains training program details for the
   * concerned member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingPartyDetails viewTrainingProgramDetailsForMember(
    TrainingProgramMemberKey key) throws AppException, InformationalException {

    TrainingPartyDetails partyDetails = new TrainingPartyDetails();

    curam.training.impl.TrainingProgram trainingProgram = null;

    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      key.trainingProgramMemberID);

    // set training program member details

    partyDetails.completion = trainingProgramMember.getCompletion().toString();

    // BEGIN, CR00112766, ABS
    // Get training program details
    trainingProgram = trainingProgramMember.getTrainingProgram();

    if (trainingProgramMember.getLifecycleState().equals(
      TRAININGPROGRAMPARTYSTATUSEntry.COMPLETE)) {
      partyDetails.creditsAchieved = trainingProgram.populateTrainingCredit();

      // BEGIN, CR00120443, KR
      if (trainingProgram.populateTrainingCredit() > 0) {
        partyDetails.creditsAchievedString = String.valueOf(
          trainingProgram.populateTrainingCredit());
      }
      // END, CR00120443
    } else {
      partyDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
    }
    // END, CR00112766

    if (trainingProgramMember.getCreditsAchieved() > 0) {
      partyDetails.creditsAchievedString = String.valueOf(
        trainingProgramMember.getCreditsAchieved());
    }
    Date completedDate = trainingProgramMember.getDateCompleted();

    partyDetails.dateCompleted = completedDate;
    partyDetails.partyConcernRoleID = trainingProgramMember.getPartyConcernRole().getID();
    partyDetails.partyVersionNo = trainingProgramMember.getVersionNo();
    partyDetails.status = trainingProgramMember.getLifecycleState().toString();
    partyDetails.trainingProgramID = trainingProgramMember.getTrainingProgram().getID();
    partyDetails.trainingProgramMemberID = trainingProgramMember.getID();
    partyDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
    if (trainingProgramMember.getUnitsCompleted() > 0) {
      partyDetails.unitsCompletedString = String.valueOf(
        trainingProgramMember.getUnitsCompleted());
    }
    partyDetails.unitsRemaining = trainingProgramMember.getUnitsRequired()
      - trainingProgramMember.getUnitsCompleted();
    partyDetails.unitsRequired = trainingProgramMember.getUnitsRequired();

    // validTill needs to be calculated for members whose training program
    // are in complete state.
    if (trainingProgramMember.getLifecycleState().equals(
      TRAININGPROGRAMPARTYSTATUSEntry.COMPLETE)) {
      // BEGIN CR00112382, NK
      // Get a list of Training Credit records for this training program
      // member.
      List<TrainingCredit> trainingCredits = trainingCreditDAO.searchBy(
        trainingProgramMember.getTrainingProgram().getTraining());

      // END CR00112382

      // Check if training has training credits associated to
      // it, then calculate valid till field.
      if (trainingCredits.size() > 0) {
        int days = trainingProgram.getTrainingValidDays();

        if (days > 0) {
          partyDetails.validTill = completedDate.addDays(days);
        }
      }
    }
    partyDetails.waiverExpiryDate = trainingProgramMember.getWaiverExpiryDate();

    // set training program details
    partyDetails.trainingProgramDetails.authorizedFrom = trainingProgram.getDateRange().start();
    partyDetails.trainingProgramDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();
    partyDetails.trainingProgramDetails.toBeCompletedBy = trainingProgram.getDateRange().end();
    if (trainingProgram.getTraining() == null) {
      partyDetails.trainingProgramDetails.trainingName = trainingProgram.getTrainingName();
    } else {
      partyDetails.trainingProgramDetails.trainingName = trainingProgram.getTraining().getName();
    }
    partyDetails.trainingProgramDetails.trainingProgramID = trainingProgram.getID();
    partyDetails.trainingProgramDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();
    if (trainingProgram.getTrainingProvider() != null) {
      partyDetails.trainingProgramDetails.trainingProvider = trainingProgram.getTrainingProvider().getName();
    }
    partyDetails.trainingProgramDetails.unitAmount = trainingProgram.getUnitAmount();
    partyDetails.trainingProgramDetails.versionNo = trainingProgram.getVersionNo();

    return partyDetails;
  }

  /**
   * Validates the members for the Provider/Provider Group.
   *
   * @param trainingPartyCreateDetailsList
   * Contains Training details which is got from the widget.
   * @param trainingProgramPartyDetailsList
   * Contains Training Program Party Details which is got from the
   * widget.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_TRAINING_PROGRAM_WITH_STATUS_OPEN_OR_APPROVED_ALREADY_EXISTS_FOR_PROVIDER_MEMBERS} -
   * if the training program already exists with the training and
   * provider member combination.
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_UNITSREQUIRED_GR_THAN_ZERO_FOR_PROVIDERMEMBERS} -
   * if the units required entered for the provider members are
   * invalid.
   */
  // BEGIN CR00113504,SS
  protected void validateMembers(
    TrainingPartyCreateDetailsList trainingPartyCreateDetailsList,
    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList,
    ProviderOrganization providerOrganization) throws InformationalException {
    // END CR00113504
    String openPartyNames = "";
    String approvedPartyNames = "";
    String invalidUnitsRequired = "";
    int openPartyNamesCounter = 0;
    int approvedPartyNamesCounter = 0;
    int invalidUnitsRequiredCounter = 0;

    for (TrainingPartyCreateDetails trainingPartyCreateDetails : trainingPartyCreateDetailsList.detailsList.items()) {

      for (TrainingProgramPartyDetails trainingProgramPartyDetails : trainingProgramPartyDetailsList.partyDetails.items()) {

        for (curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMemberDAO.getTrainingProgramsForParty(
          trainingPartyCreateDetails.trainingID,
          trainingProgramPartyDetails.partyConcernRoleID)) {

          if (trainingProgramMember.getLifecycleState().equals(
            TRAININGPROGRAMPARTYSTATUSEntry.OPEN)) {

            if (openPartyNamesCounter == 0) {
              openPartyNames = trainingPartyCreateDetails.trainingName
                + GeneralConstants.kColon
                + trainingProgramPartyDetails.partyName;
              openPartyNamesCounter++;
            } else {
              openPartyNames += GeneralConstants.kComma
                + GeneralConstants.kSpace
                + trainingPartyCreateDetails.trainingName
                + GeneralConstants.kColon
                + trainingProgramPartyDetails.partyName;
            }
          } else if (trainingProgramMember.getLifecycleState().equals(
            TRAININGPROGRAMPARTYSTATUSEntry.APPROVED)) {
            if (approvedPartyNamesCounter == 0) {
              approvedPartyNames = trainingPartyCreateDetails.trainingName
                + GeneralConstants.kColon
                + trainingProgramPartyDetails.partyName;
              approvedPartyNamesCounter++;
            } else {
              approvedPartyNames += GeneralConstants.kComma
                + GeneralConstants.kSpace
                + trainingPartyCreateDetails.trainingName
                + GeneralConstants.kColon
                + trainingProgramPartyDetails.partyName;
            }
          }

          break;
        }
        // BEGIN CR00113504,SS
        Set<ProviderMember> providerMembers = providerMemberDAO.searchBy(
          providerOrganization);

        for (ProviderMember providerMember : providerMembers) {
          if (providerMember.getParty().getID()
            == trainingProgramPartyDetails.partyConcernRoleID) {

            // BEGIN CR00113213, MST
            if (!trainingPartyCreateDetails.authorizedFrom.isZero()
              && providerMember.getDateRange().startsAfter(
                trainingPartyCreateDetails.authorizedFrom)) {

              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_PROVIDERMEMBER_FROM_DATE_ON_OR_BEFORE_AUTHORIZED_DATE(
                  trainingPartyCreateDetails.authorizedFrom,
                  providerMember.getDateRange().start(),
                  trainingProgramPartyDetails.partyName),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                  1);
            }
            if (!trainingPartyCreateDetails.toBeCompletedBy.isZero()
              && providerMember.getDateRange().isEnded()
              && providerMember.getDateRange().endsBefore(
                trainingPartyCreateDetails.toBeCompletedBy)) {

              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_PROVIDERMEMBER_TO_DATE_ON_OR_AFTER_TO_BE_COMPLETED_BY_DATE(
                  trainingPartyCreateDetails.toBeCompletedBy,
                  providerMember.getDateRange().end(),
                  trainingProgramPartyDetails.partyName),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                  1);
            }
            if (trainingPartyCreateDetails.toBeCompletedBy.isZero()
              && providerMember.getDateRange().isEnded()) {

              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
                TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_PROVIDERMEMBER_TO_DATE_ON_OR_AFTER_TO_BE_COMPLETED_BY_DATE_OPEN_ENDED(
                  providerMember.getDateRange().end(),
                  trainingProgramPartyDetails.partyName),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                  1);
            }
            // END CR00113213
          }
        }
        // END CR00113504
      }
    }

    if (openPartyNames.length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_TRAINING_PROGRAM_WITH_STATUS_OPEN_OR_APPROVED_ALREADY_EXISTS_FOR_PROVIDER_MEMBERS(
          TRAININGPROGRAMPARTYSTATUSEntry.OPEN.getCodeTableItemIdentifier(),
          openPartyNames),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (approvedPartyNames.length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_TRAINING_PROGRAM_WITH_STATUS_OPEN_OR_APPROVED_ALREADY_EXISTS_FOR_PROVIDER_MEMBERS(
          TRAININGPROGRAMPARTYSTATUSEntry.APPROVED.getCodeTableItemIdentifier(),
          approvedPartyNames),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    for (TrainingProgramPartyDetails trainingProgramPartyDetails : trainingProgramPartyDetailsList.partyDetails.items()) {
      if (trainingProgramPartyDetails.unitsRequired <= 0) {
        if (invalidUnitsRequiredCounter == 0) {
          invalidUnitsRequired = trainingProgramPartyDetails.partyName;
          invalidUnitsRequiredCounter++;
        } else {
          invalidUnitsRequired += GeneralConstants.kComma
            + GeneralConstants.kSpace + trainingProgramPartyDetails.partyName;

        }
      }
    }

    if (invalidUnitsRequired.length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_UNITSREQUIRED_GR_THAN_ZERO_FOR_PROVIDERMEMBERS(
          invalidUnitsRequired),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    ValidationHelper.failIfErrorsExist();

  }

  // BEGIN, CR00208091, RD
  /**
   * Sorts a list of Member Training Programs by Training Name.
   *
   * @param unsortedMemberTrainingPrograms
   * The list of unsorted Member Training Programs.
   *
   * @return Contains a list of Member Training Programs sorted by Training
   * Name.
   */
  protected TrainingProgramMemberList sortListMemberTrainingPrograms(
    TrainingProgramMemberList unsortedMemberTrainingPrograms) {

    List<MemberTrainingSummaryDetails> memberTrainingSummaryDetailsList = new ArrayList<MemberTrainingSummaryDetails>();

    for (MemberTrainingSummaryDetails memberTrainingSummaryDetails : unsortedMemberTrainingPrograms.memberTrainingSummaryList.items()) {
      memberTrainingSummaryDetailsList.add(memberTrainingSummaryDetails);
    }

    Collections.sort(memberTrainingSummaryDetailsList,
      new Comparator<MemberTrainingSummaryDetails>() {
      public int compare(final MemberTrainingSummaryDetails lhs,
        MemberTrainingSummaryDetails rhs) {
        return lhs.trainingName.compareTo(rhs.trainingName);
      }
    });

    TrainingProgramMemberList trainingProgramMemberList = new TrainingProgramMemberList();

    for (MemberTrainingSummaryDetails trainingProgram : memberTrainingSummaryDetailsList) {
      trainingProgramMemberList.memberTrainingSummaryList.addRef(
        trainingProgram);
    }
    return trainingProgramMemberList;
  }

  // END, CR00208091
  
  /**
   * Sorts a set of Training Programs by Training Name.
   *
   * @param unsortedTrainingPrograms
   * The set of unsorted Training Programs.
   * @return Contains a list of Training Programs sorted by Training Name.
   */
  protected TrainingProgramList sortListTrainingPrograms(
    TrainingProgramList unsortedTrainingPrograms) {

    List<TrainingSummaryDetails> trainingSummaryDetailsList = new ArrayList<TrainingSummaryDetails>();

    for (int i = 0; i < unsortedTrainingPrograms.trainingSummaryList.size(); i++) {
      trainingSummaryDetailsList.add(
        unsortedTrainingPrograms.trainingSummaryList.item(i));
    }

    // Sort the unsorted training programs
    Collections.sort(trainingSummaryDetailsList,
      new Comparator<TrainingSummaryDetails>() {
      public int compare(final TrainingSummaryDetails lhs,
        TrainingSummaryDetails rhs) {
        return lhs.trainingName.compareTo(rhs.trainingName);
      }
    });

    TrainingProgramList trainingProgramList = new TrainingProgramList();

    for (TrainingSummaryDetails trainingProgram : trainingSummaryDetailsList) {
      trainingProgramList.trainingSummaryList.addRef(trainingProgram);
    }
    return trainingProgramList;
  }

  /**
   * Sorts a set of Party Details by Party Name.
   *
   * @param unsortedPartyDetails
   * The set of unsorted Party Details.
   * @return Contains a list of Party Details sorted by Party Name.
   */
  protected TrainingProgramPartyDetailsList sortPartyDetailsList(
    TrainingProgramPartyDetailsList unsortedPartyDetails) {

    List<TrainingProgramPartyDetails> trainingPartyDetailsList = new ArrayList<TrainingProgramPartyDetails>();

    for (int i = 0; i < unsortedPartyDetails.partyDetails.size(); i++) {
      trainingPartyDetailsList.add(unsortedPartyDetails.partyDetails.item(i));
    }

    // Sort the unsorted training programs
    Collections.sort(trainingPartyDetailsList,
      new Comparator<TrainingProgramPartyDetails>() {
      public int compare(final TrainingProgramPartyDetails lhs,
        TrainingProgramPartyDetails rhs) {
        return lhs.partyName.compareTo(rhs.partyName);
      }
    });

    TrainingProgramPartyDetailsList trainingProgramList = new TrainingProgramPartyDetailsList();

    for (TrainingProgramPartyDetails trainingProgram : trainingPartyDetailsList) {
      trainingProgramList.partyDetails.addRef(trainingProgram);
    }

    return trainingProgramList;
  }

  /**
   * Sets the training program details.
   *
   * @param details
   * Training program update details.
   */
  protected void setTrainingProgram(TrainingProgramMemberUpdateDetails details) {

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProgramID);

    trainingProgram.setDateRange(
      new DateRange(details.authorizedFrom, details.toBeCompletedBy));
    trainingProgram.setUnitAmount(details.unitAmount);

  }

  /**
   * Sets the training program details.
   *
   * @param details
   * Training program update details.
   */
  protected void setTrainingProgramMember(
    TrainingProgramMemberUpdateDetails details) {

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    trainingProgramMember.setCompletion(
      TrainingCompletionEntry.get(details.completion));
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setUnitsRequired(details.unitsRequired);

    if (details.creditsAchievedString.length() > 0) {
      try {
        // convert credits achieved string to int
        details.creditsAchieved = Integer.parseInt(
          details.creditsAchievedString);
      } catch (NumberFormatException exception) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_CREDITS_ACHIEVED_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      }

      if (details.creditsAchieved <= 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_CREDITS_ACHIEVED_GR_THAN_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      }

      trainingProgramMember.setCreditsAchieved(details.creditsAchieved);
    }

    if (details.unitsCompletedString.length() > 0) {
      try {
        // convert credits achieved string to int
        details.unitsCompleted = Integer.parseInt(details.unitsCompletedString);
      } catch (NumberFormatException exception) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_UNITSCOMPLETED_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      }
      trainingProgramMember.setUnitsCompleted(details.unitsCompleted);
    }

  }

  /**
   * Sets the training program details.
   *
   * @param trainingPartyCreateDetails
   * Contains training program details.
   * @return Training program to be created.
   */
  protected curam.training.impl.TrainingProgram setTrainingProgram(
    TrainingPartyCreateDetails trainingPartyCreateDetails) {

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.newInstance();

    trainingProgram.setTraining(
      trainingDAO.get(trainingPartyCreateDetails.trainingID));
    trainingProgram.setUnitAmount(trainingPartyCreateDetails.unitAmount);

    trainingProgram.setDateRange(
      new DateRange(trainingPartyCreateDetails.authorizedFrom,
      trainingPartyCreateDetails.toBeCompletedBy));
    ConcernRole concernRole = concernRoleDAO.get(
      trainingPartyCreateDetails.concernRoleID);

    trainingProgram.setTrainingProgramOwner(concernRole);
    trainingProgram.setManagedThroughAgency(true);

    trainingProgram.setTrainingProvider(
      providerDAO.get(trainingPartyCreateDetails.trainingProviderID));

    return trainingProgram;
  }

  /**
   * Sets the completed provider training program entity details.
   *
   * @param details
   * Contains the training program completed details.
   * @param trainingProgram
   * Instance of an training program.
   */
  protected void setRecordCompletedProviderProgramDetails(
    TrainingProgramCompletedDetails details,
    curam.training.impl.TrainingProgram trainingProgram) {

    if (0 != details.trainingProviderDetails.trainingID) {
      // get the training instance
      Training training = trainingDAO.get(
        details.trainingProviderDetails.trainingID);

      trainingProgram.setTraining(training);
    }
    trainingProgram.setTrainingName(
      details.trainingProviderDetails.trainingName);

    if (0 != details.trainingProviderDetails.trainingProviderID) {
      Provider provider = providerDAO.get(
        details.trainingProviderDetails.trainingProviderID);

      trainingProgram.setTrainingProvider(provider);

    }
    trainingProgram.setTrainingProviderDetails(
      details.trainingProviderDetails.trainingProviderDetails);
    ConcernRole concernRole = concernRoleDAO.get(details.partyConcernRoleID);

    trainingProgram.setTrainingProgramOwner(concernRole);
    trainingProgram.setManagedThroughAgency(false);

  }

  /**
   * Sets the completed provider member training entity details.
   *
   * @param trainingProgram
   * Instance of an training program member.
   * @param details
   * Contains the training program completed details.
   */
  protected void setRecordCompletedProviderProgramMemberDetails(
    TrainingProgramCompletedDetails details,
    TrainingProgramMember trainingProgramMember) {

    // get the training program instance
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProviderDetails.trainingProgramID);

    trainingProgramMember.setTrainingProgram(trainingProgram);
    ConcernRole concernRole = concernRoleDAO.get(details.partyConcernRoleID);

    trainingProgramMember.setPartyConcernRole(concernRole);
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setUnitsCompleted(details.unitsCompleted);
  }

  /**
   * Validates the record completed provider training.
   *
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_FV_PROVIDER_MEMBER_UNITSCOMPLETED_GR_THAN_ZERO} -
   * If the units completed less than or equal to zero.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_PROVIDER_MEMBER_DATE_COMPLETED_LATER_THAN_CURRENT_BUSINESS_DATE} -
   * If date completed is later than the current business date.
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_PROVIDER_MEMBER_UNITSCOMPLETED_MANDATORY_IF_DATE_COMPLETED_IS_ENTERED} -
   * If date completed is entered and units completed is not entered.
   */
  protected void validateRecordCompleted(
    TrainingProgramPartyDetailsList trainingProgramPartyDetailsList)
    throws AppException, InformationalException {
    Date currentDate = Date.getCurrentDate();
    String invalidUnitsCompletedMembers = CPMConstants.kEmptyString;
    String invalidDateCompltedMembers = CPMConstants.kEmptyString;
    String invalidUnitsAnddateMembers = CPMConstants.kEmptyString;
    int invalidDateCounter = 0;
    int invalidUnitsCounter = 0;
    int invalidDateAndUnitsCounter = 0;

    for (TrainingProgramPartyDetails trainingProgramPartyDetails : trainingProgramPartyDetailsList.partyDetails.items()) {

      // check if units completed is less than or equal to zero
      if (trainingProgramPartyDetails.unitsCompleted <= 0) {
        if (invalidUnitsCounter == 0) {
          invalidUnitsCompletedMembers = trainingProgramPartyDetails.partyName;
        } else {
          invalidUnitsCompletedMembers = invalidUnitsCompletedMembers
            + GeneralConstants.kComma + trainingProgramPartyDetails.partyName;
        }
        invalidUnitsCounter++;
      }
      // check if date completed greater than current business date
      if (trainingProgramPartyDetails.dateCompleted.after(currentDate)) {
        if (invalidDateCounter == 0) {
          invalidDateCompltedMembers = trainingProgramPartyDetails.partyName;
        } else {
          invalidDateCompltedMembers = invalidDateCompltedMembers
            + GeneralConstants.kComma + trainingProgramPartyDetails.partyName;
        }
        invalidDateCounter++;
      }
      // check if units completed is not entered when date completed is
      // entered
      if (!Date.kZeroDate.equals(trainingProgramPartyDetails.dateCompleted)
        && trainingProgramPartyDetails.unitsCompleted == 0) {

        if (invalidDateAndUnitsCounter == 0) {
          invalidUnitsAnddateMembers = trainingProgramPartyDetails.partyName;
        } else {
          invalidUnitsAnddateMembers = invalidUnitsAnddateMembers
            + GeneralConstants.kComma + trainingProgramPartyDetails.partyName;
        }
        invalidDateAndUnitsCounter++;
      }
    }
    // form the consolidated messages
    if (StringHelper.trim(invalidUnitsCompletedMembers).length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_PROVIDER_MEMBER_UNITSCOMPLETED_GR_THAN_ZERO(
          invalidUnitsCompletedMembers),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }
    if (StringHelper.trim(invalidDateCompltedMembers).length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_PROVIDER_MEMBER_DATE_COMPLETED_LATER_THAN_CURRENT_BUSINESS_DATE(
          invalidDateCompltedMembers),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }
    if (StringHelper.trim(invalidUnitsAnddateMembers).length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_PROVIDER_MEMBER_UNITSCOMPLETED_MANDATORY_IF_DATE_COMPLETED_IS_ENTERED(
          invalidUnitsAnddateMembers),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }
    ValidationHelper.failIfErrorsExist();
  }

  /**
   * Sets the completed provider training program entity details.
   *
   * @param details
   * Contains the training provider party details.
   * @param trainingProgram
   * Instance of an training program.
   */
  protected void setRecordCompletedTrainingProgramDetails(
    TrainingProgramAndPartyCompletedDetails details,
    curam.training.impl.TrainingProgram trainingProgram) {

    if (0 != details.trainingProviderDetails.trainingID) {
      // get the training instance
      Training training = trainingDAO.get(
        details.trainingProviderDetails.trainingID);

      trainingProgram.setTraining(training);
    }
    trainingProgram.setTrainingName(
      details.trainingProviderDetails.trainingName);

    if (0 != details.trainingProviderDetails.trainingProviderID) {
      Provider provider = providerDAO.get(
        details.trainingProviderDetails.trainingProviderID);

      trainingProgram.setTrainingProvider(provider);

    }
    trainingProgram.setTrainingProviderDetails(
      details.trainingProviderDetails.trainingProviderDetails);
    ConcernRole concernRole = concernRoleDAO.get(
      details.trainingProviderDetails.concernRoleID);

    trainingProgram.setTrainingProgramOwner(concernRole);
    trainingProgram.setManagedThroughAgency(false);

  }

  /**
   * Sets the completed provider member training entity details.
   *
   * @param details
   * Contains the training provider party details.
   * @param trainingProgramMember
   * Instance of an training program member.
   * @param trainingProgram
   * Instance of an training program.
   */
  protected void setRecordCompletedProgramMemberDetails(
    TrainingProgramPartyDetails details,
    TrainingProgramMember trainingProgramMember,
    curam.training.impl.TrainingProgram trainingProgram) {
    trainingProgramMember.setTrainingProgram(trainingProgram);
    ConcernRole concernRole = concernRoleDAO.get(details.partyConcernRoleID);

    trainingProgramMember.setPartyConcernRole(concernRole);
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setUnitsCompleted(details.unitsCompleted);
  }

  /**
   * Sets the training program details.
   *
   * @param trainingPartyCreateDetails
   * Contains training program details.
   * @param trainingProviderID
   * Training Provider ID.
   * @param providerConcernRoleID
   * Provider Concern Role ID.
   * @return Training program to be created.
   */
  protected curam.training.impl.TrainingProgram setTrainingProgram(
    TrainingPartyCreateDetails trainingPartyCreateDetails,
    long trainingProviderID, long providerConcernRoleID) {

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.newInstance();

    trainingProgram.setTraining(
      trainingDAO.get(trainingPartyCreateDetails.trainingID));
    trainingProgram.setUnitAmount(trainingPartyCreateDetails.unitAmount);

    trainingProgram.setDateRange(
      new DateRange(trainingPartyCreateDetails.authorizedFrom,
      trainingPartyCreateDetails.toBeCompletedBy));
    ConcernRole concernRole = concernRoleDAO.get(providerConcernRoleID);

    trainingProgram.setTrainingProgramOwner(concernRole);
    trainingProgram.setManagedThroughAgency(true);

    trainingProgram.setTrainingProvider(providerDAO.get(trainingProviderID));

    return trainingProgram;
  }
  
  // BEGIN, CR00137832, ASN
  
  /**
   * Creates training program for a provider member.
   *
   * @param details
   * Contains training program details and training provider.
   *
   * @return Training program member key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramMemberKey createTrainingProgramDetailsForProviderMember(
    TrainingPartyCreateDetails details) throws AppException,
      InformationalException {

    TrainingProgramMemberKey trainingProgramMemberKey = new TrainingProgramMemberKey();

    TrainingProgramKey trainingProgramKey = new TrainingProgramKey();

    curam.training.impl.TrainingProgram trainingProgram = setTrainingProgram(
      details);

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.providerOrganizationID);

    trainingProgram.validateProviderOrganization(providerOrganization);

    trainingProgram.insert();

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();
    ConcernRole concernRole = concernRoleDAO.get(details.concernRoleID);

    trainingProgramMember.setPartyConcernRole(concernRole);
    trainingProgramMember.setCompletion(
      TrainingCompletionEntry.get(details.completion));
    trainingProgramMember.setTrainingProgram(trainingProgram);
    trainingProgramMember.setUnitsRequired(details.unitsRequired);
    trainingProgramMember.setMemberType(CPMConstants.kProviderMember);

    trainingProgramMember.insert();

    trainingProgramKey.trainingProgramID = trainingProgram.getID();

    trainingProgramMemberKey.trainingProgramMemberID = trainingProgramMember.getID();

    return trainingProgramMemberKey;
  }

  /**
   * Retrieves training program details for a provider member.
   *
   * @param trainingProgramMemberKey
   * Contains training program member ID.
   *
   * @return Contains training program details for a
   * provider member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingPartyDetails viewProviderMemberTrainingProgramDetails(
    TrainingProgramMemberKey trainingProgramMemberKey) throws AppException, InformationalException {
    TrainingPartyDetails partyDetails = new TrainingPartyDetails();

    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      trainingProgramMemberKey.trainingProgramMemberID);

    partyDetails.completion = trainingProgramMember.getCompletion().toString();
    partyDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
    if (trainingProgramMember.getCreditsAchieved() > 0) {
      partyDetails.creditsAchievedString = String.valueOf(
        trainingProgramMember.getCreditsAchieved());
    }
    Date completedDate = trainingProgramMember.getDateCompleted();

    partyDetails.dateCompleted = completedDate;
    partyDetails.partyConcernRoleID = trainingProgramMember.getPartyConcernRole().getID();
    partyDetails.partyVersionNo = trainingProgramMember.getVersionNo();
    partyDetails.status = trainingProgramMember.getLifecycleState().toString();
    partyDetails.trainingProgramID = trainingProgramMember.getTrainingProgram().getID();
    partyDetails.trainingProgramMemberID = trainingProgramMember.getID();
    partyDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
    if (trainingProgramMember.getUnitsCompleted() > 0) {
      partyDetails.unitsCompletedString = String.valueOf(
        trainingProgramMember.getUnitsCompleted());
    }
    partyDetails.unitsRemaining = trainingProgramMember.getUnitsRequired()
      - trainingProgramMember.getUnitsCompleted();
    partyDetails.unitsRequired = trainingProgramMember.getUnitsRequired();

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramMember.getTrainingProgram();

    if (TRAININGPROGRAMPARTYSTATUSEntry.COMPLETE.equals(
      trainingProgramMember.getLifecycleState())) {

      List<TrainingCredit> trainingCredits = trainingCreditDAO.searchBy(
        trainingProgramMember.getTrainingProgram().getTraining());

      if (trainingCredits.size() > 0) {
        int days = trainingProgram.getTrainingValidDays();

        if (days > 0) {
          partyDetails.validTill = completedDate.addDays(days);
        }
      }
    }
    partyDetails.waiverExpiryDate = trainingProgramMember.getWaiverExpiryDate();

    partyDetails.trainingProgramDetails.authorizedFrom = trainingProgram.getDateRange().start();
    partyDetails.trainingProgramDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();
    partyDetails.trainingProgramDetails.toBeCompletedBy = trainingProgram.getDateRange().end();
    if (trainingProgram.getTraining() == null) {
      partyDetails.trainingProgramDetails.trainingName = trainingProgram.getTrainingName();
      partyDetails.trainingProgramDetails.trainingRegisteredInd = false;
    } else {
      partyDetails.trainingProgramDetails.trainingName = trainingProgram.getTraining().getName();
      partyDetails.trainingProgramDetails.trainingID = trainingProgram.getTraining().getID();
      partyDetails.trainingProgramDetails.trainingRegisteredInd = true;
    }
    partyDetails.trainingProgramDetails.trainingProgramID = trainingProgram.getID();
    partyDetails.trainingProgramDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();
    if (trainingProgram.getTrainingProvider() != null) {
      partyDetails.trainingProgramDetails.trainingProvider = trainingProgram.getTrainingProvider().getName();
    }
    partyDetails.trainingProgramDetails.unitAmount = trainingProgram.getUnitAmount();
    partyDetails.trainingProgramDetails.versionNo = trainingProgram.getVersionNo();

    return partyDetails;
  }
 
  /**
   * Retrieves training program details not managed through agency for a
   * provider member.
   *
   * @param trainingProgramMemberKey
   * Training program member key.
   *
   * @return Training program details for a provider member.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrainingProgramPartyCompletedDetails viewMemberCompletedTrainingDetailsNotManagedByAgency(
    TrainingProgramMemberKey trainingProgramMemberKey) throws AppException, InformationalException {

    TrainingProgramPartyCompletedDetails trainingProgramPartyCompletedDetails = new TrainingProgramPartyCompletedDetails();

    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      trainingProgramMemberKey.trainingProgramMemberID);
    
    trainingProgramPartyCompletedDetails.status = trainingProgramMember.getLifecycleState().getCode();
    trainingProgramPartyCompletedDetails.dateCompleted = trainingProgramMember.getDateCompleted();
    trainingProgramPartyCompletedDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
    trainingProgramPartyCompletedDetails.trainingProgramMemberID = trainingProgramMember.getID();
    trainingProgramPartyCompletedDetails.trainingProgramMemberVersionNo = trainingProgramMember.getVersionNo();
    trainingProgramPartyCompletedDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
  
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramMember.getTrainingProgram();
 
    trainingProgramPartyCompletedDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();

    if (trainingProgram.getTraining() == null) {
      trainingProgramPartyCompletedDetails.trainingName = trainingProgram.getTrainingName();
      trainingProgramPartyCompletedDetails.trainingRegisteredInd = false;
    } else {
      trainingProgramPartyCompletedDetails.trainingName = trainingProgram.getTraining().getName();
      trainingProgramPartyCompletedDetails.trainingID = trainingProgram.getTraining().getID();
      trainingProgramPartyCompletedDetails.trainingRegisteredInd = true;
    }
    trainingProgramPartyCompletedDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();

    if (trainingProgram.getTrainingProvider() != null) {
      trainingProgramPartyCompletedDetails.trainingProviderName = trainingProgram.getTrainingProvider().getName();
    } else {
      trainingProgramPartyCompletedDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
    }
    trainingProgramPartyCompletedDetails.trainingProgramID = trainingProgram.getID();
    trainingProgramPartyCompletedDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();

    return trainingProgramPartyCompletedDetails;
  }

  // END, CR00137832
  
  // BEGIN, CR00234644, GP
  /**
   * Sets the training program details.
   *
   * @param trainingProgramList
   * Completed or managed training program list which needs to be set.
   * @param trainingProgramSummaryDetailsList
   * Struct to which values are to be set.
   * @param booleanValue
   * Indicates whether training program is a completed training program
   * or managed training program.
   */
  protected void setTrainingProgramDetails(
    final TrainingProgramList trainingProgramList,
    final TrainingProgramSummaryDetailsList trainingProgramSummaryDetailsList,
    final Boolean booleanValue) {

    for (final TrainingSummaryDetails trainingSummaryDetails : trainingProgramList.trainingSummaryList.items()) {
      TrainingProgramSummaryDetails trainingProgramSummaryDetails = new TrainingProgramSummaryDetails();
      curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
        trainingSummaryDetails.trainingProgramID);
      
      trainingProgramSummaryDetails.managedThroughAgency = booleanValue.booleanValue();
      trainingProgramSummaryDetails.referenceNumber = trainingSummaryDetails.referenceNumber;
      trainingProgramSummaryDetails.trainingName = trainingSummaryDetails.trainingName;
      trainingProgramSummaryDetails.trainingProgramID = trainingSummaryDetails.trainingProgramID;
      trainingProgramSummaryDetails.trainingProgramMemberID = trainingSummaryDetails.trainingProgramMemberID;
      trainingProgramSummaryDetails.trainingProgramMemberVersionNo = trainingSummaryDetails.trainingProgramMemberVersionNo;
      trainingProgramSummaryDetails.trainingProgramVersionNo = trainingSummaryDetails.trainingProgramVersionNo;
      trainingProgramSummaryDetails.trainingRegisteredInd = trainingSummaryDetails.trainingRegisteredInd;
      trainingProgramSummaryDetails.trainingID = trainingSummaryDetails.trainingID;
      // BEGIN, CR00247455, PS
      trainingProgramSummaryDetails.trainingProgramStatus = trainingSummaryDetails.trainingProgramStatus;
      // END, CR00247455
      
      // BEGIN, CR00236219, PS
      if (null != trainingProgram.getTrainingProvider()) {
        trainingProgramSummaryDetails.trainingProviderDetails = trainingProgram.getTrainingProvider().getName();
      } else {
        trainingProgramSummaryDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
      }
      // END, CR00236219
      
      // BEGIN, CR00306259, MR
      if (trainingProgramSummaryDetails.managedThroughAgency) {
        trainingProgramSummaryDetails.editActionURL = CPMConstants.kModifyTrainingProgramForProviderPage;
      } else {
        trainingProgramSummaryDetails.editActionURL = CPMConstants.kUpdateCompletedTrainingForProviderPage;
      }

      // END, CR00306259
      
      trainingProgramSummaryDetailsList.trainingProgramSummaryDetails.addRef(
        trainingProgramSummaryDetails);
    }
  }
  
  /**
   * Sorts a set of Training Programs by Training Name.
   *
   * @param unsortedTrainingProgramSummaryDetailsList
   * The set of unsorted Training Programs.
   *
   * @return A list of Training Programs sorted by Training Name.
   */
  protected TrainingProgramSummaryDetailsList sortTrainingPrograms(
    final TrainingProgramSummaryDetailsList unsortedTrainingProgramSummaryDetailsList) {

    List<TrainingProgramSummaryDetails> trainingProgramSummaryDetailsList = new ArrayList<TrainingProgramSummaryDetails>();

    for (final TrainingProgramSummaryDetails trainingProgramSummaryDetails : unsortedTrainingProgramSummaryDetailsList.trainingProgramSummaryDetails.items()) {
      trainingProgramSummaryDetailsList.add(trainingProgramSummaryDetails);
    }

    Collections.sort(trainingProgramSummaryDetailsList,
      new Comparator<TrainingProgramSummaryDetails>() {
      public int compare(final TrainingProgramSummaryDetails lhs,
        TrainingProgramSummaryDetails rhs) {
        return lhs.trainingName.compareTo(rhs.trainingName);
      }
    });

    TrainingProgramSummaryDetailsList sortedTrainingProgramSummaryDetailsList = new TrainingProgramSummaryDetailsList();

    for (final TrainingProgramSummaryDetails trainingProgramSummaryDetails : trainingProgramSummaryDetailsList) {
      sortedTrainingProgramSummaryDetailsList.trainingProgramSummaryDetails.addRef(
        trainingProgramSummaryDetails);
    }
    return sortedTrainingProgramSummaryDetailsList;
  }
  
  /**
   * Sets the completed training program details of provider member.
   *
   * @param trainingProgramList
   * Training program details which needs to be set.
   * @param trainingProgramSummaryDetailsList
   * Struct to which training program details are to be set.
   */
  protected void setCompletedTrainingProgramList(
    final TrainingProgramList trainingProgramList,
    final TrainingProgramSummaryDetailsList trainingProgramSummaryDetailsList) {

    for (final TrainingSummaryDetails trainingSummaryDetails : trainingProgramList.trainingSummaryList.items()) {
      TrainingProgramSummaryDetails trainingProgramSummaryDetails = new TrainingProgramSummaryDetails();
      curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
        trainingSummaryDetails.trainingProgramID);

      trainingProgramSummaryDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();
      trainingProgramSummaryDetails.trainingProgramMemberID = trainingSummaryDetails.trainingProgramMemberID;
      trainingProgramSummaryDetails.trainingProgramMemberVersionNo = trainingSummaryDetails.trainingProgramMemberVersionNo;
      trainingProgramSummaryDetails.referenceNumber = trainingSummaryDetails.referenceNumber;
      trainingProgramSummaryDetails.trainingProgramVersionNo = trainingSummaryDetails.trainingProgramVersionNo;
      trainingProgramSummaryDetails.trainingProgramID = trainingSummaryDetails.trainingProgramID;
      trainingProgramSummaryDetails.trainingProgramDateCompleted = trainingSummaryDetails.trainingProgramDateCompleted;
      trainingProgramSummaryDetails.trainingName = trainingSummaryDetails.trainingName;
      trainingProgramSummaryDetails.trainingRegisteredInd = trainingSummaryDetails.trainingRegisteredInd;
      trainingProgramSummaryDetails.trainingID = trainingSummaryDetails.trainingID;
      trainingProgramSummaryDetails.trainingProgramStatus = trainingSummaryDetails.trainingProgramStatus;

      // BEGIN, CR00249748, PS
      if (null != trainingProgram.getTrainingProvider()) {
        trainingProgramSummaryDetails.trainingProviderDetails = trainingProgram.getTrainingProvider().getName();
      } else {
        trainingProgramSummaryDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
      }
      // END, CR00249748
      trainingProgramSummaryDetailsList.trainingProgramSummaryDetails.addRef(
        trainingProgramSummaryDetails);
    }
  }
  
  /**
   * Sets the managed training program details of provider member.
   *
   * @param trainingProgramMemberList
   * Training program member details which needs to be set.
   * @param trainingProgramSummaryDetailsList
   * Struct to which training program details are to be set.
   */
  protected void setManagedTrainingProgramList(
    final TrainingProgramMemberList trainingProgramMemberList,
    final TrainingProgramSummaryDetailsList trainingProgramSummaryDetailsList) {

    for (final MemberTrainingSummaryDetails memberTrainingSummaryDetails : trainingProgramMemberList.memberTrainingSummaryList.items()) {

      TrainingProgramSummaryDetails trainingProgramSummaryDetails = new TrainingProgramSummaryDetails();
      curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
        memberTrainingSummaryDetails.trainingProgramID);

      trainingProgramSummaryDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();

      trainingProgramSummaryDetails.referenceNumber = memberTrainingSummaryDetails.referenceNumber;
      trainingProgramSummaryDetails.trainingProgramVersionNo = memberTrainingSummaryDetails.trainingProgramVersionNo;
      trainingProgramSummaryDetails.trainingProgramID = memberTrainingSummaryDetails.trainingProgramID;
      trainingProgramSummaryDetails.trainingName = memberTrainingSummaryDetails.trainingName;
      trainingProgramSummaryDetails.trainingRegisteredInd = memberTrainingSummaryDetails.trainingRegisteredInd;
      trainingProgramSummaryDetails.trainingID = memberTrainingSummaryDetails.trainingID;
      trainingProgramSummaryDetails.trainingProgramStatus = trainingProgram.getLifecycleState().getCode();
      trainingProgramSummaryDetails.trainingProgramMemberID = memberTrainingSummaryDetails.trainingProgramMemberID;
      trainingProgramSummaryDetails.trainingProgramMemberVersionNo = memberTrainingSummaryDetails.trainingProgramMemberVersionNo;
      trainingProgramSummaryDetails.trainingProgramDateCompleted = memberTrainingSummaryDetails.trainingProgramDateCompleted;
      trainingProgramSummaryDetails.trainingProgramOwnerType = memberTrainingSummaryDetails.trainingProgramOwnerType;
      trainingProgramSummaryDetails.trainingProgramOwnerID = memberTrainingSummaryDetails.trainingProgramOwnerID;
      trainingProgramSummaryDetails.trainingProgramOwnerIsProvider = memberTrainingSummaryDetails.trainingProgramOwnerIsProvider;
      trainingProgramSummaryDetails.trainingProgramOwnerIsProviderGroup = memberTrainingSummaryDetails.trainingProgramOwnerIsProviderGroup;
      trainingProgramSummaryDetails.trainingProgramOwnerIsMember = memberTrainingSummaryDetails.trainingProgramOwnerIsMember;

      // BEGIN, CR00249748, PS
      if (null != trainingProgram.getTrainingProvider()) {
        trainingProgramSummaryDetails.trainingProviderDetails = trainingProgram.getTrainingProvider().getName();
      } else {
        trainingProgramSummaryDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
      }
      // END, CR00249748
      trainingProgramSummaryDetailsList.trainingProgramSummaryDetails.addRef(
        trainingProgramSummaryDetails);
    }
  }
  
  /**
   * Sorts a set of Training Program Status History by Date time.
   *
   * @param unsortedTrainingProgramStatusHistoryDetailsList
   * The set of unsorted Training Program status history.
   *
   * @return Contains a list of Training Program Status History sorted by Date
   * Time.
   */
  protected TrainingProgramStatusHistoryDetailsList sortListTrainingProgramHistory(
    final TrainingProgramStatusHistoryDetailsList unsortedTrainingProgramStatusHistoryDetailsList) {

    List<TrainingProgramStatusHistoryDetails> trainingMemberStatusHistoryDetailsList = new ArrayList<TrainingProgramStatusHistoryDetails>();

    for (int i = 0; i
      < unsortedTrainingProgramStatusHistoryDetailsList.trainingProgramStatusHistoryDetails.size(); i++) {
      trainingMemberStatusHistoryDetailsList.add(
        unsortedTrainingProgramStatusHistoryDetailsList.trainingProgramStatusHistoryDetails.item(
          i));
    }

    Collections.sort(trainingMemberStatusHistoryDetailsList,
      new Comparator<TrainingProgramStatusHistoryDetails>() {
      public int compare(final TrainingProgramStatusHistoryDetails lhs,
        TrainingProgramStatusHistoryDetails rhs) {
        return rhs.dateTime.compareTo(lhs.dateTime);
      }
    });

    TrainingProgramStatusHistoryDetailsList sortedTrainingMemberStatusHistoryDetailsList = new TrainingProgramStatusHistoryDetailsList();

    for (TrainingProgramStatusHistoryDetails trainingProgramStatusHistoryDetails : trainingMemberStatusHistoryDetailsList) {
      sortedTrainingMemberStatusHistoryDetailsList.trainingProgramStatusHistoryDetails.addRef(
        trainingProgramStatusHistoryDetails);
    }

    return sortedTrainingMemberStatusHistoryDetailsList;
  }
  // END, CR00234644
}
