/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.citizenmessages.internal.impl;


import java.util.ArrayList;
import java.util.List;

import com.google.inject.Inject;

import curam.core.impl.EnvVars;
import curam.participant.impl.ConcernRole;
import curam.participantmessages.codetable.impl.ParticipantMessageTypeEntry;
import curam.participantmessages.events.impl.CitizenMessagesEvent;
import curam.participantmessages.impl.ParticipantMessages;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.casemanager.impl.CaseParticipantRoleDAO;
import curam.piwrapper.outcomeplan.impl.OutcomePlanActivity;
import curam.referral.impl.Referral;
import curam.referral.impl.ReferralDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;


/**
 * This listener listens for an event raised when a citizen logs in to the
 * Citizen Workspace. It checks to see if there are any referrals for the
 * citizen and if any exist that fit the criteria, creates messages based on
 * them for display to the citizen. No messages will be added if the Referral
 * participant message type has been disabled in administration. <br/>
 * This is internal and should not be called by customers.<br/>
 * <br/>
 * Referrals must have a referral date that is not in the past to fit the
 * criteria.<br/>
 * The curam.citizenaccount.referral.message.effective.days property denotes the
 * number of days before the referral start date for which the message will be
 * displayed to the citizen.
 *
 */
public class ReferralCitizenMessagesEventListener extends CitizenMessagesEvent {

  @Inject
  private CaseParticipantRoleDAO caseParticipantRoleDAO;

  @Inject
  private ReferralCitizenMessageComposer referralCitizenMessages;

  @Inject
  private CitizenMessageComposerUtil citizenMessageComposerUtil;

  @Inject
  private ReferralDAO referralDAO;

  @Override
  public void userRequestsMessages(final ParticipantMessages participantMessages)
    throws AppException, InformationalException {

    // check that messages of this kind are enabled, if not, return
    if (!citizenMessageComposerUtil.messageTypeIsEnabled(
      ParticipantMessageTypeEntry.REFERRAL)) {
      return;
    }

    // get a list of referrals
    List<Referral> referrals = getReferrals(
      participantMessages.getConcernRole());

    for (Referral referral : referrals) {
      participantMessages.addMessage(
        referralCitizenMessages.getParticipantMessage(referral));
    }
  }

  /**
   * @param concernRole
   * @return
   */
  private List<Referral> getReferrals(final ConcernRole concernRole) {

    // get a list of case participant roles for this participant
    List<CaseParticipantRole> caseParticipantRoleList = caseParticipantRoleDAO.listActiveByParticipant(
      concernRole);

    // get a list of referrals
    List<curam.referral.impl.Referral> referralList = new ArrayList<curam.referral.impl.Referral>();

    for (CaseParticipantRole caseParticipantRole : caseParticipantRoleList) {

      List<? extends OutcomePlanActivity> referralOutcomePlanActivityList = referralDAO.searchActiveByCaseParticipantRole(
        caseParticipantRole);

      for (OutcomePlanActivity outcomePlanActivity : referralOutcomePlanActivityList) {
        referralList.add((curam.referral.impl.Referral) outcomePlanActivity);
      }
    }

    List<Referral> filteredReferralList = new ArrayList<Referral>();

    for (Referral referral : referralList) {
      if (isValidReferral(referral)) {
        filteredReferralList.add(referral);
      }
    }
    return filteredReferralList;
  }

  /**
   * We only display referrals which have a referral date of today or in the
   * future. if this is not the case, remove the referral from the list.
   * Furthermore, a number of effective days is configurable in administration
   * to define when the message should start being displayed.
   *
   * @param referral
   * the referral in question
   * @return true if the referral has a referral date of today or in the future.
   */
  protected Boolean isValidReferral(final Referral referral) {
    
    if (referral.getReferralDate().isZero()
      || referral.getReferralDate().before(Date.getCurrentDate().addDays(-1))) {
      return false;
    }
    
    if (!citizenMessageComposerUtil.displayMessage(
      EnvVars.ENV_CITIZEN_ACCOUNT_REFERRAL_MESSAGES_EFFECTIVE_DAYS,
      referral.getReferralDate())) {
      return false;
    }
    return true;
  }
}
