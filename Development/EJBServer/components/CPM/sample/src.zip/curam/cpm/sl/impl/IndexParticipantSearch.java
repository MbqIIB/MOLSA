/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.sl.impl;


import java.util.ArrayList;
import java.util.List;

import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.INFORMATIONPROVIDERTYPEEntry;
import curam.core.fact.ProspectPersonFactory;
import curam.core.fact.SearchServiceFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.LuceneHelper;
import curam.core.impl.util.CuramDocToResultStruct;
import curam.core.intf.ProspectPerson;
import curam.core.sl.entity.fact.ProspectEmployerFactory;
import curam.core.sl.entity.intf.ProspectEmployer;
import curam.core.sl.entity.struct.ProspectEmployerDtls;
import curam.core.sl.entity.struct.ProspectEmployerKey;
import curam.core.sl.infrastructure.impl.IndexSearchConst;
import curam.core.sl.struct.AllParticipantSearchDetails;
import curam.core.sl.struct.AllParticipantSearchDtls;
import curam.core.sl.struct.AllParticipantSearchKey;
import curam.core.sl.struct.AllParticipantSearchResult;
import curam.core.sl.struct.TextFieldDetails;
import curam.core.struct.CuramDocument;
import curam.core.struct.CuramQuery;
import curam.core.struct.ProspectPersonDtls;
import curam.core.struct.ProspectPersonKey;
import curam.core.struct.SearchServerResults;
import curam.core.struct.SearchServiceKey;
import curam.message.BPOPARTICIPANTSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;


/**
 * This class creates the search query and performs the search for participant
 * lucene index search. This class is the overridden class from the core class
 * {@linkplain curam.core.sl.impl.IndexParticipantSearch IndexParticipantSearch}
 * .
 */
public class IndexParticipantSearch extends curam.core.sl.impl.IndexParticipantSearch {

  /**
   * Performs an index based search for all participant types using the
   * specified search criteria.
   *
   * @param key
   * Contains data on which the participant search will be based.
   *
   * @return The details of any participant records found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public AllParticipantSearchResult searchAll(
    final AllParticipantSearchKey key) throws AppException,
      InformationalException {
    final CuramQuery curamQuery = createAllParticipantSearchQuery(key);
    final SearchServerResults searchResults = executeQuery(curamQuery);
    final AllParticipantSearchResult result = processAllParticipantSearchQueryResults(
      searchResults, key);

    return result;
  }

  /**
   * Crates query for all participant lucene index search for the specified
   * search criteria.
   *
   * @param key
   * Contains data on which the query will be based.
   *
   * @return The Curam query for all participant lucene index search.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public static CuramQuery createAllParticipantSearchQuery(
    final AllParticipantSearchKey key) throws AppException,
      InformationalException {
    final SearchServiceKey searchServiceKey = new SearchServiceKey();

    searchServiceKey.searchServiceId = IndexSearchConst.kParticipantSearch;
    final CuramQuery curamQuery = new CuramQuery();
    final LuceneHelper luceneHelper = new LuceneHelper();

    curamQuery.searchServiceId = SearchServiceFactory.newInstance().read(searchServiceKey).searchServiceId;

    // Add the fields which will be used to store the results to the query.
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kPrimaryAlternateID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kAddressData));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kConcernRoleID));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kConcernRoleType));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kConcernRoleName));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kDateOfBirth));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kSubtype));
    curamQuery.fields.dtls.addRef(
      luceneHelper.createResultField(IndexSearchConst.kRoleTypeCount));

    StringBuilder participantTypeCriteria = new StringBuilder();

    participantTypeCriteria.append(getPersonSearchCriteria());
    participantTypeCriteria.append(getEmployerSearchCriteria());
    participantTypeCriteria.append(getExternalPartySearchCriteria());
    participantTypeCriteria.append(getProductProviderSearchCriteria());
    participantTypeCriteria.append(getServiceSupplierSearchCriteria());
    participantTypeCriteria.append(getUtilitySearchCriteria());
    participantTypeCriteria.append(getInformationEducationalSearchCriteria());
    participantTypeCriteria.append(getProviderSearchCriteria());
    participantTypeCriteria.append(getProviderGroupSearchCriteria());

    // Remove the first OR from type criteria.
    final String participantSearchCriteria = participantTypeCriteria.toString().substring(
      IndexSearchConst.kORLength, participantTypeCriteria.length());

    final curam.core.sl.intf.IndexParticipantSearch indexParticipantSearchObj = curam.core.sl.fact.IndexParticipantSearchFactory.newInstance();
    final TextFieldDetails textFieldDetails = new TextFieldDetails();

    if (key.referenceNumber.length() > 0) {
      curamQuery.text += IndexSearchConst.kANDString;
      textFieldDetails.fieldName = IndexSearchConst.kAlternateIDList;
      textFieldDetails.fieldValue = key.referenceNumber;
      curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
    }

    if (key.concernRoleName.length() > 0) {
      curamQuery.text += IndexSearchConst.kANDString;
      textFieldDetails.fieldName = IndexSearchConst.kConcernRoleName;
      textFieldDetails.fieldValue = key.concernRoleName;
      curamQuery.text += indexParticipantSearchObj.createQueryTextSearch(textFieldDetails).statement;
    }

    if (key.addressDtls.addressLine1.length() > 0
      || key.addressDtls.addressLine2.length() > 0
      || key.addressDtls.city.length() > 0) {
      curamQuery.text += IndexSearchConst.kANDString;
      curamQuery.text += IndexSearchConst.kPrimaryInd + CuramConst.gkColon
        + IndexSearchConst.kIndexFalseInd;
      curamQuery.text += indexParticipantSearchObj.createQueryAddressSearch(key.addressDtls).statement;
    } else {
      curamQuery.text += IndexSearchConst.kANDString;
      curamQuery.text += IndexSearchConst.kPrimaryInd + CuramConst.gkColon
        + IndexSearchConst.kIndexTrueInd;
    }
    curamQuery.text = CuramConst.gkRoundOpeningBracket
      + participantSearchCriteria + CuramConst.gkRoundClosingBracket
      + curamQuery.text;
    return curamQuery;
  }

  /**
   * Processes all participant query results.
   *
   * @param searchServerResults
   * Contains lucene index search query results.
   * @param key
   * Contains data on which the query was based.
   *
   * @return The details of any participant records found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPARTICIPANTSEARCH#ERR_PARTICIPANTSEARCH_XRV_MAXIMUM}
   * - If search results exceeds participant search maximum value.
   */
  public static AllParticipantSearchResult processAllParticipantSearchQueryResults(
    final SearchServerResults searchServerResults,
    final AllParticipantSearchKey key) throws AppException,
      InformationalException {
    int searchMaximum = 0;

    if (null
      != Configuration.getIntProperty(EnvVars.ENV_PARTICIPANT_SEARCH_MAXIMUM)) {
      searchMaximum = Configuration.getIntProperty(
        EnvVars.ENV_PARTICIPANT_SEARCH_MAXIMUM);
    } else {
      searchMaximum = EnvVars.ENV_PARTICIPANT_SEARCH_MAXIMUM_DEFAULT;
    }

    final List<Long> concernRoleIDList = new ArrayList<Long>();
    final AllParticipantSearchResult allParticipantSearchResult = new AllParticipantSearchResult();

    if (searchServerResults.documents.dtls.size() > searchMaximum) {
      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
      AppException e = new AppException(
        BPOPARTICIPANTSEARCH.ERR_PARTICIPANTSEARCH_XRV_MAXIMUM);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      informationalManager.failOperation();
    } else {

      // Convert the results into the result structure.
      int resultSize = searchServerResults.documents.dtls.size();

      allParticipantSearchResult.dtlsList.ensureCapacity(resultSize);

      for (final CuramDocument curamDocument : searchServerResults.documents.dtls.items()) {
        AllParticipantSearchDtls allParticipantSearchDtls = new AllParticipantSearchDtls();

        allParticipantSearchDtls = (AllParticipantSearchDtls) CuramDocToResultStruct.convert(
          curamDocument, allParticipantSearchDtls, allParticipantDictionary);

        // Set alternate id to input key this is to set correct
        // alternate
        // id in the case when it does not match primary alternate id.
        if (key.referenceNumber.length() > 0) {
          allParticipantSearchDtls.alternateID = key.referenceNumber;
        }

        final ParticipantSearch participantSearch = new ParticipantSearch();
        final AllParticipantSearchDetails allParticipantSearchDetails = participantSearch.processAllSearchDetails(
          allParticipantSearchDtls);

        if (!concernRoleIDList.contains(
          allParticipantSearchDetails.concernRoleID)
            && null != allParticipantSearchDetails.concernRoleName) {
          boolean prospectRegisteredInd = false;

          if (CONCERNROLETYPEEntry.PROSPECTPERSON.getCode().equals(
            allParticipantSearchDtls.concernRoleType)) {

            final ProspectPerson prospectPersonObj = ProspectPersonFactory.newInstance();
            final ProspectPersonKey prospectPersonKey = new ProspectPersonKey();

            prospectPersonKey.concernRoleID = allParticipantSearchDtls.concernRoleID;
            final ProspectPersonDtls prospectPersonDtls = prospectPersonObj.read(
              prospectPersonKey);

            prospectRegisteredInd = prospectPersonDtls.personConcernRoleID != 0;

          } else if (CONCERNROLETYPEEntry.PROSPECTEMPLOYER.getCode().equals(
            allParticipantSearchDtls.concernRoleType)) {

            final ProspectEmployer prospectEmployerObj = ProspectEmployerFactory.newInstance();
            final ProspectEmployerKey prospectEmployerKey = new ProspectEmployerKey();

            prospectEmployerKey.concernRoleID = allParticipantSearchDtls.concernRoleID;
            final ProspectEmployerDtls prospectEmployerDtls = prospectEmployerObj.read(
              prospectEmployerKey);

            prospectRegisteredInd = prospectEmployerDtls.employerConcernRoleID
              != 0;
          }

          if (!prospectRegisteredInd) {
            allParticipantSearchResult.dtlsList.addRef(
              allParticipantSearchDetails);
            concernRoleIDList.add(allParticipantSearchDetails.concernRoleID);
          }
        }
      }
    }
    return allParticipantSearchResult;
  }

  /**
   * Gets the person search criteria details.
   *
   * @return Person search criteria details.
   */
  protected static StringBuilder getPersonSearchCriteria() {
    final StringBuilder personSearchCriteria = new StringBuilder();
    final boolean personSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_PERSON_SEARCH_ENABLED);

    if (personSearchEnabled) {
      personSearchCriteria.append(IndexSearchConst.kORString);
      personSearchCriteria.append(IndexSearchConst.kConcernRoleType);
      personSearchCriteria.append(CuramConst.gkColon);
      personSearchCriteria.append(CONCERNROLETYPEEntry.PERSON.getCode());
      personSearchCriteria.append(IndexSearchConst.kORString);
      personSearchCriteria.append(IndexSearchConst.kConcernRoleType);
      personSearchCriteria.append(CuramConst.gkColon);
      personSearchCriteria.append(CONCERNROLETYPEEntry.PROSPECTPERSON.getCode());
    }
    return personSearchCriteria;
  }

  /**
   * Gets the employer search criteria details.
   *
   * @return Employer search criteria details.
   */
  protected static StringBuilder getEmployerSearchCriteria() {
    final StringBuilder employerSearchCriteria = new StringBuilder();
    final boolean employerSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_EMPLOYER_SEARCH_ENABLED);

    if (employerSearchEnabled) {
      employerSearchCriteria.append(IndexSearchConst.kORString);
      employerSearchCriteria.append(IndexSearchConst.kConcernRoleType);
      employerSearchCriteria.append(CuramConst.gkColon);
      employerSearchCriteria.append(CONCERNROLETYPEEntry.EMPLOYER.getCode());
      employerSearchCriteria.append(IndexSearchConst.kORString);
      employerSearchCriteria.append(IndexSearchConst.kConcernRoleType);
      employerSearchCriteria.append(CuramConst.gkColon);
      employerSearchCriteria.append(
        CONCERNROLETYPEEntry.PROSPECTEMPLOYER.getCode());
    }
    return employerSearchCriteria;
  }

  /**
   * Gets the external party search criteria details.
   *
   * @return External party search criteria details.
   */
  protected static StringBuilder getExternalPartySearchCriteria() {
    final StringBuilder externalPartySearchCriteria = new StringBuilder();
    final boolean externalPartySearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_EXTERNAL_PARTY_SEARCH_ENABLED);

    if (externalPartySearchEnabled) {
      externalPartySearchCriteria.append(IndexSearchConst.kORString);
      externalPartySearchCriteria.append(IndexSearchConst.kConcernRoleType);
      externalPartySearchCriteria.append(CuramConst.gkColon);
      externalPartySearchCriteria.append(
        CONCERNROLETYPEEntry.EXTERNALPARTY.getCode());
    }
    return externalPartySearchCriteria;
  }

  /**
   * Gets the product provider search criteria details.
   *
   * @return Product provider search criteria details.
   */
  protected static StringBuilder getProductProviderSearchCriteria() {
    final StringBuilder productProviderSearchCriteria = new StringBuilder();
    final boolean productProviderSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_PRODUCT_PROVIDER_SEARCH_ENABLED);

    if (productProviderSearchEnabled) {
      productProviderSearchCriteria.append(IndexSearchConst.kORString);
      productProviderSearchCriteria.append(IndexSearchConst.kConcernRoleType);
      productProviderSearchCriteria.append(CuramConst.gkColon);
      productProviderSearchCriteria.append(
        CONCERNROLETYPEEntry.PRODUCTPROVIDER.getCode());
    }
    return productProviderSearchCriteria;
  }

  /**
   * Gets the service supplier search criteria details.
   *
   * @return Service supplier search criteria details.
   */
  protected static StringBuilder getServiceSupplierSearchCriteria() {
    final StringBuilder serviceSupplierSearchCriteria = new StringBuilder();
    final boolean productServiceSupplierSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_SERVICE_SUPPLIER_SEARCH_ENABLED);

    if (productServiceSupplierSearchEnabled) {
      serviceSupplierSearchCriteria.append(IndexSearchConst.kORString);
      serviceSupplierSearchCriteria.append(IndexSearchConst.kConcernRoleType);
      serviceSupplierSearchCriteria.append(CuramConst.gkColon);
      serviceSupplierSearchCriteria.append(
        CONCERNROLETYPEEntry.SERVICESUPPLIER.getCode());
    }
    return serviceSupplierSearchCriteria;
  }

  /**
   * Gets the utility search criteria details.
   *
   * @return Utility search criteria details.
   */
  protected static StringBuilder getUtilitySearchCriteria() {
    final StringBuilder utilitySearchCriteria = new StringBuilder();
    final boolean productUtilitySearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_UTILITY_SEARCH_ENABLED);

    if (productUtilitySearchEnabled) {
      utilitySearchCriteria.append(IndexSearchConst.kORString);
      utilitySearchCriteria.append(IndexSearchConst.kConcernRoleType);
      utilitySearchCriteria.append(CuramConst.gkColon);
      utilitySearchCriteria.append(CONCERNROLETYPEEntry.UTILITY.getCode());
    }
    return utilitySearchCriteria;
  }

  /**
   * Gets an information provider or(and) an educational institute search
   * criteria details.
   *
   * @return An information provider or(and) an educational institute search
   * criteria details.
   */
  protected static StringBuilder getInformationEducationalSearchCriteria() {
    final StringBuilder informationEducationalSearchCriteria = new StringBuilder();
    boolean informationProviderSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_INFORMATION_PROVIDER_SEARCH_ENABLED);
    boolean educationalInstituteSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_EDUCATIONAL_INSTITUTE_SEARCH_ENABLED);

    // Display educational institute if educational institute administration
    // setting is disabled but information provider administration setting
    // is enabled as educational institute is information provider.
    if (informationProviderSearchEnabled) {
      educationalInstituteSearchEnabled = true;
    }

    if (informationProviderSearchEnabled || educationalInstituteSearchEnabled) {
      final StringBuilder infoProviderSearchCriteria = new StringBuilder();

      infoProviderSearchCriteria.append(IndexSearchConst.kConcernRoleType);
      infoProviderSearchCriteria.append(CuramConst.gkColon);
      infoProviderSearchCriteria.append(
        CONCERNROLETYPEEntry.INFORMATIONPROVIDER.getCode());

      if (!informationProviderSearchEnabled) {
        final StringBuilder educationalSearchCriteria = new StringBuilder();

        educationalSearchCriteria.append(CuramConst.gkRoundOpeningBracket);
        educationalSearchCriteria.append(infoProviderSearchCriteria);
        educationalSearchCriteria.append(IndexSearchConst.kANDString);
        educationalSearchCriteria.append(IndexSearchConst.kSubtype);
        educationalSearchCriteria.append(CuramConst.gkColon);
        educationalSearchCriteria.append(
          INFORMATIONPROVIDERTYPEEntry.EDUINSTITUTE.getCode());
        educationalSearchCriteria.append(CuramConst.gkRoundClosingBracket);
        informationEducationalSearchCriteria.append(IndexSearchConst.kORString);
        informationEducationalSearchCriteria.append(educationalSearchCriteria);
      } else {
        informationEducationalSearchCriteria.append(IndexSearchConst.kORString);
        informationEducationalSearchCriteria.append(infoProviderSearchCriteria);
      }
    }
    return informationEducationalSearchCriteria;
  }

  /**
   * Gets the provider search criteria details.
   *
   * @return Provider search criteria details.
   */
  protected static StringBuilder getProviderSearchCriteria() {
    final StringBuilder providerSearchCriteria = new StringBuilder();
    final boolean providerSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_PROVIDER_SEARCH_ENABLED);

    if (providerSearchEnabled) {
      providerSearchCriteria.append(IndexSearchConst.kORString);
      providerSearchCriteria.append(IndexSearchConst.kConcernRoleType);
      providerSearchCriteria.append(CuramConst.gkColon);
      providerSearchCriteria.append(CONCERNROLETYPEEntry.PROVIDER.getCode());
    }
    return providerSearchCriteria;
  }

  /**
   * Gets the provider group search criteria details.
   *
   * @return Provider group search criteria details.
   */
  protected static StringBuilder getProviderGroupSearchCriteria() {
    final StringBuilder providerGroupSearchCriteria = new StringBuilder();
    final boolean providerGroupSearchEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_PROVIDER_GROUP_SEARCH_ENABLED);

    if (providerGroupSearchEnabled) {
      providerGroupSearchCriteria.append(IndexSearchConst.kORString);
      providerGroupSearchCriteria.append(IndexSearchConst.kConcernRoleType);
      providerGroupSearchCriteria.append(CuramConst.gkColon);
      providerGroupSearchCriteria.append(
        CONCERNROLETYPEEntry.PROVIDERGROUP.getCode());
    }
    return providerGroupSearchCriteria;
  }
}
