/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.core.struct.ConcernRoleKey;
import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ContractDetailsList;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.facade.fact.ContextDescriptionFactory;
import curam.cpm.facade.fact.FlatRateContractFactory;
import curam.cpm.facade.fact.UtilizationContractFactory;
import curam.cpm.facade.intf.ContextDescription;
import curam.cpm.facade.intf.FlatRateContract;
import curam.cpm.facade.intf.UtilizationContract;
import curam.cpm.facade.struct.ViewFlatRateContractDetails;
import curam.cpm.facade.struct.ViewFlatRateContractDetails1;
import curam.cpm.facade.struct.ViewUtilizationContractDetails;
import curam.cpm.facade.struct.ViewUtilizationContractDetails1;
import curam.cpm.sl.entity.struct.ContractVersionKey;
import curam.cpm.sl.entity.struct.ProviderGroupKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This process class provides the functionality for processing contracts
 * through the external application.
 */
public abstract class ExternalContract extends curam.cpm.eua.facade.base.ExternalContract {

  /**
   * Constructor needed for access to guice
   */
  public ExternalContract() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  // ___________________________________________________________________________
  /**
   * List all contracts for the selected provider
   *
   * @param concernRoleKey -
   * contains the ConcernRoleID
   * @return This contains a list of contracts for the provider
   *
   * @throws InformationalException 
   *
   * @throws AppException
   */
  public ContractDetailsList listContractsForProvider(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    // result variable
    ContractDetailsList contractDetailsList = new ContractDetailsList();

    // need to do some security checks to ensure that the user
    // accessing the page has the rights to do so
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    FlatRateContract flatRateContractFacade = FlatRateContractFactory.newInstance();
    curam.cpm.sl.entity.struct.ProviderConcernRoleKey providerKey = new curam.cpm.sl.entity.struct.ProviderConcernRoleKey();

    // set the key
    providerKey.providerConcernRoleID = concernRoleKey.concernRoleID;

    // call method to filter returned list
    contractDetailsList.contractList = filterContractList(
      flatRateContractFacade.listProviderContracts(providerKey));

    // variables for reading the context description
    ContextDescription contextDescription = ContextDescriptionFactory.newInstance();

    // Get the context description for the concern role
    contractDetailsList.contextDescription.pageContextDescription = contextDescription.getContextDescriptionForConcern(concernRoleKey).description;

    return contractDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method filters a contract list removing any contracts that are either
   * in edit or canceled.
   *
   * @param unfilteredList -
   * contains a list of contracts
   * @return This list contains a list of contracts excluding any that are
   * canceled or in-edit.
   */
  // BEGIN, CR00177241, PM
  protected curam.cpm.facade.struct.ContractDetailsList filterContractList(
    curam.cpm.facade.struct.ContractDetailsList unfilteredList) {
    // END, CR00177241

    curam.cpm.facade.struct.ContractDetailsList contractDetailsList = new curam.cpm.facade.struct.ContractDetailsList();

    for (int i = 0; i < unfilteredList.contractDetails.size(); i++) {

      if (!unfilteredList.contractDetails.item(i).status.equals(
        CONTRACTSTATUSEntry.CANCELED.getCode())
          && !unfilteredList.contractDetails.item(i).status.equals(
            CONTRACTSTATUSEntry.INEDIT.getCode())) {

        // add to the return list
        contractDetailsList.contractDetails.addRef(
          unfilteredList.contractDetails.item(i));
      }

    }
    return contractDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Read the Flat Rate contract details for a provider
   *
   * @param key -
   * contains the contract version key
   * @return This contains contract details for the concern
   *
   * @throws InformationalException 
   *
   * @throws AppException
   */
  public ViewFlatRateContractDetails viewFlatRateContractForProvider(
    ContractVersionKey key) throws AppException, InformationalException {

    // call facade method to get contract details
    FlatRateContract flatRateContractObj = FlatRateContractFactory.newInstance();
    
    ViewFlatRateContractDetails viewFlatRateContractDetails = new ViewFlatRateContractDetails();

    ViewFlatRateContractDetails1 viewFlatRateContractDetails1 = flatRateContractObj.viewProviderFlatRateContractDetails(
      key);

    // get the concernRoleID of the provider/provider group
    ExternalUserSecurity externalUserSecurityObj = ExternalUserSecurityFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    concernRoleKey.concernRoleID = viewFlatRateContractDetails1.details.viewFlatRateContractDtls.providerConcernRoleID;

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    viewFlatRateContractDetails = viewFlatRateContractDetails1.details;

    // call method to check if logged in user has access to this information
    externalUserSecurityObj.checkProviderGroupSecurity(externalSecurityKey);

    return viewFlatRateContractDetails;
  }

  // ___________________________________________________________________________
  /**
   * Read the Flat Rate contract details for a provider group
   *
   * @param key -
   * contains the contract version key
   * @return This contains contract details for the concern
   *
   * @throws InformationalException 
   *
   * @throws AppException
   */
  public ViewFlatRateContractDetails viewFlatRateContractForProviderGroup(
    ContractVersionKey key) throws AppException, InformationalException {

    // call facade method to get contract details
    FlatRateContract flatRateContractObj = FlatRateContractFactory.newInstance();

    ViewFlatRateContractDetails viewFlatRateContractDetails = flatRateContractObj.viewProviderGroupFlatRateContract(
      key);

    // get the concernRoleID of the provider/provider group
    ExternalUserSecurity externalUserSecurityObj = ExternalUserSecurityFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // set the key
    concernRoleKey.concernRoleID = viewFlatRateContractDetails.viewFlatRateContractDtls.providerConcernRoleID;

    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    // call method to check if logged in user has access to this information
    externalUserSecurityObj.checkProviderGroupSecurity(externalSecurityKey);

    return viewFlatRateContractDetails;
  }

  // ___________________________________________________________________________
  /**
   * List all contracts for the selected provider group
   *
   * @param key
   * contains the ConcernRoleID
   * @return a list of contracts for the provider group
   *
   * @throws InformationalException
   *
   * @throws AppException
   */
  public ContractDetailsList listContractsForProviderGroup(ConcernRoleKey key)
    throws AppException, InformationalException {

    FlatRateContract flatRateContractFacade = FlatRateContractFactory.newInstance();
    ProviderGroupKey providerGroupKey = new ProviderGroupKey();

    // call security method to ensure the user has access to view this
    // information
    ExternalUserSecurity externalUserSecurityObj = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = key;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurityObj.checkProviderGroupSecurity(externalSecurityKey);

    providerGroupKey.providerGroupConcernRoleID = key.concernRoleID;

    ContractDetailsList contractDetailsList = new ContractDetailsList();

    // filter all contracts
    contractDetailsList.contractList = filterContractList(
      flatRateContractFacade.listProviderGroupContracts(providerGroupKey));

    // variables for reading the context description
    ContextDescription contextDescription = ContextDescriptionFactory.newInstance();

    // Get the context description for the concern role
    contractDetailsList.contextDescription.pageContextDescription = contextDescription.getContextDescriptionForConcern(key).description;

    return contractDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Reads a utilization contract
   *
   * @param key -
   * the ID for reading the utilization contract.
   * @return a sorted list of contracts for display.
   *
   * @throws InformationalException 
   * @throws AppException
   */
  public ViewUtilizationContractDetails viewUtilizationContractForProvider(
    ContractVersionKey key) throws AppException, InformationalException {

    // specific to the External Application
    UtilizationContract utilizationContractObj = UtilizationContractFactory.newInstance();

    // the provider group utilization contract retrieves all information
    ViewUtilizationContractDetails viewUtilizationContractDetails = new ViewUtilizationContractDetails();

    ViewUtilizationContractDetails1 viewUtilizationContractDetails1 = utilizationContractObj.viewProviderUtilizationContractDetails(
      key);

    ExternalUserSecurity externalUserSecurityObj = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey.concernRoleID = viewUtilizationContractDetails1.details.viewUtilizationContractDtls.providerConcernRoleID;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    // call security method to ensure that the user has access to the page.
    externalUserSecurityObj.checkProviderGroupSecurity(externalSecurityKey);
    viewUtilizationContractDetails = viewUtilizationContractDetails1.details;

    return viewUtilizationContractDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads a utilization contract
   *
   * @param key -
   * the ID for reading the utilization contract.
   * @return a sorted list of contracts for display.
   *
   * @throws InformationalException 
   * @throws AppException
   */
  public ViewUtilizationContractDetails viewUtilizationContractForProviderGroup(
    ContractVersionKey key) throws AppException, InformationalException {

    // specific to the External Application
    UtilizationContract utilizationContractObj = UtilizationContractFactory.newInstance();

    // the provider group utilization contract retrieves all information
    ViewUtilizationContractDetails viewUtilizationContractDetails = utilizationContractObj.viewProviderGroupUtilizationContract(
      key);

    ExternalUserSecurity externalUserSecurityObj = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey.concernRoleID = viewUtilizationContractDetails.viewUtilizationContractDtls.providerConcernRoleID;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    // call security method to ensure that the user has access to the page.
    externalUserSecurityObj.checkProviderGroupSecurity(externalSecurityKey);

    return viewUtilizationContractDetails;
  }

}
