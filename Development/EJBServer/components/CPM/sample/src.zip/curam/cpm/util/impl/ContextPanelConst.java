/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


/**
 * Utility class with constants for use in Service Delivery and Referral context
 * panels.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
public abstract class ContextPanelConst {

  /**
   * Constant for the style of the right hand side panel holding all the details
   * of the item this outcome plan context panel is for. This is used when there
   * is more than 1 client to be displayed in the left hand side panel.
   */
  public static final String kStyleContentPanelDetailServiceOrReferralContentPanel = "content-panel-detail serviceorreferral-content-panel";

  /**
   * Constant for the style of the right hand side panel holding all the details
   * of the item this outcome plan context panel is for. This is a wider panel
   * used when there is only 1 client to be displayed in the left hand side
   * panel.
   */
  public static final String kStyleContentPanelDetailServiceOrReferralContentPanelMedium = "content-panel-detail serviceorreferral-content-panel-medium";

  /**
   * Constant for the style of the right hand side panel holding all the details
   * of the item this outcome plan context panel is for. This is used when there
   * is more than 1 client to be displayed in the left hand side panel. The
   * panel should contain a blue footer panel.
   */
  public static final String kStyleContentPanelDetailServiceOrReferralContentPanelBlueFooter = "content-panel-detail serviceorreferral-content-panel content-panel-blue-footer";

  /**
   * Constant for the style of the right hand side panel holding all the details
   * of the item this outcome plan context panel is for. This is a wider panel
   * used when there is only 1 client to be displayed in the left hand side
   * panel. The panel should contain a blue footer panel.
   */
  public static final String kStyleContentPanelDetailServiceOrReferralContentPanelMediumBlueFooter = "content-panel-detail serviceorreferral-content-panel-medium content-panel-blue-footer";

  /**
   * Constant for the style of the panel holding all the details of the outcome
   * plan context panel.
   */
  public static final String kStyleContainerPanelServiceOrReferral = "container-panel-serviceorreferral";

  /**
   * Constant for the style of the provider name and icons panel.
   */
  public static final String kStyleProviderNameIcons = "provider-name-icons";

  /**
   * Constant for the style of the date content table.
   */
  public static final String kStyleDateContentTable = "date-content-table";

  /**
   * Constant for the style of the panel to hold the date images and lists.
   */
  public static final String kStyleDateContentDetail = "date-content-detail";

  /**
   * Constant for the style of the panel to hold the date details. -
   */
  public static final String kStyleDateContent = "date-content";

  /**
   * Constant for the style of the panel to hold the user and date details. E.g.
   * 300.00 on 23/10/2010, where Super User is a link to the user details modal.
   */
  public static final String kStyleUserDatePanel = "user-date-panel";

  /**
   * Constant for the style of the panel to hold the latest payment details.
   * E.g. 300.00 on 23/10/2010.
   */
  public static final String kStyleLatestPaymentPanel = "latest-payment-panel";

  /**
   * Constant for the style of the panel used in 2 column layout.
   */
  public static final String kStyleColumnContentPanel = "column-content-panel";

  /**
   * Constant for the main details horizontal table style.
   */
  public static final String kStyleMainDetailsHorizontalTable = "main-details horiz-table";

  /**
   * Constant for the horizontal table style.
   */
  public static final String kStyleHorizTable = "horiz-table";

  /**
   * Constant for the style of the person name link in the list view.
   */
  public static final String kStyleLinkPersonName = "link person-name";

  /**
   * Constant for the style of the outcome plan link.
   */
  public static final String kStyleTabLink = "link tab-link";

  /**
   * Constant for style of the list to hold the main details of the tab item.
   */
  public static final String kStyleServiceOrReferralDetailsListTwoColumns = "serviceorreferral-details-list-two-columns";

  /**
   * Constant for style for the name of the tab item.
   */
  public static final String kStyleName = "name";

  /**
   * Constant for style for the status of the tab item.
   */
  public static final String kStyleStatus = "status";

  /**
   * Constant for style for the panel containing the main details of the tab
   * item.
   */
  public static final String kStyleServiceOrReferralDetails = "serviceorreferral-details";

  /**
   * Constant for style for the panel containing the details of the tab item.
   */
  public static final String kStyleServiceOrReferralTabDetails = "serviceorreferral-tab-details";

  /**
   * Constant for style for outcome plan clients list.
   */
  public static final String kStyleServiceOrReferralMemberList = "serviceorreferral-member-list tab-case-list";

  /**
   * Constant for style for the picture panel for outcome plan clients.
   */
  public static final String kStyleFourImagesStackContainerServiceOrReferral = "stackCon-fourimages-serviceorreferral";

  /**
   * Constant for the activity outcome reason not successful domain definition.
   */
  public static final String kDomainActivityOutcomeReason = "ACTIVITY_OUTCOME_REASON";

  /**
   * Constant for the activity outcome achieved domain definition.
   */
  public static final String kDomainActivityOutcomeAchieved = "ACTIVITY_OUTCOME_ACHIEVED";

  /**
   * Constant for the service delivery status domain definition.
   */
  public static final String kDomainServiceDeliveryStatus = "SERVICE_DEL_STATUS";

  /**
   * Constant for the provider type domain definition.
   */
  public static final String kDomainProviderType = "PROVIDER_TYPE";

  /**
   * Constant for the Curam standard struts link extension. </br> Value:
   * "Page.do"
   */
  public static final String kStrutsExt = "Page.do";

  /**
   * Constant for the caseID page parameter. </br> Value: "caseID"
   */
  public static final String kPageParameterCaseID = "caseID";

  /**
   * Constant for the standard case resolve page. </br> Value:
   * "Case_resolveCaseHome"
   */
  public static final String kStandardCaseResolvePage = "Case_resolveCaseHome";

}
