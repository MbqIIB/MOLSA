/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.citizenmessages.internal.impl;


import com.google.inject.ImplementedBy;
import curam.participantmessages.impl.ParticipantMessage;
import curam.referral.impl.Referral;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Creates a {@link curam.participantmessages.impl.ParticipantMessage} object
 * based on the {@link Referral} passed in. The consuming code must ensure that
 * the user is of the correct type to receive these messages and that the
 * message type is enabled. This is internal and should not be called by
 * customers.
 *
 */
@ImplementedBy(ReferralCitizenMessageComposerImpl.class)
public interface ReferralCitizenMessageComposer {

  /**
   * Creates a {@link curam.participantmessages.impl.ParticipantMessage} object
   * based on the {@link Referral} passed in.
   */
  ParticipantMessage getParticipantMessage(Referral referralRole)
    throws AppException, InformationalException;

}
