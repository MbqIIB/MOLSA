/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import com.google.inject.Inject;
import curam.codetable.impl.COMMUNICATIONMETHODEntry;
import curam.codetable.impl.PROXIMITYDISTANCEEntry;
import curam.codetable.impl.REFERRALNOTIFICATIONTYPEEntry;
import curam.codetable.impl.REFERRALRELATEDLINKTYPEEntry;
import curam.codetable.impl.SOSINGLEORMULTIPLECLIENTSEntry;
import curam.core.fact.AddressFactory;
import curam.core.struct.AddressDtls;
import curam.cpm.facade.struct.AddReferralContextDetails;
import curam.cpm.facade.struct.AddReferralDetailsCapture;
import curam.cpm.facade.struct.AddReferralDetailsResult;
import curam.cpm.facade.struct.AddReferralNotificationCapture;
import curam.cpm.facade.struct.AddReferralNotificationResult;
import curam.cpm.facade.struct.AddReferralProviderCapture;
import curam.cpm.facade.struct.AddReferralProviderResult;
import curam.cpm.facade.struct.AddReferralServiceCapture;
import curam.cpm.facade.struct.AddReferralServiceResult;
import curam.cpm.facade.struct.AddReferralWizardData;
import curam.cpm.facade.struct.ListProviderDetailsKey;
import curam.cpm.facade.struct.ProviderReferralRoleDetails;
import curam.cpm.facade.struct.ServiceProviderDetailsList;
import curam.cpm.sl.impl.ReferralAdapter;
import curam.cpm.util.impl.ReferralWizardConstants;
import curam.cpm.util.impl.ReferralWizardHelper;
import curam.cpm.util.impl.ServiceProviderSearchHelper;
import curam.datastore.entity.struct.DatastoreEntityKey;
import curam.datastore.impl.Datastore;
import curam.datastore.impl.DatastoreFactory;
import curam.datastore.impl.Entity;
import curam.datastore.impl.EntityType;
import curam.datastore.impl.NoSuchSchemaException;
import curam.message.REFERRAL;
import curam.message.impl.REFERRALExceptionCreator;
import curam.message.impl.SERVICEDELIVERYExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.piwrapper.casemanager.impl.CaseParticipantRoleDAO;
import curam.piwrapper.impl.AddressDAO;
import curam.piwrapper.participantmanager.impl.ConcernRoleCommException;
import curam.piwrapper.participantmanager.impl.ConcernRoleCommExceptionDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderSpecialtyTypeEntry;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.servicedelivery.impl.CuramConst;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.type.Date;
import curam.util.type.StringHelper;


/**
 * Facade layer class used by the Add Referral wizard.
 *
 * @since 6.0
 */
public class ReferralWizard extends curam.cpm.facade.base.ReferralWizard {

  /**
   * Local instance of the data store.
   */
  protected Datastore datastore;

  /**
   * Reference to Case Header DAO instance.
   */
  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  /**
   * Reference to Service Offering DAO instance.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Reference to Provider DAO instance.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Provider instance reference for Service Provider Search Helper object.
   */
  @Inject
  protected com.google.inject.Provider<ServiceProviderSearchHelper> serviceProviderSearchHelperProvider;

  /**
   * Reference to Provider Offering DAO instance.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Reference to Case Participant Role DAO instance.
   */
  @Inject
  protected CaseParticipantRoleDAO caseParticipantRoleDAO;

  /**
   * Provider instance reference to Referral Wizard Helper instance.
   */
  @Inject
  protected com.google.inject.Provider<ReferralWizardHelper> referralWizardHelperProvider;

  /**
   * Reference to Address DAO instance.
   */
  @Inject
  protected AddressDAO addressDAO;

  /**
   * Reference to Concern Role Comm Exception DAO instance.
   */
  @Inject
  protected ConcernRoleCommExceptionDAO concernRoleCommExceptionDAO;

  /**
   * Default constructor used to inject Guice bindings.
   */
  public ReferralWizard() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public AddReferralServiceResult getService(final AddReferralWizardData key)
    throws AppException, InformationalException {

    AddReferralServiceResult addReferralServiceResult = new AddReferralServiceResult();

    // Populate the context details
    addReferralServiceResult.contextDetails = getContextDetails(key);

    // Read the details from the data store entity
    Entity referralEntity = getDatastore().readEntity(
      key.wizardData.rootEntityID);

    // set the finish wizard and create referral indicator
    referralWizardHelperProvider.get().setFinishWizardAndCreateInd(key,
      referralEntity);

    addReferralServiceResult.serviceOfferingID = (Long) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kSERVICE_OFFERING_ID);
    if (addReferralServiceResult.serviceOfferingID == CuramConst.gkZero) {
      addReferralServiceResult.serviceName = (String) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kSERVICE_NAME);
    }
    return addReferralServiceResult;

  }

  /**
   * {@inheritDoc}
   */
  public AddReferralWizardData setService(
    final AddReferralServiceCapture service) throws AppException,
      InformationalException {

    referralWizardHelperProvider.get().validateServiceDetails(service.dtls);
    ValidationHelper.failIfErrorsExist();

    // retrieve the referral entity
    Entity referralEntity = getDatastore().readEntity(
      service.dtls.wizardData.rootEntityID);

    if (serviceDetailsModified(service.dtls)) {

      referralWizardHelperProvider.get().updateReferralWizardDataBasedOnServiceChange(
        service.dtls, referralEntity);

      referralEntity.setTypedAttribute(
        ReferralWizardConstants.kSERVICE_OFFERING_ID, CuramConst.gkZero);
      referralEntity.setTypedAttribute(ReferralWizardConstants.kSERVICE_NAME,
        CuramConst.gkEmpty);

    }

    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kSERVICE_OFFERING_ID,
      service.dtls.serviceOfferingID);
    referralEntity.setTypedAttribute(ReferralWizardConstants.kSERVICE_NAME,
      service.dtls.serviceName);

    referralEntity.update();

    /*
     * determine if the referral wizard is complete and the referral is to be
     * created
     */
    if (referralWizardHelperProvider.get().getFinishWizardAndCreateInd(
      referralEntity)) {
      referralWizardHelperProvider.get().createReferral(referralEntity,
        service.dtls.wizardData.relatedID,
        REFERRALRELATEDLINKTYPEEntry.get(service.dtls.relatedType));
    }

    return service.dtls;

  }

  /**
   * Determines if the service details for the referral wizard have been
   * modified. If the service details passed in from the client differ from what
   * is stored on the {@link curam.datastore.impl.Datastore}, the service
   * details have been modified and true is returned.
   *
   * @param addReferralWizardData
   * The struct containing the identifier for the
   * {@link curam.datastore.impl.Datastore} and the service details
   * that where passed in from the client
   * @return true if the service details have been modified, otherwise false
   */
  protected boolean serviceDetailsModified(
    final AddReferralWizardData addReferralWizardData) {

    Entity referralEntity = getDatastore().readEntity(
      addReferralWizardData.wizardData.rootEntityID);

    // passed in service name is different to service name on data store
    if (addReferralWizardData.serviceName
      != referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kSERVICE_NAME)) {
      return true;
    }

    /*
     * passed in service offering identifier is different to service offering on
     * data store
     */
    if (addReferralWizardData.serviceOfferingID
      != (Long) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kSERVICE_OFFERING_ID)) {
      return true;
    }
    return false;
  }

  /**
   * {@inheritDoc}
   */
  public DatastoreEntityKey startCreateReferralWizard() throws AppException,
      InformationalException {
    // Create an instance of the return value object
    DatastoreEntityKey datastoreEntityKey = new DatastoreEntityKey();

    // Create the root entity
    EntityType rootEntityType = getDatastore().getEntityType(
      CuramConst.kREFERRAL_DATASTORE_ENTITY_NAME);
    Entity rootEntity = getDatastore().newEntity(rootEntityType);

    // add the root entity to the data store
    getDatastore().addRootEntity(rootEntity);

    // Set the return value
    datastoreEntityKey.entityID = rootEntity.getUniqueID();

    return datastoreEntityKey;
  }

  /**
   * Opens the {@link curam.datastore.impl.Datastore} used to store the details
   * for the add service wizard.
   *
   * @return The data store for the add service wizard script
   */
  protected Datastore getDatastore() {

    // Check if the data store has already been opened
    if (datastore != null) {
      return datastore;
    }

    try {
      datastore = DatastoreFactory.newInstance().openDatastore(
        curam.servicedelivery.impl.CuramConst.kREFERRAL_WIZARD_DATASTORE_SCHEMA_NAME);
    } catch (NoSuchSchemaException e) {
      throw new AppRuntimeException(e);
    }
    return datastore;

  }

  /**
   * Reads the context details for the wizard.
   *
   * @param wizardData
   * data relating to the wizard
   * @return The populated context details for the wizard.
   * @throws InformationalException
   * Generic Application Exception.
   * @throws AppException
   * Generic Application Exception.
   */
  protected AddReferralContextDetails getContextDetails(
    final AddReferralWizardData wizardData) throws AppException,
      InformationalException {
    AddReferralContextDetails addReferralContextDetails = new AddReferralContextDetails();

    if (REFERRALRELATEDLINKTYPEEntry.get(wizardData.relatedType).equals(
      REFERRALRELATEDLINKTYPEEntry.CASE)) {
      addReferralContextDetails.pageDescription = caseHeaderDAO.get(wizardData.wizardData.relatedID).getDescription();
    }

    addReferralContextDetails.wizardMenu = wizardData.wizardData.wizardPropertyName;
    return addReferralContextDetails;
  }

  /**
   * {@inheritDoc}
   */
  public AddReferralDetailsResult getDetails(final AddReferralWizardData key)
    throws AppException, InformationalException {
    AddReferralDetailsResult addReferralDetailsResult = new AddReferralDetailsResult();
    // Read the details from the data store
    Entity referralEntity = getDatastore().readEntity(
      key.wizardData.rootEntityID);

    // set the finish wizard and create referral indicator
    referralWizardHelperProvider.get().setFinishWizardAndCreateInd(key,
      referralEntity);

    // set context details
    addReferralDetailsResult.contextDetails = getContextDetails(key);

    // set the referral details
    addReferralDetailsResult.referralDetails.clientStringList = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kSELECTED_CLIENTS);
    addReferralDetailsResult.referralDetails.referralDtls.referralDate = (Date) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kREFERRAL_DATE);
    addReferralDetailsResult.referralDetails.loggedOnUserOwnerInd = (Boolean) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kREFERRED_BY_ME_IND);
    addReferralDetailsResult.referralDetails.referralDtls.referredBy = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kREFERRED_BY);
    addReferralDetailsResult.referralDetails.referralDtls.followUpRequiredInd = (Boolean) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kFOLLOW_UP_REQUIRED_IND);
    addReferralDetailsResult.referralDetails.referralDtls.followUpWarningDays = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kFOLLOW_UP_WARNING_DAYS);
    addReferralDetailsResult.referralDetails.referralDtls.sensitivity = referralEntity.getAttribute(
      ReferralWizardConstants.kSENSITIVITY);
    addReferralDetailsResult.referralDetails.referralDtls.reason = referralEntity.getAttribute(
      ReferralWizardConstants.kREASON);

    // retrieve the configuration settings for the referral details page
    if (multipleClientReferralServiceSelected(key)) {
      addReferralDetailsResult.multipleClientsSelectableInd = true;
    }
    return addReferralDetailsResult;
  }

  /**
   * Determines if the entered referral service is configured to allow multiple
   * clients to be selected.
   *
   * @param key
   * the key containing the selected referral service
   * @return true if the entered referral service is configured to allow
   * multiple clients to be selected.
   */
  protected boolean multipleClientReferralServiceSelected(
    final AddReferralWizardData key) {

    /*
     * if the service is an unregistered service multiple clients are allowed to
     * be selected
     */
    if (!StringHelper.isEmpty(key.serviceName)) {
      return true;
    }

    /*
     * if here, it means a service a from the service registry was selected.
     * Retrieve the service and determine if the service is configured for
     * multiple clients
     */
    if (serviceOfferingDAO.get(key.serviceOfferingID).getSingleOrMultipleClients().equals(
      SOSINGLEORMULTIPLECLIENTSEntry.MULTIPLE)) {
      return true;
    }

    /*
     * if here, it means a service from the service registry was selected that
     * is configured for a single client, return false.
     */
    return false;
  }

  /**
   * {@inheritDoc}
   */
  public AddReferralWizardData setDetails(
    final AddReferralDetailsCapture details) throws AppException,
      InformationalException {

    validateDetails(details);
    ValidationHelper.failIfErrorsExist();

    Entity referralEntity = setReferralDetails(details);

    /*
     * determine if the referral wizard is complete and the referral is to be
     * created
     */
    if (referralWizardHelperProvider.get().getFinishWizardAndCreateInd(
      referralEntity)) {
      referralWizardHelperProvider.get().createReferral(referralEntity,
        details.dtls.wizardData.relatedID,
        REFERRALRELATEDLINKTYPEEntry.get(details.dtls.relatedType));
    }
    return details.dtls;
  }

  /**
   * Validate the entered referral details. The following exceptions are thrown:
   * <ul>
   * <li>
   * {@link REFERRAL#ERR_FV_CLIENT_MANDATORY}, if no client has been selected
   * for the referral</li>
   * <li>
   * {@link REFERRAL#ERR_XFV_FOLLOWUP_REQUIRED_IND_MUST_BE_ENTERED_IF_FOLLOWUP_WARNING_DAYS_ENTERED}
   * , if the follow warning days have been entered and the follow up required
   * indicator not selected</li>
   * <li>
   * {@link REFERRAL#ERR_XFV_FOLLOWUP_WARNING_DAYS_MUST_BE_ENTERED_IF_FOLLOWUP_REQUIRED_IND_SELECTED}
   * , if the follow up warning indicator has been selected and the follow up
   * warning days not entered</li>
   * <li>
   * {@link REFERRAL#ERR_XFV_REFERRED_BY_ME_REFERRED_BY_USER_MUST_BE_SELECTED} ,
   * if the referred by me indicator has not been selected and no referred by
   * user has being entered</li>
   * <li>
   * {@link REFERRAL#ERR_XFV_ONLY_ONE_OF_REFERRED_BY_ME_OR_REFERRED_BY_USER_CAN_BE_ENTERED}
   * , if both the referred by me indicator has been selected and the referred
   * by user has being entered</li>
   * <li>
   * {@link REFERRAL#ERR_XRV_REFERRAL_DATE_AFTER_SERVICE_OFFERING_END_DATE} , if
   * both the referral date is after the end date of the selected service
   * offering</li>
   * </ul>
   *
   * @param details
   * The struct containing the referral details to be validated
   */
  protected void validateDetails(final AddReferralDetailsCapture details) {

    // client must be selected
    validateClientEntered(details);
    validationFollowUpDetails(details);
    validateReferredByDetails(details);

    if (StringHelper.isEmpty(details.referralDetails.referralDtls.reason)
      || (details.referralDetails.referralDtls.reason.equals(
        curam.servicedelivery.impl.CuramConst.BLANK_NARRATIVE))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEDELIVERYExceptionCreator.ERR_FV_REASON_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    /*
     * the referral date is after the end date of the selected service offering
     */
    validateReferralDateAfterServiceEndDate(details);

    /*
     * Validate that the referral date is not before the service start date
     */
    Date referralDate = details.referralDetails.referralDtls.referralDate;

    if (StringHelper.isEmpty(details.dtls.serviceName)
      && !referralDate.isZero()) {
      Date serviceStartDate = serviceOfferingDAO.get(details.dtls.serviceOfferingID).getDateRange().start();

      if (referralDate.before(serviceStartDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          REFERRALExceptionCreator.ERR_XRV_REFERRAL_DATE_BEFORE_SERVICE_OFFERING_START_DATE(
            details.referralDetails.referralDtls.referralDate, serviceStartDate),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  }

  /**
   * Validation, where the following exception is thrown is the referral date is
   * after the end date of the selected service offering.
   * <p>
   * {@link REFERRAL#ERR_FV_CLIENT_MANDATORY}, if no client has been selected
   * for the referral</li>
   * </p>
   *
   * @param details
   * The details struct containing the referral and service details.
   */
  protected void validateReferralDateAfterServiceEndDate(
    final AddReferralDetailsCapture details) {
    if (StringHelper.isEmpty(details.dtls.serviceName)
      && (referralDateAfterServiceOfferingEndDate(details))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_XRV_REFERRAL_DATE_AFTER_SERVICE_OFFERING_END_DATE(
          details.referralDetails.referralDtls.referralDate,
          serviceOfferingDAO.get(details.dtls.serviceOfferingID).getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

    }
  }

  /**
   * Validation, where the following exception is thrown if not client has been
   * selected.
   * <p>
   * {@link REFERRAL#ERR_XRV_REFERRAL_DATE_AFTER_SERVICE_OFFERING_END_DATE} , if
   * both the referral date is after the end date of the selected service
   * offering
   * </p>
   *
   * @param details
   * the struct containing the client details to be validated
   */
  protected void validateClientEntered(final AddReferralDetailsCapture details) {
    if (StringHelper.isEmpty(details.referralDetails.clientStringList)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_FV_CLIENT_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * Validate the entered referred by details. The following exceptions are
   * thrown:
   * <ul>
   * <li>
   * {@link REFERRAL#ERR_XFV_REFERRED_BY_ME_REFERRED_BY_USER_MUST_BE_SELECTED} ,
   * if the referred by me indicator has not been selected and no referred by
   * user has being entered</li>
   * <li>
   * {@link REFERRAL#ERR_XFV_ONLY_ONE_OF_REFERRED_BY_ME_OR_REFERRED_BY_USER_CAN_BE_ENTERED}
   * , if both the referred by me indicator has been selected and the referred
   * by user has being entered</li>
   * <li>
   * </ul>
   *
   * @param details
   * the struct containing the referred by details to be validated
   */
  protected void validateReferredByDetails(
    final AddReferralDetailsCapture details) {

    /*
     * the referred by me indicator has been selected and the referred by user
     * details entered
     */
    if (details.referralDetails.loggedOnUserOwnerInd
      && !StringHelper.isEmpty(details.referralDetails.referralDtls.referredBy)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_XFV_ONLY_ONE_OF_REFERRED_BY_ME_OR_REFERRED_BY_USER_CAN_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    /*
     * neither the referred by me indicator has been selected and the referred
     * by user details entered
     */
    if (!details.referralDetails.loggedOnUserOwnerInd
      && StringHelper.isEmpty(details.referralDetails.referralDtls.referredBy)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_XFV_REFERRED_BY_ME_REFERRED_BY_USER_MUST_BE_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * Validate the entered follow up details. The following exceptions are
   * thrown:
   * <ul>
   * <li>
   * {@link REFERRAL#ERR_XFV_FOLLOWUP_REQUIRED_IND_MUST_BE_ENTERED_IF_FOLLOWUP_WARNING_DAYS_ENTERED}
   * , if the follow warning days have been entered and the follow up required
   * indicator not selected</li>
   * <li>
   * {@link REFERRAL#ERR_XFV_FOLLOWUP_WARNING_DAYS_MUST_BE_ENTERED_IF_FOLLOWUP_REQUIRED_IND_SELECTED}
   * , if the follow up warning indicator has been selected and the follow up
   * warning days not entered</li>
   * </ul>
   *
   * @param details
   * the struct containing the follow up details to be validated
   */
  protected void validationFollowUpDetails(
    final AddReferralDetailsCapture details) {
    // follow up warning indicator has been selected an warning days not entered
    if (details.referralDetails.referralDtls.followUpRequiredInd
      && StringHelper.isEmpty(
        details.referralDetails.referralDtls.followUpWarningDays)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_XFV_FOLLOWUP_WARNING_DAYS_MUST_BE_ENTERED_IF_FOLLOWUP_REQUIRED_IND_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // follow up waring days entered and follow up waring indicator not selected
    if (!details.referralDetails.referralDtls.followUpRequiredInd
      && !StringHelper.isEmpty(
        details.referralDetails.referralDtls.followUpWarningDays)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_XFV_FOLLOWUP_REQUIRED_IND_MUST_BE_ENTERED_IF_FOLLOWUP_WARNING_DAYS_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (!StringHelper.isEmpty(
      details.referralDetails.referralDtls.followUpWarningDays)) {
      try {
        Integer.parseInt(
          details.referralDetails.referralDtls.followUpWarningDays);
      } catch (NumberFormatException e) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          REFERRALExceptionCreator.ERR_XFV_FOLLOWUP_WARNING_DAYS_MUST_BE_NUMERIC(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }
  }

  /**
   * Determines if the referral date, if entered, is after the end date (if one
   * exists) of the service offering.
   *
   * @param details
   * the struct containing the referral date
   * @return true if the referral date is after the service offering end date,
   * otherwise false
   */
  protected boolean referralDateAfterServiceOfferingEndDate(
    final AddReferralDetailsCapture details) {
    return !details.referralDetails.referralDtls.referralDate.equals(
      Date.kZeroDate)
        && (details.referralDetails.referralDtls.referralDate.after(
          serviceOfferingDAO.get(details.dtls.serviceOfferingID).getDateRange().end())
            && !serviceOfferingDAO.get(details.dtls.serviceOfferingID).getDateRange().end().equals(
              Date.kZeroDate));
  }

  /**
   * {@inheritDoc}
   */
  public AddReferralProviderResult getProvider(final AddReferralWizardData key)
    throws AppException, InformationalException {

    AddReferralProviderResult addReferralProviderResult = new AddReferralProviderResult();
    // Read the details from the data store
    Entity referralEntity = getDatastore().readEntity(
      key.wizardData.rootEntityID);

    // set the finish wizard and create referral indicator
    referralWizardHelperProvider.get().setFinishWizardAndCreateInd(key,
      referralEntity);

    // determine if the wizard is in relation to a service offering or
    // unregistered service.
    addReferralProviderResult.registeredServiceOfferingEnteredInd = registeredServiceOfferingEntered(
      referralEntity);

    // set context details
    addReferralProviderResult.contextDetails = getContextDetails(key);

    addReferralProviderResult.providerDetails.providerID = (Long) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_ID);

    // retrieve the provider representative details
    addReferralProviderResult.providerDetails.providerName = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_NAME);
    addReferralProviderResult.providerDetails.providerAddressDetails = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_ADDRESS_DETAILS);
    addReferralProviderResult.providerDetails.phoneAreaCode = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_PHONE_AREA_CODE);
    addReferralProviderResult.providerDetails.phoneCountryCode = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_PHONE_COUNTRY_CODE);
    addReferralProviderResult.providerDetails.phoneNumber = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_PHONE_NUMBER);
    addReferralProviderResult.providerDetails.emailAddress = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_EMAIL_ADDRESS);

    // retrieve the search for a provider criteria
    addReferralProviderResult.searchedProviderDetails.addressID = (Long) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kCLIENT_ADDRESSS_ID);
    addReferralProviderResult.searchedProviderDetails.caseParticipantRoleID = (Long) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kCASE_PARTICIPANT_ROLE_ID);
    addReferralProviderResult.searchedProviderDetails.providerSpecialtiesTabbedString = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_SPECIALITY_CODE);
    addReferralProviderResult.searchedProviderDetails.proximityDistance = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROXIMITYDISTANCE);
    addReferralProviderResult.searchedProviderDetails.providerID = (Long) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kSEARCHED_PROVIDER_ID);
    addReferralProviderResult.searchedProviderDetails.providerName = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDERNAME);

    // Retrieve the case participant and
    addReferralProviderResult.caseClientsAddressesList = serviceProviderSearchHelperProvider.get().getCaseClientsNameList(
      caseHeaderDAO.get(key.wizardData.relatedID).listActiveCaseMembers());
    addReferralProviderResult.specialties = serviceProviderSearchHelperProvider.get().getProviderSpecialityCodesAsList();
    // if a search has been executed retrieve the details
    addReferralProviderResult.proximityDistanceLabelDisplayString = CuramConst.gkRoundOpeningBracket
      + serviceProviderSearchHelperProvider.get().getMeasurementDistance().toUserLocaleString()
      + CuramConst.gkRoundClosingBracket;
    if ((Boolean) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_SEARCH_PERFORMED)) {

      ListProviderDetailsKey listProviderDetailsKey = new ListProviderDetailsKey();

      listProviderDetailsKey.addressID = addReferralProviderResult.searchedProviderDetails.addressID;
      listProviderDetailsKey.providerSpecialtiesTabbedString = addReferralProviderResult.searchedProviderDetails.providerSpecialtiesTabbedString;
      listProviderDetailsKey.proximityDistance = addReferralProviderResult.searchedProviderDetails.proximityDistance;
      listProviderDetailsKey.providerName = addReferralProviderResult.searchedProviderDetails.providerName;
      // listProviderDetailsKey.serviceOfferingID = (Long) referralEntity
      // .getTypedAttributeWithDefault(ReferralWizardConstants.kSERVICE_OFFERING_ID);
      ServiceOffering serviceOffering = serviceOfferingDAO.get(
        (Long) referralEntity.getTypedAttributeWithDefault(
          ReferralWizardConstants.kSERVICE_OFFERING_ID));

      addReferralProviderResult.providerDetailsList = listProviderDetailsForService(
        listProviderDetailsKey, serviceOffering);

    }
    return addReferralProviderResult;
  }

  /**
   * Determines if the referral wizard is in relation to a registered service
   * offering.
   *
   * @param referralEntity
   * the referral {@link curam.datastore.impl.Datastore} {@link Entity}
   * holding the data that is to be used to determine if the referral
   * wizard is in relation to a registered service offering
   * @return true if the referral wizard is in relation to a registered service
   * offering, otherwise false
   */
  protected boolean registeredServiceOfferingEntered(final Entity referralEntity) {
    return CuramConst.gkZero
      != ((Long) referralEntity.getTypedAttributeWithDefault(ReferralWizardConstants.kSERVICE_OFFERING_ID)).longValue();
  }

  /**
   * {@inheritDoc}
   */
  public AddReferralWizardData setProvider(
    final AddReferralProviderCapture details) throws AppException,
      InformationalException {

    /*
     * do not validate the provider details if it is a search that is been
     * performed
     */
    if (!details.searchPerformedInd) {
      validateProvider(details);
      ValidationHelper.failIfErrorsExist();
    }

    // Update the details on the referral entity
    Entity referralEntity = setReferralProvider(details);

    /*
     * Set the search provider indicator. This indicates that the user has
     * selected to search for a provider rather than select next on the wizard.
     * Note, this can not be set back to false, as once a search has been
     * performed in a wizard the details should always be displayed. That is, if
     * the user performs a search and then selects next followed by previous,
     * the results of the executed search need to be displayed.
     */
    if (!(Boolean) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_SEARCH_PERFORMED)) {
      referralEntity.setTypedAttribute(
        ReferralWizardConstants.kPROVIDER_SEARCH_PERFORMED,
        details.searchPerformedInd);
    }

    /*
     * determine if the referral wizard is complete and the referral is to be
     * created
     */
    if (referralWizardHelperProvider.get().getFinishWizardAndCreateInd(
      referralEntity)) {
      referralWizardHelperProvider.get().createReferral(referralEntity,
        details.dtls.wizardData.relatedID,
        REFERRALRELATEDLINKTYPEEntry.get(details.dtls.relatedType));
    }

    referralEntity.update();

    return details.dtls;

  }

  /**
   * Validate the entered referral provider details. The following exceptions
   * are thrown:
   * <ul>
   * <li>
   * {@link REFERRAL#ERR_XRV_MULTIPLE_PROVIDERS_MUST_NOT_BE_ENTERED} , if a
   * provider has been selected and provider details entered</li>
   * <li>
   * <li>
   * {@link REFERRAL#ERR_XRV_PROVIDER_MUST_BE_ENTERED_IF_FOLLOWUP_REQUIRED_IND_ENTERED}
   * , if the follow up required indicator has been selected and no provider
   * details have been entered</li>
   * <li>
   * {@link REFERRAL#ERR_XRV_PROVIDER_DOES_NOT_PROVIDE_SERVICE} , if the
   * selected provider does not provide the service this referral is in relation
   * to</li>
   * <li>
   * {@link REFERRAL#ERR_XRV_PROVIDER_DOES_NOT_PROVIDE_SERVICE_FOR_REFERRAL_DATE}
   * , if the selected provider does not provide the service this referral is in
   * relation to for the entered referral date</li>
   * </ul>
   *
   * @param details
   * The struct containing the referral provider details to be
   * validated
   * @throws InformationalException
   * Generic Exception Handler
   */
  protected void validateProvider(final AddReferralProviderCapture details)
    throws InformationalException {

    Entity referralEntity = getDatastore().readEntity(
      details.dtls.wizardData.rootEntityID);

    /*
     * validate to ensure that the user has not selected a provider from the
     * system and entered provider details
     */
    if (details.searchedProviderDetails.providerID != 0
      && !StringHelper.isEmpty(details.providerDetails.providerName)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_XRV_MULTIPLE_PROVIDERS_MUST_NOT_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    /*
     * validate to ensure that if the follow up required indicator has been
     * selected a provider has been entered.
     */
    if ((Boolean) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kFOLLOW_UP_REQUIRED_IND)
        && details.providerDetails.providerID == 0
        && details.searchedProviderDetails.providerID == 0
        && StringHelper.isEmpty(details.providerDetails.providerName)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_XRV_PROVIDER_MUST_BE_ENTERED_IF_FOLLOWUP_REQUIRED_IND_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    /*
     * validates to ensure that the selected provider is configured to provider
     * the service this referral is in relation to, and that the selected
     * provider offers the service within the entered referral date
     */
    if (details.searchedProviderDetails.providerID != 0
      && (Long) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kSERVICE_OFFERING_ID)
          != 0) {

      Provider provider = providerDAO.get(
        details.searchedProviderDetails.providerID);
      ServiceOffering serviceOffering = serviceOfferingDAO.get(
        (Long) referralEntity.getTypedAttributeWithDefault(
          ReferralWizardConstants.kSERVICE_OFFERING_ID));

      /*
       * ensure the selected provider is configured to provider the service this
       * referral is in relation to
       */
      validateProviderConfiguredToForReferralService(provider, serviceOffering);

      /*
       * ensure the selected provider offers the service for the entered
       * referral date
       */
      validateProviderOffersServiceWithinReferralDate(provider, serviceOffering,
        getReferralDate(referralEntity));
    }

    validateProviderAddress(details.providerDetails);
  }

  /**
   * Retrieves the referral date to be used during the referral wizard. If a
   * referral date is entered by the user by on the details page of the wizard,
   * the entered referral date is returned. If no referral date has been entered
   * by the user the current date is returned.
   *
   *
   * @param referralEntity
   * the referral {@link curam.datastore.impl.Datastore} {@link Entity}
   * holding the data entered by the user in relation to the referral
   * wizard
   * @return the referral date for the referral as entered by the user, or the
   * current date if no referral date was entered
   */
  protected Date getReferralDate(final Entity referralEntity) {

    final Date enteredReferralDate = (Date) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kREFERRAL_DATE);

    /*
     * if a referral date has been entered by the user (i.e. the datastore
     * referral date is not equal to the zero date), return the entered date
     */
    if (!enteredReferralDate.isZero()) {
      return enteredReferralDate;
    }

    // no referral date was entered by the user, return the current date
    return Date.getCurrentDate();
  }

  /**
   * Validates the address data if unregistered provider details are entered.
   *
   * @param details
   * unregistered provider details
   * @throws InformationalException
   * Generic Exception Signature
   */
  protected void validateProviderAddress(
    final ProviderReferralRoleDetails details) throws InformationalException {

    /*
     * */
    if (!StringHelper.isEmpty(details.providerName)) {
      AddressDtls addressDetails = new AddressDtls();
      curam.core.intf.Address addressObj = AddressFactory.newInstance();

      addressDetails.addressData = details.providerAddressDetails;
      try {
        addressObj.validate(addressDetails);
      } catch (AppException ae) {
        ValidationHelper.addValidationError(ae);
      }
    }
  }

  /**
   * Validates that the period the {@link Provider provider} is configured to
   * offer the {@link ServiceOffering service offering} for, contains the date
   * the referral is set to commence on. If the provider is not configured to
   * offer for the service for the referral date, the following exception is
   * thrown:
   * <ul>
   * <li>
   * {@link REFERRAL#ERR_XRV_PROVIDER_DOES_NOT_PROVIDE_SERVICE_FOR_REFERRAL_DATE}
   * </li>
   * <li>
   * </ul>
   *
   * @param provider
   * The provider that must be configured for the given service
   * offering
   * @param serviceOffering
   * the service offering the provider must be configured for
   * @param referralDate
   * the date the referral is configured to commence on
   */
  protected void validateProviderOffersServiceWithinReferralDate(
    final Provider provider, final ServiceOffering serviceOffering,
    final Date referralDate) {

    final Set<ProviderOffering> providerOfferingSet = providerOfferingDAO.searchProviderOffering(
      provider.getID(), serviceOffering.getID());

    boolean validProviderOfferingFound = false;

    for (ProviderOffering providerOffering : providerOfferingSet) {
      validProviderOfferingFound = providerOffering.getDateRange().contains(
        referralDate);

      if (validProviderOfferingFound) {
        break;
      }

    }

    if (!validProviderOfferingFound && !providerOfferingSet.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_XRV_PROVIDER_DOES_NOT_PROVIDE_SERVICE_FOR_REFERRAL_DATE(
          provider.getName(), serviceOffering.getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

    }
  }

  /**
   * Validates that the {@link Provider provider} this referral relates to is
   * configured to offer the given {@link ServiceOffering} this referral is in
   * relation to. If the provider is not configured for the service, the
   * following exception is thrown:
   * <ul>
   * <li>
   * {@link REFERRAL#ERR_XRV_PROVIDER_DOES_NOT_PROVIDE_SERVICE}</li>
   * </ul>
   *
   * @param provider
   * The provider that must be configured for the given service
   * offering
   * @param serviceOffering
   * the service offering the provider must be configured for
   */
  protected void validateProviderConfiguredToForReferralService(
    final Provider provider, final ServiceOffering serviceOffering) {

    final Set<ProviderOffering> providerOfferingSet = providerOfferingDAO.searchProviderOffering(
      provider.getID(), serviceOffering.getID());

    if (providerOfferingSet.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_XRV_PROVIDER_DOES_NOT_PROVIDE_SERVICE(
          provider.getName(), serviceOffering.getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  /**
   * Retrieves a list of provider details for a service based on the passed in
   * criteria. This method is intended to be used by users responsible for the
   * management of Referrals.
   *
   * @param listProviderDetailsKey
   * the service the provider must provide, and criteria the provider
   * must meet
   * @param serviceOffering
   * service offering instance
   * @return the list of providers the offer the service
   */
  protected ServiceProviderDetailsList listProviderDetailsForService(
    final ListProviderDetailsKey listProviderDetailsKey,
    final ServiceOffering serviceOffering) throws AppException,
      InformationalException {
    List<ProviderSpecialtyTypeEntry> specialties = new ArrayList<ProviderSpecialtyTypeEntry>();

    if (!StringHelper.isEmpty(
      listProviderDetailsKey.providerSpecialtiesTabbedString)) {
      String[] specialtyCodes = listProviderDetailsKey.providerSpecialtiesTabbedString.split(
        CuramConst.gkTabDelimiter);

      for (String specialtyCode : specialtyCodes) {
        specialties.add(ProviderSpecialtyTypeEntry.get(specialtyCode));
      }
    }
    ServiceProviderDetailsList providerDetailsList = serviceProviderSearchHelperProvider.get().listProvidersForServiceOffering(
      serviceOffering, addressDAO.get(listProviderDetailsKey.addressID),
      specialties,
      PROXIMITYDISTANCEEntry.get(listProviderDetailsKey.proximityDistance),
      listProviderDetailsKey.providerName);

    return providerDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public AddReferralNotificationResult getNotifications(
    final AddReferralWizardData key) throws AppException,
      InformationalException {

    AddReferralNotificationResult addReferralNotificationResult = new AddReferralNotificationResult();
    // Read the details from the data store
    Entity referralEntity = getDatastore().readEntity(
      key.wizardData.rootEntityID);

    // set the finish wizard and create referral indicator
    referralWizardHelperProvider.get().setFinishWizardAndCreateInd(key,
      referralEntity);

    // set context details
    addReferralNotificationResult.contextDetails = getContextDetails(key);

    // determine if a provider has been entered.
    addReferralNotificationResult.providerEnteredInd = providerEntered(
      referralEntity);

    // set the notification details
    addReferralNotificationResult.notificationDetails.notifyClientAutomatically = (Boolean) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kNOTIFIY_CLIENT_AUTOMATICALLY);
    addReferralNotificationResult.notificationDetails.notifyProviderAutomatically = (Boolean) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kNOTIFIY_PROVIDER_AUTOMATICALLY);
    addReferralNotificationResult.notificationDetails.clientNotificationText = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kCLIENT_NOTIFICATION_TEXT);
    addReferralNotificationResult.notificationDetails.providerNotificationText = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kPROVIDER_NOTIFICATION_TEXT);
    return addReferralNotificationResult;

  }

  /**
   * Determines if a provider has been entered on by the user for the referral
   * wizard.
   *
   * @param referralEntity
   * the {@link Entity} storing the data entered by the user on the
   * wizard
   * @return true if a provider has been entered for the referral, otherwise
   * false
   */
  protected boolean providerEntered(final Entity referralEntity) {
    return CuramConst.gkZero
      != ((Long) referralEntity.getTypedAttributeWithDefault(ReferralWizardConstants.kPROVIDER_ID)).longValue()
        || !StringHelper.isEmpty(
          (String) referralEntity.getTypedAttributeWithDefault(
            ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_NAME));
  }

  /**
   * {@inheritDoc}
   */
  public AddReferralWizardData setNotifications(
    final AddReferralNotificationCapture details) throws AppException,
      InformationalException {

    // Update the notification details on the referral entity
    Entity referralEntity = getDatastore().readEntity(
      details.dtls.wizardData.rootEntityID);

    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kNOTIFIY_CLIENT_AUTOMATICALLY,
      details.notificationDetails.notifyClientAutomatically);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kNOTIFIY_PROVIDER_AUTOMATICALLY,
      details.notificationDetails.notifyProviderAutomatically);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kCLIENT_NOTIFICATION_TEXT,
      details.notificationDetails.clientNotificationText);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kPROVIDER_NOTIFICATION_TEXT,
      details.notificationDetails.providerNotificationText);

    validateNotificationDetails(details);

    referralEntity.update();

    /*
     * determine if the referral wizard is complete and the referral is to be
     * created
     */
    if (referralWizardHelperProvider.get().getFinishWizardAndCreateInd(
      referralEntity)) {
      referralWizardHelperProvider.get().createReferral(referralEntity,
        details.dtls.wizardData.relatedID,
        REFERRALRELATEDLINKTYPEEntry.get(details.dtls.relatedType));
    }
    return details.dtls;
  }

  /**
   * Validate the entered notification details. The following informational
   * warnings are thrown:
   * <ul>
   * <li>
   * {@link REFERRAL#INF_NOTIFICATION_HARDCOPY_EMAIL_FAIL_FOR_PROVIDER}, if
   * notify provider automatically has been selected and it is not possible to
   * automatically notify the provider.</li>
   * <li>
   * {@link REFERRAL#INF_NOTIFICATION_HARDCOPY_EMAIL_FAIL_FOR_CLIENT}, if notify
   * provider automatically has been selected and it is not possible to
   * automatically notify the selected client(s)</li>
   * </ul>
   *
   * @param details
   * The struct containing the referral notification details to be
   * validated
   * @throws InformationalException
   * Generic Information Exception
   * @throws AppException
   * Generic Information Exception
   */
  protected void validateNotificationDetails(
    final AddReferralNotificationCapture details) throws AppException,
      InformationalException {

    /*
     * Check that the notification text doesn't exceed the max number of allowed
     * characters.
     */
    if (details.notificationDetails.clientNotificationText.length()
      > ReferralAdapter.kMaxLength_clientNotificationText) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_FV_CLIENT_NOTIFICATION_TOO_LARGE(
          details.notificationDetails.clientNotificationText.length(),
          ReferralAdapter.kMaxLength_clientNotificationText),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (details.notificationDetails.providerNotificationText.length()
      > ReferralAdapter.kMaxLength_providerNotificationText) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REFERRALExceptionCreator.ERR_FV_PROVIDER_NOTIFICATION_TOO_LARGE(
          details.notificationDetails.providerNotificationText.length(),
          ReferralAdapter.kMaxLength_providerNotificationText),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    ValidationHelper.failIfErrorsExist();

    // Retrieve the referral data store
    Entity referralEntity = getDatastore().readEntity(
      details.dtls.wizardData.rootEntityID);

    /*
     * if notify client automatically has been selected, validate it is actually
     * possible to notify all clients
     */
    if (details.notificationDetails.notifyClientAutomatically) {
      validateClientNotifications(referralEntity);
    }

    /*
     * if notify provider automatically has been selected, validate it is
     * actually possible to notify the provider
     */
    if (details.notificationDetails.notifyProviderAutomatically) {
      validateProviderNotifications(referralEntity);
    }

  }

  /**
   * Validates the entered provider notification details. Ensuring it is
   * possible to notify a provider if the automatic notify provider option has
   * been selected.
   * <p>
   * If it is not possible to notify the provider the following warning is
   * thrown:</br>
   * {@link REFERRAL#INF_NOTIFICATION_HARDCOPY_EMAIL_FAIL_FOR_PROVIDER}
   * </p>
   *
   * @param referralEntity
   * the {@link curam.datastore.impl.Datastore} entity containing the
   * provider details to be validated
   * @throws AppException
   * Generic Information Exception
   * @throws InformationalException
   * Generic Information Exception
   */
  protected void validateProviderNotifications(final Entity referralEntity)
    throws AppException, InformationalException {
    Provider provider = providerDAO.get(
      (Long) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kPROVIDER_ID));

    // Provider stored on the system was selected
    if (CuramConst.gkZero != provider.getID()) {

      validationCommunicationExceptions(provider,
        REFERRALNOTIFICATIONTYPEEntry.PROVIDER);

    }

    // a provider that does not exist on the system was entered
    if (CuramConst.gkZero == provider.getID()) {

      /*
       * ensure either an address or email address has been entered for the
       * provider
       */
      if (!notifyProviderRepresentativeAutomatically(referralEntity)) {

        createProviderAutomaticNofificationWarning(
          (String) referralEntity.getTypedAttributeWithDefault(
            ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_NAME));
      }
    }
  }

  /**
   * Creates a
   * {@link REFERRAL#INF_NOTIFICATION_HARDCOPY_EMAIL_FAIL_FOR_PROVIDER} warning
   * for the given provider name.
   *
   * @param providerName
   * the name of the provider the warning is to be created for
   * @throws InformationalException
   * Generic Information Exception
   */
  protected void createProviderAutomaticNofificationWarning(
    final String providerName) throws InformationalException {
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
      REFERRALExceptionCreator.INF_NOTIFICATION_HARDCOPY_EMAIL_FAIL_FOR_PROVIDER(
        REFERRALNOTIFICATIONTYPEEntry.PROVIDER.toUserLocaleString(),
        providerName),
        CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
        0);
  }

  /**
   * Determines if it is possible for the system to automatically notify a
   * provider representative. That is, the provider did not exist on the system
   * and their details are entered by the user.
   * <p>
   * In order to be able to contact the provider automatically either an address
   * or email address must have been entered for the provider by the user.
   * </p>
   *
   * @param referralEntity
   * The {@link curam.datastore.impl.Datastore} entity containing the
   * provider details entered by the user
   * @return true if it is possible to automatically notify the provider,
   * otherwise false
   */
  protected boolean notifyProviderRepresentativeAutomatically(
    final Entity referralEntity) {
    if (StringHelper.isEmpty(
      (String) referralEntity.getTypedAttributeWithDefault(
        ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_ADDRESS_DETAILS))
          && StringHelper.isEmpty(
            (String) referralEntity.getTypedAttributeWithDefault(
              ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_EMAIL_ADDRESS))) {
      return false;
    }

    return true;
  }

  /**
   * Validates the entered client notification details. Ensuring it is possible
   * to notify all clients if the automatic notify client option has been
   * selected.
   * <p>
   * If it is not possible to notify a client the following warning is thrown
   * for the specific client:</br>
   * {@link REFERRAL#INF_NOTIFICATION_HARDCOPY_EMAIL_FAIL_FOR_CLIENT}
   * </p>
   *
   * @param referralEntity
   * the {@link curam.datastore.impl.Datastore} entity containing the
   * client details to be validated
   * @throws AppException
   * Generic Information Exception
   * @throws InformationalException
   * Generic Information Exception
   */
  protected void validateClientNotifications(final Entity referralEntity)
    throws AppException, InformationalException {

    String clients = (String) referralEntity.getTypedAttributeWithDefault(
      ReferralWizardConstants.kSELECTED_CLIENTS);

    String[] caseParticipantRoleIDs = clients.split(CuramConst.gkTabDelimiter);

    for (String caseParticipantRoleID : caseParticipantRoleIDs) {

      validationCommunicationExceptions(
        caseParticipantRoleDAO.get(Long.parseLong(caseParticipantRoleID)).getConcernRole(),
        REFERRALNOTIFICATIONTYPEEntry.CLIENT);

    }

  }

  /**
   * Validates to ensure it is possible to notify the concern role if the
   * automatic notify option has been selected.
   * <p>
   * If either a email or hard copy communication exception exist or for the
   * given concern role, it is not possible to automatically notify the concern
   * role and a informational warning is created.
   * </p>
   *
   * @param concernRole
   * The concern role to determine if any communication exceptions
   * exist for
   * @param referralNotificationTypeEntry
   * the type of referral notification that the concern role is in
   * relation to
   * @throws AppException
   * Generic Information Exception
   * @throws InformationalException
   * Generic Information Exception
   */
  protected void validationCommunicationExceptions(
    final ConcernRole concernRole,
    final REFERRALNOTIFICATIONTYPEEntry referralNotificationTypeEntry)
    throws AppException, InformationalException {

    /*
     * create informational warning if exceptions exist or no address or email
     * exist for the concernRole
     */
    if (communicationExceptionsExistForConernRole(concernRole)
      || (concernRole.getPrimaryAddressID() == CuramConst.gkZero
        && concernRole.getPrimaryEmailAddressID() == CuramConst.gkZero)) {

      if (referralNotificationTypeEntry.equals(
        REFERRALNOTIFICATIONTYPEEntry.CLIENT)) {
        createClientAutomaticNotificationWarning(concernRole.getName());
      } else {
        createProviderAutomaticNofificationWarning(concernRole.getName());
      }
    }
  }

  /**
   * Creates a {@link REFERRAL#INF_NOTIFICATION_HARDCOPY_EMAIL_FAIL_FOR_CLIENT}
   * warning for the given client name.
   *
   * @param clientName
   * the name of the client the warning is to be created for
   * @throws InformationalException
   * Generic Information Exception
   */
  protected void createClientAutomaticNotificationWarning(
    final String clientName) throws InformationalException {
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
      REFERRALExceptionCreator.INF_NOTIFICATION_HARDCOPY_EMAIL_FAIL_FOR_CLIENT(
        REFERRALNOTIFICATIONTYPEEntry.CLIENT.toUserLocaleString(), clientName),
        CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
        0);
  }

  /**
   * Determines if any {@link ConcernRoleCommException} records exist of
   * {@link COMMUNICATIONMETHODEntry#EMAIL} and
   * {@link COMMUNICATIONMETHODEntry#HARDCOPY} for the passed in concern role.
   *
   * @param concernRole
   * The concern role the communication exceptions being search for are
   * in relation to. The concern role relates to either the client or
   * provider.
   * @return true if communication exceptions exist for the concern role,
   * otherwise false
   * @throws InformationalException
   * Generic Information Exception
   * @throws AppException
   * Generic Application Exception
   */
  protected Boolean communicationExceptionsExistForConernRole(
    final ConcernRole concernRole) throws AppException,
      InformationalException {

    List<ConcernRoleCommException> concernRoleCommExceptionList = concernRoleCommExceptionDAO.searchActiveByConcernRoleAndCommunicationMethod(
      concernRole, COMMUNICATIONMETHODEntry.EMAIL);

    concernRoleCommExceptionList.addAll(
      concernRoleCommExceptionDAO.searchActiveByConcernRoleAndCommunicationMethod(
        concernRole, COMMUNICATIONMETHODEntry.HARDCOPY));

    if (concernRoleCommExceptionList.size() > CuramConst.gkZero) {
      return true;
    }

    return false;
  }

  /**
   * Sets the general Referral details captured on the Referral Wizard details
   * page and stores the entered details on the data store. The method does not
   * validate the passed in data.
   *
   * @param details
   * The entered Referral details
   * @return The {@link curam.datastore.impl.Datastore} entity containing the
   * referral details
   */
  protected Entity setReferralDetails(final AddReferralDetailsCapture details) {
    Entity referralEntity = getDatastore().readEntity(
      details.dtls.wizardData.rootEntityID);

    referralEntity.setTypedAttribute(ReferralWizardConstants.kSELECTED_CLIENTS,
      details.referralDetails.clientStringList);
    referralEntity.setTypedAttribute(ReferralWizardConstants.kREFERRAL_DATE,
      details.referralDetails.referralDtls.referralDate);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kREFERRED_BY_ME_IND,
      details.referralDetails.loggedOnUserOwnerInd);
    referralEntity.setTypedAttribute(ReferralWizardConstants.kREFERRED_BY,
      details.referralDetails.referralDtls.referredBy);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kFOLLOW_UP_REQUIRED_IND,
      details.referralDetails.referralDtls.followUpRequiredInd);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kFOLLOW_UP_WARNING_DAYS,
      details.referralDetails.referralDtls.followUpWarningDays);
    referralEntity.setTypedAttribute(ReferralWizardConstants.kSENSITIVITY,
      details.referralDetails.referralDtls.sensitivity);
    referralEntity.setTypedAttribute(ReferralWizardConstants.kREASON,
      details.referralDetails.referralDtls.reason);

    referralEntity.update();
    return referralEntity;
  }

  /**
   * Sets the preselected service provider identifier for the Referral Wizard
   * storing the provider identifier on the referral wizard data store. The
   * method does not validate the passed in data.
   *
   * @param details
   * The entered provider details
   * @return The {@link curam.datastore.impl.Datastore} entity containing the
   * provider details
   */
  protected Entity setReferralProvider(final AddReferralProviderCapture details) {

    Entity referralEntity = getDatastore().readEntity(
      details.dtls.wizardData.rootEntityID);

    // set the finish wizard and create referral indicator
    referralWizardHelperProvider.get().setFinishWizardAndCreateInd(details.dtls,
      referralEntity);

    // update any entered provider representative details
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_EMAIL_ADDRESS,
      details.providerDetails.emailAddress);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_PHONE_AREA_CODE,
      details.providerDetails.phoneAreaCode);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_PHONE_COUNTRY_CODE,
      details.providerDetails.phoneCountryCode);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_PHONE_NUMBER,
      details.providerDetails.phoneNumber);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_NAME,
      details.providerDetails.providerName);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kPROVIDER_REPRESENTATIVE_ADDRESS_DETAILS,
      details.providerDetails.providerAddressDetails);

    // update any selected provider
    referralEntity.setTypedAttribute(ReferralWizardConstants.kPROVIDER_ID,
      details.searchedProviderDetails.providerID);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kSEARCHED_PROVIDER_ID,
      details.searchedProviderDetails.providerID);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kPROVIDER_SPECIALITY_CODE,
      details.searchedProviderDetails.providerSpecialtiesTabbedString);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kCLIENT_ADDRESSS_ID,
      details.searchedProviderDetails.addressID);
    referralEntity.setTypedAttribute(
      ReferralWizardConstants.kCASE_PARTICIPANT_ROLE_ID,
      details.searchedProviderDetails.caseParticipantRoleID);
    referralEntity.setTypedAttribute(ReferralWizardConstants.kPROXIMITYDISTANCE,
      details.searchedProviderDetails.proximityDistance);
    referralEntity.setTypedAttribute(ReferralWizardConstants.kPROVIDERNAME,
      details.searchedProviderDetails.providerName);
    return referralEntity;
  }

}
