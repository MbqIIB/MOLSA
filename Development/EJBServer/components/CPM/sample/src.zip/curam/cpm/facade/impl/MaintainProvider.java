/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2009, 2013
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office 
 */

/*
 * Copyright 2009-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.cefwidgets.docbuilder.impl.ImagePanelBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.cefwidgets.docbuilder.impl.LinksPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ListBuilder;
import curam.codetable.COMMUNICATIONSTATUS;
import curam.codetable.CONCERNROLEADDRESSTYPE;
import curam.codetable.CONCERNROLESTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SENSITIVITY;
import curam.codetable.impl.ADDRESSELEMENTTYPEEntry;
import curam.codetable.impl.CASESTATUSEntry;
import curam.codetable.impl.CMSLINKRELATEDTYPEEntry;
import curam.codetable.impl.COMMUNICATIONFORMATEntry;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.codetable.impl.CURRENCYEntry;
import curam.codetable.impl.INCIDENTSTATUSEntry;
import curam.codetable.impl.LOCALEEntry;
import curam.codetable.impl.METHODOFDELIVERYEntry;
import curam.codetable.impl.PREFERREDSERVICEENQUIRYMETHODEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.RESOLUTIONSTATUSCODEEntry;
import curam.codetable.impl.TEMPLATEIDCODEEntry;
import curam.contracts.impl.ContractNotificationEventEntry;
import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.ContractVersionDAO;
import curam.core.facade.fact.CommunicationFactory;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.intf.Communication;
import curam.core.facade.struct.FileNameAndDataDtls;
import curam.core.facade.struct.InternationalBankAccountIndicator;
import curam.core.facade.struct.ReadAttachmentKey;
import curam.core.facade.struct.ReadCommunicationAttachmentDetails;
import curam.core.fact.AddressElementFactory;
import curam.core.fact.AddressFactory;
import curam.core.fact.CommAttachmentLinkFactory;
import curam.core.fact.ConcernRoleCommunicationFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ConcernRolePhoneNumberFactory;
import curam.core.fact.DeliveryMethodFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.ConcernRoleAdapter;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.Address;
import curam.core.intf.AddressElement;
import curam.core.intf.ConcernRole;
import curam.core.intf.ConcernRoleCommunication;
import curam.core.intf.ConcernRolePhoneNumber;
import curam.core.intf.DeliveryMethod;
import curam.core.intf.UniqueID;
import curam.core.sl.fact.ParticipantTabFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.infrastructure.cmis.impl.CMISAccessInterface;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.struct.AddressTabDetails;
import curam.core.sl.struct.PhoneFaxDetails;
import curam.core.sl.struct.PreviewProFormaKey;
import curam.core.struct.AddressDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressElementDtls;
import curam.core.struct.AddressElementDtlsList;
import curam.core.struct.AddressKey;
import curam.core.struct.BankAccountDetails;
import curam.core.struct.CommunicationAttachmentLinkReadmultiKey;
import curam.core.struct.ConcernRoleCommunicationDtls;
import curam.core.struct.ConcernRoleCommunicationKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRolePhoneDetails;
import curam.core.struct.ConcernRolePhoneNumberDtls;
import curam.core.struct.DeliveryMethodDtls;
import curam.core.struct.DeliveryMethodKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PhoneForConcernRoleKey;
import curam.cpm.facade.fact.CompartmentFactory;
import curam.cpm.facade.fact.MaintainAttendanceConfigurationFactory;
import curam.cpm.facade.fact.MaintainReservationFactory;
import curam.cpm.facade.fact.PlaceFactory;
import curam.cpm.facade.fact.ProviderFactory;
import curam.cpm.facade.fact.ProviderGroupFactory;
import curam.cpm.facade.fact.ProviderInvestigationFactory;
import curam.cpm.facade.intf.Compartment;
import curam.cpm.facade.intf.MaintainAttendanceConfiguration;
import curam.cpm.facade.intf.Place;
import curam.cpm.facade.intf.ProviderInvestigation;
import curam.cpm.facade.struct.CompartmentDetails;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.InvestigationDeliveryListForProvider;
import curam.cpm.facade.struct.PlaceAndPlacementDetails;
import curam.cpm.facade.struct.PlaceAndPlacementDetailsList;
import curam.cpm.facade.struct.ProviderAttendanceTrackingDetails;
import curam.cpm.facade.struct.ProviderConcernRoleKey;
import curam.cpm.facade.struct.ProviderEnrollmentDetails;
import curam.cpm.facade.struct.ProviderEnrollmentInformation;
import curam.cpm.facade.struct.ProviderEnrollmentReferenceKey;
import curam.cpm.facade.struct.ProviderGroupSummaryDetails;
import curam.cpm.facade.struct.ProviderGroupSummaryDetailsList;
import curam.cpm.facade.struct.ProviderInvestigationDetails;
import curam.cpm.facade.struct.ProviderNotificationReturnDocDetails;
import curam.cpm.facade.struct.ProviderStatusHistoryDetails;
import curam.cpm.facade.struct.ProviderStatusHistoryUserDetailsList;
import curam.cpm.facade.struct.ProviderSummaryVersionDetails;
import curam.cpm.facade.struct.ProviderSummaryVersionDetailsList;
import curam.cpm.facade.struct.ProviderTabDetails;
import curam.cpm.facade.struct.ReservationSummaryDetailsList;
import curam.cpm.facade.struct.SearchByReferenceNumber;
import curam.cpm.facade.struct.SearchProviderOrganizationDetails;
import curam.cpm.facade.struct.UserNameDetails;
import curam.cpm.facade.struct.UserNameDetailsList;
import curam.cpm.facade.struct.ViewCompartmentKey;
import curam.cpm.facade.struct.WizardMenuDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.impl.ProviderAdapter;
import curam.cpm.sl.entity.struct.CompartmentDtls;
import curam.cpm.sl.entity.struct.CompartmentKey;
import curam.cpm.sl.entity.struct.ProviderDtls;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ProviderSearchCriteriaKey;
import curam.cpm.sl.entity.struct.ProviderSearchDetails;
import curam.cpm.sl.entity.struct.ProviderSearchDetailsList;
import curam.cpm.sl.entity.struct.ProviderSearchKey;
import curam.cpm.sl.entity.struct.SearchProviderGroupKey;
import curam.cpm.sl.fact.ProviderNotificationFactory;
import curam.cpm.sl.fact.WMCreatePlaceDataFactory;
import curam.cpm.sl.intf.ProviderNotification;
import curam.cpm.sl.intf.WMCreatePlaceData;
import curam.cpm.sl.struct.CommunicationDetails;
import curam.cpm.sl.struct.ProviderNotificationKey;
import curam.cpm.sl.struct.WMCreatePlaceDataDtls;
import curam.financial.impl.FinancialNotificationEventEntry;
import curam.localization.translation.facade.struct.LocalizableTextTranslationDetails;
import curam.message.BPOAPPLICATIONSEARCH;
import curam.message.BPOBANKACCOUNT;
import curam.message.BPOPARTICIPANT;
import curam.message.GENERALADMIN;
import curam.message.PROVIDER;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.participant.impl.PhoneNumber;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.piwrapper.webaddress.impl.WebAddress;
import curam.place.CompartmentStatus;
import curam.place.impl.PlaceDAO;
import curam.place.impl.PlaceStatusEntry;
import curam.provider.ProviderNotificationEvent;
import curam.provider.impl.LicenseNotificationEventEntry;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderCategoryNameEntry;
import curam.provider.impl.ProviderCategoryPeriod;
import curam.provider.impl.ProviderCategoryPeriodDAO;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderEnquiryDAO;
import curam.provider.impl.ProviderGroup;
import curam.provider.impl.ProviderGroupAssociate;
import curam.provider.impl.ProviderGroupAssociateDAO;
import curam.provider.impl.ProviderIncident;
import curam.provider.impl.ProviderNotificationEventEntry;
import curam.provider.impl.ProviderReferenceNumberStrategy;
import curam.provider.impl.ProviderStatusEntry;
import curam.provider.impl.ProviderStatusHistory;
import curam.provider.impl.ProviderStatusHistoryDAO;
import curam.provider.impl.ProviderType;
import curam.provider.impl.ProviderTypeDAO;
import curam.provider.impl.ProviderTypeNameEntry;
import curam.provider.impl.RosterNotificationEventEntry;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.useradmin.impl.MaintainAdminConcernRole;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.fact.DeferredProcessingFactory;
import curam.util.intf.DeferredProcessing;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateTime;
import curam.util.type.DateTimeRange;
import curam.util.type.FrequencyPattern;
import curam.util.type.StringHelper;
import curam.waitlist.impl.WaitList;
import curam.waitlist.impl.WaitListDAO;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.message.impl.LOCALIZABLETEXTExceptionCreator;


/**
 * Facade layer class having APIs for managing Provider.
 */
public class MaintainProvider extends curam.cpm.facade.base.MaintainProvider {

  // BEGIN, CR00380509, SS
  /**
   * Constant for maximum designated capacity.
   */
  protected static final int kMaximumCapacity = CPMConstants.kMaximumCapacity;

  /**
   * Constant for minimum physical and designated capacity.
   */
  protected static final int kMinimumCapacity = CPMConstants.kMinimumCapacity;

  // END, CR00380509
  
  /**
   * Constant for number of contracts to display in Provider context panel.
   */
  protected static final int kNumContractsToDisplay = 5;

  /**
   * String constant for a place name.
   */
  protected static final String kPlaceName = CPMConstants.kPlace;

  // BEGIN, CR00380509, SS
  /**
   * Constant for maximum physical capacity.
   */
  protected static final int kPRPhysicalCapacity = CPMConstants.kPRPhysicalCapacity;

  // END, CR00380509

  // BEGIN, CR00292749, MR
  /**
   * Reference to CMIS Access Interface.
   */
  @Inject
  protected CMISAccessInterface cmisAccessInterface;

  // END, CR00292749

  /**
   * Reference to Contract Version DAO.
   */
  @Inject
  protected ContractVersionDAO contractVersionDAO;

  /**
   * Reference to localizable text handler DAO.
   */
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Reference to Place DAO.
   */
  @Inject
  protected PlaceDAO placeDAO;

  /**
   * Reference to provider category period.
   */
  @Inject
  protected ProviderCategoryPeriodDAO providerCategoryPeriodDAO;

  /**
   * Reference to provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to provider enquiry DAO.
   */
  @Inject
  protected ProviderEnquiryDAO providerEnquiryDAO;

  /**
   * Reference to Provider Group Associate DAO.
   */
  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;

  /**
   * Reference to provider status history DAO.
   */
  @Inject
  protected ProviderStatusHistoryDAO providerStatusHistoryDAO;

  /**
   * Reference to provider type DAO.
   */
  @Inject
  protected ProviderTypeDAO providerTypeDAO;

  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;

  /**
   * Reference to Wait list DAO.
   */
  @Inject
  protected WaitListDAO waitListDAO;

  /**
   * Reference to provider reference number strategy.
   */
  @Inject
  ProviderReferenceNumberStrategy providerReferenceNumberStrategy;

  /**
   * Constructor for the class.
   */
  public MaintainProvider() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a localized text translation for the provider attribute, areas
   * served information.
   *
   * @param localizableTextTranslationDetails
   * The localized text translation details for areas served
   * information.
   *
   * @return The localized text translation details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public LocalizableTextTranslationDetails addAreasServedInfoTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    LocalizableTextTranslationDetails result = new LocalizableTextTranslationDetails();
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (StringHelper.isEmpty(localizableTextTranslationDetails.text)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LOCALIZABLETEXTExceptionCreator.ERR_TEXT_IS_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 4);
      ValidationHelper.failIfErrorsExist();
    }
    localizableTextHandler.setShortTextInd(true);
    localizableTextHandler.addValue(localizableTextTranslationDetails.text,
      LOCALEEntry.get(localizableTextTranslationDetails.localeCode));

    result.localizableTextID = localizableTextHandler.store();
    Provider provider = providerDAO.get(
      localizableTextTranslationDetails.localizableTextParentID);

    provider.setAreasServedInfoTextID(result.localizableTextID);
    provider.modify(localizableTextTranslationDetails.keyVersionDetails.version);
    return result;
  }

  /**
   * Creates a localized text translation for the provider attribute, client
   * information.
   *
   * @param localizableTextTranslationDetails
   * The localized text translation details for client information.
   *
   * @return The localized text translation details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public LocalizableTextTranslationDetails addClientInfoTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    LocalizableTextTranslationDetails result = new LocalizableTextTranslationDetails();
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (StringHelper.isEmpty(localizableTextTranslationDetails.text)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LOCALIZABLETEXTExceptionCreator.ERR_TEXT_IS_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 5);
      ValidationHelper.failIfErrorsExist();
    }
    localizableTextHandler.setShortTextInd(true);
    localizableTextHandler.addValue(localizableTextTranslationDetails.text,
      LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
    result.localizableTextID = localizableTextHandler.store();
    Provider provider = providerDAO.get(
      localizableTextTranslationDetails.localizableTextParentID);

    provider.setClientInfoTextID(result.localizableTextID);

    provider.modify(localizableTextTranslationDetails.keyVersionDetails.version);

    return result;
  }

  /**
   * Enrolls Provider with the specified Provider details. Sets the provider
   * enrollment date to current system date, if it is not already set. If the
   * provider is enrolled from the enquiry, then that enquiry will be closed.
   * Then a default compartment will be created for the provider. Also a status
   * history for this provider will be created. A notification will be sent to
   * the user regarding the provider enrollment.
   *
   * @param providerEnrollmentInfo
   * Contains the provider enrollment details.
   *
   * @return The key which contains the concern role ID and reference number of
   * the provider.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_PHYSICAL_CAPACITY_GREATER_THAN_LIMIT}
   * - If the physical capacity is greater than the maximum capacity.
   * @throws AppException
   * Generic Exception Signature.
   */
  public curam.cpm.facade.struct.ProviderEnrollmentReferenceKey enrollProviderDetails(
    ProviderEnrollmentInformation providerEnrollmentInfo)
    throws AppException, InformationalException {

    // BEGIN, CR00303260, SS
    ProviderEnrollmentReferenceKey providerEnrollmentReferenceKey = new ProviderEnrollmentReferenceKey();
    Provider provider = providerDAO.newInstance();
    ProviderCategoryPeriod providerCategoryPeriod = providerCategoryPeriodDAO.newInstance();
    ProviderType providerType = providerTypeDAO.newInstance();
    // END, CR00303260

    ProviderStatusHistory providerStatusHistory = providerStatusHistoryDAO.newInstance();

    if (providerEnrollmentInfo.providerEnrollmentDetails.enrollmentDate.equals(
      Date.kZeroDate)) {
      providerEnrollmentInfo.providerEnrollmentDetails.enrollmentDate = Date.getCurrentDate();

      // BEGIN, CR00200254, RPB
      // Current date time should be set as the enrollment date.
      provider.setDateTimeRange(
        new DateTimeRange(DateTime.getCurrentDateTime(), DateTime.kZeroDateTime));
      // END, CR00200254
    }

    UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    String alternateProdProvRefNo = providerReferenceNumberStrategy.generateReferenceNumber();

    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    concernRoleDtls.primaryAlternateID = alternateProdProvRefNo;
    setConcernRoleFields(providerEnrollmentInfo.providerEnrollmentDetails,
      concernRoleDtls);

    AddressDetails addressDetails = new AddressDetails();

    addressDetails.concernRoleAddressID = uniqueIDObj.getNextID();
    setAddressFields(providerEnrollmentInfo.providerEnrollmentDetails,
      addressDetails);

    ConcernRolePhoneDetails concernRolePhoneDetails = new ConcernRolePhoneDetails();

    setConcernRolePhoneFields(providerEnrollmentInfo.providerEnrollmentDetails,
      concernRolePhoneDetails);

    BankAccountDetails bankAccountDetails = new BankAccountDetails();

    setConcernRoleBankFields(providerEnrollmentInfo.providerEnrollmentDetails,
      bankAccountDetails);

    validateBankAccountDetails(providerEnrollmentInfo.providerEnrollmentDetails);

    provider.enroll(concernRoleDtls, addressDetails, concernRolePhoneDetails,
      bankAccountDetails);

    validateProviderPhysicalAndDesignatedCapacityDDetails(
      providerEnrollmentInfo.providerEnrollmentDetails);

    setProviderFields(providerEnrollmentInfo, provider);

    provider.insert();

    providerEnrollmentInfo.providerEnrollmentDetails.providerType = providerEnrollmentInfo.providerEnrollmentDetails.providerCategory;

    providerEnrollmentInfo.providerEnrollmentDetails.providerCategory = CodeTable.getParentCode(
      ProviderTypeNameEntry.TABLENAME,
      providerEnrollmentInfo.providerEnrollmentDetails.providerType);
    providerCategoryPeriod.setCategory(
      ProviderCategoryNameEntry.get(
        providerEnrollmentInfo.providerEnrollmentDetails.providerCategory));
    providerCategoryPeriod.setComments(CPMConstants.kEmptyString);
    providerCategoryPeriod.setPrimary(true);
    providerCategoryPeriod.setProvider(provider);

    final DateRange dateRange = new DateRange(
      providerEnrollmentInfo.providerEnrollmentDetails.enrollmentDate, null);

    providerCategoryPeriod.setDateRange(dateRange);

    providerCategoryPeriod.insert();

    providerType.setType(
      providerEnrollmentInfo.providerEnrollmentDetails.providerType);
    providerType.setProviderCategoryPeriod(providerCategoryPeriod);
    providerType.insert();

    if (0 != providerEnrollmentInfo.providerEnrollmentDetails.providerEnquiryID) {

      curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.get(
        providerEnrollmentInfo.providerEnrollmentDetails.providerEnquiryID);

      providerEnquiry.transferEnquiryToProvider(
        providerEnrollmentInfo.providerEnrollmentDetails.versionNo);
    }

    providerStatusHistory.setEffectiveDateTime(DateTime.getCurrentDateTime());
    String status = ProviderStatusEntry.OPEN.getCode();

    providerStatusHistory.setProviderRecordStatus(status.trim());
    providerStatusHistory.setUserName(TransactionInfo.getProgramUser());
    providerStatusHistory.setProvider(provider);

    providerStatusHistory.insert();

    providerEnrollmentReferenceKey.providerEnrollmentReferenceKey.concernRoleID = provider.getID();
    providerEnrollmentReferenceKey.providerEnrollmentReferenceKey.referenceNumber = alternateProdProvRefNo;

    // BEGIN, CR00380509, SS

    int physicalCapacity = providerEnrollmentInfo.providerEnrollmentDetails.physicalCapacity;

    if (0 != physicalCapacity && physicalCapacity > kPRPhysicalCapacity) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_PHYSICAL_CAPACITY_GREATER_THAN_LIMIT(
          kPRPhysicalCapacity),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }

    final Compartment providerCompartment = CompartmentFactory.newInstance();
    final CompartmentDtls dtls = new CompartmentDtls();

    dtls.providerConcernRoleID = providerEnrollmentReferenceKey.providerEnrollmentReferenceKey.concernRoleID;
    dtls.name = providerEnrollmentInfo.providerEnrollmentDetails.providerName;
    dtls.parentCompartmentID = 0;
    dtls.recordStatus = CompartmentStatus.ACTIVE;
    dtls.dateCreated = Date.getCurrentDate();

    final CompartmentKey compartmentKey = providerCompartment.createCompartment(
      dtls);

    createDesignatedPlaces(providerEnrollmentInfo.providerEnrollmentDetails,
      compartmentKey);
    // END, CR00380509

    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();

    ProviderNotificationKey providerNotificationKey = new ProviderNotificationKey();

    providerNotificationKey.concernRoleID = providerEnrollmentReferenceKey.providerEnrollmentReferenceKey.concernRoleID;
    providerNotificationKey.event = ProviderNotificationEvent.ENROLLMENT;

    providerNotification.sendNotification(providerNotificationKey);

    ValidationHelper.failIfErrorsExist();

    return providerEnrollmentReferenceKey;

  }

  /**
   * Retrieves the enroll provider wizard menu properties.
   *
   * @return Enroll provider wizard menu properties.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public WizardMenuDetails getProviderWizardMenuDetails() throws AppException,
      InformationalException {

    WizardMenuDetails wizardMenuDetails = new WizardMenuDetails();

    wizardMenuDetails.wizardMenu = CPMConstants.kEnrollProviderWizard;

    return wizardMenuDetails;
  }

  /**
   * Retrieves the register provider as person wizard menu properties.
   *
   * @return Register provider as person wizard menu properties.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public WizardMenuDetails getRegisterAsPersonWizardMenuDetails()
    throws AppException, InformationalException {

    WizardMenuDetails wizardMenuDetails = new WizardMenuDetails();

    wizardMenuDetails.wizardMenu = CPMConstants.kRegisterProviderAsPersonWizard;

    return wizardMenuDetails;
  }

  /**
   * Retrieves a list of providers for the resource manager supervisor.
   *
   * @return List of providers for the resource manager supervisor.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderSummaryVersionDetailsList listProviderForResourceManagerSupervisor()
    throws AppException, InformationalException {

    ProviderSummaryVersionDetailsList providerSummaryVersionDetailsList = new ProviderSummaryVersionDetailsList();

    List<String> supervisorList = new ArrayList<String>();

    final Set<curam.provider.impl.Provider> providers = providerDAO.searchProvidersByUserName(
      TransactionInfo.getProgramUser());

    for (final Provider provider : providers) {

      MaintainAdminConcernRole maintainAdminConcernRole = new MaintainAdminConcernRole();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = provider.getID();
      String owner = maintainAdminConcernRole.getProviderOrganisationOwner(concernRoleKey).userName;

      UserNameDetailsList userNameDetailsList = maintainAdminConcernRole.listProviderOrganisationSupervisor(
        concernRoleKey);

      for (final UserNameDetails userNameDetails : userNameDetailsList.detailsList.items()) {
        supervisorList.add(userNameDetails.userName);

      }

      if (owner.equals(TransactionInfo.getProgramUser())
        || supervisorList.contains(TransactionInfo.getProgramUser())) {
        providerSummaryVersionDetailsList.providerSummaryVersionDetails.addRef(
          getProviderFields(provider));
      }
    }

    return sortProviders(providerSummaryVersionDetailsList);
  }

  /**
   * Retrieves a list of providers for the resource manager.
   *
   * @return List of providers for the resource manager.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderSummaryVersionDetailsList listProvidersForResourceManager()
    throws AppException, InformationalException {

    ProviderSummaryVersionDetailsList providerSummaryVersionDetailsList = new ProviderSummaryVersionDetailsList();

    final Set<Provider> providers = providerDAO.searchProvidersByUserName(
      TransactionInfo.getProgramUser());

    for (final Provider provider : providers) {

      MaintainAdminConcernRole maintainAdminConcernRole = new MaintainAdminConcernRole();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = provider.getID();

      String owner = maintainAdminConcernRole.getProviderOrganisationOwner(concernRoleKey).userName;

      if (owner.equals(TransactionInfo.getProgramUser())) {

        providerSummaryVersionDetailsList.providerSummaryVersionDetails.addRef(
          getProviderFields(provider));
      }
    }

    return sortProviders(providerSummaryVersionDetailsList);
  }

  /**
   * Modifies the Provider details. Modifies the root compartment name if the
   * provider name has been modified. Places will be created in the root level
   * compartment based on the value of physical and designated capacity.
   *
   * @param providerEnrollmentInformation
   * Contains Provider details to be modified.
   *
   * @return The key contains the concern role ID of the Provider.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_PHYSICAL_CAPACITY_GREATER_THAN_LIMIT}
   * - If the physical capacity is greater than the maximum capacity.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderConcernRoleKey modifyProviderDetails(
    ProviderEnrollmentInformation providerEnrollmentInformation)
    throws AppException, InformationalException {

    ProviderConcernRoleKey providerKey = new ProviderConcernRoleKey();

    providerKey.providerKey.providerConcernRoleID = providerEnrollmentInformation.providerEnrollmentDetails.concernRoleID;

    // BEGIN, CR00303260, SS
    Provider provider = providerDAO.get(
      providerEnrollmentInformation.providerEnrollmentDetails.concernRoleID);
    // END, CR00303260
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = providerEnrollmentInformation.providerEnrollmentDetails.concernRoleID;

    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    boolean physicalCapacityStored = provider.getPhysicalCapacity() == 0
      ? false
      : true;

    validateConcernRoleDetails(
      providerEnrollmentInformation.providerEnrollmentDetails);

    Compartment compartmentView = CompartmentFactory.newInstance();

    ViewCompartmentKey viewCompartmentKey = new ViewCompartmentKey();

    viewCompartmentKey.providerConcernRoleID = providerKey.providerKey.providerConcernRoleID;

    CompartmentDetails compartmentDetails = compartmentView.viewCompartment(
      viewCompartmentKey);

    if (compartmentDetails.designatedCapacity > 0
      && providerEnrollmentInformation.providerEnrollmentDetails.designatedCapacityString.length()
        == kMinimumCapacity) {
      providerEnrollmentInformation.providerEnrollmentDetails.designatedCapacity = compartmentDetails.designatedCapacity;
      providerEnrollmentInformation.providerEnrollmentDetails.designatedCapacityString = String.valueOf(
        compartmentDetails.designatedCapacity);
    }

    validateProviderPhysicalAndDesignatedCapacityDDetails(
      providerEnrollmentInformation.providerEnrollmentDetails);

    setProviderFields(providerEnrollmentInformation, provider);

    // Physical capacity should be less than 1000.
    int physicalCapacity = providerEnrollmentInformation.providerEnrollmentDetails.physicalCapacity;

    if (0 != physicalCapacity && physicalCapacity > kPRPhysicalCapacity) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_PHYSICAL_CAPACITY_GREATER_THAN_LIMIT(
          kPRPhysicalCapacity),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          3);
    }

    concernRoleDtls.preferredLanguage = providerEnrollmentInformation.providerEnrollmentDetails.prefLanguage;
    concernRoleDtls.prefCommMethod = providerEnrollmentInformation.providerEnrollmentDetails.prefCommMethod;
    concernRoleDtls.comments = providerEnrollmentInformation.providerEnrollmentDetails.comments;
    concernRoleDtls.concernRoleName = providerEnrollmentInformation.providerEnrollmentDetails.providerName;

    // BEGIN, CR00274149, GP
    validateConcernRoleDetails(
      providerEnrollmentInformation.providerEnrollmentDetails);
    concernRoleObj.modify(concernRoleKey, concernRoleDtls);

    provider.modify(
      providerEnrollmentInformation.providerEnrollmentDetails.versionNo);
    // END, CR00274149

    Set<curam.place.impl.Compartment> unModifiableProviderCompartments = provider.getCompartments();
    Set<curam.place.impl.Compartment> providerCompartments = new HashSet<curam.place.impl.Compartment>();

    providerCompartments.addAll(unModifiableProviderCompartments);

    for (curam.place.impl.Compartment compartment : providerCompartments) {

      if (compartment.getParentCompartment() == null) {
        int compartmentVersionNo = 0;

        compartment.setName(
          providerEnrollmentInformation.providerEnrollmentDetails.providerName);
        compartmentVersionNo = compartment.getVersionNo();
        compartment.modify(compartmentVersionNo);
      }
    }

    if (!physicalCapacityStored) {

      long compartmentID = 0;

      // Get the root compartment for provider
      for (curam.place.impl.Compartment compartment : providerCompartments) {
        if (compartment.getParentCompartment() == null) {
          compartmentID = compartment.getID();
          break;
        }
      }

      CompartmentKey compartmentKey = new CompartmentKey();

      compartmentKey.compartmentID = compartmentID;

      // Create the places in the root level compartment.
      createDesignatedPlaces(
        providerEnrollmentInformation.providerEnrollmentDetails, compartmentKey);
    }

    return providerKey;
  }

  /**
   * Previews a pro forma communication.
   *
   * @param previewProFormaKey
   * Communication ID of the notification.
   *
   * @return Provider notification document details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderNotificationReturnDocDetails previewProForma(
    final PreviewProFormaKey previewProFormaKey) throws AppException,
      InformationalException {

    ConcernRoleCommunication concernRoleCommunicationObj = ConcernRoleCommunicationFactory.newInstance();
    ConcernRoleCommunicationKey concernRoleCommunicationKey = new ConcernRoleCommunicationKey();
    ConcernRoleCommunicationDtls concernRoleCommunicationDtls;

    concernRoleCommunicationKey.communicationID = previewProFormaKey.communicationID;

    concernRoleCommunicationDtls = concernRoleCommunicationObj.read(
      concernRoleCommunicationKey);

    ProviderNotification providerNotification = ProviderNotificationFactory.newInstance();

    CommunicationDetails communicationDetails = new CommunicationDetails();

    communicationDetails.concernRoleID = concernRoleCommunicationDtls.correspondentConcernRoleID;
    communicationDetails.event = getEventCode(concernRoleCommunicationDtls);
    communicationDetails.communicationID = previewProFormaKey.communicationID;
    communicationDetails.date = concernRoleCommunicationDtls.communicationDate;

    // BEGIN, CR00291621, MR
    ProviderNotificationReturnDocDetails providerNotificationReturnDocDetails = new ProviderNotificationReturnDocDetails();

    if (COMMUNICATIONFORMATEntry.PROFORMA.getCode().equals(
      concernRoleCommunicationDtls.communicationFormat)) {

      // If it is a automatically generated communication.
      if (!StringUtil.isNullOrEmpty(communicationDetails.event)) {

        // BEGIN, CR00292749, MR
        if (COMMUNICATIONSTATUS.SENT.equals(
          concernRoleCommunicationDtls.communicationStatus)
            && cmisAccessInterface.isCMISEnabledFor(
              CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)
              && cmisAccessInterface.contentExists(
                previewProFormaKey.communicationID,
                CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {
          final FileNameAndDataDtls fileNameAndDataDtls = cmisAccessInterface.read(
            previewProFormaKey.communicationID,
            CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION);

          providerNotificationReturnDocDetails.fileName = fileNameAndDataDtls.fileName;
          providerNotificationReturnDocDetails.fileData = fileNameAndDataDtls.fileContent;
        } else {
          providerNotificationReturnDocDetails = providerNotification.previewProForma(
            communicationDetails);
        }
        // END, CR00292749

      } else {

        // If it is a manually created communication then call core API.

        // BEGIN, CR00292749, MR
        final Communication communicationObj = CommunicationFactory.newInstance();

        providerNotificationReturnDocDetails.fileData = communicationObj.previewProForma(previewProFormaKey).fileDate;
        providerNotificationReturnDocDetails.fileName = communicationObj.previewProForma(previewProFormaKey).fileName;

        // END, CR00292749
      }
    } else if (COMMUNICATIONFORMATEntry.MSWORD.getCode().equals(
      concernRoleCommunicationDtls.communicationFormat)) {
      final CommunicationAttachmentLinkReadmultiKey communicationAttachmentLinkReadmultiKey = new CommunicationAttachmentLinkReadmultiKey();

      communicationAttachmentLinkReadmultiKey.communicationID = previewProFormaKey.communicationID;

      final ReadAttachmentKey readAttachmentKey = new ReadAttachmentKey();

      readAttachmentKey.readAttachmentIn.attachmentID = CommAttachmentLinkFactory.newInstance().searchByCommunication(communicationAttachmentLinkReadmultiKey).dtls.item(0).attachmentID;
      final ReadCommunicationAttachmentDetails readCommunicationAttachmentDetails = ParticipantFactory.newInstance().readCommunicationAttachment(
        readAttachmentKey);

      providerNotificationReturnDocDetails.fileData = readCommunicationAttachmentDetails.readCommunicationAttachmentDtls.attachmentContents;
      providerNotificationReturnDocDetails.fileName = readCommunicationAttachmentDetails.readCommunicationAttachmentDtls.attachmentName;
    }

    // END, CR00291621
    return providerNotificationReturnDocDetails;
  }

  // BEGIN, CR00281847, SS
  /**
   * Searches for provider and provider group based on the reference number.
   *
   * @param referenceNumber
   * Reference number of the Provider.
   *
   * @return Provider or provider group details which match the given reference
   * number.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOAPPLICATIONSEARCH#ERR_BPOAPPLICATIONSEARCH_XRV_NO_MATCH}
   * - If invalid reference number is specified.
   */
  public SearchProviderOrganizationDetails searchProviderOrganizationReferenceNumber(
    SearchByReferenceNumber referenceNumber) throws AppException,
      InformationalException {

    SearchProviderOrganizationDetails searchProviderOrganisationDetails = new SearchProviderOrganizationDetails();
    final String referenceNumberKey = referenceNumber.referenceNumber.trim();
    MaintainProvider maintainProviderObj = new MaintainProvider();
    ProviderSearchCriteriaKey providerKey = new ProviderSearchCriteriaKey();

    providerKey.referenceNumber = referenceNumberKey;

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    ProviderSummaryVersionDetailsList providerSummaryVersionDetailsList = maintainProviderObj.searchProviders1(
      providerKey);

    curam.cpm.facade.intf.ProviderGroup providerGroupObj = ProviderGroupFactory.newInstance();
    SearchProviderGroupKey key = new SearchProviderGroupKey();

    key.referenceNumber = referenceNumberKey;
    ProviderGroupSummaryDetailsList providerGroupSummaryDetailsList = providerGroupObj.searchAllProviderGroup(
      key);

    if (!providerSummaryVersionDetailsList.providerSummaryVersionDetails.isEmpty()) {
      // As provider reference number is unique, there can be only one provider
      // matching the reference number.
      ProviderSummaryVersionDetails providerSummaryVersionDetails = providerSummaryVersionDetailsList.providerSummaryVersionDetails.get(
        0);

      searchProviderOrganisationDetails.providerDtls.assign(
        providerSummaryVersionDetails);
      searchProviderOrganisationDetails.concernRoleType = CONCERNROLETYPEEntry.PROVIDER.getCode();

      return searchProviderOrganisationDetails;
    } else if (!providerGroupSummaryDetailsList.details.isEmpty()) {
      // As provider group reference number is unique, there can be only one
      // provider group matching the reference number.
      ProviderGroupSummaryDetails providerGroupSummaryDetails = providerGroupSummaryDetailsList.details.get(
        0);

      searchProviderOrganisationDetails.providerGroupDtls.assign(
        providerGroupSummaryDetails);

      searchProviderOrganisationDetails.concernRoleType = CONCERNROLETYPEEntry.PROVIDERGROUP.getCode();

      return searchProviderOrganisationDetails;
    } else {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          BPOAPPLICATIONSEARCH.ERR_BPOAPPLICATIONSEARCH_XRV_NO_MATCH),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
      String warnings[] = informationalManager.obtainInformationalAsString();

      for (final String warning : warnings) {
        InformationalMsgDtls infoMessage = new InformationalMsgDtls();

        infoMessage.informationMsgTxt = warning;
        searchProviderOrganisationDetails.dtls.dtls.add(infoMessage);
      }

      return searchProviderOrganisationDetails;
    }
  }

  // END, CR00281847

  // BEGIN, CR00246409, SS
  /**
   * @param providerSearchKey
   * Contains search criteria.
   *
   * @return Search results which match the entered search criteria.
   *
   * @throws InformationalException
   * {@link PROVIDER# ERR_PROVIDER_FV_REFERENCE_NO_IS_SPECIFIED_OTHER_SEARCH_CRITERIA_IS_SPECIFIED}
   * - If the search criteria is not specified.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link MaintainProvider#searchProviders1(ProviderSearchCriteriaKey)}
   * . This method is deprecated as the type of owner name of the
   * search criteria details is modified to reflect the search icon
   * in the client page.
   *
   * Searches for all the Providers based on search criteria.
   */
  @Deprecated
  // END, CR00246409
  public ProviderSummaryVersionDetailsList searchProviders(
    final ProviderSearchKey providerSearchKey) throws AppException,
      InformationalException {

    ProviderSummaryVersionDetailsList providerSummaryVersionDetailsList = new ProviderSummaryVersionDetailsList();

    String providerName = providerSearchKey.name.trim();
    String providerType = providerSearchKey.providerCategoryType.trim();
    String referenceNumber = providerSearchKey.referenceNumber.trim();
    String ownerName = providerSearchKey.ownerName.trim();

    // Check if any of the search criteria is entered.
    if (CPMConstants.kEmptyString.equalsIgnoreCase(referenceNumber)
      && CPMConstants.kEmptyString.equalsIgnoreCase(providerName)
      && CPMConstants.kEmptyString.equalsIgnoreCase(providerType)
      && CPMConstants.kEmptyString.equalsIgnoreCase(ownerName)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_SOME_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);

      // Check if reference number is entered then
      // no other criteria should be entered.
    } else if ((!CPMConstants.kEmptyString.equalsIgnoreCase(referenceNumber))
      && ((!CPMConstants.kEmptyString.equalsIgnoreCase(providerName))
        || (!CPMConstants.kEmptyString.equalsIgnoreCase(providerType))
        || (!CPMConstants.kEmptyString.equalsIgnoreCase(ownerName)))) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_REFERENCE_NO_IS_SPECIFIED_OTHER_SEARCH_CRITERIA_IS_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
    }

    ValidationHelper.failIfErrorsExist();

    ProviderSearchDetailsList providerSearchDetailsList = providerDAO.searchProvider(
      providerSearchKey.name, providerSearchKey.referenceNumber,
      providerSearchKey.providerCategoryType, providerSearchKey.ownerName);

    ProviderSummaryVersionDetails providerSummaryVersionDetails;

    for (final ProviderSearchDetails providerSearchDetails : providerSearchDetailsList.dtls.items()) {

      providerSummaryVersionDetails = new ProviderSummaryVersionDetails();

      curam.provider.impl.Provider provider = providerDAO.get(
        providerSearchDetails.providerConcernRoleID);

      providerSummaryVersionDetails.owner = providerSearchDetails.owner;

      User user = userDAO.get(providerSearchDetails.owner);

      providerSummaryVersionDetails.ownerFullName = user.getFullName();

      providerSummaryVersionDetails.name = provider.getName();
      providerSummaryVersionDetails.referenceNumber = provider.getPrimaryAlternateID();
      providerSummaryVersionDetails.concernRoleID = provider.getID();
      providerSummaryVersionDetails.primaryCategory = provider.getPrimaryProviderCategoryPeriod().getCategory().getCode();
      providerSummaryVersionDetails.recordStatus = provider.getLifecycleState().getCode();

      providerSummaryVersionDetailsList.providerSummaryVersionDetails.addRef(
        providerSummaryVersionDetails);
    }

    return sortProviders(providerSummaryVersionDetailsList);
  }

  // BEGIN, CR00246409, SS
  /**
   * This method replaces the deprecated method
   * {@link MaintainProvider#searchProviders(ProviderSearchKey)} as the type of
   * owner name of the search criteria details in the deprecated method is
   * modified to reflect the search icon in the client page.
   *
   * Searches for all the Providers based on search criteria.
   *
   * @param key
   * Contains search criteria.
   *
   * @return Search results which match the entered search criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link PROVIDER# ERR_PROVIDER_FV_REFERENCE_NO_IS_SPECIFIED_OTHER_SEARCH_CRITERIA_IS_SPECIFIED}
   * - If the search criteria is not specified.
   */
  public ProviderSummaryVersionDetailsList searchProviders1(
    ProviderSearchCriteriaKey key) throws AppException,
      InformationalException {
    ProviderSummaryVersionDetailsList providerSummaryVersionDetailsList = new ProviderSummaryVersionDetailsList();

    String providerName = key.name.trim();
    String providerType = key.providerCategoryType.trim();
    String referenceNumber = key.referenceNumber.trim();
    String ownerName = key.ownerName.trim();

    // Check if any of the search criteria is entered.
    if (CPMConstants.kEmptyString.equalsIgnoreCase(referenceNumber)
      && CPMConstants.kEmptyString.equalsIgnoreCase(providerName)
      && CPMConstants.kEmptyString.equalsIgnoreCase(providerType)
      && CPMConstants.kEmptyString.equalsIgnoreCase(ownerName)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_SOME_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);

      // Check if reference number is entered then
      // no other criteria should be entered.
    } else if ((!CPMConstants.kEmptyString.equalsIgnoreCase(referenceNumber))
      && ((!CPMConstants.kEmptyString.equalsIgnoreCase(providerName))
        || (!CPMConstants.kEmptyString.equalsIgnoreCase(providerType))
        || (!CPMConstants.kEmptyString.equalsIgnoreCase(ownerName)))) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_REFERENCE_NO_IS_SPECIFIED_OTHER_SEARCH_CRITERIA_IS_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }

    ValidationHelper.failIfErrorsExist();

    ProviderSearchDetailsList providerSearchDetailsList = providerDAO.searchProvider(
      key.name, key.referenceNumber, key.providerCategoryType, key.ownerName);

    ProviderSummaryVersionDetails providerSummaryVersionDetails;

    for (final ProviderSearchDetails providerSearchDetails : providerSearchDetailsList.dtls.items()) {

      providerSummaryVersionDetails = new ProviderSummaryVersionDetails();

      // BEGIN, CR00303260, SS
      Provider provider = providerDAO.get(
        providerSearchDetails.providerConcernRoleID);

      // END, CR00303260

      providerSummaryVersionDetails.owner = providerSearchDetails.owner;

      User user = userDAO.get(providerSearchDetails.owner);

      providerSummaryVersionDetails.ownerFullName = user.getFullName();

      providerSummaryVersionDetails.name = provider.getName();
      providerSummaryVersionDetails.referenceNumber = provider.getPrimaryAlternateID();
      providerSummaryVersionDetails.concernRoleID = provider.getID();
      providerSummaryVersionDetails.primaryCategory = provider.getPrimaryProviderCategoryPeriod().getCategory().getCode();
      providerSummaryVersionDetails.recordStatus = provider.getLifecycleState().getCode();

      // BEGIN, CR00282506, MR
      providerSummaryVersionDetails.nameReferenceNumberOpt = provider.getName()
        + CuramConst.kSeparator + provider.getPrimaryAlternateID();
      // END, CR00282506
      providerSummaryVersionDetailsList.providerSummaryVersionDetails.addRef(
        providerSummaryVersionDetails);
    }

    // BEGIN, CR00292696, IBM
    collectInformationalMsgs(
      providerSummaryVersionDetailsList.informationalMsgDtlsOpt);
    // END, CR00292696

    return sortProviders(providerSummaryVersionDetailsList);
  }

  /**
   * Reads the Provider details. The value of designated capacity will be read
   * from the compartment details. Also it reads the provider enquiry details if
   * the provider is enrolled from an enquiry.
   *
   * @param providerKey
   * The provider concern role ID.
   *
   * @return The enrolled provider details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderEnrollmentInformation viewProviderDetails(
    curam.cpm.facade.struct.ProviderConcernRoleKey providerKey)
    throws AppException, InformationalException {

    ProviderEnrollmentInformation providerEnrollmentInformation = new ProviderEnrollmentInformation();

    ProviderEnrollmentDetails providerEnrollmentDetails = new ProviderEnrollmentDetails();

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerKey.providerConcernRoleID);

    ProviderDtls providerDtls = new ProviderDtls();

    DeliveryMethod deliveryMethod = DeliveryMethodFactory.newInstance();
    DeliveryMethodKey deliveryMethodKey = new DeliveryMethodKey();

    deliveryMethodKey.deliveryMethodID = provider.getMethodOfPayment();
    DeliveryMethodDtls deliveryMethodDtls = deliveryMethod.read(
      deliveryMethodKey);

    providerDtls.methodOfPayment = provider.getMethodOfPayment();
    providerDtls.currencyType = provider.getCurrencyType().getCode();
    providerDtls.paymentFrequency = provider.getPaymentFrequency();
    providerDtls.physicalCapacity = provider.getPhysicalCapacity();
    providerDtls.providerConcernRoleID = provider.getID();
    providerDtls.versionNo = provider.getVersionNo();
    providerDtls.recordStatus = provider.getLifecycleState().getCode();
    providerDtls.acceptCWReferral = provider.getAcceptsCWReferral();

    providerEnrollmentDetails.assign(providerDtls);

    providerEnrollmentDetails.paymentFrequencyString = provider.getPaymentFrequency();

    providerEnrollmentDetails.methodOfPaymentString = CodeTable.getOneItemForUserLocale(
      METHODOFDELIVERYEntry.TABLENAME, deliveryMethodDtls.name);

    providerEnrollmentDetails.versionNo = providerDtls.versionNo;

    if (providerDtls.physicalCapacity > kMinimumCapacity) {
      providerEnrollmentDetails.physicalCapacityString = CPMConstants.kEmptyString
        + providerDtls.physicalCapacity;
    }

    if (providerEnrollmentDetails.designatedCapacity > kMinimumCapacity) {
      providerEnrollmentDetails.designatedCapacityString = CPMConstants.kEmptyString
        + providerEnrollmentDetails.designatedCapacity;
    }

    providerEnrollmentDetails.prefLanguage = provider.getPreferredLanguage().getCode();
    providerEnrollmentDetails.prefCommMethod = provider.getPreferredCommunicationMethod().getCode();
    providerEnrollmentDetails.comments = provider.getComments();
    providerEnrollmentDetails.providerName = provider.getName();

    providerEnrollmentDetails.enrollmentDate = provider.getRegistrationDate();
    providerEnrollmentDetails.endDate = provider.getEndDate();

    providerEnrollmentDetails.concernRoleID = provider.getID();
    providerEnrollmentDetails.pageContextDescription = provider.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + provider.getPrimaryAlternateID();
    providerEnrollmentDetails.referenceNumber = provider.getPrimaryAlternateID();
    Compartment compartment = CompartmentFactory.newInstance();

    ViewCompartmentKey viewCompartmentKey = new ViewCompartmentKey();

    viewCompartmentKey.providerConcernRoleID = providerKey.providerKey.providerConcernRoleID;

    // Getting the compartment details for the provider.
    CompartmentDetails compartmentDetails = compartment.viewCompartment(
      viewCompartmentKey);

    // Setting the value of designated capacity from the compartment details.
    providerEnrollmentDetails.designatedCapacity = compartmentDetails.designatedCapacity;

    if (compartmentDetails.designatedCapacity > kMinimumCapacity) {
      providerEnrollmentDetails.designatedCapacityString = CPMConstants.kEmptyString
        + compartmentDetails.designatedCapacity;
      providerEnrollmentDetails.modifyDesignatedCapacity = false;
    } else {
      providerEnrollmentDetails.modifyDesignatedCapacity = true;
    }

    // Get the primary provider category.
    final ProviderCategoryPeriod providerCategoryPeriod = provider.getPrimaryProviderCategoryPeriod();

    providerEnrollmentDetails.category = ProviderCategoryNameEntry.get(providerCategoryPeriod.getCategory().getCode()).getCode();

    providerEnrollmentDetails.providerCategoryVersion = providerCategoryPeriod.getVersionNo();

    // BEGIN, CR00303260, SS
    // Get provider types for this category
    Set<ProviderType> unModifiableProviderTypes = providerCategoryPeriod.getProviderTypes();
    Set<ProviderType> providerTypes = new HashSet<ProviderType>();

    providerTypes.addAll(unModifiableProviderTypes);

    for (final ProviderType providerType : providerTypes) {
      // END, CR00303260
      if (providerEnrollmentDetails.providerType.equals(GeneralConstants.kEmpty)) {

        providerEnrollmentDetails.providerType += CodeTable.getOneItem(
          ProviderTypeNameEntry.TABLENAME, providerType.getType());

      } else {

        providerEnrollmentDetails.providerType += GeneralConstants.kComma
          + CuramConst.gkTabDelimiter
          + CodeTable.getOneItem(ProviderTypeNameEntry.TABLENAME,
          providerType.getType());

      }
      providerEnrollmentDetails.typeVersion = providerType.getVersionNo();

    }

    Address addressObj = AddressFactory.newInstance();
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = provider.getPrimaryAddressID();

    AddressDtls addressDtls = addressObj.read(addressKey);

    OtherAddressData formattedAddressData = new OtherAddressData();

    formattedAddressData.addressData = addressDtls.addressData;
    addressObj.getAddressStrings(formattedAddressData);

    providerEnrollmentDetails.formattedAddressData = formattedAddressData.addressData;
    providerEnrollmentDetails.addressData = addressDtls.addressData;

    final PhoneNumber phoneNumber = provider.getPrimaryPhoneNumber();

    if (null != phoneNumber) {

      ConcernRolePhoneNumber concernRolePhoneNumberObj = ConcernRolePhoneNumberFactory.newInstance();
      PhoneForConcernRoleKey phoneForConcernRoleKey = new PhoneForConcernRoleKey();

      phoneForConcernRoleKey.concernRoleID = provider.getID();
      phoneForConcernRoleKey.phoneNumberID = phoneNumber.getID();

      ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls = concernRolePhoneNumberObj.readPhoneForConcernRole(
        phoneForConcernRoleKey);

      providerEnrollmentDetails.phoneNumber = phoneNumber.getNumber();
      providerEnrollmentDetails.phoneAreaCode = phoneNumber.getAreaCode();
      providerEnrollmentDetails.phoneCountryCode = phoneNumber.getCountryCode();
      providerEnrollmentDetails.phoneExtension = phoneNumber.getExtension();
      providerEnrollmentDetails.phoneType = concernRolePhoneNumberDtls.typeCode;
    }

    curam.provider.impl.ProviderEnquiry providerEnquiry = provider.getProviderEnquiry();

    if (null != providerEnquiry) {
      providerEnrollmentDetails.relatedEnquiryExist = true;
      providerEnrollmentDetails.providerEnquiryID = providerEnquiry.getID();
    }

    if (provider.getReservationGracePeriod() > CPMConstants.kZeroLong) {
      providerEnrollmentDetails.reservationGracePeriodString = CPMConstants.kEmptyString
        + provider.getReservationGracePeriod();
    }
    providerEnrollmentDetails.reservationGracePeriod = provider.getReservationGracePeriod();

    providerEnrollmentDetails.overrideMDRInd = provider.isOverrideMDR();

    providerEnrollmentInformation.preferredServiceEnquiryMethod = provider.getPreferredServiceEnquiryMethod().getCode();
    getClientInformation(provider, providerEnrollmentInformation);
    providerEnrollmentInformation.providerEnrollmentDetails.assign(
      providerEnrollmentDetails);

    curam.cpm.facade.intf.Provider providerObj = ProviderFactory.newInstance();
    ProviderKey providerConcernRoleKey = new ProviderKey();

    providerConcernRoleKey.providerConcernRoleID = providerKey.providerKey.providerConcernRoleID;
    InformationalMessageList informationalMessageList = providerObj.getProviderInformationals(
      providerConcernRoleKey);

    if (informationalMessageList.dtls.size() > 0) {
      providerEnrollmentInformation.userSkillsInd = true;
    }

    // BEGIN, CR00234497, PS
    if (ProviderStatusEntry.OPEN.equals(provider.getLifecycleState())) {

      providerEnrollmentInformation.openStatusInd = true;
      providerEnrollmentInformation.editIndicator = true;
      providerEnrollmentInformation.approveIndicator = true;
      providerEnrollmentInformation.closeIndicator = true;
      providerEnrollmentInformation.registerPersonIndicator = true;

    } else if (ProviderStatusEntry.APPROVED.equals(provider.getLifecycleState())) {

      providerEnrollmentInformation.approvedStatusInd = true;
      providerEnrollmentInformation.registerPersonIndicator = true;
      providerEnrollmentInformation.editIndicator = true;
      providerEnrollmentInformation.closeIndicator = true;

    } else if (ProviderStatusEntry.CLOSED.equals(provider.getLifecycleState())) {

      providerEnrollmentInformation.closedStatusInd = true;

    } else if (ProviderStatusEntry.SUSPENDED.equals(
      provider.getLifecycleState())) {

      providerEnrollmentInformation.suspendedStatusInd = true;
      providerEnrollmentInformation.approveIndicator = true;
      providerEnrollmentInformation.closeIndicator = true;

    } else if (ProviderStatusEntry.REJECTED.equals(provider.getLifecycleState())) {

      providerEnrollmentInformation.rejectedStatusInd = true;
      providerEnrollmentInformation.approveIndicator = true;
      providerEnrollmentInformation.closeIndicator = true;
    }
    // END, CR00234497

    MaintainAttendanceConfiguration maintainAttendanceConfiguration = MaintainAttendanceConfigurationFactory.newInstance();
    curam.cpm.sl.entity.struct.ProviderConcernRoleKey concernRoleKey = new curam.cpm.sl.entity.struct.ProviderConcernRoleKey();

    concernRoleKey.providerConcernRoleID = providerKey.providerKey.providerConcernRoleID;
    ProviderAttendanceTrackingDetails providerAttendanceTrackingDetails = maintainAttendanceConfiguration.viewProviderAttendanceTracking(
      concernRoleKey);

    // BEGIN, CR00273521, MR
    final String userName = TransactionInfo.getProgramUser();

    if (providerAttendanceTrackingDetails.dtlsList.paperRosterRequiredind) {

      if (CPMConstants.kFacilityManagerUserName.equals(userName)) {
        providerEnrollmentInformation.paperRosterActionURL = CPMConstants.kUpdateProviderAttendanceTrackingPageForFM;
      } else {
        providerEnrollmentInformation.paperRosterActionURL = CPMConstants.kUpdateProviderAttendanceTrackingPage;
      }
    } else {
      if (CPMConstants.kFacilityManagerUserName.equals(userName)) {
        providerEnrollmentInformation.paperRosterActionURL = CPMConstants.kModifyProviderAttendanceTrackingPageForFM;
      } else {
        providerEnrollmentInformation.paperRosterActionURL = CPMConstants.kModifyProviderAttendanceTrackingPage;
      }
    }
    // END, CR00273521

    return providerEnrollmentInformation;

  }

  // END, CR00224728
  // BEGIN, CR00224728, JMA

  /**
   * Reads the status history of provider life cycle.
   *
   * @param providerConcernRoleKey
   * Provider for which status history has to be retrieved.
   *
   * @return Provider status history details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderStatusHistoryUserDetailsList viewProviderStatusHistory(
    final curam.cpm.sl.entity.struct.ProviderConcernRoleKey providerConcernRoleKey)
    throws AppException, InformationalException {

    ProviderStatusHistoryUserDetailsList providerStatusHistoryUserDetailsList = new ProviderStatusHistoryUserDetailsList();

    // BEGIN, CR00303260, SS
    final Provider provider = providerDAO.get(
      providerConcernRoleKey.providerConcernRoleID);
    final Set<ProviderStatusHistory> providerStatusHistories = providerStatusHistoryDAO.searchByProvider(
      provider);
    // END, CR00303260
    List<ProviderStatusHistoryDetails> providerStatusHistoryDetailsList = new ArrayList<ProviderStatusHistoryDetails>();

    for (final ProviderStatusHistory providerStatusHistory : providerStatusHistories) {

      ProviderStatusHistoryDetails providerStatusHistoryDetails = new ProviderStatusHistoryDetails();

      providerStatusHistoryDetails.providerStatusHistoryDetails.effectiveDateTime = providerStatusHistory.getEffectiveDateTime();
      providerStatusHistoryDetails.providerStatusHistoryDetails.providerConcernRoleID = providerStatusHistory.getProvider().getID();
      providerStatusHistoryDetails.providerStatusHistoryDetails.providerStatusHistoryID = providerStatusHistory.getID();
      providerStatusHistoryDetails.providerStatusHistoryDetails.reason = providerStatusHistory.getReason();
      providerStatusHistoryDetails.providerStatusHistoryDetails.recordStatus = providerStatusHistory.getProviderRecordStatus();
      providerStatusHistoryDetails.providerStatusHistoryDetails.userName = providerStatusHistory.getUserName();

      User user = userDAO.get(providerStatusHistory.getUserName());

      providerStatusHistoryDetails.userFullName = user.getFullName();

      providerStatusHistoryDetailsList.add(providerStatusHistoryDetails);
    }

    for (final ProviderStatusHistoryDetails statusHistoryDetails : sortProviderStatusHistoryByDateTime(
      providerStatusHistoryDetailsList)) {

      providerStatusHistoryUserDetailsList.providerStatusHistoryDetailsList.addRef(
        statusHistoryDetails);
    }

    return providerStatusHistoryUserDetailsList;
  }

  /**
   * Reads the provider tab details.
   *
   * @param providerKey
   * Provider for which tab details are to be read.
   *
   * @return Provider tab details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderTabDetails viewProviderTabDetails(final ProviderKey providerKey)
    throws AppException, InformationalException {

    ProviderTabDetails providerTabDetails = new ProviderTabDetails();

    Provider provider = providerDAO.get(providerKey.providerConcernRoleID);

    ProviderConcernRoleKey providerConcernRoleKey = new ProviderConcernRoleKey();

    providerConcernRoleKey.providerKey.providerConcernRoleID = providerKey.providerConcernRoleID;
    ProviderEnrollmentInformation providerEnrollmentInformation = viewProviderDetails(
      providerConcernRoleKey);

    providerTabDetails.providerName = provider.getName();

    List<ProviderIncident> incidents = provider.getIncidents();
    int numberOfOpenIncidents = 0;

    for (ProviderIncident providerIncident : incidents) {
      if (INCIDENTSTATUSEntry.OPEN.equals(providerIncident.getLifecycleState())) {
        numberOfOpenIncidents += 1;
      }
    }

    ProviderInvestigation providerInvestigationObj = ProviderInvestigationFactory.newInstance();
    curam.cpm.sl.entity.struct.ProviderConcernRoleKey concernRoleKey = new curam.cpm.sl.entity.struct.ProviderConcernRoleKey();

    concernRoleKey.providerConcernRoleID = providerKey.providerConcernRoleID;
    // BEGIN, CR00291801, ASN
    InvestigationDeliveryListForProvider providerInvestigationDeliveryList = providerInvestigationObj.listInvestigationsForProvider(
      concernRoleKey);

    int numberOfOpenInvestigations = 0;

    for (final ProviderInvestigationDetails providerInvestigationDetails : providerInvestigationDeliveryList.providerInvestigationDetails.items()) {

      if (!RESOLUTIONSTATUSCODEEntry.CANCELED.getCode().equals(
        providerInvestigationDetails.resolutionStatus)
          && !CASESTATUSEntry.CLOSED.getCode().equals(
            providerInvestigationDetails.statusCode)) {
        // END, CR00291801

        numberOfOpenInvestigations += 1;
      }
    }

    Set<ProviderGroupAssociate> providerGroupAssociates = providerGroupAssociateDAO.searchProviderGroupsForProvider(
      provider);
    ProviderGroup providerGroup = null;

    for (ProviderGroupAssociate providerGroupAssociate : providerGroupAssociates) {

      if (RECORDSTATUSEntry.NORMAL.equals(
        providerGroupAssociate.getLifecycleState())
          && providerGroupAssociate.getDateRange().contains(
            Date.getCurrentDate())) {

        providerGroup = providerGroupAssociate.getProviderGroup();
      }
    }

    ContentPanelBuilder containerPanel = ContentPanelBuilder.createPanel(
      CPMConstants.gkProviderContainer);

    ImagePanelBuilder imagePanelBuilder = ImagePanelBuilder.createPanel();

    imagePanelBuilder.addParticipantImage(CPMConstants.kIconProvider,
      CuramConst.gkEmpty, CPMConstants.kRendererImages);

    ContentPanelBuilder imagePanel = imagePanelBuilder.getImagePanel();

    // Build Center Panel Details
    ContentPanelBuilder centerPanel = getProviderDetails(provider,
      providerEnrollmentInformation, providerGroup);

    // Build Links Panel
    ContentPanelBuilder linksPanel = getProviderLinks(provider,
      numberOfOpenIncidents, numberOfOpenInvestigations);

    containerPanel.addWidgetItem(imagePanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CPMConstants.gkProviderImagePanel);

    containerPanel.addWidgetItem(centerPanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CPMConstants.gkProviderDetailsPanel);

    containerPanel.addWidgetItem(linksPanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CPMConstants.gkProviderLinksPanel);

    providerTabDetails.providerTabDetails = containerPanel.toString();

    return providerTabDetails;
  }

  /**
   * Reads provider tab details for a facility manager.
   *
   * @param providerKey
   * Provider for which tab details are to be read.
   *
   * @return Provider tab details for a facility manager.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderTabDetails viewProviderTabDetailsForFacilityManager(
    final ProviderKey providerKey) throws AppException,
      InformationalException {

    ProviderTabDetails providerTabDetails = new ProviderTabDetails();

    Provider provider = providerDAO.get(providerKey.providerConcernRoleID);

    providerTabDetails.providerName = provider.getName();

    Set<ContractVersion> contractVersions = contractVersionDAO.searchBy(
      provider);

    final List<ContractVersion> contractList = new ArrayList<ContractVersion>();

    int contractRenewalNumberOfDays = Integer.parseInt(
      Configuration.getProperty(EnvVars.ENV_NO_OFDAYS_EVENTS));

    Date endDateToBeCompared = Date.getCurrentDate().addDays(
      contractRenewalNumberOfDays);

    for (final ContractVersion contactVersion : contractVersions) {
      if (CONTRACTSTATUSEntry.LIVE.equals(contactVersion.getLifecycleState())
        && !contactVersion.getDateRange().endsInPast()
        && contactVersion.getDateRange().endsBefore(endDateToBeCompared)) {

        contractList.add(contactVersion);
      }
    }

    int numberOfContracts = contractList.size();

    List<ProviderIncident> incidents = provider.getIncidents();
    int numberOfOpenIncidents = 0;

    for (ProviderIncident providerIncident : incidents) {
      if (INCIDENTSTATUSEntry.OPEN.equals(providerIncident.getLifecycleState())) {
        numberOfOpenIncidents += 1;
      }
    }

    ProviderInvestigation providerInvestigationObj = ProviderInvestigationFactory.newInstance();
    curam.cpm.sl.entity.struct.ProviderConcernRoleKey concernRoleKey = new curam.cpm.sl.entity.struct.ProviderConcernRoleKey();

    concernRoleKey.providerConcernRoleID = providerKey.providerConcernRoleID;

    // BEGIN, CR00291801, ASN
    InvestigationDeliveryListForProvider providerInvestigationDeliveryList = providerInvestigationObj.listInvestigationsForProvider(
      concernRoleKey);

    int numberOfOpenInvestigations = 0;

    for (final ProviderInvestigationDetails providerInvestigationDetails : providerInvestigationDeliveryList.providerInvestigationDetails.items()) {

      if (!RESOLUTIONSTATUSCODEEntry.CANCELED.getCode().equals(
        providerInvestigationDetails.resolutionStatus)
          && !CASESTATUSEntry.CLOSED.getCode().equals(
            providerInvestigationDetails.statusCode)) {
        // END, CR00291801

        numberOfOpenInvestigations += 1;
      }
    }

    Set<curam.providerservice.impl.ProviderOffering> providerOfferings = provider.getProviderOfferings();

    int numberOfServiceWaitlists = 0;

    for (curam.providerservice.impl.ProviderOffering providerOffering : providerOfferings) {

      if (!ProviderOfferingStatusEntry.CANCELED.equals(
        providerOffering.getLifecycleState())) {

        WaitList waitList = waitListDAO.readByResourceID(
          providerOffering.getID());

        if (null != waitList) {
          numberOfServiceWaitlists += waitList.getEntries().size();
        }
      }
    }

    int numberOfProviderWaitlists = 0;

    WaitList waitList = waitListDAO.readByResourceID(provider.getID());

    if (null != waitList) {
      numberOfProviderWaitlists = waitList.getEntries().size();
    }

    Set<ProviderGroupAssociate> providerGroupAssociates = providerGroupAssociateDAO.searchProviderGroupsForProvider(
      provider);
    ProviderGroup providerGroup = null;

    for (ProviderGroupAssociate providerGroupAssociate : providerGroupAssociates) {

      if (RECORDSTATUSEntry.NORMAL.equals(
        providerGroupAssociate.getLifecycleState())
          && providerGroupAssociate.getDateRange().contains(
            Date.getCurrentDate())) {

        providerGroup = providerGroupAssociate.getProviderGroup();
      }
    }

    curam.cpm.facade.intf.MaintainReservation maintainReservationObj = MaintainReservationFactory.newInstance();
    curam.cpm.facade.struct.ProviderKey providerReservationKey = new curam.cpm.facade.struct.ProviderKey();

    providerReservationKey.providerID = providerKey.providerConcernRoleID;
    ReservationSummaryDetailsList reservationSummaryDetailsList = maintainReservationObj.listReservations(
      providerReservationKey);
    int numberOfReservations = reservationSummaryDetailsList.summaryList.size();

    Place placeObj = PlaceFactory.newInstance();
    PlaceAndPlacementDetailsList placeAndPlacementDetailsList = placeObj.viewAllPlacesForProvider(
      providerKey);

    int numberOfOccupiedPlaces = 0;
    int numberOfAvailablePlaces = 0;
    int numberOfOutOfUsePlaces = 0;

    for (final PlaceAndPlacementDetails placeAndPlacementDetails : placeAndPlacementDetailsList.detailsList.items()) {

      curam.place.impl.Place place = placeDAO.get(
        placeAndPlacementDetails.placeID);

      if (PlaceStatusEntry.OCCUPIED.equals(place.getLifecycleState())) {
        numberOfOccupiedPlaces++;
      } else if (PlaceStatusEntry.OUTOFUSE.equals(place.getLifecycleState())) {
        numberOfOutOfUsePlaces++;
      } else if (PlaceStatusEntry.AVAILABLE.equals(place.getLifecycleState())) {
        numberOfAvailablePlaces++;
      }
    }

    ContentPanelBuilder containerPanel = ContentPanelBuilder.createPanel(
      CPMConstants.gkFMProviderContainer);

    ImagePanelBuilder imagePanelBuilder = ImagePanelBuilder.createPanel();

    imagePanelBuilder.addParticipantImage(CPMConstants.kIconProvider,
      CuramConst.gkEmpty, CPMConstants.kRendererImages);

    ContentPanelBuilder imagePanel = imagePanelBuilder.getImagePanel();

    ContentPanelBuilder centerPanel = getFacilityProviderDetails(provider,
      providerGroup, numberOfReservations);

    ContentPanelBuilder linksPanel = getFacilityProviderLinks(provider,
      numberOfContracts, numberOfOpenIncidents, numberOfOpenInvestigations,
      numberOfServiceWaitlists, numberOfProviderWaitlists);

    containerPanel.addWidgetItem(imagePanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CPMConstants.gkFMProviderImagePanel);

    containerPanel.addWidgetItem(centerPanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CPMConstants.gkFMProviderDetailsPanel);

    containerPanel.addWidgetItem(linksPanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CPMConstants.gkFMProviderLinksPanel);

    providerTabDetails.providerTabDetails = containerPanel.toString();

    return providerTabDetails;
  }

  /**
   * Creates the designated places in the root level compartment.
   *
   * @param details
   * Contains the provider details.
   * @param compartmentKey
   * Contains the root level compartment key.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void createDesignatedPlaces(ProviderEnrollmentDetails details,
    CompartmentKey compartmentKey) throws AppException,
      InformationalException {

    long designatedCapacity;
    int kMaxLimit = 1000;

    if (details.physicalCapacity > kMinimumCapacity
      && details.designatedCapacity == kMinimumCapacity) {
      designatedCapacity = details.physicalCapacity;
    } else {
      designatedCapacity = details.designatedCapacity;
    }

    if (designatedCapacity > kMaximumCapacity) {
      designatedCapacity = kMaximumCapacity;
    }

    // If designatedCapacity is less then or equal to the maximum limit, then
    // create the places online otherwise create them through a batch process.
    if (designatedCapacity <= kMaxLimit) {
      // Call new operation to create places repeatedly, only if the designated
      // capacity is greater than the minimum capacity.
      if (designatedCapacity > kMinimumCapacity) {
        details.designatedCapacity = designatedCapacity;
        Place placeObj = PlaceFactory.newInstance();

        placeObj.createBatchPlaces(details, compartmentKey);
      }
    } else {
      // BEGIN, CR00303260, SS
      DeferredProcessing deferredProcessingObj = DeferredProcessingFactory.newInstance();
      WMCreatePlaceData WMCreatePlaceDataObj = WMCreatePlaceDataFactory.newInstance();
      // END, CR00303260

      WMCreatePlaceDataDtls createPlaceDataDtls = new WMCreatePlaceDataDtls();

      createPlaceDataDtls.compartmentID = compartmentKey.compartmentID;
      createPlaceDataDtls.designatedCapacity = designatedCapacity;
      createPlaceDataDtls.startDate = Date.getCurrentDate();
      createPlaceDataDtls.name = kPlaceName;
      WMCreatePlaceDataObj.insert(createPlaceDataDtls);

      deferredProcessingObj.startProcess(CPMConstants.kCreatePlacesForProvider,
        createPlaceDataDtls.wmCreatePlaceDataID);

    }
  }

  /**
   * Gets the information for the clients - areas served information and client
   * information for the provider.
   *
   * @param provider
   * The provider object.
   * @param providerEnrollmentInformation
   * The provider enrollment details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void getClientInformation(
    final curam.provider.impl.Provider provider,
    final ProviderEnrollmentInformation providerEnrollmentInformation)
    throws AppException, InformationalException {

    if (0 != provider.getAreasServedInfoTextID()) {
      providerEnrollmentInformation.areasServedInformation = provider.getAreasServedInfo().getValue();
      providerEnrollmentInformation.areasServedInfoExistsInd = true;
      providerEnrollmentInformation.areasServedInfoTextID = provider.getAreasServedInfoTextID();
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        providerEnrollmentInformation.areasServedInfoTextID);

      if (0 == localizableTextHandler.listTranslations().size()) {
        providerEnrollmentInformation.areaServedAddInd = true;
        providerEnrollmentInformation.areaServedActionURL = CPMConstants.kAddLocalizableTextPage;
      } else {
        providerEnrollmentInformation.areaServedViewInd = true;
        providerEnrollmentInformation.areaServedActionURL = CPMConstants.kViewLocalizableTextPage;
      }
    } else {
      providerEnrollmentInformation.areaServedActionURL = CPMConstants.kAddAreasServedInfoPage;
    }

    if (0 != provider.getClientInfoTextID()) {
      providerEnrollmentInformation.clientInformation = provider.getClientInfo().getValue();
      providerEnrollmentInformation.clientInfoExistsInd = true;
      providerEnrollmentInformation.clientInfoTextID = provider.getClientInfoTextID();
      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        providerEnrollmentInformation.clientInfoTextID);

      if (true == providerEnrollmentInformation.clientInfoExistsInd
        && 0 == localizableText.listTranslations().size()) {

        providerEnrollmentInformation.clientInfoAddInd = true;
        providerEnrollmentInformation.clientInformationActionURL = CPMConstants.kAddLocalizableTextPage;
      } else if (true == providerEnrollmentInformation.clientInfoExistsInd
        && 0 != localizableText.listTranslations().size()) {

        providerEnrollmentInformation.clientInfoViewInd = true;
        providerEnrollmentInformation.clientInformationActionURL = CPMConstants.kViewLocalizableTextPage;
      }

    } else {
      providerEnrollmentInformation.clientInformationActionURL = CPMConstants.kAddClientInformationPage;
    }

  }

  /**
   * Gets event code based on Template ID.
   *
   * @param concernRoleCommunicationDtls
   * Template ID of the notification.
   *
   * @return Event code.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected String getEventCode(
    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00281474, MR
    
    // BEGIN, CR00304493, MR
    String eventCode = CPMConstants.kEmptyString;

    if (!StringUtil.isNullOrEmpty(
      getEventCodeForProviderNotification(
        concernRoleCommunicationDtls.documentTemplateID))) {
      eventCode = getEventCodeForProviderNotification(
        concernRoleCommunicationDtls.documentTemplateID);

    } else if (!StringUtil.isNullOrEmpty(
      getEventCodeForLicenseNotification(
        concernRoleCommunicationDtls.documentTemplateID))) {
      eventCode = getEventCodeForLicenseNotification(
        concernRoleCommunicationDtls.documentTemplateID);

    } else if (!StringUtil.isNullOrEmpty(
      getEventCodeForFinancialNotification(
        concernRoleCommunicationDtls.documentTemplateID))) {
      eventCode = getEventCodeForFinancialNotification(
        concernRoleCommunicationDtls.documentTemplateID);

    } else if (!StringUtil.isNullOrEmpty(
      getEventCodeForContractNotification(
        concernRoleCommunicationDtls.documentTemplateID))) {

      eventCode = getEventCodeForContractNotification(
        concernRoleCommunicationDtls.documentTemplateID);
    } else if (!StringUtil.isNullOrEmpty(
      getEventCodeForRosterNotification(
        concernRoleCommunicationDtls.documentTemplateID))) {

      eventCode = getEventCodeForRosterNotification(
        concernRoleCommunicationDtls.documentTemplateID);
    }
    
    // END, CR00281474
    return eventCode;
    
    // END, CR00304493
  }

  // BEGIN, CR00281474, MR
  /**
   * Gets the event code for the contract notifications.
   *
   * @param documentTemplateID
   * Contains document template associated with this notification.
   *
   * @return The contract notification event code.
   */
  protected String getEventCodeForContractNotification(
    final String documentTemplateID) {
    
    // BEGIN, CR00304493, MR
    String contractEventCode = CPMConstants.kEmptyString;

    if (TEMPLATEIDCODEEntry.PROVIDERCONTRACTACTIVATIONNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.ACTIVATEPROVIDERCONTRACT.getCode();
    } else if (TEMPLATEIDCODEEntry.PGCONTRACTACTIVATIONNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.ACTIVATEPGCONTRACT.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERCONTRACTTERMINATIONNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.TERMINATEPROVIDERCONTRACT.getCode();
    } else if (TEMPLATEIDCODEEntry.PGCONTRACTTERMINATIONNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.TERMINATEPGCONTRACT.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERCONTRACTRENEWALNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.RENEWPROVIDERCONTRACT.getCode();
    } else if (TEMPLATEIDCODEEntry.PGCONTRACTRENEWALNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.RENEWPGCONTRACT.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERFLATRATECONTRACTREG.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.NEWPROVIDERFLATRATECONTRACTREG.getCode();
    } else if (TEMPLATEIDCODEEntry.PGFLATRATECONTRACTREG.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.NEWPGFLATRATECONTRACTREG.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERFLATRATECONTRACTTOTAL.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.NEWPROVIDERFLATRATECONTRACTTOTAL.getCode();
    } else if (TEMPLATEIDCODEEntry.PGFLATRATECONTRACTTOTAL.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.NEWPGFLATRATECONTRACTTOTAL.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERUTILIZATIONCONTRACT.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.NEWPROVIDERUTILIZATIONCONTRACT.getCode();
    } else if (TEMPLATEIDCODEEntry.PGUTILIZATIONCONTRACT.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.NEWPGUTILIZATIONCONTRACT.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERCONTRACTCOVERLETTER.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.PROVIDERCONTRACTCOVERLETTER.getCode();
    } else if (TEMPLATEIDCODEEntry.PGCONTRACTCOVERLETTER.getCode().equals(
      documentTemplateID)) {
      contractEventCode = ContractNotificationEventEntry.PGCONTRACTCOVERLETTER.getCode();
    }
    return contractEventCode;

    // END, CR00304493
  }

  /**
   * Gets the event code for the financial notifications.
   *
   * @param documentTemplateID
   * Contains document template associated with this notification.
   *
   * @return The financial notification event code.
   */
  protected String getEventCodeForFinancialNotification(
    final String documentTemplateID) {
    
    // BEGIN, CR00304493, MR
    String financialEventCode = CPMConstants.kEmptyString;

    if (TEMPLATEIDCODEEntry.SILIDENIEDNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      financialEventCode = FinancialNotificationEventEntry.SILI_DENIED.getCode();
    } else if (TEMPLATEIDCODEEntry.SILICORRECTIONUNDERPAYMENTNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      financialEventCode = FinancialNotificationEventEntry.SILIC_UNDERPAYMENT.getCode();
    } else if (TEMPLATEIDCODEEntry.SILICORRECTIONOVERPAYMENTNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      financialEventCode = FinancialNotificationEventEntry.SILIC_OVERPAYMENT.getCode();
    } else if (TEMPLATEIDCODEEntry.PRLICORRECTIONOVERPAYMENTNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      financialEventCode = FinancialNotificationEventEntry.PRLIC_OVERPAYMENT.getCode();
    } else if (TEMPLATEIDCODEEntry.PRLICORRECTIONUNDERPAYMENTNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      financialEventCode = FinancialNotificationEventEntry.PRLIC_UNDERPAYMENT.getCode();
    }
    return financialEventCode;

    // END, CR00304493
  }

  // END, CR00281474

  /**
   * Gets the event code for the license notifications.
   *
   * @param documentTemplateID
   * Contains document template associated with this notification.
   *
   * @return The license notification event code.
   */
  protected String getEventCodeForLicenseNotification(
    final String documentTemplateID) {
    
    // BEGIN, CR00304493, MR
    String licenseEventCode = CPMConstants.kEmptyString;

    if (TEMPLATEIDCODEEntry.LICENSEAPPROVALNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      licenseEventCode = LicenseNotificationEventEntry.APPROVELICENSE.getCode();
    } else if (TEMPLATEIDCODEEntry.LICENSESUSPENSIONNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      licenseEventCode = LicenseNotificationEventEntry.SUSPENDLICENSE.getCode();
    } else if (TEMPLATEIDCODEEntry.LICENSEREJECTIONNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      licenseEventCode = LicenseNotificationEventEntry.REJECTLICENSE.getCode();
    } else if (TEMPLATEIDCODEEntry.LICENSERENEWALNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      licenseEventCode = LicenseNotificationEventEntry.RENEWLICENSE.getCode();
    }
    return licenseEventCode;
    
    // END, CR00304493
  }

  /**
   * Gets the event code for the provider notifications.
   *
   * @param documentTemplateID
   * Contains document template associated with this notification.
   *
   * @return The provider notification event code.
   */
  protected String getEventCodeForProviderNotification(
    final String documentTemplateID) {
    
    // BEGIN, CR00304493, MR
    String providerEventCode = CPMConstants.kEmptyString;

    if (TEMPLATEIDCODEEntry.PROVIDERENROLLMENTNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      providerEventCode = ProviderNotificationEventEntry.ENROLLMENT.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERREJECTIONNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      providerEventCode = ProviderNotificationEventEntry.REJECTION.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERAPPROVALNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      providerEventCode = ProviderNotificationEventEntry.APPROVAL.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERSUSPENSIONNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      providerEventCode = ProviderNotificationEventEntry.SUSPENSION.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERCLOSURENOTIFICATION.getCode().equals(
      documentTemplateID)) {
      providerEventCode = ProviderNotificationEventEntry.CLOSURE.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERREOPENINGNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      providerEventCode = ProviderNotificationEventEntry.REOPENING.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERGROUPENROLLMENTNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      providerEventCode = ProviderNotificationEventEntry.GROUP_REGISTRATION.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERGROUPCLOSURENOTIFICATION.getCode().equals(
      documentTemplateID)) {
      providerEventCode = ProviderNotificationEventEntry.GROUP_CLOSURE.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERGROUPREOPENINGNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      providerEventCode = ProviderNotificationEventEntry.GROUP_REOPENING.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERSERVICEOFFERINGAPPROVALNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      providerEventCode = ProviderNotificationEventEntry.SERVICE_OFFERING_APPROVAL.getCode();
    } else if (TEMPLATEIDCODEEntry.PROVIDERSERVICEOFFERINGAPPROVALDENIALNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      providerEventCode = ProviderNotificationEventEntry.SERVICE_OFFERING_APPROVAL_DENIAL.getCode();
    } else if (TEMPLATEIDCODEEntry.SERVICERATEUPDATENOTIFICATION.getCode().equals(
      documentTemplateID)) {
      providerEventCode = ProviderNotificationEventEntry.SERVICE_RATE_UPDATE.getCode();
    }
    return providerEventCode;

    // END, CR00304493
  }

  // BEGIN, CR00304493, MR
  /**
   * Gets the event code for the roster notifications.
   *
   * @param documentTemplateID
   * Contains document template associated with this notification.
   *
   * @return The roster notification event code.
   */
  protected String getEventCodeForRosterNotification(
    final String documentTemplateID) {
    String rosterEventCode = CPMConstants.kEmptyString;

    if (TEMPLATEIDCODEEntry.ROSTERLINEITEMDENIALNOTIFICATION.getCode().equals(
      documentTemplateID)) {
      rosterEventCode = RosterNotificationEventEntry.ROSTER_LINE_ITEM_DENIED.getCode();
    } 
    return rosterEventCode;
  }
  
  // END, CR00304493
  
  /**
   * Gets the facility provider details.
   *
   * @param provider
   * Provider for which details are to be retrieved.
   * @param providerGroup
   * Provider group which is related to provider.
   * @param numberOfReservations
   * Number of reservations.
   *
   * @return Content panel builder.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ContentPanelBuilder getFacilityProviderDetails(
    final Provider provider, final ProviderGroup providerGroup,
    final int numberOfReservations) throws AppException,
      InformationalException {

    ContentPanelBuilder centerPanel = ContentPanelBuilder.createPanel(
      CPMConstants.gkFMProviderTabDetails);

    centerPanel.addRoundedCorners();

    centerPanel.addStringItem(provider.getName(),
      CuramConst.gkContentParticipantName);
    centerPanel.addStringItem(provider.getPrimaryAlternateID(),
      CuramConst.gkContentParticipantID);

    ListBuilder enrollmentDetailsList = ListBuilder.createHorizontalList(2);
    int rowValue = CuramConst.gkOne;
    int colValue = CuramConst.gkOne;

    enrollmentDetailsList.addRow();

    if (null != providerGroup) {

      enrollmentDetailsList.addEntry(colValue, rowValue,
        new LocalisableString(PROVIDER.TEXT_PROVIDER_RELATED_PROVIDER_GROUP));
      enrollmentDetailsList.addEntry(colValue + 1, rowValue,
        providerGroup.getName());
      rowValue++;
    }

    enrollmentDetailsList.addRow();
    enrollmentDetailsList.addEntry(colValue, rowValue,
      new LocalisableString(PROVIDER.TEXT_PROVIDER_ACTIVE_RESERVATIONS));
    enrollmentDetailsList.addEntry(colValue + 1, rowValue,
      String.valueOf(numberOfReservations));

    centerPanel.addSingleListItem(enrollmentDetailsList,
      CPMConstants.gkFMProviderDetailsTable);

    return centerPanel;
  }

  /**
   * Gets the links for the facility provider.
   *
   * @param provider
   * Provider for which links are to be set.
   * @param numberOfContracts
   * Number of contracts.
   * @param numberOfOpenIncidents
   * Number of open incidents.
   * @param numberOfOpenInvestigations
   * Number of open investigations.
   * @param numberOfServiceWaitlists
   * Number of service wait lists.
   * @param numberOfProviderWaitlists
   * Number of provider wait lists.
   *
   * @return Content panel builder.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ContentPanelBuilder getFacilityProviderLinks(
    final Provider provider, final int numberOfContracts,
    final int numberOfOpenIncidents, final int numberOfOpenInvestigations,
    final int numberOfServiceWaitlists, final int numberOfProviderWaitlists)
    throws AppException, InformationalException {

    LinksPanelBuilder linksPanelBuilder = LinksPanelBuilder.createLinksPanel(3);

    ContentPanelBuilder caseStatus = ContentPanelBuilder.createPanel(
      CuramConst.gkProductDeliveryCaseStatus);

    String providerStatus = CodeTable.getOneItem(ProviderStatusEntry.TABLENAME,
      provider.getLifecycleState().toString());

    String status = new LocalisableString(PROVIDER.INF_STATUS).arg(providerStatus).toClientFormattedText();

    caseStatus.addlocalisableStringItem(status, CPMConstants.gkFMProviderStatus);

    linksPanelBuilder.addContentPanel(caseStatus);

    ImageBuilder incidentIcon = ImageBuilder.createImage(
      CuramConst.gkIconIncident, CuramConst.gkEmpty);

    incidentIcon.setImageResource(CuramConst.gkRendererImages);
    String incidentText = new LocalisableString(BPOPARTICIPANT.INF_TOOLTIP_INCIDENTS).arg(numberOfOpenIncidents).toClientFormattedText();

    incidentIcon.setImageAltText(incidentText);

    LinkBuilder incidentLinkBuilder = LinkBuilder.createLink(
      (new LocalisableString(PROVIDER.TEXT_PROVIDER_INCIDENTS).arg(numberOfOpenIncidents)).getMessage(
        TransactionInfo.getProgramLocale()),
        CPMConstants.kListIncidentsPage);

    incidentLinkBuilder.addParameter(CuramConst.gkPageParameterConcernRoleID,
      String.valueOf(provider.getID()));

    // BEGIN, CR00262179, GP
    incidentLinkBuilder.addLinkTitle(
      new LocalisableString(PROVIDER.TEXT_PROVIDER_OPEN_INCIDENT_FACILITY_TITLE));
    // END, CR00262179

    linksPanelBuilder.addLinkEntry(incidentIcon, incidentLinkBuilder);

    ImageBuilder serviceWaitListIcon = ImageBuilder.createImage(
      CPMConstants.kIconServiceWaitlistReview, CuramConst.gkEmpty);

    serviceWaitListIcon.setImageResource(CPMConstants.kRendererImages);

    // BEGIN, CR00262179, GP
    serviceWaitListIcon.setImageAltText(
      new LocalisableString(PROVIDER.TEXT_PROVIDER_SERVICE_WAITLIST_TOOLTIP).toClientFormattedText());
    // END, CR00262179

    LinkBuilder serviceWaitListBuilder = LinkBuilder.createLink(
      (new LocalisableString(PROVIDER.TEXT_PROVIDER_SERVICE_WAITLIST).arg(numberOfServiceWaitlists)).getMessage(
        TransactionInfo.getProgramLocale()),
        CPMConstants.kProviderWaitListEntryPage);

    serviceWaitListBuilder.addParameter(CuramConst.gkPageParameterConcernRoleID,
      String.valueOf(provider.getID()));

    // BEGIN, CR00262179, GP
    serviceWaitListBuilder.addLinkTitle(
      new LocalisableString(PROVIDER.TEXT_PROVIDER_SERVICE_WAITLIST_TITLE));
    // END, CR00262179

    linksPanelBuilder.addLinkEntry(serviceWaitListIcon, serviceWaitListBuilder);

    ImageBuilder providerWaitListIcon = ImageBuilder.createImage(
      CPMConstants.kIconProviderWaitlistReview, CuramConst.gkEmpty);

    providerWaitListIcon.setImageResource(CPMConstants.kRendererImages);

    // BEGIN, CR00262179, GP
    providerWaitListIcon.setImageAltText(
      (new LocalisableString(PROVIDER.TEXT_PROVIDER_PROVIDER_WAITLIST_TOOLTIP)).toClientFormattedText());
    // END, CR00262179

    LinkBuilder providerWaitListBuilder = LinkBuilder.createLink(
      (new LocalisableString(PROVIDER.TEXT_PROVIDER_PROVIDER_WAITLIST).arg(numberOfProviderWaitlists)).getMessage(
        TransactionInfo.getProgramLocale()),
        CPMConstants.kProviderWaitListEntryPage);

    providerWaitListBuilder.addParameter(
      CuramConst.gkPageParameterConcernRoleID, String.valueOf(provider.getID()));

    // BEGIN, CR00262179, GP
    providerWaitListBuilder.addLinkTitle(
      new LocalisableString(PROVIDER.TEXT_PROVIDER_PROVIDER_WAITLIST_TITLE));
    // END, CR00262179

    linksPanelBuilder.addLinkEntry(providerWaitListIcon,
      providerWaitListBuilder);

    return linksPanelBuilder.getLinksPanel();
  }

  /**
   * Reads the details for an Provider to be displayed in the details section on
   * the context panel.
   *
   * @param provider
   * The provider to display details for.
   * @param providerEnrollmentInformation
   * The provider enrollment information.
   * @param providerGroup
   * The providers group details.
   *
   * @return Content Panel Builder.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ContentPanelBuilder getProviderDetails(Provider provider,
    ProviderEnrollmentInformation providerEnrollmentInformation,
    ProviderGroup providerGroup) throws AppException, InformationalException {

    ContentPanelBuilder centerPanel = ContentPanelBuilder.createPanel(
      CPMConstants.gkProviderTabDetails);

    centerPanel.addRoundedCorners();

    centerPanel.addStringItem(provider.getName(),
      CuramConst.gkContentParticipantName);
    centerPanel.addStringItem(provider.getPrimaryAlternateID(),
      CuramConst.gkContentParticipantID);
    centerPanel.addStringItem(CuramConst.gkEmpty, CPMConstants.gkStaticDiv);

    TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
    AddressTabDetails addressTabDetails = new AddressTabDetails();

    addressTabDetails.addressData = providerEnrollmentInformation.providerEnrollmentDetails.addressData;

    centerPanel.addStringItem(
      tabDetailFormatterObj.formatAddress(addressTabDetails).addressString,
      CuramConst.gkContentAddress);

    String mapEnabled = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GEOCODE_ENABLED);

    if (mapEnabled == null) {
      mapEnabled = EnvVars.ENV_GEOCODE_ENABLED_DEFAULT;
    }

    if (mapEnabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      LocalisableString mapString = new LocalisableString(
        BPOPARTICIPANT.INF_MAP);

      LinkBuilder googleLinkBuilder = LinkBuilder.createLocalizableLink(
        mapString.toClientFormattedText(), CuramConst.gkAddressMapPage);

      googleLinkBuilder.addParameter(CuramConst.gkAddressID,
        String.valueOf(provider.getPrimaryAddressID()));
      googleLinkBuilder.openAsModal();
      googleLinkBuilder.setTextResource(CuramConst.gkRendererImages);
      googleLinkBuilder.addImage(CuramConst.gkIconMap, CuramConst.gkEmpty);

      centerPanel.addWidgetItem(googleLinkBuilder, CuramConst.gkStyle,
        CuramConst.gkLink, CuramConst.gkContentMap);
    }

    // Filler div to clear floating elements
    centerPanel.addStringItem(CuramConst.gkEmpty, CPMConstants.gkFiller);

    centerPanel.addCodetableItem(
      providerEnrollmentInformation.providerEnrollmentDetails.category,
      CPMConstants.kProviderTypeCategory, CPMConstants.gkProviderCategory);

    WebAddress webAddress = provider.getWebAddress();

    if (null != webAddress) {

      LinkBuilder homePage = LinkBuilder.createLink(webAddress.getWebAddress(),
        webAddress.getWebAddress());

      homePage.openInNewWindow();

      // BEGIN, CR00236083, GP
      homePage.addLinkTitle(
        new LocalisableString(PROVIDER.TEXT_PROVIDER_WEBADDRESS_TITLE));
      // END, CR00236083

      centerPanel.addWidgetItem(homePage, CuramConst.gkStyle,
        CuramConst.gkStyleLink, CPMConstants.gkProviderWebAddress);
    }

    ListBuilder enrollmentDetailsList = ListBuilder.createHorizontalList(2);

    enrollmentDetailsList.addRow();
    enrollmentDetailsList.addEntry(1, 1,
      new LocalisableString(PROVIDER.TEXT_PROVIDER_ENROLLED));
    enrollmentDetailsList.addEntry(2, 1,
      providerEnrollmentInformation.providerEnrollmentDetails.enrollmentDate);

    if (null != providerGroup) {
      enrollmentDetailsList.addRow();
      enrollmentDetailsList.addEntry(1, 2,
        new LocalisableString(PROVIDER.TEXT_PROVIDER_RELATED_PROVIDER_GROUP));

      enrollmentDetailsList.addEntry(2, 2, providerGroup.getName());
    }

    centerPanel.addSingleListItem(enrollmentDetailsList,
      CPMConstants.gkProviderDetailsTable);

    ContentPanelBuilder contactContents = ContentPanelBuilder.createPanel(
      CuramConst.gkContentContacts);

    // Create a image builder for a phone icon
    ImageBuilder phoneIconImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconPhone, CuramConst.gkEmpty);

    phoneIconImageBuilder.setImageResource(CuramConst.gkRendererImages);

    // BEGIN, CR00262179, GP
    phoneIconImageBuilder.setImageAltText(
      new LocalisableString(PROVIDER.TEXT_PROVIDER_PHONE_NUMBER).toClientFormattedText());
    // END, CR00262179

    contactContents.addImageItem(phoneIconImageBuilder);

    // Get the phone number for the Provider
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = provider.getID();
    PhoneFaxDetails phoneFaxDetails = ParticipantTabFactory.newInstance().getPhoneFaxDetails(
      concernRoleKey);

    if (phoneFaxDetails.phoneNumberString.length() != 0) {

      contactContents.addStringItem(phoneFaxDetails.phoneNumberString,
        CuramConst.gkPhoneNumber);
    } else {
      LocalisableString detailsNotRecorded = new LocalisableString(
        BPOPARTICIPANT.INF_NOT_RECORDED);

      contactContents.addlocalisableStringItem(
        detailsNotRecorded.toClientFormattedText(), CuramConst.gkPhoneNumber);
    }

    // Create a image builder for an email icon
    ImageBuilder emailIconImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconEmail, CuramConst.gkEmpty);

    emailIconImageBuilder.setImageResource(CuramConst.gkRendererImages);

    // BEGIN, CR00262179, GP
    emailIconImageBuilder.setImageAltText(
      new LocalisableString(PROVIDER.TEXT_PROVIDER_EMAIL_ADDRESS).toClientFormattedText());
    // END, CR00262179

    contactContents.addImageItem(emailIconImageBuilder);

    if (null != provider.getEmailAddress()) {

      LinkBuilder emailLinkBuilder = LinkBuilder.createLink(
        provider.getEmailAddress().getEmail(),
        CuramConst.gkMailto + provider.getEmailAddress().getEmail());

      // BEGIN, CR00262179, GP
      emailLinkBuilder.addLinkTitle(
        new LocalisableString(PROVIDER.TEXT_PROVIDER_EMAIL_TITLE));
      // END, CR00262179

      contactContents.addWidgetItem(emailLinkBuilder, CuramConst.gkStyle,
        CuramConst.gkLink, CuramConst.gkEmail);
    } else {
      LocalisableString detailsNotRecorded = new LocalisableString(
        BPOPARTICIPANT.INF_NOT_RECORDED);

      contactContents.addlocalisableStringItem(
        detailsNotRecorded.toClientFormattedText(), CuramConst.gkEmail);
    }

    centerPanel.addWidgetItem(contactContents, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    return centerPanel;
  }

  // END, CR00224728

  /**
   * Returns the provider details.
   *
   * @param provider
   * Provider for which details are to be returned.
   *
   * @return Provider details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ProviderSummaryVersionDetails getProviderFields(
    final Provider provider) throws AppException, InformationalException {

    ProviderSummaryVersionDetails providerSummaryVersionDetails = new ProviderSummaryVersionDetails();

    providerSummaryVersionDetails.concernRoleID = provider.getID();
    providerSummaryVersionDetails.recordStatus = provider.getLifecycleState().getCode();
    ProviderCategoryPeriod providerCategoryPeriod = provider.getPrimaryProviderCategoryPeriod();

    providerSummaryVersionDetails.primaryCategory = ProviderCategoryNameEntry.get(providerCategoryPeriod.getCategory().getCode()).getCode();
    providerSummaryVersionDetails.categoryVersionNo = providerCategoryPeriod.getVersionNo();

    AddressKey addressKey = new AddressKey();

    addressKey.addressID = provider.getPrimaryAddressID();
    
    AddressElement addressElementObj = AddressElementFactory.newInstance();
    AddressElementDtlsList addressElementDtlsList = addressElementObj.readAddressElementDetails(
      addressKey);

    for (final AddressElementDtls addressElementDtls : addressElementDtlsList.dtls.items()) {
      if (ADDRESSELEMENTTYPEEntry.CITY.getCode().equals(
        addressElementDtls.elementType)) {

        providerSummaryVersionDetails.city = addressElementDtls.elementValue;
      } else if (ADDRESSELEMENTTYPEEntry.LINE1.getCode().equals(
        addressElementDtls.elementType)) {

        providerSummaryVersionDetails.street1 = addressElementDtls.elementValue;
      }
    }
    // BEGIN, CR00293652, ASN
    TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
    AddressTabDetails addressTabDetails = new AddressTabDetails();

    Address addressObj = AddressFactory.newInstance();

    if (0 != provider.getPrimaryAddressID()) {
      addressTabDetails.addressData = addressObj.read(addressKey).addressData;
    }

    if (!CuramConst.gkEmpty.equals(addressTabDetails.addressData)) {
      providerSummaryVersionDetails.addressStringOpt = tabDetailFormatterObj.formatAddress(addressTabDetails).addressString;
    }
    // END, CR00293652

    providerSummaryVersionDetails.name = provider.getName();
    providerSummaryVersionDetails.referenceNumber = provider.getPrimaryAlternateID();
    providerSummaryVersionDetails.versionNo = provider.getVersionNo();

    MaintainAdminConcernRole maintainAdminConcernRole = new MaintainAdminConcernRole();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = provider.getID();
    providerSummaryVersionDetails.owner = maintainAdminConcernRole.getProviderOrganisationOwner(concernRoleKey).userName;

    User user = userDAO.get(providerSummaryVersionDetails.owner);

    providerSummaryVersionDetails.ownerFullName = user.getFullName();

    Set<ProviderType> providerTypes = providerCategoryPeriod.getProviderTypes();

    for (final ProviderType providerType : providerTypes) {

      providerSummaryVersionDetails.typeVersionNo = providerType.getVersionNo();

      break;
    }

    if (ProviderStatusEntry.OPEN.equals(provider.getLifecycleState())
      || ProviderStatusEntry.APPROVED.equals(provider.getLifecycleState())) {

      providerSummaryVersionDetails.editIndicator = true;
    }

    return providerSummaryVersionDetails;
  }

  /**
   * Reads the links panel details for a provider.
   *
   * @param provider
   * The provider to display the links details for.
   * @param numberOfOpenIncidents
   * The number of open incidents to display.
   * @param numberOfOpenInvestigations
   * The number of open investigations to display.
   *
   * @return Content Panel Builder.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ContentPanelBuilder getProviderLinks(Provider provider,
    int numberOfOpenIncidents, int numberOfOpenInvestigations)
    throws AppException, InformationalException {

    LinksPanelBuilder linksPanelBuilder = LinksPanelBuilder.createLinksPanel(3);

    ContentPanelBuilder caseStatus = ContentPanelBuilder.createPanel(
      CuramConst.gkProductDeliveryCaseStatus);

    String providerStatus = curam.util.type.CodeTable.getOneItem(
      ProviderStatusEntry.TABLENAME, provider.getLifecycleState().toString());

    String status = new LocalisableString(PROVIDER.INF_STATUS).arg(providerStatus).toClientFormattedText();

    caseStatus.addlocalisableStringItem(status, CPMConstants.gkProviderStatus);

    linksPanelBuilder.addContentPanel(caseStatus);

    // Create a image builder for a phone icon
    ImageBuilder investigationIcon = ImageBuilder.createImage(
      CuramConst.gkIconInvestigation, CuramConst.gkEmpty);

    investigationIcon.setImageResource(CuramConst.gkRendererImages);
    String investigationText = new LocalisableString(BPOPARTICIPANT.INF_TOOLTIP_INVESTIGATION).arg(numberOfOpenInvestigations).toClientFormattedText();

    investigationIcon.setImageAltText(investigationText);

    String investigationsString = new LocalisableString(PROVIDER.TEXT_PROVIDER_INVESTIGATIONS).arg(numberOfOpenInvestigations).toClientFormattedText();

    LinkBuilder linkBuilder = LinkBuilder.createLocalizableLink(
      investigationsString, CPMConstants.kListInvestigationPage);

    linkBuilder.addParameter(CuramConst.gkPageParameterConcernRoleID,
      String.valueOf(provider.getID()));
    // BEGIN, CR00250690, JMA
    linkBuilder.addParameter(CPMConstants.kProviderConcernRoleID,
      String.valueOf(provider.getID()));
    // END, CR00250690

    // BEGIN, CR00262179, GP
    linkBuilder.addLinkTitle(
      new LocalisableString(PROVIDER.TEXT_PROVIDER_OPEN_INVESTIGATIONS_TITLE));
    // END, CR00262179

    linksPanelBuilder.addLinkEntry(investigationIcon, linkBuilder);

    ImageBuilder incidentIcon = ImageBuilder.createImage(
      CuramConst.gkIconIncident, CuramConst.gkEmpty);

    incidentIcon.setImageResource(CuramConst.gkRendererImages);
    String incidentText = new LocalisableString(BPOPARTICIPANT.INF_TOOLTIP_INCIDENTS).arg(numberOfOpenIncidents).toClientFormattedText();

    incidentIcon.setImageAltText(incidentText);

    LinkBuilder incidentLinkBuilder = LinkBuilder.createLink(
      (new LocalisableString(PROVIDER.TEXT_PROVIDER_INCIDENTS).arg(numberOfOpenIncidents)).getMessage(
        TransactionInfo.getProgramLocale()),
        CPMConstants.kListIncidentsPage);

    incidentLinkBuilder.addParameter(CuramConst.gkPageParameterConcernRoleID,
      String.valueOf(provider.getID()));
    // BEGIN, CR00250690, JMA
    incidentLinkBuilder.addParameter(CPMConstants.kProviderConcernRoleID,
      String.valueOf(provider.getID()));
    // END, CR00250690

    // BEGIN, CR00262179, GP
    incidentLinkBuilder.addLinkTitle(
      new LocalisableString(PROVIDER.TEXT_PROVIDER_OPEN_INCIDENTS_TITLE));
    // END, CR00262179

    linksPanelBuilder.addLinkEntry(incidentIcon, incidentLinkBuilder);

    return linksPanelBuilder.getLinksPanel();
  }

  /**
   * Sets the address fields of the provider.
   *
   * @param details
   * provider enrollment struct contain fields set by the user.
   *
   * @param addressDetails
   * contains the provider address details. the service layer struct
   * into which the user-updateable fields must be mapped.
   */
  protected void setAddressFields(ProviderEnrollmentDetails details,
    AddressDetails addressDetails) {

    addressDetails.typeCode = CONCERNROLEADDRESSTYPE.BUSINESS;
    addressDetails.startDate = details.enrollmentDate;
    addressDetails.endDate = curam.util.type.Date.kZeroDate;
    addressDetails.statusCode = RECORDSTATUS.NORMAL;
    addressDetails.addressData = details.addressData;
    addressDetails.primaryAddressInd = true;

  }

  /**
   * Sets the provider bank fields.
   *
   * @param details
   * provider enrollment struct contain fields set by the user.
   * @param bankAccountDetails
   * Contains the provider bank details. the service layer struct into
   * which the user-updateable fields must be mapped.
   */
  protected void setConcernRoleBankFields(ProviderEnrollmentDetails details,
    BankAccountDetails bankAccountDetails) {

    bankAccountDetails.name = details.bankAccountName;
    bankAccountDetails.typeCode = details.bankAccountType;
    bankAccountDetails.bankSortCode = details.bankSortCode;
    bankAccountDetails.accountNumber = details.bankAccountNumber;
    bankAccountDetails.statusCode = RECORDSTATUS.NORMAL;
    bankAccountDetails.startDate = details.enrollmentDate;
    bankAccountDetails.primaryBankInd = true;
    bankAccountDetails.jointAccountInd = details.bankJointAccount;
    // BEGIN, CR00377006, GA
    bankAccountDetails.bicOpt = details.bicOpt;
    bankAccountDetails.ibanOpt = details.ibanOpt;
    // END, CR00377006



  }

  /**
   * Sets the provider concern role fields.
   *
   * @param details
   * Contains the provider enrollment details.
   * @param concernRoleDtls
   * Contains concern role details. the service layer struct into which
   * the user updateable fields must be mapped.
   */
  protected void setConcernRoleFields(ProviderEnrollmentDetails details,
    ConcernRoleDtls concernRoleDtls) {

    concernRoleDtls.concernRoleType = CONCERNROLETYPEEntry.PROVIDER.getCode();
    concernRoleDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();
    concernRoleDtls.registrationDate = details.enrollmentDate;
    concernRoleDtls.startDate = details.enrollmentDate;
    concernRoleDtls.endDate = curam.util.type.Date.kZeroDate;
    concernRoleDtls.concernRoleName = details.providerName;

    concernRoleDtls.primaryEmailAddressID = 0;
    concernRoleDtls.regUserName = curam.util.transaction.TransactionInfo.getProgramUser();
    concernRoleDtls.comments = CPMConstants.kEmptyString;
    concernRoleDtls.preferredLanguage = details.prefLanguage;
    concernRoleDtls.prefCommMethod = details.prefCommMethod;

    if (0 != details.prefCommMethod.length()) {
      concernRoleDtls.prefCommFromDate = details.enrollmentDate;
    }
    concernRoleDtls.sensitivity = SENSITIVITY.DEFAULTCODE;
    concernRoleDtls.statusCode = CONCERNROLESTATUS.CURRENT;
  }

  // BEGIN, CR00196848, SSK

  /**
   * Sets the provider phone fields.
   *
   * @param details
   * provider enrollment struct contain fields set by the user.
   *
   * @param concernRolePhoneDetails
   * Contains the provider phone details. the service layer struct into
   * which the user-updateable fields must be mapped.
   */
  protected void setConcernRolePhoneFields(ProviderEnrollmentDetails details,
    ConcernRolePhoneDetails concernRolePhoneDetails) {

    concernRolePhoneDetails.phoneNumber = details.phoneNumber;
    concernRolePhoneDetails.phoneExtension = details.phoneExtension;
    concernRolePhoneDetails.typeCode = details.phoneType;
    concernRolePhoneDetails.phoneAreaCode = details.phoneAreaCode;
    concernRolePhoneDetails.phoneCountryCode = details.phoneCountryCode;
    concernRolePhoneDetails.startDate = details.enrollmentDate;
    concernRolePhoneDetails.endDate = curam.util.type.Date.kZeroDate;

  }

  /**
   * Sets the Provider fields, used in create and modify provider methods.
   *
   * @param details
   * provider enrollment struct contains fields set by the user.
   * @param provider
   * the service layer object into which the user-updateable fields
   * must be mapped.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XFV_DESIGNATED_CAPACITY_MUST_BE_LESS_THAN_OR_EQUAL_TO_PHY_CAPACITY}
   * - If the designated capacity is greater than the physical
   * capacity.
   * @throws AppException
   * Generic Exception Signature.
   * {@link curam.message.PROVIDER#ERR_PROVIDER_FV_PROVIDER_RESERVATION_GRACE_PERIOD_GT_ZERO}
   * - If the reservation grace period is less than or equal to zero.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_FV_PROVIDER_RESERVATION_GRACE_PERIOD_INVALID}
   * - If the reservation grace period is invalid.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void setProviderFields(ProviderEnrollmentInformation details,
    curam.provider.impl.Provider provider) throws AppException,
      InformationalException {

    provider.setCurrencyType(
      CURRENCYEntry.get(details.providerEnrollmentDetails.currencyType));
    provider.setMethodOfPayment(
      details.providerEnrollmentDetails.methodOfPayment);

    if (!details.providerEnrollmentDetails.paymentFrequency.equals(
      CPMConstants.kEmptyString)) {
      provider.setPaymentFrequency(
        details.providerEnrollmentDetails.paymentFrequency);
    } else {
      provider.setPaymentFrequency(
        FrequencyPattern.kZeroFrequencyPattern.toString());
    }
    if (details.providerEnrollmentDetails.physicalCapacity == kMinimumCapacity
      && details.providerEnrollmentDetails.designatedCapacity
        > kMinimumCapacity) {
      details.providerEnrollmentDetails.physicalCapacity = (int) details.providerEnrollmentDetails.designatedCapacity;
      provider.setPhysicalCapacity(
        (int) details.providerEnrollmentDetails.designatedCapacity);
    } else {
      provider.setPhysicalCapacity(
        details.providerEnrollmentDetails.physicalCapacity);
    }

    // Designated capacity cannot be greater than the physical capacity
    if (details.providerEnrollmentDetails.designatedCapacity
      > details.providerEnrollmentDetails.physicalCapacity) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new curam.util.exception.AppException(curam.message.PROVIDER.ERR_PROVIDER_XFV_DESIGNATED_CAPACITY_MUST_BE_LESS_THAN_OR_EQUAL_TO_PHY_CAPACITY).arg(details.providerEnrollmentDetails.designatedCapacity).arg(
          details.providerEnrollmentDetails.physicalCapacity),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    // If this provider has existing enquiry then set the enquiry id
    if (0 != details.providerEnrollmentDetails.providerEnquiryID) {

      curam.provider.impl.ProviderEnquiry providerEnquiry = providerEnquiryDAO.get(
        details.providerEnrollmentDetails.providerEnquiryID);

      provider.setProviderEnquiry(providerEnquiry);
    }

    if (details.providerEnrollmentDetails.reservationGracePeriodString.length()
      > CPMConstants.kZeroLong) {
      try {
        details.providerEnrollmentDetails.reservationGracePeriod = Short.parseShort(
          details.providerEnrollmentDetails.reservationGracePeriodString);

      } catch (NumberFormatException exception) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_FV_PROVIDER_RESERVATION_GRACE_PERIOD_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      }

      if (details.providerEnrollmentDetails.reservationGracePeriod
        <= CPMConstants.kZeroLong) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_FV_PROVIDER_RESERVATION_GRACE_PERIOD_GT_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      }
    }
    provider.setReservationGracePeriod(
      details.providerEnrollmentDetails.reservationGracePeriod);

    provider.setPreferredServiceEnquiryMethod(
      PREFERREDSERVICEENQUIRYMETHODEntry.get(
        details.preferredServiceEnquiryMethod));

    if (provider.getAreasServedInfoTextID() == 0) {
      LocalizableTextTranslationDetails localizableTextTranslationDetails = new LocalizableTextTranslationDetails();
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.setShortTextInd(true);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text);
      provider.setAreasServedInfoTextID(localizableTextHandler.store());
    }
    provider.getAreasServedInfo().addValue(details.areasServedInformation);

    if (provider.getClientInfoTextID() == 0) {
      LocalizableTextTranslationDetails localizableTextTranslationDetails = new LocalizableTextTranslationDetails();
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.setShortTextInd(true);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text);
      provider.setClientInfoTextID(localizableTextHandler.store());
    }
    provider.getClientInfo().addValue(details.clientInformation);

    provider.setAcceptsCWReferral(details.acceptCWReferral);

  }

  /**
   * Inserts a Provider Status History record each time there is a change in
   * Provider life cycle.
   *
   * @param provider
   * provider object contains the provider status information
   * @param reason
   * reason for the change in the provider status
   * @param status
   * The status of a provider. The status will change through the life
   * cycle of the provider.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void setProviderStatusHistory(
    final curam.provider.impl.Provider provider, String reason, String status)
    throws AppException, InformationalException {

    curam.provider.impl.ProviderStatusHistory providerStatusHistory = providerStatusHistoryDAO.newInstance();

    providerStatusHistory.setEffectiveDateTime(DateTime.getCurrentDateTime());
    providerStatusHistory.setUserName(TransactionInfo.getProgramUser());
    providerStatusHistory.setProvider(provider);
    providerStatusHistory.setReason(reason);
    providerStatusHistory.setProviderRecordStatus(status);
    providerStatusHistory.insert();
  }

  // END, CR00196848

  /**
   * Sorts a set of providers in ascending order of the reference number.
   *
   * @param unsortedProviders
   * The set of unsorted providers.
   *
   * @return A list of providers sorted by name.
   */
  protected ProviderSummaryVersionDetailsList sortProviders(
    final ProviderSummaryVersionDetailsList unsortedProviders) {

    List<ProviderSummaryVersionDetails> providerSummaryVersionDetailsList = new ArrayList<ProviderSummaryVersionDetails>();

    for (final ProviderSummaryVersionDetails providerSummaryVersionDetails : unsortedProviders.providerSummaryVersionDetails.items()) {

      providerSummaryVersionDetailsList.add(providerSummaryVersionDetails);
    }

    Collections.sort(providerSummaryVersionDetailsList,
      new Comparator<ProviderSummaryVersionDetails>() {
      public int compare(final ProviderSummaryVersionDetails lhs,
        ProviderSummaryVersionDetails rhs) {
        return lhs.referenceNumber.compareToIgnoreCase(rhs.referenceNumber);
      }
    });

    ProviderSummaryVersionDetailsList providerSummaryVersionDetailsListSorted = new ProviderSummaryVersionDetailsList();

    providerSummaryVersionDetailsListSorted.providerSummaryVersionDetails.addAll(
      providerSummaryVersionDetailsList);

    return providerSummaryVersionDetailsListSorted;
  }

  /**
   * Sorts provider status history by date and time.
   *
   * @param providerStatusHistoryDetailsList
   * Provider status history details.
   *
   * @return List of sorted provider status history.
   */
  protected List<ProviderStatusHistoryDetails> sortProviderStatusHistoryByDateTime(
    List<ProviderStatusHistoryDetails> providerStatusHistoryDetailsList) {

    Collections.sort(providerStatusHistoryDetailsList,
      new Comparator<ProviderStatusHistoryDetails>() {
      public int compare(final ProviderStatusHistoryDetails lhs,
        final ProviderStatusHistoryDetails rhs) {
        return rhs.providerStatusHistoryDetails.effectiveDateTime.compareTo(
          lhs.providerStatusHistoryDetails.effectiveDateTime);
      }
    });

    return providerStatusHistoryDetailsList;
  }

  /**
   * Validates the bank account details if the bank account is joint account.
   *
   * @param details
   * Provider enrollment details which has bank account details to be
   * verified.
   *
   * @throws AppException
   * {@link curam.message.BPOBANKACCOUNT#ERR_JOINBANKACCOUNT_VALIDATION_FAILURE_LIST}
   * - If there are some errors occurred during the joint bank account
   * validation.
   */
  protected void validateBankAccountDetails(ProviderEnrollmentDetails details)
    throws AppException {

    StringBuffer validationString = new StringBuffer();

    if (details.bankJointAccount) {

      if (StringUtil.isNullOrEmpty(details.bankAccountName)) {

        validationString.append(CuramConst.gkNewLine).append(
          GENERALADMIN.ERR_BANKACCOUNT_FV_NAME_EMPTY.getMessageText());
      }

      if (StringUtil.isNullOrEmpty(details.bankAccountType)) {

        validationString.append(CuramConst.gkNewLine).append(
          GENERALADMIN.ERR_BANKACCOUNT_FV_TYPE_EMPTY.getMessageText());

      }

      // BEGIN, CR00377006, GA
      final InternationalBankAccountIndicator internationalBankAccountIndicator = new InternationalBankAccountIndicator(); 
      
      internationalBankAccountIndicator.ibanInd = Configuration.getBooleanProperty(
        EnvVars.ENV_PARTICIPANT_ENABLE_IBAN_FUNCTIONALITY);
      if (!internationalBankAccountIndicator.ibanInd) {
    	  
        if (StringUtil.isNullOrEmpty(details.bankSortCode)) {

          validationString.append(CuramConst.gkNewLine).append(
            GENERALADMIN.ERR_BANKACCOUNT_FV_BANKBRANCH_EMPTY.getMessageText());
 
        }

        if (StringUtil.isNullOrEmpty(details.bankAccountNumber)) {

          validationString.append(CuramConst.gkNewLine).append(
            GENERALADMIN.ERR_BANKACCOUNT_FV_NUM_EMPTY.getMessageText());
        }
      }
      // END, CR00377006
      
      if (validationString.length() > 0) {

        AppException e = new AppException(
          BPOBANKACCOUNT.ERR_JOINBANKACCOUNT_VALIDATION_FAILURE_LIST);

        e.arg(validationString);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
      }
    }

  }

  /**
   * Validates concern role details of the provider for modify operation.
   *
   * @param providerEnrollmentDetails
   * contains provider enrollment details.
   *
   * @throws InformationalException
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_XRV_PREFERRED_COMMUICATION_MUST_BE_ENTERED}
   * - If the preferred communication is not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_FV_NAME_MUST_BE_ENTERED}
   * - If the provider name is not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_FV_COMMENT_IS_TOO_LONG}
   * - If the length of the comments is greater than the maximum
   * length.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_FV_NAME_IS_TOO_LONG} -
   * If the length of the provider name is greater than the maximum
   * length.
   * @throws InformationalException
   * {@link curam.message.CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_XRV_PREFERRED_LANGUAGE_MUST_BE_ENTERED}
   * - If the preferred language is not entered.
   */
  protected void validateConcernRoleDetails(
    ProviderEnrollmentDetails providerEnrollmentDetails) throws AppException,
      InformationalException {

    if (StringHelper.isEmpty(providerEnrollmentDetails.providerName.trim())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_NAME_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    if (providerEnrollmentDetails.providerName.trim().length()
      > ProviderAdapter.kMaxLength_name) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_NAME_IS_TOO_LONG(
          ProviderAdapter.kMaxLength_name),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    // BEGIN, CR00274149, GP
    int length = providerEnrollmentDetails.providerName.trim().toUpperCase().length();

    if (ProviderAdapter.kMaxLength_name < length) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_NAME_EXCEEDS_MAXLIMIT(length,
        ProviderAdapter.kMaxLength_name),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
        0);
    }
    // END, CR00274149

    if (StringHelper.isEmpty(providerEnrollmentDetails.prefLanguage.trim())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_PREFERRED_LANGUAGE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    if (StringHelper.isEmpty(providerEnrollmentDetails.prefCommMethod.trim())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XRV_PREFERRED_COMMUICATION_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    if (providerEnrollmentDetails.comments.length()
      > ConcernRoleAdapter.kMaxLength_comments) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_FV_COMMENT_IS_TOO_LONG(
          ConcernRoleAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    // BEGIN, CR00274149, GP
    ValidationHelper.failIfErrorsExist();
    // END, CR00274149

  }

  // END, CR00246409

  /**
   * Validates the physical capacity and designated capacity.
   *
   * @param providerEnrollmentDetails
   * Contains provider enrollment details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws NumberFormatException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_FV_PROVIDER_PHYSICAL_CAPACITY_INVALID}
   * - If the physical capacity entered is not valid.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_FV_PROVIDER_DESIGNATED_CAPACITY_GT_ZERO}
   * - If the designated capacity is less than or equal to the minimum
   * capacity.
   * @throws NumberFormatException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_FV_PROVIDER_DESIGNATED_CAPACITY_INVALID}
   * - If the designated capacity entered is not valid.
   */
  protected void validateProviderPhysicalAndDesignatedCapacityDDetails(
    ProviderEnrollmentDetails providerEnrollmentDetails) throws AppException,
      InformationalException {

    int physicalCapacityIntType = kMinimumCapacity;
    int designatedCapacityIntType = kMinimumCapacity;
    String physicalCapacity = providerEnrollmentDetails.physicalCapacityString.trim();
    String designatedCapacity = providerEnrollmentDetails.designatedCapacityString.trim();

    if (physicalCapacity.length() > kMinimumCapacity) {
      try {
        physicalCapacityIntType = Integer.parseInt(physicalCapacity);

        providerEnrollmentDetails.physicalCapacity = physicalCapacityIntType;

      } catch (NumberFormatException exception) {
        throw PROVIDERExceptionCreator.ERR_PROVIDER_FV_PROVIDER_PHYSICAL_CAPACITY_INVALID();
      }

      // physicalCapacity cannot be less than zero
      if (physicalCapacityIntType <= kMinimumCapacity) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new curam.util.exception.AppException(
            curam.message.PROVIDER.ERR_PROVIDER_FV_PROVIDER_PHYSICAL_CAPACITY_GT_ZERO),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            1);
      }
    }

    if (designatedCapacity.length() > kMinimumCapacity) {
      try {
        designatedCapacityIntType = Integer.parseInt(designatedCapacity);

        providerEnrollmentDetails.designatedCapacity = designatedCapacityIntType;

      } catch (NumberFormatException exception) {
        throw PROVIDERExceptionCreator.ERR_PROVIDER_FV_PROVIDER_DESIGNATED_CAPACITY_INVALID();
      }

      // designatedCapacity cannot be less than zero
      if (designatedCapacityIntType <= kMinimumCapacity) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new curam.util.exception.AppException(
            curam.message.PROVIDER.ERR_PROVIDER_FV_PROVIDER_DESIGNATED_CAPACITY_GT_ZERO),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  }

  // BEGIN, CR00292696, IBM
  /**
   * Collects the list of informations from the informational manager and adds
   * them to the list parameter passed in.
   *
   * @param informationalMsgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList informationalMsgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }
  // END, CR00292696
}
