/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2011, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd..
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.text.DecimalFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.RESTRAINTTIMEUNITS;
import curam.codetable.impl.INCIDENTRESTRAINTTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.RESTRAINTTIMEUNITSEntry;
import curam.core.facade.fact.IncidentsFactory;
import curam.core.facade.intf.Incidents;
import curam.core.facade.struct.IncidentParticipantDetails;
import curam.core.facade.struct.IncidentParticipantDetailsList;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRole;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.UsersKey;
import curam.cpm.facade.struct.ByWhomParticipantDetails;
import curam.cpm.facade.struct.ByWhomParticipantDetailsList;
import curam.cpm.facade.struct.ByWhomParticipantKey;
import curam.cpm.facade.struct.IncidentRestraintDetails;
import curam.cpm.facade.struct.IncidentRestraintDetailsList;
import curam.cpm.facade.struct.IncidentRestraintKey;
import curam.cpm.facade.struct.IncidentRestraintKeyVersionDetails;
import curam.incident.entity.struct.IncidentKey;
import curam.incident.impl.Incident;
import curam.incident.impl.IncidentDAO;
import curam.incident.impl.IncidentParticipant;
import curam.incident.impl.IncidentParticipantDAO;
import curam.provider.impl.IncidentRestraint;
import curam.provider.impl.IncidentRestraintDAO;
import curam.provider.impl.ProviderMember;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.CodeTable;


/**
 * {@inheritDoc}
 */
public abstract class MaintainIncidentRestraint extends curam.cpm.facade.base.MaintainIncidentRestraint {

  /**
   * Reference to incident DAO.
   */
  @Inject
  protected IncidentDAO incidentDAO;

  /**
   * Reference to ProviderIncidentRestraintDAO.
   */
  @Inject
  protected IncidentRestraintDAO incidentRestraintDAO;

  /**
   * Reference to incident participant DAO.
   */
  @Inject
  protected IncidentParticipantDAO incidentParticipantDAO;

  /**
   * Reference to ProviderOrganizationDAO.
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Constructor for the class.
   */
  public MaintainIncidentRestraint() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public IncidentRestraintKey createIncidentRestraint(
    IncidentRestraintDetails details) throws AppException,
      InformationalException {

    IncidentRestraintKey incidentRestraintKey = new IncidentRestraintKey();
    IncidentRestraint incidentRestraintObj = incidentRestraintDAO.newInstance();
    Incident incidentObj = incidentDAO.get(details.dtls.incidentID);

    incidentRestraintObj.setIncident(incidentObj);
    incidentRestraintObj.setByWhomParticipantRoleID(
      details.dtls.byWhomParticipantRoleID);
    incidentRestraintObj.setOnWhomParticipantRoleID(
      details.dtls.onWhomParticipantRoleID);
    incidentRestraintObj.setDuration(details.dtls.duration);
    incidentRestraintObj.setDurationUnit(
      RESTRAINTTIMEUNITSEntry.get(details.dtls.durationUnitCode));
    incidentRestraintObj.setRestraintType(
      INCIDENTRESTRAINTTYPEEntry.get(details.dtls.typeCode));

    incidentRestraintObj.insert();

    incidentRestraintKey.incidentRestraintID = incidentRestraintObj.getID();

    return incidentRestraintKey;
  }

  /**
   * {@inheritDoc}
   */
  public void deleteIncidentRestraint(
    IncidentRestraintKeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    IncidentRestraint incidentRestraintObj = incidentRestraintDAO.get(
      keyVersionDetails.incidentRestraintID);

    incidentRestraintObj.cancel(keyVersionDetails.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public IncidentRestraintDetailsList listIncidentRestraint(
    IncidentRestraintKey key) throws AppException,
      InformationalException {

    IncidentRestraintDetailsList incidentRestraintDetailsList = new IncidentRestraintDetailsList();
    Incident incidentObj = incidentDAO.get(key.incidentID);

    Set<IncidentRestraint> incidentRestraints = incidentRestraintDAO.searchByIncident(
      incidentObj);

    for (IncidentRestraint incidentRestraintObj : incidentRestraints) {

      IncidentRestraintDetails incidentRestraintDetails = new IncidentRestraintDetails();

      incidentRestraintDetails.dtls.incidentID = key.incidentID;
      incidentRestraintDetails.dtls.incidentRestraintID = incidentRestraintObj.getID();
      incidentRestraintDetails.dtls.byWhomParticipantRoleID = incidentRestraintObj.getByWhomParticipantRoleID();
      incidentRestraintDetails.dtls.onWhomParticipantRoleID = incidentRestraintObj.getOnWhomParticipantRoleID();
      incidentRestraintDetails.dtls.duration = incidentRestraintObj.getDuration();
      incidentRestraintDetails.dtls.durationUnitCode = incidentRestraintObj.getDurationUnit().getCode();
      if (0 == incidentRestraintDetails.dtls.duration) {
        incidentRestraintDetails.restraintDurationAndUnitString = CuramConst.gkEmpty;
      } else {
        String str = CuramConst.gkEmpty;
        Double value = new Double(incidentRestraintDetails.dtls.duration);
        String tempStr = value.toString().substring(
          value.toString().indexOf(CuramConst.gkDotChar));

        if (Double.parseDouble(tempStr) == 0) {
          str = new Integer(value.intValue()).toString();
        } else {
          DecimalFormat df = new DecimalFormat(
            curam.servicedelivery.impl.CuramConst.gkDecimalFormat);

          str = df.format(incidentRestraintDetails.dtls.duration);
        }

        incidentRestraintDetails.restraintDurationAndUnitString = str
          + CuramConst.gkSpace
          + CodeTable.getOneItem(RESTRAINTTIMEUNITS.TABLENAME,
          incidentRestraintDetails.dtls.durationUnitCode);
      }

      incidentRestraintDetails.dtls.typeCode = incidentRestraintObj.getRestraintType().getCode();
      incidentRestraintDetails.dtls.recordStatus = incidentRestraintObj.getStatus().getCode();
      incidentRestraintDetails.dtls.versionNo = incidentRestraintObj.getVersionNo();

      if (RECORDSTATUSEntry.CANCELLED.getCode().equals(
        incidentRestraintDetails.dtls.recordStatus)) {
        incidentRestraintDetails.statusInd = true;
      }

      getParticipantName(incidentRestraintDetails, key);

      incidentRestraintDetailsList.dtls.addRef(incidentRestraintDetails);
    }

    return incidentRestraintDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public void modifyIncidentRestraint(
    IncidentRestraintDetails incidentRestraintDetails)
    throws AppException, InformationalException {

    IncidentRestraint incidentRestraintObj = incidentRestraintDAO.get(
      incidentRestraintDetails.dtls.incidentRestraintID);
    Incident incidentObj = incidentDAO.get(
      incidentRestraintDetails.dtls.incidentID);

    incidentRestraintObj.setIncident(incidentObj);
    incidentRestraintObj.setByWhomParticipantRoleID(
      incidentRestraintDetails.dtls.byWhomParticipantRoleID);
    incidentRestraintObj.setOnWhomParticipantRoleID(
      incidentRestraintDetails.dtls.onWhomParticipantRoleID);
    incidentRestraintObj.setDuration(incidentRestraintDetails.dtls.duration);
    incidentRestraintObj.setDurationUnit(
      RESTRAINTTIMEUNITSEntry.get(
        incidentRestraintDetails.dtls.durationUnitCode));
    incidentRestraintObj.setRestraintType(
      INCIDENTRESTRAINTTYPEEntry.get(incidentRestraintDetails.dtls.typeCode));
    incidentRestraintObj.modify(incidentRestraintDetails.dtls.versionNo);

  }

  /**
   * {@inheritDoc}
   */
  public void maintainIncidentRestraint(
    IncidentRestraintDetails incidentRestraintDetails)
    throws AppException, InformationalException {

    IncidentRestraint incidentRestraintObj = incidentRestraintDAO.get(
      incidentRestraintDetails.dtls.incidentRestraintID);
    Incident incidentObj = incidentDAO.get(
      incidentRestraintDetails.dtls.incidentID);

    incidentRestraintObj.setIncident(incidentObj);
    incidentRestraintObj.setByWhomParticipantRoleID(
      incidentRestraintDetails.dtls.byWhomParticipantRoleID);
    incidentRestraintObj.setOnWhomParticipantRoleID(
      incidentRestraintDetails.dtls.onWhomParticipantRoleID);
    incidentRestraintObj.setDuration(incidentRestraintDetails.dtls.duration);
    incidentRestraintObj.setDurationUnit(
      RESTRAINTTIMEUNITSEntry.get(
        incidentRestraintDetails.dtls.durationUnitCode));
    incidentRestraintObj.setRestraintType(
      INCIDENTRESTRAINTTYPEEntry.get(incidentRestraintDetails.dtls.typeCode));
    incidentRestraintObj.modify(incidentRestraintDetails.dtls.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public IncidentRestraintDetails viewIncidentRestraint(
    IncidentRestraintKey key) throws AppException,
      InformationalException {

    IncidentRestraintDetails incidentRestraintDetails = new IncidentRestraintDetails();

    IncidentRestraint incidentRestraintObj = incidentRestraintDAO.get(
      key.incidentRestraintID);

    incidentRestraintDetails.dtls.incidentID = key.incidentID;
    incidentRestraintDetails.dtls.incidentRestraintID = key.incidentRestraintID;

    incidentRestraintDetails.dtls.byWhomParticipantRoleID = incidentRestraintObj.getByWhomParticipantRoleID();
    incidentRestraintDetails.dtls.onWhomParticipantRoleID = incidentRestraintObj.getOnWhomParticipantRoleID();
    incidentRestraintDetails.dtls.duration = incidentRestraintObj.getDuration();
    incidentRestraintDetails.dtls.durationUnitCode = incidentRestraintObj.getDurationUnit().getCode();
    incidentRestraintDetails.dtls.typeCode = incidentRestraintObj.getRestraintType().getCode();

    incidentRestraintDetails.dtls.recordStatus = incidentRestraintObj.getStatus().getCode();
    incidentRestraintDetails.dtls.versionNo = incidentRestraintObj.getVersionNo();

    getParticipantName(incidentRestraintDetails, key);

    return incidentRestraintDetails;
  }

  // BEGIN, CR00313834, GA  
  /**
   * List active participant and active provider member for an incident.
   * 'By Whom' can be provider members associated with the provider or a
   * incident participants. If provider members is already an incident
   * participant, then provider member will be listed in their role as a
   * participant and not in their role as a PROVIDER MEMBER.
   *
   * @param key
   * Contains incidentID and concernRoleID.
   *
   * @return List of by whom participants.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.3.0, replaced by {@link MaintainIncidentRestraint#listByWhomParticipants()}.
   * This method is deprecated because the name of the method does not match its functionality and conveys a wrong meaning. It
   * returns a list of participants, but the method name is listByWhomParticipant(). See release note : CR00313834.
   */
  @Deprecated
  // END, CR00313834
  public ByWhomParticipantDetailsList listByWhomParticipant(
    ByWhomParticipantKey key) throws AppException,
      InformationalException {

    ByWhomParticipantDetailsList byWhomParticipantDetailsList = new ByWhomParticipantDetailsList();

    IncidentParticipantDetailsList incidentParticipantDetailsList = new IncidentParticipantDetailsList();

    IncidentKey incidentKey = new IncidentKey();

    incidentKey.incidentID = key.incidentID;

    Incidents incidentsObj = IncidentsFactory.newInstance();

    incidentParticipantDetailsList = incidentsObj.listIncidentActiveParticipantRole(
      incidentKey);

    // Get list of incident participants
    for (IncidentParticipantDetails incidentParticipantDetails :
      incidentParticipantDetailsList.dtlsList) {

      ByWhomParticipantDetails byWhomParticipantDetails = new ByWhomParticipantDetails();

      byWhomParticipantDetails.incidentParticipantID = incidentParticipantDetails.incidentParticipantRoleID;
      byWhomParticipantDetails.participantName = incidentParticipantDetails.participantName;
      byWhomParticipantDetails.participantConcernRoleID = incidentParticipantDetails.concernRoleID;

      byWhomParticipantDetailsList.dtls.addRef(byWhomParticipantDetails);
    }

    // Get list of provider members
    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      key.concernRoleID);

    for (ProviderMember providerMember : providerOrganization.getProviderMembers()) {

      if (providerMember.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)
        && (!providerMember.getDateRange().isEnded()
          || !providerMember.getDateRange().endsInPast())) {

        ByWhomParticipantDetails byWhomParticipantDetails = new ByWhomParticipantDetails();

        byWhomParticipantDetails.incidentParticipantID = providerMember.getParty().getID();
        byWhomParticipantDetails.participantName = providerMember.getParty().getName();
        byWhomParticipantDetails.participantConcernRoleID = providerMember.getParty().getID();

        // Add only those provider member which are not participants
        boolean memberExitsAsParticinantInd = false;

        for (IncidentParticipantDetails incidentParticipantDetails :
          incidentParticipantDetailsList.dtlsList) {

          if (0 != incidentParticipantDetails.concernRoleID
            && incidentParticipantDetails.concernRoleID
              == providerMember.getParty().getID()) {

            memberExitsAsParticinantInd = true;
            break;
          }
        }

        if (!memberExitsAsParticinantInd) {

          byWhomParticipantDetailsList.dtls.addRef(byWhomParticipantDetails);
        }
      }
    }

    // Sort the incident participant roles by participant name
    Collections.sort(byWhomParticipantDetailsList.dtls,
      new Comparator<ByWhomParticipantDetails>() {

      public int compare(ByWhomParticipantDetails lhs,
        ByWhomParticipantDetails rhs) {

        return lhs.participantName.compareToIgnoreCase(rhs.participantName);
      }
    });

    return byWhomParticipantDetailsList;
  }
  
  // BEGIN, CR00313834, GA 
  /**
   * {@inheritDoc}
   */
  public ByWhomParticipantDetailsList listByWhomParticipants(
    final IncidentRestraintKey key) throws AppException,
      InformationalException {

    final ByWhomParticipantDetailsList byWhomParticipantDetailsList = new ByWhomParticipantDetailsList();

    IncidentParticipantDetailsList incidentParticipantDetailsList = new IncidentParticipantDetailsList();

    final IncidentKey incidentKey = new IncidentKey();

    incidentKey.incidentID = key.incidentID;

    Incidents incidentsObj = IncidentsFactory.newInstance();

    incidentParticipantDetailsList = incidentsObj.listIncidentActiveParticipantRole(
      incidentKey);

    // Get list of incident participants.
    for (final IncidentParticipantDetails incidentParticipantDetails :
      incidentParticipantDetailsList.dtlsList) {

      ByWhomParticipantDetails byWhomParticipantDetails = new ByWhomParticipantDetails();

      byWhomParticipantDetails.incidentParticipantID = incidentParticipantDetails.incidentParticipantRoleID;
      byWhomParticipantDetails.participantName = incidentParticipantDetails.participantName;
      byWhomParticipantDetails.participantConcernRoleID = incidentParticipantDetails.concernRoleID;

      byWhomParticipantDetailsList.dtls.addRef(byWhomParticipantDetails);
    }

    // Get list of provider members.
    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      key.concernRoleID);

    for (ProviderMember providerMember : providerOrganization.getProviderMembers()) {

      if (providerMember.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)
        && (!providerMember.getDateRange().isEnded()
          || !providerMember.getDateRange().endsInPast())) {

        ByWhomParticipantDetails byWhomParticipantDetails = new ByWhomParticipantDetails();

        byWhomParticipantDetails.incidentParticipantID = providerMember.getParty().getID();
        byWhomParticipantDetails.participantName = providerMember.getParty().getName();
        byWhomParticipantDetails.participantConcernRoleID = providerMember.getParty().getID();

        // Add only those provider member which are not participants.
        boolean memberExitsAsParticinantInd = false;

        for (final IncidentParticipantDetails incidentParticipantDetails :
          incidentParticipantDetailsList.dtlsList) {

          if (0 != incidentParticipantDetails.concernRoleID
            && incidentParticipantDetails.concernRoleID
              == providerMember.getParty().getID()) {

            memberExitsAsParticinantInd = true;
            break;
          }
        }

        if (!memberExitsAsParticinantInd) {

          byWhomParticipantDetailsList.dtls.addRef(byWhomParticipantDetails);
        }
      }
    }

    // Sort the incident participant roles by participant name.
    Collections.sort(byWhomParticipantDetailsList.dtls,
      new Comparator<ByWhomParticipantDetails>() {

      public int compare(ByWhomParticipantDetails lhs,
        ByWhomParticipantDetails rhs) {

        return lhs.participantName.compareToIgnoreCase(rhs.participantName);
      }
    });

    return byWhomParticipantDetailsList;
  }

  // END, CR00313834 
  
  /**
   * Method to populate participant name.
   * By Whom can be provider members associated with the provider or incident
   * participants.
   *
   * @param IncidentRestraintDetails
   * incident restraint details
   * @param key
   * contains incidentID and concernRoleID
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void getParticipantName(
    IncidentRestraintDetails incidentRestraintDetails,
    IncidentRestraintKey key) throws AppException,
      InformationalException {

    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    // By Whom can be a provider member or incident participant.
    // If By Whom is incident participant
    if (0 != incidentRestraintDetails.dtls.byWhomParticipantRoleID) {

      boolean isParticipantInd = getIsParticipantInd(incidentRestraintDetails);

      if (isParticipantInd) {

        IncidentParticipant incidentParticipantObj = incidentParticipantDAO.get(
          incidentRestraintDetails.dtls.byWhomParticipantRoleID);

        if (0 == incidentParticipantObj.getConcernRoleID()) {
          usersKey.userName = incidentParticipantObj.getUserName();
          incidentRestraintDetails.byWhomParticipantName = userAccessObj.getFullName(usersKey).fullname;
        } else {
          concernRoleKey.concernRoleID = incidentParticipantObj.getConcernRoleID();
          incidentRestraintDetails.byWhomParticipantName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
        }
        // If By Whom is provider member.
      } else {

        ProviderOrganization providerOrganization = providerOrganizationDAO.get(
          key.concernRoleID);

        for (ProviderMember providerMember : providerOrganization.getProviderMembers()) {
          if (incidentRestraintDetails.dtls.byWhomParticipantRoleID
            == providerMember.getParty().getID()) {
            incidentRestraintDetails.byWhomParticipantName = providerMember.getParty().getName();
          }
        }
      }
    }
    // On whom incident participant
    if (0 != incidentRestraintDetails.dtls.onWhomParticipantRoleID) {

      IncidentParticipant incidentOnWhomParticipantObj = incidentParticipantDAO.get(
        incidentRestraintDetails.dtls.onWhomParticipantRoleID);

      if (0 == incidentOnWhomParticipantObj.getConcernRoleID()) {
        usersKey.userName = incidentOnWhomParticipantObj.getUserName();
        incidentRestraintDetails.onWhomParticipantName = userAccessObj.getFullName(usersKey).fullname;
      } else {
        concernRoleKey.concernRoleID = incidentOnWhomParticipantObj.getConcernRoleID();
        incidentRestraintDetails.onWhomParticipantName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
      }
    }
  }

  /**
   * Method to determine if by whom participant role as participant or
   * provider member.
   *
   * @param IncidentRestraintDetails
   * Details of the Restraint
   *
   * @return boolean true if role as participant
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected boolean getIsParticipantInd(
    IncidentRestraintDetails incidentRestraintDetails)
    throws AppException, InformationalException {

    boolean isParticipantInd = false;

    Incident incidentObj = incidentDAO.get(
      incidentRestraintDetails.dtls.incidentID);

    Set<IncidentParticipant> incidentParticipants = incidentParticipantDAO.searchByIncident(
      incidentObj);

    for (IncidentParticipant incidentParticipantObj : incidentParticipants) {

      if (incidentParticipantObj.getID()
        == incidentRestraintDetails.dtls.byWhomParticipantRoleID) {
        isParticipantInd = true;
      }
    }
    return isParticipantInd;
  }
}
