/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import com.google.inject.Inject;
import curam.codetable.impl.CONTRACTTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.contracts.impl.ContractVersionProviderOffering;
import curam.contracts.impl.ContractVersionProviderOfferingDAO;
import curam.contracts.impl.FlatRateContract;
import curam.contracts.impl.FlatRateContractDAO;
import curam.core.facade.struct.CaseParticipantRoleKey;
import curam.core.sl.infrastructure.widgetUtility.impl.XMLBuilder;
import curam.core.struct.InformationalMsgDtls;
import curam.cpm.facade.struct.ListProviderDetailsKey;
import curam.cpm.facade.struct.ParticipantAddressesXML;
import curam.cpm.facade.struct.ProviderBackgroundCheckDetails;
import curam.cpm.facade.struct.ProviderBackgroundCheckDetailsList;
import curam.cpm.facade.struct.ProviderBackgroundCheckSummaryDetails;
import curam.cpm.facade.struct.ProviderMapDetails;
import curam.cpm.facade.struct.ProviderMemberOverviewDetails;
import curam.cpm.facade.struct.ProviderMemberOverviewDetailsList;
import curam.cpm.facade.struct.ProviderOfferingRateDetailsList;
import curam.cpm.facade.struct.ProviderServiceRateDetails;
import curam.cpm.facade.struct.ProviderViewDetails;
import curam.cpm.facade.struct.ServiceCriterionEvaluationSummary;
import curam.cpm.facade.struct.ServiceCriterionEvaluationSummaryList;
import curam.cpm.facade.struct.ServiceEvaluationList;
import curam.cpm.facade.struct.ServiceEvaluationListDetails;
import curam.cpm.facade.struct.ServiceOfferingKey;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.BackgroundCheckFailureReasonDtls;
import curam.cpm.sl.entity.struct.ProviderBackgroundCheckKey;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ProviderPartyKey;
import curam.cpm.util.impl.DomUtils;
import curam.cpm.util.impl.ServiceDeliveryFacadeHelper;
import curam.message.impl.SERVICEDELIVERYEVALUATIONExceptionCreator;
import curam.participant.impl.PhoneNumber;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.casemanager.impl.CaseParticipantRoleDAO;
import curam.piwrapper.impl.Address;
import curam.piwrapper.impl.AddressDAO;
import curam.piwrapper.impl.EmailAddress;
import curam.piwrapper.webaddress.impl.WebAddress;
import curam.provider.impl.BackgroundCheckFailureReason;
import curam.provider.impl.License;
import curam.provider.impl.LicenseDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderAccreditation;
import curam.provider.impl.ProviderAccreditationTypeEntry;
import curam.provider.impl.ProviderBackgroundCheck;
import curam.provider.impl.ProviderBackgroundCheckDAO;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderMember;
import curam.provider.impl.ProviderMemberDAO;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.provider.impl.ProviderParty;
import curam.provider.impl.ProviderPartyDAO;
import curam.provider.impl.ProviderServiceCenter;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingRate;
import curam.providerservice.impl.ProviderOfferingRateDAO;
import curam.servicedelivery.impl.CuramConst;
import curam.servicedeliveryevaluation.impl.ServiceDeliveryEvaluation;
import curam.servicedeliveryevaluation.impl.ServiceDeliveryEvaluationDAO;
import curam.serviceevaluationcriterion.impl.SECRESPONSEVALUEEntry;
import curam.serviceoffering.impl.SOEvaluationCriterion;
import curam.serviceoffering.impl.SOEvaluationCriterionDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.InformationalElement.InformationalType;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.LifecycleHelper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.StringHelper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


/**
 * Facade operations for a registered Provider in CPM. This facade may be merged
 * back into existing CPM facade API's.
 *
 * @since 6.0
 */
public class ProviderAccess extends curam.cpm.facade.base.ProviderAccess {

  /**
   * Reference to Service Delivery facade helper instance.
   */
  @Inject
  protected com.google.inject.Provider<ServiceDeliveryFacadeHelper> serviceDeliveryFacadeHelperProvider;

  /**
   * Reference to Provider Party DAO.
   */
  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  /**
   * Reference to Provider Background Check DAO.
   */
  @Inject
  protected ProviderBackgroundCheckDAO providerBackgroundCheckDAO;

  /**
   * Reference to Provider Organization DAO.
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Reference to Provider Member DAO.
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  /**
   * Reference to Provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to Address DAO.
   */
  @Inject
  protected AddressDAO addressDAO;

  /**
   * Reference to License DAO.
   */
  @Inject
  protected LicenseDAO licenseDAO;

  /**
   * Reference to Contract Version Provider Offering DAO.
   */
  @Inject
  protected ContractVersionProviderOfferingDAO contractVersionProviderOfferingDAO;

  /**
   * Reference to Flat Rate Contract DAO.
   */
  @Inject
  protected FlatRateContractDAO flatRateContractDAO;

  /**
   * Reference to Provider Offering DAO.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Reference to Provider Offering Rate DAO.
   */
  @Inject
  protected ProviderOfferingRateDAO providerOfferingRateDAO;

  /**
   * Reference to Service Offering DAO.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Reference to Case Participant Role DAO.
   */
  @Inject
  protected CaseParticipantRoleDAO caseParticipantRoleDAO;

  /**
   * Reference to Service Delivery Evaluation DAO.
   */
  @Inject
  protected ServiceDeliveryEvaluationDAO serviceDeliveryEvaluationDAO;

  /**
   * Reference to Service Offering Evaluation Criterion DAO.
   */
  @Inject
  protected SOEvaluationCriterionDAO soEvaluationCriterionDAO;

  /**
   * Constructor.
   */
  protected ProviderAccess() {
    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderMemberOverviewDetailsList listProviderStaff(
    final ProviderKey providerKey) throws AppException,
      InformationalException {
    ProviderMemberOverviewDetailsList providerMemberOverviewDetailsList = new ProviderMemberOverviewDetailsList();

    ProviderMemberOverviewDetails providerMemberOverviewDetails;

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      providerKey.providerConcernRoleID);

    Set<ProviderMember> providerMembersForProvider = providerMemberDAO.searchBy(
      providerOrganization);

    for (ProviderMember providerMember : providerMembersForProvider) {
      providerMemberOverviewDetails = new ProviderMemberOverviewDetails();
      providerMemberOverviewDetails.memberName = providerMember.getParty().getName();
      providerMemberOverviewDetails.fromDate = providerMember.getDateRange().start();
      providerMemberOverviewDetails.toDate = providerMember.getDateRange().end();
      providerMemberOverviewDetails.role = providerMember.getRole().getCode();
      providerMemberOverviewDetails.memberConcernRoleID = providerMember.getParty().getID();
      providerMemberOverviewDetails.concernRoleType = providerMember.getParty().getConcernRoleType().getCode();
      providerMemberOverviewDetails.providerMemberID = providerMember.getID();
      if (providerBackgroundCheckDAO.searchByProviderMember(providerMember).size()
        > 0) {
        providerMemberOverviewDetails.backgroundChecksExistInd = true;
      }
      providerMemberOverviewDetailsList.memberDetails.addRef(
        providerMemberOverviewDetails);
    }
    return providerMemberOverviewDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ListProviderDetailsKey setProviderSearchCriteria(
    final ListProviderDetailsKey key) throws AppException,
      InformationalException {
    return key;
  }

  /**
   * {@inheritDoc}
   */
  // TODO: (JG)consider moving this into the ProviderBackgroundCheck facade API
  // when
  // moving service delivery back to CPM.
  public ProviderBackgroundCheckDetailsList viewBackgroundChecksForProviderMember(
    final ProviderPartyKey providerMemberKey) throws AppException,
      InformationalException {

    ProviderBackgroundCheckDetailsList providerBackgroundCheckDetailsList = new ProviderBackgroundCheckDetailsList();
    ProviderParty providerParty = providerPartyDAO.get(
      providerMemberKey.providerPartyID);

    Set<ProviderBackgroundCheck> memberBackgroundChecks = LifecycleHelper.filter(
      providerBackgroundCheckDAO.searchByProviderMember(providerParty),
      RECORDSTATUSEntry.NORMAL);

    ProviderBackgroundCheckDetails providerBackgroundCheckDetails;

    for (ProviderBackgroundCheck providerBackgroundCheck : memberBackgroundChecks) {
      providerBackgroundCheckDetails = new ProviderBackgroundCheckDetails();
      providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerBackgroundCheckID = providerBackgroundCheck.getID();
      providerBackgroundCheckDetails.providerBackgroundCheckDtls.result = providerBackgroundCheck.getResult().getCode();
      providerBackgroundCheckDetails.providerBackgroundCheckDtls.type = providerBackgroundCheck.getType().getCode();
      providerBackgroundCheckDetailsList.providerBackgroundCheckDetails.addRef(
        providerBackgroundCheckDetails);
    }
    return providerBackgroundCheckDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  // TODO: (JG)consider moving this into the ProviderBackgroundCheck facade API
  // when
  // moving service delivery back to CPM.
  public ProviderBackgroundCheckSummaryDetails viewBackgroundCheck(
    final ProviderBackgroundCheckKey providerBackgroundCheckKey)
    throws AppException, InformationalException {
    ProviderBackgroundCheckSummaryDetails providerBackgroundCheckSummaryDetails = new ProviderBackgroundCheckSummaryDetails();

    final curam.provider.impl.ProviderBackgroundCheck providerBackgroundCheck = providerBackgroundCheckDAO.get(
      providerBackgroundCheckKey.providerBackgroundCheckID);

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.requestDate = providerBackgroundCheck.getDateRange().start();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.receiptDate = providerBackgroundCheck.getDateRange().end();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.expiryDate = providerBackgroundCheck.getExpiryDate();

    Set<BackgroundCheckFailureReason> unModifiableBackgroundCheckFailureReasons = LifecycleHelper.filter(
      providerBackgroundCheck.getProviderBackgroundCheckFailureReasons(),
      RECORDSTATUSEntry.NORMAL);
    Set<BackgroundCheckFailureReason> backgroundCheckFailureReasons = new HashSet<BackgroundCheckFailureReason>();

    backgroundCheckFailureReasons.addAll(
      unModifiableBackgroundCheckFailureReasons);

    for (final curam.provider.impl.BackgroundCheckFailureReason backgroundCheckFailureReason : sortBackgroundCheckFailureReasonByDate(
      backgroundCheckFailureReasons)) {
      providerBackgroundCheckSummaryDetails.backgroundCheckFailureReasonsList.backgroundCheckFailureReason.addRef(
        getProviderbackgroundCheckFailureReasonFieldsForList(
          backgroundCheckFailureReason));

    }

    return providerBackgroundCheckSummaryDetails;
  }

  /**
   * This method returns Provider background Check FailureReason details for
   * user display.
   *
   * @param backgroundCheckFailureReason
   * backgroundCheckFailureReason
   * @return backgroundCheckFailureReasonDtls struct containing the fields for
   * display
   */
  protected BackgroundCheckFailureReasonDtls getProviderbackgroundCheckFailureReasonFieldsForList(
    final curam.provider.impl.BackgroundCheckFailureReason backgroundCheckFailureReason) {

    BackgroundCheckFailureReasonDtls backgroundCheckFailureReasonDtls = new BackgroundCheckFailureReasonDtls();

    backgroundCheckFailureReasonDtls.backgroundCheckFailureReasonID = backgroundCheckFailureReason.getID();

    backgroundCheckFailureReasonDtls.failureReason = backgroundCheckFailureReason.getFailureReason();

    backgroundCheckFailureReasonDtls.occurrenceDate = backgroundCheckFailureReason.getOccurrenceDate();
    return backgroundCheckFailureReasonDtls;
  }

  /**
   * Sorts a set of BackgroundCheckFailureReasons by date.
   *
   * @param unsortBackgroundCheckFailureReasons
   * a set of BackgroundCheckFailureReasons.
   * @return a sorted list of BackgroundCheckFailureReasons for display.
   */
  protected List<curam.provider.impl.BackgroundCheckFailureReason> sortBackgroundCheckFailureReasonByDate(
    final Set<curam.provider.impl.BackgroundCheckFailureReason> unsortBackgroundCheckFailureReasons) {

    // Sort by Start Date descending order for display - using a list (instead
    // of a set)
    final List<curam.provider.impl.BackgroundCheckFailureReason> backgroundCheckFailureReasons = new ArrayList<curam.provider.impl.BackgroundCheckFailureReason>(
      unsortBackgroundCheckFailureReasons);

    Collections.sort(backgroundCheckFailureReasons,
      new Comparator<curam.provider.impl.BackgroundCheckFailureReason>() {
      public int compare(
        final curam.provider.impl.BackgroundCheckFailureReason lhs,
        final curam.provider.impl.BackgroundCheckFailureReason rhs) {
        return rhs.getOccurrenceDate().compareTo(lhs.getOccurrenceDate());
      }
    });
    return backgroundCheckFailureReasons;

  }

  /**
   * {@inheritDoc}
   */
  public ProviderViewDetails viewProviderOverview(
    final ProviderConcernRoleKey providerKey,
    final ServiceOfferingKey serviceOfferingKey) throws AppException,
      InformationalException {
    ProviderViewDetails providerViewDetails = new ProviderViewDetails();

    curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);
    ServiceOffering serviceOffering = serviceOfferingDAO.get(
      serviceOfferingKey.key.key.serviceOfferingID);

    populateEmailAddress(providerViewDetails, provider);
    providerViewDetails.phoneNumber = populatePhoneNumber(provider);
    WebAddress webAddress = provider.getWebAddress();

    if (webAddress != null && webAddress.getID() != 0) {
      providerViewDetails.websiteAddress = webAddress.getWebAddress();
      providerViewDetails.webAddressLink = providerViewDetails.websiteAddress;
    }
    providerViewDetails.accreditationsListString = populateAccreditations(
      provider);

    providerViewDetails.serviceCentersListString = populateProviderServiceCenters(
      provider);

    providerViewDetails.servicesListString = populateServices(provider,
      serviceOffering);

    providerViewDetails.licensesListString = populateLicenses(provider);
    return providerViewDetails;
  }

  /**
   * Populates the list of licenses for the provider.
   *
   * @param provider
   * the provider instance
   * @return the provider's licenses populated in a comma delimited string
   */
  protected String populateLicenses(final curam.provider.impl.Provider provider) {
    StringBuffer strBuf;
    Set<License> licenses = licenseDAO.searchLicensesByProvider(provider);

    strBuf = new StringBuffer();
    for (License license : licenses) {
      if (0 != strBuf.length()) {
        strBuf.append(CuramConst.gkComma).append(CuramConst.gkSpace);
      }
      strBuf.append(license.getLicenseType().toUserLocaleString());
    }
    return strBuf.toString();
  }

  /**
   * Populates the list of other services for the provider.
   *
   * @param provider
   * the provider instance
   * @param serviceOffering
   * the service offering instance
   * @return the provider's other services populated in a comma delimited string
   */
  protected String populateServices(
    final curam.provider.impl.Provider provider,
    final ServiceOffering serviceOffering) {
    StringBuffer strBuf;
    Set<ServiceOffering> serviceOfferings = provider.getServiceOfferings();

    strBuf = new StringBuffer();
    for (ServiceOffering providerServiceOffering : serviceOfferings) {
      if (providerServiceOffering != serviceOffering) {
        if (0 != strBuf.length()) {
          strBuf.append(CuramConst.gkComma).append(CuramConst.gkSpace);
        }
        strBuf.append(providerServiceOffering.getName());
      }
    }
    return strBuf.toString();
  }

  /**
   * Populates the list of service centers for the provider.
   *
   * @param provider
   * the provider instance
   * @return the service centers populated in a comma delimited string
   */
  protected String populateProviderServiceCenters(
    final curam.provider.impl.Provider provider) {
    StringBuffer strBuf;
    Set<ProviderServiceCenter> serviceCenters = provider.getProviderServiceCenters();

    strBuf = new StringBuffer();
    for (ProviderServiceCenter providerServiceCenter : serviceCenters) {
      if (0 != strBuf.length()) {
        strBuf.append(CuramConst.gkComma).append(CuramConst.gkSpace);
      }
      strBuf.append(providerServiceCenter.getName());
    }
    return strBuf.toString();
  }

  /**
   * Populates the list of accreditations for the provider.
   *
   * @param provider
   * the provider instance
   * @return the accreditations populated in a comma delimited string
   */
  protected String populateAccreditations(
    final curam.provider.impl.Provider provider) {
    Set<ProviderAccreditation> accredidations = provider.getAccreditations();
    StringBuffer strBuf = new StringBuffer();

    for (ProviderAccreditation providerAccreditation : accredidations) {
      if (0 != strBuf.length()) {
        strBuf.append(CuramConst.gkComma).append(CuramConst.gkSpace);
      }
      strBuf.append(
        ProviderAccreditationTypeEntry.get(providerAccreditation.getType()).toUserLocaleString());
    }
    return strBuf.toString();
  }

  /**
   * Populates the provider's email address and link data.
   *
   * @param providerViewDetails
   * the details to populate with the email address data
   * @param provider
   * the provider instance
   */
  protected void populateEmailAddress(
    final ProviderViewDetails providerViewDetails,
    final curam.provider.impl.Provider provider) {
    EmailAddress emailAddress = provider.getEmailAddress();

    if (null != emailAddress) {
      providerViewDetails.emailAddress = provider.getEmailAddress().getEmail();
      providerViewDetails.emailAddressLink = CuramConst.kMailLink
        + provider.getEmailAddress().getEmail();
    }
  }

  /**
   * Populates the provider's phone number string.
   *
   * @param provider
   * provider instance
   * @return phone number string
   */
  protected String populatePhoneNumber(
    final curam.provider.impl.Provider provider) {
    PhoneNumber phoneNumber = provider.getPrimaryPhoneNumber();

    if (null != phoneNumber) {
      StringBuffer phoneNumberString = new StringBuffer();

      phoneNumberString.append(provider.getPrimaryPhoneNumber().getCountryCode()).append(CuramConst.gkDash).append(provider.getPrimaryPhoneNumber().getAreaCode()).append(CuramConst.gkDash).append(
        provider.getPrimaryPhoneNumber().getNumber());
      return phoneNumberString.toString();
    }
    return CuramConst.gkEmpty;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderOfferingRateDetailsList viewProviderServiceRates(
    final ProviderKey providerKey, final ServiceOfferingKey serviceKey)
    throws AppException, InformationalException {
    ProviderOfferingRateDetailsList providerOfferingRateDetailsList = new ProviderOfferingRateDetailsList();

    Set<ProviderOffering> providerOfferings = providerOfferingDAO.searchProviderOffering(
      providerKey.providerConcernRoleID, serviceKey.key.key.serviceOfferingID);

    for (ProviderOffering providerOffering : providerOfferings) {
      Set<ProviderOfferingRate> rates = providerOfferingRateDAO.searchBy(
        providerOffering);
      ProviderServiceRateDetails providerServiceRateDetails;

      for (ProviderOfferingRate rate : rates) {
        providerServiceRateDetails = new ProviderServiceRateDetails();
        providerServiceRateDetails.rateDetails.startDate = rate.getDateRange().start();
        providerServiceRateDetails.rateDetails.endDate = rate.getDateRange().end();
        if (rate.getFixedAmount().isNegative()) {
          providerServiceRateDetails.rateDetails.fixedAmountString = CuramConst.gkEmpty;
        } else {
          providerServiceRateDetails.rateDetails.fixedAmountString = rate.getFixedAmount().toString();
        }
        if (rate.getMaxAmount().isNegative()) {
          providerServiceRateDetails.rateDetails.maxAmountString = CuramConst.gkEmpty;
        } else {
          providerServiceRateDetails.rateDetails.maxAmountString = rate.getMaxAmount().toString();
        }
        if (rate.getMinAmount().isNegative()) {
          providerServiceRateDetails.rateDetails.minAmountString = CuramConst.gkEmpty;
        } else {
          providerServiceRateDetails.rateDetails.minAmountString = rate.getMinAmount().toString();
        }
        providerServiceRateDetails.rateDetails.type = rate.getProviderOfferingRateType().toUserLocaleString();
        providerOfferingRateDetailsList.ratesList.addRef(
          providerServiceRateDetails);
      }
      Set<ContractVersionProviderOffering> contractVersionProviderOfferings = contractVersionProviderOfferingDAO.searchBy(
        providerOffering);

      for (ContractVersionProviderOffering contractVersionProviderOffering : contractVersionProviderOfferings) {
        if (contractVersionProviderOffering.getContractVersion().getContractType().equals(
          CONTRACTTYPEEntry.FLATRATE)) {
          providerServiceRateDetails = new ProviderServiceRateDetails();
          FlatRateContract flatRateContract = flatRateContractDAO.get(
            contractVersionProviderOffering.getContractVersion().getID());

          providerServiceRateDetails.rateDetails.type = contractVersionProviderOffering.getContractVersion().getContractType().toUserLocaleString();
          providerServiceRateDetails.rateDetails.startDate = contractVersionProviderOffering.getContractVersion().getDateRange().start();
          providerServiceRateDetails.rateDetails.endDate = contractVersionProviderOffering.getContractVersion().getDateRange().end();
          providerServiceRateDetails.flatRateDescription = getFlatRateDescription(
            flatRateContract);
          providerOfferingRateDetailsList.ratesList.addRef(
            providerServiceRateDetails);
        }
      }
    }
    return providerOfferingRateDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderMapDetails viewProviderMap(final ProviderKey providerKey)
    throws AppException, InformationalException {

    Provider provider = providerDAO.get(providerKey.providerConcernRoleID);
    ProviderMapDetails mapDetails = new ProviderMapDetails();
    Address address = addressDAO.get(provider.getPrimaryAddressID());

    XMLBuilder xmlBuilder = new XMLBuilder(CuramConst.gkMap);

    xmlBuilder.addAttribute(CuramConst.gkDomain, CuramConst.gkGoogleMapXML);

    xmlBuilder.createTag(CPMConstants.kCONFIG);
    xmlBuilder.addAttribute(CPMConstants.kZOOM_LEVEL, CPMConstants.k16);
    xmlBuilder.addAttribute(CPMConstants.kSHOW_DIRECTIONS, CPMConstants.kTRUE);
    // </config>
    xmlBuilder.closeTag();

    xmlBuilder.createTag(CuramConst.gkData);

    xmlBuilder.createTag(CuramConst.gkMapAddress);
    xmlBuilder.addAttribute(CuramConst.gkLatitude,
      String.valueOf(address.getLatitude()));
    xmlBuilder.addAttribute(CuramConst.gkLongitude,
      String.valueOf(address.getLongitude()));
    xmlBuilder.createTag(CuramConst.gkIcon);
    xmlBuilder.addAttribute(CPMConstants.kWIDTH, CPMConstants.k20);
    xmlBuilder.addAttribute(CPMConstants.kHEIGHT, CPMConstants.k20);
    // </icon>
    xmlBuilder.closeTag();

    xmlBuilder.addTagData(address.getOneLineAddressString());

    // </address>
    xmlBuilder.closeTag();

    mapDetails.providerMapXML = xmlBuilder.getXmlString();
    return mapDetails;
  }

  /**
   * Constructs a description for a flat rate contract regular/fixed payment and
   * frequency.
   *
   * @param flatRateContract
   * the flatRateContract instance
   * @return description for the regular payment rate for the flat rate contract
   */
  protected String getFlatRateDescription(
    final FlatRateContract flatRateContract) {

    StringBuffer strBuf = new StringBuffer();

    if (!flatRateContract.getTotalContractAmt().isZero()) {
      strBuf.append(flatRateContract.getTotalContractAmt());
      if (!StringHelper.isEmpty(flatRateContract.getFrequency().toString())) {
        strBuf.append(CuramConst.gkRoundOpeningBracket).append(flatRateContract.getFrequency().toUserLocaleString()).append(
          CuramConst.gkRoundClosingBracket);
      }
    } else {
      strBuf.append(flatRateContract.getRegularPaymentAmt()).append(CuramConst.gkRoundOpeningBracket).append(flatRateContract.getFrequency().toUserLocaleString()).append(
        CuramConst.gkRoundClosingBracket);
    }
    return strBuf.toString();
  }

  /**
   * {@inheritDoc}
   */
  public ParticipantAddressesXML listAddressesXMLForServiceParticipant(
    final CaseParticipantRoleKey key) throws AppException,
      InformationalException {
    ParticipantAddressesXML participantAddressesXML = new ParticipantAddressesXML();

    // If no key is passed in, return an empty list
    if (key.dtls.caseParticipantRoleID == 0) {
      return participantAddressesXML;
    }
    // Create the xml required for the calendar
    Document xmlDocument = DomUtils.createNewDocument();
    Element root = xmlDocument.createElement(CPMConstants.KROOT);

    xmlDocument.appendChild(root);

    CaseParticipantRole caseParticipantRole = caseParticipantRoleDAO.get(
      key.dtls.caseParticipantRoleID);

    // Add an entry for each client
    for (Address address : addressDAO.listActiveAddressesByConcernRole(
      caseParticipantRole.getConcernRole())) {
      Element clientAddress = xmlDocument.createElement(
        CPMConstants.kCLIENT_ADDRESS);

      clientAddress.setAttribute(CPMConstants.kHIDDEN_VALUE,
        address.getID().toString());
      clientAddress.setAttribute(CPMConstants.kDISPLAY_VALUE,
        serviceDeliveryFacadeHelperProvider.get().getAddressTypeAndDataDetail(
        caseParticipantRole, address));
      root.appendChild(clientAddress);
    }

    participantAddressesXML.addressesXML = DomUtils.convertDocumentToText(
      xmlDocument);

    // BEGIN, CR00358830, SS
    participantAddressesXML.contentTypeOpt = CPMConstants.kCONTENT_TYPE;
    // END, CR00358830
    
    return participantAddressesXML;
  }

  /**
   * {@inheritDoc}
   */
  public ServiceEvaluationList listProviderEvaluationsForService(
    final ProviderKey providerKey, final ServiceOfferingKey serviceKey)
    throws AppException, InformationalException {
    ServiceEvaluationList serviceEvaluationList = new ServiceEvaluationList();

    Provider provider = providerDAO.get(providerKey.providerConcernRoleID);
    ServiceOffering serviceOffering = serviceOfferingDAO.get(
      serviceKey.key.key.serviceOfferingID);

    List<ServiceDeliveryEvaluation> providerEvaluationsForService = serviceDeliveryEvaluationDAO.searchActiveForProviderAndService(
      provider, serviceOffering);
    ServiceEvaluationListDetails listDetails;

    for (ServiceDeliveryEvaluation serviceDeliveryEvaluation : providerEvaluationsForService) {
      listDetails = new ServiceEvaluationListDetails();
      listDetails.dtls.createdBy = serviceDeliveryEvaluation.getCreatedBy().getID();
      listDetails.createdByFullName = serviceDeliveryEvaluation.getCreatedBy().getFullName();
      listDetails.dtls.creationDate = serviceDeliveryEvaluation.getCreationDate();
      listDetails.dtls.comments = serviceDeliveryEvaluation.getComments();
      listDetails.ratings = getCriterionEvaluationScoresData(
        serviceDeliveryEvaluation);
      serviceEvaluationList.listDetails.addRef(listDetails);
    }

    return serviceEvaluationList;
  }

  /**
   * Gets the evaluation scores for the {@link ServiceDeliveryEvaluation and returns a xml string
   * containing the criteria and their scores in the format:
   * <criteria>
   * <criterion name="criterionName" score="value"></criterion>
   * </criteria>.
   * @param serviceDeliveryEvaluation
   * service delivery evaluation object
   * @return xml formatted string of the evaluated criteria and their scores
   * @throws InformationalException
   * Generic Exception Signature
   */
  protected String getCriterionEvaluationScoresData(
    final ServiceDeliveryEvaluation serviceDeliveryEvaluation)
    throws InformationalException {
    Map<SOEvaluationCriterion, SECRESPONSEVALUEEntry> criteriaScoresMap = serviceDeliveryEvaluation.listCriterionEvaluationsForServiceDeliveryEvaluation();

    StringBuffer strBuf = new StringBuffer();

    for (SOEvaluationCriterion soEvaluationCriterion : criteriaScoresMap.keySet()) {
      if (0 != strBuf.length()) {
        strBuf.append(CuramConst.kNewLine);
      }
      strBuf.append(soEvaluationCriterion.getServiceEvaluationCriterion().getCriterion()).append(CuramConst.gkColon).append(CuramConst.gkSpace).append(
        criteriaScoresMap.get(soEvaluationCriterion).toUserLocaleString());
    }
    return strBuf.toString();
  }

  /**
   * {@inheritDoc}
   */
  public ServiceCriterionEvaluationSummaryList viewServiceEvaluationOverviewForProvider(
    final ProviderKey providerKey, final ServiceOfferingKey serviceOfferingKey)
    throws AppException, InformationalException {
    ServiceCriterionEvaluationSummaryList summaryList = new ServiceCriterionEvaluationSummaryList();

    Provider provider = providerDAO.get(providerKey.providerConcernRoleID);
    ServiceOffering serviceOffering = serviceOfferingDAO.get(
      serviceOfferingKey.key.key.serviceOfferingID);

    Map<SOEvaluationCriterion, Double> criteriaScoresMap = getAverageScoresForEvaluationCriterion(
      provider, serviceOffering);
    ServiceCriterionEvaluationSummary serviceCriterionEvaluationSummary;
    InformationalManager informationalManager;

    for (SOEvaluationCriterion soEvaluationCriterion : criteriaScoresMap.keySet()) {
      serviceCriterionEvaluationSummary = new ServiceCriterionEvaluationSummary();
      if (criteriaScoresMap.get(soEvaluationCriterion) != 0.0) {
        serviceCriterionEvaluationSummary.averageRatingScore = String.valueOf(
          criteriaScoresMap.get(soEvaluationCriterion));
      } else {
        informationalManager = TransactionInfo.getInformationalManager();

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          SERVICEDELIVERYEVALUATIONExceptionCreator.INF_XRV_AVERAGE_SCORE_NOT_APPLICABLE_FOR_CRITERIA_WITHOUT_RESPONSE_SCORES(),
          CuramConst.gkEmpty, InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

        String[] informationals = informationalManager.obtainInformationalAsString();

        for (String message : informationals) {
          InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

          informationalMsgDtls.informationMsgTxt = message;
          summaryList.infoMsgList.dtls.addRef(informationalMsgDtls);
        }
      }
      serviceCriterionEvaluationSummary.soCriterionDescription = soEvaluationCriterion.getServiceEvaluationCriterion().getComments();
      serviceCriterionEvaluationSummary.soCriterionName = soEvaluationCriterion.getServiceEvaluationCriterion().getCriterion();
      summaryList.summaryDtls.addRef(serviceCriterionEvaluationSummary);
    }
    return summaryList;
  }

  /**
   * Calculates the average score for each of the service criterion and returns
   * a map of the service criteria and average scores.
   *
   * @param provider
   * provider object for which evaluation scores are required
   * @param serviceOffering
   * service for which evaluation scores are required
   * @return map of the service criteria and their average scores
   */
  protected Map<SOEvaluationCriterion, Double> getAverageScoresForEvaluationCriterion(
    final Provider provider, final ServiceOffering serviceOffering) {
    // list of service evaluations carried out relative to the provider
    List<ServiceDeliveryEvaluation> providerServiceEvaluations = serviceDeliveryEvaluationDAO.searchActiveForProviderAndService(
      provider, serviceOffering);
    Map<SOEvaluationCriterion, Double> averageScores = new HashMap<SOEvaluationCriterion, Double>();

    if (0 == providerServiceEvaluations.size()) {
      return averageScores;
    }
    // set of configured criteria for the service
    Set<SOEvaluationCriterion> soEvaluationCriteria = soEvaluationCriterionDAO.searchByServiceOffering(
      serviceOffering);

    // iterate over all evaluations for each criterion, to get its average
    // score
    for (SOEvaluationCriterion soEvaluationCriterion : soEvaluationCriteria) {
      double runningScoreTotal = 0;
      int count = 0;

      for (ServiceDeliveryEvaluation serviceDeliveryEvaluation : providerServiceEvaluations) {
        // check if criterion was evaluated on this service evaluation
        Integer responseScore = serviceDeliveryEvaluation.getScoreForCriterionEvaluation(
          soEvaluationCriterion);

        if (0 != responseScore) {
          count++;
          runningScoreTotal += responseScore;
        }
      }
      if (runningScoreTotal != 0.0) {
        averageScores.put(soEvaluationCriterion, runningScoreTotal / count);
      } else {
        averageScores.put(soEvaluationCriterion, 0.0);
      }
    }
    return averageScores;
  }
}
