/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008,2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.eua.facade.impl;


import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.struct.ConcernRoleKey;
import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ProviderAccreditationDetails;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.facade.fact.ProviderAccreditationFactory;
import curam.cpm.facade.fact.ProviderFactory;
import curam.cpm.facade.intf.Provider;
import curam.cpm.facade.struct.ProviderAccreditationList;
import curam.cpm.facade.struct.ProviderAccreditationSummaryDetails;
import curam.cpm.facade.struct.ViewProviderSummaryDetails;
import curam.cpm.sl.entity.struct.ProviderAccreditationKey;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for Provider facade layer
 */
public abstract class ExternalProviderAccreditation extends curam.cpm.eua.facade.base.ExternalProviderAccreditation {
  // ___________________________________________________________________________
  /**
   * This method returns a list of accreditations for a provider
   *
   * @param concernRoleKey - contains the concernRoleID for the provider
   * @return A list of accreditations for the provider
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ProviderAccreditationDetails listProviderAccreditations(
    ConcernRoleKey concernRoleKey) throws AppException, InformationalException {

    // Create instance of provider accreditation facade
    curam.cpm.facade.intf.ProviderAccreditation providerAccreditationObj = ProviderAccreditationFactory.newInstance();
    ProviderKey providerKey = new ProviderKey();

    ProviderAccreditationDetails providerAccreditationDetails = new ProviderAccreditationDetails();

    providerKey.providerConcernRoleID = concernRoleKey.concernRoleID;

    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // call security method to ensure the logged in user
    // has access to this information
    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    Provider providerObj = ProviderFactory.newInstance();

    ProviderConcernRoleKey providerConcernRoleKey = new ProviderConcernRoleKey();

    providerConcernRoleKey.providerConcernRoleID = concernRoleKey.concernRoleID;

    ViewProviderSummaryDetails viewProviderSummaryDetails = providerObj.readProviderSummaryDetails(
      providerConcernRoleKey);

    // set the context description
    providerAccreditationDetails.pageContextDescription = viewProviderSummaryDetails.pageContextDescription;

    providerAccreditationDetails.dtls = filterList(
      providerAccreditationObj.listAccreditationsforProvider(providerKey));

    return providerAccreditationDetails;

  }

  // ___________________________________________________________________________
  /**
   * This method filters the list removing any canceled records
   *
   * @param unfilteredList
   * @return A list of all accreditations excluding canceled records.
   */
  // BEGIN, CR00177241, PM
  protected ProviderAccreditationList filterList(ProviderAccreditationList unfilteredList) {
    // END, CR00177241

    ProviderAccreditationList result = new ProviderAccreditationList();

    for (int i = 0; i < unfilteredList.providerAccreditationDtls.size(); i++) {

      if (!unfilteredList.providerAccreditationDtls.item(i).recordStatus.equals(
        RECORDSTATUSEntry.CANCELLED.getCode())) {

        result.providerAccreditationDtls.addRef(
          unfilteredList.providerAccreditationDtls.item(i));
      }
    }

    return result;

  }

  // ___________________________________________________________________________
  /**
   * This method returns the accreditation details
   *
   * @param providerAccreditationKey - contains the ID for reading
   * accreditation
   * @return This contains the details for the provider accreditation
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ProviderAccreditationSummaryDetails viewProviderAccreditation(
    ProviderAccreditationKey providerAccreditationKey) throws AppException, InformationalException {

    // Create instance of provider accreditation facade
    curam.cpm.facade.intf.ProviderAccreditation providerAccreditationObj = ProviderAccreditationFactory.newInstance();

    ProviderAccreditationSummaryDetails details = new ProviderAccreditationSummaryDetails();

    details = providerAccreditationObj.viewProviderAccreditation(
      providerAccreditationKey);

    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey.concernRoleID = details.providerAccreditation.providerConcernRoleID;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    // call security method to ensure the logged in user
    // has access to this information
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    return details;

  }
}
