/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.PROXIMITYDISTANCEEntry;
import curam.codetable.impl.UNITOFDISTANCEEntry;
import curam.cpm.facade.struct.ListCaseClientsNameListResult;
import curam.cpm.facade.struct.ProviderSpecialtyList;
import curam.cpm.facade.struct.ServiceProviderDetailsList;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.impl.Address;
import curam.provider.impl.ProviderSpecialtyTypeEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.util.List;


/**
 * Helper methods for the service/referral processing.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
@ImplementedBy(ServiceProviderSearchHelperImpl.class)
public interface ServiceProviderSearchHelper {

  /**
   * Returns a list of provider's who provide the specified service offering.
   *
   * @param serviceOffering
   * service offering object
   * @param address
   * address object for service recipient
   * @param specialties
   * required provider specialties
   * @param proximityDistance
   * proximity distance, which if specified, will filter out providers
   * who don't fall within the proximity
   * @param providerName
   * provider name, which if specified, will filter out providers
   * whose name don't match the string specified
   * @return list of providers for the specified service
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  ServiceProviderDetailsList listProvidersForServiceOffering(
    ServiceOffering serviceOffering, Address address,
    List<ProviderSpecialtyTypeEntry> specialties,
    PROXIMITYDISTANCEEntry proximityDistance, String providerName) throws InformationalException,
      AppException;

  /**
   * Retrieves a formatted list of the specified participants names in
   * {@link CaseParticipantRole} list.
   *
   * @param caseParticipantRoles
   * list of case participant object instances, whose names will be
   * added to the list
   * @return the formatted list of client names
   * @throws InformationalException
   * Generic Information Exception
   * @throws AppException
   * Generic Information Exception
   */
  ListCaseClientsNameListResult getCaseClientsNameList(
    List<CaseParticipantRole> caseParticipantRoles) throws AppException,
      InformationalException;

  /**
   * Populates a list of all the enabled provider specialty codes from the
   * {@link ProviderSpecialtyEntry} code table.
   *
   * @return list of all enabled provider specialty codes from the
   * {@link ProviderSpecialtyEntry} code table.
   * @throws InformationalException
   * @throws AppException
   */
  public ProviderSpecialtyList getProviderSpecialityCodesAsList()
    throws AppException, InformationalException;

  /**
   * Retrieves the unit of distance the proximity is to be measured in.
   *
   * @return the unit of distance the proximity is to be measured in
   * @since 6.0
   */
  public UNITOFDISTANCEEntry getMeasurementDistance();
}
