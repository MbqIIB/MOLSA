/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.workflowprocesses.impl;


import com.google.inject.Inject;

import curam.core.sl.fact.ExternalUserParticipantLinkFactory;
import curam.core.sl.struct.ExternalUserKey;
import curam.core.sl.struct.ExternalUserParticipantLinkKey;
import curam.cpm.facade.struct.ProviderEnquiryKey;
import curam.cpm.eua.facade.struct.RequestKey;
import curam.cpm.facade.fact.ProviderEnquiryFactory;
import curam.cpm.facade.intf.ProviderEnquiry;
import curam.cpm.facade.struct.ProviderEnquiryRegistrationDetails;
import curam.cpm.workflowprocesses.struct.ProviderCategoryAndTypeDetails;
import curam.cpm.workflowprocesses.struct.RequestCategoryAndTypeDetails;
import curam.externaluseraccess.impl.Request;
import curam.externaluseraccess.impl.RequestDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * External User Workflow Allocation class. This class contains methods to read
 * required details for the workflow enactments.
 */
public abstract class ExternalUserWorkflowAllocation extends curam.cpm.workflowprocesses.base.ExternalUserWorkflowAllocation {

  /**
   * Reference to request DAO.
   */
  @Inject
  protected RequestDAO requestDAO;

  /**
   * Constructor for the External User Workflow Allocation.
   */
  public ExternalUserWorkflowAllocation() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Reads the provider category and type details for a provider enquiry.
   *
   * @param providerEnquiryKey
   * Contains provider enquiry ID.
   *
   * @return The provider category and type details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderCategoryAndTypeDetails readProviderCategoryAndTypeDetailsForProviderEnquiry(
    ProviderEnquiryKey providerEnquiryKey) throws AppException,
      InformationalException {

    ProviderEnquiry providerEnquiryObj = ProviderEnquiryFactory.newInstance();

    ProviderCategoryAndTypeDetails providerCategoryAndTypeDetails = new ProviderCategoryAndTypeDetails();

    curam.cpm.sl.entity.struct.ProviderEnquiryKey key = new curam.cpm.sl.entity.struct.ProviderEnquiryKey();

    key.providerEnquiryID = providerEnquiryKey.providerEnquiryKey.providerEnquiryID;

    ProviderEnquiryRegistrationDetails providerEnquiryDetails = providerEnquiryObj.viewProviderEnquiry(
      key);

    providerCategoryAndTypeDetails.providerCategory = providerEnquiryDetails.providerCategory;
    providerCategoryAndTypeDetails.providerType = providerEnquiryDetails.providerType;
    providerCategoryAndTypeDetails.concernRoleID = providerEnquiryDetails.providerID;

    return providerCategoryAndTypeDetails;
  }

  /**
   * Reads the request category and type details for a request.
   *
   * @param requestKey
   * Contains request ID.
   *
   * @return The request category and type details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RequestCategoryAndTypeDetails readRequestCategoryAndTypeDetailsForExternalRequest(
    RequestKey requestKey) throws AppException, InformationalException {

    RequestCategoryAndTypeDetails requestCategoryAndTypeDetails = new RequestCategoryAndTypeDetails();

    Request request = requestDAO.get(requestKey.requestKey.requestID);

    requestCategoryAndTypeDetails.concernRoleID = request.getProviderOrganization().getID();
    requestCategoryAndTypeDetails.requestCategory = request.getRequestCategory().getCode();
    requestCategoryAndTypeDetails.requestType = request.getRequestType().getCode();

    return requestCategoryAndTypeDetails;
  }

  /**
   * Reads the user name for external user participant link.
   *
   * @param externalUserParticipantLinkKey
   * Contains external user participant link ID.
   *
   * @return The external user name.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ExternalUserKey readUserNameForExternalUserParticipantLink(
    ExternalUserParticipantLinkKey externalUserParticipantLinkKey)
    throws AppException, InformationalException {

    ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.userKey.userName = ExternalUserParticipantLinkFactory.newInstance().read(externalUserParticipantLinkKey).details.externalUserParticipantLinkDtls.userName;

    return externalUserKey;
  }

}
