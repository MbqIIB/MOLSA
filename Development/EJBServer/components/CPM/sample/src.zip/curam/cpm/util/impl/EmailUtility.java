/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.SMTPMessage;


/**
 * Interface to provide utility methods for the creation and sending of emails.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
@ImplementedBy(EmailUtilityImpl.class)
public interface EmailUtility {

  /**
   * Sends an email using the given {@link SMTPMessage}. The message contains
   * the specified recipient and all required content.
   *
   * @param message
   * The message containing the email recipient and email content
   * @param recipientName
   * full name of the intended recipient of the email.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void sendEmail(final SMTPMessage message, final String recipientName)
    throws AppException;

  /**
   * Retrieves the {@link SMTPMessage} to be for to be sent by email.
   *
   * @param subjectText
   * The email subject.
   * @param messageDetails
   * The details of the email message.
   * @param recipientEmailAddress
   * The email address of the intended recipient of email.
   * @return The message for sending via email
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public SMTPMessage getSMTPMessage(final String subjectText,
    final String messageDetails, final String recipientEmailAddress)
    throws AppException, InformationalException;

  /**
   * Reads the value of the given system property and based on the retrieve
   * property and returns a boolean indicating whether email notifications
   * should be sent.
   *
   * @param propertyValue
   * The system property value to be retrieved
   * @param propertyValueDefault
   * The default value of the system property value to be retrieved
   * @return true if the email is to be sent, otherwise false
   */
  public Boolean determineSendEmail(String propertyValue,
    String propertyValueDefault);
}
