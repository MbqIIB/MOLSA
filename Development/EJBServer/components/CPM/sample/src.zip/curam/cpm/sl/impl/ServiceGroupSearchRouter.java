/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.sl.impl;


import curam.core.impl.EnvVars;
import curam.cpm.sl.entity.struct.SearchServiceGroupKey;
import curam.cpm.sl.fact.DatabaseServiceGroupSearchFactory;
import curam.cpm.sl.intf.DatabaseServiceGroupSearch;
import curam.cpm.sl.struct.SearchServiceGroupResults;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;


/**
 * Provides methods which will route service group searches to the appropriate
 * search engine based on environment settings
 *
 */
public class ServiceGroupSearchRouter extends curam.cpm.sl.base.ServiceGroupSearchRouter {

  protected static boolean luceneSearchOn = false;

  /**
   * Routes service group search calls to the appropriate implementation
   *
   * @param searchServiceGroupKey
   * Contains data on which the searched will be based.
   *
   * @return The service group search results.
   */
  public SearchServiceGroupResults search(
    SearchServiceGroupKey searchServiceGroupKey) throws AppException,
      InformationalException {

    SearchServiceGroupResults searchServiceGroupResults = new SearchServiceGroupResults();

    if (((Configuration.getBooleanProperty(
      EnvVars.ENV_LUCENE_ENHANCED_SEARCH_ENABLED)))
        && ((Configuration.getBooleanProperty(
          EnvVars.ENV_LUCENE_ENHANCED_SERVICE_GROUP_SEARCH_ENABLED)))) {
      luceneSearchOn = true;

      curam.cpm.sl.intf.IndexServiceGroupSearch indexServiceGroupSearchObj = curam.cpm.sl.fact.IndexServiceGroupSearchFactory.newInstance();

      searchServiceGroupResults = indexServiceGroupSearchObj.search(
        searchServiceGroupKey);

    } else {

      DatabaseServiceGroupSearch databaseServiceGroupSearchObj = DatabaseServiceGroupSearchFactory.newInstance();

      searchServiceGroupResults = databaseServiceGroupSearchObj.search(
        searchServiceGroupKey);
    }

    return searchServiceGroupResults;
  }
}
