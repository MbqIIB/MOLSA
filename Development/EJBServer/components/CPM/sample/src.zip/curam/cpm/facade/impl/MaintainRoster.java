/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.attendance.impl.AttendanceConfigurationHelper;
import curam.attendance.impl.PRLICorrection;
import curam.attendance.impl.PRLICorrectionDAO;
import curam.attendance.impl.PRLISALILink;
import curam.attendance.impl.PRLISALILinkDAO;
import curam.attendance.impl.ProviderAttendanceTracking;
import curam.attendance.impl.ProviderAttendanceTrackingDAO;
import curam.attendance.impl.ProviderRosterLineItem;
import curam.attendance.impl.ProviderRosterLineItemDAO;
import curam.attendance.impl.Roster;
import curam.attendance.impl.RosterDAO;
import curam.attendance.impl.RosterProcessing;
import curam.attendance.impl.SOAttendanceConfiguration;
import curam.attendance.impl.SOAttendanceConfigurationDAO;
import curam.codetable.ACTIONCONTROLID;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.RosterKey;
import curam.core.struct.AddressDtls;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.cpm.facade.struct.FutureDatedRosterLineItemDetails;
import curam.cpm.facade.struct.GenerateRosterDetails;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.PRLIDetails;
import curam.cpm.facade.struct.PRLIDetailsList;
import curam.cpm.facade.struct.PaperRosterDocumentDetails;
import curam.cpm.facade.struct.ProviderKey;
import curam.cpm.facade.struct.ProviderRosterLineItemDetails;
import curam.cpm.facade.struct.ProviderRosterLineItemDetailsList;
import curam.cpm.facade.struct.RosterAndPRLIDetails;
import curam.cpm.facade.struct.RosterDetails;
import curam.cpm.facade.struct.RosterDetailsList;
import curam.cpm.facade.struct.RosterInformationalMessageDetails;
import curam.cpm.facade.struct.RosterLineItemWidgetDetails;
import curam.cpm.facade.struct.RosterServiceReportingMethod;
import curam.cpm.facade.struct.RosterViewDetails;
import curam.cpm.facade.struct.RosterViewDetailsList;
import curam.cpm.facade.struct.RosterWidgetDetails;
import curam.cpm.facade.struct.SubmitRosterDetails;
import curam.cpm.facade.struct.UnitsExceededDetails;
import curam.cpm.facade.struct.ViewAttendanceRosterDetails;
import curam.cpm.facade.struct.ViewRosterDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.util.impl.AttendanceWidgetHelper;
import curam.cpm.util.impl.WidgetHelper;
import curam.message.ROSTER;
import curam.message.impl.ROSTERExceptionCreator;
import curam.provider.impl.PRLICorrectionStatusEntry;
import curam.provider.impl.PRLIStatusEntry;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderSecurity;
import curam.provider.impl.RosterDerivedStatusEntry;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * {@inheritDoc}
 */
public abstract class MaintainRoster extends curam.cpm.facade.base.MaintainRoster {

  /**
   * providerSecurity type of ProviderSecurity
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * Provider DAO object.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to RosterDAO.
   */
  @Inject
  protected RosterDAO rosterDAO;

  /**
   * Reference to ProviderRosterLineItemDAO.
   */
  @Inject
  protected ProviderRosterLineItemDAO providerRosterLineItemDAO;

  /**
   * Provider Offering DAO object
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Reference to SOAttendanceConfiguration DAO
   */
  @Inject
  protected SOAttendanceConfigurationDAO soAttendanceConfigurationDAO;

  /**
   * reference to provider roster
   */
  @Inject
  protected RosterProcessing rosterProcessing;

  /**
   * A reference to PRLISALILink DAO.
   */
  @Inject
  protected PRLISALILinkDAO prliSALILinkDAO;

  // BEGIN, CR00207010, ASN
  /**
   * A reference to PRLICorrection DAO.
   */
  @Inject
  protected PRLICorrectionDAO prliCorrectionDAO;

  // END, CR00207010

  /**
   * A reference to instance of a roster.
   */
  @Inject
  protected Roster rosterObj;

  // BEGIN, CR00176474, AS
  // BEGIN, CR00178377, AS
  /**
   * Reference to Attendance Configuration Helper.
   */
  @Inject
  protected AttendanceConfigurationHelper attendanceConfigurationHelper;
  // END, CR00178377
  // END, CR00176474

  // BEGIN, CR00228146, ASN

  /**
   * Reference to Provider Attendance Tracking DAO.
   */
  @Inject
  protected ProviderAttendanceTrackingDAO providerAttendanceTrackingDAO;

  // END, CR00228146
  /**
   * Constructor for the class.
   */
  public MaintainRoster() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public void addClient(ProviderRosterLineItemDetails prliDetails)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.newInstance();

    // Check provider security.
    providerSecurity.checkProviderSecurity(
      providerDAO.get(prliDetails.rosterLineItemDtls.concernRoleID));

    // Validate units delivered if entered.
    if (prliDetails.unitsDeliveredString.trim().length() > 0) {

      try {
        prliDetails.rosterLineItemDtls.totalUnitsDelivered = Short.parseShort(
          prliDetails.unitsDeliveredString);
      } catch (NumberFormatException ne) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_IS_INVALID(
            prliDetails.unitsDeliveredString),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            3);
        ValidationHelper.failIfErrorsExist();
      }

      if (prliDetails.rosterLineItemDtls.totalUnitsDelivered <= 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_MUST_BE_GT_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
      }
      ValidationHelper.failIfErrorsExist();
    }

    // Set the details for provider roster line item.
    providerRosterLineItem.setServiceDateFrom(
      prliDetails.rosterLineItemDtls.serviceFrom);
    providerRosterLineItem.setServiceDateTo(
      prliDetails.rosterLineItemDtls.serviceTo);
    providerRosterLineItem.setUnitsDelivered(
      prliDetails.rosterLineItemDtls.totalUnitsDelivered);
    providerRosterLineItem.setClientReferenceNo(
      prliDetails.providerRosterLineItemDtls.clientReferenceNo);
    providerRosterLineItem.setClientFirstName(
      prliDetails.providerRosterLineItemDtls.clientFirstName);
    providerRosterLineItem.setClientLastName(
      prliDetails.providerRosterLineItemDtls.clientLastName);
    providerRosterLineItem.setClientDOB(
      prliDetails.providerRosterLineItemDtls.clientDOB);
    providerRosterLineItem.setSAReferenceNo(
      prliDetails.providerRosterLineItemDtls.saReferenceNo);
    providerRosterLineItem.setCaseReferenceNo(
      prliDetails.providerRosterLineItemDtls.caseReferenceNo);
    providerRosterLineItem.setVoucherNumber(
      prliDetails.providerRosterLineItemDtls.voucherNumber);

    // Set the address if entered.
    AddressDtls addressDtls = new AddressDtls();

    addressDtls.addressData = prliDetails.addressData;
    providerRosterLineItem.setAddress(addressDtls);

    // Add a client to the roster.
    providerRosterLineItem.addClient(
      rosterDAO.get(prliDetails.rosterLineItemDtls.rosterID));
  }

  /**
   * {@inheritDoc}
   */
  public void approveRoster(RosterKey key) throws AppException,
      InformationalException {

    Roster roster = rosterDAO.get(key.rosterID);

    roster.approve();
  }

  /**
   * {@inheritDoc}
   */
  public void deleteRoster(KeyVersionDetails key) throws AppException,
      InformationalException {

    curam.attendance.impl.Roster roster = rosterDAO.get(key.id);

    roster.cancel(key.version);
  }

  /**
   * {@inheritDoc}
   */
  public void generateRosterManually(GenerateRosterDetails details)
    throws AppException, InformationalException {

    Roster roster = rosterObj.newInstance();

    roster.setProvider(providerDAO.get(details.providerID));
    roster.setDateRange(new DateRange(details.fromDate, details.toDate));
    roster.setProviderOffering(
      providerOfferingDAO.get(details.providerOfferingID));

    rosterProcessing.generateRosterManually(roster);

  }

  /**
   * {@inheritDoc}
   */
  public RosterInformationalMessageDetails verifyRosterGeneration(
    GenerateRosterDetails details) throws AppException,
      InformationalException {

    RosterInformationalMessageDetails rosterInformationalMessageDetails = new RosterInformationalMessageDetails();

    rosterInformationalMessageDetails.rosterDetails.assign(details);

    Roster roster = rosterObj.newInstance();

    roster.setProvider(providerDAO.get(details.providerID));
    roster.setDateRange(new DateRange(details.fromDate, details.toDate));
    roster.setProviderOffering(
      providerOfferingDAO.get(details.providerOfferingID));

    InformationalMessageList informationalMessageList = rosterProcessing.getApplicableRosterRange(
      roster);

    if (informationalMessageList == null
      || (informationalMessageList != null
        && informationalMessageList.dtls.isEmpty())) {
      // if there is no warnings to be displayed to the user, generate the
      // rosters
      rosterProcessing.generateRosterManually(roster);
      rosterInformationalMessageDetails.informationalMessageInd = false;
    } else {
      // set the informational message to the return struct
      rosterInformationalMessageDetails.msgList.assign(informationalMessageList);
      rosterInformationalMessageDetails.informationalMessageInd = true;
    }

    return rosterInformationalMessageDetails;
  }

  /**
   * {@inheritDoc}
   */
  public PaperRosterDocumentDetails issuePaperRoster(
    curam.cpm.facade.struct.RosterKey rosterKey) throws AppException,
      InformationalException {

    PaperRosterDocumentDetails paperRosterDocumentDetails = new PaperRosterDocumentDetails();

    if (rosterKey.actionControlID.equals(ACTIONCONTROLID.PREVIEW)
      || rosterKey.actionControlID.length() == 0) {

      Roster roster = rosterDAO.get(rosterKey.key.rosterID);

      // BEGIN, CR00120007, JSP
      paperRosterDocumentDetails.paperRosterDocumentDetails = roster.issuePaperRoster(
        true);
      // END, CR00120007
    }
    return paperRosterDocumentDetails;

  }

  // BEGIN, CR00246084, GP
  /**
   * Lists all the rosters for a provider. This list is ordered by From Date,
   * earliest first.
   *
   * @param key
   * Contains Provider ID.
   *
   * @return List of details of rosters for the provider.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listRosterDetails(ProviderKey)}. This method is not
   * useful to show roster related links in action drop downs. Hence
   * this method is deprecated. The newly added method will give the
   * option to the user to define action drop down links. See
   * release note: CR00246084.
   */
  @Deprecated
  // END, CR00246084
  public RosterDetailsList listRoster(ProviderKey key) throws AppException,
      InformationalException {

    RosterDetailsList rosterDetailsList = new RosterDetailsList();
    List<Roster> rosters = rosterDAO.listRoster(key.providerID);
    // BEGIN, CR00120345, JSP
    List<Roster> filteredRosters = new ArrayList<Roster>(rosters.size());

    // filter out the rosters which were generated by the system and deleted
    // because the service authorization line item modified or canceled
    for (Roster roster : rosters) {

      boolean rosterAutoGeneratedInd = false;
      List<curam.attendance.impl.ProviderRosterLineItem> providerRosterLineItemList = providerRosterLineItemDAO.searchByRoster(
        roster);

      for (ProviderRosterLineItem providerRosterLineItem : providerRosterLineItemList) {
        // if one of the roster line item is auto generated, assuming that the
        // roster is also auto generated.
        if (providerRosterLineItem.getAutoGeneratedInd()) {
          rosterAutoGeneratedInd = true;
          break;
        }
      }

      // if the roster is auto generated and canceled, do not add to the
      // filtered rosters list. Else add the rest to the filtered list.
      if (rosterAutoGeneratedInd) {
        if (!roster.getDerivedStatus().equals(RosterDerivedStatusEntry.CANCELED)) {
          filteredRosters.add(roster);
        }
      } else {
        filteredRosters.add(roster);
      }
    }

    for (Roster roster : filteredRosters) {
      // END, CR00120345
      RosterDetails rosterDetails = new RosterDetails();

      rosterDetails.dtls.dateSubmitted = roster.getDateSubmitted();
      rosterDetails.dtls.submissionDueDate = roster.getSubmissionDueDate();
      rosterDetails.dtls.toDate = roster.getDateRange().end();
      rosterDetails.dtls.fromDate = roster.getDateRange().start();
      rosterDetails.dtls.recordStatus = roster.getRecordStatus().getCode();
      rosterDetails.dtls.rosterID = roster.getID();

      rosterDetails.serviceName = roster.getServiceOffering().getName();
      rosterDetails.rosterDerivedStatus = roster.getDerivedStatus().getCode();

      rosterDetails.serviceOfferingID = roster.getServiceOffering().getID();

      rosterDetailsList.details.addRef(rosterDetails);
    }

    return rosterDetailsList;
  }
  
  // BEGIN, CR00205041, GP
  /**
   * {@inheritDoc}
   */
  public RosterViewDetailsList listRosterDetails(final ProviderKey providerKey)
    throws AppException, InformationalException {

    RosterViewDetailsList rosterViewDetailsList = new RosterViewDetailsList();
    List<Roster> rosters = rosterDAO.listRoster(providerKey.providerID);
    List<Roster> filteredRosters = new ArrayList<Roster>(rosters.size());
    
    // Filter out the rosters which were generated by the system and deleted
    // because the service authorization line item modified or canceled.
    for (Roster roster : rosters) {

      boolean rosterAutoGeneratedInd = false;
      List<ProviderRosterLineItem> providerRosterLineItemList = providerRosterLineItemDAO.searchByRoster(
        roster);

      for (ProviderRosterLineItem providerRosterLineItem : providerRosterLineItemList) {
        // If one of the roster line item is auto generated, assuming that the
        // roster is also auto generated.
        if (providerRosterLineItem.getAutoGeneratedInd()) {
          rosterAutoGeneratedInd = true;
          break;
        }
      }
      
      // If the roster is auto generated and canceled, do not add to the
      // filtered rosters list. Else add the rest to the filtered list.
      if (rosterAutoGeneratedInd) {
        if (!RosterDerivedStatusEntry.CANCELED.equals(roster.getDerivedStatus())) {
          filteredRosters.add(roster);
        }
      } else {
        filteredRosters.add(roster);
      }
    }

    for (Roster roster : filteredRosters) {

      RosterViewDetails rosterViewDetails = new RosterViewDetails();
   
      rosterViewDetails.rosterDtls.dateSubmitted = roster.getDateSubmitted();
      rosterViewDetails.rosterDtls.submissionDueDate = roster.getSubmissionDueDate();
      rosterViewDetails.rosterDtls.toDate = roster.getDateRange().end();
      rosterViewDetails.rosterDtls.fromDate = roster.getDateRange().start();
      rosterViewDetails.rosterDtls.recordStatus = roster.getRecordStatus().getCode();
      rosterViewDetails.rosterDtls.rosterID = roster.getID();
      rosterViewDetails.rosterDtls.versionNo = roster.getVersionNo();
      rosterViewDetails.rosterDtls.concernRoleID = providerKey.providerID;
      rosterViewDetails.serviceName = roster.getServiceOffering().getName();
      rosterViewDetails.rosterDerivedStatus = roster.getDerivedStatus().getCode();

      rosterViewDetails.serviceOfferingID = roster.getServiceOffering().getID();
      // BEGIN, CR00215605, ASN
      rosterViewDetails.rosterDtls.referenceNo = roster.getReferenceNumber();
      rosterViewDetails.rosterDtls.dateGenerated = roster.getDateGenerated();
      // END, CR00215605
      List<ProviderRosterLineItem> providerRosterLineItemList = providerRosterLineItemDAO.searchByRoster(
        roster);

      List<ProviderRosterLineItem> filteredProviderRosterLineItemList = new ArrayList<ProviderRosterLineItem>(
        providerRosterLineItemList.size());

      for (ProviderRosterLineItem providerRosterLineItem : providerRosterLineItemList) {

        // If the provider roster line item is auto generated and is canceled,
        // do not add to the filtered list. Else add the rest to the filtered
        // list.
        if (providerRosterLineItem.getAutoGeneratedInd()) {

          if (!PRLIStatusEntry.CANCELED.equals(
            providerRosterLineItem.getLifecycleState())) {

            filteredProviderRosterLineItemList.add(providerRosterLineItem);
          }
        } else {

          filteredProviderRosterLineItemList.add(providerRosterLineItem);
        }
      }
      
      // BEGIN, CR00208100, ASN
      RosterKey rosterKey = new RosterKey();

      rosterKey.rosterID = roster.getID();

      // BEGIN, CR00228146, ASN
      rosterViewDetails.reportingMethodAttendanceInd = isReportingMethodAttendance(rosterKey).attendanceReportingIndicator;
      
      // BEGIN, CR00273521, MR
      final String userName = TransactionInfo.getProgramUser();

      if (rosterViewDetails.reportingMethodAttendanceInd) {
        rosterViewDetails.editActionURL = CPMConstants.kEditAttendanceRosterPage;
        // END, CR00208100
      } else {
        rosterViewDetails.updateRosterInd = true;
        
        if (CPMConstants.kFacilityManagerUserName.equals(userName)) {
          rosterViewDetails.editActionURL = CPMConstants.kEditUtilizationRosterPageForFM;
        } else {
          rosterViewDetails.editActionURL = CPMConstants.kEditUtilizationRosterPage;
        }
        // END, CR00273521
      }
      // END, CR00228146
     
      rosterViewDetails.unitsExceededInd = isTotalUnitsGreaterThanExpectedUnits(rosterKey).unitsExceededInd;
      
      // BEGIN, CR00206362, ASN
      rosterViewDetails.futureDatedRosterLineItemInd = isRosterLineItemFromDateInFuture(rosterKey).futureDatedRosterLineItemInd;

      if (rosterViewDetails.futureDatedRosterLineItemInd) {

        rosterViewDetails.unitsExceededInd = true;
      }
      // BEGIN, CR00228146, ASN
      if (rosterViewDetails.unitsExceededInd) {

        // BEGIN, CR00273521, MR
        if (CPMConstants.kFacilityManagerUserName.equals(userName)) {
          rosterViewDetails.submitActionURL = CPMConstants.kConfirmSubmitRosterPageForFM;
        } else {
          rosterViewDetails.submitActionURL = CPMConstants.kConfirmSubmitRosterPage;
        }
      } else {
        if (CPMConstants.kFacilityManagerUserName.equals(userName)) {
          rosterViewDetails.submitActionURL = CPMConstants.kSubmitRosterPageForFM;
        } else {
          rosterViewDetails.submitActionURL = CPMConstants.kSubmitRosterPage;
        }
        // END, CR00273521
      }
      // END, CR00228146
      
      // END, CR00206362
      String attendanceReportingEnabledString = curam.util.resources.Configuration.getProperty(
        CPMConstants.kAttendanceReportingConfiguration);

      if (!StringUtil.isNullOrEmpty(attendanceReportingEnabledString)
        && !Boolean.parseBoolean(attendanceReportingEnabledString)) {

        rosterViewDetails.actionURL = CPMConstants.kViewRosterPage;

      } else {

        if (isReportingMethodAttendance(rosterKey).attendanceReportingIndicator) {

          rosterViewDetails.actionURL = CPMConstants.kViewAttendanceRosterPage;
        } else {

          rosterViewDetails.actionURL = CPMConstants.kViewRosterPage;
        }
      }
      
      // BEGIN, CR00235049, ASN
      if (RosterDerivedStatusEntry.CANCELED.equals(roster.getDerivedStatus())) {
        rosterViewDetails.isRosterLineItemCancelledInd = true;

      }
      // END, CR00235049

      if (isProviderRosterConfigured(providerKey)
        && !RosterDerivedStatusEntry.CANCELED.equals(roster.getDerivedStatus())) {
        rosterViewDetails.showIssuePaperRosterInd = true;
      }
      
      // BEGIN, CR00236219, PS
      if ((providerRosterLineItemList.isEmpty())
        || RosterDerivedStatusEntry.CANCELED.equals(roster.getDerivedStatus())) {
        rosterViewDetails.noLineItemsInd = true;
      }
      // END, CR00236219
      
      rosterViewDetailsList.rosterViewDetails.addRef(rosterViewDetails);
    }

    return rosterViewDetailsList;
  }

  // END, CR00205041
  
  /**
   * {@inheritDoc}
   */
  public InformationalMsgDtlsList submitRoster(SubmitRosterDetails details) throws AppException,
      InformationalException {

    Roster roster = rosterDAO.get(details.rosterID);

    roster.submit(details.dateSubmitted, details.versionNo);

    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();
    String[] finalResults = TransactionInfo.getInformationalManager().obtainInformationalAsString();

    // iterate through the result from informational manager
    for (int i = 0; i < finalResults.length; i++) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = finalResults[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }

    return informationalMsgDtlsList;
  }

  /**
   * Update the provider roster line items and corresponding roster line items
   * for a roster.
   *
   * @param widgetDetails
   * Details containing the xml data received from the widget.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void updateRoster(RosterLineItemWidgetDetails widgetDetails)
    throws AppException, InformationalException {

    ProviderRosterLineItemDetailsList providerRosterLineItemDetailsList = WidgetHelper.convertXmlToProviderRosterLineItemDetailsList(
      widgetDetails.rosterLineItemDetails);

    validateRosterLineItems(providerRosterLineItemDetailsList);

    // modify all the provider roster line item records for the roster
    // specified.
    for (ProviderRosterLineItemDetails providerRosterLineItemDetails : providerRosterLineItemDetailsList.details.items()) {

      ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
        providerRosterLineItemDetails.providerRosterLineItemDtls.providerRosterLineItemID);

      providerRosterLineItem.setRosterLineItemID(
        providerRosterLineItem.getRosterLineItemID());

      providerRosterLineItem.setRLIVersionNo(
        providerRosterLineItemDetails.rosterLineItemDtls.versionNo);
      providerRosterLineItem.setVersionNo(
        providerRosterLineItemDetails.providerRosterLineItemDtls.versionNo);

      providerRosterLineItem.modifyRosterLineItem(
        providerRosterLineItemDetails.rosterLineItemDtls.totalUnitsDelivered,
        providerRosterLineItemDetails.providerRosterLineItemDtls.voucherNumber,
        providerRosterLineItemDetails.providerRosterLineItemDtls.caseReferenceNo,
        providerRosterLineItemDetails.providerRosterLineItemDtls.saReferenceNo);
    }

  }

  /**
   * Retrieves the roster details and also the associated provider roster line
   * item details.
   *
   * @param rosterKey
   * Contains roster ID.
   * @return Returns roster details and also the list of provider roster line
   * item for a specified roster ID.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewRosterDetails viewRoster(RosterKey rosterKey) throws AppException,
      InformationalException {

    ViewRosterDetails viewRosterDetails = new ViewRosterDetails();

    Roster roster = rosterDAO.get(rosterKey.rosterID);

    viewRosterDetails.rosterDetails.dtls = roster.getDtls();
    viewRosterDetails.rosterDetails.rosterDerivedStatus = roster.getDerivedStatus().getCode();

    List<curam.attendance.impl.ProviderRosterLineItem> providerRosterLineItemList = providerRosterLineItemDAO.searchByRoster(
      roster);

    // BEGIN, CR00120345, JSP
    List<ProviderRosterLineItem> filteredProviderRosterLineItemList = new ArrayList<ProviderRosterLineItem>(
      providerRosterLineItemList.size());

    for (ProviderRosterLineItem providerRosterLineItem : providerRosterLineItemList) {

      // if the provider roster line item is auto generated and is canceled, do
      // not add to the filtered list. Else add the rest to the filtered list.
      if (providerRosterLineItem.getAutoGeneratedInd()) {
        if (!providerRosterLineItem.getLifecycleState().equals(
          PRLIStatusEntry.CANCELED)) {
          filteredProviderRosterLineItemList.add(providerRosterLineItem);
        }
      } else {
        filteredProviderRosterLineItemList.add(providerRosterLineItem);
      }
    }
    // END, CR00120345

    if (!filteredProviderRosterLineItemList.isEmpty()) {
      viewRosterDetails.updateRosterInd = true;
    } else {
      viewRosterDetails.updateRosterInd = false;
    }

    // Sorting the list by service from date , earliest first
    Collections.sort(filteredProviderRosterLineItemList,
      new Comparator<curam.attendance.impl.ProviderRosterLineItem>() {
      public int compare(
        final curam.attendance.impl.ProviderRosterLineItem lhs,
        final curam.attendance.impl.ProviderRosterLineItem rhs) {
        return lhs.getServiceDateFrom().compareTo(rhs.getServiceDateTo());
      }
    });

    viewRosterDetails.rosterDetails.serviceName = roster.getServiceOffering().getName();

    SOAttendanceConfiguration soAttendanceConfiguration = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      roster.getServiceOffering(), roster.getDateGenerated());

    if (soAttendanceConfiguration != null) {
      viewRosterDetails.dailyAttendanceLinkInd = soAttendanceConfiguration.isDailyAttendanceTrackingRequired();
    }
    ProviderRosterLineItemDetailsList providerRosterLineItemDetailsList = new ProviderRosterLineItemDetailsList();

    for (curam.attendance.impl.ProviderRosterLineItem rosterLineItem : filteredProviderRosterLineItemList) {

      Set<ProviderRosterLineItem> providerRosterLineItems = providerRosterLineItemDAO.searchByRosterLineItemID(
        rosterLineItem.getRosterLineItemID());

      for (curam.attendance.impl.ProviderRosterLineItem providerRosterLineItem : providerRosterLineItems) {

        ProviderRosterLineItemDetails providerRosterLineItemDetails = getProviderRosterLineItemDetails(
          providerRosterLineItem);

        providerRosterLineItemDetailsList.details.addRef(
          providerRosterLineItemDetails);
      }
    }

    // Convert the list of provider roster line item details into xml data
    // string which would be the input for the widget.
    // BEGIN, CR00176474, AS
    if (isReportingMethodAttendance(rosterKey).attendanceReportingIndicator) {
      viewRosterDetails.rosterLineItemDetails = AttendanceWidgetHelper.convertUpdateRosterToXml(
        providerRosterLineItemDetailsList);
    } else {
      viewRosterDetails.rosterLineItemDetails = WidgetHelper.convertUpdateRosterToXml(
        providerRosterLineItemDetailsList);
    }
    // END, CR00176474

    viewRosterDetails.detailsList = providerRosterLineItemDetailsList;

    return viewRosterDetails;

  }

  /**
   * Validates if total units are greater than expected units.
   *
   * @param key
   * Contains roster ID.
   * @return Units exceeded details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public UnitsExceededDetails isTotalUnitsGreaterThanExpectedUnits(RosterKey key)
    throws AppException, InformationalException {
    UnitsExceededDetails unitsExceededDetails = new UnitsExceededDetails();

    unitsExceededDetails.unitsExceededInd = false;
    Roster roster = rosterDAO.get(key.rosterID);
    List<ProviderRosterLineItem> providerRosterLineItems = providerRosterLineItemDAO.searchByRoster(
      roster);

    if (providerRosterLineItems != null) {
      for (ProviderRosterLineItem providerRosterLineItem : providerRosterLineItems) {
        if (providerRosterLineItem.getAutoGeneratedInd()
          && providerRosterLineItem.getUnitsDelivered()
            > providerRosterLineItem.getExpectedUnits()) {
          unitsExceededDetails.unitsExceededInd = true;
        }
      }
    }
    return unitsExceededDetails;
  }

  // BEGIN, CR00129319, KR
  /**
   * Validates the actual units against the expected units.
   *
   * @param rosterKey
   * Contains roster ID.
   *
   * @return The Informational messages are added, when the actual units more
   * than the expected units.
   *
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_XFV_ACTUAL_UNITS_MORE_THAN_EXPECTED_UNITS}
   * If actual units more than expected units.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationalMessageList validateTotalAndExpectedUnits(
    curam.cpm.facade.struct.RosterKey rosterKey) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();
    boolean unitsExceededInd = false;
    Roster roster = rosterDAO.get(rosterKey.key.rosterID);
    List<ProviderRosterLineItem> providerRosterLineItems = providerRosterLineItemDAO.searchByRoster(
      roster);

    if (null != providerRosterLineItems) {
      for (ProviderRosterLineItem providerRosterLineItem : providerRosterLineItems) {

        // BEGIN, CR00279575, ASN
        if (0 != providerRosterLineItem.getExpectedUnits()
          && providerRosterLineItem.getAutoGeneratedInd()
          && providerRosterLineItem.getUnitsDelivered()
            > providerRosterLineItem.getExpectedUnits()) {
          // END, CR00279575
          unitsExceededInd = true;
        }
      }
    }

    if (unitsExceededInd) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();
      AppException appException = ROSTERExceptionCreator.INF_ROSTER_XFV_ACTUAL_UNITS_MORE_THAN_EXPECTED_UNITS();

      informationalManager.addInformationalMsg(appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning);

      String warnings[] = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        InformationalMessage infoMessage = new InformationalMessage();

        infoMessage.messageTest = warnings[i];
        informationalMessageList.dtls.addRef(infoMessage);
      }
    }
    return informationalMessageList;
  }

  // END, CR00129319
  
  // BEGIN, CR00176474, AS  
  /**
   * Checks if the reporting method on the service offering attendance
   * configuration is set to Attendance.
   *
   * @param rosterKey Contains the roster details.
   *
   * @return The attendance reporting configuration details.
   */
  public RosterServiceReportingMethod isReportingMethodAttendance(
    RosterKey rosterKey) throws AppException, InformationalException {

    Roster roster = rosterDAO.get(rosterKey.rosterID);
    
    RosterServiceReportingMethod reportingMethod = new RosterServiceReportingMethod();

    // BEGIN, CR00178377, AS
    reportingMethod.attendanceReportingIndicator = attendanceConfigurationHelper.isReportingMethodAttendance(
      roster);
    // END, CR00178377
    
    // BEGIN, CR00208100, ASN
    reportingMethod.hoursEnabledIndicator = attendanceConfigurationHelper.isHoursEnabledForAttendanceReporting(
      rosterKey);
    // END, CR00208100
    return reportingMethod;
  }

  /**
   * Update the provider roster line items and corresponding roster line items
   * for a roster.
   *
   * @param details
   * Details containing the xml data received from the widget.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void updateAttendanceRoster(RosterWidgetDetails details)
    throws AppException, InformationalException {
    ProviderRosterLineItemDetailsList providerRosterLineItemDetailsList = AttendanceWidgetHelper.convertXmlToProviderRosterLineItemsList(
      details.rosterDetails);

    validateRosterLineItems(providerRosterLineItemDetailsList);

    // Modify all the provider roster line item records for the roster
    // specified.
    for (ProviderRosterLineItemDetails providerRosterLineItemDetails : providerRosterLineItemDetailsList.details.items()) {

      ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
        providerRosterLineItemDetails.providerRosterLineItemDtls.providerRosterLineItemID);

      providerRosterLineItem.setRosterLineItemID(
        providerRosterLineItem.getRosterLineItemID());

      providerRosterLineItem.setRLIVersionNo(
        providerRosterLineItemDetails.rosterLineItemDtls.versionNo);
      providerRosterLineItem.setVersionNo(
        providerRosterLineItemDetails.providerRosterLineItemDtls.versionNo);

      providerRosterLineItem.modifyRosterLineItem(
        providerRosterLineItemDetails.rosterLineItemDtls.totalUnitsDelivered,
        providerRosterLineItemDetails.providerRosterLineItemDtls.voucherNumber,
        providerRosterLineItemDetails.providerRosterLineItemDtls.caseReferenceNo,
        providerRosterLineItemDetails.providerRosterLineItemDtls.saReferenceNo);
    }
  }

  /**
   * {@inheritDoc}
   */
  public ViewAttendanceRosterDetails viewAttendanceRoster(RosterKey key)
    throws AppException, InformationalException {
    // BEGIN, CR00215605, ASN
    RosterAndPRLIDetails rosterAndPRLIDetails = new RosterAndPRLIDetails();

    rosterAndPRLIDetails = viewRosterDetails(key);
    ViewRosterDetails rosterDetails = new ViewRosterDetails();

    rosterDetails = viewRoster(key);
       
    ViewAttendanceRosterDetails details = new ViewAttendanceRosterDetails();

    details.attendanceRosterDetails = rosterAndPRLIDetails.rosterLineItemDetails;
    details.dailyAttendanceLinkInd = rosterAndPRLIDetails.dailyAttendanceLinkInd;
    details.lineItemsList = rosterDetails.detailsList;
    details.updateRosterInd = rosterAndPRLIDetails.updateRosterInd;
    details.viewRosterDetails = rosterAndPRLIDetails.viewRosterDetails;
    details.viewRosterDetails.dtls.rosterID = key.rosterID;
    // END, CR00215605
    
    return details;
  }

  // END, CR00176474
  
  // BEGIN, CR00206362, ASN
  /**
   * Validates whether the roster line items having a from date in future.
   *
   * @param rosterKey
   * Roster for which roster line items having from date in future need
   * to be retrieved.
   *
   * @return The Informational messages are added, when roster line items are
   * having from date in future,
   *
   * @throws InformationalException
   * {@link ROSTER#INF_ROSTER_LINE_ITEM_XRV_LINE_ITEMS_HAVE_FROM_DATE_IN_FUTURE_CAN_NOT_BE_SUBMITTED}
   * -If roster line items having from date in future, they can not be
   * submitted.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationalMessageList validateFutureDatedRosterLineItems(
    final curam.cpm.facade.struct.RosterKey rosterKey) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();
    Set<Long> futureDatedRosterLineItems = new HashSet<Long>();
    // BEGIN, CR00236982, SSK
    StringBuilder validationMessage = new StringBuilder(CuramConst.gkEmpty);
    // END, CR00236982

    Roster roster = rosterDAO.get(rosterKey.key.rosterID);
    List<ProviderRosterLineItem> providerRosterLineItems = providerRosterLineItemDAO.searchByRoster(
      roster);

    // BEGIN, CR00280340, RPB
    boolean futureDatedRosterAllowed = GeneralConstants.kTrue.equalsIgnoreCase(
      Configuration.getProperty(CPMConstants.kFutureDatedRostersEnabled));

    if (!futureDatedRosterAllowed && null != providerRosterLineItems) {
      // END, CR00280340      
      for (final ProviderRosterLineItem providerRosterLineItem : providerRosterLineItems) {

        if (providerRosterLineItem.getDateRange().start().after(
          Date.getCurrentDate())) {
          futureDatedRosterLineItems.add(
            providerRosterLineItem.getRosterLineItemID());

        }
      }

    }
    int counter = 0;

    if (0 < futureDatedRosterLineItems.size()) {

      for (final long rosterLineItemID : futureDatedRosterLineItems) {

        Set<ProviderRosterLineItem> futureDatedProviderRosterLineItems = providerRosterLineItemDAO.searchByRosterLineItemID(
          rosterLineItemID);

        for (final ProviderRosterLineItem futureDatedProviderRosterLineItem : futureDatedProviderRosterLineItems) {

          validationMessage.append(
            futureDatedProviderRosterLineItem.getDateRange());

          if (counter != futureDatedRosterLineItems.size() - 1) {

            validationMessage.append(CPMConstants.kComma + CPMConstants.kSpace);
          }
          counter = counter + 1;
        }

      }
    }
    // BEGIN, CR00236982, SSK
    if (!StringUtil.isNullOrEmpty(validationMessage.toString())) {
      // END, CR00236982
      InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
      AppException appException = ROSTERExceptionCreator.INF_ROSTER_LINE_ITEM_XRV_LINE_ITEMS_HAVE_FROM_DATE_IN_FUTURE_CAN_NOT_BE_SUBMITTED(
        validationMessage.toString());

      informationalManager.addInformationalMsg(appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning);

      String warnings[] = informationalManager.obtainInformationalAsString();

      for (final String warning : warnings) {

        InformationalMessage infoMessage = new InformationalMessage();

        infoMessage.messageTest = warning;
        informationalMessageList.dtls.addRef(infoMessage);
      }
    }
    return informationalMessageList;
  }

  /**
   * Validates if total units are greater than expected units and roster line
   * items are having from date in future.
   *
   * @param rosterKey
   * Roster for which roster line items having from date in future need
   * to be retrieved.
   *
   * @return Details based on which warning will be displayed while submitting a
   * roster.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public FutureDatedRosterLineItemDetails isRosterLineItemFromDateInFuture(
    final RosterKey rosterKey) throws AppException, InformationalException {

    FutureDatedRosterLineItemDetails futureDatedRosterLineItemDetails = new FutureDatedRosterLineItemDetails();
    Set<Long> futureDatedRosterLineItems = new HashSet<Long>();
 
    Roster roster = rosterDAO.get(rosterKey.rosterID);
    List<ProviderRosterLineItem> providerRosterLineItems = providerRosterLineItemDAO.searchByRoster(
      roster);

    if (null != providerRosterLineItems) {
     
      for (final ProviderRosterLineItem providerRosterLineItem : providerRosterLineItems) {

        if (providerRosterLineItem.getDateRange().start().after(
          Date.getCurrentDate())) {

          futureDatedRosterLineItems.add(
            providerRosterLineItem.getRosterLineItemID());
        }
      }
    }

    if (0 < futureDatedRosterLineItems.size()) {

      futureDatedRosterLineItemDetails.futureDatedRosterLineItemInd = true;
    }

    return futureDatedRosterLineItemDetails;
  }

  // END, CR00206362 
  

  // BEGIN, CR00215605, ASN
  /**
   * Retrieves the roster details and also the associated provider roster line
   * item details.
   *
   * @param rosterKey
   * Roster for which all line items will be retrieved.
   *
   * @return Roster and list of provider roster line
   * item details for a specified roster ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RosterAndPRLIDetails viewRosterDetails(
    final RosterKey rosterKey) throws AppException, InformationalException {

    RosterAndPRLIDetails rosterAndPRLIDetails = new RosterAndPRLIDetails();

    Roster roster = rosterDAO.get(rosterKey.rosterID);

    rosterAndPRLIDetails.viewRosterDetails.dtls = roster.getDtls();
    rosterAndPRLIDetails.viewRosterDetails.rosterDerivedStatus = roster.getDerivedStatus().getCode();

    List<curam.attendance.impl.ProviderRosterLineItem> providerRosterLineItemList = providerRosterLineItemDAO.searchByRoster(
      roster);

    List<ProviderRosterLineItem> filteredProviderRosterLineItemList = new ArrayList<ProviderRosterLineItem>(
      providerRosterLineItemList.size());

    for (ProviderRosterLineItem providerRosterLineItem : providerRosterLineItemList) {

      // If the provider roster line item is auto generated and is canceled, do
      // not add to the filtered list. Else add the rest to the filtered list.
      if (providerRosterLineItem.getAutoGeneratedInd()) {
        if (!providerRosterLineItem.getLifecycleState().equals(
          PRLIStatusEntry.CANCELED)) {
          filteredProviderRosterLineItemList.add(providerRosterLineItem);
        }
      } else {
        filteredProviderRosterLineItemList.add(providerRosterLineItem);
      }
    }

    if (!filteredProviderRosterLineItemList.isEmpty()) {
      rosterAndPRLIDetails.updateRosterInd = true;
    } else {
      rosterAndPRLIDetails.updateRosterInd = false;
    }
    // BEGIN, CR00262205, ASN
    Collections.sort(filteredProviderRosterLineItemList,
      new Comparator<curam.attendance.impl.ProviderRosterLineItem>() {
      public int compare(
        final curam.attendance.impl.ProviderRosterLineItem lhs,
        final curam.attendance.impl.ProviderRosterLineItem rhs) {
        return lhs.getServiceDateFrom().compareTo(rhs.getServiceDateFrom());
      }
    });
    // END, CR00262205

    rosterAndPRLIDetails.viewRosterDetails.serviceName = roster.getServiceOffering().getName();

    SOAttendanceConfiguration soAttendanceConfiguration = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      roster.getServiceOffering(), roster.getDateGenerated());

    if (null != soAttendanceConfiguration) {
      rosterAndPRLIDetails.dailyAttendanceLinkInd = soAttendanceConfiguration.isDailyAttendanceTrackingRequired();
    }
    PRLIDetailsList prliDetailsList = new PRLIDetailsList();
    
    ProviderRosterLineItemDetailsList providerRosterLineItemDetailsList = new ProviderRosterLineItemDetailsList();
    
    for (final ProviderRosterLineItem rosterLineItem : filteredProviderRosterLineItemList) {

      Set<ProviderRosterLineItem> providerRosterLineItems = providerRosterLineItemDAO.searchByRosterLineItemID(
        rosterLineItem.getRosterLineItemID());

      for (final ProviderRosterLineItem providerRosterLineItem : providerRosterLineItems) {

        PRLIDetails prliDetails = getPRLIDetails(providerRosterLineItem,
          rosterAndPRLIDetails);
        
        ProviderRosterLineItemDetails providerRosterLineItemDetails = getProviderRosterLineItemDetails(
          providerRosterLineItem);

        providerRosterLineItemDetailsList.details.addRef(
          providerRosterLineItemDetails);
        prliDetailsList.prliDetails.addRef(prliDetails);
      }
    }

    // Convert the list of provider roster line item details into xml data
    // string which would be the input for the widget.
    if (isReportingMethodAttendance(rosterKey).attendanceReportingIndicator) {
      rosterAndPRLIDetails.rosterLineItemDetails = AttendanceWidgetHelper.convertUpdateRosterToXml(
        providerRosterLineItemDetailsList);
    } else {
      rosterAndPRLIDetails.rosterLineItemDetails = WidgetHelper.convertUpdateRosterToXml(
        providerRosterLineItemDetailsList);
    }

    rosterAndPRLIDetails.prliDetailsList = prliDetailsList;

    return rosterAndPRLIDetails;
  }

  // END, CR00215605
  
  /**
   * Validates the actual units are not greater than the units remaining after
   * taking in to account total units delivered of 'Complete' roster line items.
   *
   * @param providerRosterLineItem
   * Roster line item to be validated for actual units.
   *
   * @return true, if the actual units are greater than the units remaining
   * after taking in to account total units delivered of 'Complete'
   * roster line items.
   */
  protected boolean isActualUnitsMoreThanCompletedDeliveredUnits(
    ProviderRosterLineItem providerRosterLineItem) {

    Set<PRLISALILink> prisaliLinks = prliSALILinkDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);
    boolean isActualUnitsMoreThanCompletedDeliveredUnits = false;

    int unitsRemaiing = 0;

    for (final PRLISALILink prlisaliLink : prisaliLinks) {

      unitsRemaiing += prlisaliLink.getServiceAuthorizationLineItem().getUnitsAuthorized()
        - prlisaliLink.getServiceAuthorizationLineItem().getUnitsConsumed();
    }

    if (providerRosterLineItem.getUnitsDelivered() > unitsRemaiing) {
      isActualUnitsMoreThanCompletedDeliveredUnits = true;
    }
    return isActualUnitsMoreThanCompletedDeliveredUnits;
  }

  /**
   * Validates the actual units are not greater than the units remaining after
   * taking in to account total units delivered of `Pending Approval` roster
   * line items.
   *
   * @param providerRosterLineItem
   * Roster line item to be validated for actual units.
   *
   * @return true, if the actual units are greater than the units remaining
   * after taking in to account total units delivered of `Pending
   * Approval` roster line items.
   */
  protected boolean isActualUnitsMoreThanPendingApprovalDeliveredUnits(
    ProviderRosterLineItem providerRosterLineItem) {

    boolean isActualUnitsMoreThanPendingApprovalDeliveredUnits = false;

    // Retrieve all PRLISALI links for the roster line items.
    Set<PRLISALILink> prliSALILinks = prliSALILinkDAO.searchByProviderRosterLineItem(
      providerRosterLineItem);

    for (PRLISALILink prliSALILink : prliSALILinks) {

      Set<PRLISALILink> prliSALILinkList = prliSALILinkDAO.searchByServiceAuthorizationLineItem(
        prliSALILink.getServiceAuthorizationLineItem());

      long unitsDelivered = 0;

      // Add up the units delivered for the pending approval roster line items.
      for (PRLISALILink prliSALILinkObj : prliSALILinkList) {

        if (PRLIStatusEntry.PENDINGAPPROVAL.equals(
          prliSALILinkObj.getProviderRosterLineItem().getLifecycleState())) {
          unitsDelivered += prliSALILinkObj.getProviderRosterLineItem().getUnitsDelivered();

        }
      }
      // Calculate the units remaining for the service authorization line item.
      long unitsRemaining = prliSALILink.getServiceAuthorizationLineItem().getUnitsAuthorized()
        - prliSALILink.getServiceAuthorizationLineItem().getUnitsConsumed();

      if (unitsDelivered > unitsRemaining) {
        isActualUnitsMoreThanPendingApprovalDeliveredUnits = true;
        break;
      }

    }
    return isActualUnitsMoreThanPendingApprovalDeliveredUnits;
  }

  /**
   * Validate the modified provider roster line item and roster line item
   * details.
   *
   * @param providerRosterLineItemDetailsList
   * list containing the modified provider roster line item details and
   * corresponding roster line item details.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_FOLLOWING_RLI_GENERATED_BY_SYSTEM_ONLY_ACTUAL_UNITS_CAN_BE_UPDATED_FOR_THEM}
   * Service Authorization Reference Number can be updated only for
   * the client(s) that were added by the provider and were not
   * already generated as part of roster.
   * @throws AppException
   * Generic Exception Signature.
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_MUST_BE_GT_ZERO}
   * Actual Units must be greater than zero.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_FOLLOWING_RLI_GENERATED_BY_SYSTEM_ONLY_ACTUAL_UNITS_CAN_BE_UPDATED_FOR_THEM}
   * Roster Line Item Service From and Service To can be updated only
   * for the client(s) that were added by the provider and were not
   * already generated as part of roster.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void validateRosterLineItems(
    ProviderRosterLineItemDetailsList providerRosterLineItemDetailsList)
    throws AppException, InformationalException {

    String saReferenceNo = "";
    int saReferenceNoCounter = 0;

    for (ProviderRosterLineItemDetails providerRosterLineItemDetails : providerRosterLineItemDetailsList.details.items()) {
      ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
        providerRosterLineItemDetails.providerRosterLineItemDtls.providerRosterLineItemID);

      // Service Authorization Reference Number can be updated only for the
      // clients that were added by the provider.
      if ((providerRosterLineItem.getAutoGeneratedInd()
        && (!providerRosterLineItem.getSAReferenceNo().equals(
          providerRosterLineItemDetails.providerRosterLineItemDtls.saReferenceNo)))) {

        if (saReferenceNoCounter == 0) {
          saReferenceNo = providerRosterLineItemDetails.rosterLineItemDtls.serviceFrom
            + GeneralConstants.kSpace + CPMConstants.kHypen
            + GeneralConstants.kSpace
            + providerRosterLineItemDetails.rosterLineItemDtls.serviceTo;
          saReferenceNoCounter++;
        } else {
          saReferenceNo += GeneralConstants.kComma + GeneralConstants.kSpace
            + providerRosterLineItemDetails.rosterLineItemDtls.serviceFrom
            + GeneralConstants.kSpace + CPMConstants.kHypen
            + GeneralConstants.kSpace
            + providerRosterLineItemDetails.rosterLineItemDtls.serviceTo;
        }
      }

      // BEGIN, CR00127676  NK
      // If actual units are changed, it must be greater than zero.
      if (!providerRosterLineItem.getUnitsDelivered().equals(
        providerRosterLineItemDetails.rosterLineItemDtls.totalUnitsDelivered)
          && providerRosterLineItemDetails.rosterLineItemDtls.totalUnitsDelivered
            < 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_FV_UNITS_DELIVERED_ENTERED_MUST_BE_GT_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 4);
      }
    }
    // END, CR00127676
    if (saReferenceNo.length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_FOLLOWING_RLI_GENERATED_BY_SYSTEM_ONLY_ACTUAL_UNITS_CAN_BE_UPDATED_FOR_THEM(
          saReferenceNo),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    ValidationHelper.failIfErrorsExist();
  }

  /**
   * Populates the provider roster line item standard struct details from the
   * provider roster line item entity object. Also method populates the client
   * name by concatenating the client first and last name.
   *
   * @param providerRosterLineItem
   * Provider roster line item object holding the provider roster line
   * item details.
   * @return Provider Roster Line Item details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ProviderRosterLineItemDetails getProviderRosterLineItemDetails(
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {
    ProviderRosterLineItemDetails providerRosterLineItemDetails = new ProviderRosterLineItemDetails();
    
    // BEGIN, CR00207010, ASN
    PRLIDetails prliDetails = new PRLIDetails();

    prliDetails.rliCorrectionID = checkIfCorrectionExitsForRLI(
      providerRosterLineItem);

    if (PRLIStatusEntry.COMPLETE.getCode().equals(
      providerRosterLineItem.getLifecycleState().getCode())
        && 0 != prliDetails.rliCorrectionID) {

      PRLICorrection prliCorrection = prliCorrectionDAO.get(
        prliDetails.rliCorrectionID);

      providerRosterLineItemDetails.clientName = prliCorrection.getClientFirstName()
        + CuramConst.gkSpace + prliCorrection.getClientLastName();

      providerRosterLineItemDetails.providerRosterLineItemDtls.versionNo = prliCorrection.getVersionNo();
      providerRosterLineItemDetails.rosterLineItemDtls.serviceFrom = prliCorrection.getServiceDateRange().start();
      providerRosterLineItemDetails.rosterLineItemDtls.serviceTo = prliCorrection.getServiceDateRange().end();
      providerRosterLineItemDetails.providerRosterLineItemDtls.saReferenceNo = prliCorrection.getSAReferenceNo();
      providerRosterLineItemDetails.providerRosterLineItemDtls.caseReferenceNo = prliCorrection.getCaseReferenceNo();
      providerRosterLineItemDetails.providerRosterLineItemDtls.voucherNumber = prliCorrection.getVoucherNo();
      providerRosterLineItemDetails.rosterLineItemDtls.expectedUnits = prliCorrection.getProviderRosterLineItem().getExpectedUnits();
      providerRosterLineItemDetails.rosterLineItemDtls.referenceNo = prliCorrection.getProviderRosterLineItem().getReferenceNumber();
      providerRosterLineItemDetails.rosterLineItemDtls.totalUnitsDelivered = (short) prliCorrection.getTotalUnitsDeliverd();
      providerRosterLineItemDetails.providerRosterLineItemDtls.providerRosterLineItemID = prliCorrection.getProviderRosterLineItem().getID();

      prliDetails.status = prliCorrection.getLifecycleState().toUserLocaleString();

      if (PRLICorrectionStatusEntry.OPEN.toUserLocaleString().equals(
        prliDetails.status)) {
        providerRosterLineItemDetails.providerRosterLineItemDtls.status = PRLIStatusEntry.OPEN.getCode();
      }
      if (PRLICorrectionStatusEntry.PENDINGAPPROVAL.toUserLocaleString().equals(
        prliDetails.status)) {

        providerRosterLineItemDetails.providerRosterLineItemDtls.status = PRLIStatusEntry.PENDINGAPPROVAL.getCode();
      }

      if (PRLICorrectionStatusEntry.APPROVED.toUserLocaleString().equals(
        prliDetails.status)) {

        providerRosterLineItemDetails.providerRosterLineItemDtls.status = PRLIStatusEntry.COMPLETE.getCode();
      }
      if (PRLICorrectionStatusEntry.DENIED.toUserLocaleString().equals(
        prliDetails.status)) {

        providerRosterLineItemDetails.providerRosterLineItemDtls.status = PRLIStatusEntry.DENIED.getCode();
      }

      providerRosterLineItemDetails.providerRosterLineItemDtls.clientFirstName = prliCorrection.getClientFirstName();
      providerRosterLineItemDetails.providerRosterLineItemDtls.clientLastName = prliCorrection.getClientLastName();

      if (prliCorrection.getProviderRosterLineItem().getExpectedUnits() <= 0) {
        providerRosterLineItemDetails.expectedUnitsString = CPMConstants.kEmptyString;
      } else {
        providerRosterLineItemDetails.expectedUnitsString = prliCorrection.getProviderRosterLineItem().getExpectedUnits().toString();
      }

      if (providerRosterLineItem.getUnitsDelivered() <= 0) {
        providerRosterLineItemDetails.unitsDeliveredString = CPMConstants.kEmptyString;
      } else {
        String unitsDeliveredString = String.valueOf(
          prliCorrection.getTotalUnitsDeliverd());

        providerRosterLineItemDetails.unitsDeliveredString = unitsDeliveredString;
      }
    } else {
      // END, CR00207010
      providerRosterLineItemDetails.providerRosterLineItemDtls.providerRosterLineItemID = providerRosterLineItem.getID();
      providerRosterLineItemDetails.providerRosterLineItemDtls.versionNo = providerRosterLineItem.getVersionNo();
      providerRosterLineItemDetails.rosterLineItemDtls.versionNo = providerRosterLineItem.getRLIVersionNo();
      if (providerRosterLineItem.getClient() != null) {
        providerRosterLineItemDetails.clientName = providerRosterLineItem.getClient().getName();
        providerRosterLineItemDetails.rosterLineItemDtls.concernRoleID = providerRosterLineItem.getClient().getID();
        providerRosterLineItemDetails.isRegisteredClientInd = true;

      } else {
        providerRosterLineItemDetails.clientName = providerRosterLineItem.getClientFirstName()
          + CuramConst.gkSpace + providerRosterLineItem.getClientLastName();
      }
      providerRosterLineItemDetails.rosterLineItemDtls.serviceFrom = providerRosterLineItem.getServiceDateFrom();
      providerRosterLineItemDetails.rosterLineItemDtls.serviceTo = providerRosterLineItem.getServiceDateTo();
      providerRosterLineItemDetails.providerRosterLineItemDtls.saReferenceNo = providerRosterLineItem.getSAReferenceNo();
      providerRosterLineItemDetails.providerRosterLineItemDtls.caseReferenceNo = providerRosterLineItem.getCaseReferenceNo();
      providerRosterLineItemDetails.providerRosterLineItemDtls.voucherNumber = providerRosterLineItem.getVoucherNumber();
      providerRosterLineItemDetails.rosterLineItemDtls.expectedUnits = providerRosterLineItem.getExpectedUnits();
      providerRosterLineItemDetails.rosterLineItemDtls.referenceNo = providerRosterLineItem.getReferenceNumber();
      providerRosterLineItemDetails.rosterLineItemDtls.totalUnitsDelivered = providerRosterLineItem.getUnitsDelivered();
      providerRosterLineItemDetails.providerRosterLineItemDtls.status = providerRosterLineItem.getLifecycleState().getCode();
      providerRosterLineItemDetails.providerRosterLineItemDtls.clientFirstName = providerRosterLineItem.getClientFirstName();
      providerRosterLineItemDetails.providerRosterLineItemDtls.clientLastName = providerRosterLineItem.getClientLastName();
      providerRosterLineItemDetails.providerRosterLineItemDtls.voucherNumber = providerRosterLineItem.getVoucherNumber();

      providerRosterLineItemDetails.providerRosterLineItemDtls.exceptionProcInd = providerRosterLineItem.isInExceptionProcessing();

      providerRosterLineItemDetails.providerRosterLineItemDtls.correctionInd = providerRosterLineItem.getCorrectionInd();

      // BEGIN, CR00305429, SS
      providerRosterLineItemDetails.rliCorrectionIndOpt = providerRosterLineItemDetails.providerRosterLineItemDtls.correctionInd;
      // END, CR00305429
      providerRosterLineItemDetails.providerRosterLineItemDtls.autoGeneratedInd = providerRosterLineItem.getAutoGeneratedInd();

      // BEGIN, CR00128756, GYH
      if (providerRosterLineItem.getExpectedUnits() <= 0) {
        providerRosterLineItemDetails.expectedUnitsString = CPMConstants.kEmptyString;
      } else {
        providerRosterLineItemDetails.expectedUnitsString = providerRosterLineItem.getExpectedUnits().toString();
      }

      if (providerRosterLineItem.getUnitsDelivered() <= 0) {
        providerRosterLineItemDetails.unitsDeliveredString = CPMConstants.kEmptyString;
      } else {
        providerRosterLineItemDetails.unitsDeliveredString = providerRosterLineItem.getUnitsDelivered().toString();
      }
      // END, CR00128756
    }

    return providerRosterLineItemDetails;
  }

  // BEGIN, CR00207010, ASN
  /**
   * Checks if the roster line item has correction in open or pending approval
   * state.
   *
   * @param providerRosterLineItem
   * Provider roster line item details.
   *
   * @return Provider roster line item correction Id.
   */
  protected long checkIfCorrectionExitsForRLI(
    final ProviderRosterLineItem providerRosterLineItem) {

    for (final PRLICorrection prliCorrection : prliCorrectionDAO.searchByPRLI(
      providerRosterLineItem.getID())) {

      if (PRLICorrectionStatusEntry.OPEN.getCode().equals(
        prliCorrection.getLifecycleState().getCode())
          || PRLICorrectionStatusEntry.PENDINGAPPROVAL.getCode().equals(
            prliCorrection.getLifecycleState().getCode())) {

        return prliCorrection.getID();
      }
    }
    return 0;
  }

  // END, CR00207010
  
  // BEGIN, CR00215605, ASN

  /**
   * Populates the provider roster line item and the client details.Set
   * indicators associated with each stage of line item used for line item and
   * line item correction merge.
   *
   * @param providerRosterLineItem
   * Provider roster line item object holding the provider roster line
   * item details.
   * @param rosterAndPRLIDetails
   * Roster and provider roster line item details.
   *
   * @return Provider Roster Line Item details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected PRLIDetails getPRLIDetails(
    final ProviderRosterLineItem providerRosterLineItem,
    final RosterAndPRLIDetails rosterAndPRLIDetails) throws AppException,
      InformationalException {
    PRLIDetails prliDetails = new PRLIDetails();

    prliDetails.rliCorrectionID = checkIfCorrectionExitsForRLI(
      providerRosterLineItem);

    if (PRLIStatusEntry.COMPLETE.getCode().equals(
      providerRosterLineItem.getLifecycleState().getCode())) {

      prliDetails.rliCompletedInd = true;
      prliDetails.rliCorrectionID = checkIfCorrectionExitsForRLI(
        providerRosterLineItem);
      prliDetails.rliEditableInd = true;
      prliDetails.rliOpenInd = false;

      if (0 != prliDetails.rliCorrectionID) {

        PRLICorrection prliCorrection = prliCorrectionDAO.get(
          prliDetails.rliCorrectionID);

        prliDetails.versionNo = prliCorrection.getVersionNo();

        prliDetails.hasCorrectionInd = true;

        prliDetails.status = prliCorrection.getLifecycleState().toUserLocaleString();

        if (PRLICorrectionStatusEntry.OPEN.getCode().equals(
          prliCorrection.getLifecycleState().getCode())) {

          prliDetails.rliOpenCorrectionInd = true;
          prliDetails.flag = true;

          if (prliDetails.rliOpenCorrectionInd
            && rosterAndPRLIDetails.dailyAttendanceLinkInd) {

            prliDetails.rliAddAttendanceCorrectionInd = true;
            prliDetails.rliAddAttendanceInd = false;
            // BEGIN, CR00228146, ASN
            prliDetails.attendanceEnabledInd = true;
            prliDetails.restoreOriginalDataEnabledInd = true;
            // END, CR00228146
          }

          if (prliDetails.rliOpenCorrectionInd
            && !rosterAndPRLIDetails.dailyAttendanceLinkInd) {

            prliDetails.rliAddAbsenceCorrectionInd = true;
            prliDetails.rliAddAbsenceInd = false;
            // BEGIN, CR00228146, ASN
            prliDetails.absenceEnabledInd = true;
            prliDetails.restoreOriginalDataEnabledInd = true;
            // END, CR00228146
          }
    
        } else if (PRLICorrectionStatusEntry.PENDINGAPPROVAL.getCode().equals(
          prliCorrection.getLifecycleState().getCode())) {
          prliDetails.rliInPendingApprovalCorrection = true;
          // BEGIN, CR00228146, ASN
          prliDetails.restoreOriginalDataEnabledInd = true;
          prliDetails.approveEnabledInd = true;
          // END, CR00228146
        }
      }
      if ((prliDetails.rliCompletedInd
        && !prliDetails.rliInPendingApprovalCorrection)
          && !prliDetails.excprocInd) {

        prliDetails.rliEditableInd = true;
      }
    } else if (PRLIStatusEntry.OPEN.getCode().equals(
      providerRosterLineItem.getLifecycleState().getCode())) {

      prliDetails.rliOpenInd = true;
      prliDetails.flag = true;
      prliDetails.rliEditableInd = true;
      prliDetails.rliCompletedInd = false;

      if (prliDetails.rliOpenInd && rosterAndPRLIDetails.dailyAttendanceLinkInd) {

        prliDetails.rliAddAttendanceInd = true;
        prliDetails.rliAddAttendanceCorrectionInd = false;
        // BEGIN, CR00228146, ASN
        prliDetails.attendanceEnabledInd = true;
        // END, CR00228146
      }

      if (prliDetails.rliOpenInd
        && !rosterAndPRLIDetails.dailyAttendanceLinkInd) {

        prliDetails.rliAddAbsenceInd = true;
        prliDetails.rliAddAbsenceCorrectionInd = false;
        // BEGIN, CR00228146, ASN
        prliDetails.absenceEnabledInd = true;
        // END, CR00228146
      }

    } else if (PRLIStatusEntry.PENDINGAPPROVAL.getCode().equals(
      providerRosterLineItem.getLifecycleState().getCode())) {

      prliDetails.rliInPendingApprovalInd = true;
      // BEGIN, CR00228146, ASN
      prliDetails.approveEnabledInd = true;
      // END, CR00228146
    }

    if (PRLIStatusEntry.COMPLETE.getCode().equals(
      providerRosterLineItem.getLifecycleState().getCode())
        && 0 != prliDetails.rliCorrectionID) {

      PRLICorrection prliCorrection = prliCorrectionDAO.get(
        prliDetails.rliCorrectionID);

      prliDetails.clientName = prliCorrection.getClientFirstName()
        + CuramConst.gkSpace + prliCorrection.getClientLastName();

      prliDetails.versionNo = prliCorrection.getVersionNo();
      prliDetails.rliDtls.serviceFrom = prliCorrection.getServiceDateRange().start();
      prliDetails.rliDtls.serviceTo = prliCorrection.getServiceDateRange().end();
      prliDetails.prliDtls.saReferenceNo = prliCorrection.getSAReferenceNo();
      prliDetails.prliDtls.caseReferenceNo = prliCorrection.getCaseReferenceNo();
      prliDetails.prliDtls.voucherNumber = prliCorrection.getVoucherNo();
      prliDetails.rliDtls.expectedUnits = prliCorrection.getProviderRosterLineItem().getExpectedUnits();
      prliDetails.rliDtls.referenceNo = prliCorrection.getProviderRosterLineItem().getReferenceNumber();

      prliDetails.rliDtls.totalUnitsDelivered = (short) prliCorrection.getTotalUnitsDeliverd();
      prliDetails.prliDtls.providerRosterLineItemID = prliCorrection.getProviderRosterLineItem().getID();

      prliDetails.status = prliCorrection.getLifecycleState().toUserLocaleString();

      if (PRLICorrectionStatusEntry.OPEN.toUserLocaleString().equals(
        prliDetails.status)) {
        prliDetails.prliDtls.status = PRLIStatusEntry.OPEN.getCode();
      }
      if (PRLICorrectionStatusEntry.PENDINGAPPROVAL.toUserLocaleString().equals(
        prliDetails.status)) {

        prliDetails.prliDtls.status = PRLIStatusEntry.PENDINGAPPROVAL.getCode();
      }

      if (PRLICorrectionStatusEntry.APPROVED.toUserLocaleString().equals(
        prliDetails.status)) {

        prliDetails.prliDtls.status = PRLIStatusEntry.COMPLETE.getCode();
      }
      if (PRLICorrectionStatusEntry.DENIED.toUserLocaleString().equals(
        prliDetails.status)) {

        prliDetails.prliDtls.status = PRLIStatusEntry.DENIED.getCode();
      }

      // BEGIN, CR00243713, PF
      prliDetails.prliDtls.providerRosterLineItemID = providerRosterLineItem.getID();
      prliDetails.prliDtls.versionNo = providerRosterLineItem.getVersionNo();
      prliDetails.rliDtls.versionNo = providerRosterLineItem.getRLIVersionNo();
      // END, CR00243713
      
      prliDetails.prliDtls.clientFirstName = prliCorrection.getClientFirstName();
      prliDetails.prliDtls.clientLastName = prliCorrection.getClientLastName();

      if (prliCorrection.getProviderRosterLineItem().getExpectedUnits() <= 0) {
        prliDetails.expectedUnitsString = CPMConstants.kEmptyString;
      } else {
        prliDetails.expectedUnitsString = prliCorrection.getProviderRosterLineItem().getExpectedUnits().toString();
      }

      if (providerRosterLineItem.getUnitsDelivered() <= 0) {
        prliDetails.unitsDeliveredString = CPMConstants.kEmptyString;
      } else {
        String unitsDeliveredString = String.valueOf(
          prliCorrection.getTotalUnitsDeliverd());

        prliDetails.unitsDeliveredString = unitsDeliveredString;
      }
    } else {

      prliDetails.prliDtls.providerRosterLineItemID = providerRosterLineItem.getID();
      prliDetails.prliDtls.versionNo = providerRosterLineItem.getVersionNo();
      prliDetails.rliDtls.versionNo = providerRosterLineItem.getRLIVersionNo();
      if (providerRosterLineItem.getClient() != null) {
        prliDetails.clientName = providerRosterLineItem.getClient().getName();
        prliDetails.rliDtls.concernRoleID = providerRosterLineItem.getClient().getID();
        prliDetails.isRegisteredClientInd = true;

      } else {
        prliDetails.clientName = providerRosterLineItem.getClientFirstName()
          + CuramConst.gkSpace + providerRosterLineItem.getClientLastName();
      }
      prliDetails.rliDtls.serviceFrom = providerRosterLineItem.getServiceDateFrom();
      prliDetails.rliDtls.serviceTo = providerRosterLineItem.getServiceDateTo();
      prliDetails.prliDtls.saReferenceNo = providerRosterLineItem.getSAReferenceNo();
      prliDetails.prliDtls.caseReferenceNo = providerRosterLineItem.getCaseReferenceNo();
      prliDetails.prliDtls.voucherNumber = providerRosterLineItem.getVoucherNumber();
      prliDetails.rliDtls.expectedUnits = providerRosterLineItem.getExpectedUnits();
      prliDetails.rliDtls.referenceNo = providerRosterLineItem.getReferenceNumber();
      prliDetails.rliDtls.totalUnitsDelivered = providerRosterLineItem.getUnitsDelivered();
      prliDetails.prliDtls.status = providerRosterLineItem.getLifecycleState().getCode();
      prliDetails.prliDtls.clientFirstName = providerRosterLineItem.getClientFirstName();
      prliDetails.prliDtls.clientLastName = providerRosterLineItem.getClientLastName();
      prliDetails.prliDtls.voucherNumber = providerRosterLineItem.getVoucherNumber();

      prliDetails.prliDtls.exceptionProcInd = providerRosterLineItem.isInExceptionProcessing();
      // BEGIN, CR00248227, ASN
      prliDetails.excprocInd = prliDetails.prliDtls.exceptionProcInd;
      // END, CR00248227
      prliDetails.prliDtls.correctionInd = providerRosterLineItem.getCorrectionInd();
      // BEGIN, CR00305429, SS
      prliDetails.rliCorrectionIndOpt = prliDetails.prliDtls.correctionInd;
      // END, CR00305429
      prliDetails.prliDtls.autoGeneratedInd = providerRosterLineItem.getAutoGeneratedInd();

      if (providerRosterLineItem.getExpectedUnits() <= 0) {
        prliDetails.expectedUnitsString = CPMConstants.kEmptyString;
      } else {
        prliDetails.expectedUnitsString = providerRosterLineItem.getExpectedUnits().toString();
      }

      if (providerRosterLineItem.getUnitsDelivered() <= 0) {
        prliDetails.unitsDeliveredString = CPMConstants.kEmptyString;
      } else {
        prliDetails.unitsDeliveredString = providerRosterLineItem.getUnitsDelivered().toString();
      }

    }

    return prliDetails;
  }

  // END, CR00215605

  // BEGIN, CR00228146, ASN

  /**
   * Determines whether the paper roster is configured for the provider or not.
   *
   * @return true if the paper roster is configured for the provider.
   *
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature.
   */
  protected boolean isProviderRosterConfigured(final ProviderKey providerKey)
    throws AppException, InformationalException {
    boolean isPaperRosterRequired = false;

    curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerID);

    for (final ProviderAttendanceTracking providerAttendanceTracking : providerAttendanceTrackingDAO.searchByProvider(
      provider)) {
      if (providerAttendanceTracking.getID() != 0) {
        isPaperRosterRequired = providerAttendanceTracking.isPaperRosterRequired();
      }
    }
    return isPaperRosterRequired;

  }
  // END, CR00228146
}
