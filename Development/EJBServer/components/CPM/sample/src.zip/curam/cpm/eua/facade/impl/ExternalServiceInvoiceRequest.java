/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.eua.facade.impl;


import com.google.inject.Inject;

import curam.cpm.eua.entity.struct.ServiceInvoiceRequestKey;
import curam.cpm.eua.facade.fact.ExternalParticipantFactory;
import curam.cpm.eua.facade.intf.ExternalParticipant;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestDetails;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestDtls;
import curam.cpm.message.impl.SERVICEINVOICEREQUESTExceptionCreator;
import curam.externaluseraccess.impl.Request;
import curam.externaluseraccess.impl.RequestDAO;
import curam.externaluseraccess.impl.RequestStatusEntry;
import curam.externaluseraccess.impl.ServiceInvoiceRequest;
import curam.externaluseraccess.impl.ServiceInvoiceRequestDAO;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality for 
 * Service Invoice Request facade layer
 */
public abstract class ExternalServiceInvoiceRequest extends curam.cpm.eua.facade.base.ExternalServiceInvoiceRequest {

  /**
   * Constructor
   */
  public ExternalServiceInvoiceRequest() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /*
   * Initialize serviceInvoiceRequestDAO
   */
  @Inject
  protected ServiceInvoiceRequestDAO serviceInvoiceRequestDAO;
  
  /*
   * Initialize providerOrganizationDAO
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;
  
  /*
   * Initialize requestDAO
   */
  @Inject
  protected RequestDAO requestDAO;

  /**
   * Creates a service invoice request record.
   *
   * @param serviceInvoiceRequestDtls
   * Contains all details for the service Invoice request record.
   *
   * @return The service invoice request ID for the newly created service
   * invoice request record.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 , replaced with
   * {@link curam.cpm.eua.facade.impl.ExternalServiceInvoiceRequest#createExternalServiceInvoiceRequest(ServiceInvoiceRequestDtls)}
   * . Previously the size of the external reference number had 20
   * characters, in order to allow maximum of 18 characters, a new
   * domain definition of size 18, struct and method are created.
   * See release note: CR00208353.
   */
  @Deprecated
  public ServiceInvoiceRequestKey createServiceInvoiceRequest(ServiceInvoiceRequestDetails
    serviceInvoiceRequestDtls) throws AppException, InformationalException {

    final ServiceInvoiceRequest serviceInvoiceRequest = serviceInvoiceRequestDAO.newInstance();

    // map details passed from client
    setServiceInvoiceRequestFields(serviceInvoiceRequest,
      serviceInvoiceRequestDtls);
    
    // insert the record
    serviceInvoiceRequest.insert();

    ServiceInvoiceRequestKey serviceInvoiceRequestKey = new ServiceInvoiceRequestKey();

    // set the key
    serviceInvoiceRequestKey.requestID = serviceInvoiceRequest.getID();

    return serviceInvoiceRequestKey;
  }

  /**
   * Sets all of the service invoice request fields based on the service Invoice
   * details passed in.
   *
   * @param serviceInvoiceRequest
   * Contains the service invoice request object.
   * @param serviceInvoiceRequestDtls
   * Contains the service invoice request details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 , replaced with
   * {@link curam.cpm.eua.facade.impl.ExternalServiceInvoiceRequest#setExternalServiceInvoiceRequestFields(ServiceInvoiceRequest, ServiceInvoiceRequestDtls)}
   * . Previously the size of the external reference number had 20
   * characters, in order to allow maximum of 18 characters, a new
   * domain definition of size 18, struct and method are created.
   * See release note: CR00208353.
   */
  @Deprecated
  // BEGIN, CR00177241, PM
  protected void setServiceInvoiceRequestFields(
    final ServiceInvoiceRequest serviceInvoiceRequest,
    final ServiceInvoiceRequestDetails serviceInvoiceRequestDtls) throws AppException,
      InformationalException {
    // END, CR00177241

    serviceInvoiceRequest.setExternalReferenceNumber(
      serviceInvoiceRequestDtls.details.externalRefNum);

    // call method to get the concernRoleID for the logged in user
    ExternalParticipant externalParticipantObj = ExternalParticipantFactory.newInstance();

    // set the provider Organization
    serviceInvoiceRequest.setProviderOrganization(
      providerOrganizationDAO.get(
        externalParticipantObj.readProviderProviderGroupID().participantRoleID));

    serviceInvoiceRequest.setCreatedBy(TransactionInfo.getProgramUser());
    
  }
  
  // BEGIN, CR00208353, AS
  /**
   * Creates service invoice request record.
   *
   * @param serviceInvoiceRequestDtls
   * Contains service invoice request details.
   *
   * @return Service invoice request ID for newly created service invoice
   * request record.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceInvoiceRequestKey createExternalServiceInvoiceRequest(
    ServiceInvoiceRequestDtls serviceInvoiceRequestDtls) throws AppException,
      InformationalException {

    final ServiceInvoiceRequest serviceInvoiceRequest = serviceInvoiceRequestDAO.newInstance();

    setExternalServiceInvoiceRequestFields(serviceInvoiceRequest,
      serviceInvoiceRequestDtls);

    serviceInvoiceRequest.insert();

    ServiceInvoiceRequestKey serviceInvoiceRequestKey = new ServiceInvoiceRequestKey();

    serviceInvoiceRequestKey.requestID = serviceInvoiceRequest.getID();

    return serviceInvoiceRequestKey;
  }

  /**
   * Sets all the service invoice request fields based on the service invoice
   * request input criteria.
   *
   * @param serviceInvoiceRequest
   * Contains service invoice request object.
   * @param serviceInvoiceRequestDtls
   * Contains service invoice request details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void setExternalServiceInvoiceRequestFields(
    final ServiceInvoiceRequest serviceInvoiceRequest,
    final ServiceInvoiceRequestDtls serviceInvoiceRequestDtls)
    throws AppException, InformationalException {

    serviceInvoiceRequest.setExternalReferenceNumber(
      serviceInvoiceRequestDtls.externalReferenceNo);

    ExternalParticipant externalParticipantObj = ExternalParticipantFactory.newInstance();

    serviceInvoiceRequest.setProviderOrganization(
      providerOrganizationDAO.get(
        externalParticipantObj.readProviderProviderGroupID().participantRoleID));

    serviceInvoiceRequest.setCreatedBy(TransactionInfo.getProgramUser());

  }

  /**
   * Modifies service invoice request record.
   *
   * @param serviceInvoiceRequestDtls
   * Contains service invoice request details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyExternalServiceInvoiceRequest(
    ServiceInvoiceRequestDtls serviceInvoiceRequestDtls) throws AppException,
      InformationalException {

    final ServiceInvoiceRequest serviceInvoiceRequest = serviceInvoiceRequestDAO.get(
      serviceInvoiceRequestDtls.requestDtls.requestID);

    // BEGIN, CR00208581, AS
    if (serviceInvoiceRequest.getLifecycleState().equals(
      RequestStatusEntry.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICEREQUESTExceptionCreator.ERR_CANNOT_MODIFY_CANCELLED_RECORD(
          serviceInvoiceRequest.getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          3);
    } else if (serviceInvoiceRequest.getLifecycleState().equals(
      RequestStatusEntry.SUBMITTED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICEREQUESTExceptionCreator.ERR_CANNOT_MODIFY_CANCELLED_RECORD(
          serviceInvoiceRequest.getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }
    // END, CR00208581

    setExternalServiceInvoiceRequestDetails(serviceInvoiceRequest,
      serviceInvoiceRequestDtls);
    serviceInvoiceRequest.modify(
      serviceInvoiceRequestDtls.requestDtls.versionNo);
  }

  /**
   * Sets the service invoice request fields for updating the service invoice
   * request record.
   *
   * @param serviceInvoiceRequest
   * Contains service invoice request object.
   * @param serviceInvoiceRequestDtls
   * Contains service invoice request details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void setExternalServiceInvoiceRequestDetails(
    final ServiceInvoiceRequest serviceInvoiceRequest,
    ServiceInvoiceRequestDtls serviceInvoiceRequestDtls) throws AppException,
      InformationalException {

    serviceInvoiceRequest.setComments(
      serviceInvoiceRequestDtls.requestDtls.comments);
    serviceInvoiceRequest.setExternalReferenceNumber(
      serviceInvoiceRequestDtls.externalReferenceNo);

    if (serviceInvoiceRequestDtls.concernRoleID == 0) {
      ExternalParticipant externalParticipantObj = ExternalParticipantFactory.newInstance();

      serviceInvoiceRequestDtls.concernRoleID = externalParticipantObj.readProviderProviderGroupID().participantRoleID;
    }

    serviceInvoiceRequest.setProviderOrganization(
      providerOrganizationDAO.get(serviceInvoiceRequestDtls.concernRoleID));
    serviceInvoiceRequest.setCreatedBy(TransactionInfo.getProgramUser());
  }

  // END, CR00208353

  /**
   * Modifies the Service Invoice Request record.
   *
   * @param details
   * Contains Service Invoice Request details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 , replaced with
   * {@link curam.cpm.eua.facade.impl.ExternalServiceInvoiceRequest#modifyExternalServiceInvoiceRequest(ServiceInvoiceRequestDtls)}
   * . Previously the size of the external reference number had 20
   * characters, in order to allow maximum of 18 characters, a new
   * domain definition of size 18, struct and method are created.
   * See release note: CR00208353.
   */
  @Deprecated
  public void modifyServiceInvoiceRequest(ServiceInvoiceRequestDetails
    details) throws AppException, InformationalException {

    // get the Service Invoice request object
    final ServiceInvoiceRequest serviceInvoiceRequest = serviceInvoiceRequestDAO.get(
      details.requestDtls.requestID);
    
    if (serviceInvoiceRequest.getLifecycleState().equals(
      RequestStatusEntry.CANCELLED)) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICEREQUESTExceptionCreator.ERR_CANNOT_MODIFY_CANCELLED_RECORD(
          serviceInvoiceRequest.getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    } else if (serviceInvoiceRequest.getLifecycleState().equals(
      RequestStatusEntry.SUBMITTED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        SERVICEINVOICEREQUESTExceptionCreator.ERR_CANNOT_MODIFY_CANCELLED_RECORD(
          serviceInvoiceRequest.getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }
    // set the details with the details passed in
    setServiceInvoiceRequestDetails(serviceInvoiceRequest, details);

    // set the version number from the client
    serviceInvoiceRequest.modify(details.requestDtls.versionNo);

  }

  /**
   * Sets the Service Invoice Request Details
   *
   * @param serviceInvoiceRequest
   * Contains Service Invoice Request object
   * @param details
   * Contains service invoice request details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 , replaced with
   * {@link curam.cpm.eua.facade.impl.ExternalServiceInvoiceRequest#setExternalServiceInvoiceRequestDetails(ServiceInvoiceRequest, ServiceInvoiceRequestDtls)}
   * . Previously the size of the external reference number had 20
   * characters, in order to allow maximum of 18 characters, a new
   * domain definition of size 18, struct and method are created.
   * See release note: CR00208353.
   */
  @Deprecated
  // BEGIN, CR00177241, PM
  protected void setServiceInvoiceRequestDetails(final ServiceInvoiceRequest
    serviceInvoiceRequest, ServiceInvoiceRequestDetails details) throws
      AppException, InformationalException {
    // END, CR00177241

    serviceInvoiceRequest.setComments(details.requestDtls.comments);
    serviceInvoiceRequest.setExternalReferenceNumber(
      details.details.externalRefNum);
    
    // set the concern Role ID field
    if (details.concernRoleID == 0) {
      // set it to be logged in user
      // call method to get the concernRoleID 
      ExternalParticipant externalParticipantObj = ExternalParticipantFactory.newInstance();

      details.concernRoleID = externalParticipantObj.readProviderProviderGroupID().participantRoleID;
    } 
    
    // set the provider organization
    serviceInvoiceRequest.setProviderOrganization(
      providerOrganizationDAO.get(details.concernRoleID));
    serviceInvoiceRequest.setCreatedBy(TransactionInfo.getProgramUser());

  }

  /**
   * This method is called from client to read information for the
   * service invoice request 
   *
   * @param key - this contains the service invoice request ID 
   *
   * @return This contains details for the service invoice request record
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ServiceInvoiceRequestDetails readServiceInvoiceRequest(ServiceInvoiceRequestKey
    key) throws AppException, InformationalException {

    final ServiceInvoiceRequest serviceInvoiceRequest = serviceInvoiceRequestDAO.get(
      key.requestID);

    return getServiceInvoiceRequestDetails(serviceInvoiceRequest);
  }
  
  /**
   * This method gets all details about the request to be returned to 
   * the client
   *
   * @param serviceInvoiceRequest
   * @return The service Invoice Request details
   */
  // BEGIN, CR00177241, PM
  protected ServiceInvoiceRequestDetails getServiceInvoiceRequestDetails(
    ServiceInvoiceRequest serviceInvoiceRequest) {
    // END, CR00177241
    
    Request request = requestDAO.get(serviceInvoiceRequest.getID());
    ServiceInvoiceRequestDetails serviceInvoiceRequestDetails = new ServiceInvoiceRequestDetails();
    
    serviceInvoiceRequestDetails.details.externalRefNum = serviceInvoiceRequest.getExternalReferenceNumber();
    serviceInvoiceRequestDetails.requestDtls.comments = serviceInvoiceRequest.getComments();
    serviceInvoiceRequestDetails.details.referenceNumber = serviceInvoiceRequest.getReferenceNumber();
    serviceInvoiceRequestDetails.requestDtls.versionNo = serviceInvoiceRequest.getVersionNo();
    
    // set the request details
    serviceInvoiceRequestDetails.requestDtls.createdBy = request.getCreatedBy();
    serviceInvoiceRequestDetails.requestDtls.dateCreated = request.getDateCreated();
    serviceInvoiceRequestDetails.requestDtls.dateSubmitted = request.getDateSubmitted();
    serviceInvoiceRequestDetails.requestDtls.rejectionReason = request.getRejectionReason();
    serviceInvoiceRequestDetails.requestDtls.requestCategory = request.getRequestCategory().getCode();
    serviceInvoiceRequestDetails.requestDtls.requestStatus = request.getLifecycleState().getCode();
    serviceInvoiceRequestDetails.requestDtls.versionNo = request.getVersionNo();
    serviceInvoiceRequestDetails.requestDtls.requestType = request.getRequestType().getCode();
    serviceInvoiceRequestDetails.requestDtls.comments = request.getComments();
    
    return serviceInvoiceRequestDetails;
    
  }
}
