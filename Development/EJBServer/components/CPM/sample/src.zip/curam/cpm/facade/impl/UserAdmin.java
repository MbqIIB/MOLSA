/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import com.google.inject.Inject;

import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.MaintainAdminConcernRoleDetails;
import curam.core.struct.MaintainAdminConcernRoleKey;
import curam.core.struct.UsersKey;
import curam.cpm.facade.struct.BooleanResult;
import curam.cpm.facade.struct.ConcernRoleAndUserNameDetails;
import curam.cpm.facade.struct.ConcernRoleOwnerAndSupervisorDetails;
import curam.cpm.facade.struct.CreateParticipantOwnerRoleDetails;
import curam.cpm.facade.struct.CurrentUserDetails;
import curam.cpm.facade.struct.UserNameDetails;
import curam.cpm.facade.struct.UserNameDetailsList;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.provider.impl.ProviderStatusEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.transaction.TransactionInfo;


/**
 * The facade layer class for Users roles,used for setting the owner and/or supervisor
 *
 */
public abstract class UserAdmin extends curam.cpm.facade.base.UserAdmin {

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  // BEGIN, CR00235784, GP
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;
  // END, CR00235784

  /**
   * Constructor
   */
  public UserAdmin() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * List concern role owner supervisor list.
   *
   * @param key Concern role id.
   *
   * @return concern role owner supervisor list.
   *
   * @throws AppException
   * @throws InformationalException
   */
  public UserNameDetailsList listOwnerSupervisor(ConcernRoleKey key) throws AppException, InformationalException {

    curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();
    UserNameDetailsList userNameDetailsList = new UserNameDetailsList();

    userNameDetailsList = maintainAdminConcernRole.listProviderOrganisationSupervisor(
      key);

    return userNameDetailsList;

  }

  /**
   * List subordinate users for current user.
   *
   * @return subordinate user list for currently logged in user.
   *
   * @throws AppException
   * @throws InformationalException
   */
  public UserNameDetailsList listSubordinateUserForCurrentUser() throws AppException, InformationalException {

    curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();
    UserNameDetailsList userNameDetailsList = new UserNameDetailsList();

    UsersKey usersKey = new UsersKey();

    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    userNameDetailsList = maintainAdminConcernRole.listSubordinateUser(usersKey);

    return userNameDetailsList;
  }

  /**
   * List subordinate users for user.
   *
   * @param key user name
   *
   * @return supervisor user list for a user.
   * @throws AppException
   * @throws InformationalException
   */
  public UserNameDetailsList listSupervisorUserForUser(UsersKey key) throws AppException, InformationalException {

    curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();
    UserNameDetailsList userNameDetailsList = new UserNameDetailsList();

    userNameDetailsList = maintainAdminConcernRole.listSupervisorUser(key);

    return userNameDetailsList;
  }

  /**
   * Create a new owner for the concernRole supplied.
   *
   * @param details The administrator role details being entered.
   * @throws AppException
   * @throws InformationalException
   */
  public void createOwner(CreateParticipantOwnerRoleDetails details) throws AppException, InformationalException {

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.concernRoleID);

    // If the Provider Status is closed
    if (providerOrganization.getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {
      if (providerDAO.get(providerOrganization.getID()).getLifecycleState().equals(
        ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 8);
        ValidationHelper.failIfErrorsExist();
      }
    }

    curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();

    maintainAdminConcernRole.setProviderOrganisationOwner(details);

    // check for informational exceptions
    TransactionInfo.getInformationalManager().failOperation();

  }

  /**
   * Method to create a new Facility Manager for the concern role supplied.
   *
   * @param details The administrator role details being entered.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * if the status of the provider is closed.
   */
  public void createFacilityManager(CreateParticipantOwnerRoleDetails details)
    throws AppException, InformationalException {

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.concernRoleID);

    if (providerOrganization.getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {
      if (providerDAO.get(providerOrganization.getID()).getLifecycleState().equals(
        ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 9);
      }
    }
    curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();

    maintainAdminConcernRole.setProviderOrganizationFacilityManager(details);

    TransactionInfo.getInformationalManager().failOperation();
  }

  /**
   * Create a new supervisor for the concern role supplied.
   *
   * @param details Concern role and administrator role details.
   * @throws AppException
   * @throws InformationalException
   */
  public void createSupervisor(ConcernRoleAndUserNameDetails details) throws AppException, InformationalException {

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      details.concernRoleID);

    // if the status of the provider is closed
    if (providerOrganization.getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {
      if (providerDAO.get(providerOrganization.getID()).getLifecycleState().equals(
        ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 10);
        ValidationHelper.failIfErrorsExist();
      }
    }

    curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();

    MaintainAdminConcernRoleKey maintainAdminConcernRoleKey = new MaintainAdminConcernRoleKey();

    // Get concern role ID from key
    maintainAdminConcernRoleKey.concernRoleID = details.concernRoleID;

    // Prepare details to be passed into create method
    MaintainAdminConcernRoleDetails maintainAdminConcernRoleDetails = new MaintainAdminConcernRoleDetails();

    maintainAdminConcernRoleDetails.concernRoleID = details.concernRoleID;
    maintainAdminConcernRoleDetails.userName = details.userName;
    maintainAdminConcernRoleDetails.typeCode = curam.codetable.ADMINCONCERNROLETYPE.SUPERVISOR;

    maintainAdminConcernRole.createNewAdminUserRole(maintainAdminConcernRoleKey,
      maintainAdminConcernRoleDetails);

    // check for informational exceptions
    TransactionInfo.getInformationalManager().failOperation();

  }

  /**
   * Create a new owner and new supervisor for the concern role supplied.
   *
   * @param details Concern role and administrator role details.
   * @throws AppException
   * @throws InformationalException
   */
  public void createOwnerAndSupervisor(ConcernRoleOwnerAndSupervisorDetails details) throws AppException, InformationalException {

    curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();

    maintainAdminConcernRole.setProviderOrganisationOwnerAndSupervisor(details);

    // check for informational exceptions
    TransactionInfo.getInformationalManager().failOperation();
  }

  /**
   * Determine if user is a subordinate user for a supervisor of concern role
   * provided.
   *
   * @param details Concern role and administrator role details.
   *
   * @return BooleanResult
   * returns true if user is a subordinate user for a supervisor of concern role
   * provided.
   *
   * @throws AppException
   * @throws InformationalException*
   */
  public BooleanResult isSubordinateUserForConcernRoleSupervisor(ConcernRoleAndUserNameDetails details) throws AppException, InformationalException {

    curam.useradmin.impl.MaintainAdminConcernRole maintainAdminConcernRole = new curam.useradmin.impl.MaintainAdminConcernRole();

    return maintainAdminConcernRole.isSubordinateUserForConcernRoleSupervisor(
      details);
  }

  // BEGIN, CR00237197, GP
  /**
   * Returns the details for the current user.
   *
   * @return The User details for the current User.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced by {@link #getCurrentUserDetails()}.
   * This method is not useful for displaying user full name. Hence
   * this method is deprecated. The newly added method will give the
   * option to the user to display the user full name. See release
   * note: CR00237197.
   */
  @Deprecated
  // END, CR00237197
  public CurrentUserDetails getCurrentUser() throws AppException, InformationalException {

    CurrentUserDetails currentUserDetails = new CurrentUserDetails();

    currentUserDetails.userName = TransactionInfo.getProgramUser();

    return currentUserDetails;
  }

  // BEGIN, CR00235784, GP
  /**
   * Gets the current user details.
   *
   * @return Current user details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public UserNameDetails getCurrentUserDetails() throws AppException,
      InformationalException {

    UserNameDetails userNameDetails = new UserNameDetails();

    userNameDetails.userName = TransactionInfo.getProgramUser();

    User user = userDAO.get(userNameDetails.userName);

    userNameDetails.fullName = user.getFullName();

    return userNameDetails;
  }
  // END, CR00235784

}
