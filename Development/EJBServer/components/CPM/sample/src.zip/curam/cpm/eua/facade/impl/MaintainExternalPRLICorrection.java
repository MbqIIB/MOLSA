/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import com.google.inject.Inject;
import curam.attendance.impl.AbsencePeriod;
import curam.attendance.impl.AbsencePeriodCorrection;
import curam.attendance.impl.AbsencePeriodCorrectionDAO;
import curam.attendance.impl.AbsencePeriodDAO;
import curam.attendance.impl.AttendanceConfigurationHelper;
import curam.attendance.impl.AttendancePaymentProcessing;
import curam.attendance.impl.DailyAttendance;
import curam.attendance.impl.DailyAttendanceCorrection;
import curam.attendance.impl.DailyAttendanceCorrectionDAO;
import curam.attendance.impl.DailyAttendanceDAO;
import curam.attendance.impl.PRLICorrection;
import curam.attendance.impl.PRLICorrectionDAO;
import curam.attendance.impl.PRLICorrectionHistory;
import curam.attendance.impl.PRLICorrectionHistoryDAO;
import curam.attendance.impl.PRLISALILink;
import curam.attendance.impl.PRLISALILinkDAO;
import curam.attendance.impl.ProviderRosterLineItem;
import curam.attendance.impl.ProviderRosterLineItemDAO;
import curam.attendance.impl.SOAttendanceConfiguration;
import curam.attendance.impl.SOAttendanceConfigurationDAO;
import curam.codetable.impl.ATTENDANCEABSENCEREASONEntry;
import curam.codetable.impl.ATTENDANCEEntry;
import curam.codetable.impl.ATTENDANCETRACKINGHOURSEntry;
import curam.codetable.impl.ATTENDANCETRACKINGMINUTESEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.fact.AddressFactory;
import curam.core.intf.Address;
import curam.core.sl.entity.struct.RosterKey;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.InstructionLineItemDtls;
import curam.cpm.facade.struct.AbsenceCorrectionDetails;
import curam.cpm.facade.struct.CorrectionDetails;
import curam.cpm.facade.struct.DailyAttendanceDetails;
import curam.cpm.facade.struct.DailyAttendanceDetailsList;
import curam.cpm.facade.struct.PRLIAttendanceCorrectionDetails;
import curam.cpm.facade.struct.PRLICorrectionDetails;
import curam.cpm.facade.struct.PRLICorrectionHistoryList;
import curam.cpm.facade.struct.PRLICorrectionSummaryDetails;
import curam.cpm.facade.struct.PRLICorrectionSummaryDetailsList;
import curam.cpm.facade.struct.ReportingDailyAttendanceDetails;
import curam.cpm.facade.struct.VersionNo;
import curam.cpm.facade.struct.ViewDailyAttendanceReportingDetails;
import curam.cpm.facade.struct.ViewReportingDailyAttendanceDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.AbsencePeriodCorrectionDtls;
import curam.cpm.sl.entity.struct.AbsencePeriodCorrectionKey;
import curam.cpm.sl.entity.struct.DailyAttendanceCorrectionDtls;
import curam.cpm.sl.entity.struct.PRLICorrectionDtls;
import curam.cpm.sl.entity.struct.PRLICorrectionHistoryDtls;
import curam.cpm.sl.entity.struct.PRLICorrectionKey;
import curam.cpm.sl.entity.struct.ProviderRosterLineItemKey;
import curam.cpm.sl.fact.FinancialNotificationFactory;
import curam.cpm.sl.intf.FinancialNotification;
import curam.cpm.sl.struct.FinancialNotificationKey;
import curam.cpm.util.impl.AttendanceWidgetHelper;
import curam.cpm.util.impl.WidgetHelper;
import curam.financial.FinancialNotificationEvent;
import curam.financial.impl.PaymentProcessing;
import curam.message.DAILYATTENDANCECORRECTION;
import curam.message.ROSTER;
import curam.message.impl.DAILYATTENDANCECORRECTIONExceptionCreator;
import curam.message.impl.PRLICORRECTIONExceptionCreator;
import curam.message.impl.ROSTERExceptionCreator;
import curam.provider.PRLIStatus;
import curam.provider.impl.PRLIStatusEntry;
import curam.serviceauthorization.impl.ServiceAuthorization;
import curam.servicedelivery.impl.ServiceDelivery;
import curam.servicedelivery.impl.ServiceDeliveryDAO;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.Money;
import curam.util.type.StringHelper;


/**
 * This process class provides the functionality for the Provider Roster Line
 * Item Correction facade layer.
 */
public class MaintainExternalPRLICorrection extends curam.cpm.eua.facade.base.MaintainExternalPRLICorrection {

  /**
   * Provider Roster Line Item Correction DAO
   */
  @Inject
  protected PRLICorrectionDAO prliCorrectionDAO;

  /**
   * Provider Roster Line Item DAO
   */
  @Inject
  protected ProviderRosterLineItemDAO providerRosterLineItemDAO;

  /**
   * Daily Attendance Correction DAO
   */
  @Inject
  protected DailyAttendanceCorrectionDAO dailyAttendanceCorrectionDAO;

  /**
   * Provider Roster Line Item History DAO
   */
  @Inject
  protected PRLICorrectionHistoryDAO prliCorrectionHistoryDAO;

  /**
   * Service Offering Attendance Configuration DAO
   */
  @Inject
  protected SOAttendanceConfigurationDAO soAttendanceConfigurationDAO;

  /**
   * Absence Period Correction DAO
   */
  @Inject
  protected AbsencePeriodCorrectionDAO absencePeriodCorrectionDAO;

  /**
   * Daily Attendance DAO.
   */
  @Inject
  protected DailyAttendanceDAO dailyAttendanceDAO;

  /**
   * Absence Period DAO reference.
   */
  @Inject
  protected AbsencePeriodDAO absencePeriodDAO;

  /**
   * Reference to class DailyAttendance.
   */
  @Inject
  protected DailyAttendance dailyAttendance;

  /**
   * Reference to class AbsencePeriod.
   */
  @Inject
  protected AbsencePeriod absencePeriod;

  /**
   * Reference to class PaymentProcessing.
   */
  @Inject
  protected PaymentProcessing paymentProcessing;

  /**
   * Reference to class AttendancePaymentProcessing.
   */
  @Inject
  protected AttendancePaymentProcessing attendancePaymentProcessing;

  // BEGIN, CR00176474, AS
  // BEGIN, CR00178377, AS
  /**
   * Reference to Attendance Configuration Helper.
   */
  @Inject
  protected AttendanceConfigurationHelper attendanceConfigurationHelper;
  // END, CR00178377
  // END, CR00176474

  // BEGIN, CR00233623, ASN

  /**
   * Reference to PRLI SALI Link DAO.
   */
  @Inject
  protected PRLISALILinkDAO prliSALILinkDAO;

  // END, CR00233623
  
  @Inject
  protected ServiceDeliveryDAO serviceDeliveryDAO;

  /**
   * Default Constructor.
   */
  public MaintainExternalPRLICorrection() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Method used to create a PRLI Correction record. It captures SA, client
   * details, Daily attendance details and absence reason.
   *
   * @param prliCorrectionDetails
   * Contains SA, client details, Daily attendance details and absence
   * reason
   * @return Key that contains internal identifier for PRLICorrection
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLICorrectionKey createPRLICorrection(
    final PRLICorrectionDetails prliCorrectionDetails) throws AppException,
      InformationalException {

    final PRLICorrectionKey prliCorrectionKey = new PRLICorrectionKey();
    final PRLICorrection prliCorrection = prliCorrectionDAO.newInstance();

    // BEGIN CR00128151,SS
    // Set the client reference number before setting the client address as
    // this is used in validation of client address insertion.
    if (prliCorrectionDetails.isGeneratedByUser) {
      prliCorrection.setClientReferenceNo(
        prliCorrectionDetails.correctionDetails.clientReferenceNo);
      final AddressDtls addressDtls = new AddressDtls();

      addressDtls.addressData = prliCorrectionDetails.clientAddress;
      prliCorrection.setClientAddress(addressDtls);
      // BEGIN, CR00153665, RD
      prliCorrection.setClientAddressID(
        prliCorrectionDetails.correctionDetails.clientAddressID);
      // END, CR00153665      
    }
    // END CR00128151

    setPRLICorrection(prliCorrection, prliCorrectionDetails, true);
    prliCorrection.insert();
    prliCorrectionKey.prliCorrectionID = prliCorrection.getID();

    createPRLICorrectionHistory(prliCorrection);

    // Based on the configuration create daily attendance correction or
    // absence period correction
    SOAttendanceConfiguration soAttendanceConfiguration = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      prliCorrection.getProviderRosterLineItem().getRoster().getServiceOffering(),
      Date.getCurrentDate());

    if (soAttendanceConfiguration != null
      && soAttendanceConfiguration.isDailyAttendanceTrackingRequired()) {
      createDailyAttendanceCorrection(prliCorrection);
    } else {
      createAbsenceDetailsCorrection(prliCorrection);
    }

    return prliCorrectionKey;
  }

  /**
   * Deletes a Provider Roster Line Item correction.
   *
   * @param correctionKey
   * Contains the PRLICorrection ID to be submitted.
   * @param versionNo
   * Contains version no
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deletePRLICorrection(PRLICorrectionKey correctionKey,
    VersionNo versionNo) throws AppException, InformationalException {

    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      correctionKey.prliCorrectionID);

    prliCorrection.cancel(versionNo.versionNo);
    createPRLICorrectionHistory(prliCorrection);
  }

  /**
   * This method used to return all the corrections made for a Roster Line Item.
   *
   * @param providerRosterLineItemKey
   * Contains internal identifier for Provider Roster Line Item.
   * @return List of corrections that are made to the Provider Roster Line Item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLICorrectionSummaryDetailsList listPRLICorrectionDetails(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {

    final PRLICorrectionSummaryDetailsList prliCorrectionSummaryDetailsList = new PRLICorrectionSummaryDetailsList();

    // Loop through the prliCorrection entity and assign the values to
    // prliCorrectionSummaryDetails for display
    for (PRLICorrection prliCorrection : prliCorrectionDAO.searchByPRLI(
      providerRosterLineItemKey.providerRosterLineItemID)) {

      final PRLICorrectionSummaryDetails prliCorrectionSummaryDetails = new PRLICorrectionSummaryDetails();

      prliCorrectionSummaryDetails.correctionDetails.prliCorrectionID = prliCorrection.getID();

      prliCorrectionSummaryDetails.clientName = prliCorrection.getClientFirstName()
        + GeneralConstants.kSpace + prliCorrection.getClientLastName();

      prliCorrectionSummaryDetails.correctionDetails.serviceFromDate = prliCorrection.getServiceDateRange().start();
      prliCorrectionSummaryDetails.correctionDetails.serviceToDate = prliCorrection.getServiceDateRange().end();
      // BEGIN, CR00176474, AS
      // BEGIN, CR00178377, AS
      if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
        || attendanceConfigurationHelper.isReportingMethodUtilization(
          prliCorrection.getProviderRosterLineItem().getRoster())) {
        // END, CR00178377
        prliCorrectionSummaryDetails.correctionDetails.totalUnitsDelivered = prliCorrection.getTotalUnitsDeliverd();
        prliCorrectionSummaryDetails.expectedUnits = prliCorrection.getProviderRosterLineItem().getExpectedUnits();
      }
      // END, CR00176474
      prliCorrectionSummaryDetails.correctionDetails.status = prliCorrection.getLifecycleState().getCode();

      SOAttendanceConfiguration soAttendanceConfiguration = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
        prliCorrection.getProviderRosterLineItem().getRoster().getServiceOffering(),
        Date.getCurrentDate());

      if (soAttendanceConfiguration != null) {
        prliCorrectionSummaryDetails.isDailyAttendanceTrackingRequired = soAttendanceConfiguration.isDailyAttendanceTrackingRequired();
      }

      prliCorrectionSummaryDetailsList.detailsList.addRef(
        prliCorrectionSummaryDetails);

    }

    return sortPRLICorrections(prliCorrectionSummaryDetailsList);
  }

  /**
   * This method is used to sort the provider roster line item correction
   * records based on service from date with latest first.
   *
   * @param unsortedPRLICorrectionSummaryDetails
   * Unsorted provider roster line item correction records.
   *
   * @return Sorted provider roster line item correction records.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  // BEGIN, CR00177241, PM
  protected PRLICorrectionSummaryDetailsList sortPRLICorrections(
    final PRLICorrectionSummaryDetailsList unsortedPRLICorrectionSummaryDetails) {
    // END, CR00177241
    // Sort by Service From Date for display.
    final List<PRLICorrectionSummaryDetails> prliCorrectionSummaryDetailsList = new ArrayList<PRLICorrectionSummaryDetails>();

    for (final PRLICorrectionSummaryDetails details : unsortedPRLICorrectionSummaryDetails.detailsList.items()) {
      prliCorrectionSummaryDetailsList.add(details);
    }

    Collections.sort(prliCorrectionSummaryDetailsList,
      new Comparator<PRLICorrectionSummaryDetails>() {
      public int compare(final PRLICorrectionSummaryDetails lhs,
        final PRLICorrectionSummaryDetails rhs) {
        return lhs.correctionDetails.serviceFromDate.compareTo(
          rhs.correctionDetails.serviceToDate);
      }
    });

    final PRLICorrectionSummaryDetailsList prliCorrectionSummaryDetailsListSorted = new PRLICorrectionSummaryDetailsList();

    prliCorrectionSummaryDetailsListSorted.detailsList.addAll(
      prliCorrectionSummaryDetailsList);

    return prliCorrectionSummaryDetailsListSorted;
  }

  /**
   * This method returns the history of a Roster Line Item correction.
   *
   * @param prliCorrectionKey
   * Contains internal identifier for Provider Roster Line Item
   * Correction
   * @return List of Provider Roster Line Item History details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLICorrectionHistoryList listPRLICorrectionHistory(
    PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    final PRLICorrectionHistoryList prliCorrectionHistoryList = new PRLICorrectionHistoryList();

    // Loop through the prliCorrectionHistory entity and assign the values to
    // prliCorrectionHistoryDtls for display
    for (PRLICorrectionHistory prliCorrectionHistory : prliCorrectionHistoryDAO.getHistoryForPRLICorrection(
      prliCorrectionKey.prliCorrectionID)) {

      final PRLICorrectionHistoryDtls prliCorrectionHistoryDtls = new PRLICorrectionHistoryDtls();

      prliCorrectionHistoryDtls.dateTime = prliCorrectionHistory.getDateTime();
      prliCorrectionHistoryDtls.prliCorrectionHistoryID = prliCorrectionHistory.getID();
      prliCorrectionHistoryDtls.prliCorrectionID = prliCorrectionHistory.getPRLICorrection().getID();
      prliCorrectionHistoryDtls.status = prliCorrectionHistory.getPRLICorrectionStatus().getCode();
      prliCorrectionHistoryDtls.userName = prliCorrectionHistory.getUserName();

      prliCorrectionHistoryList.correctionHistory.addRef(
        prliCorrectionHistoryDtls);
    }

    return sortPRLICorrectionHistory(prliCorrectionHistoryList);
  }

  /**
   * This method is used to sort the provider roster line item correction
   * history records based on date and time with latest first.
   *
   * @param unsortedPRLICorrectionHistory
   * Unsorted provider roster line item correction history records.
   *
   * @return Sorted provider roster line item correction history records.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  // BEGIN, CR00177241, PM
  protected PRLICorrectionHistoryList sortPRLICorrectionHistory(
    final PRLICorrectionHistoryList unsortedPRLICorrectionHistory) {
    // END, CR00177241

    // Sort by Date and Time for display.
    final List<PRLICorrectionHistoryDtls> prliCorrectionHistoryList = new ArrayList<PRLICorrectionHistoryDtls>();

    for (final PRLICorrectionHistoryDtls details : unsortedPRLICorrectionHistory.correctionHistory.items()) {
      prliCorrectionHistoryList.add(details);
    }

    Collections.sort(prliCorrectionHistoryList,
      new Comparator<PRLICorrectionHistoryDtls>() {
      public int compare(final PRLICorrectionHistoryDtls lhs,
        final PRLICorrectionHistoryDtls rhs) {
        return lhs.dateTime.compareTo(rhs.dateTime);
      }
    });

    final PRLICorrectionHistoryList prliCorrectionHistoryListSorted = new PRLICorrectionHistoryList();

    prliCorrectionHistoryListSorted.correctionHistory.addAll(
      prliCorrectionHistoryList);

    return prliCorrectionHistoryListSorted;
  }

  /**
   * Method used to view Provider Roster Line item corrections. It displays only
   * new values.
   *
   * @param prliCorrectionKey
   * Contains internal identifier for PRLICorrection
   * @return Provider Roster Line Item Correction details
   *
   * @throws InformationalException
   * @throws AppException
   * Generic Exception Signature.
   */
  public CorrectionDetails readPRLICorrection(
    PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    final CorrectionDetails correctionDetails = new CorrectionDetails();

    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliCorrectionKey.prliCorrectionID);
  
    correctionDetails.details = assignToPRLICorrectionDtls(prliCorrection);

    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        prliCorrection.getProviderRosterLineItem().getRoster())) {
      // END, CR00178377
      correctionDetails.expectedUnits = prliCorrection.getProviderRosterLineItem().getExpectedUnits();
    }
    // END, CR00176474

    correctionDetails.isGeneratedByUser = !prliCorrection.getProviderRosterLineItem().getAutoGeneratedInd();
    
    // BEGIN, CR00128486,RPB
    // If generated by system fetch address from Provider roster line item.
    // If generated by user fetch address from PRLICorrection.
    if (correctionDetails.isGeneratedByUser) {
      if (prliCorrection.getClientAddressID() != CPMConstants.kZeroLong) {
        correctionDetails.clientAddress = prliCorrection.getClientAddressData();
      }
    } else {
      if (prliCorrection.getProviderRosterLineItem().getAddressID()
        != CPMConstants.kZeroLong) {
        correctionDetails.clientAddress = prliCorrection.getProviderRosterLineItem().getAddressData();
      }
    }
    // END, CR00128486
    
    correctionDetails.details.versionNo = prliCorrection.getVersionNo();

    // Load the Daily attendanceCorrection details
    for (DailyAttendanceCorrection dailyAttendanceCorrection : sortDailyAttendanceCorrectionByServiceDate(
      dailyAttendanceCorrectionDAO.searchByPRLICorrection(
        prliCorrectionKey.prliCorrectionID))) {
      final DailyAttendanceCorrectionDtls dailyAttendanceCorrectionDtls = new DailyAttendanceCorrectionDtls();

      dailyAttendanceCorrectionDtls.absenceReason = dailyAttendanceCorrection.getAbsenceReason().getCode();
      dailyAttendanceCorrectionDtls.attendance = dailyAttendanceCorrection.getAttendance().getCode();
      dailyAttendanceCorrectionDtls.serviceDate = dailyAttendanceCorrection.getServiceDate();
      dailyAttendanceCorrectionDtls.unitsAttended = dailyAttendanceCorrection.getUnitsAttended();
      dailyAttendanceCorrectionDtls.unitsUnattended = dailyAttendanceCorrection.getUnitsUnattended();
      correctionDetails.dailyAttendanceDetails.addRef(
        dailyAttendanceCorrectionDtls);
    }

    // If there are dailyAttendance details, set
    // dailyAttendanceTrackingRequired indicator to true.
    if (correctionDetails.dailyAttendanceDetails.size()
      > CPMConstants.kZeroLong) {
      correctionDetails.isDailyAttendanceTrackingRequired = true;
    } else {

      for (AbsencePeriodCorrection absencePeriodCorrection : absencePeriodCorrectionDAO.searchByPRLICorrection(
        prliCorrectionKey.prliCorrectionID)) {
        final AbsencePeriodCorrectionDtls absencePeriodCorrectionDtls = new AbsencePeriodCorrectionDtls();

        absencePeriodCorrectionDtls.absenceDate = absencePeriodCorrection.getAbsenceDate();
        absencePeriodCorrectionDtls.absenceReason = absencePeriodCorrection.getAbsenceReason();
        absencePeriodCorrectionDtls.unitsUnattended = absencePeriodCorrection.getUnitsUnattended();
        correctionDetails.absenceDetailsList.addRef(absencePeriodCorrectionDtls);
      }
      if (correctionDetails.absenceDetailsList.size() > 0) {
        correctionDetails.isAbsenceCorrectionAvailable = true;
      }

    }

    correctionDetails.serviceName = prliCorrection.getProviderRosterLineItem().getRoster().getProviderOffering().getServiceOffering().getName();

    return correctionDetails;
  }

  /**
   * Method to assign the values available in PRLICorrection to
   * PRLICorrectinDtls struct.
   *
   * @param prliCorrection
   * PRLICorrection object
   * @return PRLICorrectionDtls object
   */
  // BEGIN, CR00177241, PM
  protected PRLICorrectionDtls assignToPRLICorrectionDtls(
    PRLICorrection prliCorrection) {
    // END, CR00177241

    // BEGIN, CR00128486,RPB
    PRLICorrectionDtls prliCorrectionDtls = null;

    // If roster is auto generated fetch the details from Provider roster
    // line item.
    ProviderRosterLineItem providerRosterLineItem = prliCorrection.getProviderRosterLineItem();

    if (providerRosterLineItem.getAutoGeneratedInd()) {
      prliCorrectionDtls = getPRLICorrectionDetails(providerRosterLineItem);

      prliCorrectionDtls.totalUnitsDelivered = prliCorrection.getTotalUnitsDeliverd();

      prliCorrectionDtls.reason = prliCorrection.getReason();
      prliCorrectionDtls.status = prliCorrection.getLifecycleState().getCode();

      prliCorrectionDtls.totalUnitsDelivered = prliCorrection.getTotalUnitsDeliverd();
      prliCorrectionDtls.prliCorrectionID = prliCorrection.getID();

    } else {
      // If roster is generated by user fetch the details from PRLI Correction
      prliCorrectionDtls = new PRLICorrectionDtls();
      prliCorrectionDtls.prliCorrectionID = prliCorrection.getID();
      prliCorrectionDtls.providerRosterLineItemID = prliCorrection.getProviderRosterLineItem().getID();
      prliCorrectionDtls.clientDOB = prliCorrection.getClientDOB();
      prliCorrectionDtls.clientFirstName = prliCorrection.getClientFirstName();
      prliCorrectionDtls.clientLastName = prliCorrection.getClientLastName();
      prliCorrectionDtls.clientReferenceNo = prliCorrection.getClientReferenceNo();
      // BEGIN, CR00153665, RD
      prliCorrectionDtls.clientAddressID = prliCorrection.getClientAddressID();
      // END, CR00153665
      prliCorrectionDtls.reason = prliCorrection.getReason();
      prliCorrectionDtls.saReferenceNo = prliCorrection.getSAReferenceNo();
      // BEGIN, CR00128590, RD
      prliCorrectionDtls.caseReferenceNo = prliCorrection.getCaseReferenceNo();
      // END, CR00128590
      prliCorrectionDtls.serviceFromDate = prliCorrection.getServiceDateRange().start();
      prliCorrectionDtls.serviceToDate = prliCorrection.getServiceDateRange().end();
      prliCorrectionDtls.status = prliCorrection.getLifecycleState().getCode();
      prliCorrectionDtls.voucherNo = prliCorrection.getVoucherNo();
      prliCorrectionDtls.totalUnitsDelivered = prliCorrection.getTotalUnitsDeliverd();
    }
    // END, CR00128486
    return prliCorrectionDtls;
  }

  /**
   * This method reads the details from provider roster line item, roster line
   * item and address entities and sets the values to facade struct for
   * correction.
   *
   * @param providerRosterLineItemKey
   * Contains internal identifier for Provider Roster Line Item
   * @return Provider Roster Line Item details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLICorrectionDetails readPRLIDetails(
    final ProviderRosterLineItemKey providerRosterLineItemKey)
    throws AppException, InformationalException {

    final PRLICorrectionDetails prliCorrectionDetails = new PRLICorrectionDetails();

    final ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    prliCorrectionDetails.correctionDetails = getPRLICorrectionDetails(
      providerRosterLineItem);
    prliCorrectionDetails.expectedUnits = providerRosterLineItem.getExpectedUnits();

    if (providerRosterLineItem.getAddressID() != CPMConstants.kZeroLong) {
      prliCorrectionDetails.clientAddress = providerRosterLineItem.getAddressData();
      // BEGIN, CR00153665, RD
      prliCorrectionDetails.correctionDetails.clientAddressID = providerRosterLineItem.getAddressID();
      // END, CR00153665
    }

    prliCorrectionDetails.isGeneratedByUser = !providerRosterLineItem.getAutoGeneratedInd();

    // Based on the configuration set if daily attendance tracking is
    // required or not
    SOAttendanceConfiguration soAttendanceConfiguration = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      providerRosterLineItem.getRoster().getServiceOffering(),
      Date.getCurrentDate());

    if (soAttendanceConfiguration != null) {
      prliCorrectionDetails.isDailyAttendanceTrackingRequired = soAttendanceConfiguration.isDailyAttendanceTrackingRequired();
    }

    return prliCorrectionDetails;
  }

  /**
   * This method is used to update the provider roster line item correction
   * details which contains Roster details, Client details, Client address and
   * Daily Attendance/Absence period.
   *
   * @param prliCorrectionDetails
   * Contains the details of provider roster line item correction.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void updatePRLICorrection(
    final PRLICorrectionDetails prliCorrectionDetails) throws AppException,
      InformationalException {

    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliCorrectionDetails.correctionDetails.prliCorrectionID);

    // Set the value for update only if the prliCorrection is generated
    // by the user
    if (prliCorrectionDetails.isGeneratedByUser) {
      final AddressDtls addressDtls = new AddressDtls();

      addressDtls.addressData = prliCorrectionDetails.clientAddress;
      addressDtls.addressID = prliCorrection.getClientAddressID();

      // This call will update the addressDtls
      prliCorrection.setClientAddress(addressDtls);
    }

    setPRLICorrection(prliCorrection, prliCorrectionDetails,
      prliCorrectionDetails.isGeneratedByUser);

    prliCorrection.modify(prliCorrectionDetails.correctionDetails.versionNo);

    SOAttendanceConfiguration soAttendanceConfiguration = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      prliCorrection.getProviderRosterLineItem().getRoster().getServiceOffering(),
      Date.getCurrentDate());

    // Daily attendance corrections or absence corrections has to be updated
    // based on the changes in the service from date and to date.
    if (soAttendanceConfiguration != null
      && soAttendanceConfiguration.isDailyAttendanceTrackingRequired()) {
      addOrDeleteDailyAttendanceCorrection(prliCorrection);
    } else {
      deleteOnUpdateAbsenceDetailsCorrection(prliCorrection);
    }

  }

  /**
   * This method is used to add or delete daily attendance corrections based on
   * the changes in the service from and to date.
   *
   * @param prliCorrection
   * Provider roster line item correction
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void addOrDeleteDailyAttendanceCorrection(
    PRLICorrection prliCorrection) throws InformationalException {

    Set<DailyAttendanceCorrection> dailyAttendanceCorrections = dailyAttendanceCorrectionDAO.searchByPRLICorrection(
      prliCorrection.getID());

    List<Date> attendanceDates = new ArrayList<Date>();

    // Delete the records that are not within the service date range and
    // add the dates for which attendance record is there.
    for (DailyAttendanceCorrection dailyAttendanceCorrection : dailyAttendanceCorrections) {

      if (!prliCorrection.getServiceDateRange().contains(
        dailyAttendanceCorrection.getServiceDate())) {

        dailyAttendanceCorrection.remove(
          dailyAttendanceCorrection.getVersionNo());
      } else {
        attendanceDates.add(dailyAttendanceCorrection.getServiceDate());
      }
    }

    Date serviceDate = prliCorrection.getServiceDateRange().start();

    // Loop through entire date range of service and create default records for
    // the date attendance is not there.
    while (!serviceDate.after(prliCorrection.getServiceDateRange().end())) {

      if (!attendanceDates.contains(serviceDate)) {

        DailyAttendanceCorrection dailyAttendanceCorrection = dailyAttendanceCorrectionDAO.newInstance();

        dailyAttendanceCorrection.setAttendance(ATTENDANCEEntry.PRESENT);
        dailyAttendanceCorrection.setServiceDate(serviceDate);
        dailyAttendanceCorrection.setPRLICorrection(prliCorrection);
        dailyAttendanceCorrection.setUnitsAttended(
          Short.valueOf(Long.toString(1)));

        dailyAttendanceCorrection.insert();
      }
      serviceDate = serviceDate.addDays(1);
    }

  }

  /**
   * This method is used to delete absence period corrections based on the
   * changes in the service from and to date.
   *
   * @param prliCorrection
   * Provider roster line item correction
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void deleteOnUpdateAbsenceDetailsCorrection(
    PRLICorrection prliCorrection) throws InformationalException {

    Set<AbsencePeriodCorrection> absencePeriodCorrections = absencePeriodCorrectionDAO.searchByPRLICorrection(
      prliCorrection.getID());

    // Delete the records that are not within the service date range
    for (AbsencePeriodCorrection absencePeriodCorrection : absencePeriodCorrections) {

      if (!prliCorrection.getServiceDateRange().contains(
        absencePeriodCorrection.getAbsenceDate())) {

        absencePeriodCorrection.remove(absencePeriodCorrection.getVersionNo());
      }
    }

  }

  /**
   * This method is used to set the values from the entity record of Provider
   * roster line item to the struct that is to be displayed on the screen for
   * correction.
   *
   * @param rosterLineItem
   * Contains the details of roster line item
   * @param providerRosterLineItem
   * Contains the details of the Provider roster line item
   * @return Contains the details for correction
   */
  // BEGIN, CR00177241, PM
  protected PRLICorrectionDtls getPRLICorrectionDetails(
    final ProviderRosterLineItem providerRosterLineItem) {
    // END, CR00177241

    final PRLICorrectionDtls prliCorrectionDtls = new PRLICorrectionDtls();

    prliCorrectionDtls.clientFirstName = providerRosterLineItem.getClientFirstName();
    prliCorrectionDtls.clientLastName = providerRosterLineItem.getClientLastName();
    prliCorrectionDtls.clientDOB = providerRosterLineItem.getClientDOB();
    prliCorrectionDtls.clientReferenceNo = providerRosterLineItem.getClientReferenceNo();

    prliCorrectionDtls.providerRosterLineItemID = providerRosterLineItem.getID();
    prliCorrectionDtls.saReferenceNo = providerRosterLineItem.getSAReferenceNo();
    // BEGIN, CR00128590, RD
    prliCorrectionDtls.caseReferenceNo = providerRosterLineItem.getCaseReferenceNo();
    // END, CR00128590
    prliCorrectionDtls.versionNo = providerRosterLineItem.getVersionNo();
    prliCorrectionDtls.voucherNo = providerRosterLineItem.getVoucherNumber();

    prliCorrectionDtls.serviceFromDate = providerRosterLineItem.getServiceDateFrom();
    prliCorrectionDtls.serviceToDate = providerRosterLineItem.getServiceDateTo();
    prliCorrectionDtls.totalUnitsDelivered = providerRosterLineItem.getUnitsDelivered();

    return prliCorrectionDtls;
  }

  /**
   * This method is used to set the values from the screen that is entered or
   * modified to the entity record of Provider roster line item correction.
   *
   * @param prliCorrection
   * Contains the details of provider roster line item correction
   * entity.
   * @param prliCorrectionDetails
   * Contains the details of provider roster line item correction that
   * is entered or modified in the screen.
   */
  // BEGIN, CR00176474, AS
  // BEGIN, CR00177241, PM
  protected void setPRLICorrection(final PRLICorrection prliCorrection,
    PRLICorrectionDetails prliCorrectionDetails, boolean changesAllowed)
    throws InformationalException, AppException {
    // END, CR00177241
    // END, CR00176474

    if (changesAllowed) {
      prliCorrection.setClientDOB(
        prliCorrectionDetails.correctionDetails.clientDOB);
      prliCorrection.setClientFirstName(
        prliCorrectionDetails.correctionDetails.clientFirstName);
      prliCorrection.setClientLastName(
        prliCorrectionDetails.correctionDetails.clientLastName);
      prliCorrection.setClientReferenceNo(
        prliCorrectionDetails.correctionDetails.clientReferenceNo);
      prliCorrection.setSAReferenceNo(
        prliCorrectionDetails.correctionDetails.saReferenceNo);
      // BEGIN, CR00128590, RD
      prliCorrection.setCaseReferenceNo(
        prliCorrectionDetails.correctionDetails.caseReferenceNo);
      // END, CR00128590
      prliCorrection.setServiceDateRange(
        new DateRange(prliCorrectionDetails.correctionDetails.serviceFromDate,
        prliCorrectionDetails.correctionDetails.serviceToDate));
      prliCorrection.setVoucherNo(
        prliCorrectionDetails.correctionDetails.voucherNo);
    }

    prliCorrection.setProviderRosterLineItem(
      providerRosterLineItemDAO.get(
        prliCorrectionDetails.correctionDetails.providerRosterLineItemID));
    prliCorrection.setReason(prliCorrectionDetails.correctionDetails.reason);
    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        prliCorrection.getProviderRosterLineItem().getRoster())) {
      // END, CR00178377
      prliCorrection.setTotalUnitsDeliverd(
        prliCorrectionDetails.correctionDetails.totalUnitsDelivered);
    }
    // END, CR00176474

  }

  /**
   * This method approves a Provider Roster Line Item Correction.
   *
   * @param correctionKey
   * Contains the PRLICorrection ID to be submitted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void approvePRLICorrection(PRLICorrectionKey correctionKey)
    throws AppException, InformationalException {

    Money paidAmt = Money.kZeroMoney;
    Money newPaymentAmt = Money.kZeroMoney;

    // variables used during creating notification
    FinancialNotification notification = FinancialNotificationFactory.newInstance();
    FinancialNotificationKey notificationKey = new FinancialNotificationKey();

    final Event event = new Event();
    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      correctionKey.prliCorrectionID);

    prliCorrection.approve(prliCorrection.getVersionNo());

    ProviderRosterLineItem providerRosterLineItem = prliCorrection.getProviderRosterLineItem();

    // set the status of the PRLI from 'Completed' to 'Open'
    // PRLI Correction can be approved only when PRLI is in 'Completed' state
    updatePRLIStatus(providerRosterLineItem);

    // create PRLI Correction History
    createPRLICorrectionHistory(prliCorrection);
    // set new PRLI fields
    setPRLIFields(providerRosterLineItem, prliCorrection);
    updateDailyAttendance(correctionKey, providerRosterLineItem);
    updateAbsence(correctionKey, providerRosterLineItem);

    // automatic approval of PRLI -- call 1) submit for approval 2) approval
    providerRosterLineItem.submitAndApprovePRLIForCorrection();

    // raise an event to end the task
    event.eventKey = curam.events.ROSTER.PRLI_PROCESSED;
    event.primaryEventData = correctionKey.prliCorrectionID;

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // get the already paid amount to the payee
    InstructionLineItemDtls itemDtls = paymentProcessing.getILIforProviderRosterLineItem(
      providerRosterLineItem);

    paidAmt = itemDtls.amount;

    // get the new payment amount to the payee
    newPaymentAmt = attendancePaymentProcessing.getPaymentAmountForProviderRosterLineItem(
      providerRosterLineItem);

    // send notification for the payee regarding change in amount only if the
    // amount is already paid out
    // if paidAmt > newPaymentAmt, then send notification for amount old
    // payee owes (liability)
    // if paidAmt < newPaymentAmt, then send notification for new
    // payment
    // if paidAmt == newPaymentAmt, do nothing

    if (paidAmt.getValue() > newPaymentAmt.getValue()
      && itemDtls.instructLineItemID != 0) {

      notificationKey.providerRosterLineItemID = providerRosterLineItem.getID();
      notificationKey.event = FinancialNotificationEvent.PRLIC_OVERPAYMENT;
      notificationKey.amount = new Money(
        Math.abs(paidAmt.getValue() - newPaymentAmt.getValue()));

      notification.createNotification(notificationKey);

    } else if (paidAmt.getValue() < newPaymentAmt.getValue()
      && itemDtls.instructLineItemID != 0) {

      notificationKey.serviceInvoiceLineItemID = providerRosterLineItem.getID();
      notificationKey.event = FinancialNotificationEvent.PRLIC_UNDERPAYMENT;
      notificationKey.amount = new Money(
        Math.abs(paidAmt.getValue() - newPaymentAmt.getValue()));

      notification.createNotification(notificationKey);

    }
  }

  /**
   * Updates Absence period with the corresponding changes from Absence Period
   * correction.
   *
   * The Absence period records status are set to cancel. Absence period
   * correction records are inserted as new record in Absence period for the
   * roster
   *
   * @param prliCorrectionKey
   * Contains the PRLICorrection ID
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void updateAbsence(PRLICorrectionKey prliCorrectionKey,
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {
    // END, CR00177241
    // Set the absence period record for the roster line item to cancel
    for (AbsencePeriod absencePeriodForPRLI : absencePeriodDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID())) {
      if (RECORDSTATUSEntry.NORMAL.equals(absencePeriodForPRLI.getStatus())) {
        absencePeriodForPRLI.setStatus(RECORDSTATUSEntry.CANCELLED);
        absencePeriodForPRLI.modify();
      }
    }

    // insert correction records as new records in absence period
    for (AbsencePeriodCorrection absencePeriodCorrection : absencePeriodCorrectionDAO.searchByPRLICorrection(
      prliCorrectionKey.prliCorrectionID)) {
      AbsencePeriod absencePeriodForPRLI = absencePeriod.newInstance();

      absencePeriodForPRLI.setAbsenceDate(
        absencePeriodCorrection.getAbsenceDate());
      absencePeriodForPRLI.setAbsenceReason(
        ATTENDANCEABSENCEREASONEntry.get(
          absencePeriodCorrection.getAbsenceReason()));
      absencePeriodForPRLI.setRosterLineItem(
        providerRosterLineItem.getRosterLineItemID());
      absencePeriodForPRLI.setUnitsUnattended(
        absencePeriodCorrection.getUnitsUnattended().shortValue());
      absencePeriodForPRLI.setStatus(RECORDSTATUSEntry.NORMAL);
      absencePeriodForPRLI.insert();

    }
  }

  /**
   * Updates Daily attendance with the corresponding changes from Daily
   * attendance correction.
   *
   * The daily attendance records status are set to cancel. Daily attendance
   * correction records are inserted as new record in daily attendance for the
   * roster
   *
   * @param prliCorrectionKey
   * Contains the PRLICorrection ID
   * @param providerRosterLineItem
   * Contains the PRLI
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void updateDailyAttendance(PRLICorrectionKey prliCorrectionKey,
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {
    // END, CR00177241
    // Set the daily attendance records for the roster line item to cancel
    for (DailyAttendance dailyAttendanceForPRLI : dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID())) {
      if (RECORDSTATUSEntry.NORMAL.equals(dailyAttendanceForPRLI.getStatus())) {
        dailyAttendanceForPRLI.setStatus(RECORDSTATUSEntry.CANCELLED);
        dailyAttendanceForPRLI.modify();
      }
    }

    // insert correction records as new records in daily attendance
    for (DailyAttendanceCorrection dailyAttendanceCorrection : dailyAttendanceCorrectionDAO.searchByPRLICorrection(
      prliCorrectionKey.prliCorrectionID)) {

      DailyAttendance dailyAttendanceForPRLI = dailyAttendance.newInstance();

      ServiceAuthorization serviceAuthorization = providerRosterLineItem.getServiceAuthorization();

      if (serviceAuthorization != null) {
        final ServiceDelivery serviceDelivery = serviceDeliveryDAO.readByServiceAuthorization(
          serviceAuthorization);

        dailyAttendanceForPRLI.setRelatedItem(serviceDelivery);
      }
      dailyAttendanceForPRLI.setRosterLineItem(
        providerRosterLineItem.getRosterLineItemID());
      dailyAttendanceForPRLI.setStatus(RECORDSTATUSEntry.NORMAL);
      dailyAttendanceForPRLI.setServiceDate(
        dailyAttendanceCorrection.getServiceDate());
      dailyAttendanceForPRLI.setUnitsAttended(
        dailyAttendanceCorrection.getUnitsAttended());
      dailyAttendanceForPRLI.setUnitsUnattended(
        dailyAttendanceCorrection.getUnitsUnattended());
      dailyAttendanceForPRLI.setCreationDate(Date.getCurrentDate());
      dailyAttendanceForPRLI.setAttendance(
        dailyAttendanceCorrection.getAttendance());
      dailyAttendanceForPRLI.setAbsenceReason(
        dailyAttendanceCorrection.getAbsenceReason());
      // BEGIN, CR00249027, ASN
      dailyAttendanceForPRLI.setNumOfHoursAttended(
        dailyAttendanceCorrection.getNumOfHoursAttended());
      dailyAttendanceForPRLI.setNumOfMinutesAttended(
        dailyAttendanceCorrection.getNumOfMinutesAttended());
      dailyAttendanceForPRLI.setNumOfHoursAbsent(
        dailyAttendanceCorrection.getNumOfHoursAbsent());
      dailyAttendanceForPRLI.setNumOfMinutesAbsent(
        dailyAttendanceCorrection.getNumOfMinutesAbsent());
      // END, CR00249027

      
      // BEGIN, CR00233623, ASN
      if (null != dailyAttendanceCorrection.getDailyAttendance()) {
        dailyAttendanceForPRLI.setExpectedUnits(
          dailyAttendanceCorrection.getDailyAttendance().getExpectedUnits());
      }
      // END, CR00233623
      dailyAttendanceForPRLI.setStatus(RECORDSTATUSEntry.NORMAL);
      dailyAttendanceForPRLI.insert();
    }
  }

  /**
   * Updates the Provider Roster Line Item status to 'Open' state and adds an
   * entry in provider roster line item history.
   *
   * @param providerRosterLineItem
   * Provider Roster line item object.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void updatePRLIStatus(
    final ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {
    // END, CR00177241

    if (PRLIStatusEntry.COMPLETE.getCode().equals(
      providerRosterLineItem.getLifecycleState().getCode())) {
      providerRosterLineItem.setStatus(PRLIStatusEntry.get(PRLIStatus.OPEN));
      providerRosterLineItem.modifyRosterLineItem();
    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PRLICORRECTIONExceptionCreator.ERR_ROSTER_LINE_ITEM_CORRECTION_XRV_THIS_ROSTER_LINE_ITEM_IS_NOT_COMPLETE_CANNOT_BE_CORRECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * Sets the values from PRLICorrection to PRLI.
   *
   * @param providerRosterLineItem
   * Service invoice line item object.
   * @param prliCorrection
   * Service invoice line item correction object.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setPRLIFields(
    final ProviderRosterLineItem providerRosterLineItem,
    final PRLICorrection prliCorrection) throws AppException,
      InformationalException {
    // END, CR00177241

    final Address addressObj = AddressFactory.newInstance();
    final AddressKey addressKey = new AddressKey();

    if (CPMConstants.kZeroLong != prliCorrection.getClientAddressID()) {
      addressKey.addressID = prliCorrection.getClientAddressID();
      AddressDtls addressDtls = addressObj.read(addressKey);

      providerRosterLineItem.setAddress(addressDtls);
    }

    providerRosterLineItem.setClientDOB(prliCorrection.getClientDOB());
    providerRosterLineItem.setClientFirstName(
      prliCorrection.getClientFirstName());
    providerRosterLineItem.setClientLastName(prliCorrection.getClientLastName());
    providerRosterLineItem.setSAReferenceNo(prliCorrection.getSAReferenceNo());
    // BEGIN, CR00128590, RD
    providerRosterLineItem.setCaseReferenceNo(
      prliCorrection.getCaseReferenceNo());
    // END, CR00128590
    providerRosterLineItem.setUnitsDelivered(
      (short) prliCorrection.getTotalUnitsDeliverd());
    providerRosterLineItem.setClientReferenceNo(
      prliCorrection.getClientReferenceNo());

  }

  /**
   * Deny a Provider Roster Line Item Correction.
   *
   * @param correctionKey
   * Contains the PRLICorrection ID to be submitted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void denyPRLICorrection(PRLICorrectionKey correctionKey)
    throws AppException, InformationalException {

    final Event event = new Event();
    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      correctionKey.prliCorrectionID);

    prliCorrection.deny(prliCorrection.getVersionNo());
    createPRLICorrectionHistory(prliCorrection);

    // raise an event
    event.eventKey = curam.events.ROSTER.PRLI_DENIED;
    event.primaryEventData = correctionKey.prliCorrectionID;
    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
  }

  /**
   * Submit a Provider Roster Line item correction for processing.
   *
   * @param correctionKey
   * Contains the PRLICorrection ID to be submitted.
   * @param versionNo
   * Contains version no
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void submitPRLICorrection(PRLICorrectionKey correctionKey,
    VersionNo versionNo) throws AppException, InformationalException {
    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      correctionKey.prliCorrectionID);

    prliCorrection.submit(versionNo.versionNo);
    createPRLICorrectionHistory(prliCorrection);
  }

  /**
   * Creates PRLI Correction History Entry when the provider roster line item
   * status changes.
   *
   * @param correction
   * PRLI Correction object.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void createPRLICorrectionHistory(PRLICorrection correction)
    throws AppException, InformationalException {
    // END, CR00177241

    final PRLICorrectionHistory prliCorrectionHistory = prliCorrectionHistoryDAO.newInstance();

    prliCorrectionHistory.setPRLICorrection(correction);
    prliCorrectionHistory.insert();
  }

  /**
   * Method used to create absence correction details for a provider roster line
   * item correction.
   *
   * @param absenceCorrectionDetails
   * Contains the details of absence correction
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void createAbsenceCorrectionDetails(
    AbsenceCorrectionDetails absenceCorrectionDetails) throws AppException,
      InformationalException {

    AbsencePeriodCorrection absencePeriodCorrection = absencePeriodCorrectionDAO.newInstance();

    absencePeriodCorrection.setAbsenceDate(
      absenceCorrectionDetails.details.absenceDate);
    absencePeriodCorrection.setAbsenceReason(
      absenceCorrectionDetails.details.absenceReason);
    absencePeriodCorrection.setPRLICorrection(
      prliCorrectionDAO.get(absenceCorrectionDetails.details.prliCorrectionID));
    absencePeriodCorrection.setUnitsUnattended(
      absenceCorrectionDetails.details.unitsUnattended);

    absencePeriodCorrection.insert();

  }

  /**
   * Method used to list the absence correction details records for a provider
   * roster line item correction.
   *
   * @param prliCorrectionKey
   * Contains the internal identifier for the provider roster line item
   * correction.
   *
   * @return Struct contains the list of absence correction details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public CorrectionDetails listAbsenceCorrectionDetails(
    PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    final CorrectionDetails correctionDetails = new CorrectionDetails();

    final Set<AbsencePeriodCorrection> absenceDetailsCorrections = absencePeriodCorrectionDAO.searchByPRLICorrection(
      prliCorrectionKey.prliCorrectionID);

    // Loop through absenceDetailsCorrections and set the values to
    // AbsenceDetailsCorrectionDtls for display
    for (AbsencePeriodCorrection absencePeriodCorrection : sortAbsencePeriodCorrectionByServiceDate(
      absenceDetailsCorrections)) {
      final AbsencePeriodCorrectionDtls absencePeriodCorrectionDtls = new AbsencePeriodCorrectionDtls();

      absencePeriodCorrectionDtls.absencePeriodCorrectionID = absencePeriodCorrection.getID();
      absencePeriodCorrectionDtls.absenceDate = absencePeriodCorrection.getAbsenceDate();
      absencePeriodCorrectionDtls.absenceReason = absencePeriodCorrection.getAbsenceReason();
      absencePeriodCorrectionDtls.unitsUnattended = absencePeriodCorrection.getUnitsUnattended();
      absencePeriodCorrectionDtls.prliCorrectionID = prliCorrectionKey.prliCorrectionID;
      absencePeriodCorrectionDtls.versionNo = absencePeriodCorrection.getVersionNo();

      correctionDetails.absenceDetailsList.addRef(absencePeriodCorrectionDtls);
    }

    return correctionDetails;

  }

  /**
   * Method used to create the absence correction details for a provider roster
   * line item correction. This method retrieves all the absence record for the
   * provider roster line item and create absence correction record for each of
   * the active absence record that falls in the service date range.
   *
   * @param prliCorrection
   * Provider roster line item correction entity
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void createAbsenceDetailsCorrection(PRLICorrection prliCorrection)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      prliCorrection.getProviderRosterLineItem().getID());

    // Loop through absence period records for the provider roster line item
    // and create absence period correction for the active record which
    // falls in the date range of the service date
    for (curam.attendance.impl.AbsencePeriod absencePeriod : absencePeriodDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID())) {

      if (RECORDSTATUSEntry.NORMAL.equals(absencePeriod.getStatus())) {
        if (prliCorrection.getServiceDateRange().contains(
          absencePeriod.getAbsenceDate())) {

          final AbsencePeriodCorrection absencePeriodCorrection = absencePeriodCorrectionDAO.newInstance();

          absencePeriodCorrection.setAbsencePeriod(absencePeriod);
          absencePeriodCorrection.setAbsenceDate(absencePeriod.getAbsenceDate());
          absencePeriodCorrection.setAbsenceReason(
            absencePeriod.getAbsenceReason().getCode());
          absencePeriodCorrection.setUnitsUnattended(
            absencePeriod.getUnitsUnattended());
          absencePeriodCorrection.setPRLICorrection(prliCorrection);

          absencePeriodCorrection.insert();
        }
      }
    }
  }

  /**
   * This method is used to create Daily Attendance Correction from daily
   * attendance records for a provider roster line item. This method retrieves
   * all the daily attendance record for the provider roster line item and
   * create daily attendance correction record for each of the active daily
   * attendance record that falls in the service date range.
   *
   * @param prliCorrection
   * Provider roster line item correction entity
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void createDailyAttendanceCorrection(PRLICorrection prliCorrection)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      prliCorrection.getProviderRosterLineItem().getID());

    // Loop through daily attendance records for the provider roster line item
    // and create daily attendance correction for the active record which
    // falls in the date range of the service date
    for (curam.attendance.impl.DailyAttendance dailyAttendance : dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID())) {

      if (RECORDSTATUSEntry.NORMAL.equals(dailyAttendance.getStatus())) {

        if (prliCorrection.getServiceDateRange().contains(
          dailyAttendance.getServiceDate())) {

          DailyAttendanceCorrection dailyAttendanceCorrection = dailyAttendanceCorrectionDAO.newInstance();

          dailyAttendanceCorrection.setDailyAttendance(dailyAttendance);
          dailyAttendanceCorrection.setAttendance(
            dailyAttendance.getAttendance());
          dailyAttendanceCorrection.setAbsenceReason(
            dailyAttendance.getAbsenceReason());
          dailyAttendanceCorrection.setServiceDate(
            dailyAttendance.getServiceDate());
          dailyAttendanceCorrection.setPRLICorrection(prliCorrection);
          dailyAttendanceCorrection.setUnitsAttended(
            dailyAttendance.getUnitsAttended());
          dailyAttendanceCorrection.setUnitsUnattended(
            dailyAttendance.getUnitsUnattended());
          // BEGIN, CR00233623, ASN
          dailyAttendanceCorrection.setNumOfHoursAttended(
            dailyAttendance.getNumOfHoursAttended());
          dailyAttendanceCorrection.setNumOfMinutesAttended(
            dailyAttendance.getNumOfMinutesAttended());
          dailyAttendanceCorrection.setNumOfHoursAbsent(
            dailyAttendance.getNumOfHoursAbsent());
          dailyAttendanceCorrection.setNumOfMinutesAbsent(
            dailyAttendance.getNumOfMinutesAbsent());
          // END, CR00233623
          dailyAttendanceCorrection.insert();
        }
      }
    }
  }

  /**
   * Reads Daily Attendance Correction records for the provider roster line item
   * correction. The return list is converted to xml string and assigned to the
   * return struct. The input to the Widget is in xml format.
   *
   * @param prliCorrectionKey
   * Contains the internal identifier for the provider roster line item
   * correction.
   *
   * @return Struct containing the list of daily attendance correction as xml
   * string format.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLICorrectionDetails readDailyAttendanceCorrection(
    PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    PRLICorrectionDetails prliCorrectionDetails = new PRLICorrectionDetails();

    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();
    // BEGIN, CR00303745, SSK
    final PRLICorrection pRLICorrection = prliCorrectionDAO.get(
      prliCorrectionKey.prliCorrectionID);

    prliCorrectionDetails.correctionDetails.serviceFromDate = pRLICorrection.getServiceDateRange().start();
    prliCorrectionDetails.correctionDetails.serviceToDate = pRLICorrection.getServiceDateRange().end();
      
    if (null != pRLICorrection.getProviderRosterLineItem().getClient()) {
      prliCorrectionDetails.correctionDetails.clientFirstName = pRLICorrection.getProviderRosterLineItem().getClient().getName();
    }
    
    // END, CR00303745
    
    // BEGIN, CR00199226, ASN
    dailyAttendanceDetailsList = generateDailyAttendance(prliCorrectionKey);
    // END, CR00199226

    // Convert the list of daily attendance details to an xml. This xml is
    // the input to the widget to display the list of daily attendance details.
    prliCorrectionDetails.dailyAttendaceDetails = WidgetHelper.convertDailyAttendanceToXml(
      dailyAttendanceDetailsList);

    return prliCorrectionDetails;

  }

  // BEGIN, CR00233623, ASN
  /**
   * Maintains the daily attendance correction. The xml string is converted back
   * to list containing daily attendance correction record. Each of this
   * correction record is then updated, removed or inserted. Also the total
   * units delivered is calculated and the provider roster line item correction
   * record is modified with the new value of total units delivered.
   *
   * @param prliCorrectionDetails
   * Contains the list of daily attendance correction as xml string
   * format.
   *
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_UNATTENDED_MUST_BE_GREATER_THAN_0_IF_NOT_PRESENT}
   * -If attendance is absent or partially present and units not
   * attended is less than zero.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_ATTENDED_MUST_BE_0_UNLESS_PRESENT_OR_PARTIALLYPRESENT}
   * -If attendance is not present or partially present and units
   * attended is greater than zero.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XFV_DAILY_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED}
   * - If attendance is not entered but other details are entered.
   * records.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_ABSENCE_REASON_MUST_BE_ENTERED}
   * -If absence reason not entered and attendance is absent or
   * partially present.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED}
   * - If user tries to save all blank daily attendance correction
   * records.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_UNATTENDED_MUST_BE_GREATER_THAN_0_IF_NOT_PRESENT}
   * -If attendance is present and units not attended is not entered.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_ATTENDED_MUST_BE_GREATER_THAN_0_IF_PRESENT_OR_PARTIALLYPRESENT}
   * -If units attended is not greater than zero and attendance is
   * present or partially present.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_UNATTENDED_MUST_BE_0_IF_PRESENT}
   * -If attendance is present and units not attended is entered.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_ATTENDED_CANNOT_BE_0_IF_PRESENT_OR_PARTIALLYPRESENT}
   * -If units attended is zero and attendance is present or partially
   * present.
   */
  // END, CR00233623
  public void updateDailyAttendanceCorrection(
    PRLICorrectionDetails prliCorrectionDetails) throws AppException,
      InformationalException {

    final DailyAttendanceDetailsList dailyAttendanceDetailsList = WidgetHelper.convertXmlToAttendanceDetailsList(
      prliCorrectionDetails.dailyAttendaceDetails);

    short actualUnits = 0;

    // BEGIN, CR00233623, ASN
    validateUtilizationRecords(dailyAttendanceDetailsList);
    // END, CR00233623

    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliCorrectionDetails.correctionDetails.prliCorrectionID);

    // BEGIN, CR00199226, ASN
    for (final DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {

      if (0 != dailyAttendanceDetails.dtls.dailyAttendanceID) {

        final DailyAttendanceCorrection dailyAttendanceCorrection = dailyAttendanceCorrectionDAO.get(
          dailyAttendanceDetails.dtls.dailyAttendanceID);

        if (StringHelper.isEmpty(
          dailyAttendanceCorrection.getAttendance().getCode())) {

          dailyAttendanceCorrection.remove(
            dailyAttendanceDetails.dtls.versionNo);

        } else {
          // BEGIN, CR00233623, ASN
          dailyAttendance = dailyAttendanceDAO.get(
            dailyAttendanceCorrection.getDailyAttendance().getID());
          // END, CR00233623
          dailyAttendanceCorrection.setAttendance(
            ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
          dailyAttendanceCorrection.setAbsenceReason(
            ATTENDANCEABSENCEREASONEntry.get(
              dailyAttendanceDetails.dtls.absenceReason));
          dailyAttendanceCorrection.setServiceDate(
            dailyAttendanceDetails.dtls.serviceDate);
          dailyAttendanceCorrection.setDailyAttendance(dailyAttendance);
          dailyAttendanceCorrection.setPRLICorrection(
            prliCorrectionDAO.get(
              prliCorrectionDetails.correctionDetails.prliCorrectionID));
          dailyAttendanceCorrection.setUnitsAttended(
            dailyAttendanceDetails.dtls.unitsAttended);
          dailyAttendanceCorrection.setUnitsUnattended(
            dailyAttendanceDetails.dtls.unitsUnattended);
          dailyAttendanceCorrection.modify(
            dailyAttendanceDetails.dtls.versionNo);
        }

      } else {

        if (0 == dailyAttendanceDetails.dtls.dailyAttendanceID
          && !StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.attendance)) {

          DailyAttendanceCorrection dailyAttendanceCorrection = dailyAttendanceCorrectionDAO.newInstance();

          dailyAttendanceCorrection.setAttendance(
            ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
          dailyAttendanceCorrection.setAbsenceReason(
            ATTENDANCEABSENCEREASONEntry.get(
              dailyAttendanceDetails.dtls.absenceReason));
          dailyAttendanceCorrection.setServiceDate(
            dailyAttendanceDetails.dtls.serviceDate);
          dailyAttendanceCorrection.setPRLICorrection(
            prliCorrectionDAO.get(
              prliCorrectionDetails.correctionDetails.prliCorrectionID));
          dailyAttendanceCorrection.setUnitsAttended(
            dailyAttendanceDetails.dtls.unitsAttended);
          dailyAttendanceCorrection.setUnitsUnattended(
            dailyAttendanceDetails.dtls.unitsUnattended);
          dailyAttendanceCorrection.insert();
        }
      }
    }
    final Set<DailyAttendanceCorrection> unitsAttendedList = dailyAttendanceCorrectionDAO.searchByPRLICorrection(
      prliCorrectionDetails.correctionDetails.prliCorrectionID);

    for (final DailyAttendanceCorrection actualUnitsValue : unitsAttendedList) {

      actualUnits += actualUnitsValue.getUnitsAttended();
    }
    // END, CR00199226

    prliCorrection.setTotalUnitsDeliverd(actualUnits);
    prliCorrection.modify(prliCorrection.getVersionNo());
  }

  /**
   * Sorts a set of daily attendance correction records by service date.
   *
   * @param unsortedDailyAttendanceCorrection
   * The list of unsorted daily attendance Correction.
   * @return A sorted list of daily attendance correction.
   */
  protected ArrayList<DailyAttendanceCorrection> sortDailyAttendanceCorrectionByServiceDate(
    final Set<DailyAttendanceCorrection> unsortedDailyAttendanceCorrection) {

    // Sort by position for display
    final ArrayList<DailyAttendanceCorrection> dailyAttendanceCorrectionList = new ArrayList<DailyAttendanceCorrection>(
      unsortedDailyAttendanceCorrection);

    Collections.sort(dailyAttendanceCorrectionList,
      new Comparator<DailyAttendanceCorrection>() {
      public int compare(final DailyAttendanceCorrection lhs,
        final DailyAttendanceCorrection rhs) {
        return lhs.getServiceDate().compareTo(rhs.getServiceDate());
      }
    });
    return dailyAttendanceCorrectionList;
  }

  /**
   * Sorts a set of absences period correction by absence date.
   *
   * @param unsortedAbsencePeriodCorrectionList
   * The list of unsorted absences Period correction records.
   * @return A sorted list of absences period correction records.
   */
  protected ArrayList<AbsencePeriodCorrection> sortAbsencePeriodCorrectionByServiceDate(
    final Set<AbsencePeriodCorrection> unsortedAbsencePeriodCorrectionList) {

    // Sort by position for display
    final ArrayList<AbsencePeriodCorrection> absencePeriodCorrectionList = new ArrayList<AbsencePeriodCorrection>(
      unsortedAbsencePeriodCorrectionList);

    Collections.sort(absencePeriodCorrectionList,
      new Comparator<AbsencePeriodCorrection>() {
      public int compare(final AbsencePeriodCorrection lhs,
        final AbsencePeriodCorrection rhs) {

        return lhs.getAbsenceDate().compareTo(rhs.getAbsenceDate());
      }
    });
    return absencePeriodCorrectionList;
  }

  /**
   * Deletes the absence correction.
   *
   * @param absencePeriodCorrectionKey
   * Contains the internal identifier for the absence correction
   * entity.
   * @param versionNo
   * Version number of the record that is to be deleted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deleteAbsenceCorrectionDetails(
    AbsencePeriodCorrectionKey absencePeriodCorrectionKey, VersionNo versionNo)
    throws AppException, InformationalException {

    AbsencePeriodCorrection absencePeriodCorrection = absencePeriodCorrectionDAO.get(
      absencePeriodCorrectionKey.absencePeriodCorrectionID);

    absencePeriodCorrection.remove(versionNo.versionNo);
  }

  // BEGIN, CR00199226, ASN
  /**
   * Returns the daily attendance correction records associated with a PRLI
   * correction of reporting method 'Attendance'.
   *
   * @param prliCorrectionKey
   * Contains the internal identifier for the provider roster line item
   * correction.
   *
   * @return List of daily attendance correction.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewDailyAttendanceReportingDetails readDailyAttendanceCorrectionForReporting(
    final PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    final ViewDailyAttendanceReportingDetails viewDailyAttendanceReportingDetails = new ViewDailyAttendanceReportingDetails();
    
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    final PRLICorrection pRLICorrection = prliCorrectionDAO.get(
      prliCorrectionKey.prliCorrectionID);

    viewDailyAttendanceReportingDetails.fromDate = pRLICorrection.getServiceDateRange().start();
    viewDailyAttendanceReportingDetails.toDate = pRLICorrection.getServiceDateRange().end();
    
    // BEGIN, CR00303745, SSK
    viewDailyAttendanceReportingDetails.clientName = pRLICorrection.getProviderRosterLineItem().getClientName();
    // END, CR00303745

    SOAttendanceConfiguration soAttendanceConfig = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      pRLICorrection.getProviderRosterLineItem().getRoster().getServiceOffering(),
      pRLICorrection.getProviderRosterLineItem().getRoster().getDateGenerated());

    if (null != soAttendanceConfig
      && soAttendanceConfig.isDailyAttendanceTrackingRequired()) {
      // Generate daily attendance dynamically using data using either the daily
      // attendance correction date input at facade level or from daily
      // attendance correction entity
      // if records exist.
      dailyAttendanceDetailsList = generateDailyAttendance(prliCorrectionKey);
    }
    viewDailyAttendanceReportingDetails.viewDetailsList.assign(
      dailyAttendanceDetailsList);

    RosterKey rosterKey = new RosterKey();

    rosterKey.rosterID = pRLICorrection.getProviderRosterLineItem().getRoster().getID();

    // Convert the list of daily attendance details to an xml. This xml is the
    // input to the widget to display the list of daily attendance correction
    // details.
    if (attendanceConfigurationHelper.isHoursEnabledForAttendanceReporting(
      rosterKey)) {
      
      viewDailyAttendanceReportingDetails.hoursEnabled = true;
      viewDailyAttendanceReportingDetails.dailyAttendanceHoursDetails = AttendanceWidgetHelper.convertDailyAttendanceToXml(
        dailyAttendanceDetailsList,
        viewDailyAttendanceReportingDetails.hoursEnabled);
    } else {
      
      viewDailyAttendanceReportingDetails.hoursEnabled = false;
      viewDailyAttendanceReportingDetails.dailyAttendanceDetails = AttendanceWidgetHelper.convertDailyAttendanceToXml(
        dailyAttendanceDetailsList,
        viewDailyAttendanceReportingDetails.hoursEnabled);
    }

    return viewDailyAttendanceReportingDetails;

  }

  /**
   * Returns the daily attendance correction records associated with
   * a PRLI correction to support reporting method of 'Utilization', Attendance
   * with or without hours enabled.
   *
   * @param prliCorrectionKey
   * Contains the internal identifier for the provider roster line item
   * correction.
   *
   * @return List of daily attendance corrections.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewReportingDailyAttendanceDetails listDailyAttendanceCorrectionDetails(
    final PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    final ViewReportingDailyAttendanceDetails viewReportingDailyAttendanceDetails = new ViewReportingDailyAttendanceDetails();

    final Locale locale = new Locale(TransactionInfo.getProgramLocale());
    final DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG,
      locale);

    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliCorrectionKey.prliCorrectionID);
    RosterKey rosterKey = new RosterKey();

    rosterKey.rosterID = prliCorrection.getProviderRosterLineItem().getRoster().getID();

    viewReportingDailyAttendanceDetails.isHoursEnabled = attendanceConfigurationHelper.isHoursEnabledForAttendanceReporting(
      rosterKey);

    ReportingDailyAttendanceDetails reportingDailyAttendanceDetails; 

    for (final DailyAttendanceCorrection dailyAttendanceCorrection : sortDailyAttendanceCorrectionByServiceDate(
      dailyAttendanceCorrectionDAO.searchByPRLICorrection(
        prliCorrectionKey.prliCorrectionID))) {

      // BEGIN, CR00304523, SSK
      reportingDailyAttendanceDetails = new ReportingDailyAttendanceDetails();
      reportingDailyAttendanceDetails.dtls.serviceDate = dailyAttendanceCorrection.getServiceDate();
      // END, CR00304523
      
      final java.util.Date serviceDate = new java.util.Date(
        dailyAttendanceCorrection.getServiceDate().asLong());
      
      final String formattedServiceDate = dateFormat.format(serviceDate);
     
      reportingDailyAttendanceDetails.serviceDateString = formattedServiceDate;

      reportingDailyAttendanceDetails.dtls.absenceReason = dailyAttendanceCorrection.getAbsenceReason().getCode();
      reportingDailyAttendanceDetails.dtls.attendance = dailyAttendanceCorrection.getAttendance().getCode();
      if (null != dailyAttendanceCorrection.getDailyAttendance()) {
        
        if (0
          == dailyAttendanceCorrection.getDailyAttendance().getExpectedUnits()) {
          reportingDailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
        } else {
          reportingDailyAttendanceDetails.expectedUnitsString = String.valueOf(
            dailyAttendanceCorrection.getDailyAttendance().getExpectedUnits());
        }
      } else {
        reportingDailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
      }

      if (0 == dailyAttendanceCorrection.getUnitsAttended()) {
        reportingDailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
      } else {
        reportingDailyAttendanceDetails.unitsAttendedString = String.valueOf(
          dailyAttendanceCorrection.getUnitsAttended());
      }
      if (0 == dailyAttendanceCorrection.getUnitsUnattended()) {
        reportingDailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
      } else {
        reportingDailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
          dailyAttendanceCorrection.getUnitsUnattended());
      }
      if (viewReportingDailyAttendanceDetails.isHoursEnabled) {
        reportingDailyAttendanceDetails.hoursAttended = getFormattedTimeDuration(
          dailyAttendanceCorrection.getHoursAttended(),
          dailyAttendanceCorrection.getMinutesAttended());

        reportingDailyAttendanceDetails.hoursUnAttended = getFormattedTimeDuration(
          dailyAttendanceCorrection.getHoursAbsent(),
          dailyAttendanceCorrection.getMinutesAbsent());
      }
      viewReportingDailyAttendanceDetails.details.addRef(
        reportingDailyAttendanceDetails);
    }

    return viewReportingDailyAttendanceDetails;
  }

  /**
   * Maintains the daily attendance correction records associated with a PRLI
   * correction of reporting method 'Attendance'.
   *
   * @param prliAttendanceCorrectionDetails
   * Contains the list of daily attendance correction as xml string
   * format.
   *
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED}
   * - If user tries to save all blank daily attendance correction
   * records.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XFV_DAILY_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED}
   * - If attendance is not entered but other details are entered.
   * records.
   */
  public void maintainAttendanceTypeDailyAttendanceCorrection(
    final PRLIAttendanceCorrectionDetails prliAttendanceCorrectionDetails)
    throws AppException, InformationalException {

    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    if (!StringUtil.isNullOrEmpty(
      prliAttendanceCorrectionDetails.dailyAttendanceDetails)) {

      dailyAttendanceDetailsList = WidgetHelper.convertAttendanceXmlToAttendanceDetailsList(
        prliAttendanceCorrectionDetails.dailyAttendanceDetails, false);
      // BEGIN,  CR00233623, ASN
      validateAttendanceRecords(dailyAttendanceDetailsList, false);
      // END, CR00233623
      
    } else if (!StringUtil.isNullOrEmpty(
      prliAttendanceCorrectionDetails.dailyAttendanceHoursDetails)) {
      dailyAttendanceDetailsList = WidgetHelper.convertAttendanceXmlToAttendanceDetailsList(
        prliAttendanceCorrectionDetails.dailyAttendanceHoursDetails, true);
      // BEGIN, CR00233623, ASN
      validateAttendanceRecords(dailyAttendanceDetailsList, true);
      // END, CR00233623
    }
    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliAttendanceCorrectionDetails.attendanceCorrectionDetails.prliCorrectionID);
 
    for (final DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {
 
      if (0 != dailyAttendanceDetails.dtls.dailyAttendanceID) {
        
        DailyAttendanceCorrection dailyAttendanceCorrection = dailyAttendanceCorrectionDAO.get(
          dailyAttendanceDetails.dtls.dailyAttendanceID);

        // If the daily attendance is not set remove the daily attendance
        // record.
        if (StringHelper.isEmpty(dailyAttendanceDetails.dtls.attendance)) {

          dailyAttendanceCorrection.remove(
            dailyAttendanceDetails.dtls.versionNo);

        } else {
          dailyAttendanceCorrection.setAttendance(
            ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
          dailyAttendanceCorrection.setAbsenceReason(
            ATTENDANCEABSENCEREASONEntry.get(
              dailyAttendanceDetails.dtls.absenceReason));
          dailyAttendanceCorrection.setServiceDate(
            dailyAttendanceDetails.dtls.serviceDate);
          dailyAttendanceCorrection.setDailyAttendance(dailyAttendance);
          dailyAttendanceCorrection.setPRLICorrection(
            prliCorrectionDAO.get(
              prliAttendanceCorrectionDetails.attendanceCorrectionDetails.prliCorrectionID));
          // BEGIN, CR00233623, ASN
          dailyAttendanceCorrection.setNumOfHoursAttended(
            dailyAttendanceDetails.dtls.numHoursAttended);
          dailyAttendanceCorrection.setNumOfMinutesAttended(
            dailyAttendanceDetails.dtls.numMinutesAttended);
          dailyAttendanceCorrection.setNumOfHoursAbsent(
            dailyAttendanceDetails.dtls.numHoursAbsent);
          dailyAttendanceCorrection.setNumOfMinutesAbsent(
            dailyAttendanceDetails.dtls.numMinutesAbsent);
          // END, CR00233623
          dailyAttendanceCorrection.modify(
            dailyAttendanceDetails.dtls.versionNo);

        }

      } else {
        if (0 == dailyAttendanceDetails.dtls.dailyAttendanceID
          && !StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.attendance)) {

          DailyAttendanceCorrection dailyAttendanceCorrection = dailyAttendanceCorrectionDAO.newInstance();

          dailyAttendanceCorrection.setPRLICorrection(
            prliCorrectionDAO.get(prliCorrection.getID()));
          dailyAttendanceCorrection.setAttendance(
            ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
          dailyAttendanceCorrection.setAbsenceReason(
            ATTENDANCEABSENCEREASONEntry.get(
              dailyAttendanceDetails.dtls.absenceReason));
          dailyAttendanceCorrection.setServiceDate(
            dailyAttendanceDetails.dtls.serviceDate);
          // BEGIN, CR00233623, ASN
          dailyAttendanceCorrection.setNumOfHoursAttended(
            dailyAttendanceDetails.dtls.numHoursAttended);
          dailyAttendanceCorrection.setNumOfMinutesAttended(
            dailyAttendanceDetails.dtls.numMinutesAttended);
          dailyAttendanceCorrection.setNumOfHoursAbsent(
            dailyAttendanceDetails.dtls.numHoursAbsent);
          dailyAttendanceCorrection.setNumOfMinutesAbsent(
            dailyAttendanceDetails.dtls.numMinutesAbsent);
          // END, CR00233623
          dailyAttendanceCorrection.insert();
        }
      }
    }

    prliCorrection.modify(prliCorrection.getVersionNo());
  }
  
  /**
   * Generates daily attendance correction for a client who is added to a roster, for each
   * day of the roster line item period dynamically to support non storage of
   * daily attendance correction empty records.
   *
   * @param providerRosterLineItem
   * Contains provider roster line item details.
   *
   * @return List of Daily Attendance correction details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected DailyAttendanceDetailsList generateDailyAttendance(
    final PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();
    Map<Date, DailyAttendanceCorrection> checkDuplicateMap = new HashMap<Date, DailyAttendanceCorrection>();

    ArrayList<Date> serviceDateList = new ArrayList<Date>();

    final Set<DailyAttendanceCorrection> dailyAttendanceCorrections = dailyAttendanceCorrectionDAO.searchByPRLICorrection(
      prliCorrectionKey.prliCorrectionID);

    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliCorrectionKey.prliCorrectionID);

    Date startDate = prliCorrection.getServiceDateRange().start();
    final Date endDate = prliCorrection.getServiceDateRange().end();

    serviceDateList = serviceDatesForActiveDailyAttendance(prliCorrection);

    boolean isReporting = false;

    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        prliCorrection.getProviderRosterLineItem().getRoster())) {

      isReporting = true;
    }

    boolean isPlannedUnitsDefaulted = Boolean.parseBoolean(
      curam.util.resources.Configuration.getProperty(
        CPMConstants.kRosterLineItemPlannedUnits));

    // Create the daily Attendance for each day of the service period.
    while (startDate.before(endDate.addDays(1))) {

      if (!serviceDateList.contains(startDate)) {

        DailyAttendanceDetails dailyAttendanceDetails = new DailyAttendanceDetails();

        dailyAttendanceDetails = generateUnstoredDailyAttendanceDetails(
          prliCorrection, isReporting, isPlannedUnitsDefaulted, startDate);
        dailyAttendanceDetailsList.details.addRef(dailyAttendanceDetails);

      } else {

        for (final DailyAttendanceCorrection dailyAttendanceCorrection : sortDailyAttendanceCorrectionByServiceDate(
          dailyAttendanceCorrections)) {

          if (startDate.equals(dailyAttendanceCorrection.getServiceDate())) {

            if (!checkDuplicateMap.containsKey(
              dailyAttendanceCorrection.getServiceDate())) {

              checkDuplicateMap.put(dailyAttendanceCorrection.getServiceDate(),
                dailyAttendanceCorrection);
              DailyAttendanceDetails storedDailyAttendanceDetails = new DailyAttendanceDetails();

              storedDailyAttendanceDetails = storedDailyAttendanceDetails(
                dailyAttendanceCorrection);

              dailyAttendanceDetailsList.details.addRef(
                storedDailyAttendanceDetails);

            }
          }
        }
      }

      startDate = startDate.addDays(1);
    }

    return dailyAttendanceDetailsList;

  }

  /**
   * Retrieves the service dates for active daily attendance records.
   *
   * @param prliCorrection
   * Contains provider roster line item correction details.
   *
   * @return List of Daily Attendance service dates.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ArrayList<Date> serviceDatesForActiveDailyAttendance(
    final PRLICorrection prliCorrection) throws InformationalException,
      AppException {

    final ArrayList<Date> serviceDateList = new ArrayList<Date>();

    final Set<DailyAttendanceCorrection> dailyAttendanceCorrectionList = dailyAttendanceCorrectionDAO.searchByPRLICorrection(
      prliCorrection.getID());

    for (final DailyAttendanceCorrection dailyAttendanceCorrection : sortDailyAttendanceCorrectionByServiceDate(
      dailyAttendanceCorrectionList)) {

      ArrayList<Date> serviceDate = new ArrayList<Date>();

      serviceDate.add(dailyAttendanceCorrection.getServiceDate());

      serviceDateList.addAll(serviceDate);
    }
    return serviceDateList;
  }

  /**
   * Sorts a set of daily attendance records into a sorted list for display.
   *
   * @param unSortedDailyAttendanceDetailsList
   * List of unsorted daily attendance.
   *
   * @return List of daily attendance records sorted by service date.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  protected DailyAttendanceDetailsList sortDailyAttendance(
    final DailyAttendanceDetailsList unSortedDailyAttendanceDetailsList)
    throws AppException, InformationalException {

    final List<DailyAttendanceDetails> dailyAttendanceDetailsList = new ArrayList<DailyAttendanceDetails>();

    for (final DailyAttendanceDetails dailyAttendance : unSortedDailyAttendanceDetailsList.details.items()) {
      dailyAttendanceDetailsList.add(dailyAttendance);
    }

    Collections.sort(dailyAttendanceDetailsList,
      new Comparator<DailyAttendanceDetails>() {
      public int compare(final DailyAttendanceDetails lhs,
        final DailyAttendanceDetails rhs) {
        return lhs.dtls.serviceDate.compareTo(rhs.dtls.serviceDate);
      }
    });

    final DailyAttendanceDetailsList sortedDailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    sortedDailyAttendanceDetailsList.details.addAll(dailyAttendanceDetailsList);

    return sortedDailyAttendanceDetailsList;
  }

  /**
   * Formats the duration in "HM hours and MM minutes" format.
   *
   * @param hours
   * Hours of attendance or absence.
   * @param minutes
   * Minutes of attendance or absence.
   *
   * @return Formatted duration.
   */
  protected String getFormattedTimeDuration(
    final ATTENDANCETRACKINGHOURSEntry hours,
    final ATTENDANCETRACKINGMINUTESEntry minutes) {

    String formattedHrsMinutes = CPMConstants.kEmptyString;
    String formattedMinutes = CPMConstants.kEmptyString;
    String formattedHrs = CPMConstants.kEmptyString;
    boolean appendMinutesToHrs = false;

    if (!ATTENDANCETRACKINGMINUTESEntry.NOT_SPECIFIED.getCode().equals(
      minutes.getCode())
        && !ATTENDANCETRACKINGMINUTESEntry.ATM2001.getCode().equals(
          minutes.getCode())) {

      // If minutes is 30, append to half an hour.
      if (ATTENDANCETRACKINGMINUTESEntry.ATM2031.getCode().equals(
        minutes.getCode())) {

        appendMinutesToHrs = true;

      } else {

        if (CPMConstants.kMinturesLength == minutes.getCode().length()
          && CPMConstants.kZeroChar
            == minutes.getCode().charAt(CPMConstants.kFirstCharIndex)) {
          formattedMinutes = minutes.getCode().charAt(
            CPMConstants.kSecondCharIndex)
              + CPMConstants.kSpace
              + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_MINUTES_ATTENDED_UNATTENDED).getMessage();
        } else {
          formattedMinutes = minutes.getCode() + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_MINUTES_ATTENDED_UNATTENDED).getMessage();
        }
      }
    }

    if (!ATTENDANCETRACKINGHOURSEntry.NOT_SPECIFIED.getCode().equals(
      hours.getCode())
        && !ATTENDANCETRACKINGHOURSEntry.ATH2001.getCode().equals(
          hours.getCode())) {
      if (CPMConstants.kMinturesLength == hours.getCode().length()
        && hours.getCode().charAt(CPMConstants.kFirstCharIndex)
          == CPMConstants.kZeroChar) {
        formattedHrs = hours.getCode().charAt(CPMConstants.kSecondCharIndex)
          + CPMConstants.kEmptyString;
      } else {
        formattedHrs = hours.getCode();
      }
    }

    if (appendMinutesToHrs) {
      if (CPMConstants.kEmptyString.equals(formattedHrs)) {
        formattedHrs = CPMConstants.kZeroChar + CPMConstants.kEmptyString;
      }

      formattedHrsMinutes = formattedHrs + CPMConstants.khalfAnHour
        + CPMConstants.kSpace
        + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_ATTENDED_UNATTENDED).getMessage();

    } else {
      if (!CPMConstants.kEmptyString.equals(formattedHrs)) {
        if (!CPMConstants.kEmptyString.equals(formattedMinutes)) {
          formattedHrsMinutes = formattedHrs + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_AND_MINUTES_ATTENDED_UNATTENDED).getMessage()
            + formattedMinutes;
        } else {
          formattedHrsMinutes = formattedHrs + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_ATTENDED_UNATTENDED).getMessage();
        }
      } else if (!CPMConstants.kEmptyString.equals(formattedMinutes)) {

        formattedHrsMinutes = formattedMinutes;

      }
    }

    return formattedHrsMinutes;
  }

  // BEGIN, CR00233623, ASN
  /**
   * Validates daily attendance records for reporting method of attendance.
   *
   * @param dailyAttendanceDetailsList
   * List containing the daily attendance correction details.
   * @param attendanceHourConfig
   * To indicate hours enable indicator is set or not.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void validateAttendanceRecords(
    final DailyAttendanceDetailsList dailyAttendanceDetailsList,
    final boolean attendanceHourConfig) throws AppException,
      InformationalException {

    int recordCounter = 0;

    for (DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {

      if (attendanceHourConfig) {

        boolean checkHoursAttended = false;
        boolean checkHoursAbsent = false;

        if (dailyAttendanceDetails.dtls.absenceReason.trim().length() > 0
          || dailyAttendanceDetails.dtls.totalHours.trim().length() > 0
          || dailyAttendanceDetails.dtls.totalMinutes.trim().length() > 0) {
          checkHoursAttended = true;
        }

        if (dailyAttendanceDetails.dtls.hoursAbsent.trim().length() > 0
          || dailyAttendanceDetails.dtls.minutesAbsent.trim().length() > 0) {
          checkHoursAbsent = true;
        }
        if (0 == dailyAttendanceDetails.dtls.attendance.trim().length()
          && (checkHoursAttended || checkHoursAbsent)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XFV_DAILY_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
          ValidationHelper.failIfErrorsExist();
        }

      } else {
        if (0 == dailyAttendanceDetails.dtls.attendance.trim().length()
          && dailyAttendanceDetails.dtls.absenceReason.trim().length() > 0) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_FOR_HOURS_DISABLED_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

          ValidationHelper.failIfErrorsExist();
        }
      }

      if (StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.attendance)) {

        recordCounter = recordCounter + 1;
      }
    }

    if (recordCounter == dailyAttendanceDetailsList.details.size()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      ValidationHelper.failIfErrorsExist();
    }
  }

  // END, CR00233623
  /**
   * Generates daily attendance correction for a client who is added to a
   * roster, for each day of the roster line item period in case no daily
   * attendance correction records exists in the system for a service date.
   *
   * @param prliCorrection
   * Contains provider roster line item correction details.
   * @param isReporting
   * Checks the value of 'Reporting' indicator.
   * @param isPlannedUnitsDefaulted
   * Checks the value of 'Planned Units Defaulted' indicator.
   * @param startDate
   * Service date for which records need to be generated.
   *
   * @return List of Daily Attendance correction details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected DailyAttendanceDetails generateUnstoredDailyAttendanceDetails(
    final PRLICorrection prliCorrection, final boolean isReporting,
    final boolean isPlannedUnitsDefaulted, final Date startDate)
    throws AppException, InformationalException {

    final DailyAttendanceDetails dailyAttendanceDetails = new DailyAttendanceDetails();

    dailyAttendanceDetails.dtls.rosterLineItemID = prliCorrection.getProviderRosterLineItem().getRosterLineItemID();
    
    ArrayList<Date> serviceDateList = new ArrayList<Date>();

    serviceDateList = serviceDatesForActiveDailyAttendance(prliCorrection);

    // BEGIN, CR00303745, SSK
    // BEGIN, CR00313390, ASN
    dailyAttendanceDetails.serviceDateString = curam.util.resources.Locale.getFormattedDateTime(
      startDate.getDateTime(), // END, CR00313390
      curam.util.resources.Locale.Date_ymd);
    // END, CR00303745

    if (isReporting) {
      dailyAttendanceDetails.dtls.unitsAttended = (short) 0;
      dailyAttendanceDetails.dtls.unitsUnattended = (short) 0;

    }
    if (0 == dailyAttendanceDetails.dtls.unitsAttended) {
      dailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
    } else {
      dailyAttendanceDetails.unitsAttendedString = String.valueOf(
        dailyAttendanceDetails.dtls.unitsAttended);
    }
    if (0 == dailyAttendanceDetails.dtls.unitsUnattended) {
      dailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
    } else {
      dailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
        dailyAttendanceDetails.dtls.unitsUnattended);
    }
    dailyAttendanceDetails.dtls.creationDate = Date.getCurrentDate();

    // BEGIN, CR00233623, ASN
    Set<PRLISALILink> prliSALILinks = prliSALILinkDAO.searchByProviderRosterLineItem(
      prliCorrection.getProviderRosterLineItem());

    for (final PRLISALILink prliSALILink : prliSALILinks) {

      if (null != prliSALILink.getServiceAuthorizationLineItem()) {

        // BEGIN, CR00206362, ASN
        if (1
          == prliSALILink.getServiceAuthorizationLineItem().getDateRange().length()
            && prliSALILink.getServiceAuthorizationLineItem().getDateRange().contains(
              startDate)) {
          // END, CR00206362
          int expectedUnits = 0;

          if (isReporting) {
            expectedUnits = prliSALILink.getServiceAuthorizationLineItem().getUnitsAuthorized();
            dailyAttendanceDetails.dtls.expectedUnits = (short) expectedUnits;

            if (0 == dailyAttendanceDetails.dtls.expectedUnits) {
              dailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
            } else {
              dailyAttendanceDetails.expectedUnitsString = String.valueOf(
                expectedUnits);
            }
          }

          if (isPlannedUnitsDefaulted && 0 == serviceDateList.size()) {

            if (isReporting) {
              if (startDate.before(Date.getCurrentDate().addDays(1))) {
                dailyAttendanceDetails.dtls.unitsAttended = (short) expectedUnits;
                dailyAttendanceDetails.unitsAttendedString = String.valueOf(
                  expectedUnits);

                dailyAttendanceDetails.dtls.attendance = ATTENDANCEEntry.PRESENT.getCode();
              }
            }
          }
        }
      }
    }
    // END, CR00233623
    return dailyAttendanceDetails;
  }

  /**
   * Generates daily attendance correction for a client who is added to a
   * roster, for each day of the roster line item period in case daily
   * attendance correction records exists in the system.
   *
   * @param dailyAttendanceCorrection
   * Contains Daily attendance correction details.
   *
   * @return List of Daily Attendance correction details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected DailyAttendanceDetails storedDailyAttendanceDetails(
    final DailyAttendanceCorrection dailyAttendanceCorrection)
    throws AppException, InformationalException {
    
    final DailyAttendanceDetails storedDailyAttendanceDetails = new DailyAttendanceDetails();
    
    // BEGIN, CR00303745, SSK
    storedDailyAttendanceDetails.serviceDateString = curam.util.resources.Locale.getFormattedDateTime(
      dailyAttendanceCorrection.getServiceDate().getDateTime(),
      curam.util.resources.Locale.Date_ymd);
    // END, CR00303745

    storedDailyAttendanceDetails.dtls.attendance = dailyAttendanceCorrection.getAttendance().getCode();
    storedDailyAttendanceDetails.dtls.absenceReason = dailyAttendanceCorrection.getAbsenceReason().getCode();
    storedDailyAttendanceDetails.dtls.serviceDate = dailyAttendanceCorrection.getServiceDate();
    storedDailyAttendanceDetails.dtls.unitsAttended = dailyAttendanceCorrection.getUnitsAttended();
    storedDailyAttendanceDetails.dtls.unitsUnattended = dailyAttendanceCorrection.getUnitsUnattended();
    storedDailyAttendanceDetails.dtls.dailyAttendanceID = dailyAttendanceCorrection.getID();
    storedDailyAttendanceDetails.dtls.versionNo = dailyAttendanceCorrection.getVersionNo();
    storedDailyAttendanceDetails.dtls.rosterLineItemID = dailyAttendanceCorrection.getPRLICorrection().getID();

    if (null != dailyAttendanceCorrection.getDailyAttendance()) {

      if (0
        == dailyAttendanceCorrection.getDailyAttendance().getExpectedUnits()) {
        storedDailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
      } else {
        storedDailyAttendanceDetails.expectedUnitsString = String.valueOf(
          dailyAttendanceCorrection.getDailyAttendance().getExpectedUnits());
      }
    } else {
      storedDailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
    }
    if (0 == dailyAttendanceCorrection.getUnitsAttended()) {
      storedDailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
    } else {
      storedDailyAttendanceDetails.unitsAttendedString = String.valueOf(
        dailyAttendanceCorrection.getUnitsAttended());
    }
    if (0 == dailyAttendanceCorrection.getUnitsUnattended()) {
      storedDailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
    } else {
      storedDailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
        dailyAttendanceCorrection.getUnitsUnattended());
    }

    // BEGIN, CR00233623, ASN
    storedDailyAttendanceDetails.dtls.numHoursAttended = dailyAttendanceCorrection.getNumOfHoursAttended();
    storedDailyAttendanceDetails.dtls.numMinutesAttended = dailyAttendanceCorrection.getNumOfMinutesAttended();
    storedDailyAttendanceDetails.dtls.numHoursAbsent = dailyAttendanceCorrection.getNumOfHoursAbsent();
    storedDailyAttendanceDetails.dtls.numMinutesAbsent = dailyAttendanceCorrection.getNumOfMinutesAbsent();
    // END, CR00233623
    return storedDailyAttendanceDetails;
  }

  // END, CR00199226

  // BEGIN, CR00233623, ASN

  /**
   * Validates records for reporting method of utilization.
   *
   * @param dailyAttendanceDetailsList
   * List containing the daily attendance correction details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void validateUtilizationRecords(
    final DailyAttendanceDetailsList dailyAttendanceDetailsList)
    throws AppException, InformationalException {

    int recordCounter = 0;

    for (DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {

      if (0 == dailyAttendanceDetails.dtls.attendance.trim().length()
        && (dailyAttendanceDetails.dtls.absenceReason.trim().length() > 0
          || dailyAttendanceDetails.dtls.unitsAttended > 0
          || dailyAttendanceDetails.dtls.unitsUnattended > 0)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }

      if (dailyAttendanceDetails.dtls.attendance.equals(
        ATTENDANCEEntry.PRESENT.getCode())
          || dailyAttendanceDetails.dtls.attendance.equals(
            ATTENDANCEEntry.PARTIALLYPRESENT.getCode())) {

        if (dailyAttendanceDetails.dtls.unitsAttended < 0) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_ATTENDED_MUST_BE_GREATER_THAN_0_IF_PRESENT_OR_PARTIALLYPRESENT(
              ATTENDANCEEntry.PRESENT.toUserLocaleString(),
              ATTENDANCEEntry.PARTIALLYPRESENT.toUserLocaleString()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              1);

        } else if (0 == dailyAttendanceDetails.dtls.unitsAttended) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_ATTENDED_CANNOT_BE_0_IF_PRESENT_OR_PARTIALLYPRESENT(
              ATTENDANCEEntry.PRESENT.toUserLocaleString(),
              ATTENDANCEEntry.PARTIALLYPRESENT.toUserLocaleString()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              1);
        }

        if (dailyAttendanceDetails.dtls.attendance.equals(
          ATTENDANCEEntry.PRESENT.getCode())) {

          if (dailyAttendanceDetails.dtls.unitsUnattended != 0) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_UNATTENDED_MUST_BE_0_IF_PRESENT(
                ATTENDANCEEntry.PRESENT.toUserLocaleString()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                1);
          }
        } else {

          if (dailyAttendanceDetails.dtls.unitsUnattended <= 0) {

            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_UNATTENDED_MUST_BE_GREATER_THAN_0_IF_NOT_PRESENT(
                ATTENDANCEEntry.PRESENT.toUserLocaleString()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                2);
          }
          if (dailyAttendanceDetails.dtls.absenceReason.trim().length() == 0) {

            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_ABSENCE_REASON_MUST_BE_ENTERED(
                ATTENDANCEEntry.PRESENT.toUserLocaleString()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                4);
          }
        }
      } else if (dailyAttendanceDetails.dtls.attendance.equals(
        ATTENDANCEEntry.ABSENT.getCode())) {

        if (0 == dailyAttendanceDetails.dtls.absenceReason.trim().length()) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_ABSENCE_REASON_MUST_BE_ENTERED(
              ATTENDANCEEntry.PRESENT.toUserLocaleString()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              3);
        }

        if (dailyAttendanceDetails.dtls.unitsAttended != 0) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_ATTENDED_MUST_BE_0_UNLESS_PRESENT_OR_PARTIALLYPRESENT(
              ATTENDANCEEntry.PRESENT.toUserLocaleString(),
              ATTENDANCEEntry.PARTIALLYPRESENT.toUserLocaleString()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              1);
        }

        if (dailyAttendanceDetails.dtls.unitsUnattended <= 0) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_UNATTENDED_MUST_BE_GREATER_THAN_0_IF_NOT_PRESENT(
              ATTENDANCEEntry.PRESENT.toUserLocaleString()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              3);
        }

      }

      if (StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.attendance)) {

        recordCounter = recordCounter + 1;
      }
    }

    if (recordCounter == dailyAttendanceDetailsList.details.size()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

    ValidationHelper.failIfErrorsExist();

  }
  // END, CR00233623
}     
