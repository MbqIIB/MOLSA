/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.core.impl.EnvVars;
import curam.cpm.facade.struct.LicenseNotificationKey;
import curam.cpm.sl.impl.LicenseNotification;
import curam.provider.LicenseNotificationEvent;
import curam.provider.impl.LicenseDAO;
import curam.provider.impl.LicenseStatusEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;


/**
 * Facade layer class for processing renewal notifications.
 */
public abstract class ProcessLicenseRenewalNotifications extends curam.cpm.facade.base.ProcessLicenseRenewalNotifications {
  
  /**
   * Constructor
   */
  public ProcessLicenseRenewalNotifications() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }  
  
  @Inject
  protected LicenseDAO licenseDAO;

  // ___________________________________________________________________________
  /**
   * Processes renewal notifications for licenses.
   *
   * @throws AppException
   * @throws InformationalException
   */
  public void processLicenseRenewalNotifications() 
    throws AppException, InformationalException {
    
    Set<curam.provider.impl.License> allLicenses = licenseDAO.readAll();
    
    // number of Event days
    int numberOfEventDays;
    int remainingLicenseDays;
    String numberOfEventDaysStr;

    // Set the date to specified number of days
    numberOfEventDaysStr = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_NO_OFDAYS_EVENTS);
    try {
      numberOfEventDays = Integer.parseInt(numberOfEventDaysStr);
    } catch (NumberFormatException e) {
      // any problem, use the default.
      numberOfEventDays = EnvVars.ENV_NO_OFDAYS_EVENTS_DEFAULT;
    }

    for (final curam.provider.impl.License license : allLicenses) {

      remainingLicenseDays = license.getDateRange().end().subtract(
        Date.getCurrentDate());

      // Begin CR00096779, ABS 
      if ((!license.getLifecycleState().equals(LicenseStatusEntry.CANCELED))
        && (remainingLicenseDays <= numberOfEventDays)) {
        // End CR00096779 
        // Send Notification
        LicenseNotification licenseNotification = new LicenseNotification();
        LicenseNotificationKey licenseNotificationKey = new LicenseNotificationKey();

        licenseNotificationKey.licenseID = license.getID();
        licenseNotificationKey.event = LicenseNotificationEvent.RENEWLICENSE;

        licenseNotification.sendNotification(licenseNotificationKey, license);

      }
    }    
  }
}
