/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2010, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.inject.Inject;

import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.cefwidgets.docbuilder.impl.ListBuilder;
import curam.cefwidgets.docbuilder.impl.RotatorBuilder;
import curam.cefwidgets.docbuilder.impl.StackContainerBuilder;
import curam.cefwidgets.docbuilder.impl.helper.impl.CodeTableItemEntry;
import curam.cefwidgets.docbuilder.impl.helper.impl.DocBuilderHelperFactory;
import curam.cefwidgets.utilities.impl.RendererConfig;
import curam.cefwidgets.utilities.impl.RendererConfig.RendererConfigType;
import curam.codetable.impl.REFERRALRELATEDROLETYPEEntry;
import curam.codetable.impl.SERVICEDELIVERYSTATUSEntry;
import curam.core.facade.fact.ProductDeliveryFactory;
import curam.core.facade.struct.ListCaseFinancialsKey;
import curam.core.impl.CuramConst;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.fact.TabDetailsHelperFactory;
import curam.core.sl.impl.AgeStringDetail;
import curam.core.sl.impl.CaseTabDetailsHelper;
import curam.core.sl.impl.TabDetailFormatterInterface;
import curam.core.sl.intf.TabDetailFormatter;
import curam.core.sl.intf.TabDetailsHelper;
import curam.core.sl.struct.CaseMemberTabDetails;
import curam.core.sl.struct.ContactTabDetails;
import curam.core.sl.struct.FormatPersonNameKey;
import curam.core.sl.struct.IncidentAndRoleTabDetailsList;
import curam.core.sl.struct.InvestigationAndRoleTabDetailsList;
import curam.core.sl.struct.PersonAgeDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.FinancialInstructionCaseDetails1;
import curam.core.struct.ViewCaseInstructionDetails;
import curam.cpm.facade.struct.PaymentInformationDetails;
import curam.financial.impl.PaymentInformation;
import curam.message.SERVICEANDREFERRALCONTEXTPANEL;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.PhoneNumber;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.impl.Address;
import curam.piwrapper.impl.AddressDAO;
import curam.piwrapper.impl.ClientURI;
import curam.piwrapper.impl.EmailAddress;
import curam.piwrapper.outcomeplan.codetable.impl.ACTIVITYOUTCOMEACHIEVEDEntry;
import curam.piwrapper.user.impl.User;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderTypeNameEntry;
import curam.referral.impl.Referral;
import curam.referral.impl.ReferralRole;
import curam.referral.impl.ReferralRoleDAO;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItem;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItemDAO;
import curam.servicedelivery.impl.ServiceDelivery;
import curam.serviceoffering.SODELIVERYTYPE;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.Money;


/**
 * Implementation of helper methods for creating service and referral context
 * panels. This contains constants used in styles and domain definitions on
 * context panels.
 *
 * @since 6.0
 */
class ServiceAndReferralContextPanelHelperImpl implements
  ServiceAndReferralContextPanelHelper {

  /**
   * The width in percent of column 4 of the members header list. </br> Value:
   * 5.
   */
  protected static final int kCol4MemberHeaderListWidth = 5;

  /**
   * The width in percent of column 3 of the members header list. </br> Value:
   * 25.
   */
  protected static final int kCol3MemberHeaderListWidth = 25;

  /**
   * The width in percent of column 2 of the members header list. </br> Value:
   * 65
   */
  protected static final int kCol2MemberHeaderListWidth = 65;

  /**
   * The width in percent of column 1 of the members header list. </br> Value:
   * 5.
   */
  protected static final int kCol1MemberHeaderListWidth = 5;

  /**
   * The width in percent of column 3 of the members list. </br> Value: 30.
   */
  protected static final int kCol3MemberListWidth = 30;

  /**
   * The width in percent of column 2 of the members list. </br> Value: 65
   */
  protected static final int kCol2MemberListWidth = 65;

  /**
   * The width in percent of column 1 of the members list. </br> Value: 5.
   */
  protected static final int kCol1MemberListWidth = 5;

  /**
   * The index position of the 4th column. </br> Value: 4.
   */
  protected static final int kCol4 = 3;

  /**
   * The index position of the 3rd column. </br> Value: 3.
   */
  protected static final int kCol3 = 3;

  /**
   * The index position of the 2nd column. </br> Value: 2.
   */
  protected static final int kCol2 = 2;

  /**
   * The index position of the 1st column. </br> Value: 1.
   */
  protected static final int kCol1 = 1;

  /**
   * The number of columns in the members list. </br> Value: 3.
   */
  protected static final int kNumColsInMemberList = 3;

  /**
   * The number of photo panels to be displayed. </br> Value: 4.
   */
  protected static final int kNumPhotoPanels = 4;

  /**
   * Reference to addressDAO.
   */
  @Inject
  protected AddressDAO addressDAO;

  /**
   * Reference to referralRoleDAO.
   */
  @Inject
  protected ReferralRoleDAO referralRoleDAO;

  /**
   * Reference to serviceOfferingDAO.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Reference to serviceAuthorizationLineItemDAO.
   */
  @Inject
  protected ServiceAuthorizationLineItemDAO serviceAuthorizationLineItemDAO;

  /**
   * {@inheritDoc}
   */
  public ContentPanelBuilder getCaseMemberThumbnailDetails(
    final CaseParticipantRole caseParticipantRole) throws AppException,
      InformationalException {

    CaseMemberTabDetails caseMemberTabDetails = getCaseMemberTabDetails(
      caseParticipantRole);

    // populate case member photo item
    return curam.core.sl.impl.CaseTabDetailsHelper.getCaseMemberThumbnailDetails(
      caseMemberTabDetails, false);
  }

  /**
   * {@inheritDoc}
   */
  public StackContainerBuilder getCaseMemberThumbnailDetails(
    final List<CaseParticipantRole> caseParticipantRoleList)
    throws AppException, InformationalException {

    StackContainerBuilder stackContainerBuilder = StackContainerBuilder.createStackContainer(
      ContextPanelConst.kStyleFourImagesStackContainerServiceOrReferral, false,
      true);

    RotatorBuilder rotatorBuilder = RotatorBuilder.createRotator(
      CuramConst.gkIDRotator, kNumPhotoPanels);

    rotatorBuilder.setQuickParam(false);
    rotatorBuilder.setWrapParam(false);

    ContentPanelBuilder memberListContentPanelBuilder = ContentPanelBuilder.createPanel(
      CuramConst.gkPanelCaseMemberList);

    // create an outer list to hold the headers (for scrolling)
    ListBuilder memberListBuilderHeader = ListBuilder.createList(
      kNumColsInMemberList + 1);

    // set the column widths of the table
    memberListBuilderHeader.setColumnWidth(kCol1, kCol1MemberHeaderListWidth);
    memberListBuilderHeader.setColumnWidth(kCol2, kCol2MemberHeaderListWidth);
    memberListBuilderHeader.setColumnWidth(kCol3, kCol3MemberHeaderListWidth);
    memberListBuilderHeader.setColumnWidth(kCol4, kCol4MemberHeaderListWidth);

    // set the column titles
    memberListBuilderHeader.addColumnTitle(kCol2,
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_CLIENTS));
    memberListBuilderHeader.addColumnTitle(kCol3,
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_AGE));

    memberListContentPanelBuilder.addWidgetItem(memberListBuilderHeader,
      CuramConst.gkStyle, CuramConst.gkStyleSingleList);

    ListBuilder memberListBuilder = ListBuilder.createList(kNumColsInMemberList);

    // set the column widths of the table
    memberListBuilder.setColumnWidth(kCol1, kCol1MemberListWidth);
    memberListBuilder.setColumnWidth(kCol2, kCol2MemberListWidth);
    memberListBuilder.setColumnWidth(kCol3, kCol3MemberListWidth);

    CaseMemberTabDetails caseMemberTabDetails;

    for (int i = 0; i < caseParticipantRoleList.size(); i++) {

      CaseParticipantRole caseParticipantRole = caseParticipantRoleList.get(i);

      caseMemberTabDetails = getCaseMemberTabDetails(caseParticipantRole);

      // populate case member photo item
      ContentPanelBuilder thumbnailContentPanelBuilder = curam.core.sl.impl.CaseTabDetailsHelper.getCaseMemberThumbnailDetails(
        caseMemberTabDetails, false);

      rotatorBuilder.addWidgetItem(thumbnailContentPanelBuilder,
        CuramConst.gkStyle, CuramConst.gkContentPanel);

      // populate case member list row
      createMemberRow(memberListBuilder, caseMemberTabDetails,
        i + CuramConst.gkOne);
    }

    // Add the list to the content panel
    memberListContentPanelBuilder.addWidgetItem(memberListBuilder,
      CuramConst.gkStyle, CuramConst.gkStyleSingleList, CuramConst.gkTableList);

    stackContainerBuilder.addWidgetItem(rotatorBuilder, CuramConst.gkStyle,
      CuramConst.gkStyleRotator, CuramConst.gkStackContainerTitlePhoto,
      CuramConst.gkStyleStackContainerPhoto);

    stackContainerBuilder.addWidgetItem(memberListContentPanelBuilder,
      CuramConst.gkStyle, CuramConst.gkContentPanel,
      CuramConst.gkStackContainerTitleList,
      CuramConst.gkStyleStackContainerList);

    return stackContainerBuilder;
  }

  /**
   * Returns the details needed to build the image and lists for displaying a
   * {@link CaseParticipantRole}.
   *
   * @param caseParticipantRole
   * The person to be displayed
   * @return The details of the person to be displayed
   */
  protected CaseMemberTabDetails getCaseMemberTabDetails(
    final CaseParticipantRole caseParticipantRole) {
    CaseMemberTabDetails caseMemberTabDetails;

    caseMemberTabDetails = new CaseMemberTabDetails();
    ConcernRole concernRole = caseParticipantRole.getConcernRole();

    caseMemberTabDetails.addressData = addressDAO.get(concernRole.getPrimaryAddressID()).getAddressData();
    caseMemberTabDetails.concernRoleID = concernRole.getID();
    caseMemberTabDetails.concernRoleName = concernRole.getName();
    EmailAddress emailAddress = concernRole.getEmailAddress();

    if (null != emailAddress) {
      caseMemberTabDetails.emailAddress = emailAddress.getEmail();
    }
    PhoneNumber primaryPhoneNumber = concernRole.getPrimaryPhoneNumber();

    if (null != primaryPhoneNumber) {
      caseMemberTabDetails.phoneNumberID = primaryPhoneNumber.getID();
    }
    caseMemberTabDetails.primaryAlternateID = concernRole.getPrimaryAlternateID();
    return caseMemberTabDetails;
  }

  /**
   * Format XML data for a dates panel. The start date, with the
   * {@link SERVICEANDREFERRALCONTEXTPANEL#INFO_START} label is displayed in the
   * first column, and the other date and given label are displayed in the
   * second column.
   *
   * @param startDate
   * The start date to be displayed
   * @param otherDate
   * The other date to be displayed
   * @param labelLocalisableString
   * The label to be used for the second date field
   * @return ListBuilder with date panel details XML data.
   */
  protected ContentPanelBuilder getDatePanel(final Date startDate,
    final Date otherDate, final LocalisableString labelLocalisableString) {

    ContentPanelBuilder dateContent = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleDateContent);

    ContentPanelBuilder dateContentDetail = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleDateContentDetail);

    addIconLabelAndDate(
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_START_DATE),
      startDate, dateContentDetail);

    // Display other date and label
    addIconLabelAndDate(labelLocalisableString, otherDate, dateContentDetail);

    dateContent.addWidgetItem(dateContentDetail, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    return dateContent;

  }

  /**
   * Format XML data for a dates panel with a start and end date.
   *
   * @param startDate
   * The start date to be displayed
   * @param endDate
   * The end date to be displayed
   * @return ListBuilder with date panel details XML data.
   */
  protected ContentPanelBuilder getBasicDatePanel(final Date startDate,
    final Date endDate) {

    ContentPanelBuilder dateContent = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleDateContent);

    ContentPanelBuilder dateContentDetail = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleDateContentDetail);

    addIconLabelAndDate(
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_START_DATE),
      startDate, dateContentDetail);

    addIconLabelAndDate(
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_END_DATE),
      endDate, dateContentDetail);

    dateContent.addWidgetItem(dateContentDetail, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    return dateContent;

  }

  /**
   * Format XML data for a date panel with the given {@link LocalisableString}
   * label and date.
   *
   * @param label
   * The label to use for the date field
   * @param date
   * The start date to be displayed
   * @return ListBuilder with date panel details XML data.
   */
  protected ContentPanelBuilder getSingleDatePanel(
    final LocalisableString label, final Date date) {

    ContentPanelBuilder dateContent = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleDateContent);

    ContentPanelBuilder dateContentDetail = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleDateContentDetail);

    addIconLabelAndDate(label, date, dateContentDetail);

    dateContent.addWidgetItem(dateContentDetail, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    return dateContent;

  }

  /**
   * Adds the given label, a date icon and the given date to the given
   * {@link ContentPanelBuilder}.
   *
   * @param label
   * The label to use for the date field
   * @param date
   * The date to add
   * @param dateContentDetail
   * The date content panel
   */
  protected void addIconLabelAndDate(final LocalisableString label,
    final Date date, final ContentPanelBuilder dateContentDetail) {
    // Create a image builder for start date icon
    ImageBuilder date1ImageBuilder = ImageBuilder.createImage(
      CuramConst.gkIconScheduleBlue, CuramConst.gkEmpty);

    date1ImageBuilder.setImageResource(CuramConst.gkRendererImages);
    // BEGIN, CR00296333, MR
    date1ImageBuilder.setImageAltText(
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_DATE).toClientFormattedText());
    // END, CR00296333
    dateContentDetail.addImageItem(date1ImageBuilder);

    // create the list to hold the dates and labels
    ListBuilder dateList = ListBuilder.createHorizontalList(2);

    dateList.addRow();

    // Add the start date
    dateList.addEntry(1, 1, label);
    if (null != date) {
      dateList.addEntry(2, 1, date);
    }
    dateContentDetail.addSingleListItem(dateList,
      ContextPanelConst.kStyleDateContentTable);
  }

  /**
   * Create and populate case member list row with member details.
   *
   * @param memberListBuilder
   * Case member list builder to create and populate row
   * @param caseMemberTabDetails
   * Case member details
   * @param rowNo
   * Row number to insert into list
   */
  protected void createMemberRow(final ListBuilder memberListBuilder,
    final CaseMemberTabDetails caseMemberTabDetails, final int rowNo)
    throws AppException, InformationalException {

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = caseMemberTabDetails.concernRoleID;

    TabDetailFormatter tabDetailFormatterObj = TabDetailFormatterFactory.newInstance();
    TabDetailFormatterInterface tabDetailFormatterInterface = (TabDetailFormatterInterface) TabDetailFormatterFactory.newInstance();
    FormatPersonNameKey formatPersonNameKey = new FormatPersonNameKey();

    formatPersonNameKey.wrapNameInd = false;

    // create member list row
    memberListBuilder.addRow();

    // Add Citizen Context Viewer link
    LinkBuilder linkBuilder = getCCVLink(caseMemberTabDetails.concernRoleID);

    RendererConfig rendererConfig = new RendererConfig(RendererConfigType.STYLE,
      CuramConst.gkStyleLink);

    memberListBuilder.addEntry(1, rowNo, linkBuilder, rendererConfig);

    // Add Persons Name
    String contentPanelID = CuramConst.gkCaseMemberListContenPanelID
      + String.valueOf(caseMemberTabDetails.concernRoleID);
    ContentPanelBuilder nameContentPanelBuilder = ContentPanelBuilder.createPanelWithID(
      contentPanelID);

    formatPersonNameKey.concernRoleID = caseMemberTabDetails.concernRoleID;

    LinkBuilder memberLinkBuilder = LinkBuilder.createLink(
      tabDetailFormatterObj.formatPersonName(formatPersonNameKey).name,
      CuramConst.gkParticipantHomePage, memberListBuilder.getWidgetDocument());

    memberLinkBuilder.addParameter(CuramConst.gkPageParameterConcernRoleID,
      String.valueOf(caseMemberTabDetails.concernRoleID));

    nameContentPanelBuilder.addLinkItem(memberLinkBuilder,
      ContextPanelConst.kStyleLinkPersonName);

    ContactTabDetails contactTabDetails = new ContactTabDetails();

    contactTabDetails.assign(caseMemberTabDetails);

    ContentPanelBuilder personNameIconsPanel = ContentPanelBuilder.createPanel(
      CuramConst.gkPersonNameIcons);

    // add the name link and tool tip
    personNameIconsPanel.addWidgetItem(nameContentPanelBuilder,
      CuramConst.gkStyle, CuramConst.gkContentPanel);

    addConcernRoleIcons(concernRoleKey, personNameIconsPanel);

    RendererConfig nameContentPanelConfig = new RendererConfig(
      RendererConfigType.STYLE, CuramConst.gkContentPanel);

    memberListBuilder.addEntry(2, rowNo, personNameIconsPanel,
      nameContentPanelConfig);

    // Add age
    PersonAgeDetails personAgeDetails = new PersonAgeDetails();

    personAgeDetails.dateOfCalculation = Date.getCurrentDate();
    personAgeDetails.personID = caseMemberTabDetails.concernRoleID;
    personAgeDetails.indDisplayDateOfBirth = false;

    AgeStringDetail ageString = tabDetailFormatterInterface.formatAge(
      personAgeDetails);

    memberListBuilder.addEntry(kCol3, rowNo, ageString.localisableAgeString);

  }

  /**
   * Creates a CCV Icon link for the given concern role ID.
   *
   * @param concernRoleID
   * The concern role to open the CCV for
   * @return An icon link to open the Citizen Context Viewer for the given
   * concern
   */
  protected LinkBuilder getCCVLink(final long concernRoleID) {
    LinkBuilder linkBuilder = LinkBuilder.createLink(CuramConst.gkEmpty,
      "../flex/Citizen_resolveCitizenViewer.jsp");

    linkBuilder.addParameter(CuramConst.gkPageParameterConcernRoleID,
      String.valueOf(concernRoleID));
    linkBuilder.setTextResource(CuramConst.gkRendererImages);
    linkBuilder.addImageWithAltTextMessage(CuramConst.gkIconCCV,
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_CITIZEN_CONTEXT_VIEWER).toClientFormattedText());
    linkBuilder.addOnClickAttribute("return openContextViewer(this)");
    return linkBuilder;
  }

  /**
   * Adds the icons for the given {@link ConcernRoleKey} to the given
   * {@link ContentPanelBuilder}.
   *
   * @param concernRoleKey
   * The concern to add the icons for
   * @param iconsPanel
   * The panel the icons are to be added to
   */
  protected void addConcernRoleIcons(final ConcernRoleKey concernRoleKey,
    final ContentPanelBuilder iconsPanel) {
    // Add special caution details
    try {
      iconsPanel.addWidgetItem(
        curam.core.sl.impl.TabDetailsHelper.getSpecialCautionDetails(
          concernRoleKey),
          CuramConst.gkStyle,
          CuramConst.gkContentPanel);

      TabDetailsHelper tabDetailsHelperObj = TabDetailsHelperFactory.newInstance();

      // read incident and role details
      IncidentAndRoleTabDetailsList incidentList = tabDetailsHelperObj.readIncidentTabDetails(
        concernRoleKey);

      if (incidentList.dtls.size() > CuramConst.gkZero) {
        iconsPanel.addWidgetItem(
          CaseTabDetailsHelper.getMemberIncidentDetails(concernRoleKey,
          incidentList),
          CuramConst.gkStyle,
          CuramConst.gkContentPanel,
          CuramConst.gkListIcon);
      }

      // read investigation and role details
      InvestigationAndRoleTabDetailsList investigationList = tabDetailsHelperObj.readInvestigationTabDetails(
        concernRoleKey);

      if (investigationList.dtls.size() > CuramConst.gkZero) {

        iconsPanel.addWidgetItem(
          CaseTabDetailsHelper.getMemberInvestigationDetails(concernRoleKey,
          investigationList),
          CuramConst.gkStyle,
          CuramConst.gkContentPanel,
          CuramConst.gkListIcon);
      }
    } catch (AppException e) {// do nothing
    } catch (InformationalException e) {// do nothing
    }
  }

  /**
   * {@inheritDoc}
   */
  public ContentPanelBuilder getContextPanelDetails(final Referral referral) {

    ContentPanelBuilder referralTabDetails = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleServiceOrReferralTabDetails);

    referralTabDetails.addRoundedCorners();

    ContentPanelBuilder referralDetails = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleServiceOrReferralDetails);

    // Add name
    referralDetails.addStringItem(referral.getName(),
      ContextPanelConst.kStyleName);

    // add the parent case link
    CaseHeader relatedCase = referral.getRelatedCase();

    referralDetails.addLinkItem(getCaseLink(relatedCase),
      ContextPanelConst.kStyleTabLink);

    // Add the main details list
    ListBuilder referralList = getReferralMainDetailsList(referral);

    referralDetails.addSingleListItem(referralList,
      ContextPanelConst.kStyleMainDetailsHorizontalTable);
    referralTabDetails.addWidgetItem(referralDetails, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    // add the referral date panel
    ContentPanelBuilder datePanel = getSingleDatePanel(
      new LocalisableString(
        SERVICEANDREFERRALCONTEXTPANEL.INFO_DATE_OF_REFERRAL),
        referral.getReferralDate());

    referralTabDetails.addWidgetItem(datePanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    return referralTabDetails;
  }

  /**
   * {@inheritDoc}
   */
  public ListBuilder getReferralMainDetailsList(final Referral referral) {
    ListBuilder referralList = ListBuilder.createHorizontalList(2);
    int rowIndex = 0;

    // Display the provider
    referralList.addRow();
    rowIndex++;
    referralList.addEntry(1, rowIndex,
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_PROVIDER));
    if (referral.getProviderType().equals(REFERRALRELATEDROLETYPEEntry.PROVIDER)) {
      // display CPM provider panel
      ServiceOffering serviceOffering = getReferralService(referral);

      if (null != serviceOffering) {
        ContentPanelBuilder providerNameIconsPanel = getProviderNameIconsPanel(
          serviceOffering, (Provider) referral.getProvider());

        RendererConfig nameContentPanelConfig = new RendererConfig(
          RendererConfigType.STYLE, CuramConst.gkContentPanel);

        referralList.addEntry(2, rowIndex, providerNameIconsPanel,
          nameContentPanelConfig);
      }
    } else if (!referral.getProviderType().equals(
      REFERRALRELATEDROLETYPEEntry.NOT_SPECIFIED)) { // just display name
      referralList.addEntry(2, rowIndex, referral.getProvider().getName());
    }

    // Add referred by row
    referralList.addRow();
    rowIndex++;
    referralList.addEntry(1, rowIndex,
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_REFERRED_BY));
    LinkBuilder userLinkBuilder = getUserLink(referral.getReferredBy());
    RendererConfig linkRendererConfig = new RendererConfig(
      RendererConfigType.STYLE, CuramConst.gkStyleLink);

    referralList.addEntry(2, rowIndex, userLinkBuilder, linkRendererConfig);

    return referralList;
  }

  /**
   * {@inheritDoc}
   */
  public ContentPanelBuilder getContextPanelDetails(
    final ServiceDelivery serviceDelivery) {

    ContentPanelBuilder serviceDeliveryTabDetails = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleServiceOrReferralTabDetails);

    serviceDeliveryTabDetails.addRoundedCorners();

    ContentPanelBuilder serviceDeliveryDetails = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleServiceOrReferralDetails);

    // Add name
    serviceDeliveryDetails.addStringItem(serviceDelivery.getName(),
      ContextPanelConst.kStyleName);

    // add status
    serviceDeliveryDetails.addCodetableItem(
      serviceDelivery.getLifecycleState().getCode(),
      ContextPanelConst.kDomainServiceDeliveryStatus,
      ContextPanelConst.kStyleStatus);

    // add the parent case link
    CaseHeader relatedCase = serviceDelivery.getRelatedCase();

    serviceDeliveryDetails.addLinkItem(getCaseLink(relatedCase),
      ContextPanelConst.kStyleTabLink);

    ListBuilder serviceDeliveryList = getServiceDeliveryMainDetailsList(
      serviceDelivery);

    serviceDeliveryDetails.addSingleListItem(serviceDeliveryList);
    serviceDeliveryTabDetails.addWidgetItem(serviceDeliveryDetails,
      CuramConst.gkStyle, CuramConst.gkContentPanel);

    // add the dates details
    DateRange dateRange = serviceDelivery.getDateRange();
    ContentPanelBuilder datePanel = getBasicDatePanel(dateRange.start(),
      dateRange.end());

    serviceDeliveryTabDetails.addWidgetItem(datePanel, CuramConst.gkStyle,
      CuramConst.gkContentPanel);

    return serviceDeliveryTabDetails;

  }

  /**
   * {@inheritDoc}
   */
  public ListBuilder getServiceDeliveryMainDetailsList(
    final ServiceDelivery serviceDelivery) {
    // create a content panel for each column
    ListBuilder twoColLayout = ListBuilder.createList(2);

    twoColLayout.addRow();
    twoColLayout.setCssClass(
      ContextPanelConst.kStyleServiceOrReferralDetailsListTwoColumns);
    ContentPanelBuilder leftColContent = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleColumnContentPanel);
    ContentPanelBuilder rightColContent = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleColumnContentPanel);
    RendererConfig rendererConfig = new RendererConfig(RendererConfigType.STYLE,
      CuramConst.gkContentPanel);

    twoColLayout.addEntry(1, 1, leftColContent, rendererConfig);
    twoColLayout.addEntry(2, 1, rightColContent, rendererConfig);

    // create a list for each column content panel
    ListBuilder leftColList = ListBuilder.createHorizontalList(2);

    leftColContent.addSingleListItem(leftColList,
      ContextPanelConst.kStyleMainDetailsHorizontalTable);
    ListBuilder rightColList = ListBuilder.createHorizontalList(2);

    rightColContent.addSingleListItem(rightColList,
      ContextPanelConst.kStyleMainDetailsHorizontalTable);
    int rowIndex = 0;

    // Add provider link or provider type
    Provider provider = serviceDelivery.getProvider();
    ProviderTypeNameEntry providerType = serviceDelivery.getProviderType();

    if (null != provider) {
      leftColList.addRow();
      rightColList.addRow();
      rowIndex++;
      leftColList.addEntry(1, rowIndex,
        new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_PROVIDER));

      ContentPanelBuilder providerNameIconsPanel = getProviderNameIconsPanel(
        serviceDelivery.getServiceOffering(), provider);

      RendererConfig nameContentPanelConfig = new RendererConfig(
        RendererConfigType.STYLE, CuramConst.gkContentPanel);

      leftColList.addEntry(2, rowIndex, providerNameIconsPanel,
        nameContentPanelConfig);

    } else if (!providerType.equals(ProviderTypeNameEntry.NOT_SPECIFIED)) {
      leftColList.addRow();
      rightColList.addRow();
      rowIndex++;
      leftColList.addEntry(1, rowIndex,
        new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_PROVIDER_TYPE));
      CodeTableItemEntry providerTypeCodeTableItem = DocBuilderHelperFactory.getCodeTableItemEntry(
        providerType.getCode(), ContextPanelConst.kDomainProviderType);

      leftColList.addEntry(2, rowIndex, providerTypeCodeTableItem);
    }

    // add the next row to each list
    leftColList.addRow();
    rightColList.addRow();
    rowIndex++;

    // Add outcome
    leftColList.addEntry(1, rowIndex,
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_OUTCOME));
    CodeTableItemEntry codeTableItem = DocBuilderHelperFactory.getCodeTableItemEntry(
      serviceDelivery.getOutcome().getCode(),
      ContextPanelConst.kDomainActivityOutcomeAchieved);

    leftColList.addEntry(2, rowIndex, codeTableItem);

    // Add the reason if outcome is not successful
    if (serviceDelivery.getOutcome().equals(
      ACTIVITYOUTCOMEACHIEVEDEntry.NOTSUCCESSFUL)) {
      rightColList.addEntry(1, rowIndex,
        new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_REASON));
      CodeTableItemEntry outcomeUnattainedCodeTableItem = DocBuilderHelperFactory.getCodeTableItemEntry(
        serviceDelivery.getOutcomeReason().getCode(),
        ContextPanelConst.kDomainActivityOutcomeReason);

      rightColList.addEntry(2, rowIndex, outcomeUnattainedCodeTableItem);
    }

    // Add payments row
    leftColList.addRow();
    rightColList.addRow();
    rowIndex++;

    // Add latest payment
    leftColList.addEntry(1, rowIndex,
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_LATEST_PAYMENT));
    
    // BEGIN, CR00311734, SS
    try {
      final PaymentInformation paymentInformation = serviceDelivery.getLatestPayment();

      if (null != paymentInformation) {
        final ContentPanelBuilder latestPaymentPanel = getLatestPaymentPanel(
          paymentInformation.getAmountPaid(),
          paymentInformation.getPaymentDate());
        final RendererConfig paymentRendererConfig = new RendererConfig(
          RendererConfigType.STYLE, CuramConst.gkContentPanel);

        leftColList.addEntry(2, rowIndex, latestPaymentPanel,
          paymentRendererConfig);
      }
    } catch (AppException e) {// nothing needed
    } catch (InformationalException e) {// nothing needed
    }
    // END, CR00311734

    // Add total cost so far
    rightColList.addEntry(1, rowIndex,
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_TOTAL));
    rightColList.addEntry(2, rowIndex, getTotalCost(serviceDelivery));

    // Add estimated cost row
    leftColList.addRow();
    rightColList.addRow();
    rowIndex++;
    leftColList.addEntry(1, rowIndex,
      new LocalisableString(SERVICEANDREFERRALCONTEXTPANEL.INFO_ESTIMATED_COST));
    leftColList.addEntry(2, rowIndex, serviceDelivery.getEstimatedCost());
    
    // BEGIN, CR00292762, GYH
    if (!serviceDelivery.getServiceFrequencyPattern().isZeroPattern()) {
      if (SERVICEDELIVERYSTATUSEntry.INPROGRESS.getCode().equals(
        serviceDelivery.getLifecycleState().getCode())
          || SERVICEDELIVERYSTATUSEntry.NOTSTARTED.getCode().equals(
            serviceDelivery.getLifecycleState().getCode())) {
        // Display Next Delivery field

        // BEGIN, CR00296728, CSH
        if (!serviceDelivery.getServiceOffering().getDeliveryType().getCode().equals(
          SODELIVERYTYPE.PRODUCTDELIVERY)) {
          Set<ServiceAuthorizationLineItem> serviceAuthorizationLineItems = serviceAuthorizationLineItemDAO.searchByServiceAuthorization(
            serviceDelivery.getServiceAuthorization());

          if (!serviceAuthorizationLineItems.isEmpty()) {

            rightColList.addEntry(1, rowIndex,
              new LocalisableString(
              SERVICEANDREFERRALCONTEXTPANEL.INFO_NEXT_DELIVERY));

            Date currentDate = Date.getCurrentDate();
            Date nextDeliveryDate = Date.getCurrentDate().addDays(365);

            for (final ServiceAuthorizationLineItem serviceAuthorizationLineItem : serviceAuthorizationLineItems) {
              DateRange dateRange = serviceAuthorizationLineItem.getDateRange();
              Date saliStartDate = dateRange.start();

              if (saliStartDate.after(currentDate)
                && (saliStartDate.before(nextDeliveryDate)
                  || saliStartDate.equals(nextDeliveryDate))) {
                nextDeliveryDate = saliStartDate;
              }
            }
            rightColList.addEntry(2, rowIndex, nextDeliveryDate);

          }
        }
        // END, CR00296728
      }
    }
    // END, CR00292762


    return twoColLayout;
  }

  /**
   * Returns the total amount paid so far for the given {@link ServiceDelivery}.
   * If this cannot be read zero is returned.
   *
   * @param serviceDelivery
   * The service delivery to read
   * @return The total amount paid to date
   */
  protected Money getTotalCost(final ServiceDelivery serviceDelivery) {
    try {
      return serviceDelivery.getActualCost();
    } catch (AppException e) {
      return new Money(0);
    } catch (InformationalException e) {
      return new Money(0);
    }
  }

  /**
   * Returns a {@link ContentPanelBuilder} with the {@link Provider} name, tool
   * tip and icons.
   *
   * @param serviceOffering
   * The {@link ServiceOffering} being read
   * @param provider
   * The provider to display
   * @return The provider name and icons panel
   */
  protected ContentPanelBuilder getProviderNameIconsPanel(
    @SuppressWarnings("unused") final ServiceOffering serviceOffering,
    final Provider provider) {
    // create the panel to hold the name and icons
    ContentPanelBuilder providerNameIconsPanel = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleProviderNameIcons);

    // add the provider name
    providerNameIconsPanel.addStringItem(provider.getName(),
      ContextPanelConst.kStyleLinkPersonName);

    // add the icons
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = provider.getID();
    addConcernRoleIcons(concernRoleKey, providerNameIconsPanel);
    return providerNameIconsPanel;
  }

  /**
   * Gets the {@link ContactTabDetails} for the given {@link Provider}.
   *
   * @param provider
   * The provider to convert
   * @return The contact tab details for the given provider
   */
  protected ContactTabDetails getContactTabDetails(final Provider provider) {
    ContactTabDetails contactTabDetails = new ContactTabDetails();
    Address address = addressDAO.get(provider.getPrimaryAddressID());

    if (null != address) {
      contactTabDetails.addressData = address.getAddressData();
    }
    contactTabDetails.concernRoleName = provider.getName();
    EmailAddress emailAddress = provider.getEmailAddress();

    if (null != emailAddress) {
      contactTabDetails.emailAddress = emailAddress.getEmail();
    }
    PhoneNumber primaryPhoneNumber = provider.getPrimaryPhoneNumber();

    if (null != primaryPhoneNumber) {
      contactTabDetails.phoneNumberID = primaryPhoneNumber.getID();
    }
    contactTabDetails.primaryAlternateID = provider.getPrimaryAlternateID();
    return contactTabDetails;
  }

  /**
   * Build up the link to the given {@link Provider}.
   *
   * @param provider
   * The provider to link to
   * @param serviceOffering
   * The service this provider is providing
   * @return The link XML
   */
  protected LinkBuilder getProviderLink(final Provider provider,
    final ServiceOffering serviceOffering) {
    LinkBuilder providerLinkBuilder = LinkBuilder.createLink(provider.getName(),
      "ProviderManagement_viewProviderOverviewModalPage.do");

    providerLinkBuilder.addParameter("serviceOfferingID",
      serviceOffering.getID().toString());
    providerLinkBuilder.addParameter("providerConcernRoleID",
      provider.getID().toString());
    providerLinkBuilder.openAsModal();
    return providerLinkBuilder;
  }

  /**
   * Builds a content panel to hold details of the latest payment with the given
   * {@link Money} amount, and a {@link LocalisableString} with the details of
   * the date it was added. </br> E.g. 100.00 on 19/10/2010.
   *
   * @param money
   * The money to be included in the message
   * @param date
   * The date to be included in the message
   * @return The panel containing the latest payment information
   */
  protected ContentPanelBuilder getLatestPaymentPanel(final Money money,
    final Date date) {
    // build a panel to hold the field text
    ContentPanelBuilder moneyDatePanel = ContentPanelBuilder.createPanel(
      ContextPanelConst.kStyleLatestPaymentPanel);

    // add the amount
    moneyDatePanel.addMoneyItem(money.getValue());

    // add a space
    moneyDatePanel.addStringItem(CuramConst.gkSpace);

    // add the text
    LocalisableString localisableString = new LocalisableString(
      SERVICEANDREFERRALCONTEXTPANEL.INFO_LATEST_PAYMENT_ON_DATE);

    localisableString.arg(date);
    moneyDatePanel.addlocalisableStringItem(
      localisableString.toClientFormattedText());
    return moneyDatePanel;
  }

  /**
   * Retrieves the entered service role for a referral.
   *
   * @param referral
   * The referral to get the service referral role from
   * @return the service referral role
   */
  protected ReferralRole getServiceReferralRole(
    final curam.referral.impl.Referral referral) {

    List<ReferralRole> serviceOfferingReferralRoleList = referralRoleDAO.searchActiveByReferralAndRelatedType(
      referral, REFERRALRELATEDROLETYPEEntry.SERVICEOFFERING);

    if (serviceOfferingReferralRoleList.size() > CuramConst.gkZero) {
      return serviceOfferingReferralRoleList.get(0);
    }

    List<ReferralRole> unregisteredServiceReferralRoleList = referralRoleDAO.searchActiveByReferralAndRelatedType(
      referral, REFERRALRELATEDROLETYPEEntry.UNREGISTEREDSERVICEOFFERING);

    return unregisteredServiceReferralRoleList.get(0);
  }

  /**
   * Returns the {@link ServiceOffering} for the given {@link Referral}, if one
   * exists.
   *
   * @param referral
   * The referral to read
   * @return The service offering, or <code>null</code> if none exists
   */
  protected ServiceOffering getReferralService(final Referral referral) {
    for (ReferralRole referralRole : referral.getReferralRoles()) {
      if (referralRole.getRelatedObjectRoleType().equals(
        REFERRALRELATEDROLETYPEEntry.SERVICEOFFERING)) {
        return serviceOfferingDAO.get(referralRole.getRelatedObjectID());
      }
    }
    return null;
  }

  /**
   * Creates a {@link LinkBuilder} for the user details modal for the given
   * {@link User}.
   *
   * @param user
   * The user to link to
   * @return A link to the user details modal for the given user
   */
  protected LinkBuilder getUserLink(final User user) {
    LinkBuilder userLinkBuilder = LinkBuilder.createLink(user.getFullName(),
      "Organization_viewUserDetailsPage.do");

    userLinkBuilder.addParameter(CuramConst.gkPageParameterUserName,
      user.getUsername());
    userLinkBuilder.openAsModal();
    return userLinkBuilder;
  }

  /**
   * Build up the link to the given {@link CaseHeader}.
   *
   * @param caseHeader
   * The case to link to
   * @return The link XML
   */
  protected LinkBuilder getCaseLink(final CaseHeader caseHeader) {
    ClientURI clientURI = new ClientURI(
      ContextPanelConst.kStandardCaseResolvePage);

    clientURI.appendParam(ContextPanelConst.kPageParameterCaseID,
      caseHeader.getID().toString());
    LinkBuilder caseLinkBuilder = LinkBuilder.createLink(
      getCaseLinkText(caseHeader),
      clientURI.getPageName() + ContextPanelConst.kStrutsExt);
    Map<String, String> parameters = clientURI.getParameters();

    for (String key : parameters.keySet()) {
      caseLinkBuilder.addParameter(key, parameters.get(key));
    }
    return caseLinkBuilder;
  }

  /**
   * Returns the text to be used as the link to the given {@link CaseHeader}.
   * Tries to use {@link CaseHeader#getDescription()}, but uses the case
   * configuration name from administration if this throws an exception.
   *
   * @param caseHeader
   * The case to link to
   * @return The text to be used as the case link
   */
  private String getCaseLinkText(final CaseHeader caseHeader) {
    String caseLinkText;

    try {
      caseLinkText = caseHeader.getDescription();
    } catch (AppException e) {
      caseLinkText = caseHeader.getAdminCaseConfiguration().getCaseConfigurationName();
    } catch (InformationalException e) {
      caseLinkText = caseHeader.getAdminCaseConfiguration().getCaseConfigurationName();
    }
    return caseLinkText;
  }

  // BEGIN, CR00292762, GYH
  // BEGIN, CR00311734, SS
  /**
   * Gets the details of the latest payment made for the given service delivery
   * identifier.
   *
   * @param serviceDelivery
   * Contains service delivery identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0.3.0, replaced by
   * {@link ServiceDelivery#getLatestPayment()}. See release note:
   * CR00311734
   */
  @Deprecated
  // END, CR00311734
  protected FinancialInstructionCaseDetails1 getLatestPayment(
    final ServiceDelivery serviceDelivery) throws AppException,
      InformationalException {
    ListCaseFinancialsKey listCaseFinancialsKey = new ListCaseFinancialsKey();

    listCaseFinancialsKey.caseID = serviceDelivery.getDeliveryTypeRelatedID();
    List<ViewCaseInstructionDetails> viewCaseInstructionList = ProductDeliveryFactory.newInstance().listCaseFinancialInstruction(listCaseFinancialsKey).dtls.dtlsList;

    FinancialInstructionCaseDetails1 financialInstructionCaseDetails1 = null;

    if (!viewCaseInstructionList.isEmpty()) {
      sortFinancialInstructionDetails(viewCaseInstructionList);
      financialInstructionCaseDetails1 = viewCaseInstructionList.get(0).finInstructDtls;
    }
    return financialInstructionCaseDetails1;
  }

  // BEGIN, CR00311734, SS
  /**
   * Sorts the list of financial instruction details in descending order by
   * effective date.
   *
   * @param unsortedFinancialInstructions
   * unsorted list of financial instruction details.
   *
   * @deprecated Since Curam 6.0.3.0, replaced by
   * {@link ServiceDelivery#getLatestPayment()}. See
   * release note: CR00311734
   */
  @Deprecated
  // END, CR00311734
  protected void sortFinancialInstructionDetails(
    List<ViewCaseInstructionDetails> unsortedFinancialInstructions) {
    // Sort the corrections in the descending order by payment date
    Collections.sort(unsortedFinancialInstructions,
      new Comparator<ViewCaseInstructionDetails>() {
      public int compare(final ViewCaseInstructionDetails lhs,
        ViewCaseInstructionDetails rhs) {
        return rhs.finInstructDtls.effectiveDate.compareTo(
          lhs.finInstructDtls.effectiveDate);
      }
    });
  }

  // BEGIN, CR00311734, SS
  /**
   * Sorts the list of service delivery payments in descending order by payment
   * date.
   *
   * @param unsortedPaymentInformationDetails
   * unsorted list of service delivery payments.
   *
   * @deprecated Since Curam 6.0.3.0, replaced by
   * {@link ServiceDelivery#getLatestPayment()}. The method is no
   * longer referenced in the application, hence deprecated See
   * release note: CR00311734
   */
  @Deprecated
  // END, CR00311734
  protected void sortSDPayments(
    List<PaymentInformationDetails> unsortedPaymentInformationDetails) {
    // Sort the corrections in the descending order by payment date
    Collections.sort(unsortedPaymentInformationDetails,
      new Comparator<PaymentInformationDetails>() {
      public int compare(final PaymentInformationDetails lhs,
        PaymentInformationDetails rhs) {
        return rhs.paymentDate.compareTo(lhs.paymentDate);
      }
    });
  }

  // END, CR00292762

}
