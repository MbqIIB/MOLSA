/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd..
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.Collections;
import java.util.Comparator;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.STAFFACTIONTYPEEntry;
import curam.core.facade.fact.IncidentsFactory;
import curam.core.facade.intf.Incidents;
import curam.core.facade.struct.IncidentParticipantDetails;
import curam.core.facade.struct.IncidentParticipantDetailsList;
import curam.core.fact.ConcernRoleFactory;
import curam.core.intf.ConcernRole;
import curam.core.struct.ConcernRoleKey;
import curam.cpm.facade.struct.IncidentStaffActionDetails;
import curam.cpm.facade.struct.IncidentStaffActionDetailsList;
import curam.cpm.facade.struct.IncidentStaffActionKey;
import curam.cpm.facade.struct.IncidentStaffActionKeyVersionDtls;
import curam.cpm.facade.struct.StaffParticipantDetails;
import curam.cpm.facade.struct.StaffParticipantDetailsList;
import curam.cpm.facade.struct.StaffParticipantKey;
import curam.incident.entity.struct.IncidentKey;
import curam.incident.impl.Incident;
import curam.incident.impl.IncidentDAO;
import curam.incident.impl.IncidentParticipant;
import curam.incident.impl.IncidentParticipantDAO;
import curam.provider.impl.IncidentStaffAction;
import curam.provider.impl.IncidentStaffActionDAO;
import curam.provider.impl.ProviderMember;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * {@inheritDoc}
 */
public abstract class MaintainIncidentStaffAction extends curam.cpm.facade.base.MaintainIncidentStaffAction {

  /**
   * Reference to incident DAO.
   */
  @Inject
  protected IncidentDAO incidentDAO;

  /**
   * Reference to provider incident staff action DAO.
   */
  @Inject
  protected IncidentStaffActionDAO incidentStaffActionDAO;

  /**
   * Reference to incident participant DAO.
   */
  @Inject
  protected IncidentParticipantDAO incidentParticipantDAO;

  /**
   * Reference to ProviderOrganizationDAO.
   */
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Constructor for the class.
   */
  public MaintainIncidentStaffAction() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public IncidentStaffActionKey createIncidentStaffAction(
    IncidentStaffActionDetails details) throws AppException,
      InformationalException {

    IncidentStaffActionKey incidentStaffActionKey = new IncidentStaffActionKey();
    IncidentStaffAction incidentStaffActionObj = incidentStaffActionDAO.newInstance();
    Incident incidentObj = incidentDAO.get(details.dtls.incidentID);

    incidentStaffActionObj.setIncident(incidentObj);
    incidentStaffActionObj.setStaffParticipantRoleID(
      details.dtls.staffParticipantRoleID);
    incidentStaffActionObj.setStaffActionDescription(details.dtls.description);
    incidentStaffActionObj.setStaffActionType(
      STAFFACTIONTYPEEntry.get(details.dtls.typeCode));

    incidentStaffActionObj.insert();

    incidentStaffActionKey.incidentStaffActionID = incidentStaffActionObj.getID();

    return incidentStaffActionKey;
  }

  /**
   * {@inheritDoc}
   */
  public void deleteIncidentStaffAction(
    IncidentStaffActionKeyVersionDtls KeyVersionDtls)
    throws AppException, InformationalException {

    IncidentStaffAction incidentStaffActionObj = incidentStaffActionDAO.get(
      KeyVersionDtls.incidentStaffActionID);

    incidentStaffActionObj.cancel(KeyVersionDtls.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public IncidentStaffActionDetailsList listIncidentStaffAction(
    IncidentStaffActionKey key) throws AppException,
      InformationalException {

    IncidentStaffActionDetailsList incidentStaffActionDetailsList = new IncidentStaffActionDetailsList();

    Incident incidentObj = incidentDAO.get(key.incidentID);

    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    Set<IncidentStaffAction> incidentStaffActions = incidentStaffActionDAO.searchByIncident(
      incidentObj);

    for (IncidentStaffAction incidentStaffActionObj : incidentStaffActions) {

      IncidentStaffActionDetails incidentStaffActionDetails = new IncidentStaffActionDetails();

      incidentStaffActionDetails.dtls.incidentID = key.incidentID;
      incidentStaffActionDetails.dtls.incidentStaffActionID = incidentStaffActionObj.getID();
      incidentStaffActionDetails.dtls.staffParticipantRoleID = incidentStaffActionObj.getStaffParticipantRoleID();
      incidentStaffActionDetails.dtls.description = incidentStaffActionObj.getStaffActionDescription();
      incidentStaffActionDetails.dtls.typeCode = incidentStaffActionObj.getStaffActionType().getCode();
      incidentStaffActionDetails.dtls.recordStatus = incidentStaffActionObj.getStatus().getCode();
      incidentStaffActionDetails.dtls.versionNo = incidentStaffActionObj.getVersionNo();

      if (RECORDSTATUSEntry.CANCELLED.getCode().equals(
        incidentStaffActionDetails.dtls.recordStatus)) {
        incidentStaffActionDetails.statusInd = true;
      }
      
      Long staffParticipantRoleId = incidentStaffActionObj.getStaffParticipantRoleID();

      if (0 != staffParticipantRoleId) {
        IncidentParticipant incidentStaffParticipantObj = incidentParticipantDAO.get(
          staffParticipantRoleId);

        if (0 != incidentStaffParticipantObj.getConcernRoleID()) {
          concernRoleKey.concernRoleID = incidentStaffParticipantObj.getConcernRoleID();
          incidentStaffActionDetails.staffParticipantName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
        } 
      }
      incidentStaffActionDetailsList.dtls.addRef(incidentStaffActionDetails);
    }

    return incidentStaffActionDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public void modifyIncidentStaffAction(IncidentStaffActionDetails details)
    throws AppException, InformationalException {

    IncidentStaffAction incidentStaffActionObj = incidentStaffActionDAO.get(
      details.dtls.incidentStaffActionID);
    Incident incidentObj = incidentDAO.get(details.dtls.incidentID);

    incidentStaffActionObj.setIncident(incidentObj);
    incidentStaffActionObj.setStaffParticipantRoleID(
      details.dtls.staffParticipantRoleID);
    incidentStaffActionObj.setStaffActionDescription(details.dtls.description);
    incidentStaffActionObj.setStaffActionType(
      STAFFACTIONTYPEEntry.get(details.dtls.typeCode));

    incidentStaffActionObj.modify(details.dtls.versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public IncidentStaffActionDetails viewIncidentStaffAction(
    IncidentStaffActionKey key) throws AppException,
      InformationalException {

    IncidentStaffActionDetails incidentStaffActionDetails = new IncidentStaffActionDetails();

    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    IncidentStaffAction incidentStaffActionObj = incidentStaffActionDAO.get(
      key.incidentStaffActionID);

    incidentStaffActionDetails.dtls.incidentID = key.incidentID;
    incidentStaffActionDetails.dtls.incidentStaffActionID = key.incidentStaffActionID;

    incidentStaffActionDetails.dtls.staffParticipantRoleID = incidentStaffActionObj.getStaffParticipantRoleID();
    incidentStaffActionDetails.dtls.description = incidentStaffActionObj.getStaffActionDescription();
    incidentStaffActionDetails.dtls.typeCode = incidentStaffActionObj.getStaffActionType().getCode();
    incidentStaffActionDetails.dtls.recordStatus = incidentStaffActionObj.getStatus().getCode();
    incidentStaffActionDetails.dtls.versionNo = incidentStaffActionObj.getVersionNo();
    
    Long staffParticipantRoleId = incidentStaffActionObj.getStaffParticipantRoleID();
    
    if (0 != staffParticipantRoleId) {
      IncidentParticipant incidentStaffParticipantObj = incidentParticipantDAO.get(
        incidentStaffActionObj.getStaffParticipantRoleID());

      if (0 != incidentStaffParticipantObj.getConcernRoleID()) {
        concernRoleKey.concernRoleID = incidentStaffParticipantObj.getConcernRoleID();
        incidentStaffActionDetails.staffParticipantName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
      }
    }
    
    return incidentStaffActionDetails;
  }

  /**
   * {@inheritDoc}
   */
  public StaffParticipantDetailsList listStaffParticipant(
    StaffParticipantKey key) throws AppException,
      InformationalException {

    StaffParticipantDetailsList staffParticipantDetailsList = new StaffParticipantDetailsList();

    IncidentParticipantDetailsList incidentParticipantDetailsList = new IncidentParticipantDetailsList();

    IncidentKey incidentKey = new IncidentKey();

    incidentKey.incidentID = key.incidentID;

    Incidents incidentsObj = IncidentsFactory.newInstance();

    incidentParticipantDetailsList = incidentsObj.listIncidentActiveParticipantRole(
      incidentKey);

    // Get list of provider members
    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      key.providerConcernRoleID);

    for (ProviderMember providerMember : providerOrganization.getProviderMembers()) {

      if (providerMember.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)
        && (!providerMember.getDateRange().isEnded()
          || !providerMember.getDateRange().endsInPast())) {

        StaffParticipantDetails staffParticipantDetails = new StaffParticipantDetails();

        staffParticipantDetails.participantConcernRoleID = providerMember.getParty().getID();
        staffParticipantDetails.participantName = providerMember.getParty().getName();

        // Add only those provider member which are not participants
        boolean memberExitsAsParticinantInd = false;

        for (IncidentParticipantDetails incidentParticipantDetails : incidentParticipantDetailsList.dtlsList) {

          if (0 != incidentParticipantDetails.concernRoleID
            && incidentParticipantDetails.concernRoleID
              == providerMember.getParty().getID()) {

            staffParticipantDetails.participantRoleID = incidentParticipantDetails.incidentParticipantRoleID;
            memberExitsAsParticinantInd = true;
            break;
          }
        }

        if (memberExitsAsParticinantInd) {

          staffParticipantDetailsList.list.addRef(staffParticipantDetails);
        }
      }
    }
    // Sort the incident staff participant roles by participant name
    Collections.sort(staffParticipantDetailsList.list,
      new Comparator<StaffParticipantDetails>() {

      public int compare(StaffParticipantDetails lhs,
        StaffParticipantDetails rhs) {

        return lhs.participantName.compareToIgnoreCase(rhs.participantName);
      }
    });

    return staffParticipantDetailsList;
  }

}
