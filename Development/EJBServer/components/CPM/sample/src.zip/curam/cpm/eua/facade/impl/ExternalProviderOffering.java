/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008,2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.core.struct.ConcernRoleKey;
import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.eua.facade.struct.ProviderOfferingDetailsList;
import curam.cpm.facade.fact.ProviderFactory;
import curam.cpm.facade.fact.ProviderOfferingFactory;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetails;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetailsList;
import curam.cpm.facade.struct.ProviderOfferingSummaryVersionDetails;
import curam.cpm.facade.struct.ProviderOfferingSummaryVersionDetailsList;
import curam.cpm.facade.struct.ViewProviderOfferingDetails;
import curam.cpm.sl.entity.struct.ProviderConcernRoleKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ProviderOfferingKey;
import curam.provider.impl.ProviderDAO;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This class contains methods to retrieve information on services
 * offered by a provider through the external Application
 */
public abstract class ExternalProviderOffering extends curam.cpm.eua.facade.base.ExternalProviderOffering {

  // Variables instantiated by guice
  @Inject
  ProviderOfferingDAO providerOfferingDAO;

  @Inject
  ProviderDAO providerDAO;

  /**
   * Constructor
   */
  public ExternalProviderOffering() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * List all services offered for the provider
   *
   * @param concernRoleKey - contains the concernRoleID for the provider
   * @return This contains a list of provider offerings
   *
   * @throws InformationalException
   *
   * @throws AppException
   */
  public ProviderOfferingDetailsList listServiceOfferingsForProvider(
    ConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {

    ProviderOfferingDetailsList providerOfferingDetailsList = new ProviderOfferingDetailsList();

    ProviderKey providerKey = new ProviderKey();

    providerKey.providerConcernRoleID = concernRoleKey.concernRoleID;

    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    // call security
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    // call facade method
    curam.cpm.facade.intf.ProviderOffering providerOfferingFacade = ProviderOfferingFactory.newInstance();

    providerOfferingDetailsList.providerOfferingDetailsList = filterList(
      providerOfferingFacade.listServiceOfferingsByProvider(providerKey));

    // get the context description
    curam.cpm.facade.intf.Provider providerObj = ProviderFactory.newInstance();
    ProviderConcernRoleKey providerConcernRoleKey = new ProviderConcernRoleKey();

    // set the key
    providerConcernRoleKey.providerConcernRoleID = providerKey.providerConcernRoleID;

    providerOfferingDetailsList.contextDescription = providerObj.readProviderSummaryDetails(
      providerConcernRoleKey);

    return providerOfferingDetailsList;
  }

  /**
   * This method filters the provider offering list removing all canceled
   * records from the list
   *
   * @param unfilteredList - this contains a list of provider offerings
   * @return This contains a list of all provider offerings except canceled
   */
  // BEGIN, CR00177241, PM
  protected ProviderOfferingSummaryDetailsList filterList(ProviderOfferingSummaryDetailsList unfilteredList) {
    // END, CR00177241

    ProviderOfferingSummaryDetailsList result = new ProviderOfferingSummaryDetailsList();

    for (int i = 0; i < unfilteredList.providerOfferingSummaryDetails.size(); i++) {

      if (!unfilteredList.providerOfferingSummaryDetails.item(i).recordStatus.equals(
        ProviderOfferingStatusEntry.CANCELED.getCode())) {
        result.providerOfferingSummaryDetails.addRef(
          unfilteredList.providerOfferingSummaryDetails.item(i));
      }
    }

    return result;
  }

  /**
   * This method retrieves all details for the provider offering,
   * including the associated provider offering rates and provider
   * offering place limits.
   *
   * @param key - contains the provider offering ID
   * @return This contains the details for the provider offering
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ViewProviderOfferingDetails viewServiceOfferingForProvider(
    ProviderOfferingKey key) throws AppException, InformationalException {

    // call facade method
    curam.cpm.facade.intf.ProviderOffering providerOfferingFacade = ProviderOfferingFactory.newInstance();

    ViewProviderOfferingDetails details = providerOfferingFacade.viewProviderOffering(
      key);

    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey.concernRoleID = details.providerOfferingDtls.providerConcernRoleID;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    // call security
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    return details;
  }

  /**
   * Lists all the approved provider offerings for a given provider.
   *
   * @param key
   * The Key for the Provider for whom the provider offerings are to be
   * retrieved.
   * @return ProviderOfferingSummaryDetailsList The Provider offerings list for
   * a given provider.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderOfferingSummaryDetailsList listApprovedServiceOfferingsByProvider(
    ProviderKey key) throws AppException, InformationalException {

    ProviderOfferingSummaryDetailsList providerOfferingSummaryDetailsList = new ProviderOfferingSummaryDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      key.providerConcernRoleID);

    Set<ProviderOffering> unModifiableProviderOfferings = provider.getProviderOfferings();
    Set<ProviderOffering> providerOfferings = new HashSet<ProviderOffering>();

    providerOfferings.addAll(unModifiableProviderOfferings);

    for (final curam.providerservice.impl.ProviderOffering providerOffering : sortProviderOfferings(
      providerOfferings)) {

      if (ProviderOfferingStatusEntry.APPROVED.equals(
        providerOffering.getLifecycleState())) {
        providerOfferingSummaryDetailsList.providerOfferingSummaryDetails.addRef(
          getProviderOfferingSummaryDetails(providerOffering));
      }
    }

    return providerOfferingSummaryDetailsList;
  }

  // BEGIN, CR00228142, GP
  /**
   * Lists all the active provider offerings for the logged in provider.
   *
   * @param concernRoleKey
   *
   * @return All the active provider offerings for the logged in provider.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderOfferingSummaryVersionDetailsList listProviderOfferings(
    ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    ProviderKey providerKey = new ProviderKey();

    providerKey.providerConcernRoleID = concernRoleKey.concernRoleID;

    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    // call facade method
    curam.cpm.facade.intf.ProviderOffering providerOfferingFacade = ProviderOfferingFactory.newInstance();

    ProviderOfferingSummaryVersionDetailsList providerOfferingSummaryVersionDetailsList = getActiveProviderOfferings(
      providerOfferingFacade.listProviderOfferings(providerKey));

    return providerOfferingSummaryVersionDetailsList;
  }

  // END, CR00228142

  /**
   * Sorts a set of provider offerings into a sorted list for display.
   *
   * @param unsortedProviderOfferings
   * the set of provider offerings
   * @return a sorted list of provider offerings for display.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.providerservice.impl.ProviderOffering> sortProviderOfferings(
    final Set<curam.providerservice.impl.ProviderOffering> unsortedProviderOfferings) {
    // END, CR00177241
    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    final List<curam.providerservice.impl.ProviderOffering> providerOfferings = new ArrayList<curam.providerservice.impl.ProviderOffering>(
      unsortedProviderOfferings);

    Collections.sort(providerOfferings,
      new Comparator<curam.providerservice.impl.ProviderOffering>() {
      public int compare(
        final curam.providerservice.impl.ProviderOffering lhs,
        curam.providerservice.impl.ProviderOffering rhs) {
        return lhs.getServiceOffering().getName().compareTo(
          rhs.getServiceOffering().getName());
      }
    });
    return providerOfferings;
  }

  /**
   * Gets the provider offering summary details from provider offering.
   *
   * @param providerOffering
   * Contains the provider offering details.
   * @return ProviderOfferingSummaryDetails The Provider offerings summary
   * details.
   */
  protected ProviderOfferingSummaryDetails getProviderOfferingSummaryDetails(
    curam.providerservice.impl.ProviderOffering providerOffering) {

    ProviderOfferingSummaryDetails providerOfferingSummaryDetails = new ProviderOfferingSummaryDetails();
    ServiceOffering serviceOffering = providerOffering.getServiceOffering();

    providerOfferingSummaryDetails.serviceOfferingID = serviceOffering.getID();
    providerOfferingSummaryDetails.providerOfferingID = providerOffering.getID();

    providerOfferingSummaryDetails.startDate = providerOffering.getDateRange().start();
    providerOfferingSummaryDetails.endDate = providerOffering.getDateRange().end();
    providerOfferingSummaryDetails.name = serviceOffering.getName();
    providerOfferingSummaryDetails.recordStatus = providerOffering.getLifecycleState().getCode();

    return providerOfferingSummaryDetails;
  }

  // BEGIN, CR00228142, GP
  /**
   * Returns all the active provider offerings.
   *
   * @param providerOfferingSummaryVersionDetailsList
   * A list of provider offerings for the logged in provider.
   *
   * @return Active provider offerings for the logged in provider.
   */
  protected ProviderOfferingSummaryVersionDetailsList getActiveProviderOfferings(
    ProviderOfferingSummaryVersionDetailsList providerOfferingSummaryVersionDetailsList) {

    ProviderOfferingSummaryVersionDetailsList activeProviderOfferingSummaryVersionDetailsList = new ProviderOfferingSummaryVersionDetailsList();

    for (final ProviderOfferingSummaryVersionDetails providerOfferingSummaryVersionDetails :
      providerOfferingSummaryVersionDetailsList.detailsList.items()) {

      if (!ProviderOfferingStatusEntry.CANCELED.getCode().equals(
        providerOfferingSummaryVersionDetails.versionDetails.recordStatus)) {
        activeProviderOfferingSummaryVersionDetailsList.detailsList.addRef(
          providerOfferingSummaryVersionDetails);
      }

    }

    return activeProviderOfferingSummaryVersionDetailsList;
  }
  // END, CR00228142
}
