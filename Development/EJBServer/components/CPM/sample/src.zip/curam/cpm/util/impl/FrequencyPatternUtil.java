/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.util.impl;


import java.util.List;

import com.google.inject.ImplementedBy;

import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.FrequencyPattern;


/**
 * Provides API's to find frequency pattern occurrences and derive the anchor
 * date based on frequency pattern.
 */
@ImplementedBy(FrequencyPatternUtilImpl.class)
public interface FrequencyPatternUtil {

  /**
   * Derives the anchor date from reference date using frequency pattern.
   * Derived anchor date shall be on or after reference date.
   *
   * @param referenceDate
   * Reference date from which anchor date is derived.
   * @param frequencyPattern
   * Frequency pattern for deriving anchor date.
   *
   * @return The derived anchor date.
   */
  public Date getAnchorDateAfterReferenceDate(final Date referenceDate,
    final FrequencyPattern frequencyPattern);
	  
  /**
   * Derives the anchor date from reference date using frequency pattern.
   * Derived anchor date shall be on or before reference date.
   *
   * @param referenceDate
   * Reference date from which anchor date is derived.
   * @param frequencyPattern
   * Frequency pattern for deriving anchor date.
   *
   * @return The derived anchor date.
   */
  public Date getAnchorDateBeforeReferenceDate(final Date referenceDate,
    final FrequencyPattern frequencyPattern);
	  
  /**
   * Obtains the frequency occurrences.Occurrences starting from anchor date.
   *
   * @param frequencyPattern
   * Frequency pattern used to find occurrences.
   * @param endDate
   * End date of occurrences.
   * @param anchorDate
   * Anchor date used to find all occurrences consistently.
   *
   * @return All the frequency occurrences within the date range.
   */
  public List<Date> getFrequencyOccurrencesStartingFromAnchorDate(
    final FrequencyPattern frequencyPattern, final Date endDate,
    final Date anchorDate);
	  
  /**
   * Obtains the frequency occurrences with respect to anchor date within
   * specified period.
   *
   * @param frequencyPattern
   * Frequency pattern used to find occurrences.
   * @param period
   * Period within which the occurrences should be considered.
   * @param anchorDate
   * Anchor date used to find all occurrences consistently.
   *
   * @return All the frequency occurrences within the specified period.
   */
  public List<Date> getFrequencyOccurrencesWithinPeriod(
    final FrequencyPattern frequencyPattern, final DateRange period,
    final Date anchorDate);

}
