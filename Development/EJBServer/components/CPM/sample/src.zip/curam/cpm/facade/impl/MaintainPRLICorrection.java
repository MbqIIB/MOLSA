/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import com.google.inject.Inject;

import curam.attendance.impl.AbsencePeriod;
import curam.attendance.impl.AbsencePeriodCorrection;
import curam.attendance.impl.AbsencePeriodCorrectionDAO;
import curam.attendance.impl.AbsencePeriodDAO;
import curam.attendance.impl.AttendanceConfigurationHelper;
import curam.attendance.impl.DailyAttendance;
import curam.attendance.impl.DailyAttendanceCorrection;
import curam.attendance.impl.DailyAttendanceCorrectionDAO;
import curam.attendance.impl.DailyAttendanceDAO;
import curam.attendance.impl.PRLIClient;
import curam.attendance.impl.PRLIClientDAO;
import curam.attendance.impl.PRLICorrection;
import curam.attendance.impl.PRLICorrectionClient;
import curam.attendance.impl.PRLICorrectionClientDAO;
import curam.attendance.impl.PRLICorrectionDAO;
import curam.attendance.impl.PRLICorrectionHistory;
import curam.attendance.impl.PRLICorrectionHistoryDAO;
import curam.attendance.impl.PRLISALILink;
import curam.attendance.impl.PRLISALILinkDAO;
import curam.attendance.impl.ProviderRosterLineItem;
import curam.attendance.impl.ProviderRosterLineItemDAO;
import curam.attendance.impl.SOAttendanceConfiguration;
import curam.attendance.impl.SOAttendanceConfigurationDAO;
import curam.codetable.impl.ATTENDANCEABSENCEREASONEntry;
import curam.codetable.impl.ATTENDANCEEntry;
import curam.codetable.impl.ATTENDANCETRACKINGHOURSEntry;
import curam.codetable.impl.ATTENDANCETRACKINGMINUTESEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.fact.AddressFactory;
import curam.core.intf.Address;
import curam.core.sl.entity.struct.RosterKey;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.cpm.facade.struct.AbsenceCorrectionDetails;
import curam.cpm.facade.struct.AbsenceCorrectionDetailsList;
import curam.cpm.facade.struct.CorrectionDetails;
import curam.cpm.facade.struct.DailyAttendanceDetails;
import curam.cpm.facade.struct.DailyAttendanceDetailsList;
import curam.cpm.facade.struct.PRLIAttendanceCorrectionDetails;
import curam.cpm.facade.struct.PRLICorrectionDetails;
import curam.cpm.facade.struct.PRLICorrectionHistoryList;
import curam.cpm.facade.struct.PRLICorrectionSummaryDetails;
import curam.cpm.facade.struct.PRLICorrectionSummaryDetailsList;
import curam.cpm.facade.struct.ReportingDailyAttendanceDetails;
import curam.cpm.facade.struct.VersionNo;
import curam.cpm.facade.struct.ViewDailyAttendanceDetails;
import curam.cpm.facade.struct.ViewDailyAttendanceReportingDetails;
import curam.cpm.facade.struct.ViewReportingDailyAttendanceDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.AbsencePeriodCorrectionDtls;
import curam.cpm.sl.entity.struct.AbsencePeriodCorrectionKey;
import curam.cpm.sl.entity.struct.DailyAttendanceCorrectionDtls;
import curam.cpm.sl.entity.struct.PRLICorrectionDtls;
import curam.cpm.sl.entity.struct.PRLICorrectionHistoryDtls;
import curam.cpm.sl.entity.struct.PRLICorrectionKey;
import curam.cpm.sl.entity.struct.ProviderRosterLineItemKey;
import curam.cpm.util.impl.AttendanceWidgetHelper;
import curam.cpm.util.impl.WidgetHelper;
import curam.message.DAILYATTENDANCECORRECTION;
import curam.message.ROSTER;
import curam.message.impl.DAILYATTENDANCECORRECTIONExceptionCreator;
import curam.message.impl.PRLICORRECTIONExceptionCreator;
import curam.message.impl.ROSTERExceptionCreator;
import curam.provider.PRLIStatus;
import curam.provider.impl.PRLIStatusEntry;
import curam.serviceauthorization.impl.ServiceAuthorization;
import curam.servicedelivery.impl.ServiceDelivery;
import curam.servicedelivery.impl.ServiceDeliveryDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.UnitOfMeasureEntry;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.StringHelper;


/**
 * {@inheritDoc}
 */
public abstract class MaintainPRLICorrection extends curam.cpm.facade.base.MaintainPRLICorrection {

  /**
   * Provider Roster Line Item Correction DAO
   */
  @Inject
  protected PRLICorrectionDAO prliCorrectionDAO;

  /**
   * Provider Roster Line Item DAO
   */
  @Inject
  protected ProviderRosterLineItemDAO providerRosterLineItemDAO;

  /**
   * Daily Attendance Correction DAO
   */
  @Inject
  protected DailyAttendanceCorrectionDAO dailyAttendanceCorrectionDAO;

  /**
   * Provider Roster Line Item Correction DAO
   */
  @Inject
  protected PRLICorrectionHistoryDAO prliCorrectionHistoryDAO;

  /**
   * Service Offering Attendance Configuration DAO
   */
  @Inject
  protected SOAttendanceConfigurationDAO soAttendanceConfigurationDAO;

  /**
   * Absence Period Correction DAO
   */
  @Inject
  protected AbsencePeriodCorrectionDAO absencePeriodCorrectionDAO;

  /**
   * DailyAttendance DAO object.
   */
  @Inject
  protected DailyAttendanceDAO dailyAttendanceDAO;

  /**
   * Absence Period DAO reference.
   */
  @Inject
  protected AbsencePeriodDAO absencePeriodDAO;

  /**
   * Reference to class DailyAttendance.
   */
  @Inject
  protected DailyAttendance dailyAttendance;

  /**
   * Reference to class AbsencePeriod.
   */
  @Inject
  protected AbsencePeriod absencePeriod;

  // BEGIN, CR00168585, KG
  /**
   * Reference to PRLI client DAO.
   */
  @Inject
  protected PRLIClientDAO prliClientDao;
  
  /**
   * Reference to PRLI correction client DAO.
   */
  @Inject
  protected PRLICorrectionClientDAO prliCorrectionClientDao;
  // END, CR00168585

  // BEGIN, CR00176474, AS
  // BEGIN, CR00178377, AS
  /**
   * Reference to Attendance Configuration Helper.
   */
  @Inject
  protected AttendanceConfigurationHelper attendanceConfigurationHelper;

  // END, CR00178377
  // END, CR00176474

  // BEGIN, CR00208241, ASN
  /**
   * Reference to PRLISALILinkDAO.
   */
  @Inject
  protected PRLISALILinkDAO prliSALILinkDAO;
  // END, CR00208241
  
  @Inject
  protected ServiceDeliveryDAO serviceDeliveryDAO;
  
  /**
   * Bootstrap dependency injection for this class
   */
  public MaintainPRLICorrection() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public PRLICorrectionKey createPRLICorrection(
    final PRLICorrectionDetails prliCorrectionDetails) throws AppException,
      InformationalException {

    final PRLICorrectionKey prliCorrectionKey = new PRLICorrectionKey();
    final PRLICorrection prliCorrection = prliCorrectionDAO.newInstance();

    setPRLICorrection(prliCorrection, prliCorrectionDetails, true);
    prliCorrection.insert();
    prliCorrectionKey.prliCorrectionID = prliCorrection.getID();
    // BEGIN, CR00168585, KG
    // create PRLI correction clients in case multiple clients attached to PRLI
    // correction.
    Set<PRLIClient> prliClients = prliClientDao.listClientsForPRLI(
      prliCorrection.getProviderRosterLineItem());

    for (PRLIClient prliClient : prliClients) {
      PRLICorrectionClient prliCorrectionClient = prliCorrectionClientDao.newInstance();

      prliCorrectionClient.setClientAddressID(prliClient.getAddressID());
      prliCorrectionClient.setClientFirstName(prliClient.getClientFirstName());
      prliCorrectionClient.setClientLastName(prliClient.getClientLastName());
      prliCorrectionClient.setClientDOB(prliClient.getClientDOB());
      prliCorrectionClient.setClientReferenceNo(
        prliClient.getClientReferenceNo());
      prliCorrectionClient.setPRLICorrection(prliCorrection);
      prliCorrectionClient.insert();
    }
    // END, CR00168585

    // Based on the configuration create daily attendance correction or
    // absence period correction
    SOAttendanceConfiguration soAttendanceConfiguration = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      prliCorrection.getProviderRosterLineItem().getRoster().getServiceOffering(),
      Date.getCurrentDate());

    if (soAttendanceConfiguration != null
      && soAttendanceConfiguration.isDailyAttendanceTrackingRequired()) {
      createDailyAttendanceCorrection(prliCorrection);
    } else {
      createAbsenceDetailsCorrection(prliCorrection);
    }

    return prliCorrectionKey;
  }

  /**
   * {@inheritDoc}
   */
  public void deletePRLICorrection(PRLICorrectionKey correctionKey,
    VersionNo versionNo) throws AppException, InformationalException {

    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      correctionKey.prliCorrectionID);

    prliCorrection.cancel(versionNo.versionNo);
 
  }

  /**
   * {@inheritDoc}
   */
  public PRLICorrectionSummaryDetailsList listPRLICorrectionDetails(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {

    final PRLICorrectionSummaryDetailsList prliCorrectionSummaryDetailsList = new PRLICorrectionSummaryDetailsList();

    // Loop through the prliCorrection entity and assign the values to
    // prliCorrectionSummaryDetails for display
    for (PRLICorrection prliCorrection : prliCorrectionDAO.searchByPRLI(
      providerRosterLineItemKey.providerRosterLineItemID)) {

      final PRLICorrectionSummaryDetails prliCorrectionSummaryDetails = new PRLICorrectionSummaryDetails();

      prliCorrectionSummaryDetails.correctionDetails.prliCorrectionID = prliCorrection.getID();

      prliCorrectionSummaryDetails.clientName = prliCorrection.getClientFirstName()
        + GeneralConstants.kSpace + prliCorrection.getClientLastName();

      prliCorrectionSummaryDetails.correctionDetails.serviceFromDate = prliCorrection.getServiceDateRange().start();
      prliCorrectionSummaryDetails.correctionDetails.serviceToDate = prliCorrection.getServiceDateRange().end();
      // BEGIN, CR00176474, AS
      // BEGIN, CR00178377, AS
      if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
        || attendanceConfigurationHelper.isReportingMethodUtilization(
          prliCorrection.getProviderRosterLineItem().getRoster())) {
        // END, CR00178377
        prliCorrectionSummaryDetails.correctionDetails.totalUnitsDelivered = prliCorrection.getTotalUnitsDeliverd();
        prliCorrectionSummaryDetails.expectedUnits = prliCorrection.getProviderRosterLineItem().getExpectedUnits();
      }
      // END, CR00176474
      prliCorrectionSummaryDetails.correctionDetails.status = prliCorrection.getLifecycleState().getCode();

      SOAttendanceConfiguration soAttendanceConfiguration = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
        prliCorrection.getProviderRosterLineItem().getRoster().getServiceOffering(),
        Date.getCurrentDate());

      if (soAttendanceConfiguration != null) {
        prliCorrectionSummaryDetails.isDailyAttendanceTrackingRequired = soAttendanceConfiguration.isDailyAttendanceTrackingRequired();
      }

      prliCorrectionSummaryDetailsList.detailsList.addRef(
        prliCorrectionSummaryDetails);

    }

    return sortPRLICorrections(prliCorrectionSummaryDetailsList);
  }

  /**
   * This method is used to sort the provider roster line item correction
   * records based on service from date with latest first.
   *
   * @param unsortedPRLICorrectionSummaryDetails
   * Unsorted provider roster line item correction records.
   *
   * @return Sorted provider roster line item correction records.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  // BEGIN, CR00177241, PM
  protected PRLICorrectionSummaryDetailsList sortPRLICorrections(
    final PRLICorrectionSummaryDetailsList unsortedPRLICorrectionSummaryDetails) {
    // Sort by Service From Date for display.
    final List<PRLICorrectionSummaryDetails> prliCorrectionSummaryDetailsList = new ArrayList<PRLICorrectionSummaryDetails>();

    for (final PRLICorrectionSummaryDetails details : unsortedPRLICorrectionSummaryDetails.detailsList.items()) {
      prliCorrectionSummaryDetailsList.add(details);
    }

    Collections.sort(prliCorrectionSummaryDetailsList,
      new Comparator<PRLICorrectionSummaryDetails>() {
      public int compare(final PRLICorrectionSummaryDetails lhs,
        final PRLICorrectionSummaryDetails rhs) {
        return lhs.correctionDetails.serviceFromDate.compareTo(
          rhs.correctionDetails.serviceToDate);
      }
    });

    final PRLICorrectionSummaryDetailsList prliCorrectionSummaryDetailsListSorted = new PRLICorrectionSummaryDetailsList();

    prliCorrectionSummaryDetailsListSorted.detailsList.addAll(
      prliCorrectionSummaryDetailsList);

    return prliCorrectionSummaryDetailsListSorted;
  }

  /**
   * {@inheritDoc}
   */
  public PRLICorrectionHistoryList listPRLICorrectionHistory(
    PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    final PRLICorrectionHistoryList prliCorrectionHistoryList = new PRLICorrectionHistoryList();

    // Loop through the prliCorrectionHistory entity and assign the values to
    // prliCorrectionHistoryDtls for display
    for (PRLICorrectionHistory prliCorrectionHistory : prliCorrectionHistoryDAO.getHistoryForPRLICorrection(
      prliCorrectionKey.prliCorrectionID)) {

      final PRLICorrectionHistoryDtls prliCorrectionHistoryDtls = new PRLICorrectionHistoryDtls();

      prliCorrectionHistoryDtls.dateTime = prliCorrectionHistory.getDateTime();
      prliCorrectionHistoryDtls.prliCorrectionHistoryID = prliCorrectionHistory.getID();
      prliCorrectionHistoryDtls.prliCorrectionID = prliCorrectionHistory.getPRLICorrection().getID();
      prliCorrectionHistoryDtls.status = prliCorrectionHistory.getPRLICorrectionStatus().getCode();
      prliCorrectionHistoryDtls.userName = prliCorrectionHistory.getUserName();

      prliCorrectionHistoryList.correctionHistory.addRef(
        prliCorrectionHistoryDtls);
    }

    return sortPRLICorrectionHistory(prliCorrectionHistoryList);
  }

  /**
   * This method is used to sort the provider roster line item correction
   * history records based on date and time with latest first.
   *
   * @param unsortedPRLICorrectionHistory
   * Unsorted provider roster line item correction history records.
   *
   * @return Sorted provider roster line item correction history records.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  // BEGIN, CR00177241, PM
  protected PRLICorrectionHistoryList sortPRLICorrectionHistory(
    // END, CR00177241
    final PRLICorrectionHistoryList unsortedPRLICorrectionHistory) {

    // Sort by Date and Time for display.
    final List<PRLICorrectionHistoryDtls> prliCorrectionHistoryList = new ArrayList<PRLICorrectionHistoryDtls>();

    for (final PRLICorrectionHistoryDtls details : unsortedPRLICorrectionHistory.correctionHistory.items()) {
      prliCorrectionHistoryList.add(details);
    }

    Collections.sort(prliCorrectionHistoryList,
      new Comparator<PRLICorrectionHistoryDtls>() {
      public int compare(final PRLICorrectionHistoryDtls lhs,
        final PRLICorrectionHistoryDtls rhs) {
        return lhs.dateTime.compareTo(rhs.dateTime);
      }
    });

    final PRLICorrectionHistoryList prliCorrectionHistoryListSorted = new PRLICorrectionHistoryList();

    prliCorrectionHistoryListSorted.correctionHistory.addAll(
      prliCorrectionHistoryList);

    return prliCorrectionHistoryListSorted;
  }

  /**
   * {@inheritDoc}
   */
  public CorrectionDetails readPRLICorrection(
    PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    final CorrectionDetails correctionDetails = new CorrectionDetails();

    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliCorrectionKey.prliCorrectionID);

    correctionDetails.details = assignToPRLICorrectionDtls(prliCorrection);

    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        prliCorrection.getProviderRosterLineItem().getRoster())) {
      // END, CR00178377
      correctionDetails.expectedUnits = prliCorrection.getProviderRosterLineItem().getExpectedUnits();
    }
    // END, CR00176474

    correctionDetails.isGeneratedByUser = !prliCorrection.getProviderRosterLineItem().getAutoGeneratedInd();

    // if generated by system fetch address from Provider roster line item
    // If generated by user fetch address from PRLICorrection
    if (correctionDetails.isGeneratedByUser) {
      if (prliCorrection.getClientAddressID() != CPMConstants.kZeroLong) {
        correctionDetails.clientAddress = prliCorrection.getClientAddressData();
      }
    } else {
      if (prliCorrection.getProviderRosterLineItem().getAddressID()
        != CPMConstants.kZeroLong) {
        correctionDetails.clientAddress = prliCorrection.getProviderRosterLineItem().getAddressData();
      }
    }

    correctionDetails.details.versionNo = prliCorrection.getVersionNo();

    // Load the Daily attendanceCorrection details
    for (DailyAttendanceCorrection dailyAttendanceCorrection : sortDailyAttendanceCorrectionByServiceDate(
      dailyAttendanceCorrectionDAO.searchByPRLICorrection(
        prliCorrectionKey.prliCorrectionID))) {
      final DailyAttendanceCorrectionDtls dailyAttendanceCorrectionDtls = new DailyAttendanceCorrectionDtls();

      dailyAttendanceCorrectionDtls.absenceReason = dailyAttendanceCorrection.getAbsenceReason().getCode();
      dailyAttendanceCorrectionDtls.attendance = dailyAttendanceCorrection.getAttendance().getCode();
      dailyAttendanceCorrectionDtls.serviceDate = dailyAttendanceCorrection.getServiceDate();
      dailyAttendanceCorrectionDtls.unitsAttended = dailyAttendanceCorrection.getUnitsAttended();
      dailyAttendanceCorrectionDtls.unitsUnattended = dailyAttendanceCorrection.getUnitsUnattended();
      correctionDetails.dailyAttendanceDetails.addRef(
        dailyAttendanceCorrectionDtls);
    }

    if (correctionDetails.dailyAttendanceDetails.size()
      > CPMConstants.kZeroLong) {
      correctionDetails.isDailyAttendanceTrackingRequired = true;
    } else {

      for (AbsencePeriodCorrection absencePeriodCorrection : absencePeriodCorrectionDAO.searchByPRLICorrection(
        prliCorrectionKey.prliCorrectionID)) {
        final AbsencePeriodCorrectionDtls absencePeriodCorrectionDtls = new AbsencePeriodCorrectionDtls();

        absencePeriodCorrectionDtls.absenceDate = absencePeriodCorrection.getAbsenceDate();
        absencePeriodCorrectionDtls.absenceReason = absencePeriodCorrection.getAbsenceReason();
        absencePeriodCorrectionDtls.unitsUnattended = absencePeriodCorrection.getUnitsUnattended();
        correctionDetails.absenceDetailsList.addRef(absencePeriodCorrectionDtls);
      }
      correctionDetails.isAbsenceCorrectionAvailable = true;
    }

    correctionDetails.serviceName = prliCorrection.getProviderRosterLineItem().getRoster().getProviderOffering().getServiceOffering().getName();

    return correctionDetails;
  }

  /**
   * Method to assign the values available in PRLICorrection to
   * PRLICorrectinDtls struct.
   *
   * @param prliCorrection
   * PRLICorrection object.
   * @return PRLICorrectionDtls object.
   */
  // BEGIN, CR00177241, PM
  protected PRLICorrectionDtls assignToPRLICorrectionDtls(
    // END, CR00177241
    PRLICorrection prliCorrection) {

    PRLICorrectionDtls prliCorrectionDtls = null;

    // If roster is auto generated fetch the details from Provider roster
    // line item
    ProviderRosterLineItem providerRosterLineItem = prliCorrection.getProviderRosterLineItem();

    if (providerRosterLineItem.getAutoGeneratedInd()) {
      prliCorrectionDtls = getPRLICorrectionDetails(providerRosterLineItem);

      prliCorrectionDtls.totalUnitsDelivered = prliCorrection.getTotalUnitsDeliverd();

      prliCorrectionDtls.reason = prliCorrection.getReason();
      prliCorrectionDtls.status = prliCorrection.getLifecycleState().getCode();

      prliCorrectionDtls.totalUnitsDelivered = prliCorrection.getTotalUnitsDeliverd();
      prliCorrectionDtls.prliCorrectionID = prliCorrection.getID();

    } else {
      // If roster is generated by user fetch the details from PRLI Correction
      prliCorrectionDtls = new PRLICorrectionDtls();
      prliCorrectionDtls.prliCorrectionID = prliCorrection.getID();
      prliCorrectionDtls.providerRosterLineItemID = prliCorrection.getProviderRosterLineItem().getID();
      prliCorrectionDtls.clientDOB = prliCorrection.getClientDOB();
      prliCorrectionDtls.clientFirstName = prliCorrection.getClientFirstName();
      prliCorrectionDtls.clientLastName = prliCorrection.getClientLastName();
      prliCorrectionDtls.clientReferenceNo = prliCorrection.getClientReferenceNo();
      // BEGIN, CR00153665, RD
      prliCorrectionDtls.clientAddressID = prliCorrection.getClientAddressID();
      // END, CR00153665
      prliCorrectionDtls.reason = prliCorrection.getReason();
      prliCorrectionDtls.saReferenceNo = prliCorrection.getSAReferenceNo();
      // BEGIN, CR00128590, RD
      prliCorrectionDtls.caseReferenceNo = prliCorrection.getCaseReferenceNo();
      // END, CR00128590
      prliCorrectionDtls.serviceFromDate = prliCorrection.getServiceDateRange().start();
      prliCorrectionDtls.serviceToDate = prliCorrection.getServiceDateRange().end();
      prliCorrectionDtls.status = prliCorrection.getLifecycleState().getCode();
      prliCorrectionDtls.voucherNo = prliCorrection.getVoucherNo();
      prliCorrectionDtls.totalUnitsDelivered = prliCorrection.getTotalUnitsDeliverd();
    }

    return prliCorrectionDtls;
  }

  /**
   * {@inheritDoc}
   */
  public PRLICorrectionDetails readPRLIDetails(
    final ProviderRosterLineItemKey providerRosterLineItemKey)
    throws AppException, InformationalException {

    final PRLICorrectionDetails prliCorrectionDetails = new PRLICorrectionDetails();

    final ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    prliCorrectionDetails.correctionDetails = getPRLICorrectionDetails(
      providerRosterLineItem);
    prliCorrectionDetails.expectedUnits = providerRosterLineItem.getExpectedUnits();

    if (providerRosterLineItem.getAddressID() != CPMConstants.kZeroLong) {
      prliCorrectionDetails.clientAddress = providerRosterLineItem.getAddressData();
      // BEGIN, CR00153665, RD
      prliCorrectionDetails.correctionDetails.clientAddressID = providerRosterLineItem.getAddressID();
      // END, CR00153665
    }

    prliCorrectionDetails.isGeneratedByUser = !providerRosterLineItem.getAutoGeneratedInd();

    // Based on the configuration set if daily attendance tracking is
    // required or not
    SOAttendanceConfiguration soAttendanceConfiguration = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      providerRosterLineItem.getRoster().getServiceOffering(),
      Date.getCurrentDate());

    if (soAttendanceConfiguration != null) {
      prliCorrectionDetails.isDailyAttendanceTrackingRequired = soAttendanceConfiguration.isDailyAttendanceTrackingRequired();
    }

    return prliCorrectionDetails;
  }

  /**
   * {@inheritDoc}
   */
  public void updatePRLICorrection(
    final PRLICorrectionDetails prliCorrectionDetails) throws AppException,
      InformationalException {

    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliCorrectionDetails.correctionDetails.prliCorrectionID);

    // Set the value for update only if the prliCorrection is generated
    // by the user
    if (prliCorrectionDetails.isGeneratedByUser) {
      final AddressDtls addressDtls = new AddressDtls();

      addressDtls.addressData = prliCorrectionDetails.clientAddress;
      addressDtls.addressID = prliCorrection.getClientAddressID();

      // This call will update the addressDtls
      prliCorrection.setClientAddress(addressDtls);
    }

    setPRLICorrection(prliCorrection, prliCorrectionDetails,
      prliCorrectionDetails.isGeneratedByUser);

    prliCorrection.modify(prliCorrectionDetails.correctionDetails.versionNo);

    SOAttendanceConfiguration soAttendanceConfiguration = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      prliCorrection.getProviderRosterLineItem().getRoster().getServiceOffering(),
      Date.getCurrentDate());

    // Daily attendance corrections or absence corrections has to be updated
    // based on the changes in the service from date and to date.
    if (soAttendanceConfiguration != null
      && soAttendanceConfiguration.isDailyAttendanceTrackingRequired()) {
      addOrDeleteDailyAttendanceCorrection(prliCorrection);
    } else {
      deleteOnUpdateAbsenceDetailsCorrection(prliCorrection);
    }

  }

  /**
   * This method is used to add or delete daily attendance corrections based on
   * the changes in the service from and to date.
   *
   * @param prliCorrection
   * Provider roster line item correction
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void addOrDeleteDailyAttendanceCorrection(
    PRLICorrection prliCorrection) throws InformationalException {

    Set<DailyAttendanceCorrection> dailyAttendanceCorrections = dailyAttendanceCorrectionDAO.searchByPRLICorrection(
      prliCorrection.getID());

    List<Date> attendanceDates = new ArrayList<Date>();

    // Delete the records that are not within the service date range and
    // add the dates for which attendance record is there.
    for (DailyAttendanceCorrection dailyAttendanceCorrection : dailyAttendanceCorrections) {

      if (!prliCorrection.getServiceDateRange().contains(
        dailyAttendanceCorrection.getServiceDate())) {

        dailyAttendanceCorrection.remove(
          dailyAttendanceCorrection.getVersionNo());
      } else {
        attendanceDates.add(dailyAttendanceCorrection.getServiceDate());
      }
    }

    Date serviceDate = prliCorrection.getServiceDateRange().start();

    // Loop through entire date range of service and create default records for
    // the date attendance is not there.
    while (!serviceDate.after(prliCorrection.getServiceDateRange().end())) {

      // BEGIN, CR00208100, ASN
      if (!attendanceDates.contains(serviceDate)
        && !serviceDate.after(Date.getCurrentDate())) {
        // END, CR00208100
        
        DailyAttendanceCorrection dailyAttendanceCorrection = dailyAttendanceCorrectionDAO.newInstance();

        dailyAttendanceCorrection.setAttendance(ATTENDANCEEntry.PRESENT);
        dailyAttendanceCorrection.setServiceDate(serviceDate);
        dailyAttendanceCorrection.setPRLICorrection(prliCorrection);
        dailyAttendanceCorrection.setUnitsAttended(
          Short.valueOf(Long.toString(1)));

        dailyAttendanceCorrection.insert();
      }
      serviceDate = serviceDate.addDays(1);
    }

  }

  /**
   * This method is used to delete absence period corrections based on the
   * changes in the service from and to date.
   *
   * @param prliCorrection
   * Provider roster line item correction
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void deleteOnUpdateAbsenceDetailsCorrection(
    PRLICorrection prliCorrection) throws InformationalException {

    Set<AbsencePeriodCorrection> absencePeriodCorrections = absencePeriodCorrectionDAO.searchByPRLICorrection(
      prliCorrection.getID());

    // Delete the records that are not within the service date range
    for (AbsencePeriodCorrection absencePeriodCorrection : absencePeriodCorrections) {

      // BEGIN CR00131853, MST
      if (!absencePeriodCorrection.getAbsenceDate().isZero()
        && !prliCorrection.getServiceDateRange().contains(
          absencePeriodCorrection.getAbsenceDate())) {
        // END CR00131853
        absencePeriodCorrection.remove(absencePeriodCorrection.getVersionNo());
      }
    }

  }

  /**
   * This method is used to set the values from the entity record of Provider
   * roster line item to the struct that is to be displayed on the screen for
   * correction.
   *
   * @param rosterLineItem
   * Contains the details of roster line item
   * @param providerRosterLineItem
   * Contains the details of the Provider roster line item
   * @return Contains the details for correction
   */
  // BEGIN, CR00177241, PM
  protected PRLICorrectionDtls getPRLICorrectionDetails(
    // END, CR00177241
    final ProviderRosterLineItem providerRosterLineItem) {

    final PRLICorrectionDtls prliCorrectionDtls = new PRLICorrectionDtls();

    prliCorrectionDtls.clientFirstName = providerRosterLineItem.getClientFirstName();
    prliCorrectionDtls.clientLastName = providerRosterLineItem.getClientLastName();
    prliCorrectionDtls.clientDOB = providerRosterLineItem.getClientDOB();
    prliCorrectionDtls.clientReferenceNo = providerRosterLineItem.getClientReferenceNo();

    prliCorrectionDtls.providerRosterLineItemID = providerRosterLineItem.getID();
    prliCorrectionDtls.saReferenceNo = providerRosterLineItem.getSAReferenceNo();
    // BEGIN, CR00128590, RD
    prliCorrectionDtls.caseReferenceNo = providerRosterLineItem.getCaseReferenceNo();
    // END, CR00128590
    prliCorrectionDtls.versionNo = providerRosterLineItem.getVersionNo();
    prliCorrectionDtls.voucherNo = providerRosterLineItem.getVoucherNumber();

    prliCorrectionDtls.serviceFromDate = providerRosterLineItem.getServiceDateFrom();
    prliCorrectionDtls.serviceToDate = providerRosterLineItem.getServiceDateTo();
    prliCorrectionDtls.totalUnitsDelivered = providerRosterLineItem.getUnitsDelivered();

    return prliCorrectionDtls;
  }

  /**
   * This method is used to set the values from the screen that is entered or
   * modified to the entity record of Provider roster line item correction.
   *
   * @param prliCorrection
   * Contains the details of provider roster line item correction
   * entity.
   * @param prliCorrectionDetails
   * Contains the details of provider roster line item correction that
   * is entered or modified in the screen.
   */
  // BEGIN, CR00176474, AS
  // BEGIN, CR00177241, PM
  protected void setPRLICorrection(final PRLICorrection prliCorrection,
    // END, CR00177241
    PRLICorrectionDetails prliCorrectionDetails, boolean changesAllowed)
    throws InformationalException, AppException {
    // END, CR00176474

    if (changesAllowed) {

      prliCorrection.setSAReferenceNo(
        prliCorrectionDetails.correctionDetails.saReferenceNo);
      // BEGIN, CR00128590, RD
      prliCorrection.setCaseReferenceNo(
        prliCorrectionDetails.correctionDetails.caseReferenceNo);
      // END, CR00128590
      prliCorrection.setServiceDateRange(
        new DateRange(prliCorrectionDetails.correctionDetails.serviceFromDate,
        prliCorrectionDetails.correctionDetails.serviceToDate));
      prliCorrection.setVoucherNo(
        prliCorrectionDetails.correctionDetails.voucherNo);
      // BEGIN, CR00273745, ASN
      prliCorrection.setCaseReferenceNo(
        prliCorrectionDetails.correctionDetails.caseReferenceNo);
      // END, CR00273745
    }

    prliCorrection.setProviderRosterLineItem(
      providerRosterLineItemDAO.get(
        prliCorrectionDetails.correctionDetails.providerRosterLineItemID));

    // BEGIN, CR00168585, KG
    prliCorrection.setClientDOB(
      prliCorrection.getProviderRosterLineItem().getClientDOB());
    prliCorrection.setClientFirstName(
      prliCorrection.getProviderRosterLineItem().getClientFirstName());
    prliCorrection.setClientLastName(
      prliCorrection.getProviderRosterLineItem().getClientLastName());
    prliCorrection.setClientReferenceNo(
      prliCorrection.getProviderRosterLineItem().getClientReferenceNo());
    prliCorrection.setClientAddressID(
      prliCorrection.getProviderRosterLineItem().getAddressID());
    // END, CR00168585

    prliCorrection.setReason(prliCorrectionDetails.correctionDetails.reason);
    // BEGIN, CR00176474, AS
    // BEGIN, CR00178377, AS
    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        prliCorrection.getProviderRosterLineItem().getRoster())) {
      // END, CR00178377
      prliCorrection.setTotalUnitsDeliverd(
        prliCorrectionDetails.correctionDetails.totalUnitsDelivered);
    }
    // END, CR00176474

  }

  /**
   * {@inheritDoc}
   */
  public void approvePRLICorrection(PRLICorrectionKey correctionKey)
    throws AppException, InformationalException {

    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      correctionKey.prliCorrectionID);

    ProviderRosterLineItem providerRosterLineItem = prliCorrection.getProviderRosterLineItem();

    // set the status of the PRLI from 'Completed' to 'Open'
    // PRLI Correction can be approved only when PRLI is in 'Completed' state
    updatePRLIStatus(providerRosterLineItem);

    // set new PRLI fields
    setPRLIFields(providerRosterLineItem, prliCorrection);
    updateDailyAttendance(correctionKey, providerRosterLineItem);
    updateAbsence(correctionKey, providerRosterLineItem);

    // automatic approval of PRLI -- call 1) submit for approval 2) approval
    providerRosterLineItem.submitAndApprovePRLIForCorrection();
    correctRosterLineItemClients(providerRosterLineItem, prliCorrection);
    // BEGIN, CR00128939, ABS
    // raise an event to end the task

    final Event event = new Event();

    event.eventKey = curam.events.ROSTER.PRLIC_APPROVED;
    event.primaryEventData = correctionKey.prliCorrectionID;
    EventService.raiseEvent(event);

    // END, CR00128939

    prliCorrection.approve(prliCorrection.getVersionNo());

  }

  /**
   * Updates Absence period with the corresponding changes from Absence Period
   * correction.
   *
   * The Absence period records status are set to cancel. Absence period
   * correction records are inserted as new record in Absence period for the
   * roster
   *
   * @param prliCorrectionKey
   * Contains the PRLICorrection ID
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN,CR00177241, PM
  protected void updateAbsence(PRLICorrectionKey prliCorrectionKey,
    // END, CR00177241
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {
    // Set the absence period record for the roster line item to cancel
    for (AbsencePeriod absencePeriodForPRLI : absencePeriodDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID())) {
      if (RECORDSTATUSEntry.NORMAL.equals(absencePeriodForPRLI.getStatus())) {
        absencePeriodForPRLI.setStatus(RECORDSTATUSEntry.CANCELLED);
        absencePeriodForPRLI.modify();
      }
    }

    // insert correction records as new records in absence period
    for (AbsencePeriodCorrection absenceDetailsCorrection : absencePeriodCorrectionDAO.searchByPRLICorrection(
      prliCorrectionKey.prliCorrectionID)) {
      AbsencePeriod absencePeriodForPRLI = absencePeriod.newInstance();

      absencePeriodForPRLI.setAbsenceDate(
        absenceDetailsCorrection.getAbsenceDate());
      absencePeriodForPRLI.setAbsenceReason(
        ATTENDANCEABSENCEREASONEntry.get(
          absenceDetailsCorrection.getAbsenceReason()));
      absencePeriodForPRLI.setRosterLineItem(
        providerRosterLineItem.getRosterLineItemID());
      absencePeriodForPRLI.setUnitsUnattended(
        absenceDetailsCorrection.getUnitsUnattended().shortValue());
      absencePeriodForPRLI.setStatus(RECORDSTATUSEntry.NORMAL);
      // BEGIN, CR00281157, ASN
      absencePeriodForPRLI.getDtls().createdBySystem = true;
      // END, CR00281157
      
      absencePeriodForPRLI.insert();

    }
  }

  /**
   * Updates Daily attendance with the corresponding changes from Daily
   * attendance correction.
   *
   * The daily attendance records status are set to cancel. Daily attendance
   * correction records are inserted as new record in daily attendance for the
   * roster
   *
   * @param prliCorrectionKey
   * Contains the PRLICorrection ID
   * @param providerRosterLineItem
   * Contains the PRLI
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void updateDailyAttendance(PRLICorrectionKey prliCorrectionKey,
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {
    // END, CR00177241
    // Set the daily attendance records for the roster line item to cancel
    for (DailyAttendance dailyAttendanceForPRLI : dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID())) {
      if (RECORDSTATUSEntry.NORMAL.equals(dailyAttendanceForPRLI.getStatus())) {
        // BEGIN, CR00236982, SSK
        dailyAttendanceForPRLI.cancel();
        // END, CR00236982
      }
    }

    // Insert correction records as new records in daily attendance.
    for (DailyAttendanceCorrection dailyAttendanceCorrection : dailyAttendanceCorrectionDAO.searchByPRLICorrection(
      prliCorrectionKey.prliCorrectionID)) {
      
      // BEGIN, CR00199682, ASN
      DailyAttendance dailyAttendanceInstance = dailyAttendance.newInstance();

      dailyAttendanceInstance.setRosterLineItem(
        providerRosterLineItem.getRosterLineItemID());
      ServiceAuthorization serviceAuthorization = providerRosterLineItem.getServiceAuthorization();

      if (serviceAuthorization != null) {
        final ServiceDelivery serviceDelivery = serviceDeliveryDAO.readByServiceAuthorization(
          serviceAuthorization);

        dailyAttendanceInstance.setRelatedItem(serviceDelivery);
      }
      dailyAttendanceInstance.setStatus(RECORDSTATUSEntry.NORMAL);
      dailyAttendanceInstance.setServiceDate(
        dailyAttendanceCorrection.getServiceDate());
      dailyAttendanceInstance.setUnitsAttended(
        dailyAttendanceCorrection.getUnitsAttended());
      dailyAttendanceInstance.setUnitsUnattended(
        dailyAttendanceCorrection.getUnitsUnattended());
      dailyAttendanceInstance.setCreationDate(Date.getCurrentDate());
      dailyAttendanceInstance.setAttendance(
        dailyAttendanceCorrection.getAttendance());
      dailyAttendanceInstance.setAbsenceReason(
        dailyAttendanceCorrection.getAbsenceReason());
      // BEGIN, CR00246416, ASN
      dailyAttendanceInstance.setNumOfHoursAttended(
        dailyAttendanceCorrection.getNumOfHoursAttended());
      dailyAttendanceInstance.setNumOfMinutesAttended(
        dailyAttendanceCorrection.getNumOfMinutesAttended());
      dailyAttendanceInstance.setNumOfHoursAbsent(
        dailyAttendanceCorrection.getNumOfHoursAbsent());
      dailyAttendanceInstance.setNumOfMinutesAbsent(
        dailyAttendanceCorrection.getNumOfMinutesAbsent());
      // END, CR00246416
      dailyAttendanceInstance.setStatus(RECORDSTATUSEntry.NORMAL);
      
      // BEGIN, CR00208241, ASN
      if (null != dailyAttendanceCorrection.getDailyAttendance()) {
        dailyAttendanceInstance.setExpectedUnits(
          dailyAttendanceCorrection.getDailyAttendance().getExpectedUnits());
      }
      // END, CR00208241
      dailyAttendanceInstance.insert();
  
      // END, CR00199682
      
      // BEGIN, CR00236982, SSK
      dailyAttendanceCorrection.remove(dailyAttendanceCorrection.getVersionNo());
      // END, CR00236982
         
    }
  }

  /**
   * Updates the Provider Roster Line Item status to 'Open' state and adds an
   * entry in provider roster line item history.
   *
   * @param providerRosterLineItem
   * Provider Roster line item object.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void updatePRLIStatus(
    // END, CR00177241
    final ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {

    if (PRLIStatusEntry.COMPLETE.getCode().equals(
      providerRosterLineItem.getLifecycleState().getCode())) {
      providerRosterLineItem.setStatus(PRLIStatusEntry.get(PRLIStatus.OPEN));
      providerRosterLineItem.modifyRosterLineItem();
    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PRLICORRECTIONExceptionCreator.ERR_ROSTER_LINE_ITEM_CORRECTION_XRV_THIS_ROSTER_LINE_ITEM_IS_NOT_COMPLETE_CANNOT_BE_CORRECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
  }

  /**
   * Sets the values from PRLICorrection to PRLI.
   *
   * @param providerRosterLineItem
   * Service invoice line item object.
   * @param prliCorrection
   * Service invoice line item correction object.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setPRLIFields(
    // END, CR00177241
    final ProviderRosterLineItem providerRosterLineItem,
    final PRLICorrection prliCorrection) throws AppException,
      InformationalException {

    // If user generated roster then only update with correction values
    if (!providerRosterLineItem.getAutoGeneratedInd()) {

      final Address addressObj = AddressFactory.newInstance();
      final AddressKey addressKey = new AddressKey();

      if (CPMConstants.kZeroLong != prliCorrection.getClientAddressID()) {
        addressKey.addressID = prliCorrection.getClientAddressID();
        AddressDtls addressDtls = addressObj.read(addressKey);

        providerRosterLineItem.setAddress(addressDtls);
      }

      providerRosterLineItem.setClientDOB(prliCorrection.getClientDOB());
      providerRosterLineItem.setClientFirstName(
        prliCorrection.getClientFirstName());
      providerRosterLineItem.setClientLastName(
        prliCorrection.getClientLastName());
      providerRosterLineItem.setSAReferenceNo(prliCorrection.getSAReferenceNo());
      // BEGIN, CR00128590, RD
      providerRosterLineItem.setCaseReferenceNo(
        prliCorrection.getCaseReferenceNo());
      // END, CR00128590
      providerRosterLineItem.setClientReferenceNo(
        prliCorrection.getClientReferenceNo());
    }
    providerRosterLineItem.setUnitsDelivered(
      (short) prliCorrection.getTotalUnitsDeliverd());

  }

  /**
   * {@inheritDoc}
   */
  public void denyPRLICorrection(PRLICorrectionKey correctionKey)
    throws AppException, InformationalException {

    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      correctionKey.prliCorrectionID);

    prliCorrection.deny(prliCorrection.getVersionNo());
  }

  /**
   * {@inheritDoc}
   */
  public void submitPRLICorrection(PRLICorrectionKey correctionKey,
    VersionNo versionNo) throws AppException, InformationalException {
    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      correctionKey.prliCorrectionID);

    prliCorrection.submit(versionNo.versionNo);
  }

  /**
   * Creates PRLI Correction History Entry when the provider roster line item
   * status changes.
   *
   * @param correction
   * PRLI Correction object.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void createPRLICorrectionHistory(PRLICorrection correction)
    // END, CR00177241
    throws AppException, InformationalException {

    final PRLICorrectionHistory prliCorrectionHistory = prliCorrectionHistoryDAO.newInstance();

    prliCorrectionHistory.setPRLICorrection(correction);
    prliCorrectionHistory.insert();
  }

  /**
   * {@inheritDoc}
   */
  public void createAbsenceCorrectionDetails(
    AbsenceCorrectionDetails absenceCorrectionDetails) throws AppException,
      InformationalException {

    AbsencePeriodCorrection absenceDetailsCorrection = absencePeriodCorrectionDAO.newInstance();

    absenceDetailsCorrection.setAbsenceDate(
      absenceCorrectionDetails.details.absenceDate);
    absenceDetailsCorrection.setAbsenceReason(
      absenceCorrectionDetails.details.absenceReason);
    absenceDetailsCorrection.setPRLICorrection(
      prliCorrectionDAO.get(absenceCorrectionDetails.details.prliCorrectionID));
    absenceDetailsCorrection.setUnitsUnattended(
      absenceCorrectionDetails.details.unitsUnattended);
    // BEGIN, CR00281157, ASN
    absenceDetailsCorrection.setCreatedBySystemInd(true);
    // END, CR00281157
    absenceDetailsCorrection.insert();

  }

  /**
   * {@inheritDoc}
   */
  public AbsenceCorrectionDetailsList listAbsenceCorrectionDetails(
    PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    final AbsenceCorrectionDetailsList absenceCorrectionDetailsList = new AbsenceCorrectionDetailsList();

    final Set<AbsencePeriodCorrection> absencePeriodCorrections = absencePeriodCorrectionDAO.searchByPRLICorrection(
      prliCorrectionKey.prliCorrectionID);

    // Loop through absenceDetailsCorrections and set the values to
    // AbsencePeriodCorrectionDtls for display
    for (AbsencePeriodCorrection absencePeriodCorrection : sortAbsencePeriodCorrectionByServiceDate(
      absencePeriodCorrections)) {
      final AbsenceCorrectionDetails absenceCorrectionDetails = new AbsenceCorrectionDetails();

      absenceCorrectionDetails.details.absencePeriodCorrectionID = absencePeriodCorrection.getID();
      absenceCorrectionDetails.details.absenceDate = absencePeriodCorrection.getAbsenceDate();
      absenceCorrectionDetails.details.absenceReason = absencePeriodCorrection.getAbsenceReason();
      absenceCorrectionDetails.details.unitsUnattended = absencePeriodCorrection.getUnitsUnattended();
      absenceCorrectionDetails.details.prliCorrectionID = prliCorrectionKey.prliCorrectionID;
      absenceCorrectionDetails.details.versionNo = absencePeriodCorrection.getVersionNo();
      absenceCorrectionDetailsList.details.addRef(absenceCorrectionDetails);
    }

    return absenceCorrectionDetailsList;

  }

  /**
   * Method used to create the absence correction details for a provider roster
   * line item correction. This method retrieves all the absence record for the
   * provider roster line item and create absence correction record for each of
   * the active absence record that falls in the service date range.
   *
   * @param prliCorrection
   * Provider roster line item correction entity
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void createAbsenceDetailsCorrection(PRLICorrection prliCorrection)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      prliCorrection.getProviderRosterLineItem().getID());

    // Loop through absence period records for the provider roster line item
    // and create absence period correction for the active record which
    // falls in the date range of the service date
    for (curam.attendance.impl.AbsencePeriod absencePeriod : absencePeriodDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID())) {

      if (RECORDSTATUSEntry.NORMAL.equals(absencePeriod.getStatus())) {
        // BEGIN CR00131853, MST
        if (absencePeriod.getAbsenceDate().isZero()
          || prliCorrection.getServiceDateRange().contains(
            absencePeriod.getAbsenceDate())) {
          // END CR00131853
          final AbsencePeriodCorrection absenceDetailsCorrection = absencePeriodCorrectionDAO.newInstance();

          absenceDetailsCorrection.setAbsencePeriod(absencePeriod);
          absenceDetailsCorrection.setAbsenceDate(
            absencePeriod.getAbsenceDate());
          absenceDetailsCorrection.setAbsenceReason(
            absencePeriod.getAbsenceReason().getCode());
          absenceDetailsCorrection.setUnitsUnattended(
            absencePeriod.getUnitsUnattended());
          absenceDetailsCorrection.setPRLICorrection(prliCorrection);

          absenceDetailsCorrection.insert();
        }
      }
    }
  }

  /**
   * This method is used to create Daily Attendance Correction from daily
   * attendance records for a provider roster line item. This method retrieves
   * all the daily attendance record for the provider roster line item and
   * create daily attendance correction record for each of the active daily
   * attendance record that falls in the service date range.
   *
   * @param prliCorrection
   * Provider roster line item correction entity
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void createDailyAttendanceCorrection(PRLICorrection prliCorrection)
    throws AppException, InformationalException {

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      prliCorrection.getProviderRosterLineItem().getID());

    // BEGIN, CR00314944, SSK    
    boolean hoursEnabled = isHoursDailyAttendanceConfigured(
      providerRosterLineItem);
    
    Set<curam.attendance.impl.DailyAttendance> dailyAttendanceList = dailyAttendanceDAO.searchByRosterLineItemID(
      providerRosterLineItem.getRosterLineItemID(), hoursEnabled);

    // Loop through daily attendance records for the provider roster line item
    // and create daily attendance correction for the active record which
    // falls in the date range of the service date
    for (curam.attendance.impl.DailyAttendance dailyAttendance : dailyAttendanceList) {
      // END, CR00314944
      if (RECORDSTATUSEntry.NORMAL.equals(dailyAttendance.getStatus())) {

        if (prliCorrection.getServiceDateRange().contains(
          dailyAttendance.getServiceDate())) {

          DailyAttendanceCorrection dailyAttendanceCorrection = dailyAttendanceCorrectionDAO.newInstance();

          dailyAttendanceCorrection.setDailyAttendance(dailyAttendance);
          dailyAttendanceCorrection.setAttendance(
            dailyAttendance.getAttendance());
          dailyAttendanceCorrection.setAbsenceReason(
            dailyAttendance.getAbsenceReason());
          dailyAttendanceCorrection.setServiceDate(
            dailyAttendance.getServiceDate());
          dailyAttendanceCorrection.setPRLICorrection(prliCorrection);
          dailyAttendanceCorrection.setUnitsAttended(
            dailyAttendance.getUnitsAttended());
          dailyAttendanceCorrection.setUnitsUnattended(
            dailyAttendance.getUnitsUnattended()); 
          // BEGIN, CR00228146, ASN
          dailyAttendanceCorrection.setNumOfHoursAttended(
            dailyAttendance.getNumOfHoursAttended());
          dailyAttendanceCorrection.setNumOfMinutesAttended(
            dailyAttendance.getNumOfMinutesAttended());
          dailyAttendanceCorrection.setNumOfHoursAbsent(
            dailyAttendance.getNumOfHoursAbsent());
          dailyAttendanceCorrection.setNumOfMinutesAbsent(
            dailyAttendance.getNumOfMinutesAbsent());
          // END, CR00228146
          dailyAttendanceCorrection.insert();
        }
      }
    }
  }

  /**
   * This method is used to read Daily Attendance Correction records for the
   * provider roster line item correction. The return list is converted to xml
   * string and assigned to the return struct. The input to the Widget is in xml
   * format.
   *
   * @param prliCorrectionKey
   * Contains the internal identifier for the provider roster line item
   * correction.
   *
   * @return Struct containing the list of daily attendance correction as xml
   * string format.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PRLICorrectionDetails readDailyAttendanceCorrection(
    PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    PRLICorrectionDetails prliCorrectionDetails = new PRLICorrectionDetails();

    // BEGIN, CR00303745, SSK
    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliCorrectionKey.prliCorrectionID);

    final ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      prliCorrection.getProviderRosterLineItem().getID());

    prliCorrectionDetails.correctionDetails.serviceFromDate = providerRosterLineItem.getServiceDateFrom();
    prliCorrectionDetails.correctionDetails.serviceToDate = providerRosterLineItem.getServiceDateTo();
    if (null != providerRosterLineItem.getClient()) {

      prliCorrectionDetails.correctionDetails.clientFirstName = providerRosterLineItem.getClient().getName();
    }
    // END, CR00303745

    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    // BEGIN, CR00198730, ASN
    dailyAttendanceDetailsList = generateDailyAttendance(prliCorrectionKey);
    // END, CR00198730

    // Convert the list of daily attendance details to an xml. This xml is
    // the input to the widget to display the list of daily attendance details.
    prliCorrectionDetails.dailyAttendaceDetails = WidgetHelper.convertDailyAttendanceToXml(
      dailyAttendanceDetailsList);

    return prliCorrectionDetails;

  }

  // BEGIN, CR00199682, ASN
  /**
   * Maintains the daily attendance correction. The xml string is converted back
   * to list containing daily attendance correction record. Each of this
   * correction record is then updated, removed or inserted. Also the total
   * units delivered is calculated and the provider roster line item correction
   * record is modified with the new value of total units delivered.
   *
   * @param prliCorrectionDetails
   * Contains the list of daily attendance correction as xml string
   * format.
   *
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_UNATTENDED_MUST_BE_GREATER_THAN_0_IF_NOT_PRESENT}
   * -If attendance is absent or partially present and units not
   * attended is less than zero.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_ATTENDED_MUST_BE_0_UNLESS_PRESENT_OR_PARTIALLYPRESENT}
   * -If attendance is not present or partially present and units
   * attended is greater than zero.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XFV_DAILY_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED}
   * - If attendance is not entered but other details are entered.
   * records.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_ABSENCE_REASON_MUST_BE_ENTERED}
   * -If absence reason not entered and attendance is absent or
   * partially present.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED}
   * - If user tries to save all blank daily attendance correction
   * records.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_UNATTENDED_MUST_BE_GREATER_THAN_0_IF_NOT_PRESENT}
   * -If attendance is present and units not attended is not entered.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_ATTENDED_MUST_BE_GREATER_THAN_0_IF_PRESENT_OR_PARTIALLYPRESENT}
   * -If units attended is not greater than zero and attendance is
   * present or partially present.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_UNATTENDED_MUST_BE_0_IF_PRESENT}
   * -If attendance is present and units not attended is entered.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_ATTENDED_CANNOT_BE_0_IF_PRESENT_OR_PARTIALLYPRESENT}
   * -If units attended is zero and attendance is present or partially
   * present.
   */
  // END, CR00199859
  public void updateDailyAttendanceCorrection(
    PRLICorrectionDetails prliCorrectionDetails) throws AppException,
      InformationalException {

    short actualUnits = 0;

    DailyAttendanceDetailsList dailyAttendanceDetailsList = WidgetHelper.convertXmlToAttendanceDetailsList(
      prliCorrectionDetails.dailyAttendaceDetails);

    // BEGIN, CR00199859, ASN
    validateUtilizationRecordsExists(dailyAttendanceDetailsList);
    // END, CR00199859

    
    
    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliCorrectionDetails.correctionDetails.prliCorrectionID);

    // BEGIN, CR00320064, SSK
    validateDailyAttendanceUnits(prliCorrection.getProviderRosterLineItem(),
      dailyAttendanceDetailsList);
    // END, CR00320064
    for (DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {
      // BEGIN, CR00198730, ASN
      if (0 != dailyAttendanceDetails.dtls.dailyAttendanceID) {

        DailyAttendanceCorrection dailyAttendanceCorrection = dailyAttendanceCorrectionDAO.get(
          dailyAttendanceDetails.dtls.dailyAttendanceID);

        // BEGIN, CR00199859, ASN
        if (StringHelper.isEmpty(dailyAttendanceDetails.dtls.attendance)) {
          // END, CR00199859
          dailyAttendanceCorrection.remove(
            dailyAttendanceDetails.dtls.versionNo);

        } else {

          // BEGIN, CR00236982, SSK
          if (dailyAttendanceCorrection.getDailyAttendance() != null) {
            // END, CR00236982
            // BEGIN, CR00208241, ASN
            dailyAttendance = dailyAttendanceDAO.get(
              dailyAttendanceCorrection.getDailyAttendance().getID());
            // END, CR00208241
          }

          dailyAttendanceCorrection.setAttendance(
            ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
          dailyAttendanceCorrection.setAbsenceReason(
            ATTENDANCEABSENCEREASONEntry.get(
              dailyAttendanceDetails.dtls.absenceReason));
          dailyAttendanceCorrection.setServiceDate(
            dailyAttendanceDetails.dtls.serviceDate);
          dailyAttendanceCorrection.setDailyAttendance(dailyAttendance);
          dailyAttendanceCorrection.setPRLICorrection(
            prliCorrectionDAO.get(
              prliCorrectionDetails.correctionDetails.prliCorrectionID));
          dailyAttendanceCorrection.setUnitsAttended(
            dailyAttendanceDetails.dtls.unitsAttended);
          dailyAttendanceCorrection.setUnitsUnattended(
            dailyAttendanceDetails.dtls.unitsUnattended);
          dailyAttendanceCorrection.modify(
            dailyAttendanceDetails.dtls.versionNo);
        }

      } else {

        if (0 == dailyAttendanceDetails.dtls.dailyAttendanceID
          && !StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.attendance)) {

          // BEGIN, CR00236982, SSK
          DailyAttendanceCorrection existingDailyAttendanceCorrection = getExisitingAttendanceCorrection(
            dailyAttendanceDetails, prliCorrectionDetails);

          if (null == existingDailyAttendanceCorrection) {
            // END, CR00236982
            DailyAttendanceCorrection dailyAttendanceCorrection = dailyAttendanceCorrectionDAO.newInstance();

            dailyAttendanceCorrection.setAttendance(
              ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
            dailyAttendanceCorrection.setAbsenceReason(
              ATTENDANCEABSENCEREASONEntry.get(
                dailyAttendanceDetails.dtls.absenceReason));
            dailyAttendanceCorrection.setServiceDate(
              dailyAttendanceDetails.dtls.serviceDate);
            dailyAttendanceCorrection.setPRLICorrection(
              prliCorrectionDAO.get(
                prliCorrectionDetails.correctionDetails.prliCorrectionID));
            dailyAttendanceCorrection.setUnitsAttended(
              dailyAttendanceDetails.dtls.unitsAttended);
            dailyAttendanceCorrection.setUnitsUnattended(
              dailyAttendanceDetails.dtls.unitsUnattended);
            dailyAttendanceCorrection.insert();
          } // BEGIN, CR00236982, SSK
          else {
            existingDailyAttendanceCorrection.setAttendance(
              ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
            existingDailyAttendanceCorrection.setAbsenceReason(
              ATTENDANCEABSENCEREASONEntry.get(
                dailyAttendanceDetails.dtls.absenceReason));
            existingDailyAttendanceCorrection.setServiceDate(
              dailyAttendanceDetails.dtls.serviceDate);
            existingDailyAttendanceCorrection.setPRLICorrection(
              prliCorrectionDAO.get(
                prliCorrectionDetails.correctionDetails.prliCorrectionID));
            existingDailyAttendanceCorrection.setUnitsAttended(
              dailyAttendanceDetails.dtls.unitsAttended);
            existingDailyAttendanceCorrection.setUnitsUnattended(
              dailyAttendanceDetails.dtls.unitsUnattended);
            existingDailyAttendanceCorrection.modify(
              existingDailyAttendanceCorrection.getVersionNo());
          }
          // END, CR00236982
        }
      }
    }
    Set<DailyAttendanceCorrection> unitsAttendedList = dailyAttendanceCorrectionDAO.searchByPRLICorrection(
      prliCorrectionDetails.correctionDetails.prliCorrectionID);

    for (DailyAttendanceCorrection actualUnitsValue : unitsAttendedList) {
      actualUnits += actualUnitsValue.getUnitsAttended();
    }
    // END, CR00198730
    prliCorrection.setTotalUnitsDeliverd(actualUnits);
    prliCorrection.modify(prliCorrection.getVersionNo());
  }

  // BEGIN, CR00236982, SSK
  /**
   * Retrieves the existing daily attendance correction for the given service
   * date for roster line item correction.
   *
   * @param dailyAttendanceDetails
   * Contains the internal identifier for the provider roster line item
   * correction.
   * @param dailyAttendanceDetails
   * Contains the internal identifier for the provider roster line item
   * correction.
   *
   * @return Existing daily attendance correction for the given service date for
   * roster line item correction.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected DailyAttendanceCorrection getExisitingAttendanceCorrection(
    DailyAttendanceDetails dailyAttendanceDetails,
    PRLICorrectionDetails prliCorrectionDetails) throws AppException,
      InformationalException {
    DailyAttendanceCorrection exisitingAttendanceCorrection = null;
    Set<DailyAttendanceCorrection> existingAttendanceList = dailyAttendanceCorrectionDAO.searchByPRLICorrection(
      prliCorrectionDetails.correctionDetails.prliCorrectionID);

    for (DailyAttendanceCorrection exisitingDailyAttendanceCorrection : existingAttendanceList) {
      if (dailyAttendanceDetails.dtls.serviceDate.equals(
        exisitingDailyAttendanceCorrection.getServiceDate())
          && RECORDSTATUSEntry.NORMAL.getCode().equals(
            dailyAttendanceDetails.dtls.recordStatus)) {
        return exisitingDailyAttendanceCorrection;
      }

    }
    return exisitingAttendanceCorrection;
  }

  // END, CR00236982
  /**
   * Sorts a set of daily attendance correction records by service date.
   *
   * @param unsortedDailyAttendanceCorrection
   * The list of unsorted daily attendance Correction.
   * @return A sorted list of daily attendance correction.
   */
  protected ArrayList<DailyAttendanceCorrection> sortDailyAttendanceCorrectionByServiceDate(
    final Set<DailyAttendanceCorrection> unsortedDailyAttendanceCorrection) {

    // Sort by position for display
    final ArrayList<DailyAttendanceCorrection> dailyAttendanceCorrectionList = new ArrayList<DailyAttendanceCorrection>(
      unsortedDailyAttendanceCorrection);

    Collections.sort(dailyAttendanceCorrectionList,
      new Comparator<DailyAttendanceCorrection>() {
      public int compare(final DailyAttendanceCorrection lhs,
        final DailyAttendanceCorrection rhs) {
        return lhs.getServiceDate().compareTo(rhs.getServiceDate());
      }
    });
    return dailyAttendanceCorrectionList;
  }

  /**
   * Sorts a set of absences details correction by absence date.
   *
   * @param unsortedAbsenceDetailsCorrectionList
   * The list of unsorted absences period correction records.
   * @return A sorted list of absences period correction records.
   */
  protected ArrayList<AbsencePeriodCorrection> sortAbsencePeriodCorrectionByServiceDate(
    final Set<AbsencePeriodCorrection> unsortedAbsencePeriodCorrectionList) {

    // Sort by position for display
    final ArrayList<AbsencePeriodCorrection> absenceDetailsCorrectionList = new ArrayList<AbsencePeriodCorrection>(
      unsortedAbsencePeriodCorrectionList);

    Collections.sort(absenceDetailsCorrectionList,
      new Comparator<AbsencePeriodCorrection>() {
      public int compare(final AbsencePeriodCorrection lhs,
        final AbsencePeriodCorrection rhs) {

        return lhs.getAbsenceDate().compareTo(rhs.getAbsenceDate());
      }
    });
    return absenceDetailsCorrectionList;
  }

  /**
   * {@inheritDoc}
   */
  public void deleteAbsenceCorrectionDetails(
    AbsencePeriodCorrectionKey absencePeriodCorrectionKey, VersionNo versionNo)
    throws AppException, InformationalException {

    AbsencePeriodCorrection absenceDetailsCorrection = absencePeriodCorrectionDAO.get(
      absencePeriodCorrectionKey.absencePeriodCorrectionID);
    
    absenceDetailsCorrection.remove(versionNo.versionNo);
    
  }
  
  // BEGIN, CR00198730, ASN
  /**
   * This method returns the daily attendance correction records associated with
   * a PRLI correction for all types of reporting method such as Utilization
   * method ,Attendance method with/with out hours enabled indicator.
   *
   * @param prliCorrectionKey
   * Contains the internal identifier for the provider roster line item
   * correction.
   *
   * @return Struct containing the list of daily attendance correction
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with {@link
   * MaintainPRLICorrection.listDailyAttendanceCorrectionDetails(
   * final PRLICorrectionKey prliCorrectionKey }.To support the
   * display of daily attendance correction details based on
   * reporting method type selected. See release note: CR00198730.
   */
  @Deprecated
  public ViewDailyAttendanceDetails listDailyAttendanceCorrection(
    PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    final ViewDailyAttendanceDetails viewDailyAttendanceDetails = new ViewDailyAttendanceDetails();

    final Locale locale = new Locale(TransactionInfo.getProgramLocale());
    final DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG,
      locale);

    for (DailyAttendanceCorrection dailyAttendanceCorrection : sortDailyAttendanceCorrectionByServiceDate(
      dailyAttendanceCorrectionDAO.searchByPRLICorrection(
        prliCorrectionKey.prliCorrectionID))) {

      final DailyAttendanceDetails dailyAttendanceDetails = new DailyAttendanceDetails();

      // BEGIN, CR00303745, SSK
      dailyAttendanceDetails.serviceDateString = curam.util.resources.Locale.getFormattedDateTime(
        dailyAttendanceDetails.dtls.serviceDate.getDateTime(),
        curam.util.resources.Locale.Date_ymd);
      // END, CR00303745
      dailyAttendanceDetails.dtls.absenceReason = dailyAttendanceCorrection.getAbsenceReason().getCode();
      dailyAttendanceDetails.dtls.attendance = dailyAttendanceCorrection.getAttendance().getCode();
      if (dailyAttendanceCorrection.getDailyAttendance().getExpectedUnits()
        == 0) {
        dailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
      } else {
        dailyAttendanceDetails.expectedUnitsString = String.valueOf(
          dailyAttendanceCorrection.getDailyAttendance().getExpectedUnits());
      }
      if (dailyAttendanceCorrection.getUnitsAttended() == 0) {
        dailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
      } else {
        dailyAttendanceDetails.unitsAttendedString = String.valueOf(
          dailyAttendanceCorrection.getUnitsAttended());
      }
      if (dailyAttendanceCorrection.getUnitsUnattended() == 0) {
        dailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
      } else {
        dailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
          dailyAttendanceCorrection.getUnitsUnattended());
      }

      viewDailyAttendanceDetails.detailsList.details.addRef(
        dailyAttendanceDetails);
    }

    return viewDailyAttendanceDetails;
  }

  // END, CR00198730

  // BEGIN, CR00168585, KG
  /**
   * Copies the provider roster line item correction client details to provider
   * roster line item client.
   *
   * @param providerRosterLineItem
   * Provider roster line item details.
   * @param prliCorrection
   * Provider roster line item correction details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void correctRosterLineItemClients(
    ProviderRosterLineItem providerRosterLineItem,
    PRLICorrection prliCorrection) throws InformationalException,
      AppException {
    Set<PRLIClient> existingPRLIClients = prliClientDao.listClientsForPRLI(
      providerRosterLineItem);

    // Delete all the existing clients associated with roster line item.
    for (PRLIClient client : existingPRLIClients) {
      client.cancelToCorrectRLI();
    }

    // Copy details of each client in the correction and associate it with
    // roster line item.
    Set<PRLICorrectionClient> correctedClients = prliCorrectionClientDao.listClientsForPRLICorrection(
      prliCorrection);

    for (PRLICorrectionClient correctedClient : correctedClients) {
      PRLIClient newPRLIClient = prliClientDao.newInstance();

      newPRLIClient.setClientFirstName(correctedClient.getClientFirstName());
      newPRLIClient.setClientLastName(correctedClient.getClientLastName());
      newPRLIClient.setClientDOB(correctedClient.getClientDOB());
      newPRLIClient.setClientReferenceNo(correctedClient.getClientReferenceNo());
      newPRLIClient.setProviderRosterLineItem(providerRosterLineItem);
      newPRLIClient.setAddressID(correctedClient.getClientAddressID());
      newPRLIClient.addClientToCorrectRLI();
    }
  }

  // END, CR00168585
  
  // BEGIN, CR00198730, ASN
  /**
   * Generates daily attendance correction for a client who is added to a roster, for each
   * day of the roster line item period dynamically to support non storage of
   * daily attendance correction empty records.
   *
   * @param providerRosterLineItem
   * Contains provider roster line item details.
   *
   * @return List of Daily Attendance correction details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected DailyAttendanceDetailsList generateDailyAttendance(
    final PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();
    Map<Date, DailyAttendanceCorrection> checkDuplicateMap = new HashMap<Date, DailyAttendanceCorrection>();

    ArrayList<Date> serviceDateList = new ArrayList<Date>();

    Set<DailyAttendanceCorrection> dailyAttendanceCorrections = dailyAttendanceCorrectionDAO.searchByPRLICorrection(
      prliCorrectionKey.prliCorrectionID);

    PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliCorrectionKey.prliCorrectionID);

    Date startDate = prliCorrection.getServiceDateRange().start();
    Date endDate = prliCorrection.getServiceDateRange().end();

    serviceDateList = serviceDatesForActiveDailyAttendance(prliCorrection);

    boolean isReporting = false;

    if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
      || attendanceConfigurationHelper.isReportingMethodUtilization(
        prliCorrection.getProviderRosterLineItem().getRoster())) {

      isReporting = true;
    }

    boolean isPlannedUnitsDefaulted = Boolean.parseBoolean(
      curam.util.resources.Configuration.getProperty(
        CPMConstants.kRosterLineItemPlannedUnits));

    // Create the daily Attendance for each day of the service period.
    while (startDate.before(endDate.addDays(1))) {

      if (!serviceDateList.contains(startDate)) {

        DailyAttendanceDetails dailyAttendanceDetails = new DailyAttendanceDetails();

        dailyAttendanceDetails = generateUnstoredDailyAttendanceDetails(
          prliCorrection, isReporting, isPlannedUnitsDefaulted, startDate);
        dailyAttendanceDetailsList.details.addRef(dailyAttendanceDetails);

      } else {

        for (DailyAttendanceCorrection dailyAttendanceCorrection : sortDailyAttendanceCorrectionByServiceDate(
          dailyAttendanceCorrections)) {

          if (startDate.equals(dailyAttendanceCorrection.getServiceDate())) {

            if (!checkDuplicateMap.containsKey(
              dailyAttendanceCorrection.getServiceDate())) {

              checkDuplicateMap.put(dailyAttendanceCorrection.getServiceDate(),
                dailyAttendanceCorrection);
              DailyAttendanceDetails storedDailyAttendanceDetails = new DailyAttendanceDetails();

              storedDailyAttendanceDetails = storedDailyAttendanceDetails(
                dailyAttendanceCorrection);

              dailyAttendanceDetailsList.details.addRef(
                storedDailyAttendanceDetails);

            }
          }
        }
      }

      startDate = startDate.addDays(1);
    }

    return dailyAttendanceDetailsList;

  }

  /**
   * Retrieves the service dates for active daily attendance records.
   *
   * @param prliCorrection
   * Contains provider roster line item correction details.
   *
   * @return List of Daily Attendance service dates.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ArrayList<Date> serviceDatesForActiveDailyAttendance(
    final PRLICorrection prliCorrection) throws InformationalException,
      AppException {

    ArrayList<Date> serviceDateList = new ArrayList<Date>();

    Set<DailyAttendanceCorrection> dailyAttendanceCorrectionList = dailyAttendanceCorrectionDAO.searchByPRLICorrection(
      prliCorrection.getID());

    for (DailyAttendanceCorrection dailyAttendanceCorrection : sortDailyAttendanceCorrectionByServiceDate(
      dailyAttendanceCorrectionList)) {

      ArrayList<Date> serviceDate = new ArrayList<Date>();

      serviceDate.add(dailyAttendanceCorrection.getServiceDate());

      serviceDateList.addAll(serviceDate);
    }
    return serviceDateList;
  }

  /**
   * Sorts a set of daily attendance records into a sorted list for display.
   *
   * @param unSortedDailyAttendanceDetailsList
   * List of unsorted daily attendance.
   *
   * @return List of daily attendance records sorted by service date.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  protected DailyAttendanceDetailsList sortDailyAttendance(
    final DailyAttendanceDetailsList unSortedDailyAttendanceDetailsList)
    throws AppException, InformationalException {

    List<DailyAttendanceDetails> dailyAttendanceDetailsList = new ArrayList<DailyAttendanceDetails>();

    for (DailyAttendanceDetails dailyAttendance : unSortedDailyAttendanceDetailsList.details.items()) {
      dailyAttendanceDetailsList.add(dailyAttendance);
    }

    Collections.sort(dailyAttendanceDetailsList,
      new Comparator<DailyAttendanceDetails>() {
      public int compare(final DailyAttendanceDetails lhs,
        final DailyAttendanceDetails rhs) {
        return lhs.dtls.serviceDate.compareTo(rhs.dtls.serviceDate);
      }
    });

    DailyAttendanceDetailsList sortedDailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    sortedDailyAttendanceDetailsList.details.addAll(dailyAttendanceDetailsList);

    return sortedDailyAttendanceDetailsList;
  }

  /**
   * Returns the daily attendance correction records associated with a PRLI
   * correction of reporting method 'Attendance'.
   *
   * @param prliCorrectionKey
   * Contains the internal identifier for the provider roster line item
   * correction.
   *
   * @return List of daily attendance correction.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewDailyAttendanceReportingDetails readDailyAttendanceCorrectionForReporting(
    final PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    ViewDailyAttendanceReportingDetails viewDailyAttendanceReportingDetails = new ViewDailyAttendanceReportingDetails();
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    PRLICorrection pRLICorrection = prliCorrectionDAO.get(
      prliCorrectionKey.prliCorrectionID);

    viewDailyAttendanceReportingDetails.fromDate = pRLICorrection.getServiceDateRange().start();
    viewDailyAttendanceReportingDetails.toDate = pRLICorrection.getServiceDateRange().end();
    
    // BEGIN, CR00303745, SSK
    if (null != pRLICorrection.getProviderRosterLineItem().getClient()) {
      viewDailyAttendanceReportingDetails.clientName = pRLICorrection.getProviderRosterLineItem().getClient().getName();
    }
    // END, CR00303745

    SOAttendanceConfiguration soAttendanceConfig = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      pRLICorrection.getProviderRosterLineItem().getRoster().getServiceOffering(),
      pRLICorrection.getProviderRosterLineItem().getRoster().getDateGenerated());

    if (null != soAttendanceConfig
      && soAttendanceConfig.isDailyAttendanceTrackingRequired()) {
      // Generate daily attendance dynamically using data using either the daily
      // attendance correction date input at facade level or from daily
      // attendance correction entity
      // if records exist.
      dailyAttendanceDetailsList = generateDailyAttendance(prliCorrectionKey);
    }
    viewDailyAttendanceReportingDetails.viewDetailsList.assign(
      dailyAttendanceDetailsList);

    RosterKey rosterKey = new RosterKey();

    rosterKey.rosterID = pRLICorrection.getProviderRosterLineItem().getRoster().getID();

    // Convert the list of daily attendance details to an xml. This xml is the
    // input to the widget to display the list of daily attendance correction
    // details.
    if (attendanceConfigurationHelper.isHoursEnabledForAttendanceReporting(
      rosterKey)) {
      
      viewDailyAttendanceReportingDetails.hoursEnabled = true;
      viewDailyAttendanceReportingDetails.dailyAttendanceHoursDetails = AttendanceWidgetHelper.convertDailyAttendanceToXml(
        dailyAttendanceDetailsList,
        viewDailyAttendanceReportingDetails.hoursEnabled);
    } else {
      
      viewDailyAttendanceReportingDetails.hoursEnabled = false;
      viewDailyAttendanceReportingDetails.dailyAttendanceDetails = AttendanceWidgetHelper.convertDailyAttendanceToXml(
        dailyAttendanceDetailsList,
        viewDailyAttendanceReportingDetails.hoursEnabled);
    }

    return viewDailyAttendanceReportingDetails;

  }

  /**
   * Maintains the daily attendance correction records associated with a PRLI
   * correction of reporting method 'Attendance'.
   *
   * @param prliAttendanceCorrectionDetails
   * Contains the list of daily attendance correction as xml string
   * format.
   *
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XFV_FOR_HOURS_DISABLED_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED}
   * - If attendance is not entered but other details are entered for
   * records of type Attendance with Hours Enabled indicator set as
   * false.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link ROSTER#ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED}
   * - If user tries to save all blank daily attendance correction
   * records.
   * @throws InformationalException
   * {@link DAILYATTENDANCECORRECTION#ERR_DAILYATTENDANCECORRECTION_XFV_DAILY_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED}
   * - If attendance is not entered but other details are entered for
   * records of type Attendance with Hours Enabled indicator set as
   * true.
   */
  public void maintainAttendanceTypeDailyAttendanceCorrection(
    PRLIAttendanceCorrectionDetails prliAttendanceCorrectionDetails)
    throws AppException, InformationalException {

    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    if (!StringUtil.isNullOrEmpty(
      prliAttendanceCorrectionDetails.dailyAttendanceDetails)) {

      dailyAttendanceDetailsList = WidgetHelper.convertAttendanceXmlToAttendanceDetailsList(
        prliAttendanceCorrectionDetails.dailyAttendanceDetails, false);
      // BEGIN, CR00199682, ASN
      validateAttendanceRecordsExists(dailyAttendanceDetailsList, false);
      // END, CR00199682
      
    } else if (!StringUtil.isNullOrEmpty(
      prliAttendanceCorrectionDetails.dailyAttendanceHoursDetails)) {
      dailyAttendanceDetailsList = WidgetHelper.convertAttendanceXmlToAttendanceDetailsList(
        prliAttendanceCorrectionDetails.dailyAttendanceHoursDetails, true);
      // BEGIN, CR00199682, ASN
      validateAttendanceRecordsExists(dailyAttendanceDetailsList, true);
      // END, CR00199682
    }
    final PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliAttendanceCorrectionDetails.attendanceCorrectionDetails.prliCorrectionID);

    // BEGIN, CR00228146, ASN
    for (final DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {
      // END, CR00228146
 
      if (0 != dailyAttendanceDetails.dtls.dailyAttendanceID) {
        
        DailyAttendanceCorrection dailyAttendanceCorrection = dailyAttendanceCorrectionDAO.get(
          dailyAttendanceDetails.dtls.dailyAttendanceID);

        // If the daily attendance is not set remove the daily attendance
        // record.
        if (StringHelper.isEmpty(dailyAttendanceDetails.dtls.attendance)) {

          dailyAttendanceCorrection.remove(
            dailyAttendanceDetails.dtls.versionNo);

        } else {
          dailyAttendanceCorrection.setAttendance(
            ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
          dailyAttendanceCorrection.setAbsenceReason(
            ATTENDANCEABSENCEREASONEntry.get(
              dailyAttendanceDetails.dtls.absenceReason));
          dailyAttendanceCorrection.setServiceDate(
            dailyAttendanceDetails.dtls.serviceDate);
          dailyAttendanceCorrection.setDailyAttendance(dailyAttendance);
          dailyAttendanceCorrection.setPRLICorrection(
            prliCorrectionDAO.get(
              prliAttendanceCorrectionDetails.attendanceCorrectionDetails.prliCorrectionID));
          // BEGIN, CR00228146, ASN
          dailyAttendanceCorrection.setNumOfHoursAttended(
            dailyAttendanceDetails.dtls.numHoursAttended);
          dailyAttendanceCorrection.setNumOfMinutesAttended(
            dailyAttendanceDetails.dtls.numMinutesAttended);
          dailyAttendanceCorrection.setNumOfHoursAbsent(
            dailyAttendanceDetails.dtls.numHoursAbsent);
          dailyAttendanceCorrection.setNumOfMinutesAbsent(
            dailyAttendanceDetails.dtls.numMinutesAbsent);
          // END, CR00228146
          dailyAttendanceCorrection.modify(
            dailyAttendanceDetails.dtls.versionNo);

        }

      } else {
        if (0 == dailyAttendanceDetails.dtls.dailyAttendanceID
          && !StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.attendance)) {

          DailyAttendanceCorrection dailyAttendanceCorrection = dailyAttendanceCorrectionDAO.newInstance();

          dailyAttendanceCorrection.setPRLICorrection(
            prliCorrectionDAO.get(prliCorrection.getID()));
          dailyAttendanceCorrection.setAttendance(
            ATTENDANCEEntry.get(dailyAttendanceDetails.dtls.attendance));
          dailyAttendanceCorrection.setAbsenceReason(
            ATTENDANCEABSENCEREASONEntry.get(
              dailyAttendanceDetails.dtls.absenceReason));
          dailyAttendanceCorrection.setServiceDate(
            dailyAttendanceDetails.dtls.serviceDate);
          // BEGIN, CR00228146, ASN
          dailyAttendanceCorrection.setNumOfHoursAttended(
            dailyAttendanceDetails.dtls.numHoursAttended);
          dailyAttendanceCorrection.setNumOfMinutesAttended(
            dailyAttendanceDetails.dtls.numMinutesAttended);
          dailyAttendanceCorrection.setNumOfHoursAbsent(
            dailyAttendanceDetails.dtls.numHoursAbsent);
          dailyAttendanceCorrection.setNumOfMinutesAbsent(
            dailyAttendanceDetails.dtls.numMinutesAbsent);
          // END, CR00228146
          dailyAttendanceCorrection.insert();
        }
      }
    }

    prliCorrection.modify(prliCorrection.getVersionNo());
  }

  /**
   * {@inheritDoc}
   */
  public ViewReportingDailyAttendanceDetails listDailyAttendanceCorrectionDetails(
    final PRLICorrectionKey prliCorrectionKey) throws AppException,
      InformationalException {

    final ViewReportingDailyAttendanceDetails viewReportingDailyAttendanceDetails = new ViewReportingDailyAttendanceDetails();

    final Locale locale = new Locale(TransactionInfo.getProgramLocale());
    final DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG,
      locale);

    PRLICorrection prliCorrection = prliCorrectionDAO.get(
      prliCorrectionKey.prliCorrectionID);
    RosterKey rosterKey = new RosterKey();

    rosterKey.rosterID = prliCorrection.getProviderRosterLineItem().getRoster().getID();

    viewReportingDailyAttendanceDetails.isHoursEnabled = attendanceConfigurationHelper.isHoursEnabledForAttendanceReporting(
      rosterKey);

    ReportingDailyAttendanceDetails reportingDailyAttendanceDetails;

    for (final DailyAttendanceCorrection dailyAttendanceCorrection : sortDailyAttendanceCorrectionByServiceDate(
      dailyAttendanceCorrectionDAO.searchByPRLICorrection(
        prliCorrectionKey.prliCorrectionID))) {

      // BEGIN, CR00304523, SSK
      reportingDailyAttendanceDetails = new ReportingDailyAttendanceDetails();
      reportingDailyAttendanceDetails.dtls.serviceDate = dailyAttendanceCorrection.getServiceDate();
      // END, CR00304523
      final java.util.Date serviceDate = new java.util.Date(
        dailyAttendanceCorrection.getServiceDate().asLong());
      final String formattedServiceDate = dateFormat.format(serviceDate);

      reportingDailyAttendanceDetails.serviceDateString = formattedServiceDate;
      
      reportingDailyAttendanceDetails.dtls.absenceReason = dailyAttendanceCorrection.getAbsenceReason().getCode();
      reportingDailyAttendanceDetails.dtls.attendance = dailyAttendanceCorrection.getAttendance().getCode();
      if (null != dailyAttendanceCorrection.getDailyAttendance()) {
        
        if (0
          == dailyAttendanceCorrection.getDailyAttendance().getExpectedUnits()) {
          reportingDailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
        } else {
          reportingDailyAttendanceDetails.expectedUnitsString = String.valueOf(
            dailyAttendanceCorrection.getDailyAttendance().getExpectedUnits());
        }
      } else {
        reportingDailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
      }

      if (0 == dailyAttendanceCorrection.getUnitsAttended()) {
        reportingDailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
      } else {
        reportingDailyAttendanceDetails.unitsAttendedString = String.valueOf(
          dailyAttendanceCorrection.getUnitsAttended());
      }
      if (0 == dailyAttendanceCorrection.getUnitsUnattended()) {
        reportingDailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
      } else {
        reportingDailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
          dailyAttendanceCorrection.getUnitsUnattended());
      }
      if (viewReportingDailyAttendanceDetails.isHoursEnabled) {
        reportingDailyAttendanceDetails.hoursAttended = getFormattedTimeDuration(
          dailyAttendanceCorrection.getHoursAttended(),
          dailyAttendanceCorrection.getMinutesAttended());

        reportingDailyAttendanceDetails.hoursUnAttended = getFormattedTimeDuration(
          dailyAttendanceCorrection.getHoursAbsent(),
          dailyAttendanceCorrection.getMinutesAbsent());
      }
      viewReportingDailyAttendanceDetails.details.addRef(
        reportingDailyAttendanceDetails);
    }

    return viewReportingDailyAttendanceDetails;
  }

  /**
   * Formats the duration in "HM hours and MM minutes" format.
   *
   * @param hours
   * Hours of attendance or absence.
   * @param minutes
   * Minutes of attendance or absence.
   *
   * @return Formatted duration.
   */
  protected String getFormattedTimeDuration(
    final ATTENDANCETRACKINGHOURSEntry hours,
    final ATTENDANCETRACKINGMINUTESEntry minutes) {

    String formattedHrsMinutes = CPMConstants.kEmptyString;
    String formattedMinutes = CPMConstants.kEmptyString;
    String formattedHrs = CPMConstants.kEmptyString;
    boolean appendMinutesToHrs = false;

    if (!ATTENDANCETRACKINGMINUTESEntry.NOT_SPECIFIED.getCode().equals(
      minutes.getCode())
        && !ATTENDANCETRACKINGMINUTESEntry.ATM2001.getCode().equals(
          minutes.getCode())) {

      // If minutes is 30, append to half an hour.
      if (ATTENDANCETRACKINGMINUTESEntry.ATM2031.getCode().equals(
        minutes.getCode())) {

        appendMinutesToHrs = true;

      } else {

        if (CPMConstants.kMinturesLength == minutes.getCode().length()
          && CPMConstants.kZeroChar
            == minutes.getCode().charAt(CPMConstants.kFirstCharIndex)) {
          formattedMinutes = minutes.getCode().charAt(
            CPMConstants.kSecondCharIndex)
              + CPMConstants.kSpace
              + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_MINUTES_ATTENDED_UNATTENDED).getMessage();
        } else {
          formattedMinutes = minutes.getCode() + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_MINUTES_ATTENDED_UNATTENDED).getMessage();
        }
      }
    }

    if (!ATTENDANCETRACKINGHOURSEntry.NOT_SPECIFIED.getCode().equals(
      hours.getCode())
        && !ATTENDANCETRACKINGHOURSEntry.ATH2001.getCode().equals(
          hours.getCode())) {
      if (CPMConstants.kMinturesLength == hours.getCode().length()
        && hours.getCode().charAt(CPMConstants.kFirstCharIndex)
          == CPMConstants.kZeroChar) {
        formattedHrs = hours.getCode().charAt(CPMConstants.kSecondCharIndex)
          + CPMConstants.kEmptyString;
      } else {
        formattedHrs = hours.getCode();
      }
    }

    if (appendMinutesToHrs) {
      if (CPMConstants.kEmptyString.equals(formattedHrs)) {
        formattedHrs = CPMConstants.kZeroChar + CPMConstants.kEmptyString;
      }

      formattedHrsMinutes = formattedHrs + CPMConstants.khalfAnHour
        + CPMConstants.kSpace
        + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_ATTENDED_UNATTENDED).getMessage();

    } else {
      if (!CPMConstants.kEmptyString.equals(formattedHrs)) {
        if (!CPMConstants.kEmptyString.equals(formattedMinutes)) {
          formattedHrsMinutes = formattedHrs + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_AND_MINUTES_ATTENDED_UNATTENDED).getMessage()
            + formattedMinutes;
        } else {
          formattedHrsMinutes = formattedHrs + CPMConstants.kSpace
            + new LocalisableString(ROSTER.TEXT_ATTENDANCE_TRACKING_HOURS_ATTENDED_UNATTENDED).getMessage();
        }
      } else if (!CPMConstants.kEmptyString.equals(formattedMinutes)) {

        formattedHrsMinutes = formattedMinutes;

      }
    }

    return formattedHrsMinutes;
  }

  /**
   * Validates at least one attendance records should be present when user tries
   * to perform a save action and attendance not entered but other details are
   * entered.
   *
   * @param dailyAttendanceDetailsList
   * List containing the daily attendance correction details.
   * @param attendanceConfig
   * Hours enabled configuration for the attendance.          
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void validateAttendanceRecordsExists(
    final DailyAttendanceDetailsList dailyAttendanceDetailsList, final boolean attendanceConfig)
    throws AppException, InformationalException {

    int recordCounter = 0;

    for (DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {
      // BEGIN, CR00199859, ASN
      if (attendanceConfig) {
        // END, CR00199859
        boolean checkHoursAttended = false;
        boolean checkHoursAbsent = false;
       
        if (dailyAttendanceDetails.dtls.absenceReason.trim().length() > 0
          || dailyAttendanceDetails.dtls.totalHours.trim().length() > 0
          || dailyAttendanceDetails.dtls.totalMinutes.trim().length() > 0) {
          checkHoursAttended = true;
        }

        if (dailyAttendanceDetails.dtls.hoursAbsent.trim().length() > 0
          || dailyAttendanceDetails.dtls.minutesAbsent.trim().length() > 0) {
          checkHoursAbsent = true;
        }
        if (0 == dailyAttendanceDetails.dtls.attendance.trim().length()
          && (checkHoursAttended || checkHoursAbsent)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XFV_DAILY_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
          ValidationHelper.failIfErrorsExist();
        }
        // BEGIN, CR00199859, ASN
      } else {
        if (0 == dailyAttendanceDetails.dtls.attendance.trim().length()
          && dailyAttendanceDetails.dtls.absenceReason.trim().length() > 0) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_FOR_HOURS_DISABLED_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);

          ValidationHelper.failIfErrorsExist();
        }
      }
      // END, CR00199859

      if (StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.attendance)) {

        recordCounter = recordCounter + 1;
      }
    }
     
    if (recordCounter == dailyAttendanceDetailsList.details.size()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 4);
      ValidationHelper.failIfErrorsExist();
    }
  }
  
  /**
   * Generates daily attendance correction for a client who is added to a
   * roster, for each day of the roster line item period in case no daily
   * attendance correction records exists in the system for a service date.
   *
   * @param prliCorrection
   * Contains provider roster line item correction details.
   * @param isReporting
   * Checks the value of 'Reporting' indicator.
   * @param isPlannedUnitsDefaulted
   * Checks the value of 'Planned Units Defaulted' indicator.
   * @param startDate
   * Service date for which records need to be generated.
   *
   * @return List of Daily Attendance correction details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected DailyAttendanceDetails generateUnstoredDailyAttendanceDetails(
    final PRLICorrection prliCorrection, final boolean isReporting,
    final boolean isPlannedUnitsDefaulted, final Date startDate)
    throws AppException, InformationalException {

    DailyAttendanceDetails dailyAttendanceDetails = new DailyAttendanceDetails();

    dailyAttendanceDetails.dtls.rosterLineItemID = prliCorrection.getProviderRosterLineItem().getRosterLineItemID();
    
    ArrayList<Date> serviceDateList = new ArrayList<Date>();

    serviceDateList = serviceDatesForActiveDailyAttendance(prliCorrection);

    // BEGIN, CR00303745, SSK
    // BEGIN, CR00313390, ASN
    dailyAttendanceDetails.serviceDateString = curam.util.resources.Locale.getFormattedDateTime(
      startDate.getDateTime(), curam.util.resources.Locale.Date_ymd);
    // END, CR00313390
    
    // END, CR00303745

    if (isReporting) {
      dailyAttendanceDetails.dtls.unitsAttended = (short) 0;
      dailyAttendanceDetails.dtls.unitsUnattended = (short) 0;

    }
    if (0 == dailyAttendanceDetails.dtls.unitsAttended) {
      dailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
    } else {
      dailyAttendanceDetails.unitsAttendedString = String.valueOf(
        dailyAttendanceDetails.dtls.unitsAttended);
    }
    if (0 == dailyAttendanceDetails.dtls.unitsUnattended) {
      dailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
    } else {
      dailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
        dailyAttendanceDetails.dtls.unitsUnattended);
    }
    dailyAttendanceDetails.dtls.creationDate = Date.getCurrentDate();
    
    // BEGIN, CR00208241, ASN
    Set<PRLISALILink> prliSALILinks = prliSALILinkDAO.searchByProviderRosterLineItem(
      prliCorrection.getProviderRosterLineItem());

    for (final PRLISALILink prliSALILink : prliSALILinks) {

      if (null != prliSALILink.getServiceAuthorizationLineItem()) {
      
        // BEGIN, CR00206362, ASN
        if (1
          == prliSALILink.getServiceAuthorizationLineItem().getDateRange().length()
            && prliSALILink.getServiceAuthorizationLineItem().getDateRange().contains(
              startDate)) {
          // END, CR00206362
          int expectedUnits = 0;

          if (isReporting) {
            expectedUnits = prliSALILink.getServiceAuthorizationLineItem().getUnitsAuthorized();
            dailyAttendanceDetails.dtls.expectedUnits = (short) expectedUnits;

            if (0 == dailyAttendanceDetails.dtls.expectedUnits) {
              dailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
            } else {
              dailyAttendanceDetails.expectedUnitsString = String.valueOf(
                expectedUnits);
            }
          }

          if (isPlannedUnitsDefaulted && 0 == serviceDateList.size()) {

            if (isReporting) {
              if (startDate.before(Date.getCurrentDate().addDays(1))) {
                dailyAttendanceDetails.dtls.unitsAttended = (short) expectedUnits;
                dailyAttendanceDetails.unitsAttendedString = String.valueOf(
                  expectedUnits);

                dailyAttendanceDetails.dtls.attendance = ATTENDANCEEntry.PRESENT.getCode();
              }
            }
          }
        }
      }
    }
    // END, CR00208241
    return dailyAttendanceDetails;
  }

  /**
   * Generates daily attendance correction for a client who is added to a
   * roster, for each day of the roster line item period in case daily
   * attendance correction records exists in the system.
   *
   * @param dailyAttendanceCorrection
   * Contains Daily attendance correction details.
   *
   * @return List of Daily Attendance correction details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected DailyAttendanceDetails storedDailyAttendanceDetails(
    final DailyAttendanceCorrection dailyAttendanceCorrection)
    throws AppException, InformationalException {
    
    final DailyAttendanceDetails storedDailyAttendanceDetails = new DailyAttendanceDetails();
    
    // BEGIN, CR00303745, SSK
    storedDailyAttendanceDetails.serviceDateString = curam.util.resources.Locale.getFormattedDateTime(
      dailyAttendanceCorrection.getServiceDate().getDateTime(),
      curam.util.resources.Locale.Date_ymd);
    // END, CR00303745
    
    // BEGIN, CR00304523, SSK
    storedDailyAttendanceDetails.dtls.serviceDate = dailyAttendanceCorrection.getServiceDate();
    // END, CR00304523

    storedDailyAttendanceDetails.dtls.attendance = dailyAttendanceCorrection.getAttendance().getCode();
    storedDailyAttendanceDetails.dtls.absenceReason = dailyAttendanceCorrection.getAbsenceReason().getCode();
    storedDailyAttendanceDetails.dtls.serviceDate = dailyAttendanceCorrection.getServiceDate();
    storedDailyAttendanceDetails.dtls.unitsAttended = dailyAttendanceCorrection.getUnitsAttended();
    storedDailyAttendanceDetails.dtls.unitsUnattended = dailyAttendanceCorrection.getUnitsUnattended();
    storedDailyAttendanceDetails.dtls.dailyAttendanceID = dailyAttendanceCorrection.getID();
    storedDailyAttendanceDetails.dtls.versionNo = dailyAttendanceCorrection.getVersionNo();
    storedDailyAttendanceDetails.dtls.rosterLineItemID = dailyAttendanceCorrection.getPRLICorrection().getID();

    if (null != dailyAttendanceCorrection.getDailyAttendance()) {

      if (0
        == dailyAttendanceCorrection.getDailyAttendance().getExpectedUnits()) {
        storedDailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
      } else {
        storedDailyAttendanceDetails.expectedUnitsString = String.valueOf(
          dailyAttendanceCorrection.getDailyAttendance().getExpectedUnits());
      }
    } else {
      storedDailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
    }
    if (0 == dailyAttendanceCorrection.getUnitsAttended()) {
      storedDailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
    } else {
      storedDailyAttendanceDetails.unitsAttendedString = String.valueOf(
        dailyAttendanceCorrection.getUnitsAttended());
    }
    if (0 == dailyAttendanceCorrection.getUnitsUnattended()) {
      storedDailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
    } else {
      storedDailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
        dailyAttendanceCorrection.getUnitsUnattended());
    }
    // BEGIN, CR00228146, ASN
    storedDailyAttendanceDetails.dtls.numHoursAttended = dailyAttendanceCorrection.getNumOfHoursAttended();
    storedDailyAttendanceDetails.dtls.numMinutesAttended = dailyAttendanceCorrection.getNumOfMinutesAttended();
    storedDailyAttendanceDetails.dtls.numHoursAbsent = dailyAttendanceCorrection.getNumOfHoursAbsent();
    storedDailyAttendanceDetails.dtls.numMinutesAbsent = dailyAttendanceCorrection.getNumOfMinutesAbsent();
    // END, CR00228146
    return storedDailyAttendanceDetails;
  }

  // END, CR00198730
  
  // BEGIN, CR00199859, ASN
  /**
   * Validates at least one attendance records should be present when user tries
   * to perform a save action and attendance not entered but other details are
   * entered.
   *
   * @param dailyAttendanceDetailsList
   * List containing the daily attendance correction details.         
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void validateUtilizationRecordsExists(
    final DailyAttendanceDetailsList dailyAttendanceDetailsList)
    throws AppException, InformationalException {

    int recordCounter = 0;

    for (DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {
      
      if (0 == dailyAttendanceDetails.dtls.attendance.trim().length()
        && (dailyAttendanceDetails.dtls.absenceReason.trim().length() > 0
          || dailyAttendanceDetails.dtls.unitsAttended > 0
          || dailyAttendanceDetails.dtls.unitsUnattended > 0)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_ATTEDANCE_MANDATORY_WHEN_OTHER_DETAILS_SPECIFIED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
      }
      
      if (dailyAttendanceDetails.dtls.attendance.equals(
        ATTENDANCEEntry.PRESENT.getCode())
          || dailyAttendanceDetails.dtls.attendance.equals(
            ATTENDANCEEntry.PARTIALLYPRESENT.getCode())) {

        if (dailyAttendanceDetails.dtls.unitsAttended < 0) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_ATTENDED_MUST_BE_GREATER_THAN_0_IF_PRESENT_OR_PARTIALLYPRESENT(
              ATTENDANCEEntry.PRESENT.toUserLocaleString(),
              ATTENDANCEEntry.PARTIALLYPRESENT.toUserLocaleString()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              2);

        } else if (0 == dailyAttendanceDetails.dtls.unitsAttended) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_ATTENDED_CANNOT_BE_0_IF_PRESENT_OR_PARTIALLYPRESENT(
              ATTENDANCEEntry.PRESENT.toUserLocaleString(),
              ATTENDANCEEntry.PARTIALLYPRESENT.toUserLocaleString()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              2);
        }

        if (dailyAttendanceDetails.dtls.attendance.equals(
          ATTENDANCEEntry.PRESENT.getCode())) {

          if (dailyAttendanceDetails.dtls.unitsUnattended != 0) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_UNATTENDED_MUST_BE_0_IF_PRESENT(
                ATTENDANCEEntry.PRESENT.toUserLocaleString()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                2);
          }
        } else {

          if (dailyAttendanceDetails.dtls.unitsUnattended <= 0) {

            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_UNATTENDED_MUST_BE_GREATER_THAN_0_IF_NOT_PRESENT(
                ATTENDANCEEntry.PRESENT.toUserLocaleString()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                4);
          }
          if (dailyAttendanceDetails.dtls.absenceReason.trim().length() == 0) {

            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_ABSENCE_REASON_MUST_BE_ENTERED(
                ATTENDANCEEntry.PRESENT.toUserLocaleString()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                6);
          }
        }
      } else if (dailyAttendanceDetails.dtls.attendance.equals(
        ATTENDANCEEntry.ABSENT.getCode())) {

        if (0 == dailyAttendanceDetails.dtls.absenceReason.trim().length()) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_ABSENCE_REASON_MUST_BE_ENTERED(
              ATTENDANCEEntry.PRESENT.toUserLocaleString()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              5);
        }

        if (dailyAttendanceDetails.dtls.unitsAttended != 0) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_ATTENDED_MUST_BE_0_UNLESS_PRESENT_OR_PARTIALLYPRESENT(
              ATTENDANCEEntry.PRESENT.toUserLocaleString(),
              ATTENDANCEEntry.PARTIALLYPRESENT.toUserLocaleString()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              2);
        }

        if (dailyAttendanceDetails.dtls.unitsUnattended <= 0) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            DAILYATTENDANCECORRECTIONExceptionCreator.ERR_DAILYATTENDANCECORRECTION_XRV_UNITS_UNATTENDED_MUST_BE_GREATER_THAN_0_IF_NOT_PRESENT(
              ATTENDANCEEntry.PRESENT.toUserLocaleString()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              5);
        }

      }
    
      if (StringUtil.isNullOrEmpty(dailyAttendanceDetails.dtls.attendance)) {

        recordCounter = recordCounter + 1;
      }
    }
     
    if (recordCounter == dailyAttendanceDetailsList.details.size()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_ATTENDANCE_ONEDAY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 5);
    
    }
    
    ValidationHelper.failIfErrorsExist();
    
  }

  // END, CR00199859
  
  // BEGIN, CR00314944, SSK
  /**
   * Checks whether the hours is enabled for daily attendance tracking
   * configuration for the service associated with the provider roster line
   * item.
   *
   * @param providerRosterLineItem
   * Provider roster line item for which hours enabled configuration is
   * to be determined.
   *
   * @return True if hours is enabled on daily attendance configuration.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected boolean isHoursDailyAttendanceConfigured(
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {

    ServiceOffering serviceOffering = providerRosterLineItem.getRoster().getServiceOffering();
    SOAttendanceConfiguration attendanceConfiguration = soAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      serviceOffering, providerRosterLineItem.getRoster().getDateGenerated());

    if (attendanceConfiguration != null) {
      return attendanceConfiguration.isHoursEnabled();
         
    }
    return false;
  }
  
  // END, CR00314944
  
  // BEGIN, CR00320064, SSK
  /**
   * Validates if the units attended/units not attended is less than or equal to
   * 24.
   *
   * @param providerRosterLineItem
   * Contains provider roster line item details.
   * @param dailyAttendanceDetailsList
   * List of daily attendance details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateDailyAttendanceUnits(
    final ProviderRosterLineItem providerRosterLineItem,
    final DailyAttendanceDetailsList dailyAttendanceDetailsList)
    throws InformationalException, AppException {

    if (UnitOfMeasureEntry.HOUR.equals(
      providerRosterLineItem.getRoster().getServiceOffering().getUnitOfMeasure())) {
      for (final DailyAttendanceDetails dailyAttendanceDetails : dailyAttendanceDetailsList.details.items()) {

        if (CPMConstants.kHoursInDay
          <= dailyAttendanceDetails.dtls.unitsAttended) {
          ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_HOURS_ATTENDED_MUST_LESS_OR_EQUAL_T0_24(
              dailyAttendanceDetails.dtls.unitsAttended
                + CPMConstants.kEmptyString),
                ValidationManagerConst.kSetTwo,
                3);
          break;
        } else if (CPMConstants.kHoursInDay
          <= dailyAttendanceDetails.dtls.unitsUnattended) {
          ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XFV_HOURS_UNATTENDED_MUST_LESS_OR_EQUAL_T0_24(
              dailyAttendanceDetails.dtls.unitsUnattended
                + CPMConstants.kEmptyString),
                ValidationManagerConst.kSetTwo,
                3);
          break;
        }
      }

    }
    ValidationHelper.failIfErrorsExist();

  }

  // END, CR00320064

}
