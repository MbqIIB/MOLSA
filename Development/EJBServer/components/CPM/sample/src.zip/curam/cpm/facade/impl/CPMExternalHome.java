/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import curam.core.facade.fact.WorkAllocationFactory;
import curam.core.fact.SystemUserFactory;
import curam.cpm.facade.struct.ExternalUserKey;
import curam.cpm.facade.struct.ReadExternalHomeDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Process class used to read the External User home page details
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is no longer used. See release note:
 * CR00226000.
 */
@Deprecated
public abstract class CPMExternalHome extends curam.cpm.facade.base.CPMExternalHome {

  // __________________________________________________________________________
  /**
   * Reads the home page details for the current External User.
   *
   * @param key
   * External User key
   *
   * @return the home page details
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam V6.0.
   * This method is deprecated as it is no longer used. See release note:
   * CR00226000.
   */
  @Deprecated
  public ReadExternalHomeDetails readApplicationHome(ExternalUserKey key)
    throws AppException, InformationalException {
    // Return object
    ReadExternalHomeDetails readExternalHomeDetails = new ReadExternalHomeDetails();

    // Get the tasks list
    readExternalHomeDetails.workAllocationTaskAndActivityForUserDetails = WorkAllocationFactory.newInstance().listTaskAndActivitiesForCurrentUser();

    ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.key.userName = SystemUserFactory.newInstance().getUserDetails().userName;

    // Get context details
    // BEGIN, CR00236076, AK
    readExternalHomeDetails.context = curam.cpm.facade.fact.CPMExternalUserAccessFactory.newInstance().readUser(key).context;
    // END, CR00236076

    return readExternalHomeDetails;
  }

}
