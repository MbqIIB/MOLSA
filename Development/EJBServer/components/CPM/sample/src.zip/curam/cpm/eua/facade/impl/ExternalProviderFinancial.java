/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import curam.core.struct.ConcernRoleKey;
import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.facade.fact.ProviderFinancialFactory;
import curam.cpm.facade.intf.ProviderFinancial;
import curam.cpm.facade.struct.RetrievePaymentHistoryDetailsList;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for Provider Financials
 * through the External User Access application
 */
public abstract class ExternalProviderFinancial extends curam.cpm.eua.facade.base.ExternalProviderFinancial {

  // ___________________________________________________________________________
  /**
   * This method lists all the payments for the Provider
   *
   * @param key - this contains the concern Role ID for the provider
   * @return This contains a list of payment history details for the 
   * provider
   *
   * @throws AppException
   *
   * @throws InformationalException
   */
  public RetrievePaymentHistoryDetailsList listPaymentsForProvider(
    ConcernRoleKey key) 
    throws AppException, InformationalException {

    ProviderFinancial providerFinancial = ProviderFinancialFactory.newInstance();
    
    ProviderKey providerKey = new ProviderKey();

    providerKey.providerConcernRoleID = key.concernRoleID;
    
    // call security check to ensure that the user has the rights to view
    // this information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();
    
    // set the key
    externalSecurityKey.concernRoleKey = key;
    externalSecurityKey.viewProviderGroupDetailsInd = false;
    
    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    return providerFinancial.listPaymentsForProvider(providerKey);
    
  }
}
