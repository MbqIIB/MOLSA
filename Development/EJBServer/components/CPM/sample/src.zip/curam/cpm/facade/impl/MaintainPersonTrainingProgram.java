/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.TRAININGPROGRAMPARTYSTATUSEntry;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.TrainingPartyCreateDetails;
import curam.cpm.facade.struct.TrainingPartyDetails;
import curam.cpm.facade.struct.TrainingProgramAndMemberKey;
import curam.cpm.facade.struct.TrainingProgramCompleteDetails;
import curam.cpm.facade.struct.TrainingProgramCompletedDetails;
import curam.cpm.facade.struct.TrainingProgramConcernRoleVersionKey;
import curam.cpm.facade.struct.TrainingProgramList;
import curam.cpm.facade.struct.TrainingProgramMemberUpdateDetails;
import curam.cpm.facade.struct.TrainingProgramPartyCompletedDetails;
import curam.cpm.facade.struct.TrainingProgramPartyWaiverDetails;
import curam.cpm.facade.struct.TrainingProgramSummaryDetails;
import curam.cpm.facade.struct.TrainingProgramSummaryDetailsList;
import curam.cpm.facade.struct.TrainingSummaryDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ConcernRoleKey;
import curam.cpm.sl.entity.struct.TrainingKey;
import curam.cpm.sl.entity.struct.TrainingProgramKey;
import curam.cpm.sl.entity.struct.TrainingProgramMemberKey;
import curam.cpm.sl.entity.struct.TrainingServiceOfferingDtls;
import curam.message.TRAININGPROGRAM;
import curam.message.impl.TRAININGPROGRAMExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.TrainingCompletionEntry;
import curam.serviceoffering.impl.TrainingServiceOfferingDAO;
import curam.training.impl.PersonTrainingProgram;
import curam.training.impl.Training;
import curam.training.impl.TrainingCredit;
import curam.training.impl.TrainingCreditDAO;
import curam.training.impl.TrainingDAO;
import curam.training.impl.TrainingProgram;
import curam.training.impl.TrainingProgramDAO;
import curam.training.impl.TrainingProgramMember;
import curam.training.impl.TrainingProgramMemberDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * Facade layer class having API for managing Person training program.
 *
 */
public abstract class MaintainPersonTrainingProgram extends curam.cpm.facade.base.MaintainPersonTrainingProgram {

  /**
   * TrainingProgram DAO object.
   */
  @Inject
  protected TrainingProgramDAO trainingProgramDAO;

  /**
   * TrainingProgramMember DAO object.
   */
  @Inject
  protected TrainingProgramMemberDAO trainingProgramMemberDAO;

  /**
   * providerDAO of Provider
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to Training DAO
   */
  @Inject
  protected TrainingDAO trainingDAO;

  /**
   * Reference to Training Service Offering DAO
   */
  @Inject
  protected TrainingServiceOfferingDAO trainingServiceOfferingDAO;

  /**
   * Reference to Approve Person Training Program Strategy
   */
  @Inject
  protected PersonTrainingProgram personTrainingProgram;

  /**
   * Reference to Concern Role DAO
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Reference to Training Credit DAO.
   */
  @Inject
  protected TrainingCreditDAO trainingCreditDAO;

  // ___________________________________________________________________________
  /**
   * Default constructor
   */
  public MaintainPersonTrainingProgram() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Creates training program for a person.
   *
   * @param details
   * Contains training program details and training provider.
   * @return Training program member key.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TrainingProgramMemberKey createTrainingProgramForPerson(
    TrainingPartyCreateDetails details) throws AppException,
      InformationalException {

    TrainingProgramMemberKey trainingProgramMemberKey = new TrainingProgramMemberKey();

    curam.training.impl.TrainingProgram trainingProgram = setTrainingProgram(
      details);

    // Create training program record.
    trainingProgram.insert();

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();
    ConcernRole concernRole = concernRoleDAO.get(details.concernRoleID);

    trainingProgramMember.setPartyConcernRole(concernRole);
    trainingProgramMember.setCompletion(
      TrainingCompletionEntry.get(details.completion));
    trainingProgramMember.setTrainingProgram(trainingProgram);
    trainingProgramMember.setUnitsRequired(details.unitsRequired);
    trainingProgramMember.setMemberType(CPMConstants.kPerson);

    // Create training program member record.
    trainingProgramMember.insert();

    // set the training program member id in the return struct
    trainingProgramMemberKey.trainingProgramMemberID = trainingProgramMember.getID();

    return trainingProgramMemberKey;
  }

  // ___________________________________________________________________________
  /**
   * Deletes the specified Person Training Program.
   *
   * @param trainingProgramConcernRoleVersionKey
   * Contains Training Program Member ID, Provider Concern Role
   * ID,version number
   * @throws InformationalException
   * {@link TRAININGPROGRAM#ERR_TRAININGPROGRAM_XRV_TRAININGPROGRAM_IS_NOT_ACTIVE_CANNOT_BE_CANCELED} -
   * If training program for provider group member is already deleted.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deletePersonTrainingProgram(
    TrainingProgramConcernRoleVersionKey trainingProgramConcernRoleVersionKey)
    throws AppException, InformationalException {

    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      trainingProgramConcernRoleVersionKey.trainingProgramMemberID);

    if (trainingProgramMember.getLifecycleState().equals(
      TRAININGPROGRAMPARTYSTATUSEntry.CANCELED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_TRAININGPROGRAM_IS_NOT_ACTIVE_CANNOT_BE_CANCELED(
          trainingProgramMember.getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          4);
    }

    // Cancel the Training Program Member.
    trainingProgramMember.cancel(
      trainingProgramConcernRoleVersionKey.trainingProgramMemberVersionNo);

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramMember.getTrainingProgram();

    // Cancel the Training Program.
    trainingProgram.cancel(
      trainingProgramConcernRoleVersionKey.trainingProgramVersionNo);

  }

  // ___________________________________________________________________________
  
  // BEGIN, CR00279651, MR
  /**
   * Retrieves the list of Completed Training Programs for a Person.
   *
   * @param concernRoleKey
   * Contains the ConcernRole ID of the Person.
   *
   * @return List of Completed Training Programs.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link MaintainPersonTrainingProgram#listTrainingProgramForPerson(ConcernRoleKey)}
   * . This method is listing only completed training programs for
   * a person. So the new method is listing completed as well as
   * managed training programs for a person. See release note:
   * CR00279651.
   */
  @Deprecated
  public TrainingProgramList listCompletedTrainingProgramForPerson(
    final ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {
    // END, CR00279651
    TrainingProgramList trainingProgramList = new TrainingProgramList();

    String status = TRAININGPROGRAMPARTYSTATUSEntry.CANCELED.toString();
    Set<curam.training.impl.TrainingProgramMember> trainingProgramMemberDetails = trainingProgramMemberDAO.retrieveMemberTrainingPrograms(
      status, concernRoleKey.concernRoleID);

    // Populate the list of Completed Training Programs for person.
    for (final curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMemberDetails) {
      curam.training.impl.TrainingProgram trainingProgram = trainingProgramMember.getTrainingProgram();

      if (trainingProgram.isManagedThroughAgency() == false) {
        TrainingSummaryDetails trainingSummaryDetails = new TrainingSummaryDetails();

        trainingSummaryDetails.trainingProgramMemberID = trainingProgramMember.getID();
        trainingSummaryDetails.trainingProgramMemberVersionNo = trainingProgramMember.getVersionNo();
        trainingSummaryDetails.referenceNumber = trainingProgram.getReferenceNumber();

        trainingSummaryDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();
        trainingSummaryDetails.trainingProgramID = trainingProgram.getID();

        // BEGIN CR00113139, PDN
        trainingSummaryDetails.trainingProgramDateCompleted = trainingProgramMember.getDateCompleted();
        // END CR00113139

        if (trainingProgram.getTraining() == null) {
          trainingSummaryDetails.trainingName = trainingProgram.getTrainingName();
          trainingSummaryDetails.trainingRegisteredInd = false;
        } else {
          trainingSummaryDetails.trainingName = trainingProgram.getTraining().getName();
          trainingSummaryDetails.trainingID = trainingProgram.getTraining().getID();
          trainingSummaryDetails.trainingRegisteredInd = true;
        }

        trainingProgramList.trainingSummaryList.addRef(trainingSummaryDetails);
      }

    }

    return sortListTrainingPrograms(trainingProgramList);
  }

  // ___________________________________________________________________________
   
  // BEGIN, CR00279651, MR
  /**
   * Retrieves the list of Managed Training Programs for a Person.
   *
   * @param concernRoleKey
   * Contains the ConcernRole ID of the Person.
   * @return List of Managed Training Programs.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link MaintainPersonTrainingProgram#listTrainingProgramForPerson(ConcernRoleKey)}
   * . This method is listing only managed training programs for
   * a person. So the new method is listing managed as well as
   * completed training programs for a person. See release note:
   * CR00279651.
   */
  @Deprecated
  public TrainingProgramList listManagedTrainingProgramForPerson(
    final ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {
    // END, CR00279651
    TrainingProgramList trainingProgramList = new TrainingProgramList();

    curam.training.impl.TrainingProgram trainingProgram = null;

    String status = TRAININGPROGRAMPARTYSTATUSEntry.CANCELED.toString();
    Set<curam.training.impl.TrainingProgramMember> trainingProgramMemberDetails = trainingProgramMemberDAO.retrieveMemberTrainingPrograms(
      status, concernRoleKey.concernRoleID);

    // Populate the list of Managed Training Programs for person.
    for (final curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMemberDetails) {
      trainingProgram = trainingProgramMember.getTrainingProgram();
      if (trainingProgram.isManagedThroughAgency() == true) {

        TrainingSummaryDetails trainingSummaryDetails = new TrainingSummaryDetails();

        trainingSummaryDetails.trainingProgramMemberID = trainingProgramMember.getID();
        trainingSummaryDetails.trainingProgramMemberVersionNo = trainingProgramMember.getVersionNo();
        trainingSummaryDetails.referenceNumber = trainingProgram.getReferenceNumber();
        trainingSummaryDetails.trainingID = trainingProgram.getTraining().getID();
        trainingSummaryDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();

        // BEGIN CR00113139, PDN
        trainingSummaryDetails.trainingProgramDateCompleted = trainingProgramMember.getDateCompleted();
        trainingSummaryDetails.trainingProgramStatus = trainingProgram.getLifecycleState().getCode();
        // END CR00113139

        if (trainingProgram.getTraining() == null) {
          trainingSummaryDetails.trainingName = trainingProgram.getTrainingName();
        } else {
          trainingSummaryDetails.trainingName = trainingProgram.getTraining().getName();
          trainingSummaryDetails.trainingProgramID = trainingProgram.getID();
        }

        if (trainingSummaryDetails.trainingProgramOwnerType.equals(
          CPMConstants.kProvider)) {
          trainingSummaryDetails.trainingProgramOwnerIsProvider = true;
        } else if (trainingSummaryDetails.trainingProgramOwnerType.equals(
          CPMConstants.kProviderGroup)) {
          trainingSummaryDetails.trainingProgramOwnerIsProviderGroup = true;
        } else {
          trainingSummaryDetails.trainingProgramOwnerIsMember = true;
        }

        trainingSummaryDetails.trainingProgramOwnerType = trainingProgramMember.getTrainingProgramOwnerType();

        trainingSummaryDetails.trainingProgramOwnerID = trainingProgram.getTrainingProgramOwner().getID();

        trainingProgramList.trainingSummaryList.addRef(trainingSummaryDetails);
      }

    }

    return sortListTrainingPrograms(trainingProgramList);

  }

  // BEGIN, CR00279651, MR
  /**
   * Replaces the deprecated methods
   * {@link MaintainPersonTrainingProgram#listCompletedTrainingProgramForPerson(ConcernRoleKey)}
   * and {@link MaintainPersonTrainingProgram#listManagedTrainingProgramForPerson(ConcernRoleKey)}.
   * <p>
   * Lists all completed as well as managed training programs for a given person.
   *
   * @param concernRoleKey
   * Contains the concernRoleID for which training programs are to be retrieved.
   *
   * @return List of training programs for person.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TrainingProgramSummaryDetailsList listTrainingProgramForPerson(
    final ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {
    final TrainingProgramList trainingProgramList = new TrainingProgramList();

    TrainingProgram trainingProgram = null;

    final String status = TRAININGPROGRAMPARTYSTATUSEntry.CANCELED.toString();
    final Set<TrainingProgramMember> trainingProgramMember = trainingProgramMemberDAO.retrieveMemberTrainingPrograms(
      status, concernRoleKey.concernRoleID);

    // Populate the list of Training Programs for person.
    for (final TrainingProgramMember trainingProgramMemberDetails : trainingProgramMember) {
      trainingProgram = trainingProgramMemberDetails.getTrainingProgram();

      TrainingSummaryDetails trainingSummaryDetails = new TrainingSummaryDetails();

      trainingSummaryDetails.trainingProgramMemberID = trainingProgramMemberDetails.getID();
      trainingSummaryDetails.trainingProgramMemberVersionNo = trainingProgramMemberDetails.getVersionNo();
      trainingSummaryDetails.trainingProgramID = trainingProgram.getID();
      trainingSummaryDetails.referenceNumber = trainingProgram.getReferenceNumber();
      trainingSummaryDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();
      trainingSummaryDetails.trainingProgramDateCompleted = trainingProgramMemberDetails.getDateCompleted();
      trainingSummaryDetails.trainingProgramStatus = trainingProgram.getLifecycleState().getCode();

      if (null == trainingProgram.getTraining()) {
        trainingSummaryDetails.trainingName = trainingProgram.getTrainingName();
        trainingSummaryDetails.trainingRegisteredInd = false;
      } else {
        trainingSummaryDetails.trainingName = trainingProgram.getTraining().getName();
        trainingSummaryDetails.trainingID = trainingProgram.getTraining().getID();
        trainingSummaryDetails.trainingRegisteredInd = true;
      }

      if (trainingProgram.isManagedThroughAgency() == true) {
        trainingSummaryDetails.trainingProgramOwnerType = trainingProgramMemberDetails.getTrainingProgramOwnerType();

        trainingSummaryDetails.trainingProgramOwnerID = trainingProgram.getTrainingProgramOwner().getID();

        if (CPMConstants.kProvider.equals(
          trainingSummaryDetails.trainingProgramOwnerType)) {
          trainingSummaryDetails.trainingProgramOwnerIsProvider = true;
        } else if (CPMConstants.kProviderGroup.equals(
          trainingSummaryDetails.trainingProgramOwnerType)) {
          trainingSummaryDetails.trainingProgramOwnerIsProviderGroup = true;
        } else {
          trainingSummaryDetails.trainingProgramOwnerIsMember = true;
        }
      }
      trainingProgramList.trainingSummaryList.addRef(trainingSummaryDetails);
    }

    final TrainingProgramSummaryDetailsList trainingProgramSummaryDetailsList = new TrainingProgramSummaryDetailsList();

    setTrainingProgramList(trainingProgramList,
      trainingProgramSummaryDetailsList);
    return sortTrainingPrograms(trainingProgramSummaryDetailsList);
  }

  // END, CR00279651

  // ___________________________________________________________________________
  /**
   * Waive a training program for a Person.
   *
   * @param details
   * Contains the Training Program Waiver details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void waivePersonTrainingProgram(
    TrainingProgramPartyWaiverDetails details) throws AppException,
      InformationalException {

    // Read the Training Program Member record.
    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    // Sets the waiver expiry date
    trainingProgramMember.setWaiverExpiryDate(details.waiverExpiryDate);

    // waive of the training program.
    trainingProgramMember.waiveTrainingMemberProgram(details.partyVersionNo);

  }

  // ___________________________________________________________________________
  /**
   * Records a training program for a person that was completed outside the
   * agency.
   *
   * @param details
   * Contains the training program completed details for recording.
   * @return TrainingProgramMemberKey Contains the training program member key
   * which is recorded.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TrainingProgramMemberKey recordCompletedPersonTrainingProgram(
    TrainingProgramCompletedDetails details) throws AppException,
      InformationalException {
    // training program instance
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.newInstance();
    // training program member instance
    curam.training.impl.TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.newInstance();

    // set the training program details
    setRecordCompletedTrainingProgramDetails(details, trainingProgram);
    trainingProgram.recordCompletedTrainingProgramForPerson();

    details.trainingProviderDetails.trainingProgramID = trainingProgram.getID();
    // set the person training program member details
    setRecordCompletedTrainingProgramMemberDetails(details,
      trainingProgramMember);
    trainingProgramMember.recordCompletedTrainingMemberProgram();

    TrainingProgramMemberKey trainingProgramMemberKey = new TrainingProgramMemberKey();

    trainingProgramMemberKey.trainingProgramMemberID = trainingProgramMember.getID();

    return trainingProgramMemberKey;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the training service offering details.
   *
   * @param key
   * Contains service offering trainings.
   * @return Training program party details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TrainingPartyCreateDetails retrievePersonTrainingProgram(
    TrainingKey key) throws AppException, InformationalException {

    TrainingPartyCreateDetails trainingPartyCreateDetails = new TrainingPartyCreateDetails();

    Training training = trainingDAO.get(key.trainingID);

    trainingPartyCreateDetails.trainingID = training.getID();
    trainingPartyCreateDetails.trainingName = training.getName();
    trainingPartyCreateDetails.authorizedFrom = Date.getCurrentDate();
    trainingPartyCreateDetails.completion = TrainingCompletionEntry.RECOMMENDED.getCode();

    TrainingKey trainingKey = new TrainingKey();

    trainingKey.trainingID = key.trainingID;

    TrainingServiceOfferingDtls trainingServiceOfferingDtls = trainingServiceOfferingDAO.readByTraining(
      trainingKey);

    if (trainingServiceOfferingDtls != null
      && trainingServiceOfferingDtls.trainingServiceOfferingID != 0) {
      trainingPartyCreateDetails.unitsRequired = trainingServiceOfferingDtls.unitsRequired;
    }

    return trainingPartyCreateDetails;
  }

  // ___________________________________________________________________________
  /**
   * Updates the completed training program for person.
   *
   * @param details
   * Training program details to be updated.
   * @return Training program member key.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TrainingProgramMemberKey updateCompletedPersonTrainingProgram(
    TrainingProgramCompleteDetails details) throws AppException,
      InformationalException {

    // Update the training program member
    TrainingProgramMemberKey trainingProgramMemberKey = new TrainingProgramMemberKey();

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    trainingProgramMember.setCreditsAchieved(details.creditsAchieved);
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setUnitsCompleted(details.unitsCompleted);

    trainingProgramMember.modify(details.partyVersionNo);

    trainingProgramMemberKey.trainingProgramMemberID = details.trainingProgramMemberID;

    return trainingProgramMemberKey;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves training program details not managed through agency for a person.
   *
   * @param key
   * Training program key.
   * @return Training program details for a person.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TrainingProgramPartyCompletedDetails viewMemberCompletedTrainingNotManagedByAgency(
    TrainingProgramKey key) throws AppException, InformationalException {

    TrainingProgramPartyCompletedDetails trainingProgramPartyCompletedDetails = new TrainingProgramPartyCompletedDetails();

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      key.trainingProgramID);

    Set<curam.training.impl.TrainingProgramMember> trainingProgramMembers = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
      key.trainingProgramID);

    // Set the provider member training program details.
    for (curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMembers) {
      trainingProgramPartyCompletedDetails.status = trainingProgramMember.getLifecycleState().getCode();
      trainingProgramPartyCompletedDetails.dateCompleted = trainingProgramMember.getDateCompleted();
      trainingProgramPartyCompletedDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
      trainingProgramPartyCompletedDetails.trainingProgramMemberID = trainingProgramMember.getID();
      trainingProgramPartyCompletedDetails.trainingProgramMemberVersionNo = trainingProgramMember.getVersionNo();
      trainingProgramPartyCompletedDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
    }

    trainingProgramPartyCompletedDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();

    if (trainingProgram.getTraining() == null) {
      trainingProgramPartyCompletedDetails.trainingName = trainingProgram.getTrainingName();
      trainingProgramPartyCompletedDetails.trainingRegisteredInd = false;
    } else {
      trainingProgramPartyCompletedDetails.trainingName = trainingProgram.getTraining().getName();
      trainingProgramPartyCompletedDetails.trainingID = trainingProgram.getTraining().getID();
      trainingProgramPartyCompletedDetails.trainingRegisteredInd = true;
    }
    trainingProgramPartyCompletedDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();

    if (trainingProgram.getTrainingProvider() != null) {
      trainingProgramPartyCompletedDetails.trainingProviderName = trainingProgram.getTrainingProvider().getName();
    } else {
      trainingProgramPartyCompletedDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
    }
    trainingProgramPartyCompletedDetails.trainingProgramVersionNo = trainingProgram.getVersionNo();

    return trainingProgramPartyCompletedDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves training program details for a provider member.
   *
   * @param key
   * contains training program ID and member concern role ID.
   *
   * @return TrainingPartyDetails contains training program details for a
   * provider member.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TrainingPartyDetails viewPersonTrainingProgram(
    TrainingProgramAndMemberKey key) throws AppException,
      InformationalException {
    TrainingPartyDetails partyDetails = new TrainingPartyDetails();

    curam.training.impl.TrainingProgram trainingProgram = null;

    Set<curam.training.impl.TrainingProgramMember> trainingProgramMemberDetails = trainingProgramMemberDAO.retrieveTrainingProgramMembers(
      key.trainingProgramID);

    // set training program member details
    for (curam.training.impl.TrainingProgramMember trainingProgramMember : trainingProgramMemberDetails) {
      partyDetails.completion = trainingProgramMember.getCompletion().toString();
      partyDetails.creditsAchieved = trainingProgramMember.getCreditsAchieved();
      if (trainingProgramMember.getCreditsAchieved() > 0) {
        partyDetails.creditsAchievedString = String.valueOf(
          trainingProgramMember.getCreditsAchieved());
      }
      Date completedDate = trainingProgramMember.getDateCompleted();

      partyDetails.dateCompleted = completedDate;
      partyDetails.partyConcernRoleID = trainingProgramMember.getPartyConcernRole().getID();
      partyDetails.partyVersionNo = trainingProgramMember.getVersionNo();
      partyDetails.status = trainingProgramMember.getLifecycleState().toString();
      partyDetails.trainingProgramID = trainingProgramMember.getTrainingProgram().getID();
      partyDetails.trainingProgramMemberID = trainingProgramMember.getID();
      partyDetails.unitsCompleted = trainingProgramMember.getUnitsCompleted();
      if (trainingProgramMember.getUnitsCompleted() > 0) {
        partyDetails.unitsCompletedString = String.valueOf(
          trainingProgramMember.getUnitsCompleted());
      }
      partyDetails.unitsRemaining = trainingProgramMember.getUnitsRequired()
        - trainingProgramMember.getUnitsCompleted();
      partyDetails.unitsRequired = trainingProgramMember.getUnitsRequired();

      // get training program details
      trainingProgram = trainingProgramMember.getTrainingProgram();

      // validTill needs to be calculated for members whose training program
      // are in complete state.
      if (trainingProgramMember.getLifecycleState().equals(
        TRAININGPROGRAMPARTYSTATUSEntry.COMPLETE)) {
        // BEGIN CR00112382, NK
        // Get a list of Training Credit records for this training program
        // member.
        List<TrainingCredit> trainingCredits = trainingCreditDAO.searchBy(
          trainingProgramMember.getTrainingProgram().getTraining());

        // END CR00112382
        // Check if training has training credits associated to
        // it, then calculate valid till field.
        if (trainingCredits.size() > 0) {
          int days = trainingProgram.getTrainingValidDays();

          if (days > 0) {
            partyDetails.validTill = completedDate.addDays(days);
          }
        }
      }
      partyDetails.waiverExpiryDate = trainingProgramMember.getWaiverExpiryDate();

    }
    // set training program details
    partyDetails.trainingProgramDetails.authorizedFrom = trainingProgram.getDateRange().start();
    partyDetails.trainingProgramDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();
    partyDetails.trainingProgramDetails.toBeCompletedBy = trainingProgram.getDateRange().end();
    if (trainingProgram.getTraining() != null) {
      partyDetails.trainingProgramDetails.trainingName = trainingProgram.getTraining().getName();
      partyDetails.trainingProgramDetails.trainingID = trainingProgram.getTraining().getID();
      partyDetails.trainingProgramDetails.trainingRegisteredInd = true;
    } else {
      partyDetails.trainingProgramDetails.trainingName = trainingProgram.getTrainingName();
      partyDetails.trainingProgramDetails.trainingRegisteredInd = false;
    }
    partyDetails.trainingProgramDetails.trainingProgramID = trainingProgram.getID();
    partyDetails.trainingProgramDetails.trainingProgramRefNo = trainingProgram.getReferenceNumber();
    if (trainingProgram.getTrainingProvider() != null) {
      partyDetails.trainingProgramDetails.trainingProvider = trainingProgram.getTrainingProvider().getName();
    }
    partyDetails.trainingProgramDetails.unitAmount = trainingProgram.getUnitAmount();
    partyDetails.trainingProgramDetails.versionNo = trainingProgram.getVersionNo();

    return partyDetails;
  }

  // BEGIN, CR00112653, SK
  // ___________________________________________________________________________
  /**
   * Method used by Resource Manager and Resource Manager Supervisor to update
   * the details of a training program for a person.
   *
   * @param details
   * Contains details of Training Program Member to be updated.
   *
   * @return The list of informational messages.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationalMessageList updatePersonTrainingProgram(
    TrainingProgramMemberUpdateDetails details) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();

    setTrainingProgram(details);
    setTrainingProgramMember(details);

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProgramID);

    trainingProgram.modify(details.trainingProgramVersionNo);

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    if (!details.dateCompleted.equals(Date.kZeroDate)
      || details.creditsAchieved != 0 || details.unitsCompleted != 0) {

      // mark training program complete
      informationalMessageList = trainingProgramMember.markTrainingMemberProgramComplete(
        details.trainingProgramMemberVersionNo);
    } else {
      trainingProgramMember.modify(details.trainingProgramMemberVersionNo);
    }

    return informationalMessageList;
  }

  // END, CR00112653


  /**
   * Approves the specified Person Training Program.
   *
   * @param trainingProgramConcernRoleVersionKey
   * Contains the details required to approve the training program for
   * a person.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public void approvePersonTrainingProgram(
    TrainingProgramConcernRoleVersionKey trainingProgramConcernRoleVersionKey)
    throws AppException, InformationalException {

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      trainingProgramConcernRoleVersionKey.trainingProgramMemberID);

    KeyVersionDetails keyVersionDetails = new KeyVersionDetails();

    keyVersionDetails.version = trainingProgramConcernRoleVersionKey.trainingProgramMemberVersionNo;

    personTrainingProgram.approvePersonTrainingProgram(keyVersionDetails,
      trainingProgramMember);
  }

  // ___________________________________________________________________________
  /**
   * Sorts a set of Training Programs by Training Name
   *
   * @param unsortedTrainingPrograms
   * The set of unsorted Training Programs
   * @return Contains a list of Training Programs sorted by Training Name.
   */
  protected TrainingProgramList sortListTrainingPrograms(
    TrainingProgramList unsortedTrainingPrograms) {

    List<TrainingSummaryDetails> trainingSummaryDetailsList = new ArrayList<TrainingSummaryDetails>();

    for (int i = 0; i < unsortedTrainingPrograms.trainingSummaryList.size(); i++) {
      trainingSummaryDetailsList.add(
        unsortedTrainingPrograms.trainingSummaryList.item(i));
    }

    // Sort the unsorted reservations
    Collections.sort(trainingSummaryDetailsList,
      new Comparator<TrainingSummaryDetails>() {
      public int compare(final TrainingSummaryDetails lhs,
        TrainingSummaryDetails rhs) {
        return lhs.trainingName.compareTo(rhs.trainingName);
      }
    });

    TrainingProgramList trainingProgramList = new TrainingProgramList();

    for (TrainingSummaryDetails trainingProgram : trainingSummaryDetailsList) {
      trainingProgramList.trainingSummaryList.addRef(trainingProgram);
    }

    return trainingProgramList;
  }

  // ___________________________________________________________________________
  /**
   * Sets the training program details.
   *
   * @param trainingPartyCreateDetails
   * Contains training program details.
   * @return Training program to be created.
   */
  protected curam.training.impl.TrainingProgram setTrainingProgram(
    TrainingPartyCreateDetails trainingPartyCreateDetails) {

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.newInstance();

    trainingProgram.setTraining(
      trainingDAO.get(trainingPartyCreateDetails.trainingID));
    trainingProgram.setUnitAmount(trainingPartyCreateDetails.unitAmount);

    trainingProgram.setDateRange(
      new DateRange(trainingPartyCreateDetails.authorizedFrom,
      trainingPartyCreateDetails.toBeCompletedBy));
    ConcernRole concernRole = concernRoleDAO.get(
      trainingPartyCreateDetails.concernRoleID);

    trainingProgram.setTrainingProgramOwner(concernRole);
    trainingProgram.setManagedThroughAgency(true);

    trainingProgram.setTrainingProvider(
      providerDAO.get(trainingPartyCreateDetails.trainingProviderID));

    return trainingProgram;
  }

  // ___________________________________________________________________________
  /**
   * Sets the completed provider training program entity details.
   *
   * @param details
   * Contains the training program completed details.
   * @param trainingProgram
   * Instance of an training program.
   */
  protected void setRecordCompletedTrainingProgramDetails(
    TrainingProgramCompletedDetails details,
    curam.training.impl.TrainingProgram trainingProgram) {

    // check is search training found
    if (0 != details.trainingProviderDetails.trainingID) {
      // get the training instance
      Training training = trainingDAO.get(
        details.trainingProviderDetails.trainingID);

      trainingProgram.setTraining(training);
    }
    trainingProgram.setTrainingName(
      details.trainingProviderDetails.trainingName);

    // check search training provider found
    if (0 != details.trainingProviderDetails.trainingProviderID) {
      curam.provider.impl.Provider provider = providerDAO.get(
        details.trainingProviderDetails.trainingProviderID);

      trainingProgram.setTrainingProvider(provider);

    }
    trainingProgram.setTrainingProviderDetails(
      details.trainingProviderDetails.trainingProviderDetails);
    ConcernRole concernRole = concernRoleDAO.get(details.partyConcernRoleID);

    trainingProgram.setTrainingProgramOwner(concernRole);
    trainingProgram.setManagedThroughAgency(false);

  }

  // ___________________________________________________________________________
  /**
   * Sets the completed member training program entity details.
   *
   * @param trainingProgram
   * Instance of an training program member.
   * @param details
   * Contains the training program completed details.
   */
  protected void setRecordCompletedTrainingProgramMemberDetails(
    TrainingProgramCompletedDetails details,
    TrainingProgramMember trainingProgramMember) {

    // get the training program instance
    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProviderDetails.trainingProgramID);

    // set the training program member data
    trainingProgramMember.setTrainingProgram(trainingProgram);
    ConcernRole concernRole = concernRoleDAO.get(details.partyConcernRoleID);

    trainingProgramMember.setPartyConcernRole(concernRole);
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setUnitsCompleted(details.unitsCompleted);
  }

  // ___________________________________________________________________________
  /**
   * Sets the training program details.
   *
   * @param details
   * Training program update details.
   */
  protected void setTrainingProgram(TrainingProgramMemberUpdateDetails details) {

    curam.training.impl.TrainingProgram trainingProgram = trainingProgramDAO.get(
      details.trainingProgramID);

    trainingProgram.setDateRange(
      new DateRange(details.authorizedFrom, details.toBeCompletedBy));
    trainingProgram.setUnitAmount(details.unitAmount);

  }

  // ___________________________________________________________________________
  /**
   * Sets the training program member.
   *
   * @param details
   * Training program update details.
   */
  protected void setTrainingProgramMember(
    TrainingProgramMemberUpdateDetails details) {

    TrainingProgramMember trainingProgramMember = trainingProgramMemberDAO.get(
      details.trainingProgramMemberID);

    trainingProgramMember.setCompletion(
      TrainingCompletionEntry.get(details.completion));
    trainingProgramMember.setDateCompleted(details.dateCompleted);
    trainingProgramMember.setUnitsRequired(details.unitsRequired);

    if (details.creditsAchievedString.length() > 0) {
      try {
        // convert credits achieved string to int
        details.creditsAchieved = Integer.parseInt(
          details.creditsAchievedString);
      } catch (NumberFormatException exception) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_CREDITS_ACHIEVED_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
      }

      if (details.creditsAchieved <= 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_CREDITS_ACHIEVED_GR_THAN_ZERO(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
      }

      trainingProgramMember.setCreditsAchieved(details.creditsAchieved);
    }

    if (details.unitsCompletedString.length() > 0) {
      try {
        // convert credits achieved string to int
        details.unitsCompleted = Integer.parseInt(details.unitsCompletedString);
      } catch (NumberFormatException exception) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_FV_UNITSCOMPLETED_INVALID(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
      }
      trainingProgramMember.setUnitsCompleted(details.unitsCompleted);
    }

  }
  
  // BEGIN, CR00279651, MR  
  /**
   * Sets the training program details of a person.
   *
   * @param trainingProgramList
   * Contains the training program details which needs to be set.
   * @param trainingProgramSummaryDetailsList
   * Contains the struct to which training program details are to be set.
   */
  protected void setTrainingProgramList(
    final TrainingProgramList trainingProgramList,
    final TrainingProgramSummaryDetailsList trainingProgramSummaryDetailsList) {

    for (final TrainingSummaryDetails trainingSummaryDetails :
      trainingProgramList.trainingSummaryList.items()) {
      TrainingProgramSummaryDetails trainingProgramSummaryDetails = new TrainingProgramSummaryDetails();
      final TrainingProgram trainingProgram = trainingProgramDAO.get(
        trainingSummaryDetails.trainingProgramID);

      trainingProgramSummaryDetails.managedThroughAgency = trainingProgram.isManagedThroughAgency();
      trainingProgramSummaryDetails.trainingProgramMemberID = trainingSummaryDetails.trainingProgramMemberID;
      trainingProgramSummaryDetails.trainingProgramMemberVersionNo = trainingSummaryDetails.trainingProgramMemberVersionNo;
      trainingProgramSummaryDetails.referenceNumber = trainingSummaryDetails.referenceNumber;
      trainingProgramSummaryDetails.trainingProgramVersionNo = trainingSummaryDetails.trainingProgramVersionNo;
      trainingProgramSummaryDetails.trainingProgramID = trainingSummaryDetails.trainingProgramID;
      trainingProgramSummaryDetails.trainingProgramDateCompleted = trainingSummaryDetails.trainingProgramDateCompleted;
      trainingProgramSummaryDetails.trainingName = trainingSummaryDetails.trainingName;
      trainingProgramSummaryDetails.trainingRegisteredInd = trainingSummaryDetails.trainingRegisteredInd;
      trainingProgramSummaryDetails.trainingID = trainingSummaryDetails.trainingID;
      trainingProgramSummaryDetails.trainingProgramStatus = trainingSummaryDetails.trainingProgramStatus;
      trainingProgramSummaryDetails.trainingProgramOwnerType = trainingSummaryDetails.trainingProgramOwnerType;
      trainingProgramSummaryDetails.trainingProgramOwnerID = trainingSummaryDetails.trainingProgramOwnerID;
      trainingProgramSummaryDetails.trainingProgramOwnerIsProvider = trainingSummaryDetails.trainingProgramOwnerIsProvider;
      trainingProgramSummaryDetails.trainingProgramOwnerIsProviderGroup = trainingSummaryDetails.trainingProgramOwnerIsProviderGroup;
      trainingProgramSummaryDetails.trainingProgramOwnerIsMember = trainingSummaryDetails.trainingProgramOwnerIsMember;

      if (null != trainingProgram.getTrainingProvider()) {
        trainingProgramSummaryDetails.trainingProviderDetails = trainingProgram.getTrainingProvider().getName();
      } else {
        trainingProgramSummaryDetails.trainingProviderDetails = trainingProgram.getTrainingProviderDetails();
      }
      trainingProgramSummaryDetailsList.trainingProgramSummaryDetails.addRef(
        trainingProgramSummaryDetails);
    }
  }

  /**
   * Sorts a set of training programs by training name.
   *
   * @param unsortedTrainingProgramSummaryDetailsList
   * Contains the set of unsorted training programs.
   *
   * @return A list of training programs sorted by training name.
   */
  protected TrainingProgramSummaryDetailsList sortTrainingPrograms(
    final TrainingProgramSummaryDetailsList unsortedTrainingProgramSummaryDetailsList) {

    List<TrainingProgramSummaryDetails> trainingProgramSummaryDetailsList = new ArrayList<TrainingProgramSummaryDetails>();

    for (final TrainingProgramSummaryDetails trainingProgramSummaryDetails : unsortedTrainingProgramSummaryDetailsList.trainingProgramSummaryDetails.items()) {
      trainingProgramSummaryDetailsList.add(trainingProgramSummaryDetails);
    }

    Collections.sort(trainingProgramSummaryDetailsList,
      new Comparator<TrainingProgramSummaryDetails>() {
      public int compare(final TrainingProgramSummaryDetails lhs,
        TrainingProgramSummaryDetails rhs) {
        return lhs.trainingName.compareTo(rhs.trainingName);
      }
    });

    final TrainingProgramSummaryDetailsList sortedTrainingProgramSummaryDetailsList = new TrainingProgramSummaryDetailsList();

    for (final TrainingProgramSummaryDetails trainingProgramSummaryDetails : trainingProgramSummaryDetailsList) {
      sortedTrainingProgramSummaryDetailsList.trainingProgramSummaryDetails.addRef(
        trainingProgramSummaryDetails);
    }
    return sortedTrainingProgramSummaryDetailsList;
  }
  // END, CR00279651

}
