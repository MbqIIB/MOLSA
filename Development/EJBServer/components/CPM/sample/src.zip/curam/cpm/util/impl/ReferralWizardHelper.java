/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.util.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.REFERRALRELATEDLINKTYPEEntry;
import curam.core.impl.CuramConst;
import curam.cpm.facade.struct.AddReferralContextDetails;
import curam.cpm.facade.struct.AddReferralWizardData;
import curam.datastore.impl.Datastore;
import curam.datastore.impl.Entity;
import curam.message.REFERRAL;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.referral.impl.Referral;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.CodeTable;
import java.util.List;


/**
 * Helper interface for the {@link Referral} creation wizard.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
@ImplementedBy(ReferralWizardHelperImpl.class)
public interface ReferralWizardHelper {

  /**
   * Interface for the {@link ReferralWizardHelper} events processing. These
   * events should be called for the modification of the referral wizard data
   * based on the selected service changing on the {@link ReferralWizard}.
   *
   * @since 6.0
   */
  public abstract class ReferralWizardHelperEvent {

    /**
     * This should be called for any pre processing required to the data stored
     * on the {@link curam.datastore.impl.Datastore} for the referral wizard in reaction to the
     * updated service details passed in from the client.
     *
     * @param dtls
     * struct containing the updated service details passed in from the
     * client
     */
    @SuppressWarnings(CuramConst.kUnused)
    public void preUpdateReferralWizardDataBasedOnServiceChange(
      final AddReferralWizardData dtls) {// empty implementation that listeners can override
    }

    /**
     * This should be called for any post processing required to the data stored
     * on the {@link curam.datastore.impl.Datastore} for the referral wizard in reaction to the
     * updated service details passed in from the client.
     *
     * @param dtls
     * struct containing the updated service details passed in from the
     * client
     */
    @SuppressWarnings(CuramConst.kUnused)
    public void postUpdateReferralWizardDataBasedOnServiceChange(
      final AddReferralWizardData dtls) {// empty implementation that listeners can override
    }
  }

  /**
   * Creates a new {@link Referral} record from the data store {@link Entity}
   * data populated from the wizard.
   *
   * @param referralEntity
   * the data store {@link Entity} instance contain the details to be
   * used for the creation of this referral
   * @param relatedID
   * The unique identifier of the related object this referral is being
   * created in relation to
   * @param referralRelatedLinkType
   * {@link CodeTable} entry identifying the type of record this
   * referral is being created in relation to
   * @return instance of the newly created {@link Referral}
   * @throws AppException
   * Generic Application Exception
   * @throws InformationalException
   * Generic Information Exception
   */
  Referral createReferral(final Entity referralEntity, Long relatedID,
    REFERRALRELATEDLINKTYPEEntry referralRelatedLinkType)
    throws AppException, InformationalException;

  /**
   * Validate the entered service details. The following exceptions are thrown:
   * <ul>
   * <li>{@link REFERRAL#ERR_XFV_SERVICE_NAME_OR_SERVICE_MUST_BE_ENTERED}, if
   * neither a service name or service offering is entered</li>
   * <li>
   * {@link REFERRAL#ERR_XFV_SERVICE_NAME_MUST_NOT_BE_ENTERED_IF_SERVICE_SELECTED}
   * , if both a service name and service offering is entered</li>
   * </ul>
   *
   * @param dtls
   * The struct containing the service details to be validated
   */
  void validateServiceDetails(final AddReferralWizardData dtls);

  /**
   * Updates the details, and providers information held by the referral wizard
   * in reaction to the updated service details passed in from the client.
   * <p>
   * The updates performed are:
   * <ul>
   * <li>if changing from a single service to multiple client and the passed in
   * service is a free text service, reset the provider details if the provider
   * is selected from the system.</li>
   * <li>if changing from a single service to multiple client and the passed in
   * service exists on the service registry, reset the provider details if the
   * provider is selected from the system and not configured to provider the
   * service.</li>
   * <li>if changing from a multiple client service to single client service,
   * reset the selected clients, provider details (if the provider is selected
   * from the system and not configured to provider the service).</li>
   * </ul>
   * </p>
   *
   * @param dtls
   * struct containing the updated service details passed in from the
   * client
   * @param referralEntity
   * The xml details of the referral to be updated
   */
  void updateReferralWizardDataBasedOnServiceChange(
    final AddReferralWizardData dtls, Entity referralEntity);

  /**
   * Returns the list of {@link CaseParticipantRole} that have been selected for
   * the referral.
   *
   * @param referralEntity
   * The xml details of the referral to be created
   * @return The list of case participant roles selected for the referral
   */
  List<CaseParticipantRole> getSelectedCaseParticipantRoles(
    final Entity referralEntity);

  /**
   * Reads the context details for the wizard.
   *
   * @param wizardData
   * data relating to the wizard
   * @return The populated context details for the wizard.
   * @throws AppException
   * Generic Application Exception.
   * @throws InformationalException
   * Generic Application Exception.
   */
  AddReferralContextDetails getContextDetails(
    final AddReferralWizardData wizardData) throws AppException,
      InformationalException;

  /**
   * Sets the finish wizard and create indicator on the {@link curam.datastore.impl.Datastore}
   * {@link Entity}.
   *
   * @param key
   * The struct containing the finish wizard and create indicator
   * passed in from the client
   * @param referralEntity
   * the entity the attribute is to be set on
   */
  void setFinishWizardAndCreateInd(final AddReferralWizardData key,
    final Entity referralEntity);

  /**
   * Retrieves the finish wizard and create indicator from the {@link curam.datastore.impl.Datastore}
   * {@link Entity}.
   *
   * @param referralEntity
   * the entity the attribute to be retrieved exists on
   * @return the boolean value stored on the data store entity. If true it
   * indicates the referral wizard is complete and the {@link Referral}
   * to be created. If false, it indicates the referral wizard has yet
   * to complete and the referral is not to be created
   */
  Boolean getFinishWizardAndCreateInd(final Entity referralEntity);

}
