/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.workflowprocesses.impl;


/**
 * Represents the names of the CPM workflow processes.
 */
public class CPMWorkflowDefinition {

  // Process Definition names
  /**
   * Constant containing the value for SupervisorRequestDecision.
   */
  public static final String kSupervisorRequestDecision = "SUPERVISORREQUESTDECISION";

  /**
   * Constant containing the value for EnquiryWorkQueue.
   */
  public static final String kEnquiryWorkQueue = "EXTERNALENQUIRYWORKFLOW";

  /**
   * Constant containing the value for NewExternalUserNotification.
   */
  public static final String kNewExternalUserNotification = "SUPERVISORVIEWNEWEXTERNALUSERTASKNOTIFICATION";

  /**
   * Constant containing the value for HomeStudyApproval.
   */
  public static final String kHomeStudyApproval = "HOMESTUDYAPPROVAL";

  /**
   * Constant containing the value for ServiceInvoiceExceptionProcessing.
   */
  public static final String kServiceInvoiceExceptionProcessing = "SERVICEINVOICEEXCEPTIONPROCESSING";

  /**
   * Constant containing the value for ServiceInvoiceLineItemApproval.
   */
  public static final String kServiceInvoiceLineItemApproval = "SERVICEINVOICELINEITEMAPPROVAL";

  /**
   * Constant containing the value for ServiceInvoiceLineItemCorrectionApproval.
   */
  public static final String kServiceInvoiceLineItemCorrectionApproval = "SERVICEINVOICELINEITEMCORRECTIONAPPROVAL";

  /**
   * Constant containing the value for NewInvoiceCreated.
   */
  public static final String kNewInvoiceCreated = "NEWINVOICECREATED";
  
  // BEGIN, CR00115516, SG
  /**
   * Constant containing the value for RosterLineItem Exception Processing process.
   */
  public static final String kRosterExceptionProcessing = "ROSTEREXCEPTIONPROCESSING";
  
  /**
   * Constant containing the value for New Client Added to Roster process.
   */
  public static final String kNewClientAddedToRoster = "NEWCLIENTADDEDTOROSTER";
  // END, CR00115516
 
  // BEGIN, CR00115391, SS
  /**
   * Constant containing the value for Roster Line Item Correction Approval.
   */
  public static final String kRosterLineItemCorrectionApproval = "ROSTERLINEITEMCORRECTIONAPPROVAL";
  // END, CR00115391
  
  // BEGIN, CR00115534, ABS
  /**
   * Constant containing the value for Roster Line Item Approval.
   */
  public static final String kRosterLineItemApproval = "ROSTERLINEITEMAPPROVAL";
  // END, CR00115534
}
