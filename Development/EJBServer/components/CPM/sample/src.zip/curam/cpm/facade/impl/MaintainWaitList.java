/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008-2009, 2011-2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.WAITLISTTYPE;
import curam.codetable.impl.RESERVATIONCANCELREASONEntry;
import curam.codetable.impl.RESERVATIONSTATUSEntry;
import curam.codetable.impl.WAITLISTENTRYPRIORITYEntry;
import curam.codetable.impl.WAITLISTENTRYSTATUSEntry;
import curam.codetable.impl.WAITLISTREMOVALREASONEntry;
import curam.codetable.impl.WAITLISTTYPEEntry;
import curam.core.impl.EnvVars;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.impl.CaseParticipantRoleAdapter;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.WaitListEntryKey;
import curam.core.struct.WaitListEntryStatusHistoryDtls;
import curam.cpm.facade.struct.AllocatePlaceDetails;
import curam.cpm.facade.struct.AssignPlaceDetails;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.PlaceAndPlaceLocation;
import curam.cpm.facade.struct.PlaceAndPlaceLocationDetailsList;
import curam.cpm.facade.struct.PlaceAndPlaceLocationList;
import curam.cpm.facade.struct.PlaceLocationDetails;
import curam.cpm.facade.struct.ProviderKey;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetails;
import curam.cpm.facade.struct.ProviderOfferingSummaryDetailsList;
import curam.cpm.facade.struct.ResourceKey;
import curam.cpm.facade.struct.SearchWaitListEntryKey;
import curam.cpm.facade.struct.ViewProviderOfferingDetails;
import curam.cpm.facade.struct.ViewProviderSummaryDetails;
import curam.cpm.facade.struct.WaitListEntryAndTypeDetails;
import curam.cpm.facade.struct.WaitListEntryAndTypeDetailsList;
import curam.cpm.facade.struct.WaitListEntryDetails;
import curam.cpm.facade.struct.WaitListEntryDetailsInfo;
import curam.cpm.facade.struct.WaitListEntryDetailsList;
import curam.cpm.facade.struct.WaitListEntryHistoryDetails;
import curam.cpm.facade.struct.WaitListEntryHistoryDetailsList;
import curam.cpm.facade.struct.WaitListEntryHistoryKey;
import curam.cpm.facade.struct.WaitListEntryReviewDetails;
import curam.cpm.facade.struct.WaitListEntryReviewDetailsList;
import curam.cpm.facade.struct.WaitListEntryStatusAndPositionHistoryDetails;
import curam.cpm.facade.struct.WaitListEntryStatusAndPositionHistoryDetailsList;
import curam.cpm.facade.struct.WaitListEntryStatusHistoryDetails;
import curam.cpm.facade.struct.WaitListEntryStatusHistoryDetailsList;
import curam.cpm.facade.struct.WaitListEntryStatusHistoryList;
import curam.cpm.facade.struct.WaitListEntryViewDetails;
import curam.cpm.facade.struct.WaitListPeriodKey;
import curam.cpm.facade.struct.WaitListRemovalDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.PlaceKey;
import curam.cpm.sl.entity.struct.ProviderOfferingKey;
import curam.message.WAITLIST;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.WAITLISTExceptionCreator;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.participant.person.impl.Person;
import curam.participant.person.impl.PersonDAO;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.place.impl.Place;
import curam.place.impl.PlaceDAO;
import curam.place.impl.Placement;
import curam.place.impl.PlacementAPI;
import curam.place.impl.PlacementDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderSecurity;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.reservation.impl.Reservation;
import curam.reservation.impl.ReservationDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.serviceoffering.impl.UnitOfMeasureEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.DateTimeRange;
import curam.util.type.Money;
import curam.waitlist.impl.WaitList;
import curam.waitlist.impl.WaitListDAO;
import curam.waitlist.impl.WaitListEntry;
import curam.waitlist.impl.WaitListEntryDAO;
import curam.waitlist.impl.WaitListEntryHistoryAccessor;
import curam.waitlist.impl.WaitListEntryStatusHistory;


/**
 * {@inheritDoc}
 */
public abstract class MaintainWaitList extends curam.cpm.facade.base.MaintainWaitList {

  /**
   * Reference to WaitListDAO.
   */
  @Inject
  protected WaitListDAO waitListDAO;

  /**
   * Reference to WaitListEntryDAO.
   */
  @Inject
  protected WaitListEntryDAO waitListEntryDAO;

  /**
   * Reference to ServiceOfferingDAO.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Reference to PersonDAO.
   */
  @Inject
  protected PersonDAO personDAO;

  /**
   * Reference to ReservationDAO.
   */
  @Inject
  protected ReservationDAO reservationDAO;

  /**
   * Reference to ProviderOfferingDAO.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Reference to ProviderDAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to provider security.
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  /**
   * Reference to PlacementDAO.
   */
  @Inject
  protected PlacementDAO placementDAO;

  /**
   * Reference to PlacementAPI.
   */
  @Inject
  protected PlacementAPI placementAPI;

  @Inject
  protected PlaceDAO placeDAO;

  /**
   * Concern Role DAO object.
   */
  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  // BEGIN, CR00233823, PS
  /**
   * Reference to User DAO.
   */
  @Inject
  protected UserDAO userDAO;

  // END, CR00233823


  /**
   * Default constructor for the class to inject members.
   */
  public MaintainWaitList() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderOfferingSummaryDetailsList listProviderOfferingWaitListForProvider(
    ProviderKey key) throws AppException, InformationalException {

    ProviderOfferingSummaryDetailsList providerOfferingSummaryDetailsList = new ProviderOfferingSummaryDetailsList();

    Set<ProviderOffering> providerOfferings = listProviderOfferingWaitListForProvider(
      providerDAO.get(key.providerID));

    for (ProviderOffering providerOffering : sortProviderOfferings(
      providerOfferings)) {

      ProviderOfferingSummaryDetails providerOfferingSummaryDetails = new ProviderOfferingSummaryDetails();
      ServiceOffering serviceOffering = providerOffering.getServiceOffering();

      providerOfferingSummaryDetails.serviceOfferingID = serviceOffering.getID();
      providerOfferingSummaryDetails.providerOfferingID = providerOffering.getID();

      providerOfferingSummaryDetails.startDate = providerOffering.getDateRange().start();
      providerOfferingSummaryDetails.endDate = providerOffering.getDateRange().end();
      providerOfferingSummaryDetails.name = serviceOffering.getName();
      providerOfferingSummaryDetails.recordStatus = providerOffering.getLifecycleState().getCode();

      providerOfferingSummaryDetailsList.providerOfferingSummaryDetails.addRef(
        providerOfferingSummaryDetails);
    }
    return providerOfferingSummaryDetailsList;
  }

  /**
   * {@inheritDoc}
   */

  public WaitListEntryDetailsList listWaitListEntryForResource(ResourceKey key)
    throws AppException, InformationalException {

    Set<WaitListEntry> waitListEntries = listWaitListEntryForResource(
      key.resourceID);

    ArrayList<WaitListEntry> sortedWaitListEntries = sortWaitListEntriesByPosition(
      waitListEntries);

    WaitListEntryDetailsList waitListEntryDetailsList = new WaitListEntryDetailsList();

    for (WaitListEntry waitListEntry : sortedWaitListEntries) {
      WaitListEntryDetails waitListEntryDetails = getWaitListEntryDetails(
        waitListEntry);

      waitListEntryDetailsList.details.addRef(waitListEntryDetails);
    }

    return waitListEntryDetailsList;

  }

  /**
   * {@inheritDoc}
   */
  public void markAsAllocated(KeyVersionDetails waitListEntryIDVersion)
    throws AppException, InformationalException {

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryIDVersion.id);

    // BEGIN, CR00156341, RPB
    waitListEntry.setTransactionUser(TransactionInfo.getProgramUser());
    // END, CR00156341
    waitListEntry.allocate(waitListEntryIDVersion.version);
  }

  /**
   * {@inheritDoc}
   */
  public void removeWaitListEntry(WaitListRemovalDetails details)
    throws AppException, InformationalException {

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      details.keyVersionDtls.id);

    waitListEntry.setRemovalReason(
      WAITLISTREMOVALREASONEntry.get(details.removalReason));
    // BEGIN, CR00156341, RPB
    waitListEntry.setTransactionUser(TransactionInfo.getProgramUser());
    // END, CR00156341
    waitListEntry.cancel(details.keyVersionDtls.version);
  }

  /**
   * {@inheritDoc}
   */
  public WaitListEntryDetailsList searchWaitListEntryForProvider(
    SearchWaitListEntryKey searchWaitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntryDetailsList waitListEntryDetailsList = new WaitListEntryDetailsList();

    // BEGIN, CR00122324, SSH
    // Check if search criteria is entered.
    if ((searchWaitListEntryKey.clientName.trim() + searchWaitListEntryKey.priority.trim() + searchWaitListEntryKey.status.trim()).length()
      == 0
        && Date.kZeroDate.equals(searchWaitListEntryKey.expiryDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        WAITLISTExceptionCreator.ERR_WAITLIST_ENTRY_XFV_SOME_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    ValidationHelper.failIfErrorsExist();
    // END, CR00122324

    Set<WaitListEntry> waitListEntryList = waitListEntryDAO.searchBy(
      searchWaitListEntryKey.clientName,
      WAITLISTENTRYPRIORITYEntry.get(searchWaitListEntryKey.priority),
      searchWaitListEntryKey.expiryDate,
      WAITLISTENTRYSTATUSEntry.get(searchWaitListEntryKey.status),
      searchWaitListEntryKey.resourceID, WAITLISTTYPEEntry.PROVIDER);

    // Sorts the wait list entries in the ascending order of position.
    ArrayList<WaitListEntry> sortedWaitListEntries = sortWaitListEntriesByPosition(
      waitListEntryList);

    for (final WaitListEntry waitListEntry : sortedWaitListEntries) {
      WaitListEntryDetails waitListEntryDetails = getWaitListEntryDetails(
        waitListEntry);

      waitListEntryDetailsList.details.addRef(waitListEntryDetails);
    }
    return waitListEntryDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public WaitListEntryDetailsList searchWaitListEntryForProviderOffering(
    SearchWaitListEntryKey searchWaitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntryDetailsList waitListEntryDetailsList = new WaitListEntryDetailsList();

    // BEGIN, CR00122324, SSH
    // Check if search criteria is entered.
    if ((searchWaitListEntryKey.clientName.trim() + searchWaitListEntryKey.priority.trim() + searchWaitListEntryKey.status.trim()).length()
      == 0
        && Date.kZeroDate.equals(searchWaitListEntryKey.expiryDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        WAITLISTExceptionCreator.ERR_WAITLIST_ENTRY_XFV_SOME_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();
    // END, CR00122324

    Set<WaitListEntry> waitListEntryList = waitListEntryDAO.searchBy(
      searchWaitListEntryKey.clientName,
      WAITLISTENTRYPRIORITYEntry.get(searchWaitListEntryKey.priority),
      searchWaitListEntryKey.expiryDate,
      WAITLISTENTRYSTATUSEntry.get(searchWaitListEntryKey.status),
      searchWaitListEntryKey.resourceID, WAITLISTTYPEEntry.PROVIDEROFFERING);

    // Sorts the wait list entries in the ascending order of position.
    ArrayList<WaitListEntry> sortedWaitListEntries = sortWaitListEntriesByPosition(
      waitListEntryList);

    for (final WaitListEntry waitListEntry : sortedWaitListEntries) {
      WaitListEntryDetails waitListEntryDetails = getWaitListEntryDetails(
        waitListEntry);

      waitListEntryDetailsList.details.addRef(waitListEntryDetails);
    }

    return waitListEntryDetailsList;
  }

  // BEGIN, CR00272514, GP
  /**
   * {@inheritDoc}
   */
  public WaitListEntryAndTypeDetailsList searchWaitListEntryForProviderAndPO(
    SearchWaitListEntryKey searchWaitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntryAndTypeDetailsList waitListEntryAndTypeDetailsList = new WaitListEntryAndTypeDetailsList();
    WaitListEntryAndTypeDetails waitListEntryAndTypeDetails;
    WaitListEntryDetailsList waitListEntryDetailsList = new WaitListEntryDetailsList();

    // Retrieve all wait list entries associated to Provider.
    waitListEntryDetailsList = searchWaitListEntryForProvider(
      searchWaitListEntryKey);
    for (WaitListEntryDetails waitListEntryDetails : waitListEntryDetailsList.details.items()) {

      waitListEntryAndTypeDetails = new WaitListEntryAndTypeDetails();
      waitListEntryAndTypeDetails.assign(waitListEntryDetails);
      waitListEntryAndTypeDetails.waitListEntryDtls.assign(
        waitListEntryDetails.waitListEntryDtls);
      waitListEntryAndTypeDetails.waitListDtls.assign(
        waitListEntryDetails.waitListDtls);
      waitListEntryAndTypeDetails.waitListType = WAITLISTTYPEEntry.PROVIDER.getCode();
      if (WAITLISTENTRYSTATUSEntry.OPEN.getCode().equals(
        waitListEntryAndTypeDetails.waitListEntryDtls.status)) {

        waitListEntryAndTypeDetails.allocatePlaceInd = true;
        waitListEntryAndTypeDetails.editInd = true;
        waitListEntryAndTypeDetails.markInd = true;
        waitListEntryAndTypeDetails.removeInd = true;
      }
      waitListEntryAndTypeDetailsList.list.addRef(waitListEntryAndTypeDetails);
    }

    Provider provider = providerDAO.get(searchWaitListEntryKey.resourceID);
    Set<ProviderOffering> providerOfferings = provider.getProviderOfferings();

    for (final ProviderOffering providerOffering : providerOfferings) {

      searchWaitListEntryKey.resourceID = providerOffering.getID();

      // Retrieve all wait list entries associated to Provider Offering.
      waitListEntryDetailsList = searchWaitListEntryForProviderOffering(
        searchWaitListEntryKey);
      for (WaitListEntryDetails waitListEntryDetails : waitListEntryDetailsList.details.items()) {

        waitListEntryAndTypeDetails = new WaitListEntryAndTypeDetails();
        waitListEntryAndTypeDetails.assign(waitListEntryDetails);
        waitListEntryAndTypeDetails.waitListEntryDtls.assign(
          waitListEntryDetails.waitListEntryDtls);
        waitListEntryAndTypeDetails.waitListDtls.assign(
          waitListEntryDetails.waitListDtls);
        waitListEntryAndTypeDetails.waitListType = WAITLISTTYPEEntry.PROVIDEROFFERING.getCode();

        if (WAITLISTENTRYSTATUSEntry.OPEN.getCode().equals(
          waitListEntryAndTypeDetails.waitListEntryDtls.status)) {

          waitListEntryAndTypeDetails.allocatePlaceInd = true;
          waitListEntryAndTypeDetails.editInd = true;
          waitListEntryAndTypeDetails.markInd = true;
          waitListEntryAndTypeDetails.removeInd = true;
        }
        waitListEntryAndTypeDetailsList.list.addRef(waitListEntryAndTypeDetails);
      }
    }
    return waitListEntryAndTypeDetailsList;
  }

  // END, CR00272514


  /**
   * {@inheritDoc}
   */
  public void updateWaitListEntry(WaitListEntryDetails waitListEntryDetails)
    throws AppException, InformationalException {

    short position = 0;
    String positionString = waitListEntryDetails.positionString.trim();

    // Get the position from position string.
    if (positionString.length() > 0) {
      try {
        position = Short.parseShort(positionString);
      } catch (NumberFormatException nfe) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          WAITLISTExceptionCreator.ERR_WAITLIST_ENTRY_FV_POSITION_ENTERED_IS_INVALID(
            positionString),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      ValidationHelper.failIfErrorsExist();
    }

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryDetails.waitListEntryDtls.waitListEntryID);

    waitListEntry.setExpiryDate(
      waitListEntryDetails.waitListEntryDtls.expiryDate);
    waitListEntry.setPosition(position);
    // BEGIN, CR00156341, RPB
    waitListEntry.setPriority(
      WAITLISTENTRYPRIORITYEntry.get(
        waitListEntryDetails.waitListEntryDtls.priority));
    waitListEntry.setReviewDate(
      waitListEntryDetails.waitListEntryDtls.reviewDate);
    waitListEntry.setTransactionUser(TransactionInfo.getProgramUser());
    // END, CR00156341
    waitListEntry.modifyWaitListEntry(
      waitListEntryDetails.waitListEntryDtls.versionNo);
  }

  // BEGIN, CR00280874, GP
  /**
   * {@inheritDoc}
   */
  public WaitListEntryReviewDetailsList listRecentWaitListEntriesDueForReview()
    throws AppException, InformationalException {

    WaitListEntryReviewDetailsList waitListEntryDetailsList = new WaitListEntryReviewDetailsList();
    WaitListEntryReviewDetails waitListEntryReviewDetails;
    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();
    CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();

    List<WaitListEntry> waitListEntries = sortWaitListEntriesByReviewDate(
      waitListEntryDAO.searchByReviewDateRangeAndStatus(Date.getCurrentDate(),
      Date.getCurrentDate().addDays(CPMConstants.kWaitListEntriesRenewalDays),
      WAITLISTENTRYSTATUSEntry.OPEN));

    for (final WaitListEntry waitListEntry : waitListEntries) {

      waitListEntryReviewDetails = new WaitListEntryReviewDetails();
      caseParticipantRoleKey.caseParticipantRoleID = waitListEntry.getClient();

      CaseParticipantRole_eoFullDetails caseParticipantRoleDetails = caseParticipantRole.readFullDetails(
        caseParticipantRoleKey);

      waitListEntryReviewDetails.clientName = caseParticipantRoleDetails.name;

      if (WAITLISTTYPEEntry.PROVIDER.equals(
        waitListEntry.getWaitList().getType())) {

        Provider provider = providerDAO.get(
          waitListEntry.getWaitList().getResourceID());

        waitListEntryReviewDetails.resourceName = provider.getName();
        waitListEntryReviewDetails.providerConcernRoleID = provider.getID();
      } else if (WAITLISTTYPEEntry.PROVIDEROFFERING.equals(
        waitListEntry.getWaitList().getType())) {
        ProviderOffering providerOffering = providerOfferingDAO.get(
          waitListEntry.getWaitList().getResourceID());

        waitListEntryReviewDetails.resourceName = providerOffering.getServiceOffering().getName();
        waitListEntryReviewDetails.providerConcernRoleID = providerOffering.getProvider().getID();
      }

      waitListEntryReviewDetails.reviewDate = waitListEntry.getReviewDate();
      waitListEntryReviewDetails.participantRoleID = caseParticipantRoleDetails.participantRoleID;

      waitListEntryDetailsList.waitListEntryReviewDetails.addRef(
        waitListEntryReviewDetails);
    }

    return waitListEntryDetailsList;
  }

  // END, CR00280874

  // BEGIN, CR00236379, SK
  /**
   * Retrieves a wait list entry details for a wait list.
   *
   * @deprecated Since Curam 6.0, this method has been replaced by
   * {@link cpm.facade.MaintainWaitList#viewWaitListEntryDetails()}.
   * The new method reads the wait list entry details along with
   * latest history information like last updated date time and last
   * updated user.
   */
  @Deprecated
  // END, CR00236379
  public WaitListEntryDetails viewWaitListEntry(
    WaitListEntryKey waitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKey.waitListEntryID);
    WaitListEntryDetails waitListEntryDetails = getWaitListEntryDetails(
      waitListEntry);

    return waitListEntryDetails;
  }

  /**
   * Reads the status history information for a wait list entry.
   *
   * @param waitListEntryKey
   * Key containing the wait list entry ID.
   *
   * @return List of status history for the given wait list entry.
   * @throws AppException
   * @throws InformationalException
   */
  public WaitListEntryStatusHistoryDetailsList viewWaitListEntryStatusHistory(
    WaitListEntryKey waitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKey.waitListEntryID);

    Set<WaitListEntryStatusHistory> waitListEntryStatusHistory = waitListEntry.getHistory();

    WaitListEntryStatusHistoryDetailsList statusHistoryDetailsList = new WaitListEntryStatusHistoryDetailsList();

    List<WaitListEntryStatusHistory> statusHistoryList = new ArrayList<WaitListEntryStatusHistory>(
      waitListEntryStatusHistory);

    for (WaitListEntryStatusHistory statusHistory : sortWaitListEntryStausHistoryByDateTime(
      statusHistoryList)) {

      statusHistoryDetailsList.dtls.addRef(
        getWaitListEntryStatusHistoryDetails(statusHistory));
    }

    return statusHistoryDetailsList;
  }

  // BEGIN, CR00245989, GP
  /**
   * Reads the status history information for a wait list entry.
   *
   * @param waitListEntryKey
   * Key containing the wait list entry ID.
   *
   * @return List of status history for the given wait list entry.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public WaitListEntryStatusHistoryList viewWaitListEntryStatusHistoryDetails(
    final WaitListEntryKey waitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntryStatusHistoryList waitListEntryStatusHistoryList = new WaitListEntryStatusHistoryList();

    WaitListEntryStatusHistoryDetailsList waitListEntryStatusHistoryDetailsList = viewWaitListEntryStatusHistory(
      waitListEntryKey);

    for (final WaitListEntryStatusHistoryDtls waitListEntryStatusHistoryDtls :
      waitListEntryStatusHistoryDetailsList.dtls.items()) {

      WaitListEntryStatusHistoryDetails waitListEntryStatusHistoryDetails = new WaitListEntryStatusHistoryDetails();

      waitListEntryStatusHistoryDetails.waitListEntryStatusHistory = waitListEntryStatusHistoryDtls;
      User user = userDAO.get(waitListEntryStatusHistoryDtls.userName);

      waitListEntryStatusHistoryDetails.userFullName = user.getFullName();

      waitListEntryStatusHistoryList.waitListEntryHistoryList.addRef(
        waitListEntryStatusHistoryDetails);
    }

    return waitListEntryStatusHistoryList;
  }

  // END, CR00245989

  // BEGIN, CR00272514, GP
  /**
   * Reads the status and position history information for a wait list entry.
   *
   * @param waitListEntryKey
   * key containing the wait list entry ID.
   *
   * @return List of status and position history for the given wait list entry.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public WaitListEntryStatusAndPositionHistoryDetailsList viewWaitListEntryAndStatusHistoryDetails(
    final WaitListEntryKey waitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntryStatusAndPositionHistoryDetailsList waitListEntryStatusHistoryList = new WaitListEntryStatusAndPositionHistoryDetailsList();
    WaitListEntryStatusHistoryDetails waitListEntryStatusHistoryDetails;
    WaitListEntryStatusAndPositionHistoryDetails waitListEntryStatusAndPositionHistoryDetails;

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKey.waitListEntryID);

    WaitListEntryStatusHistoryDetailsList waitListEntryStatusHistoryDetailsList = viewWaitListEntryStatusHistory(
      waitListEntryKey);

    for (WaitListEntryStatusHistoryDtls waitListEntryStatusHistoryDtls : waitListEntryStatusHistoryDetailsList.dtls.items()) {

      waitListEntryStatusHistoryDetails = new WaitListEntryStatusHistoryDetails();

      waitListEntryStatusHistoryDetails.waitListEntryStatusHistory = waitListEntryStatusHistoryDtls;
      User user = userDAO.get(waitListEntryStatusHistoryDtls.userName);

      if (WAITLISTENTRYSTATUSEntry.OPEN.getCode().equals(
        waitListEntryStatusHistoryDtls.status)) {

        for (WaitListEntryHistoryAccessor waitListEntryHistoryAccessor : sortWaitListEntryHistoryByDateTime(
          waitListEntry.getWaitListEntryHistory())) {

          waitListEntryStatusAndPositionHistoryDetails = new WaitListEntryStatusAndPositionHistoryDetails();

          waitListEntryStatusAndPositionHistoryDetails.waitListEntryStatusHistoryDetails.assign(
            waitListEntryStatusHistoryDetails.waitListEntryStatusHistory);
          waitListEntryStatusAndPositionHistoryDetails.userFullName = user.getFullName();

          waitListEntryStatusAndPositionHistoryDetails.waitListEntryStatusHistoryDetails.changeDateTime = waitListEntryHistoryAccessor.getChangeDateTime();

          waitListEntryStatusAndPositionHistoryDetails.waitListEntryPositionHistoryDetails.waitListEntryHistoryID = waitListEntryHistoryAccessor.getID();
          waitListEntryStatusAndPositionHistoryDetails.waitListEntryPositionHistoryDetails.position = waitListEntryHistoryAccessor.getPosition();
          waitListEntryStatusAndPositionHistoryDetails.waitListEntryStatusHistoryDetails.waitListEntryID = waitListEntry.getID();
          if (WAITLISTENTRYSTATUSEntry.OPEN.getCode().equals(
            waitListEntryHistoryAccessor.getStatus().toString())) {
            waitListEntryStatusHistoryList.list.addRef(
              waitListEntryStatusAndPositionHistoryDetails);
          }
        }

      } else {

        waitListEntryStatusAndPositionHistoryDetails = new WaitListEntryStatusAndPositionHistoryDetails();

        waitListEntryStatusAndPositionHistoryDetails.waitListEntryStatusHistoryDetails.assign(
          waitListEntryStatusHistoryDetails.waitListEntryStatusHistory);
        waitListEntryStatusAndPositionHistoryDetails.userFullName = user.getFullName();
        waitListEntryStatusAndPositionHistoryDetails.waitListEntryStatusHistoryDetails.waitListEntryID = waitListEntry.getID();
        waitListEntryStatusAndPositionHistoryDetails.waitListEntryPositionHistoryDetails.position = waitListEntry.getLatestHistory().getPosition();
        waitListEntryStatusHistoryList.list.addRef(
          waitListEntryStatusAndPositionHistoryDetails);
      }

    }

    return waitListEntryStatusHistoryList;
  }

  // END, CR00272514

  // BEGIN, CR00293856, IBM
  /**
   * Updates the placement period overlapping with the wait list period and
   * allocates the wait list to the client.
   *
   * @param allocatePlaceDetails
   * Allocate place details.
   * @return AllocatePlaceDetails Allocate place details.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 5.2 SP5, replaced with {@link 
   * MaintainWaitList#modifyOverlappingPlacementPeriod(AllocatePlaceDetails)}
   *
   * This method is deprecated as informational messages are not returned. 
   * This method is replaced by modifyOverlappingPlacementPeriod(AllocatePlaceDetails)
   * which returns the informational message along with place details as well. 
   * See release note: CS-09152/CR00293856.
   */
  @Deprecated
  public AllocatePlaceDetails updateOverlappingPlacementPeriod(
    AllocatePlaceDetails allocatePlaceDetails) throws AppException,
      InformationalException {
    // END, CR00293856  
    DateTimeRange waitListDateTimeRange = new DateTimeRange(
      allocatePlaceDetails.fromDateTime, allocatePlaceDetails.toDateTime);

    AllocatePlaceDetails placeAllocationDetails = new AllocatePlaceDetails();

    placeAllocationDetails = allocatePlaceDetails;

    placeAllocationDetails.existingPlacementPeriodChangeInd = true;

    if (!placeAllocationDetails.openWaitListInd
      && !placeAllocationDetails.overlappingRsrvInd) {

      // Allocate the place to the client

      placeAllocationDetails.waitListAllocatedID = allocatePlaceToClient(
        placeAllocationDetails.keyVersionDtls.id, waitListDateTimeRange,
        placeAllocationDetails.existingPlacementPeriodChangeInd,
        placeAllocationDetails.placeID,
        placeAllocationDetails.serviceOfferingID,
        placeAllocationDetails.cancelOverlappingRsrvInd,
        placeAllocationDetails.removeOpenWaitListInd,
        placeAllocationDetails.keyVersionDtls.version);

    }
    
    return placeAllocationDetails;
  }

  // BEGIN, CR00293856, IBM
  /**
   * Allocates the client in wait list as reservation if client is waiting on a
   * future date or placement if its current or on past date. Allocate place
   * determines if there is an overlapping placement, active reservations of
   * open wait lists.
   *
   * @param allocatePlaceDetails
   * Allocate place details.
   * @return AllocatePlaceDetails Allocate place details.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 5.2 SP5, replaced with {@link 
   * MaintainWaitList#assignPlace(AllocatePlaceDetails)}
   *
   * This method is deprecated as informational messages are not returned. 
   * This method is replaced by assignPlace(AllocatePlaceDetails) which returns 
   * the informational message along with place details as well. 
   * See release note: CS-09152/CR00293856.
   */
  @Deprecated
  public AllocatePlaceDetails allocatePlace(
    AllocatePlaceDetails allocatePlaceDetails) throws AppException,
      InformationalException {
    // END, CR00293856
    Placement placement = placementDAO.newInstance();
    // Retrieve the wait list entry details
    WaitListEntry waitListEntry = waitListEntryDAO.get(
      allocatePlaceDetails.keyVersionDtls.id);

    // check appropriate security privileges
    if (WAITLISTTYPE.PROVIDER.equals(waitListEntry.getWaitList().getType())) {

      providerSecurity.checkProviderSecurity(
        providerDAO.get(waitListEntry.getWaitList().getResourceID()));
    } else if (WAITLISTTYPE.PROVIDEROFFERING.equals(
      waitListEntry.getWaitList().getType())) {

      providerSecurity.checkProviderSecurity(
        providerOfferingDAO.get(waitListEntry.getWaitList().getResourceID()).getProvider());
    }

    DateTimeRange waitListDateTimeRange = new DateTimeRange(
      allocatePlaceDetails.fromDateTime, allocatePlaceDetails.toDateTime);
    AllocatePlaceDetails placeAllocationDetails = new AllocatePlaceDetails();

    placeAllocationDetails = allocatePlaceDetails;

    placeAllocationDetails.openWaitListInd = false;
    placeAllocationDetails.overlappingRsrvInd = false;
    placeAllocationDetails.placementPeriodChangeInd = false;

    if (placeAllocationDetails.fromDateTime.before(
      DateTime.getCurrentDateTime())) {
      // Retrieve the overlapping placement details if any
      curam.place.impl.Placement overlappingPlacement = placement.getOverlappingPlacementForClient(
        waitListEntry.getClient(), waitListDateTimeRange);

      // Check if there is a placement overlapping with the wait list period
      if (overlappingPlacement != null) {
        placeAllocationDetails.placementPeriodChangeInd = true;
      }
    } else {

      final CaseParticipantRoleAdapter caseParticipantRoleAdapter = new CaseParticipantRoleAdapter();
      final long participantRoleID = caseParticipantRoleAdapter.read(waitListEntry.getClient(), false).participantRoleID;

      Person client = personDAO.get(participantRoleID);

      // Check for overlapping reservations
      Set<Reservation> overlappingReservations = overlappingReservationsForClient(
        waitListDateTimeRange, client);

      if (!overlappingReservations.isEmpty()) {
        placeAllocationDetails.overlappingRsrvInd = true;
      }
    }

    // Retrieve the list of open wait list entries for the client on the same
    // case
    Set<WaitListEntry> openWaitListEntryList = openWaitListsForCase(
      waitListEntry.getClient(), WAITLISTENTRYSTATUSEntry.OPEN);

    if (openWaitListEntryList.size() > 1) {

      placeAllocationDetails.openWaitListInd = true;
    }

    placeAllocationDetails.cancelOverlappingRsrvInd = false;
    placeAllocationDetails.existingPlacementPeriodChangeInd = false;
    placeAllocationDetails.removeOpenWaitListInd = false;

    if (!placeAllocationDetails.placementPeriodChangeInd) {
      // Allocate the place to the client

      placeAllocationDetails.waitListAllocatedID = allocatePlaceToClient(
        placeAllocationDetails.keyVersionDtls.id, waitListDateTimeRange,
        placeAllocationDetails.existingPlacementPeriodChangeInd,
        placeAllocationDetails.placeID,
        placeAllocationDetails.serviceOfferingID,
        placeAllocationDetails.cancelOverlappingRsrvInd,
        placeAllocationDetails.removeOpenWaitListInd,
        placeAllocationDetails.keyVersionDtls.version);
    }

    // Check if the wait list type is provider or provider offering.
    if (waitListEntry.getWaitList().getType().equals(WAITLISTTYPEEntry.PROVIDER)) {
      placeAllocationDetails.waitListTypeInd = true;
    } else {
      placeAllocationDetails.waitListTypeInd = false;
    }

    return placeAllocationDetails;
  }

  // BEGIN, CR00159966, SG
  /**
   * Forwards the allocation dates received from the input page to next page,
   * where the user can select a place to be allocated.
   *
   * @param allocatePlaceDetails
   * Allocate place details.
   * @return AllocatePlaceDetails Allocate place details.
   * @throws InformationalException
   * {@link CPMCommonMessages#ERR_CPMCOMMONMSG_XFV_TO_DATE_TIME_EARLIER_THAN_FROM_DATE_TIME}
   * To date time specified is earlier than the from date time.
   * @throws InformationalException
   * {@link WaitList#ERR_WAITLIST_XRV_NO_PLACE_IS_AVAILABLE_WAITLIST_CANNOT_BE_ALLOCATED}
   * No place is available for the period specified.
   * @throws AppException
   * Generic Exception Signature.
   */
  public AllocatePlaceDetails retrieveAllocateDetailsPassedByClient(
    AllocatePlaceDetails allocatePlaceDetails) throws AppException,
      InformationalException {

    // BEGIN, CR00159124, RPB
    // Validate from and to date time.
    if (!allocatePlaceDetails.toDateTime.isZero()
      && allocatePlaceDetails.fromDateTime.after(
        allocatePlaceDetails.toDateTime)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_XFV_TO_DATE_TIME_EARLIER_THAN_FROM_DATE_TIME(
          allocatePlaceDetails.toDateTime, allocatePlaceDetails.fromDateTime),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00159124

    WaitListPeriodKey waitListPeriodKey = new WaitListPeriodKey();

    waitListPeriodKey.from = allocatePlaceDetails.fromDateTime;
    waitListPeriodKey.to = allocatePlaceDetails.toDateTime;
    waitListPeriodKey.serviceOfferingID = allocatePlaceDetails.serviceOfferingID;
    waitListPeriodKey.waitListEntryID = allocatePlaceDetails.keyVersionDtls.id;
    
    // BEGIN, CR00293856, IBM
    PlaceAndPlaceLocationDetailsList placeAndPlaceLocationList = getAvailablePlaces(
      waitListPeriodKey);

    // END , CR00293856

    // Verify if any of the places are available for the period specified.
    if (placeAndPlaceLocationList.place.isEmpty()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        WAITLISTExceptionCreator.ERR_WAITLIST_XRV_NO_PLACE_IS_AVAILABLE_WAITLIST_CANNOT_BE_ALLOCATED(
          allocatePlaceDetails.fromDateTime, allocatePlaceDetails.toDateTime),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      allocatePlaceDetails.keyVersionDtls.id);

    // Check if the wait list type is provider or provider offering
    if (waitListEntry.getWaitList().getType().equals(WAITLISTTYPEEntry.PROVIDER)) {
      allocatePlaceDetails.waitListTypeInd = true;
    } else {
      allocatePlaceDetails.waitListTypeInd = false;
    }

    ValidationHelper.failIfErrorsExist();
    
    return allocatePlaceDetails;
  }

  // END, CR00159966

  // BEGIN, CR00293856, IBM
  /**
   * Retrieves the list of available places for the wait list date range.
   *
   * @param waitlistPeriodKey
   * Contains wait list period.
   * @return PlaceAndPlaceLocationList List of available places.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 5.2 SP5, replaced with {@link 
   * MaintainWaitList#getAvailablePlaces(WaitListPeriodKey)}
   *
   * This method is deprecated as informational messages are not returned. 
   * This method is replaced by getAvailablePlaces(WaitListPeriodKey) which 
   * returns the informational message along with place details as well. 
   * See release note: CS-09152/CR00293856.
   */
  @Deprecated
  public PlaceAndPlaceLocationList listAvailablePlaces(
    WaitListPeriodKey waitlistPeriodKey) throws AppException,
      InformationalException {
    // END, CR00293856
    PlaceAndPlaceLocationList placeLocationList = new PlaceAndPlaceLocationList();
    Reservation reservation = reservationDAO.newInstance();

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitlistPeriodKey.waitListEntryID);

    Set<curam.place.impl.Place> availablePlaces = null;

    if (waitListEntry.getWaitList().getType().equals(
      WAITLISTTYPEEntry.PROVIDEROFFERING)) {

      // Retrieve the list of places for the provider and date range
      availablePlaces = reservation.getPlaceAvailableInDateRange(
        providerOfferingDAO.get(waitListEntry.getWaitList().getResourceID()).getProvider(),
        new DateTimeRange(waitlistPeriodKey.from, waitlistPeriodKey.to));

    } else if (waitListEntry.getWaitList().getType().equals(
      WAITLISTTYPEEntry.PROVIDER)) {

      // Retrieve the list of places for the provider and date range
      availablePlaces = reservation.getPlaceAvailableInDateRange(
        providerDAO.get(waitListEntry.getWaitList().getResourceID()),
        new DateTimeRange(waitlistPeriodKey.from, waitlistPeriodKey.to));
    }

    // Retrieve the place and location details for each place
    for (curam.place.impl.Place place : availablePlaces) {

      PlaceKey placeKey = new PlaceKey();

      PlaceAndPlaceLocation placeAndLocation = new PlaceAndPlaceLocation();

      placeKey.placeID = place.getID();

      // Retrieves the location details
      PlaceLocationDetails placeLocationDetails = place.getLocationForPlace();

      // Set the place and location details
      placeAndLocation.placeLocation = placeLocationDetails.location;

      placeAndLocation.placeName = place.getName();

      placeAndLocation.placeID = place.getID();

      placeLocationList.place.addRef(placeAndLocation);
    }

    return placeLocationList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderOfferingSummaryDetailsList listApprovedProviderOffering(
    ResourceKey resourceKey) throws AppException, InformationalException {

    ProviderOfferingSummaryDetailsList providerOfferingSummaryDetailsList = new ProviderOfferingSummaryDetailsList();

    // Resource key contains the wait list
    WaitListEntry waitListEntry = waitListEntryDAO.get(resourceKey.resourceID);

    // Retrieve the provider details
    final curam.provider.impl.Provider provider = providerDAO.get(
      waitListEntry.getWaitList().getResourceID());
    ProviderOfferingSummaryDetails providerOfferingSummaryDetails;

    // Iterate through the list of provider offering for the provider
    for (final curam.providerservice.impl.ProviderOffering providerOffering : provider.getProviderOfferings()) {
      curam.serviceoffering.impl.ServiceOffering serviceOffering = providerOffering.getServiceOffering();

      // BEGIN, CR00260974, SK
      // Add the provider offering to the list if the status is approved and
      // unit of measure is place
      if (providerOffering.getLifecycleState().getCode().equals(
        ProviderOfferingStatusEntry.APPROVED.getCode())
          && providerOffering.getServiceOffering().getUnitOfMeasure().getCode().equals(
            UnitOfMeasureEntry.PLACE.getCode())) {
        providerOfferingSummaryDetails = new ProviderOfferingSummaryDetails();
        providerOfferingSummaryDetails.name = serviceOffering.getName();
        providerOfferingSummaryDetails.providerOfferingID = serviceOffering.getID();
        providerOfferingSummaryDetailsList.providerOfferingSummaryDetails.addRef(
          providerOfferingSummaryDetails);
      }
      // END, CR00260974
    }

    return providerOfferingSummaryDetailsList;
  }

  /**
   * {@inheritDoc}
   */
  public AllocatePlaceDetails cancelOverlappingReservation(
    AllocatePlaceDetails allocatePlaceDetails) throws AppException,
      InformationalException {

    DateTimeRange waitListDateTimeRange = new DateTimeRange(
      allocatePlaceDetails.fromDateTime, allocatePlaceDetails.toDateTime);

    AllocatePlaceDetails placeAllocationDetails = new AllocatePlaceDetails();

    placeAllocationDetails = allocatePlaceDetails;

    placeAllocationDetails.cancelOverlappingRsrvInd = true;

    Reservation reservation = null;

    try {
      reservation = reservationDAO.get(
        placeAllocationDetails.waitListAllocatedID);
    } catch (Exception e) {// Suppress the exception, wait list allocated ID can have either
      // placement
      // ID or reservation ID
    }

    // Cancels the reservations that overlaps with the wait list period
    cancelOverlappingActiveReservations(waitListDateTimeRange,
      placeAllocationDetails.cancelOverlappingRsrvInd,
      placeAllocationDetails.keyVersionDtls.id, reservation);

    return placeAllocationDetails;
  }

  /**
   * Removes the Open wait lists with other provider and provider offering for
   * the same case.
   *
   * @param allocatePlaceDetails
   * Allocate place details.
   * @return AllocatePlaceDetails Allocate place details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public AllocatePlaceDetails removeWaitListEntriesForClient(
    AllocatePlaceDetails allocatePlaceDetails) throws AppException,
      InformationalException {

    AllocatePlaceDetails placeAllocationDetails = new AllocatePlaceDetails();

    placeAllocationDetails = allocatePlaceDetails;

    placeAllocationDetails.removeOpenWaitListInd = true;

    // Removes the wait list entries for the client
    removeOpenWaitListEntriesForCase(
      placeAllocationDetails.removeOpenWaitListInd,
      allocatePlaceDetails.keyVersionDtls.id);

    return placeAllocationDetails;
  }

  // BEGIN, CR00156341, RPB
  /**
   * {@inheritDoc}
   */
  public WaitListEntryHistoryDetailsList listHistoryForWaitListEntry(
    WaitListEntryKey waitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntryHistoryDetailsList waitListEntryHistoryDetailsList = new WaitListEntryHistoryDetailsList();

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKey.waitListEntryID);

    List<? extends WaitListEntryHistoryAccessor> waitListEntryHistoryAccessor = waitListEntry.getWaitListEntryHistory();

    // BEGIN, CR00159124, RPB
    // Sort the history records by last changed date time with latest first.
    List<? extends WaitListEntryHistoryAccessor> sortedWaitListEntryHistoryAccessor = new ArrayList<WaitListEntryHistoryAccessor>();

    sortedWaitListEntryHistoryAccessor = sortWaitListEntryHistoryByDateTime(
      waitListEntryHistoryAccessor);

    for (WaitListEntryHistoryAccessor waitListEntryHistory : sortedWaitListEntryHistoryAccessor) {

      WaitListEntryHistoryDetails waitListEntryDetails = new WaitListEntryHistoryDetails();

      waitListEntryDetails.dtls.lastChangedDateTime = waitListEntryHistory.getChangeDateTime();
      waitListEntryDetails.lastUpdatedBy = waitListEntryHistory.getTransactionUserName();
      waitListEntryDetails.dtls.status = waitListEntryHistory.getStatus().getCode();
      waitListEntryDetails.dtls.waitListEntHistID = waitListEntryHistory.getID();
      waitListEntryHistoryDetailsList.details.addRef(waitListEntryDetails);
    }
    // END, CR00159124

    return waitListEntryHistoryDetailsList;

  }

  /**
   * {@inheritDoc}
   */
  public WaitListEntryHistoryDetails viewWaitListEntryHistory(
    WaitListEntryHistoryKey waitListEntryHistoryKey) throws AppException,
      InformationalException {

    WaitListEntryKey waitListEntryKey = new WaitListEntryKey();
    WaitListEntryHistoryDetails waitListEntryHistoryDetails = new WaitListEntryHistoryDetails();

    waitListEntryKey.waitListEntryID = waitListEntryHistoryKey.waitListEntryID;
    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKey.waitListEntryID);

    WaitListEntryDetails waitListEntryDetails = getWaitListEntryDetails(
      waitListEntry);

    // BEGIN, CR00272514, GP
    if (0 != waitListEntryHistoryKey.waitListEntryHistoryID) {
      // END, CR00272514
      List<? extends WaitListEntryHistoryAccessor> waitListEntryHistoryAccessor = waitListEntry.getWaitListEntryHistory();

      for (WaitListEntryHistoryAccessor waitListEntryHistory : waitListEntryHistoryAccessor) {

        if (waitListEntryHistory.getID()
          == waitListEntryHistoryKey.waitListEntryHistoryID) {
          waitListEntryHistoryDetails.dtls.waitListEntHistID = waitListEntryHistory.getID();
          waitListEntryHistoryDetails.dtls.waitListEntryID = waitListEntryKey.waitListEntryID;
          waitListEntryHistoryDetails.dtls.expiryDate = waitListEntryHistory.getExpiryDate();
          waitListEntryHistoryDetails.dtls.comments = waitListEntryHistory.getComments();
          waitListEntryHistoryDetails.dtls.lastChangedDateTime = waitListEntryHistory.getChangeDateTime();
          waitListEntryHistoryDetails.dtls.position = waitListEntryHistory.getPosition();
          waitListEntryHistoryDetails.dtls.priority = waitListEntryHistory.getPriority().getCode();
          waitListEntryHistoryDetails.dtls.removalReason = waitListEntryHistory.getRemovalReason().getCode();

          waitListEntryHistoryDetails.dtls.reviewDate = waitListEntryHistory.getReviewDate();

          // BEGIN, CR00158671, RPB
          Integer reviewReminderPeriod = Configuration.getIntProperty(
            EnvVars.ENV_WAITLIST_STATUS_REVIEW_REMINDER_PERIOD);
          int defaultValue = EnvVars.ENV_WAITLIST_STATUS_REVIEW_REMINDER_PERIOD_DEFAULT;

          if (reviewReminderPeriod != null
            && waitListEntryHistory.getReviewDate().isZero()
            && !reviewReminderPeriod.equals(defaultValue)
            && reviewReminderPeriod != 0
            && !waitListEntryHistory.getExpiryDate().isZero()) {
            waitListEntryHistoryDetails.dtls.reviewDate = waitListEntryHistory.getExpiryDate().addDays(
              -reviewReminderPeriod);
          }
          // END, CR00158671
          waitListEntryHistoryDetails.dtls.status = waitListEntryHistory.getStatus().getCode();

          waitListEntryHistoryDetails.lastUpdatedBy = waitListEntryHistory.getTransactionUserName();
          waitListEntryHistoryDetails.concernRoleName = waitListEntryDetails.concernRoleName;
          waitListEntryHistoryDetails.concernRoleID = waitListEntryDetails.concernRoleID;

        }
      }
      // BEGIN, CR00272514, GP
    } else {
      waitListEntryHistoryDetails.dtls.expiryDate = waitListEntry.getLatestHistory().getExpiryDate();
      waitListEntryHistoryDetails.dtls.priority = waitListEntry.getLatestHistory().getPriority().getCode();
      waitListEntryHistoryDetails.dtls.reviewDate = waitListEntry.getLatestHistory().getReviewDate();

      Integer reviewReminderPeriod = Configuration.getIntProperty(
        EnvVars.ENV_WAITLIST_STATUS_REVIEW_REMINDER_PERIOD);
      int defaultValue = EnvVars.ENV_WAITLIST_STATUS_REVIEW_REMINDER_PERIOD_DEFAULT;

      if (reviewReminderPeriod != null
        && waitListEntry.getReviewDate().isZero()
        && !reviewReminderPeriod.equals(defaultValue)
        && reviewReminderPeriod != 0 && !waitListEntry.getExpiryDate().isZero()) {
        waitListEntryHistoryDetails.dtls.reviewDate = waitListEntry.getLatestHistory().getExpiryDate().addDays(
          -reviewReminderPeriod);
      }
      // END, CR00272514


    }
    return waitListEntryHistoryDetails;
  }

  // END, CR00156341

  /**
   * Allocates the wait list for the client.
   *
   * @param cancelOverlappingServiceOfferingInd
   * If set the overlapping reservations will be canceled.
   * @param waitListEntryID
   * Wait List Entry ID
   * @param waitListPeriod
   * Wait list period.
   * @param existingPlacementPeriodChangeInd
   * If set the existing placement period will be changed.
   * @param placeID
   * Unique ID of the place.
   * @param selectedServiceOfferingID
   * Unique ID of the service offering.
   * @param removeOpenWaitListInd
   * If set the open wait list entries will be removed.
   *
   * @return Wait list Allocated ID.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected long allocatePlaceToClient(long waitListEntryID,
    DateTimeRange waitListPeriod, boolean existingPlacementPeriodChangeInd,
    long placeID, long selectedServiceOfferingID,
    boolean cancelOverlappingReservationsInd, boolean removeOpenWaitListInd,
    int versionNo) throws AppException, InformationalException {

    return allocatePlaceToWaitListedClient(waitListEntryID, waitListPeriod,
      existingPlacementPeriodChangeInd, placeID, selectedServiceOfferingID,
      cancelOverlappingReservationsInd, removeOpenWaitListInd, versionNo);
  }

  /**
   * Sorts a set of wait list entries by position.
   *
   * @param unsortedWaitListEntries
   * The list of unsorted wait list entries.
   * @return A sorted list of wait list entries.
   */
  protected ArrayList<WaitListEntry> sortWaitListEntriesByPosition(
    final Set<WaitListEntry> unsortedWaitListEntries) {

    // Sort by position for display

    final ArrayList<WaitListEntry> waitListEntries = new ArrayList<WaitListEntry>(
      unsortedWaitListEntries);

    Collections.sort(waitListEntries, new Comparator<WaitListEntry>() {
      public int compare(final WaitListEntry lhs, WaitListEntry rhs) {

        Short lhsPosition = new Short(lhs.getPosition());
        Short rhsPosition = new Short(rhs.getPosition());

        return lhsPosition.compareTo(rhsPosition);
      }
    });
    return waitListEntries;
  }

  /**
   * Retrieves the contents of the Wait List Entry into Wait List Entry Details
   * structs and returns it.
   *
   * @param waitListEntry
   * The source wait list entry from which data is extracted.
   * @return A populated struct containing wait list entry details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  protected WaitListEntryDetails getWaitListEntryDetails(
    WaitListEntry waitListEntry) throws AppException, InformationalException {

    WaitListEntryDetails waitListEntryDetails = new WaitListEntryDetails();

    waitListEntryDetails.waitListEntryDtls.waitListEntryID = waitListEntry.getID();
    CaseParticipantRole_eoFullDetails clientDetails = retrieveClientDetails(
      waitListEntry.getClient());

    waitListEntryDetails.concernRoleID = clientDetails.participantRoleID;
    waitListEntryDetails.concernRoleName = clientDetails.name;
    waitListEntryDetails.waitListEntryDtls.position = waitListEntry.getPosition();
    waitListEntryDetails.waitListEntryDtls.expiryDate = waitListEntry.getExpiryDate();
    waitListEntryDetails.waitListEntryDtls.priority = waitListEntry.getPriority().getCode();
    waitListEntryDetails.waitListEntryDtls.status = waitListEntry.getLifecycleState().getCode();
    waitListEntryDetails.waitListEntryDtls.removalReason = waitListEntry.getRemovalReason().getCode();
    waitListEntryDetails.waitListEntryDtls.versionNo = waitListEntry.getVersionNo();

    // BEGIN, CR00156341, RPB
    waitListEntryDetails.waitListEntryDtls.reviewDate = waitListEntry.getReviewDate();

    // BEGIN, CR00158671, RPB
    Integer reviewReminderPeriod = Configuration.getIntProperty(
      EnvVars.ENV_WAITLIST_STATUS_REVIEW_REMINDER_PERIOD);
    int defaultValue = EnvVars.ENV_WAITLIST_STATUS_REVIEW_REMINDER_PERIOD_DEFAULT;

    if (reviewReminderPeriod != null
      && waitListEntryDetails.waitListEntryDtls.reviewDate.isZero()
      && !reviewReminderPeriod.equals(defaultValue)
      && reviewReminderPeriod != 0 && !waitListEntry.getExpiryDate().isZero()) {
      waitListEntryDetails.waitListEntryDtls.reviewDate = waitListEntry.getExpiryDate().addDays(
        -reviewReminderPeriod);
    }
    // END, CR00158671

    waitListEntryDetails.waitListEntryDtls.comments = waitListEntry.getComments();
    // END, CR00156341

    if (waitListEntry.getPosition() > 0) {
      waitListEntryDetails.positionString = String.valueOf(
        waitListEntry.getPosition());
    }

    // Read the context description based on resource type.
    if (waitListEntry.getWaitList().getType().equals(WAITLISTTYPEEntry.PROVIDER)) {

      curam.cpm.facade.intf.Provider providerObj = curam.cpm.facade.fact.ProviderFactory.newInstance();
      curam.cpm.sl.entity.struct.ProviderConcernRoleKey providerConcernRoleKey = new curam.cpm.sl.entity.struct.ProviderConcernRoleKey();

      providerConcernRoleKey.providerConcernRoleID = waitListEntry.getWaitList().getResourceID();
      ViewProviderSummaryDetails viewProviderSummaryDetails = providerObj.readProviderSummaryDetails(
        providerConcernRoleKey);

      waitListEntryDetails.contextDescription = viewProviderSummaryDetails.pageContextDescription;

    } else if (waitListEntry.getWaitList().getType().equals(
      WAITLISTTYPEEntry.PROVIDEROFFERING)) {

      curam.cpm.facade.intf.ProviderOffering providerOfferingObj = curam.cpm.facade.fact.ProviderOfferingFactory.newInstance();
      ProviderOfferingKey providerOfferingKey = new ProviderOfferingKey();

      providerOfferingKey.providerOfferingID = waitListEntry.getWaitList().getResourceID();
      ViewProviderOfferingDetails viewProviderOfferingDetails = providerOfferingObj.viewProviderOffering(
        providerOfferingKey);

      waitListEntryDetails.contextDescription = viewProviderOfferingDetails.serviceOfferingName;

      curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceOfferingDAO.get(
        viewProviderOfferingDetails.providerOfferingDtls.serviceOfferingID);

      // set the allocatePlaceInd flag if the service offering is of type Place.
      if (serviceOffering.getUnitOfMeasure().equals(UnitOfMeasureEntry.PLACE)) {
        waitListEntryDetails.allocatePlaceInd = true;
      }
    }

    return waitListEntryDetails;
  }

  // BEGIN, CR00236379, SK
  /**
   * {@inheritDoc}
   */
  public WaitListEntryDetailsInfo viewWaitListEntryDetails(
    final WaitListEntryKey waitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKey.waitListEntryID);
    WaitListEntryDetailsInfo waitListEntryDetailsInfo = new WaitListEntryDetailsInfo();

    waitListEntryDetailsInfo.details = getWaitListEntryDetails(waitListEntry);
    waitListEntryDetailsInfo.lastUpdatedBy = waitListEntry.getLatestHistory().getTransactionUserName();
    waitListEntryDetailsInfo.lastUpdatedTime = waitListEntry.getLatestHistory().getChangeDateTime();

    return waitListEntryDetailsInfo;
  }

  // END, CR00236379

  // BEGIN, CR00272514, GP
  /**
   * Retrieves the wait list entry details along with latest history information
   * like last updated date time and last updated user.
   *
   * @param waitListEntryKey
   * Contains a Wait List Entry ID.
   *
   * @return The wait list entry details for a wait list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public WaitListEntryViewDetails viewWaitListEntryDetailsFromSearch(
    final WaitListEntryKey waitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntryDetailsInfo waitListEntryDetailsInfo = viewWaitListEntryDetails(
      waitListEntryKey);
    WaitListEntryViewDetails waitListEntryViewDetails = new WaitListEntryViewDetails();
    ProviderOfferingKey providerOfferingKey = new ProviderOfferingKey();
    curam.cpm.facade.intf.ProviderOffering providerOfferingObj = curam.cpm.facade.fact.ProviderOfferingFactory.newInstance();

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKey.waitListEntryID);

    waitListEntryViewDetails.assign(waitListEntryDetailsInfo);

    if (WAITLISTENTRYSTATUSEntry.REMOVED.getCode().equals(
      waitListEntryDetailsInfo.details.waitListEntryDtls.status)) {
      waitListEntryViewDetails.isStatusRemoved = true;
    }
    if (waitListEntry.getWaitList().getType().equals(
      WAITLISTTYPEEntry.PROVIDEROFFERING)) {

      providerOfferingKey.providerOfferingID = waitListEntry.getWaitList().getResourceID();
      ViewProviderOfferingDetails viewProviderOfferingDetails = providerOfferingObj.viewProviderOffering(
        providerOfferingKey);

      waitListEntryViewDetails.isProviderOffering = true;
      waitListEntryViewDetails.serviceName = viewProviderOfferingDetails.serviceOfferingName;
    }

    if (waitListEntryViewDetails.isProviderOffering
      && waitListEntryViewDetails.isStatusRemoved) {
      waitListEntryViewDetails.isProviderOfferingAndStatusRemoved = true;
      waitListEntryViewDetails.isProviderOffering = waitListEntryViewDetails.isStatusRemoved = false;
    }

    return waitListEntryViewDetails;
  }

  // END, CR00272514

  /**
   * Sorts the wait list entry status history by the changed date time of the
   * wait list entry.
   *
   * @param statusHistory
   * List of wait list entry status history to be sorted.
   * @return Sorted list of wait list entry status history.
   */
  protected List<WaitListEntryStatusHistory> sortWaitListEntryStausHistoryByDateTime(
    List<WaitListEntryStatusHistory> statusHistory) {

    Collections.sort(statusHistory,
      new Comparator<WaitListEntryStatusHistory>() {
      public int compare(final WaitListEntryStatusHistory lhs,
        WaitListEntryStatusHistory rhs) {
        return rhs.getChangeDateTime().compareTo(lhs.getChangeDateTime());
      }
    });
    return statusHistory;
  }

  // BEGIN, CR00159124, RPB
  /**
   * Sorts the wait list entry history by the changed date time of the wait list
   * entry.
   *
   * @param waitListEntryHistory
   * List of wait list entry history to be sorted.
   * @return Sorted list of wait list entry history.
   */
  protected List<? extends WaitListEntryHistoryAccessor> sortWaitListEntryHistoryByDateTime(
    List<? extends WaitListEntryHistoryAccessor> waitListEntryHistory) {

    Collections.sort(waitListEntryHistory,
      new Comparator<WaitListEntryHistoryAccessor>() {
      public int compare(final WaitListEntryHistoryAccessor lhs,
        WaitListEntryHistoryAccessor rhs) {
        return rhs.getChangeDateTime().compareTo(lhs.getChangeDateTime());
      }
    });
    return waitListEntryHistory;
  }

  // END, CR00159124

  /**
   * Sorts a set of provider offerings based on provider offering name.
   *
   * @param unsortedProviderOfferings
   * A set of unsorted provider offerings.
   * @return A set of sorted list of provider offerings.
   */
  protected List<ProviderOffering> sortProviderOfferings(
    final Set<ProviderOffering> unsortedProviderOfferings) {

    final List<ProviderOffering> sortedProviderOfferings = new ArrayList<ProviderOffering>(
      unsortedProviderOfferings);

    Collections.sort(sortedProviderOfferings,
      new Comparator<ProviderOffering>() {
      public int compare(final ProviderOffering lhs, ProviderOffering rhs) {
        return lhs.getServiceOffering().getName().compareTo(
          rhs.getServiceOffering().getName());
      }
    });
    return sortedProviderOfferings;
  }

  /**
   * Populates the wait list entry status history entity details into the
   * standard struct.
   *
   * @param statusHistory
   * Wait list status history entity details.
   * @return The standard struct holding wait list entry status details.
   */
  protected WaitListEntryStatusHistoryDtls getWaitListEntryStatusHistoryDetails(
    WaitListEntryStatusHistory statusHistory) {
    WaitListEntryStatusHistoryDtls statusHistoryDtls = new WaitListEntryStatusHistoryDtls();

    statusHistoryDtls.waitListEntryStatusHistoryID = statusHistory.getID();
    statusHistoryDtls.changeDateTime = statusHistory.getChangeDateTime();
    statusHistoryDtls.userName = statusHistory.getUserName();
    statusHistoryDtls.status = statusHistory.getStatus().getCode();

    return statusHistoryDtls;
  }

  /**
   * Filters the provider offerings of a particular provider, for which wait
   * list is created.
   *
   * @param provider
   * Contains the provider information.
   * @return A list of provider offering details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  protected Set<ProviderOffering> listProviderOfferingWaitListForProvider(
    final Provider provider) throws InformationalException, AppException {

    // Retrieve all the provider offerings for the specified provider.
    Set<curam.providerservice.impl.ProviderOffering> unModifiableProviderOfferings = provider.getProviderOfferings();
    Set<curam.providerservice.impl.ProviderOffering> providerOfferings = new HashSet<curam.providerservice.impl.ProviderOffering>();

    providerOfferings.addAll(unModifiableProviderOfferings);

    // The set contains only those provider offerings which has corresponding
    // wait lists.
    Set<ProviderOffering> filteredProviderOfferings = new HashSet<ProviderOffering>();

    // Retrieve the wait list information for every provider offering, which is
    // a resource in a wait list.
    for (ProviderOffering providerOffering : providerOfferings) {
      Set<WaitListEntry> waitListEntries = listWaitListEntryForResource(
        providerOffering.getID());

      if (waitListEntries.size() > 0) {
        filteredProviderOfferings.add(providerOffering);
        continue;
      }
    }
    return filteredProviderOfferings;
  }

  /**
   * Lists all the wait list entries for a given resource.
   *
   * @param resourceID
   * The ID of the resource for which the wait list entries are to be
   * listed.
   * @return A list of all wait list entries for the given resource.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  protected Set<WaitListEntry> listWaitListEntryForResource(long resourceID)
    throws InformationalException, AppException {

    Set<WaitListEntry> filteredWaitListEntries = new HashSet<WaitListEntry>();

    // Search the wait list for the resource.
    WaitList waitList = waitListDAO.readByResourceID(resourceID);

    if (waitList != null) {
      Set<WaitListEntry> waitListEntries = waitList.getEntries();

      // Filter the wait list entries by status open.
      for (WaitListEntry waitListEntry : waitListEntries) {
        if (waitListEntry.getLifecycleState().equals(
          WAITLISTENTRYSTATUSEntry.OPEN)) {
          filteredWaitListEntries.add(waitListEntry);
        }
      }
    }
    return filteredWaitListEntries;
  }

  /**
   * Retrieves the list of reservations that overlaps with the period.
   *
   * @param dateTimeRange
   * Wait list date range.
   * @param client
   * Client details.
   * @return Set of reservations that overlaps with the period.
   */
  protected Set<Reservation> overlappingReservationsForClient(
    DateTimeRange dateTimeRange, curam.participant.person.impl.Person client) {

    Set<Reservation> overlappingReservations = new HashSet<Reservation>();

    ConcernRole concernRole = concernRoleDAO.get(client.getID());

    // BEGIN, CR00137279, JSP
    for (Reservation overlappingReservation : reservationDAO.searchReservationByClient(
      RESERVATIONSTATUSEntry.ACTIVE, dateTimeRange, concernRole)) {
      // END, CR00137279

      if (dateTimeRange.overlapsWith(overlappingReservation.getDateTimeRange())) {
        overlappingReservations.add(overlappingReservation);
      }
    }
    return overlappingReservations;
  }

  /**
   * Retrieves the list of open wait lists for the client and the case.
   *
   * @param caseParticipantRoleID
   * Case participant role ID.
   * @param waitListEntryStatusEntry
   * Wait list entry status.
   * @return Wait list entry list.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Set<WaitListEntry> openWaitListsForCase(long caseParticipantRoleID,
    WAITLISTENTRYSTATUSEntry waitListEntryStatusEntry)
    throws InformationalException, AppException {

    return waitListEntryDAO.searchByClientAndStatus(caseParticipantRoleID,
      waitListEntryStatusEntry);
  }

  /**
   * Cancels the reservations overlapping with the wait list date time range.
   *
   * @param cancelOverlappingReservationInd
   * If set the over lapping reservations will be canceled.
   * @param waitListPeriod
   * Wait list period.
   * @param waitListEntryID
   * Unique ID of the wait list entry.
   * @param reservation
   * Reservation details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void cancelOverlappingActiveReservations(
    DateTimeRange waitListPeriod,
    boolean cancelOverlappingServiceOfferingInd, final long waitListEntryID,
    Reservation reservation) throws InformationalException, AppException {

    WaitListEntry waitListEntry = waitListEntryDAO.get(waitListEntryID);

    // Get the client details from the case participant role
    // ID.
    final CaseParticipantRoleAdapter caseParticipantRoleAdapter = new CaseParticipantRoleAdapter();
    final long participantRoleID = caseParticipantRoleAdapter.read(waitListEntry.getClient(), false).participantRoleID;

    Person client = personDAO.get(personDAO.get(participantRoleID).getID());

    // List of overlapping reservation for the client.
    Set<Reservation> overlappingReservaList = overlappingReservationsForClient(
      waitListPeriod, client);

    if (!overlappingReservaList.isEmpty()) {

      for (Reservation overlappingReservation : overlappingReservaList) {

        if (reservation == null
          || (!overlappingReservation.getID().equals(reservation.getID()))) {
          if (cancelOverlappingServiceOfferingInd) {

            // Cancels the over lapping reservations.
            overlappingReservation.cancel(overlappingReservation.getVersionNo(),
              RESERVATIONCANCELREASONEntry.ALTERNATIVERESERVATION);
          }
        }
      }
    }
  }

  /**
   * Removes all the open wait list entries.
   *
   * @param removeOpenWaitListInd
   * If set then the open wait list entries will be removed.
   * @param waitListEntryID
   * Unique ID of the wait list entry.
   *
   * @throws InformationalException
   * {@link WAITLIST#INF_WAITLIST_ENTRY_XRV_CLIENT_IS_WAITLISTED_FOR_PROVIDER_OR_PROVIDER_OFFERING}
   * If open wait list entries exist for the same case.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void removeOpenWaitListEntriesForCase(
    boolean removeOpenWaitListInd, long waitListEntryID)
    throws InformationalException, AppException {

    WaitListEntry waitListEntry = waitListEntryDAO.get(waitListEntryID);

    // Retrieve the open wait lists for the client.
    Set<WaitListEntry> openWaitListEntryList = openWaitListsForCase(
      waitListEntry.getClient(), WAITLISTENTRYSTATUSEntry.OPEN);

    if (!openWaitListEntryList.isEmpty()) {

      if (removeOpenWaitListInd) {

        // Remove the wait list entries.
        for (WaitListEntry openWaitListEntry : openWaitListEntryList) {
          WaitListEntry waitListEnt = waitListEntryDAO.get(
            openWaitListEntry.getID());

          waitListEnt.setRemovalReason(
            WAITLISTREMOVALREASONEntry.PLACEDWITHANOTHERPROVIDER);
          waitListEnt.cancel(openWaitListEntry.getVersionNo());
        }
      } else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          new AppException(
            WAITLIST.INF_WAITLIST_ENTRY_XRV_CLIENT_IS_WAITLISTED_FOR_PROVIDER_OR_PROVIDER_OFFERING),
            curam.core.impl.CuramConst.gkEmpty,
            InformationalElement.InformationalType.kWarning,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  }

  /**
   * Allocates a place to a wait listed client.
   *
   * @param removeOpenWaitListEntryInd
   * If set open wait list entries for the client will be removed.
   * @param cancelOverlappingReservationInd
   * If set overlapping reservations will be canceled.
   * @param waitListEntryID
   * Unique ID of the wait list entry.
   * @param waitListPeriod
   * Wait list period.
   * @param existingPlacementPeriodChangeInd
   * If set existing placement period will be updated.
   * @param placeID
   * Unique ID of the place.
   * @param selectedServiceOfferingID
   * Unique ID of the service offering.
   * @param versionNo
   * Version number.
   *
   * @return Returns a place ID or reservation ID.
   *
   * @throws InformationalException
   * {@link WaitList#ERR_WAITLIST_ENTRY_XRV_PLACE_NOT_AVAILABLE_FROM_DATETIME}
   * Place is not available for wait list period with no end date
   * time.
   * {@link WaitList#ERR_WAITLIST_ENTRY_XRV_PLACE_NOT_AVAILABLE_FROM_DATETIME_TO_DATETIME}
   * Place is not available for wait list period.
   * {@link WaitList#ERR_WAITLIST_ENTRY_XRV_CLIENT_ALREADY_PLACED_PLACEMENT_CANNOT_BE_CREATED}
   * Client is already place and placement cannot be created.
   * @throws AppException
   * Generic Exception Signature.
   */

  protected long allocatePlaceToWaitListedClient(long waitListEntryID,
    DateTimeRange waitListPeriod, Boolean existingPlacementPeriodChangeInd,
    Long placeID, Long selectedServiceOfferingID,
    boolean cancelOverlappingServiceOfferingInd,
    boolean removeOpenWaitListInd, int versionNo) throws AppException,
      InformationalException {

    Provider provider = null;
    ServiceOffering serviceOffering = null;
    Placement placement = null;
    Place place = null;
    curam.waitlist.impl.WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryID);

    long caseParticipantRoleID = waitListEntry.getClient();

    WaitList waitListObj = waitListEntry.getWaitList();

    // If the wait list type is provider, retrieve the provider ID.
    if (waitListObj.getType().equals(WAITLISTTYPEEntry.PROVIDER)) {
      provider = providerDAO.get(waitListObj.getResourceID());
      serviceOffering = serviceOfferingDAO.get(selectedServiceOfferingID);

    }
    // If the wait list type is provider offering, retrieve the provider ID and
    // service offering ID.
    if (waitListObj.getType().equals(WAITLISTTYPEEntry.PROVIDEROFFERING)) {

      ProviderOffering providerOffering = providerOfferingDAO.get(
        waitListObj.getResourceID());

      provider = providerOffering.getProvider();
      serviceOffering = providerOffering.getServiceOffering();
    }

    Reservation reservation = reservationDAO.newInstance();

    if (placeID == 0) {
      // Retrieve the list of available places in the date range.
      Set<Place> placeList = reservation.getPlaceAvailableInDateRange(provider,
        waitListPeriod);

      // If the place list is not empty, retrieve the first place.
      if (!placeList.isEmpty()) {

        Iterator<Place> placeIterator = placeList.iterator();

        placeID = placeIterator.next().getID();
        place = placeDAO.get(placeID);

      } else {
        if (waitListPeriod.end().equals(DateTime.kZeroDateTime)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            WAITLISTExceptionCreator.ERR_WAITLIST_ENTRY_XRV_PLACE_NOT_AVAILABLE_FROM_DATETIME(
              waitListPeriod.start()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        } else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            WAITLISTExceptionCreator.ERR_WAITLIST_ENTRY_XRV_PLACE_NOT_AVAILABLE_FROM_DATETIME_TO_DATETIME(
              waitListPeriod.start(), waitListPeriod.end()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }
        ValidationHelper.failIfErrorsExist();
      }
    }

    // Check if the start date is in the future.
    if (waitListPeriod.start().after(DateTime.getCurrentDateTime())) {

      reservation = reservation.createReservation(caseParticipantRoleID,
        serviceOffering, provider, waitListPeriod, Money.kZeroMoney, false,
        place, false, CPMConstants.kEmptyString);
    } else {
      // Retrieve the overlapping placement if any.
      placement = placementDAO.newInstance();
      Placement overlappingPlacement = placement.getOverlappingPlacementForClient(
        caseParticipantRoleID, waitListPeriod);

      // Check if there is an overlapping placement and the placement should be
      // ended.
      if (overlappingPlacement != null) {
        if (existingPlacementPeriodChangeInd) {

          // Update the placement end date to one minute before the end
          // date time.
          placementAPI.updatePlacementPeriod(overlappingPlacement.getID(),
            new DateTimeRange(overlappingPlacement.getDateTimeRange().start(),
            waitListPeriod.start().addTime(0, -1, 0)),
            overlappingPlacement.getVersionNo(),
            overlappingPlacement.getPlace().getVersionNo());

        } else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            WAITLISTExceptionCreator.ERR_WAITLIST_ENTRY_XRV_CLIENT_ALREADY_PLACED_PLACEMENT_CANNOT_BE_CREATED(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

          ValidationHelper.failIfErrorsExist();
        }
      }
      // Create a placement record.

      placement = placementAPI.createPlacement(caseParticipantRoleID,
        serviceOffering.getID(), provider.getID(), placeID, waitListPeriod,
        Money.kZeroMoney, false);

    }

    // Change the wait list entry status to allocated.
    waitListEntry = waitListEntryDAO.get(waitListEntryID);
    waitListEntry.allocate(versionNo);

    // Cancel the reservations that overlaps with the wait list period.
    cancelOverlappingActiveReservations(waitListPeriod,
      cancelOverlappingServiceOfferingInd, waitListEntryID, reservation);

    // Remove the wait list open entries for the same client and case.
    removeOpenWaitListEntriesForCase(removeOpenWaitListInd, waitListEntryID);

    if (reservation != null) {
      return reservation.getID();
    } else {
      return placement.getID();
    }
  }

  /**
   * Retrieves the details of the client by specifying a case participant role
   * id.
   *
   * @param caseParticipantRoleID
   * Case participant role ID.
   * @return Details of the client.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected CaseParticipantRole_eoFullDetails retrieveClientDetails(
    long caseParticipantRoleID) throws AppException, InformationalException {

    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = caseParticipantRoleID;

    curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();

    // Get the client name from the case participant role ID.
    CaseParticipantRole_eoFullDetails caseParticipantRoleDetails = caseParticipantRole.readFullDetails(
      caseParticipantRoleKey);

    return caseParticipantRoleDetails;
  }
  
  /**
   * Sorts a set of wait list entries in descending order of the review date.
   *
   * @param unSortedWaitListEntries
   * The set of unsorted wait list entries.
   *
   * @return A list of wait list entries sorted by review date.
   */
  protected List<WaitListEntry> sortWaitListEntriesByReviewDate(
    final Set<WaitListEntry> unSortedWaitListEntries) {

    final List<WaitListEntry> waitListEntries = new ArrayList<WaitListEntry>(
      unSortedWaitListEntries);

    Collections.sort(waitListEntries, new Comparator<WaitListEntry>() {
      public int compare(final WaitListEntry lhs, WaitListEntry rhs) {
        return rhs.getReviewDate().compareTo(lhs.getReviewDate());
      }
    });

    return waitListEntries;
  }
  
  // BEGIN, CR00292696, IBM
  /**
   * Collects the list of informations from the informational manager and adds
   * them to the list parameter passed in.
   *
   * @param informationalMsgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList informationalMsgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    final String[] infos = informationalManager.obtainInformationalAsString();

    for (final String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }

  // END, CR00292696
  
  // BEGIN, CR00293856, IBM
  /**
   * {@inheritDoc}
   */
  public AssignPlaceDetails assignPlace(
    final AllocatePlaceDetails allocatePlaceDetails) throws AppException,
      InformationalException {

    Placement placement = placementDAO.newInstance();
    WaitListEntry waitListEntry = waitListEntryDAO.get(
      allocatePlaceDetails.keyVersionDtls.id);

    if (WAITLISTTYPE.PROVIDER.equals(waitListEntry.getWaitList().getType())) {

      providerSecurity.checkProviderSecurity(
        providerDAO.get(waitListEntry.getWaitList().getResourceID()));
    } else if (WAITLISTTYPE.PROVIDEROFFERING.equals(
      waitListEntry.getWaitList().getType())) {

      providerSecurity.checkProviderSecurity(
        providerOfferingDAO.get(waitListEntry.getWaitList().getResourceID()).getProvider());
    }

    DateTimeRange waitListDateTimeRange = new DateTimeRange(
      allocatePlaceDetails.fromDateTime, allocatePlaceDetails.toDateTime);

    AssignPlaceDetails assignPlaceDetails = new AssignPlaceDetails();

    assignPlaceDetails.cancelOverlappingRsrvInd = allocatePlaceDetails.cancelOverlappingRsrvInd;
    assignPlaceDetails.existingPlacementPeriodChangeInd = allocatePlaceDetails.existingPlacementPeriodChangeInd;
    assignPlaceDetails.fromDateTime = allocatePlaceDetails.fromDateTime;
    assignPlaceDetails.keyVersionDtls = allocatePlaceDetails.keyVersionDtls;
    assignPlaceDetails.placeID = allocatePlaceDetails.placeID;
    assignPlaceDetails.removeOpenWaitListInd = allocatePlaceDetails.removeOpenWaitListInd;
    assignPlaceDetails.serviceOfferingID = allocatePlaceDetails.serviceOfferingID;
    assignPlaceDetails.toDateTime = allocatePlaceDetails.toDateTime;
    assignPlaceDetails.waitListAllocatedID = allocatePlaceDetails.waitListAllocatedID;
    assignPlaceDetails.waitListTypeInd = allocatePlaceDetails.waitListTypeInd;

    assignPlaceDetails.openWaitListInd = false;
    assignPlaceDetails.overlappingRsrvInd = false;
    assignPlaceDetails.placementPeriodChangeInd = false;

    if (assignPlaceDetails.fromDateTime.before(DateTime.getCurrentDateTime())) {
      Placement overlappingPlacement = placement.getOverlappingPlacementForClient(
        waitListEntry.getClient(), waitListDateTimeRange);

      if (overlappingPlacement != null) {
        assignPlaceDetails.placementPeriodChangeInd = true;
      }
    } else {

      final CaseParticipantRoleAdapter caseParticipantRoleAdapter = new CaseParticipantRoleAdapter();
      final long participantRoleID = caseParticipantRoleAdapter.read(waitListEntry.getClient(), false).participantRoleID;

      Person client = personDAO.get(participantRoleID);

      Set<Reservation> overlappingReservations = overlappingReservationsForClient(
        waitListDateTimeRange, client);

      if (!overlappingReservations.isEmpty()) {
        assignPlaceDetails.overlappingRsrvInd = true;
      }
    }

    Set<WaitListEntry> openWaitListEntryList = openWaitListsForCase(
      waitListEntry.getClient(), WAITLISTENTRYSTATUSEntry.OPEN);

    if (openWaitListEntryList.size() > 1) {

      assignPlaceDetails.openWaitListInd = true;
    }

    assignPlaceDetails.cancelOverlappingRsrvInd = false;
    assignPlaceDetails.existingPlacementPeriodChangeInd = false;
    assignPlaceDetails.removeOpenWaitListInd = false;

    if (!assignPlaceDetails.placementPeriodChangeInd) {

      assignPlaceDetails.waitListAllocatedID = allocatePlaceToClient(
        assignPlaceDetails.keyVersionDtls.id, waitListDateTimeRange,
        assignPlaceDetails.existingPlacementPeriodChangeInd,
        assignPlaceDetails.placeID, assignPlaceDetails.serviceOfferingID,
        assignPlaceDetails.cancelOverlappingRsrvInd,
        assignPlaceDetails.removeOpenWaitListInd,
        assignPlaceDetails.keyVersionDtls.version);
    }

    if (waitListEntry.getWaitList().getType().equals(WAITLISTTYPEEntry.PROVIDER)) {
      assignPlaceDetails.waitListTypeInd = true;
    } else {
      assignPlaceDetails.waitListTypeInd = false;
    }

    collectInformationalMsgs(assignPlaceDetails.informationalMsgDtls);

    return assignPlaceDetails;
  }

  /**
   * {@inheritDoc}
   */
  public PlaceAndPlaceLocationDetailsList getAvailablePlaces(
    final WaitListPeriodKey waitlistPeriodKey) throws AppException,
      InformationalException {

    PlaceAndPlaceLocationDetailsList placeLocationList = new PlaceAndPlaceLocationDetailsList();
    Reservation reservation = reservationDAO.newInstance();

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitlistPeriodKey.waitListEntryID);

    Set<curam.place.impl.Place> availablePlaces = null;

    if (WAITLISTTYPEEntry.PROVIDEROFFERING.equals(
      waitListEntry.getWaitList().getType())) {

      availablePlaces = reservation.getPlaceAvailableInDateRange(
        providerOfferingDAO.get(waitListEntry.getWaitList().getResourceID()).getProvider(),
        new DateTimeRange(waitlistPeriodKey.from, waitlistPeriodKey.to));

    } else if (waitListEntry.getWaitList().getType().equals(
      WAITLISTTYPEEntry.PROVIDER)) {

      availablePlaces = reservation.getPlaceAvailableInDateRange(
        providerDAO.get(waitListEntry.getWaitList().getResourceID()),
        new DateTimeRange(waitlistPeriodKey.from, waitlistPeriodKey.to));
    }

    for (curam.place.impl.Place place : availablePlaces) {

      PlaceKey placeKey = new PlaceKey();

      PlaceAndPlaceLocation placeAndLocation = new PlaceAndPlaceLocation();

      placeKey.placeID = place.getID();
      PlaceLocationDetails placeLocationDetails = place.getLocationForPlace();

      placeAndLocation.placeLocation = placeLocationDetails.location;
      placeAndLocation.placeName = place.getName();
      placeAndLocation.placeID = place.getID();
      placeLocationList.place.addRef(placeAndLocation);
    }

    collectInformationalMsgs(placeLocationList.informationalMsgDtls);

    return placeLocationList;
  }
   
  /**
   * Updates the placement period overlapping with the wait list period and
   * allocates the wait list to the client.
   *
   * @param allocatePlaceDetails
   * Allocate place details.
   *
   * @return AllocatePlaceDetails Allocate place details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public AssignPlaceDetails modifyOverlappingPlacementPeriod(
    final AllocatePlaceDetails allocatePlaceDetails) throws AppException,
      InformationalException {

    DateTimeRange waitListDateTimeRange = new DateTimeRange(
      allocatePlaceDetails.fromDateTime, allocatePlaceDetails.toDateTime);

    AssignPlaceDetails assignPlaceDetails = new AssignPlaceDetails();

    assignPlaceDetails.cancelOverlappingRsrvInd = allocatePlaceDetails.cancelOverlappingRsrvInd;
    assignPlaceDetails.fromDateTime = allocatePlaceDetails.fromDateTime;
    assignPlaceDetails.keyVersionDtls = allocatePlaceDetails.keyVersionDtls;
    assignPlaceDetails.placeID = allocatePlaceDetails.placeID;
    assignPlaceDetails.removeOpenWaitListInd = allocatePlaceDetails.removeOpenWaitListInd;
    assignPlaceDetails.serviceOfferingID = allocatePlaceDetails.serviceOfferingID;
    assignPlaceDetails.toDateTime = allocatePlaceDetails.toDateTime;
    assignPlaceDetails.waitListAllocatedID = allocatePlaceDetails.waitListAllocatedID;
    assignPlaceDetails.waitListTypeInd = allocatePlaceDetails.waitListTypeInd;
    assignPlaceDetails.openWaitListInd = allocatePlaceDetails.openWaitListInd;
    assignPlaceDetails.overlappingRsrvInd = allocatePlaceDetails.overlappingRsrvInd;
    assignPlaceDetails.placementPeriodChangeInd = allocatePlaceDetails.placementPeriodChangeInd;
    assignPlaceDetails.existingPlacementPeriodChangeInd = true;

    if (!assignPlaceDetails.openWaitListInd
      && !assignPlaceDetails.overlappingRsrvInd) {

      // Allocate the place to the client
      assignPlaceDetails.waitListAllocatedID = allocatePlaceToClient(
        assignPlaceDetails.keyVersionDtls.id, waitListDateTimeRange,
        assignPlaceDetails.existingPlacementPeriodChangeInd,
        assignPlaceDetails.placeID, assignPlaceDetails.serviceOfferingID,
        assignPlaceDetails.cancelOverlappingRsrvInd,
        assignPlaceDetails.removeOpenWaitListInd,
        assignPlaceDetails.keyVersionDtls.version);

    }
        
    collectInformationalMsgs(assignPlaceDetails.informationalMsgDtls);
      
    return assignPlaceDetails;
  }
  // END, CR00293856
}
