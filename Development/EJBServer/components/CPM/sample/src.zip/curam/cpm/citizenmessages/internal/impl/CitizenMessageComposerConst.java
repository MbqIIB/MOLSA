/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.citizenmessages.internal.impl;


/**
 * This file contains String constants for CPM Citizen Message functionality.
 * This is internal and should not be called by customers.
 *
 */
class CitizenMessageComposerConst {

  /**
   * Names of the property files stored in the resource store that are used for
   * CPM citizen messages. These files are delivered as part of Citizen
   * Workspace.
   */
  final static String ServiceDeliveryPropertiesFileName = "CitizenMessageServiceDelivery";

  final static String ReferralPropertiesFileName = "CitizenMessageReferral";

  /**
   * This value is no longer used. The icon to display is retrieved from the
   * ParticipantMessageConfiguration record associated with the given message
   * type.
   */
  @Deprecated
  final static String ServiceDeliveryImageReference = "icon_service";

  /**
   * This value is no longer used. The icon to display is retrieved from the
   * ParticipantMessageConfiguration record associated with the given message
   * type.
   */
  @Deprecated
  final static String ReferralImageReference = "icon_referral";

  /**
   * References to keys to retrieve localisable values for message property
   * files.
   */
  final static String kServiceNameReference = "Service.Name";

  final static String kReferralOwner = "Referral.Owner";

  final static String kMessageTitleReference = "Message.Title";

  final static String kStartDateReference = "Start.Date";

  final static String kEndDateReference = "End.Date";

  final static String kHours = "Hours";

  final static String kDaysOfWeek = "Days.Of.Week";

  final static String kServiceOwner = "Service.Owner";

  final static String kProviderNameReference = "Provider.Name";

  final static String kFirstSentence = "First.Sentence";

  final static String kFirstSentenceStartDateHoursDayOfWeekEndDateProvider = "First.Sentence.StartDate.Hours.DayOfWeek.EndDate.Provider";

  final static String kFirstSentenceStartDateHoursDayOfWeekEndDateNoProvider = "First.Sentence.StartDate.Hours.DayOfWeek.EndDate.NoProvider";

  final static String kFirstSentenceStartDateEndDateProvider = "First.Sentence.StartDate.EndDate.Provider";

  final static String kFirstSentenceStartDateEndDateNoProvider = "First.Sentence.StartDate.EndDate.NoProvider";

  final static String kFirstSentenceStartDateHoursDayOfWeekProvider = "First.Sentence.StartDate.Hours.DayOfWeek.Provider";

  final static String kFirstSentenceStartDateHoursDayOfWeekNoProvider = "First.Sentence.StartDate.Hours.DayOfWeek.NoProvider";

  final static String kFirstSentenceStartDateProvider = "First.Sentence.StartDate.Provider";

  final static String kFirstSentenceStartDateNoProvider = "First.Sentence.StartDate.NoProvider";

  final static String kFirstSentenceNoProviderReference = "First.Sentence.NoProvider";

  final static String kFirstSentenceRepresentativeProvider = "First.Sentence.RepresentativeProvider";

  final static String kFirstSentenceNoProvider = "First.Sentence.NoProvider";

  final static String kEmailAddressReference = "Email.Address";

  final static String kSecondSentenceHasContactDetailsReference = "Second.Sentence.HasContactDetails";

  final static String kSecondSentenceNoContactDetailsReference = "Second.Sentence.NoContactDetails";

  final static String kPhoneNumberReference = "Phone.Number";

  final static String kThirdSentenceReference = "Third.Sentence";

  final static String kMailTo = "mailto:";

  final static String kEmailLinkReference = "Email.Link";

  final static String kMyActivitiesLinkReference = "Link.MyActivities";

  final static String kMyActivitiesLinkName = "My.Activities";

  final static String kReferralDateReference = "Referral.Date";

  final static String kFirstSentenceReference = "First.Sentence";

  /**
   * Constants related to the provider modal in Citizen Workspace.
   */
  final static String kProviderModalLinkName = "ProviderModalLink";

  final static String pagePlayerURL = "../cw/PlayerPage.do";

  final static Integer providerModalHieght = 495;

  final static Integer providerModalWidth = 993;

  final static String providerModalPageParameterName = "page";

  final static String providerModalServiceIDParameterName = "serviceID";

  final static String providerModalPageName = "ProviderServiceModal";

  final static String referralModalPageName = "ConcernRoleServiceModal";

  final static String referralModalReferralIDParameterName = "referralID";
}
