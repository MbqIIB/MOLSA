/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.facade.impl;


import com.google.inject.Inject;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.ProviderBackgroundCheckDetails;
import curam.cpm.facade.struct.ProviderBackgroundCheckDetailsList;
import curam.cpm.facade.struct.ProviderBackgroundCheckSummaryDetails;
import curam.cpm.facade.struct.ProviderMemberSummaryDetails;
import curam.cpm.facade.struct.ProviderMemberSummaryDetailsList;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.BackgroundCheckFailureReasonDtls;
import curam.cpm.sl.entity.struct.BackgroundCheckFailureReasonKey;
import curam.cpm.sl.entity.struct.ProviderBackgroundCheckDtls;
import curam.cpm.sl.entity.struct.ProviderBackgroundCheckKey;
import curam.cpm.sl.entity.struct.ProviderGroupKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.participant.impl.ConcernRole;
import curam.provider.impl.BackgroundCheckFailureReason;
import curam.provider.impl.BackgroundCheckFailureReasonDAO;
import curam.provider.impl.BackgroundCheckFailureReasonTypeEntry;
import curam.provider.impl.BackgroundCheckResultEntry;
import curam.provider.impl.BackgroundCheckTypeEntry;
import curam.provider.impl.PGBackgroundCheckFailureReason;
import curam.provider.impl.PGBackgroundCheckFailureReasonDAO;
import curam.provider.impl.ProviderBackgroundCheckDAO;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderGroup;
import curam.provider.impl.ProviderGroupBackgroundCheck;
import curam.provider.impl.ProviderGroupBackgroundCheckDAO;
import curam.provider.impl.ProviderGroupDAO;
import curam.provider.impl.ProviderMember;
import curam.provider.impl.ProviderMemberDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.LifecycleHelper;
import curam.util.type.DateRange;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * Facade layer class for all the functionality relating to a Provider
 * Background check and background check failure reason.
 *
 */
public abstract class ProviderBackgroundCheck extends curam.cpm.facade.base.ProviderBackgroundCheck {

  /**
   * Injecting the DAO class for Provider
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Injecting the DAO class for Provider Group
   */
  @Inject
  protected ProviderGroupDAO providerGroupDAO;

  /**
   * Injecting the DAO class for Provider Member
   */
  @Inject
  protected ProviderMemberDAO providerMemberDAO;

  /**
   * Injecting the DAO class for Provider Background Check
   */
  @Inject
  protected ProviderBackgroundCheckDAO providerBackgroundCheckDAO;

  /**
   * Injecting the DAO class for Provider Group Background Check
   */
  @Inject
  protected ProviderGroupBackgroundCheckDAO providerGroupBackgroundCheckDAO;

  /**
   * Injecting the DAO class for Provider Background Check failure Reason
   */
  @Inject
  protected BackgroundCheckFailureReasonDAO backgroundCheckFailureReasonDAO;

  /**
   * Injecting the DAO class for Provider Group Background Check failure Reason
   */
  @Inject
  protected PGBackgroundCheckFailureReasonDAO pgBackgroundCheckFailureReasonDAO;

  /**
   * Bootstrap dependency injection for this class
   */
  public ProviderBackgroundCheck() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Logically deletes the background check associated to provider. Background
   * checks undertaken on employees or household members of a provider.
   *
   * @param keyVersionDetails
   * contains version no of the recored to be logically deleted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancelBackgroundCheck(KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    curam.provider.impl.ProviderBackgroundCheck providerBackgroundCheck = providerBackgroundCheckDAO.get(
      keyVersionDetails.id);

    providerBackgroundCheck.cancel(keyVersionDetails.version);

  }

  /**
   * Logically deletes the background check failure reason. A reason why a
   * background check has failed.
   *
   * @param keyVersionDetails
   * contains version no of the recored to be logically deleted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancelBackgroundCheckFailureReason(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {
    final curam.provider.impl.BackgroundCheckFailureReason backgroundCheckFailureReason = backgroundCheckFailureReasonDAO.get(
      keyVersionDetails.id);

    backgroundCheckFailureReason.cancel(keyVersionDetails.version);
  }

  /**
   * Creates the background check for a provider. Background checks undertaken
   * on employees or household members of a provider.
   *
   * @param providerBackgroundCheckDtls
   * contains the background check details.
   *
   * @return ProviderBackgroundCheckKey ID of the newly created background
   * check.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderBackgroundCheckKey createBackgroundCheck(
    ProviderBackgroundCheckDtls providerBackgroundCheckDtls)
    throws AppException, InformationalException {

    curam.provider.impl.ProviderBackgroundCheck providerBackgroundCheck = providerBackgroundCheckDAO.newInstance();

    // map details passed from client
    setProviderBackgroundCheckFields(providerBackgroundCheck,
      providerBackgroundCheckDtls);

    providerBackgroundCheck.insert();

    ProviderBackgroundCheckKey providerBackgroundCheckKey = new ProviderBackgroundCheckKey();

    providerBackgroundCheckKey.providerBackgroundCheckID = providerBackgroundCheck.getID();
    return providerBackgroundCheckKey;
  }

  /**
   * Creates the background check failure reason A reason why a background check
   * has failed.
   *
   * @param dtls
   * contains the background check failure reason details.
   *
   * @return BackgroundCheckFailureReasonKey ID of the newly created background
   * check failure reason.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public BackgroundCheckFailureReasonKey createBackgroundCheckFailureReason(
    BackgroundCheckFailureReasonDtls dtls) throws AppException,
      InformationalException {

    curam.provider.impl.BackgroundCheckFailureReason backgroundCheckFailureReason = backgroundCheckFailureReasonDAO.newInstance();

    // setting the fields to the entity
    setBackgroundCheckFailureReasonFields(backgroundCheckFailureReason, dtls);

    // insert the record
    backgroundCheckFailureReason.insert();

    BackgroundCheckFailureReasonKey backgroundCheckFailureReasonKey = new BackgroundCheckFailureReasonKey();

    backgroundCheckFailureReasonKey.backgroundCheckFailureReasonID = backgroundCheckFailureReason.getID();

    return backgroundCheckFailureReasonKey;
  }

  /**
   * Maps the Background Check Failure Reason fields updateable by the user to
   * the fields on the service layer
   * object.
   *
   * @param backgroundCheckFailureReason -
   * BackgroundCheckFailureReason
   *
   * @param dtls -
   * BackgroundCheckFailureReasonDtls contains the background check Failure Reason details.
   *
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00177241, PM
  protected void setBackgroundCheckFailureReasonFields(
    // END, CR00177241
    final curam.provider.impl.BackgroundCheckFailureReason backgroundCheckFailureReason,
    final BackgroundCheckFailureReasonDtls dtls) {
    backgroundCheckFailureReason.setOccurrenceDate(dtls.occurrenceDate);
    backgroundCheckFailureReason.setFailureReason(
      BackgroundCheckFailureReasonTypeEntry.get(dtls.failureReason));
    backgroundCheckFailureReason.setProviderBackgroundCheck(
      providerBackgroundCheckDAO.get(dtls.providerBackgroundCheckID));
  }

  /**
   * Lists all Background Checks.
   *
   * @param providerKey
   * provider ID for which the background checks are to be listed.
   *
   * @return ProviderBackgroundCheckDetailsList contains list of Background
   * Check Details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  public ProviderBackgroundCheckDetailsList listBackgroundChecks(
    ProviderKey providerKey) throws AppException, InformationalException {

    ProviderBackgroundCheckDetailsList providerBackgroundCheckDetailsList = new ProviderBackgroundCheckDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    ProviderBackgroundCheckDetails providerBackgroundCheckDetails;

    for (final curam.provider.impl.ProviderBackgroundCheck providerBackgroundCheck : provider.getProviderBackgroundChecks()) {

      providerBackgroundCheckDetails = new ProviderBackgroundCheckDetails();

      providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerBackgroundCheckID = providerBackgroundCheck.getID();

      providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerPartyID = providerBackgroundCheck.getProviderMember().getID();

      providerBackgroundCheckDetails.providerMemberName = providerBackgroundCheck.getProviderMember().getParty().getName();

      providerBackgroundCheckDetails.providerBackgroundCheckDtls.type = providerBackgroundCheck.getType().getCode();

      providerBackgroundCheckDetails.providerBackgroundCheckDtls.result = providerBackgroundCheck.getResult().getCode();

      providerBackgroundCheckDetails.providerBackgroundCheckDtls.recordStatus = providerBackgroundCheck.getLifecycleState().getCode();
      
      // BEGIN, CR00206440, AS
      providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerConcernRoleID = providerBackgroundCheck.getProvider().getID();
      
      providerBackgroundCheckDetails.providerBackgroundCheckDtls.versionNo = providerBackgroundCheck.getVersionNo();
      // END, CR00206440
      
      providerBackgroundCheckDetailsList.providerBackgroundCheckDetails.addRef(
        providerBackgroundCheckDetails);

    }

    return sortBackgroundCheckProviderMembers(
      providerBackgroundCheckDetailsList.providerBackgroundCheckDetails);
  }

  /**
   * Updates the Background Check details.
   *
   * @param providerBackgroundCheckDtls
   * contains Background Check details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public void updateBackgroundCheck(
    ProviderBackgroundCheckDtls providerBackgroundCheckDtls)
    throws AppException, InformationalException {

    curam.provider.impl.ProviderBackgroundCheck providerBackgroundCheck = providerBackgroundCheckDAO.get(
      providerBackgroundCheckDtls.providerBackgroundCheckID);

    // map details passed from client
    setProviderBackgroundCheckFields(providerBackgroundCheck,
      providerBackgroundCheckDtls);

    providerBackgroundCheck.modify(providerBackgroundCheckDtls.versionNo);

  }

  /**
   * Updates the Background Check Failure Reason details.
   *
   * @param dtls
   * contains Background Check Failure Reason details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public void updateBackgroundCheckFailureReason(
    BackgroundCheckFailureReasonDtls dtls) throws AppException,
      InformationalException {
    final curam.provider.impl.BackgroundCheckFailureReason backgroundCheckFailureReason = backgroundCheckFailureReasonDAO.get(
      dtls.backgroundCheckFailureReasonID);

    setBackgroundCheckFailureReasonFields(backgroundCheckFailureReason, dtls);
    backgroundCheckFailureReason.setProviderBackgroundCheck(
      providerBackgroundCheckDAO.get(dtls.providerBackgroundCheckID));
    backgroundCheckFailureReason.modify(dtls.versionNo);
  }

  /**
   * Reads the background check details.
   *
   * @param providerBackgroundCheckKey
   * provider background check ID.
   *
   * @return ProviderBackgroundCheckSummaryDetails provider background check
   * details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderBackgroundCheckSummaryDetails viewBackgroundCheck(
    ProviderBackgroundCheckKey providerBackgroundCheckKey)
    throws AppException, InformationalException {

    ProviderBackgroundCheckSummaryDetails providerBackgroundCheckSummaryDetails = new ProviderBackgroundCheckSummaryDetails();

    final curam.provider.impl.ProviderBackgroundCheck providerBackgroundCheck = providerBackgroundCheckDAO.get(
      providerBackgroundCheckKey.providerBackgroundCheckID);

    final curam.provider.impl.ProviderMember providerMember = providerBackgroundCheck.getProviderMember();

    final ConcernRole party = providerMember.getParty();

    // map the providerBackgroundCheck fields
    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerBackgroundCheckID = providerBackgroundCheck.getID();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerConcernRoleID = providerBackgroundCheck.getProvider().getID();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerPartyID = providerMember.getID();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerMemberName = party.getName();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.type = providerBackgroundCheck.getType().getCode();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.result = providerBackgroundCheck.getResult().getCode();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.requestDate = providerBackgroundCheck.getDateRange().start();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.receiptDate = providerBackgroundCheck.getDateRange().end();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.recordStatus = providerBackgroundCheck.getLifecycleState().getCode();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.versionNo = providerBackgroundCheck.getVersionNo();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.comments = providerBackgroundCheck.getComments();
    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerPartyID = providerBackgroundCheck.getProviderMember().getID();
    // BEGIN, CR00085605, SP
    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.expiryDate = providerBackgroundCheck.getExpiryDate();
    // END, CR00085605
    Set<BackgroundCheckFailureReason> unModifiableBackgroundCheckFailureReasons = providerBackgroundCheck.getProviderBackgroundCheckFailureReasons();
    Set<BackgroundCheckFailureReason> backgroundCheckFailureReasons = new HashSet<BackgroundCheckFailureReason>();

    backgroundCheckFailureReasons.addAll(
      unModifiableBackgroundCheckFailureReasons);

    for (final curam.provider.impl.BackgroundCheckFailureReason backgroundCheckFailureReason : sortBackgroundCheckFailureReasonByDate(
      backgroundCheckFailureReasons)) {
      providerBackgroundCheckSummaryDetails.backgroundCheckFailureReasonsList.backgroundCheckFailureReason.addRef(
        getProviderbackgroundCheckFailureReasonFieldsForList(
          backgroundCheckFailureReason));

    }

    return providerBackgroundCheckSummaryDetails;
  }

  /**
   * Maps the Provider Background Check fields updateable by the user to the fields on the service layer
   * object.
   *
   *
   * @param providerBackgroundCheck
   * the service layer object into which the user-updateable fields
   * must be mapped
   * @param providerBackgroundCheckDtls
   * struct contain fields set by the user (as well as other fields
   * which will be ignored)
   * @throws InformationalException
   *
   * @throws AppException
   */
  // BEGIN, CR00177241, PM
  protected void setProviderBackgroundCheckFields(
    // END, CR00177241
    final curam.provider.impl.ProviderBackgroundCheck providerBackgroundCheck,
    final ProviderBackgroundCheckDtls providerBackgroundCheckDtls)
    throws AppException, InformationalException {

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerBackgroundCheckDtls.providerConcernRoleID);

    final curam.provider.impl.ProviderMember providerMember = providerMemberDAO.get(
      providerBackgroundCheckDtls.providerPartyID);

    providerBackgroundCheck.setProvider(provider);
    providerBackgroundCheck.setProviderMember(providerMember);
    providerBackgroundCheck.setType(
      BackgroundCheckTypeEntry.get(providerBackgroundCheckDtls.type));
    providerBackgroundCheck.setResult(
      BackgroundCheckResultEntry.get(providerBackgroundCheckDtls.result));
    providerBackgroundCheck.setComments(providerBackgroundCheckDtls.comments);
    final DateRange dateRange = new DateRange(
      providerBackgroundCheckDtls.requestDate,
      providerBackgroundCheckDtls.receiptDate);

    providerBackgroundCheck.setDateRange(dateRange);
    // BEGIN, CR00085605, SP
    providerBackgroundCheck.setExpiryDate(
      providerBackgroundCheckDtls.expiryDate);
    // END, CR00085605
  }

  /**
   * This method returns Provider background Check FailureReason details for user
   * display.
   *
   * @param backgroundCheckFailureReason
   * backgroundCheckFailureReason
   * @return backgroundCheckFailureReasonDtls struct containing the fields for
   * display
   */
  // BEGIN, CR00177241, PM
  protected BackgroundCheckFailureReasonDtls getProviderbackgroundCheckFailureReasonFieldsForList(
    // END, CR00177241
    final curam.provider.impl.BackgroundCheckFailureReason backgroundCheckFailureReason) {

    BackgroundCheckFailureReasonDtls backgroundCheckFailureReasonDtls = new BackgroundCheckFailureReasonDtls();

    backgroundCheckFailureReasonDtls.backgroundCheckFailureReasonID = backgroundCheckFailureReason.getID();

    backgroundCheckFailureReasonDtls.failureReason = backgroundCheckFailureReason.getFailureReason();

    backgroundCheckFailureReasonDtls.occurrenceDate = backgroundCheckFailureReason.getOccurrenceDate();
    backgroundCheckFailureReasonDtls.recordStatus = backgroundCheckFailureReason.getLifecycleState().getCode();

    return backgroundCheckFailureReasonDtls;
  }

  /**
   * Sorts a set of BackgroundChecks by ProviderMember name into a sorted list
   * for display.
   *
   * @param unsortedBackgroundCheckProviderMembers
   * the set of unsorted BackgroundChecks
   * @return a sorted list of BackgroundChecks by ProviderMember name
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  // BEGIN, CR00177241, PM
  protected ProviderBackgroundCheckDetailsList sortBackgroundCheckProviderMembers(
    // END, CR00177241
    final ArrayList<curam.cpm.facade.struct.ProviderBackgroundCheckDetails> unsortedBackgroundCheckProviderMembers) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    Collections.sort(unsortedBackgroundCheckProviderMembers,
      new Comparator<curam.cpm.facade.struct.ProviderBackgroundCheckDetails>() {
      public int compare(
        final curam.cpm.facade.struct.ProviderBackgroundCheckDetails lhs,
        curam.cpm.facade.struct.ProviderBackgroundCheckDetails rhs) {
        return lhs.providerMemberName.compareTo(rhs.providerMemberName);
      }
    });

    ProviderBackgroundCheckDetailsList providerBackgroundCheckDetailsList = new ProviderBackgroundCheckDetailsList();

    providerBackgroundCheckDetailsList.providerBackgroundCheckDetails.addAll(
      unsortedBackgroundCheckProviderMembers);

    return providerBackgroundCheckDetailsList;
  }

  /**
   * Sorts by date- a set of BackgroundCheckFailureReasons.
   *
   * @param unsortBackgroundCheckFailureReasons
   * a set of BackgroundCheckFailureReasons.
   * @return a sorted list of BackgroundCheckFailureReasons for display.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.provider.impl.BackgroundCheckFailureReason> sortBackgroundCheckFailureReasonByDate(
    // END, CR00177241
    final Set<curam.provider.impl.BackgroundCheckFailureReason> unsortBackgroundCheckFailureReasons) {

    // Sort by Start Date descending order for display - using a list (instead
    // of a set)
    final List<curam.provider.impl.BackgroundCheckFailureReason> backgroundCheckFailureReasons = new ArrayList<curam.provider.impl.BackgroundCheckFailureReason>(
      unsortBackgroundCheckFailureReasons);

    Collections.sort(backgroundCheckFailureReasons,
      new Comparator<curam.provider.impl.BackgroundCheckFailureReason>() {
      public int compare(
        final curam.provider.impl.BackgroundCheckFailureReason lhs,
        curam.provider.impl.BackgroundCheckFailureReason rhs) {
        return rhs.getOccurrenceDate().compareTo(lhs.getOccurrenceDate());
      }
    });
    return backgroundCheckFailureReasons;

  }

  /**
   * List all provider members.
   *
   * @param providerKey
   * provider ID for whom the provider members are to be listed.
   *
   * @return ProviderMemberSummaryDetailsList list of provider members for a
   * provider.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public ProviderMemberSummaryDetailsList listProviderMembersByProvider(
    ProviderKey providerKey) throws AppException, InformationalException {

    ProviderMemberSummaryDetailsList providerMemberSummaryDetailsList = new ProviderMemberSummaryDetailsList();

    final curam.provider.impl.Provider provider = providerDAO.get(
      providerKey.providerConcernRoleID);

    Set<ProviderMember> unModifiableProviderMembers = provider.getProviderMembers();
    Set<ProviderMember> providerMembers = new HashSet<ProviderMember>();

    providerMembers.addAll(unModifiableProviderMembers);

    for (final curam.provider.impl.ProviderMember providerMember : LifecycleHelper.filter(
      providerMembers, RECORDSTATUSEntry.NORMAL)) {
      final ConcernRole party = providerMember.getParty();

      ProviderMemberSummaryDetails providerMemberSummaryDetails = new ProviderMemberSummaryDetails();

      providerMemberSummaryDetails.providerMemberID = providerMember.getID();
      providerMemberSummaryDetails.memberConcernRoleID = providerMember.getParty().getID();
      providerMemberSummaryDetails.memberName = party.getName();
      providerMemberSummaryDetails.recordStatus = providerMember.getLifecycleState().getCode();
      providerMemberSummaryDetailsList.providerMemberSummaryDetailsList.addRef(
        providerMemberSummaryDetails);

    }
    return providerMemberSummaryDetailsList;
  }

  /**
   * Reads the background check failure reason summary details.
   *
   * @param key
   * provider background check failure reason ID
   *
   * @return BackgroundCheckFailureReasonDtls Contains Background Check
   * FailureReason details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public BackgroundCheckFailureReasonDtls viewBackgroundCheckFailureReason(
    BackgroundCheckFailureReasonKey key) throws AppException,
      InformationalException {
    final curam.provider.impl.BackgroundCheckFailureReason backgroundCheckFailureReason = backgroundCheckFailureReasonDAO.get(
      key.backgroundCheckFailureReasonID);
    BackgroundCheckFailureReasonDtls backgroundCheckFailureReasonDtls = new BackgroundCheckFailureReasonDtls();

    getBackgroundCheckFailureReasonDetails(backgroundCheckFailureReasonDtls,
      backgroundCheckFailureReason);

    return backgroundCheckFailureReasonDtls;
  }

  /**
   * This method returns the background check failure reason associated to back
   * background check.
   *
   * @param backgroundCheckFailureReasonDtls -
   * BackgroundCheckFailureReasonDtls
   * @param backgroundCheckFailureReason -
   * BackgroundCheckFailureReason
   */
  // BEGIN, CR00177241, PM
  protected void getBackgroundCheckFailureReasonDetails(
    // END, CR00177241
    BackgroundCheckFailureReasonDtls backgroundCheckFailureReasonDtls,
    curam.provider.impl.BackgroundCheckFailureReason backgroundCheckFailureReason) {
    backgroundCheckFailureReasonDtls.backgroundCheckFailureReasonID = backgroundCheckFailureReason.getID();
    backgroundCheckFailureReasonDtls.failureReason = backgroundCheckFailureReason.getFailureReason();
    backgroundCheckFailureReasonDtls.occurrenceDate = backgroundCheckFailureReason.getOccurrenceDate();
    backgroundCheckFailureReasonDtls.providerBackgroundCheckID = backgroundCheckFailureReason.getProviderBackgroundCheck().getID();
    backgroundCheckFailureReasonDtls.recordStatus = backgroundCheckFailureReason.getLifecycleState().getCode();
    backgroundCheckFailureReasonDtls.versionNo = backgroundCheckFailureReason.getVersionNo();
  }

  // BEGIN, CR00117572, NK

  /**
   * Logically deletes the background check associated to provider group.
   * Background checks undertaken on employees or household members of a provider.
   *
   * @param keyVersionDetails
   * contains version no of the recored to be logically deleted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancelProviderGroupBackgroundCheck(KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    curam.provider.impl.ProviderGroupBackgroundCheck providerGroupBackgroundCheck = providerGroupBackgroundCheckDAO.get(
      keyVersionDetails.id);

    providerGroupBackgroundCheck.cancel(keyVersionDetails.version);

  }

  /**
   * Logically deletes the background check failure reason. A reason why a
   * background check has failed.
   *
   * @param keyVersionDetails
   * contains version no of the recored to be logically deleted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancelProviderGroupBackgroundCheckFailureReason(
    KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    final curam.provider.impl.PGBackgroundCheckFailureReason pgBackgroundCheckFailureReason = pgBackgroundCheckFailureReasonDAO.get(
      keyVersionDetails.id);

    pgBackgroundCheckFailureReason.cancel(keyVersionDetails.version);

  }

  /**
   * Creates the background check for a provider group. Background checks undertaken
   * on employees or household members of a provider group.
   *
   * @param providerBackgroundCheckDtls
   * contains the background check details.
   *
   * @return ProviderBackgroundCheckKey ID of the newly created background
   * check.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderBackgroundCheckKey createProviderGroupBackgroundCheck(
    ProviderBackgroundCheckDtls providerBackgroundCheckDtls)
    throws AppException, InformationalException {

    ProviderGroupBackgroundCheck providerGroupBackgroundCheck = providerGroupBackgroundCheckDAO.newInstance();

    ProviderBackgroundCheckKey providerBackgroundCheckKey = new ProviderBackgroundCheckKey();

    // map details passed from client
    setProviderGroupBackgroundCheckFields(providerGroupBackgroundCheck,
      providerBackgroundCheckDtls);

    providerGroupBackgroundCheck.insert();

    providerBackgroundCheckKey.providerBackgroundCheckID = providerGroupBackgroundCheck.getID();

    return providerBackgroundCheckKey;
  }

  /**
   * Creates the background check failure reason, A reason why a background check
   * has failed for a provider group member.
   *
   * @param backgroundCheckFailureReasonDtls
   * contains the background check failure reason details.
   *
   * @return BackgroundCheckFailureReasonKey ID of the newly created background
   * check failure reason.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public BackgroundCheckFailureReasonKey createProviderGroupBackGroundCheckFailureReason(
    BackgroundCheckFailureReasonDtls backgroundCheckFailureReasonDtls)
    throws AppException, InformationalException {

    curam.provider.impl.PGBackgroundCheckFailureReason pgBackgroundCheckFailureReason = pgBackgroundCheckFailureReasonDAO.newInstance();
    BackgroundCheckFailureReasonKey backgroundCheckFailureReasonKey = new BackgroundCheckFailureReasonKey();

    // setting the fields to the entity
    setProviderGroupBackgroundCheckFailureReasonFields(
      pgBackgroundCheckFailureReason, backgroundCheckFailureReasonDtls);

    // insert the record
    pgBackgroundCheckFailureReason.insert();

    backgroundCheckFailureReasonKey.backgroundCheckFailureReasonID = pgBackgroundCheckFailureReason.getID();

    return backgroundCheckFailureReasonKey;
  }

  /**
   * Lists all Background Checks.
   *
   * @param providerGroupKey
   * provider group ID for which the background checks are to be listed.
   *
   * @return ProviderBackgroundCheckDetailsList contains list of Background
   * Check Details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  public ProviderBackgroundCheckDetailsList listProviderGroupBackgroundChecks(
    ProviderGroupKey providerGroupKey) throws AppException, InformationalException {

    ProviderBackgroundCheckDetailsList providerBackgroundCheckDetailsList = new ProviderBackgroundCheckDetailsList();

    final ProviderGroup providerGroup = providerGroupDAO.get(
      providerGroupKey.providerGroupConcernRoleID);

    ProviderBackgroundCheckDetails providerBackgroundCheckDetails;

    for (final ProviderGroupBackgroundCheck providerGroupBackgroundCheck :
      providerGroupBackgroundCheckDAO.searchBy(providerGroup)) {

      providerBackgroundCheckDetails = new ProviderBackgroundCheckDetails();

      providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerBackgroundCheckID = providerGroupBackgroundCheck.getID();

      providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerPartyID = providerGroupBackgroundCheck.getProviderMember().getID();

      providerBackgroundCheckDetails.providerMemberName = providerGroupBackgroundCheck.getProviderMember().getParty().getName();

      providerBackgroundCheckDetails.providerBackgroundCheckDtls.type = providerGroupBackgroundCheck.getType().getCode();

      providerBackgroundCheckDetails.providerBackgroundCheckDtls.result = providerGroupBackgroundCheck.getResult().getCode();

      providerBackgroundCheckDetails.providerBackgroundCheckDtls.recordStatus = providerGroupBackgroundCheck.getLifecycleState().getCode();

      // BEGIN, CR00207677, AS
      providerBackgroundCheckDetails.providerBackgroundCheckDtls.versionNo = providerGroupBackgroundCheck.getVersionNo();

      providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerConcernRoleID = providerGroupBackgroundCheck.getProviderGroup().getID();
      // END, CR00207677
      
      providerBackgroundCheckDetailsList.providerBackgroundCheckDetails.addRef(
        providerBackgroundCheckDetails);

    }

    return sortBackgroundCheckProviderMembers(
      providerBackgroundCheckDetailsList.providerBackgroundCheckDetails);

  }

  /**
   * List all provider members for provider group.
   *
   * @param providerGroupKey
   * provider group ID for whom the provider members are to be listed.
   *
   * @return ProviderMemberSummaryDetailsList list of provider members for a
   * provider group.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderMemberSummaryDetailsList listProviderMembersByProviderGroup(
    ProviderGroupKey providerGroupKey) throws AppException, InformationalException {

    ProviderMemberSummaryDetailsList providerMemberSummaryDetailsList = new ProviderMemberSummaryDetailsList();

    final curam.provider.impl.ProviderGroup providerGroup = providerGroupDAO.get(
      providerGroupKey.providerGroupConcernRoleID);

    Set<ProviderMember> unModifiableProviderMembers = providerGroup.getProviderMembers();
    Set<ProviderMember> providerMembers = new HashSet<ProviderMember>();

    providerMembers.addAll(unModifiableProviderMembers);

    for (final curam.provider.impl.ProviderMember providerMember : LifecycleHelper.filter(
      providerMembers, RECORDSTATUSEntry.NORMAL)) {
      final ConcernRole party = providerMember.getParty();

      ProviderMemberSummaryDetails providerMemberSummaryDetails = new ProviderMemberSummaryDetails();

      providerMemberSummaryDetails.providerMemberID = providerMember.getID();
      providerMemberSummaryDetails.memberConcernRoleID = providerMember.getParty().getID();
      providerMemberSummaryDetails.memberName = party.getName();
      providerMemberSummaryDetails.recordStatus = providerMember.getLifecycleState().getCode();
      providerMemberSummaryDetailsList.providerMemberSummaryDetailsList.addRef(
        providerMemberSummaryDetails);

    }
    return providerMemberSummaryDetailsList;
  }

  /**
   * Updates the Background Check details for provider group member.
   *
   * @param providerBackgroundCheckDetails
   * Contains Background Check details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public void updateProviderGroupBackgroundCheck(
    ProviderBackgroundCheckDtls providerBackgroundCheckDetails)
    throws AppException, InformationalException {

    ProviderGroupBackgroundCheck providerGroupBackgroundCheck = providerGroupBackgroundCheckDAO.get(
      providerBackgroundCheckDetails.providerBackgroundCheckID);

    // map details passed from client
    setProviderGroupBackgroundCheckFields(providerGroupBackgroundCheck,
      providerBackgroundCheckDetails);

    providerGroupBackgroundCheck.modify(
      providerBackgroundCheckDetails.versionNo);
  }

  /**
   * Updates the Background Check Failure Reason details.
   *
   * @param backgroundCheckFailureReasonDetails
   * contains Background Check Failure Reason details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public void updateProviderGroupBackgroundCheckFailureReason(
    BackgroundCheckFailureReasonDtls backgroundCheckFailureReasonDetails)
    throws AppException, InformationalException {

    final curam.provider.impl.PGBackgroundCheckFailureReason pgBackgroundCheckFailureReason = pgBackgroundCheckFailureReasonDAO.get(
      backgroundCheckFailureReasonDetails.backgroundCheckFailureReasonID);

    setProviderGroupBackgroundCheckFailureReasonFields(
      pgBackgroundCheckFailureReason, backgroundCheckFailureReasonDetails);

    pgBackgroundCheckFailureReason.setProviderGroupBackgroundCheck(
      providerGroupBackgroundCheckDAO.get(
        backgroundCheckFailureReasonDetails.providerBackgroundCheckID));

    pgBackgroundCheckFailureReason.modify(
      backgroundCheckFailureReasonDetails.versionNo);

  }

  /**
   * Reads the background check details for Provider group member.
   *
   * @param providerBackgroundCheckKey
   * provider background check ID.
   *
   * @return ProviderBackgroundCheckSummaryDetails provider background check
   * details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderBackgroundCheckSummaryDetails viewProviderGroupBackgoundCheck(
    ProviderBackgroundCheckKey providerBackgroundCheckKey)
    throws AppException, InformationalException {

    ProviderBackgroundCheckSummaryDetails providerBackgroundCheckSummaryDetails = new ProviderBackgroundCheckSummaryDetails();

    final ProviderGroupBackgroundCheck providerGroupBackgroundCheck = providerGroupBackgroundCheckDAO.get(
      providerBackgroundCheckKey.providerBackgroundCheckID);

    final ProviderMember providerMember = providerGroupBackgroundCheck.getProviderMember();

    final ConcernRole party = providerMember.getParty();

    // Map the providerBackgroundCheck fields
    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerBackgroundCheckID = providerGroupBackgroundCheck.getID();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerConcernRoleID = providerGroupBackgroundCheck.getProviderGroup().getID();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerPartyID = providerMember.getID();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerMemberName = party.getName();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.type = providerGroupBackgroundCheck.getType().getCode();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.result = providerGroupBackgroundCheck.getResult().getCode();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.requestDate = providerGroupBackgroundCheck.getDateRange().start();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.receiptDate = providerGroupBackgroundCheck.getDateRange().end();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.recordStatus = providerGroupBackgroundCheck.getLifecycleState().getCode();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.versionNo = providerGroupBackgroundCheck.getVersionNo();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.comments = providerGroupBackgroundCheck.getComments();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.providerPartyID = providerGroupBackgroundCheck.getProviderMember().getID();

    providerBackgroundCheckSummaryDetails.providerBackgroundCheckDetails.providerBackgroundCheckDtls.expiryDate = providerGroupBackgroundCheck.getExpiryDate();

    for (final curam.provider.impl.PGBackgroundCheckFailureReason pgBackgroundCheckFailureReason :
      sortPGBackgroundCheckFailureReasonByDate(
      providerGroupBackgroundCheck.getProviderGroupBackgroundCheckFailureReasons())) {

      providerBackgroundCheckSummaryDetails.backgroundCheckFailureReasonsList.backgroundCheckFailureReason.addRef(
        getProviderGroupbackgroundCheckFailureReasonFieldsForList(
          pgBackgroundCheckFailureReason));
    }
    return providerBackgroundCheckSummaryDetails;
  }

  /**
   * Reads the background check failure reason summary details.
   *
   * @param backgroundCheckFailureReasonKey
   * Provider background check failure reason ID.
   *
   * @return BackgroundCheckFailureReasonDtls Contains Background Check
   * FailureReason details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public BackgroundCheckFailureReasonDtls viewProviderGroupBackgroundCheckFailureReason(
    BackgroundCheckFailureReasonKey backgroundCheckFailureReasonKey)
    throws AppException, InformationalException {

    BackgroundCheckFailureReasonDtls backgroundCheckFailureReasonDtls = new BackgroundCheckFailureReasonDtls();

    final curam.provider.impl.PGBackgroundCheckFailureReason pgBackgroundCheckFailureReason = pgBackgroundCheckFailureReasonDAO.get(
      backgroundCheckFailureReasonKey.backgroundCheckFailureReasonID);

    getProviderGroupBackgroundCheckFailureReasonDetails(
      backgroundCheckFailureReasonDtls, pgBackgroundCheckFailureReason);

    return backgroundCheckFailureReasonDtls;

  }

  /**
   * Maps the Provider Group Background Check fields updateable by the user to
   * the fields on the service layer object.
   *
   *
   * @param providerBackgroundCheck
   * the service layer object into which the user-updateable fields
   * must be mapped
   * @param providerBackgroundCheckDtls
   * struct contain fields set by the user (as well as other fields
   * which will be ignored)
   * @throws InformationalException
   *
   * @throws AppException
   */
  // BEGIN, CR00177241, PM
  protected void setProviderGroupBackgroundCheckFields(
    // END, CR00177241
    final ProviderGroupBackgroundCheck providerGroupBackgroundCheck,
    final ProviderBackgroundCheckDtls providerBackgroundCheckDtls)
    throws AppException, InformationalException {

    final ProviderGroup providerGroup = providerGroupDAO.get(
      providerBackgroundCheckDtls.providerConcernRoleID);

    final ProviderMember providerMember = providerMemberDAO.get(
      providerBackgroundCheckDtls.providerPartyID);

    providerGroupBackgroundCheck.setProviderGroup(providerGroup);
    providerGroupBackgroundCheck.setProviderMember(providerMember);
    providerGroupBackgroundCheck.setType(
      BackgroundCheckTypeEntry.get(providerBackgroundCheckDtls.type));
    providerGroupBackgroundCheck.setResult(
      BackgroundCheckResultEntry.get(providerBackgroundCheckDtls.result));
    providerGroupBackgroundCheck.setComments(
      providerBackgroundCheckDtls.comments);

    final DateRange dateRange = new DateRange(
      providerBackgroundCheckDtls.requestDate,
      providerBackgroundCheckDtls.receiptDate);

    providerGroupBackgroundCheck.setDateRange(dateRange);
    providerGroupBackgroundCheck.setExpiryDate(
      providerBackgroundCheckDtls.expiryDate);
  }

  /**
   * Maps the Background Check Failure Reason fields updateable by the user to
   * the fields on the service layer
   * object.
   *
   * @param backgroundCheckFailureReason -
   * BackgroundCheckFailureReason
   *
   * @param dtls -
   * BackgroundCheckFailureReasonDtls contains the background check
   * failure Reason details.
   *
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00177241, PM
  protected void setProviderGroupBackgroundCheckFailureReasonFields(
    // END, CR00177241
    final PGBackgroundCheckFailureReason pgBackgroundCheckFailureReason,
    final BackgroundCheckFailureReasonDtls dtls) {

    pgBackgroundCheckFailureReason.setOccurrenceDate(dtls.occurrenceDate);
    pgBackgroundCheckFailureReason.setFailureReason(
      BackgroundCheckFailureReasonTypeEntry.get(dtls.failureReason));
    pgBackgroundCheckFailureReason.setProviderGroupBackgroundCheck(
      providerGroupBackgroundCheckDAO.get(dtls.providerBackgroundCheckID));
  }

  /**
   * This method returns Provider background Check FailureReason details for user
   * display.
   *
   * @param backgroundCheckFailureReason
   * backgroundCheckFailureReason
   * @return backgroundCheckFailureReasonDtls struct containing the fields for
   * display
   */
  // BEGIN, CR00177241, PM
  protected BackgroundCheckFailureReasonDtls getProviderGroupbackgroundCheckFailureReasonFieldsForList(
    // END, CROO177241
    final curam.provider.impl.PGBackgroundCheckFailureReason pgBackgroundCheckFailureReason) {

    BackgroundCheckFailureReasonDtls backgroundCheckFailureReasonDtls = new BackgroundCheckFailureReasonDtls();

    backgroundCheckFailureReasonDtls.backgroundCheckFailureReasonID = pgBackgroundCheckFailureReason.getID();

    backgroundCheckFailureReasonDtls.failureReason = pgBackgroundCheckFailureReason.getFailureReason();

    backgroundCheckFailureReasonDtls.occurrenceDate = pgBackgroundCheckFailureReason.getOccurrenceDate();

    backgroundCheckFailureReasonDtls.recordStatus = pgBackgroundCheckFailureReason.getLifecycleState().getCode();

    return backgroundCheckFailureReasonDtls;
  }

  /**
   * Sorts by date- a set of Provider Group BackgroundCheckFailureReasons.
   *
   * @param unsortBackgroundCheckFailureReasons
   * a set of BackgroundCheckFailureReasons.
   * @return a sorted list of BackgroundCheckFailureReasons for display.
   */
  // BEGIN, CR00177241, PM
  protected List<curam.provider.impl.PGBackgroundCheckFailureReason> sortPGBackgroundCheckFailureReasonByDate(
    // END, CR00177241
    final Set<curam.provider.impl.PGBackgroundCheckFailureReason> unsortPGBackgroundCheckFailureReasons) {

    // Sort by Start Date descending order for display - using a list (instead
    // of a set)
    final List<curam.provider.impl.PGBackgroundCheckFailureReason> pgBackgroundCheckFailureReasons = new ArrayList<curam.provider.impl.PGBackgroundCheckFailureReason>(
      unsortPGBackgroundCheckFailureReasons);

    Collections.sort(pgBackgroundCheckFailureReasons,
      new Comparator<curam.provider.impl.PGBackgroundCheckFailureReason>() {
      public int compare(
        final curam.provider.impl.PGBackgroundCheckFailureReason lhs,
        curam.provider.impl.PGBackgroundCheckFailureReason rhs) {
        return rhs.getOccurrenceDate().compareTo(lhs.getOccurrenceDate());
      }
    });
    return pgBackgroundCheckFailureReasons;

  }

  /**
   * This method returns the provider group background check failure reason
   * associated to back background check.
   *
   * @param backgroundCheckFailureReason -
   * BackgroundCheckFailureReason
   * @param backgroundCheckFailureReasonDtls -
   * BackgroundCheckFailureReasonDtls
   */
  // BEGIN, CR00177241, PM
  protected void getProviderGroupBackgroundCheckFailureReasonDetails(
    // END, CR00177241
    BackgroundCheckFailureReasonDtls backgroundCheckFailureReasonDtls,
    PGBackgroundCheckFailureReason pgBackgroundCheckFailureReason) {

    backgroundCheckFailureReasonDtls.backgroundCheckFailureReasonID = pgBackgroundCheckFailureReason.getID();
    backgroundCheckFailureReasonDtls.failureReason = pgBackgroundCheckFailureReason.getFailureReason();
    backgroundCheckFailureReasonDtls.occurrenceDate = pgBackgroundCheckFailureReason.getOccurrenceDate();
    backgroundCheckFailureReasonDtls.providerBackgroundCheckID = pgBackgroundCheckFailureReason.getProviderGroupBackgroundCheck().getID();
    backgroundCheckFailureReasonDtls.recordStatus = pgBackgroundCheckFailureReason.getLifecycleState().getCode();
    backgroundCheckFailureReasonDtls.versionNo = pgBackgroundCheckFailureReason.getVersionNo();
  }

  // END, CR00117572

}
