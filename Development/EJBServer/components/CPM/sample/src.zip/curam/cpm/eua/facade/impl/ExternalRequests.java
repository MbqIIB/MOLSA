/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpm.eua.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.core.struct.ConcernRoleKey;
import curam.cpm.eua.facade.fact.ExternalParticipantFactory;
import curam.cpm.eua.facade.fact.ExternalUserSecurityFactory;
import curam.cpm.eua.facade.intf.ExternalParticipant;
import curam.cpm.eua.facade.intf.ExternalUserSecurity;
import curam.cpm.eua.facade.struct.ExternalSecurityKey;
import curam.cpm.eua.facade.struct.RequestDetailsSummaryList;
import curam.cpm.eua.facade.struct.RequestSummaryAndVersionDetails;
import curam.cpm.eua.facade.struct.RequestSummaryAndVersionDetailsList;
import curam.cpm.eua.facade.struct.RequestSummaryDetails;
import curam.cpm.eua.facade.struct.RequestSummaryVersionDetails;
import curam.cpm.eua.facade.struct.RequestSummaryVersionDetailsList;
import curam.cpm.eua.facade.struct.RequestVersionNoIDKey;
import curam.cpm.facade.fact.ContextDescriptionFactory;
import curam.cpm.facade.intf.ContextDescription;
import curam.externaluseraccess.impl.Request;
import curam.externaluseraccess.impl.RequestStatusEntry;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This process class provides the functionality for External Requests facade layer
 */
public abstract class ExternalRequests extends curam.cpm.eua.facade.base.ExternalRequests {

  // variable instantiated by guice.
  @Inject
  protected curam.externaluseraccess.impl.RequestDAO requestDAO;

  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  /**
   * Constructor
   */
  public ExternalRequests() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Retrieves a list of requests for the logged in user.
   *
   * @return This contains the list of provider/provider group requests.
   *
   * @throws AppException
   * @throws InformationalException
   */
  public RequestDetailsSummaryList listRequests() throws
      AppException, InformationalException {

    // Manipulation variables
    RequestDetailsSummaryList requestList = new RequestDetailsSummaryList();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    ExternalParticipant externalParticipantObj = ExternalParticipantFactory.newInstance();

    // set the provider Organization who should the logged in user
    concernRoleKey.concernRoleID = externalParticipantObj.readProviderProviderGroupID().participantRoleID;

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      concernRoleKey.concernRoleID);

    for (final curam.externaluseraccess.impl.Request request : sortRequests(
      requestDAO.searchBy(providerOrganization))) {

      requestList.requestDetails.addRef(
        setRequestSummaryDetails(request, providerOrganization));

    }

    ContextDescription contextDescription = ContextDescriptionFactory.newInstance();

    // Get the context description for the concern role
    requestList.contextDescription.pageContextDescription = contextDescription.getContextDescriptionForConcern(concernRoleKey).description;

    return requestList;
  }

  // BEGIN, CR00229430, GP
  // BEGIN, CR00261151, GP
  /**
   * Lists all the requests for a logged in provider/provider group.
   *
   * @return The list of requests.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated since curam 6.0 SP1, replaced with
   * {@link ExternalRequests#listAllRequestDetails()}. This method
   * is not useful to conditionally disable links for a request when
   * the status is not 'Open'. Hence this method is deprecated. The
   * newly added method will give the option to conditionally
   * disable links. See release note: CR00261151.
   */
  @Deprecated
  // END, CR00261151
  public RequestSummaryVersionDetailsList listRequestDetails()
    throws AppException, InformationalException {

    RequestSummaryVersionDetailsList requestSummaryVersionDetailsList = new RequestSummaryVersionDetailsList();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    ExternalParticipant externalParticipantObj = ExternalParticipantFactory.newInstance();

    concernRoleKey.concernRoleID = externalParticipantObj.readProviderProviderGroupID().participantRoleID;

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      concernRoleKey.concernRoleID);

    for (final Request request : sortRequests(
      requestDAO.searchBy(providerOrganization))) {

      requestSummaryVersionDetailsList.requestSummaryVersionDetails.addRef(
        setRequestSummaryVersionDetails(request, providerOrganization));
    }

    return requestSummaryVersionDetailsList;
  }
  
  // BEGIN, CR00261151, GP
  /**
   * Lists all the requests for a logged in provider/provider group.
   *
   * @return The list of requests.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */ 
  public RequestSummaryAndVersionDetailsList listAllRequestDetails()
    throws AppException, InformationalException {

    RequestSummaryAndVersionDetailsList requestSummaryAndVersionDetailsList = new RequestSummaryAndVersionDetailsList();
    RequestSummaryAndVersionDetails requestSummaryAndVersionDetails;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    ExternalParticipant externalParticipantObj = ExternalParticipantFactory.newInstance();

    concernRoleKey.concernRoleID = externalParticipantObj.readProviderProviderGroupID().participantRoleID;

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      concernRoleKey.concernRoleID);

    for (final Request request : sortRequests(
      requestDAO.searchBy(providerOrganization))) {
      
      // BEGIN, CR00270590, GP
      requestSummaryAndVersionDetails = new RequestSummaryAndVersionDetails();
      // END, CR00270590
      
      requestSummaryAndVersionDetails.assign(
        setRequestSummaryVersionDetails(request, providerOrganization));
      if (RequestStatusEntry.OPEN.getCode().equals(
        requestSummaryAndVersionDetails.status)) {

        requestSummaryAndVersionDetails.editIndicator = true;
        requestSummaryAndVersionDetails.cancelIndicator = true;
        requestSummaryAndVersionDetails.newLineItemIndicator = true;
        requestSummaryAndVersionDetails.submitIndicator = true;

      }
      requestSummaryAndVersionDetailsList.requestSummaryVersionDetails.addRef(
        requestSummaryAndVersionDetails);

    }
    return requestSummaryAndVersionDetailsList;
  }

  // END, CR00261151

  /**
   * Sets the request Summary details.
   *
   * @param request
   * The request from which details are to be set.
   * @param providerOrganization
   * The details of the provider Organization.
   *
   * @return The request summary details.
   */
  protected RequestSummaryVersionDetails setRequestSummaryVersionDetails(
    Request request, ProviderOrganization providerOrganization) {

    RequestSummaryVersionDetails requestSummaryVersionDetails = new RequestSummaryVersionDetails();

    requestSummaryVersionDetails.concernRoleID = providerOrganization.getID();
    requestSummaryVersionDetails.dateCreated = request.getDateCreated();
    requestSummaryVersionDetails.dateSubmitted = request.getDateSubmitted();
    requestSummaryVersionDetails.requestCategory = request.getRequestCategory().getCode();
    requestSummaryVersionDetails.requestType = request.getRequestType().getCode();
    requestSummaryVersionDetails.requestID = request.getID();
    requestSummaryVersionDetails.status = request.getLifecycleState().getCode();
    requestSummaryVersionDetails.versionNo = request.getVersionNo();

    return requestSummaryVersionDetails;
  }

  // END, CR00229430
  
  /**
   * Sets the request Summary details
   *
   * @param request - the request object
   * @param providerOrganization - the details of the provider Organization
   *
   * @return The request summary details
   */
  // BEGIN, CR00177241, PM
  protected RequestSummaryDetails setRequestSummaryDetails(Request request,
    ProviderOrganization providerOrganization) {
    // END, CR00177241

    RequestSummaryDetails requestSummaryDetails = new RequestSummaryDetails();

    // set the details
    requestSummaryDetails.concernRoleID = providerOrganization.getID();
    requestSummaryDetails.dateCreated = request.getDateCreated();
    requestSummaryDetails.dateSubmitted = request.getDateSubmitted();
    requestSummaryDetails.requestCategory = request.getRequestCategory().getCode();
    requestSummaryDetails.requestType = request.getRequestType().getCode();
    requestSummaryDetails.requestID = request.getID();
    requestSummaryDetails.status = request.getLifecycleState().getCode();

    return requestSummaryDetails;

  }

  /**
   * Cancels a request
   *
   * @param key - contains the request ID and version Number
   * @throws AppException
   * @throws InformationalException
   */
  public void cancelRequest(RequestVersionNoIDKey key) throws AppException, InformationalException {

    // get the request object
    Request request = requestDAO.get(key.requestID);

    // get the concernRoleID for the request
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = request.getProviderOrganization().getID();

    // call security method to ensure the logged in user has the
    // rights to view this information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    // set the status of the request to canceled
    request.cancel(key.versionNo);

  }

  /**
   * Submits a request
   *
   * @param key - contains the request ID and version Number
   * @throws AppException
   * @throws InformationalException
   */
  public void submitRequest(RequestVersionNoIDKey key) throws AppException, InformationalException {

    // get the request instance
    Request request = requestDAO.get(key.requestID);

    // get the concernRoleID for the request
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = request.getProviderOrganization().getID();

    // call security method to ensure the logged in user has the
    // rights to view this information
    ExternalUserSecurity externalUserSecurity = ExternalUserSecurityFactory.newInstance();
    ExternalSecurityKey externalSecurityKey = new ExternalSecurityKey();

    // set the key
    externalSecurityKey.concernRoleKey = concernRoleKey;
    externalSecurityKey.viewProviderGroupDetailsInd = false;

    externalUserSecurity.checkProviderGroupSecurity(externalSecurityKey);

    // set the status of the request to submitted,
    // this also updates the date submitted to todays date
    request.submit(key.versionNo);

    // BEGIN, CR00171487, AK
    final Event event = new Event();

    event.eventKey = curam.events.REQUESTDECISION.REQUESTSUBMITTED;
    event.primaryEventData = key.requestID;
    EventService.raiseEvent(event);
    // END, CR00171487

  }

  /**
   * Sorts a set of Requests by date created
   *
   * @param unsortedRequests -
   * the set of requests
   * @return a sorted list of requests
   */
  // BEGIN, CR00177241, PM
  protected List<curam.externaluseraccess.impl.Request> sortRequests(
    final Set<curam.externaluseraccess.impl.Request> unsortedRequests) {
    // END, CR00177241

    /*
     * Sort by start date
     */
    final List<curam.externaluseraccess.impl.Request> requests = new ArrayList<curam.externaluseraccess.impl.Request>(
      unsortedRequests);

    Collections.sort(requests,
      new Comparator<curam.externaluseraccess.impl.Request>() {
      public int compare(final curam.externaluseraccess.impl.Request lhs,
        curam.externaluseraccess.impl.Request rhs) {
        int compareTo = lhs.getDateCreated().compareTo(rhs.getDateCreated());

        // if dates are equal compare by id instead
        if (compareTo == 0) {
          return lhs.getID().compareTo(rhs.getID());
        } else {
          return compareTo;
        }
      }
    });

    return requests;
  }
}
