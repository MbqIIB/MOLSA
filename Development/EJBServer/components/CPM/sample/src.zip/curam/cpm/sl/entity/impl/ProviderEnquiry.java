/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.sl.entity.impl;


import curam.codetable.ADDRESSELEMENTTYPE;
import curam.core.impl.CuramConst;
import curam.core.impl.TimeZoneUtility;
import curam.cpm.sl.entity.fact.ProviderEnquiryFactory;
import curam.cpm.sl.entity.struct.CloseProviderEnquiryDetails;
import curam.cpm.sl.entity.struct.ListProviderEnquiryKey;
import curam.cpm.sl.entity.struct.ProviderEnquiryDtls;
import curam.cpm.sl.entity.struct.ProviderEnquiryKey;
import curam.cpm.sl.entity.struct.SearchProviderEnquiryKey;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.provider.ProviderStatus;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;


/**
 * This entity class provides the validation for provider Enquiry entity
 *
 */
public abstract class ProviderEnquiry extends curam.cpm.sl.entity.base.ProviderEnquiry {

  /**
   * Constant for empty string
   */
  static final String kEmptyString = "";

  // ___________________________________________________________________________
  /**
   * Pre Close Provider Enquiry method checks if enquiry date is after the
   * current date
   *
   * @param key
   * contains ProviderEnquiryKey
   * @param details
   * contains CloseProviderEnquiryDetails
   */
  protected void precancelEnquiry(ProviderEnquiryKey key,
    CloseProviderEnquiryDetails details) throws AppException,
      InformationalException {

    // Create the provider enquiry object
    curam.cpm.sl.entity.intf.ProviderEnquiry providerEnquiryObj = ProviderEnquiryFactory.newInstance();

    // Read provider enquiry object
    ProviderEnquiryDtls providerEnquiryDtls = providerEnquiryObj.read(key);

    // Check if enquiry date is after the current date
    // TimeZone Aware changes.
    curam.util.type.DateTime enquiryDate = new curam.util.type.DateTime(
      TimeZoneUtility.getTimeZoneAdjustedDateTime(
        curam.util.type.DateTime.getCurrentDateTime(),
        TransactionInfo.getUserTimeZone()));
    curam.util.type.Date enquiryDateTimeZone = new curam.util.type.Date(
      TimeZoneUtility.getTimeZoneAdjustedDateTime(
        providerEnquiryDtls.enquiryDate, TransactionInfo.getUserTimeZone()));
    
    if (providerEnquiryDtls.enquiryDate.after(enquiryDate)) {
      throw curam.message.impl.PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_XFV_ENDDATE_MUST_NOT_BE_EARLIER_THAN_ENQUIRY_DATE(
        providerEnquiryDtls.endDate, enquiryDateTimeZone);

    }

    // Set end date to current date and record status to CLOSED
    details.endDate = Date.getCurrentDate();
    details.recordStatus = ProviderStatus.CLOSED;

  }

  // ___________________________________________________________________________
  /**
   * Pre List Provider Enquiry
   *
   * @param key
   * contains ListProviderEnquiryKey
   */
  protected void prelistProviderEnquires(ListProviderEnquiryKey key)
    throws AppException, InformationalException {

    key.addressLine1Type = ADDRESSELEMENTTYPE.LINE1;
    key.cityTypeCode = ADDRESSELEMENTTYPE.CITY;

  }

  // ___________________________________________________________________________
  /**
   * Pre Search Provider Enquiry Validates the search criteria,sets search key
   * parameters
   *
   * @param key
   * contains reference number,name,street1 and city
   */
  protected void presearchProviderEnquiry(SearchProviderEnquiryKey key)
    throws AppException, InformationalException {

    // Manipulation variable
    String referenceNumber = key.referenceNumber.trim();
    String name = key.name.trim();
    String street1 = key.street1.trim();
    String city = key.city.trim();

    // Throw an exception if search criteria empty
    if (name.equals(kEmptyString) && street1.equals(kEmptyString)
      && city.equals(kEmptyString) && referenceNumber.equals(kEmptyString)) {
      throw PROVIDERExceptionCreator.ERR_PROVIDER_FV_SOME_SEARCH_CRITERIA_MUST_BE_ENTERED();
    }

    // Initialize the search Criteria
    key.searchByReferenceNumber = referenceNumber.length() > 0;
    key.searchByName = name.length() > 0;
    key.searchByStreet1 = street1.length() > 0;
    key.searchByCity = city.length() > 0;
    key.enquiryStatus = ProviderStatus.OPEN;
    key.addressLine1Type = ADDRESSELEMENTTYPE.LINE1;
    key.cityTypeCode = ADDRESSELEMENTTYPE.CITY;

    if (!name.equalsIgnoreCase(kEmptyString)) {
      key.name = CuramConst.gkSqlWildcard + name.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

    if (!street1.equalsIgnoreCase(kEmptyString)) {
      key.street1 = CuramConst.gkSqlWildcard + street1.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

    if (!city.equalsIgnoreCase(kEmptyString)) {
      key.city = CuramConst.gkSqlWildcard + city.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

  }

  // ___________________________________________________________________________
  /**
   * Pre Search Enquiry Validates the search criteria,sets search key
   * parameters
   *
   * @param key
   * contains reference number,name,street1 and city
   */

  protected void presearchAllEnquiries(SearchProviderEnquiryKey key)
    throws AppException, InformationalException {

    // Manipulation variable
    String referenceNumber = key.referenceNumber.trim();
    String name = key.name.trim();
    String street1 = key.street1.trim();
    String city = key.city.trim();

    // Throw an exception if search criteria empty
    if (name.equals(kEmptyString) && street1.equals(kEmptyString)
      && city.equals(kEmptyString) && referenceNumber.equals(kEmptyString)) {
      throw PROVIDERExceptionCreator.ERR_PROVIDER_FV_SOME_SEARCH_CRITERIA_MUST_BE_ENTERED();
    }

    // Initialize the search parameters
    key.searchByReferenceNumber = referenceNumber.length() > 0;
    key.searchByName = name.length() > 0;
    key.searchByStreet1 = street1.length() > 0;
    key.searchByCity = city.length() > 0;
    key.addressLine1Type = ADDRESSELEMENTTYPE.LINE1;
    key.cityTypeCode = ADDRESSELEMENTTYPE.CITY;

    if (!name.equalsIgnoreCase(kEmptyString)) {
      key.name = CuramConst.gkSqlWildcard + name.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

    if (!street1.equalsIgnoreCase(kEmptyString)) {
      key.street1 = CuramConst.gkSqlWildcard + street1.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

    if (!city.equalsIgnoreCase(kEmptyString)) {
      key.city = CuramConst.gkSqlWildcard + city.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

  }
}
