/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.core.fact.SystemUserFactory;
import curam.cpm.eua.entity.struct.ServiceInvoiceRequestKey;
import curam.cpm.eua.entity.struct.ServiceInvoiceRequestLineItemReadmultiKey;
import curam.cpm.eua.facade.fact.ExternalServiceInvoiceRequestLineItemFactory;
import curam.cpm.eua.facade.struct.ServiceInvoiceRequestLISummaryDetailsList;
import curam.cpm.facade.intf.Provider;
import curam.cpm.facade.struct.ChangeRequestStatusKey;
import curam.cpm.facade.struct.RejectRequestKey;
import curam.cpm.facade.struct.RequestDetails;
import curam.cpm.facade.struct.RequestDetailsList;
import curam.cpm.facade.struct.RequestSearchByDateRangeKey;
import curam.cpm.facade.struct.RequestSearchByOwnerAndStatusKey;
import curam.cpm.facade.struct.RequestSearchByTypeAndDateCreatedKey;
import curam.cpm.facade.struct.ServiceInvoiceRequestDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.message.impl.REQUESTExceptionCreator;
import curam.cpm.sl.entity.struct.ProviderGroupKey;
import curam.cpm.sl.entity.struct.ProviderKey;
import curam.cpm.sl.entity.struct.ServiceInvoiceLineItemDtls;
import curam.events.REQUESTDECISION;
import curam.events.SERVICEINVOICE;
import curam.externaluseraccess.impl.RequestDAO;
import curam.externaluseraccess.impl.RequestStatusEntry;
import curam.externaluseraccess.impl.RequestTypeEntry;
import curam.externaluseraccess.impl.ServiceInvoiceRequestDAO;
import curam.externaluseraccess.impl.ServiceInvoiceRequestLineItem;
import curam.externaluseraccess.impl.ServiceInvoiceRequestLineItemDAO;
import curam.financial.impl.ServiceInvoiceDAO;
import curam.financial.impl.ServiceInvoiceLineItemStatusEntry;
import curam.financial.impl.ServiceInvoiceRequestLineItemStatusEntry;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;


/**
 * Facade layer class having API for managing Requests
 *
 */
public abstract class Request extends curam.cpm.facade.base.Request {

  /**
   * Constructor
   */
  public Request() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  @Inject
  protected RequestDAO requestDAO;

  @Inject
  protected ServiceInvoiceRequestDAO serviceInvoiceRequestDAO;

  @Inject
  protected ServiceInvoiceRequestLineItemDAO serviceInvoiceRequestLineItemDAO;

  @Inject
  protected ServiceInvoiceDAO serviceInvoiceDAO;

  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  // Start CR00098705, JSP
  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;
  // End CR00098705

  /**
   * Read Service Invoice Request
   *
   * @param key
   * contains search criteria
   * @return ServiceInvoiceRequestDetails
   * @throws AppException
   * @throws InformationalException
   */
  public ServiceInvoiceRequestDetails readServiceInvoiceRequest(
    ServiceInvoiceRequestKey key) throws AppException, InformationalException {
    ServiceInvoiceRequestDetails serviceInvoiceRequestDetails = new ServiceInvoiceRequestDetails();

    curam.externaluseraccess.impl.Request request = requestDAO.get(
      key.requestID);
    curam.externaluseraccess.impl.ServiceInvoiceRequest serviceInvoiceRequest = serviceInvoiceRequestDAO.get(
      key.requestID);

    serviceInvoiceRequestDetails.requestType = serviceInvoiceRequest.getRequestType().getCode();
    serviceInvoiceRequestDetails.dateSubmitted = serviceInvoiceRequest.getDateSubmitted();
    serviceInvoiceRequestDetails.dateCreated = serviceInvoiceRequest.getDateCreated();
    serviceInvoiceRequestDetails.referenceNumber = serviceInvoiceRequest.getReferenceNumber();
    serviceInvoiceRequestDetails.requestStatus = request.getLifecycleState().getCode();
    serviceInvoiceRequestDetails.versionNo = serviceInvoiceRequest.getVersionNo();

    if (request.getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDERGROUP)) {

      long providerGroupID = request.getProviderOrganization().getID();
      curam.cpm.facade.intf.ProviderGroup providerGroupObj = curam.cpm.facade.fact.ProviderGroupFactory.newInstance();
      ProviderGroupKey providerGroupKey = new ProviderGroupKey();

      providerGroupKey.providerGroupConcernRoleID = providerGroupID;
      curam.cpm.facade.struct.ViewProviderGroupDetails viewProviderGroupDetails = providerGroupObj.viewProviderGroup(
        providerGroupKey);

      serviceInvoiceRequestDetails.comments = request.getComments();
      serviceInvoiceRequestDetails.pageContextDescription = getContextDescription(
        viewProviderGroupDetails.concernRoleID);
      // BEGIN, CR00184531, GP
      serviceInvoiceRequestDetails.contextDescription.details.providerName = viewProviderGroupDetails.providerName;
      // END, CR00184531

    } else {

      long providerID = request.getProviderOrganization().getID();
      Provider providerObj = curam.cpm.facade.fact.ProviderFactory.newInstance();
      ProviderKey providerKey = new ProviderKey();

      providerKey.providerConcernRoleID = providerID;
      curam.cpm.facade.struct.ProviderEnrollmentDetails viewDetails = providerObj.viewProvider(
        providerKey);

      serviceInvoiceRequestDetails.comments = request.getComments();
      serviceInvoiceRequestDetails.pageContextDescription = getContextDescription(
        viewDetails.concernRoleID);
      // BEGIN, CR00184531, GP
      serviceInvoiceRequestDetails.contextDescription.details.providerName = viewDetails.providerName;
      // END, CR00184531
    }
    return serviceInvoiceRequestDetails;
  }

  /**
   * Search requests by type and date created
   *
   * @param key
   * contains search criteria
   * @return RequestDetailsList
   * @throws AppException
   * @throws InformationalException
   */
  public RequestDetailsList searchByTypeDateCreatedOwner(
    RequestSearchByTypeAndDateCreatedKey key) throws AppException,
      InformationalException {

    RequestDetailsList requestDetailsList = new RequestDetailsList();
    String userName = TransactionInfo.getProgramUser();
    final Set<curam.externaluseraccess.impl.Request> requests;

    // BEGIN, CR00098690, KR
    // Check search criteria is empty.
    if (key.requestType.equals("") && key.dateCreated.equals(Date.kZeroDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REQUESTExceptionCreator.ERR_REQUEST_FV_SOME_SEARCH_CRITERIA_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // END, CR00098690, KR
    if (key.requestType.equals("") && !key.dateCreated.equals(Date.kZeroDate)) {
      requests = requestDAO.searchByCreationDateAndOwner(
        RequestTypeEntry.get(key.requestType), userName, key.dateCreated);
    } else if (!key.requestType.equals("")
      && key.dateCreated.equals(Date.kZeroDate)) {
      requests = requestDAO.searchByRequestTypeAndOwner(
        RequestTypeEntry.get(key.requestType), userName, key.dateCreated);
    } else {
      requests = requestDAO.searchByRequestTypeOwnerAndCreationDate(
        RequestTypeEntry.get(key.requestType), userName, key.dateCreated);
    }

    for (final curam.externaluseraccess.impl.Request request : requests) {

      RequestDetails requestDetails = new RequestDetails();

      if (request.getProviderOrganization().getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDERGROUP)) {

        long providerGroupID = request.getProviderOrganization().getID();
        curam.cpm.facade.intf.ProviderGroup providerGroupObj = curam.cpm.facade.fact.ProviderGroupFactory.newInstance();
        ProviderGroupKey providerGroupKey = new ProviderGroupKey();

        providerGroupKey.providerGroupConcernRoleID = providerGroupID;
        curam.cpm.facade.struct.ViewProviderGroupDetails viewProviderGroupDetails = providerGroupObj.viewProviderGroup(
          providerGroupKey);

        requestDetails.dateCreated = request.getDateCreated();
        requestDetails.versionNo = request.getVersionNo();
        requestDetails.dateSubmitted = request.getDateSubmitted();
        requestDetails.requestStatus = request.getLifecycleState().getCode();
        requestDetails.requestID = request.getID();
        requestDetails.requestType = request.getRequestType().getCode();
        requestDetails.createdBy = viewProviderGroupDetails.providerName;
        requestDetails.name = viewProviderGroupDetails.providerName;
        requestDetails.providerRefNumber = viewProviderGroupDetails.referenceNumber;
        requestDetails.providerConcernRoleID = viewProviderGroupDetails.concernRoleID;
        requestDetailsList.requestDetails.addRef(requestDetails);

      } else {

        long providerID = request.getProviderOrganization().getID();
        Provider providerObj = curam.cpm.facade.fact.ProviderFactory.newInstance();
        ProviderKey providerKey = new ProviderKey();

        providerKey.providerConcernRoleID = providerID;
        curam.cpm.facade.struct.ProviderEnrollmentDetails viewDetails = providerObj.viewProvider(
          providerKey);

        requestDetails.dateCreated = request.getDateCreated();
        requestDetails.versionNo = request.getVersionNo();
        requestDetails.dateSubmitted = request.getDateSubmitted();
        requestDetails.requestStatus = request.getLifecycleState().getCode();
        requestDetails.requestID = request.getID();
        requestDetails.requestType = request.getRequestType().getCode();
        requestDetails.createdBy = viewDetails.providerName;
        requestDetails.name = viewDetails.providerName;
        requestDetails.providerRefNumber = viewDetails.referenceNumber;
        requestDetails.providerConcernRoleID = viewDetails.concernRoleID;
        requestDetailsList.requestDetails.addRef(requestDetails);

      }

    }
    ValidationHelper.failIfErrorsExist();
    return requestDetailsList;
  }

  // BEGIN, CR00216313, RD
  /**
   * Searches requests within date range.
   *
   * @param requestSearchByDateRangeKey
   * Contains the date range.
   *
   * @return The request details list.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public RequestDetailsList searchByDateRange(
    RequestSearchByDateRangeKey requestSearchByDateRangeKey)
    throws AppException, InformationalException {

    RequestDetailsList requestDetailsList = new RequestDetailsList();

    // BEGIN, CR00225866, GP
    final Set<curam.externaluseraccess.impl.Request> requests = requestDAO.searchByOwnerAndDateRange(
      SystemUserFactory.newInstance().getUserDetails().userName,
      requestSearchByDateRangeKey.startDate,
      requestSearchByDateRangeKey.endDate);

    // END, CR00225866

    for (final curam.externaluseraccess.impl.Request request : requests) {
      RequestDetails requestDetails = new RequestDetails();

      if (request.getProviderOrganization().getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDERGROUP)) {

        long providerGroupID = request.getProviderOrganization().getID();

        curam.cpm.facade.intf.ProviderGroup providerGroupObj = curam.cpm.facade.fact.ProviderGroupFactory.newInstance();
        ProviderGroupKey providerGroupKey = new ProviderGroupKey();

        providerGroupKey.providerGroupConcernRoleID = providerGroupID;
        curam.cpm.facade.struct.ViewProviderGroupDetails viewProviderGroupDetails = providerGroupObj.viewProviderGroup(
          providerGroupKey);

        requestDetails.requestID = request.getID();
        requestDetails.requestType = request.getRequestType().getCode();
        requestDetails.requestCategory = request.getRequestCategory().getCode();
        requestDetails.createdBy = viewProviderGroupDetails.providerName;
        requestDetails.name = viewProviderGroupDetails.providerName;
        requestDetails.providerRefNumber = viewProviderGroupDetails.referenceNumber;
        requestDetails.providerConcernRoleID = viewProviderGroupDetails.concernRoleID;

        // BEGIN, CR00236455, GP
        requestDetails.dateCreated = request.getDateCreated();
        // END, CR00236455
        
        // BEGIN, CR00247606, GP
        requestDetails.requestStatus = request.getLifecycleState().getCode();
        // END, CR00247606
        
        // BEGIN, CR00225866, GP
        requestDetails.dateSubmitted = request.getDateSubmitted();
        // END, CR00225866
        requestDetailsList.requestDetails.addRef(requestDetails);

      } else {

        long providerID = request.getProviderOrganization().getID();
        Provider providerObj = curam.cpm.facade.fact.ProviderFactory.newInstance();
        ProviderKey providerKey = new ProviderKey();

        providerKey.providerConcernRoleID = providerID;
        curam.cpm.facade.struct.ProviderEnrollmentDetails providerEnrollmentDetails = providerObj.viewProvider(
          providerKey);

        requestDetails.requestID = request.getID();
        requestDetails.requestType = request.getRequestType().getCode();
        requestDetails.requestCategory = request.getRequestCategory().getCode();
        requestDetails.createdBy = providerEnrollmentDetails.providerName;
        requestDetails.name = providerEnrollmentDetails.providerName;
        requestDetails.providerRefNumber = providerEnrollmentDetails.referenceNumber;
        requestDetails.providerConcernRoleID = providerEnrollmentDetails.concernRoleID;

        // BEGIN, CR00236455, GP
        requestDetails.dateCreated = request.getDateCreated();
        // END, CR00236455

        // BEGIN, CR00247606, GP
        requestDetails.requestStatus = request.getLifecycleState().getCode();
        // END, CR00247606
        
        // BEGIN, CR00225866, GP
        requestDetails.dateSubmitted = request.getDateSubmitted();
        // END, CR00225866
        requestDetailsList.requestDetails.addRef(requestDetails);
      }
    }
    return requestDetailsList;
  }

  // END, CR00216313

  /**
   * Search requests by owner and status
   *
   * @param key
   * contains search criteria
   * @return RequestDetailsList
   * @throws AppException
   * @throws InformationalException
   */
  public RequestDetailsList searchByOwnerAndStatus(
    RequestSearchByOwnerAndStatusKey key) throws AppException,
      InformationalException {

    RequestDetailsList requestDetailsList = new RequestDetailsList();

    key.key.userName = TransactionInfo.getProgramUser();
    key.key.reqStatus = RequestStatusEntry.SUBMITTED.getCode();

    final Set<curam.externaluseraccess.impl.Request> requests = requestDAO.searchByRequestOwnerAndStatus(
      key.key.userName, RequestStatusEntry.SUBMITTED);

    for (final curam.externaluseraccess.impl.Request request : requests) {
      RequestDetails requestDetails = new RequestDetails();

      if (request.getProviderOrganization().getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDERGROUP)) {

        long providerGroupID = request.getProviderOrganization().getID();

        curam.cpm.facade.intf.ProviderGroup providerGroupObj = curam.cpm.facade.fact.ProviderGroupFactory.newInstance();
        ProviderGroupKey providerGroupKey = new ProviderGroupKey();

        providerGroupKey.providerGroupConcernRoleID = providerGroupID;
        curam.cpm.facade.struct.ViewProviderGroupDetails viewProviderGroupDetails = providerGroupObj.viewProviderGroup(
          providerGroupKey);

        requestDetails.requestID = request.getID();
        requestDetails.requestType = request.getRequestType().getCode();
        requestDetails.requestCategory = request.getRequestCategory().getCode();
        requestDetails.createdBy = viewProviderGroupDetails.providerName;
        requestDetails.name = viewProviderGroupDetails.providerName;
        requestDetails.providerRefNumber = viewProviderGroupDetails.referenceNumber;
        requestDetails.providerConcernRoleID = viewProviderGroupDetails.concernRoleID;

        // BEGIN, CR00246655, GP
        requestDetails.dateCreated = request.getDateCreated();
        requestDetails.dateSubmitted = request.getDateSubmitted();
        requestDetails.requestStatus = request.getLifecycleState().getCode();
        // END, CR00246655
        requestDetailsList.requestDetails.addRef(requestDetails);

      } else {

        long providerID = request.getProviderOrganization().getID();
        Provider providerObj = curam.cpm.facade.fact.ProviderFactory.newInstance();
        ProviderKey providerKey = new ProviderKey();

        providerKey.providerConcernRoleID = providerID;
        curam.cpm.facade.struct.ProviderEnrollmentDetails providerEnrollmentDetails = providerObj.viewProvider(
          providerKey);

        requestDetails.requestID = request.getID();
        requestDetails.requestType = request.getRequestType().getCode();
        requestDetails.requestCategory = request.getRequestCategory().getCode();
        requestDetails.createdBy = providerEnrollmentDetails.providerName;
        requestDetails.name = providerEnrollmentDetails.providerName;
        requestDetails.providerRefNumber = providerEnrollmentDetails.referenceNumber;
        requestDetails.providerConcernRoleID = providerEnrollmentDetails.concernRoleID;

        // BEGIN, CR00246655, GP
        requestDetails.dateCreated = request.getDateCreated();
        requestDetails.dateSubmitted = request.getDateSubmitted();
        requestDetails.requestStatus = request.getLifecycleState().getCode();
        // END, CR00246655

        requestDetailsList.requestDetails.addRef(requestDetails);
      }
    }

    // BEGIN, CR00143526, KR
    return sortRequestsByName(requestDetailsList);
    // END, CR00143526
  }

  /**
   * This method to determines the context description for license pages
   *
   * @param providerConcernRoleID
   * the providerConcernRoleID
   *
   * @return String containing context description
   * @throws AppException
   * @throws InformationalException
   */
  public String getContextDescription(long providerConcernRoleID)
    throws AppException, InformationalException {

    String contextDescription = "";

    // Start CR00098705, JSP
    final ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      providerConcernRoleID);

    contextDescription = providerOrganization.getName()
      + GeneralConstants.kSpace + GeneralConstants.kMinus
      + GeneralConstants.kSpace + providerOrganization.getPrimaryAlternateID();
    // End CR00098705

    return contextDescription;
  }

  /**
   * Cancel Request
   *
   * @param key
   * contains criteria of request to cancel
   * @throws AppException
   * @throws InformationalException
   */
  public void cancelRequest(ChangeRequestStatusKey key) throws AppException,
      InformationalException {
    final curam.externaluseraccess.impl.Request request = requestDAO.get(
      key.requestID);

    request.cancel(key.versionNo);

  }

  /**
   * Accept Requests
   *
   * @param key
   * contains criteria of request to be accepted
   * @throws AppException
   * @throws InformationalException
   */
  public void acceptRequest(ChangeRequestStatusKey key) throws AppException,
      InformationalException {
    final curam.externaluseraccess.impl.Request request = requestDAO.get(
      key.requestID);

    // BEGIN, CR00234426, SSK
    request.accept(request.getVersionNo());
    // END, CR00234426

    // need to read the service invoice request
    curam.externaluseraccess.impl.ServiceInvoiceRequest serviceInvoiceRequest = serviceInvoiceRequestDAO.get(
      key.requestID);

    final ConcernRole concernRoleObj = concernRoleDAO.get(
      serviceInvoiceRequest.getProviderOrganization().getID());
    // create a new entity instance
    final curam.financial.impl.ServiceInvoice serviceInvoice = serviceInvoiceDAO.newInstance();

    // set service invoice values required to create a service invoice record
    setServiceInvoiceFieldsForInsert(serviceInvoice, serviceInvoiceRequest,
      concernRoleObj);

    curam.cpm.eua.facade.intf.ExternalServiceInvoiceRequestLineItem externalServiceInvoiceRequestLineItemObj = ExternalServiceInvoiceRequestLineItemFactory.newInstance();

    ServiceInvoiceRequestLineItemReadmultiKey serviceInvoiceRequestLineItemReadmultiKey = new ServiceInvoiceRequestLineItemReadmultiKey();

    serviceInvoiceRequestLineItemReadmultiKey.serviceInvoiceRequestID = key.requestID;
    ServiceInvoiceRequestLISummaryDetailsList serviceInvoiceRequestLISummaryDetailsList = externalServiceInvoiceRequestLineItemObj.listSIRequestLineItemsBySIRequestID(
      serviceInvoiceRequestLineItemReadmultiKey);

    // Set all values for service invoice line items
    for (int i = 0; i
      < serviceInvoiceRequestLISummaryDetailsList.details.size(); i++) {

      // BEGIN CR00090253, PDN
      // Only transfer requests that are open should be transfered
      if (serviceInvoiceRequestLISummaryDetailsList.details.item(i).status.compareTo(
        ServiceInvoiceRequestLineItemStatusEntry.CANCELED.toString())
          != 0) {
        final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem = serviceInvoiceRequestLineItemDAO.get(
          serviceInvoiceRequestLISummaryDetailsList.details.item(i).serviceInvoiceRequestLineItemID);

        setServiceInvoiceLineItemFieldsForInsert(serviceInvoice,
          serviceInvoiceRequestLineItem, concernRoleObj);
      }
      // END CR00090253
    }
    // raise event for accepting the task
    raiseAcceptRequestEvent(key);
    // create task informing financials of new service invoice
    createFinancialsTask(serviceInvoice);

  }

  /**
   * Reject Request
   *
   * @param key
   * contains criteria for request to be rejected
   *
   * @throws AppException
   * @throws InformationalException
   */
  public void rejectRequest(RejectRequestKey key) throws AppException,
      InformationalException {
    final curam.externaluseraccess.impl.Request request = requestDAO.get(
      key.requestID);

    // BEGIN, CR00234426, SSK
    request.reject(request.getVersionNo(), key.rejectReason);
    // END, CR00234426

    // create event
    Event requestRejected = new Event();

    requestRejected.eventKey = REQUESTDECISION.REQUESTREJECTED;
    requestRejected.primaryEventData = key.requestID;

    // The request has been Rejected by the owner of the provider who created it
    // Raise event to close this workflow task.
    EventService.raiseEvent(requestRejected);

  }

  /**
   * Set values for service invoice record before the insert
   *
   * @param serviceInvoice
   * service Invoice record to be created
   * @param serviceInvoiceRequest
   * struct containing information passed from external client
   * @param concernRoleObj
   * contains details of the concern role
   */
  // BEGIN, CR00177241, PM
  protected void setServiceInvoiceFieldsForInsert(final curam.financial.impl.ServiceInvoice serviceInvoice,
    // END, CR00177241
    curam.externaluseraccess.impl.ServiceInvoiceRequest serviceInvoiceRequest, final ConcernRole concernRoleObj)
    throws AppException, InformationalException {

    serviceInvoice.setExternalReferenceNo(
      serviceInvoiceRequest.getExternalReferenceNumber());

    serviceInvoice.setOriginatorReferenceNo(
      concernRoleObj.getPrimaryAlternateID());
    serviceInvoice.setOriginatorName(concernRoleObj.getName());
    serviceInvoice.setComments(serviceInvoiceRequest.getComments());
    serviceInvoice.setCreationDate(Date.getCurrentDate());
    serviceInvoice.setReceiptDate(serviceInvoiceRequest.getDateSubmitted());
    serviceInvoice.insert();
  }

  // BEGIN, CR00084504, SP

  /**
   * Set values for service invoice line items records before the insert
   *
   * @param serviceInvoiceLineItem
   * service invoice line item record to be created
   * @param serviceInvoice
   * service Invoice record to be created
   * @param serviceInvoiceRequestLineItem
   * struct containing line item information passed from external client
   * @param concernRoleObj
   * contains details of the concern role
   */
  // BEGIN, CR00177241, PM
  protected void setServiceInvoiceLineItemFieldsForInsert(final curam.financial.impl.ServiceInvoice serviceInvoice,
    // END, CR00177241
    final ServiceInvoiceRequestLineItem serviceInvoiceRequestLineItem,
    final ConcernRole concernRoleObj)
    throws AppException, InformationalException {
    ServiceInvoiceLineItemDtls serviceInvoiceLineItemDtls = new ServiceInvoiceLineItemDtls();

    serviceInvoiceLineItemDtls.serviceInvoiceID = serviceInvoice.getID();

    serviceInvoiceLineItemDtls.referenceNo = serviceInvoiceRequestLineItem.getReferenceNumber();
    serviceInvoiceLineItemDtls.amountInvoiced = serviceInvoiceRequestLineItem.getInvoiceAmount();

    serviceInvoiceLineItemDtls.noOfUnits = serviceInvoiceRequestLineItem.getNumberOfUnits();

    serviceInvoiceLineItemDtls.serviceDateFrom = serviceInvoiceRequestLineItem.getDateRange().start();
    serviceInvoiceLineItemDtls.serviceDateTo = serviceInvoiceRequestLineItem.getDateRange().end();
    serviceInvoiceLineItemDtls.providerName = concernRoleObj.getName();
    // BEGIN CR00091933, PDN
    serviceInvoiceLineItemDtls.providerReferenceNo = serviceInvoiceRequestLineItem.getProviderReferenceNumber();
    serviceInvoiceLineItemDtls.clientFirstName = serviceInvoiceRequestLineItem.getClientFirstName();
    serviceInvoiceLineItemDtls.clientLastName = serviceInvoiceRequestLineItem.getClientLastName();
    serviceInvoiceLineItemDtls.clientReferenceNo = serviceInvoiceRequestLineItem.getClientReferenceNumber();
    serviceInvoiceLineItemDtls.unitAmount = serviceInvoiceRequestLineItem.getUnitAmount();
    serviceInvoiceLineItemDtls.caseReferenceNo = serviceInvoiceRequestLineItem.getCaseReferenceNumber();
    serviceInvoiceLineItemDtls.caseID = serviceInvoiceRequestLineItem.getCaseID();
    serviceInvoiceLineItemDtls.serviceID = serviceInvoiceRequestLineItem.getService().getID();
    serviceInvoiceLineItemDtls.status = ServiceInvoiceLineItemStatusEntry.OPEN.getCode();
    serviceInvoiceLineItemDtls.payeeName = serviceInvoiceRequestLineItem.getPayeeName();
    serviceInvoiceLineItemDtls.payeeReferenceNo = serviceInvoiceRequestLineItem.getPayeeReferenceNumber();
    // END CR00091933
    serviceInvoiceLineItemDtls.saReferenceNo = serviceInvoiceRequestLineItem.getServiceAuthorizationReferenceNumber();
    serviceInvoiceLineItemDtls.clientDOB = serviceInvoiceRequestLineItem.getClientDateOfBirth();
    serviceInvoice.addLineItem(serviceInvoiceLineItemDtls);

  }

  // END, CR00084504

  // ___________________________________________________________________________
  /**
   * Raise event after accepting request
   *
   * @param key
   * contains the request id
   *
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void raiseAcceptRequestEvent(ChangeRequestStatusKey key) throws AppException, InformationalException {
    // END, CR00177241
    // create event
    Event requestAccepted = new Event();

    requestAccepted.eventKey = REQUESTDECISION.REQUESTACCEPTED;
    requestAccepted.primaryEventData = key.requestID;

    // The request has been Accepted by the owner of the provider who created it
    // Raise event to close this workflow task.
    EventService.raiseEvent(requestAccepted);
  }

  /**
   * Raise task for financials to indicate new service invoice
   *
   * @param serviceInvoice
   * contains the service invoice id
   *
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void createFinancialsTask(
    // END, CR00177241
    final curam.financial.impl.ServiceInvoice serviceInvoice)
    throws AppException, InformationalException {

    // BEGIN, CR00171487, AK
    final Event event = new Event();

    event.eventKey = SERVICEINVOICE.NEW_SERVICEINVOICE_CREATED;
    event.primaryEventData = serviceInvoice.getID();
    EventService.raiseEvent(event);
    // END, CR00171487

  }

  // BEGIN, CR00143526, KR
  /**
   * Sorts a set of external user requests into a sorted list for display.
   *
   * @param unsortedRequests
   * the set of unsorted external user requests.
   *
   * @return a sorted list of external user requests.
   */
  @SuppressWarnings(CPMConstants.kUnchecked)
  // BEGIN, CR00177241, PM
  protected RequestDetailsList sortRequestsByName(
    // END, CR00177241
    RequestDetailsList unsortedRequests) {

    /*
     * Sort by name for display - using a list (instead of a set) in case there
     * are duplicate names.
     */
    List<RequestDetails> requestDetailsList = new ArrayList<RequestDetails>();
    int noOfEnquiries = unsortedRequests.requestDetails.size();

    for (int i = 0; i < noOfEnquiries; i++) {
      requestDetailsList.add(unsortedRequests.requestDetails.item(i));
    }

    Collections.sort(requestDetailsList, new Comparator<RequestDetails>() {
      public int compare(final RequestDetails lhs,
        RequestDetails rhs) {
        return lhs.name.compareToIgnoreCase(rhs.name);
      }
    });

    RequestDetailsList requestDetailsListSorted = new RequestDetailsList();

    requestDetailsListSorted.requestDetails.addAll(requestDetailsList);

    return requestDetailsListSorted;
  }
  // END, CR00143526

}
