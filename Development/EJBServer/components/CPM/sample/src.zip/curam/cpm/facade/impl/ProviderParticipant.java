/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpm.facade.impl;


import com.google.inject.Inject;
import curam.codetable.REPRESENTATIVETYPE;
import curam.core.fact.AddressFactory;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.OtherAddressData;
import curam.cpm.facade.struct.CreateProviderParticipantDetails;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.facade.struct.ListProviderParticipantDetails;
import curam.cpm.facade.struct.ListProviderParticipantDetailsList;
import curam.cpm.facade.struct.ProviderParticipantDetails;
import curam.cpm.facade.struct.ProviderParticipantDetailsList;
import curam.cpm.facade.struct.ProviderParticipantVersionDetails;
import curam.cpm.facade.struct.ViewProviderParticipantDetails;
import curam.cpm.sl.entity.struct.ProviderPartyKey;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderParticipantDAO;
import curam.provider.impl.ProviderParticipantTypeEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.StringUtil;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.StringHelper;
import curam.core.intf.Address;


/**
 * Facade layer class having API for managing Provider Participant.
 *
 */

public abstract class ProviderParticipant extends curam.cpm.facade.base.ProviderParticipant {

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected ProviderParticipantDAO providerParticipantDAO;

  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  /**
   * Constructor
   */
  public ProviderParticipant() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Retrieves the list of Provider Participant related to the provider.
   *
   * @param key Contains provider ID.
   *
   *
   * @return ListProviderParticipantDetailsList Contains list of Participants
   * associated with a provider.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListProviderParticipantDetailsList listProviderParticipants(
    ConcernRoleKey key) throws AppException, InformationalException {

    final Provider provider = providerDAO.get(key.concernRoleID);

    // Initializing the list
    final ListProviderParticipantDetailsList listProviderParticipantDetailsList = new ListProviderParticipantDetailsList();

    // Getting the list of provider participants
    for (final curam.provider.impl.ProviderParticipant providerParticipant : provider.getProviderParticipants()) {

      final ListProviderParticipantDetails listProviderParticipantDetails = new ListProviderParticipantDetails();

      listProviderParticipantDetails.providerParticipantID = providerParticipant.getID();
      listProviderParticipantDetails.participantID = providerParticipant.getParty().getID();
      listProviderParticipantDetails.fromDate = providerParticipant.getDateRange().start();
      listProviderParticipantDetails.toDate = providerParticipant.getDateRange().end();
      listProviderParticipantDetails.recordStatus = providerParticipant.getLifecycleState().getCode();
      listProviderParticipantDetails.type = providerParticipant.getParticipantType().getCode();
      listProviderParticipantDetails.participantName = providerParticipant.getParty().getName();
      listProviderParticipantDetails.concernRoleType = providerParticipant.getParty().getConcernRoleType().getCode();

      listProviderParticipantDetailsList.participantDetailsList.addRef(
        listProviderParticipantDetails);
    }

    return listProviderParticipantDetailsList;
  }

  /**
   * Creates provider Participant with the provider participant details
   * passed.
   *
   * @param details
   * Contains the details of the participant to be inserted for a
   * provider or provider group.
   *
   * @return ProviderPartyKey Contains Participant ID.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ProviderPartyKey createProviderParticipant(
    CreateProviderParticipantDetails details) throws AppException,
      InformationalException {

    // validate provider participant details for insert
    validateInsert(details);

    final ProviderPartyKey providerParticipantKey = new ProviderPartyKey();

    // If person is already not registered with the agency,
    // then create a person record
    if (0 == details.searchConcernRoleID) {
      // Recording the representative details
      // Struct passed to Representative::registerRepresentative
      // Representative maintenance object
      curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      if (StringHelper.isEmpty(details.name)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new curam.util.exception.AppException(
            curam.message.CPMCOMMONMESSAGES.ERR_CPMCOMMONMSG_FV_NAME_NOT_ENTERED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            5);
      }

      RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = details.name;

      representativeRegistrationDetails.representativeRegistrationDetails.addressData = details.addressData;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = details.phoneCountryCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = details.phoneAreaCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = details.phoneNumber;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension = details.phoneExtension;
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();

      representativeRegistrationDetails.representativeDtls.representativeType = REPRESENTATIVETYPE.CONTACT;

      // Call registerRepresentative
      representativeObj.registerRepresentative(
        representativeRegistrationDetails);
      details.participantID = representativeRegistrationDetails.representativeDtls.concernRoleID;
    } else {
      details.participantID = details.searchConcernRoleID;
    }

    // Service layer
    curam.provider.impl.ProviderParticipant providerParticipant = providerParticipantDAO.newInstance();

    providerParticipant.setProviderOrganization(
      providerDAO.get(details.providerID));
    providerParticipant.setDateRange(
      new DateRange(details.fromDate, details.toDate));
    providerParticipant.setParticipantType(
      ProviderParticipantTypeEntry.get(details.type));

    final curam.participant.impl.ConcernRole concernRole = concernRoleDAO.get(
      details.participantID);

    providerParticipant.setParty(concernRole);

    providerParticipant.insert();

    providerParticipantKey.providerPartyID = providerParticipant.getID();

    return providerParticipantKey;
  }

  /**
   * Updates the Provider Participant with the provider participant details
   * passed.
   *
   * @param providerParticipantDtls
   * Contains details of provider participant.
   *
   * @return ProviderPartyKey
   * Contains the provider participant ID.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ProviderPartyKey updateProviderParticipant(
    ProviderParticipantDetails providerParticipantDtls) throws AppException,
      InformationalException {

    // Create instance of ProviderParticipant entity
    curam.provider.impl.ProviderParticipant providerParticipant = providerParticipantDAO.get(
      providerParticipantDtls.providerPartyID);

    providerParticipant.setDateRange(
      new DateRange(providerParticipantDtls.startDate,
      providerParticipantDtls.endDate));
    providerParticipant.setParticipantType(
      ProviderParticipantTypeEntry.get(providerParticipantDtls.participantType));

    providerParticipant.modify(providerParticipantDtls.versionNo);

    final ProviderPartyKey providerPartyKey = new ProviderPartyKey();

    providerPartyKey.providerPartyID = providerParticipant.getID();

    return providerPartyKey;
  }

  /**
   * Reads provider or provider group participant details.
   *
   * @param key
   * Contains provider party ID.
   *
   * @return ViewProviderParticipantDetails Contains the details of provider
   * participant.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ViewProviderParticipantDetails viewProviderParticipant(
    ProviderPartyKey key) throws AppException, InformationalException {

    ViewProviderParticipantDetails details = new ViewProviderParticipantDetails();

    // Create an instance of ProviderParticipant struct (Entity layer)
    curam.provider.impl.ProviderParticipant providerParticipant = providerParticipantDAO.get(
      key.providerPartyID);

    details.name = providerParticipant.getParty().getName();
    details.concernRoleType = providerParticipant.getParty().getConcernRoleType().getCode();
    details.concernRoleID = providerParticipant.getParty().getID();
    details.from = providerParticipant.getDateRange().start();
    details.to = providerParticipant.getDateRange().end();
    details.recordStatus = providerParticipant.getLifecycleState().getCode();
    details.type = providerParticipant.getParticipantType().getCode();
    details.versionNo = providerParticipant.getVersionNo();

    return details;
  }

  /**
   * Cancels the Provider Participant.
   *
   * @param keyVersionDetails
   * contains provider participant ID
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */

  public void cancelProviderParticipant(KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    curam.provider.impl.ProviderParticipant providerParticipant = providerParticipantDAO.get(
      keyVersionDetails.id);

    providerParticipant.cancel(keyVersionDetails.version);
  }

  // BEGIN, CR00199320, GP
  /**
   * Lists all the participants for a given concern role.
   *
   * @param concernRoleKey
   * Concern role for which participants are to be listed.
   *
   * @return All the participant for the given concern role.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ProviderParticipantDetailsList listProviderParticipantDetails(
    final ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    ProviderParticipantDetailsList providerParticipantDetailsList = new ProviderParticipantDetailsList();

    final Provider provider = providerDAO.get(concernRoleKey.concernRoleID);

    for (final curam.provider.impl.ProviderParticipant providerParticipant : provider.getProviderParticipants()) {

      ProviderParticipantVersionDetails providerParticipantVersionDetails = new ProviderParticipantVersionDetails();

      providerParticipantVersionDetails.versionDetails.providerParticipantID = providerParticipant.getID();
      providerParticipantVersionDetails.versionDetails.participantID = providerParticipant.getParty().getID();
      providerParticipantVersionDetails.versionDetails.fromDate = providerParticipant.getDateRange().start();
      providerParticipantVersionDetails.versionDetails.toDate = providerParticipant.getDateRange().end();
      providerParticipantVersionDetails.versionDetails.recordStatus = providerParticipant.getLifecycleState().getCode();
      providerParticipantVersionDetails.versionDetails.type = providerParticipant.getParticipantType().getCode();
      providerParticipantVersionDetails.versionDetails.participantName = providerParticipant.getParty().getName();
      providerParticipantVersionDetails.versionDetails.concernRoleType = providerParticipant.getParty().getConcernRoleType().getCode();
      providerParticipantVersionDetails.versionNo = providerParticipant.getVersionNo();
      
      providerParticipantDetailsList.participantDetails.addRef(
        providerParticipantVersionDetails);
    }

    return providerParticipantDetailsList;
  }

  // END, CR00199320

  /**
   * This facade layer method to validate provider participant.
   * To check the participant is person or representative.
   *
   * @param createProviderParticipantDetails
   * createProviderParticipantDetails contains the details of provider
   * participant
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void validateInsert(
    // END, CR00177241
    CreateProviderParticipantDetails createProviderParticipantDetails)
    throws AppException, InformationalException {

    StringBuffer representativeDetails = new StringBuffer();
    OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = createProviderParticipantDetails.addressData;
    // BEGIN, CR00278685, AC
    if (!StringUtil.isNullOrEmpty(otherAddressData.addressData)) {
      Address addressObj = AddressFactory.newInstance();

      addressObj.getAddressStrings(otherAddressData);
      representativeDetails.append(otherAddressData.addressData.trim());
    }
    // END, CR00278685
    representativeDetails.append(createProviderParticipantDetails.name);
    representativeDetails.append(otherAddressData.addressData.trim());
    representativeDetails.append(createProviderParticipantDetails.phoneAreaCode);
    representativeDetails.append(
      createProviderParticipantDetails.phoneCountryCode);
    representativeDetails.append(
      createProviderParticipantDetails.phoneExtension);
    representativeDetails.append(createProviderParticipantDetails.phoneNumber);
    // BEGIN, CR00278685, AC
    if (0 == createProviderParticipantDetails.searchConcernRoleID
      && 0 == representativeDetails.toString().length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new curam.util.exception.AppException(
          curam.message.CPMCOMMONMESSAGES.ERR_CPMCOMMONMSG_XRV_REGISTERED_PERSON_OR_REGISTRATION_DETAILS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          3);
    }

    if (0 != createProviderParticipantDetails.searchConcernRoleID
      && 0 != representativeDetails.toString().length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new curam.util.exception.AppException(
          curam.message.CPMCOMMONMESSAGES.ERR_CPMCOMMONMSG_XRV_BOTH_REGISTERED_PERSON_AND_REGISTRATION_DETAILS_CANNOT_BE_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
          
    }
    // END,  CR00278685
  }
}

