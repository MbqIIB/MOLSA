/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.homestudy.impl;


import com.google.inject.ImplementedBy;

import curam.provider.impl.ProviderParty;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.LinkTable;


/**
 * Interface for the home visit Interview Attendee functionality.
 */
@ImplementedBy(InterviewAttendeeImpl.class)
public interface InterviewAttendee extends
    LinkTable<HomeVisitInterview, InterviewAttendee>, InterviewAttendeeAccessor {

  /**
   * Sets the home visit interview to associate the attendee with.
   *
   * @param homeVisitInterview
   * the interview to associate the attendee to.
   */
  public void setHomeVisitInterview(HomeVisitInterview homeVisitInterview);

  /**
   * Sets the provider member or participant to associate the attendee with.
   *
   * @param providerParty
   * the provider member or participant to associate the attendee with.
   */
  public void setProviderParty(ProviderParty providerParty);

  /**
   * Gets the home visit interview this attendee attended.
   *
   * @return the interview this attendee attended
   */
  public HomeVisitInterview getHomeVisitInterview();

  /**
   * Gets the provider party this attendee is recorded as.
   *
   * @return the provider party this attendee is recorded as
   */
  public ProviderParty getProviderParty();

  /**
   * Removes the record of attendance for the given attendee of a home visit
   * interview.
   *
   * @param interviewAttendee
   * The attendee to remove.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @see curam.homestudy.impl.InterviewAttendeeImpl#remove(InterviewAttendee)
   * The default implementation -
   * curam.homestudy.impl.InterviewAttendeeImpl#remove(InterviewAttendee)
   */
  public void remove(final InterviewAttendee interviewAttendee)
    throws InformationalException;

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the interview attendee events functionality surrounding the
   * remove method.
   */
  public interface InterviewAttendeeRemoveEvents {

    /**
     * Event interface invoked before the main body of the remove method.
     * {@linkplain curam.homestudy.impl.InterviewAttendee#remove}
     *
     * @param interviewAttendee
     * The object instance as it was before the main body of the remove
     * method.
     * @param value
     * The parameter as passed to the remove method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preRemove(InterviewAttendeeAccessor interviewAttendee,
      InterviewAttendee value) throws InformationalException;

    /**
     * Event interface invoked after the main body of the remove method.
     * {@linkplain curam.homestudy.impl.InterviewAttendee#remove}
     *
     * @param interviewAttendee
     * The object instance as it was after the main body of the remove
     * method.
     * @param value
     * The parameter as passed to the remove method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postRemove(InterviewAttendeeAccessor interviewAttendee,
      InterviewAttendee value) throws InformationalException;
  }


  /**
   * Interface to the interview attendee events functionality surrounding the
   * insert method.
   */
  public interface InterviewAttendeeInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.homestudy.impl.InterviewAttendee#insert}
     *
     * @param interviewAttendee
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(InterviewAttendeeAccessor interviewAttendee)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.homestudy.impl.InterviewAttendee#insert}
     *
     * @param interviewAttendee
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(InterviewAttendeeAccessor interviewAttendee)
      throws InformationalException;
  }
  // END, CR00144381
}
