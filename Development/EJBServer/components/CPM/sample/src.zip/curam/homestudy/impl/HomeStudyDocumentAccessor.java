/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import curam.cpm.sl.struct.HomeStudyDocumentData;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;
import curam.util.type.Date;


/**
 * Accessor interface for HomeStudyDocument
 * {@linkplain curam.homestudy.impl.HomeStudyDocument}.
 *
 */
public interface HomeStudyDocumentAccessor extends StandardEntity {

  /**
   * Gets the document template ID.
   *
   * @return the ID of document template
   */
  public String getDocumentTemplateID();

  /**
   * Gets the document template name.
   *
   * @return the name of document template
   */
  public String getDocumentTemplateName();

  /**
   * Gets the attachment ID.
   *
   * @return the ID of the attachment
   */
  public long getAttachmentID();

  /**
   * Gets date created.
   *
   * @return the date when the document was created.
   */
  public Date getDateCreated();

  /**
   * Gets document description.
   *
   * @return the document description
   */
  public String getDocumentDescription();

  /**
   * Gets template data (<code>XML BLOB</code>).
   *
   * @return the template data
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public curam.util.type.Blob getTemplateData() throws InformationalException,
      AppException;

  /**
   * Gets the name of the user who created the home study document.
   *
   * @return the user name
   */
  public String getCreatedBy();

  /**
   * Gets the Home Study details
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The associated home study details.
   */
  public HomeStudyAccessor getHomeStudy();

  /**
   * Gets the attachment data (<i>Microsoft Word Document</i>).
   *
   * @return the attachment data
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public HomeStudyDocumentData getAttachmentData() throws AppException,
      InformationalException;
}
