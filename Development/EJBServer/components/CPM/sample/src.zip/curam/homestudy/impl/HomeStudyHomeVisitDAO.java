/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.homestudy.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain curam.homestudy.impl.HomeStudyHomeVisit}.
 */
@ImplementedBy(HomeStudyHomeVisitDAOImpl.class)
public interface HomeStudyHomeVisitDAO extends StandardDAO<HomeStudyHomeVisit> {

  // ___________________________________________________________________________
  /**
   * Returns a <code>Set</code> with all the home study visits for a home study.
   * <p>The canceled records are filtered out.
   *
   * @param parent the home study that the listed home visits should apply to
   * @return the home visits which have the home study key specified applies to.
   * @see #searchActiveByHomeStudy(HomeStudy)
   */
  public Set<HomeStudyHomeVisit> searchByHomeStudy(HomeStudy parent);

  // ________________________________________________________________________
  /**
   * Returns a <code>Set</code> with all the home visits for the given home 
   * study excluding canceled records.
   *
   * @param parent the parent home study record to find the visits for
   * @return the set of active records.
   * @see #searchByHomeStudy(HomeStudy)
   */
  public Set<HomeStudyHomeVisit> searchActiveByHomeStudy(HomeStudy parent);
}
