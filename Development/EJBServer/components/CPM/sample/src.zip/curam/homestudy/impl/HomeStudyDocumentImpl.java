/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Set;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import com.google.inject.Inject;

import curam.attachment.impl.Attachment;
import curam.codetable.ATTACHMENTSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.fact.DocumentTemplateFactory;
import curam.core.sl.entity.intf.DocumentTemplate;
import curam.core.sl.entity.struct.DocumentTemplateDtls;
import curam.core.sl.entity.struct.DocumentTemplateKey;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.HomeStudyDocumentDtls;
import curam.cpm.sl.struct.HomeStudyDocumentData;
import curam.message.impl.HOMESTUDYDOCUMENTExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderMember;
import curam.provider.impl.ProviderSecurity;
import curam.provider.impl.ProviderStatusEntry;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.resources.GeneralConstants;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * Standard implementation of <code>HomeStudyDocument</code>.
 *
 * @see curam.homestudy.impl.HomeStudyDocument
 */
// BEGIN, CR00183213, SS
public class HomeStudyDocumentImpl extends SingleTableLogicallyDeleteableEntityImpl<HomeStudyDocumentDtls> implements
  HomeStudyDocument {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for modifyAttachmentData events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyDocumentModifyAttachmentDataEvents> modifyAttachmentDataEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyDocumentInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyDocumentModifyEvents> modifyEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyDocumentCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for get document template name events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyDocumentGetDocumentTemplateNameEvents> getDocumentTemplateNameEventDispatcherFactory;

  /**
   * Event dispatcher for get template data events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyDocumentGetTemplateDataEvents> getTemplateDataEventDispatcherFactory;

  /**
   * Event dispatcher for get attachment data events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyDocumentGetAttachmentDataEvents> getAttachmentDataEventDispatcherFactory;

  // END, CR00235789

  @Inject
  protected HomeStudyDAO homeStudyDAO;

  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00183213, SS

  // BEGIN, CR00226594, FM
  @Inject
  protected Attachment attachmentObj;

  // END, CR00226594

  /**
   * Constructor for the class.
   */
  protected HomeStudyDocumentImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public HomeStudy getHomeStudy() {

    final long homeStudyIDLocal = getDtls().homeStudyID;

    if (homeStudyIDLocal == 0) {
      return null;
    } else {
      return homeStudyDAO.get(homeStudyIDLocal);
    }

  }

  /**
   * {@inheritDoc}
   */
  public void setHomeStudy(final HomeStudy homeStudy) {

    getDtls().homeStudyID = homeStudy.getID();

  }

  /**
   * {@inheritDoc}
   */
  public String getDocumentTemplateID() {

    return getDtls().documentTemplateID;

  }

  /**
   * {@inheritDoc}
   */
  public void setDocumentTemplateID(final String documentTemplateID) {

    getDtls().documentTemplateID = documentTemplateID;

  }

  /**
   * Gets the document template name.
   *
   * @return The Document Template Name.
   */
  public String getDocumentTemplateName() {

    // BEGIN, CR00235789, AK
    // Raise the pre get document template name home study document event.
    getDocumentTemplateNameEventDispatcherFactory.get(HomeStudyDocumentGetDocumentTemplateNameEvents.class).preGetDocumentTemplateName(
      this);
    // END, CR00235789

    // Document template manipulation variables
    curam.core.sl.entity.intf.DocumentTemplate documentTemplateObj = curam.core.sl.entity.fact.DocumentTemplateFactory.newInstance();

    // document template key
    DocumentTemplateKey documentTemplateKey = new DocumentTemplateKey();

    // set document template key
    documentTemplateKey.documentTemplateID = getDocumentTemplateID();

    // document template details
    DocumentTemplateDtls documentTemplateDtls = new DocumentTemplateDtls();

    try {

      // read document template details
      documentTemplateDtls = documentTemplateObj.read(documentTemplateKey);

    } catch (AppException e) {

      throw new AppRuntimeException(e);

    } catch (InformationalException ie) {

      throw new AppRuntimeException(ie);

    }

    // BEGIN, CR00235789, AK
    // Raise the post get document template name home study document event.
    getDocumentTemplateNameEventDispatcherFactory.get(HomeStudyDocumentGetDocumentTemplateNameEvents.class).postGetDocumentTemplateName(
      this, documentTemplateDtls.name);
    // END, CR00235789

    return documentTemplateDtls.name;

  }

  /**
   * {@inheritDoc}
   */
  public long getAttachmentID() {

    return getDtls().attachmentID;

  }

  /**
   * Sets the attachment ID
   *
   * @param attachmentID
   * attachment ID
   */
  // BEGIN, CR00177241, PM
  protected void setAttachmentID(final long attachmentID) {
    // END, CR00177241

    getDtls().attachmentID = attachmentID;

  }

  /**
   * {@inheritDoc}
   */
  public Date getDateCreated() {

    return getDtls().dateCreated;

  }

  /**
   * Sets the date when the document was created.
   *
   * @param dateCreated
   * the date of creation
   */
  // BEGIN, CR00177241, PM
  protected void setDateCreated(final Date dateCreated) {
    // END, CR00177241

    getDtls().dateCreated = dateCreated;

  }

  /**
   * {@inheritDoc}
   */
  public String getDocumentDescription() {

    return getDtls().documentDescription;

  }

  /**
   * {@inheritDoc}
   */
  public void setDocumentDescription(final String documentDescription) {

    getDtls().documentDescription = documentDescription;

  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {

    // Set initial record status by calling inherited method
    super.setNewInstanceDefaults();

    // set the user who created this record
    setCreatedBy(curam.util.transaction.TransactionInfo.getProgramUser());
    setDateCreated(Date.getCurrentDate());

  }

  /**
   * Validates that all mandatory fields are populated.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>{@link curam.message.HOMESTUDYDOCUMENT#ERR_HOMESTUDYDOCUMENT_FV_DESCRIPTION_MANDATORY} -
   * If Document Description is not entered. </li>
   * <li>{@link curam.message.HOMESTUDYDOCUMENT#ERR_HOMESTUDYDOCUMENT_FV_DOCUMENTTEMPLATE_MANDATORY} -
   * If Document Template is not entered. </li>
   * </ul>
   *
   */
  public void mandatoryFieldValidation() {

    // If Document Description is not entered.
    if (getDocumentDescription().equals("")) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYDOCUMENTExceptionCreator.ERR_HOMESTUDYDOCUMENT_FV_DESCRIPTION_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

    // If Document Template is not entered.
    if (getDocumentTemplateID().equals("")) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYDOCUMENTExceptionCreator.ERR_HOMESTUDYDOCUMENT_FV_DOCUMENTTEMPLATE_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

    }

  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// None needed
  }

  /**
   * Validates that changes made to Home study document entity on the database
   * are consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>{@link curam.message.HOMESTUDYDOCUMENT#ERR_HOMESTUDYDOCUMENT_XRV_HOMESTUDY_MANDATORY} -
   * If related home study is not specified for the home study document.</li>
   * </ul>
   *
   */
  public void crossEntityValidation() {

    // Home Study
    if (getHomeStudy() == null) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYDOCUMENTExceptionCreator.ERR_HOMESTUDYDOCUMENT_XRV_HOMESTUDY_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

  }

  /**
   * Perform the attachment data validation.
   *
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYDOCUMENT#ERR_HOMESTUDYDOCUMENT_FV_DOCUMENTTEMPLATE_MANDATORY} -
   * if the document template ID is empty.
   */
  public void attachmentDataValidation() throws InformationalException {

    // Document Template
    if (getDocumentTemplateID().equals("")) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYDOCUMENTExceptionCreator.ERR_HOMESTUDYDOCUMENT_FV_DOCUMENTTEMPLATE_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

    ValidationHelper.failIfErrorsExist();

  }

  /**
   * Inserts the Home study document. Checks the provider security.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}
   * - If the provider is closed. Provider Details cannot be updated.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYDOCUMENT#ERR_HOMESTUDYDOCUMENT_XRV_HOMESTUDY_CANCELLED_CANNOT_ADD_HOMESTUDYDOCUMENT}
   * - If the home study document is added to a canceled home study.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYDOCUMENT#ERR_HOMESTUDYDOCUMENT_XRV_HOMESTUDY_APPROVED_CANNOT_ADD}
   * - If the home study is Approved, a home study document cannot be
   * added.
   */
  @Override
  public void insert() throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(getHomeStudy().getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre insert home study document event.
    insertEventDispatcherFactory.get(HomeStudyDocumentInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    // BEGIN, CR00207577, RD
    if (HomeStudyStatusEntry.CANCELLED.equals(
      getHomeStudy().getLifecycleState())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYDOCUMENTExceptionCreator.ERR_HOMESTUDYDOCUMENT_XRV_HOMESTUDY_CANCELLED_CANNOT_ADD_HOMESTUDYDOCUMENT(
          HomeStudyStatusEntry.CANCELLED.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00207577

    // if the status of the provider is closed
    if (getHomeStudy().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 25);
      ValidationHelper.failIfErrorsExist();
    }

    // check the home study has not already been approved
    HomeStudy homeStudy = getHomeStudy();

    if (homeStudy.getLifecycleState().equals(HomeStudyStatusEntry.APPROVED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYDOCUMENTExceptionCreator.ERR_HOMESTUDYDOCUMENT_XRV_HOMESTUDY_APPROVED_CANNOT_ADD(
          HomeStudyStatusEntry.APPROVED.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    try {

      setDefaultAttachmentData();

    } catch (AppException e) {

      throw new AppRuntimeException(e);

    }

    // Call insert
    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert home study document event.
    insertEventDispatcherFactory.get(HomeStudyDocumentInsertEvents.class).postInsert(
      this);
    // END, CR00235789

  }

  /**
   * Modifies the Home study document. Checks the provider security to modify
   * the home study document.
   *
   * @param versionNo
   * The version number.
   *
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYDOCUMENT#ERR_HOMESTUDYDOCUMENT_XRV_HOMESTUDY_APPROVED_CANNOT_UPDATE} -
   * If the home study is Approved, a home study document cannot be
   * updated.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(getHomeStudy().getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre modify home study document event.
    modifyEventDispatcherFactory.get(HomeStudyDocumentModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // if the status of the provider is closed
    if (getHomeStudy().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 23);
      ValidationHelper.failIfErrorsExist();
    }

    // check the home study has not already been approved
    HomeStudy homeStudy = getHomeStudy();

    if (homeStudy.getLifecycleState().equals(HomeStudyStatusEntry.APPROVED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYDOCUMENTExceptionCreator.ERR_HOMESTUDYDOCUMENT_XRV_HOMESTUDY_APPROVED_CANNOT_UPDATE(
          HomeStudyStatusEntry.APPROVED.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // call modify
    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify home study document event.
    modifyEventDispatcherFactory.get(HomeStudyDocumentModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * Cancels the Home study document.Checks the provider security to cancel the
   * home study document.Also cancels the attachment data.
   *
   * @param versionNo
   * The version number.
   *
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYDOCUMENT#ERR_HOMESTUDYDOCUMENT_XRV_HOMESTUDY_APPROVED_CANNOT_DELETE} -
   * If the home study is Approved, a home study document cannot be
   * deleted.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.
   */
  public void cancel(final int versionNo) throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(getHomeStudy().getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre cancel home study document event.
    cancelEventDispatcherFactory.get(HomeStudyDocumentCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    // if the status of the provider is closed
    if (getHomeStudy().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 24);
      ValidationHelper.failIfErrorsExist();
    }

    // check the home study has not already been approved
    HomeStudy homeStudy = getHomeStudy();

    if (homeStudy.getLifecycleState().equals(HomeStudyStatusEntry.APPROVED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYDOCUMENTExceptionCreator.ERR_HOMESTUDYDOCUMENT_XRV_HOMESTUDY_APPROVED_CANNOT_DELETE(
          HomeStudyStatusEntry.APPROVED.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // all OK so cancel
    super.cancel(versionNo);

    try {

      cancelAttachmentData();

    } catch (AppException e) {

      throw new AppRuntimeException(e);

    }
    // BEGIN, CR00235789, AK
    // Raise the post cancel home study document event.
    cancelEventDispatcherFactory.get(HomeStudyDocumentCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Gets the template data as blob.
   *
   * @return The template data as blob.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public curam.util.type.Blob getTemplateData() throws InformationalException,
      AppException {

    // BEGIN, CR00235789, AK
    // Raise the pre get template data home study document event.
    getTemplateDataEventDispatcherFactory.get(HomeStudyDocumentGetTemplateDataEvents.class).preGetTemplateData(
      this);
    // END, CR00235789

    // Output the XML as a string and assign it to the return object
    XMLOutputter outputter = new XMLOutputter();

    Element rootElement = new Element(CuramConst.gkRoot);
    Element fieldsElement = new Element(CuramConst.gkFields);
    Element fieldElement = new Element(CuramConst.gkField);

    Element fieldProviderMemberEntry;
    StringBuffer providerMemberEntryContent;

    HomeStudy homeStudyLocal = getHomeStudy();

    Provider provider = homeStudyLocal.getProvider();

    fieldElement.setAttribute(CuramConst.gkName, CPMConstants.kProviderName);
    fieldElement.setAttribute(CuramConst.gkValue, provider.getName());
    fieldsElement.addContent(fieldElement);

    Set<ProviderMember> providerMembers = provider.getProviderMembers();
    // Begin CR00096779, ABS
    Integer memberNo = Integer.valueOf(GeneralConstants.kZero);
    // End CR00096779

    DateRange providerMemberDateRange;
    Date currentDate = Date.getCurrentDate();
    String roleDescription;

    for (final ProviderMember providerMember : providerMembers) {

      providerMemberDateRange = providerMember.getDateRange();

      if ((!providerMemberDateRange.endsBefore(currentDate))
        && (!providerMember.getLifecycleState().getCode().equals(
          RECORDSTATUS.CANCELLED))) {

        if (memberNo < CPMConstants.kMaxNumberOfProviderMembers) {

          memberNo = memberNo + 1;

          // create a field
          fieldProviderMemberEntry = new Element(CuramConst.gkField);
          // BEGIN, CR CR00097088, DN
          fieldProviderMemberEntry.setAttribute(CuramConst.gkName,
            CPMConstants.kProviderMemberEntry + memberNo.toString());
          // END, CR CR00097088
          // retrieve provider role description
          roleDescription = curam.util.type.CodeTable.getOneItem(
            providerMember.getRole().getTableName(),
            providerMember.getRole().getCode());

          providerMemberEntryContent = new StringBuffer(
            CPMConstants.kProviderMemberEntrySize);

          // create field description
          providerMemberEntryContent.append(providerMember.getParty().getName());
          providerMemberEntryContent.append(CuramConst.gkSpace);
          providerMemberEntryContent.append(CuramConst.gkDash);
          providerMemberEntryContent.append(CuramConst.gkSpace);
          providerMemberEntryContent.append(roleDescription);

          // set value
          fieldProviderMemberEntry.setAttribute(CuramConst.gkValue,
            providerMemberEntryContent.toString());

          fieldsElement.addContent(fieldProviderMemberEntry);

        } else {

          break;

        } // end of provider member number check

      } // end of date range and lifecycle state check

    } // end loop

    // fill remaining slots with blanks
    if (memberNo < CPMConstants.kMaxNumberOfProviderMembers) {

      for (int i = memberNo; i < CPMConstants.kMaxNumberOfProviderMembers;) {

        i++;
        fieldProviderMemberEntry = new Element(CuramConst.gkField);
        fieldProviderMemberEntry.setAttribute(CuramConst.gkName,
          CPMConstants.kProviderMemberEntry + i);
        fieldProviderMemberEntry.setAttribute(CuramConst.gkValue, "");

        fieldsElement.addContent(fieldProviderMemberEntry);

      }

    }

    rootElement.addContent(fieldsElement);

    curam.util.type.Blob blob = new curam.util.type.Blob(
      outputter.outputString(rootElement).getBytes());

    // BEGIN, CR00235789, AK
    // Raise the post get template data home study document event.
    getTemplateDataEventDispatcherFactory.get(HomeStudyDocumentGetTemplateDataEvents.class).postGetTemplateData(
      this, blob);
    // END, CR00235789

    return blob;
  }

  /**
   * Gets the home study document attachment data.
   *
   * @return The Home Study Document data details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public HomeStudyDocumentData getAttachmentData() throws AppException,
      InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre get attachment data home study document event.
    getAttachmentDataEventDispatcherFactory.get(HomeStudyDocumentGetAttachmentDataEvents.class).preGetAttachmentData(
      this);
    // END, CR00235789

    // Return structure
    HomeStudyDocumentData homeStudyDocumentData = new HomeStudyDocumentData();

    // Attachment manipulation variables
    AttachmentKey attachmentKey = new AttachmentKey();
    AttachmentDtls attachmentDtls;

    // Set key to read attachment entity
    // attachmentKey.attachmentID = key.attachmentID;
    attachmentKey.attachmentID = getDtls().attachmentID;

    // Read attachment details
    attachmentDtls = attachmentObj.read(attachmentKey);

    homeStudyDocumentData.documentData = attachmentDtls.attachmentContents;
    homeStudyDocumentData.documentDataVersionNo = attachmentDtls.versionNo;

    // BEGIN, CR00235789, AK
    // Raise the post get attachment data home study document event.
    getAttachmentDataEventDispatcherFactory.get(HomeStudyDocumentGetAttachmentDataEvents.class).postGetAttachmentData(
      this, homeStudyDocumentData);
    // END, CR00235789

    return homeStudyDocumentData;

  }

  // BEGIN, CR00125604,KR

  /**
   * Modifies the attachment data (<i>Microsoft Word Document</i>). Checks the
   * provider security to modify the attachment data.
   *
   * @param data
   * the container of the attachment data
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyAttachmentData(final HomeStudyDocumentData data)
    throws AppException, InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(getHomeStudy().getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre modifyAttachmentData home study document event.
    modifyAttachmentDataEventDispatcherFactory.get(HomeStudyDocumentModifyAttachmentDataEvents.class).preModifyAttachmentData(
      this, data);
    // END, CR00235789

    // Attachment manipulation variables
    AttachmentKey attachmentKey = new AttachmentKey();
    AttachmentDtls attachmentDtls;

    attachmentKey.attachmentID = getDtls().attachmentID;

    // read attachment details
    attachmentDtls = attachmentObj.read(attachmentKey);

    // set the data
    attachmentDtls.attachmentContents = data.documentData;

    // BEGIN, CR00226594, FM
    attachmentDtls.versionNo = data.documentDataVersionNo;
    // END, CR00226594

    // update the attachment
    attachmentObj.modify(attachmentKey, attachmentDtls);

    // BEGIN, CR00235789, AK
    // Raise the post modifyAttachmentData home study document event.
    modifyAttachmentDataEventDispatcherFactory.get(HomeStudyDocumentModifyAttachmentDataEvents.class).postModifyAttachmentData(
      this, data);
    // END, CR00235789

  }

  // END, CR00125604

  /**
   * Cancels the attachment data (<i>Microsoft Word Document</i>).
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void cancelAttachmentData() throws AppException,
      InformationalException {
    // END, CR00177241

    // Attachment manipulation variables
    AttachmentKey attachmentKey = new AttachmentKey();

    attachmentKey.attachmentID = getDtls().attachmentID;
    // BEGIN, CR00306951, SS
    attachmentObj.cancel(attachmentKey);
    // END, CR00306951
  }

  /**
   * {@inheritDoc}
   */
  public String getCreatedBy() {

    return getDtls().createdBy;

  }

  /**
   * Sets the name of the user who created the home study document.
   *
   * @param createdBy
   * contains the name of the user who created this home study document
   */
  // BEGIN, CR00177241, PM
  protected void setCreatedBy(final String createdBy) {
    // END, CR00177241

    getDtls().createdBy = createdBy;

  }

  /**
   * Sets the attachment Data (<i>Microsoft Word Document</i>) from the
   * template.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setDefaultAttachmentData() throws AppException,
      InformationalException {
    // END, CR00177241

    // validate that the attachment can
    // be created
    attachmentDataValidation();

    // Attachment manipulation variables
    AttachmentDtls attachmentDtls;

    // attachment entity, dtls structure
    attachmentDtls = new AttachmentDtls();

    // insert attachment details
    attachmentDtls.attachmentStatus = ATTACHMENTSTATUS.ACTIVE;
    attachmentDtls.statusCode = RECORDSTATUS.NORMAL;

    // Document template manipulation variables
    DocumentTemplate documentTemplateObj = DocumentTemplateFactory.newInstance();
    DocumentTemplateKey documentTemplateKey = new DocumentTemplateKey();
    DocumentTemplateDtls documentTemplateDtls;

    // Set key to read document template
    documentTemplateKey.documentTemplateID = getDocumentTemplateID();

    // Read document template
    documentTemplateDtls = documentTemplateObj.read(documentTemplateKey);

    attachmentDtls.attachmentContents = documentTemplateDtls.contents;
    attachmentDtls.attachmentName = documentTemplateDtls.name
      + CPMConstants.kFileNameExtension;
    attachmentDtls.receiptDate = Date.getCurrentDate();

    attachmentObj.insert(attachmentDtls);

    // BEGIN, CR00226594, FM
    setAttachmentID(attachmentDtls.attachmentID);
    // END, CR00226594

  }

}
