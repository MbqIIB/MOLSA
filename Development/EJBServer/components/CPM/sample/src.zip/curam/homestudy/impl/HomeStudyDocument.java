/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import com.google.inject.ImplementedBy;

import curam.cpm.sl.struct.HomeStudyDocumentData;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.Validator;
import curam.util.persistence.helper.LogicallyDeleteable;


/**
 * A document created as part of a home study that is based on a Microsoft Word
 * template which contains standard home study topics to be addressed.
 * <p>
 * For example, a template on which a document may be based might contain
 * sections to capture information on the social history of the providers,
 * provider resources, or the attitudes and beliefs of the provider regarding
 * foster care/adoption issues.
 */
@ImplementedBy(HomeStudyDocumentImpl.class)
public interface HomeStudyDocument extends HomeStudyDocumentAccessor,
    Insertable, OptimisticLockModifiable, LogicallyDeleteable, Validator {

  /**
   * Gets the instance of <code>HomeStudy</code> entity.
   *
   * @return the instance of <code>HomeStudy</code> parent entity
   */
  public HomeStudy getHomeStudy();

  /**
   * Sets the instance of <code>HomeStudy</code> entity.
   *
   * @param homeStudy
   * the home study for this document
   *
   * @see curam.homestudy.impl.HomeStudy
   */
  public void setHomeStudy(final HomeStudy homeStudy);

  /**
   * Sets the document template ID.
   *
   * @param documentTemplateID
   * the ID of the document template
   */
  public void setDocumentTemplateID(final String documentTemplateID);

  /**
   * Sets the document description.
   *
   * @param documentDescription
   * the document description
   */
  public void setDocumentDescription(final String documentDescription);

  /**
   * Gets the attachment data (<i>Microsoft Word Document</i>).
   *
   * @return the attachment data
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.homestudy.impl.HomeStudyDocumentImpl#getAttachmentData() The
   * default implementation -
   * curam.homestudy.impl.HomeStudyDocumentImpl#getAttachmentData()
   */
  public HomeStudyDocumentData getAttachmentData() throws AppException,
      InformationalException;

  /**
   * Modifies the attachment data (<i>Microsoft Word Document</i>).
   *
   * @param data
   * the container of the attachment data
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.homestudy.impl.HomeStudyDocumentImpl#modifyAttachmentData(HomeStudyDocumentData)
   * The default implementation -
   * curam.homestudy.impl.HomeStudyDocumentImpl#modifyAttachmentData(HomeStudyDocumentData)
   */
  public void modifyAttachmentData(final HomeStudyDocumentData data)
    throws AppException, InformationalException;

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the home study document events functionality surrounding the
   * modifyAttachmentData method.
   */
  public interface HomeStudyDocumentModifyAttachmentDataEvents {

    /**
     * Event interface invoked before the main body of the modifyAttachmentData
     * method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#modifyAttachmentData}
     *
     * @param homeStudyDocument
     * The object instance as it was before the main body of the
     * modifyAttachmentData method.
     * @param data
     * The parameter as passed to the modifyAttachmentData method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModifyAttachmentData(
      HomeStudyDocumentAccessor homeStudyDocument, HomeStudyDocumentData data)
      throws AppException, InformationalException;

    /**
     * Event interface invoked after the main body of the modifyAttachmentData
     * method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#modifyAttachmentData}
     *
     * @param homeStudyDocument
     * The object instance as it was after the main body of the
     * modifyAttachmentData method.
     * @param data
     * The parameter as passed to the modifyAttachmentData method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModifyAttachmentData(
      HomeStudyDocumentAccessor homeStudyDocument, HomeStudyDocumentData data)
      throws AppException, InformationalException;
  }


  /**
   * Interface to the home study document events functionality surrounding the
   * insert method.
   */
  public interface HomeStudyDocumentInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#insert}
     *
     * @param homeStudyDocument
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(HomeStudyDocumentAccessor homeStudyDocument)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#insert}
     *
     * @param homeStudyDocument
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(HomeStudyDocumentAccessor homeStudyDocument)
      throws InformationalException;
  }


  /**
   * Interface to the home study document events functionality surrounding the
   * modify method.
   */
  public interface HomeStudyDocumentModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#modify}
     *
     * @param homeStudyDocument
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(HomeStudyDocumentAccessor homeStudyDocument,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#modify}
     *
     * @param homeStudyDocument
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(HomeStudyDocumentAccessor homeStudyDocument,
      Integer versionNo) throws InformationalException;
  }


  /**
   * Interface to the home study document events functionality surrounding the
   * cancel method.
   */
  public interface HomeStudyDocumentCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#cancel}
     *
     * @param homeStudyDocument
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(HomeStudyDocumentAccessor homeStudyDocument,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#cancel}
     *
     * @param homeStudyDocument
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(HomeStudyDocumentAccessor homeStudyDocument,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the home study document events functionality surrounding the
   * get document template name method.
   */
  public interface HomeStudyDocumentGetDocumentTemplateNameEvents {

    /**
     * Event interface invoked before the main body of the get document template
     * name method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#getDocumentTemplateName}
     *
     * @param homeStudyDocument
     * The object instance as it was before the main body of the get
     * document template name method.
     */
    public void preGetDocumentTemplateName(
      HomeStudyDocumentAccessor homeStudyDocument);

    /**
     * Event interface invoked after the main body of the get document template
     * name method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#getDocumentTemplateName}
     *
     * @param homeStudyDocument
     * The object instance as it was after the main body of the get
     * document template name method.
     * @param returnValue
     * The return value updated by the Event Handler.
     */
    public void postGetDocumentTemplateName(
      HomeStudyDocumentAccessor homeStudyDocument, String returnValue);
  }


  /**
   * Interface to the home study document events functionality surrounding the
   * get template data method.
   */
  public interface HomeStudyDocumentGetTemplateDataEvents {

    /**
     * Event interface invoked before the main body of the get template data
     * method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#getTemplateData}
     *
     * @param homeStudyDocument
     * The object instance as it was before the main body of the get
     * template data method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void preGetTemplateData(HomeStudyDocumentAccessor homeStudyDocument)
      throws InformationalException, AppException;

    /**
     * Event interface invoked after the main body of the get template data
     * method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#getTemplateData}
     *
     * @param homeStudyDocument
     * The object instance as it was after the main body of the get
     * template data method.
     * @param returnValue
     * The return value updated by the Event Handler.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void postGetTemplateData(
      HomeStudyDocumentAccessor homeStudyDocument,
      curam.util.type.Blob returnValue) throws InformationalException,
        AppException;
  }


  /**
   * Interface to the home study document events functionality surrounding the
   * get attachment data method.
   */
  public interface HomeStudyDocumentGetAttachmentDataEvents {

    /**
     * Event interface invoked before the main body of the get attachment data
     * method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#getAttachmentData}
     *
     * @param homeStudyDocument
     * The object instance as it was before the main body of the get
     * attachment data method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void preGetAttachmentData(HomeStudyDocumentAccessor homeStudyDocument)
      throws InformationalException, AppException;

    /**
     * Event interface invoked after the main body of the get attachment data
     * method.
     * {@linkplain curam.homestudy.impl.HomeStudyDocument#getAttachmentData}
     *
     * @param homeStudyDocument
     * The object instance as it was after the main body of the get
     * attachment data method.
     * @param returnValue
     * The return value updated by the Event Handler.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void postGetAttachmentData(
      HomeStudyDocumentAccessor homeStudyDocument,
      HomeStudyDocumentData returnValue) throws InformationalException,
        AppException;
  }
  // END, CR00144381

}
