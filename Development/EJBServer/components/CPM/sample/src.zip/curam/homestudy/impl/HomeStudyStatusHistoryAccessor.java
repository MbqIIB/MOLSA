/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import curam.util.persistence.StandardEntity;


/**
 * Accessor interface for {@linkplain HomeStudyStatusHistory}.
 *
 */
public interface HomeStudyStatusHistoryAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * Gets the user who entered/modified the home study.
   *
   * @return the user who entered/modified the home study
   */
  public String getUser();

  // ___________________________________________________________________________

  // BEGIN, CR00144284, SK
  /**
   * Gets the status of the home study.
   *
   * @return the status of the home study
   * @see curam.homestudy.impl.HomeStudyStatusEntry
   */
  // END, CR00144284
  public HomeStudyStatusEntry getHomeStudyStatus();

  // ___________________________________________________________________________
  /**
   * Gets the reason the home study was returned.
   *
   * @return the reason the home study was returned
   * @see curam.homestudy.impl.HomeStudyStatusHistoryCreator#setReturnedReason(HomeStudyReturnReasonEntry)
   */
  public HomeStudyReturnReasonEntry getReturnedReason();
}
