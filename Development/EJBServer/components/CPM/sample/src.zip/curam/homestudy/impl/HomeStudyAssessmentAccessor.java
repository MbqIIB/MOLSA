/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import curam.util.persistence.StandardEntity;
import curam.util.type.Date;


/**
 * Accessor interface for HomeStudyAssessment
 * {@linkplain curam.homestudy.impl.HomeStudyAssessment}.
 *
 */
public interface HomeStudyAssessmentAccessor extends StandardEntity {

  /**
   * Gets the home study assessment type.
   * <p>
   * The different types of home study assessments are:
   * <ul>
   * <li>{@link curam.homestudy.impl.HomeStudyAssessmentTypeEntry#EMPLOYMENT}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyAssessmentTypeEntry#FIREINSPECTION}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyAssessmentTypeEntry#MEDICALEXAMINATIONS}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyAssessmentTypeEntry#NOT_SPECIFIED}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyAssessmentTypeEntry#SAFETYINSPECTION}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyAssessmentTypeEntry#WATERTEST}</li>
   * </ul>
   *
   * @return the home study assessment type
   * @see curam.homestudy.impl.HomeStudyAssessmentTypeEntry
   */
  public HomeStudyAssessmentTypeEntry getAssessmentType();

  /**
   * Gets the date completed.
   *
   * @return the date completed
   */
  public Date getDateCompleted();

  /**
   * Returns whether corrective action is required.
   *
   * @return whether corrective action is required
   */
  public boolean isCorrectiveActionRequired();

  /**
   * Gets the corrective action plan.
   *
   * @return the corrective action plan
   */
  public String getCorrectiveActionPlan();

  /**
   * Gets the home study assessment result.
   *
   * @return the home study assessment result
   */
  public HomeStudyAssessmentResultEntry getResult();
  
  /**
   * Gets the home study details.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database. 
   *
   * @return The Home Study details.
   *
   * @see curam.homestudy.impl.HomeStudy
   */
  public curam.homestudy.impl.HomeStudyAccessor getHomeStudy();

}
