/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Set;

import curam.util.persistence.StandardEntity;
import curam.util.type.Date;


/**
 * Accessor interface for HomeStudyHomeVisit
 * {@linkplain curam.homestudy.impl.HomeStudyHomeVisit}.
 *
 */
public interface HomeStudyHomeVisitAccessor extends StandardEntity {

  /**
   * Gets the purpose for the home visit.
   *
   * @return the codetable code representing the purpose for the home visit
   * @see curam.homestudy.impl.HomeVisitPurposeEntry
   */
  public HomeVisitPurposeEntry getPurpose();

  /**
   * Gets the date of the home visit.
   *
   * @return the date of the home visit
   */
  public Date getDateOfVisit();

  /**
   * Gets the findings of the home visit.
   *
   * @return the findings of the home visit
   */
  public String getHomeVisitFindings();

  /**
   * Gets the person who conducted the home visit.
   *
   * @return the identifier for the person who conducted the home visit
   */
  public String getConductedBy();

  /**
   * Gets a <code>Set</code> with all the immutable interviews for the home
   * visit.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return the set with all the immutable interview for the home visit.
   */
  public Set<? extends curam.homestudy.impl.HomeVisitInterviewAccessor> getHomeVisitInterviews();

  /**
   * Gets the home study that is the parent for this home visit.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The home study that is the parent for this home visit.
   *
   * @see curam.homestudy.impl.HomeStudy
   */
  public HomeStudyAccessor getHomeStudy();

}
