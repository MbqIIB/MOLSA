/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.homestudy.impl;


import java.util.List;
import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.provider.impl.Provider;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.Lifecycle;
import curam.util.type.Date;


/**
 * A study conducted on a provider to ascertain that the living conditions and
 * environment of the home are suitable for the care of the agency's clients.
 * <p>
 * <i>An example of a type of provider for which a home study will be conducted is
 * a foster care home.</i>
 */
@ImplementedBy(HomeStudyImpl.class)
public interface HomeStudy extends HomeStudyAccessor, Insertable,
    Commented, OptimisticLockModifiable, Lifecycle<HomeStudyStatusEntry> {
  
  /**
   * Gets the provider for this home study.
   *
   * @return The provider for the home study.
   */
  public Provider getProvider();

  /**
   * Gets the immutable <code>Set</code> of all the home study home visits for
   * this home study.
   *
   * @return The immutable set of all the home study home visits for this home
   * study.
   */
  public Set<HomeStudyHomeVisit> getHomeStudyHomeVisits();

  /**
   * Gets the immutable <code>Set</code> of all the home study documents for
   * this home study.
   *
   * @return The immutable set of all the home study documents for this home
   * study.
   */
  public Set<HomeStudyDocument> getHomeStudyDocuments();

  /**
   * Gets the immutable <code>Set</code> of all the home study assessments for
   * this home study.
   *
   * @return The immutable set of all the home study assessments for this home
   * study.
   */
  public Set<HomeStudyAssessment> getHomeStudyAssessments();

  /**
   * Sets the home study type.
   * <p>
   * The different home study types are:
   * <ul>
   * <li>{@link curam.homestudy.impl.HomeStudyTypeEntry#ADOPTIVEHOME}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyTypeEntry#CHILDCARE}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyTypeEntry#DAYCARE}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyTypeEntry#FOSTERHOME}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyTypeEntry#NOT_SPECIFIED}</li>
   * </ul>
   *
   * @param value The codetable code of home study type to set.
   */
  public void setHomeStudyType(HomeStudyTypeEntry value);

  /**
   * Sets the home study purpose.
   * <p>
   * The different home study purpose entries are:
   * <ul>
   * <li>{@link curam.homestudy.impl.HomeStudyPurposeEntry#CHILDSPECIFICPLACEMENT}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyPurposeEntry#INITIAL}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyPurposeEntry#NOT_SPECIFIED}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyPurposeEntry#REEVALUATION}</li>
   * </ul>
   *
   * @param value The value of purpose to set.
   */
  public void setPurpose(HomeStudyPurposeEntry value);

  /**
   * Sets the home study date initiated.
   *
   * @param value The date initiated to set.
   */
  public void setDateInitiated(Date value);

  /**
   * Sets the home study reevaluation date.
   *
   * @param value The reevaluation date to set.
   */
  public void setReevaluationDate(Date value);

  /**
   * Sets the home study final recommendation.
   * <p>
   * The different values for <code>HomeStudyFinalRecommendtaionEntry</code>
   * are:
   * <ul>
   * <li>{@link curam.homestudy.impl.HomeStudyFinalRecommendationEntry#NOT_SPECIFIED}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyFinalRecommendationEntry#RECOMMENDCERTIFICATION}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyFinalRecommendationEntry#RECOMMENDDENIALOFCERTIFICATION}</li>
   * </ul>
   *
   * @param value The home study final recommendation entry.
   */
  public void setFinalRecommendation(HomeStudyFinalRecommendationEntry value);

  /**
   * Sets the home study support for recommendation.
   *
   * @param value
   * The support for recommendation.
   *
   * @see curam.homestudy.impl.HomeStudyImpl#setSupportForRecommendation(String)
   * The default implementation -
   * curam.homestudy.impl.HomeStudyImpl#setSupportForRecommendation(String).
   */
  public void setSupportForRecommendation(String value);

  /**
   * Sets the home study assessor.
   *
   * @param value
   * The assessor user name.
   *
   * @see curam.homestudy.impl.HomeStudyImpl#setAssessor(String) The default
   * implementation -
   * curam.homestudy.impl.HomeStudyImpl#setAssessor(String).
   */
  public void setAssessor(String value);

  /**
   * Sets the provider for this home study.
   *
   * @param value The provider to set.
   */
  public void setProvider(Provider value);

  // BEGIN, CR00144284, SK
  /**
   * Logically deletes the home study object.
   * <p>
   * Transitions its status from
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#OPEN} to
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#CANCELLED}.
   *
   * @param versionNo
   * The version number of the <code>HomeStudy</code> being canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.homestudy.impl.HomeStudyImpl#cancel(Integer) The default
   * implementation - curam.homestudy.impl.HomeStudyImpl#cancel(Integer)
   */
  // END, CR00144284
  public void cancel(final Integer versionNo) throws InformationalException;

  // BEGIN, CR00144284, SK
  /**
   * Submits this home study object.
   * <p>
   * Transitions its status from
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#OPEN} to
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#SUBMITTED}.
   *
   * @param versionNo
   * The version number of the <code>HomeStudy</code> being
   * submitted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.homestudy.impl.HomeStudyImpl#submit(Integer) The default
   * implementation - curam.homestudy.impl.HomeStudyImpl#submit(Integer)
   */
  // END, CR00144284
  public void submit(final Integer versionNo) throws InformationalException;

  // BEGIN, CR00144284, SK
  /**
   * Rejects this home study object.
   * <p>
   * Transitions its status from
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#SUBMITTED} to
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#RETURNED}.
   *
   * @param versionNo
   * The version number of the <code>HomeStudy</code> being rejected.
   * @param returnedReason
   * The reason the home study has been returned and not approved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.homestudy.impl.HomeStudyImpl#reject(Integer,
   * HomeStudyReturnReasonEntry) The default implementation -
   * curam.homestudy.impl.HomeStudyImpl#reject(Integer,
   * HomeStudyReturnReasonEntry).
   */
  // END, CR00144284
  public void reject(final Integer versionNo, HomeStudyReturnReasonEntry returnedReason)
    throws InformationalException;

  // BEGIN, CR00144284, SK
  /**
   * Approves this home study.
   * <p>
   * Transitions its status from
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#SUBMITTED} to
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#APPROVED}.
   *
   * @param versionNo
   * The version number of the <code>HomeStudy</code> being approved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // END, CR00144284
  public void approve(final Integer versionNo) throws InformationalException;

  /**
   * Gets the immutable <code>List</code> with all the history of changes to
   * the state of this home study, returned in ascending date/time order (i.e.
   * <i>earliest first</i>)
   *
   * @return The immutable list with all the history of changes to the state of
   * this home study.
   */
  public List<HomeStudyStatusHistory> getStatusHistory();

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the home study events functionality surrounding the cancel
   * method.
   */
  public interface HomeStudyCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.homestudy.impl.HomeStudy#cancel}
     *
     * @param homeStudy
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(HomeStudyAccessor homeStudy, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.homestudy.impl.HomeStudy#cancel}
     *
     * @param homeStudy
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(HomeStudyAccessor homeStudy, Integer versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the home study events functionality surrounding the submit
   * method.
   */
  public interface HomeStudySubmitEvents {

    /**
     * Event interface invoked before the main body of the submit method.
     * {@linkplain curam.homestudy.impl.HomeStudy#submit}
     *
     * @param homeStudy
     * The object instance as it was before the main body of the submit
     * method.
     * @param versionNo
     * The parameter as passed to the submit method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preSubmit(HomeStudyAccessor homeStudy, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the submit method.
     * {@linkplain curam.homestudy.impl.HomeStudy#submit}
     *
     * @param homeStudy
     * The object instance as it was after the main body of the submit
     * method.
     * @param versionNo
     * The parameter as passed to the submit method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postSubmit(HomeStudyAccessor homeStudy, Integer versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the home study events functionality surrounding the reject
   * method.
   */
  public interface HomeStudyRejectEvents {

    /**
     * Event interface invoked before the main body of the reject method.
     * {@linkplain curam.homestudy.impl.HomeStudy#reject}
     *
     * @param homeStudy
     * The object instance as it was before the main body of the reject
     * method.
     * @param versionNo
     * The parameter as passed to the reject method.
     * @param returnedReason
     * The parameter as passed to the reject method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preReject(HomeStudyAccessor homeStudy, Integer versionNo,
      HomeStudyReturnReasonEntry returnedReason)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the reject method.
     * {@linkplain curam.homestudy.impl.HomeStudy#reject}
     *
     * @param homeStudy
     * The object instance as it was after the main body of the reject
     * method.
     * @param versionNo
     * The parameter as passed to the reject method.
     * @param returnedReason
     * The parameter as passed to the reject method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postReject(HomeStudyAccessor homeStudy, Integer versionNo,
      HomeStudyReturnReasonEntry returnedReason)
      throws InformationalException;
  }


  /**
   * Interface to the home study events functionality surrounding the approve
   * method.
   */
  public interface HomeStudyApproveEvents {

    /**
     * Event interface invoked before the main body of the approve method.
     * {@linkplain curam.homestudy.impl.HomeStudy#approve}
     *
     * @param homeStudy
     * The object instance as it was before the main body of the
     * approve method.
     * @param versionNo
     * The parameter as passed to the approve method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preApprove(HomeStudyAccessor homeStudy, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the approve method.
     * {@linkplain curam.homestudy.impl.HomeStudy#approve}
     *
     * @param homeStudy
     * The object instance as it was after the main body of the approve
     * method.
     * @param versionNo
     * The parameter as passed to the approve method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postApprove(HomeStudyAccessor homeStudy, Integer versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the home study events functionality surrounding the insert
   * method.
   */
  public interface HomeStudyInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.homestudy.impl.HomeStudy#insert}
     *
     * @param homeStudy
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(HomeStudyAccessor homeStudy)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.homestudy.impl.HomeStudy#insert}
     *
     * @param homeStudy
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(HomeStudyAccessor homeStudy)
      throws InformationalException;
  }


  /**
   * Interface to the home study events functionality surrounding the modify
   * method.
   */
  public interface HomeStudyModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.homestudy.impl.HomeStudy#modify}
     *
     * @param homeStudy
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(HomeStudyAccessor homeStudy, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.homestudy.impl.HomeStudy#modify}
     *
     * @param homeStudy
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(HomeStudyAccessor homeStudy, Integer versionNo)
      throws InformationalException;
  }
  // END, CR00144381
}
