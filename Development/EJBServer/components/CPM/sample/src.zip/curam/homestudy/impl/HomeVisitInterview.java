/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.DateRanged;
import curam.util.type.DateTime;


/**
 * An interview conducted as part of a home visit.
 *
 * <p>
 * <i>For example a couple who wish to provide foster care services are
 * interviewed in their home by the resource manager as part of a home visit</i>.
 */
@ImplementedBy(HomeVisitInterviewImpl.class)
public interface HomeVisitInterview extends HomeVisitInterviewAccessor,
    Insertable, LogicallyDeleteable, OptimisticLockModifiable, DateRanged {

  /**
   * Gets the home study home visit for this home study.
   *
   * @return the home study home visit for this home study
   */
  public HomeStudyHomeVisit getHomeStudyHomeVisit();

  /**
   * Gets all the interview attendees for this home visit interview.
   *
   * @return the interview attendees for this home visit interview
   */
  public Set<InterviewAttendee> getInterviewAttendees();

  /**
   * Sets the type to set the interview to.
   *
   * @param value
   * the type to set the interview to
   */
  public void setType(final HomeVisitInterviewTypeEntry value);

  /**
   * Sets the start <code>DateTime</code> for this interview.
   *
   * @param value
   * the start <code>DateTime</code> to set
   */
  public void setStartDateTime(DateTime value);

  /**
   * Sets the end <code>DateTime</code> for this interview.
   *
   * @param value
   * the end <code>DateTime</code> to set
   */
  public void setEndDateTime(DateTime value);

  /**
   * Sets the home visit method for this interview.
   *
   * @param value
   * the home visit method to set
   */
  public void setMethod(HomeVisitMethodEntry value);

  /**
   * Sets the home visit location for this interview.
   *
   * @param value
   * the home visit location to set
   */
  public void setLocation(HomeVisitInterviewlocationEntry value);

  /**
   * Sets the narrative for this interview.
   *
   * @param value
   * the narrative text.
   *
   * @see curam.homestudy.impl.HomeVisitInterviewImpl#setNarrative(String) The
   * default implementation -
   * curam.homestudy.impl.HomeVisitInterviewImpl#setNarrative(String)
   */
  public void setNarrative(String value);

  /**
   * Sets the record status for this interview.
   *
   * @param value
   * the record status to set
   */
  public void setRecordStatus(RECORDSTATUSEntry value);

  /**
   * Sets the home study home visit for this interview.
   *
   * @param homeStudyHomeVisit
   * the record status to set
   */
  public void setHomeStudyHomeVisit(HomeStudyHomeVisit homeStudyHomeVisit);

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the home visit interview events functionality surrounding the
   * insert method.
   */
  public interface HomeVisitInterviewInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.homestudy.impl.HomeVisitInterview#insert}
     *
     * @param homeVisitInterview
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(HomeVisitInterviewAccessor homeVisitInterview)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.homestudy.impl.HomeVisitInterview#insert}
     *
     * @param homeVisitInterview
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(HomeVisitInterviewAccessor homeVisitInterview)
      throws InformationalException;
  }


  /**
   * Interface to the home visit interview events functionality surrounding the
   * cancel method.
   */
  public interface HomeVisitInterviewCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.homestudy.impl.HomeVisitInterview#cancel}
     *
     * @param homeVisitInterview
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(HomeVisitInterviewAccessor homeVisitInterview,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.homestudy.impl.HomeVisitInterview#cancel}
     *
     * @param homeVisitInterview
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(HomeVisitInterviewAccessor homeVisitInterview,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the home visit interview events functionality surrounding the
   * modify method.
   */
  public interface HomeVisitInterviewModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.homestudy.impl.HomeVisitInterview#modify}
     *
     * @param homeVisitInterview
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(HomeVisitInterviewAccessor homeVisitInterview,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.homestudy.impl.HomeVisitInterview#modify}
     *
     * @param homeVisitInterview
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(HomeVisitInterviewAccessor homeVisitInterview,
      Integer versionNo) throws InformationalException;
  }
  // END, CR00144381

}
