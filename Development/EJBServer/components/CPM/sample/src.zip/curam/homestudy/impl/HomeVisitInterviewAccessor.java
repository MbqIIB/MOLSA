/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Set;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.util.persistence.StandardEntity;
import curam.util.type.DateTime;


/**
 * Accessor interface for HomeVisitInterview
 * {@linkplain curam.homestudy.impl.HomeVisitInterview}.
 *
 */
public interface HomeVisitInterviewAccessor extends StandardEntity {

  /**
   * Gets the home visit interview type.
   *
   * @return the home visit interview type
   */
  public HomeVisitInterviewTypeEntry getType();

  /**
   * Gets the start date and time for the interview.
   *
   * @return the start date and time for the interview
   */
  public DateTime getStartDateTime();

  /**
   * Gets the end date and time for the interview.
   *
   * @return the end date and time for the interview
   */
  public DateTime getEndDateTime();

  /**
   * Gets the narrative description for the interview.
   *
   * @return the narrative description for the interview
   */
  public String getNarrative();

  /**
   * Gets the method for the interview.
   *
   * @return the method for the interview
   */
  public HomeVisitMethodEntry getMethod();

  /**
   * Gets the location for the interview.
   *
   * @return the location for the interview
   */
  public HomeVisitInterviewlocationEntry getLocation();

  /**
   * Gets the record status for this home study.
   *
   * @return the record status of the Home Visit Interview
   */
  public RECORDSTATUSEntry getRecordStatus();

  /**
   * Gets the home study home visit for this home study.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return the home study home visit for this home study
   */
  public HomeStudyHomeVisitAccessor getHomeStudyHomeVisit();

  /**
   * Gets all the immutable interview attendees for this home visit interview.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable interview attendees for this home visit interview
   */
  public Set<? extends InterviewAttendeeAccessor> getInterviewAttendees();

}
