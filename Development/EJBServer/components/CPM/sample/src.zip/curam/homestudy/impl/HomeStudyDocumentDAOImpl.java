/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Set;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.sl.entity.struct.DocumentTemplateDtls;
import curam.core.sl.entity.struct.DocumentTemplateDtlsList;
import curam.cpm.sl.entity.impl.HomeStudyDocumentAdapter;
import curam.cpm.sl.entity.struct.HomeStudyDocumentDtls;
import curam.cpm.sl.struct.HomeStudyDocumentTemplateCategoryKey;
import curam.cpm.sl.struct.HomeStudyDocumentTemplateDetails;
import curam.cpm.sl.struct.HomeStudyDocumentTemplateList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import curam.util.persistence.helper.LifecycleHelper;


/**
 * Home Study Document multi-record Data Access implementation.
 */
// BEGIN, CR00183213, SS
public class HomeStudyDocumentDAOImpl extends StandardDAOImpl<HomeStudyDocument, HomeStudyDocumentDtls> implements
  HomeStudyDocumentDAO {
  // END, CR00183213
  protected static final HomeStudyDocumentAdapter adapter = new HomeStudyDocumentAdapter();

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected HomeStudyDocumentDAOImpl() {
    // END, CR00183213
    super(adapter, HomeStudyDocument.class);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<HomeStudyDocument> searchByHomeStudy(final HomeStudy homeStudy) {

    return newSet(adapter.searchByHomeStudy(homeStudy.getID()));

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<HomeStudyDocument> searchActiveByHomeStudy(final HomeStudy homeStudy) {

    Set<HomeStudyDocument> homeStudyDocuments = newSet(
      adapter.searchByHomeStudy(homeStudy.getID()));

    return LifecycleHelper.filter(homeStudyDocuments, RECORDSTATUSEntry.NORMAL);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public HomeStudyDocumentTemplateList getDocumentTemplateList(
    HomeStudyDocumentTemplateCategoryKey key)
    throws AppException, InformationalException {

    // return structure
    HomeStudyDocumentTemplateList homeStudyDocumentTemplateList = new HomeStudyDocumentTemplateList();

    // Home study document template details
    HomeStudyDocumentTemplateDetails homeStudyDocumentTemplateDetails;

    // Document template manipulation variables
    curam.core.sl.entity.intf.DocumentTemplate documentTemplateObj = curam.core.sl.entity.fact.DocumentTemplateFactory.newInstance();

    // Document template list
    DocumentTemplateDtlsList documentTemplateDtlsList = documentTemplateObj.readAll();
    DocumentTemplateDtls documentTemplateDtls;

    for (int i = 0, s = documentTemplateDtlsList.dtls.size(); i < s; i++) {

      documentTemplateDtls = documentTemplateDtlsList.dtls.item(i);

      if ((documentTemplateDtls.categoryCode.equals(key.documentCategoryCode))
        && (documentTemplateDtls.recordStatus.equals(key.recordStatus))) {

        homeStudyDocumentTemplateDetails = new HomeStudyDocumentTemplateDetails();

        homeStudyDocumentTemplateDetails.documentTemplateID = documentTemplateDtls.documentTemplateID;

        homeStudyDocumentTemplateDetails.documentTemplateName = documentTemplateDtls.name;

        homeStudyDocumentTemplateList.listDtls.addRef(
          homeStudyDocumentTemplateDetails);

      }

    }

    return homeStudyDocumentTemplateList;

  }

}
