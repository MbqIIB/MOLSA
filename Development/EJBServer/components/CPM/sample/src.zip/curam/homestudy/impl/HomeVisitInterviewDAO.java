/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.homestudy.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.StandardDAO;


/**
 * Data access for
 * {@linkplain curam.homestudy.impl.HomeVisitInterview}.
 */
@ImplementedBy(HomeVisitInterviewDAOImpl.class)
public interface HomeVisitInterviewDAO extends StandardDAO<HomeVisitInterview> {

  // ___________________________________________________________________________
  /**
   * Only returns ACTIVE Home Visit Interview Records
   *
   * @param parent
   * the Home Study Home Visit that the listed home visit interviews
   * should apply to.
   *
   * @return the Home Visit Interviews which have the home study home visit key
   * specified applies to.
   */
  public Set<HomeVisitInterview> searchActiveByHomeStudyHomeVisit(HomeStudyHomeVisit parent);

  // ___________________________________________________________________________
  /**
   * Returns ALL Home Visit Interview Records
   *
   * @param parent
   * the Home Study Home Visit that the listed home visit interviews
   * should apply to.
   *
   * @return the Home Visit Interviews which have the home study home visit key
   * specified applies to.
   */
  public Set<HomeVisitInterview> searchByHomeStudyHomeVisit(HomeStudyHomeVisit parent);
}
