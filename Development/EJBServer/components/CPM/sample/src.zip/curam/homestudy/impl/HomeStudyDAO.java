/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.provider.impl.Provider;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;
import curam.util.type.Date;


/**
 * Data access for <code>HomeStudy</code>.
 *
 * @see curam.homestudy.impl.HomeStudy
 */
@ImplementedBy(HomeStudyDAOImpl.class)
public interface HomeStudyDAO extends StandardDAO<HomeStudy> {

  /**
   * Searches the home studies for those for a particular {@linkplain 
   * curam.provider.impl.Provider}.
   *
   * @param provider the provider for which we wish to search for home studies.
   * @return the set of all home studies which match the specified criteria.
   * @see HomeStudyDAO#searchActiveByProvider(Provider)
   */
  public Set<HomeStudy> searchByProvider(Provider provider);

  /**
   * Searches the home studies for those for a particular {@linkplain 
   * curam.provider.impl.Provider}.
   * <p>
   * Only returns home studies who are not CANCELLED.
   *
   * @param provider the provider for which we wish to search for home studies.
   * @return the set of all home studies which match the specified criteria.
   * @see HomeStudyDAO#searchByProvider(Provider)
   */
  public Set<HomeStudy> searchActiveByProvider(Provider provider);
  
  // BEGIN, CR00226380, GP
  /**
   * Searches all the home studies which has date initiated within the specified
   * date range for a given status.
   *
   * @param startDate
   * Start date of the date initiated date range.
   * @param endDate
   * End date of the date initiated date range.
   * @param homeStudyStatus
   * Status of the home study.
   *
   * @return A set of home studies which have date initiated within the
   * specified date range for a given date range.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public Set<HomeStudy> searchByDateInitiatedRangeAndStatus(Date startDate,
    Date endDate, HomeStudyStatusEntry homeStudyStatus) throws AppException,
      InformationalException;
  // END, CR00226380

}
