/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.List;
import java.util.Set;

import curam.provider.impl.ProviderAccessor;
import curam.util.persistence.StandardEntity;
import curam.util.type.Date;


/**
 * Accessor interface for Home Study 
 * {@linkplain curam.homestudy.impl.HomeStudy}.
 *
 */
public interface HomeStudyAccessor extends StandardEntity {
  
  /**
   * Gets the provider for this home study.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database. 
   *
   * @return The provider for the home study.
   */
  public ProviderAccessor getProvider();
  
  /**
   * Gets the home study type.
   * <p>
   * The different home study types are:
   * <ul>
   * <li>{@link curam.homestudy.impl.HomeStudyTypeEntry#ADOPTIVEHOME}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyTypeEntry#CHILDCARE}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyTypeEntry#DAYCARE}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyTypeEntry#FOSTERHOME}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyTypeEntry#NOT_SPECIFIED}</li>
   * </ul>
   *
   * @return The home study type.
   */
  public HomeStudyTypeEntry getHomeStudyType();

  /**
   * Gets the home study purpose.
   * <p>
   * The different home study purpose entries are:
   * <ul>
   * <li>{@link curam.homestudy.impl.HomeStudyPurposeEntry#CHILDSPECIFICPLACEMENT}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyPurposeEntry#INITIAL}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyPurposeEntry#NOT_SPECIFIED}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyPurposeEntry#REEVALUATION}</li>
   * </ul>
   *
   * @return The home study purpose.
   */
  public HomeStudyPurposeEntry getPurpose();

  /**
   * Gets the home study date initiated.
   *
   * @return The date initiated for this home study.
   */
  public Date getDateInitiated();

  /**
   * Gets the home study reevaluation date.
   *
   * @return The reevaluation date for this home study.
   */
  public Date getReevaluationDate();

  /**
   * Gets the home study final recommendation.
   * <p>
   * The different values for <code>HomeStudyFinalRecommendtaionEntry</code>
   * are:
   * <ul>
   * <li>{@link curam.homestudy.impl.HomeStudyFinalRecommendationEntry#NOT_SPECIFIED}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyFinalRecommendationEntry#RECOMMENDCERTIFICATION}</li>
   * <li>{@link curam.homestudy.impl.HomeStudyFinalRecommendationEntry#RECOMMENDDENIALOFCERTIFICATION}</li>
   * </ul>
   *
   * @return The final recommendation.
   */
  public HomeStudyFinalRecommendationEntry getFinalRecommendation();

  /**
   * Gets the home study support for recommendation.
   *
   * @return The support for recommendation.
   */
  public String getSupportForRecommendation();

  /**
   * Gets the home study assessor.
   *
   * @return The assessor user name.
   */
  public String getAssessor();
  
  /**
   * Gets the immutable <code>Set</code> of all the home study home visits for
   * this home study.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of all the home study home visits for this home
   * study.
   */
  public Set<? extends HomeStudyHomeVisitAccessor> getHomeStudyHomeVisits();

  /**
   * Gets the immutable <code>Set</code> of all the home study documents for
   * this home study.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of all the home study documents for this home
   * study.
   */
  public Set<? extends HomeStudyDocumentAccessor> getHomeStudyDocuments();
  
  /**
   * Gets the immutable <code>Set</code> of all the home study assessments for
   * this home study.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable set of all the home study assessments for this home
   * study.
   */
  public Set<? extends HomeStudyAssessmentAccessor> getHomeStudyAssessments();
  
  /**
   * Gets the immutable <code>List</code> with all the history of changes to
   * the state of this home study, returned in ascending date/time order (i.e.
   * <i>earliest first</i>)
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable list with all the history of changes to the state of
   * this home study
   */
  public List<? extends HomeStudyStatusHistoryAccessor> getStatusHistory();
  
}
