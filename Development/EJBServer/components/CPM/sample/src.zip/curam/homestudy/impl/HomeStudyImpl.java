/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.impl.HomeStudyAdapter;
import curam.cpm.sl.entity.struct.HomeStudyDtls;
import curam.events.HOMESTUDY;
import curam.events.PROVIDERMANAGEMENT;
import curam.message.impl.HOMESTUDYExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderSecurity;
import curam.provider.impl.ProviderStatusEntry;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.CodetableState;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.persistence.helper.State;
import curam.util.persistence.helper.Transition;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.StringHelper;


/**
 * Standard implementation of <code>HomeStudy</code>.
 * <p>
 * A study conducted on a provider to ascertain that the living conditions and
 * environment of the home are suitable for the care of the agency's clients.
 * <p>
 * <i>An example of a type of provider for which a home study will be conducted
 * is a foster care home</i>.
 *
 * @see curam.homestudy.impl.HomeStudy
 */
// BEGIN, CR00183213, SS
public class HomeStudyImpl extends SingleTableEntityImpl<HomeStudyDtls>
  implements HomeStudy {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for submit events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudySubmitEvents> submitEventDispatcherFactory;

  /**
   * Event dispatcher for reject events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyRejectEvents> rejectEventDispatcherFactory;

  /**
   * Event dispatcher for approve events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyApproveEvents> approveEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected ProviderSecurity providerSecurity;

  @Inject
  protected HomeStudyStatusHistoryDAO homeStudyStatusHistoryDAO;

  @Inject
  protected HomeStudyStatusHistoryCreatorDAO homeStudyStatusHistoryCreatorDAO;

  @Inject
  protected HomeStudyAssessmentDAO homeStudyAssessmentDAO;

  @Inject
  protected HomeStudyHomeVisitDAO homeVisitDAO;

  @Inject
  protected HomeStudyDocumentDAO homeStudyDocumentDAO;

  // Process Definition Table name (PDT)

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected HomeStudyImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public Date getDateInitiated() {
    return getDtls().dateInitiated;
  }

  /**
   * {@inheritDoc}
   */
  public HomeStudyFinalRecommendationEntry getFinalRecommendation() {
    return HomeStudyFinalRecommendationEntry.get(getDtls().finalRecommendation);
  }

  /**
   * {@inheritDoc}
   */
  public HomeStudyTypeEntry getHomeStudyType() {
    return HomeStudyTypeEntry.get(getDtls().homeStudyType);
  }

  /**
   * {@inheritDoc}
   */
  public HomeStudyPurposeEntry getPurpose() {
    return HomeStudyPurposeEntry.get(getDtls().purpose);
  }

  /**
   * {@inheritDoc}
   */
  public Date getReevaluationDate() {
    return getDtls().reevaluationDate;
  }

  /**
   * {@inheritDoc}
   */
  public String getSupportForRecommendation() {
    return getDtls().supportForRecommendation;
  }

  /**
   * {@inheritDoc}
   */
  public String getAssessor() {
    return getDtls().assessorName;
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  /**
   * {@inheritDoc}
   */
  public Provider getProvider() {
    final long myProviderID = getDtls().providerConcernRoleID;

    if (myProviderID == 0) {
      return null;
    } else {
      return providerDAO.get(myProviderID);
    }
  }

  /**
   * {@inheritDoc}
   */
  public Set<HomeStudyHomeVisit> getHomeStudyHomeVisits() {
    return Collections.unmodifiableSet(homeVisitDAO.searchByHomeStudy(this));
  }

  /**
   * {@inheritDoc}
   */
  public Set<HomeStudyDocument> getHomeStudyDocuments() {
    return Collections.unmodifiableSet(
      homeStudyDocumentDAO.searchByHomeStudy(this));
  }

  /**
   * {@inheritDoc}
   */
  public Set<HomeStudyAssessment> getHomeStudyAssessments() {
    return Collections.unmodifiableSet(
      homeStudyAssessmentDAO.searchByHomeStudy(this));
  }

  /**
   * {@inheritDoc}
   */
  public HomeStudyStatusEntry getLifecycleState() {
    return HomeStudyStatusEntry.get(getDtls().status);
  }

  /**
   * {@inheritDoc}
   */
  public void setDateInitiated(Date value) {
    getDtls().dateInitiated = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setFinalRecommendation(HomeStudyFinalRecommendationEntry value) {
    getDtls().finalRecommendation = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setHomeStudyType(HomeStudyTypeEntry value) {
    getDtls().homeStudyType = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setPurpose(HomeStudyPurposeEntry value) {
    getDtls().purpose = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setReevaluationDate(Date value) {
    getDtls().reevaluationDate = value;
  }

  /**
   * Sets the home study support for recommendation.
   *
   * @param value
   * The support for recommendation.
   *
   * @throws InformationalException
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_FV_SUPPORT_FOR_RECOMMENDATION_LONG} -
   * If the length of the support for recommendation is greater than
   * maximum length specified.
   */
  public void setSupportForRecommendation(String value) {
    getDtls().supportForRecommendation = StringHelper.trim(value);

    // field validation
    if (getSupportForRecommendation().length()
      > HomeStudyAdapter.kMaxLength_supportForRecommendation) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_FV_SUPPORT_FOR_RECOMMENDATION_LONG(
          HomeStudyAdapter.kMaxLength_supportForRecommendation),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * Sets the home study assessor.
   *
   * @param value
   * The assessor user name.
   *
   * @throws InformationalException
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_FV_ASSESSOR_NAME_LONG}
   * If the assessor name is greater than the maximum length.
   */
  public void setAssessor(String value) {
    getDtls().assessorName = StringHelper.trim(value);

    // field validation
    if (getAssessor().length() > HomeStudyAdapter.kMaxLength_assessorName) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_FV_ASSESSOR_NAME_LONG(
          HomeStudyAdapter.kMaxLength_assessorName),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * Sets the comments.
   *
   * @param value
   * the comments.
   *
   * @throws InformationalException
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_FV_COMMENTS_LONG} -
   * If the length of comments is greater than maximum length
   * specified.
   */
  public void setComments(String value) {
    getDtls().comments = StringHelper.trim(value);

    // field validation
    if (getComments().length() > HomeStudyAdapter.kMaxLength_comments) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_FV_COMMENTS_LONG(
          HomeStudyAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setProvider(Provider value) {
    getDtls().providerConcernRoleID = value.getID();
  }

  /**
   * Sets the default values for the home study.
   * <p>
   * Moreover it sets the home study status to
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#OPEN}.
   */
  public void setNewInstanceDefaults() {
    // Set initial state
    setStatus(HomeStudyStatusEntry.OPEN);
  }

  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_TYPE_MANDATORY} - If the
   * home study type is not entered. </li>
   * <li> {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_PURPOSE_MANDATORY} - If
   * the home study purpose is not entered. </li>
   * <li> {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_DATE_INITIATED_MANDATORY} -
   * If the home study Date Initiated is not entered. </li>
   * <li> {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_STATUS_MANDATORY} - If
   * the home study status is not entered. </li>
   * <li> {@link curam.message.HOMESTUDY#ERR_ASSESSOR_MANDATORY} - If the home
   * study assessor is not entered. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {
    // Mandatory fields:

    // Home Study Type
    if (getHomeStudyType().equals(HomeStudyTypeEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_TYPE_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // Purpose
    if (getPurpose().equals(HomeStudyPurposeEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_PURPOSE_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // Date Initiated
    if (getDateInitiated().isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_DATE_INITIATED_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // Status
    if (getLifecycleState().equals(HomeStudyStatusEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_STATUS_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    // Assessor
    if (StringHelper.isEmpty(getAssessor())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_ASSESSOR_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  /**
   * Validates that all the field values held are valid with respect to each
   * other.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_DATE_INITIATED_LATER_THAN_REEVALUATION_DATE} -
   * If the Date Initiated is after the Reevaluation Date. </li>
   * <li>
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_FINAL_RECOMMENDATION_SUPPORT_FOR_RECOMMENDATION_NOT_SPECIFIED} -
   * If the support for recommendation is not specified if final recommendation
   * is specified. </li>
   * </ul>
   */
  public void crossFieldValidation() {

    // Date Initiated must be earlier than Reevaluation Date
    // Reevaluation Date must be later than Date Initiated
    if (!getReevaluationDate().isZero()
      && getDateInitiated().after(getReevaluationDate())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_DATE_INITIATED_LATER_THAN_REEVALUATION_DATE(
          getReevaluationDate(), getDateInitiated()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Support for Recommendation must be specified if Final Recommendation
    // is specified
    if (!getFinalRecommendation().equals(
      HomeStudyFinalRecommendationEntry.NOT_SPECIFIED)
        && StringHelper.isEmpty(getSupportForRecommendation())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_FINAL_RECOMMENDATION_SUPPORT_FOR_RECOMMENDATION_NOT_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  /**
   * Validates that changes made to home study entity on the database are
   * consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_DATE_INITIATED_LATER_ASSESSMENT_DATE_COMPLETED} -
   * If the Date Initiated is after the Date Completed of the home study
   * assessments. </li>
   * </ul>
   */
  public void crossEntityValidation() {
    // Date Initiated may not be later than the Date Completed of the Home
    // Study Assessments contained within it.
    Set<HomeStudyAssessment> unModifiableMyAssessments = getHomeStudyAssessments();
    Set<HomeStudyAssessment> myAssessments = new HashSet<HomeStudyAssessment>();

    myAssessments.addAll(unModifiableMyAssessments);

    if (myAssessments.size() > 0) {
      Date earliestDateCompleted = new Date();

      // loop through all assessments to find earliest non-zero date
      for (HomeStudyAssessment myAssessment: myAssessments) {
        Date thisDateCompleted = myAssessment.getDateCompleted();

        if (!thisDateCompleted.isZero()
          && (thisDateCompleted.before(earliestDateCompleted))
            || earliestDateCompleted.isZero()) {
          earliestDateCompleted = thisDateCompleted;
        }
      }

      if (!earliestDateCompleted.isZero()
        && getDateInitiated().after(earliestDateCompleted)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_DATE_INITIATED_LATER_ASSESSMENT_DATE_COMPLETED(
            earliestDateCompleted),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  }

  /**
   * Performs the provider security check and inserts the home study and home
   * study status history record.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider status is closed.
   */
  @Override
  public void insert() throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre insert home study event.
    insertEventDispatcherFactory.get(HomeStudyInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 14);
      ValidationHelper.failIfErrorsExist();
    }

    // Call insert
    super.insert();

    // create a status history entry
    final HomeStudyStatusHistoryCreator homeStudStatusHistory = createHistoryEntry();

    homeStudStatusHistory.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert home study event.
    insertEventDispatcherFactory.get(HomeStudyInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * Performs the provider security check and modifies the home study record.
   *
   * @param versionNo
   * The version number of the record which has to be updated.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider status is closed.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_NOT_EDITED} - If the
   * home study cannot be modified.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre modify home study event.
    modifyEventDispatcherFactory.get(HomeStudyModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 16);
      ValidationHelper.failIfErrorsExist();
    }

    // check if we are allowed modify in this state
    if (!getCurrentState().isModifyAllowed()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_EDITED(
          getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // call modify
    super.modify(versionNo);

    // no status history is needed on modify

    // BEGIN, CR00235789, AK
    // Raise the post modify home study event.
    modifyEventDispatcherFactory.get(HomeStudyModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * Checks the provider security and logically deletes the home study. There is
   * a transition from {@link curam.homestudy.impl.HomeStudyStatusEntry#OPEN} to
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#CANCELLED}. All the home
   * study assessments, home study visits and home study documents are canceled.
   * The change in the state is recorded in the home study change status
   * history.
   *
   * @param versionNo
   * The version number of the <code>HomeStudy</code> being canceled.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   */
  public void cancel(final Integer versionNo) throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre cancel home study event.
    cancelEventDispatcherFactory.get(HomeStudyCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    // cancel this Home Study
    // change the state to Canceled
    transitionTo(CANCELLED, versionNo);

    // now cancel all of the children
    // cancel all assessments
    Set<HomeStudyAssessment> unModifiableAssessments = getHomeStudyAssessments();
    Set<HomeStudyAssessment> assessments = new HashSet<HomeStudyAssessment>();

    assessments.addAll(unModifiableAssessments);

    for (HomeStudyAssessment assessment: assessments) {
      if (!assessment.getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {
        assessment.cancel(assessment.getVersionNo());
      }
    }

    // cancel all visits
    Set<HomeStudyHomeVisit> unModifiableVisits = getHomeStudyHomeVisits();
    Set<HomeStudyHomeVisit> visits = new HashSet<HomeStudyHomeVisit>();

    visits.addAll(unModifiableVisits);

    for (HomeStudyHomeVisit visit: visits) {
      if (!visit.getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {
        visit.cancel(visit.getVersionNo());
      }
    }

    // cancel all documents
    Set<HomeStudyDocument> unModifiableDocuments = getHomeStudyDocuments();
    Set<HomeStudyDocument> documents = new HashSet<HomeStudyDocument>();

    documents.addAll(unModifiableDocuments);

    for (HomeStudyDocument document: documents) {
      if (!document.getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {
        document.cancel(document.getVersionNo());
      }
    }

    // create a status history entry
    final HomeStudyStatusHistoryCreator homeStudStatusHistory = createHistoryEntry();

    homeStudStatusHistory.insert();

    // BEGIN, CR00235789, AK
    // Raise the post cancel home study event.
    cancelEventDispatcherFactory.get(HomeStudyCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Performs the security check for the logged in user who is assigned the
   * responsibility of approving/rejecting the home study recommendation and
   * then approves this home study object.There is a transition from
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#SUBMITTED} to
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#APPROVED}.The change in
   * the state is recorded in the home study change status history and raises an
   * workflow event.
   *
   * @param versionNo
   * The version number of the <code>HomeStudy</code> being approved.
   *
   * @throws InformationalException
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_USER_NOT_SUPERVISOR} -
   * If the user is not supervisor of the provider.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   */
  public void approve(Integer versionNo) throws InformationalException {

    // Only the user who has been assigned the responsibility of approving the
    // home study recommendation may approve the home study recommendation.
    // perform the security check
    String currentUser = TransactionInfo.getProgramUser();

    if (!providerSecurity.isUserProviderSupervisor(getProvider(), currentUser)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_USER_NOT_SUPERVISOR(currentUser),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Don't continue if the security check does not pass
    ValidationHelper.failIfErrorsExist();

    // BEGIN, CR00235789, AK
    // Raise the pre approve home study event.
    approveEventDispatcherFactory.get(HomeStudyApproveEvents.class).preApprove(
      this, versionNo);
    // END, CR00235789

    // change the state to Approved
    transitionTo(APPROVED, versionNo);

    // create a status history entry
    final HomeStudyStatusHistoryCreator homeStudStatusHistory = createHistoryEntry();

    homeStudStatusHistory.insert();

    // Notification to the resource manager
    // Raise event to restart workflow
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = PROVIDERMANAGEMENT.HOMESTUDYAPPROVED;
    event.primaryEventData = getID(); // homeStudyID

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post approve home study event.
    approveEventDispatcherFactory.get(HomeStudyApproveEvents.class).postApprove(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Performs the security check for the logged in user who is assigned the
   * responsibility of approving/rejecting the home study recommendation and
   * then rejects this home study object.There is a transition from
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#SUBMITTED} to
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#RETURNED}.The change in
   * the state is recorded in the home study change status history and raises an
   * workflow event.
   *
   * @param versionNo
   * The version number of the <code>HomeStudy</code> being rejected.
   * @param returnedReason
   * The reason the home study has been returned and not approved.
   *
   * @throws InformationalException
   * {@link curam.message.HOMESTUDY#ERR_RETURNED_REASON_MANDATORY} -
   * If the reason for rejection is not entered.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_USER_NOT_SUPERVISOR} -
   * If the user is not supervisor of the provider.
   */
  public void reject(Integer versionNo,
    HomeStudyReturnReasonEntry returnedReason) throws InformationalException {

    // Only the user who has been assigned the responsibility of approving the
    // home study recommendation may reject the home study recommendation.
    // perform the security check
    String currentUser = TransactionInfo.getProgramUser();

    if (!providerSecurity.isUserProviderSupervisor(getProvider(), currentUser)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_USER_NOT_SUPERVISOR(currentUser),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    // Don't continue if the security check does not pass
    ValidationHelper.failIfErrorsExist();

    // BEGIN, CR00235789, AK
    // Raise the pre reject home study event.
    rejectEventDispatcherFactory.get(HomeStudyRejectEvents.class).preReject(
      this, versionNo, returnedReason);
    // END, CR00235789

    // check the returned reason has been set
    if (returnedReason.equals(HomeStudyReturnReasonEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_RETURNED_REASON_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // change the state to Returned
    transitionTo(RETURNED, versionNo);

    // create a status history entry
    final HomeStudyStatusHistoryCreator homeStudyStatusHistory = createHistoryEntry();

    homeStudyStatusHistory.setReturnedReason(returnedReason);
    homeStudyStatusHistory.insert();

    // Notification to the resource manager
    // Raise event to restart workflow
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = PROVIDERMANAGEMENT.HOMESTUDYRETURNED;
    event.primaryEventData = getID(); // homeStudyID

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post reject home study event.
    rejectEventDispatcherFactory.get(HomeStudyRejectEvents.class).postReject(
      this, versionNo, returnedReason);
    // END, CR00235789
  }

  // BEGIN, CR00207501, NBR
  /**
   * Submits this home study object. There is a transition from
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#OPEN} to
   * {@link curam.homestudy.impl.HomeStudyStatusEntry#SUBMITTED}. The change in
   * the state is recorded in the home study change status history. The Home
   * Study Approval workflow is enacted and an workflow event is raised.
   *
   * @param versionNo
   * The version number of the <code>HomeStudy</code> being
   * submitted.
   *
   * @throws InformationalException
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_NOT_SUBMITTED_NO_FINAL_RECOMMENDATION_OR_SUPPORT_FOR_RECOMMENDATION} -
   * If there are no final recommendation or support for
   * recommendation.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_NOT_SUBMITTED_ALREADY_DELETED} -
   * If the status of the home study is canceled.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_NOT_SUBMITTED_NO_ASSESSMENTS} -
   * If there are no assessments.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDY#ERR_HOMESTUDY_NOT_SUBMITTED_NO_INTERVIEWS} -
   * If there are no interviews.
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   */
  // END, CR00207501
  public void submit(Integer versionNo) throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre submit home study event.
    submitEventDispatcherFactory.get(HomeStudySubmitEvents.class).preSubmit(
      this, versionNo);
    // END, CR00235789

    // perform submit validations
    submitValidations();

    // change the state to Submitted
    transitionTo(SUBMITTED, versionNo);

    // create a status history entry
    final HomeStudyStatusHistoryCreator homeStudStatusHistory = createHistoryEntry();

    homeStudStatusHistory.insert();

    // BEGIN, CR00171487, AK
    final Event homeStudyApproveEvent = new Event();

    homeStudyApproveEvent.eventKey = HOMESTUDY.HOMESTUDY_APPROVE;
    homeStudyApproveEvent.primaryEventData = getID();
    homeStudyApproveEvent.secondaryEventData = getProvider().getID();

    try {
      EventService.raiseEvent(homeStudyApproveEvent);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
    // END, CR00171487, AK

    // raise post-submit event
    final Event event = new Event();

    event.eventKey = HOMESTUDY.HOMESTUDY_SUBMITTED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the post submit home study event.
    submitEventDispatcherFactory.get(HomeStudySubmitEvents.class).postSubmit(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * {@inheritDoc}
   */
  public List<HomeStudyStatusHistory> getStatusHistory() {
    return Collections.unmodifiableList(
      homeStudyStatusHistoryDAO.searchBy(this));
  }

  // BEGIN, CR00177241, PM
  protected HomeStudyStatusHistoryCreator createHistoryEntry() {
    // END, CR00177241
    final HomeStudyStatusHistoryCreator homeStudyStatusHistory = homeStudyStatusHistoryCreatorDAO.newInstance();

    homeStudyStatusHistory.setHomeStudy(this);

    return homeStudyStatusHistory;
  }

  /**
   * Sets the home study support for recommendation private method as this
   * is set internally and is not available from the public interface.
   *
   * @param value the support for recommendation
   * @see curam.homestudy.HomeStudyStatusEntry
   */
  // BEGIN, CR00177241, PM
  protected void setStatus(HomeStudyStatusEntry value) {
    // END, CR00177241
    getDtls().status = value.getCode();
  }

  /**
   * Changes the home study status to a new one.
   *
   * @param newState  the new home study status to set
   * @param versionNo the version number of the <code>HomeStudy</code> being
   * changed
   * @throws InformationalException if any application validation errors are
   * found during the operation; e.g. <i>if the object is
   * already closed</i>
   * @see curam.homestudy.HomeStudyStatusEntry
   */
  // BEGIN, CR00177241, PM
  protected void transitionTo(final State<HomeStudyStatusEntry> newState,
    final Integer versionNo) throws InformationalException {
    // END, CR00177241

    // if the status of the provider is closed
    if (getProvider().getLifecycleState().equals(ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 15);
      ValidationHelper.failIfErrorsExist();
    }

    // get the state validator for the current request status
    final State<HomeStudyStatusEntry> oldState = states.get(getLifecycleState());

    transition(oldState, newState, versionNo);

  }

  /**
   * Transitions the contract from one state to another.
   *
   * @param oldState  the state being left
   * @param newState  the state being entered
   * @param versionNo the version number known to client code from a previous
   * retrieval.
   * @throws InformationalException if any validation errors were detected
   * during single field, mandatory field or cross-field validation
   * @see curam.homestudy.HomeStudyStatusEntry
   */
  // BEGIN, CR00177241, PM
  protected void transition(final State<HomeStudyStatusEntry> oldState,
    final State<HomeStudyStatusEntry> newState, final Integer versionNo)
    throws InformationalException {
    // END, CR00177241

    // set the field which stores the status
    setStatus(newState.getValue());

    // do the state transition
    oldState.transitionTo(newState);

    // update the database - bypass the pre-modify logic
    super.modify(versionNo);

  }

  /**
   * Gets the current state for the home study.
   *
   * @return the current state
   * @see curam.homestudy.HomeStudyStatusEntry
   */
  // BEGIN, CR00177241, PM
  protected State<HomeStudyStatusEntry> getCurrentState() {
    // END, CR00177241
    return states.get(getLifecycleState());
  }

  /**
   * Performs validations before a home study can be submitted:
   * <ul>
   * <li>Check interview exists</li>
   * <li>Check assessment exists</li>
   * <li>Check final recommendation and support for recommendation exist</li>
   * </ul>
   *
   * @throws InformationalException if any application validation errors are
   * found during the submit operation
   */
  // BEGIN, CR00177241, PM
  protected void submitValidations() throws InformationalException {
    // END, CR00177241

    // BEGIN, CR00207501, NBR
    // Home Study cannot be submitted for approval if it's current state is
    // canceled
    if (getCurrentState().equals(CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_SUBMITTED_ALREADY_DELETED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else {

      // Home Study cannot be submitted for approval until at least one
      // interview has been entered for the home study.
      boolean interviewFound = false;
      Set<HomeStudyHomeVisit> unModifibleHomeVisits = getHomeStudyHomeVisits();
      Set<HomeStudyHomeVisit> homeVisits = new HashSet<HomeStudyHomeVisit>();

      homeVisits.addAll(unModifibleHomeVisits);

      if (homeVisits.size() > 0) {
        for (HomeStudyHomeVisit visit : homeVisits) {
          Set<curam.homestudy.impl.HomeVisitInterview> interviews = visit.getHomeVisitInterviews();

          // if an interview is found
          if (interviews.size() > 0) {
            interviewFound = true;
            break;
          }
        }
      }

      if (!interviewFound) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_SUBMITTED_NO_INTERVIEWS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }

      // Home Study cannot be submitted for approval until at least one
      // assessment has been entered for the home study.
      Set<HomeStudyAssessment> unModifiableAssessments = getHomeStudyAssessments();
      Set<HomeStudyAssessment> assessments = new HashSet<HomeStudyAssessment>();

      assessments.addAll(unModifiableAssessments);

      if (assessments.size() <= 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_SUBMITTED_NO_ASSESSMENTS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }

      // Home Study Final Recommendation and Support For Recommendation must be
      // entered before a Home Study may be submitted for approval.
      if (getFinalRecommendation().equals(
        HomeStudyFinalRecommendationEntry.NOT_SPECIFIED)
          || StringHelper.isEmpty(getSupportForRecommendation())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_SUBMITTED_NO_FINAL_RECOMMENDATION_OR_SUPPORT_FOR_RECOMMENDATION(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }
    // END, CR00207501
    // fail if errors exist
    ValidationHelper.failIfErrorsExist();
  }

  /**
   * A map of the states for this entity.
   */
  protected final Map<HomeStudyStatusEntry, State<HomeStudyStatusEntry>> states = new HashMap<HomeStudyStatusEntry, State<HomeStudyStatusEntry>>();

  /**
   * Represents the OPEN state for the home study.
   */
  protected final State<HomeStudyStatusEntry> OPEN = new CodetableState<HomeStudyStatusEntry>(
    states, HomeStudyStatusEntry.OPEN, true, true) {// Initial state for a Home Study
  };

  /**
   * Represents the SUBMITTED state for the home study.
   */
  protected final State<HomeStudyStatusEntry> SUBMITTED = new CodetableState<HomeStudyStatusEntry>(
    states, HomeStudyStatusEntry.SUBMITTED, false, false) {

    /**
     * Overrides <code>onUnsupporedTransitionFrom</code> to return custom
     * error message.
     *
     * @param oldState the previous state of the home study
     */
    @Override
    protected void onUnsupportedTransitionFrom(
      State<HomeStudyStatusEntry> oldState) {

      // if has been canceled
      if (oldState.getValue().equals(HomeStudyStatusEntry.CANCELLED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_SUBMITTED_ALREADY_DELETED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      } // if has already been submitted
      else if (oldState.getValue().equals(HomeStudyStatusEntry.SUBMITTED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_ALREADY_SUBMITTED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } // any other unsupported state
      else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_SUBMITTED(
            oldState.getValue().getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  };

  /**
   * Represents the RETURNED state for the home study.
   */
  protected final State<HomeStudyStatusEntry> RETURNED = new CodetableState<HomeStudyStatusEntry>(
    states, HomeStudyStatusEntry.RETURNED, true, false) {

    /**
     * Overrides <code>onUnsupporedTransitionFrom</code> to return custom
     * error message.
     *
     * @param oldState the previous state of the home study
     */
    @Override
    protected void onUnsupportedTransitionFrom(
      State<HomeStudyStatusEntry> oldState) {
      // if it is open
      if (oldState.getValue().equals(HomeStudyStatusEntry.OPEN)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_RETURNED_OPEN(
            HomeStudyStatusEntry.SUBMITTED.getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      } // if has been canceled
      else if (oldState.getValue().equals(HomeStudyStatusEntry.CANCELLED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_RETURNED_ALREADY_DELETED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } // if it has already been rejected
      else if (oldState.getValue().equals(HomeStudyStatusEntry.RETURNED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_ALREADY_RETURNED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } // all other unsupported states
      else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_RETURNED(
            oldState.getValue().getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  };

  /**
   * Represents the APPROVED state for the home study.
   */
  protected final State<HomeStudyStatusEntry> APPROVED = new CodetableState<HomeStudyStatusEntry>(
    states, HomeStudyStatusEntry.APPROVED, false, false) {

    /**
     * Overrides <code>onUnsupporedTransitionFrom</code> to return custom
     * error message.
     *
     * @param oldState the previous state of the home study
     */
    @Override
    protected void onUnsupportedTransitionFrom(
      State<HomeStudyStatusEntry> oldState) {
      // if has been canceled
      if (oldState.getValue().equals(HomeStudyStatusEntry.CANCELLED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_APPROVED_ALREADY_DELETED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } // if it has already been approved
      else if (oldState.getValue().equals(HomeStudyStatusEntry.APPROVED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_ALREADY_APPROVED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } // all other unsupported states
      else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_APPROVED(
            HomeStudyStatusEntry.SUBMITTED.getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  };

  /**
   * Represents the CANCELLED state for the home study.
   */
  protected final State<HomeStudyStatusEntry> CANCELLED = new CodetableState<HomeStudyStatusEntry>(
    states, HomeStudyStatusEntry.CANCELLED, false, false) {

    /**
     * Overrides <code>onUnsupporedTransitionFrom</code> to return custom
     * error message.
     *
     * @param oldState the previous state of the home study
     */
    @Override
    protected void onUnsupportedTransitionFrom(
      State<HomeStudyStatusEntry> oldState) {
      // if it has already been canceled
      if (oldState.getValue().equals(HomeStudyStatusEntry.CANCELLED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_ALREADY_CANCELLED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } // all other unsupported states
      else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYExceptionCreator.ERR_HOMESTUDY_NOT_CANCELLED(
            oldState.getValue().getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  };

  /**
   * Represents a transition from the OPEN state to the SUBMITTED state for the
   * home study.
   */
  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<HomeStudyStatusEntry> OPEN2SUBMITTED = new Transition<HomeStudyStatusEntry>(
    OPEN, SUBMITTED) {// Represents a Transition from the OPEN state to the SUBMITTED state
  };

  /**
   * Represents a transition from the OPEN state to the CANCELLED state for the
   * home study.
   */
  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<HomeStudyStatusEntry> OPEN2CANCELLED = new Transition<HomeStudyStatusEntry>(
    OPEN, CANCELLED) {// Represents a Transition from the OPEN state to the CANCELLED state
  };

  /**
   * Represents a transition from the SUBMITTED state to the RETURNED state for
   * the home study.
   */
  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<HomeStudyStatusEntry> SUBMITTED2RETURNED = new Transition<HomeStudyStatusEntry>(
    SUBMITTED, RETURNED) {// Represents a Transition from the SUBMITTED state to the RETURNED state
  };

  /**
   * Represents a transition from the SUBMITTED state to the APPROVED state for
   * the home study.
   */
  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<HomeStudyStatusEntry> SUBMITTED2APPROVED = new Transition<HomeStudyStatusEntry>(
    SUBMITTED, APPROVED) {// Represents a Transition from the SUBMITTED state to the APPROVED state
  };

  /**
   * Represents a transition from the RETURNED state to the SUBMITTED state for
   * the home study.
   */
  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<HomeStudyStatusEntry> RETURNED2SUBMITTED = new Transition<HomeStudyStatusEntry>(
    RETURNED, SUBMITTED) {// Represents a Transition from the RETURNED state to the SUBMITTED state
  };

}
