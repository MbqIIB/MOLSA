/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import curam.core.fact.SystemUserFactory;
import curam.core.intf.SystemUser;
import curam.cpm.sl.entity.struct.HomeStudyStatusHistoryDtls;
import curam.message.impl.HOMESTUDYExceptionCreator;
import curam.message.impl.LICENSEExceptionCreator;
import curam.util.exception.AppRuntimeException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.DateTime;


/**
 * Standard implementation of
 * {@linkplain curam.homestudy.impl.HomeStudyStatusHistory}.
 */
// BEGIN, CR00183213, SS
public class HomeStudyStatusHistoryImpl extends SingleTableEntityImpl<HomeStudyStatusHistoryDtls> implements
  HomeStudyStatusHistory, HomeStudyStatusHistoryCreator {

  /**
   * Constructor for the class.
   */
  protected HomeStudyStatusHistoryImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public DateTime getEventDateTime() {
    return getDtls().dateTime;
  }

  /**
   * {@inheritDoc}
   */
  public HomeStudyStatusEntry getHomeStudyStatus() {
    return HomeStudyStatusEntry.get(getDtls().homeStudyStatus);
  }

  /**
   * {@inheritDoc}
   */
  public HomeStudyReturnReasonEntry getReturnedReason() {
    return HomeStudyReturnReasonEntry.get(getDtls().returnedReason);
  }

  /**
   * {@inheritDoc}
   */
  public String getUser() {
    return getDtls().createdBy;
  }

  /**
   * {@inheritDoc}
   */
  public void setHomeStudy(final HomeStudy homeStudy) {
    getDtls().homeStudyID = homeStudy == null ? 0 : homeStudy.getID();
    // Begin CR00096779, ABS
    if (homeStudy != null) {
      getDtls().homeStudyStatus = homeStudy.getLifecycleState().getCode();
    }
    // End CR00096779
  }

  /**
   * {@inheritDoc}
   */
  public void setReturnedReason(HomeStudyReturnReasonEntry value) {
    getDtls().returnedReason = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// None needed
  }

  /**
   * Validates that changes made to the field HomeStudyStatus of
   * HomeStudyStatusHistory entity on the database are consistent with other
   * field HomeStudyReturnReason of HomeStudyStatusHistory entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.impl.LICENSE#ERR_LICENSE_FV_REASON_EMPTY} - If
   * the License reason is not specified. </li>
   * </ul>
   */
  public void crossFieldValidation() {

    // rejection reason must be specified if and only if the status is rejected
    if ((getHomeStudyStatus().equals(HomeStudyStatusEntry.RETURNED)
      && getReturnedReason().equals(HomeStudyReturnReasonEntry.NOT_SPECIFIED))) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LICENSEExceptionCreator.ERR_LICENSE_FV_REASON_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }
  }

  /**
   * Validates that changes made to the mandatory fields
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.impl.HomeStudy#ERR_HOMESTUDY_STATUS_MANDATORY} -
   * If the HomeStudy Status is not specified. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    // check that the status has been set
    if (getHomeStudyStatus().equals(HomeStudyStatusEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYExceptionCreator.ERR_HOMESTUDY_STATUS_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {

    getDtls().dateTime = DateTime.getCurrentDateTime();

    // Create instance of System User
    final SystemUser user = SystemUserFactory.newInstance();

    try {
      getDtls().createdBy = user.getUserDetails().userName;
    } catch (final Exception e) {
      throw new AppRuntimeException(e);
    }

  }
}
