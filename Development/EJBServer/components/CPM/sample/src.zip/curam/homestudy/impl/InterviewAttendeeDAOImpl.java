/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.homestudy.impl;


import java.util.Set;

import curam.cpm.sl.impl.InterviewAttendeeAdapter;
import curam.cpm.sl.struct.InterviewAttendeeDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Implement the Data Access Object for the
 * {@linkplain curam.homestudy.impl.InterviewAttendee} entity.
 */
// BEGIN, CR00183213, SS
public class InterviewAttendeeDAOImpl extends StandardDAOImpl<InterviewAttendee, InterviewAttendeeDtls> implements
  InterviewAttendeeDAO {
  // END, CR00183213
  protected static final InterviewAttendeeAdapter adapter = new InterviewAttendeeAdapter();

  // _________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected InterviewAttendeeDAOImpl() {
    // END, CR00183213
    super(adapter, InterviewAttendee.class);
  }

  // ________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<InterviewAttendee> searchByHomeVisitInterview(HomeVisitInterview parent) {
    return newSet(adapter.searchByHomeVisitInterview(parent.getID()));
  }
}
