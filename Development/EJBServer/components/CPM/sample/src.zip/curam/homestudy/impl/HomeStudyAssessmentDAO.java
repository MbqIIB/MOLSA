/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.StandardDAO;


/**
 * Data access for <code>HomeStudyAssessment</code>
 *
 * @see curam.homestudy.impl.HomeStudyAssessment
 */
@ImplementedBy(HomeStudyAssessmentDAOImpl.class)
public interface HomeStudyAssessmentDAO extends StandardDAO<HomeStudyAssessment> {

  /**
   * Search the home study assessment by a given home study.
   *
   * @param homeStudy the home study
   * @return the set of all home studies that match the given criteria
   * @see HomeStudyAssessmentDAO#searchActiveByHomeStudy(HomeStudy)
   */
  public Set<HomeStudyAssessment> searchByHomeStudy(HomeStudy homeStudy);

  /**
   * Search the home study assessment by a given home study.
   * <p>
   * Return only active home study assessment records.
   *
   * @param homeStudy the home study
   * @return the set of all the active home studies that match the given criteria
   * @see HomeStudyAssessmentDAO#searchByHomeStudy(HomeStudy)
   */
  public Set<HomeStudyAssessment> searchActiveByHomeStudy(HomeStudy homeStudy);
}
