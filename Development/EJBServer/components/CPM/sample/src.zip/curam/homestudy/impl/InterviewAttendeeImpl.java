/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */


package curam.homestudy.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.cpm.sl.struct.InterviewAttendeeDtls;
import curam.provider.impl.ProviderParty;
import curam.provider.impl.ProviderPartyDAO;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Standard implementation for {@link curam.homestudy.impl.InterviewAttendee}.
 * <p>This is the used to store the attendee for home visit interviews.
 */
// BEGIN, CR00183213, SS
public class InterviewAttendeeImpl extends SingleTableEntityImpl<InterviewAttendeeDtls> implements InterviewAttendee {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<InterviewAttendeeInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for remove events.
   */
  @Inject
  protected EventDispatcherFactory<InterviewAttendeeRemoveEvents> removeEventDispatcherFactory;

  // END, CR00235789

  @Inject
  protected HomeVisitInterviewDAO homeVisitInterviewDAO;

  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  @Inject
  protected InterviewAttendeeDAO interviewAttendeeDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected InterviewAttendeeImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public void setHomeVisitInterview(HomeVisitInterview homeVisitInterview) {
    getDtls().homeVisitInterviewID = homeVisitInterview.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderParty(ProviderParty providerParty) {
    getDtls().providerPartyID = providerParty.getID();
  }

  /**
   * {@inheritDoc}
   */
  public HomeVisitInterview getHomeVisitInterview() {
    return homeVisitInterviewDAO.get(getDtls().homeVisitInterviewID);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderParty getProviderParty() {
    return providerPartyDAO.get(getDtls().providerPartyID);
  }

  /**
   * {@inheritDoc}
   */
  public void remove(InterviewAttendee interviewAttendee)
    throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre remove interview attendee event.
    removeEventDispatcherFactory.get(InterviewAttendeeRemoveEvents.class).preRemove(
      this, interviewAttendee);
    // END, CR00235789

    // Lock the linked records
    getTransactionHelper().lock(this);
    getTransactionHelper().lock(interviewAttendee);

    final Set<InterviewAttendee> interviewAttendees = getInterviewAttendees(
      interviewAttendee.getHomeVisitInterview());

    for (final InterviewAttendee attendee : interviewAttendees) {
      if (attendee.getHomeVisitInterview().getID().equals(
        interviewAttendee.getHomeVisitInterview().getID())) {
        attendee.remove();
      }
    }

    // BEGIN, CR00235789, AK
    // Raise the post remove interview attendee event.
    removeEventDispatcherFactory.get(InterviewAttendeeRemoveEvents.class).postRemove(
      this, interviewAttendee);
    // END, CR00235789
  }

  // BEGIN, CR00235789, AK
  /**
   * {@inheritDoc}
   */
  @Override
  public void insert() throws InformationalException {

    // Raise the post insert absence reason configuration event.
    insertEventDispatcherFactory.get(InterviewAttendeeInsertEvents.class).preInsert(
      this);
    super.insert();
    // Raise the post insert absence reason configuration event.
    insertEventDispatcherFactory.get(InterviewAttendeeInsertEvents.class).postInsert(
      this);
  }

  // END, CR00235789

  /**
   * Gets the <code>Set</code> of link records referring to the interview.
   *
   * @param interview
   * the interview to list the attendees for
   * @return the set of link records referring to
   */
  // BEGIN, CR00177241, PM
  protected Set<InterviewAttendee> getInterviewAttendees(
    curam.homestudy.impl.HomeVisitInterview interview) {
    // END, CR00177241
    return interviewAttendeeDAO.searchByHomeVisitInterview(interview);
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// There are no mandatory field validations required
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// There are no cross field validations required
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No validations of this kind are required
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// No implementation required
  }
}
