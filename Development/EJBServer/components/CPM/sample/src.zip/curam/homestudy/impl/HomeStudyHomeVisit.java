/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.homestudy.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.Date;


/**
 * A home visit conducted as part of a home study in order to gather information
 * from individuals related to the home.
 */
@ImplementedBy(HomeStudyHomeVisitImpl.class)
public interface HomeStudyHomeVisit extends HomeStudyHomeVisitAccessor,
    Insertable, LogicallyDeleteable, Commented, OptimisticLockModifiable {

  /**
   * Gets a <code>Set</code> with all the interviews for the home visit.
   *
   * @return the set with all the interview for the home visit
   */
  public Set<curam.homestudy.impl.HomeVisitInterview> getHomeVisitInterviews();

  /**
   * Gets the home study that is the parent for this home visit.
   *
   * @return the home study that is the parent for this home visit
   *
   * @see curam.homestudy.impl.HomeStudy
   */
  public HomeStudy getHomeStudy();

  /**
   * Sets the purpose for the home visit.
   *
   * @param value
   * the codetable code representing the purpose for the home visit
   */
  public void setPurpose(final HomeVisitPurposeEntry value);

  /**
   * Sets the date of the home visit.
   *
   * @param dateOfVisit
   * the date of the home visit
   */
  public void setDateOfVisit(Date dateOfVisit);

  /**
   * Sets the findings of the home visit.
   *
   * @param homeVisitFindings
   * the findings of the home visit
   *
   * @see curam.homestudy.impl.HomeStudyHomeVisitImpl#setHomeVisitFindings(String) The
   * default implementation -
   * curam.homestudy.impl.HomeStudyHomeVisitImpl#setHomeVisitFindings(String)
   */
  public void setHomeVisitFindings(String homeVisitFindings);

  /**
   * Sets the identifier for the person who conducted the home visit.
   *
   * @param userName
   * the identifier for the person who conducted the home visit
   */
  public void setConductedBy(String userName);

  /**
   * Sets the home study that is the parent for this home visit.
   *
   * @param homeStudy
   * the home study that is the parent for this home visit
   */
  public void setHomeStudy(HomeStudy homeStudy);

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the home study home visit events functionality surrounding the
   * insert method.
   */
  public interface HomeStudyHomeVisitInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.homestudy.impl.HomeStudyHomeVisit#insert}
     *
     * @param homeStudyHomeVisit
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(HomeStudyHomeVisitAccessor homeStudyHomeVisit)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.homestudy.impl.HomeStudyHomeVisit#insert}
     *
     * @param homeStudyHomeVisit
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(HomeStudyHomeVisitAccessor homeStudyHomeVisit)
      throws InformationalException;
  }


  /**
   * Interface to the home study home visit events functionality surrounding the
   * cancel method.
   */
  public interface HomeStudyHomeVisitCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.homestudy.impl.HomeStudyHomeVisit#cancel}
     *
     * @param homeStudyHomeVisit
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(HomeStudyHomeVisitAccessor homeStudyHomeVisit,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.homestudy.impl.HomeStudyHomeVisit#cancel}
     *
     * @param homeStudyHomeVisit
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(HomeStudyHomeVisitAccessor homeStudyHomeVisit,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the home study home visit events functionality surrounding the
   * modify method.
   */
  public interface HomeStudyHomeVisitModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.homestudy.impl.HomeStudyHomeVisit#modify}
     *
     * @param homeStudyHomeVisit
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(HomeStudyHomeVisitAccessor homeStudyHomeVisit,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.homestudy.impl.HomeStudyHomeVisit#modify}
     *
     * @param homeStudyHomeVisit
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(HomeStudyHomeVisitAccessor homeStudyHomeVisit,
      Integer versionNo) throws InformationalException;
  }
  // END, CR00144381
}
