/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.homestudy.impl;


import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.impl.HomeStudyHomeVisitAdapter;
import curam.cpm.sl.entity.struct.HomeStudyHomeVisitDtls;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.message.impl.HOMESTUDYHOMEVISITExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.provider.impl.ProviderSecurity;
import curam.provider.impl.ProviderStatusEntry;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.Date;
import curam.util.type.StringHelper;


/**
 * Standard implementation of {@linkplain curam.homestudy.impl.HomeStudyHomeVisit}.
 */
// BEGIN, CR00183213, SS
public class HomeStudyHomeVisitImpl extends SingleTableLogicallyDeleteableEntityImpl<HomeStudyHomeVisitDtls> implements
  HomeStudyHomeVisit {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyHomeVisitInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyHomeVisitCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyHomeVisitModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  @Inject
  protected HomeStudyDAO homeStudyDAO;

  @Inject
  protected HomeVisitInterviewDAO homeVisitInterviewDAO;

  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected HomeStudyHomeVisitImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public HomeVisitPurposeEntry getPurpose() {
    return HomeVisitPurposeEntry.get(getDtls().purpose);
  }

  /**
   * {@inheritDoc}
   */
  public Date getDateOfVisit() {
    return getDtls().dateOfVisit;
  }

  /**
   * {@inheritDoc}
   */
  public Set<curam.homestudy.impl.HomeVisitInterview> getHomeVisitInterviews() {
    return Collections.unmodifiableSet(
      homeVisitInterviewDAO.searchByHomeStudyHomeVisit(this));
  }

  /**
   * {@inheritDoc}
   */
  public String getHomeVisitFindings() {
    return getDtls().homeVisitFindings;
  }

  /**
   * {@inheritDoc}
   */
  public HomeStudy getHomeStudy() {
    return homeStudyDAO.get(getDtls().homeStudyID);
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  /**
   * {@inheritDoc}
   */
  public String getConductedBy() {
    return getDtls().conductedBy;
  }

  /**
   * {@inheritDoc}
   */
  public void setPurpose(HomeVisitPurposeEntry value) {
    getDtls().purpose = value.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setDateOfVisit(Date dateOfVisit) {
    getDtls().dateOfVisit = dateOfVisit;
  }

  /**
   * {@inheritDoc}
   */
  public void setHomeStudy(HomeStudy homeStudy) {
    getDtls().homeStudyID = homeStudy.getID();
  }

  /**
   * Sets the findings of the home visit.
   *
   * @param homeVisitFindings
   * the findings of the home visit
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * {@link curam.message.HOMESTUDYHOMEVISIT#ERR_FV_FINDINGS_EXCEEDS_MAX_LENGTH} -
   * If the length of the home visit findings exceeds 1000 characters.
   */
  public void setHomeVisitFindings(String homeVisitFindings) {
    getDtls().homeVisitFindings = homeVisitFindings;

    // The length of the home visit findings string must not exceed the maximum
    // amount
    // specified.
    if (getHomeVisitFindings().length()
      > HomeStudyHomeVisitAdapter.kMaxLength_homeVisitFindings) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYHOMEVISITExceptionCreator.ERR_FV_FINDINGS_EXCEEDS_MAX_LENGTH(
          HomeStudyHomeVisitAdapter.kMaxLength_homeVisitFindings),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  /**
   * {@inheritDoc}
   */
  public void setConductedBy(String userName) {
    getDtls().conductedBy = userName;
  }

  /**
   * Sets the comments of the home visit.
   *
   * @param comments
   * the comments of the home visit
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * {@link curam.message.CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_COMMENTS_ABOVE_MAXIMUM_LENGTH} -
   * If the length of the home visit comments exceeds 200 characters.
   */
  public void setComments(String comments) {
    getDtls().comments = comments;

    // The length of the comments string must not exceed the maximum amount
    // specified.
    if (getComments().length() > HomeStudyHomeVisitAdapter.kMaxLength_comments) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_COMMENTS_ABOVE_MAXIMUM_LENGTH(
          HomeStudyHomeVisitAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  /**
   * Validates that all mandatory fields are populated.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>{@link curam.message.HOMESTUDYHOMEVISIT#ERR_FV_PURPOSE_FIELD_EMPTY} -
   * If the Home Visit purpose is not entered. </li>
   * <li>{@link curam.message.HOMESTUDYHOMEVISIT#ERR_FV_DATE_OF_VISIT_FIELD_EMPTY} -
   * If the date of home visit is not entered. </li>
   * <li>{@link curam.message.HOMESTUDYHOMEVISIT#ERR_FV_CONDUCTED_BY_MANDATORY} -
   * If the Home Visit Conducted By is not entered. </li>
   * </ul>
   *
   */
  public void mandatoryFieldValidation() {

    // Purpose, dateOfVisit and status are mandatory
    if (getPurpose().equals(HomeVisitPurposeEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYHOMEVISITExceptionCreator.ERR_FV_PURPOSE_FIELD_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (getDateOfVisit().isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYHOMEVISITExceptionCreator.ERR_FV_DATE_OF_VISIT_FIELD_EMPTY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Conducted By
    if (StringHelper.isEmpty(getConductedBy())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYHOMEVISITExceptionCreator.ERR_FV_CONDUCTED_BY_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// There are no cross field validations
    // required
  }

  /**
   * Validates that changes made to HomeStudyHomeVisit entity on the database
   * are consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>{@link curam.message.HOMESTUDYHOMEVISIT#ERR_HOMEVISITINTERVIEW_XRV_CANNOT_UPDATE_IF_HOME_STUDY_APPROVED} -
   * If the Date of Visit is before the home study Date Initiated.</li>
   * </ul>
   *
   */
  public void crossEntityValidation() {
    // A home study home visit with a status of Canceled may not be modified.
    // (This one is handled in the SingleTableLogicallyDeleteableEntityImpl
    // interface)

    // The Date of Visit for a home study home visit may not be earlier than the
    // Date Initiated of the home study for which it is being carried out.
    HomeStudy homeStudy = getHomeStudy();

    if (homeStudy != null
      && getDtls().dateOfVisit.before(homeStudy.getDateInitiated())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYHOMEVISITExceptionCreator.ERR_XRV_DATE_OF_VISIT_BEFORE_HOME_STUDY_INITIATED_DATE(
          getDtls().dateOfVisit, homeStudy.getDateInitiated()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  // BEGIN, CR00235789, AK
  /**
   * Modifies a home study home visit record. Checks the provider security to
   * modify. Validates that the home study for which the visit is to be
   * modified,is not already approved
   *
   * @param versionNo
   * The version number of the record, used for optimistic locking.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYHOMEVISIT#ERR_XRV_CANNOT_UPDATE_IF_HOME_STUDY_APPROVED_MODIFY} -
   * If the home study is Approved, a home study home visit cannot be
   * updated.
   */
  // END, CR00235789
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // Checks the provider security.
    providerSecurity.checkProviderSecurity(
      homeStudyDAO.get(getHomeStudy().getID()).getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre modify home study home visit event.
    modifyEventDispatcherFactory.get(HomeStudyHomeVisitModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // if the status of the provider is closed
    if (getHomeStudy().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 21);
      ValidationHelper.failIfErrorsExist();
    }

    validateIfHomeStudyApproved(CPMConstants.kMODIFY);

    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify home study home visit event.
    modifyEventDispatcherFactory.get(HomeStudyHomeVisitModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  // BEGIN, CR00235789, AK
  /**
   * Inserts a Home study home visit record. Checks the provider security to
   * insert. Validates that the home study for which the visit is to be added,is
   * not already approved
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}
   * - If the provider is closed. Provider Details cannot be updated.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYHOMEVISIT#ERR_XRV_CANNOT_UPDATE_IF_HOME_STUDY_APPROVED_INSERT}
   * - If the home study is Approved, a home study home visit cannot
   * be added.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYHOMEVISIT#ERR_HOMESTUDYHOMEVISIT_XRV_HOMESTUDY_CANCELLED_CANNOT_ADD_HOMESTUDYHOMEVISIT}
   * - If the home study home visit is added to a canceled home study.
   */
  // END, CR00235789
  @Override
  public void insert() throws InformationalException {

    // Checks the provider security
    providerSecurity.checkProviderSecurity(
      homeStudyDAO.get(getHomeStudy().getID()).getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre insert home study home visit event.
    insertEventDispatcherFactory.get(HomeStudyHomeVisitInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    // BEGIN, CR00207577, RD
    if (HomeStudyStatusEntry.CANCELLED.equals(
      getHomeStudy().getLifecycleState())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYHOMEVISITExceptionCreator.ERR_HOMESTUDYHOMEVISIT_XRV_HOMESTUDY_CANCELLED_CANNOT_ADD_HOMESTUDYHOMEVISIT(
          HomeStudyStatusEntry.CANCELLED.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00207577
    
    // if the status of the provider is closed
    if (getHomeStudy().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 20);
      ValidationHelper.failIfErrorsExist();
    }

    validateIfHomeStudyApproved(CPMConstants.kINSERT);

    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert home study home visit event.
    insertEventDispatcherFactory.get(HomeStudyHomeVisitInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  // BEGIN, CR00235789, AK
  /**
   * Cancels a Home study home visit record and its associated home visit
   * interview records. Checks the provider security to cancel. Validates that
   * the home study for which the visit is to be canceled,is not already
   * approved.
   *
   * @param versionNo
   * The version number of the record, used for optimistic locking.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYHOMEVISIT#ERR_XRV_CANNOT_UPDATE_IF_HOME_STUDY_APPROVED_CANCEL} -
   * If the home study is Approved, a home study home visit cannot be
   * deleted.
   */
  // END, CR00235789
  @Override
  public void cancel(int versionNo) throws InformationalException {

    // Checks the provider security
    providerSecurity.checkProviderSecurity(
      homeStudyDAO.get(getHomeStudy().getID()).getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre cancel home study home visit event.
    cancelEventDispatcherFactory.get(HomeStudyHomeVisitCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    // if the status of the provider is closed
    if (getHomeStudy().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 22);
      ValidationHelper.failIfErrorsExist();
    }

    validateIfHomeStudyApproved(CPMConstants.kCANCEL);

    // Cancel the Interview children of home visit
    Set<HomeVisitInterview> unModifiableHomeVisitInterviews = getHomeVisitInterviews();
    Set<HomeVisitInterview> homeVisitInterviews = new HashSet<HomeVisitInterview>();

    homeVisitInterviews.addAll(unModifiableHomeVisitInterviews);

    for (HomeVisitInterview interview : homeVisitInterviews) {
      if (!interview.getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {
        interview.cancel(interview.getVersionNo());
      }
    }

    super.cancel(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post cancel home study home visit event.
    cancelEventDispatcherFactory.get(HomeStudyHomeVisitCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Validate that the home study that the visit is to be modified for is not
   * already approved and return the appropriate informational.
   *
   * @param operation
   * The operation the validation is for e.g. 'insert' or 'modify'
   */
  // BEGIN, CR00177241, PM
  protected void validateIfHomeStudyApproved(String operation) {
    // END, CR00177241

    HomeStudy homeStudy = getHomeStudy();

    // A home study home visit cannot be added, modified, or deleted if the
    // status of the home study has been set to Approved.
    if (homeStudy != null
      && homeStudy.getLifecycleState().equals(HomeStudyStatusEntry.APPROVED)) {

      if (operation.equals(CPMConstants.kINSERT)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYHOMEVISITExceptionCreator.ERR_XRV_CANNOT_UPDATE_IF_HOME_STUDY_APPROVED_INSERT(
            HomeStudyStatusEntry.APPROVED.getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
      if (operation.equals(CPMConstants.kMODIFY)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYHOMEVISITExceptionCreator.ERR_XRV_CANNOT_UPDATE_IF_HOME_STUDY_APPROVED_MODIFY(
            HomeStudyStatusEntry.APPROVED.getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
      if (operation.equals(CPMConstants.kCANCEL)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          HOMESTUDYHOMEVISITExceptionCreator.ERR_XRV_CANNOT_UPDATE_IF_HOME_STUDY_APPROVED_CANCEL(
            HomeStudyStatusEntry.APPROVED.getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

  }
}
