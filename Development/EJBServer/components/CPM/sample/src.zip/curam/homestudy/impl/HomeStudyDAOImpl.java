/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Set;

import curam.cpm.sl.entity.impl.HomeStudyAdapter;
import curam.cpm.sl.entity.struct.HomeStudyDtls;
import curam.provider.impl.Provider;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import curam.util.type.Date;


/**
 * Implementation of data retrieval operations for the
 * {@linkplain curam.homestudy.impl.HomeStudy} entity.
 */

public class HomeStudyDAOImpl extends StandardDAOImpl<HomeStudy, HomeStudyDtls>
  implements HomeStudyDAO {

  protected static final HomeStudyAdapter adapter = new HomeStudyAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected HomeStudyDAOImpl() {
    // END, CR00183213
    super(adapter, HomeStudy.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<HomeStudy> searchActiveByProvider(Provider provider) {

    Set<HomeStudy> filteredHomeStudies = newSet(new HomeStudyDtls[0]);
    Set<HomeStudy> homeStudies = newSet(
      adapter.searchByProvider(provider.getID()));

    for (HomeStudy homeStudy: homeStudies) {
      // if the status is not CANCELLED, add it to the filtered set
      if (!homeStudy.getLifecycleState().equals(HomeStudyStatusEntry.CANCELLED)) {
        filteredHomeStudies.add(homeStudy);
      }
    }

    return filteredHomeStudies;
  }

  /**
   * {@inheritDoc}
   */
  public Set<HomeStudy> searchByProvider(Provider provider) {

    return newSet(adapter.searchByProvider(provider.getID()));
  }

  // BEGIN, CR00226380, GP
  /**
   * {@inheritDoc}
   */
  public Set<HomeStudy> searchByDateInitiatedRangeAndStatus(Date startDate,
    Date endDate, HomeStudyStatusEntry homeStudyStatus) throws AppException,
      InformationalException {

    return newSet(
      adapter.searchByDateRangeAndStatus(startDate, endDate,
      homeStudyStatus.getCode()));
  }
  // END, CR00226380
}
