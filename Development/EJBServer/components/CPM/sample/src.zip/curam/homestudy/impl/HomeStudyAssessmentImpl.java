/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.impl.HomeStudyAssessmentAdapter;
import curam.cpm.sl.entity.struct.HomeStudyAssessmentDtls;
import curam.events.HOMESTUDYASSESSMENT;
import curam.message.impl.HOMESTUDYASSESSMENTExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.provider.impl.ProviderSecurity;
import curam.provider.impl.ProviderStatusEntry;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * Standard implementation of <code>HomeStudyAssessment</code>.
 *
 * @see curam.homestudy.impl.HomeStudyAssessment
 */
// BEGIN, CR00183213, SS
public class HomeStudyAssessmentImpl extends SingleTableLogicallyDeleteableEntityImpl<HomeStudyAssessmentDtls> implements
  HomeStudyAssessment {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyAssessmentInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyAssessmentCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<HomeStudyAssessmentModifyEvents> modifyEventDispatcherFactory;
  // END, CR00235789

  @Inject
  protected HomeStudyDAO homeStudyDAO;

  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected HomeStudyAssessmentImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * Inserts the home study assessment entity in the database. If the result
   * status is conditional pass it raises an event. Checks the provider/provider
   * group security to add a home study assessment.
   *
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_CANNOT_BE_ADDED_WHEN_HOME_STUDY_IS_APPROVED}
   * - If the home study status is approved.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYASSESSMENT#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}
   * - If the provider status is closed.
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_XRV_HOMESTUDY_CANCELLED_CANNOT_ADD_HOMESTUDYASSESSMENT}
   * - If the home study assessment is added to a canceled home study.
   */
  @Override
  public void insert() throws InformationalException {

    // perform a security check
    providerSecurity.checkProviderSecurity(getHomeStudy().getProvider());
    // BEGIN, CR00235789, AK
    // Raise the pre insert home study assessment event.
    insertEventDispatcherFactory.get(HomeStudyAssessmentInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    // BEGIN, CR00207577, RD
    if (HomeStudyStatusEntry.CANCELLED.equals(
      getHomeStudy().getLifecycleState())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_XRV_HOMESTUDY_CANCELLED_CANNOT_ADD_HOMESTUDYASSESSMENT(
          HomeStudyStatusEntry.CANCELLED.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00207577

    if (getHomeStudy().getLifecycleState().equals(HomeStudyStatusEntry.APPROVED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_CANNOT_BE_ADDED_WHEN_HOME_STUDY_IS_APPROVED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // if the status of the provider is closed
    if (getHomeStudy().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 11);
      ValidationHelper.failIfErrorsExist();
    }

    // Call insert
    super.insert();

    // raise event if the assessment result is 'Conditional Pass'
    if (getResult().equals(HomeStudyAssessmentResultEntry.CONDITIONALPASS)) {
      final Event event = new Event();

      event.eventKey = HOMESTUDYASSESSMENT.HOMESTUDYASSESSMENT_RESULT_AS_CONDITIONAL_PASS;
      event.primaryEventData = getID();

      try {
        EventService.raiseEvent(event);
      } catch (AppException ex) {
        ValidationHelper.addValidationError(ex);
      }
    }

    // BEGIN, CR00235789, AK
    // Raise the post insert home study assessment event.
    insertEventDispatcherFactory.get(HomeStudyAssessmentInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * Modifies this logical entity on the database. Fails if the version number
   * (as held by the client code) is not the same as that held on the
   * database, as this would indicate that changes have been made to the data
   * since the client last read the entity. If the result status is
   * conditional pass it raises an event.
   * Checks the provider/provider group security to modify home study assessment.
   *
   * @param versionNo
   * The version number as held by the client code.
   *
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_CANNOT_BE_ADDED_WHEN_HOME_STUDY_IS_APPROVED} -
   * If the home study status is approved.
   * {@link curam.message.HOMESTUDYASSESSMENT#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider status is closed.
   * {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_STATUS_IS_CANCEL_CANNOT_BE_UPDATED} -
   * If the status is canceled.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // perform security check
    providerSecurity.checkProviderSecurity(getHomeStudy().getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre modify home study assessment event.
    modifyEventDispatcherFactory.get(HomeStudyAssessmentModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // if the status of the provider is closed
    if (getHomeStudy().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 12);
      ValidationHelper.failIfErrorsExist();
    }

    if (getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_STATUS_IS_CANCEL_CANNOT_BE_UPDATED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

      // BEGIN, CR00134618, KR
      ValidationHelper.failIfErrorsExist();
      // END, CR00134618
    }

    if (getHomeStudy().getLifecycleState().equals(HomeStudyStatusEntry.APPROVED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_CANNOT_BE_MODIFIED_WHEN_HOME_STUDY_IS_APPROVED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    super.modify(versionNo);

    // raise event if the assessment result is 'Conditional Pass'
    if (getResult().equals(HomeStudyAssessmentResultEntry.CONDITIONALPASS)) {
      final Event event = new Event();

      event.eventKey = HOMESTUDYASSESSMENT.HOMESTUDYASSESSMENT_RESULT_AS_CONDITIONAL_PASS;
      event.primaryEventData = getID();

      try {
        EventService.raiseEvent(event);
      } catch (AppException ex) {
        ValidationHelper.addValidationError(ex);
      }
    }
    // BEGIN, CR00235789, AK
    // Raise the post modify home study assessment event.
    modifyEventDispatcherFactory.get(HomeStudyAssessmentModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Logically deletes the home study assessment.
   * Checks the provider/provider group security to cancel home study assessment.
   *
   * @param versionNo
   * The version number as held by the client code.
   *
   * @throws InformationalException
   * {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_CANNOT_BE_DELETED_WHEN_HOME_STUDY_IS_APPROVED} -
   * If the home study status is approved.
   * {@link curam.message.HOMESTUDYASSESSMENT#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider status is closed.
   */
  @Override
  public void cancel(int versionNo) throws InformationalException {

    // Add method security
    providerSecurity.checkProviderSecurity(getHomeStudy().getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre cancel home study assessment event.
    cancelEventDispatcherFactory.get(HomeStudyAssessmentCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    if (getHomeStudy().getLifecycleState().equals(HomeStudyStatusEntry.APPROVED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_CANNOT_BE_DELETED_WHEN_HOME_STUDY_IS_APPROVED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // if the status of the provider is closed
    if (getHomeStudy().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 13);
    }

    super.cancel(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post cancel home study assessment event.
    cancelEventDispatcherFactory.get(HomeStudyAssessmentCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Validates that all mandatory fields are "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_ASSESSMENTTYPE_MUST_BE_ENTERED} -
   * If the assessment type is not entered.
   * </li>
   * <li> {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_DATECOMPLETED_MUST_BE_ENTERED} -
   * If the date completed is not entered.
   * </li>
   * <li> {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_RESULT_MUST_BE_ENTERED} -
   * If the result is not entered.
   * </li>
   * </ul>
   *
   */
  public void mandatoryFieldValidation() {

    // assessmentType is mandatory
    if (getAssessmentType().equals(HomeStudyAssessmentTypeEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_ASSESSMENTTYPE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // date Completed is mandatory
    if (getDateCompleted().isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_DATECOMPLETED_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // result is mandatory
    if (getResult().equals(HomeStudyAssessmentResultEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_RESULT_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
  }

  /**
   * Validates that all the field values held are valid with respect to each
   * other.
   *
   * <p>
   * The entity manager infrastructure enforces that no database access occurs
   * in this method. Only data held on this entity may be accessed.
   * <p>
   * <p>
   * It adds the following informational exceptions to the validation helper when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_CORRECTIVE_ACTION_REQUIRED_MUST_BE_FALSE_IF_RESULT_IS_PASS} -
   * If the result is pass and the corrective action required is true.
   * </li>
   * <li> {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_CORRECTIVE_ACTION_PLAN_MUST_BE_SPECIFIED_iF_CORRECTIVE_ACTION_REQUIRED_IS_TRUE} -
   * If the action plan is not specified and the corrective action required is true.
   * </li>
   * <li> {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_CORRECTIVE_ACTION_PLAN_ENTERED_AND_CORRECTIVE_ACTION_REQUIRED_IS_FALSE} -
   * If the corrective action plan is entered and the corrective action required is false.
   * </li>
   * </ul>
   *
   */
  public void crossFieldValidation() {

    // indicator is set but result is pass
    if (isCorrectiveActionRequired()
      && getResult().equals(HomeStudyAssessmentResultEntry.PASS)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_CORRECTIVE_ACTION_REQUIRED_MUST_BE_FALSE_IF_RESULT_IS_PASS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // indicator is set but no plan is entered
    // Begin CR00096779, ABS
    if (isCorrectiveActionRequired()
      && getCorrectiveActionPlan().equals(CPMConstants.kEmptyString)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_CORRECTIVE_ACTION_PLAN_MUST_BE_SPECIFIED_iF_CORRECTIVE_ACTION_REQUIRED_IS_TRUE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // plan is entered without indicator
    // Begin CR00096779, ABS
    if (!isCorrectiveActionRequired()
      && !getCorrectiveActionPlan().equals(CPMConstants.kEmptyString)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_CORRECTIVE_ACTION_PLAN_ENTERED_AND_CORRECTIVE_ACTION_REQUIRED_IS_FALSE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * Validates that changes made to this entity on the database are consistent
   * with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_DATE_COMPLETED_MUST_BE_AFTER_HOME_STUDY_DATE_INITIATED} -
   * If the completed date is before the initiated date.
   * </li>
   * </ul>
   *
   */
  public void crossEntityValidation() {

    curam.homestudy.impl.HomeStudy homeStudy = getHomeStudy();

    if (getDateCompleted().before(homeStudy.getDateInitiated())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_DATE_COMPLETED_MUST_BE_AFTER_HOME_STUDY_DATE_INITIATED(
          getDtls().dateCompleted, homeStudy.getDateInitiated()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public HomeStudyAssessmentTypeEntry getAssessmentType() {
    return HomeStudyAssessmentTypeEntry.get(getDtls().assessmentType);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Date getDateCompleted() {
    return getDtls().dateCompleted;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public boolean isCorrectiveActionRequired() {
    return getDtls().correctiveActionRequired;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getCorrectiveActionPlan() {
    return getDtls().correctiveActionPlan;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public HomeStudyAssessmentResultEntry getResult() {
    return HomeStudyAssessmentResultEntry.get(getDtls().result);
  }

  // ___________________________________________________________________________
  /**
   * Get the Home Study Assessment Comments.
   *
   * @return the Comments.
   */
  public String getComments() {
    return getDtls().comments;
  }

  // ___________________________________________________________________________
  /**
   * Get the Date range from the date the home study was initiated and the home
   * study assessment was completed.
   * @return the date range of the home study assessment from the date initiated
   * to the date completed.
   */
  public DateRange getDateRange() {

    return new DateRange(getHomeStudy().getDateInitiated(), getDateCompleted());
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setAssessmentType(HomeStudyAssessmentTypeEntry homeStudyAssessment) {
    getDtls().assessmentType = homeStudyAssessment.getCode();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setDateCompleted(Date date) {
    getDtls().dateCompleted = date;
  }

  // ___________________________________________________________________________
  /**
   * Set the Home Study Assessment Corrective Action Required Indicator.
   *
   * @param correctiveActionRequiredInd corrective action required indicator
   */
  public void setCorrectiveActionRequired(boolean correctiveActionRequiredInd) {
    getDtls().correctiveActionRequired = correctiveActionRequiredInd;
  }

  /**
   * Sets the description of the actions that must be undertaken to resolve the
   * conditions that resulted in an unsuccessful assessment.
   *
   * @param correctiveActionPlan
   * the corrective action plan.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_CORRECTIVE_ACTION_PLAN_TOO_LONG} -
   * If the corrective action plan is too long.
   * </li>
   * </ul>
   */
  public void setCorrectiveActionPlan(String correctiveActionPlan) {
    getDtls().correctiveActionPlan = correctiveActionPlan;

    if (getCorrectiveActionPlan().length()
      >= HomeStudyAssessmentAdapter.kMaxLength_correctiveActionPlan) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_CORRECTIVE_ACTION_PLAN_TOO_LONG(
          HomeStudyAssessmentAdapter.kMaxLength_correctiveActionPlan),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * Sets the result of the home study assessment.
   *
   * @param result
   * Result of the home study assessment.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_RESULT_MUST_BE_ENTERED} -
   * If the result is not specified.
   * </li>
   * </ul>
   */
  public void setResult(HomeStudyAssessmentResultEntry result) {
    getDtls().result = result.getCode();

    // Begin CR00096779, ABS
    if (getResult().equals(HomeStudyAssessmentResultEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_RESULT_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Set comments recorded by a user relating to the home study assessment.
   *
   * @param comments The home study assessment comments to set
   *
   * <p>
   * It adds the following informational exceptions to the validation helper when validation fails.
   * </p>
   * <ul>
   * <li> {@link curam.message.HOMESTUDYASSESSMENT#ERR_HOME_STUDY_ASSESSMENT_COMMENTS_TOO_LONG} -
   * If the comment length is too long.
   * </li>
   * </ul>
   */
  public void setComments(String comments) {
    getDtls().comments = comments;

    if (getComments().length()
      >= HomeStudyAssessmentAdapter.kMaxLength_comments) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMESTUDYASSESSMENTExceptionCreator.ERR_HOME_STUDY_ASSESSMENT_COMMENTS_TOO_LONG(
          HomeStudyAssessmentAdapter.kMaxLength_correctiveActionPlan),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Set the Home Study ID.
   *
   * @param homeStudy the home study to set to
   */
  public void setHomeStudy(curam.homestudy.impl.HomeStudy homeStudy) {
    getDtls().homeStudyID = homeStudy.getID();
  }

  // ___________________________________________________________________________
  /**
   * Gets the Home Study for the Home Study Assessment
   *
   * @return the home study for this home study assessment record.
   */
  public curam.homestudy.impl.HomeStudy getHomeStudy() {
    final long myHomeStudyID = getDtls().homeStudyID;

    if (myHomeStudyID == 0) {
      return null;
    } else {
      return homeStudyDAO.get(myHomeStudyID);
    }
  }

}
