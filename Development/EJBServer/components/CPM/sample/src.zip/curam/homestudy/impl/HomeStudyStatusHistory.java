/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007,2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import com.google.inject.ImplementedBy;

import curam.util.type.HistoricalEvent;


/**
 * The status history of a home study. The status of a home study will change through
 * its lifecycle for example, the status is set to 'In Progress' upon initial
 * creation, and then changed to 'Approved' following approval
 */
@ImplementedBy(HomeStudyStatusHistoryImpl.class)
public interface HomeStudyStatusHistory extends HomeStudyStatusHistoryAccessor, HistoricalEvent {// No methods are present
}
