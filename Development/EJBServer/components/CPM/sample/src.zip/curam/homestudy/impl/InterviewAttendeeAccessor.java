/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import curam.provider.impl.ProviderPartyAccessor;
import curam.util.persistence.StandardEntity;


/**
 * Accessor interface for Interview Attendee 
 * {@linkplain curam.homestudy.impl.InterviewAttendee}.
 *
 */
public interface InterviewAttendeeAccessor extends StandardEntity {

  // _________________________________________________________________________
  /**
   * Gets the home visit interview this attendee attended.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return the interview this attendee attended
   */
  public HomeVisitInterviewAccessor getHomeVisitInterview();

  // _________________________________________________________________________
  /**
   * Gets the provider party this attendee is recorded as.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return the provider party this attendee is recorded as
   */
  public ProviderPartyAccessor getProviderParty();
  
}
