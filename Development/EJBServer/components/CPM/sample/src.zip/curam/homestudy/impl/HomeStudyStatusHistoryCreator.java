/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import com.google.inject.ImplementedBy;

import curam.util.persistence.Insertable;


/**
 * Internal <code>interface</code> to create history records.
 *
 * @see curam.homestudy.impl.HomeStudyStatusHistory
 */
@ImplementedBy(HomeStudyStatusHistoryImpl.class)
// BEGIN, CR00274320, AC
public interface HomeStudyStatusHistoryCreator extends HomeStudyStatusHistory, Insertable {
  // END, CR00274320
  // ___________________________________________________________________________
  /**
   * Sets the home study that this status history record relates to.
   *
   * @param value the <code>HomeStudy</code> that this status history record 
   * relates to
   *
   * @see curam.homestudy.impl.HomeStudy
   */
  public void setHomeStudy(final HomeStudy value);

  // ___________________________________________________________________________
  /**
   * Sets the reason the home study was returned.
   *
   * @param value The reason the home study was returned.
   */
  public void setReturnedReason(final HomeStudyReturnReasonEntry value);

}
