/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Set;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.entity.impl.HomeStudyAssessmentAdapter;
import curam.cpm.sl.entity.struct.HomeStudyAssessmentDtls;
import curam.util.persistence.StandardDAOImpl;
import curam.util.persistence.helper.LifecycleHelper;


/**
 * Implementation of data retrieval operations for the
 * {@linkplain curam.homestudy.impl.HomeStudyAssessmentDAO} entity.
 */
// BEGIN, CR00183213, SS
public class HomeStudyAssessmentDAOImpl extends StandardDAOImpl<HomeStudyAssessment, HomeStudyAssessmentDtls> implements
  HomeStudyAssessmentDAO {
  // END, CR00183213
  protected static final HomeStudyAssessmentAdapter adapter = new HomeStudyAssessmentAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected HomeStudyAssessmentDAOImpl() {
    // END, CR00183213
    super(adapter, HomeStudyAssessment.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<HomeStudyAssessment> searchByHomeStudy(HomeStudy homeStudy) {

    return newSet(adapter.searchByHomeStudy(homeStudy.getID()));
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<HomeStudyAssessment> searchActiveByHomeStudy(HomeStudy homeStudy) {
    Set<HomeStudyAssessment> homeStudyAssessments = newSet(
      adapter.searchByHomeStudy(homeStudy.getID()));

    return LifecycleHelper.filter(homeStudyAssessments,
      RECORDSTATUSEntry.NORMAL);
  }

}
