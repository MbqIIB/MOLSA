/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.List;

import com.google.inject.ImplementedBy;

import curam.util.persistence.ReaderDAO;


/**
 * Data access for
 * {@linkplain curam.homestudy.impl.HomeStudyStatusHistory}.
 */
@ImplementedBy(HomeStudyStatusHistoryDAOImpl.class)
// BEGIN, CR00274320, AC
public interface HomeStudyStatusHistoryDAO extends
    ReaderDAO<Long, HomeStudyStatusHistory> {
  // END, CR00274320

  // ___________________________________________________________________________
  /**
   * Searches status history records for a home study, returned in descending
   * date/time order (i.e. latest first).
   *
   * @param homeStudy the home study for which history records are required
   * @return the list with all the status history records for a home study
   */
  public List<HomeStudyStatusHistory> searchBy(final HomeStudy homeStudy);

}
