/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.homestudy.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain curam.homestudy.impl.InterviewAttendee}.
 */
@ImplementedBy(InterviewAttendeeDAOImpl.class)
public interface InterviewAttendeeDAO extends StandardDAO<InterviewAttendee> {

  // _________________________________________________________________________
  /**
   * Returns a <code>Set</code> of interview attendees for a specified home 
   * interview visit.
   *
   * @param parent the home interview to list the attendees for
   * @return the set of interview attendees for this home interview visit
   */
  public Set<InterviewAttendee> searchByHomeVisitInterview(
    HomeVisitInterview parent);

}
