/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.cpm.sl.struct.HomeStudyDocumentTemplateCategoryKey;
import curam.cpm.sl.struct.HomeStudyDocumentTemplateList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain HomeStudyDocument}.
 */
@ImplementedBy(HomeStudyDocumentDAOImpl.class)
public interface HomeStudyDocumentDAO extends StandardDAO<HomeStudyDocument> {

  // ___________________________________________________________________________
  /**
   * Searches the home study documents for those for a particular home study.
   *
   * @param homeStudy the home study for which we wish to search for 
   * home study documents
   * @return the home study document set
   * @see curam.homestudy.impl.HomeStudyDocumentDAO#searchActiveByHomeStudy(HomeStudy)
   */
  public Set<HomeStudyDocument> searchByHomeStudy(final HomeStudy homeStudy);

  // ___________________________________________________________________________
  /**
   * Searches ACTIVE home study documents for those for a particular home study
   *
   * @param homeStudy the home study for which we wish to search for home study 
   * documents
   * @return the home study documents
   * @see curam.homestudy.impl.HomeStudyDocumentDAO#searchByHomeStudy(HomeStudy)
   */
  public Set<HomeStudyDocument> searchActiveByHomeStudy(final HomeStudy homeStudy);

  // ___________________________________________________________________________
  /**
   * Retrieves a list of home study document templates.
   *
   * @param key the container of the template category and record status
   * @return the list of home study document templates
   * @throws InformationalException
   * @throws AppException
   */
  public HomeStudyDocumentTemplateList getDocumentTemplateList(
    HomeStudyDocumentTemplateCategoryKey key)
    throws AppException, InformationalException;

}
