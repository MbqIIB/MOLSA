/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Collections;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.entity.impl.HomeVisitInterviewAdapter;
import curam.cpm.sl.entity.struct.HomeVisitInterviewDtls;
import curam.message.impl.HOMEVISITINTERVIEWExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.provider.impl.ProviderSecurity;
import curam.provider.impl.ProviderStatusEntry;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateTime;
import curam.util.type.StringHelper;


/**
 * Standard implementation of
 * {@linkplain curam.homestudy.impl.HomeVisitInterview}.
 */
// BEGIN, CR00183213, SS
public class HomeVisitInterviewImpl extends SingleTableLogicallyDeleteableEntityImpl<HomeVisitInterviewDtls> implements
  HomeVisitInterview {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<HomeVisitInterviewInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<HomeVisitInterviewCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<HomeVisitInterviewModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  @Inject
  protected HomeStudyDAO homeStudyDAO;

  @Inject
  protected HomeStudyHomeVisitDAO homeVisitDAO;

  @Inject
  protected InterviewAttendeeDAO interviewAttendeeDAO;

  @Inject
  protected ProviderSecurity providerSecurity;
  
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected HomeVisitInterviewImpl() {// not needed
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public HomeVisitInterviewTypeEntry getType() {
    return HomeVisitInterviewTypeEntry.get(getDtls().type);
  }

  /**
   * {@inheritDoc}
   */
  public DateTime getStartDateTime() {
    return getDtls().startDateTime;
  }

  /**
   * {@inheritDoc}
   */
  public DateTime getEndDateTime() {
    return getDtls().endDateTime;
  }

  /**
   * {@inheritDoc}
   */
  public String getNarrative() {
    return getDtls().narrative;
  }

  /**
   * {@inheritDoc}
   */
  public HomeVisitMethodEntry getMethod() {
    return HomeVisitMethodEntry.get(getDtls().method);
  }

  /**
   * {@inheritDoc}
   */
  public HomeVisitInterviewlocationEntry getLocation() {
    return HomeVisitInterviewlocationEntry.get(getDtls().location);
  }

  /**
   * {@inheritDoc}
   */
  public HomeStudyHomeVisit getHomeStudyHomeVisit() {
    final long myHomeStudyHomeVisitID = getDtls().homeStudyHomeVisitID;

    if (myHomeStudyHomeVisitID == 0) {
      return null;
    } else {
      return homeVisitDAO.get(myHomeStudyHomeVisitID);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setStartDateTime(DateTime value) {
    getDtls().startDateTime = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setEndDateTime(DateTime value) {
    getDtls().endDateTime = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setMethod(HomeVisitMethodEntry value) {
    getDtls().method = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setLocation(HomeVisitInterviewlocationEntry value) {
    getDtls().location = value.getCode();
  }

  /**
   * Sets the narrative for this interview.
   *
   * @param value
   * the narrative text.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.HOMEVISITINTERVIEW#ERR_HOMEVISITINTERVIEW_FV_NARRATIVE_LONG} -
   * If the narrative text length is more than 1000 characters. </li>
   * </ul>
   */
  public void setNarrative(String value) {
    // field validation
    if (value != null
      && value.length() > HomeVisitInterviewAdapter.kMaxLength_narrative) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_FV_NARRATIVE_LONG(
          HomeVisitInterviewAdapter.kMaxLength_narrative),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    } else {
      getDtls().narrative = StringHelper.trim(value);
    }
  }

  /**
   * Validates that all mandatory fields are populated.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>{@link curam.message.HOMEVISITINTERVIEW#ERR_HOMEVISITINTERVIEW_FV_TYPE_FIELD_MANDATORY} -
   * If the Home Visit Interview Type is not entered. </li>
   * <li>{@link curam.message.HOMEVISITINTERVIEW#ERR_HOMEVISITINTERVIEW_FV_METHOD_FIELD_MANDATORY} -
   * If the Home Visit Interview Method is not entered. </li>
   * <li>{@link curam.message.HOMEVISITINTERVIEW#ERR_HOMEVISITINTERVIEW_FV_LOCATION_FIELD_MANDATORY} -
   * If the Home Visit Interview Location is not entered. </li>
   * <li>{@link curam.message.HOMEVISITINTERVIEW#ERR_HOMEVISITINTERVIEW_FV_NARRATIVE_FIELD_MANDATORY} -
   * If the Narrative is not entered. </li>
   * <li>{@link curam.message.HOMEVISITINTERVIEW#ERR_HOMEVISITINTERVIEW_FV_STARTDATETIME_FIELD_MANDATORY} -
   * If the Start Date Time is not entered. </li>
   * <li>{@link curam.message.HOMEVISITINTERVIEW#ERR_HOMEVISITINTERVIEW_FV_ENDDATETIME_FIELD_MANDATORY} -
   * If the End Date Time is not entered. </li>
   * </ul>
   *
   */
  public void mandatoryFieldValidation() {
    // Type, StartDateTime, EndDateTime, Method, Narrative, Location & Status
    // are all mandatory

    if (getType().equals(HomeVisitInterviewTypeEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_FV_TYPE_FIELD_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (getMethod().equals(HomeVisitMethodEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_FV_METHOD_FIELD_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (getLocation().equals(HomeVisitInterviewlocationEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_FV_LOCATION_FIELD_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (getNarrative().length() < 1) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_FV_NARRATIVE_FIELD_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (getStartDateTime().isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_FV_STARTDATETIME_FIELD_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (getEndDateTime().isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_FV_ENDDATETIME_FIELD_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  /**
   * Validates that all the field values held are valid with respect to each
   * other.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>{@link curam.message.HOMEVISITINTERVIEW#ERR_HOMEVISITINTERVIEW_XFV_STARTDATETIME_NOT_BEFORE_ENDDATETIME} -
   * If the Start Date Time is after the End Date Time.</li>
   * </ul>
   *
   */
  public void crossFieldValidation() {
    if (!getStartDateTime().before(getEndDateTime())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_XFV_STARTDATETIME_NOT_BEFORE_ENDDATETIME(
          getStartDateTime(), getEndDateTime()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * Validates that changes made to HomeVisitInterview entity on the database
   * are consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>{@link curam.message.HOMEVISITINTERVIEW#ERR_HOMEVISITINTERVIEW_XRV_CANNOT_UPDATE_IF_HOME_STUDY_APPROVED} -
   * If the home study is 'Approved', a home visit cannot be updated. </li>
   * <li>{@link curam.message.HOMEVISITINTERVIEW#ERR_HOMEVISITINTERVIEW_XRV_STARTDATETIME_ON_HOMESTUDYHOMEVISIT_DATE} -
   * If the Start Date Time is not on the related Home Visit Date. </li>
   * <li>{@link curam.message.HOMEVISITINTERVIEW#ERR_HOMEVISITINTERVIEW_XRV_ENDDATETIME_ON_HOMESTUDYHOMEVISIT_DATE} -
   * If the End Date Time, is on the related Home Visit Date. </li>
   * </ul>
   *
   */
  public void crossEntityValidation() {
    HomeStudy homeStudy = getHomeStudyHomeVisit().getHomeStudy();
    Date homeStudyHomeVisitDate = getHomeStudyHomeVisit().getDateOfVisit();

    // A home visit interview cannot be added, modified, or deleted if the
    // status of the home study has been set to 'Approved'.
    if (homeStudy != null
      && homeStudy.getLifecycleState().equals(HomeStudyStatusEntry.APPROVED)) {

      ValidationHelper.addValidationError(
        (HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_XRV_CANNOT_UPDATE_IF_HOME_STUDY_APPROVED()));
    }

    if (!new Date(getStartDateTime().getCalendar()).equals(
      homeStudyHomeVisitDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_XRV_STARTDATETIME_ON_HOMESTUDYHOMEVISIT_DATE(
          getStartDateTime(), homeStudyHomeVisitDate),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (!new Date(getEndDateTime().getCalendar()).equals(homeStudyHomeVisitDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        HOMEVISITINTERVIEWExceptionCreator.ERR_HOMEVISITINTERVIEW_XRV_ENDDATETIME_ON_HOMESTUDYHOMEVISIT_DATE(
          getEndDateTime(), homeStudyHomeVisitDate),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  /**
   * Inserts the Home Visit Interview. Checks the provider security.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS}
   * - If the provider is closed. Provider Details cannot be
   * updated.</li>
   */
  public void insert() throws InformationalException {
 
    // Add method security
    providerSecurity.checkProviderSecurity(
      homeStudyDAO.get(getHomeStudyHomeVisit().getHomeStudy().getID()).getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre insert home visit interview event.
    insertEventDispatcherFactory.get(HomeVisitInterviewInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    // if the status of the provider is closed
    if (getHomeStudyHomeVisit().getHomeStudy().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 17);
      ValidationHelper.failIfErrorsExist();
    }

    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert home visit interview event.
    insertEventDispatcherFactory.get(HomeVisitInterviewInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * Modifies the Home Visit Interview. Checks the provider security.
   *
   * @param versionNo
   * The version number.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.</li>
   */
  public void modify(Integer versionNo) throws InformationalException {

    // Checks the provider security.
    providerSecurity.checkProviderSecurity(
      homeStudyDAO.get(getHomeStudyHomeVisit().getHomeStudy().getID()).getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre modify home visit interview event.
    modifyEventDispatcherFactory.get(HomeVisitInterviewModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // if the status of the provider is closed
    if (getHomeStudyHomeVisit().getHomeStudy().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 18);
      ValidationHelper.failIfErrorsExist();
    }

    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify home visit interview event.
    modifyEventDispatcherFactory.get(HomeVisitInterviewModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  public RECORDSTATUSEntry getRecordStatus() {
    return RECORDSTATUSEntry.get(getDtls().recordStatus);
  }

  /**
   * {@inheritDoc}
   */
  public void setRecordStatus(RECORDSTATUSEntry value) {
    getDtls().recordStatus = value.getCode();
  }

  /**
   * Cancels the Home Visit Interview. Checks the provider security.
   *
   * @param versionNo
   * The version number.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.</li>
   */
  public void cancel(int versionNo) throws InformationalException {

    // Checks the provider security
    providerSecurity.checkProviderSecurity(
      homeStudyDAO.get(getHomeStudyHomeVisit().getHomeStudy().getID()).getProvider());

    // BEGIN, CR00235789, AK
    // Raise the pre cancel home visit interview event.
    cancelEventDispatcherFactory.get(HomeVisitInterviewCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    // if the status of the provider is closed
    if (getHomeStudyHomeVisit().getHomeStudy().getProvider().getLifecycleState().equals(
      ProviderStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 19);
      ValidationHelper.failIfErrorsExist();
    }

    super.cancel(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post cancel home visit interview event.
    cancelEventDispatcherFactory.get(HomeVisitInterviewCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Gets the from the date the home study was initiated and the home
   * visit interview was completed.
   *
   * @return the date range for the home visit interview
   */
  public DateRange getDateRange() {
    curam.homestudy.impl.HomeStudy homeStudy = homeStudyDAO.newInstance();

    return new DateRange(homeStudy.getDateInitiated(),
      new Date(getEndDateTime().getCalendar()));
  }

  /**
   * Sets the default values for the home visit interview.
   * <p>
   * Sets the type to home visit interview.
   * <p>
   * Sets the start <code>DateTime</code> and end <code>DateTime</code> to
   * same date as home study home visit.
   */
  public void setNewInstanceDefaults() {
    super.setNewInstanceDefaults();

    // type is always HOMEVISITINTERVIEW
    setType(HomeVisitInterviewTypeEntry.HOMEVISITINTERVIEW);
  }

  /**
   * {@inheritDoc}
   */
  public void setType(HomeVisitInterviewTypeEntry value) {
    getDtls().type = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setHomeStudyHomeVisit(HomeStudyHomeVisit homeStudyHomeVisit) {
    getDtls().homeStudyHomeVisitID = homeStudyHomeVisit.getID();
  }

  /**
   * {@inheritDoc}
   */
  public Set<InterviewAttendee> getInterviewAttendees() {
    return Collections.unmodifiableSet(
      interviewAttendeeDAO.searchByHomeVisitInterview(this));
  }

}
