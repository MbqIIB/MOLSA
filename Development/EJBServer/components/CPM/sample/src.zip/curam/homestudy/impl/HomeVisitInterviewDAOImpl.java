/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.homestudy.impl;


import java.util.Set;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.entity.impl.HomeVisitInterviewAdapter;
import curam.cpm.sl.entity.struct.HomeVisitInterviewDtls;
import curam.util.persistence.StandardDAOImpl;
import curam.util.persistence.helper.LifecycleHelper;


// BEGIN, CR00183213, SS
public class HomeVisitInterviewDAOImpl extends StandardDAOImpl<HomeVisitInterview, HomeVisitInterviewDtls> implements
  HomeVisitInterviewDAO {
  // END, CR00183213
  protected static final HomeVisitInterviewAdapter adapter = new HomeVisitInterviewAdapter();

  // _________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected HomeVisitInterviewDAOImpl() {
    // END, CR00183213
    super(adapter, HomeVisitInterview.class);
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<HomeVisitInterview> searchActiveByHomeStudyHomeVisit(
    HomeStudyHomeVisit parent) {
    Set<HomeVisitInterview> homeVisitInterviews = newSet(
      adapter.searchByHomeStudyHomeVisit(parent.getID()));

    return LifecycleHelper.filter(homeVisitInterviews, RECORDSTATUSEntry.NORMAL);
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<HomeVisitInterview> searchByHomeStudyHomeVisit(HomeStudyHomeVisit parent) {
    return newSet(adapter.searchByHomeStudyHomeVisit(parent.getID()));
  }

}
