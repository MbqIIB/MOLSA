/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.homestudy.impl;


import com.google.inject.ImplementedBy;

import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.Date;
import curam.util.type.DateRanged;


/**
 * A factor assessed as part of a home study conducted on a provider to verify
 * the condition of the facility or the suitability of the members of the home.
 * <p>
 * For example, <i>a fire inspection assessment is conducted on a provider home
 * as part of determining whether any safety hazards exist within the home</i>.
 */
@ImplementedBy(HomeStudyAssessmentImpl.class)
public interface HomeStudyAssessment extends HomeStudyAssessmentAccessor,
    Insertable, LogicallyDeleteable, Commented, OptimisticLockModifiable,
    DateRanged {

  // BEGIN, CR00144284, SK
  /**
   * Sets the assessment type.
   *
   * @param homeStudyAssessment
   * the home study assessment
   * @see curam.homestudy.impl.HomeStudyAssessmentTypeEntry
   */
  // END, CR00144284
  public void setAssessmentType(
    final HomeStudyAssessmentTypeEntry homeStudyAssessment);

  /**
   * Sets the date completed.
   *
   * @param date
   * the date completed
   */
  public void setDateCompleted(final Date date);

  /**
   * Sets whether corrective action is required.
   *
   * @param value
   * the corrective action required
   */
  public void setCorrectiveActionRequired(final boolean value);

  /**
   * Sets the description of the actions that must be undertaken to resolve the
   * conditions that resulted in an unsuccessful assessment.
   *
   * @param correctiveActionPlan
   * the corrective action plan.
   *
   * @see curam.homestudy.impl.HomeStudyAssessment#setCorrectiveActionPlan(String)
   * The default implementation -
   * curam.homestudy.impl.HomeStudyAssessmentImpl#setCorrectiveActionPlan(String).
   */
  public void setCorrectiveActionPlan(final String correctiveActionPlan);

  /**
   * Sets the result of the home study assessment.
   *
   * @param result
   * Result of the home study assessment.
   *
   * @see curam.homestudy.impl.HomeStudyAssessment#setResult(HomeStudyAssessmentResultEntry)
   * The default implementation -
   * curam.homestudy.impl.HomeStudyAssessmentImpl#setResult(HomeStudyAssessmentResultEntry).
   */
  public void setResult(final HomeStudyAssessmentResultEntry result);

  /**
   * Set the home study ID.
   *
   * @param homeStudy
   * the home study ID
   */
  public void setHomeStudy(HomeStudy homeStudy);

  // ___________________________________________________________________________
  /**
   * Gets the home study details.
   *
   * @return The Home Study details.
   *
   * @see curam.homestudy.impl.HomeStudy
   */
  public curam.homestudy.impl.HomeStudy getHomeStudy();

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the home study assessment events functionality surrounding the
   * insert method.
   */
  public interface HomeStudyAssessmentInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.homestudy.impl.HomeStudyAssessment#insert}
     *
     * @param homeStudyAssessment
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(HomeStudyAssessmentAccessor homeStudyAssessment)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.homestudy.impl.HomeStudyAssessment#insert}
     *
     * @param homeStudyAssessment
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(HomeStudyAssessmentAccessor homeStudyAssessment)
      throws InformationalException;
  }


  /**
   * Interface to the home study assessment events functionality surrounding the
   * cancel method.
   */
  public interface HomeStudyAssessmentCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.homestudy.impl.HomeStudyAssessment#cancel}
     *
     * @param homeStudyAssessment
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(HomeStudyAssessmentAccessor homeStudyAssessment,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.homestudy.impl.HomeStudyAssessment#cancel}
     *
     * @param homeStudyAssessment
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(HomeStudyAssessmentAccessor homeStudyAssessment,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the home study assessment events functionality surrounding the
   * modify method.
   */
  public interface HomeStudyAssessmentModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.homestudy.impl.HomeStudyAssessment#modify}
     *
     * @param homeStudyAssessment
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(HomeStudyAssessmentAccessor homeStudyAssessment,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.homestudy.impl.HomeStudyAssessment#modify}
     *
     * @param homeStudyAssessment
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(HomeStudyAssessmentAccessor homeStudyAssessment,
      Integer versionNo) throws InformationalException;
  }
  // END, CR00144381
}
