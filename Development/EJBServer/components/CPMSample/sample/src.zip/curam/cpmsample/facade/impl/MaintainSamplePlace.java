/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpmsample.facade.impl;


import com.google.inject.Inject;

import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.struct.PlaceAvailabilityDetailsList;
import curam.message.CPMCOMMONMESSAGES;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.place.impl.PlaceSearch;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderTypeNameEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.type.DateTimeRange;


/**
 * Sample facade layer class having API's for managing Place.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public abstract class MaintainSamplePlace extends curam.cpmsample.facade.base.MaintainSamplePlace {

  /**
   * Reference to PlaceSearch.
   */
  @Inject
  protected PlaceSearch placeSearch;

  /**
   * Reference to ProviderDAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to ServiceOfferingDAO.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Constructor for the class.
   *
   */
  public MaintainSamplePlace() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Searches available places for the input criteria specified.
   *
   * @param placeSearchDetails
   * Contains search criteria to search available places.
   *
   * @return List of available places with each provider.
   *
   * @throws InformationalException
   * {@link CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND} -
   * When search criteria entered is invalid.
   *
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public PlaceAvailabilityDetailsList searchAvailablePlaces(
    curam.cpmsample.facade.struct.PlaceSearchDetails placeSearchDetails) 
    throws AppException, InformationalException {

    PlaceAvailabilityDetailsList placeAvailabilityDetailsList = new PlaceAvailabilityDetailsList();

    Provider provider = null;
    ServiceOffering serviceOffering = null;
    ProviderTypeNameEntry providerType = null;

    DateTimeRange searchPeriod = new DateTimeRange(placeSearchDetails.fromDate,
      placeSearchDetails.toDate);

    if (placeSearchDetails.providerID != 0) {

      provider = providerDAO.get(placeSearchDetails.providerID);
      try {
        provider.getLifecycleState();
      } catch (Exception e) {
        ValidationHelper.addValidationError(
          CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND());
        ValidationHelper.failIfErrorsExist();
      }
    }

    if (placeSearchDetails.serviceOfferingID != 0) {
      serviceOffering = serviceOfferingDAO.get(
        placeSearchDetails.serviceOfferingID);
      try {
        serviceOffering.getLifecycleState();
      } catch (Exception e) {
        ValidationHelper.addValidationError(
          CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND());
        ValidationHelper.failIfErrorsExist();
      }
    }

    if (!placeSearchDetails.providerType.equals(CPMConstants.kEmptyString)) {
      providerType = ProviderTypeNameEntry.get(placeSearchDetails.providerType);
    }

    placeAvailabilityDetailsList = placeSearch.searchAvailablePlaces(provider,
      serviceOffering, providerType, searchPeriod);

    return placeAvailabilityDetailsList;
  }
}
