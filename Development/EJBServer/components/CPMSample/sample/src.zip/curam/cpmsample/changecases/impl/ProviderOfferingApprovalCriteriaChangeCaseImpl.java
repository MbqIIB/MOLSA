/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.cpmsample.changecases.impl;


import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.KeyVersionDetails;
import curam.cpm.impl.CPMConstants;
import curam.message.impl.PROVIDEROFFERINGAPPROVALExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;


// ___________________________________________________________________________
/**
 * Sample program to demonstrate how provider offering approval criteria
 * can be extended.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public class ProviderOfferingApprovalCriteriaChangeCaseImpl implements
  curam.providerservice.impl.ProviderOfferingApprovalCriteria {

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  @SuppressWarnings(CPMConstants.kUnused)
  public InformationalManager checkAccreditationApprovalCriteria(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {

    return null;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  @SuppressWarnings(CPMConstants.kUnused)
  public InformationalManager checkAdditionalApprovalCriteria(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {

    return null;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public InformationalMessageList checkApprovalCriteria(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();
    InformationalManager informationalManager = new InformationalManager();
    InformationalMessage infoMessage = new InformationalMessage();

    checkAccreditationApprovalCriteria(keyVersionDetails);

    checkAdditionalApprovalCriteria(keyVersionDetails);

    checkBackgroundApprovalCriteria(keyVersionDetails);

    checkHomeStudyApprovalCriteria(keyVersionDetails);

    checkLicenseApprovalCriteria(keyVersionDetails);
    
    // BEGIN CR00125992, MST
    checkTrainingApprovalCriteria(keyVersionDetails);
    // END CR00125992

    AppException message = PROVIDEROFFERINGAPPROVALExceptionCreator.ERR_PROVIDER_OFFERING_APPROVAL();

    informationalManager.addInformationalMsg(message, "",
      InformationalElement.InformationalType.kWarning);
    infoMessage.messageTest = informationalManager.obtainInformationalAsString()[0];

    informationalMessageList.dtls.addRef(infoMessage);

    return informationalMessageList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  @SuppressWarnings(CPMConstants.kUnused)
  public InformationalManager checkBackgroundApprovalCriteria(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {

    return null;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  @SuppressWarnings(CPMConstants.kUnused)
  public InformationalManager checkHomeStudyApprovalCriteria(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {

    return null;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  @SuppressWarnings(CPMConstants.kUnused)
  public InformationalManager checkLicenseApprovalCriteria(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {

    return null;
  }

  // BEGIN CR00125992, MST
  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  @SuppressWarnings(CPMConstants.kUnused)  
  public InformationalManager checkTrainingApprovalCriteria(
    KeyVersionDetails keyVersionDetails) throws AppException,
      InformationalException {
    
    return null;
  }
  // END CR00125992


}
