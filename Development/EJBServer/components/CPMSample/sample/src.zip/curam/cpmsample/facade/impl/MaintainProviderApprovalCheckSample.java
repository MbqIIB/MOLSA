/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpmsample.facade.impl;


import com.google.inject.Inject;
import curam.message.impl.PROVIDERAPPROVALCHECKSAMPLEExceptionCreator;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderApprovalCheck;
import curam.provider.impl.ProviderDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;


/**
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public abstract class MaintainProviderApprovalCheckSample extends curam.cpmsample.facade.base.MaintainProviderApprovalCheckSample {
  
  /**
   * Reference to provider approval check.
   */
  @Inject
  ProviderApprovalCheck providerApprovalCheck;

  /**
   * Reference to Provider DAO. 
   */  
  @Inject
  ProviderDAO providerDAO;  
  
  /**
   * Reference to Service Offering DAO. 
   */  
  @Inject
  ServiceOfferingDAO serviceOfferingDAO;
  
  /**
   * Constructor for the class.
   *
   */
  public MaintainProviderApprovalCheckSample() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  
  /**
   * Gets the approval check information for given approval check key.
   *
   * @param approvalCheckkey
   * Approval Check key containing service, provider and user
   * information.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECKSAMPLE#ERR_APPROVAL_IS_NOT_REQUIRED}
   * If the service delivery does not require approval.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECKSAMPLE#ERR_SERVICE_AND_USERNAME_MUST_BE_ENTERED}
   * If service and user are not specified.
   * @throws InformationalException
   * {@link curam.message.PROVIDERAPPROVALCHECKSAMPLE#ERR_APPROVAL_IS_REQUIRED}
   * If the service delivery requires approval.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public void getApprovalCheckInformation(
    curam.cpmsample.facade.struct.ApprovalCheckInformationKey approvalCheckkey)
    throws AppException,
      InformationalException {

    if (0 == approvalCheckkey.service
      || StringUtil.isNullOrEmpty(approvalCheckkey.userName)) {
      ValidationHelper.addValidationError(
        PROVIDERAPPROVALCHECKSAMPLEExceptionCreator.ERR_SERVICE_AND_USERNAME_MUST_BE_ENTERED());
      ValidationHelper.failIfErrorsExist();
    }

    boolean isApprovalRequired = false;

    Provider provider = providerDAO.get(approvalCheckkey.provider);
    ServiceOffering serviceOffering = serviceOfferingDAO.get(
      approvalCheckkey.service);

    if (0 == approvalCheckkey.provider && 0 != approvalCheckkey.service
      && !StringUtil.isNullOrEmpty(approvalCheckkey.userName)) {
      isApprovalRequired = providerApprovalCheck.getApprovalCheckInformation(
        null, serviceOffering, approvalCheckkey.userName);
    } else if (0 != approvalCheckkey.provider && 0 != approvalCheckkey.service
      && !StringUtil.isNullOrEmpty(approvalCheckkey.userName)) {
      isApprovalRequired = providerApprovalCheck.getApprovalCheckInformation(
        provider, serviceOffering, approvalCheckkey.userName);
    }

    if (isApprovalRequired) {
      ValidationHelper.addValidationError(
        PROVIDERAPPROVALCHECKSAMPLEExceptionCreator.ERR_APPROVAL_IS_REQUIRED());
    }

    if (!isApprovalRequired) {
      ValidationHelper.addValidationError(
        PROVIDERAPPROVALCHECKSAMPLEExceptionCreator.ERR_APPROVAL_IS_NOT_REQUIRED());
    }

    ValidationHelper.failIfErrorsExist();

  }
}
