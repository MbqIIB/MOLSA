/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpmsample.facade.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.LOCALEEntry;
import curam.cpm.sl.entity.struct.IndexedServiceOffering;
import curam.cpm.sl.entity.struct.IndexedServiceOfferings;
import curam.cpmsample.facade.struct.*;
import curam.taxonomy.impl.TAXONOMY_SEARCH_OPTIONSEntry;
import curam.taxonomy.sl.search.impl.TaxonomySearch;
import curam.taxonomy.sl.search.struct.ProviderServiceDetails;
import curam.taxonomy.sl.search.struct.RelatedConceptDetail;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;


/**
 * Class provides an API to search taxonomy terms based on different search
 * criteria.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public abstract class TaxonomyTermSearch extends curam.cpmsample.facade.base.TaxonomyTermSearch {

  /**
   * Reference to taxonomy search *
   */
  @Inject
  protected TaxonomySearch taxonomySearch;

  /**
   * Constructor which injects the dependent objects.
   *
   */
  public TaxonomyTermSearch() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Retrieves the taxonomy terms and related concepts based on search criteria
   * like Term Name, UseReference name and related concept name.
   *
   * @param searchKey
   * Term Name, UseReference name and related concept name along with
   * indicators whether all term,any term or partial term search.
   *
   * @return Matching taxonomy terms and related concepts along with number of
   * terms and related concepts.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public TaxonomySearchDetails search(final TaxonomySearchKey searchKey)
    throws AppException, InformationalException {
    String locale = getLocale().getCode();
    curam.taxonomy.sl.search.struct.TaxonomySearchDetails taxonomySearchDetails;
    TaxonomySearchDetails searchDetails = new TaxonomySearchDetails();

    taxonomySearchDetails = taxonomySearch.searchByKeywords(searchKey.name,
      locale, TAXONOMY_SEARCH_OPTIONSEntry.get(searchKey.searchCriteria));

    for (curam.taxonomy.sl.search.struct.TaxonomyTermDetail taxonomyTermDetail : taxonomySearchDetails.terms.term.items()) {
      taxonomyTermDetail.termName = taxonomyTermDetail.termName;
      searchDetails.search.terms.term.addRef(taxonomyTermDetail);

    }

    for (RelatedConceptDetail conceptDetail : taxonomySearchDetails.reltedConcepts.related.items()) {
      searchDetails.search.reltedConcepts.related.addRef(conceptDetail);
    }

    searchDetails.relatedConcept = taxonomySearchDetails.reltedConcepts.related.size();
    searchDetails.taxonomyTerm = taxonomySearchDetails.terms.term.size();
    return searchDetails;
  }

  /**
   * Retrieves the all provider details and service center details associated
   * with taxonomy term name.
   *
   * @param searchKey
   * Taxonomy Term Name.
   *
   * @return all provider details and service center details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public ProviderServiceDetails retrieveProviderService(TaxonomySearchKey key)
    throws AppException, InformationalException {
    String locale = getLocale().getCode();
    ProviderServiceDetails providerServiceDetails = taxonomySearch.retrieveProviderServices(
      key.name, locale);

    return providerServiceDetails;
  }

  /**
   * Retrieves the all taxonomy terms indexed with provider services
   *
   * @return List of indexed taxonomy terms along with compound indexed terms
   * also.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public TaxonomyTermDetails searchIndexedTerms() throws AppException,
      InformationalException {
    String locale = getLocale().getCode();
    TaxonomyTermDetails taxonomyTermDetails = new TaxonomyTermDetails();

    try {
      Set<String> indexedTerms = taxonomySearch.searchIndexedTerms(locale);

      for (String term : indexedTerms) {
        TaxonomyTermDetail detail = new TaxonomyTermDetail();

        detail.taxonomyTermName = term;
        taxonomyTermDetails.taxonomyTerm.addRef(detail);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }

    return taxonomyTermDetails;
  }

  /**
   * Retrieves non referral services indexed with taxonomy term names which
   * matches the searching text.
   *
   * @param searchKey
   * Contains the searching text which can be either related concept
   * name or UseReference name or taxonomy term name.
   *
   * @return List of Non-Referral services indexed with the taxonomy term names
   * which matched the searching text.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public IndexedServiceOfferings searchIndexedNonReferralServices(
    final TaxonomySearchKey searchKey) throws AppException,
      InformationalException {

    String locale = getLocale().getCode();
    IndexedServiceOfferings indexedServiceOfferingsList = new IndexedServiceOfferings();

    IndexedServiceOfferings indexedServiceOfferings = taxonomySearch.searchIndexedNonReferralServices(
      searchKey.name, locale);

    for (IndexedServiceOffering indexedServiceOffering : indexedServiceOfferings.dtls.items()) {
      indexedServiceOfferingsList.dtls.addRef(indexedServiceOffering);
    }

    return indexedServiceOfferingsList;
  }

  /**
   * Retrieves referral services indexed with taxonomy term names which matches
   * the searching text.
   *
   * @param searchKey
   * Contains the searching text which can be either related concept
   * name or UseReference name or taxonomy term name.
   *
   * @return List of Referral services indexed with the taxonomy term names
   * which matched the searching text.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public IndexedServiceOfferings searchIndexedReferralServices(
    final TaxonomySearchKey searchKey) throws AppException,
      InformationalException {
    String locale = getLocale().getCode();

    IndexedServiceOfferings indexedServiceOfferingsList = new IndexedServiceOfferings();
    IndexedServiceOfferings indexedServiceOfferings = taxonomySearch.searchIndexedReferralServices(
      searchKey.name, locale);

    for (IndexedServiceOffering indexedServiceOffering : indexedServiceOfferings.dtls.items()) {
      indexedServiceOfferingsList.dtls.addRef(indexedServiceOffering);
    }

    return indexedServiceOfferingsList;
  }

  /**
   * Gets the locale of the taxonomy.
   *
   * @return Locale of taxonomy.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  protected LOCALEEntry getLocale() {
    LOCALEEntry locale = LOCALEEntry.get(TransactionInfo.getProgramLocale());

    if (LOCALEEntry.ENGLISH_GB.equals(locale)
      || LOCALEEntry.ENGLISH_US.equals(locale)
      || LOCALEEntry.ENGLISH.equals(locale)) {
      return LOCALEEntry.ENGLISH;
    }

    return locale;
  }
}
