/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpmsample.facade.impl;


import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.cpm.sl.entity.struct.BackgroundCheckFailureReasonDtls;
import curam.cpm.sl.entity.struct.ProviderBackgroundCheckList;
import curam.provider.impl.BackgroundCheckFailureReason;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderBackgroundCheck;
import curam.provider.impl.ProviderBackgroundCheckDAO;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderMember;
import curam.provider.impl.ProviderPartyDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * Maintains provider member details along with back ground check
 * information for a provider.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public abstract class MaintainProviderMemberBackgroundCheckSample extends curam.cpmsample.facade.base.MaintainProviderMemberBackgroundCheckSample {

  /**
   * Reference to Provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to Provider Member.
   */
  @Inject
  protected ProviderMember providerMember;

  /**
   * Reference to Provider Background Check DAO.
   */
  @Inject
  protected ProviderBackgroundCheckDAO providerBackGroundCheckDAO;

  /**
   * Reference to Provider Party DAO.
   */
  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  /**
   * Constructor of the class.
   *
   */
  public MaintainProviderMemberBackgroundCheckSample() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Retrieves list of failure reasons for a back ground check result of status
   * failed.
   *
   * @param backGroundCheckDetails
   * Contains the background check identifier.
   *
   * @return List having failure reasons for a back ground check result of
   * status failed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public curam.cpmsample.facade.struct.BackGroundCheckFailureReasonList listBackGroundCheckFailureReasons(
    final curam.cpmsample.facade.struct.BackGroundCheckDetails backGroundCheckDetails) throws AppException,
      InformationalException {

    final ProviderBackgroundCheck providerBackGroundCheck = providerBackGroundCheckDAO.get(
      backGroundCheckDetails.backGroundCheck);

    final curam.cpmsample.facade.struct.BackGroundCheckFailureReasonList backGroundCheckFailureReasonList = new curam.cpmsample.facade.struct.BackGroundCheckFailureReasonList();

    final Set<BackgroundCheckFailureReason> backgroundCheckFailureReasons = providerMember.getBackgroundCheckFailureReasons(
      providerBackGroundCheck);

    for (final BackgroundCheckFailureReason backgroundCheckFailureReason : backgroundCheckFailureReasons) {

      BackgroundCheckFailureReasonDtls backgroundCheckFailureReasonDtls = new BackgroundCheckFailureReasonDtls();

      backgroundCheckFailureReasonDtls.failureReason = backgroundCheckFailureReason.getFailureReason();

      backgroundCheckFailureReasonDtls.occurrenceDate = backgroundCheckFailureReason.getOccurrenceDate();
      backgroundCheckFailureReasonDtls.recordStatus = backgroundCheckFailureReason.getLifecycleState().getCode();

      backGroundCheckFailureReasonList.dtls.addRef(
        backgroundCheckFailureReasonDtls);
    }

    return backGroundCheckFailureReasonList;
  }

  /**
   * Retrieves list of back ground checks of a provider member.
   *
   * @param providerPartyDetails
   * Contains the provider party identifier.
   *
   * @return List having all back ground checks of a provider member.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public ProviderBackgroundCheckList listBackGroundChecksForProviderMember(
    final curam.cpmsample.facade.struct.ProviderPartyDetails providerPartyDetails) 
    throws AppException, InformationalException {

    final curam.provider.impl.ProviderParty providerParty = providerPartyDAO.get(
      providerPartyDetails.providerPartyID);

    return providerMember.getProviderMemberBackGroundCheck(providerParty);
  }

  /**
   * Retrieves details for all members of a provider including back ground check
   * information.
   *
   * @param providerConcernRoleDetails
   * Concern role id of a provider for which details need to be retrieved.
   *
   * @return List having Provider members details with background check
   * information.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public curam.cpmsample.facade.struct.ProviderMembersBackgroundCheckList providerMemberBackGroundDetails(
    final curam.cpmsample.facade.struct.ProviderConcernRoleDetails providerConcernRoleDetails) throws AppException,
      InformationalException {

    final curam.cpmsample.facade.struct.ProviderMembersBackgroundCheckList providerMembersBackgroundCheckList = new curam.cpmsample.facade.struct.ProviderMembersBackgroundCheckList();

    final Provider provider = providerDAO.get(
      providerConcernRoleDetails.providerConcernRoleID);

    List<curam.cpm.sl.entity.struct.ProviderMembersBackgroundCheckDetails> providerMemberBackgroundCheckList = provider.readProviderMembersBackGroundCheckDetails();

    for (final curam.cpm.sl.entity.struct.ProviderMembersBackgroundCheckDetails providerMemberBackGroundCheckDetails : providerMemberBackgroundCheckList) {

      curam.cpmsample.facade.struct.ProviderMembersBackgroundCheckDetails providerMembersBackgroundCheckDetails = new curam.cpmsample.facade.struct.ProviderMembersBackgroundCheckDetails();

      providerMembersBackgroundCheckDetails.startDate = providerMemberBackGroundCheckDetails.startDate;
      providerMembersBackgroundCheckDetails.endDate = providerMemberBackGroundCheckDetails.endDate;
      providerMembersBackgroundCheckDetails.concernRoleName = providerMemberBackGroundCheckDetails.concernRoleName;
      providerMembersBackgroundCheckDetails.backgroundCheckInd = providerMemberBackGroundCheckDetails.backgroundCheckInd;
      providerMembersBackgroundCheckDetails.type = providerMemberBackGroundCheckDetails.type;
      providerMembersBackgroundCheckDetails.recordStatus = providerMemberBackGroundCheckDetails.recordStatus;
      providerMembersBackgroundCheckDetails.position = providerMemberBackGroundCheckDetails.position;
      providerMembersBackgroundCheckDetails.providerPartyID = providerMemberBackGroundCheckDetails.providerPartyID;

      providerMembersBackgroundCheckList.dtls.addRef(
        providerMembersBackgroundCheckDetails);

    }

    return providerMembersBackgroundCheckList;

  }

}
