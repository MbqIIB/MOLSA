/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpmsample.facade.impl;


import java.util.HashSet;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.CPMEVIDENCETYPEEntry;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRole;
import curam.core.struct.ConcernRoleDtls;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.SALIModificationReason;
import curam.cpm.facade.struct.ServiceAuthorizationLineItemDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.CloseServiceAuthorizationLineItemKey;
import curam.cpm.sl.entity.struct.ConcernRoleKey;
import curam.cpm.sl.entity.struct.ServiceAuthorizationKey;
import curam.cpm.sl.entity.struct.ServiceAuthorizationLineItemDtls;
import curam.cpm.sl.entity.struct.ServiceAuthorizationLineItemKey;
import curam.cpmsample.facade.struct.*;
import curam.financial.impl.ApplicableRateListener;
import curam.financial.impl.DeliveryEvidenceInformation;
import curam.cpm.util.impl.FrequencyPatternUtil;
import curam.cpm.util.impl.FrequencyPatternUtilImpl;
import curam.message.SERVICEAUTHORIZATION;
import curam.message.impl.ROSTERExceptionCreator;
import curam.message.impl.SAMPLESERVICEAUTHORIZATIONExceptionCreator;
import curam.message.impl.SERVICEAUTHORIZATIONExceptionCreator;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.casemanager.impl.CaseParticipantRoleDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderTypeNameEntry;
import curam.serviceauthorization.impl.ServiceAuthorization;
import curam.serviceauthorization.impl.ServiceAuthorizationDAO;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItem;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItemDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.InformationalElement.InformationalType;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.FrequencyPattern;


/**
 * This process class provides the functionality for services authorization
 * presentation layer.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public abstract class MaintainServiceAuthorization extends curam.cpmsample.facade.base.MaintainServiceAuthorization {

  @Inject
  protected ServiceAuthorizationDAO serviceAuthorizationDAO;

  @Inject
  protected ServiceAuthorizationLineItemDAO serviceAuthorizationLineItemDAO;

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  @Inject
  protected ServiceAuthorization serviceAuthorization;

  // BEGIN, CR00216897, RPB
  @Inject
  protected ApplicableRateListener applicableRateListener;
  // END, CR00216897

  // BEGIN, CR00154438, ABS
  /**
   * Reference to case participant role DAO.
   */
  @Inject
  protected CaseParticipantRoleDAO caseParticipantRoleDAO;
  // END, CR00154438

  /**
   * Constructor.
   *
   */
  public MaintainServiceAuthorization() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  protected final static int kZero = 0;

  /**
   * This method adds the service authorization line item.
   *
   * @param authorizationLineItemDetails
   * This contains service authorization line item details.
   * @return ServiceAuthorizationLineItemKey.
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  // BEGIN, CR00144022, ABS
  @Deprecated
  public ServiceAuthorizationLineItemKey addServiceAuthorizationLineItem(
    curam.cpmsample.facade.struct.ServiceAuthorizationLineItemDetails authorizationLineItemDetails)
    throws AppException, InformationalException {

    ServiceAuthorizationLineItemDetails details = assign(
      authorizationLineItemDetails);
    // END, CR00144022

    // Return Struct
    ServiceAuthorizationLineItemKey serviceAuthorizationLineItemKey = new ServiceAuthorizationLineItemKey();
    // Create instance of service authorization
    curam.serviceauthorization.impl.ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceAuthorizationLineItemDAO.newInstance();

    setAddServiceAuthorizationLineItemFields(serviceAuthorizationLineItem,
      details);
    serviceAuthorizationLineItem.insertServiceAuthorizationLineItem();
    serviceAuthorizationLineItemKey.serviceAuthorizationLIID = serviceAuthorizationLineItem.getID();
    return serviceAuthorizationLineItemKey;

  }

  /**
   * This method allow to modify the service authorization line item.
   *
   * @param authorizationLineItemDetails
   * This contains service authorization line item details.
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  // BEGIN, CR00144022, ABS
  @Deprecated
  public void updateServiceAuthorizationLineItem(
    curam.cpmsample.facade.struct.ServiceAuthorizationLineItemDetails authorizationLineItemDetails)
    throws AppException, InformationalException {

    ServiceAuthorizationLineItemDetails details = assign(
      authorizationLineItemDetails);
    // END, CR00144022
    // Create instance of service authorization
    curam.serviceauthorization.impl.ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceAuthorizationLineItemDAO.get(
      details.ServiceAuthorizationLineItemID);

    setUpdateServiceAuthorizationLineItemFields(serviceAuthorizationLineItem,
      details);
    SALIModificationReason sALIModificationReason = new SALIModificationReason();

    // BEGIN, CR00144495, SK
    sALIModificationReason = serviceAuthorizationLineItem.getServiceAuthorizationLineItemModificationReason();
    // END, CR00144495

    serviceAuthorizationLineItem.modifyServiceAuthorizationLineItem(
      sALIModificationReason);

  }

  /**
   * This method close the service authorization line item based on service
   * authorization line item key.
   *
   * @param key
   * service authorization line item key
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public void closeServiceAuthorizationLineItem(
    CloseServiceAuthorizationLineItemKey key) throws AppException,
      InformationalException {

    // Create instance of service authorization
    curam.serviceauthorization.impl.ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceAuthorizationLineItemDAO.get(
      key.serviceAuthorizationLineItemID);

    serviceAuthorizationLineItem.close(key.closeDate, key.versionNumber);

  }

  /**
   * This method allows to delete the service authorization based on service
   * authorization key.
   *
   * @param key
   * service authorization key
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public void deleteServceAuthorization(ServiceAuthorizationKey key)
    throws AppException, InformationalException {

    // Create instance of service authorization
    curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.get(
      key.serviceAuthorizationID);

    serviceAuthorization.cancel();

  }

  /**
   * This method allows to delete the service authorization line item based on
   * service authorization line item key.
   *
   * @param key
   * service authorization line item key
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public void deleteServiceAuthorizationLineItem(
    ServiceAuthorizationLineItemKey key) throws AppException,
      InformationalException {

    // Create instance of service authorization
    curam.serviceauthorization.impl.ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceAuthorizationLineItemDAO.get(
      key.serviceAuthorizationLIID);

    serviceAuthorizationLineItem.cancelServiceAuthorizationLineItem();

  }

  /**
   * Adds the voucher to the service authorization.
   *
   * @param voucherDetails
   * Contains voucher and service authorization details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public void addVoucherToServiceAuthorization(VoucherDetails voucherDetails)
    throws AppException, InformationalException {
    serviceAuthorization.addVoucherToServiceAuthorization(
      voucherDetails.serviceAuthorizationRefNo, voucherDetails.voucherNumber);
  }

  /**
   * Deletes the voucher to the service authorization.
   *
   * @param voucherDetails
   * Contains voucher and service authorization details.
   * @return List of information messages.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public InformationalMessageList deleteVoucher(VoucherDetails voucherDetails)
    throws AppException, InformationalException {
    // BEGIN CR00132916,KK
    InformationalMessageList informationalMessageList = new InformationalMessageList();

    // END CR00132916
    informationalMessageList = serviceAuthorization.deleteVoucherForServiceAuthorization(
      voucherDetails.serviceAuthorizationRefNo, voucherDetails.voucherNumber);
    // BEGIN CR00132916,KK
    return informationalMessageList;
    // END CR00132916

  }

  // BEGIN, CR00144022, ABS
  /**
   * Retrieves the participant type for the nominee.
   *
   * @param authorizationLineItemKey
   * Contains the service authorization line item ID.
   *
   * @return Participant type of the nominee.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public NomineeTypeDetails viewNomineeType(ServiceAuthorizationLineItemKey authorizationLineItemKey) 
    throws AppException, InformationalException {

    NomineeTypeDetails nomineeTypeDetails = new NomineeTypeDetails();

    ServiceAuthorizationLineItem authorizationLineItem = serviceAuthorizationLineItemDAO.get(
      authorizationLineItemKey.serviceAuthorizationLIID);

    // BEGIN, CR00144825, ABS
    if (authorizationLineItem.getNominee().concernRoleID != 0) {
      // END, CR00144825
      ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
      curam.core.struct.ConcernRoleKey concernRoleKey = new curam.core.struct.ConcernRoleKey();

      concernRoleKey.concernRoleID = authorizationLineItem.getNominee().concernRoleID;

      ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

      nomineeTypeDetails.nomineeType = concernRoleDtls.concernRoleType;
    }
    return nomineeTypeDetails;
  }

  /**
   * Creates the service authorization and service authorization line item based.
   *
   * @param serviceAuthorizationSALIDetails
   * Service authorization and line item details.
   *
   * @return ServiceAuthorizationKey Contains service authorization ID.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.Roster#ERR_ROSTER_LINE_ITEM_XRV_INVALID_SERVICE_AUTHORIZATION_REFERENCE_NUMBER}
   * If no service authorization reference number is incorrect.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public ServiceAuthorizationKey addSALIForSAWithFrequency(
    ServiceAuthorizationSALIDetails serviceAuthorizationSALIDetails)
    throws AppException, InformationalException {

    // Return Struct
    ServiceAuthorizationKey serviceAuthorizationKey = new ServiceAuthorizationKey();
    curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = null;

    serviceAuthorization = serviceAuthorizationDAO.findByReferenceNumber(
      serviceAuthorizationSALIDetails.saReferenceNumber);
    if (serviceAuthorization == null) {
      ValidationHelper.addValidationError(
        ROSTERExceptionCreator.ERR_ROSTER_LINE_ITEM_XRV_INVALID_SERVICE_AUTHORIZATION_REFERENCE_NUMBER(
          serviceAuthorizationSALIDetails.saReferenceNumber));
      ValidationHelper.failIfErrorsExist();
    }

    ServiceAuthorizationLineItemDtls authorizationLineItemDtls = setAddServiceAuthorizationLineItemDtls(
      serviceAuthorizationSALIDetails);

    FrequencyPattern frequencyPattern = FrequencyPattern.kZeroFrequencyPattern;
    // BEGIN, CR00273612, SSK
    // BEGIN, CR00280114, SSK
    FrequencyPatternUtil frequencyPatternUtil = new FrequencyPatternUtilImpl();
    // END, CR00280114
    Date anchorDate = serviceAuthorizationSALIDetails.saliDtls.fromDate;

    // END, CR00273612

    if (!StringUtil.isNullOrEmpty(
      serviceAuthorizationSALIDetails.saliGenerationFrequency)) {
      frequencyPattern = new FrequencyPattern(
        serviceAuthorizationSALIDetails.saliGenerationFrequency);
      
      // BEGIN, CR00273612, SSK
      // BEGIN, CR00280918, SSK
      anchorDate = frequencyPatternUtil.getAnchorDateAfterReferenceDate(
        serviceAuthorizationSALIDetails.saliDtls.fromDate, frequencyPattern);
      // END, CR00280918
    }
    
    serviceAuthorization.addSALIToSAUsingFrequencyAndAnchorDate(
      serviceAuthorization, frequencyPattern, authorizationLineItemDtls,
      anchorDate);
    // END, CR00273612
    serviceAuthorizationKey.serviceAuthorizationID = serviceAuthorization.getID();
    return serviceAuthorizationKey;

  }

  /**
   * This method creates the service authorization for the case participant role
   * ID.
   *
   * @param serviceAuthorizationCaseParticipantRoleKey
   * Case participant role key.
   *
   * @return ServiceAuthorizationKey Contains the ID of the service
   * authorization being created.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public ServiceAuthorizationKey createServiceAuthorization(
    SACaseParticipantRoleKey serviceAuthorizationCaseParticipantRoleKey)
    throws AppException, InformationalException {

    // BEGIN, CR00154438, ABS
    String[] caseParticipantRoleArray = serviceAuthorizationCaseParticipantRoleKey.caseParticipantRoleID.split(
      CPMConstants.kComma);

    ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.newInstance();

    Set<CaseParticipantRole> caseParticipantRoleList = new HashSet<CaseParticipantRole>();

    // BEGIN, CR00200143, RPB
    for (String caseParticipantRole : caseParticipantRoleArray) {
      Long caseParticipantRoleID = 0L;

      try {
        caseParticipantRoleID = Long.parseLong(caseParticipantRole);
      } catch (NumberFormatException e) {// Not doing anything as the default value will be taken.
      }
      // END, CR00200143

      caseParticipantRoleList.add(
        caseParticipantRoleDAO.get(caseParticipantRoleID));

    }
    serviceAuthorization.createServiceAuthorization(caseParticipantRoleList);

    ServiceAuthorizationKey serviceAuthorizationKey = new ServiceAuthorizationKey();

    // END, CR00154438

    serviceAuthorizationKey.serviceAuthorizationID = serviceAuthorization.getID();
    return serviceAuthorizationKey;
  }

  /**
   * Method assigns service authorization line item struct in the sample package
   * to service authorization line item details struct in CPM facade package.
   *
   * @param authorizationLineItemDetails
   * This contains service authorization line item details.
   * @return Service authorization line item details.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  protected ServiceAuthorizationLineItemDetails assign(
    curam.cpmsample.facade.struct.ServiceAuthorizationLineItemDetails authorizationLineItemDetails) {
    ServiceAuthorizationLineItemDetails details = new ServiceAuthorizationLineItemDetails();

    details.dateAdded = authorizationLineItemDetails.dateAdded;
    details.fromDate = authorizationLineItemDetails.fromDate;
    details.maximumUnitFrequency = authorizationLineItemDetails.maximumUnitFrequency;
    details.maximumUnits = authorizationLineItemDetails.maximumUnits;
    details.nomineeID = authorizationLineItemDetails.nomineeID;
    details.nomineeName = authorizationLineItemDetails.nomineeName;
    details.nomineeReference = authorizationLineItemDetails.nomineeReference;
    details.providerID = authorizationLineItemDetails.providerID;
    details.providerName = authorizationLineItemDetails.providerName;
    details.providerType = authorizationLineItemDetails.providerType;
    details.remainingUints = authorizationLineItemDetails.remainingUints;
    details.serviceAuthorizationID = authorizationLineItemDetails.serviceAuthorizationID;
    details.ServiceAuthorizationLineItemID = authorizationLineItemDetails.ServiceAuthorizationLineItemID;
    details.serviceID = authorizationLineItemDetails.serviceID;
    details.serviceName = authorizationLineItemDetails.serviceName;
    details.status = authorizationLineItemDetails.status;
    details.toDate = authorizationLineItemDetails.toDate;
    details.totalCost = authorizationLineItemDetails.totalCost;
    details.unitAmount = authorizationLineItemDetails.unitAmount;
    details.unitsAmountFixedInd = authorizationLineItemDetails.unitsAmountFixedInd;
    details.unitsAuthorized = authorizationLineItemDetails.unitsAuthorized;
    return details;
  }

  // END, CR00144022


  /**
   * Sets the service authorization line item details.
   *
   * @param serviceAuthorizationSALIDetails
   * Service authorization line item details.
   *
   * @return ServiceAuthorizationLineItemDtls Service authorization line item details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  protected ServiceAuthorizationLineItemDtls setAddServiceAuthorizationLineItemDtls(
    ServiceAuthorizationSALIDetails serviceAuthorizationSALIDetails)
    throws InformationalException, AppException {

    ServiceAuthorizationLineItemDtls authorizationLineItemDtls = new ServiceAuthorizationLineItemDtls();

    authorizationLineItemDtls.fromDate = serviceAuthorizationSALIDetails.saliDtls.fromDate;
    authorizationLineItemDtls.toDate = serviceAuthorizationSALIDetails.saliDtls.toDate;

    try {
      authorizationLineItemDtls.unitsAuthorized = Integer.parseInt(
        serviceAuthorizationSALIDetails.saliDtls.unitsAuthorized);
    } catch (Exception e) {
      ValidationHelper.addValidationError(
        new AppException(
          SERVICEAUTHORIZATION.ERR_SERVICERATE_FV_UNITSAUTHORIZED_INVALID, e));
    }
    long maximumUnits = 0;

    if (serviceAuthorizationSALIDetails.saliDtls.maximumUnits.length() > 0) {
      try {
        maximumUnits = Long.valueOf(
          serviceAuthorizationSALIDetails.saliDtls.maximumUnits);
      } catch (NumberFormatException e) {
        ValidationHelper.addValidationError(
          SERVICEAUTHORIZATIONExceptionCreator.ERR_SERVICERATE_FV_MAXUNITS_INVALID());
      }

      if (maximumUnits <= 0) {
        ValidationHelper.addValidationError(
          SERVICEAUTHORIZATIONExceptionCreator.ERR_SERVICERAUTHORIZATION_FV_MAX_UNITS_GT_ZERO());
      }
      authorizationLineItemDtls.maximumUnits = maximumUnits;
    }

    authorizationLineItemDtls.maximumUnitsFrequency = serviceAuthorizationSALIDetails.saliDtls.maximumUnitFrequency;
    authorizationLineItemDtls.nomineeID = serviceAuthorizationSALIDetails.saliDtls.nomineeID;
    authorizationLineItemDtls.providerID = serviceAuthorizationSALIDetails.saliDtls.providerID;
    authorizationLineItemDtls.providerType = serviceAuthorizationSALIDetails.saliDtls.providerType;
    authorizationLineItemDtls.serviceID = serviceAuthorizationSALIDetails.saliDtls.serviceID;
    authorizationLineItemDtls.unitAmount = serviceAuthorizationSALIDetails.saliDtls.unitAmount;
    authorizationLineItemDtls.unitAmountFixedInd = serviceAuthorizationSALIDetails.saliDtls.unitsAmountFixedInd;

    ValidationHelper.failIfErrorsExist();
    return authorizationLineItemDtls;

  }

  /**
   * This method sets the service authorization line item fields.
   *
   * @param serviceAuthorizationLineItem
   * Service authorization line item object.
   * @param serviceAuthorizationLineItemDetails
   * Service authorization line item details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  protected void setAddServiceAuthorizationLineItemFields(
    ServiceAuthorizationLineItem serviceAuthorizationLineItem,
    ServiceAuthorizationLineItemDetails serviceAuthorizationLineItemDetails)
    throws InformationalException, AppException {

    // Read service authorization details from service authorization entity
    final curam.serviceauthorization.impl.ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.get(
      serviceAuthorizationLineItemDetails.serviceAuthorizationID);

    serviceAuthorizationLineItem.setServiceAuthorization(serviceAuthorization);

    final Provider provider = serviceAuthorizationLineItemDetails.providerID
      == 0
        ? null
        : providerDAO.get(serviceAuthorizationLineItemDetails.providerID);

    // BEGIN, CR00116240, SSH
    final curam.cpm.sl.entity.struct.ConcernRoleKey concernRoleKey = new curam.cpm.sl.entity.struct.ConcernRoleKey();

    // END, CR00116240

    serviceAuthorizationLineItem.setProvider(provider);

    // BEGIN, CR00117445, SG
    // BEGIN, CR00126147, SG
    serviceAuthorizationLineItem.setProviderType(
      ProviderTypeNameEntry.get(
        serviceAuthorizationLineItemDetails.providerType));
    // END, CR00126147
    // END, CR00117445

    final ServiceOffering serviceOffering = serviceAuthorizationLineItemDetails.serviceID
      == 0
        ? null
        : serviceOfferingDAO.get(serviceAuthorizationLineItemDetails.serviceID);

    serviceAuthorizationLineItem.setServiceOffering(serviceOffering);

    if (serviceAuthorizationLineItemDetails.maximumUnits == null
      || serviceAuthorizationLineItemDetails.maximumUnits.equals("")
        && (serviceAuthorizationLineItemDetails.maximumUnitFrequency.length()
          > kZero)) {

      ValidationHelper.addValidationError(
        SERVICEAUTHORIZATIONExceptionCreator.ERR_SERVICERAUTHORIZATION_XFV_MAX_UNITS_EMPTY_MAX_UNIT_FREQUENCY_OPTION_SELECTED());
    }

    // Unit Amount Fixed Indicator is true and Unit cost is empty
    if (serviceAuthorizationLineItemDetails.unitAmount == null
      || serviceAuthorizationLineItemDetails.unitAmount.equals("")
        && (serviceAuthorizationLineItemDetails.unitsAmountFixedInd == true)) {
      ValidationHelper.addValidationError(
        SERVICEAUTHORIZATIONExceptionCreator.ERR_SERVICERAUTHORIZATION_XFV_UINTAMOUNT_MUST_BE_ENTER_IF_UINTAMOUNT_FIXED());
      ValidationHelper.failIfErrorsExist();
    }

    try {

      // BEGIN, CR00142003, ABS
      serviceAuthorizationLineItem.setUnitAmount(
        serviceAuthorizationLineItemDetails.unitAmount);
      // END, CR00142003

    } catch (Exception e) {
      ValidationHelper.addValidationError(
        new AppException(
          SERVICEAUTHORIZATION.ERR_SERVICERATE_FV_UNITSAMOUNT_INVALID, e));
    }
    // BEGIN, CR00186201, PS
    boolean unitsAuthorizedValid = true;

    // END, CR00186201
    try {
      serviceAuthorizationLineItem.setUnitsAuthorized(
        Integer.parseInt(serviceAuthorizationLineItemDetails.unitsAuthorized));
    } catch (Exception e) {
      ValidationHelper.addValidationError(
        new AppException(
          SERVICEAUTHORIZATION.ERR_SERVICERATE_FV_UNITSAUTHORIZED_INVALID, e));
      // BEGIN, CR00186201, PS
      unitsAuthorizedValid = false;
      // END, CR00186201
    }

    // BEGIN, CR00104259, JSP
    long maximumUnits = 0;

    if (serviceAuthorizationLineItemDetails.maximumUnits.length() > 0) {
      try {
        maximumUnits = Long.valueOf(
          serviceAuthorizationLineItemDetails.maximumUnits);
      } catch (NumberFormatException e) {
        ValidationHelper.addValidationError(
          SERVICEAUTHORIZATIONExceptionCreator.ERR_SERVICERATE_FV_MAXUNITS_INVALID());
      }

      if (maximumUnits <= 0) {
        ValidationHelper.addValidationError(
          SERVICEAUTHORIZATIONExceptionCreator.ERR_SERVICERAUTHORIZATION_FV_MAX_UNITS_GT_ZERO());
      }
      serviceAuthorizationLineItem.setMaximumUnits(maximumUnits);
    }
    // END, CR00104259

    // Calculate Total Cost
    // BEGIN, CR00186201, PS
    if ((serviceAuthorizationLineItemDetails.unitsAmountFixedInd == true)
      && (unitsAuthorizedValid == true)) {
      // END, CR00186201
      // BEGIN, CR00142003, ABS
      Double totalCost = serviceAuthorizationLineItemDetails.unitAmount.getValue()
        // END, CR00142003
        * Integer.parseInt(serviceAuthorizationLineItemDetails.unitsAuthorized);

      serviceAuthorizationLineItem.setTotalCost(
        new curam.util.type.Money(totalCost));
    }

    serviceAuthorizationLineItem.setMaximumUnitsFrequency(
      serviceAuthorizationLineItemDetails.maximumUnitFrequency);
    serviceAuthorizationLineItem.setUnitAmountFixed(
      serviceAuthorizationLineItemDetails.unitsAmountFixedInd);
    final DateRange dateRange = new DateRange(
      serviceAuthorizationLineItemDetails.fromDate,
      serviceAuthorizationLineItemDetails.toDate);

    serviceAuthorizationLineItem.setDateRange(dateRange);

    // BEGIN, CR00116240, SSH
    concernRoleKey.concernRoleID = serviceAuthorizationLineItemDetails.nomineeID;
    serviceAuthorizationLineItem.setNominee(concernRoleKey);
    // END, CR00116240
    // BEGIN, CR00104259, JSP
    ValidationHelper.failIfErrorsExist();
    // END, CR00104259

  }

  /**
   * This method sets the service authorization line item fields foe
   * modification.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  protected void setUpdateServiceAuthorizationLineItemFields(
    ServiceAuthorizationLineItem serviceAuthorizationLineItem,
    ServiceAuthorizationLineItemDetails details)
    throws InformationalException, AppException {

    // BEGIN, CR00118201, SSH
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // END, CR00118201
    try {
      if (details.unitAmount != null && (!details.unitAmount.equals(""))) {
        // BEGIN, CR00142003, ABS
        serviceAuthorizationLineItem.setUnitAmount(details.unitAmount);
        // END, CR00142003
      }
    } catch (Exception e) {
      ValidationHelper.addValidationError(
        new AppException(
          SERVICEAUTHORIZATION.ERR_SERVICERATE_FV_UNITSAMOUNT_INVALID, e));
    }

    try {
      serviceAuthorizationLineItem.setUnitsAuthorized(
        Integer.parseInt(details.unitsAuthorized));
    } catch (Exception e) {
      ValidationHelper.addValidationError(
        new AppException(
          SERVICEAUTHORIZATION.ERR_SERVICERATE_FV_UNITSAUTHORIZED_INVALID, e));
    }

    // Calculate Total Cost
    if (serviceAuthorizationLineItem.isUnitAmountFixed() == true) {
      ValidationHelper.failIfErrorsExist();
      // BEGIN, CR00142003, ABS
      Double totalCost = details.unitAmount.getValue()
        * Integer.parseInt(details.unitsAuthorized);

      // END, CR00142003

      serviceAuthorizationLineItem.setTotalCost(
        new curam.util.type.Money(totalCost));
    }
    // BEGIN, CR00118201, SSH
    concernRoleKey.concernRoleID = details.nomineeID;
    serviceAuthorizationLineItem.setNominee(concernRoleKey);
    // END, CR00118201
    serviceAuthorizationLineItem.setDateRange(
      new DateRange(details.fromDate, details.toDate));

  }

  // BEGIN, CR00216897, RPB
  /**
   * Triggers the reassessment for the details supplied by the user.
   *
   * @param reassessmentDetails
   * The reassessment details which contain placement ID, service
   * authorization line item ID and date range.
   *
   * @return The list of information messages.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public InformationalMessageList triggerReassessment(
    final ReassessmentDetails reassessmentDetails) throws AppException,
      InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    DateRange dateRange = new DateRange(reassessmentDetails.startDate,
      reassessmentDetails.endDate);

    if ((0 != reassessmentDetails.serviceAuthorizationLineItemID
      && 0 != reassessmentDetails.placementID)
        || (0 == reassessmentDetails.serviceAuthorizationLineItemID
          && 0 == reassessmentDetails.placementID)) {
      ValidationHelper.addValidationError(
        SAMPLESERVICEAUTHORIZATIONExceptionCreator.ERR_REASSESSMENT_EITHER_PLACEMENT_OR_SALI_ID_MUST_BE_ENTERED());
      ValidationHelper.failIfErrorsExist();
    }

    if (Date.kZeroDate.equals(reassessmentDetails.startDate)) {
      ValidationHelper.addValidationError(
        SAMPLESERVICEAUTHORIZATIONExceptionCreator.ERR_REASSESSMENT_START_DATE_MUST_BE_ENTERED());
      ValidationHelper.failIfErrorsExist();
    }

    if (0 != reassessmentDetails.serviceAuthorizationLineItemID) {
      ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceAuthorizationLineItemDAO.get(
        reassessmentDetails.serviceAuthorizationLineItemID);

      applicableRateListener.reAssess(serviceAuthorizationLineItem, dateRange);
    } else if (0 != reassessmentDetails.placementID) {
      DeliveryEvidenceInformation deliveryEvidenceInformation = new DeliveryEvidenceInformation(
        reassessmentDetails.placementID, CPMEVIDENCETYPEEntry.PLACEMENT);

      applicableRateListener.reAssess(deliveryEvidenceInformation, dateRange);
    }

    informationalManager.addInformationalMsg(
      SAMPLESERVICEAUTHORIZATIONExceptionCreator.INF_REASSESSMENT_TRIGGERED(),
      CuramConst.gkEmpty, InformationalType.kWarning);

    String warnings[] = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMessage infoMessage = new InformationalMessage();

      infoMessage.messageTest = warnings[i];
      informationalMessageList.dtls.addRef(infoMessage);
    }

    return informationalMessageList;
  }
  // END, CR00216897
}
