/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpmsample.changecases.impl;


import curam.cpm.impl.CPMConstants;
import curam.financial.impl.RuleBasedServiceRate;
import curam.provider.impl.Provider;
import curam.serviceoffering.impl.RateReader;
import curam.serviceoffering.impl.RateReaderImpl;
import curam.util.type.DateRange;
import curam.util.type.Money;
import java.util.HashSet;
import java.util.Set;


/**
 * Sample implementation of
 * {@linkplain curam.financial.impl.RuleBasedServiceRate}.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public class RuleBasedServiceRateChangeCase implements RuleBasedServiceRate {

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  @SuppressWarnings(CPMConstants.kUnused)
  public Set<RateReader> getRuleBasedServiceOfferingRates(
    Set<RateReader> rates, Provider provider, DateRange requirePeriod) {

    Set<RateReader> newRates = new HashSet<RateReader>();

    for (RateReader rate : rates) {
      newRates.add(getRateReader(rate));
    }

    return newRates;
  }

  /**
   * Creates and returns a new rate reader with modified minimum, maximum and
   * fixed amount.
   *
   * @param rateReader
   * Original Rate Reader to be copied.
   * @return RateReader Returns the newly created rate reader.
   */
  @Deprecated
  protected RateReader getRateReader(RateReader rateReader) {

    // set own customized values for minimum amount, maximum amount and fixed
    // amount
    return new RateReaderImpl(new Money(0.99), new Money(9.99), new Money(4.99),
      rateReader.getApplicablePeriod(), rateReader.getMinAmountPaymentOption(),
      rateReader.getMaxAmountPaymentOption(),
      rateReader.getFixedAmountPaymentOption(), rateReader.isProviderRate(),
      rateReader.getServiceRateID(), rateReader.getProviderRateID(),
      rateReader.getPaymentOptionID());
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Deprecated
  public Set<RateReader> getRuleBasedServiceOfferingRatesForReassessment(
    Set<RateReader> rates, Provider provider, DateRange requirePeriod) {
    return getRuleBasedServiceOfferingRates(rates, provider, requirePeriod);
  }

}
