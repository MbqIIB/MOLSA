/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.cpmsample.changecases.impl;


import curam.codetable.impl.PRODUCTCOVERPERIODEntry;
import curam.contracts.impl.ContractVersion;
import curam.contracts.impl.FlatRateContractCoverPatternStrategy;
import curam.cpm.impl.CPMConstants;


/**
 * This sample program is used for demonstrating that the
 * determination of cover period pattern can be changed.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public class FlatRateContractCoverPatternChangeCaseImpl
  implements FlatRateContractCoverPatternStrategy {

  // _________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  @SuppressWarnings(CPMConstants.kUnused)
  public PRODUCTCOVERPERIODEntry determineCoverPattern(ContractVersion contractVersion) {

    return PRODUCTCOVERPERIODEntry.ISSUEINADVANCE;
  }

}
