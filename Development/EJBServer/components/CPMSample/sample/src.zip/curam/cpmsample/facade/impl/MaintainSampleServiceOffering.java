/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpmsample.facade.impl;


import com.google.inject.Inject;

import curam.cpm.sl.entity.struct.ServiceOfferingDtls;
import curam.cpm.sl.entity.struct.ServiceOfferingReference;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * Sample facade layer class having API's for managing Service Offering.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public class MaintainSampleServiceOffering extends curam.cpmsample.facade.base.MaintainSampleServiceOffering {

  /**
   * Reference to service offering DAO.
   */
  @Inject
  ServiceOfferingDAO serviceOfferingDAO;
  
  /**
   * Constructor for the class.
   *
   */
  public MaintainSampleServiceOffering() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  
  /**
   * Retrieves the service offering details for reference entered by the user.
   *
   * @param referenceKey
   * The reference ID for the service offering.
   *
   * @return The service offering details.
   *
   * @throws InformationalException                    
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public ServiceOfferingDtls retrieveServiceOfferingByReference(
    ServiceOfferingReference referenceKey) throws AppException,
      InformationalException {
    ServiceOffering serviceOffering = serviceOfferingDAO.newInstance();
    ServiceOfferingDtls serviceOfferingDtls = new ServiceOfferingDtls();

    serviceOffering = serviceOffering.retrieveServiceOfferingByReference(
      referenceKey.referenceUpper);
    serviceOfferingDtls.serviceOfferingID = serviceOffering.getID();
    serviceOfferingDtls.name = serviceOffering.getName();
    serviceOfferingDtls.reference = serviceOffering.getReference();
    serviceOfferingDtls.startDate = serviceOffering.getDateRange().start();
    serviceOfferingDtls.endDate = serviceOffering.getDateRange().end();
    serviceOfferingDtls.comments = serviceOffering.getComments();
    serviceOfferingDtls.deliveryFrequency = serviceOffering.getDeliveryFrequency();
    serviceOfferingDtls.unitFrequency = serviceOffering.getUnitFrequency().getCode();
    serviceOfferingDtls.unitOfMeasure = serviceOffering.getUnitOfMeasure().getCode();
    serviceOfferingDtls.maximumUnits = serviceOffering.getMaximumUnits();
    return serviceOfferingDtls;
  }

}
