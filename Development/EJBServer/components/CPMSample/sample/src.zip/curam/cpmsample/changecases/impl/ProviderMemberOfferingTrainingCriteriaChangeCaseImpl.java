/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpmsample.changecases.impl;


import com.google.inject.Inject;
import curam.codetable.impl.TRAININGPROGRAMPARTYSTATUSEntry;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.message.impl.PROVIDERMEMBEROFFERINGExceptionCreator;
import curam.provider.impl.ProviderMember;
import curam.provider.impl.ProviderMemberOfferingTrainingCriteria;
import curam.provider.impl.TrainingCompletionEntry;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.serviceoffering.impl.SOTrainingRequirement;
import curam.serviceoffering.impl.SOTrainingRequirementDAO;
import curam.training.impl.TrainingProgramMember;
import curam.training.impl.TrainingProgramMemberDAO;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.type.StringHelper;
import java.util.Set;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ProviderMemberOfferingTrainingCriteria}.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
final public class ProviderMemberOfferingTrainingCriteriaChangeCaseImpl 
  implements ProviderMemberOfferingTrainingCriteria {

  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  @Inject
  protected SOTrainingRequirementDAO soTrainingRequirementDAO;
  
  @Inject
  protected TrainingProgramMemberDAO trainingProgramMemberDAO;
  
  /**
   * Constructor
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public ProviderMemberOfferingTrainingCriteriaChangeCaseImpl() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */  
  @Deprecated
  public InformationalMessageList checkProviderMemberTrainingProgram(
    String providerOfferings, ProviderMember providerMember) 
    throws InformationalException {
    
    InformationalMessageList informationalMessageList = new InformationalMessageList();
    
    final String[] providerOfferingIDs = StringUtil.tabText2StringList(providerOfferings).items();
    
    StringBuffer servicesRequiredTraining = new StringBuffer();
    
    boolean trainingRequired = false;
    
    // For each provider offering create a provider member offering record
    for (final String providerOfferingString : providerOfferingIDs) {
      
      ProviderOffering providerOffering = providerOfferingDAO.get(
        Long.parseLong(providerOfferingString));
      
      trainingRequired = false;
      
      // Loop through all the training requirements for the service offering and 
      // check whether the provider member has member training program of status 
      // COMPLETE or WAIVED.
      for (SOTrainingRequirement soTrainingRequirement : soTrainingRequirementDAO.searchBy(
        providerOffering.getServiceOffering())) {
        
        Set<TrainingProgramMember> trainingProgramMembers = null;
        
        if (!soTrainingRequirement.getCompletion().equals(
          TrainingCompletionEntry.REQUIRED)) {
          continue;
        }
        
        if (providerMember.getParty() != null) {
          trainingProgramMembers = trainingProgramMemberDAO.getTrainingProgramsForParty(
            soTrainingRequirement.getTraining().getID(), 
            providerMember.getParty().getID());
        }
        
        if (trainingProgramMembers == null || trainingProgramMembers.isEmpty()) {
          
          trainingRequired = true;
          break;
        }
        
        for (TrainingProgramMember trainingProgramMember : 
          trainingProgramMembers) {
          
          if (!(trainingProgramMember.getLifecycleState().equals(
            TRAININGPROGRAMPARTYSTATUSEntry.COMPLETE)
              || trainingProgramMember.getLifecycleState().equals(
                TRAININGPROGRAMPARTYSTATUSEntry.WAIVED))) {
            
            trainingRequired = true;
            break;
          }
        }
      }
      
      if (trainingRequired) {
        
        if (StringHelper.isEmpty(servicesRequiredTraining.toString())) {
          servicesRequiredTraining.append(
            providerOffering.getServiceOffering().getName());
          
        } else {
          servicesRequiredTraining.append(GeneralConstants.kComma);
          servicesRequiredTraining.append(GeneralConstants.kSpace);
          servicesRequiredTraining.append(
            providerOffering.getServiceOffering().getName());
        }
      }
      
    }
    
    if (!StringHelper.isEmpty(servicesRequiredTraining.toString())) {
      ValidationHelper.addValidationError(
        PROVIDERMEMBEROFFERINGExceptionCreator.ERR_PROVIDERMEMBEROFFERING_XRV_PROVIDERMEMBER_HAS_TO_MEET_TRAINING_REQUIREMENTS(
          providerMember.getParty().getName(), 
          servicesRequiredTraining.toString()));
      
    }
    
    ValidationHelper.failIfErrorsExist();
    
    return informationalMessageList;
  }

}
