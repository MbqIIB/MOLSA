/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpmsample.facade.impl;


import com.google.inject.Inject;

import curam.cpm.sl.entity.struct.ServiceGroupDtls;
import curam.cpm.sl.entity.struct.ServiceGroupReference;
import curam.serviceoffering.impl.ServiceGroup;
import curam.serviceoffering.impl.ServiceGroupDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * Sample facade layer class having API's for managing Service Offering.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public class MaintainSampleServiceGroup extends curam.cpmsample.facade.base.MaintainSampleServiceGroup {

  /**
   * Reference to service offering DAO.
   */
  @Inject
  ServiceGroupDAO serviceGroupDAO;
  
  /**
   * Constructor for the class.
   *
   */
  public MaintainSampleServiceGroup() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  
  /**
   * Retrieves the service group details for reference entered by the user.
   *
   * @param referenceKey
   * The reference ID for the service group.
   *
   * @return The service group details.
   *
   * @throws InformationalException                    
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public ServiceGroupDtls retrieveServiceGroupByReference(
    ServiceGroupReference referenceKey) throws AppException,
      InformationalException {
    ServiceGroup serviceGroup = serviceGroupDAO.newInstance();
    ServiceGroupDtls serviceGroupDtls = new ServiceGroupDtls();

    serviceGroup = serviceGroup.retrieveServiceGroupByReference(
      referenceKey.referenceUpper);
    serviceGroupDtls.serviceGroupID = serviceGroup.getID();
    serviceGroupDtls.reference = serviceGroup.getReference();
    serviceGroupDtls.comments = serviceGroup.getComments();
    serviceGroupDtls.description = serviceGroup.getDescription();
    serviceGroupDtls.name = serviceGroup.getName();

    return serviceGroupDtls;
  }

}
