/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpmsample.facade.impl;


import com.google.inject.Inject;
import curam.cpm.sl.struct.RetrieveFacilityInformationDtlsList;
import curam.place.impl.FacilityInformation;
import curam.provider.impl.CPMProviderTypeNameEntry;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.StringUtil;
import curam.util.type.Date;


/**
 * Class maintains the facility information for a provider.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public class MaintainFacilityInformation extends curam.cpmsample.facade.base.MaintainFacilityInformation {

  /**
   * Reference to facility information object.
   */
  @Inject
  protected FacilityInformation facilityInformationObj;

  /**
   * Reference to Provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to Service Offering DAO.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Constructor for the class.
   */
  public MaintainFacilityInformation() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Retrieves the facility information for the input criteria. Facility
   * information can be retrieved either for a Provider, Service Offering
   * provided by the provider or Provider Type. This can be searched for a
   * particular input search date.
   *
   * @param key
   * Contains the input retrieval criteria.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public RetrieveFacilityInformationDtlsList retrieveFacilityInformation(
    curam.cpmsample.facade.struct.RetrieveFacilityInformationKey key) throws AppException,
      InformationalException {

    Provider provider = null;
    ServiceOffering serviceOffering = null;
    CPMProviderTypeNameEntry providerType = CPMProviderTypeNameEntry.NOT_SPECIFIED;

    if (key.providerConcernRoleID != 0) {
      provider = providerDAO.get(key.providerConcernRoleID);
    }

    if (key.serviceOfferingID != 0) {
      serviceOffering = serviceOfferingDAO.get(key.serviceOfferingID);
    }

    if (!StringUtil.isNullOrEmpty(key.providerType)) {
      providerType = CPMProviderTypeNameEntry.get(key.providerType);
    }

    Date searchDate = key.searchDate;

    return facilityInformationObj.retrieveFacilityInformation(provider,
      serviceOffering, providerType, searchDate);

  }

}
