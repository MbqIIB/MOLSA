/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpmsample.changecases.impl;


import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.cpm.facade.struct.LicenseProviderAndVersionNumberKey;
import curam.cpm.impl.CPMConstants;
import curam.message.impl.TRAININGPROGRAMExceptionCreator;
import curam.provider.impl.LicenseApprovalCriteria;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.LicenseApprovalCriteria}.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public class LicenseApprovalCriteriaChangeCaseImpl implements
  LicenseApprovalCriteria {

  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  @SuppressWarnings(CPMConstants.kUnused)
  public InformationalMessageList checkLicenseApprovalCriteria(
    LicenseProviderAndVersionNumberKey licenseProviderAndVersionNumberKey)
    throws InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    InformationalMessageList informationalMessageList = new InformationalMessageList();

    informationalManager.addInformationalMsg(
      TRAININGPROGRAMExceptionCreator.ERR_TRAININGPROGRAM_XRV_LICENSE_CANNOT_BE_APPROVED(),
      curam.core.impl.CuramConst.gkEmpty,
      InformationalElement.InformationalType.kWarning);
    
    // Assign informational messages to return struct
    String warnings[] = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMessage infoMessage = new InformationalMessage();

      infoMessage.messageTest = warnings[i];
      informationalMessageList.dtls.addRef(infoMessage);
    }
  
    return informationalMessageList;
  }

}
