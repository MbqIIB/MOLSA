/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpmsample.changecases.impl;


import curam.attendance.impl.DetermineRosterSubmissionDueDate;
import curam.attendance.impl.Roster;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;


/**
 * Sample program to demonstrate that determination of submission due date for a
 * roster can be changed.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public class RosterSubmissionDueDateChangeCaseImpl implements
  DetermineRosterSubmissionDueDate {

  // BEGIN, CR00187438, SK
  /**
   * Constructor for the class.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */  
  @Deprecated
  protected RosterSubmissionDueDateChangeCaseImpl() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00187438
  
  /**
   * Method to determine the submission due date for a roster. This
   * implementation adds thirty days to the roster end date.
   *
   * @param roster
   * Contains the roster details.
   * @return Submission due date for the roster.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public Date determineRosterSubmissionDueDate(Roster roster)
    throws AppException, InformationalException {

    // submission due date returned as roster end date + 30 days
    return roster.getDateRange().end().addDays(30);
  }

}
