/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpmsample.facade.impl;


import java.util.List;

import com.google.inject.Inject;

import curam.cpm.facade.struct.ProviderReservationKey;
import curam.cpm.facade.struct.ReservationConfirmDetails;
import curam.cpm.facade.struct.ReservationDetails;
import curam.message.impl.RESERVATIONExceptionCreator;
import curam.place.impl.Place;
import curam.place.impl.PlaceDAO;
import curam.place.impl.Placement;
import curam.place.impl.PlacementDAO;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.reservation.impl.Reservation;
import curam.reservation.impl.ReservationDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.type.DateTimeRange;


/**
 * Facade Layer class having API for managing Reservations for UOCPM.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public abstract class MaintainSampleReservation extends curam.cpmsample.facade.base.MaintainSampleReservation {

  @Inject
  protected ReservationDAO reservationDAO;
  
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;
  
  @Inject
  protected ProviderDAO providerDAO;
  
  @Inject 
  protected PlaceDAO placeDAO;
  
  @Inject
  protected PlacementDAO placementDAO;

  // ___________________________________________________________________________
  /**
   * Constructor.
   *
   */
  public MaintainSampleReservation() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * @param details
   * Contains the details of Reservation to be created.
   * @return ProviderReservationKey having the Reservation ID and Provider ID.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public ProviderReservationKey createReservation(ReservationDetails details)
    throws AppException, InformationalException {

    DateTimeRange reservationPeriod = new DateTimeRange(
      details.details.fromDate, details.details.toDate);
    Reservation reservation = reservationDAO.newInstance();
    Provider provider = validateProviderID(details.providerID);
    ServiceOffering serviceOffering = validateServiceOfferingID(
      details.serviceOfferingID);
    Place place = validatePlaceID(details.details.placeID);
   
    // BEGIN , CR00138106, VR
    // Added the expected to date to the API
    reservation = reservation.createReservation(
      details.details.caseParticipantRoleID, serviceOffering, provider,
      reservationPeriod, details.details.unitAmount,
      details.details.unitAmountFixedIndicator, place,
      details.createWithoutPlaceIndicator, details.details.comments);
    // END , CR00138106

    ProviderReservationKey providerReservationKey = new ProviderReservationKey();

    providerReservationKey.reservationID = reservation.getID();
    providerReservationKey.providerID = details.providerID;

    return providerReservationKey;
  }
  
  /**
   * Validate ID passed and returns an instance of ServiceOffering
   *
   * @param serviceOfferingID
   * Contains service Offering ID
   * @return serviceOffering
   * Contains serviceOffering instance
   * @throws InformationalException
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  protected ServiceOffering validateServiceOfferingID(long serviceOfferingID) 
    throws InformationalException {
    ServiceOffering serviceOffering = null;

    try {
      if (serviceOfferingID != 0) {
        serviceOffering = serviceOfferingDAO.get(serviceOfferingID);
      } else {
        ValidationHelper.addValidationError(
          RESERVATIONExceptionCreator.ERR_RESERVATION_FV_SERVICEOFFERING_ID_IS_MANDATORY());
        ValidationHelper.failIfErrorsExist();
      }
      serviceOffering.getLifecycleState();
    } catch (RecordNotFoundException e) {
      ValidationHelper.addValidationError(
        RESERVATIONExceptionCreator.ERR_RESERVATION_FV_SERVICEOFFERING_IS_INVALID());
      ValidationHelper.failIfErrorsExist();
    }
    return serviceOffering;
    
  }
  
  /**
   * Validate provider
   * @param ProviderID
   * contains provider ID
   * @return Provider
   * contains provider 
   * @throws InformationalException
   */
  @Deprecated
  protected Provider validateProviderID(long ProviderID) throws InformationalException {
    Provider provider = null;

    try {
      if (ProviderID != 0) {
        provider = providerDAO.get(ProviderID);
      } else {
        ValidationHelper.addValidationError(
          RESERVATIONExceptionCreator.ERR_RESERVATION_FV_PROVIDER_ID_IS_MANDATORY());
        ValidationHelper.failIfErrorsExist();
      }
      provider.getLifecycleState();
    } catch (RecordNotFoundException e) {
      ValidationHelper.addValidationError(
        RESERVATIONExceptionCreator.ERR_RESERVATION_FV_PROVIDERID_IS_INVALID());
      ValidationHelper.failIfErrorsExist();
    }
    return provider;
    
  }
  
  /**
   * Validate ID passed and returns an instance of place
   *
   * @param placeID
   * Contains place ID
   * @return Place
   * Contains Place instance
   * @throws InformationalException
   */
  @Deprecated
  protected Place validatePlaceID(long placeID) throws InformationalException {
    Place place = null;
  
    if (placeID != 0) {
      try {
        place = placeDAO.get(placeID);
        place.getLifecycleState();
      } catch (RecordNotFoundException e) {
        ValidationHelper.addValidationError(
          RESERVATIONExceptionCreator.ERR_RESERVATION_FV_PLACE_ID_IS_INVALID());
        ValidationHelper.failIfErrorsExist();
      }
    } 
     
    return place;
    
  }
  
  // BEGIN, CR00154949, AK
  /**
   * Confirms the reservation as placement.
   *
   * @param reservationConfirmDetails
   * Reservation confirm details.
   * @return ReservationConfirmDetails Reservation confirm details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Deprecated
  public ReservationConfirmDetails confirmReservation(
    ReservationConfirmDetails reservationConfirmDetails) throws AppException,
      InformationalException {

    Placement placement = placementDAO.newInstance();
    Reservation reservation = reservationDAO.get(
      reservationConfirmDetails.reservationID);

    Placement overlappingPlacement = placement.getOverlappingPlacementForClient(
      reservation.getCaseParticipantRoleID(),
      new DateTimeRange(reservationConfirmDetails.from,
      reservationConfirmDetails.to));

    if (overlappingPlacement != null) {
      reservationConfirmDetails.updateOverlappingPlacementPeriodInd = true;
    }

    // If there are no overlapping placements, then confirm the reservation
    if (!reservationConfirmDetails.updateOverlappingPlacementPeriodInd) {
      
      Place place = validatePlaceID(reservationConfirmDetails.placeID);

      reservation.confirmPlacement(place,
        new DateTimeRange(reservationConfirmDetails.from,
        reservationConfirmDetails.to),
        reservationConfirmDetails.versionNo,
        reservationConfirmDetails.updateOverlappingPlacementPeriodInd,
        reservationConfirmDetails.cancelExistingReservations,
        reservationConfirmDetails.comments,
        reservationConfirmDetails.activeReservationDtls.cancelActiveReservationInd);
    }

    // Retrieve the list of reservations overlapping with the
    // placement period
    List<Reservation> overlappingReservations = reservationDAO.searchOverlappingReservationsForClient(
      reservation, reservation.getDateTimeRange());

    if (overlappingReservations.size() != 0) {
      reservationConfirmDetails.cancelExistingReservations = true;
    }

    return reservationConfirmDetails;
  }
  // END, CR00154949
 
}
