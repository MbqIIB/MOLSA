/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpmsample.facade.impl;


import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import com.google.inject.Inject;

import curam.attendance.impl.AbsencePeriod;
import curam.attendance.impl.AttendanceConfigurationHelper;
import curam.attendance.impl.AttendanceInformationProcessing;
import curam.attendance.impl.DailyAttendance;
import curam.attendance.impl.ProviderRosterLineItem;
import curam.attendance.impl.ProviderRosterLineItemDAO;
import curam.attendance.impl.SOAttendanceConfiguration;
import curam.attendance.impl.SOAttendanceConfigurationDAO;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.facade.struct.AbsenceDetails;
import curam.cpm.facade.struct.AbsenceDetailsList;
import curam.cpm.facade.struct.DailyAttendanceDetails;
import curam.cpm.facade.struct.DailyAttendanceDetailsList;
import curam.cpm.facade.struct.ViewDailyAttendanceDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.ProviderRosterLineItemKey;
import curam.cpm.util.impl.WidgetHelper;
import curam.participant.person.impl.PersonDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;


/**
 * Facade Layer class having API for managing attendance tracking for UOCPM.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public abstract class MaintainSampleAttendance extends curam.cpmsample.facade.base.MaintainSampleAttendance {

  /**
   * ProviderRosterLineItem DAO reference.
   */
  @Inject
  protected ProviderRosterLineItemDAO providerRosterLineItemDAO;

  /**
   * AttendanceInformationProcessing reference.
   */
  @Inject
  protected AttendanceInformationProcessing attendanceInformationProcessing;

  /**
   * SOAttendanceConfiguration DAO object
   */
  @Inject
  protected SOAttendanceConfigurationDAO sOAttendanceConfigurationDAO;
  
  /**
   * Person DAO reference.
   */
  @Inject
  protected PersonDAO personDAO;

  // BEGIN, CR00176474, AS
  // BEGIN, CR00178377, AS
  /**
   * Reference to Attendance Configuration Helper.
   */
  @Inject
  protected AttendanceConfigurationHelper attendanceConfigurationHelper;
  // END, CR00178377
  // END, CR00176474
  
  /**
   * Constructor.
   *
   */
  public MaintainSampleAttendance() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Returns all roster line items which are 'Denied' or 'Canceled' are not
   * considered for a client. All the roster line items for the case including
   * those in exception processing, if exception process indicator set true are
   * returned. If the period has been specified by UoCPM, all roster line items
   * for which the Service From date is later than or equal to the From date
   * specified by UoCPM and the Service To date is earlier than or equal to the
   * To date specified by UoCPM are returned.
   *
   * @param searchDetails
   * Contains the person,service from date,service to date and
   * exception process indicator.
   * @return list of attendance details,includes roster line item details,roster
   * and service authorization details.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public curam.cpmsample.facade.struct.AttendanceDetailsList getAttendanceInformationForClient(
    curam.cpmsample.facade.struct.SearchAttendanceInformationDetails searchDetails) throws AppException,
      InformationalException {

    curam.cpmsample.facade.struct.AttendanceDetailsList attendanceDetailsList = new curam.cpmsample.facade.struct.AttendanceDetailsList();
    Set<ProviderRosterLineItem> ProviderRosterLineItems = attendanceInformationProcessing.getRosterLineItemsForClient(
      personDAO.get(searchDetails.clientID), searchDetails.serviceFrom,
      searchDetails.serviceTo, searchDetails.exceptionProcInd);

    for (ProviderRosterLineItem providerRosterLineItem : ProviderRosterLineItems) {

      curam.cpmsample.facade.struct.AttendanceDetails attendanceDetails = new curam.cpmsample.facade.struct.AttendanceDetails();

      attendanceDetails.providerName = providerRosterLineItem.getProvider().getName();
      attendanceDetails.serviceOfferingName = providerRosterLineItem.getServiceOfferingName();
      attendanceDetails.prliDetails.providerRosterLineItemDtls.saReferenceNo = providerRosterLineItem.getSAReferenceNo();
      attendanceDetails.prliDetails.providerRosterLineItemDtls.voucherNumber = providerRosterLineItem.getVoucherNumber();
      attendanceDetails.prliDetails.rosterLineItemDtls.serviceFrom = providerRosterLineItem.getServiceDateFrom();
      attendanceDetails.prliDetails.rosterLineItemDtls.serviceTo = providerRosterLineItem.getServiceDateTo();
      // BEGIN, CR00176474, AS
      // BEGIN, CR00178377, AS
      if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
        || attendanceConfigurationHelper.isReportingMethodUtilization(
          providerRosterLineItem.getRoster())) {
        // END, CR00178377
        attendanceDetails.prliDetails.rosterLineItemDtls.expectedUnits = providerRosterLineItem.getExpectedUnits();
        attendanceDetails.prliDetails.rosterLineItemDtls.totalUnitsDelivered = providerRosterLineItem.getUnitsDelivered();
      }
      // END, CR00176474
      attendanceDetails.prliDetails.providerRosterLineItemDtls.providerRosterLineItemID = providerRosterLineItem.getID();
      attendanceDetails.prliDetails.clientName = providerRosterLineItem.getClientName();
      
      // Setting the indicator for displaying daily Attendance details.
      attendanceDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
        providerRosterLineItem);
      attendanceDetailsList.detailList.addRef(attendanceDetails);
    }

    return attendanceDetailsList;
  }

  /**
   * Returns all roster line items which are 'Denied' or 'Canceled' are not
   * considered for a case. All the roster line items for the case including
   * those in exception processing, if exception process indicator set true are
   * returned. If the period has been specified by UoCPM, all roster line items
   * for which the Service From date is later than or equal to the From date
   * specified by UoCPM and the Service To date is earlier than or equal to the
   * To date specified by UoCPM are returned.
   *
   * @param searchDetails
   * Contains the person,service from date,service to date and
   * exception process indicator.
   * @return list of attendance details,includes roster line item details,roster
   * and service authorization details.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public curam.cpmsample.facade.struct.AttendanceDetailsList getAttendanceInformationForCase(
    curam.cpmsample.facade.struct.SearchAttendanceInformationDetails searchDetails) throws AppException,
      InformationalException {

    curam.cpmsample.facade.struct.AttendanceDetailsList attendanceDetailsList = new curam.cpmsample.facade.struct.AttendanceDetailsList();

    Set<ProviderRosterLineItem> ProviderRosterLineItems = attendanceInformationProcessing.getRosterLineItemsForCase(
      searchDetails.caseReferenceNumber, searchDetails.serviceFrom,
      searchDetails.serviceTo, searchDetails.exceptionProcInd);

    for (ProviderRosterLineItem providerRosterLineItem : ProviderRosterLineItems) {
      curam.cpmsample.facade.struct.AttendanceDetails attendanceDetails = new curam.cpmsample.facade.struct.AttendanceDetails();

      attendanceDetails.providerName = providerRosterLineItem.getProvider().getName();
      attendanceDetails.serviceOfferingName = providerRosterLineItem.getServiceOfferingName();
      attendanceDetails.prliDetails.providerRosterLineItemDtls.saReferenceNo = providerRosterLineItem.getSAReferenceNo();
      attendanceDetails.prliDetails.providerRosterLineItemDtls.voucherNumber = providerRosterLineItem.getVoucherNumber();
      attendanceDetails.prliDetails.rosterLineItemDtls.serviceFrom = providerRosterLineItem.getServiceDateFrom();
      attendanceDetails.prliDetails.rosterLineItemDtls.serviceTo = providerRosterLineItem.getServiceDateTo();
      // BEGIN, CR00176474, AS
      // BEGIN, CR00178377, AS
      if (!attendanceConfigurationHelper.isAttendanceTypeReportingEnabled()
        || attendanceConfigurationHelper.isReportingMethodUtilization(
          providerRosterLineItem.getRoster())) {
        // END, CR00178377
        attendanceDetails.prliDetails.rosterLineItemDtls.expectedUnits = providerRosterLineItem.getExpectedUnits();
        attendanceDetails.prliDetails.rosterLineItemDtls.totalUnitsDelivered = providerRosterLineItem.getUnitsDelivered();
      }
      // END, CR00176474
      attendanceDetails.prliDetails.providerRosterLineItemDtls.providerRosterLineItemID = providerRosterLineItem.getID();
      attendanceDetails.prliDetails.clientName = providerRosterLineItem.getClientName();
      
      // Setting the indicator for displaying daily Attendance details.
      attendanceDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
        providerRosterLineItem);
      attendanceDetailsList.detailList.addRef(attendanceDetails);
    }
    
    return attendanceDetailsList;
  }

  /**
   * Returns the list of daily attendance associated with the roster line item.
   *
   * @param key
   * Contains the roster line item key.
   *
   * @return List of daily attendance associated with roster line item.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public ViewDailyAttendanceDetails viewDailyAttendance(
    ProviderRosterLineItemKey key) throws AppException,
      InformationalException {

    ViewDailyAttendanceDetails viewDailyAttendanceDetails = new ViewDailyAttendanceDetails();
    DailyAttendanceDetailsList dailyAttendanceDetailsList = new DailyAttendanceDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      key.providerRosterLineItemID);

    // Populate the details of the roster line item.
    viewDailyAttendanceDetails.fromDate = providerRosterLineItem.getServiceDateFrom();
    viewDailyAttendanceDetails.toDate = providerRosterLineItem.getServiceDateTo();
    if (providerRosterLineItem.getClient() != null) {
      viewDailyAttendanceDetails.clientName = providerRosterLineItem.getClient().getName();
    }

    Set<curam.attendance.impl.DailyAttendance> unModifiableDailyAttendanceList = providerRosterLineItem.getDailyAttendances();
    Set<curam.attendance.impl.DailyAttendance> dailyAttendanceList = new HashSet<curam.attendance.impl.DailyAttendance>();

    dailyAttendanceList.addAll(unModifiableDailyAttendanceList);

    Locale locale = new Locale(TransactionInfo.getProgramLocale());
    DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG, locale);

    // Populate the list of daily attendance details for a specified roster
    // line
    // item.
    for (curam.attendance.impl.DailyAttendance dailyAttendance : sortDailyAttendanceByServiceDate(
      dailyAttendanceList)) {

      if (RECORDSTATUSEntry.NORMAL.equals(dailyAttendance.getStatus())) {
        DailyAttendanceDetails dailyAttendanceDetails = new DailyAttendanceDetails();
        java.util.Date serviceDate = new java.util.Date(
          dailyAttendance.getServiceDate().asLong());
        String formattedServiceDate = dateFormat.format(serviceDate);

        dailyAttendanceDetails.serviceDateString = formattedServiceDate;
        dailyAttendanceDetails.dtls.attendance = dailyAttendance.getAttendance().getCode();
        dailyAttendanceDetails.dtls.absenceReason = dailyAttendance.getAbsenceReason().getCode();
        if (dailyAttendance.getExpectedUnits() == 0) {
          dailyAttendanceDetails.expectedUnitsString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceDetails.expectedUnitsString = String.valueOf(
            dailyAttendance.getExpectedUnits());
        }
        if (dailyAttendance.getUnitsAttended() == 0) {
          dailyAttendanceDetails.unitsAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceDetails.unitsAttendedString = String.valueOf(
            dailyAttendance.getUnitsAttended());
        }
        if (dailyAttendance.getUnitsUnattended() == 0) {
          dailyAttendanceDetails.unitsUnAttendedString = CPMConstants.kEmptyString;
        } else {
          dailyAttendanceDetails.unitsUnAttendedString = String.valueOf(
            dailyAttendance.getUnitsUnattended());
        }
        dailyAttendanceDetails.dtls.dailyAttendanceID = dailyAttendance.getID();
        dailyAttendanceDetails.dtls.versionNo = dailyAttendance.getVersionNo();
        dailyAttendanceDetails.dtls.rosterLineItemID = dailyAttendance.getRosterLineItem();

        dailyAttendanceDetailsList.details.addRef(dailyAttendanceDetails);
        viewDailyAttendanceDetails.detailsList.details.addRef(
          dailyAttendanceDetails);
      }
    }

    // Setting the indicator for displaying daily Attendance details.
    viewDailyAttendanceDetails.dailyAttendanceLinkInd = isDailyAttendanceConfigured(
      providerRosterLineItem);

    // Convert the list of daily attendance details to an xml. This xml is
    // the
    // input to the widget to display the list of daily attendance details.
    viewDailyAttendanceDetails.dailyAttendanceDetails = WidgetHelper.convertDailyAttendanceToXml(
      dailyAttendanceDetailsList);

    return viewDailyAttendanceDetails;
  }

  /**
   * Returns the actual amount paid against the roster line item.
   *
   * @param key
   * Contains the roster line item key.
   * @return details contains the actual amount paid.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public curam.cpmsample.facade.struct.ProviderRosterLineItemAmuontDetails getActualAmountPaid(
    ProviderRosterLineItemKey key) throws AppException,
      InformationalException {

    curam.cpmsample.facade.struct.ProviderRosterLineItemAmuontDetails providerRosterLineItemAmuontDetails = new curam.cpmsample.facade.struct.ProviderRosterLineItemAmuontDetails();

    try {
      ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
        key.providerRosterLineItemID);

      providerRosterLineItemAmuontDetails.actualAmountPaid = providerRosterLineItem.getActualAmountPaid().toString();
    } catch (RecordNotFoundException rnfe) {
      // throw alternative error message
      throw new AppException(
        curam.message.ROSTER.ERR_ROSTER_LINE_ITEM_XRV_NO_MATCHING_ROSTER_LINE_ITEM);
    }
    return providerRosterLineItemAmuontDetails;
  }
  
  /**
   * Lists all the absence details for a specified provider roster line item.
   *
   * @param providerRosterLineItemKey
   * Contains provider roster line item id.
   * @return List of all the absence details.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public AbsenceDetailsList viewAbsencePeriod(
    ProviderRosterLineItemKey providerRosterLineItemKey) throws AppException,
      InformationalException {

    AbsenceDetailsList absenceDetailsList = new AbsenceDetailsList();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemKey.providerRosterLineItemID);

    Set<curam.attendance.impl.AbsencePeriod> unModifiableAbsencePeriodList = providerRosterLineItem.getAbsencePeriod();
    Set<curam.attendance.impl.AbsencePeriod> absencePeriodList = new HashSet<curam.attendance.impl.AbsencePeriod>();

    absencePeriodList.addAll(unModifiableAbsencePeriodList);
    
    // Populate the absencePeriod details to the list.
    for (curam.attendance.impl.AbsencePeriod absencePeriod : sortAbsenceByServiceDate(
      absencePeriodList)) {

      if (RECORDSTATUSEntry.NORMAL.equals(absencePeriod.getStatus())) {
        AbsenceDetails absenceDetails = new AbsenceDetails();

        absenceDetails.dtls.absenceReason = absencePeriod.getAbsenceReason().getCode();
        absenceDetails.dtls.unitsUnattended = absencePeriod.getUnitsUnattended();
        absenceDetails.dtls.absenceDate = absencePeriod.getAbsenceDate();
        absenceDetails.dtls.absencePeriodID = absencePeriod.getDtls().absencePeriodID;
        absenceDetailsList.details.addRef(absenceDetails);
      }
    }
    return absenceDetailsList;
  }

  /**
   * Sorts a set of daily attendance records by service date.
   *
   * @param unsortedDailyAttendance
   * The list of unsorted daily attendance.
   * @return A sorted list of daily attendance.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  protected ArrayList<DailyAttendance> sortDailyAttendanceByServiceDate(
    final Set<DailyAttendance> unsortedDailyAttendance) {

    // Sort by position for display
    final ArrayList<DailyAttendance> dailyAttendanceList = new ArrayList<DailyAttendance>(
      unsortedDailyAttendance);

    Collections.sort(dailyAttendanceList, new Comparator<DailyAttendance>() {
      public int compare(final DailyAttendance lhs, DailyAttendance rhs) {

        return lhs.getServiceDate().compareTo(rhs.getServiceDate());
      }
    });
    return dailyAttendanceList;
  }
  
  /**
   * Checks whether the daily attendance tracking is required for the service
   * associated with the provider roster line item.
   *
   * @param providerRosterLineItem
   * Provider roster line item for which the daily attendance tracking
   * configuration is to be determined.
   * @return True if daily attendance tracking is required and false otherwise.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  protected boolean isDailyAttendanceConfigured(
    ProviderRosterLineItem providerRosterLineItem) throws AppException,
      InformationalException {

    ServiceOffering serviceOffering = providerRosterLineItem.getRoster().getServiceOffering();
    SOAttendanceConfiguration attendanceConfiguration = sOAttendanceConfigurationDAO.searchByServiceOfferingAndDate(
      serviceOffering, providerRosterLineItem.getRoster().getDateGenerated());

    if (attendanceConfiguration != null) {
      return attendanceConfiguration.isDailyAttendanceTrackingRequired();
    }
    return false;
  }
  
  /**
   * Sorts a set of absencePeriods by absence date.
   *
   * @param unsortedAbsenceList
   * The list of unsorted absencePeriod records.
   * @return A sorted list of absence records.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  protected ArrayList<AbsencePeriod> sortAbsenceByServiceDate(
    final Set<AbsencePeriod> unsortedAbsenceList) {

    // Sort by position for display
    final ArrayList<AbsencePeriod> absenceList = new ArrayList<AbsencePeriod>(
      unsortedAbsenceList);

    Collections.sort(absenceList, new Comparator<AbsencePeriod>() {
      public int compare(final AbsencePeriod lhs, AbsencePeriod rhs) {

        return lhs.getAbsenceDate().compareTo(rhs.getAbsenceDate());
      }
    });
    return absenceList;
  }
}
