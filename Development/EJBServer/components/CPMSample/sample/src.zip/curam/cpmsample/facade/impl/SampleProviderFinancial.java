/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpmsample.facade.impl;


import com.google.inject.Inject;
import curam.attendance.impl.ProviderRosterLineItem;
import curam.attendance.impl.ProviderRosterLineItemDAO;
import curam.attendance.impl.SOAttendanceConfiguration;
import curam.cpm.facade.struct.SOAttendanceConfigurationDetails;
import curam.cpm.facade.struct.SOAttendanceConfigurationDetailsList;
import curam.cpm.sl.entity.struct.ServiceAuthorizationKey;
import curam.cpmsample.facade.struct.*;
import curam.financial.impl.FinancialAPI;
import curam.financial.impl.PaymentInformation;
import curam.financial.impl.ServiceInvoiceLineItem;
import curam.financial.impl.ServiceInvoiceLineItemDAO;
import curam.message.CPMCOMMONMESSAGES;
import curam.message.impl.CPMCOMMONMESSAGESExceptionCreator;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.ProviderDAO;
import curam.serviceauthorization.impl.ServiceAuthorizationDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import java.util.List;
import java.util.Set;


/**
 * Facade Layer class having API for managing Provider Financial.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public class SampleProviderFinancial extends curam.cpmsample.facade.base.SampleProviderFinancial {

  /**
   * Inject Service Group DAO
   */
  @Inject
  protected FinancialAPI financialAPI;

  /**
   * Service Offering DAO
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Service Offering DAO
   */
  @Inject
  protected ServiceAuthorizationDAO serviceAuthorizationDAO;

  @Inject
  protected ProviderRosterLineItem providerRosterLineItem;

  @Inject
  protected ServiceInvoiceLineItem serviceInvoiceLineItem;

  @Inject
  protected ServiceInvoiceLineItemDAO serviceInvoiceLineItemDAO;

  @Inject
  protected ProviderRosterLineItemDAO providerRosterLineItemDAO;
  
  // BEGIN CR00120521, MST
  @Inject
  protected ProviderDAO providerDAO;
  
  @Inject
  protected ConcernRoleDAO concernRoleDAO;
  // END CR00120521

  // ___________________________________________________________________________
  /**
   * Constructor
   *
   */
  public SampleProviderFinancial() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Retrieves Payment Information based on Case.
   *
   * @param paymentInformationInputDetails
   * Contains payment information input details.
   * @return PaymentInformationDetailsList Contains payment details.
   * @throws InformationalException
   * {@link CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND} -
   * If no records are found in the search.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public PaymentInformationDetailsList retrievePaymentInformationForCase(
    PaymentInformationInputDetails paymentInformationInputDetails)
    throws AppException, InformationalException {

    PaymentInformationDetailsList paymentInformationDetailsList = new PaymentInformationDetailsList();
    ServiceOffering serviceOffering = null;

    if (paymentInformationInputDetails.serviceOfferingID != 0) {
      serviceOffering = serviceOfferingDAO.get(
        paymentInformationInputDetails.serviceOfferingID);
    }
    Set<PaymentInformation> paymentInformationSet = financialAPI.retrievePaymentInformation(
      paymentInformationInputDetails.caseID,
      paymentInformationInputDetails.clientID, serviceOffering);

    for (PaymentInformation paymentInformation : paymentInformationSet) {
      PaymentInformationDetails paymentInformationDetails = new PaymentInformationDetails();

      paymentInformationDetails.amountInvoiced = paymentInformation.getAmountInvoiced();
      paymentInformationDetails.amountPaid = paymentInformation.getAmountPaid();
      paymentInformationDetails.clientID = paymentInformation.getClientID();
      paymentInformationDetails.numberOfUnits = new Long(paymentInformation.getNumberOfUnits()).intValue();
      paymentInformationDetails.paymentFromDate = paymentInformation.getPaymentPeriod().start();
      paymentInformationDetails.paymentToDate = paymentInformation.getPaymentPeriod().end();
      paymentInformationDetails.providerID = paymentInformation.getProviderID();
      paymentInformationDetails.serviceOfferingID = paymentInformation.getServiceOfferingID();
      
      // BEGIN CR00120521, MST
      if (paymentInformation.getProviderID() != 0) {
        paymentInformationDetails.providerName = providerDAO.get(paymentInformation.getProviderID()).getName();
      }
      if (paymentInformation.getClientID() != 0) {
        paymentInformationDetails.clientName = concernRoleDAO.get(paymentInformation.getClientID()).getName();
      }
      if (paymentInformation.getServiceOfferingID() != 0) {
        paymentInformationDetails.serviceOfferingName = serviceOfferingDAO.get(paymentInformation.getServiceOfferingID()).getName();
      }
      // END CR00120521

      paymentInformationDetailsList.paymentDetails.addRef(
        paymentInformationDetails);
    }
    if (paymentInformationDetailsList.paymentDetails.isEmpty()) {
      ValidationHelper.addValidationError(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND());
      ValidationHelper.failIfErrorsExist();
    }
    return paymentInformationDetailsList;
  }

  /**
   * Retrieves Payment Information based on Service Authorization.
   *
   * @param serviceAuthorizationKey
   * Contains service Authorization ID.
   * @return PaymentInformationDetailsList Contains payment details.
   * @throws InformationalException
   * {@link CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND} -
   * If no records are found in the search.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public PaymentInformationDetailsList retrievePaymentInformationForServiceAuthorization(
    ServiceAuthorizationKey serviceAuthorizationKey) throws AppException,
      InformationalException {
    PaymentInformationDetailsList paymentInformationDetailsList = new PaymentInformationDetailsList();

    Set<PaymentInformation> paymentInformationSet = financialAPI.retrievePaymentInformation(
      serviceAuthorizationDAO.get(
        serviceAuthorizationKey.serviceAuthorizationID));

    for (PaymentInformation paymentInformation : paymentInformationSet) {
      PaymentInformationDetails paymentInformationDetails = new PaymentInformationDetails();

      paymentInformationDetails.amountInvoiced = paymentInformation.getAmountInvoiced();
      paymentInformationDetails.amountPaid = paymentInformation.getAmountPaid();
      paymentInformationDetails.clientID = paymentInformation.getClientID();
      paymentInformationDetails.numberOfUnits = new Long(paymentInformation.getNumberOfUnits()).intValue();
      paymentInformationDetails.paymentFromDate = paymentInformation.getPaymentPeriod().start();
      paymentInformationDetails.paymentToDate = paymentInformation.getPaymentPeriod().end();
      paymentInformationDetails.providerID = paymentInformation.getProviderID();
      paymentInformationDetails.serviceOfferingID = paymentInformation.getServiceOfferingID();
      // BEGIN CR00120521, MST
      if (paymentInformation.getProviderID() != 0) {
        paymentInformationDetails.providerName = providerDAO.get(paymentInformation.getProviderID()).getName();
      }
      if (paymentInformation.getClientID() != 0) {
        paymentInformationDetails.clientName = concernRoleDAO.get(paymentInformation.getClientID()).getName();
      }
      if (paymentInformation.getServiceOfferingID() != 0) {
        paymentInformationDetails.serviceOfferingName = serviceOfferingDAO.get(paymentInformation.getServiceOfferingID()).getName();
      }
      // END CR00120521

      paymentInformationDetailsList.paymentDetails.addRef(
        paymentInformationDetails);
    }
    if (paymentInformationDetailsList.paymentDetails.isEmpty()) {
      ValidationHelper.addValidationError(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND());
      ValidationHelper.failIfErrorsExist();
    }
    return paymentInformationDetailsList;
  }

  /**
   * Retrieves Service Delivery Summary Information.
   *
   * @param paymentInformationInputDetails
   * Contains payment information input details.
   * @return ServiceDeliverySummaryInformation Contains Service Delivery Summary
   * Information.
   * @throws InformationalException
   * {@link CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND} -
   * If no records are found in the search.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public ServiceDeliverySummaryInformation retrieveServiceDeliverySummaryInformation(
    PaymentInformationInputDetails paymentInformationInputDetails)
    throws AppException, InformationalException {
    ServiceDeliverySummaryInformation serviceDeliverySummaryInformationDtls = new ServiceDeliverySummaryInformation();

    ServiceOffering serviceOffering = null;

    if (paymentInformationInputDetails.serviceOfferingID != 0) {
      serviceOffering = serviceOfferingDAO.get(
        paymentInformationInputDetails.serviceOfferingID);
    }
    curam.financial.impl.ServiceDeliverySummaryInformation serviceDeliverySummaryInformation = financialAPI.retrieveServiceDeliverySummaryInformation(
      serviceOffering, paymentInformationInputDetails.caseparticipantRoleID);

    serviceDeliverySummaryInformationDtls.firstServiceDeliveryDate = serviceDeliverySummaryInformation.getFirstServiceDeliveryDate();
    serviceDeliverySummaryInformationDtls.lastServiceDeliveryDate = serviceDeliverySummaryInformation.getLastServiceDeliveryDate();
    serviceDeliverySummaryInformationDtls.totalNumberOfUnitsConsumed = serviceDeliverySummaryInformation.getTotalNumberOfUnitsConsumed();
    if (serviceDeliverySummaryInformationDtls.firstServiceDeliveryDate.isZero()
      && serviceDeliverySummaryInformationDtls.lastServiceDeliveryDate.isZero()
      && serviceDeliverySummaryInformationDtls.totalNumberOfUnitsConsumed == 0) {

      ValidationHelper.addValidationError(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND());
      ValidationHelper.failIfErrorsExist();
    }
    return serviceDeliverySummaryInformationDtls;
  }

  /**
   * Retrieves Utilization Information.
   *
   * @param paymentInformationInputDetails
   * Contains payment information input details.
   * @return ServiceDeliverySummaryInformation Contains Service Delivery Summary
   * Information.
   * @throws InformationalException
   * {@link CPMCOMMONMESSAGES#ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND} -
   * If no records are found in the search.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public ServiceDeliverySummaryInformation retrieveUtilizationInformation(
    PaymentInformationInputDetails paymentInformationInputDetails)
    throws AppException, InformationalException {

    ServiceDeliverySummaryInformation serviceDeliverySummaryInformationDtls = new ServiceDeliverySummaryInformation();
    ServiceOffering serviceOffering = null;

    if (paymentInformationInputDetails.serviceOfferingID != 0) {
      serviceOffering = serviceOfferingDAO.get(
        paymentInformationInputDetails.serviceOfferingID);
    }
    curam.financial.impl.ServiceDeliverySummaryInformation serviceDeliverySummaryInformation = financialAPI.retrieveServiceDeliverySummaryInformation(
      serviceOffering, paymentInformationInputDetails.caseID,
      paymentInformationInputDetails.clientID);

    serviceDeliverySummaryInformationDtls.firstServiceDeliveryDate = serviceDeliverySummaryInformation.getFirstServiceDeliveryDate();
    serviceDeliverySummaryInformationDtls.lastServiceDeliveryDate = serviceDeliverySummaryInformation.getLastServiceDeliveryDate();
    serviceDeliverySummaryInformationDtls.totalNumberOfUnitsConsumed = serviceDeliverySummaryInformation.getTotalNumberOfUnitsConsumed();
    if (serviceDeliverySummaryInformationDtls.firstServiceDeliveryDate.isZero()
      && serviceDeliverySummaryInformationDtls.lastServiceDeliveryDate.isZero()
      && serviceDeliverySummaryInformationDtls.totalNumberOfUnitsConsumed == 0) {

      ValidationHelper.addValidationError(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND());
      ValidationHelper.failIfErrorsExist();
    }
    return serviceDeliverySummaryInformationDtls;
  }

  /**
   * Lists all the service offering attendance configuration for the roster line
   * item
   *
   * @param serviceInvoiceLineItemKey
   * Contains roster line item ID.
   * @return List of matched service offering attendance configuration.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public SOAttendanceConfigurationDetailsList listSOConfigurationForRLI(
    ServiceInvoiceLineItemKey serviceInvoiceLineItemKey) throws AppException,
      InformationalException {
    List<SOAttendanceConfiguration> attendanceConfigurationList = providerRosterLineItem.listSOAttendanceConfigurationForRLI(
      serviceInvoiceLineItemKey.serviceInvoiceLineItemID);
    SOAttendanceConfigurationDetailsList attendanceConfigurationDetailsList = new SOAttendanceConfigurationDetailsList();

    for (SOAttendanceConfiguration attendanceConfiguration : attendanceConfigurationList) {
      SOAttendanceConfigurationDetails attendanceConfigurationDetails = new SOAttendanceConfigurationDetails();

      attendanceConfigurationDetails.dtls.attendanceTrackingEnabledInd = attendanceConfiguration.isAttendanceTrackingEnabled();
      attendanceConfigurationDetails.dtls.dailyAttendanceTrackingReqInd = attendanceConfiguration.isDailyAttendanceTrackingRequired();
      attendanceConfigurationDetails.dtls.effectiveDate = attendanceConfiguration.getEffectiveDate();
      attendanceConfigurationDetailsList.dtlsList.addRef(
        attendanceConfigurationDetails);
    }
    return attendanceConfigurationDetailsList;
  }

  /**
   * Lists all the service offering attendance configuration for the service
   * invoice line item
   *
   * @param invoiceLineItemKey
   * Contains service invoice line item ID.
   * @return List of matched service offering attendance configuration.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public SOAttendanceConfigurationDetailsList listSOConfigurationForSILI(
    ServiceInvoiceLineItemKey invoiceLineItemKey) throws AppException,
      InformationalException {
    ServiceInvoiceLineItem invoiceLineItem = serviceInvoiceLineItemDAO.get(
      invoiceLineItemKey.serviceInvoiceLineItemID);
    List<SOAttendanceConfiguration> attendanceConfigurationList = serviceInvoiceLineItem.listSOAttendanceConfigurationforSILI(
      invoiceLineItem);
    SOAttendanceConfigurationDetailsList attendanceConfigurationDetailsList = new SOAttendanceConfigurationDetailsList();

    for (SOAttendanceConfiguration attendanceConfiguration : attendanceConfigurationList) {
      SOAttendanceConfigurationDetails attendanceConfigurationDetails = new SOAttendanceConfigurationDetails();

      attendanceConfigurationDetails.dtls.attendanceTrackingEnabledInd = attendanceConfiguration.isAttendanceTrackingEnabled();
      attendanceConfigurationDetails.dtls.dailyAttendanceTrackingReqInd = attendanceConfiguration.isDailyAttendanceTrackingRequired();
      attendanceConfigurationDetails.dtls.effectiveDate = attendanceConfiguration.getEffectiveDate();
      attendanceConfigurationDetailsList.dtlsList.addRef(
        attendanceConfigurationDetails);
    }
    return attendanceConfigurationDetailsList;
  }

  /**
   * Retrieves the pay based on payment indicator for the service offering
   * related to the roster.
   *
   * @param rosterLineItemKey
   * Contains unique ID of the provider roster line item.
   * @return PayBasedOnPaymentDetails Contains pay based on payment indicator.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public PayBasedOnPaymentDetails retrievePayBasedOnAttendanceForRLI(
    RosterLineItemKey rosterLineItemKey) throws AppException,
      InformationalException {

    PayBasedOnPaymentDetails payBasedOnPaymentDetails = new PayBasedOnPaymentDetails();
    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      rosterLineItemKey.rosterLineItemID);

    // BEGIN, CR00234553, AK
    try {
      payBasedOnPaymentDetails.payBasedOnPaymentInd = providerRosterLineItem.getPayBasedOnAttendanceIndForRLI(
        providerRosterLineItem.getRosterLineItemID());
    } catch (RecordNotFoundException rnex) {
      ValidationHelper.addValidationError(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND());
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00234553

    return payBasedOnPaymentDetails;

  }

  // BEGIN, CR00124065, SG
  /**
   * Retrieves the service invoice line item information for the input service
   * invoice line item.
   *
   * @param siliKey
   * Contains service invoice line item ID for which the information
   * has to be retrieved.
   * @return The service invoice line item details.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public UnitsDeliveredAndPaymentDetails retrieveUnitsAndPaymentInformationForSILI(
    ServiceInvoiceLineItemKey siliKey) throws AppException,
      InformationalException {

    UnitsDeliveredAndPaymentDetails unitsDeliveredAndPaymentDetails = new UnitsDeliveredAndPaymentDetails();
    ServiceInvoiceLineItem sili = null;

    // Get the service invoice line item object.
    sili = serviceInvoiceLineItemDAO.get(siliKey.serviceInvoiceLineItemID);

    // Populate the details to be returned.
    // BEGIN, CR00121703, SG
    try {

      unitsDeliveredAndPaymentDetails.serviceFrom = sili.getServiceDateFrom();
      unitsDeliveredAndPaymentDetails.serviceTo = sili.getServiceDateTo();
      unitsDeliveredAndPaymentDetails.amountPaid = sili.getAmountPaid();
      unitsDeliveredAndPaymentDetails.unitOfMeasure = sili.getServiceOffering().getUnitOfMeasure().getCode();
      unitsDeliveredAndPaymentDetails.unitsDelivered = sili.getNumberOfUnits();
    } catch (RecordNotFoundException rnfe) {
      ValidationHelper.addValidationError(
        CPMCOMMONMESSAGESExceptionCreator.ERR_CPMCOMMONMSG_FV_NO_RECORDS_FOUND());
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00121703

    return unitsDeliveredAndPaymentDetails;
  }
  // END, CR00124065

}
