/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpmsample.changecases.impl;


import java.text.SimpleDateFormat;

import com.google.inject.Singleton;

import curam.core.impl.ConcernRoleAdapter;
import curam.cpm.impl.CPMConstants;
import curam.provider.impl.ProviderReferenceNumberStrategy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import java.util.Date;


/**
 * This class Provides the default implementation for ReferenceNumber generation.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
@Singleton
final public class TestProviderReferenceNumberImpl implements
  ProviderReferenceNumberStrategy {

  // BEGIN, CR00187438, SK
  /**
   * Constructor for the class.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */  
  @Deprecated
  protected TestProviderReferenceNumberImpl() {// Constructor for the class.
  }

  // END, CR00187438
  
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public String generateReferenceNumber() throws AppException,
      InformationalException {
    long uniqueID = 0;

    // unique ID generator
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // generate positive unique id and
    // less than or equal to 18 chars
    
    SimpleDateFormat sdf;
    String str;
    Date date;

    sdf = new SimpleDateFormat(CPMConstants.kDateTimeFormatString);
    sdf.setTimeZone(TransactionInfo.getServerTimeZone());
    date = new Date();
    str = sdf.format(date);
    do {
      uniqueID = uniqueIDObj.getNextID();
    } while (!((uniqueID > 0)
      && (String.valueOf(uniqueID).length()
        >= ConcernRoleAdapter.kMaxLength_primaryAlternateID)));

    String referenceNumber = str + String.valueOf(uniqueID).substring(0, 3);

    return referenceNumber;
  }

}
