/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpmsample.changecases.impl;


import curam.cpm.impl.CPMConstants;
import curam.financial.impl.ServiceInvoiceLineItem;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class customizes the implementation of service invoice payment strategy.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public class ServiceInvoicePaymentStrategyChangeCaseImpl implements
  curam.financial.impl.ServiceInvoicePaymentStrategy {

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  @SuppressWarnings(CPMConstants.kUnused)
  public void determinePayeeForSILI(
    ServiceInvoiceLineItem serviceInvoiceLineItem) throws AppException,
      InformationalException {// This method can be used for the customization of service invoice payment strategy";
  }
}
