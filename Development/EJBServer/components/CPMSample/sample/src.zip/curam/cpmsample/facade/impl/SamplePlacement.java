/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.cpmsample.facade.impl;


import com.google.inject.Inject;

import curam.core.impl.CuramConst;
import curam.core.struct.CaseReference;
import curam.cpm.facade.struct.CasePlacementsList;
import curam.cpm.facade.struct.CreatePlacementDetails;
import curam.cpm.facade.struct.ModifyPlacementDetails;
import curam.cpm.facade.struct.PlacementToAnotherCaseDetails;
import curam.cpm.sl.entity.struct.PlacementKey;
import curam.cpmsample.facade.struct.*;
import curam.message.impl.PLACEMENTExceptionCreator;
import curam.place.impl.Placement;
import curam.place.impl.PlacementAPI;
import curam.place.impl.PlacementAPIImpl;
import curam.place.impl.PlacementDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.DateTimeRange;
import curam.util.type.Money;


/**
 * Facade Layer class having API for managing Placement for UOCPM.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public abstract class SamplePlacement extends curam.cpmsample.facade.base.SamplePlacement {

  /**
   * Placement DAO object.
   */
  @Inject
  protected PlacementDAO placementDAO;
  // @Inject
  // private PersonDAO personDAO;

  /**
   * Bootstrap dependency injection for this class.
   */
  public SamplePlacement() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a placement for the client.
   *
   * @param placementDetails
   * Contains Placement details.
   *
   * @return PlacementKey Contains Placement ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public PlacementKey createPlacement(
    final CreateSamplePlacementDetails placementDetails) throws AppException,
      InformationalException {

    PlacementAPI placementAPI = new PlacementAPIImpl();

    Money unitAmount = new Money(placementDetails.unitAmount);

    DateTimeRange dateTime = new DateTimeRange(placementDetails.fromDate,
      placementDetails.toDate);
    // BEGIN, CR00155774, AK
    // BEGIN , CR00138106, VR
    // Added the CuramConst.gkEmpty and expected to date to the API
    // BEGIN, CR00187909, SSK
    Placement placement = placementAPI.createPlacement(
      placementDetails.caseParticipantRoleId,
      placementDetails.serviceOfferingID,
      placementDetails.providerConcernRoleID, placementDetails.placeID,
      dateTime, unitAmount, placementDetails.unitsAmountFixedInd,
      placementDetails.comments,
      placementDetails.activeReservationDtls.cancelActiveReservationInd);
    // END, CR00187909
    // END , CR00138106
    // END, CR00155774
    PlacementKey key = new PlacementKey();

    key.placementID = placement.getID();
    return key;
  }

  /**
   * Creates an emergency place at highest level compartment of provider and
   * does the emergency placement for the client at the created place.
   *
   * @param placementDetails
   * Contains Placement Details.
   * @return PlacementKey Contains Placement ID.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public PlacementKey createEmergencyPlacement(
    CreatePlacementDetails placementDetails) throws AppException,
      InformationalException {

    PlacementAPI placementAPI = new PlacementAPIImpl();
    PlacementKey key = new PlacementKey();

    DateTimeRange dateTime = new DateTimeRange(placementDetails.fromDate,
      placementDetails.toDate);
    // BEGIN , CR00138106, VR
    // Added the CuramConst.gkEmpty and  expected to date to the API
    curam.place.impl.Placement placement = placementAPI.createEmergencyPlacement(
      placementDetails.caseParticipantRoleId,
      placementDetails.serviceOfferingID,
      placementDetails.providerConcernRoleID, dateTime,
      placementDetails.unitAmount, placementDetails.unitsAmountFixedInd,
      CuramConst.gkEmpty);

    // END , CR00138106

    key.placementID = placement.getID();
    return key;

  }

  /**
   * Transfers a client placement from one case to another case.
   *
   * @param placementToAnotherCaseDetails
   * Contains the existing Placement ID where the client is placed and
   * new CaseParticipantRoleID for the client.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public void transferPlacementToAnotherCase(
    PlacementToAnotherCaseDetails placementToAnotherCaseDetails)
    throws AppException, InformationalException {

    PlacementAPI placementAPI = new PlacementAPIImpl();

    placementAPI.transferPlacementToAnotherCase(
      placementToAnotherCaseDetails.placementID,
      placementToAnotherCaseDetails.caseParticipantRoleID,
      placementToAnotherCaseDetails.versionNo);

  }

  /**
   * Updates the Placement Period of an existing Placement for a client.
   *
   * @param placementDetails
   * Placement period details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public void updatePlacementPeriod(ModifyPlacementDetails placementDetails)
    throws AppException, InformationalException {

    PlacementAPI placementAPI = new PlacementAPIImpl();

    DateTimeRange dateTime = new DateTimeRange(
      placementDetails.placementPeriodDtls.startDate,
      placementDetails.placementPeriodDtls.endDate);
    Integer versionNo = new Integer(
      placementDetails.placementPeriodDtls.versionNo);
    Integer placeVersionNo = new Integer(
      placementDetails.placementPeriodDtls.placeVersionNo);

    // BEGIN, CR00155774, AK
    placementAPI.updatePlacementPeriod(
      placementDetails.placementPeriodDtls.placementID, dateTime, versionNo,
      placeVersionNo,
      placementDetails.reservationIndicatorDtls.cancelActiveReservationInd);
    // END, CR00155774

  }

  /**
   * Deletes the placement.
   *
   * @param key
   * Contains placement ID and version number.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public void deletePlacement(PlacementKeyVersionDetails key)
    throws AppException, InformationalException {

    // BEGIN, CR00122412, AS

    Placement placement = null;

    try {
      if (key.placementID != 0) {
        placement = placementDAO.get(key.placementID);
      } else {
        throw PLACEMENTExceptionCreator.ERR_PLACEMENT_FV_PLACEMENT_ID_IS_MANDATORY();
      }
      placement.getLifecycleState();
    } catch (RecordNotFoundException e) {
      throw PLACEMENTExceptionCreator.ERR_PLACEMENT_FV_PLACEMENT_ID_IS_INVALID();
    }
    // END, CR00122412

    placement.cancel(key.versionNo, key.reAssessPayment);

  }

  // BEGIN, CR00149643, AK
  /**
   * Lists all the active placements for a case.
   *
   * @param key
   * Contains reference number of the case.
   *
   * @return The list of active placements information.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public CasePlacementsList listActivePlacementsForCase(CaseReference key)
    throws AppException, InformationalException {

    CasePlacementsList casePlacementsList = new CasePlacementsList();
    PlacementAPI placementAPI = new PlacementAPIImpl();

    casePlacementsList = placementAPI.listActivePlacementsForCase(
      key.caseReference);

    return casePlacementsList;
  }
  // END, CR00149643

}
