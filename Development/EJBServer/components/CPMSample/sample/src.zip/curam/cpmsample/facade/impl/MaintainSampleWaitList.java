/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.cpmsample.facade.impl;


import com.google.inject.Inject;

import curam.codetable.impl.WAITLISTENTRYPRIORITYEntry;
import curam.codetable.impl.WAITLISTTYPEEntry;
import curam.core.struct.WaitListEntryKey;
import curam.cpm.facade.struct.WaitListEntryDetails;
import curam.message.impl.SAMPLEWAITLISTExceptionCreator;
import curam.provider.impl.ProviderDAO;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.transaction.TransactionInfo;
import curam.waitlist.impl.Resource;
import curam.waitlist.impl.WaitList;
import curam.waitlist.impl.WaitListDAO;
import curam.waitlist.impl.WaitListEntry;
import curam.waitlist.impl.WaitListEntryDAO;


/**
 * This class provides API for the WaitList functionalities which are not in CPM
 * and will be used by usage of CPM applications.
 *
 * @deprecated Since Curam V6.0.
 * This class is deprecated as it is not supported and is implemented for
 * internal use only. See release note: CR00248676.
 */
@Deprecated
public abstract class MaintainSampleWaitList extends curam.cpmsample.facade.base.MaintainSampleWaitList {

  /**
   * Wait List DAO
   */
  @Inject
  protected WaitListDAO waitListDAO;
    
  /**
   * Reference to ProviderOfferingDAO.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Reference to ProviderDAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  // BEGIN, CR00156341, RPB  
  /**
   * Wait List Entry DAO
   */
  @Inject
  protected WaitListEntryDAO waitListEntryDAO;
    
  // END, CR00156341

  /**
   * Default constructor of the class to inject members.
   *
   */
  public MaintainSampleWaitList() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  
  /**
   * Create a sample WaitList entry for the Resource for a Client.
   *
   * @param waitListEntryDetails
   * Contains WaitList and WaitList entry details.
   * @return WaitListEntryKey Contains WaitList ID of the newly created WaitList
   * entry.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam V6.0.
   * This class is deprecated as it is not supported and is implemented for
   * internal use only. See release note: CR00248676.
   */
  @Deprecated
  public WaitListEntryKey createWaitListEntry(
    WaitListEntryDetails waitListEntryDetails) throws AppException,
      InformationalException {

    // Position of the wait list entry in wait list.
    short position;

    // If position is valid assign the value else assign zero.
    try {
      position = Short.parseShort(waitListEntryDetails.positionString);
    } catch (NumberFormatException nfe) {
      position = 0;
    }

    // Get the code table codes from input strings.
    WAITLISTTYPEEntry waitListType = WAITLISTTYPEEntry.get(
      waitListEntryDetails.waitListDtls.type);
    WAITLISTENTRYPRIORITYEntry waitListPriorityEntry = WAITLISTENTRYPRIORITYEntry.get(
      waitListEntryDetails.waitListEntryDtls.priority);

    // Create a Wait List.
    WaitList waitList = waitListDAO.newInstance();
    Resource resource = null;       

    // BEGIN, CR00128914, RPB
    try {
      if (waitListType.equals(WAITLISTTYPEEntry.PROVIDER)) {
        resource = providerDAO.get(waitListEntryDetails.waitListDtls.resourceID);
      }

      if (waitListType.equals(WAITLISTTYPEEntry.PROVIDEROFFERING)) {
        resource = providerOfferingDAO.get(
          waitListEntryDetails.waitListDtls.resourceID);
      }
      waitList.setResource(resource);
    } catch (RecordNotFoundException e) {
      ValidationHelper.addValidationError(
        SAMPLEWAITLISTExceptionCreator.ERR_WAITLIST_RESOURCE_ID_INVALID());
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00128914    
  
    // BEGIN, CR00156341, RPB
    WaitListEntry wlEntry = waitListEntryDAO.newInstance();

    wlEntry.setClient(
      waitListEntryDetails.waitListEntryDtls.caseParticipantRoleID);
    wlEntry.setPosition(position);
    wlEntry.setPriority(waitListPriorityEntry);
    wlEntry.setExpiryDate(waitListEntryDetails.waitListEntryDtls.expiryDate);
    wlEntry.setComments(waitListEntryDetails.waitListEntryDtls.comments);
    wlEntry.setReviewDate(waitListEntryDetails.waitListEntryDtls.reviewDate);
    wlEntry.setTransactionUser(TransactionInfo.getProgramUser());
    WaitListEntry waitListEntry = waitList.addEntry(wlEntry);
    // END, CR00156341
    
    WaitListEntryKey waitListEntryKey = new WaitListEntryKey();

    waitListEntryKey.waitListEntryID = waitListEntry.getID();

    return waitListEntryKey;
  }
}
