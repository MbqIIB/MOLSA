/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidencebroker.impl;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.google.inject.Inject;

import curam.codetable.PRODUCTTYPE;
import curam.core.impl.Registrar;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.message.BPOBROADCASTEVIDENCEREGISTRAR;
import curam.util.exception.AppException;
import curam.util.type.CodeTableItemIdentifier;


/**
 * This class allows the registration of a custom hook that allows customers
 * delegate evidence sharing functionality to their service layer processing.
 */
public interface BroadcastEvidenceRegistrar {

  /**
   * The HookMap class is a generic product name to Curam factory class mapping.
   */
  public final class HookMap {

    // BEGIN, CR00198200, GYH 
    /**
     * Internal storage of the hook factory classes in a concurrent hash map.
     */
    protected Map hookMap = new ConcurrentHashMap();

    /**
     * Registers all the maps of Evidence Broker Hook implementations from
     * corresponding module class during the process of this class instance
     * creation.
     * 
     * @param moduleEvidenceMap
     *          Contains all the maps of Evidence Broker Hook 
     *          implementations.
     */
     @Inject(optional = true)
     void registerAll(final @Registrar(Registrar.RegistrarType.EVIDENCE_BROKER) 
         Map<String, Method> moduleEvidenceMap){
       
       // Register all the maps of Evidence Broker Hook implementations.
       hookMap.putAll(moduleEvidenceMap);
     }
     // END, CR00198200 

    /**
     * Add a mapping for the specified evidence to the specified factory
     * class.
     *
     * @param type The type of the case
     * @param factory The factory class which can create the hook
     */
    public void addMapping(final String type, final Class factory) {
      Method newInstance = null;

      try {
        newInstance =
          factory.getMethod(ReflectionConst.kNewInstance, new Class[0]);
      } catch (NoSuchMethodException e) {

        AppException ae =
          new AppException(
            BPOBROADCASTEVIDENCEREGISTRAR.ERR_REGISTRAR_NEW_INSTANCE_UNIMPLEMENTED);

        ae.arg(factory.getName());
        ae.arg(new CodeTableItemIdentifier(PRODUCTTYPE.TABLENAME, type));

        throw new RuntimeException(ae);
      }

      hookMap.put(type, newInstance);
    }

    /**
     * Creates an instance of the hook for the specified evidence.
     *
     * @param type The type of the case
     * @param intf The type that the hook should implement.
     *
     * @return The created hook object
     * 
     * @throws AppException Generic Exception Signature.
     */
    public Object createHookInstance(final String type, final Class intf)
      throws AppException {

      Method newInstance = (Method) hookMap.get(type);

      if (newInstance == null) {
        return null;
      }

      try {
        Object bpoObject = newInstance.invoke(null, new Object[0]);

        // Check that the created Business Process Object can be safely cast
        // to the type intf
        if (!(intf.isInstance(bpoObject))) {

          AppException e =
            new AppException(
              BPOBROADCASTEVIDENCEREGISTRAR.ERR_REGISTRAR_INCORRECT_BPOCLASS);

          e.arg(bpoObject.getClass().getName());
          e.arg(new CodeTableItemIdentifier(PRODUCTTYPE.TABLENAME, type));
          e.arg(intf.getName());
          throw new RuntimeException(e);
        }

        return bpoObject;
      } catch (Exception e) {

        AppException ae =
          new AppException(
            BPOBROADCASTEVIDENCEREGISTRAR.ERR_REGISTRAR_HOOK_INSTANTIATION_FAILED);

        ae.arg(new CodeTableItemIdentifier(PRODUCTTYPE.TABLENAME, type));
        ae.arg(e.getLocalizedMessage());
        throw new RuntimeException(e);
      }

    }

  }

  /**
   * Implementors should use this method to add details of the evidence
   * broadcast hook to use on a product by product basis.
   */
  public void register();

}

