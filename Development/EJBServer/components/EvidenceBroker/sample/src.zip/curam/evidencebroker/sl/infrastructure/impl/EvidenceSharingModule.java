/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.evidencebroker.sl.infrastructure.impl;


import com.google.inject.AbstractModule;
import com.google.inject.multibindings.MapBinder;
import com.google.inject.multibindings.Multibinder;

import curam.codetable.CASETYPECODE;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.core.sl.impl.EvidenceBrokerSharingStrategy;
import curam.core.sl.impl.ProcessPostponedVItem;
import curam.creole.storage.database.CREOLEPreCommitProcessingHook;
import curam.evidencebroker.bom.impl.EvidenceBrokerModule;
import curam.evidencebroker.sl.impl.EBDPTransactionCallBackImpl;
import curam.evidencebroker.sl.impl.ProcessVerificationItemImpl;


/**
 * A module class which contain the mappings for Evidence Broker Sharing
 * Strategy implementation class.
 */
public class EvidenceSharingModule extends AbstractModule {

  /**
   * Map the instance of EvidenceBrokerSharingStrategy implementation class to
   * each class type.
   */
  @Override
  public void configure() {

    // BEGIN, CR00260787, MR
    // Load the module class which registers the evidence broker business
    // object module implementation classes to a different types of BOMs.
    install(new EvidenceBrokerModule());
    // END, CR00260787

    MapBinder<String, EvidenceBrokerSharingStrategy> mapbinder = MapBinder.newMapBinder(
      binder(), String.class, EvidenceBrokerSharingStrategy.class);

    // bind the EvidenceBrokerSharingStrategyImpl object to an integrated case
    // type
    mapbinder.addBinding(CASETYPECODE.INTEGRATEDCASE).to(
      EvidenceBrokerSharingStrategyImpl.class);

    // bind the EvidenceBrokerSharingStrategyImpl object to product delivery
    // case type
    mapbinder.addBinding(CASETYPECODE.PRODUCTDELIVERY).to(
      EvidenceBrokerSharingStrategyImpl.class);

    // bind the EvidenceBrokerSharingStrategyImpl object to liability case
    // type
    mapbinder.addBinding(CASETYPECODE.LIABILITY).to(
      EvidenceBrokerSharingStrategyImpl.class);

    // BEGIN, CR00345678, ZV
    // bind the EvidenceBrokerSharingStrategyImpl object to participant data case
    mapbinder.addBinding(CASETYPECODE.PARTICIPANTDATACASE).to(
      EvidenceBrokerSharingStrategyImpl.class);
    // END, CR00345678
    
    // set up the default map binder
    final MapBinder<CASETYPECODEEntry, EvidenceBrokerHooks> defaultHooks = MapBinder.newMapBinder(
      binder(), CASETYPECODEEntry.class, EvidenceBrokerHooks.class);   
    
    // BEGIN, CR00409418, GK
    final Multibinder<CREOLEPreCommitProcessingHook> creolePreCommitProcessingcreolePreCommitProcessingEventListeners = Multibinder.newSetBinder(
      binder(), CREOLEPreCommitProcessingHook.class);

    creolePreCommitProcessingcreolePreCommitProcessingEventListeners.addBinding().to(
      EBDPTransactionCallBackImpl.class);
    // END, CR00409418
    
    // BEGIN, CR00427012, KRK
    binder().bind(ProcessPostponedVItem.class).to(
      ProcessVerificationItemImpl.class);
    // END, CR00427012
  }

}

