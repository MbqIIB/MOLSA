/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.fundpm.util.impl;


import curam.core.struct.UniqueIDKeySet;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * Standard implementation of
 * {@linkplain curam.fundpm.util.impl.FundFiscalYearLineItemRefNum}.
 */
public class FundFiscalYearLineItemRefNumImpl implements FundFiscalYearLineItemRefNum {

  /**
   * Protected constructor of FundFiscalYearLineItemRefNumImpl.
   */
  protected FundFiscalYearLineItemRefNumImpl() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Generates fund fiscal year line item reference number and returns the
   * string representation of the same. The default generation mechanism
   * involves creation of reference number starting from 1024 and incrementing
   * by 1.
   *
   * @return String representation of the reference number.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  public String generateFFYLIReferenceNumber() throws AppException,
      InformationalException {

    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();
    UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    uniqueIDKeySet.keySetName = FundPMConstants.kFFYLIKeySetName;

    String referenceNumber = String.valueOf(
      uniqueIDObj.getNextIDFromKeySet(uniqueIDKeySet));

    return referenceNumber;
  }

}
