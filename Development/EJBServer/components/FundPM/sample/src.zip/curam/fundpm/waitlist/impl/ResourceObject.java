/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.fundpm.waitlist.impl;


import curam.codetable.impl.WAITLISTTYPEEntry;
import curam.waitlist.impl.Resource;


/**
 * This is a object which implements the Resource interface used for executing
 * wait list.
 *
 */

public class ResourceObject implements Resource {

  /**
   * Contains the resource ID.
   */
  private long resouceID;

  /**
   * Contains the wait list type.
   */
  private WAITLISTTYPEEntry waitListType;

  /**
   * Gets the id of the resource.
   *
   * @return The id of the resource.
   */
  public long getResourceID() {
    return resouceID;
  }

  /**
   * Gets the type of the resource.
   *
   * @return The type of the resource.
   */
  public WAITLISTTYPEEntry getResourceType() {
    return waitListType;
  }

  /**
   * Sets the id of the resource.
   *
   * @param value
   * The id of the resource.
   */

  public void setResourceID(final long value) {
    resouceID = value;
  }

  /**
   * Sets the type of the resource.
   *
   * @param value
   * The type of the resource.
   */
  public void setResourceType(final WAITLISTTYPEEntry value) {
    waitListType = value;
  }

}
