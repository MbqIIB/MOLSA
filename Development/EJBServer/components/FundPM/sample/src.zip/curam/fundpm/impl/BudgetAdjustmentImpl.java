/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.fundpm.impl;


import com.google.inject.Inject;

import curam.codetable.impl.BUDGETADJUSTMENTTYPEEntry;
import curam.codetable.impl.CREDITDEBITEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.fundpm.fundfiscalyearlineitem.impl.FundFiscalYearLineItem;
import curam.fundpm.fundfiscalyearlineitem.impl.FundFiscalYearLineItemDAO;
import curam.fundpm.sl.entity.struct.BudgetAdjustmentDtls;
import curam.message.BUDGETADJUSTMENT;
import curam.message.impl.BUDGETADJUSTMENTExceptionCreator;
import curam.message.impl.FUNDMANAGEMENTExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.Money;


/**
 * Standard implementation of {@linkplain BudgetAdjustment}.
 */
public class BudgetAdjustmentImpl extends SingleTableEntityImpl<BudgetAdjustmentDtls> implements BudgetAdjustment {

  /**
   * Reference to fund fiscal year line item DAO.
   */
  @Inject
  private FundFiscalYearLineItemDAO fundFiscalYearLineItemDAO;

  /**
   * Protected constructor of BudgetAdjustmentImpl.
   */
  protected BudgetAdjustmentImpl() {// Protected no-arg constructor for use only by Guice
  }

  /**
   * {@inheritDoc}
   */
  public Money getAmount() {
    return this.getDtls().amount;
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return this.getDtls().comments;
  }

  /**
   * {@inheritDoc}
   */
  public Date getCreationDate() {
    return this.getDtls().creationDate;
  }

  /**
   * {@inheritDoc}
   */
  public CREDITDEBITEntry getCreditDebitType() {
    return CREDITDEBITEntry.get(this.getDtls().creditDebitType);
  }

  /**
   * {@inheritDoc}
   */
  public void setAmount(final Money amount) {
    this.getDtls().amount = amount;
  }

  /**
   * {@inheritDoc}
   */
  public void setComments(final String comments) {
    this.getDtls().comments = comments;
  }

  /**
   * {@inheritDoc}
   */
  public void setCreditDebitType(final CREDITDEBITEntry creditDebitType) {
    this.getDtls().creditDebitType = creditDebitType.getCode();
  }

  /**
   * Validates that changes made to budget adjustment entity on the database are
   * consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.BUDGETADJUSTMENT#ERR_BUDGETADJUSTMENT_XRV_CREATION_DATE_BEFORE_FUND_START_DATE} -
   * If the creation date is before the fund start date. </li>
   * <li>
   * {@link curam.message.BUDGETADJUSTMENT#ERR_BUDGETADJUSTMENT_XRV_CREATION_DATE_AFTER_FUND_END_DATE} -
   * If the creation date is after the fund end date. </li>
   * </ul>
   */
  public void crossEntityValidation() {

    ProgramFund fund = null;

    if (BUDGETADJUSTMENTTYPEEntry.FUNDFISCALYEARLINEITEM.equals(
      getRelatedType())) {

      FundFiscalYearLineItem fundFiscalYearLineItem = fundFiscalYearLineItemDAO.get(
        getRelatedID());

      fund = fundFiscalYearLineItem.getFundFiscalYear().getFund();
    }

    if (null != fund) {
      // BEGIN, CR00200081, AS
      if (getCreationDate().before(fund.getDateRange().start())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          BUDGETADJUSTMENTExceptionCreator.ERR_BUDGETADJUSTMENT_XRV_CREATION_DATE_BEFORE_FUND_START_DATE(
            getCreationDate(), fund.getDateRange().start()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
            0);
      }
      // BEGIN, CR00200154, AS
      if (!Date.kZeroDate.equals(fund.getDateRange().end())
        && getCreationDate().after(fund.getDateRange().end())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          BUDGETADJUSTMENTExceptionCreator.ERR_BUDGETADJUSTMENT_XRV_CREATION_DATE_AFTER_FUND_END_DATE(
            getCreationDate(), fund.getDateRange().end()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
            0);
      }
      // END, CR00200154
    }
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No Implementation required
  }

  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   * <p>
   * When validation fails, following exceptions can be thrown.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.FUNDMANAGEMENT#ERR_FV_BUDGETADJUSTMENT_AMOUNT_MUST_BE_GREATER_THAN_OR_EQUAL_TO_ZERO} -
   * If the amount is not entered. </li>
   * <li>
   * {@link curam.message.FUNDMANAGEMENT#ERR_BUDGETADJUSTMENT_FV_DATE_NOT_ENTERED} -
   * If the effective date is not entered. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    // need to enter amount
    if (getAmount().isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FUNDMANAGEMENTExceptionCreator.ERR_FV_BUDGETADJUSTMENT_AMOUNT_MUST_BE_GREATER_THAN_OR_EQUAL_TO_ZERO(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);

    }

    // need to enter effective Date
    if (getCreationDate().isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FUNDMANAGEMENTExceptionCreator.ERR_BUDGETADJUSTMENT_FV_DATE_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
    }

  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {
    getDtls().creationDate = Date.getCurrentDate();
    getDtls().userFirstName = TransactionInfo.getProgramUser();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {
    super.modify(versionNo);
  }

  /**
   * Inserts a Budget Adjustment record.
   *
   * @throws InformationalException
   * {@link BUDGETADJUSTMENT#ERR_BUDGETADJUSTMENT_XRV_FUNDFISCALYEARLINEITEM_IS_CANCELLED_CANNOT_BE_CREATED}
   * - If a budget adjustment is created for a fund fiscal year line
   * item which is canceled.
   */
  @Override
  public void insert() throws InformationalException {
    if (BUDGETADJUSTMENTTYPEEntry.FUNDFISCALYEARLINEITEM.equals(
      getRelatedType())) {
      FundFiscalYearLineItem fundFiscalYearLineItem = fundFiscalYearLineItemDAO.get(
        getRelatedID());

      if (RECORDSTATUSEntry.CANCELLED.getCode().equals(
        fundFiscalYearLineItem.getLifecycleState().getCode())) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          BUDGETADJUSTMENTExceptionCreator.ERR_BUDGETADJUSTMENT_XRV_FUNDFISCALYEARLINEITEM_IS_CANCELLED_CANNOT_BE_CREATED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
      }
      ValidationHelper.failIfErrorsExist();

    }
    super.insert();
  }

  /**
   * {@inheritDoc}
   */
  public Long getRelatedID() {
    return getDtls().relatedID;
  }

  /**
   * {@inheritDoc}
   */
  public String getAllocationReferenceNumber() {
    return getDtls().allocationRefNo;
  }

  /**
   * {@inheritDoc}
   */
  public String getUserFirstName() {
    return getDtls().userFirstName;
  }

  /**
   * {@inheritDoc}
   */
  public String getUserSurname() {
    return getDtls().userLastName;
  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedID(final Long relatedID) {
    getDtls().relatedID = relatedID;
  }

  /**
   * {@inheritDoc}
   */
  public void setAllocationReferenceNumber(final String allocationReferenceNo) {
    getDtls().allocationRefNo = allocationReferenceNo;
  }

  /**
   * {@inheritDoc}
   */
  public BUDGETADJUSTMENTTYPEEntry getRelatedType() {
    return BUDGETADJUSTMENTTYPEEntry.get(getDtls().relatedType);
  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedType(final BUDGETADJUSTMENTTYPEEntry relatedType) {
    getDtls().relatedType = relatedType.getCode();
  }

}
