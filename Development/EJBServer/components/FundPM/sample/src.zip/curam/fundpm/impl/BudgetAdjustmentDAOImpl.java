/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.fundpm.impl;


import java.util.List;

import com.google.inject.Singleton;

import curam.fundpm.sl.entity.impl.BudgetAdjustmentAdapter;
import curam.fundpm.sl.entity.struct.BudgetAdjustmentDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of {@linkplain BudgetAdjustmentDAO}.
 */
@Singleton
public class BudgetAdjustmentDAOImpl extends StandardDAOImpl<BudgetAdjustment, BudgetAdjustmentDtls> implements
  BudgetAdjustmentDAO {

  /**
   * Single instance of the entity adapter shared across all DAO
   * implementations.
   */
  private static BudgetAdjustmentAdapter budgetAdjustmentAdapter = new BudgetAdjustmentAdapter();

  /**
   * Protected constructor of BudgetAdjustmentDAOImpl.
   */
  protected BudgetAdjustmentDAOImpl() {
    // Protected no-arg constructor for use only by Guice
    super(budgetAdjustmentAdapter, BudgetAdjustment.class);
  }

  /**
   * {@inheritDoc}
   */
  public List<BudgetAdjustment> listBudgetAdjustmentForRelatedID(
    final Long realtedID) {
    return newList(budgetAdjustmentAdapter.searchByRelatedID(realtedID));
  }

}
