/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.fundpm.util.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * A FundFiscalYearLineItemRefNum class is used generate a reference number for
 * a fund fiscal year line item. The default implementation of this interface is
 * provided by FundFiscalYearLineItemRefNumImpl.
 *
 * The default implementation of this interface can be replaced with a new
 * custom implementation by creating a new Guice module class and adding a
 * corresponding entry in the MODULE table. Chapter 5 - Creating a Guice Module
 * in the Persistence Cookbook explains this in detail.
 *
 * A new implementation of this interface is required to change the mechanism
 * used to generate the reference numbers.
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
@ImplementedBy(FundFiscalYearLineItemRefNumImpl.class)
public interface FundFiscalYearLineItemRefNum {

  /**
   * Generates a fund fiscal year line item reference number and returns the
   * string representation of the generated reference number. The default
   * generation mechanism involves creation of reference number starting from
   * 1024 and incrementing it by 1.
   *
   * @return The reference number of a fund fiscal year line item.
   *
   * @see curam.fundpm.util.impl.FundFiscalYearLineItemRefNumImpl#generateFFYLIReferenceNumber()
   * The default implementation -
   * curam.fundpm.util.impl.FundFiscalYearLineItemRefNum
   * #generateFFYLIReferenceNumber()
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  @curam.util.type.Implementable
  String generateFFYLIReferenceNumber() throws AppException,
      InformationalException;

}
