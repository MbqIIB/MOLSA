/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.fundpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.google.inject.Inject;

import curam.codetable.impl.FISCALYEARNAMEEntry;
import curam.codetable.impl.PROGRAMFUNDNAMEEntry;
import curam.codetable.impl.WAITLISTENTRYPRIORITYEntry;
import curam.codetable.impl.WAITLISTENTRYSTATUSEntry;
import curam.codetable.impl.WAITLISTEXPIRYDAYSEntry;
import curam.codetable.impl.WAITLISTREMOVALREASONEntry;
import curam.core.fact.ExpireWaitListEntryFactory;
import curam.core.fact.WaitListEntryHistoryFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ExpireWaitListEntry;
import curam.core.intf.WaitListEntryHistory;
import curam.core.struct.BatchProcessingDate;
import curam.core.struct.WaitListEntryHistoryDtls;
import curam.core.struct.WaitListEntryHistoryDtlsList;
import curam.core.struct.WaitListEntryHistoryKey;
import curam.fundpm.facade.struct.FundWaitListEntryDetails;
import curam.fundpm.facade.struct.FundWaitListEntryStatusHistoryDtls;
import curam.fundpm.facade.struct.FundWaitListEntryStatusHistoryDtlsList;
import curam.fundpm.facade.struct.NotificationDetails;
import curam.fundpm.facade.struct.WaitListEntryKey;
import curam.fundpm.facade.struct.WaitListEntryKeyDetails;
import curam.fundpm.facade.struct.WaitListRemovalDetails;
import curam.fundpm.facade.struct.WaitListSearchCriteria;
import curam.fundpm.facade.struct.WaitListSearchResultList;
import curam.fundpm.impl.FundFiscalYearDAO;
import curam.message.impl.BPOWAITLISTExceptionCreator;
import curam.message.impl.WAITLISTExceptionCreator;
import curam.piwrapper.casemanager.impl.CaseParticipantRoleDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.waitlist.impl.WaitListEntry;
import curam.waitlist.impl.WaitListEntryDAO;


/**
 * Facade layer class having methods for managing Fund Wait Lists. Fund Wait
 * List is a queue of clients waiting for fund available. An entry on a wait
 * list for a fund relating to a client is called Wait List Entry.
 */
public abstract class MaintainFundWaitList extends curam.fundpm.facade.base.MaintainFundWaitList {

  /**
   * Reference to Wait List Entry DAO.
   */
  @Inject
  private WaitListEntryDAO waitListEntryDAO;

  /**
   * Reference to Fund Fiscal Year DAO.
   */
  @Inject
  private FundFiscalYearDAO fundFiscalYearDAO;

  // BEGIN, CR00200567, AS
  /**
   * Reference to case participant role DAO.
   */
  @Inject
  private CaseParticipantRoleDAO caseParticipantRoleDAO;
  // END, CR00200567

  /**
   * Constructor for the class.
   */
  public MaintainFundWaitList() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Removes the entry from the wait list.
   *
   * @param waitListRemovalDetails
   * Contains the wait list entry removal details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void removeWaitListEntry(
    final WaitListRemovalDetails waitListRemovalDetails) throws AppException,
      InformationalException {
    long waitListEntryID = waitListRemovalDetails.waitListEntryID;
    WaitListEntry waitListEntry = null;

    try {
      waitListEntry = waitListEntryDAO.get(waitListEntryID);
    } catch (RecordNotFoundException exception) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOWAITLISTExceptionCreator.ERR_WAITLIST_ENTRY_XRV_WAIT_LIST_ENTRY_DOES_NOT_EXIST(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
      ValidationHelper.failIfErrorsExist();
    }

    waitListEntry.setRemovalReason(
      WAITLISTREMOVALREASONEntry.get(waitListRemovalDetails.removalReason));
    waitListEntry.cancel(waitListEntry.getVersionNo());

  }

  /**
   * Searches the wait list entries by fund fiscal year for the given criteria.
   *
   * @param waitListSearchCriteria
   * Contains the criteria to search the wait list entry details.
   *
   * @return Contains list of wait list entry search results.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public WaitListSearchResultList searchWaitListDetails(
    final WaitListSearchCriteria waitListSearchCriteria) throws AppException,
      InformationalException {
    // BEGIN, CR00205954, AS
    // BEGIN, CR00200567, AS
    if (WAITLISTEXPIRYDAYSEntry.NOT_SPECIFIED.getCode().equals(
      waitListSearchCriteria.expiryDays)
        && WAITLISTENTRYPRIORITYEntry.NOT_SPECIFIED.getCode().equals(
          waitListSearchCriteria.priority)
          && WAITLISTENTRYSTATUSEntry.NOT_SPECIFIED.getCode().equals(
            waitListSearchCriteria.status)
            && 0 == waitListSearchCriteria.personID
            && 0 == waitListSearchCriteria.fundFiscalYearID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        WAITLISTExceptionCreator.ERR_WAITLIST_SERACH_CRITERIA_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 0);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00200567
    // END, CR00205954
    WaitListSearchResultList waitListSearchResultList = fundFiscalYearDAO.searchWaitListByFundFiscalYearDynamicSQL(
      waitListSearchCriteria);

    return waitListSearchResultList;
  }

  /**
   * Updates a Wait List entry for a client waiting for a resource.
   *
   * @param fundWaitListEntryDetails
   * Contains the Wait List entry details which needs to be updated.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void updateWaitListEntry(
    final FundWaitListEntryDetails fundWaitListEntryDetails)
    throws AppException, InformationalException {

    WaitListEntry waitListEntry = null;
    short position = 0;
    String positionString = fundWaitListEntryDetails.waitListEntryDtls.position
      + CuramConst.gkEmpty.trim();

    // Get the position from position string.
    if (positionString.length() > 0) {
      try {
        position = Short.parseShort(positionString);
      } catch (NumberFormatException nfe) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          WAITLISTExceptionCreator.ERR_WAITLIST_ENTRY_FV_POSITION_ENTERED_IS_INVALID(
            positionString),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen,
            0);
      }

      ValidationHelper.failIfErrorsExist();
    }

    long waitListEntryID = fundWaitListEntryDetails.waitListEntryDtls.waitListEntryID;

    try {
      waitListEntry = waitListEntryDAO.get(waitListEntryID);
    } catch (RecordNotFoundException exception) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOWAITLISTExceptionCreator.ERR_WAITLIST_ENTRY_XRV_WAIT_LIST_ENTRY_DOES_NOT_EXIST(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 2);
      ValidationHelper.failIfErrorsExist();
    }

    // Populate the details modified.
    waitListEntry.setExpiryDate(
      fundWaitListEntryDetails.waitListEntryDtls.expiryDate);
    waitListEntry.setPosition(position);
    // BEGIN, CR00200567, AS
    waitListEntry.setComments(
      fundWaitListEntryDetails.waitListEntryDtls.comments);
    // END, CR00200567
    waitListEntry.modifyWaitListEntry(waitListEntry.getVersionNo());

  }

  /**
   * Retrieves a wait list entry details for a wait list.
   *
   * @param waitListEntryKey
   * Contains a Wait List Entry ID.
   *
   * @return Contains fund wait list entry details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public FundWaitListEntryDetails viewWaitListEntry(
    final WaitListEntryKey waitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntry waitListEntry = null;

    try {
      waitListEntry = waitListEntryDAO.get(waitListEntryKey.waitListEntryID);
    } catch (RecordNotFoundException exception) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOWAITLISTExceptionCreator.ERR_WAITLIST_ENTRY_XRV_WAIT_LIST_ENTRY_DOES_NOT_EXIST(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTen, 1);
      ValidationHelper.failIfErrorsExist();
    }

    FundWaitListEntryDetails fundWaitListEntryDetails = getWaitListEntryDetails(
      waitListEntry);

    return fundWaitListEntryDetails;
  }

  /**
   * Reads the status history information for a wait list entry.
   *
   * @param waitListEntryKey
   * Key containing the wait list entry ID.
   *
   * @return List of wait list entry status history details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public FundWaitListEntryStatusHistoryDtlsList viewWaitListEntryStatusHistory(
    final WaitListEntryKey waitListEntryKey) throws AppException,
      InformationalException {
    // BEGIN, CR00200567, AS
    FundWaitListEntryStatusHistoryDtlsList statusHistoryDetailsList = new FundWaitListEntryStatusHistoryDtlsList();
    // END, CR00200567
    curam.core.struct.WaitListEntryKey waitListEntryIDKey = new curam.core.struct.WaitListEntryKey();

    waitListEntryIDKey.waitListEntryID = waitListEntryKey.waitListEntryID;
    // BEGIN, CR00205389, AS
    WaitListEntryHistory waitListEntryHistoryObj = WaitListEntryHistoryFactory.newInstance();
    WaitListEntryHistoryDtlsList waitListEntryHistoryDtlsList = waitListEntryHistoryObj.searchByWaitListEntry(
      waitListEntryIDKey);
    // END, CR00205389
    // BEGIN, CR00200567, AS
    List<FundWaitListEntryStatusHistoryDtls> fundWaitListEntryStatusHistoryDtlslist = new ArrayList<FundWaitListEntryStatusHistoryDtls>();

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKey.waitListEntryID);

    // BEGIN, CR00205389, AS
    for (int j = 0; j < waitListEntryHistoryDtlsList.dtls.size(); j++) {
      FundWaitListEntryStatusHistoryDtls fundWaitListEntryStatusHistoryDtls = new FundWaitListEntryStatusHistoryDtls();

      fundWaitListEntryStatusHistoryDtls.waitListEntryHistoryID = waitListEntryHistoryDtlsList.dtls.item(j).waitListEntHistID;
      fundWaitListEntryStatusHistoryDtls.position = waitListEntryHistoryDtlsList.dtls.item(j).position;
      fundWaitListEntryStatusHistoryDtls.expiryDate = waitListEntryHistoryDtlsList.dtls.item(j).expiryDate;
      fundWaitListEntryStatusHistoryDtls.comments = waitListEntryHistoryDtlsList.dtls.item(j).comments;
      fundWaitListEntryStatusHistoryDtls.dtls.changeDateTime = waitListEntryHistoryDtlsList.dtls.item(j).lastChangedDateTime;
      fundWaitListEntryStatusHistoryDtls.dtls.status = waitListEntryHistoryDtlsList.dtls.item(j).status;
      fundWaitListEntryStatusHistoryDtls.dtls.userName = waitListEntryHistoryDtlsList.dtls.item(j).userName;
      fundWaitListEntryStatusHistoryDtls.priority = waitListEntry.getPriority().getCode();
      fundWaitListEntryStatusHistoryDtls.fundFiscalYearID = waitListEntry.getWaitList().getResourceID();
      fundWaitListEntryStatusHistoryDtls.fundFiscalYearName = CodeTable.getOneItem(
        PROGRAMFUNDNAMEEntry.TABLENAME,
        fundFiscalYearDAO.get(fundWaitListEntryStatusHistoryDtls.fundFiscalYearID).getFund().getName().getCode())
          + CuramConst.gkSpaceChar
          + CodeTable.getOneItem(FISCALYEARNAMEEntry.TABLENAME,
          fundFiscalYearDAO.get(fundWaitListEntryStatusHistoryDtls.fundFiscalYearID).getFiscalYear().getYearName().getCode());

      fundWaitListEntryStatusHistoryDtls.participantName = caseParticipantRoleDAO.get(waitListEntry.getClient()).getConcernRole().getName();

      fundWaitListEntryStatusHistoryDtlslist.add(
        fundWaitListEntryStatusHistoryDtls);
    }
    // END, CR00205389
    // Sort the wait list entry based on the changed date time
    for (FundWaitListEntryStatusHistoryDtls statusHistory : sortWaitListEntryStausHistoryByDateTime(
      fundWaitListEntryStatusHistoryDtlslist)) {
      statusHistoryDetailsList.dtlsList.addRef(statusHistory);
    }
    // END, CR00200567
    return statusHistoryDetailsList;
  }

  // BEGIN, CR00205389, AS
  /**
   * Retrieves the history information for a wait list entry.
   *
   * @param waitListEntryKeyDetails
   * Wait list entry key details.
   *
   * @return Wait list entry status history details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public FundWaitListEntryStatusHistoryDtls viewFundWaitListEntryHistory(
    WaitListEntryKeyDetails waitListEntryKeyDetails) throws AppException,
      InformationalException {

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKeyDetails.waitListEntryID);
    FundWaitListEntryStatusHistoryDtls fundWaitListEntryStatusHistoryDtls = new FundWaitListEntryStatusHistoryDtls();
    WaitListEntryHistory waitListEntryHistoryObj = WaitListEntryHistoryFactory.newInstance();
    WaitListEntryHistoryKey waitListEntryHistoryKey = new WaitListEntryHistoryKey();

    waitListEntryHistoryKey.waitListEntHistID = waitListEntryKeyDetails.waitListEntryHistoryID;
    WaitListEntryHistoryDtls waitListEntryHistoryDtls = waitListEntryHistoryObj.read(
      waitListEntryHistoryKey);

    fundWaitListEntryStatusHistoryDtls.reviewDate = waitListEntry.getReviewDate();

    fundWaitListEntryStatusHistoryDtls.comments = waitListEntry.getComments();
    if (WAITLISTENTRYSTATUSEntry.REMOVED.getCode().equals(
      waitListEntryHistoryDtls.status)) {
      fundWaitListEntryStatusHistoryDtls.removalReason = waitListEntry.getRemovalReason().getCode();
    }
    return fundWaitListEntryStatusHistoryDtls;
  }

  // END, CR00205389

  /**
   * Expires fund wait list whose expiration date is less than or equal to
   * system processing date.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void expireFundWaitListEntry() throws AppException,
      InformationalException {

    BatchProcessingDate batchProcessingDate = new BatchProcessingDate();

    batchProcessingDate.processingDate = Date.getCurrentDate();
    ExpireWaitListEntry expireWaitListEntry = ExpireWaitListEntryFactory.newInstance();

    expireWaitListEntry.expireWaitListEntry(batchProcessingDate);
  }

  // BEGIN, CR00229186, AK
  /**
   * This method is used to send notification to caseworker.
   *
   * @param workflowName
   * The name of the workflow.
   * @param notificationDetails
   * Contains the notification details.
   *
   * @throws AppException
   * Application Exception
   * @throws InformationalException
   * Informational Exception
   *
   * @deprecated Since 6.0 as this method is not used anywhere and also sending
   * the notification is not supported in the fund wait list.
   */
  @Deprecated
  protected void sendNotification(final String workflowName,
    final NotificationDetails notificationDetails) throws AppException,
      InformationalException {

    java.util.List<NotificationDetails> enactmentStructs = new java.util.ArrayList<NotificationDetails>();

    enactmentStructs.add(notificationDetails);

    curam.util.workflow.impl.EnactmentService.startProcessInV3CompatibilityMode(
      workflowName, enactmentStructs);
  }

  // END, CR00229186

  /**
   * Retrieves the contents of the Wait List Entry into Wait List Entry Details
   * struct and returns it.
   *
   * @param waitListEntry
   * The source wait list entry from which data is extracted.
   *
   * @return Contains fund wait list entry details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected FundWaitListEntryDetails getWaitListEntryDetails(
    final WaitListEntry waitListEntry) throws AppException,
      InformationalException {

    FundWaitListEntryDetails fundWaitListEntryDetails = new FundWaitListEntryDetails();

    fundWaitListEntryDetails.waitListEntryDtls.waitListEntryID = waitListEntry.getID();
    fundWaitListEntryDetails.waitListEntryDtls.position = waitListEntry.getPosition();
    fundWaitListEntryDetails.waitListEntryDtls.expiryDate = waitListEntry.getExpiryDate();
    fundWaitListEntryDetails.waitListEntryDtls.priority = waitListEntry.getPriority().getCode();
    fundWaitListEntryDetails.waitListEntryDtls.position = waitListEntry.getPosition();
    fundWaitListEntryDetails.waitListEntryDtls.status = waitListEntry.getLifecycleState().getCode();
    fundWaitListEntryDetails.waitListEntryDtls.removalReason = waitListEntry.getRemovalReason().getCode();
    fundWaitListEntryDetails.waitListEntryDtls.versionNo = waitListEntry.getVersionNo();
    // BEGIN, CR00200567, AS
    fundWaitListEntryDetails.waitListEntryDtls.comments = waitListEntry.getComments();
    // END, CR00200567

    return fundWaitListEntryDetails;
  }

  /**
   * Sorts the wait list entry status history by the changed date time of the
   * wait list entry.
   *
   * @param statusHistory
   * List of wait list entry status history to be sorted.
   *
   * @return Sorted list of wait list entry status history by its changed date
   * time.
   */
  // BEGIN, CR00200567, AS
  protected List<FundWaitListEntryStatusHistoryDtls> sortWaitListEntryStausHistoryByDateTime(
    final List<FundWaitListEntryStatusHistoryDtls> statusHistory) {

    Collections.sort(statusHistory,
      new Comparator<FundWaitListEntryStatusHistoryDtls>() {
      public int compare(final FundWaitListEntryStatusHistoryDtls lhs,
        final FundWaitListEntryStatusHistoryDtls rhs) {
        return rhs.dtls.changeDateTime.compareTo(lhs.dtls.changeDateTime);
      }
    });
    // END, CR00200567
    return statusHistory;
  }

}
