/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.fundpm.fundfiscalyearlineitem.impl;


import curam.codetable.impl.FUNDFISCALYEARLINEITEMTYPEEntry;
import curam.fundpm.impl.FundFiscalYear;
import curam.util.persistence.StandardEntity;
import curam.util.type.Money;


/**
 * Accessor interface for {@linkplain FundFiscalYearLineItem}.
 */
public interface FundFiscalYearLineItemAccessor extends StandardEntity {

  // BEGIN, CR00199595, AK
  /**
   * Retrieves the allocated total amount for the fund fiscal year line item.
   *
   * @return The allocated total for the fund fiscal year line item.
   */
  public Money getAllocatedTotal();
  // END, CR00199595
  
  /**
   * Gets the unique ID assigned by the organization for a fund fiscal year line
   * item.
   *
   * @return The unique ID assigned by the organization for a fund fiscal year
   * line item.
   */
  public String getLineItemReferenceNumber();

  /**
   * Gets the source of the funding, for example Federal, State.
   *
   * @return The source of the funding, for example Federal, State.
   */
  public FUNDFISCALYEARLINEITEMTYPEEntry getType();

  /**
   * Gets the total amount allocated for the Fund in the Fiscal Year.
   *
   * @return The total amount allocated for the Fund in the Fiscal Year.
   */
  public Money getBudgetAllocatedTotal();

  /**
   * Gets the total amount paid from the fund fiscal year line item.
   *
   * @return The total amount paid from the fund fiscal year line item.
   */
  public Money getPaymentTotal();

  /**
   * Gets the immutable fund fiscal year for which the line item is created.
   *
   * @return The immutable fund fiscal year.
   */
  public FundFiscalYear getFundFiscalYear();

}
