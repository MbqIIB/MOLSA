/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.fundpm.fundfiscalyearlineitem.impl;


import com.google.inject.ImplementedBy;

import curam.codetable.impl.FUNDFISCALYEARLINEITEMTYPEEntry;
import curam.fundpm.impl.FundFiscalYear;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;
import curam.util.type.Money;


/**
 * A Fund Fiscal Year Line Item contains details of monies available from a
 * funding source for a fund fiscal year.
 *
 */
@ImplementedBy(FundFiscalYearLineItemImpl.class)
public interface FundFiscalYearLineItem extends FundFiscalYearLineItemAccessor,
    Insertable, OptimisticLockModifiable, LogicallyDeleteable, DateRanged,
    Commented {
  
  /**
   * Sets the source of the funding, for example Federal, State.
   *
   * @param fundFiscalYearLineItemType
   * The source of the funding, for example Federal, State.
   */
  void setType(FUNDFISCALYEARLINEITEMTYPEEntry fundFiscalYearLineItemType);

  /**
   * Sets the total amount allocated for the Fund in the Fiscal Year.
   *
   * @param bugetAllocatedTotal
   * The total amount allocated for the Fund in the Fiscal Year.
   */
  void setBudgetAllocatedTotal(Money bugetAllocatedTotal);

  /**
   * Sets the total amount paid from the fund fiscal year line item.
   *
   * @param paymentTotal
   * The total amount paid from the fund fiscal year line item.
   */
  void setPaymentTotal(Money paymentTotal);

  /**
   * Sets the fund fiscal year for which the line item is created.
   *
   * @param fundFiscalYear
   * The fund fiscal year.
   */
  void setFundFiscalYear(FundFiscalYear fundFiscalYear);

  /**
   * Sets the period of the fund fiscal year line item.
   *
   * @param dateRange
   * The period of the fund fiscal year line item.
   */
  void setDateRange(DateRange dateRange);

}
