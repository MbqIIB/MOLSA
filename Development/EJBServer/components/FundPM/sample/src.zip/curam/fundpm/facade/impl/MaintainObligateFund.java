/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.fundpm.facade.impl;


import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.CREDITDEBITEntry;
import curam.fundpm.facade.struct.FundFiscalYearKey;
import curam.fundpm.facade.struct.ObligationDetails;
import curam.fundpm.facade.struct.ObligationDetailsList;
import curam.fundpm.facade.struct.ObligationHistoryDetails;
import curam.fundpm.facade.struct.ObligationHistoryDetailsList;
import curam.fundpm.facade.struct.ObligationKey;
import curam.obligation.impl.Obligation;
import curam.obligation.impl.ObligationDAO;
import curam.obligation.impl.ObligationHistory;
import curam.obligation.impl.ObligationHistoryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This class manages the Obligation of fund.
 */
public abstract class MaintainObligateFund extends curam.fundpm.facade.base.MaintainObligateFund {

  /**
   * Reference to Obligation DAO.
   */
  @Inject
  private ObligationDAO obligationDAO;
  
  // BEGIN, CR00200008, AK
  /**
   * Reference to Obligation History DAO.
   */
  @Inject
  ObligationHistoryDAO obligationHistoryDAO;
  // END, CR00200008
  
  /**
   * Constructor for MaintainObligateFund.
   */
  protected MaintainObligateFund() {
    // Private no-arg constructor for use only by Guice
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Reads all the obligations for a particular fund fiscal year.
   *
   * @param fundFiscalYearKey The fund fiscal year ID.
   *
   * @return The list of obligation details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ObligationDetailsList readAllObligationsForFundFiscalYear(
    FundFiscalYearKey fundFiscalYearKey) throws AppException,
      InformationalException {

    List<Obligation> obligations = obligationDAO.searchByFundFiscalYear(
      fundFiscalYearKey.fundFiscalYearID);

    ObligationDetailsList obligationDetailsList = new ObligationDetailsList();

    for (Obligation obligation : obligations) {
      ObligationDetails obligationDetails = new ObligationDetails();

      obligationDetails.dtls.transactionType = obligation.getTransactionType().getCode();
      obligationDetails.dtls.debitCreditType = obligation.getCreditDebitType().getCode();
      if (CREDITDEBITEntry.CREDIT.equals(obligation.getCreditDebitType())) {
        obligationDetails.creditedAmount = obligation.getAmount();
      } else {
        obligationDetails.debitedAmount = obligation.getAmount();
      }
      obligationDetails.dtls.creationDate = obligation.getCreationDate();
      obligationDetails.dtls.obligationID = obligation.getID();
      // BEGIN, CR00200567, AS
      obligationDetails.dtls.amount = obligation.getAmount();
      obligationDetails.dtls.startDate = obligation.getDateRange().start();
      obligationDetails.dtls.endDate = obligation.getDateRange().end();
      // END, CR00200567
      obligationDetailsList.detailsList.addRef(obligationDetails);
    }
    
    return obligationDetailsList;
  }
  
  // BEGIN, CR00200008, AK
  /**
   * Reads all the obligation history details for a particular obligation.
   *
   * @param obligationKey
   * The obligation ID.
   *
   * @return The list of obligation history details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ObligationHistoryDetailsList readAllObligationHistoryDetails(
    ObligationKey obligationKey) throws AppException, InformationalException {

    ObligationHistoryDetailsList obligationHistoryDetailsList = new ObligationHistoryDetailsList();

    Set<ObligationHistory> obligationHistories = obligationHistoryDAO.searchByObligationID(
      obligationKey.obligationID);

    for (ObligationHistory obligationHistory : obligationHistories) {
      ObligationHistoryDetails obligationHistoryDetails = new ObligationHistoryDetails();

      obligationHistoryDetails.dtls.amount = obligationHistory.getAmount();
      obligationHistoryDetails.dtls.startDate = obligationHistory.getDateRange().start();
      obligationHistoryDetails.dtls.endDate = obligationHistory.getDateRange().end();
      obligationHistoryDetails.dtls.obligationHistoryID = obligationHistory.getID();
      obligationHistoryDetails.dtls.obligationID = obligationHistory.getObligation().getID();
      obligationHistoryDetails.creationDate = obligationHistory.getObligation().getCreationDate();
      obligationHistoryDetails.dtls.debitCreditType = obligationHistory.getCreditDebitType().getCode();

      obligationHistoryDetailsList.detailsList.addRef(obligationHistoryDetails);
    }

    return obligationHistoryDetailsList;

  }

  // END, CR00200008
  
  /**
   * Reads the details of Obligation for a specified Obligation Key.
   *
   * @param obligationKey
   * Contains the obligation key details.
   *
   * @return The obligation details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ObligationDetails viewObligation(final ObligationKey obligationKey)
    throws AppException, InformationalException {

    ObligationDetails obligationDetails = new ObligationDetails();

    Obligation obligation = obligationDAO.get(obligationKey.obligationID);

    obligationDetails.dtls.obligationID = obligation.getID();
    obligationDetails.dtls.transactionType = obligation.getTransactionType().getCode();
    obligationDetails.dtls.debitCreditType = obligation.getCreditDebitType().getCode();
    obligationDetails.dtls.amount = obligation.getAmount();
    obligationDetails.dtls.creationDate = obligation.getCreationDate();
    obligationDetails.dtls.startDate = obligation.getDateRange().start();
    obligationDetails.dtls.endDate = obligation.getDateRange().end();
    
    // BEGIN, CR00197894, AK
    obligationDetails.dtls.relatedID = obligation.getRelatedID();
    obligationDetails.dtls.relatedType = obligation.getRelatedType().getCode();
    // END, CR00197894
    
    // BEGIN, CR00199595, AK
    obligationDetails.dtls.fundFiscalYearID = obligation.getFundFiscalYear().getID();
    obligationDetails.dtls.versionNo = obligation.getVersionNo();
    // END, CR00199595

    return obligationDetails;
  }
}
