/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.fundpm.facade.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.google.inject.Inject;

import curam.codetable.FUNDFISCALYEARLINEITEMTYPE;
import curam.codetable.impl.BUDGETADJUSTMENTTYPEEntry;
import curam.codetable.impl.CREDITDEBITEntry;
import curam.codetable.impl.FUNDFISCALYEARLINEITEMTYPEEntry;
import curam.fundpm.facade.struct.FundFiscalYearKey;
import curam.fundpm.facade.struct.FundFiscalYearLineItemDetails;
import curam.fundpm.facade.struct.FundFiscalYearLineItemDetailsList;
import curam.fundpm.facade.struct.FundFiscalYearLineItemKey;
import curam.fundpm.facade.struct.KeyVersionDetails;
import curam.fundpm.facade.struct.ViewFundFiscalYearLineItemDetails;
import curam.fundpm.fundfiscalyearlineitem.impl.FundFiscalYearLineItem;
import curam.fundpm.fundfiscalyearlineitem.impl.FundFiscalYearLineItemDAO;
import curam.fundpm.impl.BudgetAdjustmentDAO;
import curam.fundpm.impl.FundFiscalYearDAO;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.type.CodeTable;
import curam.util.type.DateRange;
import curam.util.type.Money;


/**
 * Facade layer class having API for Maintain Fund Fiscal Year Line Item.
 */
public abstract class MaintainFundFiscalYearLineItem extends curam.fundpm.facade.base.MaintainFundFiscalYearLineItem {

  /**
   * Reference to fund fiscal year line item DAO.
   */
  @Inject
  private FundFiscalYearLineItemDAO fundFiscalYearLineItemDAO;

  /**
   * Reference to fund fiscal year DAO.
   */
  @Inject
  private FundFiscalYearDAO fundFiscalYearDAO;

  /**
   * Reference to budget adjustment DAO.
   */
  @Inject
  private BudgetAdjustmentDAO budgetAdjustmentDAO;

  /**
   * Constructor for the class.
   */
  public MaintainFundFiscalYearLineItem() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a fund fiscal year line item for a fund fiscal year.
   *
   * @param fundFiscalYearLineItemDetails
   * The fund fiscal year line item details.
   *
   * @return The fund fiscal year line item ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public FundFiscalYearLineItemKey createLineItem(
    FundFiscalYearLineItemDetails fundFiscalYearLineItemDetails)
    throws AppException, InformationalException {

    FundFiscalYearLineItem fundFiscalYearLineItem = fundFiscalYearLineItemDAO.newInstance();

    fundFiscalYearLineItem.setBudgetAllocatedTotal(
      fundFiscalYearLineItemDetails.dtls.budgetAllocatedTotal);
    fundFiscalYearLineItem.setFundFiscalYear(
      fundFiscalYearDAO.get(fundFiscalYearLineItemDetails.dtls.fundFiscalYearID));
    fundFiscalYearLineItem.setPaymentTotal(
      fundFiscalYearLineItemDetails.dtls.paymentTotal);
    fundFiscalYearLineItem.setType(
      FUNDFISCALYEARLINEITEMTYPEEntry.get(
        fundFiscalYearLineItemDetails.dtls.type));
    fundFiscalYearLineItem.setDateRange(
      new DateRange(fundFiscalYearLineItemDetails.dtls.startDate,
      fundFiscalYearLineItemDetails.dtls.endDate));
    fundFiscalYearLineItem.setComments(
      fundFiscalYearLineItemDetails.dtls.comments);
    fundFiscalYearLineItem.insert();

    FundFiscalYearLineItemKey fiscalYearLineItemKey = new FundFiscalYearLineItemKey();

    fiscalYearLineItemKey.key.fundFclYrLineItemID = fundFiscalYearLineItem.getID();

    curam.fundpm.impl.BudgetAdjustment budgetAdjustmentObj = budgetAdjustmentDAO.newInstance();

    budgetAdjustmentObj.setAmount(
      fundFiscalYearLineItemDetails.dtls.budgetAllocatedTotal);
    budgetAdjustmentObj.setCreditDebitType(CREDITDEBITEntry.CREDIT);
    budgetAdjustmentObj.setRelatedID(
      fiscalYearLineItemKey.key.fundFclYrLineItemID);
    budgetAdjustmentObj.setRelatedType(
      BUDGETADJUSTMENTTYPEEntry.FUNDFISCALYEARLINEITEM);
    budgetAdjustmentObj.setAllocationReferenceNumber(
      fundFiscalYearLineItemDetails.dtls.lineItemRefNo);
    budgetAdjustmentObj.setRelatedType(
      BUDGETADJUSTMENTTYPEEntry.FUNDFISCALYEARLINEITEM);
    budgetAdjustmentObj.insert();

    return fiscalYearLineItemKey;
  }

  /**
   * Logically deletes the fund fiscal year line item.
   *
   * @param keyVersionDetails
   * Contains the fund fiscal year line item ID and version number.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deleteLineItem(KeyVersionDetails keyVersionDetails)
    throws AppException, InformationalException {

    FundFiscalYearLineItem fundFiscalYearLineItem = fundFiscalYearLineItemDAO.get(
      keyVersionDetails.id);

    fundFiscalYearLineItem.cancel(keyVersionDetails.versionNo);

  }

  /**
   * Retrieves the list of fund fiscal year line items related to the fund
   * fiscal year.
   *
   * @param fundFiscalYearKey
   * Contains the fund fiscal year ID.
   *
   * @return The list of fund fiscal year line item details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public FundFiscalYearLineItemDetailsList listLineItems(
    FundFiscalYearKey fundFiscalYearKey) throws AppException,
      InformationalException {

    List<FundFiscalYearLineItem> fundFiscalYearLineItems = fundFiscalYearLineItemDAO.searchByFundFiscalYear(
      fundFiscalYearDAO.get(fundFiscalYearKey.fundFiscalYearID));

    FundFiscalYearLineItemDetailsList fundFiscalYearLineItemDetailsList = new FundFiscalYearLineItemDetailsList();
    
    List<FundFiscalYearLineItemDetails> fundFiscalYearLineItemDtlsList = new ArrayList<FundFiscalYearLineItemDetails>();

    for (FundFiscalYearLineItem fundFiscalYearLineItem : fundFiscalYearLineItems) {

      FundFiscalYearLineItemDetails fundFiscalYearLineItemDetails = new FundFiscalYearLineItemDetails();

      // BEGIN, CR00176297, ABS
      fundFiscalYearLineItemDetails.dtls.budgetAllocatedTotal = fundFiscalYearLineItem.getAllocatedTotal();
      // END, CR00176297
      fundFiscalYearLineItemDetails.dtls.paymentTotal = fundFiscalYearLineItem.getPaymentTotal();
      fundFiscalYearLineItemDetails.dtls.type = fundFiscalYearLineItem.getType().getCode();
      fundFiscalYearLineItemDetails.dtls.versionNo = fundFiscalYearLineItem.getVersionNo();
      fundFiscalYearLineItemDetails.dtls.fundFclYrLineItemID = fundFiscalYearLineItem.getID();
      // BEGIN, CR00199595, AK
      fundFiscalYearLineItemDtlsList.add(fundFiscalYearLineItemDetails);
    }
    // BEGIN, CR00187494, AS
    Collections.sort(fundFiscalYearLineItemDtlsList,
      new Comparator<FundFiscalYearLineItemDetails>() {
      public int compare(final FundFiscalYearLineItemDetails lhs,
        FundFiscalYearLineItemDetails rhs) {
        try {
          return CodeTable.getOneItem(FUNDFISCALYEARLINEITEMTYPE.TABLENAME, lhs.dtls.type).compareTo(
            CodeTable.getOneItem(FUNDFISCALYEARLINEITEMTYPE.TABLENAME,
            rhs.dtls.type));
        } catch (AppException ex) {
          ValidationHelper.addValidationError(ex);
        } catch (InformationalException ex) {
          throw new AppRuntimeException(ex);
        }
        return 0;
      }
    });
    
    // END, CR00199595

    for (FundFiscalYearLineItemDetails fundLineItemDetails : fundFiscalYearLineItemDtlsList) {
      fundFiscalYearLineItemDetailsList.detailsList.addRef(fundLineItemDetails);
    }

    return fundFiscalYearLineItemDetailsList;
    // END, CR00187494
  }

  /**
   * Modifies the fund fiscal year line item details.
   *
   * @param fundFiscalYearLineItemDetails
   * The fund fiscal year line item details to be modified.
   *
   * @return The fund fiscal year line item ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public FundFiscalYearLineItemKey modifyLineItem(
    FundFiscalYearLineItemDetails fundFiscalYearLineItemDetails)
    throws AppException, InformationalException {

    curam.fundpm.fundfiscalyearlineitem.impl.FundFiscalYearLineItem fundFiscalYearLineItem = fundFiscalYearLineItemDAO.get(
      fundFiscalYearLineItemDetails.dtls.fundFclYrLineItemID);

    fundFiscalYearLineItem.setType(
      FUNDFISCALYEARLINEITEMTYPEEntry.get(
        fundFiscalYearLineItemDetails.dtls.type));
    fundFiscalYearLineItem.setComments(
      fundFiscalYearLineItemDetails.dtls.comments);
    fundFiscalYearLineItem.setDateRange(
      new DateRange(fundFiscalYearLineItemDetails.dtls.startDate,
      fundFiscalYearLineItemDetails.dtls.endDate));
    fundFiscalYearLineItem.modify(fundFiscalYearLineItemDetails.dtls.versionNo);

    FundFiscalYearLineItemKey fiscalYearLineItemKey = new FundFiscalYearLineItemKey();

    fiscalYearLineItemKey.key.fundFclYrLineItemID = fundFiscalYearLineItem.getID();
    return fiscalYearLineItemKey;
  }

  /**
   * Retrieves the fund fiscal year line item details.
   *
   * @param fundFiscalYearLineItemKey
   * Contains fund fiscal year line item ID.
   *
   * @return The fund fiscal year line item details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewFundFiscalYearLineItemDetails viewLineItem(
    FundFiscalYearLineItemKey fundFiscalYearLineItemKey) throws AppException,
      InformationalException {

    FundFiscalYearLineItem fundFiscalYearLineItem = fundFiscalYearLineItemDAO.get(
      fundFiscalYearLineItemKey.key.fundFclYrLineItemID);

    ViewFundFiscalYearLineItemDetails fundFiscalYearLineItemDetails = new ViewFundFiscalYearLineItemDetails();

    // BEGIN, CR00176297, ABS
    fundFiscalYearLineItemDetails.lineItemDetails.dtls.budgetAllocatedTotal = fundFiscalYearLineItem.getAllocatedTotal();
    // END, CR00176297
    fundFiscalYearLineItemDetails.remainingActualBalance = new Money(
      fundFiscalYearLineItemDetails.lineItemDetails.dtls.budgetAllocatedTotal.getValue()
        - fundFiscalYearLineItem.getPaymentTotal().getValue());
    fundFiscalYearLineItemDetails.lineItemDetails.dtls.paymentTotal = fundFiscalYearLineItem.getPaymentTotal();
    fundFiscalYearLineItemDetails.lineItemDetails.dtls.type = fundFiscalYearLineItem.getType().getCode();
    fundFiscalYearLineItemDetails.lineItemDetails.dtls.versionNo = fundFiscalYearLineItem.getVersionNo();
    fundFiscalYearLineItemDetails.lineItemDetails.dtls.startDate = fundFiscalYearLineItem.getDateRange().start();
    fundFiscalYearLineItemDetails.lineItemDetails.dtls.endDate = fundFiscalYearLineItem.getDateRange().end();
    fundFiscalYearLineItemDetails.lineItemDetails.dtls.lineItemRefNo = fundFiscalYearLineItem.getLineItemReferenceNumber();
    fundFiscalYearLineItemDetails.lineItemDetails.dtls.recordStatus = fundFiscalYearLineItem.getLifecycleState().getCode();
    fundFiscalYearLineItemDetails.lineItemDetails.dtls.fundFiscalYearID = fundFiscalYearLineItem.getFundFiscalYear().getID();
    fundFiscalYearLineItemDetails.lineItemDetails.dtls.comments = fundFiscalYearLineItem.getComments();
    fundFiscalYearLineItemDetails.relatedType = BUDGETADJUSTMENTTYPEEntry.FUNDFISCALYEARLINEITEM.getCode();

    return fundFiscalYearLineItemDetails;
  }

}
