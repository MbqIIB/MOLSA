/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.fundpm.fundfiscalyearlineitem.impl;


import java.util.List;

import com.google.inject.Singleton;

import curam.fundpm.impl.FundFiscalYear;
import curam.fundpm.sl.entity.impl.FundFclYrLineItemAdapter;
import curam.fundpm.sl.entity.struct.FundFclYrLineItemDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of {@linkplain FundFiscalYearLineItemDAO}.
 */
@Singleton
public class FundFiscalYearLineItemDAOImpl extends StandardDAOImpl<FundFiscalYearLineItem, FundFclYrLineItemDtls> implements
  FundFiscalYearLineItemDAO {

  /**
   * Single instance of the entity adapter shared across all DAO
   * implementations.
   */
  private static FundFclYrLineItemAdapter fundFclYrLineItemAdapter = new FundFclYrLineItemAdapter();

  /**
   * Constructor for the class.
   */
  protected FundFiscalYearLineItemDAOImpl() {
    // Protected no-arg constructor for use only by Guice
    super(fundFclYrLineItemAdapter, FundFiscalYearLineItem.class);

  }

  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00199742, RD
  public List<FundFiscalYearLineItem> searchByFundFiscalYear(
    final FundFiscalYear fundFiscalYear) {
    // END, CR00199742
    return newList(
      fundFclYrLineItemAdapter.searchByFundFiscalYear(fundFiscalYear.getID()));
  }
}
