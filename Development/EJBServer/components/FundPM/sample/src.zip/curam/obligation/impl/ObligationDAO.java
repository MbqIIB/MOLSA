/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.obligation.impl;


import java.util.List;
import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.FUNDRELATIONTYPEEntry;
import curam.codetable.impl.OBLIGATIONRELATEDTYPEEntry;
import curam.util.persistence.StandardDAO;
import curam.util.type.Date;


/**
 * Data access for {@linkplain Obligation}.
 */
@ImplementedBy(ObligationDAOImpl.class)
public interface ObligationDAO extends StandardDAO<Obligation> {
  
  /**
   * Returns all the obligations for the fund fiscal year.
   *
   * @param fundFiscalYearID The fund fiscal year ID.
   *
   * @return The list of obligations.
   */
  public List<Obligation> searchByFundFiscalYear(long fundFiscalYearID);

  /**
   * Retrieves the list of obligations based on the related ID and related type.
   *
   * @param relatedID
   * The unique reference number of the related financial transaction
   * which caused the obligation to be created, such as a Product
   * Delivery or Planned Item.
   * @param relatedType
   * The type of financial transaction which caused the obligation to
   * be created, such as a Product Delivery or Planned Item.
   *
   * @return Set of obligations matching the input criteria.
   */
  public Set<Obligation> searchByRelatedIDAndRelatedType(
    Long relatedID, OBLIGATIONRELATEDTYPEEntry relatedType);
  
  // BEGIN, CR00188291, AS
  /**
   * Retrieves the list of obligations based on the program fund ID and
   * obligation related type.
   *
   * @param programFundID
   * The identifier of the program fund.
   *
   * @param obligationRelatedType
   * The type of financial transaction which caused the obligation to
   * be created, such as a Product Delivery or Planned Item.
   *
   * @return List of obligations matching the input criteria.
   */
  public List<Obligation> searchByProgramFundIDandObligationRelatedType(
    long programFundID, OBLIGATIONRELATEDTYPEEntry obligationRelatedType);
  // END, CR00188291
  
  // BEGIN, CR00205954, AS
  // BEGIN, CR00200430, AS
  /**
   * Retrieves the list of obligation based on the funded item rules link
   * period, related id and related type of Product/Service Offering and
   * obligation related type of Product Delivery/Planned Item.
   *
   * @param startDate
   * The start date of funded item rules link.
   * @param endDate
   * The end date of funded item rules link.
   * @param relatedID
   * Contains the funded item rules link related ID.
   * @param obligationRelatedType
   * The type of financial transaction which caused the obligation to
   * be created, such as a Product Delivery or Planned Item.
   * @param fundRulesLinkRelatedType
   * The type of financial transaction which caused the funded item
   * rules link to be created, such as a Product/Service Offering.
   *
   * @return List of obligations matching the input criteria.
   */
  // BEGIN, CR00200567, AS
  public List<Obligation> searchByPeriodRelatedIDAndRelatedType(Date startDate,
    Date endDate, long relatedID,
    OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
    FUNDRELATIONTYPEEntry fundRulesLinkRelatedType);
  // END, CR00200567
  // END, CR00200430
  // END, CR00205954
}
