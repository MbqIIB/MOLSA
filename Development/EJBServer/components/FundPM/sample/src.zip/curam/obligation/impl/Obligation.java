/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.obligation.impl;


import com.google.inject.ImplementedBy;

import curam.codetable.impl.CREDITDEBITEntry;
import curam.codetable.impl.FUNDRELATIONTYPEEntry;
import curam.codetable.impl.OBLIGATIONRELATEDTYPEEntry;
import curam.codetable.impl.OBLIGATIONTRANSACTIONTYPEEntry;
import curam.fundpm.impl.FundFiscalYear;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;
import curam.util.type.Money;


/**
 * This interface provides methods related to Obligation functionality. An
 * obligation is a type of fund fiscal year transaction which, when created,
 * impacts the budgeted balance of the fund fiscal year by the value of the
 * obligation amount.
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
@ImplementedBy(ObligationImpl.class)
public interface Obligation extends ObligationAccessor, Insertable, DateRanged,
    OptimisticLockModifiable {

  // BEGIN, CR00188402, AK
  /**
   * Creates an obligation for a fund. System searches a fund fiscal year for
   * the given fund and the obligation period. An obligation is created for the
   * retrieved fund fiscal year and the total obligated amount will be modified
   * for the fund fiscal year. If the fund fiscal year is not having sufficient
   * funds and the wait list allowed indicator is enabled for the fund
   * configuration, then the participant will be wait listed for the fund fiscal
   * year.
   *
   * @bowrite Obligation
   * @bowrite WaitList
   * @boread Fund
   * @bowrite FundFiscalYear
   *
   * @param programFundID
   * The key of the program fund.
   * @param requestedAmount
   * The amount requested to obligate a fund.
   * @param obligationPeriod
   * The period for which the fund needs to be obligated.
   * @param obligationRelatedID
   * The key of the related financial transaction which causes the
   * obligation, such as a Product Delivery or Planned Item.
   * @param obligationRelatedType
   * The type of the related financial transaction which causes the
   * obligation, such as a Product Delivery or Planned Item. * @param
   * caseParticipantRoleID The case participant role ID of the client.
   * @param caseParticipantRoleID
   * The case participant role key of the client.
   * @param waitListExpiryDays
   * The expiry days of the wait list.
   *
   * @return The obligation result which contains the list of obligations, if
   * obligation is succeeded or the wait list, if the client is wait
   * listed.
   *
   * @see curam.obligation.impl.ObligationImpl#createObligation(Long, Money,
   * DateRange, Long, OBLIGATIONRELATEDTYPEEntry, Long, Integer) The
   * default implementation -
   * curam.obligation.impl.ObligationImpl#createObligation(Long, Money,
   * DateRange, Long, OBLIGATIONRELATEDTYPEEntry, Long, Integer).
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  public ObligationResult createObligation(final Long programFundID,
    final Money requestedAmount, final DateRange obligationPeriod,
    final Long obligationRelatedID,
    final OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
    final Long caseParticipantRoleID, final Integer waitListExpiryDays)
    throws AppException, InformationalException;
  // END, CR00188402
  
  // BEGIN, CR00199055, AK
  /**
   * Gets the immutable fund fiscal year for the obligation.
   *
   * @return The immutable fund fiscal year.
   */
  public FundFiscalYear getFundFiscalYear();
  // END, CR00199055

  /**
   * Processes the obligation for a financial transaction. The system first
   * checks whether any obligations exist for the originating case. If there are
   * any obligations, then the existing obligation will be modified. Otherwise,
   * it retrieves a list of funds for creating an obligation. It then selects
   * and evaluates each fund from the retrieved list to check whether any of the
   * funds can be obligated or not. If a fund which can be obligated is
   * selected, then an obligation will be created for the selected fund. If none
   * of the funds are selected, then system returns all the fund fiscal years
   * which can be wait listed and puts the client on the wait list for these
   * fund fiscal years.
   *
   * @boread Obligation
   * @bowrite Obligation
   * @bowrite WaitList
   * @boread Fund
   * @bowrite FundFiscalYear
   *
   * @param fundRelatedID
   * The key of the funded item which causes the obligation. For e.g.,
   * ProductID or ServiceOfferingID.
   * @param fundRelationType
   * The type of the funded item which causes the obligation. For e.g.,
   * Product or Service Offering.
   * @param requestedAmount
   * The amount requested to obligate a fund.
   * @param obligationPeriod
   * The period for which a fund needs to be obligated.
   * @param obligationRelatedID
   * The key of the related financial transaction which causes the
   * obligation, such as a Product Delivery or Planned Item.
   * @param obligationRelatedType
   * The type of financial transaction which causes the obligation,
   * such as a Product Delivery or Planned Item.
   * @param caseParticipantRoleID
   * The case participant role key of the client.
   * @param waitListExpiryDays
   * The expiry days of the wait list.
   *
   * @return The obligation result which contains the list of obligations, if
   * obligation is succeeded or the wait list, if the client is wait
   * listed.
   *
   * @see curam.obligation.impl.ObligationImpl#processObligation(Long,
   * FUNDRELATIONTYPEEntry, Money, DateRange, Long,
   * OBLIGATIONRELATEDTYPEEntry, Long, Integer) The default implementation
   * - curam.obligation.impl.ObligationImpl#processObligation(Long,
   * FUNDRELATIONTYPEEntry, Money, DateRange, Long,
   * OBLIGATIONRELATEDTYPEEntry, Long, Integer).
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  public ObligationResult processObligation(final Long fundRelatedID,
    final FUNDRELATIONTYPEEntry fundRelationType, final Money requestedAmount,
    final DateRange obligationPeriod, final Long obligationRelatedID,
    final OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
    final Long caseParticipantRoleID, final Integer waitListExpiryDays)
    throws AppException, InformationalException;

  /**
   * Sets the financial amount associated with the obligation.
   *
   * @param amount
   * The financial amount associated with the obligation.
   */
  public void setAmount(final Money amount);
  
  /**
   * Sets the unique reference number of the related financial transaction which
   * caused the obligation to be created, such as a Product Delivery or Planned
   * Item.
   *
   * @param relatedID
   * The unique reference number of the related financial transaction
   * which caused the obligation to be created, such as a Product
   * Delivery or Planned Item.
   */
  public void setRelatedID(final Long relatedID);

  /**
   * Sets the type of transaction, such as Obligation or Obligation adjustment.
   *
   * @param transactionType
   * The type of transaction, such as Obligation or Obligation
   * adjustment.
   */
  public void setTransactionType(final OBLIGATIONTRANSACTIONTYPEEntry transactionType);

  /**
   * Sets the indicator if the obligation increases or decreases the fund fiscal
   * year Remaining Budgeted Balance, and the Obligated Total.
   *
   * @param creditDebitType
   * The indicator if the obligation increases or decreases the fund
   * fiscal year Remaining Budgeted Balance, and the Obligated Total.
   */
  public void setCreditDebitType(final CREDITDEBITEntry creditDebitType);

  /**
   * Sets the obligation period.
   *
   * @param dateRange
   * The obligation period.
   */
  public void setDateRange(final DateRange dateRange);

  /**
   * Sets the fund fiscal year ID for the obligation.
   *
   * @param fundFiscalYearID
   * The fund fiscal year ID.
   */
  public void setFundFiscalYearID(final Long fundFiscalYearID);

  /**
   * Sets the type of financial transaction which caused the obligation to be
   * created, such as a Product Delivery or Planned Item
   *
   * @param relatedType
   * The type of financial transaction which caused the obligation to
   * be created, such as a Product Delivery or Planned Item
   */
  public void setRelatedType(final OBLIGATIONRELATEDTYPEEntry relatedType);

  // BEGIN, CR00199055, AK
  /**
   * Modifies an obligation for a fund fiscal year for the given related ID and
   * related type. The system searches for an obligation for the given
   * obligation related ID and related type. If the obligation request falls in
   * the same fund fiscal year, it then modifies the obligation amount and/or
   * obligation period to the new values supplied by the user. If the obligation
   * request falls in a new fund fiscal year, then it creates a new obligation
   * and modifies the total obligated amount for the new fund fiscal year. It
   * then adjusts the amount of the previous obligation to zero and subtracts
   * this amount from the total obligated amount of the associated fund fiscal
   * year.
   *
   * @boread Obligation
   * @bowrite Obligation
   * @bowrite FundFiscalYear
   *
   * @param requestedAmount
   * The amount requested to obligate a fund.
   * @param obligationPeriod
   * The period for which a fund needs to be obligated.
   * @param obligationRelatedID
   * The key of the related financial transaction which causes the
   * obligation, such as a Product Delivery or Planned Item.
   * @param obligationRelatedType
   * The type of financial transaction which causes the obligation,
   * such as a Product Delivery or Planned Item.
   * @return The obligation result contains a list of obligations.
   *
   * @see curam.obligation.impl.ObligationImpl#updateObligation(Money,
   * DateRange, Long, OBLIGATIONRELATEDTYPEEntry) The default
   * implementation -
   * curam.obligation.impl.ObligationImpl#updateObligation(Money,
   * DateRange, Long, OBLIGATIONRELATEDTYPEEntry).
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  public ObligationResult updateObligation(final Money requestedAmount,
    final DateRange obligationPeriod, final Long obligationRelatedID,
    final OBLIGATIONRELATEDTYPEEntry obligationRelatedType)
    throws AppException, InformationalException;

  /**
   * Interface to the obligation events functionality surrounding the
   * processObligation method.
   */
  public interface ObligationProcessObligationEvents {

    /**
     * Event interface invoked before the main body of the processObligation
     * method. {@linkplain curam.obligation.impl.Obligation#processObligation}
     *
     * @param obligation
     * The object instance as it was before the main body of the
     * processObligation method.
     * @param fundRelatedID
     * The parameter as passed to the processObligation method.
     * @param fundRelationType
     * The parameter as passed to the processObligation method.
     * @param requestedAmount
     * The parameter as passed to the processObligation method.
     * @param obligationPeriod
     * The parameter as passed to the processObligation method.
     * @param obligationRelatedID
     * The parameter as passed to the processObligation method.
     * @param obligationRelatedType
     * The parameter as passed to the processObligation method.
     * @param caseParticipantRoleID
     * The parameter as passed to the processObligation method.
     * @param waitListExpiryDays
     * The parameter as passed to the processObligation method.
     */
    public void preProcessObligation(ObligationAccessor obligation,
      Long fundRelatedID, FUNDRELATIONTYPEEntry fundRelationType,
      Money requestedAmount, DateRange obligationPeriod,
      Long obligationRelatedID,
      OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
      Long caseParticipantRoleID, Integer waitListExpiryDays);

    /**
     * Event interface invoked after the main body of the processObligation
     * method. {@linkplain curam.obligation.impl.Obligation#processObligation}
     *
     * @param obligation
     * The object instance as it was after the main body of the
     * processObligation method.
     * @param fundRelatedID
     * The parameter as passed to the processObligation method.
     * @param fundRelationType
     * The parameter as passed to the processObligation method.
     * @param requestedAmount
     * The parameter as passed to the processObligation method.
     * @param obligationPeriod
     * The parameter as passed to the processObligation method.
     * @param obligationRelatedID
     * The parameter as passed to the processObligation method.
     * @param obligationRelatedType
     * The parameter as passed to the processObligation method.
     * @param caseParticipantRoleID
     * The parameter as passed to the processObligation method.
     * @param waitListExpiryDays
     * The parameter as passed to the processObligation method.
     * @param returnValue
     * The return value updated by the Event Handler.
     */
    public void postProcessObligation(ObligationAccessor obligation,
      Long fundRelatedID, FUNDRELATIONTYPEEntry fundRelationType,
      Money requestedAmount, DateRange obligationPeriod,
      Long obligationRelatedID,
      OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
      Long caseParticipantRoleID, Integer waitListExpiryDays,
      ObligationResult returnValue);
  }
  

  /**
   * Interface to the obligation events functionality surrounding the
   * createObligation method.
   */
  public interface ObligationCreateObligationEvents {

    /**
     * Event interface invoked before the main body of the createObligation
     * method. {@linkplain curam.obligation.impl.Obligation#createObligation}
     *
     * @param obligation
     * The object instance as it was before the main body of the
     * createObligation method.
     * @param programFundID
     * The parameter as passed to the createObligation method.
     * @param requestedAmount
     * The parameter as passed to the createObligation method.
     * @param obligationPeriod
     * The parameter as passed to the createObligation method.
     * @param obligationRelatedID
     * The parameter as passed to the createObligation method.
     * @param obligationRelatedType
     * The parameter as passed to the createObligation method.
     * @param caseParticipantRoleID
     * The parameter as passed to the createObligation method.
     * @param waitListExpiryDays
     * The parameter as passed to the createObligation method.
     */
    public void preCreateObligation(ObligationAccessor obligation,
      Long programFundID, Money requestedAmount, DateRange obligationPeriod,
      Long obligationRelatedID,
      OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
      Long caseParticipantRoleID, Integer waitListExpiryDays);

    /**
     * Event interface invoked after the main body of the createObligation
     * method. {@linkplain curam.obligation.impl.Obligation#createObligation}
     *
     * @param obligation
     * The object instance as it was after the main body of the
     * createObligation method.
     * @param programFundID
     * The parameter as passed to the createObligation method.
     * @param requestedAmount
     * The parameter as passed to the createObligation method.
     * @param obligationPeriod
     * The parameter as passed to the createObligation method.
     * @param obligationRelatedID
     * The parameter as passed to the createObligation method.
     * @param obligationRelatedType
     * The parameter as passed to the createObligation method.
     * @param caseParticipantRoleID
     * The parameter as passed to the createObligation method.
     * @param waitListExpiryDays
     * The parameter as passed to the createObligation method.
     * @param returnValue
     * The return value updated by the Event Handler.
     */
    public void postCreateObligation(ObligationAccessor obligation,
      Long programFundID, Money requestedAmount, DateRange obligationPeriod,
      Long obligationRelatedID,
      OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
      Long caseParticipantRoleID, Integer waitListExpiryDays,
      ObligationResult returnValue);
  }


  /**
   * Interface to the obligation events functionality surrounding the
   * updateObligation method.
   */
  public interface ObligationUpdateObligationEvents {

    /**
     * Event interface invoked before the main body of the updateObligation
     * method. {@linkplain curam.obligation.impl.Obligation#updateObligation}
     *
     * @param obligation
     * The object instance as it was before the main body of the
     * updateObligation method.
     * @param requestedAmount
     * The parameter as passed to the updateObligation method.
     * @param obligationPeriod
     * The parameter as passed to the updateObligation method.
     * @param obligationRelatedID
     * The parameter as passed to the updateObligation method.
     * @param obligationRelatedType
     * The parameter as passed to the updateObligation method.
     */
    public void preUpdateObligation(ObligationAccessor obligation,
      Money requestedAmount, DateRange obligationPeriod,
      Long obligationRelatedID, 
      OBLIGATIONRELATEDTYPEEntry obligationRelatedType);

    /**
     * Event interface invoked after the main body of the updateObligation
     * method. {@linkplain curam.obligation.impl.Obligation#updateObligation}
     *
     * @param obligation
     * The object instance as it was after the main body of the
     * updateObligation method.
     * @param requestedAmount
     * The parameter as passed to the updateObligation method.
     * @param obligationPeriod
     * The parameter as passed to the updateObligation method.
     * @param obligationRelatedID
     * The parameter as passed to the updateObligation method.
     * @param obligationRelatedType
     * The parameter as passed to the updateObligation method.
     * @param returnValue
     * The return value updated by the Event Handler.
     */
    public void postUpdateObligation(ObligationAccessor obligation,
      Money requestedAmount, DateRange obligationPeriod,
      Long obligationRelatedID,
      OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
      ObligationResult returnValue);
  }
  // END, CR00199055
}
