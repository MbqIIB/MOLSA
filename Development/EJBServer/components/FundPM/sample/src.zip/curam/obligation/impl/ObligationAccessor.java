/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.obligation.impl;


import curam.codetable.impl.CREDITDEBITEntry;
import curam.codetable.impl.OBLIGATIONRELATEDTYPEEntry;
import curam.codetable.impl.OBLIGATIONTRANSACTIONTYPEEntry;
import curam.fundpm.impl.FundFiscalYearAccessor;
import curam.util.persistence.StandardEntity;
import curam.util.type.Date;
import curam.util.type.Money;


/**
 * Accessor interface for {@linkplain Obligation}.
 */
public interface ObligationAccessor extends StandardEntity {

  /**
   * Gets the financial amount associated with the obligation.
   *
   * @return The financial amount associated with the obligation.
   */
  public Money getAmount();

  /**
   * Gets the date the record was created.
   *
   * @return The date the record was created.
   */
  public Date getCreationDate();

  /**
   * Gets the indicator if the obligation process increases or decreases the
   * fund fiscal year Remaining Budgeted Balance, and the Obligated Total.
   *
   * @return The indicator if the obligation increases or decreases the fund
   * fiscal year Remaining Budgeted Balance, and the Obligated Total.
   */
  public CREDITDEBITEntry getCreditDebitType();

  // BEGIN, CR00199055, AK
  /**
   * Gets the immutable fund fiscal year for the obligation.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable fund fiscal year.
   */
  public FundFiscalYearAccessor getFundFiscalYear();
  // END, CR00199055
  
  /**
   * Gets the type of transaction, such as Obligation or Obligation adjustment.
   *
   * @return The type of transaction, such as Obligation or Obligation
   * adjustment.
   */
  public OBLIGATIONTRANSACTIONTYPEEntry getTransactionType();

  /**
   * Gets the unique reference number of the related financial transaction which
   * caused the obligation to be created, such as a Product Delivery or Planned
   * Item.
   *
   * @return The unique reference number of the related financial transaction
   * which caused the obligation to be created, such as a Product
   * Delivery or Planned Item.
   */
  public Long getRelatedID();

  /**
   * Gets the type of financial transaction which caused the obligation to be
   * created, such as a Product Delivery or Planned Item.
   *
   * @return The type of financial transaction which caused the obligation to be
   * created, such as a Product Delivery or Planned Item
   */
  public OBLIGATIONRELATEDTYPEEntry getRelatedType(); 

}
