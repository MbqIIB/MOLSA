/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.obligation.impl;


import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.google.inject.Singleton;

import curam.codetable.impl.FUNDRELATIONTYPEEntry;
import curam.codetable.impl.OBLIGATIONRELATEDTYPEEntry;
import curam.fundpm.sl.entity.impl.ObligationAdapter;
import curam.fundpm.sl.entity.struct.ObligationDtls;
import curam.util.persistence.StandardDAOImpl;
import curam.util.type.Date;


/**
 * Standard implementation of {@linkplain ObligationDAO}.
 */
@Singleton
public class ObligationDAOImpl extends StandardDAOImpl<Obligation, ObligationDtls> implements ObligationDAO {

  /**
   * Single instance of the entity adapter shared across all DAO
   * implementations.
   */
  private static ObligationAdapter obligationAdapter = new ObligationAdapter();

  /**
   * Protected constructor of ObligationDAOImpl.
   */
  protected ObligationDAOImpl() {

    super(obligationAdapter, Obligation.class);
  }

  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00199742, RD
  public Set<Obligation> searchByRelatedIDAndRelatedType(final Long relatedID,
    final OBLIGATIONRELATEDTYPEEntry relatedType) {
    // END, CR00199742
    return newSet(
      obligationAdapter.searchByRelatedIDAndRelatedType(relatedID,
      relatedType.getCode()));
  }

  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00199742, RD
  public List<Obligation> searchByFundFiscalYear(final long fundFiscalYearID) {
    // END, CR00199742
    return newList(obligationAdapter.searchByFundFiscalYear(fundFiscalYearID));
  }

  // BEGIN, CR00188291, AS
  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00199742, RD
  public List<Obligation> searchByProgramFundIDandObligationRelatedType(
    final long programFundID, final OBLIGATIONRELATEDTYPEEntry obligationRelatedType) {
    // END, CR00199742
    return newList(
      obligationAdapter.searchByProgramFundIDandObligationRelatedType(
        programFundID, obligationRelatedType.getCode()));
  }

  // END, CR00188291

  // BEGIN, CR00200430, AS
  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00205954, AS
  // BEGIN, CR00200567, AS
  public List<Obligation> searchByPeriodRelatedIDAndRelatedType(
    final Date startDate, final Date endDate, final long relatedID,
    final OBLIGATIONRELATEDTYPEEntry obligationRelatedType,
    final FUNDRELATIONTYPEEntry fundRulesLinkRelatedType) {
    List<Obligation> obligations = new ArrayList<Obligation>();

    if (FUNDRELATIONTYPEEntry.PRODUCT.equals(fundRulesLinkRelatedType)
      && OBLIGATIONRELATEDTYPEEntry.PRODUCTDELIVERY.equals(
        obligationRelatedType)) {
      obligations = newList(
        obligationAdapter.searchByFundedItemRulesLinkPeriodAndRelatedID(
          startDate, endDate, relatedID));
    } else if (FUNDRELATIONTYPEEntry.PRODUCT.equals(fundRulesLinkRelatedType)
      && OBLIGATIONRELATEDTYPEEntry.PLANNEDITEM.equals(obligationRelatedType)) {
      obligations = newList(
        obligationAdapter.searchByRelatedIDObligationRelatedTypeForProduct(
          relatedID, obligationRelatedType.getCode(), startDate, endDate));
    } else {
      // else if the fund related type is service offering and the
      // obligation related type is planned item.
      obligations = newList(
        obligationAdapter.searchByRelatedIDObligationRelatedTypeForServiceOffering(
          relatedID, obligationRelatedType.getCode(), startDate, endDate));
    }
    return obligations;
    // END, CR00200567
    // END, CR00205954
  }
  // END, CR00200430
}
