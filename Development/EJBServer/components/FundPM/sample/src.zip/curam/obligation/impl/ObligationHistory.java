/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.obligation.impl;


import com.google.inject.ImplementedBy;

import curam.codetable.impl.CREDITDEBITEntry;
import curam.util.persistence.Insertable;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;
import curam.util.type.Money;


/**
 * Entity interface of ObligationHistory. Contains the methods to manage the
 * state of ObligationHistory entity.
 */
@ImplementedBy(ObligationHistoryImpl.class)
public interface ObligationHistory extends ObligationHistoryAccessor,
    Insertable, DateRanged {

  /**
   * Gets the immutable obligation for the obligation history.
   *
   * @return The immutable obligation for the obligation history.
   */
  public Obligation getObligation();

  /**
   * Sets the financial amount associated with the obligation.
   *
   * @param amount
   * The financial amount associated with the obligation.
   */
  public void setAmount(Money amount);

  /**
   * Sets the indicator if the obligation increases or decreases the fund fiscal
   * year Remaining Budgeted Balance, and the Obligated Total.
   *
   * @param creditDebitEntry
   * The indicator if the obligation increases or decreases the fund
   * fiscal year Remaining Budgeted Balance, and the Obligated Total.
   */
  public void setCreditDebitType(CREDITDEBITEntry creditDebitEntry);

  /**
   * Sets the obligation for the obligation history.
   *
   * @param obligation
   * The obligation object for the obligation history.
   */
  public void setObligation(Obligation obligation);

  /**
   * Sets the date range of the associated obligation.
   *
   * @param dateRange
   * The date range of the obligation.
   */
  public void setDateRange(DateRange dateRange);

}
