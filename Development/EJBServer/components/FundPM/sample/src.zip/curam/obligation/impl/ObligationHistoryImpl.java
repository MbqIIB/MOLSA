/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.obligation.impl;


import com.google.inject.Inject;

import curam.codetable.impl.CREDITDEBITEntry;
import curam.fundpm.sl.entity.struct.ObligationHistoryDtls;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.DateRange;
import curam.util.type.Money;


/**
 * Standard implementation of {@linkplain ObligationHistory}.
 *
 */
public class ObligationHistoryImpl extends SingleTableEntityImpl<ObligationHistoryDtls> implements ObligationHistory {

  /**
   * Reference to obligation DAO.
   */
  @Inject
  private ObligationDAO obligationDAO;

  /**
   * Protected constructor of ObligationHistoryImpl.
   */
  protected ObligationHistoryImpl() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No validations required.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No validations required.
  }

  /**
   * {@inheritDoc}
   */
  public Money getAmount() {
    return getDtls().amount;
  }

  /**
   * {@inheritDoc}
   */
  public CREDITDEBITEntry getCreditDebitType() {
    return CREDITDEBITEntry.get(this.getDtls().debitCreditType);
  }

  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {
    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * {@inheritDoc}
   */
  public Obligation getObligation() {
    return obligationDAO.get(getDtls().obligationID);
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// No validations required.
  }

  /**
   * {@inheritDoc}
   */
  public void setAmount(final Money amount) {
    getDtls().amount = amount;
  }

  /**
   * {@inheritDoc}
   */
  public void setCreditDebitType(final CREDITDEBITEntry creditDebitType) {
    this.getDtls().debitCreditType = creditDebitType.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setDateRange(final DateRange dateRange) {
    getDtls().startDate = dateRange.start();
    getDtls().endDate = dateRange.end();
  }

  /**
   * {@inheritDoc}
   */
  public void setObligation(final Obligation obligation) {
    this.getDtls().obligationID = obligation.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// No implementation required
  }
}
