/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.obligation.impl;


import java.util.ArrayList;
import java.util.List;

import com.google.inject.Inject;

import curam.util.persistence.GuiceWrapper;
import curam.waitlist.impl.WaitList;


/**
 * An utility class contains the list of obligations and wait list which is
 * required for setting up the result for process obligation.
 */
public class ObligationResult {

  protected ObligationResult() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * List of obligation objects.
   */
  protected List<Obligation> obligations = new ArrayList<Obligation>();

  /**
   * Reference to wait list.
   */
  @Inject
  protected WaitList waitList;
  
  // BEGIN, CR00196961, AK
  /**
   * List of wait list objects.
   */
  protected List<WaitList> waitLists;
  // END, CR00196961

  /**
   * Gets the list of obligations.
   *
   * @return The array list contains the reference to the obligations.
   */
  public List<Obligation> getObligations() {
    return obligations;
  }

  /**
   * Sets the list of obligations to be returned as a result for the process obligation.
   *
   * @param obligations The list of obligations.
   */
  // BEGIN, CR00199742, RD
  public void setObligations(final List<Obligation> obligations) {
    // END, CR00199742
    this.obligations = obligations;
  }

  /**
   * The wait list to be returned as a result for the process obligation.
   *
   * @return The wait list object.
   */
  public WaitList getWaitList() {
    return waitList;
  }

  /**
   * Sets the wait list reference for the obligation.
   *
   * @param waitList The wait list object.
   */
  // BEGIN, CR00199742, RD 
  public void setWaitList(final WaitList waitList) {
    // END, CR00199742
    this.waitList = waitList;
  }
  
  // BEGIN, CR00196961, AK
  /**
   * Gets the list of wait lists.
   *
   * @return The list of wait lists.
   */
  public List<WaitList> getWaitLists() {
    return waitLists;
  }

  /**
   * Sets the list of wait list references for the obligation.
   *
   * @param waitLists The list of wait lists.
   */
  // BEGIN, CR00199742, RD
  public void setWaitLists(final List<WaitList> waitLists) {
    // END, CR00199742
    this.waitLists = waitLists;
    
    // BEGIN, CR00205682, AK
    this.waitList = waitLists.get(0);
    // END, CR00205682
  }
  // END, CR00196961
}
