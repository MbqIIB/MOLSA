/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.facade.impl;


/**
 * This process class provides the functionality for the Provider Service Plan facade layer.
 *
 */

import curam.serviceplans.facade.struct.CreatePlanItemForSubGoalDetails;
import curam.serviceplans.facade.struct.ModifyPlanItemDetails;
import curam.serviceplans.facade.struct.PlanItemContextDescription;
import curam.serviceplans.facade.struct.PlanItemDetails;
import curam.serviceplans.facade.struct.PlanItemKey;
import curam.serviceplans.facade.struct.ReadPlanItemDetails;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.type.CodeTableItemIdentifier;


public abstract class ProviderServicePlan extends curam.providerserviceplan.facade.base.ProviderServicePlan {

  /**
   * This method is used to create a plan item independent of subgoal.
   *
   * @param createPlanItemDetails
   * Contains the provider plan item details.
   *
   * @return The plan item ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated since Curam v6, replaced with {@link addProviderPlanItem1}.
   */
  @Deprecated
  public PlanItemKey addProviderPlanItem(
    curam.serviceplans.facade.struct.CreatePlanItemDetails createPlanItemDetails)
    throws AppException, InformationalException {
    curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    curam.providerserviceplan.sl.intf.ProviderPlanItem providerPlanItemObj = curam.providerserviceplan.sl.fact.ProviderPlanItemFactory.newInstance();

    PlanItemDtls planItemDtls = new PlanItemDtls();
    PlanItemKey key = new PlanItemKey();

    planItemDtls.assign(createPlanItemDetails.details);

    // Call validate method
    providerPlanItemObj.validateForNonServiceAndCustomService(planItemDtls);

    key.key = planItemObj.create(createPlanItemDetails.details);

    return key;

  }

  /**
   * This method is used to create a plan item independent of subgoal.
   *
   * @param providerItemDetails
   * Contains the provider plan item details.
   *
   * @return The plan item ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PlanItemKey addProviderPlanItem1(PlanItemDetails providerItemDetails)
    throws AppException, InformationalException {

    curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    curam.providerserviceplan.sl.intf.ProviderPlanItem providerPlanItemObj = curam.providerserviceplan.sl.fact.ProviderPlanItemFactory.newInstance();

    PlanItemDtls planItemDtls = new PlanItemDtls();
    PlanItemKey key = new PlanItemKey();

    planItemDtls.assign(providerItemDetails.details);

    providerPlanItemObj.validateForNonServiceAndCustomService(planItemDtls);

    key.key = planItemObj.createPlanItem(providerItemDetails.details);

    return key;

  }

  // __________________________________________________________________________
  /**
   * This method is used to create a plan item
   *
   * @returns Plan Item Key with Plan Item Id as its value
   * @param providerPlanItemDetails
   * contains plan item details
   *
   * @throws AppException
   * @throws InformationalException
   */

  public PlanItemKey createProviderPlanItem(
    CreatePlanItemForSubGoalDetails providerPlanItemDetails)
    throws AppException, InformationalException {

    // return object
    PlanItemKey planItemKey = new PlanItemKey();

    // populate the create details
    curam.serviceplans.sl.struct.CreatePlanItemDetails createPlanItemDetails = new curam.serviceplans.sl.struct.CreatePlanItemDetails();

    createPlanItemDetails.assign(providerPlanItemDetails.details.planItemDtls);

    // create the plan item for the sub goal
    curam.serviceplans.sl.intf.SubGoal subGoalObj = curam.serviceplans.sl.fact.SubGoalFactory.newInstance();

    curam.providerserviceplan.sl.intf.ProviderPlanItem providerPlanItemObj = curam.providerserviceplan.sl.fact.ProviderPlanItemFactory.newInstance();

    // Call validate method
    providerPlanItemObj.validateForNonServiceAndCustomService(
      providerPlanItemDetails.details.planItemDtls);

    planItemKey.key = subGoalObj.createPlanItem(
      providerPlanItemDetails.details.subGoalKey, createPlanItemDetails);

    return planItemKey;
  }

  // __________________________________________________________________________
  /**
   * This method is used to modify a plan item
   *
   * @param ModifyPlanItemDetails
   * contains plan item details to modify
   *
   * @throws AppException
   * @throws InformationalException
   */

  public void modifyProviderPlanItem(ModifyPlanItemDetails details)
    throws AppException, InformationalException {

    curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();
    curam.providerserviceplan.sl.intf.ProviderPlanItem providerPlanItemObj = curam.providerserviceplan.sl.fact.ProviderPlanItemFactory.newInstance();

    // Call validate method
    providerPlanItemObj.validateForNonServiceAndCustomService(
      details.details.dtls);

    planItemObj.modify(details.details);

  }

  // __________________________________________________________________________
  /**
   * This method is used to read plan item details
   *
   * @param PlanItemKey
   * contains plan item Id
   *
   * @return ReadPlanItemDetails contains plan item details for particular plan
   * item id
   * @throws InformationalException
   * @throws AppException
   */
  public ReadPlanItemDetails readProviderPlanItem(PlanItemKey key)
    throws AppException, InformationalException {

    curam.providerserviceplan.sl.intf.ProviderPlanItem providerPlanItemObj = curam.providerserviceplan.sl.fact.ProviderPlanItemFactory.newInstance();

    ReadPlanItemDetails details = new ReadPlanItemDetails();

    details.details = providerPlanItemObj.readProviderPlanItem(key.key);
    // BEGIN, CR00161962, LJ
    // read context description
    details.contextDescription = getPlanItemContextDescription(key);
    // END, CR00161962
    return details;

  }

  // BEGIN, CR00161962, LJ
  /**
   * Reads planned item context description.
   *
   * @param key
   * PlanItem unique identifier
   *
   * @return planned item context description
   * @throws AppException
   * @throws InformationalException
   */
  protected PlanItemContextDescription getPlanItemContextDescription(
    final PlanItemKey key) throws AppException, InformationalException {

    // PlanItem BPO
    final curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    // return value
    final PlanItemContextDescription planItemContextDescription = new PlanItemContextDescription();

    // read plan item name
    final curam.serviceplans.sl.struct.PlanItemNameDetails planItemNameDetails = planItemObj.readName(
      key.key);

    // create the context description
    final LocalisableString description = new LocalisableString(
      curam.message.BPOSERVICEPLAN.INF_MENU_CTI_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(curam.codetable.PLANITEMNAME.TABLENAME,
      planItemNameDetails.planItemNameDetails.name));

    // assign it to the return object
    planItemContextDescription.contextDescription = description.toClientFormattedText();

    // return context description
    return planItemContextDescription;

  }
  // END, CR00161962
}
