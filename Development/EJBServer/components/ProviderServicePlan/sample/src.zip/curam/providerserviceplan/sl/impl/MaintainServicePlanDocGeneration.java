/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.sl.impl;


import curam.core.impl.EnvVars;
import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.providerserviceplan.sl.intf.MaintainServicePlanContract;
import curam.providerserviceplan.sl.fact.MaintainServicePlanContractFactory;
import curam.providerserviceplan.sl.struct.ServicePlanData;
import curam.providerserviceplan.sl.struct.ServicePlanDocumentData;
import curam.serviceplans.facade.struct.ReadCompleteContractDetails;
import curam.serviceplans.facade.struct.ServicePlanContractKey;
import curam.serviceplans.facade.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.serviceplans.sl.intf.ServicePlanDocGeneration;
import curam.serviceplans.sl.struct.ServicePlanDocumentDetails;
import curam.serviceplans.sl.struct.ServicePlanDocumentKey;
import curam.serviceplans.sl.struct.ServicePlanDocumentTemplateCodeKey;
import curam.serviceplans.sl.struct.ServicePlanReturnDocDetails;
import curam.serviceplans.sl.struct.ServicePlanUserData;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.Locale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Blob;
import curam.util.xml.impl.XMLDocument;
import curam.util.xml.impl.XMLEncodingConstants;
import curam.util.xml.impl.XMLPrintStream;
import java.io.ByteArrayOutputStream;


/**
 * This service layer class interacts with the service layer of core to perform
 * various operations on the Service Plan Document Generation 
 *
 */
public abstract class MaintainServicePlanDocGeneration extends curam.providerserviceplan.sl.base.MaintainServicePlanDocGeneration {

  // ___________________________________________________________________________
  /**
   * This Method generates the service plan contract details for preview.
   *
   * @param key of service plan contract
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ReadCompleteContractDetails generateContractForPreview
    (ServicePlanContractKey servicePlanContractKey) 
    throws AppException, InformationalException {
    // return value
    ReadCompleteContractDetails readCompleteContractDetails = new ReadCompleteContractDetails();

    // Contract manipulation variables
    curam.serviceplans.sl.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.fact.ServicePlanContractFactory.newInstance();
    ServicePlanDocumentTemplateCodeKey servicePlanDocumentTemplateCodeKey = new ServicePlanDocumentTemplateCodeKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    servicePlanDocumentTemplateCodeKey.caseID = servicePlanContractObj.readCaseID(servicePlanContractKey.servPlanContractKey).key.caseID;
    servicePlanDocumentTemplateCodeKey.servicePlanContractID = servicePlanContractKey.servPlanContractKey.servicePlanContractID;
    servicePlanDocumentTemplateCodeKey.templateTypeCode = curam.codetable.TEMPLATEIDCODE.PROVIDERSERVICEPLANCONTRACT;

    // readCompleteContractDetails.description
    readCompleteContractDetails.contactDetails = previewDocumentByTemplateIDCode(
      servicePlanDocumentTemplateCodeKey);

    // return the list
    return readCompleteContractDetails;
  }
  
  // ___________________________________________________________________________
  /**
   * Previews document by template id code and service plan contract and
   * case specified .
   *
   * @param servicePlanDocumentTemplateCodeKey Contains caseID, 
   * service plan ContractID and document template ID code.
   *
   * @return Service Plan return details - file Name and File Contents
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */

  protected ServicePlanReturnDocDetails previewDocumentByTemplateIDCode
    (ServicePlanDocumentTemplateCodeKey servicePlanDocumentTemplateCodeKey)
    throws AppException, InformationalException {

    // create return struct
    ServicePlanReturnDocDetails servicePlanReturnDocDetails = new ServicePlanReturnDocDetails();

    ServicePlanDocumentKey servicePlanDocumentKey = new ServicePlanDocumentKey();

    curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey = new curam.util.xml.struct.XSLTemplateIDCodeKey();

    // read document template by template id
    xslTemplateIDCodeKey.templateIDCode = servicePlanDocumentTemplateCodeKey.templateTypeCode;
    curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj = curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

    xslTemplateIDCodeKey.localeIdentifier = TransactionInfo.getProgramLocale();

    curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
      xslTemplateIDCodeKey);

    // preview document
    servicePlanDocumentKey.servicePlanContractID = servicePlanDocumentTemplateCodeKey.servicePlanContractID;
    servicePlanDocumentKey.caseID = servicePlanDocumentTemplateCodeKey.caseID;
    servicePlanDocumentKey.templateID = xslTemplateInstanceKey.templateID;
    servicePlanDocumentKey.versionNo = xslTemplateInstanceKey.templateVersion;

    ServicePlanData servicePlanData = getRequiredInformationForDocument(
      servicePlanDocumentKey);

    // populate return struct
    servicePlanReturnDocDetails = generateAndPreviewDocument(
      servicePlanData.documentDetails, servicePlanData.documentData);

    return servicePlanReturnDocDetails;

  }

  // ___________________________________________________________________________
  /**
   * Returns the required service plan date to either print or preview a service
   * plan document
   *
   * @param servicePlanDocumentKey Contains case ID, service Plan Contract ID, 
   * document ID and document template 
   * version No of document to be printed/Previewed
   *
   * @return service plan document data.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected ServicePlanData getRequiredInformationForDocument
    (ServicePlanDocumentKey servicePlanDocumentKey)
    throws AppException, InformationalException { // income support document data

    // Return Struct
    ServicePlanDocumentData servicePlanDocumentData = new ServicePlanDocumentData();
    ServicePlanData servicePlanData = new ServicePlanData();
    ServicePlanDocumentDetails servicePlanDocumentDetails = new ServicePlanDocumentDetails();
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();
    ServicePlanContractKey servicePlanContractKey = new ServicePlanContractKey();
    ServicePlanUserData servicePlanUserData;
    MaintainServicePlanContract maintainServicePlanContractObj = MaintainServicePlanContractFactory.newInstance();
    
    // ServicePlanContract business object
    ServicePlanDocGeneration servicePlanDocGenerationObj = curam.serviceplans.sl.fact.ServicePlanDocGenerationFactory.newInstance();
    
    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = servicePlanDocumentKey.caseID;
    servicePlanUserData = servicePlanDocGenerationObj.getUserData(
      servicePlanDeliveryKey.servicePlanDeliveryKey);

    servicePlanDocumentDetails.printerName = servicePlanUserData.defaultPrinter;
    servicePlanDocumentDetails.templateID = servicePlanDocumentKey.templateID;
    servicePlanDocumentDetails.versionNo = servicePlanDocumentKey.versionNo;
    servicePlanDocumentDetails.caseID = servicePlanDocumentKey.caseID;
    servicePlanDocumentDetails.servicePlanContractID = servicePlanDocumentKey.servicePlanContractID;

    servicePlanData.documentDetails = servicePlanDocumentDetails;

    servicePlanContractKey.servPlanContractKey.servicePlanContractID = servicePlanDocumentKey.servicePlanContractID;

    // get full income support details
    servicePlanDocumentData.contractDetails = maintainServicePlanContractObj.readCompleteContract(
      servicePlanContractKey.servPlanContractKey);
    servicePlanData.documentData = servicePlanDocumentData;

    return servicePlanData;
  }
  
  // ___________________________________________________________________________
  /**
   * Generates an XML document from the specified XSL template and previews that
   * document.
   *
   * @param servicePlanDocumentDetails Contains service plan document details.
   * @param servicePlanDocumentData Contains service plan document data to be printed.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected ServicePlanReturnDocDetails generateAndPreviewDocument(
    ServicePlanDocumentDetails servicePlanDocumentDetails,
    ServicePlanDocumentData servicePlanDocumentData)
    throws AppException, InformationalException {

    ServicePlanReturnDocDetails servicePlanReturnDocDetails = new ServicePlanReturnDocDetails();

    // Create Preview Stream
    ByteArrayOutputStream previewStream = new java.io.ByteArrayOutputStream();

    // Create XMLPrintStream object
    XMLPrintStream printStreamObj = new XMLPrintStream();

    curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey = new curam.util.administration.struct.XSLTemplateInstanceKey();

    // Set up XSL template instance
    xslTemplateInstanceKey.templateID = servicePlanDocumentDetails.templateID;
    xslTemplateInstanceKey.templateVersion = servicePlanDocumentDetails.versionNo;

    // BEGIN, CR00408986, KRK
    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS_DEFAULT))) {
      // set printer name (if already defined)
      if (servicePlanDocumentDetails.printerName.length() > 0) {
        printStreamObj.setPrinterName(servicePlanDocumentDetails.printerName);
      }

      printStreamObj.setPreviewStream(previewStream);

      xslTemplateInstanceKey.locale = TransactionInfo.getProgramLocale();

      // Open print stream
      printStreamObj.open(xslTemplateInstanceKey);

      XMLDocument documentObj = new XMLDocument(printStreamObj.getStream(),
        XMLEncodingConstants.kEncodeUTF8);
      
      // open document
      documentObj.open(curam.util.transaction.TransactionInfo.getProgramUser(),
        Locale.getFormattedTime(curam.util.type.DateTime.getCurrentDateTime()),
        String.valueOf(servicePlanDocumentDetails.versionNo),
        servicePlanDocumentDetails.comments);

      // add data to document
      documentObj.add(servicePlanDocumentData);

      // close document and print stream objects
      documentObj.close();

      printStreamObj.close();
    }
    // END, CR00408986
   
    // previewBuffer
    servicePlanReturnDocDetails.fileName = ExtensionConst.gkPDFFileNameExtenmsion;
    servicePlanReturnDocDetails.fileData = new Blob(previewStream.toByteArray());

    return servicePlanReturnDocDetails;
  }
}
