/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.sl.event.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.attendance.impl.AbsencePeriod;
import curam.attendance.impl.PRLICorrection;
import curam.attendance.impl.PRLICorrectionDAO;
import curam.attendance.impl.PRLISALILink;
import curam.attendance.impl.PRLISALILinkDAO;
import curam.attendance.impl.PRLITransaction;
import curam.attendance.impl.PRLITransactionDAO;
import curam.attendance.impl.ProviderRosterLineItem;
import curam.attendance.impl.ProviderRosterLineItemDAO;
import curam.attendance.impl.SOAttendanceConfiguration;
import curam.attendance.impl.SOAttendanceConfigurationDAO;
import curam.codetable.ATTENDANCE;
import curam.codetable.PLANNEDITEMSTATUS;
import curam.codetable.PRLITRANSACTIONSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.ATTENDANCEEntry;
import curam.codetable.impl.ATTENDANCEREPORTINGTYPEEntry;
import curam.codetable.impl.PLANNEDITEMSTATUSEntry;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.fact.DailyAttendanceFactory;
import curam.core.sl.entity.intf.DailyAttendance;
import curam.core.sl.entity.struct.AbsencePeriodDtlsList;
import curam.core.sl.entity.struct.AbsencePeriodKey;
import curam.core.sl.entity.struct.DailyAttendanceDtls;
import curam.core.sl.entity.struct.DailyAttendanceDtlsList;
import curam.core.sl.entity.struct.DailyAttendanceKey;
import curam.core.sl.entity.struct.PlannedItemModifyStatusDetails;
import curam.core.sl.entity.struct.RosterLineItemDtls;
import curam.core.sl.entity.struct.RosterLineItemKey;
import curam.cpm.sl.entity.struct.ServiceAuthorizationKey;
import curam.financial.impl.ServiceInvoiceLineItem;
import curam.financial.impl.ServiceInvoiceLineItemCorrectionDAO;
import curam.financial.impl.ServiceInvoiceLineItemDAO;
import curam.provider.impl.PRLIStatusEntry;
import curam.providerserviceplan.sl.entity.fact.ProviderPlannedItemLinkFactory;
import curam.providerserviceplan.sl.entity.intf.ProviderPlannedItemLink;
import curam.providerserviceplan.sl.entity.struct.ProviderPlannedItemLinkDtls;
import curam.providerserviceplan.util.impl.GeneralProviderConstants;
import curam.serviceauthorization.impl.ServiceAuthorization;
import curam.serviceauthorization.impl.ServiceAuthorizationDAO;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItem;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItemDAO;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.serviceoffering.impl.UnitOfMeasureEntry;
import curam.serviceplans.sl.entity.fact.PIDailyAttendanceLinkFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemAbsenceLinkFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.intf.PIDailyAttendanceLink;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.intf.PlannedItemAbsenceLink;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkDtls;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkDtlsList;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkKey;
import curam.serviceplans.sl.entity.struct.PlannedItemAbsenceLinkDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedItemDetailsStruct;
import curam.serviceplans.sl.entity.struct.RelatedIDKey;
import curam.serviceplans.sl.entity.struct.SetPlannedItemStatusKey;
import curam.util.events.impl.EventFilter;
import curam.util.events.impl.EventHandler;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.StringUtil;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.Money;


/**
 * This event handler listens for events from a Provider Application such as CPM
 * and updates PlannedItem data based on the event information
 *
 */

public class UpdateProviderInformation implements EventFilter, EventHandler {

  /**
   * Injecting the Data Access Object for ServiceInvoiceLineItem class.
   */
  @Inject
  protected ServiceInvoiceLineItemDAO serviceInvoiceLineItemDAO;

  /**
   * Injecting Data Access Object for ProviderRosterLineItemTransaction class.
   */

  @Inject
  protected PRLITransactionDAO prliTransactionDAO;

  /**
   * Injecting the Data Access Object for ServiceOfferingDAO class.
   */

  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Injecting the Data Access Object for ProviderRosterLineItemDAO class.
   */

  @Inject
  protected ProviderRosterLineItemDAO providerRosterLineItemDAO;

  @Inject
  protected SOAttendanceConfigurationDAO soAttendanceConfigurationDAO;

  @Inject
  protected PRLICorrectionDAO pRLICorrectionDAO;
  
  // BEGIN, CR00314944, SSK
  /**
   * Reference to PRLISALI link DAO.
   */
  @Inject
  protected PRLISALILinkDAO pRLISALILinkDAO;
  // END, CR00314944

  // BEGIN CR00128516, GBA
  @Inject
  protected ServiceInvoiceLineItemCorrectionDAO sILICorrectionDAO;

  // BEGIN, CR00228146, ASN
  /**
   * Reference to Service Authorization DAO.
   */
  @Inject
  protected ServiceAuthorizationDAO serviceAuthorizationDAO;

  // END, CR00228146
  
  // BEGIN, CR00380597, GA
  /**
   * Reference to Service Authorization Line Item sDAO.
   */
  @Inject
  protected ServiceAuthorizationLineItemDAO serviceAuthorizationLineItemDAO; 
  // END, CR00380597

  /**
   * Default constructor.
   */
  public UpdateProviderInformation() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * Returns true if the event is one of the Provider events
   *
   * @param event
   * The details of the event.
   *
   * @return boolean if an only if the event is interesting to the listener
   */
  public boolean accept(Event event) throws AppException,
      InformationalException {

    if (event.eventKey.eventClass.equals(
      GeneralProviderConstants.kEventClassCPMInvoice)) {
      // BEGIN CR00128516, GBA
      // BEGIN, CR00303511, SS
      if (event.eventKey.eventType.equals(
        GeneralProviderConstants.kEventTypeInvoiceUpdate)
          || event.eventKey.eventType.equals(
            GeneralProviderConstants.kEventTypeInvoiceCorrected)
            || event.eventKey.eventType.equals(
              GeneralProviderConstants.kEventTypeSILIReassessed)) {
        return true;
      }// END CR00128516
      // END, CR00303511
    }

    if (event.eventKey.eventClass.equals(
      GeneralProviderConstants.kEventClassCPMRoster)) {
      // BEGIN CR00131282, GBA
      if (event.eventKey.eventType.equals(
        GeneralProviderConstants.kEventTypeRosterApproved)
          || event.eventKey.eventType.equals(
            GeneralProviderConstants.kEventTypeRosterCorrected)) {
        return true;
      } // END CR00131282
    }

    return false;

  }

  /**
   * Populates CPM data to respective tables based on the event key, which may
   * be of type roster line item id, service invoice line item id or the service
   * authorization id .
   *
   * @param event
   * The details of the event.
   *
   * @throws AppException
   * , InformationalException
   */

  public void eventRaised(Event event) throws AppException,
      InformationalException {

    // BEGIN CR00128516, GBA
    if (event.eventKey.eventType.equals(
      GeneralProviderConstants.kEventTypeRosterApproved)) {

      updateRosterDetails(event);

    }

    if (event.eventKey.eventType.equals(
      GeneralProviderConstants.kEventTypeInvoiceUpdate)) {
      updateServiceInvoiceDetails(event);
    }

    // BEGIN CR00129860, GBA
    if (event.eventKey.eventType.equals(
      GeneralProviderConstants.kEventTypeInvoiceCorrected)) {
      updateWithSILICorrection(event);
    }
    // END CR00129860

    // END CR00128516

    // BEGIN CR00131282, GBA
    if (event.eventKey.eventType.equals(
      GeneralProviderConstants.kEventTypeRosterCorrected)) {

      updateRosterCorrection(event);

    }
    // BEGIN, CR00303511, SS
    if (event.eventKey.eventType.equals(
      GeneralProviderConstants.kEventTypeSILIReassessed)) {

      updateActualCost(event);
    }

  }

  /**
   * Updates the planned item actual cost whenever a service invoice line item
   * is reassessed.
   *
   * @param event
   * Contains primary event data.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void updateActualCost(Event event) throws AppException,
      InformationalException {

    ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      event.primaryEventData);

    long serviceAuthorizationID = serviceInvoiceLineItem.retrieveServiceAuthorization().getID();

    ServiceAuthorizationKey serviceAuthorizationKey = new ServiceAuthorizationKey();

    serviceAuthorizationKey.serviceAuthorizationID = serviceAuthorizationID;

    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    long plannedItemID;

    try {
      plannedItemID = providerPlannedItemLinkObj.readByServiceAuthorization(serviceAuthorizationKey).plannedItemID;

    } catch (RecordNotFoundException e) {
      // Stop processing as there is no relation between the service
      // authorization and any of the existing planned items.
      return;
    }

    Date fromDate = Date.kZeroDate;
    Date toDate = Date.kZeroDate;
    double amount = 0;

    // Get all SILI-Attendance-Planned Item link records for the planned
    // item.
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();
    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = plannedItemID;

    PIDailyAttendanceLinkDtlsList piDailyAttendanceLinkDtlsList = piDailyAttendanceLinkObj.searchByPlannedItemID(
      plannedItemKey);

    if (piDailyAttendanceLinkDtlsList.dtls.size() > 0) {
      int firstIntance = 0;

      for (final PIDailyAttendanceLinkDtls piDailyAttendanceLinkDtls : piDailyAttendanceLinkDtlsList.dtls.items()) {

        ServiceInvoiceLineItem piServiceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
          piDailyAttendanceLinkDtls.relatedID);

        Date tempDate = piServiceInvoiceLineItem.getServiceDateFrom();

        if (firstIntance == 0) {
          fromDate = tempDate;
          toDate = tempDate;
          firstIntance++;
        }
        if (tempDate.before(fromDate)) {
          fromDate = tempDate;
        }
        if (tempDate.after(toDate)) {
          toDate = tempDate;
        }

        amount += piServiceInvoiceLineItem.getAmountPaid().getValue();
      }
    }

    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    PlannedItemDtls plannedItemDtls = plannedItemObj.read(plannedItemKey);

    plannedItemDtls.actualCost = new Money(amount);

    plannedItemObj.modify(plannedItemKey, plannedItemDtls);

  }

  // END, CR00303511

   
  /**
   * Daily Attendance and Absence records modified in Roster correction are
   * updated and associated with service plan item
   *
   * @param primaryEventData
   * : PRLICorrectionID
   *
   * @throws AppException
   * , InformationalException
   */

  // BEGIN, CR00177241, PM
  protected void updateRosterCorrection(Event event) throws AppException,
      InformationalException {
    // END, CR00177241

    PRLICorrection pRLICorrection = pRLICorrectionDAO.get(
      event.primaryEventData);
    long providerRosterLineItemID = pRLICorrection.getProviderRosterLineItem().getID();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      providerRosterLineItemID);

    long rosterLineItemID = providerRosterLineItem.getRosterLineItemID();

    // delete existing records in planned item and absence link table
    PlannedItemAbsenceLink plannedItemAbsenceLinkObj = PlannedItemAbsenceLinkFactory.newInstance();
    RosterLineItemKey rosterLineItemKey = new RosterLineItemKey();

    rosterLineItemKey.rosterLineItemID = rosterLineItemID;
    try {
      plannedItemAbsenceLinkObj.removeAbsenceByRosterLineItemID(
        rosterLineItemKey);
    } catch (Exception e) {// ignore as exception might be because of empty link
      // table
    }

    // delete existing records in planned item daily attendance link table
    PIDailyAttendanceLink pIDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    try {
      pIDailyAttendanceLinkObj.removeAttendanceRosterLnItem(rosterLineItemKey);
    } catch (Exception e) {// ignore as exception might be because of empty link
      // table
    }

    // BEGIN, CR00273068,SS
    updateRosterDetails(event, pRLICorrection.getProviderRosterLineItem());
    // END, CR00273068

  }

  // END CR00131282

   
  /**
   * Populates CPM data to respective tables after receiving event notification
   * for Roster approval or correction.
   *
   * @param primaryEventData
   * : ProviderRosterLineItemID
   *
   * @throws AppException
   * , InformationalException
   */

  // BEGIN, CR00177241, PM
  protected void updateRosterDetails(Event event) throws AppException,
      InformationalException {
    // END, CR00177241
    Date fromDate = Date.kZeroDate;
    Date toDate = Date.kZeroDate;
    Date tempDate = Date.kZeroDate;
    int noOfUnits = 0;
    double amount = 0;
    long serviceAuthID = 0;
    long rosterLineItemID = 0;

    boolean payBasedOnAttendanceInd = false;
    boolean isDailyAttendanceTrackingRequired = false;

    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    RosterLineItemKey rosterLineItemKey = new RosterLineItemKey();

    rosterLineItemKey.rosterLineItemID = event.primaryEventData;

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      event.primaryEventData);

    payBasedOnAttendanceInd = providerRosterLineItem.getPayBasedOnAttendanceIndForRLI(
      providerRosterLineItem.getRosterLineItemID());

    serviceAuthID = providerRosterLineItem.getServiceAuthorization().getID();
    
    // BEGIN CR00124859, GBA
    rosterLineItemID = providerRosterLineItem.getRosterLineItemID();
    updateClientParticipationRecords(rosterLineItemID, serviceAuthID);
    // END CR00124859

    fromDate = providerRosterLineItem.getDateRange().start();
    toDate = providerRosterLineItem.getDateRange().end();

    // BEGIN, CR00128926, MC
    DateRange dateRange = new DateRange(fromDate, toDate);

    List<SOAttendanceConfiguration> soAttendanceConfigurationList = soAttendanceConfigurationDAO.searchByServiceOfferingAndDateRange(
      providerRosterLineItem.getRoster().getServiceOffering(), dateRange);

    if (soAttendanceConfigurationList.size() > 0) {
      isDailyAttendanceTrackingRequired = soAttendanceConfigurationList.get(0).isDailyAttendanceTrackingRequired();
    } else {
      isDailyAttendanceTrackingRequired = false;
    }
    // END, CR00128926

    List<PRLITransaction> prliTransactionsSet = prliTransactionDAO.listTransactionsForRosterLineItem(
      providerRosterLineItem);

    // BEGIN, CR00314944, SSK
    Set<curam.attendance.impl.DailyAttendance> unModifiableDailyAttendanceList = new HashSet<curam.attendance.impl.DailyAttendance>();

    if (isDailyAttendanceTrackingRequired) {

      unModifiableDailyAttendanceList = providerRosterLineItem.getDailyAttendances();
      // END, CR00314944

      Set<curam.attendance.impl.DailyAttendance> dailyAttendanceList = new HashSet<curam.attendance.impl.DailyAttendance>();

      dailyAttendanceList.addAll(unModifiableDailyAttendanceList);

      Iterator dailyAttendaceIterator = dailyAttendanceList.iterator();
      int firstIntance = 0;

      while (dailyAttendaceIterator.hasNext()) {
        curam.attendance.impl.DailyAttendance dailyAttendance = (curam.attendance.impl.DailyAttendance) dailyAttendaceIterator.next();

        if (dailyAttendance.getAttendance().equals(ATTENDANCEEntry.PRESENT)
          || dailyAttendance.getAttendance().equals(
            ATTENDANCEEntry.PARTIALLYPRESENT)) {

          tempDate = dailyAttendance.getServiceDate();
          noOfUnits = noOfUnits + dailyAttendance.getUnitsAttended();

          if (firstIntance == 0) {
            fromDate = tempDate;
            // BEGIN CR00129860, GBA
            toDate = tempDate;
            // END CR00129860
            firstIntance++;
          }
          // BEGIN CR00128947, GBA
          if (tempDate.before(fromDate)) {
            fromDate = tempDate;
          }
          // END CR00128947

          if (tempDate.after(toDate)) {
            toDate = tempDate;
          }
        }

      }
    } else {
      // handle absence data
      rosterLineItemKey = new RosterLineItemKey();
      rosterLineItemKey.rosterLineItemID = rosterLineItemID;

      fromDate = providerRosterLineItem.getServiceDateFrom();
      toDate = providerRosterLineItem.getServiceDateTo();
      noOfUnits = providerRosterLineItem.getUnitsDelivered();

    }

    // BEGIN CR00128516, GBA
    // get amount from Active ProviderRosterLineItemTransaction
    if (payBasedOnAttendanceInd) {
      for (PRLITransaction prliTransaction : prliTransactionsSet) {

        if (PRLITRANSACTIONSTATUS.ACTIVE.equals(
          prliTransaction.getTransactionStatus().getCode())) {
          amount = amount + prliTransaction.getAmount().getValue();
        }
      }
    }

    // read plannedItem details by service AuthorizationKey
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    PlannedItemKey plannedItemKey = new PlannedItemKey();

    ServiceAuthorizationKey serviceAuthorizationKey = new ServiceAuthorizationKey();

    serviceAuthorizationKey.serviceAuthorizationID = serviceAuthID;

    PlannedItemDtls plannedItemDtls = null;

    try {

      plannedItemKey.plannedItemID = providerPlannedItemLinkObj.readByServiceAuthorization(serviceAuthorizationKey).plannedItemID;
      plannedItemDtls = plannedItemObj.read(plannedItemKey);
      
    } catch (RecordNotFoundException ex) {
      // Stop processing as there is no relation between the service
      // authorization and any of the existing planned items.
      return;

    }

    // update actual start date, end date and status

    // BEGIN, CR00148309, GBA
    if (event.eventKey.eventType.equals(
      GeneralProviderConstants.kEventTypeRosterApproved)
        && plannedItemDtls.unitsDelivered
          != GeneralProviderConstants.kSentinelValue) {
      plannedItemDtls.unitsDelivered = plannedItemDtls.unitsDelivered
        + noOfUnits;
    } else { // for Roster Correction and no units delivered initially
      plannedItemDtls.unitsDelivered = noOfUnits;
    }
    // END, CR00148309

    // BEGIN, CR00314944, SSK
    final List<ProviderRosterLineItem> providerRosterLineItems = getEarliestAndLatestProviderRosterLineItem(
      providerRosterLineItem);
    ProviderRosterLineItem earliestProviderRosterLineItem = null;
    ProviderRosterLineItem latestProviderRosterLineItem = null;

    if (1 == providerRosterLineItems.size()) {
      earliestProviderRosterLineItem = providerRosterLineItems.get(0);
      latestProviderRosterLineItem = earliestProviderRosterLineItem;
    } else if (1 < providerRosterLineItems.size()) {
      earliestProviderRosterLineItem = providerRosterLineItems.get(0);
      latestProviderRosterLineItem = providerRosterLineItems.get(1);
    }

    if (null != earliestProviderRosterLineItem) {
      plannedItemDtls.actualStartDate = getPlannedItemActualStartDate(
        isDailyAttendanceTrackingRequired, earliestProviderRosterLineItem);
    }

    plannedItemDtls.status = PLANNEDITEMSTATUSEntry.INPROGRESS.getCode();
    // BEGIN, CR00380597, GA
    if (ATTENDANCEREPORTINGTYPEEntry.UTILIZATION.getCode().equals(
      soAttendanceConfigurationList.get(0).getReportingMethod().toString())) {
      if (plannedItemDtls.actualEndDate.isZero()
        && null != latestProviderRosterLineItem) {
    	
        if (PRLIStatusEntry.COMPLETE.equals(
          providerRosterLineItem.getLifecycleState())) {
          final ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.get(
            serviceAuthID);

          final Set<ServiceAuthorizationLineItem> serviceAuthorizationLineItems = serviceAuthorizationLineItemDAO.searchByServiceAuthorization(
            serviceAuthorization);

          if (1 == serviceAuthorizationLineItems.size()) {

            final ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceAuthorizationLineItems.iterator().next();

            if (serviceAuthorizationLineItem.getDateRange().end().equals(
              providerRosterLineItem.getServiceDateTo())
                || !providerRosterLineItem.getServiceDateTo().before(
                  serviceAuthorizationLineItem.getDateRange().end())) { 
              int remainingUnits = getUnitsRemainingOnPlannedItem(
                providerRosterLineItem);

              if (0 == remainingUnits) {
                plannedItemDtls.actualEndDate = getPlannedItemActualEndDate(
                  isDailyAttendanceTrackingRequired,
                  latestProviderRosterLineItem);
                plannedItemDtls.status = PLANNEDITEMSTATUSEntry.COMPLETED.getCode();
              }
            }

          } else if (1 < serviceAuthorizationLineItems.size()) {
				
            final List<ServiceAuthorizationLineItem> SALIList = sortServiceAuthorizationLineItem(
              serviceAuthorizationLineItems);
				
            final ServiceAuthorizationLineItem serviceAuthorizationLineItem = SALIList.iterator().next();
				
            if (serviceAuthorizationLineItem.getDateRange().end().equals(
              providerRosterLineItem.getServiceDateTo())
                || !providerRosterLineItem.getServiceDateTo().before(
                  serviceAuthorizationLineItem.getDateRange().end())) {
					
              plannedItemDtls.actualEndDate = providerRosterLineItem.getServiceDateTo();
              plannedItemDtls.status = PLANNEDITEMSTATUSEntry.COMPLETED.getCode();
					
            }
          }

        }	
      }
      
    } else {
    	
      if (PRLIStatusEntry.COMPLETE.equals(
        providerRosterLineItem.getLifecycleState())) {
        final ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.get(
          serviceAuthID);

        final Set<ServiceAuthorizationLineItem> serviceAuthorizationLineItems = serviceAuthorizationLineItemDAO.searchByServiceAuthorization(
          serviceAuthorization);

        if (1 == serviceAuthorizationLineItems.size()) {

          final ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceAuthorizationLineItems.iterator().next();

          if (serviceAuthorizationLineItem.getDateRange().end().equals(
            providerRosterLineItem.getServiceDateTo())
              || !providerRosterLineItem.getServiceDateTo().before(
                serviceAuthorizationLineItem.getDateRange().end())) {
            plannedItemDtls.actualEndDate = providerRosterLineItem.getServiceDateTo();
            plannedItemDtls.status = PLANNEDITEMSTATUSEntry.COMPLETED.getCode();
          }

        } else if (1 < serviceAuthorizationLineItems.size()) {
				
          final List<ServiceAuthorizationLineItem> SALIList = sortServiceAuthorizationLineItem(
            serviceAuthorizationLineItems);
				
          final ServiceAuthorizationLineItem serviceAuthorizationLineItem = SALIList.iterator().next();
				
          if (serviceAuthorizationLineItem.getDateRange().end().equals(
            providerRosterLineItem.getServiceDateTo())
              || !providerRosterLineItem.getServiceDateTo().before(
                serviceAuthorizationLineItem.getDateRange().end())) {
					
            plannedItemDtls.actualEndDate = providerRosterLineItem.getServiceDateTo();
            plannedItemDtls.status = PLANNEDITEMSTATUSEntry.COMPLETED.getCode();
					
          }
        }

      }
    }	
    // END, CR00380597
    
    // Update to Actual Cost information on the plan item should only be
    // applied to the plan item if the Pay Based on Attendance indicator for
    // the service in CPM is set to No
    // Update to Actual Cost information on the plan item should only be
    // applied to the plan item if the Attendance Tracking Enabled indicator for
    // the service in CPM is set to Yes

    if (event.eventKey.eventType.equals(
      GeneralProviderConstants.kEventTypeRosterApproved)) {
      plannedItemDtls.actualCost = new Money(
        plannedItemDtls.actualCost.getValue() + amount);

    } else { // for Roster Correction
      plannedItemDtls.actualCost = new Money(amount);
    }
    
    // modify plannedItem details
    plannedItemObj.modify(plannedItemKey, plannedItemDtls);
    
  }

  // BEGIN, CR00273068,SS
  /**
   * Populates CPM data to respective tables after receiving event notification
   * for Roster approval or correction.
   *
   * @param event
   * Event containing event data.
   * @param provRosterLineItem
   * Provider roster line item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void updateRosterDetails(Event event,
    ProviderRosterLineItem provRosterLineItem) throws AppException,
      InformationalException {
    Date fromDate = Date.kZeroDate;
    Date toDate = Date.kZeroDate;
    int noOfUnits = 0;
    double amount = 0;
    long serviceAuthID = 0;
    long rosterLineItemID = 0;

    boolean payBasedOnAttendanceInd = false;
    boolean isDailyAttendanceTrackingRequired = false;

    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    RosterLineItemKey rosterLineItemKey = new RosterLineItemKey();

    rosterLineItemKey.rosterLineItemID = provRosterLineItem.getID();

    ProviderRosterLineItem providerRosterLineItem = providerRosterLineItemDAO.get(
      provRosterLineItem.getID());

    payBasedOnAttendanceInd = providerRosterLineItem.getPayBasedOnAttendanceIndForRLI(
      providerRosterLineItem.getRosterLineItemID());

    serviceAuthID = providerRosterLineItem.getServiceAuthorization().getID();

    rosterLineItemID = providerRosterLineItem.getRosterLineItemID();
    updateClientParticipationRecords(rosterLineItemID, serviceAuthID);

    fromDate = providerRosterLineItem.getDateRange().start();
    toDate = providerRosterLineItem.getDateRange().end();

    DateRange dateRange = new DateRange(fromDate, toDate);

    List<SOAttendanceConfiguration> soAttendanceConfigurationList = soAttendanceConfigurationDAO.searchByServiceOfferingAndDateRange(
      providerRosterLineItem.getRoster().getServiceOffering(), dateRange);

    if (soAttendanceConfigurationList.size() > 0) {
      isDailyAttendanceTrackingRequired = soAttendanceConfigurationList.get(0).isDailyAttendanceTrackingRequired();

    } else {
      isDailyAttendanceTrackingRequired = false;

    }

    // BEGIN, CR00279052, ASN
    String saReferenceNumber = providerRosterLineItem.getSAReferenceNo();

    Set<ProviderRosterLineItem> providerRosterLineItemSet = providerRosterLineItemDAO.searchByServiceAuthorizarion(
      serviceAuthorizationDAO.findByReferenceNumber(saReferenceNumber));

    // END, CR00279052

    rosterLineItemKey = new RosterLineItemKey();
    rosterLineItemKey.rosterLineItemID = rosterLineItemID;

    fromDate = providerRosterLineItem.getServiceDateFrom();
    toDate = providerRosterLineItem.getServiceDateTo();
    // BEGIN, CR00279857, ASN
    if (PRLIStatusEntry.COMPLETE.equals(
      providerRosterLineItem.getLifecycleState())) {
      noOfUnits = providerRosterLineItem.getUnitsDelivered();
    }
    // END, CR00279857
    // BEGIN, CR00279052, ASN
    for (final ProviderRosterLineItem existingPrli : providerRosterLineItemSet) {

      // BEGIN, CR00279575, ASN
      if ((PRLIStatusEntry.COMPLETE.equals(existingPrli.getLifecycleState()))
        && existingPrli.getID() != providerRosterLineItem.getID()
        && existingPrli.getRoster().getID()
          != providerRosterLineItem.getRoster().getID()) {
        // END, CR00279575
        noOfUnits = noOfUnits + existingPrli.getUnitsDelivered();
      }
    }

    List<PRLITransaction> prliTransactionsSet = new ArrayList<PRLITransaction>();

    for (final ProviderRosterLineItem proRosterLineItem : providerRosterLineItemSet) {

      prliTransactionsSet.addAll(
        prliTransactionDAO.listTransactionsForRosterLineItem(proRosterLineItem));

    }
    // END, CR00279052
    // get amount from Active ProviderRosterLineItemTransaction
    if (payBasedOnAttendanceInd) {
      for (PRLITransaction prliTransaction : prliTransactionsSet) {

        if (PRLITRANSACTIONSTATUS.ACTIVE.equals(
          prliTransaction.getTransactionStatus().getCode())) {
          amount = amount + prliTransaction.getAmount().getValue();
        }
      }
    }

    // read plannedItem details by service AuthorizationKey
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    PlannedItemKey plannedItemKey = new PlannedItemKey();

    ServiceAuthorizationKey serviceAuthorizationKey = new ServiceAuthorizationKey();

    serviceAuthorizationKey.serviceAuthorizationID = serviceAuthID;

    PlannedItemDtls plannedItemDtls = null;

    try {

      plannedItemKey.plannedItemID = providerPlannedItemLinkObj.readByServiceAuthorization(serviceAuthorizationKey).plannedItemID;
      plannedItemDtls = plannedItemObj.read(plannedItemKey);

    } catch (RecordNotFoundException ex) {
      // Stop processing as there is no relation between the service
      // authorization and any of the existing planned items.
      return;

    }
    
    // BEGIN, CR00314944, SSK
    final List<ProviderRosterLineItem> providerRosterLineItems = getEarliestAndLatestProviderRosterLineItem(
      providerRosterLineItem);
    ProviderRosterLineItem earliestProviderRosterLineItem = null;
    ProviderRosterLineItem latestProviderRosterLineItem = null;

    if (1 == providerRosterLineItems.size()) {
      earliestProviderRosterLineItem = providerRosterLineItems.get(0);
      latestProviderRosterLineItem = earliestProviderRosterLineItem;
    } else if (1 < providerRosterLineItems.size()) {
      earliestProviderRosterLineItem = providerRosterLineItems.get(0);
      latestProviderRosterLineItem = providerRosterLineItems.get(1);
    }

    if (null != earliestProviderRosterLineItem) {
      plannedItemDtls.actualStartDate = getPlannedItemActualStartDate(
        isDailyAttendanceTrackingRequired, earliestProviderRosterLineItem);

      plannedItemDtls.status = PLANNEDITEMSTATUSEntry.INPROGRESS.getCode();
    }

    if (plannedItemDtls.actualEndDate.isZero()
      && null != latestProviderRosterLineItem) {
      int remainingUnits = getUnitsRemainingOnPlannedItem(
        providerRosterLineItem);

      if (0 == remainingUnits) {
        plannedItemDtls.actualEndDate = getPlannedItemActualEndDate(
          isDailyAttendanceTrackingRequired, latestProviderRosterLineItem);
        plannedItemDtls.status = PLANNEDITEMSTATUSEntry.COMPLETED.getCode();
      }
    }

    // BEGIN, CR00279052, ASN
    plannedItemDtls.unitsDelivered = noOfUnits;
    // END, CR00279052


    // Update to Actual Cost information on the plan item should only be
    // applied to the plan item if the Pay Based on Attendance indicator for
    // the service in CPM is set to No
    // Update to Actual Cost information on the plan item should only be
    // applied to the plan item if the Attendance Tracking Enabled indicator for
    // the service in CPM is set to Yes

    if (event.eventKey.eventType.equals(
      GeneralProviderConstants.kEventTypeRosterApproved)) {
      plannedItemDtls.actualCost = new Money(
        plannedItemDtls.actualCost.getValue() + amount);

    } else { // for Roster Correction
      plannedItemDtls.actualCost = new Money(amount);
    }

    // modify plannedItem details
    
    
    
    // modify plannedItem details
    plannedItemObj.modify(plannedItemKey, plannedItemDtls);
    
    SetPlannedItemStatusKey setPlannedItemStatusKey = new SetPlannedItemStatusKey();

    setPlannedItemStatusKey.plannedItemID = plannedItemKey.plannedItemID;
    setPlannedItemStatusKey.plannedItemStatus = plannedItemDtls.status;
    plannedItemObj.setStatusCode(setPlannedItemStatusKey);
    // END, CR00314944
    
  }

  // END, CR00273068

  // BEGIN CR00129860, GBA
   
  /**
   * Populates CPM data after receiving event notification for service invoice
   * line item approval.
   *
   * @param primaryEventData
   * : ServiceInvoiceLineItemID
   *
   * @throws AppException
   * , InformationalException
   */

  // BEGIN, CR00177241, PM
  protected void updateServiceInvoiceDetails(Event event) throws AppException,
      InformationalException {
    // END, CR00177241

    boolean isPlacement = false;
    boolean isAttendanceTrackingEnabled = false;
    boolean payBasedOnAttendanceInd = false;
    boolean isDailyAttendanceTrackingRequired = false;
    boolean isUnitOfMeasureHour = false;

    // Retrieve service invoice line item from primary event data
    ServiceInvoiceLineItem serviceInvoiceLineItem = serviceInvoiceLineItemDAO.get(
      event.primaryEventData);

    long serviceAuthID = serviceInvoiceLineItem.retrieveServiceAuthorization().getID();

    DateRange dateRange = new DateRange(
      serviceInvoiceLineItem.getServiceDateFrom(),
      serviceInvoiceLineItem.getServiceDateTo());

    List<SOAttendanceConfiguration> soAttendanceConfigurationList = soAttendanceConfigurationDAO.searchByServiceOfferingAndDateRange(
      serviceInvoiceLineItem.getServiceOffering(), dateRange);

    payBasedOnAttendanceInd = serviceInvoiceLineItem.getServiceOffering().isPayBasedOnAttendance();

    if (soAttendanceConfigurationList.size() > 0) {
      isAttendanceTrackingEnabled = soAttendanceConfigurationList.get(0).isAttendanceTrackingEnabled();
      isDailyAttendanceTrackingRequired = soAttendanceConfigurationList.get(0).isDailyAttendanceTrackingRequired();
    } else {
      isAttendanceTrackingEnabled = false;
      isDailyAttendanceTrackingRequired = false;
    }

    Date attendanceFromDate = serviceInvoiceLineItem.getServiceDateFrom();
    int attendanceNoOfUnits = serviceInvoiceLineItem.getNumberOfUnits();

    if (UnitOfMeasureEntry.PLACE.equals(
      serviceInvoiceLineItem.getServiceOffering().getUnitOfMeasure())) {

      isPlacement = true;

    }

    if (UnitOfMeasureEntry.HOUR.equals(
      serviceInvoiceLineItem.getServiceOffering().getUnitOfMeasure())) {
      isUnitOfMeasureHour = true;
    }

    // read plannedItem ID by service AuthorizationKey
    ServiceAuthorizationKey serviceAuthorizationKey = new ServiceAuthorizationKey();

    serviceAuthorizationKey.serviceAuthorizationID = serviceAuthID;

    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();
    long plannedItemID;

    try {
      plannedItemID = providerPlannedItemLinkObj.readByServiceAuthorization(serviceAuthorizationKey).plannedItemID;

    } catch (RecordNotFoundException ex) {

      // Stop processing as there is no relation between the service
      // authorization and any of the existing planned items.
      return;

    }

    // BEGIN, CR00147896, GBA
    // Create Planned Item and SILI link record for any Unit of Measure type
    PIDailyAttendanceLinkDtls pIDailyAttendanceLinkDtls = new PIDailyAttendanceLinkDtls();

    pIDailyAttendanceLinkDtls.plannedItemID = plannedItemID;
    pIDailyAttendanceLinkDtls.recordStatus = RECORDSTATUS.NORMAL;
    pIDailyAttendanceLinkDtls.relatedID = serviceInvoiceLineItem.getID();
    PIDailyAttendanceLink pIDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    // END, CR00147896

    if (!isPlacement) {

      // Update Daily Attendance only if in CPM Attendance Tracking indicator
      // is set to No effective from the Service Date From to Service End Date
      // of the service invoice line item, or the Attendance Tracking indicator
      // for the service is set to Yes and the 'Daily Attendance Tracking
      // Required' indicator for the service is set to No

      if ((!isAttendanceTrackingEnabled)
        || (isAttendanceTrackingEnabled && !isDailyAttendanceTrackingRequired)) {
        // Insert new Daily Attendance record
        DailyAttendanceDtls dailyAttendanceDtls = new DailyAttendanceDtls();

        PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
        PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

        plannedItemIDKey.plannedItemID = plannedItemID;
        ReadCaseIDByPlannedItemDetailsStruct caseIDDtls = plannedItemObj.readCaseIDByPlannedItemID(
          plannedItemIDKey);

        curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

        dailyAttendanceDtls.dailyAttendanceID = uniqueIDObj.getNextID();
        dailyAttendanceDtls.serviceDate = attendanceFromDate;
        dailyAttendanceDtls.caseID = caseIDDtls.caseID;
        dailyAttendanceDtls.unitsAttended = (short) attendanceNoOfUnits;
        dailyAttendanceDtls.attendance = ATTENDANCE.PRESENT;
        dailyAttendanceDtls.recordStatus = RECORDSTATUS.NORMAL;
        dailyAttendanceDtls.creationDate = Date.getCurrentDate();
        dailyAttendanceDtls.createdBySystem = true;
        setTotalHours(dailyAttendanceDtls, isUnitOfMeasureHour);

        DailyAttendance dailyAttendanceObj = DailyAttendanceFactory.newInstance();

        dailyAttendanceObj.insert(dailyAttendanceDtls);

        pIDailyAttendanceLinkDtls.dailyAttendanceID = dailyAttendanceDtls.dailyAttendanceID;
      }

    }
    // BEGIN, CR00147896, GBA
    pIDailyAttendanceLinkObj.insert(pIDailyAttendanceLinkDtls);
    // END, CR00147896

    updatePlannedItem(plannedItemID, isAttendanceTrackingEnabled,
      payBasedOnAttendanceInd);

  }

  // END CR00128516

   
  /**
   * Populates CPM data after receiving event notification for service invoice
   * line item correction approval.
   *
   * @param primaryEventData
   * : SILICorrectionID
   *
   * @throws AppException
   * , InformationalException
   */

  // BEGIN, CR00177241, PM
  protected void updateWithSILICorrection(Event event) throws AppException,
      InformationalException {
    // END, CR00177241

    boolean isPlacement = false;
    boolean isAttendanceTrackingEnabled = false;
    boolean payBasedOnAttendanceInd = false;
    boolean isDailyAttendanceTrackingRequired = false;
    boolean updateDailyAttendance = false;
    boolean isUnitOfMeasureHour = false;

    // Retrieve service invoice line item from primary event data
    ServiceInvoiceLineItem serviceInvoiceLineItem = sILICorrectionDAO.get(event.primaryEventData).getServiceInvoiceLineItem();

    Date attendanceFromDate = serviceInvoiceLineItem.getServiceDateFrom();
    int attendanceNoOfUnits = serviceInvoiceLineItem.getNumberOfUnits();

    // Retrieve various configurations for associated service offering
    DateRange dateRange = new DateRange(
      serviceInvoiceLineItem.getServiceDateFrom(),
      serviceInvoiceLineItem.getServiceDateTo());

    List<SOAttendanceConfiguration> soAttendanceConfigurationList = soAttendanceConfigurationDAO.searchByServiceOfferingAndDateRange(
      serviceInvoiceLineItem.getServiceOffering(), dateRange);

    payBasedOnAttendanceInd = serviceInvoiceLineItem.getServiceOffering().isPayBasedOnAttendance();

    if (soAttendanceConfigurationList.size() > 0) {
      isAttendanceTrackingEnabled = soAttendanceConfigurationList.get(0).isAttendanceTrackingEnabled();
      isDailyAttendanceTrackingRequired = soAttendanceConfigurationList.get(0).isDailyAttendanceTrackingRequired();
    } else {
      isAttendanceTrackingEnabled = false;
      isDailyAttendanceTrackingRequired = false;
    }

    if (UnitOfMeasureEntry.PLACE.equals(
      serviceInvoiceLineItem.getServiceOffering().getUnitOfMeasure())) {
      isPlacement = true;
    }

    if (UnitOfMeasureEntry.HOUR.equals(
      serviceInvoiceLineItem.getServiceOffering().getUnitOfMeasure())) {
      isUnitOfMeasureHour = true;
    }

    if (!isPlacement) {

      // Update Daily Attendance only if in CPM Attendance Tracking indicator
      // is set to No effective from the Service Date From to Service End Date
      // of the service invoice line item, or the Attendance Tracking indicator
      // for the service is set to Yes and the 'Daily Attendance Tracking
      // Required' indicator for the service is set to No

      if ((!isAttendanceTrackingEnabled)
        || (isAttendanceTrackingEnabled && !isDailyAttendanceTrackingRequired)) {
        updateDailyAttendance = true;
      }

    }

    // Determine the old plan item associated to SILI being corrected
    PIDailyAttendanceLink pIDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();
    RelatedIDKey relatedIDKey = new RelatedIDKey();

    relatedIDKey.relatedID = serviceInvoiceLineItem.getID();
    // BEGIN CR00145417, GBA
    PIDailyAttendanceLinkDtls oldPIDailyAttendanceLinkDtls = null;

    try {
      oldPIDailyAttendanceLinkDtls = pIDailyAttendanceLinkObj.readByRelatedID(
        relatedIDKey);
    } catch (RecordNotFoundException ex) {

      // Stop processing as there is no relation between the service
      // invoice line item and any of the existing planned items.
      return;
    }
    // END CR00145417

    long oldPlannedItemID = oldPIDailyAttendanceLinkDtls.plannedItemID;

    // Retrieve old service authorization
    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();
    PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = oldPlannedItemID;

    ProviderPlannedItemLinkDtls oldProviderPlannedItemLinkDtls = providerPlannedItemLinkObj.readByPlannedItemID(
      plannedItemIDKey);

    // Retrieve new service authorization for SILI being corrected
    long serviceAuthID = serviceInvoiceLineItem.retrieveServiceAuthorization().getID();

    boolean serviceAuthorizationChanged = false;

    if (oldProviderPlannedItemLinkDtls.serviceAuthorizationID != serviceAuthID) {
      serviceAuthorizationChanged = true;
    }

    DailyAttendance dailyAttendanceObj = DailyAttendanceFactory.newInstance();
    DailyAttendanceKey dailyAttendanceKey = new DailyAttendanceKey();
    DailyAttendanceDtls dailyAttendanceDtls;

    if (serviceAuthorizationChanged) {
      // BEGIN, CR00147896, GBA
      // Delete old planned item and daily attendance/SILI link record
      PIDailyAttendanceLinkKey pIDailyAttendanceLinkKey = new PIDailyAttendanceLinkKey();

      pIDailyAttendanceLinkKey.piDailyAttendanceLinkID = oldPIDailyAttendanceLinkDtls.piDailyAttendanceLinkID;
      pIDailyAttendanceLinkObj.remove(pIDailyAttendanceLinkKey);

      if (updateDailyAttendance) {
        // Delete old daily attendance record
        dailyAttendanceKey.dailyAttendanceID = oldPIDailyAttendanceLinkDtls.dailyAttendanceID;
        dailyAttendanceObj.remove(dailyAttendanceKey);
      }
      // END, CR00147896

      // Determine the new planned item by new service Authorization

      ServiceAuthorizationKey serviceAuthorizationKey = new ServiceAuthorizationKey();

      serviceAuthorizationKey.serviceAuthorizationID = serviceAuthID;

      long plannedItemID;

      try {

        plannedItemID = providerPlannedItemLinkObj.readByServiceAuthorization(serviceAuthorizationKey).plannedItemID;

      } catch (RecordNotFoundException ex) {
        // Stop processing as there is no relation between the service
        // authorization and any of the existing planned items.
        return;

      }
      // BEGIN, CR00147896, GBA
      // Create Planned Item and SILI link record for any Unit of Measure type
      PIDailyAttendanceLinkDtls pIDailyAttendanceLinkDtls = new PIDailyAttendanceLinkDtls();

      pIDailyAttendanceLinkDtls.plannedItemID = plannedItemID;
      pIDailyAttendanceLinkDtls.recordStatus = RECORDSTATUS.NORMAL;
      pIDailyAttendanceLinkDtls.relatedID = serviceInvoiceLineItem.getID();
      // END, CR00147896
      if (updateDailyAttendance) {
        // Insert new Daily Attendance record
        dailyAttendanceDtls = new DailyAttendanceDtls();

        PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
        ReadCaseIDByPlannedItemDetailsStruct caseIDDtls = plannedItemObj.readCaseIDByPlannedItemID(
          plannedItemIDKey);
        curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

        dailyAttendanceDtls.dailyAttendanceID = uniqueIDObj.getNextID();
        dailyAttendanceDtls.serviceDate = attendanceFromDate;
        dailyAttendanceDtls.caseID = caseIDDtls.caseID;
        dailyAttendanceDtls.unitsAttended = (short) attendanceNoOfUnits;
        dailyAttendanceDtls.attendance = ATTENDANCE.PRESENT;
        dailyAttendanceDtls.recordStatus = RECORDSTATUS.NORMAL;
        dailyAttendanceDtls.creationDate = Date.getCurrentDate();
        dailyAttendanceDtls.createdBySystem = true;
        setTotalHours(dailyAttendanceDtls, isUnitOfMeasureHour);

        dailyAttendanceObj.insert(dailyAttendanceDtls);

        pIDailyAttendanceLinkDtls.dailyAttendanceID = dailyAttendanceDtls.dailyAttendanceID;
      }
      // BEGIN, CR00147896, GBA
      pIDailyAttendanceLinkObj.insert(pIDailyAttendanceLinkDtls);
      // END, CR00147896
      // BEGIN CR00141541, GBA
      // Update new planned item
      updatePlannedItem(plannedItemID, isAttendanceTrackingEnabled,
        payBasedOnAttendanceInd);
      // END CR00141541
    } else {

      if (updateDailyAttendance) {
        // update attendance record with Units Attended, Service Date, Total
        // Hour

        dailyAttendanceKey.dailyAttendanceID = oldPIDailyAttendanceLinkDtls.dailyAttendanceID;
        dailyAttendanceDtls = dailyAttendanceObj.read(dailyAttendanceKey);

        dailyAttendanceDtls.serviceDate = attendanceFromDate;
        dailyAttendanceDtls.unitsAttended = (short) attendanceNoOfUnits;
        setTotalHours(dailyAttendanceDtls, isUnitOfMeasureHour);

        dailyAttendanceObj.modify(dailyAttendanceKey, dailyAttendanceDtls);
      }

    }

    // Update planned item - old one for service authorization change
    updatePlannedItem(oldPlannedItemID, isAttendanceTrackingEnabled,
      payBasedOnAttendanceInd);
  }

  /**
   * Populates Planned Item Actual Start and End Date, Total Units Delivered,
   * Amount, Status
   *
   * @param plannedItemID
   * , Set containing SILIs, isAttendanceTrackingEnabled,
   * payBasedOnAttendanceInd
   */
  // BEGIN, CR00177241, PM
  protected void updatePlannedItem(long plannedItemID,
    boolean isAttendanceTrackingEnabled, boolean payBasedOnAttendanceInd)
    throws AppException, InformationalException {
    // END, CR00177241

    Date fromDate = Date.kZeroDate;
    Date toDate = Date.kZeroDate;
    int noOfUnits = 0;
    double amount = 0;

    // Get all SILI-Attendance-Planned Item link records for the planned item
    PIDailyAttendanceLink pIDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();
    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = plannedItemID;

    PIDailyAttendanceLinkDtlsList pIDailyAttendanceLinkDtlsList = pIDailyAttendanceLinkObj.searchByPlannedItemID(
      plannedItemKey);

    if (pIDailyAttendanceLinkDtlsList.dtls.size() > 0) {
      int firstIntance = 0;

      for (int i = 0; i < pIDailyAttendanceLinkDtlsList.dtls.size(); i++) {
        ServiceInvoiceLineItem serviceInvoiceLnItem = serviceInvoiceLineItemDAO.get(
          pIDailyAttendanceLinkDtlsList.dtls.item(i).relatedID);

        if (!isAttendanceTrackingEnabled) {
          noOfUnits += serviceInvoiceLnItem.getNumberOfUnits();
          Date tempDate = serviceInvoiceLnItem.getServiceDateFrom();

          if (firstIntance == 0) {
            fromDate = tempDate;
            toDate = tempDate;
            firstIntance++;
          }
          if (tempDate.before(fromDate)) {
            fromDate = tempDate;
          }
          if (tempDate.after(toDate)) {
            toDate = tempDate;
          }
        }
        // Update to Actual Cost information on the plan item should only be
        // applied to the plan item if the Pay Based on Attendance indicator for
        // the service in CPM is set to No and the Attendance Tracking Enabled
        // indicator for the service in CPM is set to Yes
        if (!payBasedOnAttendanceInd) {
          amount += serviceInvoiceLnItem.getAmountPaid().getValue();
        }
      }
    }

    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    PlannedItemDtls plannedItemDtls = plannedItemObj.read(plannedItemKey);

    if (!isAttendanceTrackingEnabled) {
      // Update actual start date, end date and status
      plannedItemDtls.unitsDelivered = noOfUnits;

      if (plannedItemDtls.unitsDelivered == 0) {

        plannedItemDtls.actualStartDate = Date.kZeroDate;
        plannedItemDtls.actualEndDate = Date.kZeroDate;
        plannedItemDtls.status = PLANNEDITEMSTATUS.NOTSTARTED;

      }

      if (plannedItemDtls.unitsDelivered != 0
        && plannedItemDtls.unitsDelivered
          < plannedItemDtls.totalUnitsAuthorized) {

        plannedItemDtls.actualStartDate = fromDate;
        plannedItemDtls.actualEndDate = Date.kZeroDate;
        plannedItemDtls.status = PLANNEDITEMSTATUS.INPROGRESS;
      }

      if (plannedItemDtls.unitsDelivered
        == plannedItemDtls.totalUnitsAuthorized) {
        plannedItemDtls.actualStartDate = fromDate;
        plannedItemDtls.actualEndDate = toDate;
        plannedItemDtls.status = PLANNEDITEMSTATUS.COMPLETED;
      }
    }

    if (payBasedOnAttendanceInd == false) {
      plannedItemDtls.actualCost = new Money(amount);
    }

    // modify plannedItem details
    plannedItemObj.modify(plannedItemKey, plannedItemDtls);
  }

  /**
   * Populates 'TotalHours','TotalMinutes','HoursAbsent' and 'MinutesAbsent' of
   * Daily Attendance. Set 'TotalHours' same as 'Units Attended' if unit of
   * measure is Hours and 'Units Attended' is greater than zero, otherwise set
   * zero. Set 'HoursAbsent' same as 'Units Not Attended' if unit of measure is
   * Hours and 'Units Unattended' is greater than zero, otherwise set zero Set
   * 'TotalMinutes'/'MinutesAbsent' always zero.
   *
   * @param object
   * DailyAttendanceDtls, boolean isUnitOfMeasureHour
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void setTotalHours(DailyAttendanceDtls dailyAttendanceDtls,
    boolean isUnitOfMeasureHour) throws AppException, InformationalException {
    // END, CR00177241
    // BEGIN, CR00171307, GBA
    if (isUnitOfMeasureHour) {
      if (dailyAttendanceDtls.unitsAttended > 0) {
        // set 'Total Hours' value same as units attended
        // if units attended is single digit, prefix with 0 to match
        // ATTENDANCETRACKINGMINUTES code table values.
        if (dailyAttendanceDtls.unitsAttended < 10) {
          dailyAttendanceDtls.totalHours = CuramConst.gkStringZero
            + String.valueOf(dailyAttendanceDtls.unitsAttended);
        } else {
          dailyAttendanceDtls.totalHours = String.valueOf(
            dailyAttendanceDtls.unitsAttended);
        }
        if (CuramConst.gkZero == dailyAttendanceDtls.unitsUnattended) {
          dailyAttendanceDtls.hoursAbsent = curam.codetable.ATTENDANCETRACKINGHOURS.ATH2001;
        }
        // BEGIN, CR00147814, GBA
      }

      if (dailyAttendanceDtls.unitsUnattended > 0) {
        // set 'Hours Absent' value same as units unattended
        // if units unattended is single digit, prefix with 0 to match
        // ATTENDANCETRACKINGMINUTES code table values.
        if (dailyAttendanceDtls.unitsUnattended < 10) {
          dailyAttendanceDtls.hoursAbsent = CuramConst.gkStringZero
            + String.valueOf(dailyAttendanceDtls.unitsUnattended);
        } else {
          dailyAttendanceDtls.hoursAbsent = String.valueOf(
            dailyAttendanceDtls.unitsUnattended);
        }
        if (CuramConst.gkZero == dailyAttendanceDtls.unitsAttended) {
          dailyAttendanceDtls.totalHours = curam.codetable.ATTENDANCETRACKINGHOURS.ATH2001;
        }
      }
      // END, CR00147814
    } else {
      dailyAttendanceDtls.totalHours = curam.codetable.ATTENDANCETRACKINGHOURS.ATH2001;
      dailyAttendanceDtls.hoursAbsent = curam.codetable.ATTENDANCETRACKINGHOURS.ATH2001;
    }
    dailyAttendanceDtls.totalMinutes = curam.codetable.ATTENDANCETRACKINGMINUTES.ATM2001;
    dailyAttendanceDtls.minutesAbsent = curam.codetable.ATTENDANCETRACKINGMINUTES.ATM2001;
    // END, CR00171307
  }

  // END CR00129860

   
  /**
   * Associate the absence and daily attendance records to planned item; Update
   * 'Total Hours', caseID for Daily Attendance record; Update period dates
   * associated with the Absence Details record
   *
   * @param rosterLineItemID
   * , serviceAuthID
   */
  // BEGIN, CR00177241, PM
  protected void updateClientParticipationRecords(long rosterLineItemID,
    long serviceAuthID) throws AppException, InformationalException {
    // END, CR00177241

    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    ServiceAuthorizationKey serviceAuthorizationKey = new ServiceAuthorizationKey();

    serviceAuthorizationKey.serviceAuthorizationID = serviceAuthID;

    ProviderPlannedItemLinkDtls providerPlannedItemLinkDtls = null;

    try {
      providerPlannedItemLinkDtls = providerPlannedItemLinkObj.readByServiceAuthorization(
        serviceAuthorizationKey);
    } catch (RecordNotFoundException e) {// No service plan item is associated
      // to the service authorization,
      // processing stops.
    }

    if (providerPlannedItemLinkDtls != null) {

      // associate daily attendance and absence records with planned item
      // BEGIN CR00131528, GBA
      // read Roster Line Item record
      curam.core.sl.entity.intf.RosterLineItem rosterLineItemObj = curam.core.sl.entity.fact.RosterLineItemFactory.newInstance();
      RosterLineItemKey rosterLineItemKey = new RosterLineItemKey();

      rosterLineItemKey.rosterLineItemID = rosterLineItemID;
      RosterLineItemDtls rosterLineItemDtls = rosterLineItemObj.read(
        rosterLineItemKey);
      // END CR00131528

      // read absence records with given RosterLineItemID
      curam.core.sl.entity.intf.AbsencePeriod absencePeriodObj = curam.core.sl.entity.fact.AbsencePeriodFactory.newInstance();
      AbsencePeriodDtlsList absenceDtlsList = absencePeriodObj.searchByRosterLineItemID(
        rosterLineItemKey);

      if (absenceDtlsList != null) {
        int numberOfAbsence = absenceDtlsList.dtls.size();

        // associate planned item with absence details record

        PlannedItemAbsenceLink plannedItemAbsenceObj = PlannedItemAbsenceLinkFactory.newInstance();
        PlannedItemAbsenceLinkDtls plannedItemAbsenceLinkDtls = new PlannedItemAbsenceLinkDtls();

        plannedItemAbsenceLinkDtls.plannedItemID = providerPlannedItemLinkDtls.plannedItemID;

        for (int k = 0; k < numberOfAbsence; k++) {
          plannedItemAbsenceLinkDtls.absencePeriodID = absenceDtlsList.dtls.item(k).absencePeriodID;
          // BEGIN CR00128937, GBA
          plannedItemAbsenceLinkDtls.recordStatus = absenceDtlsList.dtls.item(k).recordStatus;
          // END CR00128937

          // BEGIN CR00128516, GBA
          // After Roster correction happens, only active records should be
          // added to the link table
          if (RECORDSTATUS.NORMAL.equals(
            absenceDtlsList.dtls.item(k).recordStatus)) {
            // insert into planned item and absence link entity
            plannedItemAbsenceObj.insert(plannedItemAbsenceLinkDtls);
          }
          // END CR00128516

          // BEGIN CR00131528, GBA
          // update period start date and end date for absence record
          AbsencePeriodKey absencePeriodKey = new AbsencePeriodKey();

          absencePeriodKey.absencePeriodID = absenceDtlsList.dtls.item(k).absencePeriodID;

          absenceDtlsList.dtls.item(k).periodStartDate = rosterLineItemDtls.serviceFrom;
          absenceDtlsList.dtls.item(k).periodEndDate = rosterLineItemDtls.serviceTo;

          // update daily attendance record
          absencePeriodObj.modify(absencePeriodKey,
            absenceDtlsList.dtls.item(k));
          // END CR00131528
        }
      }

      // read service offering for the planned item
      curam.serviceoffering.impl.ServiceOffering serviceOffering = serviceOfferingDAO.get(
        providerPlannedItemLinkDtls.serviceOfferingID);

      boolean isUnitOfMeasureHour = false;

      if (UnitOfMeasureEntry.HOUR.equals(serviceOffering.getUnitOfMeasure())) {
        isUnitOfMeasureHour = true;
      }

      // read daily attendance records with given RosterLineItemID
      curam.core.sl.entity.intf.DailyAttendance dailyAttendanceObj = curam.core.sl.entity.fact.DailyAttendanceFactory.newInstance();
      DailyAttendanceDtlsList dailyAttendanceDtlsList = dailyAttendanceObj.searchByRosterLineItemID(
        rosterLineItemKey);

      if (dailyAttendanceDtlsList != null) {
        int numberOfAttendance = dailyAttendanceDtlsList.dtls.size();

        // associate planned item with daily attendance records

        PIDailyAttendanceLink pIDailyAttendanceObj = PIDailyAttendanceLinkFactory.newInstance();

        PIDailyAttendanceLinkDtls pIDailyAttendanceLinkDtls = new PIDailyAttendanceLinkDtls();

        pIDailyAttendanceLinkDtls.plannedItemID = providerPlannedItemLinkDtls.plannedItemID;

        // BEGIN CR00131528, GBA
        // read service plan case id
        PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
        PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

        plannedItemIDKey.plannedItemID = providerPlannedItemLinkDtls.plannedItemID;

        ReadCaseIDByPlannedItemDetailsStruct caseIDDtls = plannedItemObj.readCaseIDByPlannedItemID(
          plannedItemIDKey);

        // END CR00131528

        for (int k = 0; k < numberOfAttendance; k++) {

          // BEGIN CR00122149, GBA
          if ((dailyAttendanceDtlsList.dtls.item(k).attendance == null)
            || dailyAttendanceDtlsList.dtls.item(k).attendance.trim().length()
              == 0) {
            continue;
          }
          // END CR00122149

          pIDailyAttendanceLinkDtls.dailyAttendanceID = dailyAttendanceDtlsList.dtls.item(k).dailyAttendanceID;

          // BEGIN CR00128937, GBA
          pIDailyAttendanceLinkDtls.recordStatus = dailyAttendanceDtlsList.dtls.item(k).recordStatus;
          // END CR00128937

          // BEGIN CR00128516, GBA
          // After Roster correction happens, canceled records should not be
          // added to the link table
          if (RECORDSTATUS.NORMAL.equals(
            dailyAttendanceDtlsList.dtls.item(k).recordStatus)) {
            // insert into planned item and daily attendance link entity
            pIDailyAttendanceObj.insert(pIDailyAttendanceLinkDtls);
          }
          // END CR00128516

          // if unit of measure is HOUR, update total hours of daily attendance
          // BEGIN CR00141692, GBA
          setTotalHours(dailyAttendanceDtlsList.dtls.item(k),
            isUnitOfMeasureHour);
          // END CR00141692

          // BEGIN CR00131528, GBA
          DailyAttendanceKey dailyAttendanceKey = new DailyAttendanceKey();

          dailyAttendanceKey.dailyAttendanceID = dailyAttendanceDtlsList.dtls.item(k).dailyAttendanceID;
          dailyAttendanceDtlsList.dtls.item(k).caseID = caseIDDtls.caseID;

          // update daily attendance record
          dailyAttendanceObj.modify(dailyAttendanceKey,
            dailyAttendanceDtlsList.dtls.item(k));
          // END CR00131528
          // END CR00124859
        }

      }

    }

  }

  // BEGIN, CR00314944, SSK

  /**
   * Retrieves the earliest and the latest provider roster line item among the
   * provider roster line items associated with planned item.
   *
   * @param ProviderRosterLineItem
   * The provider roster line item associated with the planned item.
   *
   * @return The earliest and the latest provider roster line item among the
   * provider roster line items associated with planned item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected List<ProviderRosterLineItem> getEarliestAndLatestProviderRosterLineItem(
    final  ProviderRosterLineItem currentProviderRosterLineItem)
    throws AppException, InformationalException {
    final List<ProviderRosterLineItem> providerRosterLineItems = new ArrayList<ProviderRosterLineItem>();
    final Set<ProviderRosterLineItem> allProviderRosterLineItems = providerRosterLineItemDAO.searchByServiceAuthorizarion(
      currentProviderRosterLineItem.getServiceAuthorization());

    if (1 == allProviderRosterLineItems.size()) {
      providerRosterLineItems.add(allProviderRosterLineItems.iterator().next());
    } else if (1 < allProviderRosterLineItems.size()) {
      final List<ProviderRosterLineItem> sortedProviderRosterLineItems = sortProviderRosterLineItem(
        allProviderRosterLineItems);

      providerRosterLineItems.add(sortedProviderRosterLineItems.get(0));
      providerRosterLineItems.add(
        sortedProviderRosterLineItems.get(allProviderRosterLineItems.size() - 1));

    }

    return providerRosterLineItems;
  }

  /**
   * Retrieves the total units remaining on the planned item.
   *
   * @param ProviderRosterLineItem
   * The  provider roster line item associated with the planned
   * item.
   * @return The total units remaining on the planned item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected int getUnitsRemainingOnPlannedItem(final ProviderRosterLineItem currentProviderRosterLineItem)
    throws AppException, InformationalException {
    
    int remainingUnit = 0;
    final Set<ProviderRosterLineItem> providerRosterLineItems = providerRosterLineItemDAO.searchByServiceAuthorizarion(
      currentProviderRosterLineItem.getServiceAuthorization());
    Set<PRLISALILink> prliSaliLinkList;

    for (final ProviderRosterLineItem providerRosterLineItem : providerRosterLineItems) {
      prliSaliLinkList = pRLISALILinkDAO.searchByProviderRosterLineItem(
        providerRosterLineItem);
      for (final PRLISALILink prliSaliLink : prliSaliLinkList) {
        remainingUnit += prliSaliLink.getRemainingUnits();
      }
    }

    return remainingUnit;
  }

  /**
   * Retrieves the planned item start date.
   *
   * @param isDailyAttendanceTrackingRequired
   * Indicator is daily attendance tracking is configured.
   *
   * @param earliestProviderRosterLineItem
   * The earliest provider roster line item associated with the planned
   * item.
   *
   * @return The start date of the planned item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected Date getPlannedItemActualStartDate(
    final boolean isDailyAttendanceTrackingRequired,
    final ProviderRosterLineItem earliestProviderRosterLineItem)
    throws AppException, InformationalException {

    Date plannedItemActualStartDate = Date.kZeroDate;
    final ArrayList<AbsencePeriod> absencePeriods = sortAbsenceByServiceDate(
      getAllAbsencePeriodsForPlannedItem(earliestProviderRosterLineItem));
    Date absenceStartDate = getEarliestAbsenceDate(absencePeriods);

    if (isDailyAttendanceTrackingRequired) {

      final ArrayList<curam.attendance.impl.DailyAttendance> sortedDailyAttebdance = sortDailyAttendanceByServiceDate(
        getAllDailyAttendancesForPlannedItem(earliestProviderRosterLineItem));
      Date dailyAttendanceStartDate = getEarliestDailyAttendanceDeliveryDate(
        sortedDailyAttebdance);

      if (!(dailyAttendanceStartDate.isZero() && absenceStartDate.isZero())
        && dailyAttendanceStartDate.before(absenceStartDate)) {
        plannedItemActualStartDate = dailyAttendanceStartDate;
      } else {
        if (!absenceStartDate.isZero()) {
          plannedItemActualStartDate = absenceStartDate;
        } else {
          plannedItemActualStartDate = dailyAttendanceStartDate;
        }
      }
    } else {
      Date providerRosterLineItemStartDate = earliestProviderRosterLineItem.getDateRange().start();

      if (!(providerRosterLineItemStartDate.isZero()
        && absenceStartDate.isZero())
          && providerRosterLineItemStartDate.before(absenceStartDate)) {
        plannedItemActualStartDate = providerRosterLineItemStartDate;
      } else {
        if (!absenceStartDate.isZero()) {
          plannedItemActualStartDate = absenceStartDate;
        } else {
          plannedItemActualStartDate = providerRosterLineItemStartDate;
        }
      }
    }
    return plannedItemActualStartDate;
  }

  /**
   * Retrieves the set of absence period associated with the planned item.
   *
   * @param providerRosterLineItem
   * Contains the details of the provider roster line item associated
   * with planned item.
   *
   * @return The set of absence period associated with the planned item. 
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected Set<AbsencePeriod> getAllAbsencePeriodsForPlannedItem(final ProviderRosterLineItem currentProviderRosterLineItem) throws AppException,
      InformationalException {
    final Set<AbsencePeriod> absencePeriods = new HashSet<AbsencePeriod>();
    
    final Set<ProviderRosterLineItem> allProviderRosterLineItems = providerRosterLineItemDAO.searchByServiceAuthorizarion(
      currentProviderRosterLineItem.getServiceAuthorization());
    
    for (final ProviderRosterLineItem providerRosterLineItem : allProviderRosterLineItems) {
      absencePeriods.addAll(providerRosterLineItem.getAbsencePeriod());
    }
    return absencePeriods;
  }
  
  /**
   * Retrieves the set of daily attendances associated with the planned item.
   *
   * @param providerRosterLineItem
   * Contains the details of the provider roster line item associated
   * with planned item.
   *
   * @return The set of daily attendances associated with the planned item.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected Set<curam.attendance.impl.DailyAttendance> getAllDailyAttendancesForPlannedItem(final ProviderRosterLineItem currentProviderRosterLineItem) throws AppException,
      InformationalException {
    final Set<curam.attendance.impl.DailyAttendance> dailyAttendances = new HashSet<curam.attendance.impl.DailyAttendance>();
  
    final Set<ProviderRosterLineItem> allProviderRosterLineItems = providerRosterLineItemDAO.searchByServiceAuthorizarion(
      currentProviderRosterLineItem.getServiceAuthorization());
  
    for (final ProviderRosterLineItem providerRosterLineItem : allProviderRosterLineItems) {
      dailyAttendances.addAll(providerRosterLineItem.getDailyAttendances());
    }
    return dailyAttendances;
  }

  /**
   * Retrieves the planned item end date.
   *
   * @param isDailyAttendanceTrackingRequired
   * Indicator is daily attendance tracking is configured.
   *
   * @param latestProviderRosterLineItem
   * The latest provider roster line item associated with the planned
   * item.
   *
   * @return The end date of the planned item.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected Date getPlannedItemActualEndDate(
    final boolean isDailyAttendanceTrackingRequired,
    final ProviderRosterLineItem latestProviderRosterLineItem) throws AppException,
      InformationalException {
    Date plannedItemActualEndDate = Date.kZeroDate;
    final ArrayList<AbsencePeriod> absencePeriods = sortAbsenceByServiceDate(
      getAllAbsencePeriodsForPlannedItem(latestProviderRosterLineItem));
    Date absenceEndDate = getLatestAbsenceDate(absencePeriods);

    if (isDailyAttendanceTrackingRequired) {

      final ArrayList<curam.attendance.impl.DailyAttendance> sortedDailyAttebdance = sortDailyAttendanceByServiceDate(
        getAllDailyAttendancesForPlannedItem(latestProviderRosterLineItem));

      Date dailyAttendanceEndDate = getLatestDailyAttendanceDeliveryDate(
        sortedDailyAttebdance);

      if (!(dailyAttendanceEndDate.isZero() && absenceEndDate.isZero())
        && dailyAttendanceEndDate.after(absenceEndDate)) {
        plannedItemActualEndDate = dailyAttendanceEndDate;
      } else {
        if (!absenceEndDate.isZero()) {
          plannedItemActualEndDate = absenceEndDate;
        } else {
          plannedItemActualEndDate = dailyAttendanceEndDate;
        }
      }
    } else {

      Date providerRosterLineItemEndDate = latestProviderRosterLineItem.getDateRange().end();

      if (!(providerRosterLineItemEndDate.isZero() && absenceEndDate.isZero())
        && providerRosterLineItemEndDate.after(absenceEndDate)) {
        plannedItemActualEndDate = providerRosterLineItemEndDate;
      } else {
        if (!absenceEndDate.isZero()) {
          plannedItemActualEndDate = absenceEndDate;
        } else {
          plannedItemActualEndDate = providerRosterLineItemEndDate;
        }
      }
    }
    return plannedItemActualEndDate;
  }

  /**
   * Retrieves the earliest daily attendance date among the list of daily attendances.
   *
   * @param dailyAttendances The list of daily attendances.
   *
   * @return The earliest daily attendance date.
   */
  protected Date getEarliestDailyAttendanceDeliveryDate(
    final ArrayList<curam.attendance.impl.DailyAttendance> dailyAttebdances) {
    Date dailyAttendanceStartDate = Date.kZeroDate;

    if (!dailyAttebdances.isEmpty()) {
      for (final curam.attendance.impl.DailyAttendance dailyAttendance : dailyAttebdances) {
        if (!StringUtil.isNullOrEmpty(dailyAttendance.getAttendance().getCode())) {
          dailyAttendanceStartDate = dailyAttendance.getServiceDate();
          break;
        }

      }
    }

    return dailyAttendanceStartDate;
  }

  /**
   * Retrieves the latest daily attendance date among the list of daily attendances.
   *
   * @param dailyAttendances The list of daily attendances.
   *
   * @return The latest daily attendance date.
   */
  protected Date getLatestDailyAttendanceDeliveryDate(
    final ArrayList<curam.attendance.impl.DailyAttendance> dailyAttendances) {
    Date dailyAttendanceStartDate = Date.kZeroDate;

    if (!dailyAttendances.isEmpty()) {
      curam.attendance.impl.DailyAttendance dailyAttendance;

      for (int i = dailyAttendances.size() - 1; i >= 0; i--) {
        dailyAttendance = dailyAttendances.get(i);
        if (!StringUtil.isNullOrEmpty(dailyAttendance.getAttendance().getCode())) {
          dailyAttendanceStartDate = dailyAttendance.getServiceDate();
          break;
        }

      }
    }

    return dailyAttendanceStartDate;
  }

  /**
   * Retrieves the earliest absence date among the set of absence periods.
   *
   * @param absencePeriods The list of absence periods
   *
   * @return The earliest absence date.
   */
  protected Date getEarliestAbsenceDate(final ArrayList<AbsencePeriod> absencePeriods) {
    Date absenceStartDate = Date.kZeroDate;

    for (final AbsencePeriod absencePeriod : absencePeriods) {
      absenceStartDate = getEarliestDate(absencePeriod.getAbsenceDate(),
        absencePeriod.getPeriodStartDate());
      if (!absenceStartDate.isZero()) {
        break;
      }
    }
    return absenceStartDate;
  }

  /**
   * Compares the two dates and retrieves the earliest among the two.
   *
   * @param date1
   * First date.
   * @param date2
   * Second date.
   *
   * @return The earliest date among the two dates.
   */
  protected Date getEarliestDate(final Date date1, final Date date2) {
    Date earliestDate = Date.kZeroDate;

    if (!(date1.isZero() && date2.isZero())) {
      if (date1.before(date2)) {
        earliestDate = date1;
      } else {
        earliestDate = date2;
      }
    } else {

      if (!date1.isZero()) {
        earliestDate = date1;
      } else {
        earliestDate = date2;
      }
    }

    return earliestDate;
  }

  /**
   * Compares the two dates and retrieves the latest among the two.
   *
   * @param date1
   * First date.
   * @param date2
   * Second date.
   *
   * @return The latest date among the two dates.
   */
  protected Date getLatestDate(final Date date1, final Date date2) {
    Date earliestDate = Date.kZeroDate;

    if (!(date1.isZero() && date2.isZero())) {
      if (date1.after(date2)) {
        earliestDate = date1;
      } else {
        earliestDate = date2;
      }
    } else {

      if (!date1.isZero()) {
        earliestDate = date1;
      } else {
        earliestDate = date2;
      }
    }

    return earliestDate;
  }

  /**
   * Retrieves the latest absence date among the set of absence periods.
   *
   * @param absencePeriods The list of absence periods
   *
   * @return The latest absence date.
   */
  protected Date getLatestAbsenceDate(final ArrayList<AbsencePeriod> absencePeriods) {
    Date absenceEndDate = Date.kZeroDate;
    AbsencePeriod absencePeriod;

    for (int i = absencePeriods.size() - 1; i >= 0; i--) {
      absencePeriod = absencePeriods.get(i);
      absenceEndDate = getLatestDate(absencePeriod.getAbsenceDate(),
        absencePeriod.getPeriodEndDate());
      if (!absenceEndDate.isZero()) {
        break;
      }
    }
    return absenceEndDate;
  }

  /**
   * Sorts a set of absencePeriods by absence date.
   *
   * @param unsortedAbsenceList
   * The list of unsorted absencePeriod records.
   *
   * @return A sorted list of absence records.
   */
  protected ArrayList<AbsencePeriod> sortAbsenceByServiceDate(
    final Set<AbsencePeriod> unsortedAbsenceList) {

    final ArrayList<AbsencePeriod> absenceList = new ArrayList<AbsencePeriod>(
      unsortedAbsenceList);

    Collections.sort(absenceList, new Comparator<AbsencePeriod>() {
      public int compare(final AbsencePeriod lhs, AbsencePeriod rhs) {

        return lhs.getPeriodStartDate().compareTo(rhs.getPeriodStartDate());
      }
    });
    return absenceList;
  }  
  
  /**
   * Sorts a set of provider roster line item by start date.
   *
   * @param unsortedAbsenceList
   * The list of unsorted provider roster line item.
   *
   * @return A sorted list of provider roster line item.
   */
  protected List<ProviderRosterLineItem> sortProviderRosterLineItem(
    final Set<ProviderRosterLineItem> unsortedPRLIList) {

    final ArrayList<ProviderRosterLineItem> prliList = new ArrayList<ProviderRosterLineItem>(
      unsortedPRLIList);

    Collections.sort(prliList,
      new Comparator<ProviderRosterLineItem>() {
      public int compare(final ProviderRosterLineItem lhs,
        ProviderRosterLineItem rhs) {

        return lhs.getDateRange().start().compareTo(rhs.getDateRange().start());
      }
    });
    return prliList;
  }

  /**
   * Sorts a set of daily attendance records by service date.
   *
   * @param unsortedDailyAttendance
   * The list of unsorted daily attendance.
   *
   * @return A sorted list of daily attendance.
   */
  protected ArrayList<curam.attendance.impl.DailyAttendance> sortDailyAttendanceByServiceDate(
    final Set<curam.attendance.impl.DailyAttendance> unsortedDailyAttendance) {

    // Sort by position for display
    final ArrayList<curam.attendance.impl.DailyAttendance> dailyAttendanceList = new ArrayList<curam.attendance.impl.DailyAttendance>(
      unsortedDailyAttendance);

    Collections.sort(dailyAttendanceList,
      new Comparator<curam.attendance.impl.DailyAttendance>() {
      public int compare(final curam.attendance.impl.DailyAttendance lhs,
        curam.attendance.impl.DailyAttendance rhs) {

        return lhs.getServiceDate().compareTo(rhs.getServiceDate());
      }
    });
    return dailyAttendanceList;
  }
  
  // END, CR00314944
  
  // BEGIN, CR00380597, GA
  /**
   * Sorts a set of Service Authorization line item by end date.
   *
   * @param unsortedList
   * The list of unsorted Service Authorization line item.
   *
   * @return A sorted list of Service Authorization line item.
   */
  protected List<ServiceAuthorizationLineItem> sortServiceAuthorizationLineItem(
    final Set<ServiceAuthorizationLineItem> unsortedList) {

    final ArrayList<ServiceAuthorizationLineItem> SALIList = new ArrayList<ServiceAuthorizationLineItem>(
      unsortedList);

    Collections.sort(SALIList, new Comparator<ServiceAuthorizationLineItem>() {
      public int compare(final ServiceAuthorizationLineItem lhs,
        ServiceAuthorizationLineItem rhs) {

        return rhs.getDateRange().end().compareTo(lhs.getDateRange().end());
      }
    });
    return SALIList;
  }
  // END, CR00380597
  
}
