/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.sl.impl;


import com.google.inject.Inject;

import curam.codetable.ASSOCIATEDTYPE;
import curam.codetable.PLANITEMTYPE;
import curam.codetable.impl.LOCALEEntry;
import curam.cpm.sl.entity.fact.ServiceOfferingFactory;
import curam.cpm.sl.entity.intf.ServiceOffering;
import curam.cpm.sl.entity.struct.ServiceOfferingDtls;
import curam.cpm.sl.entity.struct.ServiceOfferingKey;
import curam.message.BPOPLANITEM;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.fact.PlanItemFactory;
import curam.serviceplans.sl.intf.PlanItem;
import curam.serviceplans.sl.struct.PlanItemKey;
import curam.serviceplans.sl.struct.ReadPlanItemDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;


/**
 * This process class provides the functionality for the Provider Service Plan
 * service layer.
 *
 */

public abstract class ProviderPlanItem extends curam.providerserviceplan.sl.base.ProviderPlanItem {

  // BEGIN, CR00237116, MR
  /**
   * Reference to localizable text handler DAO.
   */
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Constructor for the class.
   */
  protected ProviderPlanItem() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // __________________________________________________________________________
  /**
   * Reads provider plan item details based on the plan item key.
   *
   * @returns Plan item details.
   *
   * @param key
   * Contains plan item ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public ReadPlanItemDetails readProviderPlanItem(final PlanItemKey key)
    throws AppException, InformationalException {
    // END, CR00237116
    // read the plan item details
    curam.serviceplans.sl.entity.intf.PlanItem objPlanItem = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    ReadPlanItemDetails readPlanItemDetails = new ReadPlanItemDetails();
    ServiceOffering serviceOfferingobj = ServiceOfferingFactory.newInstance();
    ServiceOfferingDtls serviceOfferingDetails = new ServiceOfferingDtls();
    ServiceOfferingKey serviceOfferingKey = new ServiceOfferingKey();

    readPlanItemDetails.dtls = objPlanItem.read(key.key);
    // BEGIN, CR00161962, LJ
    final PlanItem planItemObj = PlanItemFactory.newInstance();

    // Read the task information
    readPlanItemDetails.taskConfigDtls = planItemObj.readTaskConfigurationDetails(
      key);
    // END, CR00161962
    // Read Service offering ID only if it is a Plan Item of type Service
    if (readPlanItemDetails.dtls.typeCode.equalsIgnoreCase(
      PLANITEMTYPE.SERVICEPLANITEM)) {

      try {
        // assign the service offering ID from the related details
        serviceOfferingKey.serviceOfferingID = readPlanItemDetails.dtls.associatedID;

        // Get the service offering Name and other details
        serviceOfferingDetails = serviceOfferingobj.read(serviceOfferingKey);
        // BEGIN, CR00399308, KRK
      } catch (RecordNotFoundException recordNotFoundException) {        
        if (Trace.atLeast(Trace.kTraceVerbose)) { 
          Trace.kTopLevelLogger.info(
            Trace.exceptionStackTraceAsString(recordNotFoundException));
        }     
        // END, CR00399308
      }       
      // BEGIN, CR00237116, MR
      if (0 != serviceOfferingDetails.nameTextID) {
        LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          serviceOfferingDetails.nameTextID);

        serviceOfferingDetails.name = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
      // END, CR00237116
      // Get the service offering name into return struct
      readPlanItemDetails.associatedItemName = serviceOfferingDetails.name;

    }
    return readPlanItemDetails;
  }

  // __________________________________________________________________________
  /**
   * This method is used to validate the
   * plan item details
   *
   * @param PlanItemDtls contains plan item details
   *
   * @throws AppException
   * @throws InformationalException
   */
  // This method is written to Validate for Non Service and Custom Service Plan
  // item types
  // These validations have to be moved to entity validation class once these
  // are made unique for all types of plan items
  public void validateForNonServiceAndCustomService(PlanItemDtls details)
    throws AppException, InformationalException {

    if ((!details.typeCode.equals(PLANITEMTYPE.SERVICEPLANITEM)
      && !details.typeCode.equals(PLANITEMTYPE.CUSTOMSERVICEPLANITEM))
        && details.associatedType.equals(ASSOCIATEDTYPE.SERVICE)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_OTHER_PLAN_ITEM_SERVICE_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

    if ((!details.typeCode.equals(PLANITEMTYPE.SERVICEPLANITEM)
      && !details.typeCode.equals(PLANITEMTYPE.CUSTOMSERVICEPLANITEM))
        && details.associatedID != 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_OTHER_PLAN_ITEM_SERVICE_OFFERING_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

  }

}
