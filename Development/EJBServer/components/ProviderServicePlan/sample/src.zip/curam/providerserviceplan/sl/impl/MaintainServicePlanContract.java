/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.providerserviceplan.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.codetable.SUBGOALNAME;
import curam.codetable.SUBGOALTYPE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.intf.CaseHeader;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.ConcernRoleKey;
import curam.cpm.sl.entity.fact.ServiceOfferingFactory;
import curam.cpm.sl.entity.intf.ServiceOffering;
import curam.cpm.sl.entity.struct.ServiceOfferingKey;
import curam.provider.impl.ProviderTypeNameEntry;
import curam.providerserviceplan.sl.entity.fact.ProviderPlannedItemLinkFactory;
import curam.providerserviceplan.sl.entity.intf.ProviderPlannedItemLink;
import curam.providerserviceplan.sl.entity.struct.ProviderPlannedItemLinkDtls;
import curam.providerserviceplan.sl.struct.PlannedItemDetailsForContract;
import curam.providerserviceplan.sl.struct.PlannedSubGoalDetailsForContract;
import curam.providerserviceplan.sl.struct.ServicePlanContractDetails;
import curam.serviceplans.facade.struct.PlannedItemIDKey;
import curam.serviceplans.facade.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.intf.PlannedSubGoal;
import curam.serviceplans.sl.entity.struct.PlannedGoalIDandRecordStatusKey;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemDtlsList;
import curam.serviceplans.sl.entity.struct.PlannedItemIDAndContractTextDetailsList;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalIDAndConcernRoleKey;
import curam.serviceplans.sl.struct.CompleteContractDetails;
import curam.serviceplans.sl.struct.ServicePlanContractKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.type.CodeTable;
import curam.util.type.FrequencyPattern;


/**
 * This service layer class interacts with the entity layer classes to perform
 * various operations to maintain the service plan contract details.
 *
 */
public class MaintainServicePlanContract extends curam.providerserviceplan.sl.base.MaintainServicePlanContract {

  // ___________________________________________________________________________
  /**
   * Reads the complete details of the contract record including goal, sub
   * goal and plan item details.
   *
   * @param spContractKey Identifies the Service Plan Contract record to be read.
   *
   * @return Complete Contract details.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ServicePlanContractDetails readCompleteContract(
    ServicePlanContractKey servPlanContractKey)
    throws AppException, InformationalException {
    // Manipulation Variables
    ServicePlanContractDetails servicePlanContractDetails = new ServicePlanContractDetails();
    // ServicePlanContract business object
    curam.serviceplans.sl.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.fact.ServicePlanContractFactory.newInstance();
    curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractEntObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();
    curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    CompleteContractDetails completeContractDetails = servicePlanContractObj.readCompleteContract(
      servPlanContractKey);
    // Set the case id
    curam.serviceplans.sl.entity.struct.ServicePlanContractKey servicePlanContractKey = new curam.serviceplans.sl.entity.struct.ServicePlanContractKey();

    servicePlanContractKey.servicePlanContractID = servPlanContractKey.servicePlanContractID;

    servicePlanContractDetails.caseID = servicePlanContractEntObj.readCaseIDDateClientNameAndSSN(servicePlanContractKey).caseID;
    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = servicePlanContractDetails.caseID;
    servicePlanContractDetails.plannedGoalID = plannedGoalObj.readIDByCaseID(servicePlanDeliveryKey.servicePlanDeliveryKey.key).plannedGoalID;

    // Populate the basic service plan contract information
    populateBasicServicePlanContractDetails(servicePlanContractDetails,
      completeContractDetails);

    // Populate the service plan signatories list
    servicePlanContractDetails.servicePlanSignatories.assign(
      completeContractDetails.servicePlanSignatories);

    // Populate the List of Sub Goals of a given goal.
    getPlannedSubGoalListForGoal(servicePlanContractDetails);

    return servicePlanContractDetails;
  }

  // ___________________________________________________________________________
  /**
   * Gets the list of planned sub goals for the given planned goal
   *
   * @param ServicePlanContractDetailsthe Service Plan Contract details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected void getPlannedSubGoalListForGoal
    (ServicePlanContractDetails servicePlanContractDetails)
    throws AppException, InformationalException {

    curam.serviceplans.sl.entity.struct.PlannedSubGoalDetailsForContractList plannedSubGoalDetailsForContractList = new curam.serviceplans.sl.entity.struct.PlannedSubGoalDetailsForContractList();
    PlannedGoalIDandRecordStatusKey plannedGoalIDandRecordStatusKey = new PlannedGoalIDandRecordStatusKey();
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = servicePlanContractDetails.caseID;

    plannedGoalIDandRecordStatusKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    plannedGoalIDandRecordStatusKey.plannedGoalID = servicePlanContractDetails.plannedGoalID;
    plannedGoalIDandRecordStatusKey.recordStatus = RECORDSTATUS.DEFAULTCODE;
    PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();

    plannedSubGoalDetailsForContractList = plannedSubGoalObj.searchSubGoalDetailsByPlannedGoalID(
      plannedGoalIDandRecordStatusKey);

    for (int i = 0; i < plannedSubGoalDetailsForContractList.dtls.size(); i++) {

      // populate the sub goal details for contract
      PlannedSubGoalDetailsForContract plannedSubGoalDetailsForContract = new PlannedSubGoalDetailsForContract();

      plannedSubGoalDetailsForContract.subGoalID = plannedSubGoalDetailsForContractList.dtls.item(i).plannedSubGoalID;
      plannedSubGoalDetailsForContract.subGoalName = CodeTable.getOneItem(
        SUBGOALNAME.TABLENAME,
        plannedSubGoalDetailsForContractList.dtls.item(i).subGoalName);
      plannedSubGoalDetailsForContract.subGoalTypeCode = plannedSubGoalDetailsForContractList.dtls.item(i).subGoalType;
      plannedSubGoalDetailsForContract.subGoalTypeName = CodeTable.getOneItem(
        SUBGOALTYPE.TABLENAME, plannedSubGoalDetailsForContract.subGoalTypeCode);
      plannedSubGoalDetailsForContract.subGoalContractText = plannedSubGoalDetailsForContractList.dtls.item(i).subGoalContractText;

      // Populate Planned Item Details for contract using the Planned Item
      // Summary list
      getPlannedItemListForSubGoal(plannedSubGoalDetailsForContract);

      // Check to see what TYPE the sub is and assign to appropriate
      // list
      assignSubGoalToCorrespondingTypeList(servicePlanContractDetails,
        plannedSubGoalDetailsForContract);
    }
  }

  // ___________________________________________________________________________
  /**
   * Check to see what TYPE the sub is and assign to appropriate Type list
   * @param ServicePlanContractDetailsthe Service Plan Contract details.
   *
   * @param plannedSubGoalDetailsForContract Sub Goal details
   */
  protected void assignSubGoalToCorrespondingTypeList
    (ServicePlanContractDetails servicePlanContractDetails,
    PlannedSubGoalDetailsForContract plannedSubGoalDetailsForContract) {

    // Check to see what TYPE the sub is and assign to appropriate
    // list
    if (plannedSubGoalDetailsForContract.subGoalTypeCode.equals(
      SUBGOALTYPE.OBJECTIVE)) {
      // Add SubGoal record to list of subGoals returned for goal
      servicePlanContractDetails.objectivePlannedSubGoalDetails.plannedSubGoalDetails.addRef(
        plannedSubGoalDetailsForContract);
    } else if (plannedSubGoalDetailsForContract.subGoalTypeCode.equals(
      SUBGOALTYPE.BARRIER)) {
      // Add SubGoal record to list of subGoals returned for goal
      servicePlanContractDetails.barrierPlannedSubGoalDetails.plannedSubGoalDetails.addRef(
        plannedSubGoalDetailsForContract);
    } else if (plannedSubGoalDetailsForContract.subGoalTypeCode.equals(
      SUBGOALTYPE.NEED)) {
      // Add SubGoal record to list of subGoals returned for goal
      servicePlanContractDetails.needPlannedSubGoalDetails.plannedSubGoalDetails.addRef(
        plannedSubGoalDetailsForContract);
    } else {
      // Add SubGoal record to list of subGoals returned for goal
      servicePlanContractDetails.otherPlannedSubGoalDetails.plannedSubGoalDetails.addRef(
        plannedSubGoalDetailsForContract);
    }
  }

  // ___________________________________________________________________________
  /**
   * Gets the list of planned items of the planned sub goal.
   *
   * @param PlannedSubGoalDetailsForContract planned sub goal details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected void getPlannedItemListForSubGoal
    (PlannedSubGoalDetailsForContract plannedSubGoalDetailsForContract)
    throws AppException, InformationalException {

    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    PlannedItemDtlsList plannedItemDtlsList = new PlannedItemDtlsList();
    curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();

    plannedSubGoalKey.plannedSubGoalID = plannedSubGoalDetailsForContract.subGoalID;

    plannedItemDtlsList = plannedItemObj.searchByPlannedSubGoalID(
      plannedSubGoalKey);

    for (int i = 0; i < plannedItemDtlsList.dtls.size(); i++) {

      // Populate Planned Item Details for contract using the Planned Item
      // Summary list
      // for every planned item id
      // 1. Read the CEF planned item details
      PlannedItemDetailsForContract plannedItemDetailsForContract = new PlannedItemDetailsForContract();

      plannedItemDetailsForContract.plannedItemID = plannedItemDtlsList.dtls.item(i).plannedItemID;
      plannedItemDetailsForContract.plannedItemName = plannedItemDtlsList.dtls.item(i).name;
      plannedItemDetailsForContract.plannedItemActualStartDate = plannedItemDtlsList.dtls.item(i).actualStartDate;
      plannedItemDetailsForContract.plannedItemActualEndDate = plannedItemDtlsList.dtls.item(i).actualEndDate;
      plannedItemDetailsForContract.plannedItemExpectedStartDate = plannedItemDtlsList.dtls.item(i).expectedStartDate;
      plannedItemDetailsForContract.plannedItemExpectedEndDate = plannedItemDtlsList.dtls.item(i).expectedEndDate;
      plannedItemDetailsForContract.comments = plannedItemDtlsList.dtls.item(i).comments;
      plannedItemDetailsForContract.subGoalTypeCode = plannedSubGoalDetailsForContract.subGoalTypeCode;
      plannedItemDetailsForContract.planItemContractText = getPlanItemContractText(
        plannedItemDtlsList.dtls.item(i));

      // 2. Read the Provider planned item details
      populateCustomPlannedItemDetails(plannedItemDetailsForContract);

      if (plannedItemDetailsForContract.displayCustomDetails) {
        plannedItemDetailsForContract.frequency = plannedItemDtlsList.dtls.item(i).frequency;
        plannedItemDetailsForContract.frequencyName = populateFrequencyName(
          plannedItemDetailsForContract.frequency);
        plannedItemDetailsForContract.authorizedUnits = plannedItemDtlsList.dtls.item(i).authorizedUnits;
        plannedItemDetailsForContract.rateAuthorized = plannedItemDtlsList.dtls.item(i).rateAuthorized;
        plannedItemDetailsForContract.totalUnitsAuthorized = plannedItemDtlsList.dtls.item(i).totalUnitsAuthorized;
      }
      plannedSubGoalDetailsForContract.plannedItemDetails.addRef(
        plannedItemDetailsForContract);
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to set the frequency name string based on the given frequency.
   *
   * @param String represents the frequency.
   */
  protected String populateFrequencyName(String frequency) {

    String frequencyName = "";

    if (frequency != null && frequency.length() > 0) {
      // BEGIN, CR00136863, ANK
      frequencyName = new FrequencyPattern(frequency).toHumanReadableString();
      // END, CR00136863
    }

    return frequencyName;
  }

  // ___________________________________________________________________________
  /**
   * Populates the Custom Planned Item details.
   *
   * @param PlannedItemDetailsForContract planned item Details for contract.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected void populateCustomPlannedItemDetails
    (PlannedItemDetailsForContract plannedItemDetailsForContract)
    throws AppException, InformationalException {

    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();
    PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemDetailsForContract.plannedItemID;
    ProviderPlannedItemLinkDtls providerPlannedItemLinkDtls = new ProviderPlannedItemLinkDtls();

    boolean foundProviderPlannedItemLink = true;

    try {
      providerPlannedItemLinkDtls = providerPlannedItemLinkObj.readByPlannedItemID(
        plannedItemIDKey.plannedItemIDKey.plannedItemIDKey);
    } catch (RecordNotFoundException e) {
      foundProviderPlannedItemLink = false;
    }
    if (foundProviderPlannedItemLink) {
      plannedItemDetailsForContract.displayCustomDetails = true;
      plannedItemDetailsForContract.serviceOfferingName = populateServiceOfferingName(
        providerPlannedItemLinkDtls.serviceOfferingID);
      plannedItemDetailsForContract.providerName = populateProviderName(
        providerPlannedItemLinkDtls.providerConcernRoleID);
      plannedItemDetailsForContract.providerTypeName = CodeTable.getOneItem(
        ProviderTypeNameEntry.TABLENAME,
        providerPlannedItemLinkDtls.providerTypeCode);
    }

  }

  // ___________________________________________________________________________
  /**
   * Populates the Plan Item contract text.
   *
   * @param PlannedItemDtls Plan Item details to read the contract text.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected String getPlanItemContractText(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {
    StringBuffer planItemContractText = new StringBuffer();

    PlannedItemIDAndContractTextDetailsList plannedItemIDAndContractTextDetails;

    PlannedSubGoalIDAndConcernRoleKey plannedSubGoalIDAndConcernRoleKey = new PlannedSubGoalIDAndConcernRoleKey();

    plannedSubGoalIDAndConcernRoleKey.concernRoleID = plannedItemDtls.concerningID;
    plannedSubGoalIDAndConcernRoleKey.plannedSubGoalID = plannedItemDtls.plannedSubGoalID;
    curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // BEGIN, CR00291811, GP
    plannedItemIDAndContractTextDetails = plannedItemObj.searchContractTextByPlannedSubGoalAndParticipant(
      plannedSubGoalIDAndConcernRoleKey);
    // END, CR00291811

    for (int j = 0; j < plannedItemIDAndContractTextDetails.dtls.size(); j++) {

      planItemContractText.append(
        plannedItemIDAndContractTextDetails.dtls.item(j).planItemContractText);
    }

    return planItemContractText.toString();
  }

  // ___________________________________________________________________________
  /**
   * Populates the basic service plan contract details.
   *
   * @param servicePlanContractDetails service plan contract details.
   */
  protected void populateBasicServicePlanContractDetails
    (ServicePlanContractDetails servicePlanContractDetails,
    CompleteContractDetails completeContractDetails) {

    servicePlanContractDetails.caseReference = completeContractDetails.caseReference;
    servicePlanContractDetails.clientName = completeContractDetails.clientName;
    servicePlanContractDetails.contractDate = completeContractDetails.contractDate;
    servicePlanContractDetails.ssnNumber = completeContractDetails.ssnNumber;
    servicePlanContractDetails.plannedGoalName = completeContractDetails.plannedGoalName;
    servicePlanContractDetails.goalContractText = completeContractDetails.goalContractText;

  }

  // _________________________________________________________________________
  /**
   * Populates the provider Name into the view struct
   *
   * @throw AppException, InformationalException
   *
   * @param viewProviderPlannedItemDetails - details of provider planned item
   */
  protected String populateProviderName
    (long providerConcernRoleID)
    throws AppException, InformationalException {

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    String providerName = "";

    if (providerConcernRoleID != 0) {
      // Get provider the provider name
      try {
        concernRoleKey.concernRoleID = providerConcernRoleID;
        providerName = ConcernRoleFactory.newInstance().read(concernRoleKey).concernRoleName;

      } catch (RecordNotFoundException rnfe) {// Do not populate the provider name if there are no records found
      }
    }

    return providerName;
  }

  // _________________________________________________________________________
  /**
   * Populates the Service Offering Name into the view struct
   *
   * @throw AppException, InformationalException
   *
   * @param viewProviderPlannedItemDetails - details of provider planned item
   */
  protected String populateServiceOfferingName(
    long serviceOfferingID)
    throws AppException, InformationalException {

    // ServiceOffering entity declaration
    ServiceOffering serviceOfferingEntObj = ServiceOfferingFactory.newInstance();
    ServiceOfferingKey serviceOfferingKey = new ServiceOfferingKey();

    String serviceOfferingName = "";

    if (serviceOfferingID != 0) {
      // Get the service offering name
      try {
        serviceOfferingKey.serviceOfferingID = serviceOfferingID;

        serviceOfferingName = serviceOfferingEntObj.read(serviceOfferingKey).name;

      } catch (RecordNotFoundException rnfe) {// Do not populate the service offering name if there are no records found
      }
    }
    return serviceOfferingName;
  }
}
