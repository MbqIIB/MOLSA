/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.sl.impl;


import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.ATTENDANCE;
import curam.codetable.OUTCOMEACHIEVED;
import curam.codetable.PLANITEMNAME;
import curam.codetable.PLANITEMTYPE;
import curam.codetable.PLANNEDITEMSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SENSITIVITY;
import curam.codetable.impl.LOCALEEntry;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.DailyAttendanceFactory;
import curam.core.sl.entity.struct.DailyAttendanceDtls;
import curam.core.sl.entity.struct.DailyAttendanceKey;
import curam.cpm.facade.struct.SALIModificationReason;
import curam.cpm.sl.entity.fact.ServiceOfferingFactory;
import curam.cpm.sl.entity.intf.ServiceOffering;
import curam.cpm.sl.entity.struct.ServiceOfferingKey;
import curam.cpm.sl.struct.ServiceOfferingDetails;
import curam.financial.ServiceAuthorizationLineItemDerivedStatus;
import curam.financial.impl.ServiceAuthorizationLineItemModificationReasonEntry;
import curam.message.BPOBASELINE;
import curam.message.BPOCLIENTPARTICIPATION;
import curam.message.BPOPROVIDERPLANNEDITEM;
import curam.message.ENTDAILYATTENDANCE;
import curam.providerserviceplan.sl.entity.fact.ProviderPlannedItemLinkFactory;
import curam.providerserviceplan.sl.entity.intf.ProviderPlannedItemLink;
import curam.providerserviceplan.sl.entity.struct.ProviderPlannedItemLinkDtls;
import curam.serviceauthorization.impl.ServiceAuthorization;
import curam.serviceauthorization.impl.ServiceAuthorizationDAO;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItem;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItemDAO;
import curam.serviceplans.facade.struct.ModifyPlanItemReturnStruct;
import curam.serviceplans.facade.struct.ReadPlanItemDetails;
import curam.serviceplans.facade.struct.ViewPlannedItemDetailsStruct;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplateFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplateMilestoneFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanGroupFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory;
import curam.serviceplans.sl.entity.fact.PlannedGoalFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanGroup;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem;
import curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.struct.GoalIDDetails;
import curam.serviceplans.sl.entity.struct.MilestoneTemplateDetails;
import curam.serviceplans.sl.entity.struct.MilestoneTemplateDetailsList;
import curam.serviceplans.sl.entity.struct.PlanItemAndTemplatePlanItemDetails;
import curam.serviceplans.sl.entity.struct.PlanItemAndTemplatePlanItemDetailsList;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanItemTypeCodeDetails;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupDetailsList;
import curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalDtls;
import curam.serviceplans.sl.entity.struct.PlannedGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDtls;
import curam.serviceplans.sl.entity.struct.RequiresApprovalStruct;
import curam.serviceplans.sl.entity.struct.TemplateSubGoalDetailsList;
import curam.serviceplans.sl.fact.AbsenceFactory;
import curam.serviceplans.sl.fact.ClientParticipationFactory;
import curam.serviceplans.sl.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.serviceplans.sl.intf.Absence;
import curam.serviceplans.sl.intf.ServicePlanDelivery;
import curam.serviceplans.sl.struct.CreatePlannedItemDetailsStruct;
import curam.serviceplans.sl.struct.ModifyPlannedItemDetailsStruct;
import curam.serviceplans.sl.struct.PlanItemKey;
import curam.serviceplans.sl.struct.PlanTemplateKey;
import curam.serviceplans.sl.struct.PlannedItemAbsenceDetails;
import curam.serviceplans.sl.struct.PlannedItemAbsenceDetailsList;
import curam.serviceplans.sl.struct.PlannedItemDailyAttendanceDetails;
import curam.serviceplans.sl.struct.PlannedItemDetailsStruct;
import curam.serviceplans.sl.struct.PlannedItemIDAndNameDetailsList;
import curam.serviceplans.sl.struct.PlannedItemIDKey;
import curam.serviceplans.sl.struct.ServicePlanAndParticipantDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanParticipantDetailsList;
import curam.serviceplans.sl.struct.ViewPlannedItemDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.FrequencyPattern;
import curam.util.type.Money;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.cpm.util.impl.FrequencyPatternUtil;
import curam.cpm.util.impl.FrequencyPatternUtilImpl;


/**
 * This service layer class interacts with the service layer of core to perform
 * various operations on the plannedItem entity
 *
 */

public abstract class ProviderPlannedItem extends curam.providerserviceplan.sl.base.ProviderPlannedItem {

  // BEGIN, CR00237116, MR
  /**
   * Reference to localizable text handler DAO.
   */
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;
  // END, CR00237116
  /**
   * Injecting the Data Access Object for ServiceAuthorizationDAO class.
   */
  @Inject
  protected ServiceAuthorizationDAO serviceAuthorizationDAO;

  /**
   * Injecting the Data Access Object for ServiceAuthorizationLineItemDAO
   * class.
   */
  @Inject
  protected ServiceAuthorizationLineItemDAO serviceAuthorizationLineItemDAO;

  /**
   * Default constructor.
   */
  public ProviderPlannedItem() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  // ___________________________________________________________________________
  // BEGIN, CR00237116, MR
  /**
   * This method is used to create a Provider Service Plan Item.
   *
   * @param createPlannedItemDetailsStruct
   * details of the planned item to be created.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void createPlannedItem(
    final CreatePlannedItemDetailsStruct createPlannedItemDetailsStruct)
    throws AppException, InformationalException {
    // END, CR00237116
    curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // BEGIN, CR00120774, ANK
    // Calculate Total Units authorized details
    // BEGIN, CR00273612, SSK
    // BEGIN, CR00280918, SSK
    calculateTotalUnitsAuthorized(
      createPlannedItemDetailsStruct.plannedItemDtls);
    // END, CR00280918
    // END, CR00273612
    // END, CR00120774

    // BEGIN, CR00237116, MR
    final PlannedItemDetailsStruct plannedItemDetailsStruct = new PlannedItemDetailsStruct();

    plannedItemDetailsStruct.assign(createPlannedItemDetailsStruct);
    plannedItemObj.createBasicPlanItemDetails(plannedItemDetailsStruct);
    createPlannedItemDetailsStruct.assign(plannedItemDetailsStruct);
    // END, CR00237116
  }

  // ___________________________________________________________________________
  /**
   * This method is used to modify a Provider Service Plan Plan Item.
   *
   * @param modifyPlannedItemDetailsStruct
   * details of the planned item to be modified.
   *
   * @throws AppException
   * , InformationalException
   */

  public ModifyPlanItemReturnStruct modifyPlannedItem(
    ModifyPlannedItemDetailsStruct modifyPlannedItemDetailsStruct)
    throws AppException, InformationalException {

    PlannedItemDtls modifyPlannedItemDtls = modifyPlannedItemDetailsStruct.plannedItemDtls;

    curam.serviceplans.sl.entity.intf.PlannedItem plannedItemEntObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = modifyPlannedItemDtls.plannedItemID;

    PlannedItemDtls plannedItemDtls = plannedItemEntObj.read(plannedItemKey);

    curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    ModifyPlanItemReturnStruct modifyPlanItemReturnStruct = new ModifyPlanItemReturnStruct();

    curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    // set back the fields, which could come in as null,
    // and should not be modified by the user.

    // BEGIN, CR00124561, MC
    if (!modifyPlannedItemDtls.actualEndDate.equals(Date.kZeroDate)) {
      if (modifyPlannedItemDtls.actualStartDate.equals(Date.kZeroDate)) {
        if (modifyPlannedItemDtls.expectedStartDate.after(Date.getCurrentDate())) {
          modifyPlannedItemDtls.actualStartDate = Date.getCurrentDate();
        } else {
          modifyPlannedItemDtls.actualStartDate = modifyPlannedItemDtls.expectedStartDate;
        }
      }
    }
    // END, CR00124561

    // BEGIN, CR00120774, ANK
    // Calculate Total Units authorized details
    // BEGIN, CR00273612, SSK
    // BEGIN, CR00280918, SSK
    calculateTotalUnitsAuthorized(
      modifyPlannedItemDetailsStruct.plannedItemDtls);
    // END, CR00280918
    // END, CR00273612
    // END, CR00120774

    plannedItemObj.modifyBasicPlanItem(modifyPlannedItemDetailsStruct);

    modifyPlanItemReturnStruct.plannedSubGoalID = modifyPlannedItemDtls.plannedSubGoalID;
    plannedItemIDKey.plannedItemID = modifyPlannedItemDtls.plannedItemID;
    modifyPlanItemReturnStruct.caseID = plannedItemEntObj.readCaseIDByPlannedItemID(plannedItemIDKey).caseID;

    ProviderPlannedItemLink providerplannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    ProviderPlannedItemLinkDtls providerPlannedItemLinkDtls = null;

    try {
      providerPlannedItemLinkDtls = providerplannedItemLinkObj.readByPlannedItemID(
        plannedItemIDKey);
    } catch (RecordNotFoundException ex) {// Do nothing if there are no matching records found
    }

    if (providerPlannedItemLinkDtls != null) {
      long serviceAuthID = providerPlannedItemLinkDtls.serviceAuthorizationID;

      createSALI(modifyPlannedItemDetailsStruct.plannedItemDtls);

      ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.get(
        serviceAuthID);

      Set<ServiceAuthorizationLineItem> serviceAuthorizationLineItems = serviceAuthorizationLineItemDAO.searchByServiceAuthorization(
        serviceAuthorization);
      
      // BEGIN, CR00273450, ASN  
      SALIModificationReason modificationReason = new SALIModificationReason();

      modificationReason.modificationReason = ServiceAuthorizationLineItemModificationReasonEntry.SERVICEPLANUPDATED.getCode();

      if (modifyPlannedItemDtls.frequency.length() == 0) {

        if (!plannedItemDtls.expectedStartDate.equals(
          modifyPlannedItemDtls.expectedStartDate)
            || !plannedItemDtls.expectedEndDate.equals(
              modifyPlannedItemDtls.expectedEndDate)
              || plannedItemDtls.rateAuthorized
                != modifyPlannedItemDtls.rateAuthorized
                || plannedItemDtls.authorizedUnits
                  != modifyPlannedItemDtls.authorizedUnits) {

          for (ServiceAuthorizationLineItem
            serviceAuthorizationLineItem :
            serviceAuthorizationLineItems) {

            DateRange dateRange = new DateRange(
              modifyPlannedItemDtls.expectedStartDate,
              modifyPlannedItemDtls.expectedEndDate);

            serviceAuthorizationLineItem.setDateRange(dateRange);
            serviceAuthorizationLineItem.setUnitsAuthorized(
              modifyPlannedItemDtls.authorizedUnits);
            Money rateAuthorized = new Money(
              modifyPlannedItemDtls.rateAuthorized);

            serviceAuthorizationLineItem.setUnitAmount(rateAuthorized);

            if (rateAuthorized.isPositive()) {
              serviceAuthorizationLineItem.setUnitAmountFixed(true);
            } else {
              serviceAuthorizationLineItem.setUnitAmountFixed(false);
            }

          }
          
          serviceAuthorizationLineItemDAO.newInstance().modifyServiceAuthorizationLineItems(
            serviceAuthorizationLineItems, modificationReason);
        }
      } else {

        if (plannedItemDtls.rateAuthorized
          != modifyPlannedItemDtls.rateAuthorized
            || plannedItemDtls.authorizedUnits
              != modifyPlannedItemDtls.authorizedUnits) {

          for (ServiceAuthorizationLineItem
            serviceAuthorizationLineItem :
            serviceAuthorizationLineItems) {

            serviceAuthorizationLineItem.setUnitsAuthorized(
              modifyPlannedItemDtls.authorizedUnits);
            Money rateAuthorized = new Money(
              modifyPlannedItemDtls.rateAuthorized);

            serviceAuthorizationLineItem.setUnitAmount(rateAuthorized);

            if (rateAuthorized.isPositive()) {
              serviceAuthorizationLineItem.setUnitAmountFixed(true);
            } else {
              serviceAuthorizationLineItem.setUnitAmountFixed(false);
            }
          }
          serviceAuthorizationLineItemDAO.newInstance().modifyServiceAuthorizationLineItems(
            serviceAuthorizationLineItems, modificationReason);

        }
      }
      // END, CR00273450


      // remove related service authorization
      if (modifyPlannedItemDtls.outcomeAchieved.equals(
        OUTCOMEACHIEVED.CANCELLED)) {

        curam.serviceplans.sl.struct.PlannedItemIDKey key = new PlannedItemIDKey();

        key.plannedItemIDKey.plannedItemID = plannedItemIDKey.plannedItemID;
        cancelServiceAuthorizationLineItem(key);
      }

      // Remove related service authorization line items if the actual
      // end date is manually set by the user
      if (!modifyPlannedItemDtls.actualEndDate.equals(Date.kZeroDate)) {

        if (modifyPlannedItemDtls.frequency.length() == 0) {

          for (ServiceAuthorizationLineItem
            serviceAuthorizationLineItem :
            serviceAuthorizationLineItems) {

            // set the version number to any value as this is an
            // unused field in
            // the close operation
            int versionNo = CuramConst.gkZero;

            serviceAuthorizationLineItem.close(
              modifyPlannedItemDtls.actualEndDate, versionNo);

          }

        } else {

          for (ServiceAuthorizationLineItem
            serviceAuthorizationLineItem :
            serviceAuthorizationLineItems) {

            DateRange dateRange = serviceAuthorizationLineItem.getDateRange();

            // BEGIN, CR00124561, MC
            if (serviceAuthorizationLineItem.getDerivedStatus().equals(
              ServiceAuthorizationLineItemDerivedStatus.OPEN)
                && dateRange.startsAfter(modifyPlannedItemDtls.actualEndDate)) {

              serviceAuthorizationLineItem.cancelServiceAuthorizationLineItem();

            }
            // END, CR00124561
          }
        }
      }
    }
    return modifyPlanItemReturnStruct;

  }

  // ___________________________________________________________________________
  /**
   * This method is used to view the planned item details
   *
   * @param plannedItemIDKey
   * unique id of the planned item
   *
   * @return The planned item details
   *
   * @throws AppException
   * ,InformationalException
   */
  public ViewPlannedItemDetails readPlannedItemDetails(PlannedItemIDKey key)
    throws AppException, InformationalException {

    curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    ViewPlannedItemDetailsStruct viewPlannedItemDetailsStruct = new ViewPlannedItemDetailsStruct();

    try {
      viewPlannedItemDetailsStruct.plannedItemDetails = plannedItemObj.readPlannedItemDetails(
        key);
    } catch (RecordNotFoundException e) {
      throw new AppException(
        BPOBASELINE.BASELINE_PLAN_ITEM_RV_PLANNED_ITEM_DELETED);
    }
    ViewPlannedItemDetails viewPlannedItemDetails = new ViewPlannedItemDetails();

    viewPlannedItemDetails.assign(
      viewPlannedItemDetailsStruct.plannedItemDetails);

    return viewPlannedItemDetails;

  }

  // BEGIN CR00109139, PN
  // ___________________________________________________________________________
  // BEGIN, CR00237116, MR
  /**
   * Method used for getting service offering details for selected service
   * planned Item.
   *
   * @param key
   * Contains Plan Item ID.
   *
   * @return Service Offering Details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ServiceOfferingDetails getServiceOfferingDetailsForPlannedItem(
    final PlanItemKey key) throws AppException, InformationalException {
    // END, CR00237116
    curam.serviceplans.sl.entity.intf.PlanItem objPlanItem = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    ReadPlanItemDetails readPlanItemDetails = new ReadPlanItemDetails();
    // Return object having service offering details
    ServiceOfferingDetails serviceOfferingDetails = new ServiceOfferingDetails();

    // ServiceOffering entity declaration
    ServiceOffering serviceOfferingEntObj = ServiceOfferingFactory.newInstance();
    ServiceOfferingKey serviceOfferingKey = new ServiceOfferingKey();

    readPlanItemDetails.details.dtls = objPlanItem.read(key.key);

    // Get the service offering key into key struct
    serviceOfferingKey.serviceOfferingID = readPlanItemDetails.details.dtls.associatedID;

    try {
      // Call entity method for getting service offering details
      serviceOfferingDetails.serviceOfferingDtls = serviceOfferingEntObj.read(
        serviceOfferingKey);
    } catch (RecordNotFoundException rnfe) {// Do nothing if there are no matching records found
    }

    // BEGIN, CR00237116, MR
    if (0 != serviceOfferingDetails.serviceOfferingDtls.nameTextID) {
      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        serviceOfferingDetails.serviceOfferingDtls.nameTextID);

      serviceOfferingDetails.serviceOfferingDtls.name = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00237116
    return serviceOfferingDetails;

  }

  // END CR00109139

  // ___________________________________________________________________________
  /**
   * This method is used to create Service Authorization Line Items for a
   * planned item.
   *
   * @param plannedItemDtls
   * details of the planned item for which SALI is to be created
   *
   * @throws AppException
   * , InformationalException
   */

  public void createSALI(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {

    PlanItem planItemObj = PlanItemFactory.newInstance();

    curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    planItemKey.planItemID = plannedItemDtls.planItemID;

    RequiresApprovalStruct requiresApproval = planItemObj.readApprovalRequired(
      planItemKey);

    // BEGIN, CR00123078, MC

    ProviderPlannedItemLink plannedItemProviderLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = plannedItemDtls.plannedItemID;

    int noOfRecords = plannedItemProviderLinkObj.getServiceAuthorizationLineItemCount(plannedItemIDKey).noOfRecords;

    // END, CR00123078

    curam.serviceplans.sl.entity.struct.PlannedItemDtls plannedItemEntDtls = new curam.serviceplans.sl.entity.struct.PlannedItemDtls();

    plannedItemEntDtls.assign(plannedItemDtls);

    if (noOfRecords == 0) {
      if (requiresApproval.requiresApproval
        && plannedItemDtls.status.equals(PLANNEDITEMSTATUS.NOTSTARTED)) {
        plannedItemProviderLinkObj.createServiceAuthorizationDetails(
          plannedItemEntDtls);
      }

      if (!requiresApproval.requiresApproval) {
        plannedItemProviderLinkObj.createServiceAuthorizationDetails(
          plannedItemEntDtls);
      }
    }
  }

  // BEGIN, CR00120973, CSH
  // ___________________________________________________________________________
  /**
   * This method creates an absence period record and a link record that
   * contains the association between the absence and the planned item.
   *
   * @param details
   * - The absence and planned item details to be inserted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void createPlanItemAbsence(PlannedItemAbsenceDetails details)
    throws AppException, InformationalException {

    // BEGIN CR00129628, GBA
    if (details.plannedItemID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_ABSENCE_FV_PLANNED_ITEM_MUST_BE_ENTERED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END CR00129628

    // Absence service layer object
    Absence absenceObj = AbsenceFactory.newInstance();

    // BEGIN, CR00120337, CSH
    // Set the planned item key
    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = details.plannedItemID;

    // Set the record status for the new record
    details.dtls.dtls.recordStatus = RECORDSTATUS.NORMAL;

    // Validate the plan item is a valid type
    validatePlanItemTypeForAbsence(plannedItemKey);
    // END, CR00120337

    // Create the absence record
    absenceObj.createPlanItemAbsence(details);
  }

  // ___________________________________________________________________________
  /**
   * This method lists the absence records associated with the specified
   * planned item.
   *
   * @param key
   * - The planned item identifier.
   *
   * @return The list of absence records.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PlannedItemAbsenceDetailsList listPlanItemAbsence(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // Return struct
    PlannedItemAbsenceDetailsList plannedItemAbsenceDetailsList = new PlannedItemAbsenceDetailsList();

    // Absence service layer object
    Absence absenceObj = AbsenceFactory.newInstance();

    // BEGIN, CR00120337, CSH
    // Set the planned item key
    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = key.plannedItemIDKey.plannedItemID;

    // Validate the plan item is a valid type
    validatePlanItemTypeForAbsence(plannedItemKey);
    // END, CR00120337

    // List the absence records
    plannedItemAbsenceDetailsList = absenceObj.listPlanItemAbsence(key);

    // Return the list
    return plannedItemAbsenceDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method verifies that the plan item is of a type which allows absence
   * period details to be recorded.
   *
   * @param key
   * - The planned item identifier.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link
   * BPOCLIENTPARTICIPATION #ERR_ABSENCE_RV_INVALID_PLAN_ITEM_TYPE}
   * - absences can only be recorded against plan items with valid
   * types.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void validatePlanItemTypeForAbsence(PlannedItemKey key)
    throws AppException, InformationalException {

    // Planned Item manipulation variables
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    PlanItemTypeCodeDetails planItemTypeCodeDetails = new PlanItemTypeCodeDetails();

    // Read the plan item type
    planItemTypeCodeDetails = plannedItemObj.readPlanItemTypeCodeByPlannedItemID(
      key);

    // Verify the plan item is of the correct type
    if (!((planItemTypeCodeDetails.typeCode.equals(PLANITEMTYPE.SERVICEPLANITEM))
      || (planItemTypeCodeDetails.typeCode.equals(
        PLANITEMTYPE.CUSTOMSERVICEPLANITEM)))) {

      AppException appException = new AppException(
        BPOCLIENTPARTICIPATION.ERR_ABSENCE_RV_INVALID_PLAN_ITEM_TYPE);

      appException.arg(
        CodeTable.getOneItem(PLANITEMTYPE.TABLENAME,
        PLANITEMTYPE.SERVICEPLANITEM));
      appException.arg(
        CodeTable.getOneItem(PLANITEMTYPE.TABLENAME,
        PLANITEMTYPE.CUSTOMSERVICEPLANITEM));

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    TransactionInfo.getInformationalManager().failOperation();
  }

  // END, CR00120973
  // BEGIN, CR00120079, PMD
  // ___________________________________________________________________________
  /**
   * Validates the attendance units
   *
   * @param details
   * the daily attendance details
   *
   * @throws AppException
   * {@link ENTDAILYATTENDANCE. ERR_DAILYATTENDANCE_XFV_UNITS_NOT_ATTENDED_MUST_BE_ZERO_IF_ATTENDANCE_IS_PRESENT }
   * - Units Not Attended must not be entered if attendance is
   * entered as 'Present'.
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPROVIDERPLANNEDITEM. ERR_DAILYATTENDANCE_XFV_UNITS_UNATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_ABSENT_OR_PARTIALLY_PRESENT}
   * - Units Not Attended must be entered and must be greater than
   * zero if attendance is entered as either 'Absent' or
   * 'Partially Present'.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link ENTDAILYATTENDANCE. ERR_DAILYATTENDANCE_XFV_UNITS_ATTENDED_MUST_BE_ZERO_IF_ATTENDANCE_IS_ENTERED_ABSENT}
   * - Units Attended must not be entered if attendance is entered
   * as 'Absent'.
   * @throws AppException
   * {@link ENTDAILYATTENDANCE. ERR_DAILYATTENDANCE_FV_UNITS_ATTENDED_MUST_BE_GREATER_THAN_OR_EQUAL_TO_ZERO}
   * - Units attended must be greater than or equal to zero.
   * @throws AppException
   * {@link ENTDAILYATTENDANCE. ERR_DAILYATTENDANCE_XFV_UNITS_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_PRESENT_OR_PARTIALLY_PRESENT}
   * - Units Attended must be entered and must be greater than
   * zero, if attendance is entered as either 'Present' or
   * 'Partially Present'.
   * @throws AppException
   * {@link ENTDAILYATTENDANCE. ERR_DAILYATTENDANCE_FV_UNITS_NOT_ATTENDED_MUST_BE_GREATER_THAN_OR_EQUAL_TO_ZERO}
   * - Units not attended must be greater than or equal to zero.
   */
  public void validateAttendanceUnits(
    PlannedItemDailyAttendanceDetails details) throws AppException,
      InformationalException {

    // Check units attended less than zero.
    if (details.dtls.dtls.unitsAttended < 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          ENTDAILYATTENDANCE.ERR_DAILYATTENDANCE_FV_UNITS_ATTENDED_MUST_BE_GREATER_THAN_OR_EQUAL_TO_ZERO),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Check units unattended less than zero.
    if (details.dtls.dtls.unitsUnattended < 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          ENTDAILYATTENDANCE.ERR_DAILYATTENDANCE_FV_UNITS_NOT_ATTENDED_MUST_BE_GREATER_THAN_OR_EQUAL_TO_ZERO),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Units Attended must be entered and must be greater than zero, if
    // attendance is entered as either 'Present' or 'Partially Present'.
    if (details.dtls.dtls.attendance.equals(ATTENDANCE.PRESENT)
      || details.dtls.dtls.attendance.equals(ATTENDANCE.PARTIALLYPRESENT)) {

      if (details.dtls.dtls.unitsAttended <= 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            ENTDAILYATTENDANCE.ERR_DAILYATTENDANCE_XFV_UNITS_ATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_PRESENT_OR_PARTIALLY_PRESENT),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

    // Units Attended must not be entered if attendance is entered as
    // 'Absent'.
    if (details.dtls.dtls.attendance.equals(ATTENDANCE.ABSENT)) {

      if (details.dtls.dtls.unitsAttended != 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            ENTDAILYATTENDANCE.ERR_DAILYATTENDANCE_XFV_UNITS_ATTENDED_MUST_BE_ZERO_IF_ATTENDANCE_IS_ENTERED_ABSENT),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

    // Units Not Attended must be entered and must be greater than zero if
    // attendance is entered as either 'Absent' or 'Partially Present'.
    if (details.dtls.dtls.attendance.equals(ATTENDANCE.ABSENT)
      || details.dtls.dtls.attendance.equals(ATTENDANCE.PARTIALLYPRESENT)) {

      if (details.dtls.dtls.unitsUnattended <= 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPROVIDERPLANNEDITEM.ERR_DAILYATTENDANCE_XFV_UNITS_UNATTENDED_MUST_BE_ENTERED_IF_ATTENDANCE_IS_ENTERED_EITHER_ABSENT_OR_PARTIALLY_PRESENT),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

    // Units Not Attended must not be entered if attendance is
    // entered as 'Present'.
    if (details.dtls.dtls.attendance.equals(ATTENDANCE.PRESENT)
      && details.dtls.dtls.unitsUnattended != 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          ENTDAILYATTENDANCE.ERR_DAILYATTENDANCE_XFV_UNITS_NOT_ATTENDED_MUST_BE_ZERO_IF_ATTENDANCE_IS_PRESENT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  // _________________________________________________________________________
  /**
   * Adds a Daily Attendance record.
   *
   * @param plannedItemDailyAttendanceDetails
   * Daily attendance information provided by user.
   * @return Identifier of newly created daily attendance record.
   */
  public DailyAttendanceKey addDailyAttendance(
    PlannedItemDailyAttendanceDetails details) throws AppException,
      InformationalException {

    // Return struct
    DailyAttendanceKey dailyAttendanceKey = new DailyAttendanceKey();

    // Validate the attendance units
    validateAttendanceUnits(details);

    // Create the daily attendance
    dailyAttendanceKey = ClientParticipationFactory.newInstance().addParticipation(
      details);

    return dailyAttendanceKey;
  }

  // _________________________________________________________________________
  /**
   * Modifies a Daily Attendance record.
   *
   * @param plannedItemDailyAttendanceDetails
   * the modified Daily attendance information provided by user.
   */
  public void modifyDailyAttendance(PlannedItemDailyAttendanceDetails details)
    throws AppException, InformationalException {

    // Validate Attendance Units
    validateAttendanceUnits(details);

    // If the record was created by the system, apply validations
    if (details.dtls.dtls.createdBySystem) {

      // Validate the modify operation
      validateModifyDailyAttendance(details);
    }

    // Modify the daily attendance
    ClientParticipationFactory.newInstance().modifyDetails(details);

  }

  // ___________________________________________________________________________
  /**
   * Validates the modify daily attendance operation
   *
   * @param details
   * the daily attendance details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPROVIDERPLANNEDITEM. ERR_DAILYATTENDANCE_RV_ABSENCE_REASON_CANNOT_MODIFY_SYSTEM_CREATED_RECORD}
   * - Absence Reason must not be updated if the record was
   * created by the system.
   * @throws AppException
   * {@link BPOPROVIDERPLANNEDITEM. ERR_DAILYATTENDANCE_RV_TIME_PARTICIPATED_CANNOT_MODIFY_SYSTEM_CREATED_RECORD}
   * - Time participated must not be updated if the record was
   * created by the system.
   * @throws AppException
   * {@link BPOPROVIDERPLANNEDITEM. ERR_DAILYATTENDANCE_RV_UNITS_UNATTENDED_CANNOT_MODIFY_SYSTEM_CREATED_RECORD}
   * - Units Not Attended must not be updated if the record was
   * created by the system.
   * @throws AppException
   * {@link BPOPROVIDERPLANNEDITEM. ERR_DAILYATTENDANCE_RV_UNITS_ATTENDED_CANNOT_MODIFY_SYSTEM_CREATED_RECORD}
   * - Units Attended must not be updated if the record was
   * created by the system.
   * @throws AppException
   * {@link BPOPROVIDERPLANNEDITEM. ERR_DAILYATTENDANCE_RV_SERVICE_DATE_CANNOT_MODIFY_SYSTEM_CREATED_RECORD}
   * - Service Date must not be updated if the record was created
   * by the system.
   * @throws AppException
   * {@link BPOPROVIDERPLANNEDITEM. ERR_DAILYATTENDANCE_RV_ATTENDANCE_CANNOT_MODIFY_SYSTEM_CREATED_RECORD}
   * - Attendance must not be updated if the record was created by
   * the system.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void validateModifyDailyAttendance(
    PlannedItemDailyAttendanceDetails details) throws AppException,
      InformationalException {

    DailyAttendanceKey dailyAttendanceKey = new DailyAttendanceKey();

    dailyAttendanceKey.dailyAttendanceID = details.dtls.dtls.dailyAttendanceID;

    // Read back the original daily attendance details
    DailyAttendanceDtls originalDetails = DailyAttendanceFactory.newInstance().read(
      dailyAttendanceKey);

    // BEGIN CR00127740, GBA
    // Attendance must not be updated if the record was created by the
    // system
    if (!originalDetails.attendance.equals(details.dtls.dtls.attendance)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_DAILYATTENDANCE_RV_ATTENDANCE_CANNOT_MODIFY_SYSTEM_CREATED_RECORD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Absence Reason must not be updated if the record
    // was created by the system
    if (!originalDetails.absenceReason.equals(details.dtls.dtls.absenceReason)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_DAILYATTENDANCE_RV_ABSENCE_REASON_CANNOT_MODIFY_SYSTEM_CREATED_RECORD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Service Date must not be updated if the record
    // was created by the system
    if (!originalDetails.serviceDate.equals(details.dtls.dtls.serviceDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_DAILYATTENDANCE_RV_SERVICE_DATE_CANNOT_MODIFY_SYSTEM_CREATED_RECORD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END CR00127740

    // Time participated must not be updated if the record
    // was created by the system
    if (!originalDetails.totalHours.equals(details.dtls.dtls.totalHours)
      || !originalDetails.totalMinutes.equals(details.dtls.dtls.totalMinutes)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_DAILYATTENDANCE_RV_TIME_PARTICIPATED_CANNOT_MODIFY_SYSTEM_CREATED_RECORD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Units Attended must not be updated if the record
    // was created by the system
    if (originalDetails.unitsAttended != details.dtls.dtls.unitsAttended) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_DAILYATTENDANCE_RV_UNITS_ATTENDED_CANNOT_MODIFY_SYSTEM_CREATED_RECORD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Units Not Attended must not be updated if the record
    // was created by the system
    if (originalDetails.unitsUnattended != details.dtls.dtls.unitsUnattended) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_DAILYATTENDANCE_RV_UNITS_UNATTENDED_CANNOT_MODIFY_SYSTEM_CREATED_RECORD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  // END, CR00120079

  // ___________________________________________________________________________
  /**
   * This method is used to cancel all service authorization line items
   * associated with the planned item
   *
   * @param plannedItemIDKey
   * unique id of the planned item
   *
   * @throws AppException
   * ,InformationalException
   */

  public void cancelServiceAuthorizationLineItem(
    PlannedItemIDKey plannedItemIDKey) throws AppException,
      InformationalException {

    // Get Service Authorization key from the Provider Planned item link
    // table, and cancel it
    // by calling CPM API

    // Cancellation depends on whether the whole planned item is being
    // deleted,
    // or whether the actual
    // end date is modified, or when the outcome is set to canceled.

    curam.providerserviceplan.sl.entity.intf.ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    ProviderPlannedItemLinkDtls providerPlannedItemLinkDtls = null;

    try {
      providerPlannedItemLinkDtls = providerPlannedItemLinkObj.readByPlannedItemID(
        plannedItemIDKey.plannedItemIDKey);
    } catch (RecordNotFoundException ex) {// Service Authorization has not yet been created for the planned
      // item
    }

    long serviceAuthID = 0;

    if (providerPlannedItemLinkDtls != null) {
      serviceAuthID = providerPlannedItemLinkDtls.serviceAuthorizationID;
      ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.get(
        serviceAuthID);

      Set<ServiceAuthorizationLineItem> serviceAuthorizationLineItems = serviceAuthorizationLineItemDAO.searchByServiceAuthorization(
        serviceAuthorization);

      for (ServiceAuthorizationLineItem serviceAuthorizationLineItem :
        serviceAuthorizationLineItems) {

        // BEGIN, CR00123918, MC
        if (serviceAuthorizationLineItem.getDerivedStatus().equals(
          ServiceAuthorizationLineItemDerivedStatus.OPEN)) {
          serviceAuthorizationLineItem.cancelServiceAuthorizationLineItem();

        }
        // END, CR00123918
      }
    }

  }

  // BEGIN, CR00120774, ANK
  // ___________________________________________________________________________
  // BEGIN, CR00280918, SSK
  /**
   * Calculates the total units authorized per service type plan planItem.
   *
   * @param PlannedItemDtls
   * Planned Item details used for the calculation.
   *
   * @throws AppException
   * , InformationalException
   */
  protected void calculateTotalUnitsAuthorized(
    PlannedItemDtls plannedItemDtls) {

    // Check if the frequency field has a valid value

    if (plannedItemDtls.frequency != null
      && plannedItemDtls.frequency.length() > 0) {

      FrequencyPattern frequencyPattern = new FrequencyPattern(
        plannedItemDtls.frequency);
      FrequencyPatternUtil frequencyPatternUtil = new FrequencyPatternUtilImpl();
      
      Date anchorDate = frequencyPatternUtil.getAnchorDateAfterReferenceDate(
        plannedItemDtls.expectedStartDate, frequencyPattern);

      DateRange dateRange = new DateRange(plannedItemDtls.expectedStartDate,
        plannedItemDtls.expectedEndDate);
      List<Date> dateList = frequencyPatternUtil.getFrequencyOccurrencesWithinPeriod(
        frequencyPattern, dateRange, anchorDate);

      int noOfDates = dateList.size();

      if (noOfDates > 0) {

        plannedItemDtls.totalUnitsAuthorized = noOfDates
          * plannedItemDtls.authorizedUnits;

      }
      
      // END, CR00280918
    } else {
      // Total Units Authorized = Authorized Units
      plannedItemDtls.totalUnitsAuthorized = plannedItemDtls.authorizedUnits;
    }
  }

  // END, CR00120774

  // BEGIN, CR00120337, CSH
  // ___________________________________________________________________________
  /**
   * This method lists the service and custom service type plan items
   * associated with the specified service plan delivery.
   *
   * @param key
   * - The service plan delivery identifier.
   *
   * @return The list of planned items.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PlannedItemIDAndNameDetailsList listServicePlanPlanItems(
    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // Planned Item manipulation variables
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    PlannedItemIDAndNameDetailsList plannedItemIDAndNameDetailsList = new PlannedItemIDAndNameDetailsList();
    PlanItemTypeCodeDetails planItemTypeCodeDetails = new PlanItemTypeCodeDetails();
    PlannedItemKey plannedItemKey = new PlannedItemKey();

    // Absence service layer object
    Absence absenceObj = AbsenceFactory.newInstance();

    // Retrieve the list of plan items associated with the
    // service plan delivery
    plannedItemIDAndNameDetailsList = absenceObj.listServicePlanPlanItems(key);
    // BEGIN CR00128278, GBA
    PlannedItemIDAndNameDetailsList returnPlannedItemIDAndNameDetailsList = new PlannedItemIDAndNameDetailsList();

    // Filter out any non-service type plan items from the list
    // as absences can only be created for plan items of service types
    for (int i = 0; i < plannedItemIDAndNameDetailsList.list.dtls.size(); i++) {

      // Set the planned item key
      plannedItemKey.plannedItemID = plannedItemIDAndNameDetailsList.list.dtls.item(i).plannedItemID;

      // Read the plan item type
      planItemTypeCodeDetails = plannedItemObj.readPlanItemTypeCodeByPlannedItemID(
        plannedItemKey);

      // Verify the plan item is of the correct type
      if (planItemTypeCodeDetails.typeCode.equals(PLANITEMTYPE.SERVICEPLANITEM)
        || planItemTypeCodeDetails.typeCode.equals(
          PLANITEMTYPE.CUSTOMSERVICEPLANITEM)) {

        // add to the return list
        returnPlannedItemIDAndNameDetailsList.list.dtls.addRef(
          plannedItemIDAndNameDetailsList.list.dtls.item(i));

      }
      // END CR00128278
    }

    // Return the list of service or custom service plan items for
    // the service plan delivery
    return returnPlannedItemIDAndNameDetailsList;
  }

  // END, CR00120337

  // ___________________________________________________________________________
  /**
   * Adds a plan template to a service plan delivery. Creates planned goal,
   * plan groups, milestones, sub-goals and planItems defined by the template.
   *
   * @param servicePlanKey
   * Service plan delivery case ID.
   * @param planTemplateKey
   * Plan template ID
   */
  public void addTemplate(ServicePlanDeliveryKey servicePlanKey,
    PlanTemplateKey planTemplateKey) throws AppException,
      InformationalException {

    // PlanTemplate entity
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // PlanTemplatePlanGroup entity
    PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();

    // PlanTemplateSubGoal entity
    PlanTemplateSubGoal planTemplateSubGoalObj = PlanTemplateSubGoalFactory.newInstance();

    // PlanTemplatePlanItem entity
    PlanTemplatePlanItem planTemplatePlanItemObj = PlanTemplatePlanItemFactory.newInstance();

    // PlannedGoal entity
    curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = PlannedGoalFactory.newInstance();

    PlannedGoalDtls plannedGoalDtls = new PlannedGoalDtls();

    // PlannedSubGoal entity
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem entity and service layer
    curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = PlanItemFactory.newInstance();

    // Read Goal ID
    GoalIDDetails goalIDDetails = new GoalIDDetails();

    goalIDDetails = planTemplateObj.readGoalID(planTemplateKey.planTemplateKey);

    // create planned goal details
    plannedGoalDtls.caseID = servicePlanKey.key.caseID;
    plannedGoalDtls.goalID = goalIDDetails.goalID;

    // insert planned goal
    plannedGoalObj.insert(plannedGoalDtls);

    // Get back the newly created planned goal key
    PlannedGoalKey plannedGoalKey = new PlannedGoalKey();

    plannedGoalKey.plannedGoalID = plannedGoalDtls.plannedGoalID;

    // BEGIN, CR00057255, PMD
    // Create service plan level milestones
    MilestoneTemplateDetailsList milestoneTemplateDetailsList = new MilestoneTemplateDetailsList();

    // Get the list of milestones configured at service plan level
    // for the selected template
    milestoneTemplateDetailsList = PlanTemplateMilestoneFactory.newInstance().searchServicePlanLevelMilestones(
      planTemplateKey.planTemplateKey);

    for (int k = 0; k < milestoneTemplateDetailsList.dtls.size(); k++) {

      // Add the service plan template milestone to the service plan
      servicePlanDeliveryObj.addTemplateMilestone(servicePlanKey,
        milestoneTemplateDetailsList.dtls.item(k));
    }
    // END, CR00057255

    // Create PlanGroups
    PlanTemplatePlanGroupDetailsList planTemplatePlanGroupDetailsList = new PlanTemplatePlanGroupDetailsList();

    planTemplatePlanGroupDetailsList.detailsList = planTemplatePlanGroupObj.getParentPlanGroupDetails(
      planTemplateKey.planTemplateKey);

    // Call recursive method
    servicePlanDeliveryObj.addTemplatePlanGroup(
      planTemplatePlanGroupDetailsList, plannedGoalKey);

    // Read Template Sub-Goal details
    TemplateSubGoalDetailsList templateSubGoalDetailsList = new TemplateSubGoalDetailsList();

    templateSubGoalDetailsList = planTemplateSubGoalObj.searchParentSubGoalsByPlanTemplateID(
      planTemplateKey.planTemplateKey);

    for (int i = 0; i < templateSubGoalDetailsList.dtls.size(); i++) {

      // create planned sub goal details
      PlannedSubGoalDtls plannedSubGoalDtls = new PlannedSubGoalDtls();

      plannedSubGoalDtls.plannedGoalID = plannedGoalDtls.plannedGoalID;
      plannedSubGoalDtls.recordStatus = RECORDSTATUS.NORMAL;
      plannedSubGoalDtls.ownerID = curam.util.transaction.TransactionInfo.getProgramUser();
      plannedSubGoalDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;
      plannedSubGoalDtls.subGoalID = templateSubGoalDetailsList.dtls.item(i).subGoalID;

      // insert planned sub goal
      plannedSubGoalObj.insert(plannedSubGoalDtls);

      // Read template plan items that are assigned to this template
      // sub-goal
      // PlanItemAndPlanTemplatePlanItemDetailsList
      // planItemAndPlanTemplatePlanItemDetailsList =
      // new PlanItemAndPlanTemplatePlanItemDetailsList();

      // Set the PlanTemplateSubGoalKey
      PlanTemplateSubGoalKey planTemplateSubGoalKey = new PlanTemplateSubGoalKey();

      planTemplateSubGoalKey.planTemplateSubGoalID = templateSubGoalDetailsList.dtls.item(i).planTemplateSubGoalID;

      // BEGIN, CR00235789, AK
      PlanItemAndTemplatePlanItemDetailsList planItemAndPlanTemplatePlanItemDetailsList = planTemplatePlanItemObj.searchPlanItemByPlanTemplateSubGoalID(
        planTemplateSubGoalKey);

      // END, CR00235789

      for (int j = 0; j
        < planItemAndPlanTemplatePlanItemDetailsList.dtls.size(); j++) {

        curam.serviceplans.sl.struct.PlannedItemDetailsStruct plannedItemDetailsStruct = new curam.serviceplans.sl.struct.PlannedItemDetailsStruct();

        // Read the plan item name and assign
        curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

        planItemKey.planItemID = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).planItemID;

        PlanItemDtls planItemDtls = planItemObj.read(planItemKey);

        plannedItemDetailsStruct.plannedItemDtls.name = CodeTable.getOneItem(
          PLANITEMNAME.TABLENAME, planItemDtls.name);

        // create planned item details
        plannedItemDetailsStruct.plannedItemDtls.expectedOutcomeID = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).expectedOutcomeID;

        plannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID = plannedSubGoalDtls.plannedSubGoalID;

        plannedItemDetailsStruct.plannedItemDtls.planItemID = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).planItemID;

        plannedItemDetailsStruct.plannedItemDtls.expectedStartDate = curam.util.type.Date.getCurrentDate().addDays(
          planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).startDay);

        // BEGIN, CR00000048, PMD
        plannedItemDetailsStruct.plannedItemDtls.authorizedUnits = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).authorizedUnits;
        // END, CR00000048

        // BEGIN, CR00000637, PMD
        plannedItemDetailsStruct.plannedItemDtls.maximumUnits = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).maximumUnits;
        // END, CR00000637
        // BEGIN, CR00161962, LJ
        // BEGIN, CR00228236, SK
        PlanItemAndTemplatePlanItemDetails planItemAndTemplatePlanItemDetails = new PlanItemAndTemplatePlanItemDetails();

        plannedItemDetailsStruct.plannedItemDtls.isMandatoryInd = planItemAndTemplatePlanItemDetails.isMandatoryInd;

        // setting the status of the planned item based on the
        // approval required indicator value set in the template.
        if (planItemAndTemplatePlanItemDetails.approvalReqInd) {
          // END, CR00228236
          plannedItemDetailsStruct.plannedItemDtls.status = PLANNEDITEMSTATUS.UNAPPROVED;
        } else {
          plannedItemDetailsStruct.plannedItemDtls.status = PLANNEDITEMSTATUS.NOTSTARTED;
        }

        plannedItemDetailsStruct.plannedItemDtls.guidanceURL = planItemDtls.guidanceURL;
        ServicePlanDelivery servicePlanDelivery = ServicePlanDeliveryFactory.newInstance();
        // Check to see if we only have one plan participants for this
        // service
        // plan. If so then default the concerningID
        ServicePlanParticipantDetailsList servicePlanParticipantDetailsList = servicePlanDelivery.listPlanParticipants(
          servicePlanKey);

        if (servicePlanParticipantDetailsList.servicePlanParticipantDetailsList.dtls.size()
          == 1) {
          // get the primary participant concernRoleID's so we can
          // default all
          // PlannedItem concerningID's to this value
          ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = servicePlanDelivery.readServicePlanIDAndConcernRoleID(
            servicePlanKey);

          plannedItemDetailsStruct.plannedItemDtls.concerningID = servicePlanAndParticipantDetails.concernRoleID;
        }
        // END, CR00161962
        int duration = planItemAndPlanTemplatePlanItemDetailsList.dtls.item(j).duration;

        if (duration > 0) {
          duration = duration - 1;
        }

        plannedItemDetailsStruct.plannedItemDtls.expectedEndDate = plannedItemDetailsStruct.plannedItemDtls.expectedStartDate.addDays(
          duration);

        plannedItemDetailsStruct.plannedItemDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;

        // BEGIN, CR00161962, LJ
        // BEGIN, CR00228236, SK
        plannedItemDetailsStruct.planTemplatePlanItemID = planItemAndTemplatePlanItemDetails.planTemplatePlanItemID;
        // END, CR00228236

        // END, CR00161962

        // insert planned item
        // call the service layer method
        plannedItemObj.createBasicPlanItemDetails(plannedItemDetailsStruct);

        // insert link details

        if (PLANITEMTYPE.CUSTOMSERVICEPLANITEM.equals(planItemDtls.typeCode)
          || PLANITEMTYPE.SERVICEPLANITEM.equals(planItemDtls.typeCode)) {

          long serviceID = planItemDtls.associatedID;

          if (serviceID != 0) {
            ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

            ProviderPlannedItemLinkDtls providerPlannedItemLinkDtls = new ProviderPlannedItemLinkDtls();
            // Manipulation variables
            UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

            providerPlannedItemLinkDtls.providerPlannedItemLinkID = uniqueIDObj.getNextID();
            providerPlannedItemLinkDtls.plannedItemID = plannedItemDetailsStruct.plannedItemDtls.plannedItemID;
            providerPlannedItemLinkDtls.serviceOfferingID = serviceID;
            providerPlannedItemLinkDtls.plannedSubGoalID = plannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

            providerPlannedItemLinkObj.insert(providerPlannedItemLinkDtls);
          }

        }
      }

      // BEGIN, CR00057255, PMD
      // Create sub-goal level milestones
      milestoneTemplateDetailsList = new MilestoneTemplateDetailsList();

      // Get the list of milestones configured at sub-goal level
      milestoneTemplateDetailsList = PlanTemplateMilestoneFactory.newInstance().searchSubGoalLevelMilestones(
        planTemplateSubGoalKey);

      for (int l = 0; l < milestoneTemplateDetailsList.dtls.size(); l++) {

        MilestoneTemplateDetails milestoneTemplateDetails = new MilestoneTemplateDetails();

        milestoneTemplateDetails = milestoneTemplateDetailsList.dtls.item(l);
        milestoneTemplateDetails.linkDtls.plannedSubGoalID = plannedSubGoalDtls.plannedSubGoalID;

        // Add the sub-goal template milestone to the service plan
        servicePlanDeliveryObj.addTemplateMilestone(servicePlanKey,
          milestoneTemplateDetails);
      }
      // END, CR00057255
    }
  }
  
}
