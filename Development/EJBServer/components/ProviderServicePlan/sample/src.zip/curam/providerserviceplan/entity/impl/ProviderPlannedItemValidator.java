/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2009, 2013. All rights reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 *
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.entity.impl;


import com.google.inject.Inject;

import curam.core.sl.entity.fact.DailyAttendanceFactory;
import curam.core.sl.entity.intf.DailyAttendance;
import curam.core.sl.entity.struct.DailyAttendanceDtls;
import curam.core.sl.entity.struct.DailyAttendanceKey;
import curam.core.struct.CurrentCaseStatusKey;
import curam.message.BPOPROVIDERPLANNEDITEM;
import curam.providerserviceplan.entity.fact.ProviderPlannedItemFactory;
import curam.providerserviceplan.entity.intf.ProviderPlannedItem;
import curam.providerserviceplan.sl.entity.fact.ProviderPlannedItemLinkFactory;
import curam.providerserviceplan.sl.entity.intf.ProviderPlannedItemLink;
import curam.providerserviceplan.sl.entity.struct.ClonedPlannedItemDtls;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.serviceoffering.impl.UnitOfMeasureEntry;
import curam.serviceplans.sl.entity.fact.PIDailyAttendanceLinkFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemValidatorFactory;
import curam.serviceplans.sl.entity.intf.PIDailyAttendanceLink;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.intf.PlannedItemValidator;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkDtls;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkDtlsList;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemKeyList;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;


// BEGIN, CR00261232, GYH
/**
 * This class is used to perform pre/post insert/modify data validation of
 * provider planned item record.
 *
 */
public class ProviderPlannedItemValidator extends curam.providerserviceplan.entity.base.ProviderPlannedItemValidator
  implements PlannedItemValidator {

  /**
   * Injecting the Data Access Object for ServiceOfferingDAO class.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Default constructor.
   */
  public ProviderPlannedItemValidator() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  // END, CR00261232

  // ___________________________________________________________________________
  /**
   * Validates the details of a planned item.
   *
   * @param plannedItemDtls details of the planned item to be validated.
   */
  
  public void validateDetails(PlannedItemDtls plannedItemDtls) throws AppException, InformationalException {
    // BEGIN, CR00114996, MC

    // PlannedItemValidator plannedItemValidatorObj = PlannedItemValidatorFactory.newInstance();
    
    ProviderPlannedItem providerPlannedItemObj = ProviderPlannedItemFactory.newInstance();

    // BEGIN, CR00124146, MC
    curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();
    
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    
    curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();

    plannedSubGoalKey.plannedSubGoalID = plannedItemDtls.plannedSubGoalID;
    
    CurrentCaseStatusKey currentCaseStatusKey = new CurrentCaseStatusKey();

    currentCaseStatusKey.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;
    
    // BEGIN, CR00235789, AK
    curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    // END, CR00235789
    
    if (!curam.codetable.CASESTATUS.CLOSED.equals(caseStatusDtls.statusCode)) {
      // BEGIN, CR00147010, MC
      PlannedItemValidator plannedItemValidator = PlannedItemValidatorFactory.newInstance();

      plannedItemValidator.validateDetails(plannedItemDtls);
      // END, CR00147010
    }

    // END, CR00124146
    // END, CR00114996

    // BEGIN, CR00123078, MC
    if (plannedItemDtls.frequency.length() > 0 && !isCloned(plannedItemDtls)) {
      providerPlannedItemObj.validateProviderServiceFrequencyDetails(
        plannedItemDtls);
    }
    
    // END, CR00123078
    
  }

  // ___________________________________________________________________________
  /**
   * This method is used to view the planned item details
   *
   * @param plannedItemDtls
   * details which are to be validated on pre-modify
   *
   * @throws AppException,
   * InformationalException
   */
  public void validateModify(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00114996, MC
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    // BEGIN, CR00147010, MC
    PlannedItemValidator plannedItemValidator = PlannedItemValidatorFactory.newInstance();

    plannedItemValidator.validateModify(plannedItemDtls);
    // END, CR00147010
    ProviderPlannedItem providerPlannedItemObj = ProviderPlannedItemFactory.newInstance();
    
    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = plannedItemDtls.plannedItemID;

    PlannedItemDtls originalPlannedItemDtls = plannedItemObj.read(
      plannedItemKey);

    if (!plannedItemDtls.actualEndDate.isZero()) {

      // Has an outcome of canceled been entered?
      if (plannedItemDtls.outcomeAchieved.equals(
        curam.codetable.OUTCOMEACHIEVED.CANCELLED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPROVIDERPLANNEDITEM.ERR_FV_END_DATE_PRESENT_CANNOT_CANCEL_PLANNED_ITEM),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

    if (!originalPlannedItemDtls.frequency.equals(plannedItemDtls.frequency)) {

      providerPlannedItemObj.validateProviderServiceFrequencyDetails(
        plannedItemDtls);

    }

    // check if dates are being modified after creation of SALI
    PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = plannedItemDtls.plannedItemID;
    
    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();
    
    int noOfRecords = providerPlannedItemLinkObj.getServiceAuthorizationLineItemCount(plannedItemIDKey).noOfRecords;

    if (plannedItemDtls.frequency.length() > 0 && noOfRecords > 0) {

      if (!originalPlannedItemDtls.expectedStartDate.equals(
        plannedItemDtls.expectedStartDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPROVIDERPLANNEDITEM.ERR_SERVICEPLAN_FV_START_DATE_CANNOT_BE_UPDATED_FREQ),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);

      }

      if (!originalPlannedItemDtls.expectedEndDate.equals(
        plannedItemDtls.expectedEndDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPROVIDERPLANNEDITEM.ERR_SERVICEPLAN_FV_END_DATE_CANNOT_BE_UPDATED_FREQ),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);

      }
    }

    // BEGIN, CR00123487, MC

    if (originalPlannedItemDtls.nomineeID != plannedItemDtls.nomineeID
      && noOfRecords > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_SERVICEPLAN_FV_NOMINEE_CANNOT_BE_MODIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END, CR00123487

    PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = plannedItemDtls.planItemID;

    // END, CR00114996
    // BEGIN, CR00261232, GYH
    final UnitOfMeasureEntry providerServiceUnitOfMeasure = serviceOfferingDAO.get(providerPlannedItemLinkObj.readByPlannedItemID(plannedItemIDKey).serviceOfferingID).getUnitOfMeasure();

    if (!plannedItemDtls.actualEndDate.isZero()
      && !providerServiceUnitOfMeasure.equals(UnitOfMeasureEntry.PLACE)) {
      // END, CR00261232
      
      // check client participation record for date of delivery of the last
      // planned item
      // if date of delivery is after or equal to the actual end date throw
      // exception stating
      // actual end date cannot be modified

      boolean isCreatedBySet = false;
      PIDailyAttendanceLink piDailyAttendanceLink = PIDailyAttendanceLinkFactory.newInstance();

      PIDailyAttendanceLinkDtlsList piDailyAttendanceLinkDtlsList = piDailyAttendanceLink.searchByPlannedItemID(
        plannedItemKey);
      Date date = Date.kZeroDate;

      for (PIDailyAttendanceLinkDtls piDailyAttendanceLinkDtls : piDailyAttendanceLinkDtlsList.dtls.items()) {
        // BEGIN, CR00386476, GA 
        if (0 != piDailyAttendanceLinkDtls.dailyAttendanceID) {
         
          DailyAttendance dailyAttendanceObj = DailyAttendanceFactory.newInstance();
          DailyAttendanceKey dailyAttendanceKey = new DailyAttendanceKey();

          dailyAttendanceKey.dailyAttendanceID = piDailyAttendanceLinkDtls.dailyAttendanceID;
        
          DailyAttendanceDtls dailyAttendanceDtls = dailyAttendanceObj.read(
            dailyAttendanceKey);

          isCreatedBySet = dailyAttendanceDtls.createdBySystem;
        
          if (date.before(dailyAttendanceDtls.serviceDate)) {
            date = dailyAttendanceDtls.serviceDate;
          }
        }
        // END, CR00386476
      }
      
      if (!isCreatedBySet) {
        if (date.after(plannedItemDtls.actualEndDate)
          || date.equals(plannedItemDtls.actualEndDate)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(BPOPROVIDERPLANNEDITEM.ERR_FV_ACTUAL_END_DATE_CANNOT_BE_MODIFIED).arg(plannedItemDtls.actualEndDate).arg(
              date),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }
      }
    }
  }
  
  // ___________________________________________________________________________
  /**
   * This method is used to view the planned item details
   *
   * @param plannedItemDtls
   * details which are to be validated on post-modify and post-insert
   *
   * @throws AppException,
   * InformationalException
   */
  public void validatePostDetails(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00114996, MC
    // BEGIN, CR00147010, MC
    PlannedItemValidator plannedItemValidator = PlannedItemValidatorFactory.newInstance();

    // END, CR00147010
    plannedItemValidator.validatePostDetails(plannedItemDtls);
    // END, CR00114996

    Event event = new Event();

    event.eventKey = curam.events.PROVIDERSERVICEPLAN.VALIDATEPLANNEDITEM;
    PlannedItemKey key = new PlannedItemKey();

    key.plannedItemID = plannedItemDtls.plannedItemID;
    raiseEvent(key, event);

  }

  /**
   * This method raises a workflow event.
   *
   * @param key
   * Unique id of the plannedItem.
   *
   * @param event
   * The event class and event type to be raised.
   *
   * @throws AppException
   */
  // BEGIN, CR00177241, PM
  protected void raiseEvent(PlannedItemKey key, Event event) throws AppException,
      InformationalException {
    // END, CR00177241

    event.primaryEventData = key.plannedItemID;
    // Raise the event
    EventService.raiseEvent(event);
  }
  
  /**
   * @param plannedItemDtls
   * @return boolean - Whether the planned item is being cloned or not
   * @throws AppException
   * @throws InformationalException
   */


  // BEGIN, CR00177241, PM
  protected boolean isCloned(PlannedItemDtls plannedItemDtls) 
    throws AppException, InformationalException {
    // END, CR00177241
    
    boolean isCloned = false;
    ProviderPlannedItemLink providerPlannedItemLink = ProviderPlannedItemLinkFactory.newInstance();
    
    ClonedPlannedItemDtls clonedPlannedItemDtls = new ClonedPlannedItemDtls();

    clonedPlannedItemDtls.authorizedUnits = plannedItemDtls.authorizedUnits;
    clonedPlannedItemDtls.expectedEndDate = plannedItemDtls.expectedEndDate;
    clonedPlannedItemDtls.expectedStartDate = plannedItemDtls.expectedStartDate;
    clonedPlannedItemDtls.expectedOutcomeID = plannedItemDtls.expectedOutcomeID;
    clonedPlannedItemDtls.name = plannedItemDtls.name;
    clonedPlannedItemDtls.frequency = plannedItemDtls.frequency;
    clonedPlannedItemDtls.status = plannedItemDtls.status;
    try {
      PlannedItemKeyList plannedItemKeyList = providerPlannedItemLink.searchClonedPlannedItemDtls(
        clonedPlannedItemDtls);

      if (plannedItemKeyList.dtls.size() > 0) {
        isCloned = true;
      }
    } catch (RecordNotFoundException ex) {// Do nothing as is Cloned is already set to false
    }
    
    return isCloned;
    
  }
  
}
