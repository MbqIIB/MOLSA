/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.entity.impl;


import curam.serviceplans.sl.entity.impl.ServicePlanHookRegistrar;
import curam.providerserviceplan.entity.fact.ProviderPlanItemValidatorFactory;
import curam.providerserviceplan.entity.fact.ProviderPlannedItemValidatorFactory;
import curam.serviceplans.sl.entity.impl.ServicePlanHookManager;
import curam.codetable.PLANITEMTYPE;


public class ProviderServicePlanHookRegistrar extends curam.providerserviceplan.entity.base.ProviderServicePlanHookRegistrar
  implements ServicePlanHookRegistrar {

  public void registerPlanItemDataHooks() {
    // BEGIN, CR00147010, MC
    ServicePlanHookManager.getPlanItemHookMap().addMapping(
      PLANITEMTYPE.CUSTOMSERVICEPLANITEM,
      ProviderPlanItemValidatorFactory.class);

    ServicePlanHookManager.getPlanItemHookMap().addMapping(
      PLANITEMTYPE.SERVICEPLANITEM, ProviderPlanItemValidatorFactory.class);
    
    // END, CR00147010

  }

  public void registerPlannedItemDataHooks() {
    
    // BEGIN, CR00147010, MC    
    ServicePlanHookManager.getPlannedItemHookMap().addMapping(
      PLANITEMTYPE.CUSTOMSERVICEPLANITEM,
      ProviderPlannedItemValidatorFactory.class);

    ServicePlanHookManager.getPlannedItemHookMap().addMapping(
      PLANITEMTYPE.SERVICEPLANITEM, ProviderPlannedItemValidatorFactory.class);
    // END, CR00147010
    
  }

}
