/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.providerserviceplan.sl.entity.impl;


import java.util.List;

import com.google.inject.Inject;

import curam.core.fact.CaseHeaderFactory;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.sl.struct.RecordCount;
import curam.core.struct.CaseKey;
import curam.core.struct.IntegratedCaseKey;
import curam.cpm.sl.entity.struct.ConcernRoleKey;
import curam.cpm.util.impl.FrequencyPatternUtil;
import curam.cpm.util.impl.FrequencyPatternUtilImpl;
import curam.message.BPOPROVIDERPLANNEDITEM;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderTypeNameEntry;
import curam.providerserviceplan.sl.entity.fact.ProviderPlannedItemLinkFactory;
import curam.providerserviceplan.sl.entity.struct.ProviderPlannedItemLinkDtls;
import curam.providerserviceplan.sl.entity.struct.ProviderPlannedItemLinkKey;
import curam.providerserviceplan.sl.entity.struct.ServiceAuthLineItemCount;
import curam.serviceauthorization.impl.ServiceAuthorization;
import curam.serviceauthorization.impl.ServiceAuthorizationDAO;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItem;
import curam.serviceauthorization.impl.ServiceAuthorizationLineItemDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedItemDetailsStruct;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.FrequencyPattern;
import curam.util.type.Money;


/**
 * This service layer class interacts with the entity layer classes to perform
 * various operations on the ProviderPlannedItemLink entity
 *
 */
public abstract class ProviderPlannedItemLink extends curam.providerserviceplan.sl.entity.base.ProviderPlannedItemLink {

  /**
   * Injecting the Data Access Object for ServiceAuthorizationDAO class.
   */
  @Inject
  protected ServiceAuthorizationDAO serviceAuthorizationDAO;

  /**
   * Injecting the Data Access Object for ServiceAuthorizationLineItemDAO class.
   */
  @Inject
  protected ServiceAuthorizationLineItemDAO serviceAuthorizationLineItemDAO;

  /**
   * Injecting the Data Access Object for ProviderDAO class.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Injecting the Data Access Object for ServiceOfferingDAO class.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Default constructor.
   */
  public ProviderPlannedItemLink() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  @Override
  protected void preinsert(ProviderPlannedItemLinkDtls details)
    throws AppException, InformationalException {

    validateInsert(details);

  }

  @Override
  protected void premodify(ProviderPlannedItemLinkKey key,
    ProviderPlannedItemLinkDtls details)
    throws AppException, InformationalException {

    validateModify(details);

  }

  /**
   * This method will validate insert operations on the
   * ProviderPlannedItemLink entity
   *
   * @param details - ProviderPlannedItemLinkDtls
   * @throws AppException
   */


  // BEGIN, CR00123078, MC
  public void validateInsert(ProviderPlannedItemLinkDtls details)
    throws AppException {

    // BEGIN CR118524 PP
    // Validation to restrict the user to select either Provider type or
    // Provider
    if (details.providerConcernRoleID != 0
      && details.providerTypeCode.length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_PROVIDER_TYPE_AND_PROVIDER_CANNOT_BE_SELECTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    }

    // END CR118524 PP

  }

  /**
   * This method will validate modify operations on the
   * ProviderPlannedItemLink entity
   *
   * @param details - ProviderPlannedItemLinkDtls
   * @throws AppException
   */


  public void validateModify(ProviderPlannedItemLinkDtls details)
    throws AppException {

    // Validation to restrict the user to select either Provider type or
    // Provider
    if (details.providerConcernRoleID != 0
      && details.providerTypeCode.length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_PROVIDER_TYPE_AND_PROVIDER_CANNOT_BE_SELECTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  /**
   * This method is used to create a service authorization and service
   * authorization line items depending on the frequency. If no frequency is
   * specified, then there will be just one SALI created.
   *
   * @param plannedItemDtls 
   * Details using which the service authorization line item will be created.
   * This SALI will be associated with Service Authorization.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00196702, DRS
  public void createServiceAuthorizationDetails(final PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {
    // END, CR00196702

    PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = plannedItemDtls.plannedItemID;
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = plannedItemObj.readCaseIDByPlannedItemID(
      plannedItemIDKey);

    CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    CaseKey caseKey = new CaseKey();

    caseKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;
    IntegratedCaseKey integratedCaseKey = caseHeader.readIntegratedCaseIDByCaseID(
      caseKey);

    // BEGIN, CR00196702, DRS
    Money unitAmount = new Money(plannedItemDtls.rateAuthorized);
    // END, CR00196702

    int noOfUnitsAuthorized = plannedItemDtls.authorizedUnits;
    long maximumUnits = plannedItemDtls.maximumUnits;

    curam.providerserviceplan.sl.entity.intf.ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    ProviderPlannedItemLinkDtls providerPlannedItemLinkDtls = providerPlannedItemLinkObj.readByPlannedItemID(
      plannedItemIDKey);

    long providerID = providerPlannedItemLinkDtls.providerConcernRoleID;

    long serviceID = providerPlannedItemLinkDtls.serviceOfferingID;

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = plannedItemDtls.nomineeID;

    CaseParticipantRole caseParticipantRole = CaseParticipantRoleFactory.newInstance();
    CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();

    caseIDParticipantRoleKey.participantRoleID = plannedItemDtls.concerningID;
    caseIDParticipantRoleKey.caseID = integratedCaseKey.integratedCaseID;

    CaseParticipantRoleDtlsList caseParticipantRoleDtlsList = caseParticipantRole.searchByParticipantRoleAndCase(
      caseIDParticipantRoleKey);

    // BEGIN CR00124552, GBA
    // Get active case member case participant role id.
    long caseParticipantRoleID = 0;

    if (caseParticipantRoleDtlsList.dtls != null) {
      for (int k = 0; k < caseParticipantRoleDtlsList.dtls.size(); k++) {
        if (curam.codetable.RECORDSTATUS.NORMAL.equals(
          caseParticipantRoleDtlsList.dtls.item(k).recordStatus)) {
          caseParticipantRoleID = caseParticipantRoleDtlsList.dtls.item(k).caseParticipantRoleID;
          break;
        }
      }
    }
    // END CR00124552

    // Create Service Authorization Line Item depending on frequency
    // If frequency is not set then only one SALI needs to be created
    // if frequency is set, then depending on the from date, to date
    // and the frequency SALI's will be generated

    // BEGIN, CR00123487, MC
    ServiceAuthorization serviceAuthorization = serviceAuthorizationDAO.newInstance();

    serviceAuthorization.setCaseParticipantRoleID(caseParticipantRoleID);
    serviceAuthorization.insertServiceAuthorization();
    // END, CR00123487

    Provider provider = providerDAO.get(providerID);

    ProviderTypeNameEntry providerTypeNameEntry = ProviderTypeNameEntry.get(
      providerPlannedItemLinkDtls.providerTypeCode);

    ServiceOffering serviceOffering = serviceOfferingDAO.get(serviceID);

    if (plannedItemDtls.frequency.length() > 0) {

      // BEGIN, CR00273612, SSK
      FrequencyPattern frequencyPattern = new FrequencyPattern(
        plannedItemDtls.frequency);
      // BEGIN, CR00280114, SSK
      FrequencyPatternUtil frequencyPatternUtil = new FrequencyPatternUtilImpl();
      // END, CR00280114
      
      // BEGIN, CR00280918, SSK
      Date anchorDate = frequencyPatternUtil.getAnchorDateAfterReferenceDate(
        plannedItemDtls.expectedStartDate, frequencyPattern);
      // END, CR00280918
      
      DateRange dateRange = new DateRange(plannedItemDtls.expectedStartDate,
        plannedItemDtls.expectedEndDate);
      List<Date> dateList = frequencyPatternUtil.getFrequencyOccurrencesWithinPeriod(
        frequencyPattern, dateRange, anchorDate);

      // END, CR00273612

      // BEGIN, CR00123487, MC
      // BEGIN, CR00273450, ASN

      ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceAuthorizationLineItemDAO.newInstance();

      serviceAuthorizationLineItem.setMaximumUnits(maximumUnits);
      serviceAuthorizationLineItem.setProvider(provider);
      serviceAuthorizationLineItem.setServiceAuthorization(serviceAuthorization);
      serviceAuthorizationLineItem.setUnitAmount(unitAmount);

      if (unitAmount.isPositive()) {
        serviceAuthorizationLineItem.setUnitAmountFixed(true);
      } else {
        serviceAuthorizationLineItem.setUnitAmountFixed(false);
      }
      serviceAuthorizationLineItem.setNominee(concernRoleKey);
      // BEGIN, CR00126147, SG
      serviceAuthorizationLineItem.setProviderType(providerTypeNameEntry);
      // END, CR00126147
      serviceAuthorizationLineItem.setServiceOffering(serviceOffering);

      serviceAuthorizationLineItem.setUnitsAuthorized(noOfUnitsAuthorized);

      serviceAuthorizationLineItem.insertServiceAuthorizationLineItems(dateList,
        serviceAuthorizationLineItem);
      // END, CR00273450
      // END, CR00123487

    } else {

      DateRange authorizedPeriod = new DateRange(
        plannedItemDtls.expectedStartDate, plannedItemDtls.expectedEndDate);

      // BEGIN, CR00123487, MC
      // BEGIN, CR00273450, ASN
      ServiceAuthorizationLineItem serviceAuthorizationLineItem = serviceAuthorizationLineItemDAO.newInstance();

      // END, CR00273450
      serviceAuthorizationLineItem.setDateRange(authorizedPeriod);
      serviceAuthorizationLineItem.setMaximumUnits(maximumUnits);
      serviceAuthorizationLineItem.setProvider(provider);
      serviceAuthorizationLineItem.setServiceAuthorization(serviceAuthorization);
      serviceAuthorizationLineItem.setUnitAmount(unitAmount);

      if (unitAmount.isPositive()) {

        serviceAuthorizationLineItem.setUnitAmountFixed(true);
      } else {
        serviceAuthorizationLineItem.setUnitAmountFixed(false);
      }
      // BEGIN, CR00126147, SG
      serviceAuthorizationLineItem.setProviderType(providerTypeNameEntry);
      // END, CR00126147
      serviceAuthorizationLineItem.setServiceOffering(serviceOffering);
      serviceAuthorizationLineItem.setUnitsAuthorized(noOfUnitsAuthorized);
      serviceAuthorizationLineItem.setNominee(concernRoleKey);
      serviceAuthorizationLineItem.insertServiceAuthorizationLineItem();
      // END, CR00123487

    }

    providerPlannedItemLinkDtls.serviceAuthorizationID = serviceAuthorization.getID();

    ProviderPlannedItemLinkKey providerPlannedItemLinkKey = new ProviderPlannedItemLinkKey();

    providerPlannedItemLinkKey.providerPlannedItemLinkID = providerPlannedItemLinkDtls.providerPlannedItemLinkID;
    providerPlannedItemLinkObj.modify(providerPlannedItemLinkKey,
      providerPlannedItemLinkDtls);

  }

  /**
   * This method returns the number of service authorizations line items
   * for a planned item.
   * @param plannedItemDtls - PlannedItemDtls for which the SALI count has
   * to be returned
   *
   * @throws AppException, InformationalException
   */

  public ServiceAuthLineItemCount getServiceAuthorizationLineItemCount(PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // Check if Service Authorization Line items already exists for the planned item

    ServiceAuthLineItemCount serviceAuthLineItemCount = new ServiceAuthLineItemCount();
    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = plannedItemIDKey.plannedItemID;
    if (plannedItemKey.plannedItemID == 0) {
      serviceAuthLineItemCount.noOfRecords = 0;
      return serviceAuthLineItemCount;
    }

    curam.providerserviceplan.sl.entity.intf.ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();
    ProviderPlannedItemLinkDtls providerPlannedItemLinkDtls = null;
    int numberOfServiceAuthLineItems = 0;

    // BEGIN, CR00123918, MC
    try {
      providerPlannedItemLinkDtls = providerPlannedItemLinkObj.readByPlannedItemID(
        plannedItemIDKey);
    } catch (RecordNotFoundException ex) {
      serviceAuthLineItemCount.noOfRecords = 0;
    }
    // BEGIN, CR00281074, SK
    if (providerPlannedItemLinkDtls != null) {
      StringBuilder sqlStringBuilder = new StringBuilder();

      sqlStringBuilder.append("SELECT count(*) INTO :count FROM ");
      sqlStringBuilder.append("serviceauthorizationlineitem sali JOIN ");
      sqlStringBuilder.append("providerplanneditemlink ppil ON ");
      sqlStringBuilder.append(
        "ppil.serviceauthorizationid = sali.serviceauthorizationid ");
      // BEGIN, CR00343603, SS
      sqlStringBuilder.append("WHERE ppil.planneditemid = :plannedItemID");
      final RecordCount recordCount = (RecordCount) DynamicDataAccess.executeNs(
        RecordCount.class, plannedItemIDKey, false, sqlStringBuilder.toString());

      // END, CR00343603
      numberOfServiceAuthLineItems = (int) (recordCount.count);
      serviceAuthLineItemCount.noOfRecords = numberOfServiceAuthLineItems;
    }
    // END, CR00281074
    // END, CR00123918
    return serviceAuthLineItemCount;

  }
  // END CR00123078




}
