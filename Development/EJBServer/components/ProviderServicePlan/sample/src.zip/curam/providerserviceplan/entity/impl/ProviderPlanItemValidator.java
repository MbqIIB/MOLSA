/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.entity.impl;


import curam.providerserviceplan.entity.fact.ProviderPlanItemFactory;
import curam.providerserviceplan.entity.intf.ProviderPlanItem;
import curam.serviceplans.sl.entity.fact.PlanItemValidatorFactory;
import curam.serviceplans.sl.entity.intf.PlanItemValidator;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class contains validation method for plan item creation and 
 * modification. The methods contained in this class are invoked using hook
 * mechanism.
 *
 *
 */

public class ProviderPlanItemValidator extends curam.providerserviceplan.entity.base.ProviderPlanItemValidator 
  implements PlanItemValidator {

  // ___________________________________________________________________________
  /**
   * Validates the details of a planned item before insertion
   *
   * @param dtls details of the plan item to be validated.
   */
  
  public void validateInsert(PlanItemDtls details) throws AppException, InformationalException {
    
    ProviderPlanItem providerPlanItemObj = ProviderPlanItemFactory.newInstance();
    PlanItemValidator planItemValidatorObj = PlanItemValidatorFactory.newInstance();
    
    planItemValidatorObj.validateInsert(details);
    providerPlanItemObj.validateInsert(details);
    
  }
  
  // ___________________________________________________________________________
  /**
   * Validates the details of a planned item before modification
   *
   * @param dtls details of the plan item to be validated.
   *
   * @param key id of the plan item whose details are to be modified
   */

  public void validateModify(PlanItemKey key, PlanItemDtls details) throws AppException, InformationalException {
    ProviderPlanItem providerPlanItemObj = ProviderPlanItemFactory.newInstance();
    PlanItemValidator planItemValidatorObj = PlanItemValidatorFactory.newInstance();
    
    planItemValidatorObj.validateModify(key, details);
    providerPlanItemObj.validateModify(key, details);
    
  }
  
}
