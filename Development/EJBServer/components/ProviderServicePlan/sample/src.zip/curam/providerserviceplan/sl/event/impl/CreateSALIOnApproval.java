/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.sl.event.impl;


import curam.codetable.PLANITEMTYPE;
import curam.events.SERVICEPLANAPPROVAL;
import curam.events.SERVICEPLANS;
import curam.providerserviceplan.sl.fact.ProviderPlannedItemFactory;
import curam.providerserviceplan.sl.intf.ProviderPlannedItem;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.util.events.impl.EventFilter;
import curam.util.events.impl.EventHandler;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This event handler listens for events from a raised when a planned item is
 * approved.
 *
 */

public class CreateSALIOnApproval implements EventFilter, EventHandler {

  // BEGIN, CR00332169, GYH
  /**
   * Returns true if the event is of type service plan approval or plan item
   * approval.
   *
   * @param event
   * The details of the event.
   *
   * @return true if the event is of type service plan approval or plan item
   * approval otherwise false.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public boolean accept(Event event) throws AppException,
      InformationalException {
    boolean acceptEvent = false;

    if (event.eventKey.eventClass.equals(
      SERVICEPLANS.APPROVEPLANITEM.eventClass)) {
      if (event.eventKey.eventType.equals(
        SERVICEPLANS.APPROVEPLANITEM.eventType)) {
        acceptEvent = true;
      }
    } else if (event.eventKey.eventClass.equals(
      SERVICEPLANAPPROVAL.APPROVEPLANITEM.eventClass)) {
      if (event.eventKey.eventType.equals(
        SERVICEPLANAPPROVAL.APPROVEPLANITEM.eventType)) {
        acceptEvent = true;
      }

    }
    return acceptEvent;

  }

  /**
   * When a planned item of type service or custom service is approved, the
   * events are captured and service authorization line items are created for
   * the same.
   *
   * @param event
   * The details of the event.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public void eventRaised(Event event) throws AppException,
      InformationalException {

    long plannedItemID = event.primaryEventData;

    PlannedItemKey key = new PlannedItemKey();

    key.plannedItemID = plannedItemID;
    PlannedItemDtls plannedItemDtls = PlannedItemFactory.newInstance().read(key);
    long planItemID = plannedItemDtls.planItemID;

    PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = planItemID;
    PlanItemDtls planItemDtls = PlanItemFactory.newInstance().read(planItemKey,
      false);
    String planItemName = planItemDtls.typeCode;

    if (PLANITEMTYPE.SERVICEPLANITEM.equals(planItemName)
      || PLANITEMTYPE.CUSTOMSERVICEPLANITEM.equals(planItemName)) {

      ProviderPlannedItemFactory.newInstance().createSALI(plannedItemDtls);
    }
  }
  // END, CR00332169
}
