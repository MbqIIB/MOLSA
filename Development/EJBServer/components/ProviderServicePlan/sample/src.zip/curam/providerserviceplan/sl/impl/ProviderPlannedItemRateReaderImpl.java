/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.sl.impl;


import java.util.ArrayList;
import java.util.List;

import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.DateRange;


/**
 * Standard implementation of {@linkplain ProviderPlannedItemRateReader}
 */
public class ProviderPlannedItemRateReaderImpl implements
  ProviderPlannedItemRateReader {

  /**
   * {@inheritDoc}
   */
  public List<ProviderPlannedItemApplicableRate> retrieveProviderPlannedItemApplicableRates(
    long plannedItemID) throws AppException, InformationalException {
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    List<ProviderPlannedItemApplicableRate> providerPlannedItemRateList = new ArrayList<ProviderPlannedItemApplicableRate>();
    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = plannedItemID;
    PlannedItemDtls plannedItemDtls = plannedItemObj.read(plannedItemKey);

    DateRange actualDateRange = new DateRange(plannedItemDtls.actualStartDate,
      plannedItemDtls.actualEndDate);

    ProviderPlannedItemApplicableRate providerPlannedItemRate = new ProviderPlannedItemApplicableRate(
      actualDateRange, plannedItemDtls.rateAuthorized);

    providerPlannedItemRateList.add(providerPlannedItemRate);

    return providerPlannedItemRateList;
  }

}
