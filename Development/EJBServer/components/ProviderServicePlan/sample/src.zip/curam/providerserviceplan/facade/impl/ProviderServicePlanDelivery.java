/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.facade.impl;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.jdom.Attribute;
import org.jdom.DataConversionException;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.filter.ElementFilter;
import org.jdom.filter.Filter;
import org.jdom.output.XMLOutputter;

import com.google.inject.Inject;

import curam.codetable.ADDRESSELEMENTTYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.PLANITEMTYPE;
import curam.codetable.PLANNEDITEMSTATUS;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.fact.AddressDataFactory;
import curam.core.fact.CaseStatusFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.AddressData;
import curam.core.intf.CaseStatus;
import curam.core.intf.ConcernRole;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.DailyAttendanceFactory;
import curam.core.sl.entity.intf.DailyAttendance;
import curam.core.sl.entity.struct.DailyAttendanceDtls;
import curam.core.sl.entity.struct.DailyAttendanceKey;
import curam.core.sl.fact.UserRecentActionFactory;
import curam.core.sl.infrastructure.impl.ServicePlanGanttConst;
import curam.core.sl.intf.UserRecentAction;
import curam.core.sl.struct.UserRecentActionDetails;
import curam.core.struct.AddressFieldDetails;
import curam.core.struct.AddressMap;
import curam.core.struct.AddressMapList;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CurrentCaseStatusKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.OtherAddressData;
import curam.cpm.facade.struct.SearchProviderTypeResults;
import curam.cpm.facade.struct.SearchProviderTypeResultsList;
import curam.cpm.facade.struct.ServiceOfferingDetails;
import curam.cpm.sl.entity.fact.ServiceOfferingFactory;
import curam.cpm.sl.entity.intf.ServiceOffering;
import curam.cpm.sl.entity.struct.ProviderServiceOfferingSearchKey;
import curam.cpm.sl.entity.struct.ProviderServiceOfferingSearchResults;
import curam.cpm.sl.entity.struct.ProviderServiceOfferingSearchResultsList;
import curam.cpm.sl.entity.struct.ServiceOfferingKey;
import curam.cpm.sl.entity.struct.providerTypeSearchKey;
import curam.message.BPOBASELINE;
import curam.message.BPOMAINTAINSERVICEPLANDELIVERY;
import curam.message.BPOPROVIDERPLANNEDITEM;
import curam.message.PROVIDER;
import curam.provider.ProviderTypeName;
import curam.provider.impl.ProviderTypeNameEntry;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerserviceplan.facade.fact.ProviderServicePlanDeliveryFactory;
import curam.providerserviceplan.facade.struct.BaselineProviderPlannedItemDetails;
import curam.providerserviceplan.facade.struct.GanttChartDeliveryParamDetails;
import curam.providerserviceplan.facade.struct.ModifyProviderPlannedItemDetails;
import curam.providerserviceplan.facade.struct.ProviderPlannedItemDetails;
import curam.providerserviceplan.facade.struct.ProviderSearchResultsList;
import curam.providerserviceplan.facade.struct.ViewProviderPlannedItemDetails;
import curam.providerserviceplan.sl.entity.fact.BaselinePlanItemProviderLinkFactory;
import curam.providerserviceplan.sl.entity.fact.ProviderPlannedItemLinkFactory;
import curam.providerserviceplan.sl.entity.intf.BaselinePlanItemProviderLink;
import curam.providerserviceplan.sl.entity.intf.ProviderPlannedItemLink;
import curam.providerserviceplan.sl.entity.struct.BaselinePlanItemProviderLinkDtls;
import curam.providerserviceplan.sl.entity.struct.ProviderPlannedItemLinkDtls;
import curam.providerserviceplan.sl.entity.struct.ProviderPlannedItemLinkDtlsList;
import curam.providerserviceplan.sl.entity.struct.ProviderPlannedItemLinkKey;
import curam.providerserviceplan.sl.entity.struct.ProviderPlannedItemLinkReadmultiKey;
import curam.providerserviceplan.sl.fact.MaintainServicePlanDocGenerationFactory;
import curam.providerserviceplan.sl.fact.ProviderPlannedItemFactory;
import curam.providerserviceplan.sl.intf.MaintainServicePlanDocGeneration;
import curam.providerserviceplan.sl.intf.ProviderPlannedItem;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.serviceoffering.impl.UnitOfMeasureEntry;
import curam.serviceplans.facade.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.facade.intf.ServicePlanDelivery;
import curam.serviceplans.facade.struct.AddClientParticipationDetails;
import curam.serviceplans.facade.struct.AddTemplateDetails;
import curam.serviceplans.facade.struct.BaselineGanttDetails;
import curam.serviceplans.facade.struct.BaselineKey;
import curam.serviceplans.facade.struct.BaselineReturnKey;
import curam.serviceplans.facade.struct.CreateBaselineDetails;
import curam.serviceplans.facade.struct.ICServicePlanDeliveryMenuDataDetails;
import curam.serviceplans.facade.struct.ModifyClientParticipationDetails;
import curam.serviceplans.facade.struct.ModifyPlanItemReturnStruct;
import curam.serviceplans.facade.struct.PlanItemKey;
import curam.serviceplans.facade.struct.PlannedItemAbsenceDetails;
import curam.serviceplans.facade.struct.PlannedItemAbsenceDetailsList;
import curam.serviceplans.facade.struct.PlannedItemIDAndNameDetailsList;
import curam.serviceplans.facade.struct.PlannedItemIDKey;
import curam.serviceplans.facade.struct.PlannedSubGoalAndCaseIDStruct;
import curam.serviceplans.facade.struct.PlannedSubGoalKey;
import curam.serviceplans.facade.struct.ReadCompleteContractDetails;
import curam.serviceplans.facade.struct.SPDeliveryContextDescription;
import curam.serviceplans.facade.struct.ServicePlanContractKey;
import curam.serviceplans.facade.struct.ServicePlanDeliveryHomeDetails;
import curam.serviceplans.facade.struct.ServicePlanDeliveryHomePageDetails;
import curam.serviceplans.facade.struct.ServicePlanDeliveryHomePageDetails1;
import curam.serviceplans.facade.struct.ServicePlanDeliveryKey;
import curam.serviceplans.facade.struct.ServicePlanIntegratedCaseKey;
import curam.serviceplans.facade.struct.TrackingGanttDetails;
import curam.serviceplans.facade.struct.ViewBaselinePlannedItemDetails;
import curam.serviceplans.facade.struct.ViewPlannedItemDetailsStruct;
import curam.serviceplans.sl.entity.fact.PIDailyAttendanceLinkFactory;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.intf.PIDailyAttendanceLink;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.struct.BaselinePlanItemByBaselineSubGoalIDDetails;
import curam.serviceplans.sl.entity.struct.BaselinePlanItemByBaselineSubGoalIDDetailsList;
import curam.serviceplans.sl.entity.struct.BaselinePlanItemKey;
import curam.serviceplans.sl.entity.struct.BaselineSubGoalByBaselineIDDetails;
import curam.serviceplans.sl.entity.struct.BaselineSubGoalByBaselineIDDetailsList;
import curam.serviceplans.sl.entity.struct.BaselineSubGoalKey;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkDtlsList;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanItemTypeCodeDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedItemDetailsStruct;
import curam.serviceplans.sl.fact.TrackingGanttFactory;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.serviceplans.sl.intf.TrackingGantt;
import curam.serviceplans.sl.struct.ViewPlannedItemDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.StringUtil;
import curam.util.resources.XMLUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.NotFoundIndicator;


/**
 * This process class provides the facade for Provider Service Plans
 *
 */

public abstract class ProviderServicePlanDelivery implements
  curam.providerserviceplan.facade.intf.ProviderServicePlanDelivery {

  /**
   * Injecting the Data Access Object for ProviderOfferingDAO class.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  // BEGIN, CR00274074, GYH
  /**
   * Injecting the Data Access Object for ServiceOfferingDAO class.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  // END, CR00274074

  /**
   * Default constructor.
   */
  public ProviderServicePlanDelivery() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);

  }

  // ___________________________________________________________________________
  /**
   * View details of a planned item.
   *
   * @param PlannedItemIDKey
   * details of the plan item to be added.
   *
   * @return ViewPlannedItemDetailsStruct
   *
   * @throws AppException
   * , InformationalException
   */

  public ViewProviderPlannedItemDetails viewPlannedItem(PlannedItemIDKey key)
    throws AppException, InformationalException {

    // Manipulation variables
    ViewPlannedItemDetailsStruct viewPlannedItemDetailsStruct = new ViewPlannedItemDetailsStruct();
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();
    ServicePlanDelivery servicePlanDelivery = ServicePlanDeliveryFactory.newInstance();
    ProviderPlannedItem providerPlannedItemObj = ProviderPlannedItemFactory.newInstance();
    // BEGIN, CR00116058, ANK
    // PlannedItem business object
    curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();
    // END, CR00116058
    // BEGIN, CR00116214, ANK
    PlanItemKey planItemKey = new PlanItemKey();
    ViewProviderPlannedItemDetails viewProviderPlannedItemDetails = new ViewProviderPlannedItemDetails();

    // END, CR00116214

    ServicePlanSecurityImplementationFactory.register();

    try {
      // Read planned item details
      viewPlannedItemDetailsStruct.plannedItemDetails = providerPlannedItemObj.readPlannedItemDetails(
        key.plannedItemIDKey);
    } catch (RecordNotFoundException e) {
      throw new AppException(
        BPOBASELINE.BASELINE_PLAN_ITEM_RV_PLANNED_ITEM_DELETED);
    }

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = viewPlannedItemDetailsStruct.plannedItemDetails.caseID;

    // getting the service plan context description
    viewPlannedItemDetailsStruct.description = servicePlanDelivery.getServicePlanContextDescription(
      servicePlanDeliveryKey);

    // BEGIN, CR00116058, ANK
    viewPlannedItemDetailsStruct.participants.list = plannedItemObj.getResponsibleParticipantsForPlannedItem(key.plannedItemIDKey).list;
    // END, CR00116058

    // BEGIN, CR00116214, ANK
    planItemKey.key.key.planItemID = viewPlannedItemDetailsStruct.plannedItemDetails.plannedItemDtls.planItemID;

    viewProviderPlannedItemDetails.plannedItemDetails.assign(
      viewPlannedItemDetailsStruct);

    // BEGIN, CR00123487, MC
    if (viewPlannedItemDetailsStruct.plannedItemDetails.plannedItemDtls.nomineeID
      != 0) {

      ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      concernRoleKey.concernRoleID = viewPlannedItemDetailsStruct.plannedItemDetails.plannedItemDtls.nomineeID;
      viewProviderPlannedItemDetails.nomineeName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
      viewProviderPlannedItemDetails.nomineeType = concernRoleObj.readConcernRoleType(concernRoleKey).concernRoleType;
    }
    // END, CR00123487

    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    ProviderPlannedItemLinkDtls providerPlannedItemLinkDtls = null;

    // BEGIN, CR00123918, MC
    try {
      providerPlannedItemLinkDtls = providerPlannedItemLinkObj.readByPlannedItemID(
        key.plannedItemIDKey.plannedItemIDKey);
      viewProviderPlannedItemDetails.viewProviderPlanItemLink.assign(
        providerPlannedItemLinkDtls);

    } catch (RecordNotFoundException ex) {
      viewProviderPlannedItemDetails.isPlanItemApproved = false;
    }
    // END, CR00123918

    if (providerPlannedItemLinkDtls != null) {

      viewProviderPlannedItemDetails.viewProviderPlanItemLink.assign(
        providerPlannedItemLinkDtls);

      viewProviderPlannedItemDetails.serviceOfferingName = populateServiceOfferingName(
        viewProviderPlannedItemDetails.viewProviderPlanItemLink.serviceOfferingID);

      viewProviderPlannedItemDetails.providerTypeName = CodeTable.getOneItem(
        ProviderTypeNameEntry.TABLENAME,
        viewProviderPlannedItemDetails.viewProviderPlanItemLink.providerTypeCode);

      viewProviderPlannedItemDetails.providerName = populateProviderName(
        viewProviderPlannedItemDetails.viewProviderPlanItemLink.providerConcernRoleID);

      viewProviderPlannedItemDetails.unitOfMeasure = populateUnitOfMeasure(
        viewProviderPlannedItemDetails.viewProviderPlanItemLink.serviceOfferingID);

      if (providerPlannedItemLinkDtls.serviceAuthorizationID != 0) {
        viewProviderPlannedItemDetails.isPlanItemApproved = true;
      } else {
        viewProviderPlannedItemDetails.isPlanItemApproved = false;
      }

    }

    return viewProviderPlannedItemDetails;
    // END, CR00116214
  }

  // ___________________________________________________________________________
  /**
   * Adds a planned item to a planned subgoal.
   *
   * @param ProviderPlannedItemDetailsStruct
   * details of the plan item to be added.
   *
   * @throws AppException
   * , InformationalException
   */

  public void addPlannedItem(
    ProviderPlannedItemDetails providerPlannedItemDetails)
    throws AppException, InformationalException {

    // Registering the operation for Service Plan Security
    ServicePlanSecurityImplementationFactory.register();

    // Provider Planned Item Service Layer object
    ProviderPlannedItem providerPlannedItem = ProviderPlannedItemFactory.newInstance();

    // Creating the Planned item
    providerPlannedItem.createPlannedItem(
      providerPlannedItemDetails.plannedItemDetails);

    // Creating the referral attachment if the attachment name is specified
    createReferralAttachment(providerPlannedItemDetails);

    // Create Provider Planned Item Entry
    createProviderPlannedItem(providerPlannedItemDetails);

    providerPlannedItem.createSALI(
      providerPlannedItemDetails.plannedItemDetails.plannedItemDtls);
  }

  // ___________________________________________________________________________
  /**
   * Method to insert provider planned item referral attachment details
   *
   * @param providerPlannedItemDetails
   * - Provider planned item details to be created
   * @throws AppException
   * @throws InformationalException
   */
  protected void createReferralAttachment(
    ProviderPlannedItemDetails providerPlannedItemDetails)
    throws AppException, InformationalException {

    // Service Plan Delivery object from core
    ServicePlanDelivery servicePlanDelivery = ServicePlanDeliveryFactory.newInstance();

    if (providerPlannedItemDetails.attachmentDetails.attachmentName != null
      && providerPlannedItemDetails.attachmentDetails.attachmentName.length()
        > 0) {

      // Getting the planned item newly created
      providerPlannedItemDetails.attachmentDetails.plannedItemID = providerPlannedItemDetails.plannedItemDetails.plannedItemDtls.plannedItemID;

      // Setting the default description for referral attachment
      providerPlannedItemDetails.attachmentDetails.description = BPOPROVIDERPLANNEDITEM.INF_INITIAL_DESCRIPTION_FOR_REFERRAL_ATTACHMENT.getMessageText();

      // create the attachment record
      servicePlanDelivery.createAttachment(
        providerPlannedItemDetails.attachmentDetails);
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to insert provider planned item link entry
   *
   * @param providerPlannedItemDetails
   * - Provider planned item details to be created
   * @throws AppException
   * @throws InformationalException
   */
  protected void createProviderPlannedItem(
    ProviderPlannedItemDetails providerPlannedItemDetails)
    throws AppException, InformationalException {

    // Provider Planned Item Service Layer object
    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    // BEGIN, CR00119913, ANK
    // Validate the details before creating new Planned Item
    validatePlannedItemDetails(
      providerPlannedItemDetails.providerPlannedItemLink,
      providerPlannedItemDetails.plannedItemDetails.plannedItemDtls);
    // END, CR00119913

    // Manipulation variables
    UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    providerPlannedItemDetails.providerPlannedItemLink.providerPlannedItemLinkID = uniqueIDObj.getNextID();

    providerPlannedItemDetails.providerPlannedItemLink.plannedItemID = providerPlannedItemDetails.plannedItemDetails.plannedItemDtls.plannedItemID;

    providerPlannedItemDetails.providerPlannedItemLink.plannedSubGoalID = providerPlannedItemDetails.plannedItemDetails.plannedItemDtls.plannedSubGoalID;

    // Insert the Provider Planned Item Link Details
    providerPlannedItemLinkObj.insert(
      providerPlannedItemDetails.providerPlannedItemLink);

  }

  // BEGIN, CR00119913, ANK
  // ___________________________________________________________________________
  /**
   * Method to validate planned item details
   *
   * @param ProviderPlannedItemLinkDtls
   * - Provider planned item link details
   * @param PlannedItemDtls
   * - Core planned item details
   * @throws AppException
   * @throws InformationalException
   */
  public void validatePlannedItemDetails(
    ProviderPlannedItemLinkDtls providerPlannedItemLinkDtls,
    PlannedItemDtls plannedItemDtls) throws AppException,
      InformationalException {

    // BEGIN, CR00128415 , ANK
    // Units authorized and Rate Authorized shouldn't be changed if the
    // planned item status is completed
    validateFieldsIfStatusCompleted(plannedItemDtls);
    // END, CR00128415

    if (plannedItemDtls.authorizedUnits <= 0) {
      AppException e = new AppException(
        BPOPROVIDERPLANNEDITEM.ERR_PLANITEM_FV_UNITS_AUTHORIZED_CANNOT_BE_ZERO);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (providerPlannedItemLinkDtls.providerConcernRoleID != 0
      && providerPlannedItemLinkDtls.serviceOfferingID != 0) {

      Set<ProviderOffering> providerOfferingList = providerOfferingDAO.searchProviderOffering(
        providerPlannedItemLinkDtls.providerConcernRoleID,
        providerPlannedItemLinkDtls.serviceOfferingID);

      if (providerOfferingList.size() == 0) {
        AppException e = new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_SERVICEPLAN_FV_NO_PROVIDER_OFFERING_FOUND);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
      }

      /*
       * The system shall ensure while saving the planned item that the provider
       * offering of the provider in CPM must have a Start Date before the
       * Expected Start Date of the planned item and no end date, or an end date
       * that is greater than or equal to the Expected End Date of the planned
       * item.
       */
      DateRange plannedItemDateRange = new DateRange(
        plannedItemDtls.expectedStartDate, plannedItemDtls.expectedEndDate);

      Date startDate = plannedItemDateRange.start();
      Date endDate = plannedItemDateRange.end();

      for (ProviderOffering providerOffering : providerOfferingList) {

        // BEGIN, CR00132550, ANK
        // Validate if the provider offering start date is after the
        // planned item start date
        if (providerOffering.getDateRange().startsAfter(startDate)) {

          AppException e = new AppException(
            BPOPROVIDERPLANNEDITEM.ERR_PLANITEM_FV_PROVIDER_OFFERING_STARTDATE_IS_NOT_BEFORE);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
        }

        // Validate if the provider offering end date is before the
        // planned item end date
        if (providerOffering.getDateRange().endsBefore(endDate)) {

          AppException e = new AppException(
            BPOPROVIDERPLANNEDITEM.ERR_PLANITEM_FV_PROVIDER_OFFERING_ENDDATE_IS_NOT_AFTER);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
        }

        // Validate if the provider offering start and end dates
        // doesn't overlaps with planned item dates
        if (!providerOffering.getDateRange().overlapsWith(plannedItemDateRange)) {
          AppException e = new AppException(
            BPOPROVIDERPLANNEDITEM.ERR_SERVICEPLAN_FV_NO_PROVIDER_OFFERING_FOUND_FOR_DATERANGE);

          e.arg(plannedItemDtls.expectedStartDate);
          e.arg(plannedItemDtls.expectedEndDate);
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
        }
        // END, CR00132550
      }
    }
  }

  // END, CR00119913

  // BEGIN, CR00128415 , ANK
  // ___________________________________________________________________________
  /**
   * Method to validate the fields if the plan item status is completed
   *
   * @param plannedItemDtls
   * @throws AppException
   * @throws InformationalException
   */
  protected void validateFieldsIfStatusCompleted(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {

    PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();
    ViewProviderPlannedItemDetails viewProviderPlannedItemDetails = new ViewProviderPlannedItemDetails();

    // Units authorized and Rate Authorized shouldn't be changed if the
    // planned item status is completed
    plannedItemIDKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemDtls.plannedItemID;

    boolean isUnitsOrRateAuthorizedChanged = false;

    viewProviderPlannedItemDetails = viewPlannedItem(plannedItemIDKey);

    if (viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.authorizedUnits
      != plannedItemDtls.authorizedUnits) {
      isUnitsOrRateAuthorizedChanged = true;
    }
    if (viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.rateAuthorized
      != plannedItemDtls.rateAuthorized) {
      isUnitsOrRateAuthorizedChanged = true;
    }
    if (plannedItemDtls.status.equals(PLANNEDITEMSTATUS.COMPLETED)
      && isUnitsOrRateAuthorizedChanged) {
      AppException e = new AppException(
        BPOPROVIDERPLANNEDITEM.ERR_PLANITEM_IN_COMPLETED_STATE_CANNOT_BE_MODIFIED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  // END, CR00128415

  // ___________________________________________________________________________
  /**
   * Modifies the service plan planItem.
   *
   * @param modifyPlannedItemDetailsStruct
   * details to be modified.
   *
   * @return ModifyPlanItemReturnStruct
   *
   * @throws AppException
   * , InformationalException
   */

  public ModifyPlanItemReturnStruct modifyProviderServicePlannedItem(
    ModifyProviderPlannedItemDetails modifyProviderPlannedItemDetails)
    throws AppException, InformationalException {

    // Manipulation Variables
    ModifyPlanItemReturnStruct modifyPlanItemReturnStruct = new ModifyPlanItemReturnStruct();

    ProviderPlannedItem providerPlannedItemObj = ProviderPlannedItemFactory.newInstance();

    // Registering the operation for Service Plan Security
    ServicePlanSecurityImplementationFactory.register();

    // BEGIN, CR00119913, ANK
    // Validate the details before creating new Planned Item
    validatePlannedItemDetails(
      modifyProviderPlannedItemDetails.modifyProviderPlanLink,
      modifyProviderPlannedItemDetails.plannedItemDetails.modifyPlannedItemDetailsStruct.plannedItemDtls);
    // END, CR00119913

    if (modifyProviderPlannedItemDetails.modifyProviderPlanLink.providerPlannedItemLinkID
      == 0) {
      ProviderPlannedItemDetails providerPlannedItemDtls = new ProviderPlannedItemDetails();

      providerPlannedItemDtls.plannedItemDetails.plannedItemDtls.assign(
        modifyProviderPlannedItemDetails.plannedItemDetails.modifyPlannedItemDetailsStruct.plannedItemDtls);
      providerPlannedItemDtls.providerPlannedItemLink.assign(
        modifyProviderPlannedItemDetails.modifyProviderPlanLink);

      createProviderPlannedItem(providerPlannedItemDtls);
    }

    // Modify the Provider Planned Item Link Entity
    if (modifyProviderPlannedItemDetails.modifyProviderPlanLink.providerPlannedItemLinkID
      != 0) {
      modifyProviderPlannedItemLink(modifyProviderPlannedItemDetails);
    }

    // Modify Core Planned Item Entity
    modifyPlanItemReturnStruct = providerPlannedItemObj.modifyPlannedItem(
      modifyProviderPlannedItemDetails.plannedItemDetails.modifyPlannedItemDetailsStruct);

    return modifyPlanItemReturnStruct;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the provider planned item link entity.
   *
   * @param modifyPlannedItemDetailsStruct
   * details to be modified.
   *
   * @return ModifyPlanItemReturnStruct
   *
   * @throws AppException
   * , InformationalException
   */
  protected void modifyProviderPlannedItemLink(
    ModifyProviderPlannedItemDetails modifyProviderPlannedItemDetails)
    throws AppException, InformationalException {

    // Manipulation variables
    ProviderPlannedItemLinkKey providerPlannedItemLinkKey = new ProviderPlannedItemLinkKey();
    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    // Reading the Provider Planned Item Link key
    providerPlannedItemLinkKey.providerPlannedItemLinkID = modifyProviderPlannedItemDetails.modifyProviderPlanLink.providerPlannedItemLinkID;

    // Assigning the variables
    modifyProviderPlannedItemDetails.modifyProviderPlanLink.plannedItemID = modifyProviderPlannedItemDetails.plannedItemDetails.modifyPlannedItemDetailsStruct.plannedItemDtls.plannedItemID;

    modifyProviderPlannedItemDetails.modifyProviderPlanLink.plannedSubGoalID = modifyProviderPlannedItemDetails.plannedItemDetails.modifyPlannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

    modifyProviderPlannedItemDetails.modifyProviderPlanLink.serviceAuthorizationID = providerPlannedItemLinkObj.read(providerPlannedItemLinkKey).serviceAuthorizationID;

    providerPlannedItemLinkObj.modify(providerPlannedItemLinkKey,
      modifyProviderPlannedItemDetails.modifyProviderPlanLink);
  }

  // ___________________________________________________________________________
  /**
   * Deletes the service plan planItem.
   *
   * @param plannedItemIDKey
   * plannedItem to be modified.
   *
   * @return PlannedSubGoalAndCaseIDStruct
   *
   * @throws AppException
   * , InformationalException
   */

  public PlannedSubGoalAndCaseIDStruct deleteProviderPlannedItem(
    PlannedItemIDKey plannedItemIDKey) throws AppException,
      InformationalException {

    // Registering the operation for Service Plan Security
    ServicePlanSecurityImplementationFactory.register();

    // PlannedItem business object
    curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    ViewPlannedItemDetails viewPlannedItemDetailsStruct = plannedItemObj.readPlannedItemDetails(
      plannedItemIDKey.plannedItemIDKey);

    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = plannedItemIDKey.plannedItemIDKey.plannedItemIDKey.plannedItemID;

    // Return struct
    PlannedSubGoalAndCaseIDStruct plannedSubGoalAndCaseIDStruct = new PlannedSubGoalAndCaseIDStruct();

    plannedSubGoalAndCaseIDStruct.caseID = viewPlannedItemDetailsStruct.caseID;

    plannedSubGoalAndCaseIDStruct.plannedSubGoalID = viewPlannedItemDetailsStruct.plannedItemDtls.plannedSubGoalID;

    // remove related service authorization
    ProviderPlannedItem providerPlannedItem = ProviderPlannedItemFactory.newInstance();

    providerPlannedItem.cancelServiceAuthorizationLineItem(
      plannedItemIDKey.plannedItemIDKey);

    // Delete the planned item
    plannedItemObj.removeServicePlanPlanItem(plannedItemIDKey.plannedItemIDKey);

    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    try {
      providerPlannedItemLinkObj.removeByPlannedItem(plannedItemKey);
    } catch (RecordNotFoundException ex) {// Currently no records exist for this
      // planned item
    }

    return plannedSubGoalAndCaseIDStruct;

  }

  // BEGIN CR00109139, PN
  // ___________________________________________________________________________
  /**
   * Method used for getting service offering details for selected service
   * planned Item.
   *
   * @param plan
   * Item ID unique id of the plan item
   *
   * @return Service Offering Details
   *
   * @throws AppException
   * ,InformationalException
   */
  public ServiceOfferingDetails getServiceOfferingDetailsForPlannedItem(
    PlanItemKey key) throws AppException, InformationalException {

    // Return object having service offering details
    ServiceOfferingDetails serviceOfferingDetails = new ServiceOfferingDetails();

    // Register the Service Plan Security Implementation for this method:
    ServicePlanSecurityImplementationFactory.register();

    // Service component for getting service offering details
    ProviderPlannedItem providerPlannedItemObj = ProviderPlannedItemFactory.newInstance();

    // Get service offering details
    serviceOfferingDetails.serviceOfferingDetails = providerPlannedItemObj.getServiceOfferingDetailsForPlannedItem(
      key.key);

    return serviceOfferingDetails;
  }

  // END CR00109139

  // BEGIN, CR00118042, ANK
  // ___________________________________________________________________________
  /**
   * Creates the new Service Plan Baseline and Returns the key of the newly
   * created baseline.
   *
   * @param details
   * Contains the baseline details
   *
   * @return Key of the created baseline
   * @throws AppException
   * @throws InformationalException
   */
  public BaselineReturnKey createBaseline(CreateBaselineDetails details)
    throws AppException, InformationalException {
    BaselineReturnKey baselineReturnKey = new BaselineReturnKey();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();
    ServicePlanDelivery servicePlanDelivery = ServicePlanDeliveryFactory.newInstance();

    // Create the core baseline
    baselineReturnKey = servicePlanDelivery.createServicePlanBaseline(details);

    // Manipulation variables
    curam.serviceplans.sl.entity.intf.BaselineSubGoal baselineSubGoalObj = curam.serviceplans.sl.entity.fact.BaselineSubGoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.BaselineKey baselineKey = new curam.serviceplans.sl.entity.struct.BaselineKey();
    curam.serviceplans.sl.entity.intf.BaselinePlanItem baselinePlanItemObj = curam.serviceplans.sl.entity.fact.BaselinePlanItemFactory.newInstance();

    baselineKey.baseLineID = baselineReturnKey.returnKey.baselineIDDetails.baseLineID;
    BaselineSubGoalByBaselineIDDetailsList baselineSubGoalByBaselineIDDetailsList = baselineSubGoalObj.searchSubGoalsByBaselineID(
      baselineKey);

    // BEGIN, CR00292716, SK
    for (final BaselineSubGoalByBaselineIDDetails baselineSubGoalByBaselineIDDetails : baselineSubGoalByBaselineIDDetailsList.dtls.items()) {

      // Manipulation variables
      UniqueID uniqueIDObj = UniqueIDFactory.newInstance();
      BaselinePlanItemProviderLinkDtls baselinePlanItemProviderLinkDtls = new BaselinePlanItemProviderLinkDtls();
      BaselinePlanItemProviderLink baselinePlanItemProviderLinkObj = BaselinePlanItemProviderLinkFactory.newInstance();
      ProviderPlannedItemLinkReadmultiKey providerPlannedItemReadmultiKey = new ProviderPlannedItemLinkReadmultiKey();
      ProviderPlannedItemLinkDtlsList providerPlannedItemLinkDtlsList = new ProviderPlannedItemLinkDtlsList();
      int providerPlannedItemLinkDtlsListSize = 0;

      ProviderPlannedItemLinkKey providerPlannedItemKey = new ProviderPlannedItemLinkKey();

      ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

      providerPlannedItemReadmultiKey.plannedSubGoalID = baselineSubGoalByBaselineIDDetails.plannedSubGoalID;

      // provider planned item link entity based on the sub goal id
      providerPlannedItemLinkDtlsList = providerPlannedItemLinkObj.searchByPlannedSubGoalID(
        providerPlannedItemReadmultiKey);

      providerPlannedItemLinkDtlsListSize = providerPlannedItemLinkDtlsList.dtls.size();
      PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

      ViewProviderPlannedItemDetails viewProviderPlannedItemDetails = new ViewProviderPlannedItemDetails();

      // Create baseline of entries in provider planned item link entity;
      for (int i = 0; i < providerPlannedItemLinkDtlsListSize; i++) {

        plannedItemIDKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = providerPlannedItemLinkDtlsList.dtls.item(i).plannedItemID;

        viewProviderPlannedItemDetails = viewPlannedItem(plannedItemIDKey);
        providerPlannedItemKey.providerPlannedItemLinkID = viewProviderPlannedItemDetails.viewProviderPlanItemLink.providerPlannedItemLinkID;
        providerPlannedItemLinkObj.read(providerPlannedItemKey);
        baselinePlanItemProviderLinkDtls.baseLineID = baselineKey.baseLineID;
        
        BaselineSubGoalKey baselineSubGoalKey = new BaselineSubGoalKey();

        baselineSubGoalKey.baselineSubGoalID = baselineSubGoalByBaselineIDDetails.baselineSubGoalID;
        BaselinePlanItemByBaselineSubGoalIDDetailsList baselinePlanItemByBaselineSubGoalIDDetailsList = baselinePlanItemObj.searchByBaselineSubGoalID(
          baselineSubGoalKey);

        for (final BaselinePlanItemByBaselineSubGoalIDDetails baselinePlanItemByBaselineSubGoalIDDetails : baselinePlanItemByBaselineSubGoalIDDetailsList.dtls.items()) {
          if (baselinePlanItemByBaselineSubGoalIDDetails.plannedItemID
            == providerPlannedItemLinkDtlsList.dtls.item(i).plannedItemID) {
            baselinePlanItemProviderLinkDtls.baselinePlanItemID = baselinePlanItemByBaselineSubGoalIDDetails.baselinePlanItemID;
          }
        }

        baselinePlanItemProviderLinkDtls.baselinePlanItemProviderLinkID = uniqueIDObj.getNextID();

        baselinePlanItemProviderLinkDtls.assign(
          providerPlannedItemLinkDtlsList.dtls.item(i));

        baselinePlanItemProviderLinkDtls.unitOfMeasure = viewProviderPlannedItemDetails.unitOfMeasure;
        baselinePlanItemProviderLinkDtls.serviceOfferingName = viewProviderPlannedItemDetails.serviceOfferingName;
        baselinePlanItemProviderLinkDtls.providerName = viewProviderPlannedItemDetails.providerName;
        baselinePlanItemProviderLinkDtls.providerTypeName = viewProviderPlannedItemDetails.providerTypeName;
        baselinePlanItemProviderLinkDtls.nomineeName = viewProviderPlannedItemDetails.nomineeName;

        baselinePlanItemProviderLinkDtls.nomineeID = viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.nomineeID;
        baselinePlanItemProviderLinkDtls.frequency = viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.frequency;
        baselinePlanItemProviderLinkDtls.unitsDelivered = viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.unitsDelivered;
        baselinePlanItemProviderLinkDtls.rateAuthorized = viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.rateAuthorized;
        baselinePlanItemProviderLinkDtls.totalUnitsAuthorized = viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.totalUnitsAuthorized;
        baselinePlanItemProviderLinkDtls.referralReason = viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.referralReason;

        baselinePlanItemProviderLinkObj.insert(baselinePlanItemProviderLinkDtls);
        // END, CR00292716
      }
    }
    return baselineReturnKey;
  }

  /**
   * @return
   * @throws AppException
   * @throws InformationalException
   */
  protected boolean isServiceOrCustomServicePlanItem(
    PlannedItemKey plannedItemKey) throws AppException,
      InformationalException {
    // Planned Item manipulation variables
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    PlanItemTypeCodeDetails planItemTypeCodeDetails = new PlanItemTypeCodeDetails();
    boolean isServiceOrCustomServicePlanItemFlag = false;

    // Read the plan item type
    planItemTypeCodeDetails = plannedItemObj.readPlanItemTypeCodeByPlannedItemID(
      plannedItemKey);

    if (planItemTypeCodeDetails.typeCode.equals(PLANITEMTYPE.SERVICEPLANITEM)
      || planItemTypeCodeDetails.typeCode.equals(
        PLANITEMTYPE.CUSTOMSERVICEPLANITEM)) {
      isServiceOrCustomServicePlanItemFlag = true;
    }
    return isServiceOrCustomServicePlanItemFlag;
  }

  // ___________________________________________________________________________
  /**
   * Method create base baseline of Provider Planned Item
   *
   * @param baselineKey
   * - key of the baseline created
   * @param plannedSubGoalID
   * - sub goal id of which the baseline created
   * @throws AppException
   * @throws InformationalException
   */
  protected void createBaselinePlanItemProviderLink(
    curam.serviceplans.sl.entity.struct.BaselineKey baselineKey,
    long plannedSubGoalID) throws AppException, InformationalException {

    // Manipulation variables
    UniqueID uniqueIDObj = UniqueIDFactory.newInstance();
    BaselinePlanItemProviderLinkDtls baselinePlanItemProviderLinkDtls = new BaselinePlanItemProviderLinkDtls();
    BaselinePlanItemProviderLink baselinePlanItemProviderLinkObj = BaselinePlanItemProviderLinkFactory.newInstance();
    ProviderPlannedItemLinkReadmultiKey providerPlannedItemReadmultiKey = new ProviderPlannedItemLinkReadmultiKey();
    ProviderPlannedItemLinkDtlsList providerPlannedItemLinkDtlsList = new ProviderPlannedItemLinkDtlsList();
    int providerPlannedItemLinkDtlsListSize = 0;

    ProviderPlannedItemLinkKey providerPlannedItemKey = new ProviderPlannedItemLinkKey();

    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    providerPlannedItemReadmultiKey.plannedSubGoalID = plannedSubGoalID;

    // provider planned item link entity based on the sub goal id
    providerPlannedItemLinkDtlsList = providerPlannedItemLinkObj.searchByPlannedSubGoalID(
      providerPlannedItemReadmultiKey);

    providerPlannedItemLinkDtlsListSize = providerPlannedItemLinkDtlsList.dtls.size();
    PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    ViewProviderPlannedItemDetails viewProviderPlannedItemDetails = new ViewProviderPlannedItemDetails();

    // Create baseline of entries in provider planned item link entity;
    for (int i = 0; i < providerPlannedItemLinkDtlsListSize; i++) {

      plannedItemIDKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = providerPlannedItemLinkDtlsList.dtls.item(i).plannedItemID;

      viewProviderPlannedItemDetails = viewPlannedItem(plannedItemIDKey);
      providerPlannedItemKey.providerPlannedItemLinkID = viewProviderPlannedItemDetails.viewProviderPlanItemLink.providerPlannedItemLinkID;
      providerPlannedItemLinkObj.read(providerPlannedItemKey);
      baselinePlanItemProviderLinkDtls.baseLineID = baselineKey.baseLineID;

      baselinePlanItemProviderLinkDtls.baselinePlanItemID = providerPlannedItemLinkDtlsList.dtls.item(i).plannedItemID;

      baselinePlanItemProviderLinkDtls.baselinePlanItemProviderLinkID = uniqueIDObj.getNextID();

      baselinePlanItemProviderLinkDtls.assign(
        providerPlannedItemLinkDtlsList.dtls.item(i));

      baselinePlanItemProviderLinkDtls.unitOfMeasure = viewProviderPlannedItemDetails.unitOfMeasure;
      baselinePlanItemProviderLinkDtls.serviceOfferingName = viewProviderPlannedItemDetails.serviceOfferingName;
      baselinePlanItemProviderLinkDtls.providerName = viewProviderPlannedItemDetails.providerName;
      baselinePlanItemProviderLinkDtls.providerTypeName = viewProviderPlannedItemDetails.providerTypeName;
      baselinePlanItemProviderLinkDtls.nomineeName = viewProviderPlannedItemDetails.nomineeName;

      baselinePlanItemProviderLinkDtls.nomineeID = viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.nomineeID;
      baselinePlanItemProviderLinkDtls.frequency = viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.frequency;
      baselinePlanItemProviderLinkDtls.unitsDelivered = viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.unitsDelivered;
      baselinePlanItemProviderLinkDtls.rateAuthorized = viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.rateAuthorized;
      baselinePlanItemProviderLinkDtls.totalUnitsAuthorized = viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.totalUnitsAuthorized;
      baselinePlanItemProviderLinkDtls.referralReason = viewProviderPlannedItemDetails.plannedItemDetails.plannedItemDetails.plannedItemDtls.referralReason;

      baselinePlanItemProviderLinkObj.insert(baselinePlanItemProviderLinkDtls);
    }
  }

  // ___________________________________________________________________________
  /**
   * Removes the Service Plan Baseline and corresponding details
   *
   * @param Key
   * of the created baseline
   * @throws AppException
   * @throws InformationalException
   */
  public void removeBaseline(BaselineKey baselineKey) throws AppException,
      InformationalException {

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();
    ServicePlanDelivery servicePlanDelivery = ServicePlanDeliveryFactory.newInstance();

    // Remove the core service plan baseline
    servicePlanDelivery.removeServicePlanBaseline(baselineKey);

    BaselinePlanItemProviderLink baselinePlanItemProviderLinkObj = BaselinePlanItemProviderLinkFactory.newInstance();

    try {
      // Remove the corresponding provider planned item baseline
      baselinePlanItemProviderLinkObj.removeByBaseline(
        baselineKey.key.baselineKey);
    } catch (RecordNotFoundException e) {// Don't do anything if there are no
      // baseline records to delete
    }
  }

  // ___________________________________________________________________________
  /**
   * Removes the SubGoal and the corresponding planned item of a Service Plan
   *
   * @param Key
   * of the planned subgoal
   * @throws AppException
   * @throws InformationalException
   */

  public void removeSubGoal(PlannedSubGoalKey plannedSubGoalKey)
    throws AppException, InformationalException {
    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();
    ServicePlanDelivery servicePlanDelivery = ServicePlanDeliveryFactory.newInstance();

    curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalIDKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();

    plannedSubGoalIDKey.plannedSubGoalID = plannedSubGoalKey.plannedSubGoalKey.key.plannedSubGoalID;
    // Remove the core service plan subgoal
    servicePlanDelivery.removePlannedSubGoal(plannedSubGoalKey);

    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    try {
      // Remove the corresponding provider planned item details
      providerPlannedItemLinkObj.removeByPlannedSubGoal(plannedSubGoalIDKey);
    } catch (RecordNotFoundException e) {// Don't do anything if there are no
      // records to delete
    }

  }

  // ___________________________________________________________________________
  /**
   * Returns the provider planned item baseline details to view.
   *
   * @param key
   * of the baseline provider planned item entity
   *
   * @return the baseline provider planned item details
   * @throws AppException
   * @throws InformationalException
   */
  public BaselineProviderPlannedItemDetails viewBaselineProviderPlannedItemDetails(
    BaselinePlanItemKey baselinePlanItemKey) throws AppException,
      InformationalException {

    // Manipulation variables
    BaselineProviderPlannedItemDetails baselineProviderPlannedItemDetails = new BaselineProviderPlannedItemDetails();
    ServicePlanDelivery servicePlanDelivery = ServicePlanDeliveryFactory.newInstance();
    PlannedItemKey plannedItemKey = new PlannedItemKey();
    BaselinePlanItemProviderLinkDtls baselinePlanItemProviderLinkDtls = new BaselinePlanItemProviderLinkDtls();

    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    BaselinePlanItemProviderLink baselinePlanItemProviderLinkObj = BaselinePlanItemProviderLinkFactory.newInstance();

    ViewBaselinePlannedItemDetails viewBaselinePlannedItemDetails = new ViewBaselinePlannedItemDetails();

    // Registering the operation for Service Plan Security
    ServicePlanSecurityImplementationFactory.register();

    // Get the core baseline planned item details
    viewBaselinePlannedItemDetails = servicePlanDelivery.viewServicePlanBaselinePlannedItemDetails(
      baselinePlanItemKey);

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = viewBaselinePlannedItemDetails.baselinePlannedItemDetails.baselinePlannedItem.caseID;

    // getting the service plan context description
    viewBaselinePlannedItemDetails.description = servicePlanDelivery.getServicePlanContextDescription(
      servicePlanDeliveryKey);

    baselineProviderPlannedItemDetails.baselinePlannedItemDetails.assign(
      viewBaselinePlannedItemDetails);

    plannedItemKey.plannedItemID = viewBaselinePlannedItemDetails.baselinePlannedItemDetails.baselinePlannedItem.plannedItemID;

    try {
      // Get the provider planned item baseline details
      baselinePlanItemProviderLinkDtls = baselinePlanItemProviderLinkObj.readByPlannedItem(
        plannedItemKey);
      if (baselinePlanItemProviderLinkDtls != null
        && baselinePlanItemProviderLinkDtls.baselinePlanItemProviderLinkID != 0) {
        baselineProviderPlannedItemDetails.displayCustomDetails = true;
      }
    } catch (RecordNotFoundException e) {// Don't do anything if there are no
      // records to read
    }

    baselineProviderPlannedItemDetails.baselineProviderPlannedItem.assign(
      baselinePlanItemProviderLinkDtls);

    return baselineProviderPlannedItemDetails;
  }

  // END, CR00118042

  // BEGIN, CR00120973, CSH
  // ___________________________________________________________________________
  /**
   * This method creates an absence record and a link record that contains the
   * association between the absence and the planned item.
   *
   * @param details
   * - The absence and planned item details to be inserted.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createAbsenceForPlanItem(PlannedItemAbsenceDetails details)
    throws AppException, InformationalException {

    ProviderPlannedItem providerPlannedItemObj = ProviderPlannedItemFactory.newInstance();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Create the absence period details
    providerPlannedItemObj.createPlanItemAbsence(details.dtls);

  }

  // ___________________________________________________________________________
  /**
   * This method lists the absence records associated with the specified planned
   * item.
   *
   * @param key
   * - The planned item identifier.
   *
   * @return The list of absence records.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PlannedItemAbsenceDetailsList listAbsenceForPlanItem(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // Planned Item Absence manipulation variables
    ProviderPlannedItem providerPlannedItemObj = ProviderPlannedItemFactory.newInstance();
    PlannedItemAbsenceDetailsList plannedItemAbsenceDetailsList = new PlannedItemAbsenceDetailsList();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Retrieve the planned item absence list
    plannedItemAbsenceDetailsList.list = providerPlannedItemObj.listPlanItemAbsence(
      key.plannedItemIDKey);

    return plannedItemAbsenceDetailsList;
  }

  // END, CR00120973

  // BEGIN, CR00120079, PMD
  // ___________________________________________________________________________
  /**
   * Returns the plan item type code for the specified planned item id.
   *
   * @param key
   * planned item unique identifier
   *
   * @return the plan item type code
   *
   * @throws AppException
   * , InformationalException
   */
  public curam.providerserviceplan.facade.struct.PlanItemTypeCodeDetails readPlanItemTypeCode(
    PlannedItemIDKey key) throws AppException, InformationalException {

    // Return struct
    curam.providerserviceplan.facade.struct.PlanItemTypeCodeDetails planItemTypeCodeDetails = new curam.providerserviceplan.facade.struct.PlanItemTypeCodeDetails();

    curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Get the plan item type code
    planItemTypeCodeDetails.typeCode = plannedItemObj.readPlanItemTypeCode(
      key.plannedItemIDKey);

    return planItemTypeCodeDetails;
  }

  // _________________________________________________________________________
  /**
   * Adds a Daily Attendance record for a 'service' type plan item
   *
   * @param addClientParticipationDetails
   * Details of daily attendance entered by user
   *
   * @return Identifier of newly created daily attendance record.
   */
  public DailyAttendanceKey addDailyAttendanceServicePlanItem(
    AddClientParticipationDetails details) throws AppException,
      InformationalException {

    // Return struct
    DailyAttendanceKey dailyAttendanceKey = new DailyAttendanceKey();

    // Registering the operation for Service Plan Security
    ServicePlanSecurityImplementationFactory.register();

    // Add the daily attendance
    dailyAttendanceKey = ProviderPlannedItemFactory.newInstance().addDailyAttendance(
      details.dailyAttendanceDtls);

    return dailyAttendanceKey;
  }

  // _________________________________________________________________________
  /**
   * Modifies a Daily Attendance record for a 'service' type plan item
   *
   * @param modifyClientParticipationDetails
   * modified details of daily attendance entered by user
   */
  public void modifyDailyAttendanceServicePlanItem(
    ModifyClientParticipationDetails details) throws AppException,
      InformationalException {

    // Registering the operation for Service Plan Security
    ServicePlanSecurityImplementationFactory.register();

    // Modify the daily attendance
    ProviderPlannedItemFactory.newInstance().modifyDailyAttendance(
      details.dailyAttendanceDtls);

  }

  // END, CR00120079

  // BEGIN, CR00117767, ANK
  // ___________________________________________________________________________
  /**
   * This Method generates the service plan contract details for preview.
   *
   * @param key
   * of service plan contract
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ReadCompleteContractDetails generateContractForPreview(
    ServicePlanContractKey servicePlanContractKey) throws AppException,
      InformationalException {

    // return value
    ReadCompleteContractDetails readCompleteContractDetails = new ReadCompleteContractDetails();

    // Contract manipulation variables
    MaintainServicePlanDocGeneration maintainServicePlanDocGenerationObj = MaintainServicePlanDocGenerationFactory.newInstance();

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    readCompleteContractDetails = maintainServicePlanDocGenerationObj.generateContractForPreview(
      servicePlanContractKey);

    // return the list
    return readCompleteContractDetails;
  }

  // END, CR00117767

  // _________________________________________________________________________
  /**
   * Populates the provider Name into the view struct
   *
   * @throw AppException, InformationalException
   *
   * @param viewProviderPlannedItemDetails
   * - details of provider planned item
   */
  protected String populateProviderName(long providerConcernRoleID)
    throws AppException, InformationalException {

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    String providerName = "";

    if (providerConcernRoleID != 0) {
      // Get provider the provider name
      try {
        concernRoleKey.concernRoleID = providerConcernRoleID;
        providerName = ConcernRoleFactory.newInstance().read(concernRoleKey).concernRoleName;

      } catch (RecordNotFoundException rnfe) {// Do not populate the provider
        // name if there are no records
        // found
      }
    }

    return providerName;
  }

  // BEGIN, CR00274074, GYH
  /**
   * Populates the service offering name.
   *
   * @param serviceOfferingID
   * Unique identifier of service offering.
   *
   * @return The service offering name.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected String populateServiceOfferingName(long serviceOfferingID)
    throws AppException, InformationalException {
    String serviceOfferingName = "";

    if (0 != serviceOfferingID) {
      serviceOfferingName = serviceOfferingDAO.get(serviceOfferingID).getName();
    }
    return serviceOfferingName;
  }

  // END, CR00274074

  // ___________________________________________________________________________
  /**
   * Populates the Service Offering Name into the view struct
   *
   * @throw AppException, InformationalException
   *
   * @param viewProviderPlannedItemDetails
   * - details of provider planned item
   */
  protected String populateUnitOfMeasure(long serviceOfferingID)
    throws AppException, InformationalException {

    // ServiceOffering entity declaration
    ServiceOffering serviceOfferingEntObj = ServiceOfferingFactory.newInstance();
    ServiceOfferingKey serviceOfferingKey = new ServiceOfferingKey();
    String unitOfMeasure = "";

    if (serviceOfferingID != 0) {
      // Get Unit of Measure of the service offering
      try {
        serviceOfferingKey.serviceOfferingID = serviceOfferingID;

        unitOfMeasure = serviceOfferingEntObj.read(serviceOfferingKey).unitOfMeasure;

      } catch (RecordNotFoundException rnfe) {// Don't populate the service
        // offering name if there are no
        // records found
      }
    }
    return unitOfMeasure;
  }

  // ___________________________________________________________________________
  /**
   * Method for searching the Providers based on the given search criteria
   *
   * @throw AppException, InformationalException
   *
   * @param ProviderServiceOfferingSearchKey
   * - key which have Search Criteria
   * @return ProviderSearchResultsList - List of providers based on the search
   */
  public ProviderSearchResultsList searchProviders(
    ProviderServiceOfferingSearchKey providerSearchKey) throws AppException,
      InformationalException {

    // Manipulation variables
    ProviderSearchResultsList providerSearchResultsList = new ProviderSearchResultsList();

    curam.cpm.sl.entity.intf.Provider providerObj = curam.cpm.sl.entity.fact.ProviderFactory.newInstance();

    ProviderServiceOfferingSearchResultsList providerServiceOfferingSearchResultsList = new ProviderServiceOfferingSearchResultsList();

    ProviderServiceOfferingSearchResults providerServiceOfferingSearchResults;

    // BEGIN, CR00126839, ANK
    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Parse the Address Data and Set the Search Criteria
    parseAddressDataAndSetSearchCriteria(providerSearchKey);

    // Parse the Address Data and Set the Search Criteria
    setSearchByIndicatorsBasedOnSearchCriteria(providerSearchKey);
    // END, CR00126839

    // Search the Service Offerings by Provider
    providerServiceOfferingSearchResultsList = providerObj.searchProviderServiceOffering(
      providerSearchKey);

    for (int i = 0; i < providerServiceOfferingSearchResultsList.dtls.size(); i++) {

      providerServiceOfferingSearchResults = new ProviderServiceOfferingSearchResults();

      providerServiceOfferingSearchResults.concernRoleName = providerServiceOfferingSearchResultsList.dtls.item(i).concernRoleName;
      providerServiceOfferingSearchResults.providerConcernRoleID = providerServiceOfferingSearchResultsList.dtls.item(i).providerConcernRoleID;
      providerServiceOfferingSearchResults.recordStatus = providerServiceOfferingSearchResultsList.dtls.item(i).recordStatus;
      providerServiceOfferingSearchResults.category = CodeTable.getParentCode(
        ProviderTypeNameEntry.TABLENAME,
        providerServiceOfferingSearchResultsList.dtls.item(i).providerType);
      providerServiceOfferingSearchResults.providerType = providerServiceOfferingSearchResultsList.dtls.item(i).providerType;
      providerSearchResultsList.list.dtls.addRef(
        providerServiceOfferingSearchResults);
    }
    return providerSearchResultsList;
  }

  // BEGIN, CR00126839, ANK
  // ___________________________________________________________________________
  /**
   * Setting the indicators to search Providers by the given search criteria
   *
   * @throw AppException, InformationalException
   *
   * @param ProviderServiceOfferingSearchKey
   * - key which have Search Criteria
   */
  protected void setSearchByIndicatorsBasedOnSearchCriteria(
    ProviderServiceOfferingSearchKey providerSearchKey) throws AppException,
      InformationalException {

    // check for search criteria entered
    String referenceNumber = providerSearchKey.referenceNumber.trim();
    String providerName = providerSearchKey.providerName.trim();
    String providerCategory = providerSearchKey.category.trim();
    String providerType = providerSearchKey.providerCategoryType.trim();

    // check if reference number is entered and
    // no other criteria should be entered
    if (referenceNumber.equalsIgnoreCase(CuramConst.gkEmpty)
      && providerName.equalsIgnoreCase(CuramConst.gkEmpty)
      && providerType.equalsIgnoreCase(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_PROVIDER_FV_SOME_SEARCH_CRITERIA_MUST_BE_ENTERED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    } else if ((!referenceNumber.equalsIgnoreCase(CuramConst.gkEmpty))
      && ((!providerName.equalsIgnoreCase(CuramConst.gkEmpty))
        || (!providerType.equalsIgnoreCase(CuramConst.gkEmpty)))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          PROVIDER.ERR_PROVIDER_FV_REFERENCE_NO_IS_SPECIFIED_OTHER_SEARCH_CRITERIA_IS_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          4);
    }

    // manipulation variables
    int referenceNumberLength = referenceNumber.length();
    int providerNameLength = providerName.length();
    int providerCategoryLength = providerCategory.length();
    int providerTypeLength = providerType.length();

    // Add the wild card character to name if it is entered.
    if ((providerNameLength > 0)
      && (!providerName.equalsIgnoreCase(CuramConst.gkEmpty))) {
      providerSearchKey.providerName = CuramConst.gkSqlWildcard
        + providerName.toUpperCase() + CuramConst.gkSqlWildcard;
    }

    // Check for reference number criteria.
    if ((referenceNumberLength > 0)
      && (!referenceNumber.equalsIgnoreCase(CuramConst.gkEmpty))) {
      providerSearchKey.searchByReferenceNumber = true;
      providerSearchKey.referenceNumber = referenceNumber;
    }

    if (((providerNameLength > 0)
      && (!providerName.equalsIgnoreCase(CuramConst.gkEmpty)))
        && ((providerTypeLength > 0)
          && (!providerType.equalsIgnoreCase(CuramConst.gkEmpty)))) {
      // check for Provider Name and providerType criteria.

      providerSearchKey.searchByName = true;
      providerSearchKey.searchByType = true;
    }
    if (((providerNameLength > 0)
      && (!providerName.equalsIgnoreCase(CuramConst.gkEmpty)))
        && ((providerCategoryLength > 0)
          && (!providerCategory.equalsIgnoreCase(CuramConst.gkEmpty)))) {
      // check for name and category criteria

      providerSearchKey.searchByName = true;
      providerSearchKey.searchByCategory = true;
    }
    if ((providerNameLength > 0)
      && (!providerName.equalsIgnoreCase(CuramConst.gkEmpty))) {
      // check for Provider Name criteria.

      providerSearchKey.searchByName = true;
    }
    if (((providerCategoryLength > 0)
      && (!providerCategory.equalsIgnoreCase(CuramConst.gkEmpty)))
        && ((providerTypeLength > 0)
          && (!providerType.equalsIgnoreCase(CuramConst.gkEmpty)))) {
      // check for category and provider type.

      String parentCode = curam.util.type.CodeTable.getParentCode(
        ProviderTypeName.TABLENAME, providerType);

      providerSearchKey.category = parentCode;
      providerSearchKey.searchByCategory = true;
      providerSearchKey.searchByType = true;
    }
    if (((providerTypeLength > 0)
      && (!providerType.equalsIgnoreCase(CuramConst.gkEmpty)))) {
      // check for category and provider type.
      providerSearchKey.searchByType = true;
    }
    if ((providerCategoryLength > 0)
      && (!providerCategory.equalsIgnoreCase(CuramConst.gkEmpty))) {
      // check for category criteria.

      providerSearchKey.searchByCategory = true;
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to parse the address data and setting it as the search criteria
   *
   * @throw AppException, InformationalException
   *
   * @param ProviderServiceOfferingSearchKey
   * - key which have Search Criteria
   */
  protected void parseAddressDataAndSetSearchCriteria(
    ProviderServiceOfferingSearchKey providerSearchKey) throws AppException,
      InformationalException {

    // variables for parsing address
    OtherAddressData otherAddressData = new OtherAddressData();
    AddressData addressDataObj = AddressDataFactory.newInstance();
    AddressFieldDetails addressFieldDetails = new AddressFieldDetails();
    AddressMap addressMap = new AddressMap();

    // parse the address
    otherAddressData.addressData = providerSearchKey.address.trim();
    AddressMapList addressMapList = addressDataObj.parseDataToMap(
      otherAddressData);

    // iterate through address map to assign values from map to
    // address field struct
    for (int i = 0; i < addressMapList.dtls.size(); i++) {
      addressMap = addressMapList.dtls.item(i);
      if (!StringUtil.isNullOrEmpty(addressMap.value)) {
        providerSearchKey.searchByAddress = true;
      }
      if (addressMap.name.equalsIgnoreCase(ADDRESSELEMENTTYPE.LINE1)) {
        addressFieldDetails.addressLine3 = addressMap.value.trim();
      }
      if (addressMap.name.equalsIgnoreCase(ADDRESSELEMENTTYPE.LINE2)) {
        addressFieldDetails.addressLine1 = addressMap.value.trim();
      }
      if (addressMap.name.equalsIgnoreCase(ADDRESSELEMENTTYPE.LINE3)) {
        addressFieldDetails.addressLine2 = addressMap.value.trim();
      }
      if (addressMap.name.equalsIgnoreCase(ADDRESSELEMENTTYPE.CITY)) {
        addressFieldDetails.city = addressMap.value.trim();
      }
      if (addressMap.name.equalsIgnoreCase(ADDRESSELEMENTTYPE.STATE)) {
        addressFieldDetails.stateCode = addressMap.value.trim();
      }
      if (addressMap.name.equalsIgnoreCase(ADDRESSELEMENTTYPE.ZIP)) {
        addressFieldDetails.zipCode = addressMap.value.trim();
      }
    }
    // construct the address search string with wild card
    if (providerSearchKey.searchByAddress) {
      providerSearchKey.address = (CuramConst.gkSqlWildcard + ADDRESSELEMENTTYPE.LINE1 + CuramConst.gkEqualsNoSpaces + addressFieldDetails.addressLine3 + CuramConst.gkSqlWildcard + ADDRESSELEMENTTYPE.LINE2 + CuramConst.gkEqualsNoSpaces + addressFieldDetails.addressLine1 + CuramConst.gkSqlWildcard + ADDRESSELEMENTTYPE.LINE3 + CuramConst.gkEqualsNoSpaces + addressFieldDetails.addressLine2 + CuramConst.gkSqlWildcard + ADDRESSELEMENTTYPE.CITY + CuramConst.gkEqualsNoSpaces + addressFieldDetails.city + CuramConst.gkSqlWildcard + ADDRESSELEMENTTYPE.STATE + CuramConst.gkEqualsNoSpaces + addressFieldDetails.stateCode + CuramConst.gkSqlWildcard + ADDRESSELEMENTTYPE.ZIP + CuramConst.gkEqualsNoSpaces + addressFieldDetails.zipCode + CuramConst.gkSqlWildcard).toUpperCase();
    }
  }

  // END, CR00126839

  // BEGIN, CR00120337, CSH
  // ___________________________________________________________________________
  /**
   * This method lists the service and custom service type plan items associated
   * with the specified service plan delivery.
   *
   * @param key
   * - The service plan delivery identifier.
   *
   * @return The list of planned items.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PlannedItemIDAndNameDetailsList listPlanItemsForServicePlan(
    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // Planned Item Absence manipulation variables
    ProviderPlannedItem providerPlannedItemObj = ProviderPlannedItemFactory.newInstance();
    PlannedItemIDAndNameDetailsList plannedItemIDAndNameDetailsList = new PlannedItemIDAndNameDetailsList();

    // Register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // Retrieve the planned item list for the service plan
    plannedItemIDAndNameDetailsList.list = providerPlannedItemObj.listServicePlanPlanItems(
      key);

    return plannedItemIDAndNameDetailsList;
  }

  // END, CR00120337

  // ___________________________________________________________________________
  /**
   * Gets the list of Provider Types based on provider category.
   *
   * @param providerTypeSearchKey
   * contains the provider type id.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchProviderTypeResultsList searchProviderTypes(
    providerTypeSearchKey key) throws AppException, InformationalException {

    // Manipulation variables
    SearchProviderTypeResultsList searchProviderTypeResultsList = new SearchProviderTypeResultsList();
    SearchProviderTypeResults searchProviderTypeResults;

    // BEGIN, CR00129175, ANK
    if (key.providerCategoryType != null
      && key.providerCategoryType.length() > 0) {

      searchProviderTypeResults = new SearchProviderTypeResults();
      searchProviderTypeResults.category = CodeTable.getParentCode(
        ProviderTypeNameEntry.TABLENAME, key.providerCategoryType);
      searchProviderTypeResults.providerType = key.providerCategoryType;

      searchProviderTypeResultsList.detailsList.addRef(
        searchProviderTypeResults);
    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.INFO_PROVIDER_TYPE_SEARCH_CRITERIA_TO_BE_SELECTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END, CR00129175

    return searchProviderTypeResultsList;

  }

  // ___________________________________________________________________________
  /**
   * Creates service plan delivery for an integrated case member based on the
   * selected service plan template.
   *
   * @param details
   * Service plan template details
   */
  public void addTemplate(AddTemplateDetails details) throws AppException,
      InformationalException {

    // ServicePlanDelivery manipulation variables
    curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // validate details
    servicePlanDeliveryObj.validateAddTemplateToServicePlanDetails(
      details.planTemplateKey);

    ProviderPlannedItem providerPlannedItemObj = ProviderPlannedItemFactory.newInstance();

    // add template
    providerPlannedItemObj.addTemplate(
      details.servicePlanDeliveryKey.servicePlanDeliveryKey,
      details.planTemplateKey);
  }

  // ___________________________________________________________________________
  /**
   * Reads service plan delivery details.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Service plan delivery details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ServicePlanDeliveryHomePageDetails readHomePageDetails(
    ServicePlanDeliveryKey key) throws AppException, InformationalException {

    // return value
    ServicePlanDeliveryHomePageDetails servicePlanDeliveryHomePageDetails = new ServicePlanDeliveryHomePageDetails();

    // ServicePlanDelivery business object
    curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryFacadeObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();

    // Service Plan integrated case key
    ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    // BEGIN, CR00066883, SPD
    // UserRecentAction manipulation variables
    UserRecentAction userRecentActionObj = UserRecentActionFactory.newInstance();
    UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();

    // END, CR00066883

    // register the service plan security implementation
    ServicePlanSecurityImplementationFactory.register();

    // read service plan details
    servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails = servicePlanDeliveryObj.read(
      key.servicePlanDeliveryKey);

    if (servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails.trackingGanttDetails.trackGanttXmlString
      != null
        && servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails.trackingGanttDetails.trackGanttXmlString.length()
          > 0) {

      // BEGIN, CR00246922, MR
      servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails.trackingGanttDetails.trackGanttXmlString = updateGanttXmlString(
        servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails.trackingGanttDetails.trackGanttXmlString);
      // END, CR00246922
    }

    // read context description
    servicePlanDeliveryHomePageDetails.spDeliveryContextDescription = servicePlanDeliveryFacadeObj.getServicePlanContextDescription(
      key);

    // set the key to read menu data
    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    // read menu data
    ICServicePlanDeliveryMenuDataDetails menuData = servicePlanDeliveryFacadeObj.getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    // assign menu data to the returned struct
    servicePlanDeliveryHomePageDetails.integratedCaseMenuDataDetails.menuData = menuData.menuData;

    // BEGIN, CR00066883, SPD
    // populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = key.servicePlanDeliveryKey.key.caseID;

    // create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);
    // END, CR00066883

    // return home page details
    return servicePlanDeliveryHomePageDetails;
  }

  // BEGIN, CR00246922, MR
  /**
   * Views the tracking gantt details for a service plan delivery with service
   * or custom service planned item.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Details in form of XML string to be displayed as Gantt diagram.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TrackingGanttDetails viewTrackingGantt(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    TrackingGanttDetails trackingGanttDetails = new TrackingGanttDetails();
    TrackingGantt trackingGanttObj = TrackingGanttFactory.newInstance();
    curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryFacadeObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();

    ServicePlanSecurityImplementationFactory.register();

    try {
      trackingGanttDetails.trackGanttDetails = trackingGanttObj.viewTrackingGantt(
        key.servicePlanDeliveryKey);

      // Display tracking gantt if there is no validation failure.
      trackingGanttDetails.displayPlanInd = true;
    } catch (AppException e) {
      trackingGanttDetails.infoMsg = addExceptionToInformational(e);
    }

    if (trackingGanttDetails.displayPlanInd) {

      // Update gantt chart with planned items details.
      trackingGanttDetails.trackGanttDetails.trackGanttXmlString = updateGanttXmlString(
        trackingGanttDetails.trackGanttDetails.trackGanttXmlString);
    }

    trackingGanttDetails.description = servicePlanDeliveryFacadeObj.getServicePlanContextDescription(
      key);

    ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;

    ICServicePlanDeliveryMenuDataDetails menuData = servicePlanDeliveryFacadeObj.getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    trackingGanttDetails.menuData.menuData = menuData.menuData;

    return trackingGanttDetails;
  }

  /**
   * Update gantt chart XML with service and custom service planned item
   * details.
   *
   * @param inputXmlString
   * Contains gantt chart details in form of XML string.
   *
   * @return String representation of gantt chart details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected String updateGanttXmlString(String inputXmlString)
    throws AppException, InformationalException {
    Document document = XMLUtil.convertStringToJDOMDocument(inputXmlString);

    Filter filter = new ElementFilter(ServicePlanGanttConst.kGantt);

    Iterator iterate = document.getDescendants(filter);

    Element element = null;

    while (iterate.hasNext()) {
      element = (Element) iterate.next();
      List<Element> goals = element.getChildren();

      for (int i = 0; i < goals.size(); i++) {

        // Get all sub goals under the Goal.
        List<Element> subGoals = goals.get(i).getChildren();

        updateSubGoalList(subGoals);

      }

    }

    XMLOutputter outputter = new XMLOutputter();

    return outputter.outputString(document);
  }

  /**
   * Helper method to add an exception to the informational manager.
   *
   * @param e
   * Generic Exception Signature.
   *
   * @return List of informational messages.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected InformationMsgDtlsList addExceptionToInformational(AppException e)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    TransactionInfo.setInformationalManager();

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    informationalManager.addInformationalMsg(e, CuramConst.gkEmpty,
      InformationalElement.InformationalType.kWarning);

    for (final String warnings : informationalManager.obtainInformationalAsString()) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings;
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // END, CR00246922

  /**
   * Gets updates the Gantt Chart XML with the appropriate sub goal details for
   * Plan Item of type Service and Custom service.
   *
   * @param List
   * subGoals
   *
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void updateSubGoalList(List<Element> subGoals) throws AppException,
      InformationalException {
    // END, CR00177241

    int i = 0;
    List<Element> tempSubGoals = new ArrayList<Element>();

    while (i < subGoals.size()) {

      if (subGoals.get(i).getName().equals(ServicePlanGanttConst.kPlannedGroup)) {

        tempSubGoals = subGoals.get(i).getChildren();
        if (tempSubGoals.size() > 0) {
          updateSubGoalList(tempSubGoals);
        }

      } else if (subGoals.get(i).getName().equals(
        ServicePlanGanttConst.kPlannedSubGoal)) {
        Element subGoal = subGoals.get(i);

        updatePlannedItemForGanttChart(subGoal);

      }
      i++;

    }

  }

  /**
   * Checks if the planned Item is of type service or custom service, returns
   * true if it is either of them
   *
   * @param plannedItemKey
   * @return
   * @throws AppException
   * @throws InformationalException
   */

  public GanttChartDeliveryParamDetails checkPlannedItemType(
    PlannedItemKey plannedItemKey) throws AppException,
      InformationalException {

    PlannedItem plannedItem = PlannedItemFactory.newInstance();
    PlanItemTypeCodeDetails planItemTypeCodeDetails = plannedItem.readPlanItemTypeCodeByPlannedItemID(
      plannedItemKey);

    PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemKey.plannedItemID;
    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = plannedItem.readCaseIDByPlannedItemID(
      plannedItemIDKey.plannedItemIDKey.plannedItemIDKey);

    ServicePlanDelivery servicePlanDelivery = ServicePlanDeliveryFactory.newInstance();
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;
    SPDeliveryContextDescription spDeliveryContextDescription = servicePlanDelivery.getServicePlanContextDescription(
      servicePlanDeliveryKey);

    GanttChartDeliveryParamDetails ganttChartDeliveryParamDetails = new GanttChartDeliveryParamDetails();

    ganttChartDeliveryParamDetails.description = spDeliveryContextDescription.description;

    if (planItemTypeCodeDetails.typeCode.equals(PLANITEMTYPE.SERVICEPLANITEM)
      || planItemTypeCodeDetails.typeCode.equals(
        PLANITEMTYPE.CUSTOMSERVICEPLANITEM)) {
      ganttChartDeliveryParamDetails.isServiceCustomService = true;
      return ganttChartDeliveryParamDetails;
    } else {
      ganttChartDeliveryParamDetails.isServiceCustomService = false;
      return ganttChartDeliveryParamDetails;
    }

  }

  /**
   * Gets updates the Gantt Chart XML with the appropriate details for Plan Item
   * of type Service and Custom service.
   *
   * @param subGoal
   * @throws AppException
   * @throws InformationalException
   */

  // BEGIN, CR00177241, PM
  protected void updatePlannedItemForGanttChart(Element subGoal)
    throws AppException, InformationalException {
    // END, CR00177241

    List<Element> plannedItems = subGoal.getChildren();

    for (int i = 0; i < plannedItems.size(); i++) {

      try {
        Element plannedItem = plannedItems.get(i);

        // Check for plan items only as a sub goal may have other components
        // such as milestones

        // BEGIN, CR00145264, MC
        String name = plannedItem.getName();

        if (ServicePlanGanttConst.kPlanItem.equals(name)) {

          // END, CR00145264

          Attribute attribute = plannedItem.getAttribute(
            ServicePlanGanttConst.kID);
          long plannedItemID = attribute.getLongValue();

          PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
          PlannedItemKey plannedItemKey = new PlannedItemKey();

          plannedItemKey.plannedItemID = plannedItemID;
          PlannedItemDtls plannedItemDtls = plannedItemObj.read(plannedItemKey);

          long planItemID = plannedItemDtls.planItemID;

          PlanItem planItemObj = PlanItemFactory.newInstance();
          PlanItemKey planItemKey = new PlanItemKey();

          planItemKey.key.key.planItemID = planItemID;
          PlanItemDtls planItemDtls = planItemObj.read(planItemKey.key.key);

          if (PLANITEMTYPE.SERVICEPLANITEM.equals(planItemDtls.typeCode)
            || PLANITEMTYPE.CUSTOMSERVICEPLANITEM.equals(planItemDtls.typeCode)) {

            // BEGIN, CR00141732, MC
            // Clear existing details which may have been incorrectly introduced
            // by CEF, as CEF cannot differentiate between a service unit
            // delivery and deliveries for service and custom service

            if (plannedItem.getContentSize() > 0) {
              plannedItem.removeContent();
            }
            // END, CR00141732

            ProviderPlannedItemLink providerPlannedItemLink = ProviderPlannedItemLinkFactory.newInstance();
            PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

            plannedItemIDKey.plannedItemIDKey.plannedItemIDKey.plannedItemID = plannedItemID;

            try {

              ProviderPlannedItemLinkDtls providerPlannedItemLinkDtls = providerPlannedItemLink.readByPlannedItemID(
                plannedItemIDKey.plannedItemIDKey.plannedItemIDKey);

              long serviceOfferingID = providerPlannedItemLinkDtls.serviceOfferingID;

              // ServiceOffering entity declaration
              ServiceOffering serviceOfferingEntObj = ServiceOfferingFactory.newInstance();
              ServiceOfferingKey serviceOfferingKey = new ServiceOfferingKey();

              serviceOfferingKey.serviceOfferingID = serviceOfferingID;
              // Get Unit of Measure of the service offering
              String unitOfMeasure = serviceOfferingEntObj.read(serviceOfferingKey).unitOfMeasure;

              if (!UnitOfMeasureEntry.PLACE.equals(unitOfMeasure)) {

                plannedItem.setAttribute(ServicePlanGanttConst.kAuthorizedUnits,
                  String.valueOf(plannedItemDtls.authorizedUnits));
                plannedItem.setAttribute(ServicePlanGanttConst.kUnitType,
                  unitOfMeasure);

                if (plannedItemDtls.unitsDelivered > 0) {

                  plannedItem.setAttribute(ServicePlanGanttConst.kReceivedUnits,
                    String.valueOf(plannedItemDtls.unitsDelivered));
                  PIDailyAttendanceLink piDailyAttendanceLink = PIDailyAttendanceLinkFactory.newInstance();
                  PIDailyAttendanceLinkDtlsList piDailyAttendanceLinkDtlsList = piDailyAttendanceLink.searchByPlannedItemID(
                    plannedItemKey);

                  DailyAttendance dailyAttendanceEntObj = DailyAttendanceFactory.newInstance();

                  DailyAttendanceKey dailyAttendanceKey = new DailyAttendanceKey();

                  for (int l = 0; l < piDailyAttendanceLinkDtlsList.dtls.size(); l++) {

                    long dailyAttendanceID = piDailyAttendanceLinkDtlsList.dtls.item(l).dailyAttendanceID;

                    dailyAttendanceKey.dailyAttendanceID = dailyAttendanceID;
                    DailyAttendanceDtls dailyAttendanceDtls = dailyAttendanceEntObj.read(
                      dailyAttendanceKey);

                    if (dailyAttendanceDtls.unitsAttended > 0) {
                      Element delivery = new Element(
                        ServicePlanGanttConst.kServiceUnitDelivery);

                      delivery.setName(
                        ServicePlanGanttConst.kServiceUnitDelivery);
                      delivery.setAttribute(ServicePlanGanttConst.kDate,
                        String.valueOf(dailyAttendanceDtls.serviceDate));

                      delivery.setAttribute(ServicePlanGanttConst.kUnits,
                        String.valueOf(dailyAttendanceDtls.unitsAttended));

                      plannedItem.addContent(delivery);
                    }
                  }
                }
              }
            } catch (RecordNotFoundException ex) {
              continue;
            }
          }

          // BEGIN, CR00145264, MC
        }
        // END, CR00145264
      } catch (DataConversionException ex) {// Do nothing
      }
    }

  }

  // BEGIN, CR00246922, MR
  /**
   * Reads service plan delivery details.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Service plan delivery details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link ProviderServicePlanDelivery#readHomePageDetails1(ServicePlanDeliveryKey)}
   * . This method is not returning the indicators to denote which
   * manage actions should be visible to the user. See release note:
   * CR00246922.
   */
  @Deprecated
  public ServicePlanDeliveryHomeDetails readServicePlanDeliveryHomeDetails(
    final ServicePlanDeliveryKey key) throws AppException,
      InformationalException {

    curam.providerserviceplan.facade.intf.ProviderServicePlanDelivery providerServicePlanDeliveryObj = ProviderServicePlanDeliveryFactory.newInstance();
    ServicePlanDeliveryHomePageDetails servicePlanDeliveryHomePageDetails = new ServicePlanDeliveryHomePageDetails();
    ServicePlanDeliveryHomeDetails servicePlanDeliveryHomeDetails = new ServicePlanDeliveryHomeDetails();

    servicePlanDeliveryHomePageDetails = providerServicePlanDeliveryObj.readHomePageDetails(
      key);
    if (servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails.spGoalAndOutcomeDetails.goalName.equals(
      CuramConst.gkEmpty)) {
      servicePlanDeliveryHomeDetails.goalInd = true;
      LocalisableString infoMessage = new LocalisableString(
        BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_MODIFY_SERVICE_PLAN_GOAL_NOT_EXISTS);
      InformationalMsgDtlsList informationMsgDtlsList = new InformationalMsgDtlsList();
      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
      for (final String warnings : informationalManager.obtainInformationalAsString()) {
        InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings;
        informationMsgDtlsList.dtls.addRef(informationalMsgDtls);
      }
      servicePlanDeliveryHomeDetails.informationalmsgdtls = informationMsgDtlsList;
    }
    servicePlanDeliveryHomeDetails.integratedCaseMenuDataDetails = servicePlanDeliveryHomePageDetails.integratedCaseMenuDataDetails;
    servicePlanDeliveryHomeDetails.servicePlanDeliveryReadDetails = servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails;
    servicePlanDeliveryHomeDetails.spDeliveryContextDescription = servicePlanDeliveryHomePageDetails.spDeliveryContextDescription;

    return servicePlanDeliveryHomeDetails;
  }

  /**
   * Replaces the deprecated method
   * {@link ProviderServicePlanDelivery#readServicePlanDeliveryHomeDetails(ServicePlanDeliveryKey)}
   * .
   * <p>
   * Reads service plan delivery home page details, including indicators to
   * denote which manage actions should be visible to the user.
   *
   * @param key
   * Contains case ID of the service plan delivery.
   *
   * @return Service plan delivery details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ServicePlanDeliveryHomePageDetails1 readHomePageDetails1(
    final ServicePlanDeliveryKey key) throws AppException,
      InformationalException {

    // Register the service plan security implementation.
    ServicePlanSecurityImplementationFactory.register();
    final ServicePlanDeliveryHomePageDetails1 servicePlanDeliveryHomePageDetails = new ServicePlanDeliveryHomePageDetails1();
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails = servicePlanDeliveryObj.read(
      key.servicePlanDeliveryKey);

    if (null
      != servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails.trackingGanttDetails.trackGanttXmlString
        && 0
          < servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails.trackingGanttDetails.trackGanttXmlString.length()) {
      servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails.trackingGanttDetails.trackGanttXmlString = updateGanttXmlString(
        servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails.trackingGanttDetails.trackGanttXmlString);
    }

    if (CuramConst.gkEmpty.equals(
      servicePlanDeliveryHomePageDetails.servicePlanDeliveryReadDetails.spGoalAndOutcomeDetails.goalName)) {
      final LocalisableString infoMessage = new LocalisableString(
        BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_MODIFY_SERVICE_PLAN_GOAL_NOT_EXISTS);
      final InformationalMsgDtlsList informationMsgDtlsList = new InformationalMsgDtlsList();
      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      for (final String warnings : informationalManager.obtainInformationalAsString()) {
        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings;
        informationMsgDtlsList.dtls.addRef(informationalMsgDtls);
      }
      servicePlanDeliveryHomePageDetails.informationalMsgDtlsList = informationMsgDtlsList;
    }

    final ServicePlanDelivery servicePlanDeliveryFacadeObj = ServicePlanDeliveryFactory.newInstance();

    servicePlanDeliveryHomePageDetails.spDeliveryContextDescription = servicePlanDeliveryFacadeObj.getServicePlanContextDescription(
      key);

    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = key.servicePlanDeliveryKey.key.caseID;
    final ICServicePlanDeliveryMenuDataDetails menuData = servicePlanDeliveryFacadeObj.getICServicePlanMenuData(
      servicePlanIntegratedCaseKey);

    servicePlanDeliveryHomePageDetails.integratedCaseMenuDataDetails.menuData = menuData.menuData;

    final UserRecentAction userRecentActionObj = UserRecentActionFactory.newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();

    userRecentActionDetails.dtls.referenceNo = key.servicePlanDeliveryKey.key.caseID;
    userRecentActionObj.createCaseActionView(userRecentActionDetails);

    // Read current status of the service plan delivery to determine
    // which actions should be available to the user.
    final CaseStatus caseStatusObj = CaseStatusFactory.newInstance();
    final CurrentCaseStatusKey currentCaseStatusKey = new CurrentCaseStatusKey();

    currentCaseStatusKey.caseID = key.servicePlanDeliveryKey.key.caseID;
    final CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    if (CASESTATUS.OPEN.equals(caseStatusDtls.statusCode)) {
      servicePlanDeliveryHomePageDetails.showSubmitInd = true;
    } else {
      servicePlanDeliveryHomePageDetails.showSubmitInd = false;
    }
    if (CASESTATUS.PLANSUBMITTED.equals(caseStatusDtls.statusCode)) {
      servicePlanDeliveryHomePageDetails.showApproveRejectInd = true;
    } else {
      servicePlanDeliveryHomePageDetails.showApproveRejectInd = false;
    }
    if (CASESTATUS.CLOSED.equals(caseStatusDtls.statusCode)) {
      servicePlanDeliveryHomePageDetails.isClosedInd = true;
    }
    return servicePlanDeliveryHomePageDetails;
  }

  // END, CR00246922
  
  // BEGIN, CR00292716, SK
  /**
   * Reads the baseline details and updates the plan items details like units
   * delivered, units authorized and unit type for service and custom
   * service plan items.
   *
   * @param baselineKey
   * Contains the baselineID.
   *
   * @return The baseline details in an XML format.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public BaselineGanttDetails viewBaselineGantt(final BaselineKey baselineKey)
    throws AppException, InformationalException {

    final ServicePlanDelivery servicePlanDeliveyObj = ServicePlanDeliveryFactory.newInstance();
    BaselineGanttDetails baselineGanttDetails = servicePlanDeliveyObj.viewBaselineGantt(
      baselineKey);

    // BEGIN, CR00303472, SK
    if (!StringUtil.isNullOrEmpty(// END, CR00303472
      baselineGanttDetails.baselineGantt.baselineGanttXmlString)) {
      baselineGanttDetails.baselineGantt.baselineGanttXmlString = updateBaselineGanttXmlString(
        baselineGanttDetails.baselineGantt.baselineGanttXmlString);
    }
    return baselineGanttDetails;

  }
  
  /**
   * Update gantt chart XML with service and custom service planned item
   * details for a baseline.
   *
   * @param inputXmlString
   * Contains gantt chart details in form of XML string.
   *
   * @return String representation of gantt chart details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected String updateBaselineGanttXmlString(final String inputXmlString)
    throws AppException, InformationalException {

    Document document = XMLUtil.convertStringToJDOMDocument(inputXmlString);

    Filter filter = new ElementFilter(ServicePlanGanttConst.kGantt);

    Iterator iterate = document.getDescendants(filter);
    Element element = null;

    while (iterate.hasNext()) {
      element = (Element) iterate.next();
      List<Element> goals = element.getChildren();

      for (int i = 0; i < goals.size(); i++) {
        // Get all sub goals under the Goal.
        List<Element> subGoals = goals.get(i).getChildren();

        updateBaselineSubGoalList(subGoals);
      }
    }
    XMLOutputter outputter = new XMLOutputter();

    return outputter.outputString(document);
  }

  /**
   * Gets updates the Gantt Chart XML with the appropriate sub goal details for
   * Plan Item of type Service and Custom service.
   *
   * @param subGoals
   * The list of baseline sub goals.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void updateBaselineSubGoalList(final List<Element> subGoals)
    throws AppException, InformationalException {

    int i = 0;
    List<Element> tempSubGoals = new ArrayList<Element>();

    while (i < subGoals.size()) {
      if (subGoals.get(i).getName().equals(ServicePlanGanttConst.kPlannedGroup)) {
        tempSubGoals = subGoals.get(i).getChildren();
        if (tempSubGoals.size() > 0) {
          updateBaselineSubGoalList(tempSubGoals);
        }
      } else if (subGoals.get(i).getName().equals(
        ServicePlanGanttConst.kPlannedSubGoal)) {
        Element subGoal = subGoals.get(i);

        updateBaselinePlannedItemForGanttChart(subGoal);
      }
      i++;
    }
  }

  /**
   * Updates the Gantt Chart XML with the appropriate details for baseline plan item
   * of type Service and Custom service.
   *
   * @param subGoal
   * The baseline subgoal for which the plan items needs to be updated.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void updateBaselinePlannedItemForGanttChart(final Element subGoal)
    throws AppException, InformationalException {

    List<Element> plannedItems = subGoal.getChildren();

    BaselinePlanItemProviderLink baselinePlanItemProviderLinkObj = BaselinePlanItemProviderLinkFactory.newInstance();

    for (int i = 0; i < plannedItems.size(); i++) {

      try {
        Element plannedItem = plannedItems.get(i);

        String name = plannedItem.getName();

        if (ServicePlanGanttConst.kPlanItem.equals(name)) {
          Attribute baselinePlanItemIDattribute = plannedItem.getAttribute(
            ServicePlanGanttConst.kID);

          final long baselinePlanItemID = baselinePlanItemIDattribute.getLongValue();
          final BaselinePlanItemKey baselinePlanItemKey = new BaselinePlanItemKey();

          baselinePlanItemKey.baselinePlanItemID = baselinePlanItemID;
          NotFoundIndicator nfIndicator = new NotFoundIndicator();

          BaselinePlanItemProviderLinkDtls baselinePlanItemProviderLinkDtls = baselinePlanItemProviderLinkObj.readByBaselinePlanItem(
            nfIndicator, baselinePlanItemKey);

          if (!nfIndicator.isNotFound()) {

            if (plannedItem.getContentSize() > 0) {
              plannedItem.removeContent();
            }
            plannedItem.setAttribute(ServicePlanGanttConst.kAuthorizedUnits,
              String.valueOf(
              baselinePlanItemProviderLinkDtls.totalUnitsAuthorized));

            plannedItem.setAttribute(ServicePlanGanttConst.kUnitType,
              baselinePlanItemProviderLinkDtls.unitOfMeasure);
            if (baselinePlanItemProviderLinkDtls.unitsDelivered >= 0) {
              plannedItem.setAttribute(ServicePlanGanttConst.kReceivedUnits,
                String.valueOf(baselinePlanItemProviderLinkDtls.unitsDelivered));
            } else {
              plannedItem.setAttribute(ServicePlanGanttConst.kReceivedUnits,
                String.valueOf(0));
            }

          }

        }
      } catch (DataConversionException dcx) {// Data Conversion Exception catch.
      }
    }
  }
  // END, CR00292716
}
