/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */


package curam.providerserviceplan.sl.event.impl;


import curam.codetable.PLANITEMTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.AbsencePeriodFactory;
import curam.core.sl.entity.intf.AbsencePeriod;
import curam.core.sl.entity.struct.AbsencePeriodDtls;
import curam.core.sl.entity.struct.AbsencePeriodDtlsList;
import curam.providerserviceplan.sl.entity.fact.ProviderPlannedItemLinkFactory;
import curam.providerserviceplan.sl.entity.intf.ProviderPlannedItemLink;
import curam.providerserviceplan.sl.entity.struct.ProviderPlannedItemLinkDtls;
import curam.providerserviceplan.util.impl.GeneralProviderConstants;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemAbsenceLinkFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.intf.PlannedItemAbsenceLink;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemAbsenceLinkDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.util.events.impl.EventFilter;
import curam.util.events.impl.EventHandler;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;


public class CloneProviderInformation implements EventFilter, EventHandler {
  
  public boolean accept(Event event) throws AppException, InformationalException {
    
    if (event.eventKey.eventClass.equals(
      GeneralProviderConstants.kEventServicePlans)) {
      return true;
    }
    
    return false;
  }
  
  public void eventRaised(Event event) throws AppException, InformationalException {
    
    if (event.eventKey.eventType.equals(
      GeneralProviderConstants.kEventClonePlan)) {
      
      boolean closePreviousPlan_default = curam.util.resources.Configuration.getBooleanProperty(
        curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE_DEFAULT);
      
      boolean closePreviousPlan = curam.util.resources.Configuration.getBooleanProperty(
        curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE,
        closePreviousPlan_default);
     
      // BEGIN CR00140720, GBA
      if (closePreviousPlan) {
        adjustClonedPlannedItem(event);
      } else {
        defaultServicePlannedItem(event);
      }
      // END CR00140720
    }
    
  }
  
  /**
   * Gets the details of the original planned item and maps it to the clone of 
   * the original planned item
   * @param event
   * @throws InformationalException
   * @throws AppException
   */
  
  // BEGIN, CR00177241, PM
  protected void adjustClonedPlannedItem(Event event) throws AppException, InformationalException {
    // END, CR00177241
    
    
    
    long originalPlannedItemID = event.primaryEventData;
    long clonedPlannedItemID = event.secondaryEventData;
    
    PlannedItemKey plannedItemKey = new PlannedItemKey();
    
    PlanItem planItemObj = PlanItemFactory.newInstance();
    
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    plannedItemKey.plannedItemID = originalPlannedItemID;
    
    PlannedItemDtls plannedItemDtls = plannedItemObj.read(plannedItemKey);
    PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = plannedItemDtls.planItemID;

    if ((PLANITEMTYPE.CUSTOMSERVICEPLANITEM.equals(
      planItemObj.read(planItemKey).typeCode))
        || (PLANITEMTYPE.SERVICEPLANITEM.equals(
          planItemObj.read(planItemKey).typeCode))) {
      
      ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();
      PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

      plannedItemIDKey.plannedItemID = originalPlannedItemID;
      ProviderPlannedItemLinkDtls providerPlannedItemLinkDtls = null;

      try {
        providerPlannedItemLinkDtls = providerPlannedItemLinkObj.readByPlannedItemID(
          plannedItemIDKey);
        providerPlannedItemLinkDtls.plannedItemID = clonedPlannedItemID;
        
        UniqueID uniqueIDObj = UniqueIDFactory.newInstance();
        
        providerPlannedItemLinkDtls.providerPlannedItemLinkID = uniqueIDObj.getNextID();
        
        plannedItemKey.plannedItemID = clonedPlannedItemID;
        PlannedItemDtls clonedPlannedItemDtls = plannedItemObj.read(
          plannedItemKey);
        
        providerPlannedItemLinkDtls.plannedSubGoalID = clonedPlannedItemDtls.plannedSubGoalID;
        
        providerPlannedItemLinkObj.insert(providerPlannedItemLinkDtls);
        
      } catch (RecordNotFoundException ex) {
        // If no records are found don't do anything, return
        return;
      }
      // BEGIN, CR00130731, GBA
      // Clone Absence records if 'curam.serviceplans.closepreviousplanonclone' 
      // property is set to YES
      
      boolean closePreviousPlan_default = curam.util.resources.Configuration.getBooleanProperty(
        curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE_DEFAULT);
      boolean closePreviousPlan = curam.util.resources.Configuration.getBooleanProperty(
        curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE,
        closePreviousPlan_default);

      if (closePreviousPlan) {
        // Search for absence records
        AbsencePeriodDtlsList absencePeriodDtlsList = PlannedItemAbsenceLinkFactory.newInstance().searchAbsenceByPlannedItemID(
          plannedItemIDKey);

        AbsencePeriodDtls absencePeriodDtls = new AbsencePeriodDtls();
        PlannedItemAbsenceLinkDtls plannedItemAbsenceLinkDtls = new PlannedItemAbsenceLinkDtls();

        plannedItemAbsenceLinkDtls.plannedItemID = clonedPlannedItemID;
        plannedItemAbsenceLinkDtls.recordStatus = RECORDSTATUS.NORMAL;
        AbsencePeriod absencePeriodObj = AbsencePeriodFactory.newInstance();
        PlannedItemAbsenceLink plannedItemAbsenceLinkObj = PlannedItemAbsenceLinkFactory.newInstance();

        for (int i = 0; i < absencePeriodDtlsList.dtls.size(); i++) {

          absencePeriodDtls.assign(absencePeriodDtlsList.dtls.item(i));

          if (RECORDSTATUS.NORMAL.equals(absencePeriodDtls.recordStatus)) {
            // Insert the absence record
            absencePeriodObj.insert(absencePeriodDtls);

            plannedItemAbsenceLinkDtls.absencePeriodID = absencePeriodDtls.absencePeriodID;

            // Insert the link record
            plannedItemAbsenceLinkObj.insert(plannedItemAbsenceLinkDtls);
          }
        }
      }
      // END, CR00130731
    }
    
  }
  
  // BEGIN CR00140720, GBA
  /**
   * Gets Service Offering value from the original planned item of type service 
   * and maps it to the cloned one.
   *
   * @param event
   * @throws InformationalException
   * @throws AppException
   */
  
  // BEGIN, CR00177241, PM
  protected void defaultServicePlannedItem(Event event) 
    throws AppException, InformationalException {
    // END, CR00177241
    
    long originalPlannedItemID = event.primaryEventData;
    long clonedPlannedItemID = event.secondaryEventData;
    
    PlannedItemKey plannedItemKey = new PlannedItemKey();
    
    PlanItem planItemObj = PlanItemFactory.newInstance();
    
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    plannedItemKey.plannedItemID = originalPlannedItemID;
    
    PlannedItemDtls plannedItemDtls = plannedItemObj.read(plannedItemKey);
    PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = plannedItemDtls.planItemID;

    if (PLANITEMTYPE.SERVICEPLANITEM.equals(
      planItemObj.read(planItemKey).typeCode)) {
      
      ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();
      PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

      plannedItemIDKey.plannedItemID = originalPlannedItemID;
      ProviderPlannedItemLinkDtls providerPlannedItemDtls = new ProviderPlannedItemLinkDtls();

      UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

      providerPlannedItemDtls.providerPlannedItemLinkID = uniqueIDObj.getNextID();
      providerPlannedItemDtls.plannedItemID = clonedPlannedItemID;

      try {
        ProviderPlannedItemLinkDtls providerPlannedItemLinkDtls = providerPlannedItemLinkObj.readByPlannedItemID(
          plannedItemIDKey);
        
        plannedItemKey.plannedItemID = clonedPlannedItemID;
        PlannedItemDtls clonedPlannedItemDtls = plannedItemObj.read(
          plannedItemKey);

        providerPlannedItemDtls.plannedSubGoalID = clonedPlannedItemDtls.plannedSubGoalID;
        providerPlannedItemDtls.serviceOfferingID = providerPlannedItemLinkDtls.serviceOfferingID;
        
        providerPlannedItemLinkObj.insert(providerPlannedItemDtls);
        
      } catch (RecordNotFoundException ex) {
        // If no records are found don't do anything, return
        return;
      }

    }
    
  }  
  // END CR00140720

}
