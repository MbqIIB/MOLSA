/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.sl.impl;


import curam.util.type.DateRange;


/**
 * This class is a data holder class for getting the values of planned item
 * applicable rate. By default this class contains values for the date range and
 * the authorized rate. Customer can customize this class by adding any other
 * applicable rates for the planned item. The applicable rates can be the rates
 * based on location, volume discount rates or performance based rates.
 */
public final class ProviderPlannedItemApplicableRate {

  /**
   * The date range applicable for the rate for the planned item.
   */
  protected DateRange dateRange;

  /**
   * The authorized rate for the planned item.
   */
  protected int authorizedRate;

  /**
   * Constructor for the class.
   *
   * @param dateRange
   * The date range of the planned item.
   * @param authorizedRate
   * The authorized rate of the planned item.
   */
  public ProviderPlannedItemApplicableRate(DateRange dateRange,
    int authorizedRate) {
    this.dateRange = dateRange;
    this.authorizedRate = authorizedRate;
  }

  /**
   * Gets the date range applicable for the rate of the planned item.
   *
   * @return The date range of the planned item.
   */
  public DateRange getDateRange() {
    return dateRange;
  }

  /**
   * Gets the authorized rate associated with the planned item.
   *
   * @return The authorized rate of the planned item.
   */
  public int getAuthorizedRate() {
    return authorizedRate;
  }
}
