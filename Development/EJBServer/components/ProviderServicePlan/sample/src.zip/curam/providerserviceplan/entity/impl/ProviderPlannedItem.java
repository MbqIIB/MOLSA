/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */



package curam.providerserviceplan.entity.impl;


import java.util.ArrayList;

import curam.codetable.PLANNEDITEMSTATUS;
import curam.message.BPOPROVIDERPLANNEDITEM;
import curam.providerserviceplan.sl.entity.fact.ProviderPlannedItemLinkFactory;
import curam.providerserviceplan.sl.entity.intf.ProviderPlannedItemLink;
import curam.providerserviceplan.sl.entity.struct.ClonedPlannedItemDtls;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.struct.IsMandatoryIndResult;
import curam.serviceplans.sl.entity.struct.ModifyEstimatedCostDetails;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemApprovalProcessingStatusDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemEstimatedCost;
import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.entity.struct.PlannedItemKeyList;
import curam.serviceplans.sl.entity.struct.RequiresApprovalStruct;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.type.Date;
import curam.util.type.FrequencyPattern;


/**
 * This provider planned item entity class helps to validate service and
 * custom service plan items on pre insert, pre modify, post insert and post
 * modify.
 *
 * This class also creates service authorization line items based on the planned item
 * details such as frequency, from date, to date etc
 *
 */



public abstract class ProviderPlannedItem extends curam.providerserviceplan.entity.base.ProviderPlannedItem {

  /**
   * @param plannedItemDtls
   * @return boolean - Whether the planned item is being cloned or not
   * @throws AppException
   * @throws InformationalException
   */


  protected boolean isCloned(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {

    boolean isCloned = false;
    ProviderPlannedItemLink providerPlannedItemLink = ProviderPlannedItemLinkFactory.newInstance();

    ClonedPlannedItemDtls clonedPlannedItemDtls = new ClonedPlannedItemDtls();

    clonedPlannedItemDtls.authorizedUnits = plannedItemDtls.authorizedUnits;
    clonedPlannedItemDtls.expectedEndDate = plannedItemDtls.expectedEndDate;
    clonedPlannedItemDtls.expectedStartDate = plannedItemDtls.expectedStartDate;
    clonedPlannedItemDtls.expectedOutcomeID = plannedItemDtls.expectedOutcomeID;
    clonedPlannedItemDtls.name = plannedItemDtls.name;
    clonedPlannedItemDtls.frequency = plannedItemDtls.frequency;
    clonedPlannedItemDtls.status = plannedItemDtls.status;
    try {
      PlannedItemKeyList plannedItemKeyList = providerPlannedItemLink.searchClonedPlannedItemDtls(
        clonedPlannedItemDtls);

      if (plannedItemKeyList.dtls.size() > 0) {
        isCloned = true;
      }
    } catch (RecordNotFoundException ex) {// Do nothing as is Cloned is already set to false
    }

    return isCloned;

  }

  // ___________________________________________________________________________
  /**
   * This method validates the frequency details associated with the planned item
   *
   * @param PlannedItemDtls - plannedItemDtls contains details which are to be
   * validated
   *
   * @throws AppException, InformationalException
   */
  public void validateProviderServiceFrequencyDetails(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {

    // Check number of occurrences using the specified frequency pattern
    if (plannedItemDtls.frequency.length() > 0) {
      FrequencyPattern frequencyPattern = new FrequencyPattern(
        plannedItemDtls.frequency);

      final ArrayList<Date> dateList = new ArrayList<Date>();

      boolean nextOccurance = true;

      Date startingPoint = frequencyPattern.getPrevOccurrence(
        plannedItemDtls.expectedStartDate);
      Date occurrenceDate = startingPoint;
      final Date endDate = plannedItemDtls.expectedEndDate;

      while (nextOccurance) {

        // get next occurrence

        occurrenceDate = frequencyPattern.getNextOccurrence(occurrenceDate);

        // ensure occurrence is not after the end date

        if (occurrenceDate.after(endDate)) {

          nextOccurance = false;

          break;

        }
        // add occurrence to list
        dateList.add(occurrenceDate);

      }

      int noOfOccurances = dateList.size();

      if (noOfOccurances == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPROVIDERPLANNEDITEM.ERR_SERVICEPLAN_FV_FREQUENCY_DATE_CANNOT_BE_UPDATED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

    PlanItem planItemObj = PlanItemFactory.newInstance();
    PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = plannedItemDtls.planItemID;
    RequiresApprovalStruct requiresApproval = planItemObj.readApprovalRequired(
      planItemKey);

    if (requiresApproval.requiresApproval
      && plannedItemDtls.status.equals(PLANNEDITEMSTATUS.NOTSTARTED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_SERVICEPLAN_FV_PLANNEDITEM_ALREADY_APPROVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

    }

    PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = plannedItemDtls.plannedItemID;

    ProviderPlannedItemLink providerPlannedItemLinkObj = ProviderPlannedItemLinkFactory.newInstance();

    int noOfRecords = providerPlannedItemLinkObj.getServiceAuthorizationLineItemCount(plannedItemIDKey).noOfRecords;

    if (noOfRecords > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPROVIDERPLANNEDITEM.ERR_SERVICEPLAN_FV_SALI_ALREADY_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

}
