/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.providerserviceplan.sl.entity.impl;


import curam.providerserviceplan.sl.entity.struct.BaselinePlanItemProviderLinkDtls;
import curam.providerserviceplan.sl.entity.struct.BaselinePlanItemProviderLinkKey;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This service layer class interacts with the entity layer classes to perform
 * various operations on the BaselinePlanItemProviderLink entity
 *
 */
public abstract class BaselinePlanItemProviderLink extends curam.providerserviceplan.sl.entity.base.BaselinePlanItemProviderLink {

  @Override
  protected void preinsert(BaselinePlanItemProviderLinkDtls details) throws AppException, InformationalException {// TODO Auto-generated method stub
  }

  @Override
  protected void preread(BaselinePlanItemProviderLinkKey key) throws AppException, InformationalException {// TODO Auto-generated method stub
  }

  @Override
  protected void prereadByPlannedItem(PlannedItemKey plannedItemKey) throws AppException, InformationalException {// TODO Auto-generated method stub
  }

  @Override
  protected void preremove(BaselinePlanItemProviderLinkKey key) throws AppException, InformationalException {// TODO Auto-generated method stub
  }

}
