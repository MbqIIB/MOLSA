/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.providerserviceplan.entity.impl;


import curam.message.BPOPLANITEM;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaSummaryDetailsList;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanItemDtlsList;
import curam.serviceplans.sl.entity.struct.PlanItemNameIDDetailsList;
import curam.serviceplans.sl.entity.struct.SearchUnassociatedApprovalCriteriaForPlanItemKey;
import curam.serviceplans.sl.entity.struct.TaskConfigurationIDKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public class ProviderPlanItem extends curam.providerserviceplan.entity.base.ProviderPlanItem {

  /**
   * Validate on pre-insert
   *
   * @param PlanItemDtls details - plan item details which are to be validated
   *
   * @throws AppException, InformationalException
   */
  public void validateInsert(PlanItemDtls details) throws AppException,
      InformationalException {

    validateProviderPlanItemDetails(details);
  }

  /**
   * Validate on pre-modify
   *
   * @param PlanItemDtls details - plan item details which are to be validated
   *
   * @throws AppException, InformationalException
   */

  public void validateModify(
    curam.serviceplans.sl.entity.struct.PlanItemKey key, PlanItemDtls details)
    throws AppException, InformationalException {

    validateProviderPlanItemDetails(details);
  }

  // ___________________________________________________________________________
  /**
   * Validates the details for Service and Custom service plan item types
   *
   * @param details the plan item details
   *
   * @throws AppException, InformationalException
   */
  public void validateProviderPlanItemDetails(PlanItemDtls details)
    throws AppException, InformationalException {

    if (details.typeCode.equals(curam.codetable.PLANITEMTYPE.SERVICEPLANITEM)
      && !details.associatedType.equals(curam.codetable.ASSOCIATEDTYPE.SERVICE)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_SERVICE_PLAN_ITEM_ASSOCIATE_SERVICE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if (details.typeCode.equals(
      curam.codetable.PLANITEMTYPE.CUSTOMSERVICEPLANITEM)
        && !details.associatedType.equals(
          curam.codetable.ASSOCIATEDTYPE.SERVICE)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_CUSTOM_SERVICE_PLAN_ITEM_ASSOCIATE_SERVICE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (details.typeCode.equals(
      curam.codetable.PLANITEMTYPE.CUSTOMSERVICEPLANITEM)
        && details.associatedID != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_CUSTOM_SERVICE_PLAN_ITEM_SERVICE_OFFERING),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (details.typeCode.equals(curam.codetable.PLANITEMTYPE.SERVICEPLANITEM)
      && details.associatedID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_SERVICE_PLAN_ITEM_NO_SERVICE_OFFERING),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

}
