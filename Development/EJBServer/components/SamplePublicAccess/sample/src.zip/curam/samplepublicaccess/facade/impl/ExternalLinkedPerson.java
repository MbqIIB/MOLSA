/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.samplepublicaccess.facade.impl;


import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.intf.ParticipantContext;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.sl.entity.fact.ExternalUserParticipantLinkFactory;
import curam.core.sl.entity.intf.ExternalUserParticipantLink;
import curam.core.sl.entity.struct.ExternalUserKey;
import curam.core.sl.entity.struct.ExternalUserParticipantLinkDtlsList;
import curam.core.sl.struct.ExternalUsersRoleAndRelTypeDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.SecurityResult;
import curam.message.GENERALCONCERN;
import curam.samplepublicaccess.facade.struct.ExternalPersonHomePageResults;
import curam.samplepublicaccess.facade.struct.ExternalUserParticipantLinkKey;
import curam.samplepublicaccess.sl.fact.ExternalLinkedPersonFactory;
import curam.samplepublicaccess.sl.struct.ReadPersonPageDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * Process class used to read and maintain External Person data
 */
public abstract class ExternalLinkedPerson extends curam.samplepublicaccess.facade.base.ExternalLinkedPerson {

  // ___________________________________________________________________________
  /**
   * Method to return the person details for External User linked to the person.
   *
   * @param key Contains an external user participant link identifier
   * @return The External Person home page details
   */
  public ExternalPersonHomePageResults readHomePageDetails(
    ExternalUserParticipantLinkKey key)
    throws AppException, InformationalException {

    // Return object
    ExternalPersonHomePageResults externalPersonHomePageResults = new ExternalPersonHomePageResults();

    // External person home page value objects
    curam.samplepublicaccess.sl.intf.ExternalLinkedPerson externalLinkedPersonObj = ExternalLinkedPersonFactory.newInstance();
    ReadPersonPageDetails readPersonPageDetails = new ReadPersonPageDetails();

    // BEGIN, CR00093230, VM
    // Perform security check here to see if the client whose data is being
    // viewed is linked to the external user
    curam.core.sl.intf.ExternalUserParticipantLink externalUserParticipantLink = curam.core.sl.fact.ExternalUserParticipantLinkFactory.newInstance();

    ExternalUsersRoleAndRelTypeDetails details = externalUserParticipantLink.readParticipantRoleID(
      key.key);

    // set the participantRoleID
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.participantRoleID;

    checkSecurity(concernRoleKey);
    // END, CR00093230

    // Read the person home page details
    readPersonPageDetails = externalLinkedPersonObj.readHomePage(key.key);

    // Assign the details to the return value object
    externalPersonHomePageResults.personHomePageDetails.assign(
      readPersonPageDetails);

    externalPersonHomePageResults.participantRoleIDDtls.participantRoleID = readPersonPageDetails.roleAndRelTypeDetails.participantRoleID;

    // BEGIN, CR00169613, VK 
    // Context Objects
    ParticipantContext participantContextObj = ParticipantContextFactory.newInstance();
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = readPersonPageDetails.roleAndRelTypeDetails.participantRoleID;

    // Get the context description for the concern role
    externalPersonHomePageResults.contextDescriptionDtls = participantContextObj.readContextDescription(
      participantContextDescriptionKey);
    
    // END, CR00169613 
    return externalPersonHomePageResults;
  }

  // BEGIN, CR00093230, VM
  // ___________________________________________________________________________
  /**
   * Checks to see if the external user has access to the client's details.
   * This consists of a check against the External User Participant Link
   * records attached to the external user.
   *
   * @param key Concern Role entity key
   */
  protected void checkSecurity(ConcernRoleKey key)
    throws AppException, InformationalException {

    SecurityResult securityResult = new SecurityResult();

    securityResult.result = false;

    // ExternalUserParticipantLink table objects
    ExternalUserParticipantLink externalUserParticipantLinkObj = ExternalUserParticipantLinkFactory.newInstance();

    // get all the participants that this userName has access to
    ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.userName = TransactionInfo.getProgramUser();

    ExternalUserParticipantLinkDtlsList externalUserParticipantLinkDtlsList = externalUserParticipantLinkObj.searchByUsername(
      externalUserKey);

    // If there is a record on the External User Participant Link table
    // matching the user to the participantKey, grant access to the user.
    for (int i = 0; i < externalUserParticipantLinkDtlsList.dtls.size(); i++) {

      if (externalUserParticipantLinkDtlsList.dtls.item(i).participantRoleID
        == key.concernRoleID) {
        securityResult.result = true;
        break;
      }
    }

    if (securityResult.result == false) {
      throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
    }

  }
  // END, CR00093230
}
