/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.samplepublicaccess.sl.impl;


import curam.core.fact.AlternateNameFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.PersonFactory;
import curam.core.intf.AlternateName;
import curam.core.intf.ConcernRole;
import curam.core.intf.Person;
import curam.core.sl.fact.ExternalUserParticipantLinkFactory;
import curam.core.sl.intf.ExternalUserParticipantLink;
import curam.core.sl.struct.ExternalUserParticipantLinkKey;
import curam.core.struct.AlternateNameKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.PersonKey;
import curam.samplepublicaccess.sl.fact.ExternalLinkedParticipantFactory;
import curam.samplepublicaccess.sl.intf.ExternalLinkedParticipant;
import curam.samplepublicaccess.sl.struct.ReadLinkedParticipantDetails;
import curam.samplepublicaccess.sl.struct.ReadLinkedParticipantDetailsKey;
import curam.samplepublicaccess.sl.struct.ReadPersonPageDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Service Layer class used to read / maintain data for an External Person User
 */
public abstract class ExternalLinkedPerson extends
  curam.samplepublicaccess.sl.base.ExternalLinkedPerson {

  // ___________________________________________________________________________
  /**
   * Method to read the home page details for a person based on the participant
   * role identifier.
   *
   * @param key Contains an External User Participant Link Key entity key
   *
   * @return The person home page details
   */
  public ReadPersonPageDetails readHomePage(ExternalUserParticipantLinkKey key)
    throws AppException, InformationalException {

    // Return object
    ReadPersonPageDetails readPersonPageDetails = new ReadPersonPageDetails();

    // Get the participantRoleID and rel type from the external users
    // participant link table
    ExternalUserParticipantLink externalUserParticipantLink =
      ExternalUserParticipantLinkFactory.newInstance();

    readPersonPageDetails.roleAndRelTypeDetails =
      externalUserParticipantLink.readParticipantRoleID(key);

    // set the participantRoleID
    long participantRoleID =
      readPersonPageDetails.roleAndRelTypeDetails.participantRoleID;

    // ConcernRole value objects
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Person Entity value objects
    Person personObj = PersonFactory.newInstance();
    PersonKey personKey = new PersonKey();

    // AlternateName Entity value objects
    AlternateName alternateNameObj = AlternateNameFactory.newInstance();
    AlternateNameKey alternateNameKey = new AlternateNameKey();

    // ExternalLinkedParticipant value objects
    ExternalLinkedParticipant externalLinkedParticipantObj =
      ExternalLinkedParticipantFactory.newInstance();
    ReadLinkedParticipantDetailsKey readPrimaryParticipantDetailsKey =
      new ReadLinkedParticipantDetailsKey();
    ReadLinkedParticipantDetails readPrimaryParticipantDetails =
      new ReadLinkedParticipantDetails();

    // Read the ConcernRole Details
    concernRoleKey.concernRoleID = participantRoleID;
    readPersonPageDetails.concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Read the person details
    personKey.concernRoleID = participantRoleID;
    readPersonPageDetails.personDtls = personObj.read(personKey);

    // Assign the key value for the alternateName read
    alternateNameKey.alternateNameID =
      readPersonPageDetails.personDtls.primaryAlternateNameID;
    readPersonPageDetails.alternateNameDtls =
      alternateNameObj.read(alternateNameKey);

    // Assign the key value for the PrimaryParticipantDetails read
    readPrimaryParticipantDetailsKey.participantRoleID = participantRoleID;
    readPrimaryParticipantDetailsKey.primaryAddressID =
      readPersonPageDetails.concernRoleDtls.primaryAddressID;
    readPrimaryParticipantDetailsKey.primaryPhoneNumberID =
      readPersonPageDetails.concernRoleDtls.primaryPhoneNumberID;
    readPrimaryParticipantDetailsKey.primaryBankAccountID =
      readPersonPageDetails.concernRoleDtls.primaryBankAccountID;
    readPrimaryParticipantDetailsKey.prefPublicOfficeID =
      readPersonPageDetails.concernRoleDtls.prefPublicOfficeID;
    readPrimaryParticipantDetailsKey.primaryEmailAddressID =
      readPersonPageDetails.concernRoleDtls.primaryEmailAddressID;

    // Read the AlternateName details
    readPrimaryParticipantDetails =
      externalLinkedParticipantObj.readParticipantDetails(
        readPrimaryParticipantDetailsKey);

    // Assign the AlternateNameDtls to the return object
    readPersonPageDetails.participantDtls.assign(readPrimaryParticipantDetails);

    // Assign codetable attributes their underlying code descriptions
    readPersonPageDetails.gender = readPersonPageDetails.personDtls.gender;
    readPersonPageDetails.title = readPersonPageDetails.alternateNameDtls.title;
    readPersonPageDetails.nameSuffix =
      readPersonPageDetails.alternateNameDtls.nameSuffix;

    return readPersonPageDetails;
  }

}
