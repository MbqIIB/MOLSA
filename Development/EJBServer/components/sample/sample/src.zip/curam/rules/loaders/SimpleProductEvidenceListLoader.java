/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.rules.loaders;


import curam.core.impl.CuramConst;
import curam.rules.rdo.SimpleProductRulesEvidenceListGroup;
import curam.sample.fact.RulesSimpleProductEvidenceFactory;
import curam.sample.struct.SimpleProductRulesEvidenceDetails;
import curam.sample.struct.SimpleProductRulesEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.rules.ItemGroupGlobals;
import curam.util.type.Money;


/**
 * This module contains the Simple Product Evidence List Loader implementation
 *
 */
public class SimpleProductEvidenceListLoader extends curam.util.rules.Loader {

  // ___________________________________________________________________________
  /**
   * Method to retrieve data from the Business Process called by this loader
   * based on the rules parameters passed in. The values returned are used to
   * set the necessary data items.
   *
   * @param rp rules parameters
   */
  protected void load(curam.util.rules.RulesParameters rp)
    throws AppException, InformationalException {

    // declare data tree used for rules execution
    ItemGroupGlobals globals = ItemGroupGlobals.getCurrentInstance(rp);
    SimpleProductRulesEvidenceListGroup rdoSimpleProductRulesEvidenceList = SimpleProductRulesEvidenceListGroup.getCurrentInstance(
      rp);

    // Set key to retrieve data
    SimpleProductRulesEvidenceKey simpleProductRulesEvidenceKey = new SimpleProductRulesEvidenceKey();

    simpleProductRulesEvidenceKey.caseID = globals.getClaimReferenceNumber().getValueNoLoad();
    simpleProductRulesEvidenceKey.dateOfCalculation = globals.getDateOfCalculation().getValueNoLoad();
    simpleProductRulesEvidenceKey.personID = globals.getPersonReferenceNumber().getValueNoLoad();

    // execute
    SimpleProductRulesEvidenceDetails simpleProductRulesEvidenceDetails = RulesSimpleProductEvidenceFactory.newInstance().getEvidence(
      simpleProductRulesEvidenceKey);
    
    int i = 0;
    
    rdoSimpleProductRulesEvidenceList.startLoader();
    
    /*
     * This will generate two list objectives:
     * 1st with value =   'daily rate'+5 and description = "yes"
     * 2nd with value = 2*'daily rate'+5 and description = "no"
     */
    while (i < 2) {

      rdoSimpleProductRulesEvidenceList.insertIfRequired(i);
      rdoSimpleProductRulesEvidenceList.setCurrentPos(i);
      
      Money dailyRate = new Money(
        (simpleProductRulesEvidenceDetails.dailyRate.getValue() * (i + 1)) + 5);
      
      // map data
      rdoSimpleProductRulesEvidenceList.current().geteligibleInd().setValue(
        simpleProductRulesEvidenceDetails.eligibleInd);

      // BEGIN, CR00296014, KH
      // When the child component is disabled, list objective two is disabled
      if (i == 1 && !simpleProductRulesEvidenceDetails.childIndicator) {
        rdoSimpleProductRulesEvidenceList.current().geteligibleInd().setValue(
          false);
      }
      // END, CR00296014

      rdoSimpleProductRulesEvidenceList.current().getdailyRate().setValue(
        dailyRate);

      String description = CuramConst.gkEmpty;
      
      if (0 == i) {
        description = CuramConst.gkYes;
      } else {
        description = CuramConst.gkNo;
      }
      
      rdoSimpleProductRulesEvidenceList.current().getdescription().setValue(
        description);
      
      i++;
    }
    rdoSimpleProductRulesEvidenceList.endLoader();
  }

}
