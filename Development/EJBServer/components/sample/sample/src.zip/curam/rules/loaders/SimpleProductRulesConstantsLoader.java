/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.rules.loaders;


import curam.rules.rdo.SimpleProductRulesConstantsGroup;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This module contains the constants for the Simple Product Constants Loader
 * implementation
 *
 */
public class SimpleProductRulesConstantsLoader extends curam.util.rules.Loader {

  //
  // Constants used to populate the values loaded by this loader.
  //

  // This is the minimum age a person must be in order to be considered
  // eligible for entitlements
  protected final static int kMinAge = 18;

  // This is the maximum age a person must be in order to be considered
  // eligible for entitlements
  protected final static int kMaxAge = 65;

  // ___________________________________________________________________________
  /**
   * Method to return data items based on constant values set within this
   * class
   *
   * @param rp Rules Parameter
   *
   */
  protected void load(curam.util.rules.RulesParameters rp)
    throws AppException, InformationalException {

    SimpleProductRulesConstantsGroup simpleProductRulesConstantsGroup =
      SimpleProductRulesConstantsGroup.getCurrentInstance(rp);

    // map out
    simpleProductRulesConstantsGroup.getkMinAge().setValue(kMinAge);
    simpleProductRulesConstantsGroup.getkMaxAge().setValue(kMaxAge);
  }

}
