/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.rules.loaders;


import curam.rules.rdo.FSAssessmentHholdEvidenceGroup;
import curam.rules.rdo.FSAssessmentIncomeEvidenceGroup;
import curam.sample.sl.struct.HouseholdEvidenceDetailsList;
import curam.sample.sl.struct.HouseholdEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.rules.ItemGroupGlobals;


public class FSAssessmentHouseholdLoader extends curam.util.rules.Loader {

  static int kAge60 = 60;

  // ___________________________________________________________________________
  /**
   * Method to retrieve data from the Business Process called by this loader
   * based on the rules parameters passed in. The values returned are used to
   * set the necessary data items.
   *
   * @param rp Rules Parameter
   */
  protected void load(curam.util.rules.RulesParameters rp) throws AppException, InformationalException {
    // declare data structures

    ItemGroupGlobals globals = ItemGroupGlobals.getCurrentInstance(rp);

    FSAssessmentIncomeEvidenceGroup fsAssessmentIncomeEvidenceGroup =
      FSAssessmentIncomeEvidenceGroup.getCurrentInstance(rp);

    FSAssessmentHholdEvidenceGroup fsAssessmentHholdEvidenceGroup =
      FSAssessmentHholdEvidenceGroup.getCurrentInstance(rp);

    // RulesHealthGrantEvidenceKey variables
    HouseholdEvidenceKey householdEvidenceKey = new HouseholdEvidenceKey();

    // RuleHealthGrantVisitEvidenceDtlsList variable
    HouseholdEvidenceDetailsList householdEvidenceDetailsList;

    // map in
    householdEvidenceKey.caseID =
      globals.getClaimReferenceNumber().getValueNoLoad();
    householdEvidenceKey.assessmentID =
      globals.getAssessmentReferenceNumber().getValueNoLoad();
    householdEvidenceKey.dateOfCalculation =
      globals.getDateOfCalculation().getValueNoLoad();

    // execute
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj =
      curam.sample.sl.fact.IncomeScreeningFactory.newInstance();

    householdEvidenceDetailsList =
      incomeScreeningObj.readHouseholdEvidenceDtls(householdEvidenceKey);

    // map out

    // Set the loop size
    fsAssessmentHholdEvidenceGroup.setLoopSize(
      householdEvidenceDetailsList.hholdDtlsList.size());

    fsAssessmentIncomeEvidenceGroup.getmemberOver60Ind().setValue(false);
    fsAssessmentIncomeEvidenceGroup.getmemberTanfRecipientInd().setValue(false);

    // For each record
    for (int i = 0; i < householdEvidenceDetailsList.hholdDtlsList.size(); i++) {

      // Insert the record
      fsAssessmentHholdEvidenceGroup.insertNewMember();
      // Set values
      fsAssessmentHholdEvidenceGroup.current().getmemberName().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).memberName);
      fsAssessmentHholdEvidenceGroup.current().getconcernRoleID().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).concernRoleID);
      fsAssessmentHholdEvidenceGroup.current().getmemberAge().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).memberAge);
      fsAssessmentHholdEvidenceGroup.current().getdisabledInd().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).disabledInd);
      fsAssessmentHholdEvidenceGroup.current().getearnedIncomeAmount().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).earnedIncomeAmount);
      fsAssessmentHholdEvidenceGroup.current().getheadOfHouseholdInd().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).headOfHouseholdInd);
      fsAssessmentHholdEvidenceGroup.current().getineligibleAlienInd().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).ineligibleAlienInd);
      fsAssessmentHholdEvidenceGroup.current().getinvalidSSNInd().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).invalidSSNInd);
      fsAssessmentHholdEvidenceGroup.current().getlivingAloneInd().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).livingAloneInd);
      fsAssessmentHholdEvidenceGroup.current().getmedicalExpenseTotal()
        .setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).medicalExpenseTotal);
      fsAssessmentHholdEvidenceGroup.current().getprepareMealsInd().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).prepareMealsInd);
      fsAssessmentHholdEvidenceGroup.current().getresourceAmount().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).resourceAmount);
      fsAssessmentHholdEvidenceGroup.current().getshelterExpenseTotal()
        .setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).shelterExpenseTotal);
      fsAssessmentHholdEvidenceGroup.current().getstrikerInd().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).strikerInd);
      fsAssessmentHholdEvidenceGroup.current().getunearnedIncomeAmount()
        .setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i)
          .unearnedIncomeAmount);
      fsAssessmentHholdEvidenceGroup.current().getfoodStampsRecipientInd()
        .setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i)
          .foodStampsRecipientInd);
      fsAssessmentHholdEvidenceGroup.current().getspouseOfHOHInd().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).spouseOfHOHInd);
      fsAssessmentHholdEvidenceGroup.current().getresidingWithParentsInd()
        .setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i)
          .residingWithParentsInd);
      fsAssessmentHholdEvidenceGroup.current().getliveInAttendantInd().setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i).liveInAttendantInd);
      fsAssessmentHholdEvidenceGroup.current().getinvalidResourceTransferInd()
        .setValue(
        householdEvidenceDetailsList.hholdDtlsList.item(i)
          .invalidResourceTransferInd);

      if (householdEvidenceDetailsList.hholdDtlsList.item(i)
        .memberAge > kAge60) {

        fsAssessmentIncomeEvidenceGroup.getmemberOver60Ind().setValue(true);

      }

      if (householdEvidenceDetailsList.hholdDtlsList.item(i).tanfRecipientInd
        == true) {

        fsAssessmentIncomeEvidenceGroup.getmemberTanfRecipientInd().setValue(
          true);

      }

    }

  }

}
