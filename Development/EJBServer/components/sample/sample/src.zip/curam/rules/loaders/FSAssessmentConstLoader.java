/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.rules.loaders;


import curam.rules.rdo.FSAssessmentConstantsGroup;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public class FSAssessmentConstLoader extends curam.util.rules.Loader {

  // Constants used to populate the values loaded by this loader.
  protected final static int kAge18 = 18;
  protected final static int kAge60 = 60;
  protected final static curam.util.type.Money kResourceLimit =
    new curam.util.type.Money(2000);
  protected final static curam.util.type.Money kResourceO60Limit =
    new curam.util.type.Money(3000);
  protected final static double kEarnedIncomePercent = 0.2;
  protected final static double kShelterExpensePercent = 0.5;
  protected final static curam.util.type.Money kStandardDeduction4 =
    new curam.util.type.Money(134);
  protected final static curam.util.type.Money kStandardDeduction5 =
    new curam.util.type.Money(147);
  protected final static curam.util.type.Money kStandardDeduction6 =
    new curam.util.type.Money(168);
  protected final static curam.util.type.Money kMaxShelterExpense =
    new curam.util.type.Money(364);
  protected final static curam.util.type.Money kAddGrossIncomeAmt =
    new curam.util.type.Money(334);
  protected final static curam.util.type.Money kAddNetIncomeAmt =
    new curam.util.type.Money(257);
  protected final static curam.util.type.Money kMedicalExpenseExcessAmt =
    new curam.util.type.Money(35);
  protected final static short kZeroValue = 0;

  // ___________________________________________________________________________
  /**
   * Method to return data items based on constant values set within this
   * class
   *
   * @param rp Rules Parameter
   */

  protected void load(curam.util.rules.RulesParameters rp)
    throws AppException, InformationalException {

    FSAssessmentConstantsGroup fsAssessmentConstantsGroup =
      FSAssessmentConstantsGroup.getCurrentInstance(rp);

    // map out
    fsAssessmentConstantsGroup.getkFSAge18().setValue(kAge18);
    fsAssessmentConstantsGroup.getkFSAge60().setValue(kAge60);
    fsAssessmentConstantsGroup.getkFSResourceLimit().setValue(kResourceLimit);
    fsAssessmentConstantsGroup.getkFSResourceO60Limit().setValue(
      kResourceO60Limit);
    fsAssessmentConstantsGroup.getkFSEarnedIncomePercent().setValue(
      kEarnedIncomePercent);
    fsAssessmentConstantsGroup.getkFSShelterExpensePercent().setValue(
      kShelterExpensePercent);
    fsAssessmentConstantsGroup.getkFSStandardDeduction4().setValue(
      kStandardDeduction4);
    fsAssessmentConstantsGroup.getkFSStandardDeduction5().setValue(
      kStandardDeduction5);
    fsAssessmentConstantsGroup.getkFSStandardDeduction6().setValue(
      kStandardDeduction6);
    fsAssessmentConstantsGroup.getkFSMaxShelterExpense().setValue(
      kMaxShelterExpense);
    fsAssessmentConstantsGroup.getkFSAdditionalGrossIncomeAmt().setValue(
      kAddGrossIncomeAmt);
    fsAssessmentConstantsGroup.getkFSAdditionalNetIncomeAmt().setValue(
      kAddNetIncomeAmt);
    fsAssessmentConstantsGroup.getkFSMedicalExpenseExcessAmt().setValue(
      kMedicalExpenseExcessAmt);
    fsAssessmentConstantsGroup.getkFSZeroValue().setValue(kZeroValue);

  }

}
