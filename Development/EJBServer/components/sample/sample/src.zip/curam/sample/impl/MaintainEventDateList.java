/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import java.util.Calendar;

import com.google.inject.Inject;

import curam.codetable.RATETABLETYPE;
import curam.core.sl.entity.struct.RateCellByColumnIDKey;
import curam.core.sl.entity.struct.RateCellDtlsList;
import curam.core.sl.entity.struct.RateColumnDtlsList;
import curam.core.sl.entity.struct.RateColumnSearchByHeaderIDIn;
import curam.core.sl.entity.struct.RateHeaderByRateTableTypeIn;
import curam.core.sl.entity.struct.RateHeaderDtlsList;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngine;
import curam.core.sl.struct.DecisionDateDetails;
import curam.core.struct.PersonKey;
import curam.core.struct.ReadDateOfBirthDetails;
import curam.sample.struct.DetermineProductSignificantBirthdaysDetails;
import curam.sample.struct.DetermineProductSignificantBirthdaysKey;
import curam.sample.struct.DetermineProductSignificantBirthdaysListDetails;
import curam.sample.struct.MemberSignificantBirthdaysKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;


/**
 * Processes to maintain the event date list for the Benefit Sample Product
 */
public abstract class MaintainEventDateList extends curam.sample.base.MaintainEventDateList {

  // BEGIN, CR00232051, GD
  @Inject
  private AssessmentEngine assessmentEngine;
  
  // ___________________________________________________________________________
  /**
   * Add injection.
   */
  public MaintainEventDateList() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  // END, CR00232051
  
  // ___________________________________________________________________________
  /**
   * Method to add any significant birthdays for the member to the event
   * date list.  Each product will have it own set of significant birthdays on
   * which the eligibility and entitlements of a member may change.
   *
   * @param key Contains the identifier for participant
   *            and the product delivery case
   */
  public void addMemberSignificantBithdays(MemberSignificantBirthdaysKey key)
    throws AppException, InformationalException {

    DetermineProductSignificantBirthdaysKey determineProductSignificantBirthdaysKey =
      new DetermineProductSignificantBirthdaysKey();

    determineProductSignificantBirthdaysKey.productID = key.productID;
    determineProductSignificantBirthdaysKey.effectiveDate = key.effectiveDate;

    // Read the significant birthdays for the benefit product
    DetermineProductSignificantBirthdaysListDetails determineProductSignificantBirthdaysListDetails =
      determineProductSignificantBirthdays(
        determineProductSignificantBirthdaysKey);

    // Create and populate the key to read the person date of birth
    PersonKey personKey = new PersonKey();

    personKey.concernRoleID = key.participantRoleID;

    curam.core.intf.Person personObj =
      curam.core.fact.PersonFactory.newInstance();

    // Read the person date of birth
    ReadDateOfBirthDetails readDateOfBirthDetails =
      personObj.readDateOfBirth(personKey);

    Calendar calendarDate = readDateOfBirthDetails.dateOfBirth.getCalendar();

    // Add the person's significant birthdays to the date list
    for (int i = 0; i
      < determineProductSignificantBirthdaysListDetails.dtls.size(); i++) {

      calendarDate.add(Calendar.YEAR,
        determineProductSignificantBirthdaysListDetails.dtls.item(i)
          .significantAge);

      // Create and populate the decision date struct
      // BEGIN, CR00232051, GD
      DecisionDateDetails decisionDateDetails = new DecisionDateDetails();

      decisionDateDetails.caseID = key.caseID;
      decisionDateDetails.decisionDate = new Date(calendarDate);
      decisionDateDetails.productID = key.productID;

      // Add a date to the date list
      assessmentEngine.addDecisionDate(decisionDateDetails);
      // END, CR00232051      

      // Reset the calendar date back to the date of birth
      calendarDate = readDateOfBirthDetails.dateOfBirth.getCalendar();
    }

  }

  // ___________________________________________________________________________
  /**
   * Method to determine the significant birthdays of Sample Benefit product.
   *
   * @param key Contains the effective date
   */
  public DetermineProductSignificantBirthdaysListDetails determineProductSignificantBirthdays(DetermineProductSignificantBirthdaysKey key)
    throws AppException, InformationalException {

    // Return struct
    DetermineProductSignificantBirthdaysListDetails determineProductSignificantBirthdaysListDetails =
      new DetermineProductSignificantBirthdaysListDetails();

    // variables for reading rate cell details list
    curam.core.sl.entity.intf.RateCell rateCellObj =
      curam.core.sl.entity.fact.RateCellFactory.newInstance();

    curam.core.sl.entity.intf.RateColumn rateColumnObj =
      curam.core.sl.entity.fact.RateColumnFactory.newInstance();
    curam.core.sl.entity.intf.RateHeader rateHeaderObj =
      curam.core.sl.entity.fact.RateHeaderFactory.newInstance();

    //
    // Find the rate header ID
    //
    RateHeaderByRateTableTypeIn rateHeaderByRateTableTypeIn =
      new RateHeaderByRateTableTypeIn();

    rateHeaderByRateTableTypeIn.rateTableType =
      RATETABLETYPE.SAMPLEBENEFITSIGNIFICANBIRTHDAYS;

    RateHeaderDtlsList rateHeaderDtlsList =
      rateHeaderObj.searchByRateTableType(rateHeaderByRateTableTypeIn);

    //
    // Find the rate column ID
    //

    RateColumnSearchByHeaderIDIn rateColumnSearchByHeaderIDIn =
      new RateColumnSearchByHeaderIDIn();

    rateColumnSearchByHeaderIDIn.rateHeaderID =
      rateHeaderDtlsList.dtls.item(0).rateHeaderID;

    RateColumnDtlsList rateColumnDtlsList =
      rateColumnObj.searchByHeaderID(rateColumnSearchByHeaderIDIn);

    //
    // Read by rate column to retrieve all cells
    //

    RateCellByColumnIDKey rateCellByColumnIDKey = new RateCellByColumnIDKey();

    rateCellByColumnIDKey.rateColumnID =
      rateColumnDtlsList.dtls.item(0).rateColumnID;

    RateCellDtlsList rateCellDtlsList =
      rateCellObj.searchByColumn(rateCellByColumnIDKey);

    // Iterate through the list of significant dates and add them to
    // the return object
    for (int i = 0; i < rateCellDtlsList.dtls.size(); i++) {

      DetermineProductSignificantBirthdaysDetails determineProductSignificantBirthdaysDetails =
        new DetermineProductSignificantBirthdaysDetails();

      determineProductSignificantBirthdaysDetails.significantAge =
        (int) rateCellDtlsList.dtls.item(i).rateCellValue;

      determineProductSignificantBirthdaysListDetails.dtls.addRef(
        determineProductSignificantBirthdaysDetails);
    }

    return determineProductSignificantBirthdaysListDetails;

  }

}
