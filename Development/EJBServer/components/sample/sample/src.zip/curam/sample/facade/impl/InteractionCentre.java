/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003-2004, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;


import curam.core.facade.struct.ParticipantContextDescriptionDetails;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ParticipantContextKey;
import curam.core.impl.SecurityImplementationFactory;
import curam.sample.facade.struct.ClientInteractionPersonSearchDetails;
import curam.sample.facade.struct.ClientInteractionPersonSearchKey;
import curam.sample.facade.struct.ReadClientInteractionHomePageDetails;
import curam.sample.facade.struct.ReadClientInteractionHomePageKey;
import curam.sample.facade.struct.RecordCommentsDetails;
import curam.sample.facade.struct.RecordInteractionKey;
import curam.sample.facade.struct.VerifyInteractionCentreParametersDetails;
import curam.sample.facade.struct.VerifyInteractionCentreParametersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for the Interaction Center
 * presentation layer.
 */
public abstract class InteractionCentre extends curam.sample.facade.base.InteractionCentre {

  // ___________________________________________________________________________
  /**
   * Searches for a person by ConcernRoleID.
   *
   * @param key Identifies the person concerned.
   *
   * @return The details of the person read.
   * 
   */
  @SuppressWarnings("deprecation")
  public ClientInteractionPersonSearchDetails personSearch(ClientInteractionPersonSearchKey key)
    throws AppException, InformationalException {

    // details to be returned
    ClientInteractionPersonSearchDetails clientInteractionPersonSearchDetails =
      new ClientInteractionPersonSearchDetails();

    curam.sample.sl.intf.InteractionCentre interactionCentreObj =
      curam.sample.sl.fact.InteractionCentreFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // reads person details
    clientInteractionPersonSearchDetails.clientInteractionSearchDetails =
      interactionCentreObj.personSearch(key.clientInteractionSearchKey);

    // return the details
    return clientInteractionPersonSearchDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads a person's interaction home page details and interaction records.
   *
   * @param key Identifies the person concerned.
   *
   * @return The home page details of the person.
   */
  public ReadClientInteractionHomePageDetails readHomePage(ReadClientInteractionHomePageKey key)
    throws AppException, InformationalException {

    // details to be returned

    ReadClientInteractionHomePageDetails readClientInteractionHomePageDetails =
      new ReadClientInteractionHomePageDetails();

    curam.sample.sl.intf.InteractionCentre interactionCentreObj =
      curam.sample.sl.fact.InteractionCentreFactory.newInstance();


    // register the security implementation
    SecurityImplementationFactory.register();

    // read person interaction homepage details
    readClientInteractionHomePageDetails.readPersonInteractionHomePageDetails =
      interactionCentreObj.readPersonInteractionHomePage(
        key.readPersonInteractionHomePageKey);

    // context key
    ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID =
      key.readPersonInteractionHomePageKey.readPersonInteractionHomePageKey.participantID;

    // get the context description for the concern role
    readClientInteractionHomePageDetails.participantContextDescriptionDetails =
      readParticipantContextDescription(
        participantContextKey.participantContextDescriptionKey);

    // return the details
    return readClientInteractionHomePageDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads a person's interaction home page details and interaction records.
   * Shows all except the most recent(current) interaction.
   *
   * @param key Identifies the person concerned.
   *
   * @return The home page details of the person.
   */
  public ReadClientInteractionHomePageDetails readHomePagePreviousInteractions(ReadClientInteractionHomePageKey key)
    throws AppException, InformationalException {

    // register the security implementation
    SecurityImplementationFactory.register();

    // details to be returned
    ReadClientInteractionHomePageDetails readClientInteractionHomePageDetails =
      readHomePage(key);

    // filter out the most recent one (current one)
    readClientInteractionHomePageDetails.readPersonInteractionHomePageDetails.listInteractionDetails.detailsList.dtls.remove(
      0);

    return readClientInteractionHomePageDetails;

  }

  // ___________________________________________________________________________
  /**
   * Verifies interaction Center parameters social security number
   * and interactionID.
   *
   * @param key Interaction center parameter.
   *
   * @return participant id and verification code.
   */
  public VerifyInteractionCentreParametersDetails verifyInteractionCentreParameters(
    VerifyInteractionCentreParametersKey key)
    throws AppException, InformationalException {

    // details to be returned
    VerifyInteractionCentreParametersDetails verifyInteractionCentreParametersDetails =
      new VerifyInteractionCentreParametersDetails();

    curam.sample.sl.intf.InteractionCentre interactionCentreObj =
      curam.sample.sl.fact.InteractionCentreFactory.newInstance();


    // register the security implementation
    SecurityImplementationFactory.register();

    // verify interaction center parameter social security number
    // and interaction id
    verifyInteractionCentreParametersDetails.dtls =
      interactionCentreObj.verifyInteractionCentreParameters(key.dtls);

    // return the details
    return verifyInteractionCentreParametersDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads the person's context description.
   *
   * @param key Contains the person identifier.
   *
   * @return A context description for a person.
   */
  public ParticipantContextDescriptionDetails readParticipantContextDescription(ParticipantContextDescriptionKey key)
    throws AppException, InformationalException {

    // context details to be returned
    ParticipantContextDescriptionDetails participantContextDescriptionDetails;

    // participant context object
    curam.core.facade.intf.ParticipantContext participantContextObj =
      curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // context key
    ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID =
      key.concernRoleID;

    // get the context description for the concern role
    participantContextDescriptionDetails =
      participantContextObj.readContextDescription(
        participantContextKey.participantContextDescriptionKey);

    // return the details
    return participantContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Inserts a client Interaction Record.
   *
   * @param key Contains the person identifier.
   */
  public void recordInteraction(RecordInteractionKey key)
    throws AppException, InformationalException {

    curam.sample.sl.intf.InteractionCentre interactionCentreObj =
      curam.sample.sl.fact.InteractionCentreFactory.newInstance();


    // register the security implementation
    SecurityImplementationFactory.register();

    // record interaction details
    interactionCentreObj.recordInteraction(key.key);
  }

  // ___________________________________________________________________________
  /**
   * Records comments for an Interaction.
   *
   * @param details contains the key and the comments entered
   */
  public void recordComments(RecordCommentsDetails details)
    throws AppException, InformationalException {

    curam.sample.sl.intf.InteractionCentre interactionCentreObj =
      curam.sample.sl.fact.InteractionCentreFactory.newInstance();


    // register the security implementation
    SecurityImplementationFactory.register();

    // record comments
    interactionCentreObj.recordComments(details.recordInteractionComments);

  }
}
