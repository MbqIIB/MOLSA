/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import org.apache.log4j.Logger;

import curam.core.impl.EnvVars;
import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.sample.sl.entity.struct.SimpleProductDtls;
import curam.sample.sl.entity.struct.SimpleProductKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo.TransactionType;


/**
 * This class provides cached access to the SimpleProduct entity. This is
 * used in batch mode to increase the performance of this operation.
 *
 */
public abstract class CachedSimpleProduct extends curam.sample.base.CachedSimpleProduct {

  protected static ThreadLocal cachedSimpleProductDtls = new ThreadLocal();
  // ___________________________________________________________________________
  // Logger for the caching output
  // BEGIN, CR00052924, GM
  public static final String kBatchCachingCategory = Trace.kDefaultTraceCategory
    + ExtensionConst.kBatchCachingCategory;
  // END, CR00052924
  public static final Logger kBatchLauncherCacheLogger = Logger.getLogger(
    kBatchCachingCategory);

  public static final boolean logging;
  // ___________________________________________________________________________

  // static to hold the logging_enabled environmental Variable
  static {
    String logging_enabled = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED);

    if (logging_enabled == null) {
      logging_enabled = EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED_DEFAULT;
    }

    if (logging_enabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      logging = true;

    } else {
      logging = false;
    }
  }

  // ___________________________________________________________________________
  /**
   * This method provides a simple cache for access to the SimpleProduct
   * Entity.
   *
   * @param key The key containing the simpleProductID
   *
   * @return The details of the SimpleProduct record
   */
  public SimpleProductDtls read(SimpleProductKey key)
    throws AppException, InformationalException {

    // variable to hold transaction type
    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    // If this is a batch transaction, and we've hit the cache
    // just copy the data from the cache
    if (transactionType.equals(TransactionType.kBatch)) {
      SimpleProductDtls simpleProductDtls = getCachedDtls();

      if (simpleProductDtls != null
        && simpleProductDtls.simpleProductID == key.simpleProductID) {

        return simpleProductDtls;
      }
    }

    // Otherwise we need to read the SimpleProduct data
    return reloadDtlsCache(key);
  }

  // ___________________________________________________________________________
  /**
   * This method is used to clear the cache.
   *
   */
  public void clearCache() throws AppException, InformationalException {

    cachedSimpleProductDtls.set(null);

  }

  // ___________________________________________________________________________
  /**
   * This method is used to reload the cache when a cache miss is identified
   *
   * @param key The key for the SimpleProduct record
   * @return The details of the SimpleProduct
   */
  public SimpleProductDtls reloadDtlsCache(SimpleProductKey key) throws AppException, InformationalException {

    // variable to hold transaction type
    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    curam.sample.sl.entity.intf.SimpleProduct simpleProductObj = curam.sample.sl.entity.fact.SimpleProductFactory.newInstance();

    SimpleProductDtls simpleProductDtls = simpleProductObj.read(key);

    // If this was a cache miss, refresh the cache
    if (transactionType.equals(TransactionType.kBatch)) {

      // set the cache with a copy of the Dtls
      SimpleProductDtls simpleProductDtlsCache = new SimpleProductDtls();

      cachedSimpleProductDtls.set(
        simpleProductDtlsCache.assign(simpleProductDtls));
    }

    return simpleProductDtls;

  }

  // ___________________________________________________________________________
  /**
   * This method is used to access the cached SimpleProduct details
   *
   * @return The details of the SimpleProduct
   */
  public SimpleProductDtls getCachedDtls() {

    SimpleProductDtls simpleProductDtlsCache = (SimpleProductDtls) cachedSimpleProductDtls.get();

    if (simpleProductDtlsCache != null) {

      SimpleProductDtls simpleProductDtls = new SimpleProductDtls();

      // return a copy of the cached Dtls
      return simpleProductDtls.assign(simpleProductDtlsCache);

    }

    return null;

  }

}
