/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import curam.codetable.PRODUCTTYPE;
import curam.core.sl.fact.ReassessmentProductFactory;
import curam.core.sl.struct.GetEvidenceKey;
import curam.core.sl.struct.OverpmtEvidenceDetails;
import curam.core.struct.InformationalMsgDtlsList;
import curam.sample.sl.entity.struct.EvidenceDateAndVersionNoKey;
import curam.sample.struct.GetLiabilityOverpaymentEvidenceResult;
import curam.sample.struct.MaintainLiabilityOverpaymentEvidenceDetails;
import curam.sample.struct.MaintainLiabilityOverpaymentEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code to get the details of Liability Overpayment Evidences
 */
public abstract class MaintainLiabilityOverpaymentEvidence
  extends curam.sample.base.MaintainLiabilityOverpaymentEvidence {

  // BEGIN, CR00192165, VM
  // ___________________________________________________________________________
  /**
   * Retrieves the evidence for the specified case. If the evidence ID is set
   * in the key, that evidence will be retrieved, otherwise the current
   * evidence will be retrieved.
   *
   * @param key Structure containing relevant case ID.
   *
   * @return Structure containing evidence details, related case details and
   *    concern role evidence details.
   *
   * @deprecated since Curam 6.0, replaced with
   *   {@link curam.core.sl.impl.ReassessmentProduct#getLiabilityOverpaymentEvidence(
   *     GetEvidenceKey)}
   * <P>
   * As part of the work for separating the sample and core components,
   * the Liability Overpayment Evidence entity and associated processing has
   * been moved into core. See release note CR00192165.
   * </P>
   */
  public GetLiabilityOverpaymentEvidenceResult getEvidence(
    MaintainLiabilityOverpaymentEvidenceKey key)
    throws AppException, InformationalException {

    GetLiabilityOverpaymentEvidenceResult getLiabilityOverpaymentEvidenceResult =
      new GetLiabilityOverpaymentEvidenceResult();

    GetEvidenceKey getEvidenceKey = new GetEvidenceKey();

    getEvidenceKey.caseID = key.caseID;
    getEvidenceKey.date = key.date;
    getEvidenceKey.evidenceID = key.evidenceID;

    curam.core.sl.struct.GetLiabilityOverpaymentEvidenceResult result =
      ReassessmentProductFactory.newInstance().getLiabilityOverpaymentEvidence(
        getEvidenceKey);

    getLiabilityOverpaymentEvidenceResult.maintainLiabilityOverpaymentEvidenceDetails.caseID =
      result.details.caseID;
    getLiabilityOverpaymentEvidenceResult.maintainLiabilityOverpaymentEvidenceDetails.effectiveFromDate =
      result.details.effectiveFromDate;
    getLiabilityOverpaymentEvidenceResult.maintainLiabilityOverpaymentEvidenceDetails.evidenceID =
      result.details.evidenceID;
    getLiabilityOverpaymentEvidenceResult.maintainLiabilityOverpaymentEvidenceDetails.fromDate =
      result.details.fromDate;
    getLiabilityOverpaymentEvidenceResult.maintainLiabilityOverpaymentEvidenceDetails.toDate =
      result.details.toDate;
    getLiabilityOverpaymentEvidenceResult.maintainLiabilityOverpaymentEvidenceDetails.overpaymentAmount =
      result.details.overpaymentAmount;
    getLiabilityOverpaymentEvidenceResult.maintainLiabilityOverpaymentEvidenceDetails.overpaymentEvidenceID =
      result.details.overpaymentEvidenceID;
    getLiabilityOverpaymentEvidenceResult.maintainLiabilityOverpaymentEvidenceDetails.reassessmentDate =
      result.details.reassessmentDate;
    getLiabilityOverpaymentEvidenceResult.maintainLiabilityOverpaymentEvidenceDetails.relatedCaseID =
      result.details.relatedCaseID;
    getLiabilityOverpaymentEvidenceResult.maintainLiabilityOverpaymentEvidenceDetails.versionNo =
      result.details.versionNo;

    getLiabilityOverpaymentEvidenceResult.productDeliverySummaryDetails =
      result.productDeliverySummary;
    getLiabilityOverpaymentEvidenceResult.maintainConcernRoleEvidenceDetails.concernRoleID =
      result.concernDetails.concernRoleID;
    getLiabilityOverpaymentEvidenceResult.maintainConcernRoleEvidenceDetails.concernRoleType =
      result.concernDetails.concernRoleType;
    getLiabilityOverpaymentEvidenceResult.maintainConcernRoleEvidenceDetails.concernRoleName =
      result.concernDetails.concernRoleName;
    getLiabilityOverpaymentEvidenceResult.maintainConcernRoleEvidenceDetails.concernAddressData =
      result.concernDetails.concernAddressData;

    return getLiabilityOverpaymentEvidenceResult;
  }

  // ___________________________________________________________________________
  /**
   * This method creates case evidences.
   *
   * @param dtls Maintain Liability Overpayment Evidence details
   *
   * @deprecated since Curam 6.0, replaced with
   *   {@link curam.core.sl.impl.ReassessmentProduct#createOverpaymentEvidence(
   *     OverpmtEvidenceDetails)}
   * <P>
   * As part of the work for separating the sample and core components,
   * the Liability Overpayment Evidence entity and associated processing has
   * been moved into core. See release note CR00192165.
   * </P>
   */
  public void createEvidence(
    MaintainLiabilityOverpaymentEvidenceDetails dtls)
    throws AppException, InformationalException {

    OverpmtEvidenceDetails overpmtEvidenceDetails = new OverpmtEvidenceDetails();

    overpmtEvidenceDetails.amount = dtls.overpaymentAmount;
    overpmtEvidenceDetails.fromDate = dtls.fromDate;
    overpmtEvidenceDetails.toDate = dtls.toDate;
    overpmtEvidenceDetails.relatedCaseID = dtls.relatedCaseID;
    overpmtEvidenceDetails.caseID = dtls.caseID;
    overpmtEvidenceDetails.type = PRODUCTTYPE.LIABILITYOVERPAYMENT;

    ReassessmentProductFactory.newInstance().createOverpaymentEvidence(
      overpmtEvidenceDetails);
  }

  // ___________________________________________________________________________
  /**
   * Maintains the evidence for the specified case. If the date-time is not set
   * in the date key, the current evidence will be used, otherwise the closest
   * evidence to the supplied date-time will be used.
   *
   * @param dtls Maintain Liability Overpayment Evidence details.
   * @param evidenceDateAndVersionNoKey date from which the evidence is
   *         effective, the evidence ID and the version number.
   *
   * @return Informational messages.
   *
   * @deprecated since Curam 6.0, replaced with
   *   {@link curam.core.sl.impl.ReassessmentProduct#maintainLiabilityOverpaymentEvidence(
   *     curam.core.sl.struct.MaintainLiabilityOverpaymentEvidenceDetails,
   *     curam.core.sl.struct.EvidenceDateAndVersionNoKey)}
   * <P>
   * As part of the work for separating the sample and core components,
   * the Liability Overpayment Evidence entity and associated processing has
   * been moved into core. See release note CR00192165.
   * </P>
   */
  public InformationalMsgDtlsList maintainEvidence(
    MaintainLiabilityOverpaymentEvidenceDetails dtls,
    EvidenceDateAndVersionNoKey evidenceDateAndVersionNoKey)
    throws AppException, InformationalException {

    curam.core.sl.struct.MaintainLiabilityOverpaymentEvidenceDetails details =
      new curam.core.sl.struct.MaintainLiabilityOverpaymentEvidenceDetails();

    details.caseID = dtls.caseID;
    details.effectiveFromDate = dtls.effectiveFromDate;
    details.evidenceID = dtls.evidenceID;
    details.fromDate = dtls.fromDate;
    details.toDate = dtls.toDate;
    details.overpaymentAmount = dtls.overpaymentAmount;
    details.overpaymentEvidenceID = dtls.overpaymentEvidenceID;
    details.reassessmentDate = dtls.reassessmentDate;
    details.relatedCaseID = dtls.relatedCaseID;
    details.versionNo = dtls.versionNo;

    curam.core.sl.struct.EvidenceDateAndVersionNoKey key =
      new curam.core.sl.struct.EvidenceDateAndVersionNoKey();

    key.effectiveFrom = evidenceDateAndVersionNoKey.effectiveFrom;
    key.evidenceID = evidenceDateAndVersionNoKey.evidenceID;
    key.versionNo = evidenceDateAndVersionNoKey.versionNo;

    return
      ReassessmentProductFactory.newInstance().maintainLiabilityOverpaymentEvidence(
        details, key);
  }
  // END, CR00192165

}
