/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.sample.sl.tab.impl;

/**
 * This class assigns values to the Tab Loader constants
 */
public abstract class SampleTabLoaderConst {

  /**
   * String constants for Sporting Activity Business Object Tab.
   */
  public static final String kSportingActivityNewSportingActivityExpense =
    "NewSportingActivityExpense";

  /**
   * String constant for Legal Status Navigation Item.
   */
  public static final String kLegalStatus = "LegalStatus";

  /**
   * String constant for Services Navigation Item.
   */
  public static final String kServices = "Services";
  
  /**
   * String constant for Referrals Navigation Item.
   */
  public static final String kReferrals = "Referrals";

  /**
   * String constant for Participants Navigation Item.
   */
  public static final String kParticipants = "Participants";

  /**
   * String constant for Participants Folder Navigation Item.
   */
  public static final String kParticipantsFolder = "ParticipantsFolder"; 
  
  /**
   * String constant for Appeals Navigation Item.
   */
  public static final String kAppeals = "Appeals";
  

  /**
   * String constant for Legal Actions Folder Navigation Item.
   */
  public static final String kLegalActions = "LegalActions";

}
