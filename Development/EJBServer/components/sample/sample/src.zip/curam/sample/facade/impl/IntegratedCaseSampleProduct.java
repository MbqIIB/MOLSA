/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;


import curam.core.facade.struct.CreatedCaseIDKey;
import curam.core.facade.struct.WarningsDtls;
import curam.core.facade.struct.WarningsDtlsList;
import curam.core.fact.ProductProvisionFactory;
import curam.core.fact.ProvisionLocationFactory;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.ProductProvision;
import curam.core.intf.ProvisionLocation;
import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.struct.IsEventDateListEnabledDetailsKey;
import curam.core.struct.ProductKey;
import curam.core.struct.ProductProvisionDetails1List;
import curam.core.struct.ProductProvisionKey;
import curam.core.struct.ProvisionLocationDetailsStructRef1List;
import curam.core.struct.RegisterProductDeliveryDetails;
import curam.core.struct.RegisterProductDeliveryKey;
import curam.sample.facade.struct.CreateICProductDetails;
import curam.sample.facade.struct.OutcomeNameAndIDDetailsList;
import curam.sample.struct.MemberSignificantBirthdaysKey;
import curam.sample.struct.SimpleEvidenceDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;


/**
 * Contains the create case function for a product on an Integrated
 * Case.
 *
 */
public abstract class IntegratedCaseSampleProduct extends curam.sample.facade.base.IntegratedCaseSampleProduct {

  // BEGIN, CR00021498, NK
  // ___________________________________________________________________________
  /**
   * Extracts warning message from InformationManager and returns warning details
   *
   * @return Warnings list
   */
  public WarningsDtlsList getWarnings() throws AppException, InformationalException {
    WarningsDtlsList warningsDtlsList = new WarningsDtlsList();

    // InformationalManager

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Retrieve list of informational messages
    String[] messages = informationalManager.obtainInformationalAsString();

    // Return the Informational messages
    for (int i = 0; i < messages.length; i++) {

      WarningsDtls warningsDtls = new WarningsDtls();

      warningsDtls.warning = messages[i];
      warningsDtlsList.dtls.addRef(warningsDtls);
    }

    return warningsDtlsList;
  }

  // END, CR00021498

  // ___________________________________________________________________________
  /**
   * Creates a product delivery and associated evidence on an Integrated Case.
   *
   * @param details Details to create the Integrated Case Sample Product.
   *
   * @return The Case ID of the case created
   */
  public CreatedCaseIDKey createCase(CreateICProductDetails details)
    throws AppException, InformationalException {

    // Create return object
    CreatedCaseIDKey createdCaseIDKey = new CreatedCaseIDKey();

    // CreateProductDelivery manipulation variables
    curam.core.intf.CreateProductDelivery createProductDeliveryObj = curam.core.fact.CreateProductDeliveryFactory.newInstance();
    RegisterProductDeliveryKey registerProductDeliveryKey = new RegisterProductDeliveryKey();
    RegisterProductDeliveryDetails registerProductDeliveryDetails = new RegisterProductDeliveryDetails();

    registerProductDeliveryDetails.integratedCaseInd = true;

    // MaintainSampleBenefitEvidence manipulation variables
    curam.sample.intf.MaintainSimpleProductEvidence maintainSampleProductEvidenceObj = curam.sample.fact.MaintainSimpleProductEvidenceFactory.newInstance();
    SimpleEvidenceDetails simpleEvidenceDetails = new SimpleEvidenceDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // MaintainCase manipulation variables
    curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    // Only get caseID & concernRoleID if a case participant role id exists
    if (details.caseParticipantRoleID != 0) {
      // Read caseID & ConcernRoleID by searching on CaseParticipantRoleID
      // passed in.
      caseParticipantRoleKey.caseParticipantRoleID = details.caseParticipantRoleID;

      caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj.readCaseIDandParticipantID(
        caseParticipantRoleKey);

      // Assign caseID and concern role id details to the
      details.clientID = caseIDAndParticipantRoleIDDetails.participantRoleID;

      details.integratedCaseID = caseIDAndParticipantRoleIDDetails.caseID;
    }

    // Assign details to key
    registerProductDeliveryKey.assign(details);

    // BEGIN, CR00150534, JMA
    registerProductDeliveryKey.caseStartDate = Date.getCurrentDate();
    // BEGIN, CR00347149, KH
    // Use the base currency specified in the application properties
    String baseCurrency = Configuration.getProperty(EnvVars.ENV_BASECURRENCY);

    if (baseCurrency == null) {
      baseCurrency = EnvVars.ENV_BASECURRENCY_DEFAULT; 
    }
    registerProductDeliveryKey.currencyType = baseCurrency;
    // END, CR00347149

    // Get Provider and Location details
    ProductKey productKey = new ProductKey();
    // BEGIN, CR00220013, ZV
    ProductProvisionDetails1List productProvisionDetailsList = new ProductProvisionDetails1List();

    // Get productID from key
    productKey.productID = details.productID;

    ProductProvision productProvisionObj = ProductProvisionFactory.newInstance();

    productProvisionDetailsList = productProvisionObj.searchProvisionByProductID1(
      productKey);
    // END, CR00220013
    // Value to compare earliest provision creation date
    Date earliestProvisionDate = new Date();
    ProductProvisionKey productProvisionKey = new ProductProvisionKey();

    for (int i = 0; i < productProvisionDetailsList.dtls.size(); i++) {

      // Check that provision end date has not passed
      if (productProvisionDetailsList.dtls.item(i).endDate.after(
        Date.getCurrentDate())
          || productProvisionDetailsList.dtls.item(i).endDate.isZero()) {

        if (earliestProvisionDate.isZero()
          || productProvisionDetailsList.dtls.item(i).creationDate.before(
            earliestProvisionDate)) {

          earliestProvisionDate = productProvisionDetailsList.dtls.item(i).creationDate;

          registerProductDeliveryKey.productProviderID = productProvisionDetailsList.dtls.item(i).providerConcernRoleID;
          productProvisionKey.productProvisionID = productProvisionDetailsList.dtls.item(i).productProvisionID;
        }
      }
    }

    // get the provision location
    if (productProvisionKey.productProvisionID != 0) {

      ProvisionLocation provisionLocationObj = ProvisionLocationFactory.newInstance();
      // BEGIN, CR00220013, ZV
      ProvisionLocationDetailsStructRef1List provisionLocationDetailsStructRefList = provisionLocationObj.searchProvisionLocationByProvisionID1(
        productProvisionKey);
      // END, CR00220013

      // Value to compare earliest provision location creation date
      Date earliestProvisionLocationDate = new Date();

      for (int i = 0; i < provisionLocationDetailsStructRefList.dtls.size(); i++) {

        // Check that provision location end date has not passed
        if (provisionLocationDetailsStructRefList.dtls.item(i).endDate.after(
          Date.getCurrentDate())
            || provisionLocationDetailsStructRefList.dtls.item(i).endDate.isZero()) {

          if (earliestProvisionLocationDate.isZero()
            || provisionLocationDetailsStructRefList.dtls.item(i).creationDate.before(
              earliestProvisionDate)) {

            earliestProvisionLocationDate = provisionLocationDetailsStructRefList.dtls.item(i).creationDate;

            registerProductDeliveryKey.providerLocationID = provisionLocationDetailsStructRefList.dtls.item(i).providerLocationID;
          }
        }
      }
    }
    // END, CR00150534

    // Set the integrated case id as related case id
    registerProductDeliveryKey.relatedCaseID = details.integratedCaseID;

    // Call CreateProductDelivery BPO to register the Sample Benefit Product
    createdCaseIDKey.caseID = createProductDeliveryObj.registerProductDelivery(registerProductDeliveryKey, registerProductDeliveryDetails).caseID;

    // Assign details to create initial evidence on the Sample Benefit
    simpleEvidenceDetails.assign(details);
    simpleEvidenceDetails.caseID = createdCaseIDKey.caseID;

    // Call MaintainSimpleBenefitEvidence BPO to create initial evidence
    // on the Sample Benefit case that has just been created above
    maintainSampleProductEvidenceObj.createEvidence(simpleEvidenceDetails);

    // If the event based date list is being used by the Assessment Engine
    // the claimants significant birthdays need to be added to the date list
    curam.core.sl.intf.CaseEligibilityDates caseEligibilityDatesObj = curam.core.sl.fact.CaseEligibilityDatesFactory.newInstance();

    IsEventDateListEnabledDetailsKey isEventDateListEnabledDetailsKey = new IsEventDateListEnabledDetailsKey();

    isEventDateListEnabledDetailsKey.productID = details.productID;

    if (caseEligibilityDatesObj.isEventDateListEnabled(isEventDateListEnabledDetailsKey).result) {

      curam.sample.intf.MaintainEventDateList maintainEventDateListObj = curam.sample.fact.MaintainEventDateListFactory.newInstance();

      // Create and populate the key
      MemberSignificantBirthdaysKey memberSignificantBirthdaysKey = new MemberSignificantBirthdaysKey();

      memberSignificantBirthdaysKey.caseID = createdCaseIDKey.caseID;
      memberSignificantBirthdaysKey.effectiveDate = details.caseStartDate;
      memberSignificantBirthdaysKey.participantRoleID = details.clientID;
      memberSignificantBirthdaysKey.productID = details.productID;

      // Add the claimants significant birthdays
      maintainEventDateListObj.addMemberSignificantBithdays(
        memberSignificantBirthdaysKey);
    }

    // BEGIN, CR00021498, NK
    createdCaseIDKey.warnings = getWarnings();
    // END, CR00021498

    return createdCaseIDKey;
  }

  // ___________________________________________________________________________
  /**
   * Lists all existing outcomes.
   *
   * @return List of existing outcome details (name and ID)
   */
  public OutcomeNameAndIDDetailsList listAllExistingOutcomes()
    throws AppException, InformationalException {

    // return value
    OutcomeNameAndIDDetailsList outcomeNameAndIDDetailsList = new OutcomeNameAndIDDetailsList();

    // Product Delivery Planned Item business object
    curam.core.sl.intf.ProductDeliveryPlanItemLink productDeliveryPlanItemLinkObj = curam.core.sl.fact.ProductDeliveryPlanItemLinkFactory.newInstance();

    // list all existing outcomes
    outcomeNameAndIDDetailsList.OutcomeNameAndIDDetailsList = productDeliveryPlanItemLinkObj.listAllExpectedOutcomes();

    // return the list
    return outcomeNameAndIDDetailsList;
  }

}
