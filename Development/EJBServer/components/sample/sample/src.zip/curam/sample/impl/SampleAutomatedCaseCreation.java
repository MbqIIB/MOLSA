/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2005, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import curam.core.fact.AutomatedCaseCreationFactory;
import curam.core.struct.AutomatedCreateCaseDetails;
import curam.core.struct.BeneficiaryDetails;
import curam.core.struct.NewCreatedCaseDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Sample implementation of Methods to create a new over/underpayment case or
 * send a ticket to the case owner letting them know that an over/underpayment
 * case is required.
 *
 * @deprecated since-v6.0
 */
@Deprecated
public abstract class SampleAutomatedCaseCreation extends curam.sample.base.SampleAutomatedCaseCreation {

  protected static final int kOneElement = 1;

  // ___________________________________________________________________________
  /**
   * Method to automatically create a new overpayment case.
   *
   * @param details details of the original case, the type of case required and
   *         the amount
   * @param beneficiaryDetails details of the beneficiary
   *
   * @return the caseID of the new case
   *
   * @deprecated since-v6.0
   */
  public NewCreatedCaseDetails createAutomatedCase(
    AutomatedCreateCaseDetails details,
    BeneficiaryDetails beneficiaryDetails)
    throws AppException, InformationalException {

    return
      AutomatedCaseCreationFactory.newInstance().createAutomatedCase(
        details, beneficiaryDetails);
  }

  // ___________________________________________________________________________
  /**
   * Description:
   *   Creates a ticket for the newly created case.
   *
   * @param newDetails details of the original case, the
   *                    type of case required and the amount
   * @param details the caseID of the new case
   *
   * @deprecated since-v6.0
   */
  public void createTicketForNewCase(
    NewCreatedCaseDetails newDetails,
    AutomatedCreateCaseDetails details)
    throws AppException, InformationalException {

    AutomatedCaseCreationFactory.newInstance().createTicketForNewCase(newDetails,
      details);
  }

  // ___________________________________________________________________________
  /**
   * Description:
   *   Creates evidence for the new overpayment case.
   *
   * @param newCreatedCaseDetails the caseID of the new case
   * @param details details of the original case, the
   *         type of case required and the amount
   *
   * @deprecated since-v6.0
   */
  public void createEvidenceForNewCase(
    NewCreatedCaseDetails newCreatedCaseDetails,
    AutomatedCreateCaseDetails details)
    throws AppException, InformationalException {

    AutomatedCaseCreationFactory.newInstance().createEvidenceForNewCase(
      newCreatedCaseDetails, details);
  }

}
