/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.entity.impl;


import curam.codetable.CASEEVIDENCE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.SAMPLESPORTINGACTIVITYTYPE;
import curam.core.impl.CuramConst;
import curam.core.sl.impl.ExternalEvidenceInterface;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.entity.struct.RelatedIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.EvidenceInterface;
import curam.core.sl.infrastructure.impl.StandardEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.EvidenceTransferDetails;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.SharedEvidenceDescriptorDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseRelationshipCaseIDKey;
import curam.core.struct.IntegratedCaseKey;
import curam.core.struct.RelatedCasesDetailsList;
import curam.message.BPOSAMPLESPORTINGACTIVITY;
import curam.message.ENTSAMPLESPORTINGSPONSORSHIP;
import curam.sample.sl.entity.fact.SampleSportingActivityExpenseFactory;
import curam.sample.sl.entity.fact.SampleSportingActivityFactory;
import curam.sample.sl.entity.fact.SportingSponsorshipFactory;
import curam.sample.sl.entity.intf.SampleSportingActivity;
import curam.sample.sl.entity.intf.SampleSportingActivityExpense;
import curam.sample.sl.entity.struct.SampleSportingActivityDtls;
import curam.sample.sl.entity.struct.SampleSportingActivityExpenseDtls;
import curam.sample.sl.entity.struct.SampleSportingActivityExpenseKey;
import curam.sample.sl.entity.struct.SampleSportingActivityKey;
import curam.sample.sl.entity.struct.SportingSponsorshipDtls;
import curam.sample.sl.entity.struct.SportingSponsorshipKey;
import curam.sample.sl.entity.struct.ValidateDuplicateSponsorshipDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;


/*
 * Operations for the SampleSportingActivity entity
 */
public class SportingSponsorship extends curam.sample.sl.entity.base.SportingSponsorship
  implements EvidenceInterface, ExternalEvidenceInterface {

  // ___________________________________________________________________________
  /**
   * Calculate the attribution dates for the case
   *
   * @param caseKey Contains the case identifier
   * @param evKey Contains the evidenceID and evidenceType
   *
   * @return The attribution dates for the entity
   */
  public AttributedDateDetails calcAttributionDatesForCase(
    CaseKey caseKey, EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // Return object
    AttributedDateDetails attributedDateDetails = new AttributedDateDetails();

    attributedDateDetails.fromDate = Date.kZeroDate;
    attributedDateDetails.toDate = Date.kZeroDate;

    return attributedDateDetails;
  }

  // ___________________________________________________________________________
  /**
   * Gets evidence details for the list display
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   *
   * @return Evidence details to be displayed on the list page
   */
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = new EIFieldsForListDisplayDtls();

    // SampleSportingActivityKey entity key
    SportingSponsorshipKey SportingSponsorshipKey = new SportingSponsorshipKey();

    // Read the SampleSportingActivity entity to get display details
    SportingSponsorshipKey.sportingSponsorshipID = key.evidenceID;
    SportingSponsorshipDtls SportingSponsorshipDtls = read(
      SportingSponsorshipKey);

    // Set the start / end dates
    eiFieldsForListDisplayDtls.startDate = Date.kZeroDate;
    ;
    eiFieldsForListDisplayDtls.endDate = Date.kZeroDate;
    ;

    // Set the summary details.
    StringBuffer strBuf = new StringBuffer(
      // BEGIN, CR00163098, JC
      CodeTable.getOneItem(SAMPLESPORTINGACTIVITYTYPE.TABLENAME,
      SportingSponsorshipDtls.sponsorshipType,
      TransactionInfo.getProgramLocale()));

    // END, CR00163098, JC

    // BEGIN, CR00052924, GM
    strBuf.append(CuramConst.gkSpace).append(
      SportingSponsorshipDtls.sponsorshipAmount);
    // END, CR00052924

    eiFieldsForListDisplayDtls.summary = strBuf.toString();

    return eiFieldsForListDisplayDtls;
  }

  // ___________________________________________________________________________
  /**
   * Inserts Sample Sporting Sponsorship evidence
   *
   * @param parentKey Key containing
   *
   * @return Key containing the evidenceID and evidenceType
   */
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey)
    throws AppException, InformationalException {

    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((SportingSponsorshipDtls) dtls);

    eiEvidenceKey.evidenceID = ((SportingSponsorshipDtls) dtls).sportingSponsorshipID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SPORTINGSPONSORSHIP;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Inserts Sample Sporting Sponsorship evidence on modification
   * @param origKey 
   * @param parentKey Key containing
   *
   * @return Key containing the evidenceID and evidenceType
   */
  public EIEvidenceKey insertEvidenceOnModify(
    Object dtls, EIEvidenceKey origKey, EIEvidenceKey parentKey)
    throws AppException, InformationalException {

    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((SportingSponsorshipDtls) dtls);

    eiEvidenceKey.evidenceID = ((SportingSponsorshipDtls) dtls).sportingSponsorshipID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SPORTINGSPONSORSHIP;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modify Sample Sporting Sponsorship evidence
   *
   * @param key Evidence key containing evidenceID and evidenceType
   * @param dtls Sample Sporting Sponsorship entity details
   */
  public void modifyEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // SampleSportingActivityKey object
    SportingSponsorshipKey SportingSponsorshipKey = new SportingSponsorshipKey();

    // Set entity key for modify
    SportingSponsorshipKey.sportingSponsorshipID = key.evidenceID;

    // Modify details
    modify(SportingSponsorshipKey, (SportingSponsorshipDtls) dtls);
  }

  // ___________________________________________________________________________
  /**
   * Reads all child records.
   *
   * @param key Contains an evidenceID / evidenceType pairing
   *
   * @return List of evidenceID / evidenceType pairings
   */
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key)
    throws AppException, InformationalException {

    // Do nothing... this entity is a top level entity. No parent.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * Read Sample Sporting Sponsorship evidence
   *
   * @param key Evidence key containing evidenceID and evidenceType
   *
   * @return Sample Sporting Sponsorship entity details
   */
  public Object readEvidence(EIEvidenceKey key)
    throws AppException, InformationalException {

    // SampleSportingActivityKey object
    SportingSponsorshipKey SportingSponsorshipKey = new SportingSponsorshipKey();

    // Set key to read SampleSportingActivity
    SportingSponsorshipKey.sportingSponsorshipID = key.evidenceID;

    // Read SampleSportingActivity
    return read(SportingSponsorshipKey);
  }

  // ___________________________________________________________________________
  /**
   * Inserts Sample Sporting Sponsorship details
   *
   * @param details Sample Sporting Sponsorship details
   */
  protected void preinsert(SportingSponsorshipDtls details)
    throws AppException, InformationalException {

    validate(details);
  }

  // ___________________________________________________________________________
  /**
   * Modifies Sample Sporting Sponsorship details
   *
   * @param key Sample Sporting Sponsorship key
   * @param details Sample Sporting Sponsorship details
   */
  protected void premodify(SportingSponsorshipKey key,
    SportingSponsorshipDtls details)
    throws AppException, InformationalException {

    validate(details);
  }

  // ___________________________________________________________________________
  /**
   * Validates Sample Sporting Sponsorship entity details
   *
   * @param details Sample Sporting Sponsorship details
   */
  public void validate(SportingSponsorshipDtls details)
    throws AppException, InformationalException {

    // The amount entered must be positive
    if (!details.sponsorshipAmount.isPositive()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSAMPLESPORTINGACTIVITY.ERR_SA_FV_PAYMENT_AMOUNT_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // A sponsorship type must be specified
    if (details.sponsorshipType.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSAMPLESPORTINGACTIVITY.ERR_SA_FV_ACTIVITY_TYPE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Selects all the records for validations
   *
   * @param evKey Contains an evidenceID / evidenceType pairing
   *
   * @return List of evidenceID / evidenceType pairings
   */
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey)
    throws AppException, InformationalException {

    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    // BEGIN, CR00091163, VM
    // Casting to interface to avoid class cast exceptions when tracing is
    // turned on
    StandardEvidenceInterface standardEvidenceInterface = (StandardEvidenceInterface) SampleSportingActivityExpenseFactory.newInstance();

    // END, CR00091163

    eiEvidenceKey.evidenceID = evKey.evidenceID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SPORTINGSPONSORSHIP;

    EIEvidenceKeyList eiEvidenceKeyList = standardEvidenceInterface.readAllByParentID(
      eiEvidenceKey);

    eiEvidenceKeyList.dtls.add(0, evKey);

    return eiEvidenceKeyList;
  }

  // ___________________________________________________________________________
  /**
   * Validates evidence details
   *
   * @param evKey Evidence key
   * @param evKeyList Evidence key list
   * @param mode Validate mode (insert, delete, applyChanges, modify)
   */
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList,
    ValidateMode mode) throws AppException, InformationalException {

    // EvidenceDescriptor manipulation variables

    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey = new RelatedIDAndEvidenceTypeKey();

    relatedIDAndEvidenceTypeKey.relatedID = evKey.evidenceID;
    relatedIDAndEvidenceTypeKey.evidenceType = evKey.evidenceType;

    EvidenceDescriptorDtls evidenceDescriptorDtls = evidenceDescriptorObj.readByRelatedIDAndType(
      relatedIDAndEvidenceTypeKey);

    // BEGIN, CR00127135, ELG
    // Sporting Sponsorship manipulation variables
    curam.sample.sl.entity.intf.SportingSponsorship sportingSponsorshipObj = SportingSponsorshipFactory.newInstance();

    SportingSponsorshipKey currSportingSponsorshipKey = new SportingSponsorshipKey();

    currSportingSponsorshipKey.sportingSponsorshipID = evKey.evidenceID;

    SportingSponsorshipDtls sportingSponsorshipDtls = sportingSponsorshipObj.read(
      currSportingSponsorshipKey);

    // END, CR00127135

    if (!((mode.applyChanges)
      && evidenceDescriptorDtls.statusCode.equals(
        EVIDENCEDESCRIPTORSTATUS.CANCELED))
          || ((mode.validateChanges)
            && evidenceDescriptorDtls.pendingRemovalInd == true)) {

      ValidateDuplicateSponsorshipDtls validateDuplicateSponsorshipDtls = new ValidateDuplicateSponsorshipDtls();

      // BEGIN, CR00127135, ELG
      validateDuplicateSponsorshipDtls.dtls = sportingSponsorshipDtls;
      // END, CR00127135
      validateDuplicateSponsorshipDtls.caseID = evidenceDescriptorDtls.caseID;

      if (mode.applyChanges) {
        validateDuplicateSponsorshipDtls.validateOnAppliedChangesInd = true;
      } else {
        validateDuplicateSponsorshipDtls.validateOnAppliedChangesInd = false;
      }
      validateDuplicates(validateDuplicateSponsorshipDtls);

    }

    if (mode.applyChanges) {

      // CaseHeader manipulation variables
      curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

      // BEGIN, CR00127135, ELG
      // SampleSportingActivityKey entity key
      SportingSponsorshipKey sportingSponsorshipKey = new SportingSponsorshipKey();

      // END, CR00127135

      // get the case's parent case ID - the Integrated case ID
      caseKey.caseID = evidenceDescriptorDtls.caseID;
      IntegratedCaseKey integratedCaseKey = caseHeaderObj.readIntegratedCaseIDByCaseID(
        caseKey);

      RelatedCasesDetailsList relatedCasesDetailsList = new RelatedCasesDetailsList();
      CaseRelationshipCaseIDKey caseRelationshipCaseIDKey = new CaseRelationshipCaseIDKey();

      caseRelationshipCaseIDKey.caseID = integratedCaseKey.integratedCaseID;

      // get all the case relationships for this integrated case
      curam.core.intf.CaseRelationship caseRelationshipObj = curam.core.fact.CaseRelationshipFactory.newInstance();

      relatedCasesDetailsList = caseRelationshipObj.searchCaseRelationshipByCaseID(
        caseRelationshipCaseIDKey);

      // BEGIN, CR00127135, ELG
      double totalSponsorshipAmount = 0;
      double totalSportingActivityAmount = 0;
      double totalSportingActivityExpenseAmount = 0;

      CaseIDKey caseIDKeyIC = new CaseIDKey();
      CaseIDKey caseIDKeyPD = new CaseIDKey();

      EvidenceDescriptorDtlsList evidenceDescriptorDtlsListPD;
      EvidenceDescriptorDtlsList evidenceDescriptorDtlsListIC;

      EvidenceDescriptorDtls evidenceDescriptorDtlsPD;
      EvidenceDescriptorDtls evidenceDescriptorDtlsIC;

      // Sample sporting activity manipulation variables
      SampleSportingActivity sampleSportingActivityObj = SampleSportingActivityFactory.newInstance();
      SampleSportingActivityKey sampleSportingActivityKey = new SampleSportingActivityKey();
      SampleSportingActivityDtls sampleSportingActivityDtls;

      // Sample sporting activity expense manipulation variables
      SampleSportingActivityExpense sampleSportingActivityExpenseObj = SampleSportingActivityExpenseFactory.newInstance();
      SampleSportingActivityExpenseKey sampleSportingActivityExpenseKey = new SampleSportingActivityExpenseKey();
      SampleSportingActivityExpenseDtls sampleSportingActivityExpenseDtls;

      // Calculate all amounts for product deliveries.
      for (int i = 0; i < relatedCasesDetailsList.dtls.size(); i++) {

        caseIDKeyPD.caseID = relatedCasesDetailsList.dtls.item(i).relatedCaseID;

        evidenceDescriptorDtlsListPD = evidenceDescriptorObj.searchByCaseID(
          caseIDKeyPD);

        for (int k = 0; k < evidenceDescriptorDtlsListPD.dtls.size(); k++) {

          evidenceDescriptorDtlsPD = evidenceDescriptorDtlsListPD.dtls.item(k);

          // BEGIN, CR00147554, CW
          // We are in Apply Changes mode so do not include In Edit or
          // Superseded evidence records for validation
          if (!evidenceDescriptorDtlsPD.statusCode.equals(
            EVIDENCEDESCRIPTORSTATUS.CANCELED)
              && !evidenceDescriptorDtlsPD.statusCode.equals(
                EVIDENCEDESCRIPTORSTATUS.INEDIT)
                && !evidenceDescriptorDtlsPD.statusCode.equals(
                  EVIDENCEDESCRIPTORSTATUS.SUPERSEDED)) {
            // END, CR00147554

            // Calculate total sponsorship amount
            if (evidenceDescriptorDtlsPD.evidenceType.equals(
              CASEEVIDENCE.SPORTINGSPONSORSHIP)) {

              sportingSponsorshipKey.sportingSponsorshipID = evidenceDescriptorDtlsPD.relatedID;
              sportingSponsorshipDtls = read(sportingSponsorshipKey);

              totalSponsorshipAmount = totalSponsorshipAmount
                + sportingSponsorshipDtls.sponsorshipAmount.getValue();

              // Calculate total sample sporting activity amount
            } else if (evidenceDescriptorDtlsPD.evidenceType.equals(
              CASEEVIDENCE.SAMPLESPORTINGACTIVITY)) {

              sampleSportingActivityKey.sportingActivityID = evidenceDescriptorDtlsPD.relatedID;

              sampleSportingActivityDtls = sampleSportingActivityObj.read(
                sampleSportingActivityKey);
              totalSportingActivityAmount = totalSportingActivityAmount
                + sampleSportingActivityDtls.paymentAmount.getValue();

              // Calculate total sample sporting activity expense amount
            } else if (evidenceDescriptorDtlsPD.evidenceType.equals(
              CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE)) {

              sampleSportingActivityExpenseKey.sportingActivityExpenseID = evidenceDescriptorDtlsPD.relatedID;
              sampleSportingActivityExpenseDtls = sampleSportingActivityExpenseObj.read(
                sampleSportingActivityExpenseKey);

              totalSportingActivityExpenseAmount = totalSportingActivityExpenseAmount
                + sampleSportingActivityExpenseDtls.amount.getValue();
            }

          }

        }

      }

      caseIDKeyIC.caseID = integratedCaseKey.integratedCaseID;
      evidenceDescriptorDtlsListIC = evidenceDescriptorObj.searchByCaseID(
        caseIDKeyIC);

      // Calculate amounts for IC evidence.
      for (int k = 0; k < evidenceDescriptorDtlsListIC.dtls.size(); k++) {

        evidenceDescriptorDtlsIC = evidenceDescriptorDtlsListIC.dtls.item(k);

        if (!evidenceDescriptorDtlsIC.statusCode.equals(
          EVIDENCEDESCRIPTORSTATUS.CANCELED)) {

          // Calculate sample sporting activity expense amount
          if (evidenceDescriptorDtlsIC.evidenceType.equals(
            CASEEVIDENCE.SAMPLESPORTINGACTIVITYEXPENSE)) {

            sampleSportingActivityExpenseKey.sportingActivityExpenseID = evidenceDescriptorDtlsIC.relatedID;
            sampleSportingActivityExpenseDtls = sampleSportingActivityExpenseObj.read(
              sampleSportingActivityExpenseKey);

            totalSportingActivityExpenseAmount = totalSportingActivityExpenseAmount
              + sampleSportingActivityExpenseDtls.amount.getValue();

            // Calculate sample sporting activity amount
          } else if (evidenceDescriptorDtlsIC.evidenceType.equals(
            CASEEVIDENCE.SAMPLESPORTINGACTIVITY)) {

            sampleSportingActivityKey.sportingActivityID = evidenceDescriptorDtlsIC.relatedID;
            sampleSportingActivityDtls = sampleSportingActivityObj.read(
              sampleSportingActivityKey);

            totalSportingActivityAmount = totalSportingActivityAmount
              + sampleSportingActivityDtls.paymentAmount.getValue();

          }

        }

      }

      double netSportingActivityAmount = totalSportingActivityAmount
        - totalSportingActivityExpenseAmount;

      if (netSportingActivityAmount < totalSponsorshipAmount) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            ENTSAMPLESPORTINGSPONSORSHIP.ERR_SAMPLE_SPORTINGSPONSORSHIP_XRV_AMOUNT_GREARWE_THAN_IC),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);

      }
      // END, CR00127135

    }

  }

  // ___________________________________________________________________________
  /**
   * Validate for duplicate evidence records
   *
   * @param validateDtls Details to check for duplicate evidence
   */
  public void validateDuplicates(ValidateDuplicateSponsorshipDtls validateDtls)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Retrieve evidence for this case

    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();
    CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey = new CaseIDAndEvidenceTypeKey();

    caseIDAndEvidenceTypeKey.caseID = validateDtls.caseID;
    caseIDAndEvidenceTypeKey.evidenceType = CASEEVIDENCE.SPORTINGSPONSORSHIP;

    eiEvidenceKeyList.assign(
      evidenceDescriptorObj.searchAllByTypeForCase(caseIDAndEvidenceTypeKey));
    // BEGIN, CR00101929, PDN
    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    // End, CR00101929

    eiEvidenceKeyList = evidenceControllerObj.filterActiveAndPendingChanges(
      eiEvidenceKeyList);

    SportingSponsorshipDtls SportingSponsorshipDtls = new SportingSponsorshipDtls();
    SportingSponsorshipKey SportingSponsorshipKey = new SportingSponsorshipKey();

    // EvidenceDescriptor entity objects
    RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey = new RelatedIDAndEvidenceTypeKey();

    //
    // Retrieve the instanceID of the modified evidence
    //
    relatedIDAndEvidenceTypeKey.evidenceType = CASEEVIDENCE.SPORTINGSPONSORSHIP;
    relatedIDAndEvidenceTypeKey.relatedID = validateDtls.dtls.sportingSponsorshipID;

    EvidenceDescriptorDtls updatedEvidenceDescriptorDtls = evidenceDescriptorObj.readByRelatedIDAndType(
      relatedIDAndEvidenceTypeKey);

    for (int i = 0; i < eiEvidenceKeyList.dtls.size(); i++) {

      // Read the details for the current record
      SportingSponsorshipKey.sportingSponsorshipID = eiEvidenceKeyList.dtls.item(i).evidenceID;

      SportingSponsorshipDtls = read(SportingSponsorshipKey);

      // Get the instance ID of the current record
      relatedIDAndEvidenceTypeKey.relatedID = eiEvidenceKeyList.dtls.item(i).evidenceID;

      EvidenceDescriptorDtls currentEvidenceDescriptorDtls = evidenceDescriptorObj.readByRelatedIDAndType(
        relatedIDAndEvidenceTypeKey);
      
      // BEGIN, CR00147554, CW
      // If we are validating on apply changes then we do not want to consider In Edit records
      if (validateDtls.validateOnAppliedChangesInd
        && currentEvidenceDescriptorDtls.statusCode.equals(
          EVIDENCEDESCRIPTORSTATUS.INEDIT)) {
        
        continue;
      }
      // END, CR00147554


      // Check the Disability Type and case participant match ignoring
      // the record with the same identifier and records with the same SuccessionID

      if (SportingSponsorshipDtls.sponsorshipType.equals(
        validateDtls.dtls.sponsorshipType)

          // If the correctionSetID's are equal this is a change of
          // circumstance and the original record will be superseded.
          // Likewise if the successionID's are equal this means both
          // records are in the same succession set. This means that
          // the original record is being cloned. In both cases we can
          // safely ignore these records.

          && !currentEvidenceDescriptorDtls.correctionSetID.equals(
            updatedEvidenceDescriptorDtls.correctionSetID)
            && currentEvidenceDescriptorDtls.successionID
              != updatedEvidenceDescriptorDtls.successionID) {

        // If we are validating on Apply Changes throw an error, otherwise
        // throw a warning

        AppException appException = new AppException(
          ENTSAMPLESPORTINGSPONSORSHIP.ERR_SAMPLE_SPORTINGSPONSORSHIP_XRV_SPORTINGSPONSORSHIP_EXISTS);

        if (validateDtls.validateOnAppliedChangesInd) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            appException, CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

        } else {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            appException, CuramConst.gkEmpty,
            InformationalElement.InformationalType.kWarning,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

        }
      }
    }
  }

  // BEGIN, CR00078469, VM
  // ___________________________________________________________________________
  /**
   * Method that does any entity adjustments for moving the evidence record
   * to a new caseID
   *
   * @param details Contains the evidenceID / evidenceType pairings of the
   * evidence to be transferred and the transferred
   * @param fromCaseKey The case from which the evidence is being transferred
   * @param toCaseKey The case to which the evidence is being transferred
   */
  public void transferEvidence(EvidenceTransferDetails details,
    CaseHeaderKey fromCaseKey, CaseHeaderKey toCaseKey)
    throws AppException, InformationalException {// Insert transfer evidence implementation here.
  }

  // END, CR00078469
  
  // BEGIN, CR00206664, PB.
  /**
   * Transfers evidence from a remote case to a source case.
   *
   * @param evidenceObject
   * Contains the evidence key value pair object.
   * @param descriptorDetails 
   * @param details
   * Contains the evidenceID / evidenceType pairings of the evidence to
   * be transferred and the transferred
   * @param fromCaseKey
   * The case from which the evidence is being transferred
   * @param toCaseKey
   * The case to which the evidence is being transferred
   *
   * * @throws AppException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void transferExternalEvidence(final Object evidenceObject,
    final SharedEvidenceDescriptorDetails descriptorDetails,
    final EvidenceTransferDetails details, final CaseHeaderKey fromCaseKey,
    final CaseHeaderKey toCaseKey) throws AppException, InformationalException {// Insert external evidence implementation as required
  }

  // END, CR00206664.
  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   *
   * @param evKey The evidence key.
   */
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    return new Date();
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   *
   * @param evKey The evidence key.
   */
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    return new Date();
  }
  // END, CR002204022
}
