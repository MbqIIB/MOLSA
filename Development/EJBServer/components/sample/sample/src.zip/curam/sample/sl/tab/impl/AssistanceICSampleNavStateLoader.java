/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.sample.sl.tab.impl;


import java.util.Map;

import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.util.resources.Configuration;
import curam.util.tab.impl.DynamicNavStateLoader;
import curam.util.tab.impl.NavigationState;
import curam.util.transaction.TransactionInfo;


/**
 * Populates the sample assistance integrate case navigation.
 */
public class AssistanceICSampleNavStateLoader implements DynamicNavStateLoader {

  // ___________________________________________________________________________
  /**
   * Returns the state of the given list of navigation items.
   *
   * @param navigation The navigation instance to load states into.
   * @param pageParameters The context information, in our current case it is
   * the page parameters.
   *
   * @param idsToUpdate The IDs requested by the client to be updated.
   * @return The same navigation instance with the updated states.
   */
  public NavigationState loadNavState(NavigationState navigation,
    Map<String, String> pageParameters, String[] idsToUpdate) {
    
    String locale = TransactionInfo.getProgramLocale();
    boolean cpmInstalled = Configuration.getBooleanProperty(
      EnvVars.ENV_CPM_ISINSTALLED);     

    for (String id : idsToUpdate) {
      
      if (id.equals(SampleTabLoaderConst.kLegalStatus)) {

        // Only display legal status when appeals is installed
        navigation.setVisible(
          Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED),
          SampleTabLoaderConst.kLegalStatus);
      }
      
      if (id.equals(SampleTabLoaderConst.kReferrals)) {
        
        // Only display referrals when CPM is installed
        navigation.setVisible(cpmInstalled, SampleTabLoaderConst.kReferrals);
      }
      
      if (id.equals(SampleTabLoaderConst.kServices)) {
        
        // Only display services when CPM is installed
        navigation.setVisible(cpmInstalled, SampleTabLoaderConst.kServices);
      }
      
      if (id.equals(CuramConst.kEvidenceFlowNav)) {
         
        // show/hide Evidence Flow link depending on locale
        if (locale.equals(CuramConst.gkConstAR)) {
          navigation.setVisible(false, CuramConst.kEvidenceFlowNav);
        } else {
          navigation.setVisible(true, CuramConst.kEvidenceFlowNav);
        }
      
      }
    
    }
    
    return navigation;
  }

}
