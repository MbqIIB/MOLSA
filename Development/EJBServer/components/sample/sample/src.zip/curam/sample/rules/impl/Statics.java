/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.sample.rules.impl;

import java.util.Calendar;

import curam.creole.execution.session.Session;
import curam.util.type.Date;

/**
 * Static methods available to CREOLE rule sets.
 */
public final class Statics {

  private Statics() {
    // Static access only
  }

  // TODO centralise this date arithmetic into CEF?

  // ____________________________________________________________________________
  /**
   * Computes a date by adding a specified number of years to an existing date.
   * <p>
   * If the input date is February 29th, and adding a number of years results in
   * a year which does not have a February 29th, then March 1st will be
   * returned.
   * 
   * @param session
   *          the CREOLE session used to manipulate rule objects
   * @param date
   *          the date to which to add the specified number of years
   * @param numberOfYears
   *          the number of years to add
   * @return the date the specified number of years after the specified date
   */
  public static Date addYears(final Session session, final Date date,
      final Number numberOfYears) {

    final Calendar calendar = date.getCalendar();

    calendar.roll(Calendar.YEAR, numberOfYears.intValue());

    return new Date(calendar);

  }
}