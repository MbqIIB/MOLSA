/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2003, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;


import curam.core.impl.CuramConst;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.struct.CreateScreeningCaseDtls;
import curam.core.sl.struct.CreateScreeningCaseKey;
import curam.core.sl.struct.RunAssessmentDtls_so;
import curam.core.sl.struct.ScreeningAssessmentResult;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CreateNewVersionOfEvidenceTreeKey;
import curam.core.struct.CreateNewVersionOfEvidenceTreeResult;
import curam.core.struct.EvidenceTypeAndLinkDtls;
import curam.core.struct.EvidenceTypeAndLinkKey;
import curam.sample.facade.struct.CancelBenefitEvidenceKey;
import curam.sample.facade.struct.CancelExpenseEvidenceKey;
import curam.sample.facade.struct.CancelHholdEvidenceKey;
import curam.sample.facade.struct.CancelIncomeEvidenceKey;
import curam.sample.facade.struct.CancelResourceEvidenceKey;
import curam.sample.facade.struct.CaseHomeKey;
import curam.sample.facade.struct.CheckEligibilityKey;
import curam.sample.facade.struct.CheckUserAvailabilityDtls;
import curam.sample.facade.struct.CheckUserAvailabilityKey;
import curam.sample.facade.struct.ContextDetails;
import curam.sample.facade.struct.ContextKey;
import curam.sample.facade.struct.CreateBenefitEvidenceDtls;
import curam.sample.facade.struct.CreateHouseholdEvidenceDtls;
import curam.sample.facade.struct.CreateIncomeEvidenceDtls;
import curam.sample.facade.struct.CreateMedicalExpenseEvidenceDtls;
import curam.sample.facade.struct.CreateResourceEvidenceDtls;
import curam.sample.facade.struct.CreateShelterExpenseEvidenceDtls;
import curam.sample.facade.struct.GetMemberDetailsList;
import curam.sample.facade.struct.GetRegisteredMemberDtls;
import curam.sample.facade.struct.GetRegisteredMemberKey;
import curam.sample.facade.struct.IncomeScreeningAssessmentResult;
import curam.sample.facade.struct.InsertHomePhoneNo;
import curam.sample.facade.struct.InsertMailingAddress;
import curam.sample.facade.struct.InsertPrimaryResAddress;
import curam.sample.facade.struct.InsertWorkPhoneNo;
import curam.sample.facade.struct.ListBenefitEvidenceDtls;
import curam.sample.facade.struct.ListExpenseEvidenceDtls;
import curam.sample.facade.struct.ListHholdEvidenceDtls;
import curam.sample.facade.struct.ListIncomeEvidenceDtls;
import curam.sample.facade.struct.ListResourceEvidenceDtls;
import curam.sample.facade.struct.ModifyBenefitEvidenceDtls;
import curam.sample.facade.struct.ModifyHholdEvidenceDtls;
import curam.sample.facade.struct.ModifyIncomeEvidenceDtls;
import curam.sample.facade.struct.ModifyMedicalExpenseEvidenceDtls;
import curam.sample.facade.struct.ModifyResourceEvidenceDtls;
import curam.sample.facade.struct.ModifyShelterExpenseEvidenceDtls;
import curam.sample.facade.struct.ReadBenefitEvidenceDtls;
import curam.sample.facade.struct.ReadBenefitEvidenceKey;
import curam.sample.facade.struct.ReadEvidenceListKey;
import curam.sample.facade.struct.ReadExpenseEvidenceKey;
import curam.sample.facade.struct.ReadHholdEvidenceDtls;
import curam.sample.facade.struct.ReadHholdEvidenceKey;
import curam.sample.facade.struct.ReadIncomeEvidenceDtls;
import curam.sample.facade.struct.ReadIncomeEvidenceKey;
import curam.sample.facade.struct.ReadMedicalExpenseEvidenceDtls;
import curam.sample.facade.struct.ReadMembersListKey;
import curam.sample.facade.struct.ReadResourceEvidenceDtls;
import curam.sample.facade.struct.ReadResourceEvidenceKey;
import curam.sample.facade.struct.ReadShelterExpenseEvidenceDtls;
import curam.sample.facade.struct.ScheduleAppointmentDtls;
import curam.sample.facade.struct.ScreeningCaseDtls;
import curam.sample.facade.struct.ScreeningCaseHomeDetails;
import curam.sample.facade.struct.ScreeningCaseKey;
import curam.sample.sl.entity.struct.FSHouseholdEvidenceDtls;
import curam.sample.sl.struct.AssessmentInfoDtls;
import curam.sample.sl.struct.AssessmentInfoKey;
import curam.sample.sl.struct.AssessmentResultText;
import curam.sample.sl.struct.CreateAppointmentDetails;
import curam.sample.sl.struct.CreateBfitEvidenceDtls;
import curam.sample.sl.struct.CreateExpEvidenceDtls;
import curam.sample.sl.struct.CreateHholdEvidenceDtls;
import curam.sample.sl.struct.GetBenefitEvidenceDetails;
import curam.sample.sl.struct.GetBenefitEvidenceKey;
import curam.sample.sl.struct.GetBenefitEvidenceListDetailsList;
import curam.sample.sl.struct.GetEvidenceListKey;
import curam.sample.sl.struct.GetExpenseEvidenceDetails;
import curam.sample.sl.struct.GetExpenseEvidenceDetailsList;
import curam.sample.sl.struct.GetExpenseEvidenceKey;
import curam.sample.sl.struct.GetHouseholdEvidenceKey;
import curam.sample.sl.struct.GetIncomeEvidenceKey;
import curam.sample.sl.struct.GetIncomeEvidenceListDetailsList;
import curam.sample.sl.struct.GetMemberNameKey;
import curam.sample.sl.struct.GetMembersListKey;
import curam.sample.sl.struct.GetResourceEvidenceKey;
import curam.sample.sl.struct.GetResourceEvidenceListDetailsList;
import curam.sample.sl.struct.GetUserAvailabilityKey;
import curam.sample.sl.struct.GethouseholdEvidenceListDetailsList;
import curam.sample.sl.struct.InsertAddressDtls;
import curam.sample.sl.struct.InsertHomePhoneDtls;
import curam.sample.sl.struct.InsertMailingAddressDtls;
import curam.sample.sl.struct.InsertWorkPhoneDtls;
import curam.sample.sl.struct.ModifyBenefitEvidenceDetails;
import curam.sample.sl.struct.ModifyExpenseEvidenceDetails;
import curam.sample.sl.struct.ModifyHouseholdEvidenceDetails;
import curam.sample.sl.struct.ModifyIncomeEvidenceDetails;
import curam.sample.sl.struct.ModifyResourceEvidenceDetails;
import curam.sample.sl.struct.RemoveBenefitEvidenceKey;
import curam.sample.sl.struct.RemoveExpenseEvidenceKey;
import curam.sample.sl.struct.RemoveHouseholdEvidenceKey;
import curam.sample.sl.struct.RemoveIncomeEvidenceKey;
import curam.sample.sl.struct.RemoveResourceEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for the screening case
 *
 */
public abstract class IncomeScreening extends curam.sample.facade.base.IncomeScreening {

  // ___________________________________________________________________________
  /**
   * To cancel/remove a specified fsHouseholdBenefit evidence record.
   *
   * @param key Identifies evidence to be canceled
   */
  public void cancelBenefitEvidence(CancelBenefitEvidenceKey key)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    RemoveBenefitEvidenceKey removeBenefitEvidenceKey = new RemoveBenefitEvidenceKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform the Benefit evidence removal
    removeBenefitEvidenceKey.cancBfitKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    removeBenefitEvidenceKey.cancBfitKey.fsHouseholdBenefitsID = key.fsHouseholdBenefitsID;
    removeBenefitEvidenceKey.cancBfitKey.versionNo = key.versionNo;

    incomeScreeningObj.removeBenefitEvidence(removeBenefitEvidenceKey);

  }

  // ___________________________________________________________________________
  /**
   * To cancel/remove a specified fsHouseholdExpense record from the database.
   *
   * @param key Identifies evidence to be canceled
   */
  public void cancelExpenseEvidence(CancelExpenseEvidenceKey key)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    RemoveExpenseEvidenceKey removeExpenseEvidenceKey = new RemoveExpenseEvidenceKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform the Expense evidence removal
    removeExpenseEvidenceKey.cancExpKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    removeExpenseEvidenceKey.cancExpKey.fsHouseholdExpensesID = key.fsHouseholdExpensesID;
    removeExpenseEvidenceKey.cancExpKey.versionNo = key.versionNo;

    incomeScreeningObj.removeExpenseEvidence(removeExpenseEvidenceKey);

  }

  // ___________________________________________________________________________
  /**
   * To cancel/remove a specified fsHouseholdEvidence record from the
   * database
   *
   * @param key Identifies evidence to be canceled
   */
  public void cancelHouseholdEvidence(CancelHholdEvidenceKey key)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    RemoveHouseholdEvidenceKey removeHouseholdEvidenceKey = new RemoveHouseholdEvidenceKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform the Household evidence removal
    removeHouseholdEvidenceKey.cancHholdKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    removeHouseholdEvidenceKey.cancHholdKey.fsHouseholdEvidenceID = key.fsHouseholdEvidenceID;
    removeHouseholdEvidenceKey.cancHholdKey.versionNo = key.versionNo;

    incomeScreeningObj.removeHouseholdEvidence(removeHouseholdEvidenceKey);

  }

  // ___________________________________________________________________________
  /**
   * To remove/cancel a specified fsHouseholdIncome record from the database
   *
   * @param key Identifies evidence to be canceled
   */
  public void cancelIncomeEvidence(CancelIncomeEvidenceKey key)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    RemoveIncomeEvidenceKey removeIncomeEvidenceKey = new RemoveIncomeEvidenceKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform the Income evidence removal
    removeIncomeEvidenceKey.cancIncKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    removeIncomeEvidenceKey.cancIncKey.fsHouseholdIncomeID = key.fsHouseholdIncomeID;
    removeIncomeEvidenceKey.cancIncKey.versionNo = key.versionNo;

    incomeScreeningObj.removeIncomeEvidence(removeIncomeEvidenceKey);

  }

  // ___________________________________________________________________________
  /**
   * To cancel/remove a specified fsHouseholResource record from the database.
   *
   * @param key Identifies evidence to be canceled
   */
  public void cancelResourceEvidence(CancelResourceEvidenceKey key)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    RemoveResourceEvidenceKey removeResourceEvidenceKey = new RemoveResourceEvidenceKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform the Resource evidence removal
    removeResourceEvidenceKey.cancResourceKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    removeResourceEvidenceKey.cancResourceKey.fsHouseholdResourceID = key.fsHouseholdResourceID;
    removeResourceEvidenceKey.cancResourceKey.versionNo = key.versionNo;

    incomeScreeningObj.removeResourceEvidence(removeResourceEvidenceKey);

  }

  // ___________________________________________________________________________
  /**
   * Creates a screening case, creates the evidence tree for the food stamp
   * product and inserts household evidence.
   *
   * @param key key to create a screening case
   * @param dtls details to create a screening case
   *
   * @return details of the screening case created
   */
  @SuppressWarnings("deprecation")
  public ScreeningCaseDtls createScreeningCase(
    ScreeningCaseKey key,
    CreateHouseholdEvidenceDtls dtls)
    throws AppException, InformationalException {

    // screeningCaseDtls manipulation variable
    ScreeningCaseDtls screeningCaseDtls = new ScreeningCaseDtls();

    // screening_so manipulation variables
    curam.core.sl.intf.Screening screening_soObj = curam.core.sl.fact.ScreeningFactory.newInstance();
    CreateScreeningCaseKey createScreeningCaseKey = new CreateScreeningCaseKey();
    CreateScreeningCaseDtls createScreeningCaseDtls;

    // manipulate evidence tree manipulation variables
    curam.core.intf.ManipulateEvidenceTree manipulateEvidenceTreeObj = curam.core.fact.ManipulateEvidenceTreeFactory.newInstance();
    CreateNewVersionOfEvidenceTreeKey createNewVersionOfEvidenceTreeKey = new CreateNewVersionOfEvidenceTreeKey();
    CreateNewVersionOfEvidenceTreeResult createNewVersionOfEvidenceTreeResult;
    EvidenceTypeAndLinkDtls evidenceTypeAndLinkDtlsIn = new EvidenceTypeAndLinkDtls();
    EvidenceTypeAndLinkKey evidenceTypeAndLinkKey = new EvidenceTypeAndLinkKey();
    EvidenceTypeAndLinkDtls evidenceTypeAndLinkDtlsOut;

    // fsHouseholdEvidence object and details
    curam.sample.sl.entity.intf.FSHouseholdEvidence fsHouseholdEvidenceObj = curam.sample.sl.entity.fact.FSHouseholdEvidenceFactory.newInstance();
    FSHouseholdEvidenceDtls fsHouseholdEvidenceDtls = new FSHouseholdEvidenceDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set the key to create a screening case
    createScreeningCaseKey.concernRoleID = key.concernRoleID;
    createScreeningCaseKey.assessmentNameCode = curam.codetable.ASSESSMENTNAME.FOODSTAMPS;

    // create a screening case on the database for the head of household
    createScreeningCaseDtls = screening_soObj.createScreeningCase(
      createScreeningCaseKey);

    // set the caseID in the return struct
    screeningCaseDtls.caseID = createScreeningCaseDtls.caseID;

    // set the details to create a new version of the evidence tree
    curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    createNewVersionOfEvidenceTreeKey.caseID = createScreeningCaseDtls.caseID;
    createNewVersionOfEvidenceTreeKey.assessmentID = createScreeningCaseDtls.assessmentID;
    createNewVersionOfEvidenceTreeKey.date = currentDate;

    createNewVersionOfEvidenceTreeResult = manipulateEvidenceTreeObj.createNewVersionOfEvidenceTree(
      createNewVersionOfEvidenceTreeKey);

    // map the details to be inserted as food stamp household evidence
    fsHouseholdEvidenceDtls.concernRoleID = key.concernRoleID;
    fsHouseholdEvidenceDtls.citizenshipCode = dtls.citizenshipCode;
    fsHouseholdEvidenceDtls.disabledInd = dtls.disabledInd;
    fsHouseholdEvidenceDtls.prepareMealsInd = true;
    fsHouseholdEvidenceDtls.rshipToHOH = curam.codetable.RELATIONSHIPTYPECODE.SELF;
    fsHouseholdEvidenceDtls.strikerInd = dtls.strikerInd;
    fsHouseholdEvidenceDtls.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

    // create new food stamp household evidence
    fsHouseholdEvidenceObj.insert(fsHouseholdEvidenceDtls);

    // set details to create the new case evidence type and link record
    evidenceTypeAndLinkDtlsIn.evidenceType = curam.codetable.CASEEVIDENCE.HOUSEHOLDEVIDENCE;
    evidenceTypeAndLinkDtlsIn.evidenceTypeCode = curam.codetable.CASEEVIDENCETYPECODE.FOODSTAMPS;
    evidenceTypeAndLinkDtlsIn.evidenceID = createNewVersionOfEvidenceTreeResult.dtls.evidenceID;
    evidenceTypeAndLinkDtlsIn.relatedID = fsHouseholdEvidenceDtls.fsHouseholdEvidenceID;

    evidenceTypeAndLinkKey.evidenceID = createNewVersionOfEvidenceTreeResult.dtls.evidenceID;
    evidenceTypeAndLinkKey.overwriteExisting = true;
    evidenceTypeAndLinkKey.evidenceFormName = curam.codetable.EVIDENCENAMECODE.FOODSTAMPS;

    evidenceTypeAndLinkDtlsOut = manipulateEvidenceTreeObj.createNewCaseEvidenceTypeAndLink(
      evidenceTypeAndLinkKey, evidenceTypeAndLinkDtlsIn);

    // set the caseEvidenceTypeID in the return struct
    screeningCaseDtls.caseEvidenceTypeID = evidenceTypeAndLinkDtlsOut.caseEvidenceTypeID;

    return screeningCaseDtls;
  }

  // ___________________________________________________________________________
  /**
   * To record fsHouseholdBenefit records.
   *
   * @param dtls evidence to be inserted
   */
  public void insertBenefitEvidence(CreateBenefitEvidenceDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    CreateBfitEvidenceDtls createBfitEvidenceDtls = new CreateBfitEvidenceDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // map the household benefit details to be inserted
    createBfitEvidenceDtls.createBfitDtls.assign(dtls);

    incomeScreeningObj.createBenefitEvidence(createBfitEvidenceDtls);

  }

  // ___________________________________________________________________________
  /**
   * To create fsHouseholdExpense record(s) on the database.
   *
   * @param dtls evidence to be inserted
   */
  public void insertShelterExpenseEvidence(
    CreateShelterExpenseEvidenceDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    CreateExpEvidenceDtls createExpEvidenceDtls = new CreateExpEvidenceDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // map the household expense details to be inserted
    createExpEvidenceDtls.assign(dtls);
    createExpEvidenceDtls.expenseCategoryCode = curam.codetable.EXPENSECATEGORYCODE.SHELTEREXPENSES;
    createExpEvidenceDtls.expenseTypeCode = dtls.shelterExpenseTypeCode;

    incomeScreeningObj.createExpenseEvidence(createExpEvidenceDtls);

  }

  // ___________________________________________________________________________
  /**
   * To create fsHouseholdEvidence records on the database.
   *
   * @param dtls evidence to be inserted
   */
  public void insertHouseholdEvidence(CreateHouseholdEvidenceDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    CreateHholdEvidenceDtls createHholdEvidenceDtls = new CreateHholdEvidenceDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // map the household evidence details to be inserted
    createHholdEvidenceDtls.createHholdDtls.assign(dtls);

    incomeScreeningObj.createHouseholdEvidence(createHholdEvidenceDtls);

  }

  // ___________________________________________________________________________
  /**
   * To add fsHouseholdIncome records to the database.
   *
   * @param dtls evidence to be inserted
   */
  public void insertIncomeEvidence(CreateIncomeEvidenceDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    curam.sample.sl.struct.CreateIncomeEvidenceDtls createIncomeEvidenceDtls = new curam.sample.sl.struct.CreateIncomeEvidenceDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // map the income evidence details to be inserted
    createIncomeEvidenceDtls.createIncDtls.assign(dtls);

    incomeScreeningObj.createIncomeEvidence(createIncomeEvidenceDtls);

  }

  // ___________________________________________________________________________
  /**
   * To create fsHouseholdResource record(s) on the database.
   *
   * @param dtls evidence to be inserted
   */
  public void insertResourceEvidence(CreateResourceEvidenceDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    curam.sample.sl.struct.CreateResourceEvidenceDtls createResourceEvidenceDtls = new curam.sample.sl.struct.CreateResourceEvidenceDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // map the household resource details to be inserted
    createResourceEvidenceDtls.createResDtls.assign(dtls);

    incomeScreeningObj.createResourceEvidence(createResourceEvidenceDtls);

  }

  // ___________________________________________________________________________
  /**
   * To retrieve all fsHouseholdBenefitEvidence records from the database.
   *
   * @param key identifies the case
   *
   * @return the evidence list
   */
  public ListBenefitEvidenceDtls listBenefitEvidence(ReadEvidenceListKey key)
    throws AppException, InformationalException {

    // return struct
    ListBenefitEvidenceDtls listBenefitEvidenceDtls = new ListBenefitEvidenceDtls();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetEvidenceListKey getEvidenceListKey = new GetEvidenceListKey();
    GetBenefitEvidenceListDetailsList getBenefitEvidenceListDetailsList;

    // Context details
    ContextDetails contextDetails = new ContextDetails();
    ContextKey contextKey = new ContextKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform the readmulti
    getEvidenceListKey.listKeyDtls.caseID = key.caseID;

    getBenefitEvidenceListDetailsList = incomeScreeningObj.getBenefitEvidenceList(
      getEvidenceListKey);

    listBenefitEvidenceDtls.listBfitDtls = getBenefitEvidenceListDetailsList;

    contextKey.caseID = key.caseID;

    contextDetails = getContextDescription(contextKey);

    listBenefitEvidenceDtls.benefitCtx.description = contextDetails.description;

    return listBenefitEvidenceDtls;

  }

  // ___________________________________________________________________________
  /**
   * To retrieve all fsHouseholdExpense records from the database
   *
   * @param key identifies the case
   *
   * @return the evidence list
   */
  public ListExpenseEvidenceDtls listExpenseEvidence(ReadEvidenceListKey key)
    throws AppException, InformationalException {

    // return struct
    ListExpenseEvidenceDtls listExpenseEvidenceDtls = new ListExpenseEvidenceDtls();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetEvidenceListKey getEvidenceListKey = new GetEvidenceListKey();
    GetExpenseEvidenceDetailsList getExpenseEvidenceDetailsList;

    // Context details
    ContextDetails contextDetails = new ContextDetails();
    ContextKey contextKey = new ContextKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform the readmulti
    getEvidenceListKey.listKeyDtls.caseID = key.caseID;

    getExpenseEvidenceDetailsList = incomeScreeningObj.getExpenseEvidenceList(
      getEvidenceListKey);

    // map details to return struct
    listExpenseEvidenceDtls.expensesList = getExpenseEvidenceDetailsList;

    contextKey.caseID = key.caseID;

    contextDetails = getContextDescription(contextKey);

    listExpenseEvidenceDtls.expenseCtx.description = contextDetails.description;

    return listExpenseEvidenceDtls;

  }

  // ___________________________________________________________________________
  /**
   * To retrieve all fsHouseholdEvidence records from the database.
   *
   * @param key identifies the case
   *
   * @return the evidence list
   */
  public ListHholdEvidenceDtls listHouseholdEvidence(ReadEvidenceListKey key)
    throws AppException, InformationalException {

    // return struct
    ListHholdEvidenceDtls listHholdEvidenceDtls = new ListHholdEvidenceDtls();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetEvidenceListKey getEvidenceListKey = new GetEvidenceListKey();
    GethouseholdEvidenceListDetailsList gethouseholdEvidenceListDetailsList;

    // Context details
    ContextDetails contextDetails = new ContextDetails();
    ContextKey contextKey = new ContextKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform the readmulti
    getEvidenceListKey.listKeyDtls.caseID = key.caseID;

    gethouseholdEvidenceListDetailsList = incomeScreeningObj.getHouseholdEvidenceList(
      getEvidenceListKey);

    listHholdEvidenceDtls.listHholdDtls = gethouseholdEvidenceListDetailsList;

    contextKey.caseID = key.caseID;

    contextDetails = getContextDescription(contextKey);

    listHholdEvidenceDtls.hholdCtx.description = contextDetails.description;

    return listHholdEvidenceDtls;
  }

  // ___________________________________________________________________________
  /**
   * To retrieve all fsHouseholdIncome records from the database.
   *
   * @param key identifies the case
   *
   * @return the evidence list
   */
  public ListIncomeEvidenceDtls listIncomeEvidence(ReadEvidenceListKey key)
    throws AppException, InformationalException {

    // return struct
    ListIncomeEvidenceDtls listIncomeEvidenceDtls = new ListIncomeEvidenceDtls();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetEvidenceListKey getEvidenceListKey = new GetEvidenceListKey();
    GetIncomeEvidenceListDetailsList getIncomeEvidenceListDetailsList;

    // Context details
    ContextDetails contextDetails = new ContextDetails();
    ContextKey contextKey = new ContextKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform the readmulti
    getEvidenceListKey.listKeyDtls.caseID = key.caseID;

    getIncomeEvidenceListDetailsList = incomeScreeningObj.getIncomeEvidenceList(
      getEvidenceListKey);

    // map details to return struct
    listIncomeEvidenceDtls.listIncomeDtls = getIncomeEvidenceListDetailsList;

    contextKey.caseID = key.caseID;

    contextDetails = getContextDescription(contextKey);

    listIncomeEvidenceDtls.incomeCtx.description = contextDetails.description;

    return listIncomeEvidenceDtls;

  }

  // ___________________________________________________________________________
  /**
   * To retrieve all fsHouseholdResource records from the database
   *
   * @param key identifies the case
   *
   * @return the evidence list
   */
  public ListResourceEvidenceDtls listResourceEvidence(ReadEvidenceListKey key)
    throws AppException, InformationalException {

    // return struct
    ListResourceEvidenceDtls listResourceEvidenceDtls = new ListResourceEvidenceDtls();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetEvidenceListKey getEvidenceListKey = new GetEvidenceListKey();
    GetResourceEvidenceListDetailsList getResourceEvidenceListDetailsList;

    // Context details
    ContextDetails contextDetails = new ContextDetails();
    ContextKey contextKey = new ContextKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform the readmulti
    getEvidenceListKey.listKeyDtls.caseID = key.caseID;

    getResourceEvidenceListDetailsList = incomeScreeningObj.getResourceEvidenceList(
      getEvidenceListKey);

    listResourceEvidenceDtls.listResourceDtls = getResourceEvidenceListDetailsList;

    contextKey.caseID = key.caseID;

    contextDetails = getContextDescription(contextKey);

    listResourceEvidenceDtls.resourceCtx.description = contextDetails.description;

    return listResourceEvidenceDtls;

  }

  // ___________________________________________________________________________
  /**
   * To modify a specified fsBenefitEvidence record.
   *
   * @param dtls details to be modified
   */
  public void modifyBenefitEvidence(ModifyBenefitEvidenceDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    ModifyBenefitEvidenceDetails modifyBenefitEvidenceDetails = new ModifyBenefitEvidenceDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // map the household evidence details to be inserted
    modifyBenefitEvidenceDetails.modifyBfitDtls.assign(dtls);

    incomeScreeningObj.modifyBenefitEvidence(modifyBenefitEvidenceDetails);

  }

  // ___________________________________________________________________________
  /**
   * To modify a specified fsHouseholdExpense record
   *
   * @param dtls details to be modified
   */
  public void modifyShelterExpenseEvidence(
    ModifyShelterExpenseEvidenceDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    ModifyExpenseEvidenceDetails modifyExpenseEvidenceDetails = new ModifyExpenseEvidenceDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // map the expense evidence details to be modified
    modifyExpenseEvidenceDetails.assign(dtls);
    modifyExpenseEvidenceDetails.expenseCategoryCode = curam.codetable.EXPENSECATEGORYCODE.SHELTEREXPENSES;
    modifyExpenseEvidenceDetails.expenseTypeCode = dtls.shelterExpenseTypeCode;

    incomeScreeningObj.modifyExpenseEvidence(modifyExpenseEvidenceDetails);

  }

  // ___________________________________________________________________________
  /**
   * To modify a specified fsHouseholdEvidence record.
   *
   * @param dtls details to be modified
   */
  public void modifyHouseholdEvidence(ModifyHholdEvidenceDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    ModifyHouseholdEvidenceDetails modifyHouseholdEvidenceDetails = new ModifyHouseholdEvidenceDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // map the household evidence details to be inserted
    modifyHouseholdEvidenceDetails.modifyHholdDtls.assign(dtls);

    incomeScreeningObj.modifyHouseholdEvidence(modifyHouseholdEvidenceDetails);

  }

  // ___________________________________________________________________________
  /**
   * To modify a specified fsHouseholdIncome record.
   *
   * @param dtls details to be modified
   */
  public void modifyIncomeEvidence(ModifyIncomeEvidenceDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    ModifyIncomeEvidenceDetails modifyIncomeEvidenceDetails = new ModifyIncomeEvidenceDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // map the expense evidence details to be modified
    modifyIncomeEvidenceDetails.modifyIncDtls.assign(dtls);

    incomeScreeningObj.modifyIncomeEvidence(modifyIncomeEvidenceDetails);

  }

  // ___________________________________________________________________________
  /**
   * To update a specified fsHouseholdResource record.
   *
   * @param dtls details to be modified
   */
  public void modifyResourceEvidence(ModifyResourceEvidenceDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    ModifyResourceEvidenceDetails modifyResourceEvidenceDetails = new ModifyResourceEvidenceDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // map the household evidence details to be modified
    modifyResourceEvidenceDetails.modResourceDtls.assign(dtls);

    incomeScreeningObj.modifyResourceEvidence(modifyResourceEvidenceDetails);

  }

  // ___________________________________________________________________________
  /**
   * To retrieve all details for a specified fsHouseholdBenefit record.
   *
   * @param key identifies the evidence
   *
   * @return the evidence details
   */
  public ReadBenefitEvidenceDtls viewBenefitEvidence(ReadBenefitEvidenceKey key)
    throws AppException, InformationalException {

    // variable to store return values
    ReadBenefitEvidenceDtls readBenefitEvidenceDtls = new ReadBenefitEvidenceDtls();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetBenefitEvidenceKey getBenefitEvidenceKey = new GetBenefitEvidenceKey();
    GetBenefitEvidenceDetails getBenefitEvidenceDetails;

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform benefit evidence read
    getBenefitEvidenceKey.getBfitKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    getBenefitEvidenceKey.getBfitKey.fsHouseholdBenefitsID = key.fsHouseholdBenefitsID;

    getBenefitEvidenceDetails = incomeScreeningObj.getBenefitEvidence(
      getBenefitEvidenceKey);

    // map the details back to the output struct
    readBenefitEvidenceDtls.getBfitDtls = getBenefitEvidenceDetails;

    return readBenefitEvidenceDtls;

  }

  // ___________________________________________________________________________
  /**
   * To retrieve details of a specified fsHouseholdExpense record
   *
   * @param key identifies the evidence
   *
   * @return the evidence details
   */
  public ReadShelterExpenseEvidenceDtls viewShelterExpenseEvidence(
    ReadExpenseEvidenceKey key)
    throws AppException, InformationalException {

    // variable to store return values
    ReadShelterExpenseEvidenceDtls readExpenseEvidenceDtls = new ReadShelterExpenseEvidenceDtls();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetExpenseEvidenceKey getExpenseEvidenceKey = new GetExpenseEvidenceKey();
    GetExpenseEvidenceDetails getExpenseEvidenceDetails;

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform benefit evidence read
    getExpenseEvidenceKey.getExpKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    getExpenseEvidenceKey.getExpKey.fsHouseholdExpensesID = key.fsHouseholdExpensesID;

    getExpenseEvidenceDetails = incomeScreeningObj.getExpenseEvidence(
      getExpenseEvidenceKey);

    // map the details back to the output struct
    readExpenseEvidenceDtls.assign(getExpenseEvidenceDetails);
    readExpenseEvidenceDtls.shelterExpenseTypeCode = getExpenseEvidenceDetails.expenseTypeCode;

    return readExpenseEvidenceDtls;

  }

  // ___________________________________________________________________________
  /**
   * To retrieve details of a specified fsHouseholdEvidence record from the
   * database.
   *
   * @param key identifies the evidence
   *
   * @return the evidence details
   */
  public ReadHholdEvidenceDtls viewHouseholdEvidence(ReadHholdEvidenceKey key)
    throws AppException, InformationalException {

    // variable to store return values
    ReadHholdEvidenceDtls readHholdEvidenceDtls = new ReadHholdEvidenceDtls();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetHouseholdEvidenceKey getHouseholdEvidenceKey = new GetHouseholdEvidenceKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform household evidence read
    getHouseholdEvidenceKey.getHholdKey.fsHouseholdEvidenceID = key.fsHouseholdEvidenceID;

    // map details back to the output struct
    readHholdEvidenceDtls.getHholdDtls = incomeScreeningObj.getHouseholdEvidence(
      getHouseholdEvidenceKey);

    return readHholdEvidenceDtls;

  }

  // ___________________________________________________________________________
  /**
   * To return all details for a specified fsHouseholdIncome record.
   *
   * @param key identifies the evidence
   *
   * @return the evidence details
   */
  public ReadIncomeEvidenceDtls viewIncomeEvidence(ReadIncomeEvidenceKey key)
    throws AppException, InformationalException {

    // variable to store return values
    ReadIncomeEvidenceDtls readIncomeEvidenceDtls = new ReadIncomeEvidenceDtls();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetIncomeEvidenceKey getIncomeEvidenceKey = new GetIncomeEvidenceKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform income evidence read
    getIncomeEvidenceKey.getIncDtls.caseEvidenceTypeID = key.caseEvidenceTypeID;
    getIncomeEvidenceKey.getIncDtls.fsHouseholdIncomeID = key.fsHouseholdIncomeID;

    // map the details back to the output struct
    readIncomeEvidenceDtls.getIncomeDtls = incomeScreeningObj.getIncomeEvidence(
      getIncomeEvidenceKey);

    return readIncomeEvidenceDtls;

  }

  // ___________________________________________________________________________
  /**
   * To read details of a specified fsHouseholdResource record from the database
   *
   * @param key identifies the evidence
   *
   * @return the evidence details
   */
  public ReadResourceEvidenceDtls viewResourceEvidence(
    ReadResourceEvidenceKey key)
    throws AppException, InformationalException {

    // variable to store return values
    ReadResourceEvidenceDtls readResourceEvidenceDtls = new ReadResourceEvidenceDtls();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetResourceEvidenceKey getResourceEvidenceKey = new GetResourceEvidenceKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform resource evidence read
    getResourceEvidenceKey.getResourceKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    getResourceEvidenceKey.getResourceKey.fsHouseholdResourcesID = key.fsHouseholdResourcesID;

    // map the details back to the output struct
    readResourceEvidenceDtls.getResourceDtls = incomeScreeningObj.getResourceEvidence(
      getResourceEvidenceKey);

    return readResourceEvidenceDtls;

  }

  // ___________________________________________________________________________
  /**
   * To run a screening assessment
   *
   * @param key key to check eligibility
   *
   * @return the assessment result
   */
  public IncomeScreeningAssessmentResult checkEligibility(
    CheckEligibilityKey key)
    throws AppException, InformationalException {

    IncomeScreeningAssessmentResult incomeScreeningAssessmentResult = new IncomeScreeningAssessmentResult();

    // Determine Assessment Info variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    AssessmentInfoKey assessmentInfoKey = new AssessmentInfoKey();
    AssessmentInfoDtls assessmentInfoDtls = new AssessmentInfoDtls();

    // Run Assessment Variables
    curam.core.sl.intf.Screening screening_soObj = curam.core.sl.fact.ScreeningFactory.newInstance();
    RunAssessmentDtls_so runAssessmentDtls_so = new RunAssessmentDtls_so();
    ScreeningAssessmentResult screeningAssessmentResult = new ScreeningAssessmentResult();

    // manipulation variables
    AssessmentResultText assessmentResultText = new AssessmentResultText();

    // register the security implementation
    SecurityImplementationFactory.register();

    assessmentInfoKey.assessKey.caseID = key.caseID;
    assessmentInfoDtls = incomeScreeningObj.determineAssessmentInfo(
      assessmentInfoKey);

    runAssessmentDtls_so.runAssDtls.assessmentConfigurationID = assessmentInfoDtls.assessmentConfigurationID;
    runAssessmentDtls_so.runAssDtls.assessmentID = assessmentInfoDtls.assessmentID;
    runAssessmentDtls_so.runAssDtls.caseID = key.caseID;
    runAssessmentDtls_so.runAssDtls.assessmentModePromptAsRequired = true;
    runAssessmentDtls_so.runAssDtls.assessmentModePromptNoValues = false;
    runAssessmentDtls_so.runAssDtls.assessmentModePromptWithDefaults = false;

    screeningAssessmentResult = screening_soObj.runAssessment(
      runAssessmentDtls_so);

    assessmentResultText.assessmentID = assessmentInfoDtls.assessmentID;

    incomeScreeningObj.manipulateAssessmentResult(assessmentResultText);

    incomeScreeningAssessmentResult.assResultDtls = assessmentResultText;
    incomeScreeningAssessmentResult.incScreenRslt = screeningAssessmentResult;

    return incomeScreeningAssessmentResult;

  }

  // ___________________________________________________________________________
  /**
   * To get details of all household members
   *
   * @param key key to retrieve member details
   *
   * @return details of the case members
   */
  public GetMemberDetailsList readMemberDetails(ReadMembersListKey key)
    throws AppException, InformationalException {

    // return struct
    GetMemberDetailsList getMemberDetailsList = new GetMemberDetailsList();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetMembersListKey getMembersListKey = new GetMembersListKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform the readmulti
    getMembersListKey.mbrDtlsList.caseEvidenceTypeID = key.caseEvidenceTypeID;

    getMemberDetailsList.memberList = incomeScreeningObj.getMemberDetails(
      getMembersListKey);

    return getMemberDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * To add a new home phone number for the head of household
   *
   * @param dtls Home phone number details
   */
  public void insertHomePhoneNumber(InsertHomePhoneNo dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    InsertHomePhoneDtls insertHomePhoneDtls = new InsertHomePhoneDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set details to perform the home phone number insert
    insertHomePhoneDtls.assign(dtls);

    incomeScreeningObj.insertHomePhoneNumber(insertHomePhoneDtls);

  }

  // ___________________________________________________________________________
  /**
   * To add a new mailing address for the head of household
   *
   * @param dtls mailing address details
   */
  public void insertMailingAddress(InsertMailingAddress dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    InsertMailingAddressDtls insertMailingAddressDtls = new InsertMailingAddressDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set details to perform the mailing address insert
    insertMailingAddressDtls.assign(dtls);

    incomeScreeningObj.insertMailingAddress(insertMailingAddressDtls);

  }

  // ___________________________________________________________________________
  /**
   * To add a new primary residence address for the head of household.
   *
   * @param dtls primary address details
   */
  public void insertPrimaryResidenceAddress(InsertPrimaryResAddress dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    InsertAddressDtls insertAddressDtls = new InsertAddressDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set details to perform the primary residence address insert
    insertAddressDtls.assign(dtls);

    incomeScreeningObj.insertResidenceAddress(insertAddressDtls);

  }

  // ___________________________________________________________________________
  /**
   * To add a new work phone number for the head of household
   *
   * @param dtls Work phone number details
   */
  public void insertWorkPhoneNumber(InsertWorkPhoneNo dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    InsertWorkPhoneDtls insertWorkPhoneDtls = new InsertWorkPhoneDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // set details to perform the home phone number insert
    insertWorkPhoneDtls.assign(dtls);

    incomeScreeningObj.insertWorkPhoneNumber(insertWorkPhoneDtls);

  }

  // ___________________________________________________________________________
  /**
   * To retrieve the context details.
   *
   * @param key Identifies a case
   *
   * @return context description
   */
  protected ContextDetails getContextDescription(ContextKey key)
    throws AppException, InformationalException {

    ContextDetails contextDetails = new ContextDetails();

    // Concern Role Manipulation Variables
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Case Header Manipulation Variables
    curam.core.intf.CaseHeader caseObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    caseHeaderKey.caseID = key.caseID;

    // BEGIN, CR00279909, SG
    CaseHeaderDtls caseHeaderDtls = caseObj.read(caseHeaderKey);

    // END, CR00279909
    
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Set the context description.
    contextDetails.description = concernRoleDtls.concernRoleName
      + CuramConst.gkDashChar + key.caseID;

    return contextDetails;
  }

  // ___________________________________________________________________________
  /**
   * To schedule an appointment with a caseworker.
   *
   * @param dtls details to schedule an appointment
   */
  @SuppressWarnings("deprecation")   
  public void scheduleAppointment(ScheduleAppointmentDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    CreateAppointmentDetails createAppointmentDetails = new CreateAppointmentDetails();

    // CaseHeader variables
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    caseHeaderKey.caseID = dtls.caseID;
    
    // BEGIN, CR00279909, SG
    CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // END, CR00279909

    // set details to create an appointment
    createAppointmentDetails.activityTypeCode = curam.codetable.ACTIVITYTYPE.APPOINTMENT;
    createAppointmentDetails.appointmentDateTime = dtls.appointmentDate;
    createAppointmentDetails.assignToType = curam.codetable.ASSIGNEETYPE.USER;
    createAppointmentDetails.caseID = dtls.caseID;

    createAppointmentDetails.concernRoleID = caseHeaderDtls.concernRoleID;
    createAppointmentDetails.recordStatusCode = curam.codetable.RECORDSTATUS.NORMAL;
    createAppointmentDetails.userName = dtls.userName;

    incomeScreeningObj.createAppointment(createAppointmentDetails);

  }

  // ___________________________________________________________________________
  /**
   * To create fsHouseholdExpense record(s) on the database.
   *
   * @param dtls Medical expense evidence details
   */
  public void insertMedicalExpenseEvidence(
    CreateMedicalExpenseEvidenceDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    CreateExpEvidenceDtls createExpEvidenceDtls = new CreateExpEvidenceDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // map the household expense details to be inserted
    createExpEvidenceDtls.assign(dtls);
    createExpEvidenceDtls.expenseCategoryCode = curam.codetable.EXPENSECATEGORYCODE.MEDICALEXPENSES;
    createExpEvidenceDtls.expenseTypeCode = dtls.medicalExpenseTypeCode;

    incomeScreeningObj.createExpenseEvidence(createExpEvidenceDtls);

  }

  // ___________________________________________________________________________
  /**
   * To modify a specified fsHouseholdExpense record
   *
   * @param dtls details to be modified
   */
  public void modifyMedicalExpenseEvidence(
    ModifyMedicalExpenseEvidenceDtls dtls)
    throws AppException, InformationalException {

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    ModifyExpenseEvidenceDetails modifyExpenseEvidenceDetails = new ModifyExpenseEvidenceDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // map the expense evidence details to be modified
    modifyExpenseEvidenceDetails.assign(dtls);
    modifyExpenseEvidenceDetails.expenseCategoryCode = curam.codetable.EXPENSECATEGORYCODE.MEDICALEXPENSES;
    modifyExpenseEvidenceDetails.expenseTypeCode = dtls.medicalExpenseTypeCode;

    incomeScreeningObj.modifyExpenseEvidence(modifyExpenseEvidenceDetails);

  }

  // ___________________________________________________________________________
  /**
   * To retrieve details of a specified fsHouseholdExpense medical expense
   * record
   *
   * @param key identifies the evidence
   *
   * @return the evidence details
   */
  public ReadMedicalExpenseEvidenceDtls viewMedicalExpenseEvidence(
    ReadExpenseEvidenceKey key)
    throws AppException, InformationalException {

    // variable to store return values
    ReadMedicalExpenseEvidenceDtls readMedicalExpenseDtls = new ReadMedicalExpenseEvidenceDtls();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetExpenseEvidenceKey getExpenseEvidenceKey = new GetExpenseEvidenceKey();
    GetExpenseEvidenceDetails getExpenseEvidenceDetails;

    // register the security implementation
    SecurityImplementationFactory.register();

    // set key to perform benefit evidence read
    getExpenseEvidenceKey.getExpKey.caseEvidenceTypeID = key.caseEvidenceTypeID;
    getExpenseEvidenceKey.getExpKey.fsHouseholdExpensesID = key.fsHouseholdExpensesID;

    getExpenseEvidenceDetails = incomeScreeningObj.getExpenseEvidence(
      getExpenseEvidenceKey);

    // map the details back to the output struct
    readMedicalExpenseDtls.assign(getExpenseEvidenceDetails);
    readMedicalExpenseDtls.medicalExpenseTypeCode = getExpenseEvidenceDetails.expenseTypeCode;

    return readMedicalExpenseDtls;
  }

  // ___________________________________________________________________________
  /**
   * To view the case home page of an income screening case
   *
   * @param key Identifies the case
   *
   * @return screening case home details
   */
  public ScreeningCaseHomeDetails viewCaseHome(CaseHomeKey key)
    throws AppException, InformationalException {

    // variable to store return values
    ScreeningCaseHomeDetails screeningCaseHomeDetailsRet = new ScreeningCaseHomeDetails();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    curam.sample.sl.struct.CaseHomeKey caseHomeKey = new curam.sample.sl.struct.CaseHomeKey();
    curam.sample.sl.struct.ScreeningCaseHomeDetails screeningCaseHomeDetails;

    // register the security implementation
    SecurityImplementationFactory.register();

    // Context details
    ContextDetails contextDetails = new ContextDetails();
    ContextKey contextKey = new ContextKey();

    // set key to get the screening case home details
    caseHomeKey.caseKey.caseID = key.caseID;

    screeningCaseHomeDetails = incomeScreeningObj.viewScreeningCaseHome(
      caseHomeKey);

    contextKey.caseID = key.caseID;

    contextDetails = getContextDescription(contextKey);

    screeningCaseHomeDetails.contxtDtls.description = contextDetails.description;

    // map the details to the return struct
    screeningCaseHomeDetailsRet.screenDtls.assign(screeningCaseHomeDetails);

    return screeningCaseHomeDetailsRet;

  }

  // ___________________________________________________________________________
  /**
   * To get the name of a household member
   *
   * @param key Key to retrieve a registered members details
   *
   * @return registered member details
   */
  public GetRegisteredMemberDtls getRegisteredMemberDetails(
    GetRegisteredMemberKey key)
    throws AppException, InformationalException {

    GetRegisteredMemberDtls getRegisteredMemberDtls = new GetRegisteredMemberDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetMemberNameKey getMemberNameKey = new GetMemberNameKey();

    getMemberNameKey.memberKey.concernRoleID = key.concernRoleID;

    getRegisteredMemberDtls.memberDtls = incomeScreeningObj.getMemberName(
      getMemberNameKey);

    return getRegisteredMemberDtls;
  }

  // ___________________________________________________________________________
  /**
   * To check appointment availability
   *
   * @param key Key to check user availability
   *
   * @return details of the users availability
   */
  public CheckUserAvailabilityDtls checkUserAvailability(
    CheckUserAvailabilityKey key)
    throws AppException, InformationalException {

    CheckUserAvailabilityDtls checkUserAvailabilityDtls = new CheckUserAvailabilityDtls();

    // IncomeScreening manipulation variables
    curam.sample.sl.intf.IncomeScreening incomeScreeningObj = curam.sample.sl.fact.IncomeScreeningFactory.newInstance();
    GetUserAvailabilityKey getUserAvailabilityKey = new GetUserAvailabilityKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    getUserAvailabilityKey.userAvailKey.appointmentDate = key.appointmentDate;
    getUserAvailabilityKey.userAvailKey.organisationUnitID = key.organisationUnitID;

    checkUserAvailabilityDtls.checkAvailbility = incomeScreeningObj.getUserAvailability(
      getUserAvailabilityKey);

    return checkUserAvailabilityDtls;
  }

}
