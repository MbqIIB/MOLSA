/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;


/**
 * This class assigns values to the Curam constants
 */

public abstract class SampleSportingGrantConst {

  public static final String kSampleSportingActivityDomainsFile = "curam.sample.facade.impl.SampleSportingActivityDomains";
  public static final String kSampleSportingActivityLabelsFile = "curam.sample.facade.impl.SampleSportingActivityLabels";
  public static final String[] kSampleSportingActivityNames = {
    "readDtls.clientDtls.name", 
    "readDtls.sportingActivityType",
    "readDtls.sportingAwardType", 
    "readDtls.paymentAmount",
    "readDtls.startDate",
    "readDtls.endDate",
    "readDtls.comments"};
  
  public static final String kSampleSportingActivityExpenseDomainsFile = "curam.sample.facade.impl.SampleSportingActivityExpenseDomains";
  public static final String kSampleSportingActivityExpenseLabelsFile = "curam.sample.facade.impl.SampleSportingActivityExpenseLabels";
  public static final String[] kSampleSportingActivityExpenseNames = {
    "readDtls.sportingExpenseType"
    , "readDtls.amount"
    , "readDtls.startDate"
    , "readDtls.endDate"
    , "readDtls.comments"
      };
  
  public static final String kSportingSponsershipDomainsFile = "curam.sample.facade.impl.SportingSponsershipDomains";
  public static final String kSportingSponsershipLabelsFile = "curam.sample.facade.impl.SportingSponsershipLabels";
  public static final String[] kSportingSponsershipNames = {
    "readDtls.clientDtls.name"
    , "readDtls.sponsorshipAmount"
    , "readDtls.sponsorshipType"
    , "readDtls.comments"
      };
  
}
