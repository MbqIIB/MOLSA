/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.facade.infrastructure.fact.EvidenceFactory;
import curam.core.facade.infrastructure.intf.Evidence;
import curam.core.facade.struct.CaseParticipantRoleIDKey;
import curam.core.facade.struct.ICProductDeliveryContextDescription;
import curam.core.facade.struct.ICProductDeliveryContextDescriptionKey;
import curam.core.facade.struct.ICProductDeliveryMenuDataDetails;
import curam.core.facade.struct.ICProductDeliveryMenuDataKey;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.MaintainAdminIntegratedCaseFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.MaintainAdminIntegratedCase;
import curam.core.intf.ProductDelivery;
import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseIDAndStatusKey;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseDetails;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseKey;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorInsertDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.SuccessionID;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EIEvidenceInsertDtls;
import curam.core.sl.infrastructure.impl.EIEvidenceModifyDtls;
import curam.core.sl.infrastructure.impl.EIEvidenceReadDtls;
import curam.core.sl.infrastructure.impl.Evidence2Compare;
import curam.core.sl.infrastructure.impl.EvidenceComparisonHelper;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.infrastructure.struct.ECEvidenceForListPageDtls;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIListCaseEvidenceKey;
import curam.core.sl.infrastructure.struct.EvidenceAttributeDtls;
import curam.core.sl.infrastructure.struct.EvidenceComparisonDtls;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.sl.struct.EvidenceCaseKey;
import curam.core.struct.CaseConcernRoleName;
import curam.core.struct.CaseHomePageNameAndType;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.ICPageNamesICTypeAndConcernDetails;
import curam.core.struct.ICParticipantHomePageKey;
import curam.core.struct.ICParticipantHomePageName;
import curam.core.struct.IntegratedCaseReferenceKey;
import curam.core.struct.ParticipantCaseAndUserDetails;
import curam.core.struct.ParticipantCaseAndUserKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.message.BPOREFLECTION;
import curam.message.FACADEEVIDENCE;
import curam.sample.facade.struct.CreateSportingSponsorshipDtls;
import curam.sample.facade.struct.ListSportingSponsershipEvidenceDtls;
import curam.sample.facade.struct.ListSportingSponsershipEvidenceKey;
import curam.sample.facade.struct.ModifySportingSponsorshipDtls;
import curam.sample.facade.struct.ModifySportingSponsorshipReturnDtls;
import curam.sample.facade.struct.ReadSportingSponsorshipSiteMapDetails;
import curam.sample.facade.struct.SportingSponsershipKey;
import curam.sample.facade.struct.SportingSponsorshipActivityReturnDtls;
import curam.sample.facade.struct.ViewSportingSponsorshipDtls;
import curam.sample.sl.entity.struct.SportingSponsorshipDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.resources.Configuration;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;


/**
 * Facade methods for the Sporting Sponsorship product.
 */
public class SportingSponsership extends curam.sample.facade.base.SportingSponsership
  // BEGIN, CR00120297, CD
  implements Evidence2Compare {
  // END, CR00120297

  // BEGIN, CR00122003, KH
  /**
   * Initial size of string buffer 
   */
  protected static final int kBufSize = 256;

  // ___________________________________________________________________________
  /**
   * Method to create Sporting Sponsorship Evidence
   *
   * @param dtls Sporting Sponsorship Evidence details
   *
   * @return Unique identifier of the Sporting Sponsorship Evidence record
   * created as well as a list of informational messages
   */
  public SportingSponsorshipActivityReturnDtls createSportingSponsershipEvidence(
    CreateSportingSponsorshipDtls dtls)
    throws AppException, InformationalException {

    // Return Struct
    SportingSponsorshipActivityReturnDtls sportingSponsorshipActivityReturnDtls = new SportingSponsorshipActivityReturnDtls();
    
    // Set up the required structures.
    SportingSponsorshipDtls sampleSportingSponsorshipDtls = new SportingSponsorshipDtls();
    EIEvidenceInsertDtls eiEvidenceInsertDtls = new EIEvidenceInsertDtls();
    EvidenceDescriptorInsertDtls evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();

    evidenceDescriptorInsertDtls.assign(dtls);
    sampleSportingSponsorshipDtls.assign(dtls);

    evidenceDescriptorInsertDtls.evidenceType = CASEEVIDENCE.SPORTINGSPONSORSHIP;

    // Get CaseParticipant Name
    CaseHeader caseheaderObj = CaseHeaderFactory.newInstance();
    ParticipantCaseAndUserKey participantCaseAndUserKey = new ParticipantCaseAndUserKey();

    participantCaseAndUserKey.caseID = dtls.caseID;
    participantCaseAndUserKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;

    ParticipantCaseAndUserDetails participantCaseAndUserDetails = caseheaderObj.readParticipanCaseAndUserDetails(
      participantCaseAndUserKey);

    CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();

    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = participantCaseAndUserDetails.caseParticipantRoleID;

    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails = caseParticipantRoleObj.readCaseIDandParticipantID(
      caseParticipantRoleKey);

    evidenceDescriptorInsertDtls.participantID = caseIDAndParticipantRoleIDDetails.participantRoleID;

    // EvidenceController business object
    EvidenceControllerInterface evidenceControllerObj = (curam.core.sl.infrastructure.impl.EvidenceControllerInterface)
      EvidenceControllerFactory.newInstance();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.descriptor.receivedDate = Date.getCurrentDate();
    eiEvidenceInsertDtls.parentKey.evidenceID = 0;
    eiEvidenceInsertDtls.evidenceObject = sampleSportingSponsorshipDtls;

    EIEvidenceKey eiEvidenceKey = evidenceControllerObj.insertEvidence(
      eiEvidenceInsertDtls);

    sportingSponsorshipActivityReturnDtls.key.sportingSponsorshipID = eiEvidenceKey.evidenceID;

    return sportingSponsorshipActivityReturnDtls;
  }

  // ___________________________________________________________________________
  /**
   * Method to read the Sporting Sponsorship Object.
   *
   * @param key Identifies the evidence business object to read.
   *
   * @return Sponsorship Object.
   */
  public ViewSportingSponsorshipDtls readSportingSponsershipObject(SuccessionID key)
    throws AppException, InformationalException {     

    Evidence evidenceObj = EvidenceFactory.newInstance();
    EvidenceCaseKey evidenceCaseKey = evidenceObj.getEvidenceAndCaseFromSuccession(
      key);
    SportingSponsershipKey sportingSponsershipKey = new SportingSponsershipKey();

    sportingSponsershipKey.sportingSponsorshipID = evidenceCaseKey.evidenceKey.evidenceID;
    return readSportingSponsershipEvidence(sportingSponsershipKey);    
  }    
  
  // ___________________________________________________________________________
  /**
   * Method to read the Sporting Sponsorship Evidence
   *
   * @param key Key to read the Sporting Sponsorship Evidence
   *
   * @return Sponsorship Evidence Details
   */
  public ViewSportingSponsorshipDtls readSportingSponsershipEvidence(
    SportingSponsershipKey key)
    throws AppException, InformationalException {

    // Set up the required structures
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceID = key.sportingSponsorshipID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SPORTINGSPONSORSHIP;

    // EvidenceController business object
    EvidenceControllerInterface evidenceControllerObj = (curam.core.sl.infrastructure.impl.EvidenceControllerInterface)
      EvidenceControllerFactory.newInstance();

    // Read evidence
    EIEvidenceReadDtls eiEvidenceReadDtls = evidenceControllerObj.readEvidence(
      eiEvidenceKey);

    ViewSportingSponsorshipDtls viewSportingSponsorshipDtls = new ViewSportingSponsorshipDtls();

    viewSportingSponsorshipDtls.assign(eiEvidenceReadDtls.descriptor);
    viewSportingSponsorshipDtls.evidenceType = eiEvidenceReadDtls.descriptor.evidenceType;
    viewSportingSponsorshipDtls.assign((SportingSponsorshipDtls)
      (eiEvidenceReadDtls.evidenceObject));

    // Get CaseParticipant Name
    CaseHeader caseheaderObj = CaseHeaderFactory.newInstance();
    ParticipantCaseAndUserKey participantCaseAndUserKey = new ParticipantCaseAndUserKey();

    participantCaseAndUserKey.caseID = eiEvidenceReadDtls.descriptor.caseID;
    participantCaseAndUserKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;

    ParticipantCaseAndUserDetails participantCaseAndUserDetails = caseheaderObj.readParticipanCaseAndUserDetails(
      participantCaseAndUserKey);

    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = participantCaseAndUserDetails.caseParticipantRoleID;

    viewSportingSponsorshipDtls.clientDtls.name = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance().readNameAndParticipantRoleID(caseParticipantRoleKey).name;
    
    // BEGIN, CR00100029, NP
    // Set the caseParticipantRoleID
    viewSportingSponsorshipDtls.clientDtls.caseParticipantRoleID = caseParticipantRoleKey.caseParticipantRoleID;
    viewSportingSponsorshipDtls.caseParticipantRoleID = caseParticipantRoleKey.caseParticipantRoleID;
    // END, CR00100029

    return viewSportingSponsorshipDtls;

  }

  // ___________________________________________________________________________
  /**
   * Method to list Sporting Sponsorship Evidence
   *
   * @param key Key to retrieve list of Sporting Sponsorship Evidence
   *
   * @return List of Sporting Sponsorship Evidence
   */
  public ListSportingSponsershipEvidenceDtls listSportingSponsorshipEvidence(
    ListSportingSponsershipEvidenceKey key)
    throws AppException, InformationalException {

    // Instantiate the return struct
    ListSportingSponsershipEvidenceDtls listSportingSponsershipEvidenceDtls = new ListSportingSponsershipEvidenceDtls();

    // EvidenceInterface variable
    EIListCaseEvidenceKey eiListCaseEvidenceKey = new EIListCaseEvidenceKey();

    eiListCaseEvidenceKey.caseID = key.caseID;
    eiListCaseEvidenceKey.evidenceType = CASEEVIDENCE.SPORTINGSPONSORSHIP;

    // EvidenceController business object
    EvidenceControllerInterface evidenceControllerObj = (curam.core.sl.infrastructure.impl.EvidenceControllerInterface)
      EvidenceControllerFactory.newInstance();

    ECEvidenceForListPageDtls ecEvidenceForListPageDtls = evidenceControllerObj.listAllForEvidenceListPage(
      eiListCaseEvidenceKey);

    listSportingSponsershipEvidenceDtls.listDtls.assign(
      ecEvidenceForListPageDtls);

    // Retrieve context description
    // Read context description
    ICProductDeliveryContextDescriptionKey iCProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    iCProductDeliveryContextDescriptionKey.caseID = key.caseID;

    listSportingSponsershipEvidenceDtls.contextDescription = getSportingSponsershipContextDescription(iCProductDeliveryContextDescriptionKey).description;

    return listSportingSponsershipEvidenceDtls;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify the Sporting Sponsorship Evidence
   *
   * @param key Key to modify Sporting Sponsorship Evidence
   *
   * @param dtls Modified Sporting Sponsorship Evidence
   */
  public ModifySportingSponsorshipReturnDtls modifySportingActivityEvidence(
    SportingSponsershipKey key, ModifySportingSponsorshipDtls dtls)
    throws AppException, InformationalException {

    // Return Struct
    ModifySportingSponsorshipReturnDtls modifySportingSponsorshipReturnDtls = new ModifySportingSponsorshipReturnDtls();
    
    // Set up the required structures.
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();
    EIEvidenceModifyDtls eiEvidenceModifyDtls = new EIEvidenceModifyDtls();

    eiEvidenceKey.evidenceID = key.sportingSponsorshipID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.SPORTINGSPONSORSHIP;

    SportingSponsorshipDtls sampleSportingSponsorshipDtls = new SportingSponsorshipDtls();

    sampleSportingSponsorshipDtls.assign(dtls);

    eiEvidenceModifyDtls.descriptor.assign(dtls);
    eiEvidenceModifyDtls.parentKey.evidenceID = 0;
    eiEvidenceModifyDtls.descriptor.receivedDate = Date.getCurrentDate();
    eiEvidenceModifyDtls.evidenceObject = sampleSportingSponsorshipDtls;

    // EvidenceController business object
    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    evidenceControllerObj.modifyEvidence(eiEvidenceKey, eiEvidenceModifyDtls);

    modifySportingSponsorshipReturnDtls.warning = evidenceControllerObj.getWarnings();

    return modifySportingSponsorshipReturnDtls;
  }

  // ___________________________________________________________________________
  /**
   * Method to read the SiteMapDetails
   *
   * @param key Key to modify Sporting Sponsorship Evidence
   */
  public ReadSportingSponsorshipSiteMapDetails readSiteMapDetails(CaseKey key)
    throws AppException, InformationalException {

    // register the security implementation
    SecurityImplementationFactory.register();

    // Return object
    ReadSportingSponsorshipSiteMapDetails readSportingSponsorshipSiteMapDetails = new ReadSportingSponsorshipSiteMapDetails();

    // EvidenceDescriptor manipulation objects
    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    CaseIDAndStatusKey caseIDAndStatusKey = new CaseIDAndStatusKey();

    // Set key retrieve list of EvidenceDescriptors
    caseIDAndStatusKey.caseID = key.caseID;
    caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.ACTIVE;

    EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = evidenceDescriptorObj.searchByCaseIDAndStatus(
      caseIDAndStatusKey);

    for (int i = 0; i < evidenceDescriptorDtlsList.dtls.size(); i++) {

      if (evidenceDescriptorDtlsList.dtls.item(i).evidenceType.equals(
        CASEEVIDENCE.SPORTINGSPONSORSHIP)) {
        readSportingSponsorshipSiteMapDetails.active = true;
      }
    }

    // Check for in edit evidence
    caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.INEDIT;

    evidenceDescriptorDtlsList = evidenceDescriptorObj.searchByCaseIDAndStatus(
      caseIDAndStatusKey);

    for (int i = 0; i < evidenceDescriptorDtlsList.dtls.size(); i++) {

      if (evidenceDescriptorDtlsList.dtls.item(i).evidenceType.equals(
        CASEEVIDENCE.SPORTINGSPONSORSHIP)) {

        readSportingSponsorshipSiteMapDetails.inEdit = true;
      }
    }

    // Read context description
    ICProductDeliveryContextDescriptionKey iCProductDeliveryContextDescriptionKey = new ICProductDeliveryContextDescriptionKey();

    iCProductDeliveryContextDescriptionKey.caseID = key.caseID;

    readSportingSponsorshipSiteMapDetails.contextDescription = getICProductDeliveryContextDescription(iCProductDeliveryContextDescriptionKey).description;

    // Read menu data
    ICProductDeliveryMenuDataKey iCProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    iCProductDeliveryMenuDataKey.caseID = key.caseID;
    readSportingSponsorshipSiteMapDetails.menuData = getICProductDeliveryMenuData(iCProductDeliveryMenuDataKey).menuData;

    return readSportingSponsorshipSiteMapDetails;
  }

  // ___________________________________________________________________________
  /**
   * Generates the context description for a product delivery on an Integrated
   * Case
   *
   * @param key Contains the case identifier.
   *
   * @return A context description for a product delivery.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected ICProductDeliveryContextDescription getICProductDeliveryContextDescription(
    ICProductDeliveryContextDescriptionKey key)
    throws AppException, InformationalException {

    // Create the return object
    ICProductDeliveryContextDescription icProductDeliveryContextDescription = new ICProductDeliveryContextDescription();

    // CaseHeader manipulation variables
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseConcernRoleName caseConcernRoleName;
    CaseKey caseKey = new CaseKey();

    // ProductDelivery manipulation variables
    ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set key to read ProductDelivery
    productDeliveryKey.caseID = key.caseID;

    // Read ProductDelivery
    productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = productDeliveryDtls.recipConcernRoleID;

    CaseHomePageNameAndType caseHomePageNameAndType;

    // Set key to read caseHeader
    caseKey.caseID = key.caseID;

    // Read caseHeader
    caseConcernRoleName = caseHeaderObj.readCaseConcernRoleName(caseKey);

    // Read productDelivery
    caseHomePageNameAndType = productDeliveryObj.readCaseHomePageNameAndType(
      caseKey);

    // Create the context description
    StringBuffer buffer = new StringBuffer(kBufSize);

    buffer.append(
      // BEGIN, CR00163098, JC
      CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
      caseHomePageNameAndType.typeCode, TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC
    // BEGIN, CR00098942, SAI
    buffer.append(CuramConst.gkSpace);
    // END, CR00098942
    buffer.append(CuramConst.kSeparator);
    buffer.append(caseConcernRoleName.caseReference);

    // Assign it to the return object
    icProductDeliveryContextDescription.description = buffer.toString();

    return icProductDeliveryContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Generates the context description for a Sporting Sponsorship Evidence
   * Case
   *
   * @param key Contains the case identifier.
   *
   * @return A context description for a Sporting Sponsorship.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected ICProductDeliveryContextDescription getSportingSponsershipContextDescription(
    ICProductDeliveryContextDescriptionKey key)
    throws AppException, InformationalException {

    // Create the return object
    ICProductDeliveryContextDescription icProductDeliveryContextDescription = new ICProductDeliveryContextDescription();

    // CaseHeader manipulation variables
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseConcernRoleName caseConcernRoleName;
    CaseKey caseKey = new CaseKey();

    // ProductDelivery manipulation variables
    ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;

    // ConcernRole manipulation variables
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Set key to read ProductDelivery
    productDeliveryKey.caseID = key.caseID;

    // Read ProductDelivery
    productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = productDeliveryDtls.recipConcernRoleID;

    // Read concernRoleName
    concernRoleNameDetails = concernRoleObj.readConcernRoleName(concernRoleKey);

    CaseHomePageNameAndType caseHomePageNameAndType;

    // Set key to read caseHeader
    caseKey.caseID = key.caseID;

    // Read caseHeader
    caseConcernRoleName = caseHeaderObj.readCaseConcernRoleName(caseKey);

    // Read productDelivery
    caseHomePageNameAndType = productDeliveryObj.readCaseHomePageNameAndType(
      caseKey);

    LocalisableString description = new LocalisableString(
      FACADEEVIDENCE.EVIDENCECONTEXTDESCRIPTION);

    caseKey.caseID = key.caseID;

    description.arg(
      // BEGIN, CR00163098, JC
      CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
      caseHomePageNameAndType.typeCode, TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC

    description.arg(caseConcernRoleName.caseReference);
    // BEGIN, CR00098942, SAI
    description.arg(CuramConst.gkSpace);
    // END, CR00098942
    // BEGIN, CR00071077, GM
    description.arg(CuramConst.kSeparator);
    description.arg(concernRoleNameDetails.concernRoleName);
    // BEGIN, CR00098942, SAI
    description.arg(CuramConst.gkSpace);
    // END, CR00098942
    description.arg(CuramConst.kSeparator);
    // END, CR00071077
    description.arg(
      new CodeTableItemIdentifier(CASEEVIDENCE.TABLENAME,
      CASEEVIDENCE.SPORTINGSPONSORSHIP));
    icProductDeliveryContextDescription.description = description.toClientFormattedText();

    return icProductDeliveryContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Generates the menu data for a product delivery on an Product Delivery of
   * Sponsorship Evidence.
   *
   * @param key Contains the case identifier.
   *
   * @return Menu data for a product delivery.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected ICProductDeliveryMenuDataDetails getICProductDeliveryMenuData(
    ICProductDeliveryMenuDataKey key)
    throws AppException, InformationalException {

    // Create return object
    ICProductDeliveryMenuDataDetails icProductDeliveryMenuDataDetails = new ICProductDeliveryMenuDataDetails();

    // Check the Environmental variable
    // Retrieve the Environment variable for the Appeals component installation
    // setting. If the environment variable is present and set to 'true', run
    // the Reflection code.
    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {
      // BEGIN, CR00069996, SK
      String className = ReflectionConst.appealIntegratedClassName;
      String methodName = ReflectionConst.icProductDeliveryMenuMethodName;
      // END, CR00069996
      // Set the arguments to pass through
      Object[] arguments = new Object[] { key};

      // Set the passed class types to the method
      Class[] parameterTypes = new Class[] {
        ICProductDeliveryMenuDataKey.class};

      return (ICProductDeliveryMenuDataDetails) performReflection(className,
        methodName, arguments, parameterTypes);
    }

    curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    CaseParticipantRoleIDKey caseParticipantRoleIDKey = new CaseParticipantRoleIDKey();

    ParticipantHomePageName participantHomePageName;

    // CaseHeader manipulation variables
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails;
    IntegratedCaseReferenceKey integratedCaseReferenceKey;
    CaseKey caseKey = new CaseKey();

    // ProductDelivery manipulation variables
    ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;

    // ConcernRole manipulation variables
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // Set key to read ProductDelivery
    productDeliveryKey.caseID = key.caseID;

    // Read ProductDelivery
    productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = productDeliveryDtls.recipConcernRoleID;

    // Read concernRoleName
    concernRoleNameDetails = concernRoleObj.readConcernRoleName(concernRoleKey);

    CaseHomePageNameAndType caseHomePageNameAndType;

    // Set key to read productDelivery
    caseKey.caseID = key.caseID;

    // Read productDelivery to retrieve the case home page name and
    // product type
    caseHomePageNameAndType = productDeliveryObj.readCaseHomePageNameAndType(
      caseKey);

    // Read integratedCaseID from caseHeader
    integratedCaseReferenceKey = caseHeaderObj.readIntegratedCaseReferenceByCaseID(
      caseKey);

    // Re-set key with integratedCaseID to read caseHeader
    caseKey.caseID = integratedCaseReferenceKey.integratedCaseID;

    // Read caseHeader
    icPageNamesICTypeAndConcernDetails = caseHeaderObj.readICPageNamesICTypeAndConcernDetails(
      caseKey);

    LocalisableString description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icPageNamesICTypeAndConcernDetails.integratedCaseType));

    description.arg(integratedCaseReferenceKey.caseReference);

    // Create Root Node
    Element navigationMenuElement = new Element(
      XmlMetaDataConst.kNavigationMenu);

    // Create Child Node
    Element linkElement = new Element(XmlMetaDataConst.kItem);

    linkElement.setAttribute(XmlMetaDataConst.kPageID,
      icPageNamesICTypeAndConcernDetails.homePageName);
    linkElement.setAttribute(XmlMetaDataConst.kDesc,
      description.toClientFormattedText());

    linkElement.setAttribute(XmlMetaDataConst.kType, XmlMetaDataConst.kTypeCase);

    navigationMenuElement.addContent(linkElement);

    Element paramElement = new Element(XmlMetaDataConst.kParam);

    paramElement.setAttribute(XmlMetaDataConst.kName,
      XmlMetaDataConst.kParamCaseID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // BEGIN, CR00278729, SK
    // Create person item child element and add it to the root
    // Populate the caseIDParticipantRoleKey
    // BEGIN, CR00305478, MV
    final ReadByParticipantRoleTypeAndCaseKey readByParticipantRoleTypeAndCaseKey = new ReadByParticipantRoleTypeAndCaseKey();

    readByParticipantRoleTypeAndCaseKey.caseID = integratedCaseReferenceKey.integratedCaseID;
    readByParticipantRoleTypeAndCaseKey.participantRoleID = productDeliveryDtls.recipConcernRoleID;
    readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;    

    final ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails = caseParticipantRole.readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
      readByParticipantRoleTypeAndCaseKey);

    // END, CR00278729 

    caseParticipantRoleIDKey.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
    // END, CR00305478
    
    // Get participant home page
    participantHomePageName = resolveParticipantHome(caseParticipantRoleIDKey);

    // create link to the participant home page.
    linkElement = new Element(XmlMetaDataConst.kItem);

    linkElement.setAttribute(XmlMetaDataConst.kPageID,
      participantHomePageName.participantHomePageName);
    
    description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(concernRoleNameDetails.concernRoleName);

    linkElement.setAttribute(XmlMetaDataConst.kDesc,
      description.toClientFormattedText());
    linkElement.setAttribute(XmlMetaDataConst.kType,
      XmlMetaDataConst.kTypePerson);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(XmlMetaDataConst.kParam);

    paramElement.setAttribute(XmlMetaDataConst.kName,
      XmlMetaDataConst.kParamCaseParticipantRoleID);
    // BEGIN, CR00305478, MV
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      Long.toString(
      readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID));
    // END, CR00305478
    linkElement.addContent(paramElement);

    paramElement = new Element(XmlMetaDataConst.kParam);

    paramElement.setAttribute(XmlMetaDataConst.kName,
      XmlMetaDataConst.kParamCaseID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // Create product item child element and add it to the root
    linkElement = new Element(XmlMetaDataConst.kItem);

    linkElement.setAttribute(XmlMetaDataConst.kPageID,
      caseHomePageNameAndType.caseHomePageName);

    description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_PD_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(PRODUCTTYPE.TABLENAME,
      caseHomePageNameAndType.typeCode));

    linkElement.setAttribute(XmlMetaDataConst.kDesc,
      description.toClientFormattedText());
    linkElement.setAttribute(XmlMetaDataConst.kType,
      XmlMetaDataConst.kTypeProduct);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(XmlMetaDataConst.kParam);

    paramElement.setAttribute(XmlMetaDataConst.kName,
      XmlMetaDataConst.kParamCaseID);
    paramElement.setAttribute(XmlMetaDataConst.kValue,
      Long.toString(key.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    XMLOutputter outputter = new XMLOutputter();

    icProductDeliveryMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return icProductDeliveryMenuDataDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the home page name for an Integrated Case participant.
   *
   * @param key Contains the integrated case identifier.
   *
   * @return The home page name for an Integrated Case participant
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ParticipantHomePageName resolveParticipantHome(
    CaseParticipantRoleIDKey key) throws AppException, InformationalException {

    // Create return object
    ParticipantHomePageName participantHomePageName = new ParticipantHomePageName();

    // MaintainAdminIntegratedCase manipulation variable
    MaintainAdminIntegratedCase maintainAdminIntegratedCaseObj = MaintainAdminIntegratedCaseFactory.newInstance();

    ICParticipantHomePageKey iCParticipantHomePageKey = new ICParticipantHomePageKey();

    ICParticipantHomePageName iCParticipantHomePageName;

    // Assign key to read participant home page name
    iCParticipantHomePageKey.caseParticipantRoleID = key.caseParticipantRoleID;

    // Call MaintainAdminIntegratedCase BPO to read participant home page name
    // and assign to return object
    iCParticipantHomePageName = maintainAdminIntegratedCaseObj.getICParticipantHomePageName(
      iCParticipantHomePageKey);

    participantHomePageName.participantHomePageName = iCParticipantHomePageName.participantHomePageName;

    participantHomePageName.participantIconName = iCParticipantHomePageName.participantIconName;

    // return details.
    return participantHomePageName;
  }

  // ___________________________________________________________________________
  /**
   * Execute reflection on the Argument Class and Method, using argument
   * parameters.
   *
   * @param className Class name to instantiate
   * @param methodName Method to be run
   * @param arguments Arguments to be passed to Method
   * @param parameterTypes Class Types of Parameters used
   *
   * @return Invoked method will return object which can be case by cast method.
   */
  protected Object performReflection(String className, String methodName,
    Object[] arguments, Class[] parameterTypes)
    throws AppException, InformationalException {

    Class cls = null;
    AppException ae = null;

    try {
      // Load the class
      cls = Class.forName(className);

      // Create a method for the static newInstance constructor
      // BEGIN, CR00052924, GM
      Method constructorMethod = cls.getMethod(ReflectionConst.kNewInstance);
      // END, CR00052924
      Object classObj = constructorMethod.invoke(cls);

      // Define the method
      // BEGIN, CR00142355, CD
      Method method = classObj.getClass().getMethod(methodName, parameterTypes);

      // END, CR00142355

      // Now invoke the method
      return method.invoke(classObj, arguments);

    } catch (IllegalAccessException e) {// ignore - biz methods MUST be public
    } catch (ClassNotFoundException e) {

      ae = new AppException(BPOREFLECTION.ERR_REFLECTION_CLASS_NOT_FOUND);

      ae.arg(className);
      ae.arg(getClass().toString());
      // BEGIN, CR00163098, JC
      ae.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
        TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

    } catch (NoSuchMethodException e) {

      ae = new AppException(BPOREFLECTION.ERR_REFLECTION_NO_SUCH_METHOD);

      ae.arg(className);
      // BEGIN, CR00052924, GM
      ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
      // END, CR00052924
      // BEGIN, CR00163098, JC
      ae.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
        TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

    } catch (IllegalArgumentException e) {

      ae = new AppException(BPOREFLECTION.ERR_ILLEGAL_FUNCTION_ARGUMENTS);
      // BEGIN, CR00052924, GM
      ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
      // END, CR00052924
      ae.arg(className);
      // BEGIN, CR00163098, JC
      ae.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
        TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

    } catch (InvocationTargetException e) {

      AppException exc = new AppException(
        BPOREFLECTION.ERR_BPO_MESSAGE_RETURNED);

      exc.arg(e.getTargetException().getMessage());
      throw exc;
    }

    if (ae != null) {
      throw new RuntimeException(ae);
    }

    return null;
  }

  // BEGIN, CR00120297, CD
  // ___________________________________________________________________________
  /**
   * Return details that will comprise the XML blob used to populate the
   * evidence comparison screen inside the Evidence Broker.
   *
   * @param key Identifies an evidence entity
   * @return Evidence entity details
   */
  public EvidenceComparisonDtls getComparisonData(EvidenceCaseKey key)
    throws AppException, InformationalException {
  
    EvidenceComparisonDtls evidenceComparisonDtls = new EvidenceComparisonDtls();
    
    SportingSponsershipKey sportingSponsershipKey = new SportingSponsershipKey();

    sportingSponsershipKey.sportingSponsorshipID = key.evidenceKey.evidenceID;
    
    ViewSportingSponsorshipDtls readDtls = readSportingSponsershipEvidence(
      sportingSponsershipKey);
    
    // BEGIN, CR00122003, KH
    EvidenceDescriptorKey evidenceKey = new EvidenceDescriptorKey();

    evidenceKey.evidenceDescriptorID = readDtls.evidenceDescriptorID;
    
    EvidenceDescriptorDtls evidenceDtls = EvidenceControllerFactory.newInstance().readEvidenceDescriptorDtls(
      evidenceKey);
    
    evidenceComparisonDtls.descriptor.assign(evidenceDtls);
    // END, CR00122003

    evidenceComparisonDtls.descriptor.updatedBy = readDtls.updatedBy;
    evidenceComparisonDtls.descriptor.updatedDateTime = readDtls.updatedDateTime;
    
    // BEGIN, CR00386333, VT
    final Locale locale = ProgramLocale.parseLocale(
      TransactionInfo.getProgramLocale());

    ResourceBundle domainTypes = ResourceBundle.getBundle(
      SampleSportingGrantConst.kSportingSponsershipDomainsFile, locale);

    ResourceBundle labels = ResourceBundle.getBundle(
      SampleSportingGrantConst.kSportingSponsershipLabelsFile, locale);
    // END, CR00386333

    Object[] valueObjects = {
      readDtls.clientDtls.name, readDtls.sponsorshipAmount,
      readDtls.sponsorshipType, readDtls.comments
    };
      
    EvidenceComparisonHelper helper = new EvidenceComparisonHelper();

    // populate the return struct one attribute at a time
    for (int i = 0; i
      < SampleSportingGrantConst.kSportingSponsershipNames.length
        && i < valueObjects.length; i++) {
    
      EvidenceAttributeDtls attribute = new EvidenceAttributeDtls();
      
      try {
        attribute.domain = domainTypes.getString(
          SampleSportingGrantConst.kSportingSponsershipNames[i]);      
      } catch (MissingResourceException mre) {
        // missing domain causes widget to fail
        // insert SVR_STRING by default
        attribute.domain = CuramConst.kDomainSVR_STRING;
      }
      try {
        attribute.label = labels.getString(
          SampleSportingGrantConst.kSportingSponsershipNames[i]);        
      } catch (MissingResourceException mre) {
        // labels are blank by default
        attribute.label = CuramConst.gkEmpty;
      }
      attribute.value = helper.objectToString(valueObjects[i]);
      evidenceComparisonDtls.details.addRef(attribute);      
    }    
    
    return evidenceComparisonDtls;    
  }
  // END, CR00120297, CR00122003
}

