/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;


import curam.core.facade.struct.ProductDeliveryContextDescription;
import curam.core.facade.struct.ProductDeliveryContextDescriptionKey;
import curam.core.sl.entity.struct.GetBenefitOverpaymentEvidenceResult;
import curam.core.sl.fact.ReassessmentProductFactory;
import curam.core.sl.struct.GetEvidenceKey;
import curam.sample.facade.struct.SampleBenefitOverpaymentEvidenceDetails;
import curam.sample.facade.struct.SampleBenefitOverpaymentEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Contains maintenance functions for the Sample Benefit Overpayment facade.
 *
 */
public abstract class SampleBenefitOverpayment extends curam.sample.facade.base.SampleBenefitOverpayment {

  // ___________________________________________________________________________
  /**
   * Returns evidence for the specified overpayment case.
   *
   * @param key The case ID.
   *
   * @return Evidence relating to the case.
   *
   * @deprecated Since Curam 6.0
   */
  @Deprecated
  public SampleBenefitOverpaymentEvidenceDetails getEvidence
    (SampleBenefitOverpaymentEvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    SampleBenefitOverpaymentEvidenceDetails sampleBenefitOverpaymentEvidenceDetails =
      new SampleBenefitOverpaymentEvidenceDetails();

    // BEGIN, CR00192165, VM
    GetEvidenceKey getEvidenceKey = new GetEvidenceKey();
    getEvidenceKey.caseID = key.caseID;

    GetBenefitOverpaymentEvidenceResult result =
      ReassessmentProductFactory.newInstance().getBenefitOverpaymentEvidence(
        getEvidenceKey);

    // Assign details
    sampleBenefitOverpaymentEvidenceDetails.concernRoleID =
      result.concernDetails.concernRoleID;
    sampleBenefitOverpaymentEvidenceDetails.concernRoleType =
      result.concernDetails.concernRoleType;
    sampleBenefitOverpaymentEvidenceDetails.concernAddressData =
      result.concernDetails.concernAddressData;
    sampleBenefitOverpaymentEvidenceDetails.concernRoleName =
      result.concernDetails.concernRoleName;

    sampleBenefitOverpaymentEvidenceDetails.overpaymentAmount =
      result.details.overpaymentAmount;
    sampleBenefitOverpaymentEvidenceDetails.evidenceID =
      result.details.evidenceID;
    sampleBenefitOverpaymentEvidenceDetails.caseReference =
      result.details.caseReference;
    sampleBenefitOverpaymentEvidenceDetails.relatedCaseID =
      result.details.relatedCaseID;
    sampleBenefitOverpaymentEvidenceDetails.relatedCaseReference =
      result.details.relatedCaseReference;
    sampleBenefitOverpaymentEvidenceDetails.versionNo =
      result.details.versionNo;
    sampleBenefitOverpaymentEvidenceDetails.reassessmentDate =
      result.details.reassessmentDate;

    sampleBenefitOverpaymentEvidenceDetails.productName =
      result.productDeliverySummary.productName;
    sampleBenefitOverpaymentEvidenceDetails.productID =
      result.productDeliverySummary.productID;
    sampleBenefitOverpaymentEvidenceDetails.productProviderName =
      result.productDeliverySummary.productProviderName;
    sampleBenefitOverpaymentEvidenceDetails.productProviderID =
      result.productDeliverySummary.productProviderID;
    // END, CR00192165

    // ProductDeliveryContext manipulation variables
    curam.core.facade.intf.ProductDeliveryContext productDeliveryContextObj =
      curam.core.facade.fact.ProductDeliveryContextFactory.newInstance();
    ProductDeliveryContextDescription productDeliveryContextDescription =
      new ProductDeliveryContextDescription();
    ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey =
      new ProductDeliveryContextDescriptionKey();

    productDeliveryContextDescriptionKey.caseID = key.caseID;

    productDeliveryContextDescription =
      productDeliveryContextObj.readContextDescription(
        productDeliveryContextDescriptionKey);

    sampleBenefitOverpaymentEvidenceDetails.contextDescription =
      productDeliveryContextDescription.description;

    // Return evidence details
    return sampleBenefitOverpaymentEvidenceDetails;
  }

}
