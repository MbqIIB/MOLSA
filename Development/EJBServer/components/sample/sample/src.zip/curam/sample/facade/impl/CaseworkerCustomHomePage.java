/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;

import curam.core.sl.infrastructure.widgetUtility.impl.PodContainerConfig;
import curam.sample.facade.struct.CustomPage;
import curam.sample.sl.impl.CustomizablePageLoader;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;



/**
 * Loads and returns the Workspace Contents for rendering a Users
 * customized workspace.
 *
 * @deprecated since Curam 6.0.
 */
@Deprecated
public abstract class CaseworkerCustomHomePage
  extends curam.sample.facade.base.CaseworkerCustomHomePage {


  // __________________________________________________________________________
  /**
   * Returns a formatted string representation of the current xml document.
   * The string is formatted for line length and indenting.
   *
   * @return null
   *
   * @deprecated since Curam 6.0.
   */
  @Deprecated
  public CustomPage getPageContent()
    throws AppException, InformationalException {

    // Return struct
    CustomPage page = new CustomPage();

    // PageLoader Object
    CustomizablePageLoader contentLoader = new CustomizablePageLoader();

    // Retrieve all relevant data to render up Case Homepage pods
    // (configuration and application data)
    page = contentLoader.loadContent();

    return page;
  }

  //________________________________________________________________________
  /**
   * Sets the configuration details for the Caseworker_customHome page.
   * Configuration settings can range from selecting the relevant pods to be
   * displayed, saving the location of pods on the homepage.
   *
   * @param details The updated configuration data for the custom page.
   *
   * @deprecated since Curam 6.0.
   */
  @Deprecated
  public void setConfigurationDetails(curam.sample.facade.struct.ConfigurationDetails details)
    throws AppException, InformationalException {

    // PodContainerConfig object
    PodContainerConfig podContainerConfig = new PodContainerConfig();

    // Set Caseworker_customHome preferences for user
    podContainerConfig.setConfigurationDetails(details.configSettings);
  }
}
