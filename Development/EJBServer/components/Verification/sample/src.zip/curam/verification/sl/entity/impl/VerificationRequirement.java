/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006,2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.message.ENTVERIFICATIONREQUIREMENT;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.verification.sl.entity.struct.ActiveRequirementUsageByRequirementCountDetails;
import curam.verification.sl.entity.struct.SearchAllActiveVerificationRequirementNamesList;
import curam.verification.sl.entity.struct.VerifiableDataItemIDAndStatusKey;
import curam.verification.sl.entity.struct.VerificationRequirementCancelDetails;
import curam.verification.sl.entity.struct.VerificationRequirementDtls;
import curam.verification.sl.entity.struct.VerificationRequirementIDAndStatusKey;
import curam.verification.sl.entity.struct.VerificationRequirementKey;
import curam.verification.sl.entity.struct.VerificationRequirementRecordCount;
import curam.verification.sl.infrastructure.entity.fact.VerificationFactory;
import curam.verification.sl.infrastructure.entity.intf.Verification;
import curam.verification.sl.infrastructure.entity.struct.VerificationRequirementIDDetailsList;
import curam.verification.sl.infrastructure.fact.VerificationControllerFactory;
import curam.verification.sl.infrastructure.intf.VerificationController;


/**
 * Contains details about a specific operations that can be executed on a
 * Verification Requirement record. A Verification Requirement record contains
 * details required to verify a specific data item.
 */

public abstract class VerificationRequirement extends curam.verification.sl.entity.base.VerificationRequirement {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details Verification requirement details
   */
  protected void preinsert(VerificationRequirementDtls details) throws AppException, InformationalException {
    validateInsert(details);
    validateDetails(details);
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param details Verification requirement details
   */
  protected void premodify(VerificationRequirementKey key, VerificationRequirementDtls details) throws AppException, InformationalException {
    validateModify(details);
    validateDetails(details);
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data deletion
   *
   * @param key Verification requirement key
   *
   * @param dtls Verification requirement details
   */
  protected void precancel(VerificationRequirementKey key, VerificationRequirementCancelDetails dtls) throws AppException, InformationalException {

    validateCancel(dtls);

    // Set the record status to cancelled
    dtls.recordStatus = RECORDSTATUS.CANCELLED;

  }

  // ___________________________________________________________________________
  /**
   * Performs the validations common to all operations.
   *
   * @param dtls Verification requirement details
   */
  public void validateDetails(VerificationRequirementDtls dtls) throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    int numberOfDays = 0;

    // The name must be entered
    if (dtls.name.trim().length() == 0) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_NAME_EMPTY);
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!dtls.toDate.isZero()) {
      if (dtls.toDate.before(dtls.fromDate)) {
        AppException appException = new AppException(
          curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_TO_DATE_BEFORE_FROM_DATE);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          appException, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }

    if (dtls.minimumItems < 0) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_NEGATIVE_MINIMUM_ITEMS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      
    }

    if (dtls.dueDays < 0) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_NEGATIVE_DUE_DAYS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (dtls.warningDays < 0) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_NEGATIVE_WARNING_DAYS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (dtls.dueDays == 0 && dtls.warningDays > 0) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_WARNING_DAYS_WITHOUT_DUE_DAYS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (dtls.dueDays == 0 && dtls.dueDateEventType.trim().length() > 0) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_DUE_DAYS_EVENT_WITHOUT_DUE_DAYS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (dtls.warningDays >= dtls.dueDays && dtls.dueDays > 0) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_WARNING_DAYS_GREATER_THAN_OR_EQUAL_TO_DUE_DAYS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (dtls.dueDays == 0 && dtls.dueDateModifiableInd) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_MODIFY_DUE_DAYS_TRUE_WITHOUT_DUE_DAYS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!dtls.toDate.isZero()) {

      numberOfDays = dtls.toDate.subtract(dtls.fromDate);
      if (dtls.dueDays > numberOfDays) {
        AppException appException = new AppException(
          curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_DUE_DAYS_EXCEED_VERIFICATION_REQUIREMENT_PERIOD);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          appException, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

    }

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification Requirement details before the logical delete
   *
   * @param details Verification requirement details
   */
  public void validateCancel(VerificationRequirementCancelDetails details) throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Record must not be already cancelled
    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_VERIFICATION_REQUIREMENT_CANCELLED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // Verification Requirement must not have any active Verification Requirement Usage.

    curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsage = curam.verification.sl.entity.fact.VerificationRequirementUsageFactory.newInstance();

    VerificationRequirementIDAndStatusKey verificationRequirementIDAndStatusKey = new VerificationRequirementIDAndStatusKey();

    verificationRequirementIDAndStatusKey.verificationRequirementID = details.verificationRequirementID;
    verificationRequirementIDAndStatusKey.recordStatus = RECORDSTATUS.CANCELLED;

    ActiveRequirementUsageByRequirementCountDetails activeRequirementUsageByRequirementCountDetails = verificationRequirementUsage.countAllUsagesByRequirementID(
      verificationRequirementIDAndStatusKey);

    if (activeRequirementUsageByRequirementCountDetails.recordCount > 0) {
      AppException appException = new AppException(
        ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_XRV_HAS_ASSOCIATED_VERIFICATION_REQUIREMENT);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    VerificationRequirementIDDetailsList verificationRequirementIDDetailsList = new VerificationRequirementIDDetailsList();
    VerificationRequirementKey verificationRequirementKey = new VerificationRequirementKey();
    
    Verification verification = VerificationFactory.newInstance();
    
    verificationRequirementKey.verificationRequirementID = details.verificationRequirementID;
    
    verificationRequirementIDDetailsList = verification.searchVerificationRequirementsByRequirementID(
      verificationRequirementKey);
    
    if (!verificationRequirementIDDetailsList.dtls.isEmpty()) {
      
      AppException appException = new AppException(
        ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_XRV_HAS_ASSOCIATED_USAGE_VERIFICATION_APPLICATION);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    
    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification requirement details before the data insertion
   *
   * @param dtls Verification requirement details
   */
  public void validateInsert(VerificationRequirementDtls dtls) throws AppException, InformationalException {

    // check if Verification Requirement is unique
    curam.verification.sl.entity.struct.VerificationRequirementNameAndStatus verificationRequirementNameAndStatus = new curam.verification.sl.entity.struct.VerificationRequirementNameAndStatus();

    verificationRequirementNameAndStatus.recordStatus = curam.codetable.RECORDSTATUS.CANCELLED;

    verificationRequirementNameAndStatus.name = dtls.name;

    verificationRequirementNameAndStatus.verifiableDataItemID = dtls.verifiableDataItemID;

    VerificationRequirementRecordCount verificationRequirementRecordCount;

    verificationRequirementRecordCount = countByNameAndStatus(
      verificationRequirementNameAndStatus);
    // BEGIN, CR00051101, GSP
    // BEGIN, HARP 65054, NK 
    if (dtls.dueDays != 0 && dtls.dueDateFrom.trim().length() == 0) { 
      AppException appException = new AppException( 
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_DUE_DAYS_WITHOUT_DUEDATEFROM); 
 
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        appException,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0); 
    } 
    // END, HARP 65054 
    // END, CR00051101

    if (verificationRequirementRecordCount.recordCount > 0) {
      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_XRV_NAME_ALREADY_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        appException,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification requirement details before the data modification
   *
   * @param dtls Verification requirement details
   */
  public void validateModify(VerificationRequirementDtls dtls) throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Record must not be already canceled
    if (dtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_VERIFICATION_REQUIREMENT_CANCELLED);
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // The name must not already be in use

    // Retrieve a list of all Verification requirement names.

    VerifiableDataItemIDAndStatusKey verifiableDataItemIDAndStatusKey = new VerifiableDataItemIDAndStatusKey();

    verifiableDataItemIDAndStatusKey.recordStatus = RECORDSTATUS.CANCELLED;
    verifiableDataItemIDAndStatusKey.verifiableDataItemID = dtls.verifiableDataItemID;

    SearchAllActiveVerificationRequirementNamesList searchAllActiveVerificationRequirementNamesList = searchAllActiveNames(
      verifiableDataItemIDAndStatusKey);

    // Iterate through the list of Verification requirement.
    for (int i = 0; i
      < searchAllActiveVerificationRequirementNamesList.dtls.size(); i++) {

      // Do not check against its own record in the list.
      if (dtls.verificationRequirementID
        != searchAllActiveVerificationRequirementNamesList.dtls.item(i).verificationRequirementID) {

        // Check that the name does not already exist.
        if (dtls.name.equals(
          searchAllActiveVerificationRequirementNamesList.dtls.item(i).name)) {

          AppException appException = new AppException(
            ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_XRV_NAME_ALREADY_EXISTS);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            appException, CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
        }
      }
    }
   
    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

}
