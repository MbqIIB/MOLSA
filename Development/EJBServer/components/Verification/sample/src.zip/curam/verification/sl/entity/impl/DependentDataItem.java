/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.message.ENTDEPENDANTDATAITEM;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.verification.sl.entity.fact.DependentDataItemFactory;
import curam.verification.sl.entity.struct.DependentDataItemCancelDetails;
import curam.verification.sl.entity.struct.DependentDataItemDtls;
import curam.verification.sl.entity.struct.DependentDataItemKey;
import curam.verification.sl.entity.struct.DependentDataItemNameAndStatusKey;
import curam.verification.sl.entity.struct.DependentDataItemRecordCount;
import curam.verification.sl.entity.struct.SearchAllActiveDependentDataItemNamesList;
import curam.verification.sl.entity.struct.VerifiableDataItemIDAndStatusKey;
import curam.verification.sl.infrastructure.fact.VerificationControllerFactory;
import curam.verification.sl.infrastructure.intf.VerificationController;


/**
 * Contains details about specific operations that can be performed on a Dependent
 * Data Item record. A Dependent Data record Item is a data item that can affect
 * the verification of the verifiable data item.
 */
public abstract class DependentDataItem extends curam.verification.sl.entity.base.DependentDataItem {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details Dependent Data Item details
   */
  protected void preinsert(DependentDataItemDtls details) throws AppException, InformationalException {
    validateInsert(details);
    validateDetails(details);
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param key Dependent Data Item identifier
   * @param details Dependent Data Item details
   */
  protected void premodify(DependentDataItemKey key, DependentDataItemDtls details) throws AppException, InformationalException {
    validateModify(details);
    validateDetails(details);
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the logical delete
   *
   * @param key Dependent Data Item  identifier
   * @param dtls Dependent Data Item  details
   */
  protected void precancel(DependentDataItemKey key, DependentDataItemCancelDetails dtls) throws AppException, InformationalException { 
    curam.verification.sl.entity.intf.DependentDataItem dependentDataItem = DependentDataItemFactory.newInstance();
  
    dependentDataItem.validateCancel(dtls);
    
    // Set the record status to cancelled
    dtls.recordStatus = RECORDSTATUS.CANCELLED;
  }

  // ___________________________________________________________________________
  /**
   * Performs the validations common to all operations
   *
   * @param details dependent data item details
   */
  public void validateDetails(DependentDataItemDtls details) throws AppException, InformationalException {
    
    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175
   
  }

  // ___________________________________________________________________________
  /**
   * Validates the dependent data item details before the logical delete
   *
   *
   * @param details dependent data item details
   */
  public void validateCancel(DependentDataItemCancelDetails details) throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Record must not be already cancelled
    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      AppException appException = new AppException(
        curam.message.ENTDEPENDANTDATAITEM.ERR_VERIFICATIONDEPENDENTDATAITEM_VERIFICATION_DEPENDENT_DATA_ITEM_CANCELLED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    
    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175
    
  }

  // ___________________________________________________________________________
  /**
   * Validates the dependent data item details before the data insertion
   *
   * @param details dependent data item details
   */
  public void validateInsert(DependentDataItemDtls details) throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // The name must be entered
    if (details.name.trim().length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.ENTDEPENDANTDATAITEM.ERR_VERIFICATIONDEPENDENTDATAITEM_FV_NAME_MUST_BE_ENTERED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
    
    // check if  dependent data item is unique
    DependentDataItemNameAndStatusKey dependentDataItemNameAndStatusKey = new curam.verification.sl.entity.struct.DependentDataItemNameAndStatusKey();

    dependentDataItemNameAndStatusKey.recordStatus = curam.codetable.RECORDSTATUS.CANCELLED;

    dependentDataItemNameAndStatusKey.name = details.name;
    dependentDataItemNameAndStatusKey.verifiableDataItemID = details.verifiableDataItemID;

    DependentDataItemRecordCount dependentDataItemRecordCount;

    dependentDataItemRecordCount = countByNameAndStatus(
      dependentDataItemNameAndStatusKey);

    if (dependentDataItemRecordCount.recordCount > 0) {
      AppException appException = new AppException(
        curam.message.ENTDEPENDANTDATAITEM.ERR_VERIFICATIONDEPENDENTDATAITEM_XRV_NAME_AND_DETAILS_ALREADY_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175
    
  }

  // ___________________________________________________________________________
  /**
   * Validates the dependent data item details before the data modification
   *
   *
   * @param details dependent data item details
   */
  public void validateModify(DependentDataItemDtls details) throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Record must not be already canceled
    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      AppException appException = new AppException(
        curam.message.ENTDEPENDANTDATAITEM.ERR_VERIFICATIONDEPENDENTDATAITEM_VERIFICATION_DEPENDENT_DATA_ITEM_CANCELLED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // The name must not already be in use
    // Retrieve a list of all dependent data item names.
    VerifiableDataItemIDAndStatusKey verifiableDataItemIDAndStatusKey = new VerifiableDataItemIDAndStatusKey();

    verifiableDataItemIDAndStatusKey.recordStatus = RECORDSTATUS.CANCELLED;
    verifiableDataItemIDAndStatusKey.verifiableDataItemID = details.verifiableDataItemID;
    SearchAllActiveDependentDataItemNamesList searchAllActiveDependentDataItemNamesList = searchAllActiveNames(
      verifiableDataItemIDAndStatusKey);

    // Iterate through the list of dependent data item.
    for (int i = 0; i < searchAllActiveDependentDataItemNamesList.dtls.size(); i++) {

      // Do not check against its own record in the list.
      if (details.dependentDataItemID
        != searchAllActiveDependentDataItemNamesList.dtls.item(i).dependentDataItemID) {

        // Check that the name does not already exist.
        if (details.name.equals(
          searchAllActiveDependentDataItemNamesList.dtls.item(i).name)) {

          AppException appException = new AppException(
            ENTDEPENDANTDATAITEM.ERR_VERIFICATIONDEPENDENTDATAITEM_XRV_NAME_AND_DETAILS_ALREADY_EXISTS);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            appException, CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
        }
      }
    }

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }

}
