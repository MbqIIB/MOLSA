/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2006, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/**
 * Copyright 2006, 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.infrastructure.impl;


import curam.codetable.EXPIRYDATEFROM;
import curam.codetable.VERIFIABLEITEMNAME;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.NotificationFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.sl.fact.TaskManagementUtilityFactory;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.intf.TaskManagementUtility;
import curam.core.sl.struct.DateTimeInSecondsKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.ConcernRoleKey;
import curam.message.VERIFICATIONITEMUTILIZATIONWORKFLOW;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.intf.CodeTable;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.verification.sl.entity.fact.VerifiableDataItemFactory;
import curam.verification.sl.entity.fact.VerificationItemUtilizationFactory;
import curam.verification.sl.entity.intf.VerifiableDataItem;
import curam.verification.sl.entity.intf.VerificationItemUtilization;
import curam.verification.sl.entity.struct.UtlizationExpiryWarningAndDateFrom;
import curam.verification.sl.entity.struct.VerifiableDataItemKey;
import curam.verification.sl.entity.struct.VerificationItemNameDetails;
import curam.verification.sl.entity.struct.VerificationItemUtilizationDtls;
import curam.verification.sl.entity.struct.VerificationItemUtilizationKey;
import curam.verification.sl.infrastructure.entity.fact.VerificationItemProvidedFactory;
import curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided;
import curam.verification.sl.infrastructure.entity.struct.EvidenceDescriptorDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedKey;
import curam.verification.sl.infrastructure.struct.VerificationUtilizationExpiryDate;
import curam.verification.sl.infrastructure.struct.VerificationUtilizationWarningDate;


// BEGIN, CR00170942, NS
public abstract class ProcessVerificationItemExpiryDate extends curam.verification.sl.infrastructure.base.ProcessVerificationItemExpiryDate {
  // END, CR00170942

  /**
   * This calculateExpiryDate method calculate the expiry date of verification
   * item provided to satisfy the verification requirement.
   *
   * @param key
   * Contains the verification item utilization ID.
   * @param verificationItemProvidedKey
   * Contains the verification item provided ID.
   *
   * @return The verification utilization expiry date.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public VerificationUtilizationExpiryDate calculateExpiryDate(
    final VerificationItemUtilizationKey key,
    final VerificationItemProvidedKey verificationItemProvidedKey)
    throws AppException, InformationalException {

    final TaskManagementUtility taskManagementUtilityObj = TaskManagementUtilityFactory.newInstance();

    final DateTimeInSecondsKey dateTimeInSecondsKey = new DateTimeInSecondsKey();
    final Date currentDate = Date.getCurrentDate();
    final Date expiryDate = getExpiryDate(key, verificationItemProvidedKey);

    final VerificationUtilizationExpiryDate verificationUtilizationExpiryDate = new VerificationUtilizationExpiryDate();

    verificationUtilizationExpiryDate.expiryDateInFutureInd = true;
    
    // BEGIN, CR00227793, NS
    if (!Date.kZeroDate.equals(expiryDate)) {
      // END, CR00227793

      dateTimeInSecondsKey.dateTime = expiryDate.getDateTime();

      verificationUtilizationExpiryDate.expiryDateDeadline = taskManagementUtilityObj.convertDateTimeToSeconds(dateTimeInSecondsKey).seconds;

      if (expiryDate.before(currentDate.addDays(1))) {

        verificationUtilizationExpiryDate.expiryDateInFutureInd = false;
      }
    }

    return verificationUtilizationExpiryDate;
  }

  /**
   * This getExpiryDate method calculate the expiry date depends on the
   * selection of expiry date from option in the item utilization.
   *
   * @param key
   * Contains the verification item utilization ID.
   * @param verificationItemProvidedKey
   * Contains the verification item provided ID.
   *
   * @return The expiry date.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected Date getExpiryDate(final VerificationItemUtilizationKey key,
    final VerificationItemProvidedKey verificationItemProvidedKey)
    throws AppException, InformationalException {
    // END, CR00198672
    
    Date expiryDate;

    UtlizationExpiryWarningAndDateFrom utlizationExpiryWarningAndDateFrom = new UtlizationExpiryWarningAndDateFrom();

    utlizationExpiryWarningAndDateFrom = calculateDates(key);

    final int expiryDays = utlizationExpiryWarningAndDateFrom.expiryDays;

    // BEGIN, CR00227793, NS
    if (CuramConst.gkMinusOne == expiryDays) {
      expiryDate = Date.kZeroDate;
    } else {
      // END, CR00227793
      
      // Calculate the expiry date depends on the selection of
      // expiry date from option.
      if (utlizationExpiryWarningAndDateFrom.expiryDateFrom.equals(
        EXPIRYDATEFROM.ITEMADDED)) {

        expiryDate = Date.getCurrentDate().addDays(expiryDays);
      } else if (utlizationExpiryWarningAndDateFrom.expiryDateFrom.equals(
        EXPIRYDATEFROM.ITEMRECEIVED)) {

        expiryDate = calculateExpiryDateFromItemReceived(
          verificationItemProvidedKey, expiryDays);
      } else {

        expiryDate = calculateExpiryDateFromItemProvided(
          verificationItemProvidedKey, expiryDays);
      }
    }

    return expiryDate;
  }

  /**
   * This calculateExpiryDateFromItemProvided is a utility method for
   * calculation of the expiry date.
   *
   * @param verificationItemProvidedKey
   * Contains the verification item provided ID.
   * @param expiryDays
   * Contains the number of days for expiry.
   *
   * @return The expiry date.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected Date calculateExpiryDateFromItemReceived(
    VerificationItemProvidedKey verificationItemProvidedKey, int expiryDays)
    throws AppException, InformationalException {

    Date expiryDate;

    final VerificationItemProvided verificationItemProvidedObj = VerificationItemProvidedFactory.newInstance();
    VerificationItemProvidedDtls verificationItemProvidedDtls = new VerificationItemProvidedDtls();

    verificationItemProvidedDtls = verificationItemProvidedObj.read(
      verificationItemProvidedKey);

    expiryDate = verificationItemProvidedDtls.dateReceived.addDays(expiryDays);

    return expiryDate;
  }

  /**
   * This calculateExpiryDateFromItemProvided is a utility method for
   * calculation of the expiry date.
   *
   * @param verificationItemProvidedKey
   * Contains the verification item provided ID.
   * @param expiryDays
   * Contains the number of days for expiry.
   *
   * @return The expiry date.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected Date calculateExpiryDateFromItemProvided(
    VerificationItemProvidedKey verificationItemProvidedKey, int expiryDays)
    throws AppException, InformationalException {

    Date expiryDate;

    final VerificationItemProvided verificationItemProvidedObj = VerificationItemProvidedFactory.newInstance();
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    EvidenceDescriptorDetails evidenceDescriptorDetails = new EvidenceDescriptorDetails();
    EvidenceDescriptorDtls evidenceDescriptorDtls = new EvidenceDescriptorDtls();
    final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    evidenceDescriptorDetails = verificationItemProvidedObj.readEvidenceDescriptorIDByItemProvidedKey(
      verificationItemProvidedKey);

    evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDetails.evidenceDescriptorID;

    evidenceDescriptorDtls = evidenceDescriptorObj.read(evidenceDescriptorKey);

    expiryDate = evidenceDescriptorDtls.receivedDate.addDays(expiryDays);

    return expiryDate;
  }

  /**
   * This calculateWarningDate method calculate the warning date of the
   * verification item expiry.
   *
   * @param key
   * Contains the verification item utilization ID.
   * @param verificationItemProvidedKey
   * Contains the verification item provided ID.
   *
   * @return The verification utilization warning date.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public VerificationUtilizationWarningDate calculateWarningDate(
    VerificationItemUtilizationKey key,
    VerificationItemProvidedKey verificationItemProvidedKey)
    throws AppException, InformationalException {

    final TaskManagementUtility taskManagementUtilityObj = TaskManagementUtilityFactory.newInstance();
    final DateTimeInSecondsKey dateTimeInSecondsKey = new DateTimeInSecondsKey();
    UtlizationExpiryWarningAndDateFrom utlizationExpiryWarningAndDateFrom = new UtlizationExpiryWarningAndDateFrom();

    final VerificationUtilizationWarningDate verificationUtilizationWarningDate = new VerificationUtilizationWarningDate();

    verificationUtilizationWarningDate.warningDateInFutureInd = true;

    utlizationExpiryWarningAndDateFrom = calculateDates(key);
    final int warningDays = utlizationExpiryWarningAndDateFrom.warningDays;
    Date expiryDate;
    Date warningDate;

    if (utlizationExpiryWarningAndDateFrom.expiryDateFrom.equals(
      EXPIRYDATEFROM.ITEMADDED)) {

      expiryDate = Date.getCurrentDate().addDays(
        utlizationExpiryWarningAndDateFrom.expiryDays);
    } else {

      expiryDate = calculateExpiryDateFromItemProvided(
        verificationItemProvidedKey,
        utlizationExpiryWarningAndDateFrom.expiryDays);
    }

    if (warningDays <= 0) {

      verificationUtilizationWarningDate.warningDateStatus = VerificationConst.gkItemUtilizationWarningDateEmpty;
      verificationUtilizationWarningDate.warningDateInFutureInd = false;
    } else {

      warningDate = expiryDate.addDays(-warningDays);
      if (warningDate.after(Date.getCurrentDate())) {

        verificationUtilizationWarningDate.warningDateStatus = VerificationConst.gkItemUtilizationWarningDateInFuture;
        verificationUtilizationWarningDate.warningDateInFutureInd = false;
      } else {

        verificationUtilizationWarningDate.warningDateStatus = VerificationConst.gkItemUtilizationWarningDateInPast;
      }

      dateTimeInSecondsKey.dateTime = warningDate.getDateTime();

      verificationUtilizationWarningDate.warningDateDeadline = taskManagementUtilityObj.convertDateTimeToSeconds(dateTimeInSecondsKey).seconds;
    }

    return verificationUtilizationWarningDate;
  }

  /**
   * This expiryDateReached method checks whether the expiry date for
   * verification item warning has been reached and raise the date expiration
   * workflow event.
   *
   * @param verificationItemUtilizationKey
   * Contains the verification item utilization ID.
   * @param key
   * Contains the verification item provided ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void expiryDateReached(
    VerificationItemUtilizationKey verificationItemUtilizationKey,
    VerificationItemProvidedKey key) throws AppException,
      InformationalException {

    // raise workflow event for DeadLine Expired
    final Event dueDateExpiredEvent = new Event();

    // BEGIN, CR00059934, MPB
    // Replaced event Class and event Type data files with actual event files

    dueDateExpiredEvent.eventKey = curam.events.Verification.ExpiryDateElapsed;
    // END, CR00059934, MPB

    dueDateExpiredEvent.primaryEventData = key.verificationItemProvidedID;

    EventService.raiseEvent(dueDateExpiredEvent);
  }

  /**
   * This warningDateReached method raises the warning date elapsed workflow
   * event.
   *
   * @param key
   * Contains the verification item utilization ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void warningDateReached(VerificationItemProvidedKey key)
    throws AppException, InformationalException {

    // raise workflow event for DeadLine Expired
    final Event dueDateExpiredEvent = new Event();

    // BEGIN, CR00059934, MPB
    // Replaced event Class and event Type data files with event files
    dueDateExpiredEvent.eventKey = curam.events.Verification.WarningDateElapsed;
    // END, CR00059934, MPB

    dueDateExpiredEvent.primaryEventData = key.verificationItemProvidedID;

    EventService.raiseEvent(dueDateExpiredEvent);

  }

  /**
   * This calculateDates utility method returns the verification item expiry
   * date, warning days and expiry date from.
   *
   * @param key
   * Contains the verification item utilization ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public UtlizationExpiryWarningAndDateFrom calculateDates(
    VerificationItemUtilizationKey key) throws AppException,
      InformationalException {

    UtlizationExpiryWarningAndDateFrom utlizationExpiryWarningAndDateFrom = new UtlizationExpiryWarningAndDateFrom();

    final VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    final VerificationItemUtilizationKey verificationItemUtilizationKey = new VerificationItemUtilizationKey();

    verificationItemUtilizationKey.verificationItemUtilizationID = key.verificationItemUtilizationID;

    utlizationExpiryWarningAndDateFrom = verificationItemUtilization.searchExpWarnAndExpFromByUtilID(
      verificationItemUtilizationKey);

    return utlizationExpiryWarningAndDateFrom;
  }

  /**
   * The sendNotification utility method used to send the verification item
   * warning and expiry notifications.
   *
   * @param verificationItemProvidedKey
   * Contains the Verification Item Provided ID.
   * @param communicationSubject
   * Contains the Notification subject.
   * @param communicationText
   * Contains the Notification text.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected void sendNotification(
    VerificationItemProvidedKey verificationItemProvidedKey,
    LocalisableString communicationSubject,
    LocalisableString communicationText) throws AppException,
      InformationalException {
    // END, CR00198672

    // Get the evidence DescriptorID
    final VerificationItemProvided verificationItemProvidedObj = VerificationItemProvidedFactory.newInstance();
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    EvidenceDescriptorDetails evidenceDescriptorDetails = new EvidenceDescriptorDetails();
    final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();
    EvidenceDescriptorDtls evidenceDescriptorDtls;

    evidenceDescriptorDetails = verificationItemProvidedObj.readEvidenceDescriptorIDByItemProvidedKey(
      verificationItemProvidedKey);
    evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDetails.evidenceDescriptorID;

    evidenceDescriptorDtls = evidenceDescriptorObj.read(evidenceDescriptorKey);
    caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;

    CaseHeaderDtls caseHeaderDtls;

    // Read the case header
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Set key to read concernRole entity
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    // Notification objects
    final curam.core.intf.Notification notificationObj = NotificationFactory.newInstance();

    final StandardManualTaskDtls standardManualTaskDtls = new StandardManualTaskDtls();

    // Set Notification details
    // BEGIN, CR00371868, MV
    standardManualTaskDtls.dtls.concerningDtls.caseID = evidenceDescriptorDtls.caseID;
    // END, CR00371868

    // BEGIN, CR00163659, CL
    standardManualTaskDtls.dtls.taskDtls.comments = communicationText.getMessage(
      TransactionInfo.getProgramLocale());
    standardManualTaskDtls.dtls.taskDtls.subject = communicationSubject.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163659
    standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = VerificationConst.gkVerificationNotification;

    // Create the notification
    notificationObj.createWorkAllocationNotification(standardManualTaskDtls);
  }

  /**
   * The sendItemExpiryNotification method sends the notification when
   * verification item expiry date is reached.
   *
   * @param verificationItemUtilizationKey
   * Contains the Verification Item Utilization ID.
   * @param verificationItemProvidedKey
   * Contains Verification Item Provided ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void sendItemExpiryNotification(
    VerificationItemUtilizationKey verificationItemUtilizationKey,
    VerificationItemProvidedKey verificationItemProvidedKey)
    throws AppException, InformationalException {

    // Get the evidence DescriptorID
    final VerificationItemProvided verificationItemProvidedObj = VerificationItemProvidedFactory.newInstance();
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    EvidenceDescriptorDetails evidenceDescriptorDetails = new EvidenceDescriptorDetails();
    final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();
    EvidenceDescriptorDtls evidenceDescriptorDtls;

    // BEGIN, CR00017999, KY
    // CaseHeader variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    // END, CR00017999

    evidenceDescriptorDetails = verificationItemProvidedObj.readEvidenceDescriptorIDByItemProvidedKey(
      verificationItemProvidedKey);

    evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDetails.evidenceDescriptorID;
    evidenceDescriptorDtls = evidenceDescriptorObj.read(evidenceDescriptorKey);

    // BEGIN, CR00017999, KY
    caseSearchKey.caseID = evidenceDescriptorDtls.caseID;
    // END, CR00017999

    // Get Verification item name
    final VerificationItemNameDetails verificationItemNameDetails = getVerificationItemName(
      verificationItemUtilizationKey);

    final LocalisableString communicationSubject = new LocalisableString(
      VERIFICATIONITEMUTILIZATIONWORKFLOW.INF_VERIFICATION_ITEM_UTILIZATION_WORKFLOW_COMMUNICATION__EXPIRY_SUBJECT);

    communicationSubject.arg(verificationItemNameDetails.name);

    final LocalisableString communicationText = new LocalisableString(
      VERIFICATIONITEMUTILIZATIONWORKFLOW.INF_VERIFICATION_ITEM_UTILIZATION_WORKFLOW_COMMUNICATION_EXPIRY_TEXT);

    // BEGIN, CR00017999, KY
    communicationText.arg(
      caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference);
    // END, CR00017999

    sendNotification(verificationItemProvidedKey, communicationSubject,
      communicationText);

    // Raise the workflow event
    final VerificationItemUtilization verificationItemUtilizationObj = VerificationItemUtilizationFactory.newInstance();
    VerificationItemUtilizationDtls verificationItemUtilizationDtls = new VerificationItemUtilizationDtls();

    verificationItemUtilizationDtls = verificationItemUtilizationObj.read(
      verificationItemUtilizationKey);
    // BEGIN, CR00052924, GM
    if (verificationItemUtilizationDtls.expiryDateEvent.trim().equals(
      CuramConst.gkEmpty)) {
      // END, CR00052924

      return;
    }

    // raise workflow event for DeadLine Expired
    final Event dueDateExpiredEvent = new Event();

    dueDateExpiredEvent.eventKey.eventClass = VerificationConst.gkVerificationEventClass;

    dueDateExpiredEvent.eventKey.eventType = verificationItemUtilizationDtls.expiryDateEvent;
    dueDateExpiredEvent.primaryEventData = verificationItemProvidedKey.verificationItemProvidedID;

    EventService.raiseEvent(dueDateExpiredEvent);

  }

  /**
   * The getVerificationItemName utility method reads the verification item
   * name.
   *
   * @param verificationItemUtilizationKey
   * Contains the Verification Item Utilization ID.
   *
   * @return The verification item name.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  protected VerificationItemNameDetails getVerificationItemName(
    VerificationItemUtilizationKey verificationItemUtilizationKey)
    throws AppException, InformationalException {

    final VerificationItemNameDetails verificationItemNameDetails = new VerificationItemNameDetails();
    // Read verification item name
    final VerificationItemUtilization verificationItemUtilizationObj = VerificationItemUtilizationFactory.newInstance();

    final VerifiableDataItem verifiableDataItemObj = VerifiableDataItemFactory.newInstance();

    VerificationItemUtilizationDtls verificationItemUtilizationDtls = new VerificationItemUtilizationDtls();

    verificationItemUtilizationDtls = verificationItemUtilizationObj.read(
      verificationItemUtilizationKey);

    final VerifiableDataItemKey verifiableDataItemKey = new VerifiableDataItemKey();

    verifiableDataItemKey.verifiableDataItemID = verificationItemUtilizationDtls.verifiableDataItemID;

    // code table variables
    final CodeTable codeTableInterface = CodeTableFactory.newInstance();
    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    ctitemKey.code = verifiableDataItemObj.readNameByID(verifiableDataItemKey).name;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = VERIFIABLEITEMNAME.TABLENAME;
    // BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    // END, CR00163098, JC

    verificationItemNameDetails.name = ctitem.description;

    return verificationItemNameDetails;
  }

  /**
   * The sendWarningNotification method sends the notification when warning date
   * of verification item is reached.
   *
   * @param verificationItemUtilizationKey
   * Contains the Verification Item Utilization ID.
   * @param verificationItemProvidedKey
   * Contains the Verification Item Provided ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void sendWarningNotification(
    VerificationItemUtilizationKey verificationItemUtilizationKey,
    VerificationItemProvidedKey verificationItemProvidedKey)
    throws AppException, InformationalException {

    // Get the evidence DescriptorID
    final VerificationItemProvided verificationItemProvidedObj = VerificationItemProvidedFactory.newInstance();
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    EvidenceDescriptorDetails evidenceDescriptorDetails = new EvidenceDescriptorDetails();
    final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();
    EvidenceDescriptorDtls evidenceDescriptorDtls;

    // BEGIN, CR00017999, KY
    // CaseHeader variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    // END, CR00017999

    evidenceDescriptorDetails = verificationItemProvidedObj.readEvidenceDescriptorIDByItemProvidedKey(
      verificationItemProvidedKey);

    evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDetails.evidenceDescriptorID;
    evidenceDescriptorDtls = evidenceDescriptorObj.read(evidenceDescriptorKey);

    // BEGIN, CR00017999, KY
    caseSearchKey.caseID = evidenceDescriptorDtls.caseID;
    // END, CR00017999

    // Get Verification item name
    final VerificationItemNameDetails verificationItemNameDetails = getVerificationItemName(
      verificationItemUtilizationKey);

    // Get the expiry date
    final Date expiryDate = getExpiryDate(verificationItemUtilizationKey,
      verificationItemProvidedKey);

    final LocalisableString communicationSubject = new LocalisableString(
      VERIFICATIONITEMUTILIZATIONWORKFLOW.INF_VERIFICATION_ITEM_UTILIZATION_WORKFLOW_COMMUNICATION__WARNING_SUBJECT);

    communicationSubject.arg(verificationItemNameDetails.name);
    communicationSubject.arg(expiryDate);

    final LocalisableString communicationText = new LocalisableString(
      VERIFICATIONITEMUTILIZATIONWORKFLOW.INF_VERIFICATION_ITEM_UTILIZATION_WORKFLOW_COMMUNICATION_WARNING_TEXT);

    // BEGIN, CR00017999, KY
    communicationText.arg(
      caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference);
    // END, CR00017999
    communicationText.arg(expiryDate.toString());

    sendNotification(verificationItemProvidedKey, communicationSubject,
      communicationText);
    // warningDateReached(verificationItemProvidedKey);
  }
}
