/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2006, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.verification.sl.infrastructure.entity.impl;


import curam.codetable.CASESTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.VERIFICATIONTYPE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorIDRelatedIDAndEvidenceType;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.ReadStatusCodeDetails;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.SecurityResult;
import curam.core.struct.UsersKey;
import curam.message.ENTVERIFICATIONITEMPROVISION;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.verification.sl.entity.fact.VerificationItemUtilizationFactory;
import curam.verification.sl.entity.intf.VerificationItemUtilization;
import curam.verification.sl.entity.struct.SecurityDetails;
import curam.verification.sl.entity.struct.VerificationItemUtilizationKey;
import curam.verification.sl.infrastructure.entity.fact.VDIEDLinkFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationItemProvidedFactory;
import curam.verification.sl.infrastructure.entity.intf.VDIEDLink;
import curam.verification.sl.infrastructure.entity.struct.CancelVerificationItemProvidedDtls;
import curam.verification.sl.infrastructure.entity.struct.EvidenceDescriptorDetails;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtlsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemUtilizationIDDetails;
import curam.verification.sl.infrastructure.fact.VerificationControllerFactory;
import curam.verification.sl.infrastructure.intf.VerificationController;


/**
 * The VerificationItemProvided class provides a number of methods to declare that
 * a item of verification has been presented or undertaken in order to confirm
 * the accuracy of the data entered and to display the details of a verification
 * item that has been provided in respect of a particular verification.
 */

public abstract class VerificationItemProvided extends curam.verification.sl.infrastructure.entity.base.VerificationItemProvided {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the logical delete
   *
   * @param key Verification Item Provided identifier
   * @param cancelVerificationItemProvidedDtls Verification Item Provided  details
   */
  protected void precancel(VerificationItemProvidedKey key,
    CancelVerificationItemProvidedDtls cancelVerificationItemProvidedDtls)
    throws AppException, InformationalException {

    curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided verificationItemProvided = VerificationItemProvidedFactory.newInstance();

    verificationItemProvided.validateCancel(cancelVerificationItemProvidedDtls);

    cancelVerificationItemProvidedDtls.recordStatus = RECORDSTATUS.CANCELLED;

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details Verification Item Provided  details
   */
  protected void preinsert(VerificationItemProvidedDtls details)
    throws AppException, InformationalException {
    validateInsert(details);
    validateDetails(details);

  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification Item Provided details before the logical delete
   *
   *
   * @param details Verification Item Provided details
   */
  public void validateCancel(CancelVerificationItemProvidedDtls details)
    throws AppException, InformationalException {

    curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided verificationItemProvided = curam.verification.sl.infrastructure.entity.fact.VerificationItemProvidedFactory.newInstance();

    EvidenceDescriptor evidenceDescriptor = EvidenceDescriptorFactory.newInstance();
    VerificationItemProvidedKey verificationItemProvidedKey = new VerificationItemProvidedKey();

    ReadStatusCodeDetails readStatusCodeDetails = new ReadStatusCodeDetails();
    EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    verificationItemProvidedKey.verificationItemProvidedID = details.verificationItemProvidedID;

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    verificationItemProvidedKey.verificationItemProvidedID = details.verificationItemProvidedID;

    VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();

    vDIEDLinkKey.VDIEDLinkID = verificationItemProvided.readVDIEDLinkID(verificationItemProvidedKey).VDIEDLinkID;

    // BEGIN, CR00075820, POH
    VDIEDLink vDIEDLinkObj = VDIEDLinkFactory.newInstance();

    // read details from related evidence descriptor
    EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType = vDIEDLinkObj.readEDIDRelatedIDAndEvidenceTypeByVDIEDLinkID(
      vDIEDLinkKey);

    // Indicator used to indicate if dealing with participant evidence
    boolean isNonCaseEDForParticipantEvidence = false;

    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    // determine if verification item provided is being created for participant
    // level evidence
    isNonCaseEDForParticipantEvidence = evidenceControllerObj.isNonCaseEDForParticipantEvidence(
      evidenceDescriptorIDRelatedIDAndEvidenceType);

    // Only perform below validation if verification item provided is being
    // created for a verification on a integrated case or product delivery
    if (!isNonCaseEDForParticipantEvidence) {

      curam.verification.sl.infrastructure.entity.intf.Verification verificationObj = VerificationFactory.newInstance();
      VerificationDtlsList verificationDtlsList = new VerificationDtlsList();

      // BEGIN, CR00074026, BF
      // The caseID no longer exists on the verification entity. Instead it
      // has been replaced with verificationLinkedID and verificationLinkedType.
      // Read verification dtls list to get Case ID (verificationLinkedID)
      verificationDtlsList = verificationObj.readByVDIEDLinkID(vDIEDLinkKey);

      CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      CaseStatusCode caseStatusCode = new CaseStatusCode();
      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
      boolean allCaseClosed = true;

      // Iterate to check Case Status
      for (int j = 0; j < verificationDtlsList.dtls.size(); j++) {

        // Read for linked type of caseID and check the status
        // BEGIN, CR00349499, ARM  
        if (!verificationDtlsList.dtls.item(j).verificationLinkedType.equals(
          VERIFICATIONTYPE.NONCASEDATA)) {
          // END, CR00349499 
          // read based on the linkedID
          caseHeaderKey.caseID = verificationDtlsList.dtls.item(j).verificationLinkedID;
          caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

          if (!caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {

            allCaseClosed = false;
            break;
          }
        }
      }
      // END,  CR00074026
      // If case is closed throw exception
      if (allCaseClosed) {

        AppException appException = new AppException(
          ENTVERIFICATIONITEMPROVISION.ERR_VERIFICATIONITEMPROVISION_FV_ITEM_REMOVE_CASE_CLOSED);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          appException, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }

    // This verification item has already been removed from this verification
    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.ENTVERIFICATIONITEMPROVISION.ERR_VERIFICATIONITEMPROVISION_XRV_ASSOCIATED_REMOVED_VERIFICATION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // you may not remove the item from this verification as the evidence
    // associated with it is no longer in use
    EvidenceDescriptorDetails evidenceDescriptorDetails = new  EvidenceDescriptorDetails();

    evidenceDescriptorDetails = verificationItemProvided.readEvidenceDescriptorIDByItemProvidedKey(
      verificationItemProvidedKey);
    evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDetails.evidenceDescriptorID;
    readStatusCodeDetails = evidenceDescriptor.readStatusCode(
      evidenceDescriptorKey);

    if ((readStatusCodeDetails.statusCode.equals(
      curam.codetable.EVIDENCEDESCRIPTORSTATUS.CANCELED))
        || (readStatusCodeDetails.statusCode.equals(
          curam.codetable.EVIDENCEDESCRIPTORSTATUS.SUPERSEDED))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.ENTVERIFICATIONITEMPROVISION.ERR_VERIFICATIONITEMPROVISION_XRV_ASSOCIATED_EVIDENCE_REMOVED_VERIFICATION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // you do not have the appropriate privileges to remove this item from this
    // verification
    VerificationItemUtilizationIDDetails verificationItemUtilizationIDDetails = new VerificationItemUtilizationIDDetails();

    verificationItemUtilizationIDDetails = verificationItemProvided.readUtilizationID(
      verificationItemProvidedKey);
    VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();
    VerificationItemUtilizationKey verificationItemUtilizationKey = new VerificationItemUtilizationKey();

    verificationItemUtilizationKey.verificationItemUtilizationID = verificationItemUtilizationIDDetails.verificationItemUtilizationID;
    SecurityDetails securityDetails = verificationItemUtilization.readSecurityDetails(
      verificationItemUtilizationKey);

    SecurityResult securityResult = new SecurityResult();
    UsersKey userKey = new UsersKey();

    userKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    if (securityDetails.removeSID.length() != 0) {

      securityResult.result = curam.util.security.Authorisation.isSIDAuthorised(
        securityDetails.removeSID, userKey.userName);
      // if the result is false, it means the user does not have access to
      // this case
      if (!securityResult.result) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.ENTVERIFICATIONITEMPROVISION.ERR_VERIFICATIONITEMPROVISION_FV_NO_APPROPRIATE_PRIVILEGES_TO_REMOVE_ITEM),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }

  // ___________________________________________________________________________
  /**
   * Performs the validations common to all operations
   *
   * @param details Verification Item Provided details
   */
  public void validateDetails(VerificationItemProvidedDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification Item Provided details before the data insertion
   *
   * @param details Verification Item Provided details
   */
  public void validateInsert(VerificationItemProvidedDtls details)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    VDIEDLink vDIEDLinkObj = VDIEDLinkFactory.newInstance();

    EvidenceDescriptor evidenceDescriptor = EvidenceDescriptorFactory.newInstance();
    VerificationItemProvidedKey verificationItemProvidedKey = new VerificationItemProvidedKey();
    VDIEDLinkKey vDIEDLinkKey = new VDIEDLinkKey();

    vDIEDLinkKey.VDIEDLinkID = details.VDIEDLinkID;
    ReadStatusCodeDetails readStatusCodeDetails = new ReadStatusCodeDetails();
    EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    // BEGIN, CR00075820, POH
    // read details from related evidence descriptor
    EvidenceDescriptorIDRelatedIDAndEvidenceType evidenceDescriptorIDRelatedIDAndEvidenceType = vDIEDLinkObj.readEDIDRelatedIDAndEvidenceTypeByVDIEDLinkID(
      vDIEDLinkKey);

    // Indicator used to indicate if dealing with participant evidence
    boolean isNonCaseEDForParticipantEvidence = false;

    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    // determine if verification item provided is being created for participant
    // level evidence
    isNonCaseEDForParticipantEvidence = evidenceControllerObj.isNonCaseEDForParticipantEvidence(
      evidenceDescriptorIDRelatedIDAndEvidenceType);
    // BEGIN, CR00358503, AKr
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = evidenceDescriptorIDRelatedIDAndEvidenceType.evidenceType;
    final boolean isPDCEvidence = evidenceControllerObj.isPDCEvidence(
      evidenceTypeKey);
   
    // Only perform below validation if verification item provided is being
    // created for a verification on a integrated case or product delivery
    if (!isNonCaseEDForParticipantEvidence && !isPDCEvidence) {
      // END, CR00358503
    
      // BEGIN, HARPNO 61318, PL
      curam.verification.sl.infrastructure.entity.intf.Verification verificationObj = VerificationFactory.newInstance();
      VerificationDtlsList verificationDtlsList = new VerificationDtlsList();

      // Read verification dtls list to get Case ID
      verificationDtlsList = verificationObj.readByVDIEDLinkID(vDIEDLinkKey);

      CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      CaseStatusCode caseStatusCode = new CaseStatusCode();
      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
      boolean allCaseClosed = true;

      // BEGIN, CR00074026, BF
      // The caseID no longer exists on the verification entity. Instead it
      // has been replaced with verificationLinkedID and verificationLinkedType.
      // Iterate to check Case Status
      for (int j = 0; j < verificationDtlsList.dtls.size(); j++) {

        // Read the linkedType to check for case type. This verificaitonLinkedType
        // can refer to either product delivery, IC or participant.
        // Read for linked type of type case and check the status
        // BEGIN, CR00349499, ARM  
        if (!verificationDtlsList.dtls.item(j).verificationLinkedType.equals(
          VERIFICATIONTYPE.NONCASEDATA)) {
          // END, CR00349499          
          // read based on the linkedID
          caseHeaderKey.caseID = verificationDtlsList.dtls.item(j).verificationLinkedID;
          caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

          if (!caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {

            allCaseClosed = false;
            break;
          }
        }
      }
      // END,  CR00074026

      // If case is closed throw exception
      if (allCaseClosed) {

        AppException appException = new AppException(
          ENTVERIFICATIONITEMPROVISION.ERR_VERIFICATIONITEMPROVISION_FV_CASE_CLOSED);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          appException, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }
    // END, CR00075820

    verificationItemProvidedKey.verificationItemProvidedID = details.verificationItemProvidedID;

    // The evidence associated with the verification must not be
    // cancelled or superseded
    EvidenceDescriptorDetails evidenceDescriptorDetails = new  EvidenceDescriptorDetails();

    evidenceDescriptorDetails = vDIEDLinkObj.readEvidenceDescriptorIDByVDIEDLink(
      vDIEDLinkKey);

    evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDetails.evidenceDescriptorID;
    readStatusCodeDetails = evidenceDescriptor.readStatusCode(
      evidenceDescriptorKey);

    if ((readStatusCodeDetails.statusCode.equals(
      curam.codetable.EVIDENCEDESCRIPTORSTATUS.CANCELED))
        || (readStatusCodeDetails.statusCode.equals(
          curam.codetable.EVIDENCEDESCRIPTORSTATUS.SUPERSEDED))) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.ENTVERIFICATIONITEMPROVISION.ERR_VERIFICATIONITEMPROVISION_FV_EVIDENCE_NO_LONGER_USE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // The Date received cannot be later than the current business date
    if (!details.dateReceived.isZero()) {

      if (details.dateReceived.after(curam.util.type.Date.getCurrentDate())) {

        AppException appException = new AppException(
          ENTVERIFICATIONITEMPROVISION.ERR_VERIFICATIONITEMPROVISION_FV_DATE_RECEIVED_NOT_LATER_THAN_CURRENT_DATE);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          appException, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175
    
  }
  
}
