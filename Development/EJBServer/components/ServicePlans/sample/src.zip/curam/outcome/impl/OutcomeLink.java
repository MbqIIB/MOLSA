/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.outcome.impl;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.OUTCOMELINKTYPEEntry;
import curam.serviceplans.sl.entity.struct.RelatedReferenceKey;
import curam.serviceplans.sl.struct.OutcomeKey;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockRemovable;

/**
 * The Outcome Link provides link between expected outcomes and related
 * references. A related reference can be any business entity like Service
 * Offering, Planned Item etc., which associates with Outcome.
 */
@ImplementedBy(OutcomeLinkImpl.class)
public interface OutcomeLink extends Insertable, OptimisticLockRemovable,
    OutcomeLinkAccessor {

  /**
   * Sets the outcome for the Outcome Link.
   * 
   * @param outcomeKey
   *          Contains the outcome ID.
   */
  void setOutcome(OutcomeKey outcomeKey);

  /**
   * Sets the related reference for the Outcome Link.
   * 
   * @param relatedReferenceKey
   *          Contains related reference ID.
   */
  void setRelatedReference(RelatedReferenceKey relatedReferenceKey);

  /**
   * Sets the related type for the Outcome Link.
   * 
   * @param relatedType
   *          Contains related type code.
   */
  void setRelatedType(OUTCOMELINKTYPEEntry relatedType);
}
