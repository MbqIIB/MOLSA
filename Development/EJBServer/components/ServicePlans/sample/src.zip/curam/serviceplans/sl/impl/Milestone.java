/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;

import curam.codetable.MILESTONESTATUSCODE;
import curam.codetable.impl.LOCALEEntry;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.struct.MilestoneDeliveryAndConfigDetails;
import curam.core.sl.entity.struct.MilestoneDeliveryAndConfigDetailsList;
import curam.core.sl.entity.struct.MilestoneDeliveryDetails;
import curam.core.sl.entity.struct.MilestoneDeliveryDtls;
import curam.core.sl.entity.struct.MilestoneDeliveryKey;
import curam.core.sl.fact.MilestoneDeliveryFactory;
import curam.core.sl.struct.CaseTypeAndCaseTypeID;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.message.BPOMILESTONE;
import curam.message.BPOSERVICEPLANDELIVERY;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.GENERALCASE;
import curam.serviceplans.sl.entity.fact.SPMilestoneDeliveryLinkFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.struct.CaseIDAndMilestoneStatus;
import curam.serviceplans.sl.entity.struct.SPMilestoneAndLinkDtls;
import curam.serviceplans.sl.entity.struct.SPMilestoneDeliveryLinkDtls;
import curam.serviceplans.sl.entity.struct.SPMilestoneDeliveryLinkKey;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.MilestoneConfigIDNameAndTypeList;
import curam.serviceplans.sl.struct.MilestoneDeliveryDetailsList;
import curam.serviceplans.sl.struct.PlannedGroupKey;
import curam.serviceplans.sl.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.struct.SPMilestoneDeliveryDetails;
import curam.serviceplans.sl.struct.SPMilestoneReadDeliveryDetails;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;


public abstract class Milestone extends curam.serviceplans.sl.base.Milestone {

  // BEGIN, CR00236426, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public Milestone() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00236426
  // ___________________________________________________________________________
  /**
   * This method creates a milestone delivery for a service plan,
   * plan group or sub goal
   *
   * @param details the service plan milestone delivery details
   */
  public void create(SPMilestoneDeliveryDetails details)
    throws AppException, InformationalException {

    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = details.spMilestoneDetails.dtls.caseID;

    // Check the service plan security
    securityCheckMaintain(servicePlanDeliveryKey);

    MilestoneDeliveryKey milestoneDeliveryKey = new MilestoneDeliveryKey();

    // Insert the generic milestone details
    milestoneDeliveryKey = MilestoneDeliveryFactory.newInstance().create(
      details.spMilestoneDetails);

    // Set the milestone delivery id
    details.linkDtls.milestoneDeliveryID = milestoneDeliveryKey.milestoneDeliveryID;

    // Insert the service plan milestone delivery link
    // (service plan specific details)
    SPMilestoneDeliveryLinkFactory.newInstance().insert(details.linkDtls);

  }

  // ___________________________________________________________________________
  /**
   * This method lists all milestones at service plan, plan group and sub goal
   * levels with a status of Not Started, In Progress and Completed.
   *
   * @param key the unique identifier of the service plan
   *
   * @return the list of milestone deliveries for the specified service plan
   */
  public MilestoneDeliveryDetailsList listAllMilestoneDeliveriesForServicePlan(
    CaseHeaderKey key)
    throws AppException, InformationalException {

    // Return Struct
    MilestoneDeliveryDetailsList milestoneDeliveryDetailsList = new MilestoneDeliveryDetailsList();

    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = key.caseID;

    // Check the service plan security
    securityCheckRead(servicePlanDeliveryKey);

    // Get the list of all milestone deliveries
    milestoneDeliveryDetailsList.spMilestoneDetailsList = MilestoneDeliveryFactory.newInstance().listAllMilestoneDeliveries(
      key);

    return milestoneDeliveryDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method lists all milestones that have been configured
   * for the specified service plan type
   *
   * @param key the unique identifier of the service plan
   *
   * @return the list of milestones configured for the specified service plan
   */
  public MilestoneConfigIDNameAndTypeList listMilestoneConfigsForServicePlanType(
    CaseHeaderKey key)
    throws AppException, InformationalException {

    // Return struct
    MilestoneConfigIDNameAndTypeList milestoneConfigIDNameAndTypeList = new MilestoneConfigIDNameAndTypeList();

    CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = key.caseID;

    // Set the caseType and caseTypeID
    CaseTypeAndCaseTypeID caseTypeAndCaseTypeID = new CaseTypeAndCaseTypeID();

    // Read the case type code
    caseTypeAndCaseTypeID.dtls.caseType = CaseHeaderFactory.newInstance().readCaseTypeCode(caseKey).caseTypeCode;

    // Read the service plan id
    caseTypeAndCaseTypeID.dtls.caseTypeID = ServicePlanDeliveryFactory.newInstance().readServicePlanID(servicePlanDeliveryKey).servicePlanID;

    // Get the list of available milestones
    milestoneConfigIDNameAndTypeList.dtlsList = MilestoneDeliveryFactory.newInstance().listMilestonesForCaseType(
      caseTypeAndCaseTypeID);

    // If no milestones are configured,
    // send back an informational to the client
    if (milestoneConfigIDNameAndTypeList.dtlsList.dtlsList.dtls.size() == 0) {

      curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

      AppException e = new AppException(
        BPOMILESTONE.INF_NO_MILESTONES_CONFIGURED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    return milestoneConfigIDNameAndTypeList;
  }

  // ___________________________________________________________________________
  /**
   * This method lists milestones at service plan level with a status of
   * Not Started or In Progress.
   *
   * @param key the unique identifier of the service plan
   *
   * @return the list of milestone deliveries
   */
  public MilestoneDeliveryDetailsList listUncompletedMilestonesForServicePlan(
    CaseHeaderKey key)
    throws AppException, InformationalException {

    // Return struct
    MilestoneDeliveryDetailsList milestoneDeliveryDetailsList = new MilestoneDeliveryDetailsList();

    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = key.caseID;

    // Check the service plan security
    securityCheckRead(servicePlanDeliveryKey);

    CaseIDAndMilestoneStatus caseIDAndMilestoneStatus = new CaseIDAndMilestoneStatus();

    caseIDAndMilestoneStatus.caseID = key.caseID;
    // Need milestones with status of NOT 'Completed'
    caseIDAndMilestoneStatus.status = MILESTONESTATUSCODE.COMPLETED;

    // BEGIN, CR00236426, GP
    // Get the list of uncompleted milestone deliveries.
    MilestoneDeliveryDetails milestoneDeliveryDetails = new
      MilestoneDeliveryDetails();
    MilestoneDeliveryAndConfigDetailsList milestoneDeliveryAndConfigDetailsList = SPMilestoneDeliveryLinkFactory.newInstance().searchUncompletedMilestonesForServicePlan1(
      caseIDAndMilestoneStatus);

    for (MilestoneDeliveryAndConfigDetails milestoneDeliveryAndConfigDetails :
      milestoneDeliveryAndConfigDetailsList.dtls.items()) {

      milestoneDeliveryDetails = new MilestoneDeliveryDetails();
      milestoneDeliveryDetails.assign(milestoneDeliveryAndConfigDetails);

      // Read the localized name.
      if (0 != milestoneDeliveryAndConfigDetails.nameTextID) {

        LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          milestoneDeliveryAndConfigDetails.nameTextID);

        milestoneDeliveryDetails.name = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
      // Read the localized type.
      if (0 != milestoneDeliveryAndConfigDetails.typeTextID) {

        LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          milestoneDeliveryAndConfigDetails.typeTextID);

        milestoneDeliveryDetails.type = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }

      milestoneDeliveryDetailsList.spMilestoneDetailsList.dtlsList.dtls.add(
        milestoneDeliveryDetails);
    }
    // END, CR00236426

    return milestoneDeliveryDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to modify the service plan milestone delivery details
   *
   * @param details The modified milestone delivery details.
   */
  public void modify(SPMilestoneDeliveryDetails details)
    throws AppException, InformationalException {

    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = details.spMilestoneDetails.dtls.caseID;

    // Check the service plan security
    securityCheckMaintain(servicePlanDeliveryKey);
    MilestoneDeliveryKey milestoneDeliveryKey = new MilestoneDeliveryKey();

    milestoneDeliveryKey.milestoneDeliveryID = details.spMilestoneDetails.dtls.milestoneDeliveryID;
    MilestoneDeliveryDtls readMilestoneDeliveryDetails = curam.core.sl.entity.fact.MilestoneDeliveryFactory.newInstance().read(
      milestoneDeliveryKey);

    details.spMilestoneDetails.dtls.createdBySystem = readMilestoneDeliveryDetails.createdBySystem;
    details.spMilestoneDetails.dtls.relatedID = readMilestoneDeliveryDetails.relatedID;

    // Modify the milestone details
    MilestoneDeliveryFactory.newInstance().modify(details.spMilestoneDetails);
  }

  // ___________________________________________________________________________
  /**
   * This method is used to read the service plan milestone delivery details.
   *
   * @param key The unique identifier of the milestone delivery.
   *
   * @return The milestone delivery details.
   */
  public SPMilestoneReadDeliveryDetails read(MilestoneDeliveryKey key)
    throws AppException, InformationalException {

    // Return struct
    SPMilestoneReadDeliveryDetails spMilestoneReadDeliveryDetails = new SPMilestoneReadDeliveryDetails();

    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    // Read the milestone delivery details
    spMilestoneReadDeliveryDetails.readDetails = MilestoneDeliveryFactory.newInstance().read(
      key);

    servicePlanDeliveryKey.caseID = spMilestoneReadDeliveryDetails.readDetails.readDetails.caseID;

    // Check the service plan security
    securityCheckRead(servicePlanDeliveryKey);

    return spMilestoneReadDeliveryDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to remove a milestone delivery from a service plan.
   *
   * @param key The unique identifier of the milestone delivery.
   */
  public void remove(MilestoneDeliveryKey key)
    throws AppException, InformationalException {

    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    // Read the case id for the milestone
    servicePlanDeliveryKey.caseID = curam.core.sl.entity.fact.MilestoneDeliveryFactory.newInstance().readCaseID(key).caseID;

    // Check the service plan security
    securityCheckMaintain(servicePlanDeliveryKey);

    // Read back the service plan link record
    SPMilestoneDeliveryLinkKey spMilestoneDeliveryLinkKey = SPMilestoneDeliveryLinkFactory.newInstance().readSPMSDelLinkIDByMSDelID(
      key);

    // Remove the link record
    SPMilestoneDeliveryLinkFactory.newInstance().remove(
      spMilestoneDeliveryLinkKey);

    // Remove the generic milestone details
    MilestoneDeliveryFactory.newInstance().remove(key);
  }

  // BEGIN, CR00056110, PMD
  /**
   * Checks that the user is allowed to maintain the service plan.
   *
   * @param key
   * ID of the service plan that is being checked.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link BPOSERVICEPLANSECURITY#ERR_MAINTAIN_SECURITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to
   * maintain this service plan.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have maintenance rights for this case. Please contact
   * your security administrator.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   */
  @Override
  protected void securityCheckMaintain(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // get plan participant ID
    caseHeaderKey.caseID = key.caseID;
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID;

    // BEGIN, CR00227859, PM
    // Security variables
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // Get the service plan id
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = ServicePlanDeliveryFactory.newInstance().read(key).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOSERVICEPLANSECURITY.ERR_MAINTAIN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        // user-participant item sensitivity check failed
        throw new AppException(
          BPOSERVICEPLANSECURITY.ERR_MAINTAIN_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

  }

  /**
   * Checks that the user is allowed to view the service plan.
   *
   * @param key
   * ID of the service plan that is being checked.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_VIEW_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this service plan.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have maintenance rights for this case. Please contact
   * your security administrator.
   * @throws AppException
   * {@link BPOSERVICEPLANDELIVERY#ERR_VIEW_SECURITY_CHECK_FAILED} -
   * if the user does not have the appropriate privileges to view this
   * service plan.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   */
  @Override
  protected void securityCheckRead(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // get plan participant ID
    caseHeaderKey.caseID = key.caseID;
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = CaseHeaderFactory.newInstance().readParticipantRoleID(caseHeaderKey).concernRoleID;

    // BEGIN, CR00227859, PM
    // Security variables
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Get the service plan id
    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = ServicePlanDeliveryFactory.newInstance().read(key).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_VIEW_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        // user-participant item sensitivity check failed
        throw new AppException(
          BPOSERVICEPLANDELIVERY.ERR_VIEW_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
  }

  // END, CR00056110

  // BEGIN, CR00057087, PMD
  // ___________________________________________________________________________
  /**
   * Clones milestone details
   *
   * @param details milestone and service plan link details
   * that are to be cloned
   *
   * @param newPlannedGroupID newly created planned group identifier,
   * this will be populated if the milestone was created at planned group level
   * @param newPlannedSubGoalID newly created sub-goal identifier
   * this will be populated if the milestone was created at sub-goal level
   * If neither are populated then the milestone
   * was created at service plan level
   */
  public void clone(
    SPMilestoneAndLinkDtls details, PlannedGroupKey newPlannedGroupID,
    PlannedSubGoalKey newPlannedSubGoalID)
    throws AppException, InformationalException {

    MilestoneDeliveryDtls milestoneDeliveryDtls = new MilestoneDeliveryDtls();

    // create new milestone details
    milestoneDeliveryDtls.milestoneConfigurationID = details.milestoneConfigurationID;
    milestoneDeliveryDtls.caseID = details.caseID;
    milestoneDeliveryDtls.ownerUserName = details.ownerUserName;
    milestoneDeliveryDtls.expectedStartDate = details.expectedStartDate;
    milestoneDeliveryDtls.expectedEndDate = details.expectedEndDate;
    milestoneDeliveryDtls.actualStartDate = details.actualStartDate;
    milestoneDeliveryDtls.actualEndDate = details.actualEndDate;
    milestoneDeliveryDtls.comments = details.comments;
    milestoneDeliveryDtls.status = details.status;

    // Insert the new milestone
    curam.core.sl.entity.fact.MilestoneDeliveryFactory.newInstance().insert(
      milestoneDeliveryDtls);

    // Create the new link details
    SPMilestoneDeliveryLinkDtls spMilestoneDeliveryLinkDtls = new SPMilestoneDeliveryLinkDtls();

    spMilestoneDeliveryLinkDtls.milestoneDeliveryID = milestoneDeliveryDtls.milestoneDeliveryID;

    spMilestoneDeliveryLinkDtls.plannedGroupID = newPlannedGroupID.key.plannedGroupID;
    spMilestoneDeliveryLinkDtls.plannedSubGoalID = newPlannedSubGoalID.key.plannedSubGoalID;

    // Insert the new SPMilestoneDeliveryLink details
    SPMilestoneDeliveryLinkFactory.newInstance().insert(
      spMilestoneDeliveryLinkDtls);

  }
  // END, CR00057087
}
