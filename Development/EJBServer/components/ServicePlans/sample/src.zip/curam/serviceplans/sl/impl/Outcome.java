/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;

import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.message.BPOOUTCOME;
import curam.message.GENERAL;
import curam.message.impl.BPOOUTCOMEExceptionCreator;
import curam.outcome.impl.OutcomeLink;
import curam.outcome.impl.OutcomeLinkDAO;
import curam.serviceplans.sl.entity.struct.OutcomeDescriptionTextID;
import curam.serviceplans.sl.entity.struct.OutcomeDtls;
import curam.serviceplans.sl.struct.CancelOutcomeDetails;
import curam.serviceplans.sl.struct.CreateOutcomeDetails;
import curam.serviceplans.sl.struct.ModifyOutcomeDetails;
import curam.serviceplans.sl.struct.OutcomeDtlsList;
import curam.serviceplans.sl.struct.OutcomeKey;
import curam.serviceplans.sl.struct.OutcomeList;
import curam.serviceplans.sl.struct.OutcomeNameDetails;
import curam.serviceplans.sl.struct.ReadOutcomeDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.workspaceservices.localization.fact.TextTranslationFactory;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.intf.TextTranslation;
import curam.workspaceservices.localization.struct.LocalizableTextTranslationDetails;
import curam.workspaceservices.localization.struct.SearchByLocalizableTextIDKey;
import curam.workspaceservices.localization.struct.TextTranslationDtls;
import curam.workspaceservices.localization.struct.TextTranslationDtlsList;


/**
 * This process class provides the functionality for the Outcome service layer.
 *
 */
public abstract class Outcome extends curam.serviceplans.sl.base.Outcome {

  // BEGIN, CR00158401, SG
  /**
   * Reference to outcomeLink DAO.
   */
  @Inject
  private OutcomeLinkDAO outcomeLinkDAO;

  // BEGIN, CR00234442, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;
  // END, CR00234442

  /**
   * Constructor for the class.
   */
  public Outcome() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00158401

  /**
   * Creates an Outcome with input details.
   *
   * @param details
   * The details of the Outcome to be created.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void create(CreateOutcomeDetails details) throws AppException,
      InformationalException {

    // Outcome entity and details
    curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();
    curam.serviceplans.sl.entity.struct.OutcomeDtls outcomeDtls = new curam.serviceplans.sl.entity.struct.OutcomeDtls();

    // assign outcome details
    outcomeDtls.assign(details.createOutcomeDetails);

    // set creation date
    outcomeDtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // set record status
    outcomeDtls.recordStatus = RECORDSTATUS.NORMAL;

    // BEGIN, CR00234442, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!outcomeDtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(outcomeDtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      outcomeDtls.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      outcomeDtls.descriptionTextID = localizableTextHandler.store();
    }

    outcomeDtls.description = null;
    // END, CR00234442

    // insert outcome
    outcomeObj.insert(outcomeDtls);

  }

  /**
   * Modifies the existing Outcome with input details.
   *
   * @param details
   * The details of the Outcome to be modified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOOUTCOME#ERR_OUTCOME_CANCELED
   * ERR_OUTCOME_CANCELED}- if the Outcome to be modified
   * is already canceled.
   */
  public void modify(ModifyOutcomeDetails details) throws AppException,
      InformationalException {

    // Outcome entity and manipulation variables
    curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();
    curam.serviceplans.sl.entity.struct.OutcomeKey outcomeKey = new curam.serviceplans.sl.entity.struct.OutcomeKey();
    curam.serviceplans.sl.entity.struct.OutcomeDtls outcomeDtls = new curam.serviceplans.sl.entity.struct.OutcomeDtls();

    // set outcome key
    outcomeKey.outcomeID = details.outcomeDtls.outcomeID;

    // BEGIN, CR00234442, GP
    // Check if Outcome is already canceled.
    outcomeDtls = outcomeObj.read(outcomeKey);

    if (outcomeDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOOUTCOME.ERR_OUTCOME_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // set outcome details
    outcomeDtls.assign(details.outcomeDtls);

    // Modify localized description.
    long descriptionTextID;

    // Modify Localized description.
    if (0 == outcomeDtls.descriptionTextID) {

      if (!outcomeDtls.description.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(outcomeDtls.description,
          LOCALEEntry.get(
          (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
        descriptionTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        descriptionTextID = localizableTextHandler.store();
      }
      // Update the struct passed to modify().
      outcomeDtls.descriptionTextID = descriptionTextID;

    } else {

      // Handling New data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        outcomeDtls.descriptionTextID);

      localizableTextHandler.addValue(outcomeDtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      localizableTextHandler.store();

    }

    outcomeDtls.description = null;
    // END, CR00234442

    // modify outcome
    outcomeObj.modify(outcomeKey, outcomeDtls);

  }

  /**
   * Cancels the specified Outcome.
   *
   * @param details
   * The details of the Outcome to be canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancel(CancelOutcomeDetails details) throws AppException,
      InformationalException {

    // Outcome entity and manipulation variables
    curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();
    curam.serviceplans.sl.entity.struct.OutcomeKey outcomeKey = new curam.serviceplans.sl.entity.struct.OutcomeKey();
    curam.serviceplans.sl.entity.struct.OutcomeCancelDetails outcomeCancelDetails = new curam.serviceplans.sl.entity.struct.OutcomeCancelDetails();

    // set the key
    outcomeKey.outcomeID = details.outcomeID;

    // set cancellation details
    outcomeCancelDetails.recordStatus = RECORDSTATUS.CANCELLED;
    outcomeCancelDetails.versionNo = details.versionNo;

    // BEGIN, CR00158401, SG
    // Search the related references for this outcome. If at least one reference
    // exists, throw the exception.
    for (final OutcomeLink outcomeLink : outcomeLinkDAO.searchByOutcome(
      outcomeKey)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOOUTCOMEExceptionCreator.ERR_OUTCOME_XRV_ASSIGNED_TO_REFERENCE(
          outcomeLink.getRelatedType().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      ValidationHelper.failIfErrorsExist();
    }
    // END, CR00158401

    // cancel outcome
    outcomeObj.cancel(outcomeKey, outcomeCancelDetails);

  }

  /**
   * Reads the specified Outcome details.
   *
   * @param key
   * The Outcome unique identifier.
   *
   * @return The Outcome details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReadOutcomeDetails read(OutcomeKey key) throws AppException,
      InformationalException {

    // Outcome entity and key
    curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();
    curam.serviceplans.sl.entity.struct.OutcomeKey outcomeKey = new curam.serviceplans.sl.entity.struct.OutcomeKey();

    // return value
    ReadOutcomeDetails readOutcomeDetails = new ReadOutcomeDetails();

    outcomeKey.outcomeID = key.key.outcomeID;

    // read outcome
    readOutcomeDetails.outcomeDtls = outcomeObj.read(outcomeKey);

    // BEGIN, CR00234442, GP
    // Read the localized description.
    if (0 != readOutcomeDetails.outcomeDtls.descriptionTextID) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        readOutcomeDetails.outcomeDtls.descriptionTextID);

      readOutcomeDetails.outcomeDtls.description = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00234442

    // return outcome details
    return readOutcomeDetails;
  }

  // BEGIN, CR00218024, CSH
  // ___________________________________________________________________________
  /**
   * @return Outcome details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated since v6.0 - replaced by {@link #listOutcomeDetails()}
   * This method has been deprecated to introduce new user interface
   * enhancements. See release note: CR00218024.
   *
   * Lists all the existing Outcomes.
   */
  @Deprecated
  public OutcomeList list() throws AppException, InformationalException {

    // return value
    OutcomeList outcomeList = new OutcomeList();

    // Outcome entity
    curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();

    // list outcomes
    outcomeList.outcomeDetailsList = outcomeObj.list();

    // return outcome list
    return outcomeList;
  }

  // BEGIN, CR00218024

  /**
   * Reads the Outcome name.
   *
   * @param key
   * Outcome unique identifier.
   *
   * @return Outcome name.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public OutcomeNameDetails readName(OutcomeKey key) throws AppException,
      InformationalException {

    // return value
    OutcomeNameDetails outcomeNameDetails = new OutcomeNameDetails();

    // Outcome entity manipulation variables
    curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();

    // read outcome name
    outcomeNameDetails.outcomeNameDetails = outcomeObj.readName(key.key);

    // return outcome name
    return outcomeNameDetails;

  }

  // BEGIN, CR00218024, CSH
  /**
   * Lists all the existing Outcomes.
   *
   * @return Outcome details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public OutcomeDtlsList listOutcomeDetails() throws AppException,
      InformationalException {

    // return value
    OutcomeDtlsList outcomeDtlsList = new OutcomeDtlsList();

    // Outcome entity
    curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();

    // list outcomes
    outcomeDtlsList.list = outcomeObj.readAll();

    // return outcome list
    return outcomeDtlsList;
  }

  // END, CR00218024

  // BEGIN, CR00234442, GP
  /**
   * Checks to ensure multiple text translations are not present for a single
   * locale. If it is, an error message is thrown.
   *
   * @param localizableTextHandler
   * The localizable text handler to store localizable text.
   *
   * @param locale
   * The locale for which localizable text will be entered.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - If
   * multiple text translation is present for the same locale.
   */
  protected void validateNoTranslationsForLocale(
    final LocalizableTextHandler localizableTextHandler, final String locale)
    throws AppException, InformationalException {

    TextTranslationDtlsList textTranslationDtlsList = new
      TextTranslationDtlsList();
    TextTranslation textTranslation = TextTranslationFactory.newInstance();
    SearchByLocalizableTextIDKey key = new SearchByLocalizableTextIDKey();

    key.localizableTextID = localizableTextHandler.getID();
    textTranslationDtlsList = textTranslation.searchByLocalizableTextID(key);

    for (TextTranslationDtls textTranslationDtls : textTranslationDtlsList.dtls.items()) {

      if (textTranslationDtls.localeCode.equals(locale)) {
        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(textTranslationDtls.localeCode);
        throw e;
      }
    }
  }

  /**
   * Creates a text translation for the Outcome attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Outcome
   * attribute, description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text
   * to be translated is empty.
   *
   * {@link GENERAL#ERR_LOCALE_EMPTY ERR_LOCALE_EMPTY} - if locale is
   * empty.
   *
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   *
   * {@link BPOOUTCOME#ERR_OUTCOME_CANCELED
   * ERR_OUTCOME_CANCELED}- if the Outcome to be modified
   * is already canceled.
   */
  public void addDescriptionTextTranslation(final
    LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();
    OutcomeKey outcomeKey = new OutcomeKey();

    OutcomeDescriptionTextID outcomeDescriptionTextID = new
      OutcomeDescriptionTextID();
    OutcomeDtls outcomeDtls = new OutcomeDtls();

    outcomeKey.key.outcomeID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_TEXT_EMPTY);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_LOCALE_EMPTY);
    }

    outcomeDtls = outcomeObj.read(outcomeKey.key);

    // Record must not be already canceled.
    if (outcomeDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      throw new AppException(BPOOUTCOME.ERR_OUTCOME_CANCELED);
    }

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == outcomeDtls.descriptionTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !outcomeDtls.description.equals(CuramConst.gkEmpty)) {

        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        throw e;

      }

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      String value = outcomeDtls.description;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      outcomeDescriptionTextID.descriptionTextID = textID;
      outcomeDescriptionTextID.versionNo = outcomeDtls.versionNo;
      outcomeObj.modifyDescriptionTextID(outcomeKey.key,
        outcomeDescriptionTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != outcomeDtls.descriptionTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        outcomeDtls.descriptionTextID);
      
      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();

    }
  }

  /**
   * Modifies the text translation details for the Outcome attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Outcome attribute,
   * description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   *
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   *
   * {@link BPOOUTCOME#ERR_OUTCOME_CANCELED
   * ERR_OUTCOME_CANCELED}- if the Outcome to be modified
   * is already canceled.
   */
  public void modifyDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();
    OutcomeKey outcomeKey = new OutcomeKey();

    OutcomeDescriptionTextID outcomeDescriptionTextID = new
      OutcomeDescriptionTextID();
    OutcomeDtls outcomeDtls = new OutcomeDtls();

    outcomeKey.key.outcomeID = localizableTextTranslationDetails.localizableTextParentID;

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 25);
    }

    outcomeDtls = outcomeObj.read(outcomeKey.key);

    // Record must not be already canceled.
    if (outcomeDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOOUTCOME.ERR_OUTCOME_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == outcomeDtls.descriptionTextID) {
      // END, CR00246419


      // Handling legacy Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      textID = localizableTextHandler.store();
      outcomeDescriptionTextID.descriptionTextID = textID;
      outcomeDescriptionTextID.versionNo = outcomeDtls.versionNo;
      outcomeObj.modifyDescriptionTextID(outcomeKey.key,
        outcomeDescriptionTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != outcomeDtls.descriptionTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        outcomeDtls.descriptionTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      localizableTextHandler.store();
    }
  }
  // END, CR00234442
}
