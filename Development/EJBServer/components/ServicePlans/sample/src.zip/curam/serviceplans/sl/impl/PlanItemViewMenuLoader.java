/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;

import java.util.Map;

import curam.codetable.PLANNEDITEMSTATUS;
import curam.core.sl.tab.impl.TabLoaderConst;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Trace;
import curam.util.tab.impl.DynamicMenuStateLoader;
import curam.util.tab.impl.MenuState;

/**
 * Provides dynamic tab navigation functionality for the plan item which allows
 * particular navigation item(s) to be disabled/enabled and hidden/shown
 * dynamically, based on the state of data in the database.
 */
public class PlanItemViewMenuLoader implements DynamicMenuStateLoader {

  /**
   * Default constructor.
   */
  public PlanItemViewMenuLoader() {
    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Returns the state of the given list of menu items.
   *
   * @param menuState
   *            The menu instance to load states into.
   * @param pageParameters
   *            The context information, in our current case it is the page
   *            parameters.
   * @param idsToUpdate
   *            The IDs requested by the client to be updated.
   *
   * @return The same menu instance with the updated states.
   */
  public MenuState loadMenuState(MenuState menuState,
      Map<String, String> pageParameters, String[] idsToUpdate) {

    final MenuState returnState = menuState;

    final String plannedItemIDParam = pageParameters
        .get(ServicePlanConst.kPlannedItemID);

    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    final PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = Long.parseLong(plannedItemIDParam);
    PlannedItemDtls plannedItemDtls = null;

    try {
      plannedItemDtls = plannedItemObj.read(plannedItemKey);
    } catch (AppException e) {
      if (Trace.atLeast(Trace.kTraceUltraVerbose)) {
        Trace.kTopLevelLogger
            .info(Trace.exceptionStackTraceAsString(e));
      }
    } catch (InformationalException e) {
      if (Trace.atLeast(Trace.kTraceUltraVerbose)) {
        Trace.kTopLevelLogger
            .info(Trace.exceptionStackTraceAsString(e));
      }
    }

    if (null != plannedItemDtls) {
      if (PLANNEDITEMSTATUS.UNAPPROVED.equals(plannedItemDtls.status)) {

        returnState.setVisible(true, ServicePlanConst.kSubmit);
        returnState.setEnabled(true, ServicePlanConst.kSubmit);

        returnState.setVisible(true, ServicePlanConst.kApprove);
        returnState.setEnabled(false, ServicePlanConst.kApprove);

        returnState.setVisible(true, TabLoaderConst.kReject);
        returnState.setEnabled(false, TabLoaderConst.kReject);

      } else if (PLANNEDITEMSTATUS.SUBMITTED
          .equals(plannedItemDtls.status)) {

        returnState.setVisible(true, ServicePlanConst.kSubmit);
        returnState.setEnabled(false, ServicePlanConst.kSubmit);

        returnState.setVisible(true, ServicePlanConst.kApprove);
        returnState.setEnabled(true, ServicePlanConst.kApprove);

        returnState.setVisible(true, TabLoaderConst.kReject);
        returnState.setEnabled(true, TabLoaderConst.kReject);
      } else {
        returnState.setVisible(true, ServicePlanConst.kSubmit);
        returnState.setEnabled(false, ServicePlanConst.kSubmit);

        returnState.setVisible(true, ServicePlanConst.kApprove);
        returnState.setEnabled(false, ServicePlanConst.kApprove);

        returnState.setVisible(true, TabLoaderConst.kReject);
        returnState.setEnabled(false, TabLoaderConst.kReject);
      }
    }
    return returnState;
  }
}

