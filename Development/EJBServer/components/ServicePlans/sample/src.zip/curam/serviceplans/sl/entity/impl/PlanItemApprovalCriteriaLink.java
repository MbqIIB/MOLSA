/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.BPOPLANITEM;
import curam.serviceplans.sl.entity.fact.PlanTemplateFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemApprCritFactory;
import curam.serviceplans.sl.entity.intf.PlanTemplate;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanItemApprCrit;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkCancelDetails;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkKey;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemApprCritDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemApprCritDtlsList;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemApprCritKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateStatus;
import curam.serviceplans.sl.entity.struct.SearchByPlanItemApprovalCriteriaLinkID;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Implementation for the ApprovalCriteria entity.
 */
public class PlanItemApprovalCriteriaLink extends curam.serviceplans.sl.entity.base.PlanItemApprovalCriteriaLink {

  /**
   * Validate the soft delete of an entry.
   *
   * @param key Contains the unique ID of the record to cancel.
   * @param details Contains the versionNo of the record to cancel
   *
   * @throws AppException, InformationalException
   */
  @Override
  protected void precancel(final PlanItemApprovalCriteriaLinkKey key,
    final PlanItemApprovalCriteriaLinkCancelDetails details) 
    throws AppException, InformationalException {
    
    validateCancel(key);
  }

  /**
   * Validate the data passed into the cancel method.
   *
   * @param key Contains the unique ID of the record to cancel
   *
   * @throws AppException, InformationalException
   */
  public void validateCancel(PlanItemApprovalCriteriaLinkKey key)
    throws AppException, InformationalException {

    SearchByPlanItemApprovalCriteriaLinkID searchKey = new SearchByPlanItemApprovalCriteriaLinkID();

    // Assign key values.
    searchKey.planItemApprovalCriteriaLinkID = key.planItemApprovalCriteriaLinkID;

    final PlanTemplatePlanItemApprCrit planTemplatePlanItemApprCritObj = PlanTemplatePlanItemApprCritFactory.newInstance();

    final PlanTemplatePlanItemApprCritDtlsList list = planTemplatePlanItemApprCritObj.searchByPlanItemApprovalCriteriaLinkID(
      searchKey);

    boolean TemplateRecordStatusNormalInd = false;
    
    final int size = list.dtls.size();

    for (int i = 0; i < size; i++) {
     
      PlanTemplatePlanItemApprCritDtls dtls = list.dtls.item(i);
     
      PlanTemplatePlanItemApprCritKey apprCritKey = new PlanTemplatePlanItemApprCritKey();
      
      apprCritKey.planTemplatePlanItemApprCritID = dtls.planTemplatePlanItemApprCritID;

      PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
      
      // get the status by plan template plan item approval criteria
      PlanTemplateStatus status = planTemplateObj.readStatusByPlanTemplatePlanItemApprCritID(
        apprCritKey);
      
      if (!status.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
        TemplateRecordStatusNormalInd = true;
        break;
      }
    }

    if (TemplateRecordStatusNormalInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_APPROVAL_CRIERIA_FV_ACTIVE_PLAN_TEMPLATE_PLAN_ITEM_APPROVAL_CRITERIA),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }
}
