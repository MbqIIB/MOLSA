/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 - 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.core.impl.CuramConst;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.message.BPOMAINTAINSERVICEPLANDELIVERY;
import curam.message.BPOSERVICEPLANDELIVERY;
import curam.serviceplans.sl.entity.fact.IndexServicePlanDeliverySynchronizationFactory;
import curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory;
import curam.serviceplans.sl.entity.intf.PlannedSubGoal;
import curam.serviceplans.sl.entity.struct.ModifyServicePlanTypeDetails;
import curam.serviceplans.sl.entity.struct.ModifyServicePlanTypeKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalCaseIDKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalIDDetails;
import curam.serviceplans.sl.entity.struct.PlannedGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalCaseIDKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalCountDetails;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.entity.struct.ServicePlanOwnerKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * A specific Service Plan Delivery offered by the Social Security Agency.
 */
public abstract class ServicePlanDelivery extends curam.serviceplans.sl.entity.base.ServicePlanDelivery {

  // BEGIN, CR00092405, MJC
  // ___________________________________________________________________________
  /**
   * Called after insert operation.
   *
   * @param details the details of the service plan delivery being inserted.
   */
  protected void postinsert(final ServicePlanDeliveryDtls details) throws AppException, InformationalException {
    IndexServicePlanDeliverySynchronizationFactory.newInstance().insert(details);
    
  }

  // ___________________________________________________________________________
  /**
   * Called after modify operation.
   *
   * @param key the key of the service plan delivery being modified.
   * @param details the details of the service plan delivery being modified.
   */
  protected void postmodifyServicePlanType(final ModifyServicePlanTypeKey key, final ModifyServicePlanTypeDetails details) throws AppException, InformationalException {
    IndexServicePlanDeliverySynchronizationFactory.newInstance().modifyServicePlanType(
      key, details);
  }

  // END, CR00092405

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion.
   *
   * @param details Service plan delivery details
   */
  protected void preinsert(ServicePlanDeliveryDtls details)
    throws AppException, InformationalException {

    // Validate the details
    validateDetails(details);

  }

  // ___________________________________________________________________________
  /**
   * Validates the service plan delivery details
   *
   * @param dtls The details of the service plan delivery
   */
  public void validateDetails(ServicePlanDeliveryDtls dtls)
    throws AppException, InformationalException {

    // service plan ID field validation
    if (dtls.servicePlanID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSERVICEPLANDELIVERY.ERR_FV_SERVICE_PLAN_ID_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification.
   *
   * @param key Contains case ID of the service plan delivery.
   *
   * @param dtls Service plan delivery details
   */
  protected void premodifyServicePlanType(
    ModifyServicePlanTypeKey key,
    ModifyServicePlanTypeDetails dtls)
    throws AppException, InformationalException {

    // Validate the details
    validateModifyServicePlanType(key, dtls);

  }

  // ___________________________________________________________________________
  /**
   * Validates the service plan delivery modify details
   *
   * @param key Contains case ID of the service plan delivery.
   *
   * @param dtls Details of the service plan type and comments
   */
  public void validateModifyServicePlanType(
    ModifyServicePlanTypeKey key,
    ModifyServicePlanTypeDetails dtls)
    throws AppException, InformationalException {

    // PlannedGoal entity manipulation variables
    curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();

    // ServicePlanDelivery entity manipulation variables
    curam.serviceplans.sl.entity.intf.ServicePlanGoalLink servicePlanGoalLinkObj = curam.serviceplans.sl.entity.fact.ServicePlanGoalLinkFactory.newInstance();

    // Validation - if case is closed, unable to modify type
    // CaseHeader manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = new CaseStatusCode();

    // set the key
    caseHeaderKey.caseID = key.caseID;
    // Read case header details
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    if (caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_MODIFY_SERVICE_PLAN_TYPE_CASESTATUS_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // validation when sub goals have already been added to the service plan delivery
    // PlannedSubGoal manipulation variables
    PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();
    PlannedSubGoalCaseIDKey plannedSubGoalCaseIDKey = new PlannedSubGoalCaseIDKey();
    curam.serviceplans.sl.entity.struct.PlannedSubGoalCountDetails count = new PlannedSubGoalCountDetails();

    // Set the key
    plannedSubGoalCaseIDKey.caseID = key.caseID;
    // Check if any planned sub goals have been created for this service plan
    count = plannedSubGoalObj.countPlannedSubGoalByCaseID(
      plannedSubGoalCaseIDKey);

    // if records exist, sub goals exist so type cannot be modified
    if (count.recordCount > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINSERVICEPLANDELIVERY.ERR_FV_MODIFY_SERVICE_PLAN_TYPE_SUBGOALS_ALREADY_ADDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Method Variables
    curam.serviceplans.sl.entity.struct.GoalKey goalKey = new curam.serviceplans.sl.entity.struct.GoalKey();

    curam.core.struct.CaseID caseID = new curam.core.struct.CaseID();

    curam.serviceplans.sl.entity.struct.ServicePlanGoalLinkCount servicePlanGoalLinkCount;

    curam.serviceplans.sl.entity.struct.ServicePlanAndGoalKey servicePlanAndGoalKey = new curam.serviceplans.sl.entity.struct.ServicePlanAndGoalKey();

    // Read GoalID by CaseID from Planned Goal to see which goal we are currently using.
    try {
      caseID.caseID = key.caseID;
      goalKey = plannedGoalObj.readGoalIDByCaseID(caseID);
    } catch (Exception ex) {
      // if there is no goal existing we can change the type to any service plan type
      // and the goal check is not necessary. This is the exceptional case.
      return;
    }

    // If there is no planned goal then any goal associated with the plan is valid
    // Count the goal and service plan combination to see if they are still valid
    servicePlanAndGoalKey.goalID = goalKey.goalID;

    // service plan delivery entity variable
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // set the key
    servicePlanDeliveryKey.caseID = key.caseID;

    // Service Plan id of modified service plan
    servicePlanAndGoalKey.servicePlanID = dtls.servicePlanID;

    servicePlanGoalLinkCount = servicePlanGoalLinkObj.countByGoalIDAndServicePlanID(
      servicePlanAndGoalKey);

    if (servicePlanGoalLinkCount.count == 0) {

      // Throw informational here letting the user know they must change the goal as it has been blanked out.
      // this can only be done if there are no subgoals or plan groups added to the service plan.

      // read the plannedGoal
      PlannedGoalCaseIDKey plannedGoalCaseIDKey = new PlannedGoalCaseIDKey();

      // set the key
      plannedGoalCaseIDKey.caseID = key.caseID;

      PlannedGoalIDDetails plannedGoalIDDetails = plannedGoalObj.readPlannedGoalIDByCaseID(
        plannedGoalCaseIDKey);

      // then remove the planned goal
      PlannedGoalKey plannedGoalKey = new PlannedGoalKey();

      plannedGoalKey.plannedGoalID = plannedGoalIDDetails.plannedGoalID;

      plannedGoalObj.remove(plannedGoalKey);

      // Create an informational manager
      curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

      // Add the message to the informational manager
      AppException e = new AppException(
        BPOMAINTAINSERVICEPLANDELIVERY.INF_MODIFY_SERVICE_PLAN_TYPE_RESET_GOAL);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

  }

  // BEGIN, CR00051799, GBA  
  // ___________________________________________________________________________
  /**
   * Sets the criteria for the concernRole as Primary
   */  
  
  protected void presearchByOwnerID(ServicePlanOwnerKey key) throws AppException, InformationalException {

    key.typeCode = curam.codetable.CASEPARTICIPANTROLETYPE.PRIMARY;
    
  }
  // END, CR00051799
}
