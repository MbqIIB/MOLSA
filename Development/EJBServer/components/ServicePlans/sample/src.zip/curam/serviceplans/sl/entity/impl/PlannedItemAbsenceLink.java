/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008,2011  Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.core.sl.entity.fact.AbsencePeriodFactory;
import curam.core.sl.entity.struct.AbsencePeriodDtls;
import curam.core.sl.entity.struct.AbsencePeriodDtlsList;
import curam.core.sl.entity.struct.AbsencePeriodKey;
import curam.core.sl.entity.struct.RosterLineItemKey;
import curam.core.sl.infrastructure.entity.struct.RecordStatusAndVersionNo;
import curam.serviceplans.sl.entity.fact.PlannedItemAbsenceLinkFactory;
import curam.serviceplans.sl.entity.struct.PlannedItemAbsenceLinkDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemAbsenceLinkDtlsList;
import curam.serviceplans.sl.entity.struct.PlannedItemAbsenceLinkKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Links an Absence to a Planned Item.
 */
public abstract class PlannedItemAbsenceLink extends curam.serviceplans.sl.entity.base.PlannedItemAbsenceLink {

  // ___________________________________________________________________________
  /**
   * Validates the data constraints before modification of the status.
   *
   * @param key The unique identifier of the planned item absence
   * link record.
   * @param recordStatusAndVersionNo The record status and version number
   * details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature
   */
  protected void premodifyStatus(PlannedItemAbsenceLinkKey key,
    RecordStatusAndVersionNo recordStatusAndVersionNo)
    throws AppException, InformationalException {

    // Read the version number from the database
    recordStatusAndVersionNo.versionNo = PlannedItemAbsenceLinkFactory.newInstance().readVersionNo(key).versionNo;

  }

  // ___________________________________________________________________________
  /**
   * Remove the absence roster line items.
   *
   * @param key Roster line item identifier.
   */
  public void removeAbsenceByRosterLineItemID(RosterLineItemKey key)
    throws AppException, InformationalException {

    // Get the list absence periods
    AbsencePeriodDtlsList absencePeriodDtlsList = AbsencePeriodFactory.newInstance().searchByRosterLineItemID(
      key);
    AbsencePeriodKey absencePeriodKey = new AbsencePeriodKey();
    PlannedItemAbsenceLinkKey plannedItemAbsenceLinkKey = new PlannedItemAbsenceLinkKey();

    for (AbsencePeriodDtls o : absencePeriodDtlsList.dtls) {
      absencePeriodKey.absencePeriodID = o.absencePeriodID;
      PlannedItemAbsenceLinkDtlsList plannedItemAbsenceLinkDtlsList = searchByAbsencePeriodID(
        absencePeriodKey);

      for (PlannedItemAbsenceLinkDtls o2: plannedItemAbsenceLinkDtlsList.dtls) {
        plannedItemAbsenceLinkKey.plannedItemAbsenceLinkID = o2.plannedItemAbsenceLinkID;
        remove(plannedItemAbsenceLinkKey);
      }
    }
  }

}
