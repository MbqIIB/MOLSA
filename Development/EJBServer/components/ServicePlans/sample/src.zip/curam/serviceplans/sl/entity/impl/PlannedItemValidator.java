/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2009, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.PLANITEMTYPE;
import curam.codetable.SUBGOALNAME;
import curam.codetable.impl.PLANITEMTYPEEntry;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.UsersFactory;
import curam.core.intf.Users;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.SensitivityCode;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOPLANNEDITEM;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDtls;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedItemDetailsStruct;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedSubGoalIDDetails;
import curam.serviceplans.sl.entity.struct.ReadOwnerDetails;
import curam.serviceplans.sl.entity.struct.ReadSensitivityCodeByPlannedItem;
import curam.serviceplans.sl.entity.struct.ReadSensitivityCodeByPlannedItemID;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.NotFoundIndicator;
import curam.util.type.StringList;


/**
 * This class contains validation method for planned item creation and
 * modification. The methods contained in this class are invoked using hook
 * mechanism.
 */
public class PlannedItemValidator extends curam.serviceplans.sl.entity.base.PlannedItemValidator {

  /**
   * Validates the details of a planned item.
   *
   * @param plannedItemDtls details of the planned item to be validated.
   */

  public void validateDetails(PlannedItemDtls plannedItemDtls) throws AppException, InformationalException {
    // Set the proposed owner
    UsersKey userKey = new UsersKey();

    userKey.userName = plannedItemDtls.ownerUserName;

    // BEGIN, CR00098617, VM
    SensitivityCode userSensitivityCode = UserAccessFactory.newInstance().readSensitivityCodeForUser(
      userKey);
    // END, CR00098617

    int sensitivity = Integer.parseInt(plannedItemDtls.sensitivityCode);
    int userSensitivity = Integer.parseInt(userSensitivityCode.sensitivity);

    // If the sensitivity level is higher than that of the proposed owner
    // throw the appropriate error message
    if (userSensitivity < sensitivity) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANNEDITEM.ERR_SERVICEPLAN_XRV_USERS_SENSITIVITY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Is expected Start Date specified
    if (plannedItemDtls.expectedStartDate.equals(curam.util.type.Date.kZeroDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_EXPECTED_START_DATE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Is expected End Date specified
    if (plannedItemDtls.expectedEndDate.equals(curam.util.type.Date.kZeroDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_EXPECTED_END_DATE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // BEGIN, CR00161962, LJ
    if (plannedItemDtls.estimatedCost.isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_ESTIMATED_COST_NON_NEGATIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (plannedItemDtls.actualCost.isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_ACTUAL_COST_NON_NEGATIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00161962
    // Is plan item name specified
    if (plannedItemDtls.name.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_NAME_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Is planned sub goal id specified
    if (plannedItemDtls.plannedSubGoalID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_PLANNED_SUBGOAL_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Is expected outcome specified
    if (plannedItemDtls.expectedOutcomeID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_XFV_EXPECTED_OUTCOME_NOT_DEFINED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Is expected Start Date before expected End Date?
    if (!plannedItemDtls.expectedStartDate.equals(
      plannedItemDtls.expectedEndDate)) {
      if (!plannedItemDtls.expectedStartDate.before(
        plannedItemDtls.expectedEndDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_EXPECTED_START_DATE_LATER_THAN_EXPECTED_END_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      // END HARP 47548
    }

    // Has responsibility been specified?
    if ((plannedItemDtls.responsibilityID == 0)
      && (plannedItemDtls.respUserName.length() == 0)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_RESPONSIBILITY_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // PlannedSubGoalObject
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    ReadCaseIDByPlannedSubGoalIDDetails readCaseIDByPlannedSubGoalIDDetails = new ReadCaseIDByPlannedSubGoalIDDetails();

    plannedSubGoalKey.plannedSubGoalID = plannedItemDtls.plannedSubGoalID;

    // BEGIN, CR00096202, SK
    PlannedSubGoalDtls plannedSubGoalDtls;

    plannedSubGoalKey.plannedSubGoalID = plannedItemDtls.plannedSubGoalID;
    plannedSubGoalDtls = plannedSubGoalObj.read(plannedSubGoalKey);

    // Read the CaseID
    readCaseIDByPlannedSubGoalIDDetails = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(
      plannedSubGoalKey);

    // CaseHeader manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = new CaseStatusCode();

    caseHeaderKey.caseID = readCaseIDByPlannedSubGoalIDDetails.caseID;

    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);
    // BEGIN, CR00161962, LJ
    // Is the case closed?
    if (caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANNEDITEM.ERR_SERVICEPLAN_XRV_CLOSED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00161962
    // BEGIN, CR00117669, MC
    if (!caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.OPEN)) {
      if ((plannedSubGoalDtls.outcomeAchieved != null)
        && (plannedSubGoalDtls.outcomeAchieved.length() > 0)) {
        if ((plannedItemDtls.outcomeAchieved != null)
          && (plannedItemDtls.outcomeAchieved.length() == 0)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_CANNOT_BE_REMOVED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }
    }
    // END, CR00117669
    // END, CR00096202

  }

  /**
   * Performs validation of the details for a modify operation.
   *
   * @param plannedItemDtls The planned item details to be modified.
   */

  public void validateModify(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {
    // Has an owner been specified?
    if (plannedItemDtls.ownerUserName.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_OWNER_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Validate the details
    validateDetails(plannedItemDtls);

    // PlannedSubGoal Object
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    // PlannedSubGoal Object
    curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    PlannedItemKey plannedItemKey = new PlannedItemKey();
    PlannedItemDtls tempPlannedItemDtls = new PlannedItemDtls();

    plannedItemKey.plannedItemID = plannedItemDtls.plannedItemID;

    // Read the original details ;
    tempPlannedItemDtls = plannedItemObj.read(plannedItemKey);

    ReadSensitivityCodeByPlannedItem readSensitivityCodeByPlannedItemDetails = new ReadSensitivityCodeByPlannedItem();

    ReadSensitivityCodeByPlannedItemID readSensitivityCodeByPlannedItemIDKey = new ReadSensitivityCodeByPlannedItemID();

    readSensitivityCodeByPlannedItemIDKey.plannedItemID = plannedItemDtls.plannedItemID;

    // Read the SubGoalOwners sensitivity
    readSensitivityCodeByPlannedItemDetails = plannedSubGoalObj.readSensitivityCodeByPlannedItemID(
      readSensitivityCodeByPlannedItemIDKey);

    // Is the sensitivity level lower than the selected sub goal?
    if (Integer.parseInt(plannedItemDtls.sensitivityCode)
      < Integer.parseInt(
        readSensitivityCodeByPlannedItemDetails.sensitivityCode)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_XRV_SUBGOAL_SENSITIVITY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // current date
    curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // Plan Item entity object
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    // set plan item key
    planItemKey.planItemID = tempPlannedItemDtls.planItemID;

    String planItemType = planItemObj.read(planItemKey).typeCode;

    // BEGIN, ?????, VM
    StringList componentDeductionTypeList = CodeTable.getDistinctCodesForAllLanguages(
      PLANITEMTYPE.TABLENAME);

    // END, ?????

    // BEGIN, CR00314645, SSK
    if (PLANITEMTYPEEntry.CUSTOMBASIC.getCode().equals(planItemType)
      || PLANITEMTYPEEntry.ORGANIZATIONACTIVITY.getCode().equals(planItemType)
      || PLANITEMTYPEEntry.PARTICIPANTACTIVITY.getCode().equals(planItemType)
      || PLANITEMTYPEEntry.SUPPORTSERVICE.getCode().equals(planItemType)) {
      // END, CR00314645
      // Is the Actual Start Date after the current Date?
      if (plannedItemDtls.actualStartDate.after(currentDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_XRV_ACTUAL_START_DATE_NOT_ON_OR_BEFORE_CURRENT_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // Is the Actual Start Date before the Actual End Date?
    if (plannedItemDtls.actualEndDate.isZero() == false) {

      if (plannedItemDtls.actualStartDate.after(plannedItemDtls.actualEndDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_XRV_ACTUAL_START_DATE_ON_OR_BEFORE_ACTUAL_END_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // variables used for flow control
    boolean actualStartDateEntered = false;
    boolean actualEndDateEntered = true;

    // BEGIN, CR00021588, TV
    // BEGIN, HARP 66537, PAD
    // Product Delivery Planned Item link entity object
    curam.core.sl.entity.intf.ProductDeliveryPlanItemLink productDeliveryPlanItemLinkObj = curam.core.sl.entity.fact.ProductDeliveryPlanItemLinkFactory.newInstance();
    curam.core.sl.entity.struct.PlannedItemCaseLinkPlannedItemIDKey plannedItemCaseLinkPlannedItemIDKey = new curam.core.sl.entity.struct.PlannedItemCaseLinkPlannedItemIDKey();

    // set planned item ID key
    plannedItemCaseLinkPlannedItemIDKey.plannedItemID = plannedItemDtls.plannedItemID;

    // count product deliveries associated
    curam.core.sl.entity.struct.PlannedItemCaseLinkCountDetails plannedItemCaseLinkCountDetails = productDeliveryPlanItemLinkObj.countByPlannedItemID(
      plannedItemCaseLinkPlannedItemIDKey);

    if (plannedItemCaseLinkCountDetails.recordCount == 0) {

      // END, HARP 66537
      // END, CR00021588

      // Has an Actual End Date been entered?
      if (plannedItemDtls.actualEndDate.isZero() == true) {

        actualEndDateEntered = false;
        // Has an Outcome of Attained or Not Attained been entered.
        if ((plannedItemDtls.outcomeAchieved.equals(
          curam.codetable.OUTCOMEACHIEVED.ATTAINED))
            || (plannedItemDtls.outcomeAchieved.equals(
              curam.codetable.OUTCOMEACHIEVED.NOTATTAINED))) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_OUTCOME_NO_MODIFY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);

        }
      }
      // Has an Actual Start Date been entered?
      if (plannedItemDtls.actualStartDate.isZero() == true) {

        actualStartDateEntered = false;

      } else {

        actualStartDateEntered = true;
      }

      // Only go in here if an actual end date has been entered or if no actual
      // end date has been entered but an actual start date has
      if (actualStartDateEntered == true || actualEndDateEntered == true) {

        // Has an Actual Start Date been entered?
        if (plannedItemDtls.actualStartDate.isZero() == true) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_ACTUAL_START_DATE_EMPTY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }

        // BEGIN, CR00021588, TV
      }
      // END, CR00021588

      // Has the expected outcome been achieved after an actual start date has been entered?
      // BEGIN, CR00095530, MM
      if (!plannedItemDtls.actualStartDate.isZero()
        && (plannedItemDtls.expectedOutcomeID
          != tempPlannedItemDtls.expectedOutcomeID)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_EXPECTED_OUTCOME_NO_MODIFY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      if (!plannedItemDtls.outcomeAchieved.equals(
        curam.codetable.OUTCOMEACHIEVED.NOTATTAINED)) {

        if (plannedItemDtls.goodCauseID != 0) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_GOOD_CAUSE_NO_MODIFY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }

      if ((plannedItemDtls.status.equals(
        curam.codetable.PLANNEDITEMSTATUS.UNAPPROVED))
          || (plannedItemDtls.status.equals(
            curam.codetable.PLANNEDITEMSTATUS.SUBMITTED))) {

        if (plannedItemDtls.actualStartDate.isZero() == false) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_PLAN_ITEM_START_DATE_NO_MODIFY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }

      if (actualEndDateEntered == true) {
        // Has Expected End Date been modified?
        if (!plannedItemDtls.expectedEndDate.equals(
          tempPlannedItemDtls.expectedEndDate)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_EXPECTED_END_DATE_NO_MODIFY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }

      if (actualStartDateEntered == true) {

        // Has an outcome of cancelled been entered?
        if (plannedItemDtls.outcomeAchieved.equals(
          curam.codetable.OUTCOMEACHIEVED.CANCELLED)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_START_DATE_NO_CANCEL),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }

      // BEGIN, CR00312755, GP
      if (PLANITEMTYPEEntry.CUSTOMBASIC.getCode().equals(planItemType)
        || PLANITEMTYPEEntry.ORGANIZATIONACTIVITY.getCode().equals(planItemType)
        || PLANITEMTYPEEntry.PARTICIPANTACTIVITY.getCode().equals(planItemType)
        || PLANITEMTYPEEntry.SUPPORTSERVICE.getCode().equals(planItemType)) {
        // END, CR00312755

        if (plannedItemDtls.actualEndDate.isZero() == false) {

          if ((plannedItemDtls.actualEndDate.before(
            plannedItemDtls.actualStartDate)
              || (plannedItemDtls.actualEndDate.after(currentDate)))) {

            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(
                BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_XRV_ACTUAL_END_DATE_AFTER_ACTUAL_START_DATE_ON_OR_BEFORE_ACTUAL_END_DATE),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
          }
        }
        if (actualStartDateEntered == true) {

          // Has Expected Start Date been modified?
          if (!plannedItemDtls.expectedStartDate.equals(
            tempPlannedItemDtls.expectedStartDate)) {

            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(
                BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_EXPECTED_START_DATE_NO_MODIFY),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
          }
        }
      }

      boolean allowToModifyCostInd = false;

      if ((plannedItemDtls.status.equals(
        curam.codetable.PLANNEDITEMSTATUS.UNAPPROVED))
          || (plannedItemDtls.status.equals(
            curam.codetable.PLANNEDITEMSTATUS.SUBMITTED))) {
        // set indicator
        allowToModifyCostInd = true;
      }

      if (!allowToModifyCostInd) {

        double estCost = plannedItemDtls.estimatedCost.getValue();
        double tmpCost = tempPlannedItemDtls.estimatedCost.getValue();

        if (estCost != tmpCost) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_FV_ESTIMATED_COST_NO_MODIFY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }

      planItemKey.planItemID = tempPlannedItemDtls.planItemID;

      // if associated type is "Product Delivery" than actual cost must not be modified
      if (planItemObj.readAssociatedTypeAndApprovalRequired(planItemKey).associatedType.equals(
        curam.codetable.ASSOCIATEDTYPE.CASEASSOCIATION)) {
        if (!plannedItemDtls.actualCost.equals(tempPlannedItemDtls.actualCost)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOPLANNEDITEM.ERR_SERVICEPLAN_PLAN_ITEM_ACTUAL_COST_CANNOT_BE_MODIFIED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }
      // BEGIN, CR00021588, TV
      // BEGIN, HARP 66537, PAD
    }
    // END, HARP 66537
    // END, CR00021588

  }

  /**
   * Validates the details of the post insert and post modify operations.
   *
   * @param plannedItemDtls - details of the planned item to be validated.
   */
  public void validatePostDetails(PlannedItemDtls plannedItemDtls)
    throws AppException, InformationalException {

    // System User Details
    curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    SystemUserDtls systemUserDtls;

    systemUserDtls = systemUserObj.getUserDetails();

    // notification manipulation variables
    curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();

    StandardManualTaskDtls planItemOwnerDtls = new StandardManualTaskDtls();
    StandardManualTaskDtls subGoalOwnerDtls = new StandardManualTaskDtls();

    boolean ownerDiffToCurrentUser = false;
    boolean subGoalOwnerDiffTOCurrentUser = false;
    // BEGIN, CR00234114, AK
    Users userObj = UsersFactory.newInstance();
    UsersKey userKey = new UsersKey();
    NotFoundIndicator nfIndicator = new NotFoundIndicator();
    String planItemOwnerLocale = TransactionInfo.getProgramLocale();
    String subGoalOwnerLocale = TransactionInfo.getProgramLocale();

    // END, CR00234114
    // Is the current user the plan item owner?
    if (!systemUserDtls.userName.equals(plannedItemDtls.ownerUserName)) {

      // Assign notification to planned item owner
      planItemOwnerDtls.dtls.assignDtls.assignmentID = plannedItemDtls.ownerUserName;
      // BEGIN, CR00234114, AK
      userKey.userName = plannedItemDtls.ownerUserName;
      UsersDtls usersDtls = userObj.read(nfIndicator, userKey);

      if (!nfIndicator.isNotFound()) {
        planItemOwnerLocale = usersDtls.defaultLocale;
      }
      // END, CR00234114
      ownerDiffToCurrentUser = true;
    }

    // PlannedSubGoal Object
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();
    // CaseHeader manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    CaseSearchKey caseSearchKey = new CaseSearchKey();

    PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();
    ReadOwnerDetails readOwnerDetails = new ReadOwnerDetails();

    plannedSubGoalKey.plannedSubGoalID = plannedItemDtls.plannedSubGoalID;
    readOwnerDetails = plannedSubGoalObj.readOwner(plannedSubGoalKey);

    // Is the subgoal owner equal to the plan item owner or the current user?
    if (!readOwnerDetails.ownerID.equals(plannedItemDtls.ownerUserName)
      && !readOwnerDetails.ownerID.equals(systemUserDtls.userName)) {

      // Assign notification to the planned subgoal owner
      subGoalOwnerDtls.dtls.assignDtls.assignmentID = readOwnerDetails.ownerID;
      subGoalOwnerDiffTOCurrentUser = true;
      // BEGIN, CR00234114, AK
      userKey.userName = readOwnerDetails.ownerID;
      UsersDtls usersDtls = userObj.read(nfIndicator, userKey);

      if (!nfIndicator.isNotFound()) {
        subGoalOwnerLocale = usersDtls.defaultLocale;
      }
      // END, CR00234114
    }

    // set subject and comments
    AppException subjectText = new AppException(
      curam.message.BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_OWNER_ASSIGNMENT_SUBJECT);

    // read caseID by planned item id
    plannedItemIDKey.plannedItemID = plannedItemDtls.plannedItemID;

    // Read case ID
    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct = plannedItemObj.readCaseIDByPlannedItemID(
      plannedItemIDKey);

    // Read case reference by case ID
    caseSearchKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;
    // BEGIN, CR00333044, GYH
    planItemOwnerDtls.dtls.concerningDtls.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;
    subGoalOwnerDtls.dtls.concerningDtls.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;
    // END, CR00333044

    CaseReference caseReference = new CaseReference();

    caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey);

    subjectText.arg(plannedItemDtls.name);
    subjectText.arg(caseReference.caseReference);
    AppException commentsText = new AppException(
      curam.message.BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_OWNER_ASSIGNMENT_COMMENTS);

    commentsText.arg(plannedItemDtls.name);
    commentsText.arg(
      // BEGIN, CR00163098, JC
      CodeTable.getOneItem(SUBGOALNAME.TABLENAME,
      plannedSubGoalObj.readPlannedSubGoalDetailsAndSubgoalName(plannedSubGoalKey).subGoalName,
      planItemOwnerLocale));
    // END, CR00163098, JC

    // BEGIN, CR00163659, CL
    // Set the notification for the two possible types of messages
    planItemOwnerDtls.dtls.taskDtls.subject = subjectText.getMessage(
      planItemOwnerLocale);
    planItemOwnerDtls.dtls.taskDtls.comments = commentsText.getMessage(
      planItemOwnerLocale);
    // END, CR00163659
    // BEGIN, CR00023618, SK
    planItemOwnerDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.standardCaseTaskDefinitionID;
    // END, CR00023618
    commentsText.arg(
      // BEGIN, CR00163098, JC
      CodeTable.getOneItem(SUBGOALNAME.TABLENAME,
      plannedSubGoalObj.readPlannedSubGoalDetailsAndSubgoalName(plannedSubGoalKey).subGoalName,
      subGoalOwnerLocale));

    // BEGIN, CR00163659, CL
    subGoalOwnerDtls.dtls.taskDtls.subject = subjectText.getMessage(
      subGoalOwnerLocale);
    subGoalOwnerDtls.dtls.taskDtls.comments = commentsText.getMessage(
      subGoalOwnerLocale);
    // END, CR00163659
    // BEGIN, CR00023618, SK
    subGoalOwnerDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.standardCaseTaskDefinitionID;
    // END, CR00023618
    // Only send one notification to any one user
    if ((ownerDiffToCurrentUser) && (subGoalOwnerDiffTOCurrentUser)) {

      // BEGIN, CR00091205, CM
      if (planItemOwnerDtls.dtls.assignDtls.assignmentID.equals(
        subGoalOwnerDtls.dtls.assignDtls.assignmentID)) {
        // END, CR00091205

        // Users are the same, only send one notification
        // send notification
        notificationObj.createWorkAllocationNotification(planItemOwnerDtls);
      } else {

        // PlanItem Owner and subGoal owner are different and neither are the current user
        // send notification
        notificationObj.createWorkAllocationNotification(planItemOwnerDtls);
        notificationObj.createWorkAllocationNotification(subGoalOwnerDtls);

      }
    } else {
      if (ownerDiffToCurrentUser) {

        notificationObj.createWorkAllocationNotification(planItemOwnerDtls);
      }
      if (subGoalOwnerDiffTOCurrentUser) {

        notificationObj.createWorkAllocationNotification(subGoalOwnerDtls);
      }

    }

    StandardManualTaskDtls planItemResponsibilityDtls = new StandardManualTaskDtls();
    StandardManualTaskDtls subGoalResponsibilityDtls = new StandardManualTaskDtls();
    
    // BEGIN, CR00333044, GYH
    planItemResponsibilityDtls.dtls.concerningDtls.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;
    subGoalResponsibilityDtls.dtls.concerningDtls.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;
    // END, CR00333044

    // BEGIN, CR00234114, AK
    String planItemResponsibilityLocale = TransactionInfo.getProgramLocale();
    String subGoalResponsibilityLocale = TransactionInfo.getProgramLocale();
    
    // END, CR00213430
    boolean respToUserDiffToCurrentUser = false;
    boolean respSubGoalUserDiffTOCurrentUser = false;

    // BEGIN, CR00155032, GBA
    // Is the client or plan participant deemed to be responsible?
    // If yes then end here.
    if (!(plannedItemDtls.responsibilityType.equals(
      curam.codetable.RESPONSIBILITYTYPE.CLIENT)
        || plannedItemDtls.responsibilityType.equals(
          curam.codetable.RESPONSIBILITYTYPE.PARTICIPANT))) {

      // END, CR00155032

      if (plannedItemDtls.responsibilityType.length() == 0) {

        // Default: Set responsibility equal to the client and end here
        plannedItemDtls.responsibilityType = curam.codetable.RESPONSIBILITYTYPE.CLIENT;

      } else {

        // Is the user specified as responsible equal to the current user?
        if (!plannedItemDtls.respUserName.equals(systemUserDtls.userName)) {

          planItemResponsibilityDtls.dtls.assignDtls.assignmentID = plannedItemDtls.respUserName;
          // BEGIN, CR00234114, AK
          userKey.userName = plannedItemDtls.respUserName;
          UsersDtls usersDtls = userObj.read(nfIndicator, userKey);

          if (!nfIndicator.isNotFound()) {
            planItemResponsibilityLocale = usersDtls.defaultLocale;
          }
          // END, CR00234114

          respToUserDiffToCurrentUser = true;
        }

        // Is the user specified as responsible equal to the subgoal owner?
        if (!plannedItemDtls.respUserName.equals(readOwnerDetails.ownerID)
          && !readOwnerDetails.ownerID.equals(systemUserDtls.userName)) {

          subGoalResponsibilityDtls.dtls.assignDtls.assignmentID = readOwnerDetails.ownerID;
          // BEGIN, CR002343114,  AK
          userKey.userName = readOwnerDetails.ownerID;
          UsersDtls usersDtls = userObj.read(nfIndicator, userKey);

          if (!nfIndicator.isNotFound()) {
            subGoalResponsibilityLocale = usersDtls.defaultLocale;
          }
          respSubGoalUserDiffTOCurrentUser = true;
        }

        // set subject and comments
        AppException responsibilitySubjectText = new AppException(
          curam.message.BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_RESPONSIBILITY_ASSIGNMENT_SUBJECT);

        // BEGIN HARP 46024, BF
        responsibilitySubjectText.arg(plannedItemDtls.name);
        responsibilitySubjectText.arg(caseReference.caseReference);
        AppException responsibilityCommentsText = new AppException(
          curam.message.BPOPLANNEDITEM.INF_SERVICEPLAN_PLAN_ITEM_RESPONSIBILITY_ASSIGNMENT_COMMENTS);

        responsibilityCommentsText.arg(plannedItemDtls.name);
        responsibilityCommentsText.arg(
          // BEGIN, CR00163098, JC
          CodeTable.getOneItem(SUBGOALNAME.TABLENAME,
          plannedSubGoalObj.readPlannedSubGoalDetailsAndSubgoalName(plannedSubGoalKey).subGoalName,
          planItemResponsibilityLocale));
        // END, CR00163098, JC
        // BEGIN, CR00163659, CL
        // Set the notification for the two possible types of messages
        planItemResponsibilityDtls.dtls.taskDtls.subject = responsibilitySubjectText.getMessage(
          planItemResponsibilityLocale);

        planItemResponsibilityDtls.dtls.taskDtls.comments = responsibilityCommentsText.getMessage(
          planItemResponsibilityLocale);

        responsibilityCommentsText.arg(
          // BEGIN, CR00163098, JC
          CodeTable.getOneItem(SUBGOALNAME.TABLENAME,
          plannedSubGoalObj.readPlannedSubGoalDetailsAndSubgoalName(plannedSubGoalKey).subGoalName,
          subGoalResponsibilityLocale));
        subGoalResponsibilityDtls.dtls.taskDtls.subject = responsibilitySubjectText.getMessage(
          subGoalResponsibilityLocale);

        subGoalResponsibilityDtls.dtls.taskDtls.comments = responsibilityCommentsText.getMessage(
          subGoalResponsibilityLocale);
        // END, CR00163659

        // Set the definition id for both
        // BEGIN, CR00023618, SK
        planItemResponsibilityDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.standardCaseTaskDefinitionID;
        subGoalResponsibilityDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.standardCaseTaskDefinitionID;
        // END, CR00023618
        // Only send one notification to any one user
        if ((respToUserDiffToCurrentUser) && (respSubGoalUserDiffTOCurrentUser)) {

          // if both users are the same then only send one notification
          // BEGIN, CR00091205, CM
          if (planItemResponsibilityDtls.dtls.assignDtls.assignmentID.equals(
            subGoalResponsibilityDtls.dtls.assignDtls.assignmentID)) {
            // END, CR00091205

            notificationObj.createWorkAllocationNotification(
              planItemResponsibilityDtls);
          } else {

            // PlanItem resp user and subGoal owner are different and neither are the current user
            // Send two notification
            notificationObj.createWorkAllocationNotification(
              planItemResponsibilityDtls);
            notificationObj.createWorkAllocationNotification(
              subGoalResponsibilityDtls);

          }
        } else {
          if (respToUserDiffToCurrentUser) {
            notificationObj.createWorkAllocationNotification(
              planItemResponsibilityDtls);
          }
          if (respSubGoalUserDiffTOCurrentUser) {
            notificationObj.createWorkAllocationNotification(
              subGoalResponsibilityDtls);
          }

        }

      }
    }

  }

}
