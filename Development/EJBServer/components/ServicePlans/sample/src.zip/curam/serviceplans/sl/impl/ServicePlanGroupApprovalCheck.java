/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;

import curam.codetable.RECORDSTATUS;
import curam.codetable.SERVICEPLANGROUPNAMECODE;
import curam.serviceplans.sl.entity.fact.ServicePlanGroupApprovalCheckFactory;
import curam.serviceplans.sl.entity.struct.CancelServicePlanGroupApprovalCheckDetails;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupApprovalCheckDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupApprovalCheckKey;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupApprovalCheckUsernameKey;
import curam.serviceplans.sl.struct.CancelServicePlanGroupApprovalCheckKey;
import curam.serviceplans.sl.struct.ServicePlanGroupApprovalCheckDetails;
import curam.serviceplans.sl.struct.ServicePlanGroupApprovalCheckDetailsList;
import curam.serviceplans.sl.struct.ServicePlanGroupApprovalCheckID;
import curam.serviceplans.sl.struct.ServicePlanGroupApprovalCheckUsernameID;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * Process class that implements the facade functionality for the service 
 * plan group approval check.
 * 
 *
 */
public class ServicePlanGroupApprovalCheck extends
    curam.serviceplans.sl.base.ServicePlanGroupApprovalCheck {

  //___________________________________________________________________________   
  /**
   * This method is to cancel Service Plan Group approval check for the passed
   * SPG approval check key. 
   *  
   * @param key
   *         Details of the entry to be cancelled.
   * 
   * @throws AppException e1
   * @throws InformationalException e2
   */
  public void cancelServicePlanGroupApprovalCheck(final 
      CancelServicePlanGroupApprovalCheckKey key) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.ServicePlanGroupApprovalCheck 
    spgApprovalCheckObj =
        ServicePlanGroupApprovalCheckFactory.newInstance();

    final ServicePlanGroupApprovalCheckKey id =
        new ServicePlanGroupApprovalCheckKey();
    final CancelServicePlanGroupApprovalCheckDetails details =
        new CancelServicePlanGroupApprovalCheckDetails();

    id.assign(key);
    details.versionNo = key.versionNo;
    details.statusCode = RECORDSTATUS.CANCELLED;

    spgApprovalCheckObj.cancel(id, details);
  }

  //___________________________________________________________________________   
  /**
   * This method is to create new Service Plan Group approval check for the 
   * passed SPG approval check details. 
   *  
   * @param details
   *             Details of the new SPG approval check to be created
   * 
   * @throws AppException e1
   * @throws InformationalException e2
   */
  public void createServicePlanGroupApprovalCheck(final 
      ServicePlanGroupApprovalCheckDetails details) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.ServicePlanGroupApprovalCheck 
    spgApprovalCheckObj =
        ServicePlanGroupApprovalCheckFactory.newInstance();

    final ServicePlanGroupApprovalCheckDtls dtls =
        new ServicePlanGroupApprovalCheckDtls();

    dtls.assign(details.dtls);

    spgApprovalCheckObj.insert(dtls);

    // This is needed to ensure that the generated unique ID gets passed back
    // the structs above are different to simplify the modeled aggregations but
    // that means that the Java object that gets passed into the insert is
    // different
    // from the one used to call the entity.
    details.dtls.servicePlanGroupApprovalChkID =
        dtls.servicePlanGroupApprovalChkID;
  }

  /**
   * This method is to modify Service Plan Group approval check details. 
   *  
   * @param details
   *              Details of the SPG approval check to be modified.
   * 
   * @throws AppException e1
   * @throws InformationalException e2
   */
  public void modifyServicePlanGroupApprovalCheck(final 
      ServicePlanGroupApprovalCheckDetails details) throws AppException,
      InformationalException {

    final curam.serviceplans.sl.entity.intf.ServicePlanGroupApprovalCheck 
    spgApprovalCheckObj =
        ServicePlanGroupApprovalCheckFactory.newInstance();

    final ServicePlanGroupApprovalCheckKey id =
        new ServicePlanGroupApprovalCheckKey();
    final ServicePlanGroupApprovalCheckDtls dtls =
        new ServicePlanGroupApprovalCheckDtls();

    id.servicePlanGroupApprovalChkID =
        details.dtls.servicePlanGroupApprovalChkID;
    dtls.assign(details.dtls);

    spgApprovalCheckObj.modify(id, dtls);
  }

  /**
   * This method is to read Service Plan Group approval check details for
   * the passed service plan group approval check id value.
   *  
   * @param key 
   *          Key value for which the details is to be read
   * @return Details of SPG approval check details that was read
   * 
   * @throws AppException e1 
   * @throws InformationalException e2
   */
  public ServicePlanGroupApprovalCheckDetails readServicePlanGroupApprovalCheck(
      final ServicePlanGroupApprovalCheckID key) throws AppException,
      InformationalException {

    final ServicePlanGroupApprovalCheckDetails dtls =
        new ServicePlanGroupApprovalCheckDetails();

    final curam.serviceplans.sl.entity.intf.ServicePlanGroupApprovalCheck 
    spgApprovalCheckObj =
        ServicePlanGroupApprovalCheckFactory.newInstance();

    final ServicePlanGroupApprovalCheckKey id =
        new ServicePlanGroupApprovalCheckKey();

    id.assign(key);

    dtls.dtls.assign(spgApprovalCheckObj.readWithSPGType(id));

    // If this is entry applies to all types, need to change the spgTypeCode to
    // "All Types" so that it displays correctly.
    if (dtls.dtls.appliesToAllInd == true) {
      dtls.dtls.servicePlanGroupTypeCode = SERVICEPLANGROUPNAMECODE.ALLTYPES;
    }

    return dtls;
  }

  /**
   * This method is to get the list of service plan group approval 
   * check details for the given user name.
   *  
   * @param key
   *          User name for which the SPG approval check details are to be 
   *          retrieved.
   * 
   * @return List of SPG approval check details.
   * 
   * @throws AppException e1
   * @throws InformationalException e2
   */
  public ServicePlanGroupApprovalCheckDetailsList 
  listServicePlanGroupApprovalChecks(final 
      ServicePlanGroupApprovalCheckUsernameID key) throws AppException,
      InformationalException {

    final ServicePlanGroupApprovalCheckDetailsList list =
        new ServicePlanGroupApprovalCheckDetailsList();

    final curam.serviceplans.sl.entity.intf.ServicePlanGroupApprovalCheck 
    spgApprovalCheckObj =
        ServicePlanGroupApprovalCheckFactory.newInstance();

    final ServicePlanGroupApprovalCheckUsernameKey id =
        new ServicePlanGroupApprovalCheckUsernameKey();

    id.assign(key);

    list.servicePlanGroupApprovalCheckList.assign(spgApprovalCheckObj
        .searchWithSPGTypeByUsername(id));

    // get the list size
    final int size = list.servicePlanGroupApprovalCheckList.dtls.size();

    // If this is entry applies to all types, need to change the spgTypeCode to
    // "All Types" so that it displays correctly.
    for (int i = 0; i < size; i++) {
      if (list.servicePlanGroupApprovalCheckList.dtls.item(i).
          appliesToAllInd == true) {
        list.servicePlanGroupApprovalCheckList.dtls.item(i).
        servicePlanGroupTypeCode =
            SERVICEPLANGROUPNAMECODE.ALLTYPES;
      }
    }
    return list;
  }

}
