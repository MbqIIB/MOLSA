/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006-2007, 2009-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import org.jdom.Document;
import org.jdom.Element;

import com.google.inject.Inject;

import curam.codetable.impl.LOCALEEntry;
import curam.core.sl.infrastructure.impl.XmlTreeConst;
import curam.serviceplans.facade.struct.XMLDetails;
import curam.serviceplans.sl.entity.fact.PlanTemplateMilestoneFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanGroupFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemApprCritFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanGroup;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanItemApprCrit;
import curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal;
import curam.serviceplans.sl.entity.struct.PlanTemplateMilestoneAssociatedIDs;
import curam.serviceplans.sl.entity.struct.PlanTemplateMilestoneAssociatedIDsList;
import curam.serviceplans.sl.entity.struct.PlanTemplateMilestoneNameAndIDs;
import curam.serviceplans.sl.entity.struct.PlanTemplateMilestoneNameAndIDsList;
import curam.serviceplans.sl.entity.struct.PlanTemplateNameAndNameTextID;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupKey;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalKey;
import curam.serviceplans.sl.entity.struct.TemplateApprovalCriteriaDetailsList;
import curam.serviceplans.sl.entity.struct.TemplatePlanGroupDetailsList;
import curam.serviceplans.sl.entity.struct.TemplatePlanGroupIDAndNameDetailsList;
import curam.serviceplans.sl.entity.struct.TemplatePlanItemDetailsList;
import curam.serviceplans.sl.entity.struct.TemplateSubGoalDetailsList;
import curam.serviceplans.sl.struct.PlanTemplateKey;
import curam.serviceplans.sl.struct.PlanTemplateTreeApprovalCriteriaDetails;
import curam.serviceplans.sl.struct.PlanTemplateTreePlanGroupDetails;
import curam.serviceplans.sl.struct.PlanTemplateTreePlanItemDetails;
import curam.serviceplans.sl.struct.PlanTemplateTreeSubGoalDetails;
import curam.serviceplans.sl.struct.ServicePlanTemplateTreeDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.resources.XMLUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;


/**
 * The plan template tree builds up an xml string containing all the necessary
 * service plan template information required to display the template tree structure.
 */
public abstract class PlanTemplateTree extends curam.serviceplans.sl.base.PlanTemplateTree {

  // BEGIN, CR00069996, SK
  protected static final String kNamespace = XmlTreeConst.kNamespace;
  protected static final String kTreeName = XmlTreeConst.kServicePlanTreeName;
  protected static final String kNodeInfo = XmlTreeConst.kNodeInfo;
  protected static final String kNodeTypes = XmlTreeConst.kNodeTypes;
  protected static final String kNodeType = XmlTreeConst.kNodeType;
  protected static final String kActions = XmlTreeConst.kActions;
  protected static final String kAction = XmlTreeConst.kAction;
  protected static final String kKey = XmlTreeConst.kKey;
  protected static final String kDefault = XmlTreeConst.kDefault;
  protected static final String kName = XmlTreeConst.kName;
  protected static final String kView = XmlTreeConst.kView;
  protected static final String kGoal = XmlTreeConst.kGoal;
  protected static final String kPlanGroup = XmlTreeConst.kPlanGroup;
  protected static final String kSubGoal = XmlTreeConst.kSubGoal;
  protected static final String kPlanItem = XmlTreeConst.kPlanItem;
  protected static final String kPlanTemplateID = XmlTreeConst.kPlanTemplateID;
  protected static final String kPlanTemplatePlanGroupID = XmlTreeConst.kPlanTemplatePlanGroupID;
  protected static final String kPlanTemplateSubGoalID = XmlTreeConst.kPlanTemplateSubGoalID;
  protected static final String kPlanTemplatePlanItemID = XmlTreeConst.kPlanTemplatePlanItemID;
  protected static final String kStartNode = XmlTreeConst.kStartNode;
  protected static final String kNodeSet = XmlTreeConst.kNodeSet;
  protected static final String kNode = XmlTreeConst.kNode;
  protected static final String kID = XmlTreeConst.kID;
  protected static final String kType = XmlTreeConst.kType;
  protected static final String kTitle = XmlTreeConst.kTitle;
  protected static final String kParamValue = XmlTreeConst.kParamValue;
  // END, CR00069996
  // BEGIN, CR00020193, PMD
  // BEGIN, CR00086169, PMD
  protected TreeXMLNodeUtil stTheLastAccessedNode;
  protected String stStartNodeId;
  // END, CR00086169
  // END, CR00020193
  // BEGIN, CR00069996, SK
  // BEGIN, CR00047794, PMD
  protected static final String kMilestone = XmlTreeConst.kMilestone;
  protected static final String kPlanTemplateMilestoneID = XmlTreeConst.kPlanTemplateMilestoneID;
  // END, CR00047794
  // END, CR00069996
  // BEGIN, CR00161962, LJ
  // for approval criteria
  protected static final String kApprovalCriteria = XmlTreeConst.kApprovalCriteria;
  protected static final String kPlanTemplatePlanItemApprovalCriteriaID = XmlTreeConst.kPlanTemplatePlanItemApprovalCriteriaID;
  // END, CR00161962

  // BEGIN, CR00226647, GP
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public PlanTemplateTree() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00226647

  // ___________________________________________________________________________
  /**
   * Retrieves the xml string for the service plan template tree control.
   *
   * @param key the service plan template key
   * @return the XML details required for the Tree Control.
   */
  public XMLDetails getXMLStringForServicePlanTemplateTree(PlanTemplateKey key)
    throws AppException, InformationalException {

    // Return Object
    XMLDetails xmlDetails = new XMLDetails();

    ServicePlanTemplateTreeDetails servicePlanTemplateTreeDetails = new ServicePlanTemplateTreeDetails();

    // Read Template Details (Parent sub-goals & their plan items)
    servicePlanTemplateTreeDetails = readServicePlanTemplateTreeData(key);

    // Build XML
    xmlDetails = buildXMLTree(servicePlanTemplateTreeDetails);
    xmlDetails.templateName = servicePlanTemplateTreeDetails.planTemplateName;

    return xmlDetails;
  }

  // ___________________________________________________________________________
  /**
   * Read the service plan template data required for the tree control.
   * (Parent sub-goals & their plan items)
   *
   * @param key the service plan template key
   * @return the Service Plan Template Tree Details
   */
  public ServicePlanTemplateTreeDetails readServicePlanTemplateTreeData(PlanTemplateKey key)
    throws AppException, InformationalException {

    // Return Struct
    ServicePlanTemplateTreeDetails servicePlanTemplateTreeDetails = new ServicePlanTemplateTreeDetails();

    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal planTemplateSubGoalObj = curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory.newInstance();

    curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem planTemplatePlanItemObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory.newInstance();
    // BEGIN, CR00161962, LJ
    final PlanTemplatePlanItemApprCrit planTemplatePlanItemApprovalCriteriaObj = PlanTemplatePlanItemApprCritFactory.newInstance();
    // END, CR00161962
    curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();

    curam.serviceplans.sl.entity.struct.GoalIDDetails goalIDDetails = planTemplateObj.readGoalID(
      key.planTemplateKey);

    curam.serviceplans.sl.entity.struct.GoalKey goalKey = new curam.serviceplans.sl.entity.struct.GoalKey();

    goalKey.goalID = goalIDDetails.goalID;

    curam.serviceplans.sl.entity.struct.GoalNameDetails goalNameDetails;

    goalNameDetails = goalObj.readName(goalKey);

    servicePlanTemplateTreeDetails.goalName = // BEGIN, CR00163098, JC
      CodeTable.getOneItem(curam.codetable.GOALNAME.TABLENAME,
      goalNameDetails.name, TransactionInfo.getProgramLocale());
    // END, CR00163098, JC

    servicePlanTemplateTreeDetails.planTemplateID = key.planTemplateKey.planTemplateID;

    curam.serviceplans.sl.entity.struct.PlanTemplateKey planTemplateKey = new curam.serviceplans.sl.entity.struct.PlanTemplateKey();

    planTemplateKey.planTemplateID = key.planTemplateKey.planTemplateID;

    // BEGIN, CR00226647, GP
    PlanTemplateNameAndNameTextID planTemplateNameAndNameTextID = new
      PlanTemplateNameAndNameTextID();

    planTemplateNameAndNameTextID = planTemplateObj.readPlanTemplateName(
      key.planTemplateKey);

    // Read the localized name.
    if (planTemplateNameAndNameTextID.nameTextID != 0) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        planTemplateNameAndNameTextID.nameTextID);

      servicePlanTemplateTreeDetails.planTemplateName = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    } else {
      servicePlanTemplateTreeDetails.planTemplateName = planTemplateNameAndNameTextID.name;
    }
    // END, CR00226647


    // Get list of parent subgoals
    TemplateSubGoalDetailsList templateSubGoalDetailsList = planTemplateSubGoalObj.searchParentSubGoalsByPlanTemplateID(
      planTemplateKey);
    // BEGIN, CR00161962, LJ
    int subGoalSize = templateSubGoalDetailsList.dtls.size();

    // For each parent sub goal found for the template...
    for (int i = 0; i < subGoalSize; i++) {

      // Create an element of the returned struct
      PlanTemplateTreeSubGoalDetails planTemplateTreeSubGoalDetails = new PlanTemplateTreeSubGoalDetails();

      // Assign the details to the return struct
      planTemplateTreeSubGoalDetails.assign(
        templateSubGoalDetailsList.dtls.item(i));

      PlanTemplateSubGoalKey planTemplateSubGoalKey = new PlanTemplateSubGoalKey();

      planTemplateSubGoalKey.planTemplateSubGoalID = planTemplateTreeSubGoalDetails.planTemplateSubGoalID;

      // Read plan item details for current sub-goal
      TemplatePlanItemDetailsList templatePlanItemDetailsList = planTemplatePlanItemObj.searchByPlanTemplateSubGoalID(
        planTemplateSubGoalKey);

      int planItemSize = templatePlanItemDetailsList.dtls.size();

      // For each plan item found for the sub-goal
      for (int j = 0; j < planItemSize; j++) {

        // Create an element of the returned struct
        PlanTemplateTreePlanItemDetails planTemplateTreePlanItemDetails = new PlanTemplateTreePlanItemDetails();

        // Assign the details to the return struct
        planTemplateTreePlanItemDetails.assign(
          templatePlanItemDetailsList.dtls.item(j));
        planTemplateTreeSubGoalDetails.planTemplateTreePlanItemDetails.addRef(
          planTemplateTreePlanItemDetails);

        final PlanTemplatePlanItemKey plantemplateplanitemkey = new PlanTemplatePlanItemKey();

        plantemplateplanitemkey.planTemplatePlanItemID = planTemplateTreePlanItemDetails.planTemplatePlanItemID;

        // read approval criteria associated with plan item
        final TemplateApprovalCriteriaDetailsList templateApprovalCriteriaDetailsList = planTemplatePlanItemApprovalCriteriaObj.searchByPlanTemplatePlanItemID(
          plantemplateplanitemkey);

        final int apprCritSize = templateApprovalCriteriaDetailsList.dtls.size();

        // For each approval criteria found for the plan item
        for (int k = 0; k < apprCritSize; k++) {
          // Create an element of the returned struct
          final PlanTemplateTreeApprovalCriteriaDetails planTemplateTreeApprovalCriteriaDetails = new PlanTemplateTreeApprovalCriteriaDetails();

          // Assign the details to the return struct
          planTemplateTreeApprovalCriteriaDetails.assign(
            templateApprovalCriteriaDetailsList.dtls.item(k));
          planTemplateTreePlanItemDetails.planTemplateTreeApprovalCriteriaDetails.addRef(
            planTemplateTreeApprovalCriteriaDetails);

        }
      }
      // END, CR00161962
      servicePlanTemplateTreeDetails.planTemplateTreeSubGoalDetails.addRef(
        planTemplateTreeSubGoalDetails);
    }

    return servicePlanTemplateTreeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Builds the xml string for the tree control widget
   *
   * @param details the service plan template details
   * @return the Service Plan Template Tree XML
   */
  public XMLDetails buildXMLTree(ServicePlanTemplateTreeDetails details)
    throws AppException, InformationalException {

    // Return Struct
    XMLDetails xmlDetails = new XMLDetails();

    PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();

    // create node types that will be added to the tree
    Element mainElement = new Element(kNodeInfo, kNamespace);

    mainElement.setAttribute(kName, kTreeName);

    Element nodeTypesElement = new Element(kNodeTypes, kNamespace);

    // BEGIN, CR00047794, PMD
    // Create a goal node type
    Element nodeTypeElement = createNodeTypeElement(kGoal, kPlanTemplateID);

    nodeTypesElement.addContent(nodeTypeElement);

    // Create a plan group node type
    nodeTypeElement = createNodeTypeElement(kPlanGroup,
      kPlanTemplatePlanGroupID);
    nodeTypesElement.addContent(nodeTypeElement);

    // Create a sub goal node type
    nodeTypeElement = createNodeTypeElement(kSubGoal, kPlanTemplateSubGoalID);
    nodeTypesElement.addContent(nodeTypeElement);

    // Create a plan item node type
    nodeTypeElement = createNodeTypeElement(kPlanItem, kPlanTemplatePlanItemID);
    nodeTypesElement.addContent(nodeTypeElement);

    // Create a milestone node type
    nodeTypeElement = createNodeTypeElement(kMilestone,
      kPlanTemplateMilestoneID);
    nodeTypesElement.addContent(nodeTypeElement);
    // END, CR00047794
    // BEGIN, CR00161962, LJ
    // create a approval criteria node type
    nodeTypeElement = createNodeTypeElement(kApprovalCriteria,
      kPlanTemplatePlanItemApprovalCriteriaID);
    nodeTypesElement.addContent(nodeTypeElement);
    // END, CR00161962
    // attach the node types
    mainElement.addContent(nodeTypesElement);

    // BEGIN, CR00020193, PMD
    stTheLastAccessedNode = new TreeXMLNodeUtil().getLastAccessedNode();
    // END, CR00020193

    // Goal/Template
    Element nodeElementGoal = new Element(kNode, kNamespace);
    // BEGIN, CR00069996, SK
    String goalUniqueID = XmlTreeConst.kPrefixgoalUniqueID
      + String.valueOf(details.planTemplateID);

    // END, CR00069996
    nodeElementGoal.setAttribute(kID, goalUniqueID);
    nodeElementGoal.setAttribute(kType, kGoal);

    Element titleElementGoal = new Element(kTitle, kNamespace);

    nodeElementGoal.addContent(titleElementGoal);
    titleElementGoal.setText(details.goalName);

    Element paramValueElementGoal = new Element(kParamValue, kNamespace);

    nodeElementGoal.addContent(paramValueElementGoal);
    paramValueElementGoal.setAttribute(kName, kPlanTemplateID).addContent(
      String.valueOf(details.planTemplateID));

    curam.serviceplans.sl.entity.struct.PlanTemplateKey planTemplateKey = new curam.serviceplans.sl.entity.struct.PlanTemplateKey();

    planTemplateKey.planTemplateID = details.planTemplateID;

    // BEGIN, CR00020193, PMD
    if (stTheLastAccessedNode != null
      && stTheLastAccessedNode.equals(String.valueOf(details.planTemplateID),
      TreeXMLNodeUtil.kPlanTemplate)) {

      stStartNodeId = goalUniqueID;
    }
    // END, CR00020193

    // BEGIN, CR00047794, PMD
    // Read milestones at root level
    // BEGIN, CR00311377, AKr
    final LOCALEEntry localeEntry = LOCALEEntry.get(
      ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString());
    final PlanTemplateMilestoneAssociatedIDsList planTemplateMilestoneAssociatedIDsList = PlanTemplateMilestoneFactory.newInstance().searchMilestoneAndIdsByPlanTemplate(
      planTemplateKey);
    PlanTemplateMilestoneNameAndIDs planTemplateMilestoneNameAndIDs;

    for (final PlanTemplateMilestoneAssociatedIDs planTemplateMilestoneAssociatedIDs
      :planTemplateMilestoneAssociatedIDsList.dtls.items()) {
        
      planTemplateMilestoneNameAndIDs = new PlanTemplateMilestoneNameAndIDs();
      planTemplateMilestoneNameAndIDs.assign(planTemplateMilestoneAssociatedIDs);
        
      if (0 != planTemplateMilestoneAssociatedIDs.nameTextID) {
        final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          planTemplateMilestoneAssociatedIDs.nameTextID);

        planTemplateMilestoneNameAndIDs.name = localizableText.getValue(
          localeEntry);
      }
      nodeElementGoal.addContent(
        createMilestoneXML(planTemplateMilestoneNameAndIDs));
    }
    // END, CR00311377
    // END, CR00047794

    // BEGIN, CR00235328, GP
    // Read plan group details.
    TemplatePlanGroupIDAndNameDetailsList templatePlanGroupDetailsList = planTemplatePlanGroupObj.searchParentPlanGroupNamesForTemplate(
      planTemplateKey);

    // END, CR00235328

    for (int i = 0; i < templatePlanGroupDetailsList.dtls.size(); i++) {

      PlanTemplateTreePlanGroupDetails planTemplateTreePlanGroupDetails = new PlanTemplateTreePlanGroupDetails();

      // BEGIN, CR00235328, GP
      planTemplateTreePlanGroupDetails.assign(
        templatePlanGroupDetailsList.dtls.item(i));
      if (0 != templatePlanGroupDetailsList.dtls.item(i).planGroupNameTextID) {

        LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          templatePlanGroupDetailsList.dtls.item(i).planGroupNameTextID);

        planTemplateTreePlanGroupDetails.planTemplatePlanGroupName = localizableText.getValue(
          localeEntry);
      }
      // END, CR00235328

      // Create Plan Group XML for current plan group
      Element planGroupElement = createPlanGroupXML(
        planTemplateTreePlanGroupDetails);

      // Add the plan group Element to the root
      nodeElementGoal.addContent(planGroupElement);
    }

    // Create XML for parent elements (Parent sub-goals & their plan items)
    // retrieved in readServicePlanTemplateTreeData(PlanTemplateKey) method
    nodeElementGoal = createSubGoalXML(details, nodeElementGoal);

    // BEGIN, CR00020193, PMD
    // add category nodes
    Element nodeSetElement = new Element(kNodeSet, kNamespace);

    if (stStartNodeId != null) {
      nodeSetElement.setAttribute(kStartNode, stStartNodeId);
    } else {
      nodeSetElement.setAttribute(kStartNode, goalUniqueID);
    }

    nodeSetElement.addContent(nodeElementGoal);
    // END, CR00020193

    mainElement.addContent(nodeSetElement);
    Document document = new Document(mainElement);

    xmlDetails.xmlOutput = XMLUtil.getAsString(document);

    return xmlDetails;
  }

  // ___________________________________________________________________________
  /**
   * Creates an Element for a Sub-Goal
   *
   * @param Element the parent Element
   * @param details the sub-goal details
   * @return Element the new sub-goal element
   */
  // BEGIN, CR00198672, VK
  protected Element createSubGoalXML(
    ServicePlanTemplateTreeDetails details, Element parentElement) throws AppException,
      InformationalException {
    // END, CR00198672
    // iterate through sub goals list
    for (int i = 0; i < details.planTemplateTreeSubGoalDetails.size(); i++) {

      PlanTemplateTreeSubGoalDetails planTemplateTreeSubGoalDetails = new PlanTemplateTreeSubGoalDetails();

      planTemplateTreeSubGoalDetails.assign(
        details.planTemplateTreeSubGoalDetails.item(i));

      // Create a sub-goal element
      // BEGIN, CR00069996, SK
      String subGoalUniqueID = XmlTreeConst.kPrefixsubGoalUniqueID;

      // END, CR00069996
      if (planTemplateTreeSubGoalDetails.planTemplatePlanGroupID != 0) {

        subGoalUniqueID = subGoalUniqueID
          + String.valueOf(
            planTemplateTreeSubGoalDetails.planTemplatePlanGroupID)
            + String.valueOf(
              planTemplateTreeSubGoalDetails.planTemplateSubGoalID);

      } else {

        subGoalUniqueID = subGoalUniqueID
          + String.valueOf(details.planTemplateID)
          + String.valueOf(planTemplateTreeSubGoalDetails.planTemplateSubGoalID);
      }

      Element nodeElementSubGoal = new Element(kNode, kNamespace);

      nodeElementSubGoal.setAttribute(kID, subGoalUniqueID);
      nodeElementSubGoal.setAttribute(kType, kSubGoal);

      Element titleElementSubGoal = new Element(kTitle, kNamespace);

      nodeElementSubGoal.addContent(titleElementSubGoal);

      titleElementSubGoal.setText(
        // BEGIN, CR00163098, JC
        CodeTable.getOneItem(curam.codetable.SUBGOALNAME.TABLENAME,
        planTemplateTreeSubGoalDetails.name, TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

      Element paramValueElementSubGoal = new Element(kParamValue, kNamespace);

      nodeElementSubGoal.addContent(paramValueElementSubGoal);

      paramValueElementSubGoal.setAttribute(kName, kPlanTemplateSubGoalID).addContent(
        String.valueOf(planTemplateTreeSubGoalDetails.planTemplateSubGoalID));

      // BEGIN, CR00020193, PMD
      if (stTheLastAccessedNode != null
        && stTheLastAccessedNode.equals(
          String.valueOf(planTemplateTreeSubGoalDetails.planTemplateSubGoalID),
          TreeXMLNodeUtil.kPlanTemplateSubGoal)) {

        stStartNodeId = subGoalUniqueID;
      }
      // END, CR00020193

      // BEGIN, CR00047794, PMD
      // Read milestones at sub goal level
      PlanTemplateSubGoalKey planTemplateSubGoalKey = new PlanTemplateSubGoalKey();

      planTemplateSubGoalKey.planTemplateSubGoalID = planTemplateTreeSubGoalDetails.planTemplateSubGoalID;
 
      // BEGIN, CR00311377, AKr
      final LOCALEEntry localeEntry = LOCALEEntry.get(
        ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString());
      final PlanTemplateMilestoneAssociatedIDsList planTemplateMilestoneAssociatedIDsList = PlanTemplateMilestoneFactory.newInstance().searchMilestoneAndIDsByPlanTemplateSubGoal(
        planTemplateSubGoalKey);
      PlanTemplateMilestoneNameAndIDs planTemplateMilestoneNameAndIDs;

      for (final PlanTemplateMilestoneAssociatedIDs 
        planTemplateMilestoneAssociatedIDs :planTemplateMilestoneAssociatedIDsList.dtls.items()) {
        planTemplateMilestoneNameAndIDs = new PlanTemplateMilestoneNameAndIDs();
        planTemplateMilestoneNameAndIDs.assign(
          planTemplateMilestoneAssociatedIDs);

        if (0 != planTemplateMilestoneAssociatedIDs.nameTextID) {

          final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
            planTemplateMilestoneAssociatedIDs.nameTextID);

          planTemplateMilestoneNameAndIDs.name = localizableText.getValue(
            localeEntry);
        }
        nodeElementSubGoal.addContent(
          createMilestoneXML(planTemplateMilestoneNameAndIDs));
      }
      // END, CR00311377
      // END, CR00047794

      // iterate plan items list for the sub goal
      for (int j = 0; j
        < planTemplateTreeSubGoalDetails.planTemplateTreePlanItemDetails.size(); j++) {

        PlanTemplateTreePlanItemDetails planTemplateTreePlanItemDetails = new PlanTemplateTreePlanItemDetails();

        planTemplateTreePlanItemDetails.assign(
          planTemplateTreeSubGoalDetails.planTemplateTreePlanItemDetails.item(j));

        // Create a plan item element
        // BEGIN, CR00069996, SK
        String planItemUniqueID = XmlTreeConst.kPrefixplanItemUniqueID
          + String.valueOf(planTemplateTreeSubGoalDetails.planTemplateSubGoalID)
          + String.valueOf(
            planTemplateTreePlanItemDetails.planTemplatePlanItemID);
        // END, CR00069996
        Element nodeElementPlanItem = new Element(kNode, kNamespace);

        // Add plan item element to the sub-goal element
        nodeElementSubGoal.addContent(nodeElementPlanItem);

        nodeElementPlanItem.setAttribute(kID, planItemUniqueID);
        nodeElementPlanItem.setAttribute(kType, kPlanItem);

        Element titleElementPlanItem = new Element(kTitle, kNamespace);

        nodeElementPlanItem.addContent(titleElementPlanItem);
        titleElementPlanItem.setText(
          // BEGIN, CR00163098, JC
          CodeTable.getOneItem(curam.codetable.PLANITEMNAME.TABLENAME,
          planTemplateTreePlanItemDetails.name,
          TransactionInfo.getProgramLocale()));
        // END, CR00163098, JC

        Element paramValueElementPlanItem = new Element(kParamValue, kNamespace);

        nodeElementPlanItem.addContent(paramValueElementPlanItem);

        paramValueElementPlanItem.setAttribute(kName, kPlanTemplatePlanItemID).addContent(
          String.valueOf(planTemplateTreePlanItemDetails.planTemplatePlanItemID));

        // BEGIN, CR00020193, PMD
        if (stTheLastAccessedNode != null
          && stTheLastAccessedNode.equals(
            String.valueOf(
              planTemplateTreePlanItemDetails.planTemplatePlanItemID),
              TreeXMLNodeUtil.kPlanTemplatePlanItem)) {

          stStartNodeId = planItemUniqueID;
        }
        // END, CR00020193
        // BEGIN, CR00161962, LJ
        int size = planTemplateTreePlanItemDetails.planTemplateTreeApprovalCriteriaDetails.size();

        for (int k = 0; k < size; k++) {

          final PlanTemplateTreeApprovalCriteriaDetails planTemplateTreeApprovalCriteriaDetails = new PlanTemplateTreeApprovalCriteriaDetails();

          planTemplateTreeApprovalCriteriaDetails.assign(
            planTemplateTreePlanItemDetails.planTemplateTreeApprovalCriteriaDetails.item(
              k));

          // Create a approval criteria element
          final StringBuffer approvalCriteriaUniqueID = new StringBuffer();

          approvalCriteriaUniqueID.append(XmlTreeConst.kPrefixApprovalCriteriaUniqueID).append(String.valueOf(planTemplateTreePlanItemDetails.planTemplatePlanItemID)).append(
            String.valueOf(
              planTemplateTreeApprovalCriteriaDetails.planTemplatePlanItemApprCritID));

          final Element nodeElementApprovalCriteria = new Element(kNode,
            kNamespace);

          // Add approval criteria element to the plan item element
          nodeElementPlanItem.addContent(nodeElementApprovalCriteria);

          nodeElementApprovalCriteria.setAttribute(kID,
            approvalCriteriaUniqueID.toString());
          nodeElementApprovalCriteria.setAttribute(kType, kApprovalCriteria);

          final Element titleElementApprovalCriteria = new Element(kTitle,
            kNamespace);

          nodeElementApprovalCriteria.addContent(titleElementApprovalCriteria);
          titleElementApprovalCriteria.setText(
            CodeTable.getOneItem(curam.codetable.APPROVALCRITERIANAME.TABLENAME,
            planTemplateTreeApprovalCriteriaDetails.name));

          final Element paramValueElementApprovalCriteria = new Element(
            kParamValue, kNamespace);

          nodeElementApprovalCriteria.addContent(
            paramValueElementApprovalCriteria);

          paramValueElementApprovalCriteria.setAttribute(kName, kPlanTemplatePlanItemApprovalCriteriaID).addContent(
            String.valueOf(
              planTemplateTreeApprovalCriteriaDetails.planTemplatePlanItemApprCritID));

          if (stTheLastAccessedNode != null
            && stTheLastAccessedNode.equals(
              String.valueOf(
                planTemplateTreeApprovalCriteriaDetails.planTemplatePlanItemApprCritID),
                TreeXMLNodeUtil.kPlanTemplatePlanItemApprovalCriteria)) {

            stStartNodeId = approvalCriteriaUniqueID.toString();
          }
        }
        // END, CR00161962
      }

      // Add sub-goal element to parent element
      parentElement.addContent(nodeElementSubGoal);
    }

    return parentElement;
  }

  // ___________________________________________________________________________
  /**
   * Creates an Element for a Plan Group
   *
   * @param planTemplateTreePlanGroupDetails the plan group details
   * @return Element the plan group element
   */
  // BEGIN, CR00198672, VK
  protected Element createPlanGroupXML(
    PlanTemplateTreePlanGroupDetails planTemplateTreePlanGroupDetails) throws AppException,
      InformationalException {
    // END, CR00198672
    PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();

    PlanTemplateSubGoal planTemplateSubGoalObj = PlanTemplateSubGoalFactory.newInstance();

    PlanTemplatePlanItem planTemplatePlanItemObj = PlanTemplatePlanItemFactory.newInstance();
    // BEGIN, CR00161962, LJ
    PlanTemplatePlanItemApprCrit planTemplatePlanItemApprovalCriteriaObj = PlanTemplatePlanItemApprCritFactory.newInstance();
    // END, CR00161962
    // Create Plan Group Element
    // BEGIN, CR00069996, SK
    String planGroupUniqueID = XmlTreeConst.kPrefixplanGroupUniqueID
      + String.valueOf(planTemplateTreePlanGroupDetails.planTemplatePlanGroupID);
    // END, CR00069996
    Element nodeElementPlanGroup = new Element(kNode, kNamespace);

    nodeElementPlanGroup.setAttribute(kID, planGroupUniqueID);
    nodeElementPlanGroup.setAttribute(kType, kPlanGroup);

    Element titleElementPlanGroup = new Element(kTitle, kNamespace);

    nodeElementPlanGroup.addContent(titleElementPlanGroup);
    titleElementPlanGroup.setText(
      planTemplateTreePlanGroupDetails.planTemplatePlanGroupName);

    Element paramValueElementPlanGroup = new Element(kParamValue, kNamespace);

    nodeElementPlanGroup.addContent(paramValueElementPlanGroup);

    paramValueElementPlanGroup.setAttribute(kName, kPlanTemplatePlanGroupID).addContent(
      String.valueOf(planTemplateTreePlanGroupDetails.planTemplatePlanGroupID));

    // BEGIN, CR00020193, PMD
    if (stTheLastAccessedNode != null
      && stTheLastAccessedNode.equals(
        String.valueOf(planTemplateTreePlanGroupDetails.planTemplatePlanGroupID),
        TreeXMLNodeUtil.kPlanTemplatePlanGroup)) {

      stStartNodeId = planGroupUniqueID;
    }
    // END, CR00020193

    PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new PlanTemplatePlanGroupKey();

    planTemplatePlanGroupKey.planTemplatePlanGroupID = planTemplateTreePlanGroupDetails.planTemplatePlanGroupID;

    // BEGIN, CR00047794, PMD
    // Read milestones at plan group level
    // BEGIN, CR00311377, AKr
    final LOCALEEntry localeEntry = LOCALEEntry.get(
      ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString());
    final PlanTemplateMilestoneAssociatedIDsList planTemplateMilestoneAssociatedIDsList = PlanTemplateMilestoneFactory.newInstance().searchMilestoneAndIDsByPlanTemplatePlanGroup(
      planTemplatePlanGroupKey);
    PlanTemplateMilestoneNameAndIDs planTemplateMilestoneNameAndIDs;

    for (final PlanTemplateMilestoneAssociatedIDs planTemplateMilestoneAssociatedIDs
      :planTemplateMilestoneAssociatedIDsList.dtls.items()) {
    
      planTemplateMilestoneNameAndIDs = new PlanTemplateMilestoneNameAndIDs();
      planTemplateMilestoneNameAndIDs.assign(planTemplateMilestoneAssociatedIDs);
       
      if (0 != planTemplateMilestoneAssociatedIDs.nameTextID) {
        final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          planTemplateMilestoneAssociatedIDs.nameTextID);

        planTemplateMilestoneNameAndIDs.name = localizableText.getValue(
          localeEntry);
      }
      nodeElementPlanGroup.addContent(
        createMilestoneXML(planTemplateMilestoneNameAndIDs));
    }
    // END, CR00311377
    // END, CR00047794

    // Read Child SubGoals for Plan Group
    TemplateSubGoalDetailsList templateSubGoalDetailsList = planTemplateSubGoalObj.searchByPlanTemplatePlanGroupID(
      planTemplatePlanGroupKey);

    ServicePlanTemplateTreeDetails servicePlanTemplateTreeDetails = new ServicePlanTemplateTreeDetails();

    // For each sub-goal found for the plan group....
    for (int i = 0; i < templateSubGoalDetailsList.dtls.size(); i++) {

      PlanTemplateTreeSubGoalDetails planTemplateTreeSubGoalDetails = new PlanTemplateTreeSubGoalDetails();

      // Assign sub-goal details to the return struct
      planTemplateTreeSubGoalDetails.assign(
        templateSubGoalDetailsList.dtls.item(i));

      PlanTemplateSubGoalKey planTemplateSubGoalKey = new PlanTemplateSubGoalKey();

      planTemplateSubGoalKey.planTemplateSubGoalID = planTemplateTreeSubGoalDetails.planTemplateSubGoalID;

      // Read plan items for sub-goal
      TemplatePlanItemDetailsList templatePlanItemDetailsList = planTemplatePlanItemObj.searchByPlanTemplateSubGoalID(
        planTemplateSubGoalKey);

      // For each plan item found for the sub-goal....
      for (int j = 0; j < templatePlanItemDetailsList.dtls.size(); j++) {

        PlanTemplateTreePlanItemDetails planTemplateTreePlanItemDetails = new PlanTemplateTreePlanItemDetails();

        // Assign plan item details to the return struct
        planTemplateTreePlanItemDetails.assign(
          templatePlanItemDetailsList.dtls.item(j));

        // Add the plan item details to the return struct
        planTemplateTreeSubGoalDetails.planTemplateTreePlanItemDetails.addRef(
          planTemplateTreePlanItemDetails);
        // BEGIN, CR00161962, LJ
        PlanTemplatePlanItemKey plantemplateplanitemkey = new PlanTemplatePlanItemKey();

        plantemplateplanitemkey.planTemplatePlanItemID = planTemplateTreePlanItemDetails.planTemplatePlanItemID;

        // read approval criteria associated with plan item
        TemplateApprovalCriteriaDetailsList templateApprovalCriteriaDetailsList = planTemplatePlanItemApprovalCriteriaObj.searchByPlanTemplatePlanItemID(
          plantemplateplanitemkey);

        // For each approval criteria found for the plan item
        final int size = templateApprovalCriteriaDetailsList.dtls.size();
        PlanTemplateTreeApprovalCriteriaDetails planTemplateTreeApprovalCriteriaDetails;

        for (int k = 0; k < size; k++) {
          // Create an element of the returned struct
          planTemplateTreeApprovalCriteriaDetails = new PlanTemplateTreeApprovalCriteriaDetails();

          // Assign the details to the return struct
          planTemplateTreeApprovalCriteriaDetails.assign(
            templateApprovalCriteriaDetailsList.dtls.item(k));
          planTemplateTreePlanItemDetails.planTemplateTreeApprovalCriteriaDetails.addRef(
            planTemplateTreeApprovalCriteriaDetails);

        }
        // END, CR00161962
      }

      // Add sub-goal details to the return struct
      servicePlanTemplateTreeDetails.planTemplateTreeSubGoalDetails.addRef(
        planTemplateTreeSubGoalDetails);
    }

    // Updates the plan group element with all the sub-goal/plan items element details
    nodeElementPlanGroup = createSubGoalXML(servicePlanTemplateTreeDetails,
      nodeElementPlanGroup);

    // Read Child groups for plan group
    TemplatePlanGroupDetailsList templatePlanGroupDetailsList = planTemplatePlanGroupObj.searchChildPlanGroupsForTemplate(
      planTemplatePlanGroupKey);

    // If a sub plan group exists for this plan group, then call this method again to
    // list all the subgoals/groups for for each child plan group found
    // This will be done until there are no plan groups found.
    boolean planGroupsExist = false;

    if (templatePlanGroupDetailsList.dtls.size() > 0) {
      planGroupsExist = true;
    }
    while (planGroupsExist) {
      // Search until no more child plan groups found.
      planGroupsExist = false;
      for (int j = 0; j < templatePlanGroupDetailsList.dtls.size(); j++) {

        planTemplateTreePlanGroupDetails = new PlanTemplateTreePlanGroupDetails();

        planTemplateTreePlanGroupDetails.assign(
          templatePlanGroupDetailsList.dtls.item(j));
        // BEGIN, CR00292665, AKr
        planTemplatePlanGroupKey = new PlanTemplatePlanGroupKey();
        planTemplatePlanGroupKey.planTemplatePlanGroupID = planTemplateTreePlanGroupDetails.planTemplatePlanGroupID;
        final Long planGroupNameTextID = planTemplatePlanGroupObj.read(planTemplatePlanGroupKey).nameTextID;

        if (0 != planGroupNameTextID) {

          final LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
            planGroupNameTextID);

          planTemplateTreePlanGroupDetails.planTemplatePlanGroupName = localizableText.getValue(
            LOCALEEntry.get(
              ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
        }
        // END, CR00292665
        Element subPlanGroupElement = createPlanGroupXML(
          planTemplateTreePlanGroupDetails);

        nodeElementPlanGroup.addContent(subPlanGroupElement);
      }
    }
    return nodeElementPlanGroup;
  }

  // BEGIN, CR00047794, PMD
  // ___________________________________________________________________________
  /**
   * Creates an Element for a Milestone
   *
   * @param Element the parent Element
   * @param details the milestone details
   * @return Element the new milestone element
   */
  // BEGIN, CR00198672, VK
  protected Element createMilestoneXML(PlanTemplateMilestoneNameAndIDs details)
    throws AppException, InformationalException {
    // END, CR00198672
    // Build the milestone unique id for the tree control.
    // The unique id is built using its position in the tree
    // i.e. if a milestone has been created at the plan group level
    // the unique id is planTemplatePlanGroupID and the planTemplateMilestoneID
    // BEGIN, CR00069996, SK
    String milestoneUniqueID = XmlTreeConst.kPrefixmilestoneUniqueID;

    // END, CR00069996
    // BEGIN, CR00054810, PMD
    if (details.planTemplateSubGoalID != 0) {

      milestoneUniqueID = milestoneUniqueID
        + String.valueOf(details.planTemplateSubGoalID)
        + String.valueOf(details.planTemplateMilestoneID);

    } else if (details.planTemplatePlanGroupID != 0) {

      milestoneUniqueID = milestoneUniqueID
        + String.valueOf(details.planTemplatePlanGroupID)
        + String.valueOf(details.planTemplateMilestoneID);
    } else {

      milestoneUniqueID = milestoneUniqueID
        + String.valueOf(details.planTemplateID)
        + String.valueOf(details.planTemplateMilestoneID);
    }
    // END, CR00054810

    Element nodeElementMilestone = new Element(kNode, kNamespace);

    nodeElementMilestone.setAttribute(kID, milestoneUniqueID);
    nodeElementMilestone.setAttribute(kType, kMilestone);

    Element titleElementMilestone = new Element(kTitle, kNamespace);

    nodeElementMilestone.addContent(titleElementMilestone);
    titleElementMilestone.setText(details.name);

    Element paramValueElementMilestone = new Element(kParamValue, kNamespace);

    nodeElementMilestone.addContent(paramValueElementMilestone);

    paramValueElementMilestone.setAttribute(kName, kPlanTemplateMilestoneID).addContent(
      String.valueOf(details.planTemplateMilestoneID));

    if (stTheLastAccessedNode != null
      && stTheLastAccessedNode.equals(
        String.valueOf(details.planTemplateMilestoneID),
        TreeXMLNodeUtil.kPlanTemplateMilestone)) {

      stStartNodeId = milestoneUniqueID;
    }

    return nodeElementMilestone;
  }

  // ___________________________________________________________________________
  /**
   * Creates a node type element
   *
   * @param the node type to be created
   * @param the parameter to be used in the node type creation
   * @return The new node type element
   */
  // BEGIN, CR00198672, VK
  protected Element createNodeTypeElement(String nodeType, String nodeKey)
    throws AppException, InformationalException {
    // END, CR00198672
    Element nodeTypeElement = new Element(kNodeType, kNamespace);

    nodeTypeElement.setAttribute(kName, nodeType);

    Element actionsElement = new Element(kActions, kNamespace);

    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(kDefault, kView);

    Element actionElement = new Element(kAction, kNamespace);

    actionsElement.addContent(actionElement);
    actionElement.setAttribute(kName, kView);

    Element paramElement = new Element(kKey, kNamespace);

    actionElement.addContent(paramElement);
    paramElement.setAttribute(kName, nodeKey);

    return nodeTypeElement;
  }
  // END, CR00047794
}
