/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.serviceplans.sl.entity.struct.GoalOutcomeLinkDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Links an Outcome to a Goal.
 */
public abstract class GoalOutcomeLink extends curam.serviceplans.sl.entity.base.GoalOutcomeLink {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   * 
   * @param details
   *          GoalOutcomeLink details
   */
  protected void preinsert(GoalOutcomeLinkDtls details) throws AppException,
      InformationalException {
    //

  }
  
}
