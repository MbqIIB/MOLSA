/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;

import curam.serviceplans.sl.entity.fact.SPGDeliveryLinkFactory;
import curam.serviceplans.sl.entity.intf.SPGDeliveryLink;
import curam.serviceplans.sl.entity.struct.SPGDeliveryLinkDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryLinkKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * performs maintain functionality on Service Plan Group Delivery link records
 * 
 */
public abstract class MaintainSPGDeliveryLink extends
  curam.serviceplans.sl.base.MaintainSPGDeliveryLink {

  /**
   * creates a link record between the Service Plan Delivery and Service Plan
   * Group Delivery
   * 
   * @param SPGDeliveryLinkDtls
   *          the details of the Service Plan Delivery and Service Plan Group
   *          Delivery ids
   * @throws AppException
   * @throws InformationalException
   */
  public void createLink(SPGDeliveryLinkDtls dtls) 
    throws AppException, InformationalException {

    SPGDeliveryLink spgdLink = SPGDeliveryLinkFactory.newInstance();
    spgdLink.insert(dtls);
  }
  
  //____________________________________________________________________________
  /**
   * reads the link record
   * 
   * @param SPGDeliveryLinkKey
   *          the id of the link record
   * 
   * @return SPGDeliveryLinkDtls the link record details
   * @throws AppException
   * @throws InformationalException
   */
  public SPGDeliveryLinkDtls readLink(SPGDeliveryLinkKey key)
    throws AppException, InformationalException {
    SPGDeliveryLink spgdLink = SPGDeliveryLinkFactory.newInstance();
    return spgdLink.read(key);
  }

  //____________________________________________________________________________
  /**
   * deletes the link record
   * 
   * @param SPGDeliveryLinkKey
   *          the id of the link record
   * @throws AppException
   * @throws InformationalException         
   */
  public void removeLink(SPGDeliveryLinkKey key) 
    throws AppException, InformationalException {
    SPGDeliveryLink spgdLink = SPGDeliveryLinkFactory.newInstance();
    spgdLink.remove(key);
  }

}
