/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;

import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.ContractTextDtls;
import curam.core.sl.struct.Priority;
import curam.core.sl.struct.PriorityDetails;
import curam.message.BPOCONTRACTTEXT;
import curam.message.BPOPLANITEM;
import curam.message.GENERAL;
import curam.serviceplans.sl.entity.fact.ApprovalCriteriaFactory;
import curam.serviceplans.sl.entity.fact.GoodCauseFactory;
import curam.serviceplans.sl.entity.fact.PlanItemApprovalCriteriaLinkFactory;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlanItemGoodCauseLinkFactory;
import curam.serviceplans.sl.entity.fact.PlanItemOutcomeLinkFactory;
import curam.serviceplans.sl.entity.fact.TaskConfigurationFactory;
import curam.serviceplans.sl.entity.intf.ApprovalCriteria;
import curam.serviceplans.sl.entity.intf.GoodCause;
import curam.serviceplans.sl.entity.intf.PlanItemApprovalCriteriaLink;
import curam.serviceplans.sl.entity.intf.PlanItemGoodCauseLink;
import curam.serviceplans.sl.entity.intf.PlanItemOutcomeLink;
import curam.serviceplans.sl.entity.intf.TaskConfiguration;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaDtls;
import curam.serviceplans.sl.entity.struct.ApprovalCriteriaKey;
import curam.serviceplans.sl.entity.struct.GoodCauseDtls;
import curam.serviceplans.sl.entity.struct.OutcomeCountDetails;
import curam.serviceplans.sl.entity.struct.OutcomeDtls;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkCancelDetails;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkDetails;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkDetailsList;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkDtls;
import curam.serviceplans.sl.entity.struct.PlanItemContractTextCountKey;
import curam.serviceplans.sl.entity.struct.PlanItemContractTextDtls;
import curam.serviceplans.sl.entity.struct.PlanItemContractTextRemoveKey;
import curam.serviceplans.sl.entity.struct.PlanItemDescriptionTextID;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanItemGoodCauseLinkCountDetails;
import curam.serviceplans.sl.entity.struct.PlanItemGoodCauseLinkDtls;
import curam.serviceplans.sl.entity.struct.PlanItemOutcomeLinkDtls;
import curam.serviceplans.sl.entity.struct.PlanItemStatusDetails;
import curam.serviceplans.sl.entity.struct.SearchByPlanItemIDAndStatusKey;
import curam.serviceplans.sl.entity.struct.SearchByPlanItemIDStatusAndOccursWhenKey;
import curam.serviceplans.sl.entity.struct.SearchUnassociatedApprovalCriteriaForPlanItemKey;
import curam.serviceplans.sl.entity.struct.SearchUnassociatedGoodCausesForPlanItemKey;
import curam.serviceplans.sl.entity.struct.SearchUnassociatedOutcomesForPlanItemKey;
import curam.serviceplans.sl.entity.struct.TaskConfigurationDtls;
import curam.serviceplans.sl.entity.struct.TaskConfigurationKey;
import curam.serviceplans.sl.fact.PriorityHelperFactory;
import curam.serviceplans.sl.intf.PriorityHelper;
import curam.serviceplans.sl.struct.ApprovalCriteriaKeyList;
import curam.serviceplans.sl.struct.AssociatedTypeAndApprovalRequiredDetails;
import curam.serviceplans.sl.struct.ContractTextDetails;
import curam.serviceplans.sl.struct.ContractTextKey;
import curam.serviceplans.sl.struct.CreateContractTextDetails;
import curam.serviceplans.sl.struct.CreateOutcomeDetails;
import curam.serviceplans.sl.struct.GoodCauseCreateDetails;
import curam.serviceplans.sl.struct.GoodCauseKey;
import curam.serviceplans.sl.struct.GoodCauseKeyList;
import curam.serviceplans.sl.struct.ModifyContractTextDetails;
import curam.serviceplans.sl.struct.ModifyPlanItemDetails;
import curam.serviceplans.sl.struct.OrderPriorityDetails;
import curam.serviceplans.sl.struct.OutcomeKey;
import curam.serviceplans.sl.struct.OutcomeKeyList;
import curam.serviceplans.sl.struct.PlanItemApprovalCriteriaCancelDetails;
import curam.serviceplans.sl.struct.PlanItemApprovalCriteriaCreateDetails;
import curam.serviceplans.sl.struct.PlanItemApprovalCriteriaDetails;
import curam.serviceplans.sl.struct.PlanItemApprovalCriteriaDetailsList;
import curam.serviceplans.sl.struct.PlanItemApprovalCriteriaLinkKey;
import curam.serviceplans.sl.struct.PlanItemApprovalCriteriaLinkModifyDetails;
import curam.serviceplans.sl.struct.PlanItemCancelKey;
import curam.serviceplans.sl.struct.PlanItemContractTextDetailsList;
import curam.serviceplans.sl.struct.PlanItemDetailsList;
import curam.serviceplans.sl.struct.PlanItemGoodCauseDetailsList;
import curam.serviceplans.sl.struct.PlanItemGoodCauseKey;
import curam.serviceplans.sl.struct.PlanItemKey;
import curam.serviceplans.sl.struct.PlanItemNameDetails;
import curam.serviceplans.sl.struct.PlanItemNameIDDetailsList;
import curam.serviceplans.sl.struct.PlanItemOutcomeDetailsList;
import curam.serviceplans.sl.struct.PlanItemOutcomeKey;
import curam.serviceplans.sl.struct.PlanItemServiceUnitDetails;
import curam.serviceplans.sl.struct.PlanItemUnassociatedApprovalCriteriaDetailsList;
import curam.serviceplans.sl.struct.PlanItemUnassociatedGoodCauseDetailsList;
import curam.serviceplans.sl.struct.PlanItemUnassociatedOutcomeDetailsList;
import curam.serviceplans.sl.struct.PriorityDetailsList;
import curam.serviceplans.sl.struct.ProcessApprovalCriteriaPriorityDetails;
import curam.serviceplans.sl.struct.ReadPlanItemDetails;
import curam.serviceplans.sl.struct.RemovePlanItemContractTextKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.workspaceservices.localization.fact.TextTranslationFactory;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.intf.TextTranslation;
import curam.workspaceservices.localization.struct.LocalizableTextTranslationDetails;
import curam.workspaceservices.localization.struct.SearchByLocalizableTextIDKey;
import curam.workspaceservices.localization.struct.TextTranslationDtls;
import curam.workspaceservices.localization.struct.TextTranslationDtlsList;


public abstract class PlanItem extends curam.serviceplans.sl.base.PlanItem {

  // BEGIN, CR00234442, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Constructor for the class.
   */
  public PlanItem() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00234442

  /**
   * Cancels a plan item
   *
   * @param key
   * Identifies the plan item to be canceled.
   */
  public void cancel(PlanItemCancelKey key) throws AppException,
      InformationalException {

    // populate the cancel details
    curam.serviceplans.sl.entity.struct.PlanItemStatusDetails details = new curam.serviceplans.sl.entity.struct.PlanItemStatusDetails();

    details.recordStatus = RECORDSTATUS.CANCELLED;

    // cancel the planItem
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    planItemObj.cancel(key.key, details);

    // BEGIN, CR00161962, LJ
    // Delete the plan item links with the approval criteria
    cancelPlanItemApprovalCriteriaLink(key.key.planItemID);
    // END, CR00161962
  }

  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________
  /**
   * Cancel the plan item approval link before canceling the plan item.
   *
   * @param planItemID
   * the Plan Item ID
   *
   * @throws AppException
   * AppException
   * @throws InformationalException
   * InformationalException
   */
  protected void cancelPlanItemApprovalCriteriaLink(final long planItemID)
    throws AppException, InformationalException {

    PlanItemApprovalCriteriaLink piAppLinkObj = PlanItemApprovalCriteriaLinkFactory.newInstance();

    SearchByPlanItemIDAndStatusKey piAndStatusKey = new SearchByPlanItemIDAndStatusKey();

    piAndStatusKey.planItemID = planItemID;

    piAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    PlanItemApprovalCriteriaLinkDetailsList planItemApprovalCriteriaLinkDetailsList = piAppLinkObj.searchForPIApprovalCriteriaListDetails(
      piAndStatusKey);

    PlanItemApprovalCriteriaLinkDetails planItemApprovalCriteriaLinkDetails;

    // Loop through all the approval criteria linked
    // with this plan item and cancel it.
    for (int approvalLinkIter = 0; approvalLinkIter
      < planItemApprovalCriteriaLinkDetailsList.dtls.size(); approvalLinkIter++) {

      planItemApprovalCriteriaLinkDetails = planItemApprovalCriteriaLinkDetailsList.dtls.item(
        approvalLinkIter);

      curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkKey piLinkKey = new curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkKey();

      PlanItemApprovalCriteriaLinkCancelDetails linkDetails = new PlanItemApprovalCriteriaLinkCancelDetails();

      piLinkKey.planItemApprovalCriteriaLinkID = planItemApprovalCriteriaLinkDetails.planItemApprovalCriteriaLinkID;

      linkDetails.versionNo = planItemApprovalCriteriaLinkDetails.versionNo;

      linkDetails.recordStatus = RECORDSTATUS.CANCELLED;

      piAppLinkObj.cancel(piLinkKey, linkDetails);
    }
  }

  // END, CR00161962

  // BEGIN, CR00234077, TV
  // ___________________________________________________________________________
  /**
   * Creates a plan item.
   *
   * @param details
   * The plan item details.
   *
   * @deprecated Since Curam v6, replaced with {@link createPlanItem}.
   * Reason:- As per code line issue, the attribute
   * 'guidanceURL'and 'taskConfigID' removed from
   * 'CreatePlanItemDetails' struct and added into
   * 'PlanItemDetails' struct along with existing attribute of
   * 'CreatePlanItemDetails' struct.
   * See release note <CR00234077>
   */
  @Deprecated
  public curam.serviceplans.sl.struct.PlanItemKey create(
    curam.serviceplans.sl.struct.CreatePlanItemDetails details)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {

    // Populate the create details
    curam.serviceplans.sl.struct.PlanItemDetails planItemDetails = new curam.serviceplans.sl.struct.PlanItemDetails();

    // Assign attributes
    planItemDetails.assign(details);

    return createPlanItem(planItemDetails);
  }

  // END, CR00234077

  // ___________________________________________________________________________
  /**
   * Adds existing outcomes to a plan item.
   *
   * @param planItemKey
   * Identifies the planItem.
   * @param outcomeKeyList
   * The list of outcome IDs to be added to the planItem.
   */
  public void addExistingOutcomes(PlanItemKey planItemKey,
    OutcomeKeyList outcomeKeyList) throws AppException,
      InformationalException {

    // BEGIN CR00156191, SS
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    // read in the record status
    PlanItemStatusDetails planItemStatusDetails = planItemObj.readRecordStatus(
      planItemKey.key);

    // is the plan item already canceled?
    if (planItemStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_EXPECTED_OUTCOME_CANNOT_BE_ADDED_AS_PLAN_ITEM_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);

    }
    // END CR00156191
    // loop variables
    PlanItemOutcomeLink planItemOutcomeLinkObj = PlanItemOutcomeLinkFactory.newInstance();
    PlanItemOutcomeKey planItemOutcomeKey = new PlanItemOutcomeKey();

    // loop through all the outcomes
    for (int i = 0; i < outcomeKeyList.outcomeKey.size(); i++) {

      // validate that the outcome can be added to the planItem
      planItemOutcomeKey.planItemOutcomeKey.outcomeID = outcomeKeyList.outcomeKey.item(i).key.outcomeID;
      planItemOutcomeKey.planItemOutcomeKey.planItemID = planItemKey.key.planItemID;

      validateAddOutcome(planItemOutcomeKey);

      // add the outcome to the planItem
      PlanItemOutcomeLinkDtls planItemOutcomeLinkDtls = new PlanItemOutcomeLinkDtls();

      planItemOutcomeLinkDtls.planItemID = planItemKey.key.planItemID;
      planItemOutcomeLinkDtls.outcomeID = outcomeKeyList.outcomeKey.item(i).key.outcomeID;
      planItemOutcomeLinkObj.insert(planItemOutcomeLinkDtls);

    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a new outcome associated with a plan item.
   *
   * @param planItemKey
   * Identifies the associated planItem.
   * @param createOutcomeDetails
   * The new outcome details.
   *
   * @return The id of the new outcome.
   */
  public OutcomeKey createOutcome(PlanItemKey planItemKey,
    CreateOutcomeDetails createOutcomeDetails) throws AppException,
      InformationalException {

    // BEGIN CR00156191, SS
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    // read in the record status
    PlanItemStatusDetails planItemStatusDetails = planItemObj.readRecordStatus(
      planItemKey.key);

    // is the plan item already canceled?
    if (planItemStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_EXPECTED_OUTCOME_CANNOT_BE_ADDED_AS_PLAN_ITEM_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
    // END CR00156191
    //
    // create the outcome
    //

    // populate the details
    OutcomeDtls outcomeDtls = new OutcomeDtls();

    outcomeDtls.assign(createOutcomeDetails.createOutcomeDetails);

    // default the record status and creation date
    outcomeDtls.recordStatus = RECORDSTATUS.NORMAL;
    outcomeDtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // BEGIN, CR00234442, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!outcomeDtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(outcomeDtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      outcomeDtls.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      outcomeDtls.descriptionTextID = localizableTextHandler.store();
    }

    outcomeDtls.description = null;
    // END, CR00234442

    // create the outcome record
    curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();

    outcomeObj.insert(outcomeDtls);

    //
    // link the outcome to the planItem
    //

    // populate the link details
    PlanItemOutcomeLinkDtls planItemOutcomeLinkDtls = new PlanItemOutcomeLinkDtls();

    planItemOutcomeLinkDtls.planItemID = planItemKey.key.planItemID;
    planItemOutcomeLinkDtls.outcomeID = outcomeDtls.outcomeID;

    // insert the link
    curam.serviceplans.sl.entity.intf.PlanItemOutcomeLink planItemOutcomeLinkObj = curam.serviceplans.sl.entity.fact.PlanItemOutcomeLinkFactory.newInstance();

    planItemOutcomeLinkObj.insert(planItemOutcomeLinkDtls);

    //
    // return the new outcome id
    //

    OutcomeKey outcomeKey = new OutcomeKey();

    outcomeKey.key.outcomeID = outcomeDtls.outcomeID;
    return outcomeKey;

  }

  // ___________________________________________________________________________
  /**
   * Lists all planItems.
   *
   * @return The list of planItems.
   */
  public PlanItemDetailsList list() throws AppException, InformationalException {

    // read the list of planItems and populate them into the output struct
    curam.serviceplans.sl.entity.intf.PlanItem objPlanItem = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    PlanItemDetailsList planItemDetailsList = new PlanItemDetailsList();

    planItemDetailsList.dtls = objPlanItem.list();

    return planItemDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists the contract texts associated with a plan item.
   *
   * @param key
   * Identifies the planItem.
   *
   * @return The list of associated contract texts.
   */
  public PlanItemContractTextDetailsList listContractTexts(PlanItemKey key)
    throws AppException, InformationalException {

    // return object
    PlanItemContractTextDetailsList contractTextList = new PlanItemContractTextDetailsList();

    // read the list of contracts and populate the return object
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    contractTextList.dtls = planItemObj.searchContractTexts(key.key);

    return contractTextList;

  }

  // ___________________________________________________________________________
  /**
   * Lists the outcomes associated with a particular planItem.
   *
   * @param key
   * Identifies the planItem
   *
   * @return The list of associated outcomes.
   */
  public PlanItemOutcomeDetailsList listOutcomes(PlanItemKey key)
    throws AppException, InformationalException {

    // return object
    PlanItemOutcomeDetailsList outcomeList = new PlanItemOutcomeDetailsList();

    // read the outcome list and populate the return object
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    outcomeList.dtls = planItemObj.searchOutcomes(key.key);

    return outcomeList;

  }

  // ___________________________________________________________________________
  /**
   * Lists the outcomes not associated with a particular planItem.
   *
   * @param key
   * Identifies the planItem
   *
   * @return The list of unassociated outcomes.
   */
  public PlanItemUnassociatedOutcomeDetailsList listUnassociatedOutcomes(
    PlanItemKey key) throws AppException, InformationalException {

    // return object
    PlanItemUnassociatedOutcomeDetailsList unassociatedOutcomeList = new PlanItemUnassociatedOutcomeDetailsList();

    // populate the search key
    SearchUnassociatedOutcomesForPlanItemKey searchKey = new SearchUnassociatedOutcomesForPlanItemKey();

    searchKey.planItemID = key.key.planItemID;
    searchKey.outcomeRecordStatus = RECORDSTATUS.NORMAL;

    // read the list of unassociated outcomes
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    unassociatedOutcomeList.dtls = planItemObj.searchUnassociatedOutcomesByStatus(
      searchKey);

    return unassociatedOutcomeList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies a plan item.
   *
   * @param details
   * The modified details.
   */
  public void modify(ModifyPlanItemDetails details) throws AppException,
      InformationalException {

    // populate the modify details
    curam.serviceplans.sl.entity.struct.PlanItemKey key = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    key.planItemID = details.dtls.planItemID;

    // modify the planItem
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // BEGIN, CR00234442, GP
    // Modify localized description.
    long descriptionTextID;

    // Modify Localized description.
    if (0 == details.dtls.descriptionTextID) {

      if (!details.dtls.description.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(details.dtls.description,
          LOCALEEntry.get(
          (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
        descriptionTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        descriptionTextID = localizableTextHandler.store();
      }
      // Update the struct passed to modify().
      details.dtls.descriptionTextID = descriptionTextID;

    } else {

      // Handling New data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        details.dtls.descriptionTextID);

      localizableTextHandler.addValue(details.dtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      localizableTextHandler.store();

    }

    details.dtls.description = null;
    // END, CR00234442


    planItemObj.modify(key, details.dtls);

  }

  // ___________________________________________________________________________
  /**
   * Reads a plan item's details.
   *
   * @param key
   * Identifies the planItem.
   *
   * @return The plan item details.
   */
  public ReadPlanItemDetails read(PlanItemKey key) throws AppException,
      InformationalException {

    // read the plan item details
    curam.serviceplans.sl.entity.intf.PlanItem objPlanItem = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    ReadPlanItemDetails readPlanItemDetails = new ReadPlanItemDetails();

    readPlanItemDetails.dtls = objPlanItem.read(key.key);
    // BEGIN, CR00161962, LJ
    readPlanItemDetails.taskConfigDtls = readTaskConfigurationDetails(key);
    // END, CR00161962

    // BEGIN, CR00234442, GP
    // Read the localized description.
    if (0 != readPlanItemDetails.dtls.descriptionTextID) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        readPlanItemDetails.dtls.descriptionTextID);

      readPlanItemDetails.dtls.description = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00234442

    return readPlanItemDetails;
  }

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * This method is used to check if the task configuration exists for the plan
   * item. If it exists it fetches the task configuration details.
   *
   * @param key
   * PlanItemKey
   * @return the task configuration details
   * @throws InformationalException
   * InformationalException
   * @throws AppException
   * AppException
   */
  public TaskConfigurationDtls readTaskConfigurationDetails(PlanItemKey key)
    throws AppException, InformationalException {

    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = PlanItemFactory.newInstance();
    PlanItemDtls planItemDtls = planItemObj.read(key.key);
    TaskConfiguration piTaskConfigObj = TaskConfigurationFactory.newInstance();
    TaskConfigurationKey piTaskConfigKey = new TaskConfigurationKey();

    piTaskConfigKey.taskConfigurationID = planItemDtls.taskConfigID;
    TaskConfigurationDtls piTaskConfigurationDtls = null;

    if (planItemDtls.taskConfigID != 0) {
      piTaskConfigurationDtls = piTaskConfigObj.read(piTaskConfigKey);
    } else {
      piTaskConfigurationDtls = new TaskConfigurationDtls();
    }
    return piTaskConfigurationDtls;
  }

  // END, CR00161962
  // ___________________________________________________________________________
  /**
   * Reads contract text details.
   *
   * @param key
   * Identifies contract text
   *
   * @return Contract text details
   */
  public ContractTextDetails readContractText(ContractTextKey key)
    throws AppException, InformationalException {

    // return object
    ContractTextDetails contractTextDetails = new ContractTextDetails();

    // read the contract text entity(now moved to core)
    curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();

    // populate the output details
    contractTextDetails.assign(contractTextObj.read(key.contractTextKey, false));

    return contractTextDetails;

  }

  // ___________________________________________________________________________
  /**
   * Creates a contract text for the planItem.
   *
   * @param planItemKey
   * Identifies the planItem
   * @param createContractTextDetails
   * The new contract text details.
   *
   * @return The ID of the contract text
   */
  public ContractTextKey createContractText(PlanItemKey planItemKey,
    CreateContractTextDetails createContractTextDetails) throws AppException,
      InformationalException {

    // BEGIN CR00156191, SS
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    // read in the record status
    PlanItemStatusDetails planItemStatusDetails = planItemObj.readRecordStatus(
      planItemKey.key);

    // is the plan item already canceled?
    if (planItemStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_CONTRACT_TEXT_CANNOT_BE_ADDED_AS_PLAN_ITEM_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
    // END CR00156191

    // check that the contract text can be added
    validateAddContractText(planItemKey, createContractTextDetails);

    //
    // add the contract text and link it to the planItem
    //

    // insert the contract text record
    curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();
    ContractTextDtls contractTextDtls = new ContractTextDtls();

    contractTextDtls.contractText = createContractTextDetails.contractText;
    contractTextDtls.languageCode = createContractTextDetails.languageCode;
    contractTextDtls.recordStatus = RECORDSTATUS.NORMAL;
    // populate the contract text type
    contractTextDtls.typeCode = curam.codetable.CONTRACTTEXTTYPE.SERVICEPLANS;
    contractTextObj.insert(contractTextDtls);

    // add the plan item contract text link
    PlanItemContractTextDtls planItemContractTextDtls = new PlanItemContractTextDtls();

    planItemContractTextDtls.planItemID = planItemKey.key.planItemID;
    planItemContractTextDtls.contractTextID = contractTextDtls.contractTextID;
    curam.serviceplans.sl.entity.intf.PlanItemContractText planItemContractTextObj = curam.serviceplans.sl.entity.fact.PlanItemContractTextFactory.newInstance();

    planItemContractTextObj.insert(planItemContractTextDtls);

    // return the contract text id
    ContractTextKey contractTextKey = new ContractTextKey();

    contractTextKey.contractTextKey.contractTextID = contractTextDtls.contractTextID;
    return contractTextKey;

  }

  // ___________________________________________________________________________
  /**
   * Modifies plan item contract text
   *
   * @param modifyDetails
   * details of the contract text to be modified
   */
  public void modifyContractText(ModifyContractTextDetails modifyDetails)
    throws AppException, InformationalException {
    // BEGIN CR00156191, SS
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    // read in the record status
    PlanItemStatusDetails planItemStatusDetails = planItemObj.readRecordStatus(
      modifyDetails.planItemKey);

    // is the plan item already canceled?
    if (planItemStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_CONTRACT_TEXT_CANNOT_BE_MODIFIED_AS_PLAN_ITEM_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
    // END CR00156191
    // populate the key
    curam.core.sl.entity.struct.ContractTextKey key = new curam.core.sl.entity.struct.ContractTextKey();

    key.contractTextID = modifyDetails.dtls.contractTextID;

    // populate the details
    curam.core.sl.entity.struct.ModifyContractTextDetails details = new curam.core.sl.entity.struct.ModifyContractTextDetails();

    details.contractText = modifyDetails.dtls.contractText;
    details.versionNo = modifyDetails.dtls.versionNo;

    // modify the details
    curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();

    contractTextObj.modify(key, details);

  }

  // ___________________________________________________________________________
  /**
   * Removes contract text for a plan item
   *
   * @param key
   * Identifies the contract text
   */
  public void removeContractText(RemovePlanItemContractTextKey key)
    throws AppException, InformationalException {
    // BEGIN CR00156191, SS
    curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    planItemKey.planItemID = key.planItemID;
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    // read in the record status
    PlanItemStatusDetails planItemStatusDetails = planItemObj.readRecordStatus(
      planItemKey);

    // is the plan item already canceled?
    if (planItemStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_CONTRACT_TEXT_CANNOT_BE_DELETED_AS_PLAN_ITEM_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
    // END CR00156191
    //
    // remove the plan item - contract text link
    //

    // populate the plan item contract text key
    PlanItemContractTextRemoveKey linkKey = new PlanItemContractTextRemoveKey();

    linkKey.planItemID = key.planItemID;
    linkKey.contractTextID = key.contractTextID;

    // remove the link between the plan item and the contract text
    curam.serviceplans.sl.entity.intf.PlanItemContractText planItemContractTextObj = curam.serviceplans.sl.entity.fact.PlanItemContractTextFactory.newInstance();

    planItemContractTextObj.removeByPlanItemIDAndContractTextID(linkKey);

    //
    // cancel the contract text record
    //

    // cancel structs
    curam.core.sl.entity.struct.ContractTextKey contractTextKey = new curam.core.sl.entity.struct.ContractTextKey();
    curam.core.sl.entity.struct.CancelContractTextDetails cancelContractTextDetails = new curam.core.sl.entity.struct.CancelContractTextDetails();

    // populate the cancel details
    contractTextKey.contractTextID = key.contractTextID;
    cancelContractTextDetails.recordStatus = RECORDSTATUS.CANCELLED;
    cancelContractTextDetails.versionNo = key.contractTextVersionNo;

    // cancel the contract text
    curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();

    contractTextObj.cancel(contractTextKey, cancelContractTextDetails);

  }

  // ___________________________________________________________________________
  /**
   * Removes outcome for a plan item
   *
   * @param planItemOutcomeKey
   * Identifies the plan item and the outcome
   */
  public void removeOutcome(PlanItemOutcomeKey planItemOutcomeKey)
    throws AppException, InformationalException {

    // BEGIN CR00156191, SS
    curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    planItemKey.planItemID = planItemOutcomeKey.planItemOutcomeKey.planItemID;

    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    // read in the record status
    PlanItemStatusDetails planItemStatusDetails = planItemObj.readRecordStatus(
      planItemKey);

    // is the plan item already canceled?
    if (planItemStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      throw new AppException(
        BPOPLANITEM.ERR_EXPECTED_OUTCOME_CANNOT_BE_REMOVED_AS_PLAN_ITEM_CANCELLED);

    }
    // END CR00156191
    // PlanItemOutcomeLink entity
    PlanItemOutcomeLink planItemOutcomeLink = PlanItemOutcomeLinkFactory.newInstance();

    // remove the link between the plan item and outcome
    planItemOutcomeLink.removeByPlanItemIDAndOutcomeID(
      planItemOutcomeKey.planItemOutcomeKey);

  }

  // ___________________________________________________________________________
  /**
   * Validates that an outcome can be added to a plan item, i.e. that it is not
   * already associated with the planItem.
   *
   * @param planItemOutcomeKey
   * Identifies the planItem and outcome.
   */
  @Override
  public void validateAddOutcome(PlanItemOutcomeKey planItemOutcomeKey)
    throws AppException, InformationalException {

    // PlanItemOutcomeLink entity
    PlanItemOutcomeLink planItemOutcomeLinkObj = PlanItemOutcomeLinkFactory.newInstance();

    // OutcomeKey
    curam.serviceplans.sl.entity.struct.OutcomeKey outcomeKey = new curam.serviceplans.sl.entity.struct.OutcomeKey();

    // count the number of existing associations between the plan item and
    // outcome
    OutcomeCountDetails countDetails = planItemOutcomeLinkObj.countByPlanItemIDAndOutcomeID(
      planItemOutcomeKey.planItemOutcomeKey);

    // is the outcome already linked to the planItem?
    if (countDetails.recordCount > 0) {

      // get the outcome name
      curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();

      outcomeKey.outcomeID = planItemOutcomeKey.planItemOutcomeKey.outcomeID;

      curam.serviceplans.sl.entity.struct.OutcomeNameDetails outcomeNameDetails = outcomeObj.readName(
        outcomeKey);

      // throw an exception indicating the name of the outcome which
      // caused the problem
      AppException e = new AppException(
        BPOPLANITEM.ERR_PLAN_ITEM_XFV_OUTCOME_EXISTS);

      e.arg(outcomeNameDetails.name);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Validates that a contract text can be created for a plan item, the planItem
   * cannot already have a contract text in the same language.
   *
   * @param planItemKey
   * Identifies the planItem.
   * @param createContractTextDetails
   * The new contract text details.
   */
  @Override
  public void validateAddContractText(PlanItemKey planItemKey,
    CreateContractTextDetails createContractTextDetails) throws AppException,
      InformationalException {

    //
    // check that the plan item doesn't already have a contract in the same
    // language as the new contract
    //

    // check that the language code has been specified
    if (createContractTextDetails.languageCode.length() < 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOCONTRACTTEXT.ERR_LANGUAGECODE_FV_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);

    }

    // set up the count key
    PlanItemContractTextCountKey planItemContractTextCountKey = new PlanItemContractTextCountKey();

    planItemContractTextCountKey.planItemID = planItemKey.key.planItemID;
    planItemContractTextCountKey.languageCode = createContractTextDetails.languageCode;
    planItemContractTextCountKey.recordStatus = RECORDSTATUS.NORMAL;

    // count the number of active contracts for this plan item in the same
    // language
    curam.serviceplans.sl.entity.intf.PlanItemContractText planItemContractTextObj = curam.serviceplans.sl.entity.fact.PlanItemContractTextFactory.newInstance();
    curam.serviceplans.sl.entity.struct.ContractTextCountDetails contractTextCountDetails = planItemContractTextObj.countByPlanItemIDLanguageAndRecordStatus(
      planItemContractTextCountKey);

    // is there already a contract in the same language as the new contract?
    if (contractTextCountDetails.numContractTexts > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_PLAN_ITEM_XFV_CONTRACTTEXT_EXISTS_FOR_LANGUAGE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Reads plan item name.
   *
   * @param key
   * PlanItem unique identifier
   * @return PlanItem name
   */
  public PlanItemNameDetails readName(PlanItemKey key) throws AppException,
      InformationalException {

    // return value
    PlanItemNameDetails planItemNameDetails = new PlanItemNameDetails();

    // PlanItem entity manipulation variables
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // read plan item name
    planItemNameDetails.planItemNameDetails = planItemObj.readName(key.key);

    // return outcome name
    return planItemNameDetails;

  }

  // ___________________________________________________________________________
  /**
   * Adds existing good causes to a plan item.
   *
   * @param planItemKey
   * Identifies the planItem.
   * @param goodCauseKeyList
   * The list of good cause IDs to be added to the planItem.
   */
  public void addExistingGoodCauses(PlanItemKey planItemKey,
    GoodCauseKeyList goodCauseKeyList) throws AppException,
      InformationalException {
    // BEGIN CR00156191, SS
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    // read in the record status
    PlanItemStatusDetails planItemStatusDetails = planItemObj.readRecordStatus(
      planItemKey.key);

    // is the plan item already canceled?
    if (planItemStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      throw new AppException(
        BPOPLANITEM.ERR_GOOD_CAUSE_CANNOT_BE_ADDED_AS_PLAN_ITEM_CANCELLED);

    }
    // END CR00156191, SS

    // PlanItemGoodCauseLink entity and details
    PlanItemGoodCauseLink planItemGoodCauseLinkObj = PlanItemGoodCauseLinkFactory.newInstance();
    PlanItemGoodCauseLinkDtls planItemGoodCauseLinkDtls;

    // PlanItemGoodCauseKey
    PlanItemGoodCauseKey planItemGoodCauseKey = new PlanItemGoodCauseKey();

    // loop through all the good causes
    for (int i = 0; i < goodCauseKeyList.goodCauseKey.size(); i++) {

      // validate that the outcome can be added to the planItem
      planItemGoodCauseKey.planItemGoodCauseKey.goodCauseID = goodCauseKeyList.goodCauseKey.item(i).goodCauseKey.goodCauseID;
      planItemGoodCauseKey.planItemGoodCauseKey.planItemID = planItemKey.key.planItemID;

      validateAddGoodCause(planItemGoodCauseKey);

      // add the good cause to the planItem
      planItemGoodCauseLinkDtls = new PlanItemGoodCauseLinkDtls();

      planItemGoodCauseLinkDtls.planItemID = planItemKey.key.planItemID;
      planItemGoodCauseLinkDtls.goodCauseID = goodCauseKeyList.goodCauseKey.item(i).goodCauseKey.goodCauseID;
      planItemGoodCauseLinkObj.insert(planItemGoodCauseLinkDtls);

    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a new good cause associated with a plan item.
   *
   * @param planItemKey
   * Identifies the associated planItem.
   * @param goodCauseCreateDetails
   * The new good cause details.
   *
   * @return The id of the new good cause.
   */
  public GoodCauseKey createGoodCause(PlanItemKey planItemKey,
    GoodCauseCreateDetails goodCauseCreateDetails) throws AppException,
      InformationalException {

    // BEGIN CR00156191, SS
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    // read in the record status
    PlanItemStatusDetails planItemStatusDetails = planItemObj.readRecordStatus(
      planItemKey.key);

    // is the plan item already canceled?
    if (planItemStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      throw new AppException(
        BPOPLANITEM.ERR_GOOD_CAUSE_CANNOT_BE_ADDED_AS_PLAN_ITEM_CANCELLED);

    }
    // END CR00156191
    // return value
    GoodCauseKey goodCauseKey = new GoodCauseKey();

    // populate the good cause details
    GoodCauseDtls goodCauseDtls = new GoodCauseDtls();

    goodCauseDtls.assign(goodCauseCreateDetails);

    // default the record status and creation date
    goodCauseDtls.recordStatus = RECORDSTATUS.NORMAL;
    goodCauseDtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // BEGIN, CR00234442, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!goodCauseDtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(goodCauseDtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      goodCauseDtls.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      goodCauseDtls.descriptionTextID = localizableTextHandler.store();
    }

    goodCauseDtls.description = null;
    // END, CR00234442

    // create the good cause record
    GoodCause goodCauseObj = GoodCauseFactory.newInstance();

    goodCauseObj.insert(goodCauseDtls);

    // populate the link details
    PlanItemGoodCauseLinkDtls planItemGoodCauseLinkDtls = new PlanItemGoodCauseLinkDtls();

    planItemGoodCauseLinkDtls.planItemID = planItemKey.key.planItemID;
    planItemGoodCauseLinkDtls.goodCauseID = goodCauseDtls.goodCauseID;

    // insert the link
    PlanItemGoodCauseLink planItemGoodCauseLinkObj = PlanItemGoodCauseLinkFactory.newInstance();

    planItemGoodCauseLinkObj.insert(planItemGoodCauseLinkDtls);

    // return the new good cause identifier
    goodCauseKey.goodCauseKey.goodCauseID = goodCauseDtls.goodCauseID;

    return goodCauseKey;

  }

  // ___________________________________________________________________________
  /**
   * Lists the good causes associated with a particular planItem.
   *
   * @param key
   * Identifies the planItem
   *
   * @return The list of associated good causes.
   */
  public PlanItemGoodCauseDetailsList listGoodCauses(PlanItemKey key)
    throws AppException, InformationalException {

    // return object
    PlanItemGoodCauseDetailsList planItemGoodCauseDetailsList = new PlanItemGoodCauseDetailsList();

    // PlanItem entity
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // read the good cause list and populate the return object
    planItemGoodCauseDetailsList.planItemGoodCauseDetailsList = planItemObj.searchGoodCauses(
      key.key);

    return planItemGoodCauseDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Lists the good causes not associated with a particular planItem.
   *
   * @param key
   * Identifies the planItem.
   *
   * @return The list of unassociated good causes.
   */
  public PlanItemUnassociatedGoodCauseDetailsList listUnassociatedGoodCauses(
    PlanItemKey key) throws AppException, InformationalException {

    // PlanItem entity
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // return object
    PlanItemUnassociatedGoodCauseDetailsList planItemUnassociatedGoodCauseDetailsList = new PlanItemUnassociatedGoodCauseDetailsList();

    // populate the search key
    SearchUnassociatedGoodCausesForPlanItemKey searchKey = new SearchUnassociatedGoodCausesForPlanItemKey();

    searchKey.planItemID = key.key.planItemID;
    searchKey.goodCauseRecordStatus = RECORDSTATUS.NORMAL;

    // read the list of unassociated good causes
    planItemUnassociatedGoodCauseDetailsList.planItemUnassociatedGoodCauseDetailsList = planItemObj.searchUnassociatedGoodCausesByStatus(
      searchKey);

    return planItemUnassociatedGoodCauseDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Removes good cause for a plan item
   *
   * @param key
   * Identifies the plan item and the good cause
   */
  public void removeGoodCause(PlanItemGoodCauseKey key) throws AppException,
      InformationalException {

    // BEGIN CR00156191, SS
    curam.serviceplans.sl.entity.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.entity.struct.PlanItemKey();

    planItemKey.planItemID = key.planItemGoodCauseKey.planItemID;

    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    // read in the record status
    PlanItemStatusDetails planItemStatusDetails = planItemObj.readRecordStatus(
      planItemKey);

    // is the plan item already canceled?
    if (planItemStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      throw new AppException(
        BPOPLANITEM.ERR_GOOD_CAUSE_CANNOT_BE_REMOVED_AS_PLAN_ITEM_CANCELLED);

    }
    // END CR00156191
    // PlanItemGoodCauseLink entity
    PlanItemGoodCauseLink planItemGoodCauseLink = PlanItemGoodCauseLinkFactory.newInstance();

    // remove the link between the plan item and good cause
    planItemGoodCauseLink.removeByPlanItemIDAndGoodCauseID(
      key.planItemGoodCauseKey);
  }

  // ___________________________________________________________________________
  /**
   * Validates that a good cause can be added to a plan item, i.e. that it is
   * not already associated with the planItem.
   *
   * @param key
   * Identifies the planItem and good cause.
   */
  @Override
  protected void validateAddGoodCause(PlanItemGoodCauseKey key)
    throws AppException, InformationalException {

    // PlanItem entity
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // GoodCauseKey
    curam.serviceplans.sl.entity.struct.GoodCauseKey goodCauseKey = new curam.serviceplans.sl.entity.struct.GoodCauseKey();

    // count the number of existing associations between the plan item and
    // the good cause
    PlanItemGoodCauseLinkCountDetails planItemGoodCauseLinkCountDetails = planItemObj.countGoodCausesByGoodCauseID(
      key.planItemGoodCauseKey);

    // is the good cause already linked to the planItem?
    if (planItemGoodCauseLinkCountDetails.recordCount > 0) {

      // get the good cause name
      curam.serviceplans.sl.entity.intf.GoodCause goodCauseObj = curam.serviceplans.sl.entity.fact.GoodCauseFactory.newInstance();

      goodCauseKey.goodCauseID = key.planItemGoodCauseKey.goodCauseID;

      curam.serviceplans.sl.entity.struct.GoodCauseNameDetails goodCauseNameDetails = goodCauseObj.readName(
        goodCauseKey);

      // throw an exception indicating the name of the outcome which
      // caused the problem
      AppException e = new AppException(
        BPOPLANITEM.ERR_PLAN_ITEM_XFV_GOOD_CAUSE_EXISTS);

      e.arg(goodCauseNameDetails.name);
      throw e;

    }

  }

  // ___________________________________________________________________________
  /**
   * Reads associated type.
   *
   * @param key
   * Identifies the action.
   *
   * @return associated type and approval required indicator
   */
  public AssociatedTypeAndApprovalRequiredDetails readAssociatedTypeAndApprovalRequestDetails(
    PlanItemKey key) throws AppException, InformationalException {

    // Return value
    AssociatedTypeAndApprovalRequiredDetails associatedTypeAndApprovalRequiredDetails = new AssociatedTypeAndApprovalRequiredDetails();

    // Action Object
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // read associated type
    associatedTypeAndApprovalRequiredDetails.dtls = planItemObj.readAssociatedTypeAndApprovalRequired(
      key.key);

    // return associated type
    return associatedTypeAndApprovalRequiredDetails;
  }

  // BEGIN, CR00000061, CM
  // ___________________________________________________________________________
  /**
   * Reads a plan item's details.
   *
   * @param key
   * Identifies the planItem.
   *
   * @return The plan item details.
   */
  public PlanItemServiceUnitDetails readPlanItemServiceUnitDeliveryDetails(
    PlanItemKey key) throws AppException, InformationalException {

    // read the plan item details
    curam.serviceplans.sl.entity.intf.PlanItem objPlanItem = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    PlanItemServiceUnitDetails planItemServiceUnitDetails = new PlanItemServiceUnitDetails();

    planItemServiceUnitDetails.dtls = objPlanItem.readPlanItemServiceUnitDeliveryDetails(
      key.key);

    return planItemServiceUnitDetails;
  }

  // END, CR00000061

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method for obtaining the list of approval criteria for a specific plan
   * item.
   *
   * @param PlanItemKey
   * - ID of the plan item
   * @return a list of all approval criteria for a plan item
   */
  public PlanItemApprovalCriteriaDetailsList listApprovalCriteria(
    PlanItemKey key) throws AppException, InformationalException {

    // Create return struct
    PlanItemApprovalCriteriaDetailsList planItemApprovalCriteriaList = new PlanItemApprovalCriteriaDetailsList();

    // Create entity object instance
    PlanItemApprovalCriteriaLink planItemApprovalCriteriaLinkObj = PlanItemApprovalCriteriaLinkFactory.newInstance();

    // Create key struct and populate attributes
    SearchByPlanItemIDAndStatusKey searchByPlanItemIDAndStatusKey = new SearchByPlanItemIDAndStatusKey();

    searchByPlanItemIDAndStatusKey.planItemID = key.key.planItemID;
    searchByPlanItemIDAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // Make call to obtain list
    planItemApprovalCriteriaList.dtlsList = planItemApprovalCriteriaLinkObj.searchForPIApprovalCriteriaListDetails(
      searchByPlanItemIDAndStatusKey);

    // Return result
    return planItemApprovalCriteriaList;

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // _____________________________________________________________________________
  /**
   * Method for adding one or more existing approval criteria to a specific plan
   * item.
   *
   * @param key
   * ID of the plan item
   * @param keyList
   * key list of approval criteria to associate to plan item
   */
  public void addExistingApprovalCriteria(PlanItemKey key,
    ApprovalCriteriaKeyList keyList) throws AppException,
      InformationalException {

    // Create PlanItemApprovalCriteriaLink entity and details
    PlanItemApprovalCriteriaLink planItemApprovalCriteriaLinkObj = PlanItemApprovalCriteriaLinkFactory.newInstance();

    // Create Plan Item Approval Criteria Link details struct
    PlanItemApprovalCriteriaLinkDtls planItemApprovalCriteriaLinkDtls;

    // Create ApprovalCriteria entity and key, details structs
    ApprovalCriteria approvalCriteriaObj = ApprovalCriteriaFactory.newInstance();

    // Create Approval Criteria Key struct
    ApprovalCriteriaKey approvalCriteriaKey = new ApprovalCriteriaKey();

    // Create Approval Criteria Details struct
    ApprovalCriteriaDtls approvalCriteriaDtls = new ApprovalCriteriaDtls();

    // Create plan item approval criteria create details struct
    // - used in processing priority
    PlanItemApprovalCriteriaCreateDetails planItemAppCriteriaCreateDtls = new PlanItemApprovalCriteriaCreateDetails();

    // Get number of the approval criteria to add
    int approvalCriteriaListSize = keyList.approvalCriteriaKey.size();

    // Loop through all the approval criteria
    for (int i = 0; i < approvalCriteriaListSize; i++) {

      // Set the approvalCriteria key
      approvalCriteriaKey.approvalCriteriaID = keyList.approvalCriteriaKey.item(i).approvalCriteriaID;

      // Perform the read of approval criteria details
      approvalCriteriaDtls = approvalCriteriaObj.read(approvalCriteriaKey);

      // Set create attribute details struct for priority processing
      planItemAppCriteriaCreateDtls.createDtls.assignNextPriority = false;
      planItemAppCriteriaCreateDtls.planItemID = key.key.planItemID;
      planItemAppCriteriaCreateDtls.createDtls.dtls.priority = approvalCriteriaDtls.priority;
      planItemAppCriteriaCreateDtls.createDtls.dtls.occursWhen = approvalCriteriaDtls.occursWhen;

      // Create link details struct and set attributes
      planItemApprovalCriteriaLinkDtls = new PlanItemApprovalCriteriaLinkDtls();

      planItemApprovalCriteriaLinkDtls.planItemID = key.key.planItemID;
      planItemApprovalCriteriaLinkDtls.approvalCriteriaID = keyList.approvalCriteriaKey.item(i).approvalCriteriaID;
      planItemApprovalCriteriaLinkDtls.occursWhen = approvalCriteriaDtls.occursWhen;

      // Get priority
      planItemApprovalCriteriaLinkDtls.priority = getPriorityForApprovalCriteriaLinkRecord(planItemAppCriteriaCreateDtls).dtls.priority;

      planItemApprovalCriteriaLinkDtls.description = approvalCriteriaDtls.description;
      planItemApprovalCriteriaLinkDtls.recordStatus = RECORDSTATUS.NORMAL;

      // Insert link record into entity
      planItemApprovalCriteriaLinkObj.insert(planItemApprovalCriteriaLinkDtls);

    }

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method for obtaining the priority for details to be used for creating a new
   * plan item approval criteria link record.
   *
   * @param details
   * details of the plan item approval criteria
   * @return priority
   */

  public Priority getPriorityForApprovalCriteriaLinkRecord(
    PlanItemApprovalCriteriaCreateDetails details) throws AppException,
      InformationalException {

    // Create structs to manipulate and process priorities
    ProcessApprovalCriteriaPriorityDetails processPriorityDetails = new ProcessApprovalCriteriaPriorityDetails();

    // Create return struct
    Priority priority = new Priority();

    // Create priority manipulation struct
    PriorityDetailsList priorityDetailsList = new PriorityDetailsList();

    // Create plan item key to read other approval criteria associated to it
    PlanItemKey planItemKey = new PlanItemKey();

    // Set plan item key
    planItemKey.key.planItemID = details.planItemID;

    // Create plan item approval criteria entity manipulation variable.
    PlanItemApprovalCriteriaLink planItemApprovalCriteriaLinkObj = PlanItemApprovalCriteriaLinkFactory.newInstance();

    // Create priority manipulation helper objects
    PriorityHelper priorityHelperObj = PriorityHelperFactory.newInstance();

    // Create search approval criteria link struct
    SearchByPlanItemIDStatusAndOccursWhenKey planItemIDStatusOccursWhenSearchKey = new SearchByPlanItemIDStatusAndOccursWhenKey();

    planItemIDStatusOccursWhenSearchKey.planItemID = planItemKey.key.planItemID;
    planItemIDStatusOccursWhenSearchKey.recordStatus = RECORDSTATUS.NORMAL;
    planItemIDStatusOccursWhenSearchKey.occursWhen = details.createDtls.dtls.occursWhen;

    // Read all plan item approval criteria records for this specific plan item
    priorityDetailsList.assign(
      planItemApprovalCriteriaLinkObj.searchForIDAndPriorityDetailsList(
        planItemIDStatusOccursWhenSearchKey));

    // Set size of the priority details list
    int planItemApprovalCriteriaLinkSize = priorityDetailsList.dtls.size();

    // If no records exist in the list and assign next priority
    // has been selected, return priority to have a value of one
    if (planItemApprovalCriteriaLinkSize == 0) {

      if (details.createDtls.assignNextPriority) {

        // Set priority to be one
        priority.dtls.priority = 1;

      } else {
        // No records in list but user entered a priority
        // Just use that one - please note that it might not be 1
        priority.dtls.priority = details.createDtls.dtls.priority;

      }
    } else {
      // There are records in the list
      // i.e. existing plan item approval criteria link records

      // Check for the assignNextPriority indicator
      if (details.createDtls.assignNextPriority) {

        // Create details for the existing entry
        OrderPriorityDetails currentDetails = new OrderPriorityDetails();

        currentDetails.priority = details.createDtls.dtls.priority;
        currentDetails.recordKeyID = details.createDtls.dtls.approvalCriteriaID;
        currentDetails.versionNo = details.createDtls.dtls.versionNo;

        // Given the current list of priority details, get the next one
        priority = priorityHelperObj.getNextPriority(priorityDetailsList,
          currentDetails);

      } else {
        // Records in the list and user entered a priority
        // Need to check to see if the list needs
        // re-ordering in terms of priority

        // Populate details struct to process priority
        // PlanItemApprovalCriteriaLinkID will
        // be zero when creating a new record
        processPriorityDetails.planItemApprovalCriteriaLinkID = 0;
        processPriorityDetails.assignNextPriorityInd = details.createDtls.assignNextPriority;
        processPriorityDetails.priority = details.createDtls.dtls.priority;
        processPriorityDetails.planItemID = details.planItemID;

        // Process existing priorities
        priority = processApprovalCriteriaPriority(processPriorityDetails,
          priorityDetailsList);

      }
    }

    // Return priority
    return priority;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method for creating a new approval criteria and then linking it to a
   * specific plan item.
   *
   * @param details
   * details of the approval criteria to create and line item to
   * associate it to
   * @return key of the newly created criteria
   */
  public PlanItemApprovalCriteriaLinkKey createApprovalCriteria(
    PlanItemApprovalCriteriaCreateDetails details) throws AppException,
      InformationalException {

    // Create plan item approval criteria entity manipulation variable.
    PlanItemApprovalCriteriaLink planItemApprovalCriteriaLinkObj = PlanItemApprovalCriteriaLinkFactory.newInstance();

    // Create return struct
    PlanItemApprovalCriteriaLinkKey planItemApprovalCriteriaLinkKey = new PlanItemApprovalCriteriaLinkKey();

    // Create Approval Criteria service layer manipulation objects
    curam.serviceplans.sl.intf.ApprovalCriteria approvalCriteriaObj = curam.serviceplans.sl.fact.ApprovalCriteriaFactory.newInstance();

    // Call appropriate service layer to make
    // the insert into Approval Criteria entity
    approvalCriteriaObj.createApprovalCriteria(details.createDtls);

    // Now, create the link between the newly
    // created approval criteria and the plan item
    // Create Plan Item Approval Criteria Link manipulation objects
    PlanItemApprovalCriteriaLinkDtls planItemApprovalCriteriaLinkDtls = new PlanItemApprovalCriteriaLinkDtls();

    // Set the attributes
    planItemApprovalCriteriaLinkDtls.planItemID = details.planItemID;
    planItemApprovalCriteriaLinkDtls.approvalCriteriaID = details.createDtls.dtls.approvalCriteriaID;
    planItemApprovalCriteriaLinkDtls.occursWhen = details.createDtls.dtls.occursWhen;
    planItemApprovalCriteriaLinkDtls.priority = getPriorityForApprovalCriteriaLinkRecord(details).dtls.priority;
    planItemApprovalCriteriaLinkDtls.description = details.createDtls.dtls.description;
    planItemApprovalCriteriaLinkDtls.recordStatus = RECORDSTATUS.NORMAL;

    // Insert into link table
    planItemApprovalCriteriaLinkObj.insert(planItemApprovalCriteriaLinkDtls);

    // Set return result
    planItemApprovalCriteriaLinkKey.key.planItemApprovalCriteriaLinkID = planItemApprovalCriteriaLinkDtls.planItemApprovalCriteriaLinkID;

    // Return the result
    return planItemApprovalCriteriaLinkKey;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method for obtaining a list of all approval criteria not currently
   * associated to a specific plan item.
   *
   * @param key
   * ID of the plan item
   * @return list of approval criteria not associated to plan item
   */
  public PlanItemUnassociatedApprovalCriteriaDetailsList listUnassociatedApprovalCriteria(
    PlanItemKey key) throws AppException, InformationalException {

    // Create return struct
    PlanItemUnassociatedApprovalCriteriaDetailsList planItemUnassociatedApprovalCriteriaDtlsList = new PlanItemUnassociatedApprovalCriteriaDetailsList();

    // PlanItem entity
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = PlanItemFactory.newInstance();

    // Populate the search key
    SearchUnassociatedApprovalCriteriaForPlanItemKey searchKey = new SearchUnassociatedApprovalCriteriaForPlanItemKey();

    searchKey.planItemID = key.key.planItemID;
    searchKey.approvalCriteriaRecordStatus = RECORDSTATUS.NORMAL;

    // Read the list of unassociated approval criteria
    planItemUnassociatedApprovalCriteriaDtlsList.planItemUnassociatedApprovalCriteriaDetailsList = planItemObj.searchUnassociatedApprovalCriteriaByStatus(
      searchKey);

    // Return the result
    return planItemUnassociatedApprovalCriteriaDtlsList;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method for modifying a plan item approval criteria link record
   *
   * @param details
   * details of the plan item approval criteria record to modify
   */
  public void modifyApprovalCriteria(
    PlanItemApprovalCriteriaLinkModifyDetails details) throws AppException,
      InformationalException {

    // Create priority manipulation object
    Priority priority = new Priority();

    // Create plan item approval criteria manipulation variables.
    PlanItemApprovalCriteriaLink planItemApprovalCriteriaLinkObj = PlanItemApprovalCriteriaLinkFactory.newInstance();

    // Create priority details list for manipulation
    PriorityDetailsList priorityDetailsList = new PriorityDetailsList();

    // Create search approval criteria link struct
    SearchByPlanItemIDStatusAndOccursWhenKey planItemIDStatusOccursWhenSearchKey = new SearchByPlanItemIDStatusAndOccursWhenKey();

    planItemIDStatusOccursWhenSearchKey.planItemID = details.modifyDtls.planItemID;
    planItemIDStatusOccursWhenSearchKey.recordStatus = RECORDSTATUS.NORMAL;
    planItemIDStatusOccursWhenSearchKey.occursWhen = details.modifyDtls.occursWhen;

    // Read all plan item approval criteria records for this specific plan item
    priorityDetailsList.assign(
      planItemApprovalCriteriaLinkObj.searchForIDAndPriorityDetailsList(
        planItemIDStatusOccursWhenSearchKey));

    // Populate details struct for processing the existing priorities
    ProcessApprovalCriteriaPriorityDetails processPriorityDetails = new ProcessApprovalCriteriaPriorityDetails();

    processPriorityDetails.assignNextPriorityInd = details.assignNextPriorityInd;
    processPriorityDetails.planItemApprovalCriteriaLinkID = details.key.planItemApprovalCriteriaLinkID;
    processPriorityDetails.priority = details.modifyDtls.priority;
    processPriorityDetails.planItemID = details.modifyDtls.planItemID;

    // Process the existing priorities
    priority = processApprovalCriteriaPriority(processPriorityDetails,
      priorityDetailsList);

    // Populate details struct for modify operation
    details.modifyDtls.priority = priority.dtls.priority;

    // Modify existing record with the new information
    planItemApprovalCriteriaLinkObj.modifyPlannedItemApprovalDetails(
      details.key, details.modifyDtls);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Validates the priority details, then sets the next priority if specified by
   * user. If next priority is left blank then the new priority is set from the
   * priority entered by the user. Existing priorities are reordered if a record
   * exists whose priority equals the new priority
   *
   * @param details
   * details needed to for processing existing priorities if necessary
   * @param list
   * list of existing approval criteria records
   * @return priority of the record
   */
  public Priority processApprovalCriteriaPriority(
    ProcessApprovalCriteriaPriorityDetails details, PriorityDetailsList list)
    throws AppException, InformationalException {

    // Create priority manipulation helper objects
    PriorityHelper priorityHelperObj = PriorityHelperFactory.newInstance();

    PriorityDetails priorityDetails = new PriorityDetails();
    Priority priority = new Priority();

    // Set validate priority attributes
    priorityDetails.applyNextPriorityInd = details.assignNextPriorityInd;
    priorityDetails.priority = details.priority;

    // Validate the priority modified details
    priorityHelperObj.validatePriority(priorityDetails);

    // If 'Apply Next Priority' has been set to true, find next priority
    if (details.assignNextPriorityInd) {

      // Create details for the existing entry
      OrderPriorityDetails currentDetails = new OrderPriorityDetails();

      currentDetails.priority = details.priority;
      currentDetails.recordKeyID = details.planItemApprovalCriteriaLinkID;
      currentDetails.versionNo = details.versionNo;

      // Return next lowest priority
      priority = priorityHelperObj.getNextPriority(list, currentDetails);

    } // If 'Apply Next Priority' is blank, use priority set by user
    else {

      // Populate priority struct
      priority.dtls.priority = details.priority;

      // Populate details struct to reorder priority
      OrderPriorityDetails orderPriorityDetails = new OrderPriorityDetails();

      orderPriorityDetails.priority = details.priority;
      orderPriorityDetails.recordKeyID = details.planItemApprovalCriteriaLinkID;

      // Reorder priorities (if applicable)
      list = priorityHelperObj.reorderPriority(orderPriorityDetails, list);

      // Create plan item approval criteria manipulation variables.
      PlanItemApprovalCriteriaLink planItemApprovalCriteriaLinkObj = PlanItemApprovalCriteriaLinkFactory.newInstance();

      // Create entity key and details struct
      curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkKey piApprCriteriaLinkKey = new curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkKey();

      PlanItemApprovalCriteriaLinkDtls piApprCriteriaLinkDtls = new PlanItemApprovalCriteriaLinkDtls();

      // Set size of the priority details list
      int planItemApprovalCriteriaLinkSize = list.dtls.size();

      // For each item in the list modify the priority
      for (int i = 0; i < planItemApprovalCriteriaLinkSize; i++) {

        // Set key
        piApprCriteriaLinkKey.planItemApprovalCriteriaLinkID = list.dtls.item(i).recordKeyID;

        // Read back standard details for modify operation
        piApprCriteriaLinkDtls = planItemApprovalCriteriaLinkObj.read(
          piApprCriteriaLinkKey);

        // Set new updated priority for modify
        piApprCriteriaLinkDtls.priority = list.dtls.item(i).priority;

        // Modify existing record with the new priority
        planItemApprovalCriteriaLinkObj.modify(piApprCriteriaLinkKey,
          piApprCriteriaLinkDtls);

      } // end for

    }

    // Return back the result
    return priority;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method for canceling a plan item approval criteria link record
   *
   * @param details
   * details of the plan item approval criteria to cancel
   */
  public void cancelApprovalCriteria(
    PlanItemApprovalCriteriaCancelDetails details) throws AppException,
      InformationalException {

    // PlanItemApprovalCriteriaLink entity manipulation variables
    PlanItemApprovalCriteriaLink planItemApprovalCriteriaLinkObj = PlanItemApprovalCriteriaLinkFactory.newInstance();

    // PlanItemApprovalCriteriaCancelDetails manipulation struct
    PlanItemApprovalCriteriaLinkCancelDetails planItemApprovalCriteriaLinkCancelDetails = new PlanItemApprovalCriteriaLinkCancelDetails();

    // Set plan item approval criteria link cancel details
    planItemApprovalCriteriaLinkCancelDetails.recordStatus = RECORDSTATUS.CANCELLED;
    planItemApprovalCriteriaLinkCancelDetails.versionNo = details.versionNo;

    // Cancel the link between approval criteria and the plan item
    planItemApprovalCriteriaLinkObj.cancel(details.key,
      planItemApprovalCriteriaLinkCancelDetails);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Method for reading a plan item approval criteria link record
   *
   * @param key
   * ID of the plan item approval criteria record
   * @return details of the plan item approval criteria record
   */
  public PlanItemApprovalCriteriaDetails readApprovalCriteria(
    PlanItemApprovalCriteriaLinkKey key) throws AppException,
      InformationalException {

    // Create return struct
    PlanItemApprovalCriteriaDetails planItemApprovalCriteriaDtls = new PlanItemApprovalCriteriaDetails();

    // Create plan item approval criteria link manipulation variables
    PlanItemApprovalCriteriaLink planItemApprovalCriteriaLinkObj = PlanItemApprovalCriteriaLinkFactory.newInstance();

    // Read and set the plan item approval criteria link details
    planItemApprovalCriteriaDtls.readDtls = planItemApprovalCriteriaLinkObj.read(
      key.key);

    // Read the approval criteria entity for other required info
    // Create approval criteria manipulation variables
    ApprovalCriteria approvalCriteriaObj = ApprovalCriteriaFactory.newInstance();

    // Create read struct
    ApprovalCriteriaKey approvalCriteriaKey = new ApprovalCriteriaKey();

    approvalCriteriaKey.approvalCriteriaID = planItemApprovalCriteriaDtls.readDtls.approvalCriteriaID;

    // Perform the read
    ApprovalCriteriaDtls approvalCriteriaDtls = approvalCriteriaObj.read(
      approvalCriteriaKey);

    // Set the required attributes
    planItemApprovalCriteriaDtls.workflowEventName = approvalCriteriaDtls.workflowEvent;
    planItemApprovalCriteriaDtls.criteriaName = approvalCriteriaDtls.criteriaName;

    // Return back the result
    return planItemApprovalCriteriaDtls;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Return a list of active plan items.
   *
   * @see curam.serviceplans.sl.intf.PlanItem#listActivePINames()
   */
  public PlanItemNameIDDetailsList listActivePINames() throws AppException,
      InformationalException {
    PlanItemNameIDDetailsList result = new PlanItemNameIDDetailsList();

    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = PlanItemFactory.newInstance();

    PlanItemStatusDetails key = new PlanItemStatusDetails();

    key.recordStatus = RECORDSTATUS.NORMAL;

    result.planItemNameIDDetailsList = planItemObj.searchActivePINames(key);

    return result;
  }

  // END, CR00161962

  // BEGIN, CR00234077, TV
  // ___________________________________________________________________________
  /**
   * Creates a plan item.
   *
   * @param details
   * The plan item details.
   *
   * @return The ID of the new planItem.
   */
  public PlanItemKey createPlanItem(
    curam.serviceplans.sl.struct.PlanItemDetails details)
    throws AppException, InformationalException {

    // Populate the create details
    PlanItemDtls planItemDtls = new PlanItemDtls();

    planItemDtls.assign(details);

    // Default the record status and creation date
    planItemDtls.recordStatus = RECORDSTATUS.NORMAL;
    planItemDtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // Create the new planItem
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // BEGIN, CR00234442, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!planItemDtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(planItemDtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      planItemDtls.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      planItemDtls.descriptionTextID = localizableTextHandler.store();
    }

    planItemDtls.description = null;
    // END, CR00234442

    planItemObj.insert(planItemDtls);

    // return the new planItem's ID
    PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.key.planItemID = planItemDtls.planItemID;

    return planItemKey;
  }

  // END, CR00234077

  // BEGIN, CR00234442, GP
  /**
   * Checks to ensure multiple text translations are not present for a single
   * locale. If it is, an error message is thrown.
   *
   * @param localizableTextHandler
   * The localizable text handler to store localizable text.
   *
   * @param locale
   * The locale for which localizable text will be entered.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - If
   * multiple text translation is present for the same locale.
   */
  protected void validateNoTranslationsForLocale(
    final LocalizableTextHandler localizableTextHandler, final String locale)
    throws AppException, InformationalException {

    TextTranslationDtlsList textTranslationDtlsList = new
      TextTranslationDtlsList();
    TextTranslation textTranslation = TextTranslationFactory.newInstance();
    SearchByLocalizableTextIDKey key = new SearchByLocalizableTextIDKey();

    key.localizableTextID = localizableTextHandler.getID();
    textTranslationDtlsList = textTranslation.searchByLocalizableTextID(key);

    for (TextTranslationDtls textTranslationDtls : textTranslationDtlsList.dtls.items()) {

      if (textTranslationDtls.localeCode.equals(locale)) {
        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(textTranslationDtls.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          20);
      }
    }
  }

  /**
   * Creates a text translation for the PlanItem attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for PlanItem
   * attribute, description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text
   * to be translated is empty.
   *
   * {@link GENERAL#ERR_LOCALE_EMPTY ERR_LOCALE_EMPTY} - if locale is
   * empty.
   *
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   *
   * {@link BPOPLANITEM#ERR_PLAN_ITEM_CANCELED
   * ERR_PLAN_ITEM_CANCELED}- if the PlanItem to be modified
   * is already canceled.
   */
  public void addDescriptionTextTranslation(final
    LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    PlanItemKey planItemKey = new PlanItemKey();

    PlanItemDescriptionTextID planItemDescriptionTextID = new
      PlanItemDescriptionTextID();
    PlanItemDtls planItemDtls = new PlanItemDtls();

    planItemKey.key.planItemID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 28);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_LOCALE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 13);
    }

    planItemDtls = planItemObj.read(planItemKey.key);

    // Record must not be already canceled.
    if (planItemDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planItemDtls.descriptionTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !planItemDtls.description.equals(CuramConst.gkEmpty)) {

        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          19);

      }

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      String value = planItemDtls.description;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      planItemDescriptionTextID.descriptionTextID = textID;
      planItemDescriptionTextID.versionNo = planItemDtls.versionNo;
      planItemObj.modifyDescriptionTextID(planItemKey.key,
        planItemDescriptionTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planItemDtls.descriptionTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planItemDtls.descriptionTextID);
      
      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();

    }
  }

  /**
   * Modifies the text translation details for the PlanItem attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of PlanItem attribute,
   * description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   *
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   *
   * {@link BPOPLANITEM#ERR_PLAN_ITEM_CANCELED
   * ERR_PLAN_ITEM_CANCELED}- if the PlanItem to be modified
   * is already canceled.
   */
  public void modifyDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
    PlanItemKey planItemKey = new PlanItemKey();

    PlanItemDescriptionTextID planItemDescriptionTextID = new
      PlanItemDescriptionTextID();
    PlanItemDtls planItemDtls = new PlanItemDtls();

    planItemKey.key.planItemID = localizableTextTranslationDetails.localizableTextParentID;
    ;

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 29);
    }

    planItemDtls = planItemObj.read(planItemKey.key);

    // Record must not be already canceled.
    if (planItemDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planItemDtls.descriptionTextID) {
      // END, CR00246419

      // Handling legacy Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      textID = localizableTextHandler.store();
      planItemDescriptionTextID.descriptionTextID = textID;
      planItemDescriptionTextID.versionNo = planItemDtls.versionNo;
      planItemObj.modifyDescriptionTextID(planItemKey.key,
        planItemDescriptionTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planItemDtls.descriptionTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planItemDtls.descriptionTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      localizableTextHandler.store();
    }
  }
  // END, CR00234442

}
