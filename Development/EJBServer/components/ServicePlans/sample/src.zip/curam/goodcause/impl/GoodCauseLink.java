/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.goodcause.impl;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.GOODCAUSELINKTYPEEntry;
import curam.serviceplans.sl.entity.struct.GoodCauseKey;
import curam.serviceplans.sl.entity.struct.RelatedReferenceKey;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockRemovable;

/**
 * The Good Cause Link provides link between good causes and related references.
 * A related reference can be any business entity like Service Offering, Planned
 * Item etc., which associates with Good Cause.
 */
@ImplementedBy(GoodCauseLinkImpl.class)
public interface GoodCauseLink extends Insertable, OptimisticLockRemovable,
    GoodCauseLinkAccessor {

  /**
   * Sets the good cause for the Good Cause Link.
   * 
   * @param goodCauseKey
   *          Contains the good cause ID.
   */
  void setGoodCause(GoodCauseKey goodCauseKey);

  /**
   * Sets the related reference for the Good Cause Link.
   * 
   * @param relatedReferenceKey
   *          Contains related reference ID.
   */
  void setRelatedReference(RelatedReferenceKey relatedReferenceKey);

  /**
   * Sets the related type for the Good Cause Link.
   * 
   * @param relatedType
   *          Contains related type code.
   */
  void setRelatedType(GOODCAUSELINKTYPEEntry relatedType);

}
