/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;

import java.util.List;

import com.google.inject.Inject;

import curam.codetable.impl.GOALNAMEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.serviceplans.sl.entity.struct.GoalDtls;
import curam.util.persistence.helper.ReadOnlyEntityImpl;
import curam.util.type.Date;

/**
 * Standard implementation of the {@link Goal} interface.
 */
// BEGIN, CR00183334, PS
public class GoalImpl extends ReadOnlyEntityImpl<Long, GoalDtls> implements
    Goal {
  // END, CR00183334
  @Inject
  private SubGoalDAO subGoalDAO;

  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected GoalImpl() {
    // no-arg constructor for use only by Guice.
  }

  // END, CR00183334

  /**
   * {@inheritDoc}
   */
  public Date getDateCreated() {
    return getDtls().dateCreated;
  }

  /**
   * {@inheritDoc}
   */
  public String getDescription() {
    return getDtls().description;
  }

  /**
   * {@inheritDoc}
   */
  public GOALNAMEEntry getName() {
    return GOALNAMEEntry.get(getDtls().name);
  }

  /**
   * {@inheritDoc}
   */
  public String getReference() {
    return getDtls().goalReference;
  }

  /**
   * {@inheritDoc}
   */
  public RECORDSTATUSEntry getLifecycleState() {
    return RECORDSTATUSEntry.get(getDtls().recordStatus);
  }

  /**
   * {@inheritDoc}
   */
  public List<SubGoal> listActiveSubGoals() {
    return subGoalDAO.listActiveByGoal(this);
  }

}
