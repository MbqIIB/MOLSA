/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.Inject;

import curam.codetable.impl.SERVICEPLANTYPEEntry;
import curam.core.impl.CuramConst;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.piwrapper.caseheader.impl.CaseHeaderImpl;
import curam.piwrapper.impl.ClientURI;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Standard implementation of the {@link ServicePlanDelivery} interface.
 */
// BEGIN, CR00183334, PS
public class ServicePlanDeliveryImpl extends CaseHeaderImpl<ServicePlanDeliveryDtls> implements ServicePlanDelivery {
  // END, CR00183334
  @Inject
  private ServicePlanDAO servicePlanDAO;

  @Inject
  private PlannedGoalDAO plannedGoalDAO;

  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected ServicePlanDeliveryImpl() {// no-arg constructor for use only by Guice.
  }

  // END, CR00183334

  /**
   * {@inheritDoc}
   */
  @Override
  public Long getAdminConfigurationID() {
    return getDtls().servicePlanID;
  }

  /**
   * {@inheritDoc}
   */
  public ServicePlan getServicePlan() {
    return servicePlanDAO.get(getDtls().servicePlanID);
  }

  /**
   * {@inheritDoc}
   */
  public SERVICEPLANTYPEEntry getServicePlanType() {
    return getServicePlan().getServicePlanType();
  }

  /**
   * {@inheritDoc}
   */
  public PlannedGoal getPlannedGoal() {
    return plannedGoalDAO.readByServicePlanDelivery(this);
  }

  // BEGIN, CR00365714, ZV
  /**
   * {@inheritDoc}
   */
  @Override
  public ClientURI getHomePageName() 
    throws AppException, InformationalException {
    
    ClientURI clientURI = new ClientURI(UimConst.kServicePlanHome);
    
    clientURI.appendParam(CuramConst.gkPageParameterCaseID,
      String.valueOf(getID()));
    
    return clientURI;
  }
  // END, CR00365714
  
}
