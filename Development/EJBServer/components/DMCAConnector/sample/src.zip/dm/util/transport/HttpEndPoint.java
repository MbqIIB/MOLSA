/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package dm.util.transport;

import java.util.LinkedHashMap;
import java.util.Map;

import dm.util.transport.EndPoint;

/**
 * 
 * HTTP EndPoint Class.
 * Represents EndPoint for HTTP Protocol.
 *
 */

public class HttpEndPoint implements EndPoint {

	public final static String HTTP_GET_METHOD = "GET";
	public final static String HTTP_POST_METHOD = "POST";
	/*
	 * Http Request Header Map.
	 */
	Map<String,String> httpRequestHeader
	   = new LinkedHashMap<String,String>();
	/*
	 * Request Method.
	 */
	String requestMethod;
	/*
	 * URI String.
	 */
	String uriString;
	/*
	 * URL String.
	 */
	String urlString;
	/*
	 * Host Name.
	 */
	String host;
	/*
	 * port.
	 */
	int port;
	/**
	 * 
	 * @param host
	 * @param port
	 */
	public HttpEndPoint(String host, int port) {
		this.host =  host;
		this.port = port;
	}

	/**
	 * 
	 * @param host
	 * @param port
	 * @param requestMethod
	 */
	public HttpEndPoint(String host, int port, String requestMethod) {
		this(host, port);
		this.requestMethod = requestMethod;
	}
	
	/**
	 * Add Http Request Header key value.
	 * @param key
	 * @param value
	 */
	public void addRequestHeader(String key, String value) {
		httpRequestHeader.put(key, value);
	}

	/**
	 * returns map of Http Request Header.
	 * @return
	 */
	public Map<String, String> getHttpRequestHeader() {
		return httpRequestHeader;
	}

	/**
	 * 
	 * @param httpRequestHeader
	 */
	public void setHttpRequestHeader(Map<String, String> httpRequestHeader) {
		this.httpRequestHeader = httpRequestHeader;
	}

	/**
	 * Returns Request Method.
	 * @return
	 */
	public String getRequestMethod() {
		return requestMethod;
	}

	/**
	 * 
	 * @param requestMethod
	 */
	public void setRequestMethod(String requestMethod) {
		this.requestMethod = requestMethod;
	}

	/**
	 * 
	 * @return
	 */
	public String getUriString() {
		return uriString;
	}

	/**
	 * 
	 * @param uriString
	 */
	public void setUriString(String uriString) {
		this.uriString = uriString;
	}

	/**
	 * 
	 * @return
	 */
	public String getUrlString() {
		return urlString;
	}

	/**
	 * 
	 * @param urlString
	 */
	public void setUrlString(String urlString) {
		this.urlString = urlString;
	}
	
	
   @Override
	public String getHost() {
		return this.host;
	}
    @Override
    public int getPort() {
	return this.port;
    }

}
