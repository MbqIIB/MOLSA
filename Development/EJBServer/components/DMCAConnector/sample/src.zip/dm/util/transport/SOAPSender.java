/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package dm.util.transport;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.apache.axis2.util.XMLUtils;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;


/**
 * 
 * SOAP Message Sender Utility. Invokes webservice.
 *
 */
public class SOAPSender implements Transport<WebServicesEndPoint> {
	
	
@Override
public void invoke(WebServicesEndPoint endpointInfo, Object payloadObject) throws Exception {
	
	
	SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory
			.newInstance();
	SOAPConnection soapConnection = soapConnectionFactory
			.createConnection();

	try {

	String requestURL = endpointInfo.getUrlString();
	// invoke webservice.
	SOAPMessage soapMessageResponse = soapConnection.call(
			createSOAPRequest(endpointInfo, (String)payloadObject), requestURL);
	

	SOAPPart soapPart = soapMessageResponse.getSOAPPart();
	SOAPEnvelope soapEnvelope = soapPart.getEnvelope();
	SOAPBody soapBody = soapEnvelope.getBody();
	if (soapBody.hasFault()) {
		SOAPFault soapFault = soapBody.getFault();
		// TODO Logging and throwing soap fault.
		System.out.println("Fault: " + soapFault.getFaultCode()
				+ soapFault.getFaultString());
	}
	
	} catch (Throwable e) {
	   throw new Exception(e);
    } finally {  
		soapConnection.close();
	}
  
	
}

/**
 * Creates SOAP Request.
 * @param endpointInfo
 * @param payload
 * @return
 * @throws SOAPException
 * @throws IOException
 * @throws SAXException
 * @throws ParserConfigurationException
 */
public SOAPMessage createSOAPRequest(WebServicesEndPoint endpointInfo
		, String payload) throws SOAPException, 
		                  IOException, SAXException, 
		                  ParserConfigurationException  {

	MessageFactory messageFactory = MessageFactory
			.newInstance(SOAPConstants.SOAP_1_2_PROTOCOL);
	SOAPMessage soapMessage = messageFactory.createMessage();
	SOAPPart soapPart = soapMessage.getSOAPPart();

	SOAPEnvelope soapEnvelope = soapPart.getEnvelope();


	SOAPBody soapBody = soapEnvelope.getBody();
	
	// add soap body element from payload.
	InputStream is = new ByteArrayInputStream(payload.getBytes("UTF-8"));
		Document doc = XMLUtils.newDocument(is);
		SOAPElement element = soapBody.addDocument(doc);
	

	MimeHeaders mimeHeaders = soapMessage.getMimeHeaders();
	mimeHeaders.addHeader(
			"SOAPAction",
			endpointInfo.getSoapActionUri());

	soapMessage.saveChanges();
	try {
		soapMessage.writeTo(System.out);
	} catch (IOException e) {
		e.printStackTrace();
	}

	return soapMessage;
}


}
