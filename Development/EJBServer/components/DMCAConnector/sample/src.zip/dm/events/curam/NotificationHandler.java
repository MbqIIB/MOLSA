/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package dm.events.curam;

import dm.events.EventException;

public interface NotificationHandler {

	/**
	 * Handles all notification to remote SOR
	 * invoking notification webservice.
	 * @param event
	 * @throws EventException 
	 */
	public void handleNotification(
			dm.events.type.SOREvent event) throws EventException;

		
}
