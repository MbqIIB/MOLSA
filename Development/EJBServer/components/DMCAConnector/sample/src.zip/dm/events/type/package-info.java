/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */

@XmlSchema(
    namespace = "http://dm.diona.com",
    elementFormDefault = XmlNsForm.QUALIFIED,
    xmlns={@XmlNs(prefix="dm", namespaceURI="http://dm.diona.com")})
package dm.events.type;

import javax.xml.bind.annotation.*;