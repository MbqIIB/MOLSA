package curam.diona.mobility.citizenselfservice.impl;

import curam.diona.mobility.citizenselfservice.struct.TaskDetails;
import curam.diona.mobility.citizenselfservice.struct.TaskKey;
import curam.core.fact.ConcernRoleFactory;
import curam.core.intf.ConcernRole;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

public class CitizenSelfService implements curam.diona.mobility.citizenselfservice.intf.CitizenSelfService{

	/**
	 * This method returns the details required for a task.  
	 * 
	 * @param Document
	 * @return Document
	 * @throws AppException
	 * @throws InformationalException
	 */
	public TaskDetails readTaskDetails(TaskKey key) throws AppException,
			InformationalException {
		
		TaskDetails taskDetails =  new TaskDetails();
		taskDetails.concernRoleID = key.concernRoleID;
		
		//read concernrole name
		ConcernRole concernRole = ConcernRoleFactory.newInstance();
		ConcernRoleKey concernRoleKey =  new ConcernRoleKey();
		ConcernRoleNameDetails concernRoleNameDetails;
		concernRoleKey.concernRoleID = key.concernRoleID;
		concernRoleNameDetails =  concernRole.readConcernRoleName(concernRoleKey);
		taskDetails.concernRoleName = concernRoleNameDetails.concernRoleName;
		
		taskDetails.data = key.data;
		taskDetails.type = key.type;
				
		return taskDetails;
	}

} 
