package curam.diona.mobility.citizenselfservice.impl;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import curam.codetable.METHODOFDELIVERY;
import curam.codetable.PRODUCTTYPE;
import curam.core.facade.intf.ProductDelivery;
import curam.core.facade.struct.ListCaseFinancialsKey;
import curam.core.fact.CaseHeaderFactory;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.struct.ExternalUserDtls;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.FinancialComponentDtls;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.type.DateTime;
import dm.events.EventException;
import dm.events.curam.DMNotificationHandler;
import dm.events.curam.NotificationHandler;
import dm.events.type.SOREvent;
import dm.events.type.SOREventWrapper;

public class FinancialComponentEventListener 
    extends curam.core.sl.event.impl.FinancialComponentEvent {
	
	@Override
	public void componentCreated(FinancialComponentDtls financialComponentDtls)
			throws   InformationalException {
		// TODO Auto-generated method stub
		super.componentCreated(financialComponentDtls);
		debug(financialComponentDtls, "created");
	}
	
	@Override
	public void componentUpdated(FinancialComponentDtls financialComponentDtls)
			throws  InformationalException {
		// TODO Auto-generated method stub
		super.componentUpdated(financialComponentDtls);
		
		
		if (financialComponentDtls.statusCode.equals("CLD")) {
		// debug gets removed.
		debug(financialComponentDtls, "updated");
		
		boolean isSuccess  = true;
		SOREventWrapper  wrapper = new SOREventWrapper ();
		SOREvent sorEvent = wrapper.getEvent();
		sorEvent.setSentDateTime(DateTime.getCurrentDateTime().toString());
		sorEvent.setType(curam.codetable.DMMessageType.PAYMENT);

		sorEvent.setRelatedId(financialComponentDtls.caseID);

		CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
		CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
		caseHeaderKey.caseID=financialComponentDtls.caseID;
		//read case details
		try {
			CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);
				
			//read product type
			ProductDeliveryKey pdKey = new ProductDeliveryKey();
			pdKey.caseID = caseHeaderDtls.caseID;
			ProductDeliveryDtls pdDtls = 
				curam.core.fact.ProductDeliveryFactory.newInstance().read(
						pdKey);
		    if (pdDtls != null) {
				sorEvent.setCaseType(
						curam.util.type.CodeTable
						.getOneItem(PRODUCTTYPE.TABLENAME,
								(pdDtls.productType)));
				//read user name of the concernrole
				// this will be removed in future, as we will use
				// the appropriate curam mapping table.
				StringBuilder sqlBuilder = new StringBuilder();
				sqlBuilder.append(" SELECT EXTERNALUSER.USERNAME");
				sqlBuilder.append(" INTO :userName");
				sqlBuilder.append(" FROM EXTERNALUSER,CONCERNROLE ");
				sqlBuilder.append(" WHERE EXTERNALUSER.FULLNAME=CONCERNROLE.CONCERNROLENAME");
				sqlBuilder.append(" AND CONCERNROLE.CONCERNROLEID="+caseHeaderDtls.concernRoleID);
				try{
				ExternalUserDtls externalUserDtls = (ExternalUserDtls)
				curam.util.dataaccess.DynamicDataAccess.executeNs( ExternalUserDtls.class, null, 
						false, sqlBuilder.toString());
				sorEvent.setUserId(externalUserDtls.userName); 
				}catch(RecordNotFoundException re){
					isSuccess = false;
				}

				ProductDelivery productDelivery = curam.core.facade.fact.ProductDeliveryFactory.newInstance();
				ListCaseFinancialsKey listCaseFinancialsKey = new ListCaseFinancialsKey();
				listCaseFinancialsKey.caseID=financialComponentDtls.caseID;
				curam.core.facade.struct.ViewCaseFinancialInstructionList list = 
					productDelivery.listCaseFinancialInstruction(listCaseFinancialsKey);
				sorEvent.setDeliveryMethod(curam.util.type.CodeTable
						.getOneItem(METHODOFDELIVERY.TABLENAME,
								financialComponentDtls.nomineeDelivMethod));
				sorEvent.setIssuedDateTime(getXMLGregCalDateTime(list.dtls.dtlsList.get(0).
						finInstructDtls.postingDate.getCalendar().getTime()));
				sorEvent.setAmount(financialComponentDtls.amount.toString());


				if(isSuccess){
					NotificationHandler notify = DMNotificationHandler.getInstance();
					try {
						notify.handleNotification(
								sorEvent);
					} catch (EventException e) {
						e.printStackTrace();
					}
				}		
			}
		  	
		} catch (AppException e) {
			e.printStackTrace();
			throw new AppRuntimeException(e);
		}
	  }
	}



	/**
	 * Method to fetch Date
	 * 
	 * @param Document
	 * @return
	 * @throws AppException
	 * @throws InformationalException
	 */
	private XMLGregorianCalendar getXMLGregCalDateTime(java.util.Date date) {
		XMLGregorianCalendar formatteddate = null;
		if (date != null) {
			try {
				GregorianCalendar cal = new GregorianCalendar();
				cal.setTime(date);
				formatteddate = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
				return formatteddate;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return formatteddate;

	}
	
	private void debug(FinancialComponentDtls financialComponentDtls, String type) {
		System.out.println("--financial batch event triggered -" + type + " " 
			       + financialComponentDtls.caseID
			       + financialComponentDtls.caseTypeCode
			       + financialComponentDtls.categoryCode
		           + financialComponentDtls.productID
		           + financialComponentDtls.concernRoleID
		           + financialComponentDtls.amount
		           + financialComponentDtls.concernRoleID
		           + financialComponentDtls.primaryClientID
		           + financialComponentDtls.financialCompID
		           + financialComponentDtls.typeCode
		           + financialComponentDtls.creationDate
		           + financialComponentDtls.dueDate
		           + financialComponentDtls.endDate
		           + financialComponentDtls.nextProcessingDate
		           + financialComponentDtls.expiryDate
		           + financialComponentDtls.statusCode);

	}
}
