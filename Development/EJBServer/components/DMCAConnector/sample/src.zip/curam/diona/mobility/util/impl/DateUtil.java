package curam.diona.mobility.util.impl;

import curam.util.type.Date;

public class DateUtil {
	
	/**
	 * Converting Date to String
	 * @param date
	 * @return
	 */
	public static String convertDateToString(Date date){
		
		String stringDate = new String();
		if (!Date.kZeroDate.equals(date)){
			stringDate = date.toString();
		}
		return stringDate;
	}	


}
