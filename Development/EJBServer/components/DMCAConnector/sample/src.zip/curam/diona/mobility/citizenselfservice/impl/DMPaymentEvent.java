/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package curam.diona.mobility.citizenselfservice.impl;


/**
 * Interface to the mobility payment notification.
 */
public interface DMPaymentEvent {
	
	  public void paymentNotification(long paymentInstrumentId);


}
