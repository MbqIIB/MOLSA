/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */

package curam.diona.mobility.citizenselfservice.impl;

import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.google.inject.Inject;
import curam.util.type.Money;
import curam.codetable.PRODUCTTYPE;
import curam.core.fact.PaymentInstructionFactory;
import curam.core.sl.entity.fact.CaseNomineeFactory;
import curam.core.sl.entity.struct.CaseNomineeKey;
import curam.core.sl.entity.struct.ExternalUserDtls;
import curam.core.sl.event.impl.PaymentInstrumentEvent;
import curam.core.struct.FinInstructionID;
import curam.core.struct.PaymentInstrumentDtls;
import curam.core.struct.PmtInstrumentID;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.piwrapper.financialmanager.impl.FinancialComponentDAO;
import curam.piwrapper.financialmanager.impl.FinancialInstruction;
import curam.piwrapper.financialmanager.impl.FinancialInstructionDAO;
import curam.piwrapper.financialmanager.impl.InstructionLineItem;
import curam.piwrapper.financialmanager.impl.InstructionLineItemDAO;
import curam.piwrapper.financialmanager.impl.PaymentInstructionDAO;
import curam.piwrapper.financialmanager.impl.PaymentInstrumentDAO;
import curam.piwrapper.financialmanager.impl.PaymentInstrument;
import curam.core.sl.entity.intf.CaseNominee;
import curam.util.resources.Configuration;
import curam.core.impl.EnvVars;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.type.DateTime;
import curam.util.type.NotFoundIndicator;
import dm.events.EventException;
import dm.events.curam.DMNotificationHandler;
import dm.events.curam.NotificationHandler;
import dm.events.type.SOREvent;
import dm.events.type.SOREventWrapper;

/**
 * An event listener for the PaymentInstrumentEvent interface.
 */
public class PaymentInstrumentEventListener extends PaymentInstrumentEvent {

	@Inject
	private PaymentInstrumentDAO paymentInstrumentDAO;
	@Inject
    private InstructionLineItemDAO instructionLineItemDAO;
	@Inject
	private CaseHeaderDAO caseHeaderDAO;
	@Inject
	private FinancialInstructionDAO financialInstructionDAO;
	@Inject
	private FinancialComponentDAO financialComponentDAO;

  /**
   * {@inheritDoc}
   */
  @Override
  public void paymentIssued(final PaymentInstrumentDtls paymentInstrumentDtls)
      throws InformationalException {
      super.paymentIssued(paymentInstrumentDtls);
      
      // TODO remove dependency on the DAO's, make use of dynamic sql.
		SOREventWrapper  wrapper = new SOREventWrapper ();
		SOREvent sorEvent = wrapper.getEvent();
		sorEvent.setSentDateTime(DateTime.getCurrentDateTime().toString());
		sorEvent.setType(curam.codetable.DMMessageType.PAYMENT);
		sorEvent.setDeliveryMethod(paymentInstrumentDtls.deliveryMethodType);
        String currencySymbol = Configuration
                    .getProperty(EnvVars.ENV_CURRENCY_SYMBOL);
        if (currencySymbol == null) {
            currencySymbol = "";
        }
        sorEvent.setAmount(currencySymbol + "" + paymentInstrumentDtls.amount.toString());    
        sorEvent.setIssuedDateTime(getXMLGregCalDateTime(
                curam.util.type.Date.getCurrentDate().getCalendar().getTime()));
        try {
            // batch process will trigger a different event handler.
            // due to OOTB limitation of amount not being returned in this event.
            if (!Configuration.runningInAppServer()) {
                return;

            }
        
	        if (paymentInstrumentDtls.pmtInstrumentID != 0L) {
		        PaymentInstrument paymentInstrument = 
		        		(PaymentInstrument)paymentInstrumentDAO.get(
		        		Long.valueOf(paymentInstrumentDtls.pmtInstrumentID));
                        
                        
               CaseHeader caseHeader = getCaseHeader(paymentInstrumentDtls);      
               
                boolean isInValidPayment = paymentInstrumentDtls.amount.isZero();
               

				//read product type
				ProductDeliveryKey pdKey = new ProductDeliveryKey();
				pdKey.caseID = caseHeader.getID();
				ProductDeliveryDtls pdDtls = 
					curam.core.fact.ProductDeliveryFactory.newInstance().read(
							pdKey);
			    if (pdDtls != null) {
					sorEvent.setCaseType(
							curam.util.type.CodeTable
							.getOneItem(PRODUCTTYPE.TABLENAME,
									(pdDtls.productType)));
                                    
                                    
                    try {
                        sorEvent.setCaseType(
                        new org.apache.commons.codec.binary.Base64()
                                .encodeBase64String(sorEvent.getCaseType().getBytes("UTF-8")));
                    } catch (Throwable e) {
                        e.printStackTrace();
                    }
                                    
			        PmtInstrumentID paymentInstrumentID = new PmtInstrumentID();
			        paymentInstrumentID.pmtInstrumentID = 
			        		paymentInstrumentDtls.pmtInstrumentID;
            			        
					//read user name of the concernrole
					// this will be removed in future, as we will use
					// the appropriate curam mapping table.
					StringBuilder sqlBuilder = new StringBuilder();
					sqlBuilder.append(" SELECT EXTERNALUSER.USERNAME");
					sqlBuilder.append(" INTO :userName");
					sqlBuilder.append(" FROM EXTERNALUSER,CONCERNROLE ");
					sqlBuilder.append(""
							+ " WHERE EXTERNALUSER.FULLNAME"
							+ "=CONCERNROLE.CONCERNROLENAME");
					sqlBuilder.append(" AND CONCERNROLE.CONCERNROLEID="
					+ paymentInstrumentDtls.concernRoleID);
			
					boolean isSuccess  = true;
					try{
						ExternalUserDtls externalUserDtls = (ExternalUserDtls)
						curam.util.dataaccess.DynamicDataAccess.executeNs(
								ExternalUserDtls.class, null, 
								false, sqlBuilder.toString());
						sorEvent.setUserId(externalUserDtls.userName); 
					}catch(RecordNotFoundException re){
						isSuccess = false;
					}
                    if(isSuccess && !isInValidPayment){
						NotificationHandler notify = DMNotificationHandler.getInstance();
						try {
							notify.handleNotification(
									sorEvent);
						} catch (EventException e) {
							e.printStackTrace();
						}
					}		
	
		        
			    }
	
	        }

		} catch (Throwable e) {
			e.printStackTrace();
			// throw new AppRuntimeException(e);
		}

  }


  private CaseHeader getCaseHeader(
		  PaymentInstrumentDtls paymentInstrumentDtls)
	        throws AppException, InformationalException
	    {
	        if(0L == paymentInstrumentDtls.caseNomineeID)
	        {
	            InstructionLineItem instructionLineItem = getILIByInstrument((
	            		PaymentInstrument)paymentInstrumentDAO.get(
	            		Long.valueOf(paymentInstrumentDtls.pmtInstrumentID)));
	            return (CaseHeader)caseHeaderDAO.get(
	            		instructionLineItem.getCaseId());
	        } else
	        {
	            CaseNominee caseNomineeObj 
	              = CaseNomineeFactory.newInstance();
	            CaseNomineeKey caseNomineeKey = new CaseNomineeKey();
	            caseNomineeKey.caseNomineeID 
	              = paymentInstrumentDtls.caseNomineeID;
	            return (CaseHeader)caseHeaderDAO.get(
	            		Long.valueOf(
	            				caseNomineeObj.readCaseID(
	            						caseNomineeKey).caseID));
	        }
	    }
  
  

private InstructionLineItem getILIByInstrument(
		PaymentInstrument paymentInstrument)
        throws AppException, InformationalException {
	    // TODO convert this into dynamic sql.
        PmtInstrumentID pmtInstrumentID = new PmtInstrumentID();
        pmtInstrumentID.pmtInstrumentID = (
        		(Long)paymentInstrument.getID()).longValue();
        curam.core.intf.PaymentInstruction paymentInstructionObj 
        = PaymentInstructionFactory.newInstance();
        NotFoundIndicator nfIndicator = new NotFoundIndicator();
        FinInstructionID finInstructionID = 
        		
        		paymentInstructionObj.readByPmtInstrumentID(
        		nfIndicator, pmtInstrumentID);
        if(nfIndicator.isNotFound())
        {
            return null;
        }
        List instructionLineItemList = 
        		instructionLineItemDAO.searchByFinancialInstruction(
        		(FinancialInstruction)financialInstructionDAO.get(
        		Long.valueOf(finInstructionID.finInstructionID)));
        if(instructionLineItemList.size() > 0)
        {
            return (InstructionLineItem)instructionLineItemList.get(0);
        } else
        {
            return null;
        }
    }


/**
 * Method to fetch Date
 * 
 * @param Document
 * @return
 * @throws AppException
 * @throws InformationalException
 */
private XMLGregorianCalendar getXMLGregCalDateTime(java.util.Date date) {
	XMLGregorianCalendar formatteddate = null;
	if (date != null) {
		try {
			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(date);
			formatteddate = DatatypeFactory
					.newInstance().newXMLGregorianCalendar(cal);
			return formatteddate;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	return formatteddate;

}

  private void debug(final PaymentInstrumentDtls paymentInstrumentDtls) {
              
      System.out.println("paymentInstrumentDtls amt=" + paymentInstrumentDtls.amount);
      System.out.println("paymentInstrumentDtls nominee=" + paymentInstrumentDtls.nomineeName);
      System.out.println("paymentInstrumentDtls instrument id=" + paymentInstrumentDtls.pmtInstrumentID);
      System.out.println("paymentInstrumentDtls reconcil status=" + paymentInstrumentDtls.reconcilStatusCode);      
  
  
  }
}