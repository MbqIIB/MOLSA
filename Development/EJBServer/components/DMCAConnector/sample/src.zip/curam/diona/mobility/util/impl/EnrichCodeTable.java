package curam.diona.mobility.util.impl;

import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.intf.CodeTable;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;

public class EnrichCodeTable {
	
	public static String enrichCodeTableValue(String ctTableName, String ctValue)
			throws AppException, InformationalException {
		CodeTable ct = CodeTableFactory.newInstance();
		CTItemKey ctItemKey = new CTItemKey();
		ctItemKey.tableName = ctTableName;
		ctItemKey.code = ctValue;
		CTItem ctItem = ct.getOneItem(ctItemKey);
		return ctItem.description;
	}

}
