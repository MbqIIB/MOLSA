/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package curam.diona.mobility.citizenselfservice.impl;

public class DMConstant {

	public static final String kPendingCase="DMCST1";
	public static final String kOngoingCase="DMCST2";
	public static final String kSuspended="DMCST3";
	public static final String kClosed="DMCST4";
	public static final String kDMCitizenAddressDetailsUpdates="DMCitizenAddressDetailsUpdates";
	public static final String kDMCitizenPhoneDetailsUpdates="DMCitizenPhoneDetailsUpdates";
	public static final String kDMCitizenEmailDetailsUpdates="DMCitizenEmailDetailsUpdates";
}
