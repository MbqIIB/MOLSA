/*
 * Copyright 2013-2014 Diona.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you
 * entered into with Diona.
 */
package curam.diona.mobility.util.impl;

public class DIMASConstants {
	
	public static String gAll = "All";
	
	public static String gSingle = "Single";
	
	//String constant for %.
	public static  String kPercentage = "%";
	
	//String constant for %%.
	public static  String kDoublePercentage = "%%";
	
	//String constant for ,.
	public static final String kComma = ",";
	
	//String constant for ,.
	public static final String kSpace = " ";

}
