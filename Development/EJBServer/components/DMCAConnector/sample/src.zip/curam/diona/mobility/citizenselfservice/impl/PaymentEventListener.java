/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package curam.diona.mobility.citizenselfservice.impl;


import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.w3c.dom.events.EventException;

import com.google.inject.Inject;

import curam.codetable.PRODUCTTYPE;
import curam.core.fact.PaymentInstructionFactory;
import curam.core.fact.PaymentInstrumentFactory;
import curam.core.impl.EnvVars;
import curam.core.intf.PaymentInstrument;
import curam.core.sl.entity.struct.ExternalUserDtls;
import curam.core.struct.FinInstructionID;
import curam.core.struct.PaymentInstrumentDtls;
import curam.core.struct.PaymentInstrumentKey;
import curam.core.struct.PmtInstrumentID;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.piwrapper.financialmanager.impl.FinancialComponentDAO;
import curam.piwrapper.financialmanager.impl.FinancialInstruction;
import curam.piwrapper.financialmanager.impl.FinancialInstructionDAO;
import curam.piwrapper.financialmanager.impl.InstructionLineItem;
import curam.piwrapper.financialmanager.impl.InstructionLineItemDAO;
import curam.piwrapper.financialmanager.impl.PaymentInstrumentDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.type.DateTime;
import curam.util.type.NotFoundIndicator;
import dm.events.curam.DMNotificationHandler;
import dm.events.curam.NotificationHandler;
import dm.events.type.SOREvent;
import dm.events.type.SOREventWrapper;

/**
 * This class provides the operations to provide mobile payment notification.
 */
@SuppressWarnings("all")
public class PaymentEventListener implements DMPaymentEvent {
	

	@Inject
	private PaymentInstrumentDAO paymentInstrumentDAO;
	@Inject
    private InstructionLineItemDAO instructionLineItemDAO;
	@Inject
	private CaseHeaderDAO caseHeaderDAO;
	@Inject
	private FinancialInstructionDAO financialInstructionDAO;
	@Inject
	private FinancialComponentDAO financialComponentDAO;

	
	  /**
	   * Default Constructor
	   */
	  public PaymentEventListener() {
	    GuiceWrapper.getInjector().injectMembers(this);
	
	  }
	
	@Override
	public void paymentNotification(long paymentInstrumentId) {


        try {

		PaymentInstrument paymentInstrumentObj = PaymentInstrumentFactory
				.newInstance();

		PaymentInstrumentKey piKey = new PaymentInstrumentKey();
		piKey.pmtInstrumentID = paymentInstrumentId;
		PaymentInstrumentDtls paymentInstrumentDtls = paymentInstrumentObj.read(piKey);
		
		
		
	      // TODO remove dependency on the DAO's, make use of dynamic sql.
			SOREventWrapper  wrapper = new SOREventWrapper ();
			SOREvent sorEvent = wrapper.getEvent();
			sorEvent.setSentDateTime(DateTime.getCurrentDateTime().toString());
			sorEvent.setType(curam.codetable.DMMessageType.PAYMENT);
			sorEvent.setDeliveryMethod(paymentInstrumentDtls.deliveryMethodType);
	        String currencySymbol = Configuration
	                    .getProperty(EnvVars.ENV_CURRENCY_SYMBOL);
	        if (currencySymbol == null) {
	            currencySymbol = "";
	        }
	        sorEvent.setAmount(currencySymbol + "" + paymentInstrumentDtls.amount.toString());    
	        sorEvent.setIssuedDateTime(getXMLGregCalDateTime(
	                curam.util.type.Date.getCurrentDate().getCalendar().getTime()));
            boolean isInValidPayment = paymentInstrumentDtls.amount.isZero();
            if (isInValidPayment) {
                return;
            }
            
	        	
	        	List<InstructionLineItem> instructionLineItemList = 
	        			 getILIByInstrument(paymentInstrumentDtls);
	        	StringBuilder programNames = new StringBuilder();
                if (instructionLineItemList != null) {
                    for (InstructionLineItem ili : instructionLineItemList) {
                        long caseID = ili.getCaseId();
                        ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
                        productDeliveryKey.caseID = caseID;
                        ProductDeliveryDtls productDelDtls = curam.core.fact.ProductDeliveryFactory
                            .newInstance().read(productDeliveryKey);
                        String caseDesc = curam.util.type.CodeTable.getOneItem(
                                PRODUCTTYPE.TABLENAME, (productDelDtls.productType));
                        if (programNames.indexOf(caseDesc + ",") == -1) {
                            programNames.append(caseDesc + ", ");
                        }

                    }
                }
	            if (programNames.length() > 0) {
	            	programNames.setLength(programNames.length() - 2);
	            }
	        	
                if (programNames.length() == 0) {
                    isInValidPayment = true;
                }
                
	        	sorEvent.setCaseType(programNames.toString());
                
                try {
                    sorEvent.setCaseType(
                    new org.apache.commons.codec.binary.Base64()
                            .encodeBase64String(sorEvent.getCaseType().getBytes("UTF-8")));
                } catch (Throwable e) {
                    e.printStackTrace();
                }
                
                
				//read user name of the concernrole
				// this will be removed in future, as we will use
				// the appropriate curam mapping table.
				StringBuilder sqlBuilder = new StringBuilder();
				sqlBuilder.append(" SELECT EXTERNALUSER.USERNAME");
				sqlBuilder.append(" INTO :userName");
				sqlBuilder.append(" FROM EXTERNALUSER,CONCERNROLE ");
				sqlBuilder.append(""
						+ " WHERE EXTERNALUSER.FULLNAME"
						+ "=CONCERNROLE.CONCERNROLENAME");
				sqlBuilder.append(" AND CONCERNROLE.CONCERNROLEID="
				+ paymentInstrumentDtls.concernRoleID);
		
				boolean isSuccess  = true;
				try{
					ExternalUserDtls externalUserDtls = (ExternalUserDtls)
					curam.util.dataaccess.DynamicDataAccess.executeNs(
							ExternalUserDtls.class, null, 
							false, sqlBuilder.toString());
					sorEvent.setUserId(externalUserDtls.userName); 
				}catch(RecordNotFoundException re){
					isSuccess = false;
				}
                if(isSuccess && !isInValidPayment){
					NotificationHandler notify = DMNotificationHandler.getInstance();
					try {
						notify.handleNotification(
								sorEvent);
					} catch (EventException e) {
						e.printStackTrace();
					}
				}		
		
		

			} catch (Throwable e) {
				e.printStackTrace();
				// throw new AppRuntimeException(e);
			}

		
		
	}


/**
 * Method to fetch Date
 * 
 * @param Document
 * @return
 * @throws AppException
 * @throws InformationalException
 */
private XMLGregorianCalendar getXMLGregCalDateTime(java.util.Date date) {
	XMLGregorianCalendar formatteddate = null;
	if (date != null) {
		try {
			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(date);
			formatteddate = DatatypeFactory
					.newInstance().newXMLGregorianCalendar(cal);
			return formatteddate;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	return formatteddate;

}

private List<InstructionLineItem> getILIByInstrument(
		PaymentInstrumentDtls paymentInstrument)
        throws AppException, InformationalException {
    PmtInstrumentID pmtInstrumentID = new PmtInstrumentID();
    pmtInstrumentID.pmtInstrumentID = paymentInstrument.pmtInstrumentID;
    curam.core.intf.PaymentInstruction paymentInstructionObj 
    = PaymentInstructionFactory.newInstance();
    NotFoundIndicator nfIndicator = new NotFoundIndicator();
    FinInstructionID finInstructionID = 
    		paymentInstructionObj.readByPmtInstrumentID(
    		nfIndicator, pmtInstrumentID);
    if(nfIndicator.isNotFound())
    {
        return null;
    }
    List<InstructionLineItem> instructionLineItemList = 
    		instructionLineItemDAO.searchByFinancialInstruction(
    		(FinancialInstruction)financialInstructionDAO.get(
    		Long.valueOf(finInstructionID.finInstructionID)));
    return instructionLineItemList;
}

	
}
