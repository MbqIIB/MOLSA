/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package curam.diona.mobility.citizenselfservice.impl;

import curam.core.impl.CuramConst;
import curam.util.transaction.TransactionInfo;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.impl.CASESTATUSEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.core.facade.fact.OrganizationFactory;
import curam.core.facade.intf.Organization;
import curam.core.facade.struct.ReadOrganizationUserHomePageDetails;
import curam.core.facade.struct.ReadUserHomePageKey;
import curam.core.fact.CaseHeaderFactory;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.struct.ExternalUserDtls;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.events.PRODUCTDELIVERY;
import curam.util.events.impl.EventFilter;
import curam.util.events.impl.EventHandler;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.type.DateTime;
import dm.events.EventException;
import dm.events.curam.DMNotificationHandler;
import dm.events.curam.NotificationHandler;
import dm.events.type.SOREvent;
import dm.events.type.SOREventWrapper;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.dataaccess.CuramValueList;
import curam.message.GENERAL;

@SuppressWarnings("all")
public class ProductDeliveryCaseHandler implements EventHandler, EventFilter {

	@Override
	public boolean accept(Event event) throws AppException,
	InformationalException {

		return true;
	}


	@Override
	public void eventRaised(Event event) throws AppException,
	InformationalException {

		CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
		CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
		//read case details 
		caseHeaderKey.caseID = event.primaryEventData;
		CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);
        if (!CASETYPECODEEntry.PRODUCTDELIVERY.getCode().equals(
           caseHeaderDtls.caseTypeCode)) {
           return;
        }

		SOREventWrapper  wrapper = new SOREventWrapper ();
		SOREvent sorEvent = wrapper.getEvent();

		if(event.eventKey.eventType.equals(PRODUCTDELIVERY.SUSPEND.eventType)){
			sorEvent.setNewState(CASESTATUSEntry.SUSPENDED.getCode());
			sorEvent.setPreviousState(CASESTATUSEntry.OPEN.getCode());
		}else if(event.eventKey.eventType.equals(PRODUCTDELIVERY.UNSUSPEND.eventType)){
			sorEvent.setNewState(CASESTATUSEntry.OPEN.getCode());
			sorEvent.setPreviousState(CASESTATUSEntry.SUSPENDED.getCode());
		} 
        
        if(event.eventKey.eventType.equals(PRODUCTDELIVERY.SUSPEND.eventType)){

            try {
                String prevState = getPreviousState(caseHeaderDtls.caseID, CASESTATUSEntry.SUSPENDED.getCode());
                if (prevState != null) {
                    sorEvent.setPreviousState(prevState);
                }

            } catch (Throwable ee) {

                ee.printStackTrace();
            }
        }


		sorEvent.setSentDateTime(DateTime.getCurrentDateTime().toString());
		sorEvent.setType(curam.codetable.DMMessageType.CASESTATUSCHANGE);
		sorEvent.setRelatedId(caseHeaderDtls.caseID);

		ProductDeliveryKey pdKey = new ProductDeliveryKey();
		pdKey.caseID = caseHeaderDtls.caseID;
		ProductDeliveryDtls pdDtls = 
			curam.core.fact.ProductDeliveryFactory.newInstance().read(
					pdKey);
        String caseTypeDesc = curam.util.type.CodeTable
                .getOneItem(PRODUCTTYPE.TABLENAME,
                        (pdDtls.productType));

        try {
        
        sorEvent.setCaseType(
        new org.apache.commons.codec.binary.Base64()
                .encodeBase64String(
                       caseTypeDesc.getBytes("UTF-8")
                        ));
        } catch (Throwable e) {
            e.printStackTrace();
            sorEvent.setCaseType(caseTypeDesc);

        }

		OrgObjectLinkKey orgKey = new OrgObjectLinkKey();
		orgKey.orgObjectLinkID = caseHeaderDtls.ownerOrgObjectLinkID;
		OrgObjectLinkDtls orgD = 
			OrgObjectLinkFactory.newInstance().read(orgKey);
		if (orgD != null 
				&& orgD.orgObjectType.equals(ORGOBJECTTYPEEntry.USER.getCode())) {

			Organization organization = OrganizationFactory.newInstance();
			ReadUserHomePageKey homePageKey = new ReadUserHomePageKey();

			homePageKey.userKeyStruct.userName = orgD.userName;
			ReadOrganizationUserHomePageDetails  
			orgUserHomePageDetails = organization
			.readOrganizationUserHomePage(homePageKey);
			sorEvent.setContactPhone(
					orgUserHomePageDetails.
					organizationUserDetails.businessCountryCode
					+ orgUserHomePageDetails.
					organizationUserDetails.businessAreaCode
					+ orgUserHomePageDetails.
					organizationUserDetails.businessNumber
					+ orgUserHomePageDetails.
					organizationUserDetails.businessPhoneExtn
			);
			
			sorEvent.setContactEmailAddress( 
					orgUserHomePageDetails.
					organizationUserDetails.businessEMail
			);
			sorEvent.setContactPerson(
					orgUserHomePageDetails.
					organizationUserDetails.fullName
			);
			sorEvent.setMobileContactNumber(
					orgUserHomePageDetails.
					organizationUserDetails.mobileCountryCode
					+ orgUserHomePageDetails.
					organizationUserDetails.mobileAreaCode
					+ orgUserHomePageDetails.
					organizationUserDetails.mobileNumber
			);

		}

		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append(" SELECT EXTERNALUSER.USERNAME");
		sqlBuilder.append(" INTO :userName");
		sqlBuilder.append(" FROM EXTERNALUSER,CONCERNROLE ");
		sqlBuilder.append(" WHERE EXTERNALUSER.FULLNAME=CONCERNROLE.CONCERNROLENAME");
		sqlBuilder.append(" AND CONCERNROLE.CONCERNROLEID="+caseHeaderDtls.concernRoleID);
       
		boolean isSuccess = true;
	    try{
		ExternalUserDtls externalUserDtls = (ExternalUserDtls)
		curam.util.dataaccess.DynamicDataAccess.executeNs( ExternalUserDtls.class, null, 
				false, sqlBuilder.toString());
		sorEvent.setUserId(externalUserDtls.userName); 
	    }catch(RecordNotFoundException re){
	    	isSuccess = false;
	    }
         if(isSuccess){
        	 NotificationHandler notify = DMNotificationHandler.getInstance();
     		try {
     			notify.handleNotification(
     					sorEvent);
     		} catch (EventException e) {
     			e.printStackTrace();
     		}
         }
	}



  public String getPreviousState(long caseID, String newState)
      throws AppException, InformationalException {

  
    InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();
    StringBuilder sqlBuilder = new StringBuilder();
        
    sqlBuilder
        .append(" SELECT CASESTATUS.statusCode,CASESTATUS.userName,CASESTATUS.startDateTime, CASESTATUS.endDateTime  ");
    sqlBuilder
        .append(" INTO :statusCode,:userName,:startDateTime,:endDateTime");
    sqlBuilder.append(" FROM CASESTATUS");
    sqlBuilder.append(" WHERE CASESTATUS.caseID = :caseID ORDER BY CASESTATUS.endDateTime DESC" );
        curam.core.struct.CaseStatusSearchByCaseIDKey caseStatusSearchByCaseIDKey = new curam.core.struct.CaseStatusSearchByCaseIDKey();

        caseStatusSearchByCaseIDKey.caseID = caseID;
    CuramValueList<curam.core.struct.CaseStatusDtls> valueList = null;
    try {
      valueList = curam.util.dataaccess.DynamicDataAccess
          .executeNsMulti(curam.core.struct.CaseStatusDtls.class, caseStatusSearchByCaseIDKey, false, true,
              sqlBuilder.toString());
    } catch (curam.util.exception.ReadmultiMaxException e) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .addInfoMgrExceptionWithLookup(
              new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      informationalManager.failOperation();
    }
    String prevState = null;
    String tempState = null;
    for (curam.core.struct.CaseStatusDtls caseSt : valueList.items()) {
        
        if (caseSt.statusCode.equals(newState) ||  caseSt.endDateTime == null || caseSt.endDateTime.isZero() || caseSt.statusCode.equals(CASESTATUSEntry.DELAYEDPROC.getCode())) {
            continue;
        }
        if ((tempState == null && !caseSt.endDateTime.isZero()) || 
         (tempState != null && !tempState.equals(caseSt.statusCode))) {
            prevState = caseSt.statusCode;
            break;
        }
        tempState = caseSt.statusCode;
    }
    return prevState;
  }

}
