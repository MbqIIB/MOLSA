// wrapped by build app
define("dojox/storage", ["dijit","dojo","dojox","dojo/require!dojox/storage/_common"], function(dijit,dojo,dojox){
dojo.provide("dojox.storage");
dojo.require("dojox.storage._common");

});
