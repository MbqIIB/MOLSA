//>>built
define("dojox/storage",["dijit","dojo","dojox","dojo/require!dojox/storage/_common"],function(_1,_2,_3){
_2.provide("dojox.storage");
_2.require("dojox.storage._common");
});
