This is dojox/storage from standard Dojo 1.7.3, but removed the flash, air and gears storage providers

