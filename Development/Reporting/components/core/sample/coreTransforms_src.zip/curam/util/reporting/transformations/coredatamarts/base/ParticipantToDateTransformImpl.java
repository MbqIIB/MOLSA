/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.coredatamarts.base;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.base.PostProcessImpl;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;

/**
 * This module updates a table end date column.
 * 
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
abstract class ParticipantToDateTransformImpl extends PostProcessImpl implements
ETLPostProcess {

    /**
     * update SQL.
     */
    private final String kUodateFactSQL;

    /**
     * SQL to read where to date is null.
     */
    private final String sqlSelectLatestFacts;

    // ___________________________________________________________________________
    /**
     * Creates an object to parse address data strings.
     * 
     * @param inSourceTable
     *          the source table name
     * @throws SQLException
     *           if database error occurs
     */
    public ParticipantToDateTransformImpl(final String inSourceTable)
    throws SQLException {

        kUodateFactSQL = "update " + inSourceTable + " set enddatekey=?"
        + " where concernroleid=? and startdatekey=?";

        sqlSelectLatestFacts = "select concernroleid, startdatekey as fromdatekey from "
            + inSourceTable
            + " t1,"
            + " dm_dimtimeperiod t2 "
            + " where enddatekey = -1 and t1.startdatekey=t2.timeperiodkey"
            + " order by concernroleid, t2.daydate desc";
    }

    // ___________________________________________________________________________
    /**
     * This module updates a table end date column.
     * 
     * @param inTargetTableName
     *          the target table being populated
     * @throws java.sql.SQLException
     *           if a database operation failed
     */
    @Override
    public void executePostProcess(final String inTargetTableName)
    throws SQLException {
        // if an SQL statement failed, initialize to false
        boolean failed = false;
        // the database transaction
        Transaction transaction = null;

        try {
            // start a transaction, get DAO to read from the control table
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            updateToDateOfPreviousStatuses();

            // update the control table
            super.executePostProcess(inTargetTableName);
        } catch (final Exception e) {
            System.out.println("ToDateTransformImpl: caught exception "
                    + e.getMessage());
            failed = true;
            // do not throw an exception, allow our test process to
            // pick up on any data quality issues.
        } finally {

            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                    System.out
                    .println("ToDateTransformImpl:failed, transaction rolled back");
                } else {
                    // commit the changes
                    transaction.commit();
                    System.out
                    .println("ToDateTransformImpl:transaction commited, processed ");
                }
            }
        }
    }

    // __________________________________________________________________________
    /**
     * Sets the number of cases on hand prior to a given date.
     * 
     * @throws SQLException
     *           if a database operation fails
     */

    private void updateToDateOfPreviousStatuses() throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection.prepareStatement(sqlSelectLatestFacts);
            final ResultSet rs = statement.executeQuery();

            FactKey mostRecentStatus = null;
            FactKey previousstatusForCase = null;

            while (rs.next()) {
                mostRecentStatus = new FactKey(rs.getLong(1), rs.getLong(2));

                if (previousstatusForCase != null
                        && mostRecentStatus.logicalKey == previousstatusForCase.logicalKey) {

                    mostRecentStatus.toDate = previousstatusForCase.fromDate;
                    System.out.println("setting TODATE on case <"
                            + mostRecentStatus.logicalKey + "> with from date<"
                            + mostRecentStatus.fromDate + "> to " + mostRecentStatus.toDate);

                    update(mostRecentStatus);
                } else {
                    previousstatusForCase = mostRecentStatus;
                    System.out.println("next case " + mostRecentStatus.logicalKey);
                }
            }

        } catch (final Exception e) {
            System.out.println("ToDateTransformImpl:readCasesOnHand:" + e);
            throw new SQLException("ToDateTransformImpl:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // __________________________________________________________________________
    /**
     * Sets the to date value.
     * 
     * @param inFactKey
     *          the target table being populated
     * @throws SQLException
     *           if database operation failed
     */
    public void update(final FactKey inFactKey) throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;

        try {

            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.prepareStatement(kUodateFactSQL);

            // set month
            statement.setLong(1, inFactKey.toDate);

            // set case
            statement.setLong(2, inFactKey.logicalKey);

            // set cases on hand at start of month

            statement.setLong(3, inFactKey.fromDate);
            final int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated != 1) {
                System.out.println("Warning: " + rowsUpdated
                        + " row(s) updated history table.");
            }

        } catch (final Exception e) {
            System.out.println("ToDateTransformImpl:update:" + e.getMessage());
            throw new SQLException("ToDateTransformImpl:update:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    /**
     * This module defines the key to fact records.
     */
    class FactKey {

        /**
         * the from date for a case status record.
         */

        private final long fromDate;

        /**
         * the to date for a case status record.
         */
        private long toDate;

        /**
         * the case id.
         */
        private final long logicalKey;

        /**
         * Creates a new fact key for latest records.
         * 
         * @param inLogicalKey
         *          the case identity
         * @param inFromDate
         *          the from date
         */
        public FactKey(final long inLogicalKey, final long inFromDate) {
            fromDate = inFromDate;
            logicalKey = inLogicalKey;
        }

        /**
         * Sets the to date for a case status records.
         * 
         * @param inToDate
         *          the end date for a status
         */
        public void setToDate(final long inToDate) {
            toDate = inToDate;
        }

    }
}
