/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2012 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.coredatamarts.base;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.Calendar;

/**
 * This module contains portable data utilities.
 * 
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
public class DateUtilitiesTransformImpl {

  private static final int kTimeInSeconds = 1000;
  @SuppressWarnings("unused")
  static private final int kTimeInMinutes = 60;
  @SuppressWarnings("unused")
  static private final int kTimeInHours = 60;
  @SuppressWarnings("unused")
  static private final int kTimeInDays = 24;

  // ___________________________________________________________________________
  /**
   * Creates an date utilities object.
   * 
   * @throws Exception
   * 
   * @throws SQLException
   *           if database error occurs
   */
  public DateUtilitiesTransformImpl() throws Exception {

  }

  // ___________________________________________________________________________
  /**
   * returns the elapsed time in minutes.
   * 
   * @param inStart
   *          the start date
   * 
   * @param inEnd
   *          the end date
   * 
   * @return the number of minutes between the start and end dates, return a
   *         negative value if the end data is before the start date
   * @throws Exception
   */
  static public int secondsBetween(final Date inStart, final Date inEnd)
      throws Exception {

    if (inStart == null || inEnd == null) {
      return 0;
    }

    Calendar start = Calendar.getInstance();
    start.setTimeInMillis(inStart.getTime());

    Calendar end = Calendar.getInstance();
    end.setTimeInMillis(inEnd.getTime());
    int seconds;

    if (inEnd.after(inStart)) {
      seconds = (int) ((end.getTimeInMillis() - start.getTimeInMillis()) / kTimeInSeconds);
    } else if (inEnd.before(inStart)) {
      seconds = (int) ((start.getTimeInMillis() - end.getTimeInMillis()) / kTimeInSeconds);
    } else {
      seconds = 0;
    }

    return seconds;
  }

  // ___________________________________________________________________________
  /**
   * returns the elapsed time in minutes.
   * 
   * @param inStart
   *          the start date
   * 
   * @param inEnd
   *          the end date
   * 
   * @return the number of minutes between the start and end dates, return a
   *         negative value if the end data is before the start date
   * @throws Exception
   */
  static public int secondsBetween(final Timestamp inStart,
      final Timestamp inEnd) throws Exception {

    if (inStart == null || inEnd == null) {
      return 0;
    }
    Calendar start = Calendar.getInstance();
    start.setTimeInMillis(inStart.getTime());

    Calendar end = Calendar.getInstance();
    end.setTimeInMillis(inEnd.getTime());
    int seconds = (int) ((end.getTimeInMillis() - start.getTimeInMillis()) / kTimeInSeconds);

    return seconds;
  }

  // ___________________________________________________________________________
  /**
   * the current date.
   * 
   * 
   * @return the number of minutes between the start and end dates, return a
   *         negative value if the end data is before the start date
   * @throws Exception
   */
  static public Date currentDate() throws Exception {
    Calendar rightNow = Calendar.getInstance();
    return new Date(rightNow.getTime().getTime());
  }

  static public Date currentDate(String s) throws Exception {
    return currentDate();
  }

  // ___________________________________________________________________________
  /**
   * the current time stamp.
   * 
   * 
   * @return the number of minutes between the start and end dates, return a
   *         negative value if the end data is before the start date
   * @throws Exception
   */
  static public Date currentDateTime() throws Exception {
    Calendar rightNow = Calendar.getInstance();
    return new java.sql.Date(rightNow.getTime().getTime());
  }

  // ___________________________________________________________________________
  /**
   * the current time stamp.
   * 
   * 
   * @return the number of minutes between the start and end dates, return a
   *         negative value if the end data is before the start date
   * @throws Exception
   */
  static public Timestamp currentTimeStamp() throws Exception {
    Calendar rightNow = Calendar.getInstance();
    return new Timestamp(rightNow.getTime().getTime());
  }

  // ___________________________________
  /**
   * Subtracts the number of days.
   * 
   * @param inStart
   *          the start date
   * 
   * @param inDays
   *          the days to subtract
   * 
   * @return start date minutes number of days
   * @throws Exception
   */
  static public Date dateMinusDays(final Date inStart, final int inDays)
      throws Exception {

    if (inStart == null) {
      return inStart;
    }
    Calendar start = Calendar.getInstance();
    start.setTimeInMillis(inStart.getTime());

    start.add(Calendar.DATE, (-1 * inDays));
    java.sql.Date returnValue = new java.sql.Date(start.getTimeInMillis());
    return returnValue;
  }

  // ___________________________________________________________________________
  /**
   * Subtracts the number of days.
   * 
   * @param inStart
   *          the start date
   * 
   * @param inDays
   *          the days to subtract
   * 
   * @return start date minutes number of days
   * @throws Exception
   */
  static public Timestamp dateMinusDays(final Timestamp inStart,
      final int inDays) throws Exception {

    if (inStart == null) {
      return inStart;
    }
    Calendar start = Calendar.getInstance();
    start.setTimeInMillis(inStart.getTime());

    start.add(Calendar.DATE, (-1 * inDays));

    return new Timestamp(start.getTimeInMillis());
  }

}
