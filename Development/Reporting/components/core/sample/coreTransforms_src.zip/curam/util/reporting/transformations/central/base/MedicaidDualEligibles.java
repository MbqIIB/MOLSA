/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.transformations.central.base;

import curam.util.type.*;

@AccessLevel(AccessLevelType.EXTERNAL)
public class MedicaidDualEligibles extends MedicalAssistance {

  public MedicaidDualEligibles(
      int inKey,
      String inMaintenanceAssistenceCode,
      String inMASStatus) {
    super(inKey, inMaintenanceAssistenceCode, inMASStatus);
    // TODO Auto-generated constructor stub
  }

}
