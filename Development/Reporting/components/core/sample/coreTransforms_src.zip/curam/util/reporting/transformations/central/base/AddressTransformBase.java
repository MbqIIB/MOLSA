/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.central.base;

import java.sql.SQLException;
import curam.util.type.*;

/**
 * This module provides functionality to flatten address details, and perform
 * state lookup.
 *
 *
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AddressTransformBase extends AddressTransformImpl {

  public AddressTransformBase() throws SQLException {
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates an object to parse address data strings.
   *
   * @param inSourceTable
   *          the source table name
   * @throws SQLException
   *           if database error occurs
   */
  public AddressTransformBase(final String inSourceTable) throws SQLException {
    super(inSourceTable);
  }

}
