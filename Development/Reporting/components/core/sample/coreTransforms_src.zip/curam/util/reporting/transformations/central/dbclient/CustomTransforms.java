/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.central.dbclient;

import java.sql.Date;
import java.sql.SQLException;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;
import curam.util.reporting.transformations.central.base.CentralDWStaticDataTransformBase;
import curam.util.reporting.transformations.central.base.DuplicateCasesTransformDB2Impl;
import curam.util.reporting.transformations.central.fact.AddressFactory;
import curam.util.reporting.transformations.central.fact.CaseStatusHistoryFactory;
import curam.util.reporting.transformations.central.fact.EndDateFactory;
import curam.util.reporting.transformations.central.fact.FederalTransformsFactory;
import curam.util.reporting.transformations.central.fact.OrganisationUnitFactory;
import curam.util.reporting.transformations.central.fact.PersonTransformsFactory;
import curam.util.reporting.transformations.staging.base.PropertyReaderBase;
import curam.util.reporting.transformations.central.fact.PropertyReaderDBFactory;
import curam.util.type.*;

/**
 * 
 * This class is the interface or entry point between the database and the
 * staging transformations.
 * 
 * The interface specification is enforced by the Oracle and DB2 call
 * specifications A call spec exposes a Java methods top-level entry point to
 * Oracle..
 * 
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public final class CustomTransforms {

    // ___________________________________________________________________________
    /**
     * Private constructor ensures no instances of this class.
     */
    private CustomTransforms() {
    }

    @AccessLevel(AccessLevelType.RESTRICTED)
    public static void main(final String args[]) throws SQLException {
        /*
         * Calendar from = Calendar.getInstance(); from.set(Calendar.YEAR, 2005);
         * from.set(Calendar.MONTH, Calendar.FEBRUARY);
         * from.set(Calendar.DAY_OF_MONTH, 2);
         * 
         * Calendar to = Calendar.getInstance(); to.set(Calendar.YEAR, 2007);
         * to.set(Calendar.MONTH, Calendar.JANUARY); to.set(Calendar.DAY_OF_MONTH,
         * 2);
         * 
         * System.out.println("age=" + calculateAge(new
         * Date(from.getTime().getTime()), new Date(to .getTime().getTime())));
         * 
         * findCaseStatusKey(-1,new Date(from.getTime().getTime()), new Date(to
         * .getTime().getTime()));
         */

        // linkrecipientToEvidence("");
        TransactionFactory
        .overRideRequestforDefaultTransactions(DataWarehouseConstants.kCentralDatabase);

        // addRegisteredRecievedStatus("DW_ADDRESS");
        // calculatePreviousMaltreatments(1, 1, null);
        CustomTransforms.addRegisteredRecievedStatus("DW_CASEHEADER");
    }

    /**
     * 
     * Calculates the federal status values for product awarded.
     * 
     * For each CGISS recipient
     * 
     * <ol>
     * <li>only process benefit groups members</li>
     * <li>generate a timeline to process</li>
     * <li>process each month between in the time line between the start date and
     * end date</li>
     * <li>if the end date is null then set to current month</li>
     * <li>insert a record for each recipient into summary table for each month</li>
     * <li>if the end date is set set processed flag to true.</li>
     * <li>call the standard post process.</li>
     * </ol>
     * 
     * This is an algorithm based on the rules defined in the requirements
     * specifications for Curam 5.2 SP5.
     * 
     * @param inTargetTableName
     *          the target table name
     * 
     * @exception SQLException
     *              if a database operation fails
     * @deprecated see federal method
     */

    @Deprecated
    static public void linkrecipientToEvidence(final String inTargetTableName)
    throws SQLException {
        System.out
        .println(" FederalProgramsTransformsImpl test linkReciepientToEvidence"
                + " exiting early as part of test");
        return;

        // FederalTransformsFactory.newInstance().linkReciepientToEvidence(
        // inTargetTableName);
    }

    static public void federalCGISS(final String inTableName) throws SQLException {

        FederalTransformsFactory.newInstance()
        .linkReciepientToEvidence(inTableName);
    }

    /**
     * Returns a person history key for a point in time
     * 
     * @param inConcernRoleID
     *          the concern role identity.
     * @param inStartDate
     *          the start date
     * @param inEndDate
     *          the end date
     * @return boolean a person key for a point in time
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    static public int findPersonHistoryKey(final long inConcernRoleID,
            final Date inStartDate, final Date inEndDate) throws SQLException {

        return (int) (PersonTransformsFactory.newInstance().findPersonHistoryKey(
                inConcernRoleID, inStartDate, inEndDate));
    }

    /**
     * Returns a person history key for a point in time
     * 
     * @param inDWCaseID
     *          the concern role identity.
     * @param inStartDate
     *          the start date
     * @param inEndDate
     *          the end date
     * @return boolean a person key for a point in time
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    static public long findCaseStatusKey(final long inDWCaseID,
            final Date inStartDate, final Date inEndDate) throws SQLException {

        return PersonTransformsFactory.newInstance().findCaseStatusKey(inDWCaseID,
                inStartDate, inEndDate);
    }

    // ___________________________________________________________________________
    /**
     * Calculates a persons age using to dates in time. Calculate the youngest age
     * in a monthly frame
     * 
     * @param inStartDate
     *          the start date
     * @param inEndDate
     *          the end date
     * @return the age as of the first day of the month
     * @throws SQLException
     *           if the operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static int calcuateAgeInMonthlyFrame(final Date inStartDate,
            final Date inEndDate) throws SQLException {

        return PersonTransformsFactory.newInstance().calcuateAgeInMonthlyFrame(
                inStartDate, inEndDate);
    }

    // ___________________________________________________________________________
    /**
     * Calculates age in years based on two dates.
     * 
     * @param inStartDate
     *          the start date
     * @param inEndDate
     *          the end date
     * @return the age at this point in time
     * @throws SQLException
     *           if the operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static int calculateAge(final Date inStartDate, final Date inEndDate)
    throws SQLException {

        return PersonTransformsFactory.newInstance().calcuateAge(inStartDate,
                inEndDate);
    }

    // ___________________________________________________________________________
    /**
     * Calculates number of previous maltreatments for the person who is the
     * victim on an allegation It is based on the allegation date and concern role
     * and the 6 month period read from the config table
     * 
     * @param inAllegationID
     *          the allegation id
     * @param inConcernRoleID
     *          the concern role id of the victim
     * @param inAllegationDate
     *          the allegation date
     * @return the number of previous maltreatments in the previous period, the
     *         period is a configurable duration.
     * @throws SQLException
     *           if the operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static int calculatePreviousMaltreatments(final long inAllegationID,
            final long inConcernRoleID, final Date inAllegationDate)
    throws SQLException {

        return PersonTransformsFactory.newInstance()
        .calculatePreviousMaltreatments(inAllegationID, inConcernRoleID,
                inAllegationDate);
    }

    // ___________________________________________________________________________
    /**
     * Removes duplicate cases from temp table.
     * 
     * @param inTargetTable
     *          the target table name
     * 
     * @throws SQLException
     *           if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static void flagDuplicateStatus(final String inTargetTable)
    throws SQLException {

        new DuplicateCasesTransformDB2Impl(inTargetTable) {
        }.flagCaseStatusDuplicates(inTargetTable);
    }

    // ___________________________________________________________________________
    /**
     * Removes duplicate cases from temp table.
     * 
     * @param inTargetTable
     *          the target table name
     * 
     * @throws SQLException
     *           if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static void flagDuplicateCases(final String inTargetTable)
    throws SQLException {

        new DuplicateCasesTransformDB2Impl(inTargetTable) {
        }.executePostProcess(inTargetTable);
    }

    // ___________________________________________________________________________
    /**
     * Inserts static data.
     * 
     * 
     * @throws SQLException
     *           if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static void addStaticData() throws SQLException {

        new CentralDWStaticDataTransformBase().executePreProcess();
    }

    // ___________________________________________________________________________
    /**
     * Insert status records into the case status history table if the registered
     * and received dates are populated.
     * 
     * @param inTargetTable
     *          the source table name
     * 
     * @throws SQLException
     *           if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static void addRegisteredRecievedStatus(final String inTargetTable)
    throws SQLException {

        CaseStatusHistoryFactory.newInstance(inTargetTable).executePostProcess(
                inTargetTable);
    }

    // ___________________________________________________________________________
    /**
     * DB2 transform only, ensures case closure reason descriptions are set only
     * against closed case status records.
     * 
     * @param inSourceTableName
     *          the case status, e.g. open, closed etc.
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static void setClosureReason(final String inSourceTableName)
    throws SQLException {

        CaseStatusHistoryFactory.newInstance(inSourceTableName).isClosureReason(
                inSourceTableName, "");
    }

    // __________________________________________________________________________
    /**
     * Returns the closure reason where the case status is closed.
     * 
     * @param inCaseStatus
     *          the case status, e.g. open, closed etc.
     * @param inDescription
     *          the case status description
     * 
     * @return String if the case status is closed return description otherwise
     *         null
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static String isClosureReason(final String inCaseStatus,
            final String inDescription) throws SQLException {

        return CaseStatusHistoryFactory.newInstance("").isClosureReason(
                inCaseStatus, inDescription);
    }

    // __________________________________________________________________________
    /**
     * Sets the level fields in the organization unit table and executes the
     * default post process procedures.
     * 
     * @param inTargetTableName
     *          the target table being populated
     * 
     * @throws SQLException
     *           if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static void addOrgUnitLevelIndicators(final String inTargetTableName)
    throws SQLException {

        final ETLPostProcess etlPreProcess = OrganisationUnitFactory.newInstance();

        etlPreProcess.executePostProcess(inTargetTableName);
    }

    // __________________________________________________________________________
    /**
     * Extract address elements from the address string.
     * 
     * @param inSourceTableName
     *          the source table from which to read data from
     * @param inTargetTableName
     *          the target table being populated
     * 
     * @throws SQLException
     *           if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static void setAddressElements(final String inSourceTableName,
            final String inTargetTableName) throws SQLException {

        final ETLPostProcess etlPreProcess = AddressFactory
        .newInstance(inSourceTableName);

        etlPreProcess.executePostProcess(inTargetTableName);
    }

    // __________________________________________________________________________
    /**
     * Set the to date for the history table.
     * 
     * @param inETLName
     *          - note target table and ETL name are the same the target table
     *          being populated
     * @param inTable
     *          key
     * @param inSourceKey
     *          key
     * 
     * @throws SQLException
     *           if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static void setToDateFor(final String inETLName, final String inTable,
            final String inSourceKey) throws SQLException {

        final ETLPostProcess etlPreProcess = EndDateFactory.newInstance(inTable,
                inSourceKey);

        etlPreProcess.executePostProcess(inETLName);
    }

    // __________________________________________________________________________
    /**
     * Returns a property value.
     * 
     * @param inPropertyName
     *          table property name
     * 
     * @return String the property value, "not found" is returned if the property
     *         name does not exist
     * 
     * @throws SQLException
     *           if the address cannot be transformed
     */
    @AccessLevel(AccessLevelType.RESTRICTED)
    public static String readPropertyFromDB(final String inPropertyName)
    throws SQLException {
        final PropertyReaderBase reader = PropertyReaderDBFactory.newPropertyReader();

        final String propertyValue = reader.readPropertyFromDB(inPropertyName);

        return propertyValue;
    }

    // __________________________________________________________________________
    /**
     * Sets the to date for the slowly changing dimension.
     * 
     * @param inETLName
     *          - the transform ETL date in the control table.
     * @param inSourceDataETLName
     *          - the name of the control entry that adds the raw data.
     * @param inTable
     *          the table to process
     * @param inSourceKey
     *          the logical key to process
     * 
     * @throws SQLException
     *           if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static void setToDateForSCD(final String inETLName,
            final String inTable, final String inSourceKey) throws SQLException {

        final ETLPostProcess etlPreProcess = EndDateFactory.newInstanceSCD(inTable,
                inSourceKey);

        etlPreProcess.executePostProcess(inETLName);
    }

    // __________________________________________________________________________
    /**
     * Returns a property value for undefined if the data value is null.
     * 
     * @param inColumnValue
     *          the value
     * 
     * @return String the localized property value for undefined if the parameter
     *         is null
     * 
     * @throws SQLException
     *           if the address cannot be transformed
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static String readUndefinedIFNull(final String inColumnValue)
    throws SQLException {
        if (inColumnValue != null) {
            return inColumnValue;
        }
        final PropertyReaderBase reader = PropertyReaderDBFactory.newPropertyReader();
        final String propertyValue = reader
        .readPropertyFromDB(PropertyReaderBase.kUNDEFINED_PROPERTY_NAME);

        return propertyValue;
    }

    // __________________________________________________________________________
    /**
     * Returns a property value for undefined if the data value is null.
     * 
     * @param inColumnValue
     *          the value
     * @param inPropertyName
     *          the property name
     * 
     * @return String the localized property value if the value is null
     * 
     * @throws SQLException
     *           if the address cannot be transformed
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static String readPropertyIFNull(final String inColumnValue,
            final String inPropertyName) throws SQLException {
        if (inColumnValue != null) {
            return inColumnValue;
        }
        final PropertyReaderBase reader = PropertyReaderDBFactory.newPropertyReader();
        final String propertyValue = reader.readPropertyFromDB(inPropertyName);

        return propertyValue;
    }

    // __________________________________________________________________________
    /**
     * Set the to date for the history table.
     * 
     * @param inETLName
     *          - note target table and ETL name are the same the target table
     *          being populated
     * @param inSourceKey
     *          key
     * 
     * 
     * @throws SQLException
     *           if a database operation fails
     */
    @AccessLevel(AccessLevelType.EXTERNAL)
    public static void setToDate(final String inETLName, final String inSourceKey)
    throws SQLException {
        final String operationalTable = inETLName;
        final ETLPostProcess etlPreProcess = EndDateFactory.newInstance(
                operationalTable, inSourceKey);

        etlPreProcess.executePostProcess(inETLName);
    }

    /**
     * Returns a race key for ethnic origins.
     * 
     * @param inBlackOrAfrAmerIND
     *          race indicator
     * @param inNatAlaskOrAmerIND
     *          race indicator
     * @param inAsianIND
     *          race indicator
     * @param inNatjawOrPaisIND
     *          race indicator
     * @param inWhiteOrCaucIND
     *          race indicator
     * 
     * @return int the race key for the indicator parameters
     * 
     * @exception SQLException
     *              if a database operation fails
     */

    @AccessLevel(AccessLevelType.EXTERNAL)
    static public int findRaceKey(final String inBlackOrAfrAmerIND,
            final String inNatAlaskOrAmerIND, final String inAsianIND,
            final String inNatjawOrPaisIND, final String inWhiteOrCaucIND)
    throws SQLException {

        return PersonTransformsFactory.newInstance().findRaceKey(
                inBlackOrAfrAmerIND, inNatAlaskOrAmerIND, inAsianIND,
                inNatjawOrPaisIND, inWhiteOrCaucIND);
    }

    /**
     * Returns UnearnedIncomeType key based on a Benefit code and/or Un-earned
     * income code.
     * 
     * @param inUnearnedIncomeCode
     *          Benefit code and/or Un-earned income code
     * 
     * @return int UnearnedIncomeType key
     * 
     * @exception SQLException
     *              if a database operation fails
     */

    @AccessLevel(AccessLevelType.EXTERNAL)
    static public int findUnearnedIncomeKey(final String inUnearnedIncomeCode)
    throws SQLException {

        return -1;
    }

    /**
     * Returns Sanction Type key based on a Sanction Reason code.
     * 
     * @param inSanctionCode
     *          Sanction Reason code
     * 
     * @return int SanctionType key
     * 
     * @exception SQLException
     *              if a database operation fails
     */

    @AccessLevel(AccessLevelType.EXTERNAL)
    static public int findSanctionKey(final String inSanctionCode)
    throws SQLException {

        return (int) FederalTransformsFactory.newInstance().getSanctionTypeKey(
                inSanctionCode);
    }

    /**
     * Returns Federal Benefit Type key based on a BenefitType code.
     * 
     * @param inBenefitType
     *          BenefitType code
     * 
     * @return int FederalBenefitType key
     * 
     * @exception SQLException
     *              if a database operation fails
     */

    @AccessLevel(AccessLevelType.EXTERNAL)
    static public int findFedBenefitKey(final String inBenefitType)
    throws SQLException {

        return (int) FederalTransformsFactory.newInstance()
        .calculateFederalBenefitTypeStatus(inBenefitType);
    }

}
