/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.central.base;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.base.PostProcessImpl;
import curam.util.reporting.internal.transformations.prepost.fact.PreProcessFactory;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;
import curam.util.type.*;

@AccessLevel(AccessLevelType.INTERNAL)
abstract class OrgUnitPostProcessImpl extends PostProcessImpl implements
ETLPostProcess {

    /**
     * the SQL statement to read from the organization unit table.
     */
    private final String kSQLSelect = "select dworgunitid, orgunitid, parentid, orglevel, name, parentname from DW_ORGUNIT "
        + " where parentname is NULL and dworgunitid != -1 order by parentID desc";

    /**
     * updates the level for an organization unit.
     */
    private final String kSQLUpdate = "update DW_ORGUNIT set orglevel=? where dworgunitid=?";

    /**
     * inserts a new organization unit record.
     */
    private static final String kSQLInsertOracle = "insert into dw_orgunit(dworgunitid, parentid,orgunitid,name, description"
        + " ,parentname, orglevel,lastwritten)  "
        + " values (dworgunitseq.nextval,?,?,?,?,?,?,?)";

    /**
     * inserts a new organization unit record.
     */
    private static final String kSQLInsertIBM = "insert into dw_orgunit(dworgunitid, parentid,orgunitid,name, description"
        + " ,parentname, orglevel,lastwritten)  "
        + "values (nextval for dworgunitseq,?,?,?,?,?,?,?)";

    /**
     * the date at which organization records were inserted.
     */

    private static final Timestamp lastWritten = new Timestamp(
            System.currentTimeMillis());
    /**
     * the date at which organization records were inserted.
     */

    public static boolean verbose = true;

    // ___________________________________________________________________________
    /**
     * Adds level indicators on the central data warehouse organization unit table
     * and updates the control table.
     * 
     * @param inTargetTableName
     *          the target table being populated
     * @throws SQLException
     *           if a database operation fails
     */
    @Override
    public void executePostProcess(final String inTargetTableName)
    throws SQLException {
        // if an SQL statement failed, initialize to false
        boolean failed = false;
        // the database transaction
        Transaction transaction = null;

        try {
            // start a transaction
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);

            // read all records from the organization unit table
            final List<Node> orgUnitRecords = read();

            if (orgUnitRecords.size() > 0) {
                // build a hierarchy from the records
                final Organisation organisation = buildHierarchy(orgUnitRecords);

                final TreeWalker treeWalker = new TreeWalker(organisation.root,
                        new DescendentsVisitor());

                treeWalker.traverse();

                // save all records where the level indicator was set
                saveModifiedRecords(organisation);
            }
            // update the control table
            // super.executePostProcess(inTargetTableName);
        } catch (final Exception e) {

            System.out.println("OrgunitPostProcessImp: " + e.getMessage());
            failed = true;
            // do not throw an exception, allow test process to catch
            // any missing data
        } finally {

            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();

                    System.out.println("OrgUnitPostProcessImpl:transaction rolled back");

                } else {
                    // commit the changes
                    transaction.commit();
                    if (verbose) {
                        System.out.println("OrgUnitPostProcessImpl:transaction commited");
                    }
                }
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Builds a hierarchy from database records.
     * 
     * @param inOrgUnitRecords
     *          the list of records which make up the hierarchy
     * @return Organization the organization structure in hierarchical format
     * @throws SQLException
     *           if a database operation fails
     */
    public Organisation buildHierarchy(final List<Node> inOrgUnitRecords)
    throws SQLException {
        boolean addedToHierarchy = false;
        Node node;
        final Organisation organisation = new Organisation();
        final int maxIterations = 10;
        int numberIterations = 0;
        final int previousNumberNodes = 0;

        // loop until all records are added to the hierarchy
        // children may appear before parents, a number of
        // iterations may be required
        while (!addedToHierarchy) {
            for (int i = 0; i < inOrgUnitRecords.size(); i++) {
                node = inOrgUnitRecords.get(i);
                if (verbose) {
                    System.out.println("Start Processing Node:" + node.name);
                }
                if (organisation.addToHierarchy(node)) {
                    inOrgUnitRecords.remove(i);
                }
            }

            // added in a fail safe to avoid a loop to the death
            if (previousNumberNodes >= inOrgUnitRecords.size()) {
                numberIterations++;
            }
            // if all records have been added to hierarchy
            // set the exit condition to true
            // added in a fail safe to avoid a loop to the death
            if (inOrgUnitRecords.size() == 0) {
                addedToHierarchy = true;
            } else if (inOrgUnitRecords.size() == 1
                    && numberIterations > maxIterations) {
                if (verbose) {
                    System.out.println("-remaining nodes =" + inOrgUnitRecords.size()
                            + " unexpected abort");
                }
                addedToHierarchy = true;
            }
        }
        return organisation;
    }

    // ___________________________________________________________________________
    /**
     * Reads from organization unit table where the organization level is null.
     * 
     * @return List a list of records
     * @throws SQLException
     *           if a database operation fails
     */

    public List<Node> read() throws SQLException {
        // stored the record from the database
        final List<Node> orgunits = new ArrayList<Node>();
        Statement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection.createStatement();

            final ResultSet rs = statement.executeQuery(kSQLSelect);
            Node node;
            long dwOrgunitId, orgunitID;
            long orgLevel;
            long parentID;
            boolean rootFound = false;

            while (rs.next()) {
                dwOrgunitId = rs.getLong(1);
                orgunitID = rs.getLong(2);
                parentID = rs.getLong(3);
                orgLevel = rs.getLong(4);

                node = new Node(dwOrgunitId, orgunitID, (parentID == 0 ? null
                        : new Long(parentID)), (orgLevel == 0 ? null : new Long(orgLevel)),
                        rs.getString(5), rs.getString(6));

                if (rootFound && parentID == 0) {
                    throw new SQLException("Only one row can have parentID of null");
                }
                // if the parent is null this is the root organization
                if (parentID == 0) {
                    orgunits.add(0, node);
                    rootFound = true;
                } else {
                    orgunits.add(node);
                }
            }
            if (verbose) {
                System.out
                .println("OrgUnitPostProcessImpl:read: number of rows to process is "
                        + orgunits.size());
            }
            return orgunits;
        } catch (final Exception e) {
            System.out.println("OrgUnitPostProcessImpl:read:" + e);

            throw new SQLException("ab2:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // ___________________________________________________________________________
    /**
     * Updates any changed records to the organization unit table.
     * 
     * @param inOrganisation
     *          the organization hierarchy
     * @throws SQLException
     *           if a database operation fails
     */

    public void saveModifiedRecords(final Organisation inOrganisation)
    throws SQLException {

        PreparedStatement statement = null;
        int uncommitted = 0;
        final int commitLevel = 1000;

        try {

            if (inOrganisation.modifiedNodes.size() > 0) {
                final Transaction transaction = TransactionFactory
                .getTransaction(DataWarehouseConstants.kDefaultDatabase);
                Node node;

                statement = transaction.getConnection().prepareStatement(kSQLUpdate);
                final Iterator<Node> iterator = inOrganisation.modifiedNodes.iterator();

                while (iterator.hasNext()) {
                    node = (Node) iterator.next();
                    statement.setInt(1, node.getLevel().intValue());
                    statement.setLong(2, node.dwOrgUnitid);
                    statement.addBatch();
                    uncommitted++;
                    if (uncommitted >= commitLevel) {
                        transaction.executeBatch(statement);
                        uncommitted = 0;
                    }
                }
                if (uncommitted >= 0) {
                    transaction.executeBatch(statement);
                    uncommitted = 0;
                }
            }
        } catch (final Exception e) {
            System.out.println("OrgUnitPostProcessImpl:saveModifiedRecords:" + e);
            throw new SQLException("OrgUnitPostProcessImpl:saveModifiedRecords:"
                    + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    /**
     * Sets the date from which to extract data from.
     * 
     * @param inParent
     *          the nodes parent * @param inNode the node to insert
     * @param inNode
     * @param inLastWritten
     *          the date the record was created
     * @throws SQLException
     *           if database operation failed
     */
    public static void insertRecord(final Node inParent, final Node inNode,
            final Timestamp inLastWritten) throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;
        String sql = "insert into db2admin.dw_orgunit(dworgunitid, parentid,orgunitid,name, description ,parentname, orglevel,lastwritten)"
            + " values (nextval for db2admin.dworgunitseq,";

        try {
            // get a new connection
            transaction = TransactionFactory.getMostRecent();
            final Connection connection = transaction.getConnection();

            // default the insert statement to oracle format
            String insertSQL = kSQLInsertOracle;

            if (TransactionFactory.getTargetDatabaseType(
                    DataWarehouseConstants.kDefaultDatabase).isDB2()) {
                insertSQL = kSQLInsertIBM;

            }

            statement = connection.prepareStatement(insertSQL);
            // set parent - logical id
            final int i = 88;

            if (inNode.isRoot()) {
                statement.setLong(1, inNode.orgInitid);
                sql = sql + inNode.orgInitid;
            } else {
                statement.setLong(1, inParent.orgInitid);
                sql = sql + inParent.orgInitid;
            }

            // set organization unit - logical id
            statement.setLong(2, inNode.orgInitid);
            sql = sql + "," + inNode.orgInitid;
            // set name
            statement.setString(3, inNode.name);
            sql = sql + ",'" + inNode.name + "'";
            // set description
            statement.setString(4, inNode.name);
            sql = sql + ",'" + inNode.name + "'";
            // set parent name
            if (inNode.isRoot()) {
                statement.setString(5, inNode.name);
                sql = sql + ",'" + inNode.name + "'";
            } else {
                statement.setString(5, inParent.name);
                sql = sql + ",'" + inParent.name + "'";
            }
            // set org level
            statement.setInt(6, inNode.orgLevel.intValue());
            sql = sql + "," + inNode.orgLevel.intValue();

            // set last written
            statement.setTimestamp(7, inLastWritten);
            sql = sql + ",current timestamp)";

            statement.executeUpdate();

        } catch (final Exception e) {
            System.out.println(sql + System.getProperty( "line.separator" ) + "    " +
                    inNode.toString());
            throw new SQLException("insertRecord:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
    }

    /**
     * Builds an organization hierarchy from a set of relation records.
     */
    static class Organisation {

        /**
         * the root level.
         */
        static final int kRootLevel = 1;

        /**
         * the root node in the hierarchy.
         */
        private Node root;

        /**
         * counter recording the depth of the current search.
         */
        private int currentDepth = kRootLevel;

        private final boolean infoMessages = true;

        /**
         * the list of nodes where the level indicator was updated.
         */
        private final List<Node> modifiedNodes = new ArrayList<Node>();

        // ________________________________________________________________________
        /**
         * Adds a node to the hierarchy if it's parent can be found.
         * 
         * @param inNewNode
         *          the node to be added to the hierarchy
         * @return boolean
         */
        public boolean addToHierarchy(final Node inNewNode) {
            if (root == null) {
                root = inNewNode;
                if (root.getLevel() == null) {
                    root.setLevel(1);
                    modifiedNodes.add(root);
                }
                return true;
            }
            // set the current level to one
            currentDepth = kRootLevel;
            return addToHierarchy(root, inNewNode);
        }

        // ________________________________________________________________________
        /**
         * Adds the node to the hierarchy by searching for it's parent, this is a
         * recursive method.
         * 
         * @param inParent
         *          the parent node
         * @param inNewNode
         *          the node to be added to the hierarchy
         * @return boolean
         */
        private boolean addToHierarchy(final Node inParent, final Node inNewNode) {
            // check this node first then its children
            currentDepth++;
            if (isParent(inParent, inNewNode)) {
                return true;
            }
            // check the children

            for (Node child = (Node) inParent.getFirstChild(); child != null; child = (Node) inParent
            .getNextSibling()) {
                if (addToHierarchy(child, inNewNode)) {
                    return true;
                }
            }
            currentDepth--;
            return false;
        }

        // ________________________________________________________________________
        /**
         * Checks if two nodes are related.
         * 
         * @param inParent
         *          the parent node
         * @param inNewNode
         *          the node to be added to the hierarchy
         * @return boolean
         */
        private boolean isParent(final Node inParent, final Node inNewNode) {
            // if the root node its parent

            if (infoMessages) {
                for (int i = 0; i < currentDepth; i++) {
                    if (verbose) {
                        System.out.print("    ");
                    }
                }
            }
            if (verbose) {
                System.out.println("depth=" + currentDepth + "parent="
                        + inParent.orgInitid + "  child=" + inNewNode.orgInitid);
            }
            if (inParent.orgInitid == inNewNode.parentID.longValue()) {
                inNewNode.setParent(inParent);
                if (inNewNode.getLevel() == null) {
                    inNewNode.setLevel(currentDepth);
                    modifiedNodes.add(inNewNode);
                }
                inParent.addChild(inNewNode);
                return true;
            }

            return false;
        }
    }

    /**
     * Implements a organization unit node in the organization hierarchy.
     */
    static class Node {

        /**
         * the parent of this node, null if this is the root node.
         */
        private Object parent;

        /**
         * the surrogate key in the data warehouse.
         */
        private final long dwOrgUnitid;

        /**
         * the logical key.
         */
        private final long orgInitid;

        /**
         * the level in the organization, may be null.
         */
        private Long orgLevel;

        /**
         * the parent organization, may be null if this is the root.
         */
        private final Long parentID;

        /**
         * set to true is the level was updated.
         */
        private boolean modified;

        /**
         * organization unit name.
         */
        private final String name;

        /**
         * organization unit name.
         */
        private final String parentName;

        /**
         * the first element in the array, it's value is {@value} .
         */
        private static final int kFirstChild = 0;

        /**
         * the current element a call to getFirstChild, resets this to zero.
         */
        private int currentChild;

        /**
         * the list of child organizations.
         */
        private final List<Node> childJoins;

        // ________________________________________________________________________
        /**
         * Constructs a new Node.
         * 
         * @param inDWOrgUnit
         *          surrogate key
         * @param inOrgUnitId
         *          logical key
         * @param inParentID
         *          parent logical key
         * @param inLevel
         *          level
         * @param inName
         *          organization unit name
         * @param inParentName
         *          parent name
         */
        public Node(
                final long inDWOrgUnit,
                final long inOrgUnitId,
                final Long inParentID,
                final Long inLevel,
                final String inName,
                final String inParentName) {

            parentID = inParentID;
            childJoins = new ArrayList<Node>();
            dwOrgUnitid = inDWOrgUnit;
            orgInitid = inOrgUnitId;
            name = inName;
            parentName = inParentName;
            if (inLevel != null) {
                orgLevel = inLevel;
            }
        }

        @Override
        public String toString() {
            final StringBuffer sb = new StringBuffer();
            sb.append(" name=" + (name == null ? "" : name.trim()));
            sb.append(" parentName=" + (parentName == null ? "" : parentName.trim()));
            sb.append(" dwOrgUnitid=" + dwOrgUnitid);
            sb.append(" parentID=" + parentID);
            sb.append(" orgInitid=" + orgInitid);

            return sb.toString();
        }

        // ________________________________________________________________________
        /**
         * Sets the level in the organization.
         * 
         * @param inLevel
         *          returns the level in the organization may be null
         */
        public void setLevel(final int inLevel) {
            modified = true;
            orgLevel = new Long(inLevel);
        }

        // ________________________________________________________________________
        /**
         * Returns the if the level indicator was updated.
         * 
         * @return boolean
         */
        public boolean isModified() {
            return modified;
        }

        // ________________________________________________________________________
        /**
         * Returns the level in the organization.
         * 
         * @return Integer returns the level in the organization may be null
         */
        public Integer getLevel() {
            if (orgLevel == null) {
                return null;
            }

            return new Integer(orgLevel.intValue());
        }

        // ________________________________________________________________________
        /**
         * Returns true if this is the root.
         * 
         * @return boolean
         */
        public boolean isRoot() {
            return parent == null;
        }

        // ________________________________________________________________________
        /**
         * Sets the parent.
         * 
         * @param inParent
         *          the nodes parent
         */
        public void setParent(final Object inParent) {
            parent = inParent;
        }

        // ________________________________________________________________________
        /**
         * Gets the parent.
         * 
         * @return Object
         */
        public Object getParent() {
            return parentID;
        }

        // ________________________________________________________________________
        /**
         * Adds a child.
         * 
         * @param inNode
         *          the child to add
         */
        public void addChild(final Node inNode) {
            childJoins.add(inNode);
        }

        // ________________________________________________________________________
        /**
         * Returns all children.
         * 
         * @return List
         */
        public List<Node> getChildren() {
            return childJoins;
        }

        // ________________________________________________________________________
        /**
         * Returns the first child.
         * 
         * @return Object
         */
        public Object getFirstChild() {
            currentChild = kFirstChild;
            return childJoins.size() == kFirstChild ? null : ((Object) childJoins
                    .get(kFirstChild));
        }

        // ________________________________________________________________________
        /**
         * Returns the next sibling.
         * 
         * @return Object
         */
        public Object getNextSibling() {
            return ++currentChild >= childJoins.size() ? null : ((Object) childJoins
                    .get(currentChild));
        }

        // ________________________________________________________________________
        /**
         * Returns true if this is a leaf.
         * 
         * @return boolean
         */
        public boolean isLeaf() {
            return childJoins.size() == 0;
        }

    }

    /**
     * This module defines the visitor interface.
     */
    public interface Visitor {
        // ________________________________________________________________________
        /**
         * The method to execute on the visitor.
         * 
         * @param inNode
         *          the node being visited
         */
        void visit(Node inNode);
    }

    /**
     * This module defines functions to traverse a node and insert record for each
     * child.
     */
    public static class DescendentsVisitor implements Visitor {
        // ________________________________________________________________________
        /**
         * Visits each node.
         * 
         * @param inNode
         *          the node being visited
         */
        public void visit(final Node inNode) {
            if (verbose) {
                System.out.println("processing hierarchy->" + inNode.name);
            }
            final TreeWalker treeWalker = new TreeWalker(inNode,
                    new UpdateDatabaseVisitor(inNode));

            treeWalker.traverse();
            if (verbose) {
                System.out.println("completed nodes at root " + inNode.name);
            }
        }
    }

    /**
     * This module defines functions to inserts a record for each child in a
     * hierarchy for a root node.
     */
    public static class UpdateDatabaseVisitor implements Visitor {

        /**
         * the root node of this hierarchy.
         */
        private final Node root;

        /**
         * See the parent of each child.
         * 
         * @param inRoot
         *          the root node
         */
        public UpdateDatabaseVisitor(final Node inRoot) {
            root = inRoot;
        }

        // ________________________________________________________________________
        /**
         * The method to execute on the visitor.
         * 
         * @param inNode
         *          the node being visited
         */
        public void visit(final Node inNode) {
            try {
                insertRecord(root, inNode, lastWritten);
            } catch (final SQLException e) {
                if (verbose) {
                    System.out.println("        Warning:record already exists:"
                            + inNode.toString());
                    System.out.println("        Warning:record already exists:"
                            + e.getMessage());
                }
            }
        }
    }

    /**
     * Traverses a hierarchy calling the visitor.
     */

    public static class TreeWalker {

        /**
         * the root of the hierarchy.
         */
        private final Node root;

        /**
         * the visitor for each node.
         */
        private final Visitor visitor;

        /**
         * Create a tree walker to visit nodes.
         * 
         * @param inRootNode
         *          the root
         * @param inVisitor
         *          the visitor
         */
        public TreeWalker(final Node inRootNode, final Visitor inVisitor) {
            root = inRootNode;
            visitor = inVisitor;
        }

        /**
         * traverses the hierarchy.
         */
        public void traverse() {
            traverse(root);
        }

        /**
         * Recursive method to traverse the hierarchy.
         * 
         * @param inNode
         *          the node to process
         */
        private void traverse(final Node inNode) {
            for (int i = 0; i < inNode.getLevel().intValue(); i++) {
                System.out.print("  ");
            }
            if (verbose) {
                System.out.println(inNode.name);
            }
            // process the parent
            visitor.visit(inNode);
            for (Node child = (Node) inNode.getFirstChild(); child != null; child = (Node) inNode
            .getNextSibling()) {
                traverse(child);
            }
        }
    }

    public static void main(final String args[]) throws SQLException {
        final String etlname = "DW_ORGUNIT_TRANSFORM";
        TransactionFactory
        .overRideRequestforDefaultTransactions(DataWarehouseConstants.kCentralDatabase);

        System.out.println("About to execute PRE process for " + etlname);
        PreProcessFactory.newInstance().executePreProcess(etlname);
        System.out.println("Executed PRE process for " + etlname);
        System.out.println("About to execute POST process for " + etlname);
        new OrgUnitPostProcessImpl() {
        }.executePostProcess(etlname);
        System.out.println("Executed POST process for " + etlname);
    }
}
