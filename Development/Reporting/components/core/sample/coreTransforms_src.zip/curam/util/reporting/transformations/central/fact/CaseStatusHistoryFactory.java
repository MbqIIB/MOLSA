/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.central.fact;

import java.sql.SQLException;

import curam.util.reporting.transformations.central.base.CaseStatusHistoryTransformBase;
import curam.util.reporting.transformations.central.intf.CaseStatusHistoryTransfrom;

import curam.util.type.*;

/**
 * Factory class to create an instance of case status transformation
 * {@link CaseStatusHistoryTransfrom} class, one of its subclasses, a proxy for
 * it or a mock object for it.
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public final class CaseStatusHistoryFactory {

  // ___________________________________________________________________________
  /**
   * Private constructor ensures no instances of this class.
   */
  private CaseStatusHistoryFactory() {
  }

  // ___________________________________________________________________________
  /**
   * Returns a new object to load data into the case status history table.
   * 
   * @param inSourceTableName
   *          the table name to update/read
   * @return ETLPostProcess
   * @throws java.sql.SQLException
   *           if a database operation fails
   */
  public static CaseStatusHistoryTransfrom newInstance(
      final String inSourceTableName) throws SQLException {
    // returns the base implementation of the data access object
    CaseStatusHistoryTransfrom caseStatusHistoryTransfrom;

    caseStatusHistoryTransfrom = new CaseStatusHistoryTransformBase();

    return caseStatusHistoryTransfrom;
  }

}
