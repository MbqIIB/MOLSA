/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.coredatamarts.base;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.base.PostProcessImpl;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;

/**
 * This module populates the fact case process aggregate table.
 * 
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
abstract class CaseFactProcessTransformImpl extends PostProcessImpl implements
    ETLPostProcess {

  /**
   * update SQL
   */
  private final String kUodateFactSQL = "update dm_factcasehistory set enddatekey=?"
      + " where caseid=? and startdatekey=?";

  /**
   * SQL to read where to date is null.
   */
  private final String sqlSelectLatestFacts = "select caseid, startdatekey as fromdatekey from dm_factcasehistory t1,"
      + " dm_dimtimeperiod t2 "
      + " where enddatekey = -1 and t1.startdatekey=t2.timeperiodkey"
      + " order by caseid, t2.daydate desc";

  public static void main(String args[]) throws SQLException {
    new CaseFactProcessTransformImpl() {
    }.executePostProcess("DM_FACTCASEPROCESS");
  }

  // ___________________________________________________________________________
  /**
   * Populates the aggregate table using the case fact processes table.
   * 
   * @param inTargetTableName
   *          the target table being populated
   * @throws java.sql.SQLException
   *           if a database operation failed
   */
  @Override
  public void executePostProcess(final String inTargetTableName)
      throws SQLException {
    // if an SQL statement failed, initialize to false
    boolean failed = false;
    // the database transaction
    Transaction transaction = null;

    try {
      // start a transaction, get DAO to read from the control table
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      updateToDateOfPreviousStatuses();

      // update the control table
      super.executePostProcess(inTargetTableName);
    } catch (Exception e) {
      System.out.println("CaseFactProcessTransformImpl: caught exception "
          + e.getMessage());
      failed = true;
      throw new SQLException("CaseFactProcessTransformImpl:" + e.getMessage());
    } finally {

      if (transaction != null && !transaction.isClientManagedTransaction()) {
        if (failed) {
          transaction.rollback();
          System.out
              .println("CaseFactProcessTransformImpl:failed, transaction rolled back");
        } else {
          // commit the changes
          transaction.commit();
          System.out
              .println("CaseFactProcessTransformImpl:transaction commited, processed ");
        }
      }
    }
  }

  // __________________________________________________________________________
  /**
   * Sets the number of cases on hand prior to a given date.
   * 
   * @throws SQLException
   *           if a database operation fails
   */

  private void updateToDateOfPreviousStatuses() throws SQLException {

    // stored the record from the database
    PreparedStatement statement = null;

    try {
      final Connection connection = TransactionFactory.getTransaction(
          DataWarehouseConstants.kDefaultDatabase).getConnection();

      statement = connection.prepareStatement(sqlSelectLatestFacts);
      final ResultSet rs = statement.executeQuery();

      FactKey mostRecentStatus = null;
      FactKey previousstatusForCase = null;

      while (rs.next()) {
        mostRecentStatus = new FactKey(rs.getLong(1), rs.getLong(2));

        if (previousstatusForCase != null
            && mostRecentStatus.dwCaseID == previousstatusForCase.dwCaseID) {

          mostRecentStatus.toDateKey = previousstatusForCase.fromDateKey;
          System.out.println("setting TODATE on case <"
              + mostRecentStatus.dwCaseID + "> with from date<"
              + mostRecentStatus.fromDateKey + "> to "
              + mostRecentStatus.toDateKey);

          update(mostRecentStatus);
        } else {
          previousstatusForCase = mostRecentStatus;
          System.out.println("next case " + mostRecentStatus.dwCaseID);
        }
      }

    } catch (Exception e) {
      System.out.println("readCasesOnHand:readCasesOnHand:" + e);
      throw new SQLException("readCasesOnHand:" + e.getMessage());
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Sets the to date value
   * 
   * @param inFactKey
   *          the target table being populated
   * @throws SQLException
   *           if database operation failed
   */
  public void update(final FactKey inFactKey) throws SQLException {

    PreparedStatement statement = null;
    Transaction transaction = null;

    try {

      // get a new connection
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();

      statement = connection.prepareStatement(kUodateFactSQL);

      // set month
      statement.setLong(1, inFactKey.toDateKey);

      // set case
      statement.setLong(2, inFactKey.dwCaseID);

      // set cases on hand at start of month

      statement.setLong(3, inFactKey.fromDateKey);
      final int rowsUpdated = statement.executeUpdate();

      if (rowsUpdated != 1) {
        System.out.println("CaseFactProcessTransformImpl:updated "
            + rowsUpdated + " rows.");
      }

    } catch (Exception e) {
      System.out.println("CaseFactProcessTransformImpl:update:" + e);
      throw new SQLException("CaseFactProcessTransformImpl:update:"
          + e.getMessage());
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }

  }

  /**
   * This module defines the key to fact records.
   */
  class FactKey {

    /**
     * the from date for a case status record.
     */

    private final long fromDateKey;

    /**
     * the to date for a case status record.
     */
    private long toDateKey;

    /**
     * the case id.
     */
    private final long dwCaseID;

    /**
     * Creates a new fact key for latest records.
     * 
     * @param inDWCaseID
     *          the case identity
     * @param inFromDate
     *          the from date
     */
    public FactKey(final long inDWCaseID, final long inFromDate) {
      fromDateKey = inFromDate;
      dwCaseID = inDWCaseID;
    }

    /**
     * Sets the to date for a case status records.
     * 
     * @param inToDate
     *          the end date for a status
     */
    public void setToDate(final long inToDate) {
      toDateKey = inToDate;
    }

  }
}
