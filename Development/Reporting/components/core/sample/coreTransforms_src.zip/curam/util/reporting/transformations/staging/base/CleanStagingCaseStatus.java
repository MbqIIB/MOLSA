/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.staging.base;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;

import curam.util.reporting.internal.transformations.prepost.fact.PostProcessFactory;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;

/**
 * Provides various methods to process case status values.
 * 
 * 
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
abstract class CleanStagingCaseStatus implements ETLPostProcess {

    /**
     * test harness test data.
     */

    static final private List<CaseStatusData> testData = new ArrayList<CaseStatusData>();
    {
        testData.add(new CaseStatusData(1,
                new Timestamp(System.currentTimeMillis()), "Active"));
        testData.add(new CaseStatusData(1,
                new Timestamp(System.currentTimeMillis()), "Active"));

    }

    /**
     * SQL statement to read the Case Status rows duplicate rows in staging.
     */

    private final String readStagingCaseStatusSQL;

    /**
     * SQL statement to delete duplicate row where enddate is not null
     */
    private final String deleteDupCaseStatusSQL;

    /**
     * Creates and initializes an object to process case status value in the Curam
     * reporting staging schema
     * 
     * @param inSourceTableName
     *          the staging case status table name, this is also the target table
     *          name value in the control table
     * @throws SQLException
     */
    public CleanStagingCaseStatus(final String inSourceTableName)
    throws SQLException {

        readStagingCaseStatusSQL = "select caseid, startdate, statusdescription, count(*) as count from "
            + inSourceTableName
            + " group by caseid, startdate, statusdescription having count(*) >1 and statusdescription='Active'";

        deleteDupCaseStatusSQL = "delete from "
            + inSourceTableName
            + " where enddate is not null and caseid=? AND startdate=? and statusdescription=?";
    }

    // ______________________________________________________________________
    /**
     * Deletes duplicate case status records with a status description of Active
     * and where enddate is not null.
     * 
     * @param inTargetTableName
     *          table name where source data resides
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    public void executePostProcess(final String inTargetTableName)
    throws SQLException {
        // stored success of SQL statements

        boolean failed = false;
        // the database transaction
        Transaction transaction = null;

        try {
            // start a transaction
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);

            final List<CaseStatusData> sourceData = readSourceData(readStagingCaseStatusSQL);

            deleteCaseStatusRecords(sourceData, deleteDupCaseStatusSQL);

            PostProcessFactory.newInstance().executePostProcess(inTargetTableName);

        } catch (final Exception e) {
            System.out.println("CleanStagingCaseStatus:execute: caught exception "
                    + readStagingCaseStatusSQL + e.getMessage());
            failed = true;
            // do not throw an exception, allow our test process to
            // pick up on any data quality issues.
        } finally {
            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                    System.out.println("CleanStagingCaseStatus:failed");
                } else {
                    // commit the changes
                    transaction.commit();
                    System.out.println("CleanStagingCaseStatus:successful");
                }
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Returns the set of cases which are duplicates.
     * 
     * @param inSQLSelect
     *          the SQL to read source data
     * 
     * @return List record for possible deletion
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    private List<CaseStatusData> readSourceData(final String inSQLSelect)
    throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;
        final List<CaseStatusData> sourceData = new ArrayList<CaseStatusData>();

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection.prepareStatement(inSQLSelect);

            final ResultSet rs = statement.executeQuery();
            CaseStatusData caseStatusRecord;

            while (rs.next()) {
                caseStatusRecord = new CaseStatusData(rs.getLong(1),
                        rs.getTimestamp(2), rs.getString(3));
                sourceData.add(caseStatusRecord);
            }

            System.out.println("Clean CaseStatus Records: " + sourceData.size()
                    + " case status records to be processed");

        } catch (final Exception e) {
            System.out.println("CleanStagingCaseStatus:execute: " + e);
            throw new SQLException("CleanStagingCaseStatus:execute: "
                    + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
        return sourceData;
    }

    /**
     * this is s method use by the test harness to test the delete SQL
     * 
     * @exception SQLException
     *              if a database operation fails
     */

    public void deleteCaseStatusRecords() throws SQLException {
        deleteCaseStatusRecords(testData, deleteDupCaseStatusSQL);
    }

    /**
     * Deletes duplicate records
     * 
     * @param inStatusRecords
     *          record for possible deletion
     * @param inDeleteSQL
     *          the delete SQL statement
     * @exception SQLException
     *              if a database operation fails
     */

    private void deleteCaseStatusRecords(
            final List<CaseStatusData> inStatusRecords, final String inDeleteSQL)
    throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;
        final Transaction transaction = TransactionFactory.getTransaction(
                DataWarehouseConstants.kDefaultDatabase);
        try {
            CaseStatusData caseStatusRecord = null;
            final Connection connection = transaction.getConnection();

            statement = connection.prepareStatement(inDeleteSQL);
            final int commitLevel = 1000;
            int uncommitted = 0;
            final Iterator<CaseStatusData> records = inStatusRecords.iterator();

            while (records.hasNext()) {
                caseStatusRecord = (CaseStatusData) records.next();

                statement.setLong(1, caseStatusRecord.caseID);
                statement.setTimestamp(2, caseStatusRecord.startDate);
                statement.setString(3, caseStatusRecord.statusDesc);

                statement.addBatch();
                uncommitted++;
                if (uncommitted >= commitLevel) {
                    transaction.executeBatch(statement);
                    uncommitted = 0;
                }
            }
            if (uncommitted >= 0) {
                transaction.executeBatch(statement);
                uncommitted = 0;
            }


            System.out.println("CleanStagingCaseStatus:"
                    + System.getProperty("line.separator") + inStatusRecords.size()
                    + " case status records read for deletion");

        } catch (final Exception e) {
            System.out.println("CleanStagingCaseStatus:deleteStatuses:" + e);
            throw new SQLException("CleanStagingCaseStatus:deleteStatuses:"
                    + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
    }

    // __________________________________________________________________

    /**
     * Value object for Case Status data.
     */
    class CaseStatusData {

        /**
         * the surrogate case identity.
         */
        private final long caseID;

        /**
         * the registered date for a case.
         */
        private final Timestamp startDate;

        /**
         * the status description for a case.
         */
        private final String statusDesc;

        /**
         * Creates data for a new status record.
         * 
         * @param inCaseID
         *          case id
         * @param inStartDate
         *          start date
         * @param inStatusDesc
         *          case status description
         */
        public CaseStatusData(
                final long inCaseID,
                final Timestamp inStartDate,
                final String inStatusDesc) {
            caseID = inCaseID;
            startDate = inStartDate;
            statusDesc = inStatusDesc;
        }
    }

}
