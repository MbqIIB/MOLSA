/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.central.base;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.base.PostProcessImpl;
import curam.util.reporting.transformations.central.fact.PersonTransformsFactory;
import curam.util.reporting.transformations.central.intf.FederalTransforms;
import curam.util.type.*;

/**
 * Calculates the federal status values for products awarded.
 * 
 * For each CGISS recipient
 * 
 * <ol>
 * <li>only process benefit groups members</li>
 * <li>generate a time line to process</li>
 * <li>process each month between in the time line between the start date and
 * end date</li>
 * <li>if the end date is null then set to current month</li>
 * <ol>
 * <li>calculate the age in the monthly frame, age for all the month</li>
 * <li>set the federal adult indicator, based on age and educational levels</li>
 * <li>calculate the federal maintenance assistance status, based on program and
 * benefit type</li>
 * <li>calculate the federal basis of eligibility assistance status</li>
 * <li>calculate the federal basis of dual eligible status, based on products
 * awarded</li>
 * <li>calculate the federal household assistance status, based on benefit types
 * </li>
 * <li>calculate the parent indicator , based on household roles</li>
 * <li>calculate the federal educational status, based on education level</li>
 * <li>calculate the earned, unearned, cash resources amounts, based 4 evidence
 * tables</li>
 * <li>calculate the federal sanction status, based on product and sanction type
 * </li>
 * <li>calculate the federal employment status, based 4 evidence tables</li>
 * </ol>
 * <li>insert a record for each recipient into summary table for each month</li>
 * <li>if the end date is set set processed flag to true.</li> <li>call the
 * standard post process.</li> </ol>
 * 
 * This is an algorithm based on the rules defined in the requirements
 * specifications for Curam 5.2.
 */

@AccessLevel(AccessLevelType.INTERNAL)
@SuppressWarnings({ "rawtypes", "unchecked" })
class FederalProgramsTransformsImpl extends PostProcessImpl implements
    FederalTransforms {

  public static void main(String args[]) throws SQLException {
    /*
     * Calendar from = Calendar.getInstance(); from.set(Calendar.YEAR, 2005);
     * from.set(Calendar.MONTH, Calendar.FEBRUARY);
     * from.set(Calendar.DAY_OF_MONTH, 2);
     * 
     * Calendar to = Calendar.getInstance(); to.set(Calendar.YEAR, 2007);
     * to.set(Calendar.MONTH, Calendar.JANUARY); to.set(Calendar.DAY_OF_MONTH,
     * 2);
     * 
     * System.out.println("        age=" + calculateAge(new
     * Date(from.getTime().getTime()), new Date(to .getTime().getTime())));
     * 
     * findCaseStatusKey(-1,new Date(from.getTime().getTime()), new Date(to
     * .getTime().getTime()));
     */

    // linkReciepientToEvidence("");
    TransactionFactory
        .overRideRequestforDefaultTransactions(DataWarehouseConstants.kCentralDatabase);

    // addRegisteredRecievedStatus("DW_ADDRESS");
    // new PersonTransformsImpl().findPersonHistoryKey(101, new Date(63, 01,
    // 01),
    // new Date(63, 01, 01), 2);
    new FederalProgramsTransformsImpl()
        .monthlyProcess("DW_CASERECIPIENT_MONTH");
  }

  private final boolean isSilent = false;

  /**
   * a mapping for product codes to the un-earned income federal status codes
   * see also the initial data for the federal status codes and values
   * initializeUnEarnedIncomeCodes
   */
  // private Map unearnedIncomeByProduct;

  // ___________________________________________________________________________
  /**
   * Creates an object to generate recipient attributes.
   * 
   * 
   * @throws SQLException
   *           if database error occurs
   */
  public FederalProgramsTransformsImpl() throws SQLException {
  }

  /**
   * Determines the household assistance federal status code
   * 
   * @param inRecipient
   * @return
   * @throws SQLException
   */
  protected BenefitEvidence calculateHouseholdAssistanceStatus(
      Recipient inRecipient) throws SQLException {

    MedicalAssistance assistanceStatus = null;
    BenefitEvidence benefitEvidence = null;
    if (kClassicFoodProgramCode.equalsIgnoreCase(inRecipient.getProgramCode())) {
      StringBuffer assistanceProductTypes = new StringBuffer(
          "BT12 BT8 BT24 BT6");

      List benefits = findBenefitRecord(inRecipient);
      Iterator iterator = benefits.iterator();

      while (iterator.hasNext()) {
        benefitEvidence = (BenefitEvidence) iterator.next();
        if (benefitEvidence != null
            && assistanceProductTypes.indexOf(benefitEvidence.getType()) == kUndefinedKey) {
          // read the public assistance key
          Long assistanceKey = null;
          // find the key for this product
          assistanceKey = findLookUpKey(readAssistanceStatusKey,
              kPublicAssiatanceKey);
          if (assistanceKey == null) {
            // this is an error, default to undefined
            assistanceKey = new Long(-1);
            if (!isSilent) {
              System.out
                  .print("Error:calculateHouseholdAssistanceStatus: could not find code in table using "
                      + readAssistanceStatusKey
                      + "with "
                      + kPublicAssiatanceKey);
            }
          } else {
            assistanceStatus = new MedicalAssistance(assistanceKey.intValue());
          }
        }
      }

      if (assistanceStatus == null) {
        Long assistanceKey = null;
        // find the key for this product
        assistanceKey = findLookUpKey(readAssistanceStatusKey,
            kNonPublicAssiatanceKey);
        if (assistanceKey == null) {
          // this is an error, default to undefined
          assistanceKey = new Long(-1);
          if (!isSilent) {
            System.out
                .print("Error:calculateHouseholdAssistanceStatus: could not find code in table using "
                    + readAssistanceStatusKey + "with " + kPublicAssiatanceKey);
          }
        }
        assistanceStatus = new MedicalAssistance(assistanceKey.intValue());
      }

      inRecipient.setAssistanceStatus(assistanceStatus);

    } else {
      // this is an error, default to undefined
      Long assistanceKey = new Long(-1);
      assistanceStatus = new MedicalAssistance(assistanceKey.intValue());
    }
    inRecipient.setAssistanceStatus(assistanceStatus);

    return benefitEvidence;

  }

  private RecordExistsEvidence calculateChildSupportEnforcementStatus(
      Recipient inRecipient) {

    final String kChildEnforcementYesCode = "YES";
    final String kChildenforcementNoCode = "NO";
    final String kChildenforcementUndefinedCode = "UNDEFINED";
    String code = kChildenforcementUndefinedCode;

    RecordExistsEvidence childEnforcementEvidence = null;
    try {
      childEnforcementEvidence = checkSingleRecordExists(inRecipient,
          readChildSupportEnforceByDate, kEvidenceNameChildSupportEnforcement,
          true);
    } catch (SQLException e1) {
      // ignore, the SQL is valid
      System.out.println("            calculateChildSupportEnforcementStatus:"
          + e1.getMessage());
    }

    Long childKey = new Long(kUndefinedKey);

    if (childEnforcementEvidence != null) {
      if (childEnforcementEvidence.getType().equalsIgnoreCase(
          kChildEnforcmentStringYes)) {
        code = kChildEnforcementYesCode;
      } else {
        code = kChildenforcementNoCode;
      }
    }
    // the dual key
    Long key = null;
    try {
      // find the key for this product
      key = findLookUpKey(readFChildSupportStatusKey, code);
    } catch (SQLException e) {
      // ignore, the SQL is valid
      System.out.println("            calculateChildSupportEnforcementStatus:"
          + e.getMessage());
    }
    // if we found a key then set the value
    // otherwise leave the default value as undefined
    if (key != null) {
      childKey = key;
    }

    inRecipient.setChildEnforcementKey(childKey.intValue());
    return childEnforcementEvidence;
  }

  private void calculateDualEligibleStatus(Recipient inRecipient) {

    final String readDualKeyNotDualProductCode = "NOT A DUEL ELIGIBLE PRODUCT";

    Long dualKey = new Long(kUndefinedKey);

    if (kClassicFoodProgramCode.equalsIgnoreCase(inRecipient.getProgramCode())) {
      // the dual key
      Long hasDualKey = null;
      try {
        // find the key for this product
        hasDualKey = findLookUpKey(readDualKeyForProduct,
            inRecipient.getProductCode());
        // if the product is not part of a dual product award
        // then find the right key for the not dual product code value
        if (hasDualKey == null) {
          hasDualKey = findLookUpKey(readDualKeyNotDualProduct,
              readDualKeyNotDualProductCode);
        }
      } catch (SQLException e) {
        // ignore, the SQL is valid
        System.out.println("            calculateDualEligibles:" + e.getMessage());
      }
      // if we found a key then set the value
      // otherwise leave the default value as undefined
      if (hasDualKey != null) {
        dualKey = hasDualKey;
      }
    }

    MedicalAssistance dualEligibleKey = new MedicalAssistance(
        dualKey.intValue());
    inRecipient.setDualEligible(dualEligibleKey);

  }

  /**
   * Determines the maintenance assistance federal code and the basis of
   * eligibility federal code
   * 
   * @param inRecipient
   */
  protected void calculateMASAndBOEStatus(Recipient inRecipient,
      Map inBOEStatusesByProduct) {

    StringBuffer masDualEligibleProductTypes = new StringBuffer("PN36 PN37");
    MedicalAssistance masValue = null;
    BasisOfEligibilityStatus boeValue = null;
    if (!isSilent) {
      System.out.println("        Setting MAS and BOE statuses");

    }

    // set the MAS and BOE values if
    if (kClassicMedicalProgramCode.equalsIgnoreCase(inRecipient
        .getProgramCode())) {
      // if a recipient is eligible for one of the dual eligible products
      // they will also receive a further product, only calculate
      // MAS values for non dual eligible product types

      // set the primary MAS indicator to false if there is another
      // product delivery that is not one of the two dual product codes
      try {
        try {
          PrimaryMASIndicator primaryMASIndicator = findProductsThisMonth(inRecipient);

          if (masDualEligibleProductTypes.indexOf(inRecipient.getProductCode()) != -1) {
            // if this is a dual eligible and other products already exist
            // then do not set this record as the primary MAS indicator
            if (primaryMASIndicator.hasOther()) {
              inRecipient.unsetPrimaryMAS();
              if (!isSilent) {
                System.out
                    .println("             unsetPrimaryMAS as previous dual eligible is set ");
              }
            }
          }
          if (masDualEligibleProductTypes.indexOf(inRecipient.getProductCode()) == -1) {

            if (primaryMASIndicator.hasOther()) {
              // if this is not one of the dual eligible products and
              // another product that is not dual eligible is also found
              // then do not set this records primary MAS indicator
              inRecipient.unsetPrimaryMAS();
              if (!isSilent) {
                System.out
                    .println("             unsetPrimaryMAS as previous non dual eligible is set ");
              }
            } else if (!primaryMASIndicator.hasOther()) {
              // if this is not one of the dual eligible products and
              // NO other product that is not dual eligible is found
              // then do set this records primary MAS indicator
              inRecipient.setPrimaryMAS();
              if (!isSilent) {
                System.out
                    .println("             setPrimaryMAS as not a dual eligible and primary MAS not previosuly set");
              }
            }
          }

        } catch (SQLException e) {
          e.printStackTrace();
        }

        boeValue = (BasisOfEligibilityStatus) inBOEStatusesByProduct
            .get(inRecipient.getProductCode());
        BasisOfEligibilityStatus tempStatus = new BasisOfEligibilityStatus(-1,
            "", "");
        // if we have not found a basis of eligibility status for a product code
        // without age constraints or adult constraints then
        // try and find a basis of eligibility for aged and blind first
        // and finally for adult/child if not aged of blind
        if (boeValue == null && inRecipient.getAge() >= 65) {
          // if we can not find by product, check the for aged
          // aged only if over 65 with the product types
          BasisOfEligibilityStatus ageConstraint = (BasisOfEligibilityStatus) inBOEStatusesByProduct
              .get(tempStatus.getOver65Object().hashKey(
                  inRecipient.getProductCode()));
          boeValue = ageConstraint;
        } else if (boeValue == null && inRecipient.getAge() < 65) {
          // if we cant find the by product, check the for adult and
          // child based product
          BasisOfEligibilityStatus ageConstraint = (BasisOfEligibilityStatus) inBOEStatusesByProduct
              .get(tempStatus.getUnder65Object().hashKey(
                  inRecipient.getProductCode()));
          boeValue = ageConstraint;
        }

        if (boeValue == null && !inRecipient.isAdult()) {
          BasisOfEligibilityStatus childConstraint = (BasisOfEligibilityStatus) inBOEStatusesByProduct
              .get(tempStatus.getChildObject().hashKey(
                  inRecipient.getProductCode()));
          boeValue = childConstraint;
        } else if (boeValue == null && inRecipient.isAdult()) {
          BasisOfEligibilityStatus adultConstraint = (BasisOfEligibilityStatus) inBOEStatusesByProduct
              .get(tempStatus.getAdultObject().hashKey(
                  inRecipient.getProductCode()));
          boeValue = adultConstraint;

        }

        if (!isSilent) {
          System.out.println("             found a BOE mapping? "
              + (boeValue != null ? "YES" : "NO"));
        }

        if (boeValue == null) {
          // set to unknown
          boeValue = new BasisOfEligibilityStatus(1);
          if (!isSilent) {
            System.out.println("                 defaulting BOE to unkown");
          }
        }

        // get the MAS status
        Long key = null;
        try {
          key = findLookUpKey(readMASMappings, inRecipient.getProductCode());
        } catch (SQLException e) {
        }
        if (key == null) {
          // set to unknown
          key = new Long(1);
          if (!isSilent) {
            System.out.println("             defaulting MAS to unkown");
          }
        }
        masValue = new MedicalAssistance(key.intValue());
      } catch (Exception e) {
        // catch any issues and allow to continue
      }

    } else {
      // set this to not applicable
      System.out
          .println("             not a medical program setting to not applicable, program code is "
              + inRecipient.getProgramCode());

      masValue = new MedicalAssistance(-1);
      boeValue = new BasisOfEligibilityStatus(-1);

    }

    inRecipient.setMas(masValue);
    inRecipient.setBoe(boeValue);
    System.out.println("            Setting MAS and BOE key values to "
        + masValue.getMaintenanceAssistenceStatusKey() + " "
        + boeValue.getMaintenanceAssistenceStatusKey());

  }

  /**
   * 
   * Calculates the federal status values for product awarded.
   * 
   * For each CGISS recipient
   * 
   * <ol>
   * <li>only process benefit groups members</li>
   * <li>generate a time line to process</li>
   * <li>process each month between in the time line between the start date and
   * end date</li>
   * <li>if the end date is null then set to current month</li>
   * <ol>
   * <li>calculate the age in the monthly frame, age for all the month</li>
   * <li>set the federal adult indicator, based on age and educational levels</li>
   * <li>calculate the federal maintenance assistance status, based on program
   * and benefit type</li>
   * <li>calculate the federal basis of eligibility assistance status</li>
   * <li>calculate the federal basis of dual eligible status, based on products
   * awarded</li>
   * <li>calculate the federal household assistance status, based on benefit
   * types</li>
   * <li>calculate the parent indicator , based on household roles</li>
   * <li>calculate the federal educational status, based on education level</li>
   * <li>calculate the earned, unearned, cash resources amounts, based 4
   * evidence tables</li>
   * <li>calculate the federal sanction status, based on product and sanction
   * type</li>
   * <li>calculate the federal employment status, based 4 evidence tables</li>
   * </ol>
   * <li>insert a record for each recipient into summary table for each month</li>
   * <li>if the end date is set set processed flag to true.</li> <li>call the
   * standard post process.</li> </ol>
   * 
   * This is an algorithm based on the rules defined in the requirements
   * specifications for Curam 5.2 SP5.
   * 
   * @param inTable
   *          the target table name
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  public void linkReciepientToEvidence(final String inTable)
      throws SQLException {

    monthlyProcess(inTable);
  }

  /**
   * Returns the key for a code.
   * 
   * @param inSQL
   *          the SQL statement which return the primary key column for a given
   *          code value.
   * @param inCode
   *          the code value to search
   * 
   * @return Long null if no record was found or the primary key
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected Long findLookUpKey(final String inSQL, final String inCode)
      throws SQLException {

    PreparedStatement statement = null;
    Transaction transaction = null;
    Long key = null;

    try {
      // get a new connection
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();
      statement = connection.prepareStatement(inSQL);
      // set parameters
      statement.setString(1, inCode);
      final ResultSet statuses = statement.executeQuery();

      if (statuses.next()) {
        // get the primary key for the table
        key = new Long(statuses.getLong(1));
      }
      // return the key for this code
    } catch (Exception e) {
      System.out
          .println("      findLookUpKey Error: " + e.getMessage() + inSQL);
      // throw new SQLException("findLookUpKey Error: " + e.getMessage() +
      // inSQL);
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
    return key;

  }

  /**
   * Returns true if this month has already been processed.
   * 
   * @param inYear
   *          the year
   * 
   * @param inMonth
   *          the year
   * 
   * @param inDWCaseGroupID
   *          the year
   * @param inCode
   *          the code value to search
   * 
   * @return boolean true if the month is to be processed
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected boolean monthIsProcessed(final Recipient inMonthToProcess)
      throws SQLException {

    PreparedStatement statement = null;
    Transaction transaction = null;
    boolean toBeProcessed = true;

    try {
      // get a new connection
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();

      statement = connection.prepareStatement(readMonthProcessed);
      // set parameters
      statement.setLong(1, inMonthToProcess.getRecipientID());
      statement.setLong(2, inMonthToProcess.getYear());
      statement.setLong(3, inMonthToProcess.getMonth());

      final ResultSet statuses = statement.executeQuery();

      if (statuses.next()) {
        // get the primary key for the table
        toBeProcessed = true;
        System.out.println("         aggregate record already exists for : "
            + "DWCASEGROUPID=" + inMonthToProcess.getRecipientID() + "year="
            + inMonthToProcess.getYear() + "month="
            + inMonthToProcess.getMonth());
      } else {

      }

      // return the key for this code
    } catch (Exception e) {
      System.out.println("        isProcessed Error: " + e.getMessage()
          + readMonthProcessed);
      // throw new SQLException("findLookUpKey Error: " + e.getMessage() +
      // inSQL);
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
    return toBeProcessed;
  }

  /**
   * Returns the federal sanction status key based on the sanction code
   * 
   * Example federal sanction statuses are
   * <ol>
   * <li>TOTAL DOLLAR AMOUNT FOR REDUCTION DUE TO SANCTIONS</li>
   * <li>FAMILY ADULT SANCTION WITH NO HIGH SCHOOL DIPLOMA OR EQUIV</li>
   * <li>SANCTION FOR TEEN PARENT NOT ATTENDING SCHOOL</li>
   * </ol>
   * 
   * @param inSanctionCode
   *          the sanction code.
   * @return the federal status sanction key
   * 
   * @exception SQLException
   *              if a database operation fails
   */
  public long getSanctionTypeKey(final String inSanctionCode)
      throws SQLException {
    String kSanctionsTOTALDOLLARAMOUNTCode = "TOTAL DOLLAR AMOUNT FOR REDUCTION DUE TO SANCTIONS";
    String kSanctionsFAMILYADULTSANCTIONCode = "FAMILY ADULT SANCTION WITH NO HIGH SCHOOL DIPLOMA OR EQUIV";
    String kSanctionsSANCTIONFORTEENCode = "SANCTION FOR TEEN PARENT NOT ATTENDING SCHOOL";
    String kSanctionsNONCOOPERATIONCode = "NON-COOPERATION WITH CHILD SUPPORT";
    String kSanctionsWORKREQUIREMENTSSANCTIONCode = "WORK REQUIREMENTS SANCTION";
    String kSanctionsFAILURETOCOMPLYCode = "FAILURE TO COMPLY WITH AN INDIVIDUAL RESPONSIBILITY PLAN";
    String kSanctionsOTHERSANCTIONCode = "OTHER SANCTION";
    String kUndefined = "UNFEFINED";

    StringBuffer kWORKREQUIREMENTSSANCTIONS = new StringBuffer("SR12 SR8");
    StringBuffer kTeenParent = new StringBuffer("SR9");
    StringBuffer kNoCoop = new StringBuffer("SR1");

    StringBuffer kFailureToComply = new StringBuffer("SR4 SR6 SR7 SR8");
    StringBuffer kOther = new StringBuffer(
        "SR2 SR3 SR5 SR10 SR10 SR11 SR13 SR14 SR15");

    String sanctionCode = kUndefined;
    // set the default value
    long key = -1;

    if (kWORKREQUIREMENTSSANCTIONS.indexOf(inSanctionCode) != kUndefinedKey) {
      sanctionCode = kSanctionsWORKREQUIREMENTSSANCTIONCode;
    } else if (kTeenParent.indexOf(inSanctionCode) != kUndefinedKey) {
      sanctionCode = kSanctionsSANCTIONFORTEENCode;
    } else if (kNoCoop.indexOf(inSanctionCode) != kUndefinedKey) {
      sanctionCode = kSanctionsNONCOOPERATIONCode;
    } else if (kFailureToComply.indexOf(inSanctionCode) != kUndefinedKey) {
      sanctionCode = kSanctionsFAILURETOCOMPLYCode;
    } else if (kOther.indexOf(inSanctionCode) != kUndefinedKey) {
      sanctionCode = kSanctionsOTHERSANCTIONCode;
    } else if (kSanctionsTOTALDOLLARAMOUNTCode.indexOf(inSanctionCode) != kUndefinedKey) {
      sanctionCode = kSanctionsOTHERSANCTIONCode;
    } else if (kSanctionsFAMILYADULTSANCTIONCode.indexOf(inSanctionCode) != kUndefinedKey) {
      sanctionCode = kSanctionsOTHERSANCTIONCode;
    }
    try {
      /**
       * returns the sanction key for a given product
       */
      final String readSanctionStatusKey = "select DWISPSANCTIONKEY as key "
          + " from DW_ISPSANCTIONTYPES" + " where CODE=?";
      // find the key for this product
      Long hasKey = findLookUpKey(readSanctionStatusKey, sanctionCode);
      if (hasKey != null) {
        key = hasKey.longValue();
      }
    } catch (SQLException e) {
      // ignore, the SQL is valid
      System.out.println("            getSanctionTypeKey:" + e.getMessage());
    }
    // return the key
    return key;

  }

  /**
   * Determines the household assistance federal status code
   * 
   * @param inRecipient
   * @return
   * @throws SQLException
   */
  protected boolean hasFederalBenefitStatus(Recipient inRecipient)
      throws SQLException {
    BenefitEvidence benefitEvidence = null;
    boolean hasFederalStatus = false;
    List benefits = findBenefitRecord(inRecipient);
    Iterator iterator = benefits.iterator();

    while (iterator.hasNext()) {
      benefitEvidence = (BenefitEvidence) iterator.next();
      if (benefitEvidence != null && benefitEvidence.getType() != null) {
        long federalStatusKey = calculateFederalBenefitTypeStatus(benefitEvidence
            .getType());
        if (federalStatusKey == kFederalStatusKey) {
          hasFederalStatus = true;
          return hasFederalStatus;
        }
      }

    }

    inRecipient.setFederalBenefitsIndicator(hasFederalStatus);

    return hasFederalStatus;
  }

  /**
   * Returns the federal benefit status key based on the sanction code
   * 
   * Example federal benefit statuses are
   * <ol>
   * <li>RECEIVES AID UNDER TITLE XVI-SSI</li>
   * <li>RECEIVES AID UNDER TITLE XIV-APDT</li>
   * </ol>
   * 
   * @param inBenefitCode
   *          the benefit code
   * @return the federal sanction key
   * 
   * @exception SQLException
   *              if a database operation fails
   */
  public long calculateFederalBenefitTypeStatus(final String inBenefitCode)
      throws SQLException {

    final String kFederalBenefitOASDI = "RECEIVES FEDERAL OASDI";
    final String kFederalBenefitDisability = "RECEIVES BENEFITS BASED ON FEDERAL DISABILITY STATUS";
    final String kFederalBenefitSSI = "RECEIVES AID UNDER TITLE XVI-SSI";
    final String kUndefinedStatus = "UNDEFINED";
    //
    StringBuffer kOASDI = new StringBuffer("BT38 BT49   BT40   BT41 BT18");
    StringBuffer kDisabilityStatus = new StringBuffer(
        "BT51 BT15 BT12 BT51 BT15 BT42 BT43 BT45 BT46 BT47 BT55");
    StringBuffer kSSI = new StringBuffer("BT6 BT23");
    // see the initial data for unearned federal status codes
    // need to get requirements for these
    // final String kUnEarnedIncomeSocialSecurityCode = "SOCIAL SECURITY";
    // final String kUnEarnedIncomeSSIKey = "SSI";
    // final String kUnEarnedIncomeWorkersCompKey = "WORKER'S COMPENSATION";
    // final String kUnEarnedIncomeOtherKey = "OTHER";
    // final String kUnDefinedStatusIndex = "UNDEFINED";

    String fedBenefitCode = kUndefinedStatus;
    long fedBenefitKey = kUndefinedKey;

    if (kOASDI.indexOf(inBenefitCode) != kUndefinedKey) {
      fedBenefitCode = kFederalBenefitOASDI;
    } else if (kDisabilityStatus.indexOf(inBenefitCode) != kUndefinedKey) {
      fedBenefitCode = kFederalBenefitDisability;
    } else if (kSSI.indexOf(inBenefitCode) != kUndefinedKey) {
      fedBenefitCode = kFederalBenefitSSI;
    }
    // read the federal key for employed
    Long key = findLookUpKey(readFederalBenifetTypesStatusKey, fedBenefitCode);
    if (key == null) {
      // return the fall back
      key = new Long(fedBenefitKey);
    }
    return key.longValue();
  }

  /**
   * Returns the record key if a record existed in the period
   * 
   * @param Recipient
   *          contains the product case id and participant id
   * 
   * @return RecordExistsEvidence the record key if a record existed in the
   *         period
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected RecordExistsEvidence checkSingleRecordExists(
      final Recipient inRecipient, final String inSQL,
      final String inEvidenceType, final boolean inReadCode)
      throws SQLException {

    List records = checkMultipleRecordsExist(inRecipient, inSQL,
        inEvidenceType, inReadCode);

    if (records.size() == 0)
      return null;
    else
      return (RecordExistsEvidence) records.get(0);
  }

  /**
   * Returns the record key if a record existed in the period
   * 
   * @param Recipient
   *          contains the product case id and participant id
   * 
   * @return a list RecordExistsEvidence objects if records existed in the
   *         period
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected List checkMultipleRecordsExist(final Recipient inRecipient,
      final String inSQL, final String inEvidenceType,
      final boolean inReadTypeCode) throws SQLException {

    PreparedStatement statement = null;
    Transaction transaction = null;
    Date inEndDate = null;
    RecordExistsEvidence evidence = null;
    List records = new ArrayList();

    // if null then used an end date of now
    if (inRecipient.getEndDate() == null) {
      inEndDate = new Date(System.currentTimeMillis());
    } else {
      inEndDate = inRecipient.getEndDate();
    }

    try {
      // get a new connection
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();

      statement = connection.prepareStatement(inSQL);

      statement.setLong(1, inRecipient.getDwCaseID());
      statement.setLong(2, inRecipient.getDwParticipantID());
      statement.setDate(3, inEndDate);
      statement.setDate(4, inRecipient.getStartDate());
      final ResultSet evidenceRecord = statement.executeQuery();

      while (evidenceRecord.next()) {
        evidence = new RecordExistsEvidence(evidenceRecord.getLong(1),
            inEvidenceType);

        if (inReadTypeCode) {
          evidence.setType(evidenceRecord.getString(2));
        }
        records.add(evidence);
        if (!isSilent) {
          System.out.println("            Found evidence record in period "
              + inRecipient.getStartDate() + "," + inEndDate);
        }
      }
      if (records.size() == 0) {
        String prefix = inEvidenceType;
        if (!isSilent) {
          System.out.println("        " + prefix
              + ":Did not find any  record in period "
              + inRecipient.getStartDate() + "," + inEndDate + " dwcaseid="
              + inRecipient.getDwCaseID() + ", dwparticipantid="
              + inRecipient.getDwParticipantID() + " , recipientid="
              + inRecipient.getRecipientID());
        }
      }

    } catch (Exception e) {
      System.out.println("        checkMultipleRecordsExist Error: "
          + inEvidenceType + ":" + e.getMessage() + inSQL);
      // throw new SQLException("checkMultipleRecordsExist Error: "
      // + e.getMessage() + inSQL);
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
    return records;

  }

  /**
   * Returns the primary MAS indicator settings
   * 
   * @param Recipient
   *          contains the product case id and participant id
   * 
   * @return a list BenefitEvidence objects if records existed in the period
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected List findBenefitRecord(final Recipient inRecipient)
      throws SQLException {

    PreparedStatement statement = null;
    Transaction transaction = null;
    Date inEndDate = null;
    BenefitEvidence benefitEvidence = null;
    List benefitRecords = new ArrayList();
    // if null then used an end date of now
    if (inRecipient.getEndDate() == null) {
      inEndDate = new Date(System.currentTimeMillis());
    } else {
      inEndDate = inRecipient.getEndDate();
    }

    try {
      // get a new connection
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();

      statement = connection.prepareStatement(readBenefitByDate);

      statement.setLong(1, inRecipient.getDwCaseID());
      statement.setLong(2, inRecipient.getDwParticipantID());
      statement.setDate(3, inEndDate);
      statement.setDate(4, inRecipient.getStartDate());
      final ResultSet benefits = statement.executeQuery();

      while (benefits.next()) {
        benefitEvidence = new BenefitEvidence(benefits.getLong(1),
            benefits.getString(2), 0f);
        benefitRecords.add(benefitEvidence);
        if (!isSilent) {
          System.out.println("            Found evidence benefit record in period "
              + inRecipient.getStartDate() + "," + inEndDate);
        }

      }
      if (benefitRecords.size() == 0) {
        if (!isSilent) {
          System.out.println("        Did not find any benefit record in period "
              + inRecipient.getStartDate() + "," + inEndDate + " dwcaseid="
              + inRecipient.getDwCaseID() + ", dwparticipantid="
              + inRecipient.getDwParticipantID() + " , recipientid="
              + inRecipient.getRecipientID());
        }
      }
    } catch (Exception e) {
      System.out.println("        findBenefitRecord Error: " + e.getMessage()
          + readBenefitByDate);
      // throw new SQLException("findBenefitRecord Error: " + e.getMessage()
      // + readStudentByDate);
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
    return benefitRecords;

  }

  /**
   * Returns the HHM evidence if a record existed in the period
   * 
   * @param Recipient
   *          contains the product case id and participant id
   * 
   * @return HHMEvidence a record if a record existed in the period
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected HHMEvidence findHouseHoldMemberRecord(final Recipient inRecipient)
      throws SQLException {

    PreparedStatement statement = null;
    Transaction transaction = null;
    Date inEndDate = null;
    HHMEvidence evidence = null;

    // if null then used an end date of now
    if (inRecipient.getEndDate() == null) {
      inEndDate = new Date(System.currentTimeMillis());
    } else {
      inEndDate = inRecipient.getEndDate();
    }

    try {
      // get a new connection
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();

      statement = connection.prepareStatement(readHouseHoldMemberByDate);

      statement.setLong(1, inRecipient.getDwCaseID());
      statement.setLong(2, inRecipient.getDwParticipantID());
      statement.setDate(3, inEndDate);
      statement.setDate(4, inRecipient.getStartDate());
      final ResultSet householdMembers = statement.executeQuery();

      if (householdMembers.next()) {
        evidence = new HHMEvidence(householdMembers.getLong(1),
            householdMembers.getString(2));
        if (!isSilent) {
          System.out.println("        Found evidence HHM record in period "
              + inRecipient.getStartDate() + "," + inEndDate);
        }
      } else {
        if (!isSilent) {
          System.out.println("        Did not find any HHM record in period "
              + inRecipient.getStartDate() + "," + inEndDate + " dwcaseid="
              + inRecipient.getDwCaseID() + ", dwparticipantid="
              + inRecipient.getDwParticipantID() + " , recipientid="
              + inRecipient.getRecipientID());
        }
      }
    } catch (Exception e) {
      System.out.println("        findHHMRecord Error: " + e.getMessage()
          + readHouseHoldMemberByDate);
      // throw new SQLException("findHHMRecord Error: " + e.getMessage()
      // + readHouseHoldMemberByDate);
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
    return evidence;

  }

  /**
   * Returns the records if income records existed in the period
   * 
   * @param Recipient
   *          contains the product case id and participant id
   * 
   * @return a list IncomeEvidence objects if records existed in the period
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected List findIncomeRecord(final Recipient inRecipient,
      final String inEvidenceName, final String inSQL) throws SQLException {

    PreparedStatement statement = null;
    Transaction transaction = null;
    Date inEndDate = null;
    IncomeEvidence unearnedIncomeEvidence = null;
    List list = new ArrayList();
    float totalIncome = 0;
    StringBuffer cashResources = new StringBuffer("LR3 LR4 LR5 LR18 ");

    // in order to find a person record if the case groups end date is
    // null then used an end date of now
    if (inRecipient.getEndDate() == null) {
      inEndDate = new Date(System.currentTimeMillis());
    } else {
      inEndDate = inRecipient.getEndDate();
    }

    try {
      // get a new connection
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();

      statement = connection.prepareStatement(inSQL);

      statement.setLong(1, inRecipient.getDwCaseID());
      statement.setLong(2, inRecipient.getDwParticipantID());
      statement.setDate(3, inEndDate);
      statement.setDate(4, inRecipient.getStartDate());
      final ResultSet unearnedIncomeRecords = statement.executeQuery();

      // there may be 0 or more unearned income record in the period
      //
      while (unearnedIncomeRecords.next()) {

        unearnedIncomeEvidence = new IncomeEvidence(
            unearnedIncomeRecords.getLong(1),
            unearnedIncomeRecords.getString(2),
            unearnedIncomeRecords.getFloat(3), inEvidenceName);
        if (!isSilent) {
          System.out
              .println("        Found evidence IncomeEvidence record in period "
                  + inEvidenceName + ":" + inRecipient.getStartDate() + ","
                  + inEndDate);
        }
        list.add(unearnedIncomeEvidence);

        // total income for a month is the amount times frequency
        // getting clarification on what values frequency can have
        // amend this total when we get frequency data

        if (kEvidenceNameLiquidResource.equalsIgnoreCase(inEvidenceName)) {
          String resourceType = unearnedIncomeEvidence.getType();

          if (resourceType != null && cashResources.indexOf(resourceType) != -1) {
            totalIncome += unearnedIncomeEvidence.getIncomeAmount();
          }

        } else {
          totalIncome += unearnedIncomeEvidence.getIncomeAmount();
        }
      }

      if (kEvidenceNameAbParChildSupport.equalsIgnoreCase(inEvidenceName)) {
        inRecipient.incrementTotalChildSupportIncome(totalIncome);
      } else if (kEvidenceNameEarnedIncome.equalsIgnoreCase(inEvidenceName)) {
        inRecipient.incrementTotalEarnedIncome(totalIncome);
      } else if (kEvidenceNameUnEarnedIncome.equalsIgnoreCase(inEvidenceName)) {
        inRecipient.incrementTotalUnearnedIncome(totalIncome);
      } else if (kEvidenceNameUnEarnedIncome.equalsIgnoreCase(inEvidenceName)) {
        inRecipient.incrementTotalUnearnedIncome(totalIncome);
      } else if (kEvidenceNameLiquidResource.equalsIgnoreCase(inEvidenceName)) {
        inRecipient.incrementCashResources(totalIncome);
      }

      if (list.size() == 0) {
        if (!isSilent) {
          System.out
              .println("        Did not find any Found IncomeEvidence record in period "
                  + inEvidenceName
                  + ":"
                  + inRecipient.getStartDate()
                  + ","
                  + inEndDate
                  + " dwcaseid="
                  + inRecipient.getDwCaseID()
                  + ", dwparticipantid="
                  + inRecipient.getDwParticipantID()
                  + " , recipientid=" + inRecipient.getRecipientID());
        }
      }

    } catch (Exception e) {
      System.out.println("         findIncomeRecord Error: " + e.getMessage()
          + inSQL);
      System.out.println("         findIncomeRecord Error: " + inSQL);
      // throw new SQLException("findIncomeRecord Error: " + e.getMessage()
      // + inSQL);
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
    return list;

  }

  /**
   * Returns the primary MAS indicator settings for a recipient
   * 
   * @param Recipient
   *          contains the product case id and participant id
   * 
   * @return PrimaryMASIndicator the MAS indicator settings
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected PrimaryMASIndicator findProductsThisMonth(
      final Recipient inRecipient) throws SQLException {

    PreparedStatement statement = null;
    Transaction transaction = null;
    PrimaryMASIndicator primaryMAS = new PrimaryMASIndicator();

    try {
      // get a new connection
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();

      statement = connection.prepareStatement(productsThisMonth);

      statement.setLong(1, inRecipient.getYear());
      statement.setLong(2, inRecipient.getMonth());
      statement.setLong(3, inRecipient.getDwParticipantID());

      final ResultSet products = statement.executeQuery();
      String productCode;
      boolean noProducts = true;
      StringBuffer baseProducts = new StringBuffer("PN36 PN37");

      while (products.next()) {
        noProducts = false;
        productCode = products.getString(1);
        String isSet = products.getString(2);
        if (isSet == null) {
          if (!isSilent) {
            System.out
                .println("      findProductsThisMonth Error: primary indicator should be set "
                    + isSet);
          }
        }
        if (baseProducts.indexOf(productCode) != -1) {
          primaryMAS.setBasic(true);
        } else if (baseProducts.indexOf(productCode) == -1) {
          primaryMAS.setOther(true);

        }
      }

      if (noProducts) {
        primaryMAS.setBasic(false);
        primaryMAS.setOther(false);
      }

    } catch (Exception e) {
      System.out.println("        findProductsThisMonth Error: " + e.getMessage()
          + readAlienByDate);
      // throw new SQLException("findAlienRecord Error: " + e.getMessage()
      // + readAlienByDate);
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
    return primaryMAS;

  }

  /**
   * Calculates the federal status values for a recipient.
   * 
   * <ol>
   * <li>calculate the age in the monthly frame, age for all the month</li>
   * <li>set the federal adult indicator, based on age and educational levels</li>
   * <li>calculate the federal maintenance assistance status, based on program
   * and benefit type</li>
   * <li>calculate the federal basis of eligibility assistance status</li>
   * <li>calculate the federal basis of dual eligible status, based on products
   * awarded</li>
   * <li>calculate the federal household assistance status, based on benefit
   * types</li>
   * <li>calculate the parent indicator , based on household roles</li>
   * <li>calculate the federal educational status, based on education level</li>
   * <li>calculate the earned, unearned, cash resources amounts, based 4
   * evidence tables</li>
   * <li>calculate the federal sanction status, based product and sanction type</li>
   * <li>calculate the federal employment status, based 4 evidence tables</li>
   * </ol>
   * Evidence is only associated once to a recipient even through there may be
   * many evidence records that allow eligibility.
   * 
   * This is an algorithm based on the rules defined in our requirements
   * specifications for TANF.
   * 
   * @param String
   *          the target table name
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected void monthlyCalculateFederalStatuses(final Recipient inRecipient,
      Map inBOEStatusesByProduct) throws SQLException {

    // calculate age in monthly frame
    short age = (short) PersonTransformsFactory.newInstance()
        .calcuateAgeInMonthlyFrame(inRecipient.getDateOfBirth(),
            inRecipient.getStartDate());
    inRecipient.setAge(age);

    // is the recipient an adult
    boolean isAdult = true;
    RecordExistsEvidence studentEvidence = checkSingleRecordExists(inRecipient,
        readStudentByDate, kEvidenceNameStudent, false);

    calcuateEducationalStatus(inRecipient, studentEvidence);

    if (inRecipient.getAge() < 18) {
      isAdult = false;
    } else if (inRecipient.getAge() < 19 && studentEvidence != null) {
      // if the person is 18 and in education then classify as a child
      isAdult = false;
    }
    inRecipient.setAdultIndicator(isAdult);

    System.out.println("         age is  " + inRecipient.getAge()
        + " , adult indicator set to " + inRecipient.getAdultIndicator());

    calculateMASAndBOEStatus(inRecipient, inBOEStatusesByProduct);
    calculateDualEligibleStatus(inRecipient);
    BenefitEvidence benefitEvidence = calculateHouseholdAssistanceStatus(inRecipient);

    hasFederalBenefitStatus(inRecipient);

    // is the recipient a parent?, needed for reporting on 2 parent families
    // in future releases if the recipient is a child we need check
    // if he/she has parents, no just if the recipient is a parent

    HouseHoldRelationshipEvidence houseHoldRelationshipEvidence = isParent(inRecipient);
    if (houseHoldRelationshipEvidence != null) {
      inRecipient.setParentIndicator(houseHoldRelationshipEvidence.isParent());
    }

    // get the alien and citizen status values and keys
    HHMEvidence householdMemberEvidence = findHouseHoldMemberRecord(inRecipient);
    AlienEvidence alienEvidence = findAlienRecord(inRecipient);

    if (alienEvidence != null && householdMemberEvidence != null) {
      // citizen status values are the code table category "AlienStatus"
      // alien type values are the code table category
      // "AlienStatusOnEntry"

      if (kCitizenStatus.compareToIgnoreCase(householdMemberEvidence.getType()) == 0
          && (alienEvidence.alienType
              .equalsIgnoreCase(kLPR_WITHOUT_40_QUALIFYING_QUARTERS)
              || alienEvidence.alienType
                  .equalsIgnoreCase(kLPR_WITH_40_QUALIFYING_QUARTERS)
              || alienEvidence.alienType.equalsIgnoreCase(kREFUGEE)
              || alienEvidence.alienType.equalsIgnoreCase(kCONDITIONAL_ENTRANT)
              || alienEvidence.alienType.equalsIgnoreCase(ASYLEE)
              || alienEvidence.alienType.equalsIgnoreCase(kPAROLEE)
              || alienEvidence.alienType
                  .equalsIgnoreCase(kDEPORTATION_WITHHELD)
              || alienEvidence.alienType
                  .equalsIgnoreCase(kCUBAN_HAITIAN_ENTRANT)
              || alienEvidence.alienType.equalsIgnoreCase(kAMERASIAN_IMMIGRANT)
              || alienEvidence.alienType
                  .equalsIgnoreCase(kAMERICAN_INDIAN_BORN_IN_CANADA) || alienEvidence.alienType
              .equalsIgnoreCase(kVICTIMS_OF_SEVERE_TRAFFICKING))) {

        inRecipient.setQualifiedAlienIndicator(true);
      }

    }

    List unearnedIncomeRecords = findIncomeRecord(inRecipient,
        kEvidenceNameUnEarnedIncome, readUnEarnedIncomeByDate);
    List paidEmploymentIncomeRecords = findIncomeRecord(inRecipient,
        kEvidenceNameEarnedIncome, readEarnedIncomeByDate);
    List selfEmploymentIncomeRecords = findIncomeRecord(inRecipient,
        FederalTransforms.kEvidenceNameEarnedIncomeGrossReceipt,
        readSelfEmployedIncomeByDate);
    List abChildSupportIncomeRecords = findIncomeRecord(inRecipient,
        kEvidenceNameAbParChildSupport, readAbParChildSupportByDate);
    List liquidResourceRecords = findIncomeRecord(inRecipient,
        kEvidenceNameLiquidResource, readLiquidResourceByDate);

    List sanctionEvidence = checkMultipleRecordsExist(inRecipient,
        readSanctionsByDate, kEvidenceNameSanctions, false);
    // read sanctions
    List unpaidEmploymentEvidence = checkMultipleRecordsExist(inRecipient,
        readUnPaidEmploymentByDate, kEvidenceNameUnPaidEmployment, false);

    if (sanctionEvidence.size() > 0) {
      inRecipient.setSanctions();
    }

    // is the recipient co-operating in child support enforcement
    RecordExistsEvidence childEnforcementEvidence = calculateChildSupportEnforcementStatus(inRecipient);

    // get subsidized housing key
    RecordExistsEvidence subsizedHouseingKey = setSubsizedHouseingKey(inRecipient);

    // work out the employment status
    setEmploymentStatus(inRecipient);

    // link any benefit evidence
    List benefits = findBenefitRecord(inRecipient);

    RelatedEvidence relatedEvidence = new RelatedEvidence();
    relatedEvidence.addEvidence(alienEvidence);
    relatedEvidence.addEvidence(householdMemberEvidence);
    relatedEvidence.addEvidence(houseHoldRelationshipEvidence);
    relatedEvidence.addEvidence(studentEvidence);
    relatedEvidence.addEvidence(benefitEvidence);
    relatedEvidence.addEvidence(unearnedIncomeRecords);
    relatedEvidence.addEvidence(abChildSupportIncomeRecords);
    relatedEvidence.addEvidence(paidEmploymentIncomeRecords);
    relatedEvidence.addEvidence(selfEmploymentIncomeRecords);
    relatedEvidence.addEvidence(liquidResourceRecords);

    relatedEvidence.addEvidence(sanctionEvidence);
    relatedEvidence.addEvidence(childEnforcementEvidence);
    relatedEvidence.addEvidence(subsizedHouseingKey);
    relatedEvidence.addEvidence(benefits);
    relatedEvidence.addEvidence(unpaidEmploymentEvidence);
    inRecipient.setEvidenceKeys(relatedEvidence);
  }

  protected long calcuateEducationalStatus(final Recipient inRecipient,
      final RecordExistsEvidence inEvidence) throws SQLException {

    // default the search code
    String eduLevelCode = "No formal education";
    // default the return key.
    long notKnownKey = 99;
    if (!isSilent) {
      System.out.println("        Checking educational level");
      System.out.print("    ");
    }

    RecordExistsEvidence studentEvidence = checkSingleRecordExists(inRecipient,
        readStudentLevelByDate, kEvidenceNameStudent, true);
    if (studentEvidence != null) {
      String curamLevel = studentEvidence.getType();

      if ("SG1".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "First Grade";
      } else if ("SG2".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Second Grade";
      } else if ("SG3".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Third Grade";
      } else if ("SG4".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Fourth Grade";
      } else if ("SG5".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Firth Grade";
      } else if ("SG6".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Sixth Grade";
      } else if ("SG7".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Seventh Grade";
      } else if ("SG8".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Eight Grade";
      } else if ("SG9".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Nineth Grade";
      } else if ("SG10".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Thenth Grade";
      } else if ("SG11".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Eleventh Grade";
      } else if ("SG12".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Diploma,GED";
      } else if ("SG13".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Diploma,GED";
      } else if ("SG14".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Awarded Associates Degree";
      } else if ("SG15".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Awarded graduate degree";
      } else if ("SG16".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Awarded graduate degree";
      } else if ("SG16".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Awarded graduate degree";
      } else if ("SG17".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Awarded graduate degree";
      } else if ("SG18".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Other credentials";
      } else if ("SG19".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Other credentials";
      } else if ("SG20".indexOf(curamLevel) != kUndefinedKey) {
        eduLevelCode = "Other credentials";
      }
    }
    // read the employment status key for employed
    Long key = findLookUpKey(readFederalBenifetTypesStatusKey, eduLevelCode);
    if (key == null) {
      // return the fall back
      key = new Long(notKnownKey);
    }
    inRecipient.setEducationalLevelKey(key.longValue());
    return key.longValue();
  }

  /**
   * returns a relationship object if the recipient was a parent with the period
   * of time.
   * 
   * Is the recipient a parent?, needed for reporting on 2 parent families In
   * future releases if the recipient is a child we need check if he/she has
   * parents, not just if the recipient is a parent
   * 
   * @param Recipient
   *          contains the product case identity, participant identity and time
   *          frame
   * 
   * @return HouseHoldRelationshipEvidence a record if a recipient was a parent
   *         in the period, null otherwise
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected HouseHoldRelationshipEvidence isParent(final Recipient inRecipient)
      throws SQLException {

    PreparedStatement statement = null;
    Transaction transaction = null;
    Date inEndDate = null;
    int recordsForConcern = 0;
    HouseHoldRelationshipEvidence houseHoldRelationshipEvidence = null;

    // IF null then use an end date of now
    if (inRecipient.getEndDate() == null) {
      inEndDate = new Date(System.currentTimeMillis());
    } else {
      inEndDate = inRecipient.getEndDate();
    }

    try {
      // get a new connection
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();

      statement = connection.prepareStatement(readHouseholdRoleByDate);

      statement.setLong(1, inRecipient.getDwCaseID());
      statement.setLong(2, inRecipient.getDwParticipantID());
      statement.setDate(3, inEndDate);
      statement.setDate(4, inRecipient.getStartDate());
      final ResultSet houseHold = statement.executeQuery();
      long key = 0;
      String role = null;
      boolean isParent = false;
      while (houseHold.next()) {

        key = houseHold.getLong(1);
        role = houseHold.getString(2);
        isParent = false;
        recordsForConcern++;

        /*
         * if (kParent.compareToIgnoreCase(role) == 0) { isParent = true;
         * houseHoldRelationshipEvidence = new HouseHoldRelationshipEvidence(
         * key, role, isParent); break; } else
         */
        // if the person has a relationship to a child then person is a
        // parent
        if (kParent.compareToIgnoreCase(role) == 0) {
          isParent = true;
          houseHoldRelationshipEvidence = new HouseHoldRelationshipEvidence(
              key, kParent, isParent);
          break;

        }
      }

      if (houseHoldRelationshipEvidence != null) {
        if (!isSilent) {
          System.out
              .println("        isParent:Found evidence relationship record for  "
                  + role + "-" + inRecipient.getStartDate() + "-" + inEndDate);
        }
      } else {
        if (!isSilent) {
          System.out.println("        isParent:found  no " + recordsForConcern
              + " relationship record(s) in period "
              + inRecipient.getStartDate() + "," + inEndDate + " dwcaseid="
              + inRecipient.getDwCaseID() + ", dwparticipantid="
              + inRecipient.getDwParticipantID() + " , recipientid="
              + inRecipient.getRecipientID());
        }
      }

    } catch (Exception e) {
      System.out.println("        isParent: Error: " + e.getMessage()
          + readHouseholdRoleByDate);
      // throw new SQLException("isParent: Error: " + e.getMessage()
      // + readHouseholdRoleByDate);
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
    return houseHoldRelationshipEvidence;

  }

  protected RecordExistsEvidence setSubsizedHouseingKey(Recipient inRecipient)
      throws SQLException {
    // need requirements for these
    // final String kUndefined = "UNDEFINED";
    // final String kHousingRentCode = "Rent Subsidy";

    final String kHousingPublicCode = "Public Housing";
    final String KHousingNoSubsidyCode = "No Housing Subsidy";
    String code = kHousingPublicCode;
    RecordExistsEvidence evidence = null;
    // work out the employment status
    // if employed
    evidence = checkSingleRecordExists(inRecipient,
        readUnEarnedIncomeTypeByDate, kEvidenceNameUnEarnedIncome, true);

    if (evidence != null) {
      // then employed
      StringBuffer rent = new StringBuffer("UT27 UT28  UT29 UT30 UT18");
      if (rent.indexOf(evidence.getType()) != -1) {
        code = kHousingPublicCode;
      }
    }

    // renting
    evidence = checkSingleRecordExists(inRecipient,
        readRentAllowanceSubHousingByDate, kEvidenceNameSubsizedHousing, true);

    if (evidence != null) {
      // then employed
      StringBuffer rent = new StringBuffer("SET5 SET2");
      if (rent.indexOf(evidence.getType()) != -1) {
        code = kHousingPublicCode;
      } else {
        code = KHousingNoSubsidyCode;
      }
    }

    Long key = findLookUpKey(readHousingStatusKey, code);
    if (key == null) {
      // return the undefined record
      key = new Long(-1);
    }
    inRecipient.setSubsizedHousingKeyKey(key.intValue());

    return evidence;
  }

  /**
   * Calculates the employee status for a recipient
   * 
   * @param Recipient
   *          contains the product case identity, participant identity and time
   *          frame
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  protected void setEmploymentStatus(final Recipient inRecipient)
      throws SQLException {

    // used to store the employee status
    EmploymentStatusEvidence employeeStatus = null;
    Long notEmployed = new Long(2);
    // work out the employment status
    // check if employed
    RecordExistsEvidence employmentEvidence = checkSingleRecordExists(
        inRecipient, readEmploymentStatusPaidEmploymentByDate,
        kEvidenceNamePaidEmployment, false);

    if (employmentEvidence != null) {
      // read the employment status key for employed
      Long employmentStatusKey = findLookUpKey(readEmploymentStatusKey,
          kEmploymentStatusEmployed);
      if (employmentStatusKey == null) {
        // this is an error
        employmentStatusKey = notEmployed;
        if (!isSilent) {
          System.out
              .print("Error:setEmploymentStatus: could not find code in table using "
                  + readEmploymentStatusKey
                  + "with "
                  + kEmploymentStatusEmployed);
        }
      }
      employeeStatus = new EmploymentStatusEvidence(
          kEvidenceNamePaidEmployment, employmentEvidence.getKey(),
          employmentStatusKey.longValue(), employmentEvidence.getType());

      inRecipient.setEmploymentStatusKey(employeeStatus);

      // check if the recipient is self employed
      employmentEvidence = checkSingleRecordExists(inRecipient,
          readEmploymentStatusSelfEmployedByDate, kEvidenceNameSelfEmployment,
          false);
      if (employmentEvidence != null)
        employeeStatus = new EmploymentStatusEvidence(
            kEvidenceNameSelfEmployment, employmentEvidence.getKey(),
            employmentStatusKey.longValue(), employmentEvidence.getType());
    } else if (employmentEvidence == null) {
      // check if exempt from work
      employmentEvidence = checkSingleRecordExists(inRecipient,
          readEmploymentStatusWorkRequirementsByDate,
          kEvidenceNameWorkRequirements, false);
      if (employmentEvidence != null) {
        // read the employment status key for not in work force
        Long employmentStatusKey = findLookUpKey(readEmploymentStatusKey,
            kEmploymentStatusNoInLabourForce);
        if (employmentStatusKey == null) {
          employmentStatusKey = notEmployed;
          if (!isSilent) {
            System.out
                .print("Error:setEmploymentStatus: could not find code in table using "
                    + readEmploymentStatusKey
                    + "with "
                    + kEmploymentStatusNoInLabourForce);
          }
        }
        employeeStatus = new EmploymentStatusEvidence(
            kEvidenceNameWorkRequirements, employmentEvidence.getKey(),
            employmentStatusKey.intValue(), employmentEvidence.getType());
      }
    }

    // if neither in paid,self employment of not in work force then
    // the recipient is unemployed
    if (employeeStatus == null) {
      // read the employment status key for not employed
      Long key = findLookUpKey(readEmploymentStatusKey,
          kEmploymentStatusNotEmployed);
      if (key == null) {
        // a last ditch fall back of not employed
        key = notEmployed;
        if (!isSilent) {
          System.out
              .print("Error:setEmploymentStatus: could not find code in table using "
                  + readEmploymentStatusKey
                  + "with "
                  + kEmploymentStatusNotEmployed);
        }
      }
      employeeStatus = new EmploymentStatusEvidence("NONE", new Long(
          kUndefinedKey).longValue(), key.longValue(), "NONE");
    }
    // set the employee status
    inRecipient.setEmploymentStatusKey(employeeStatus);
  }

  /**
   * Reads records from the central case groups table where the processed
   * indicator is set to false.
   * 
   * Only benefit records are included in processing.
   * 
   * This is an algorithm based on the rules defined in our requirements
   * specifications for TANF.
   * 
   * @param String
   *          the target table name
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected List monthlyFindRecipients(final String inTargetTableName)
      throws SQLException {

    List list = new ArrayList();
    // the database transaction
    Transaction transaction = null;
    // statement to read recipient records
    PreparedStatement toProcess = null;
    int recipientRecordsToProcess = 0;
    Recipient recipient = null;

    try {
      // start a transaction
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();

      toProcess = connection.prepareStatement(readReciepientsToProcess);

      // read recipient records to process
      final ResultSet recipients = toProcess.executeQuery();
      while (recipients.next()) {
        recipientRecordsToProcess++;
        // read recipient data
        long inRecipientID = recipients.getLong(1);
        Date inDOB = recipients.getDate(2);
        Date inStartDate = recipients.getDate(3);
        Date inEndDate = recipients.getDate(4);
        long inDWCaseID = recipients.getLong(5);
        long inDWParticipantID = recipients.getLong(6);
        Timestamp inLastWritten = recipients.getTimestamp(7);
        String inProductCode = recipients.getString(8);
        String inProgramCode = recipients.getString(9);

        recipient = new Recipient(inRecipientID, inDOB, inStartDate, inEndDate,
            inDWCaseID, inDWParticipantID, inLastWritten, inProductCode,
            inProgramCode);

        recipient.setProgramKey(recipients.getLong(10));

        long personID = recipients.getLong(11);
        long ccgID = recipients.getLong(12);
        long caseSHID = recipients.getLong(13);
        String productCode = recipients.getString(14);

        recipient.setPersonHistoryKey(personID);
        recipient.setCaseclientgroupid(ccgID);
        recipient.setCaseStatusHistoryKey(caseSHID);
        recipient.setProductCode(productCode);

        list.add(recipient);
      }

      /*
       * test harness code to be removed. GregorianCalendar start = new
       * GregorianCalendar(); start.set(Calendar.YEAR, 2012);
       * start.set(Calendar.MONTH, start.getActualMinimum(Calendar.MONTH));
       * start.set(Calendar.DAY_OF_MONTH,
       * start.getActualMinimum(Calendar.DAY_OF_MONTH));
       * 
       * Recipient temp = new Recipient(1L, new
       * Date(System.currentTimeMillis()), new Date(start.getTimeInMillis()),
       * null, 1L, 1L, new Timestamp( System.currentTimeMillis()), "", "");
       * recipientRecordsToProcess++; list.add(temp);
       */

    } catch (Exception e) {
      e.printStackTrace();
      System.out.println("        findRecipients: caught exception "
          + e.getMessage());
      System.out.println("        findRecipients: sql " + readReciepientsToProcess);
      // throw new SQLException("findRecipients:" + e.getMessage());
    } finally {
      // close statements
      if (toProcess != null) {
        toProcess.close();
      }
    }
    return list;

  }

  // ___________________________________________________________________________
  /**
   * This method process new recipient data or new time lines
   * <ol>
   * <li>read all recipient to process</li>
   * <li>generates a time line to process</li>
   * <li>calculate the federal status values</li>
   * <li>save the record to the aggregate table</li>
   * <li>sets the processed flag to true if processed false otherwise</li>
   * <li>it will only execute for the last day of the month</li>
   * </ol>
   * .
   * 
   * @param inTargetTableName
   *          the target table being populated
   * @throws java.sql.SQLException
   *           if a database operation failed
   */
  protected void monthlyProcess(final String inTargetTableName)
      throws SQLException {
    List results = new ArrayList();
    Recipient recipient = null;
    Recipient recipientForThisMonth = null;
    int totalRecordsInserted = 0;
    int insertedForThisPerson = 0;

    // read the BOE mappings from the database
    Map boeStatusesByProduct = initializeBOECodes();

    System.out.println("monthlyProcess:loaded boeStatusesByProduct "
        + boeStatusesByProduct.size());

    // the list of people to process
    System.out.println("monthlyProcess:start processing all recipient ");
    Date start = new Date(System.currentTimeMillis());
    List toProcess = monthlyFindRecipients(inTargetTableName);
    Iterator people = toProcess.iterator();

    System.out.println("monthlyFindRecipients: " + toProcess.size()
        + " recipients to be processed");
    for (; people.hasNext();) {
      recipient = (Recipient) people.next();
      System.out.println("    -----------------------------------------------");
      System.out.println("    monthlyProcess: processing where dwcasegroupid="
          + recipient);
      System.out.println("    -----------------------------------------------");
      boolean toBeProcessed = true;
      // the time line to process
      List timeline = monthlyTimeLine(recipient);
      Iterator timeIterator = timeline.iterator();
      insertedForThisPerson = 0;
      for (; timeIterator.hasNext();) {
        recipientForThisMonth = (Recipient) timeIterator.next();
        // calculate the federal status
        System.out.println("    start: calculateFederalStatuses "
            + recipientForThisMonth);
        toBeProcessed = monthIsProcessed(recipientForThisMonth);
        System.out.println("        month toBeProcessed=" + toBeProcessed
            + ", if toBeProcessed=false then no operation required");
        if (toBeProcessed == true) {
          monthlyCalculateFederalStatuses(recipientForThisMonth,
              boeStatusesByProduct);

          System.out.println("    end: calculateFederalStatuses ");

          System.out.println("    start: insert monthly federal status ");
          // save the data to the monthly table
          int rowsAdded = monthlySave(recipientForThisMonth);
          insertedForThisPerson += rowsAdded;
          totalRecordsInserted += rowsAdded;
          System.out.println("    end: insert monthly federal status ");
        }
      }
      results.add(insertedForThisPerson
          + " rows inserted into DW_CASERECIPIENT_MONTH for "
          + recipientForThisMonth.getRecipientID());

      System.out.println("    start: recipient record to fully processed ?"
          + recipient);
      // save the data to the monthly table
      String processed = monthlySetToProcessed(recipient);
      toBeProcessed = false;
      System.out.println("            :all processing completed=" + processed);
      System.out.println("    end: recipient record to fully processed ?");
      System.out.println("    -----------------------------------------------");

    }
    System.out.println("    -----------------------------------------------");
    System.out.println("    Job Summary                                  --");
    System.out.println("    -----------------------------------------------");

    for (int i = 0; i < results.size(); i++) {
      System.out.println("    " + results.get(i));
    }
    System.out.println("monthlyFindRecipients: " + toProcess.size()
        + " recipients to be processed");
    System.out.println("monthlyFindRecipients: " + totalRecordsInserted
        + " records inserted into summary table");
    Date end = new Date(System.currentTimeMillis());
    long milis1 = start.getTime();
    long milis2 = end.getTime();
    long d = milis2 - milis1;
    long dSeconds = d / 1000;

    System.out.println("Durantion in seconds: " + dSeconds + " seconds.");

    // update the control table
    super.executePostProcess(inTargetTableName);
    System.out.println("monthlyProcess:end processing all recipients");

  }

  // ___________________________________________________________________________
  /**
   * This method generates a timeline to process for each recipient.
   * 
   * @param inTargetTableName
   *          the target table being populated
   * 
   * @return List a list of Recipient objects to process
   * @throws java.sql.SQLException
   *           if a database operation failed
   */
  protected List monthlyTimeLine(final Recipient inRecipient)
      throws SQLException {
    int monthsProcessed = 0;
    List timeline = new ArrayList();
    Calendar start;
    Calendar end;
    Date proposedEnd = inRecipient.getEndDate();
    Date proposedStart = inRecipient.getStartDate();

    try {

      if (proposedEnd == null) {

        end = new GregorianCalendar();
        end.set(Calendar.DAY_OF_MONTH,
            end.getActualMaximum(Calendar.DAY_OF_MONTH));
      } else {

        end = new GregorianCalendar();
        end.setTime(proposedEnd);
        end.set(Calendar.DAY_OF_MONTH,
            end.getActualMaximum(Calendar.DAY_OF_MONTH));

      }
      if (proposedStart == null) {

        start = new GregorianCalendar();
        start.set(Calendar.DAY_OF_MONTH,
            start.getActualMinimum(Calendar.DAY_OF_MONTH));
      } else {

        start = new GregorianCalendar();
        start.setTime(proposedStart);
        start.set(Calendar.DAY_OF_MONTH,
            end.getActualMinimum(Calendar.DAY_OF_MONTH));
      }

      // only run if this is the last day of the month,
      // assumes that the fact case process ETL has completed.
      if (end.get(Calendar.DAY_OF_MONTH) != end
          .getActualMaximum(Calendar.DAY_OF_MONTH)) {
        System.out.println("        Warning, " + end.get(Calendar.MONTH)
            + " is not last day of month, current day of month="
            + end.get(Calendar.DAY_OF_MONTH) + ", last day of month is="
            + end.getActualMaximum(Calendar.DAY_OF_MONTH));
        ;
      }

      if (end.before(start)) {
        System.out.println("        End date is before start date, check "
            + " control table and system clock");
        System.out.println("            start date is "
            + new Date(start.getTimeInMillis()));
        System.out.println("            end date is "
            + new Date(end.getTimeInMillis()));

        return timeline;
      }

      System.out
          .print("        generating processing instructions for  months inclusive:");
      System.out.print(start.getTime());
      System.out.println("-->" + end.getTime());
      boolean completed = false;
      // we need to make sure we do not get stuck in a loop
      int failSafe = 1200;
      monthsProcessed = 0;
      do {
        // place the aggregate row in the aggregate table
        Recipient monthToProcess = new Recipient(inRecipient);
        monthToProcess.setYear(start.get(Calendar.YEAR));
        // calendar months start at 1, January is zero
        // increment to human readable form, January is one
        monthToProcess.setMonth(start.get(Calendar.MONTH) + 1);

        GregorianCalendar endOfMonth = new GregorianCalendar();
        endOfMonth.setTime(new Date(start.getTimeInMillis()));
        endOfMonth.set(Calendar.DAY_OF_MONTH,
            start.getActualMaximum(Calendar.DAY_OF_MONTH));

        monthToProcess.setStartDate(new Date(start.getTimeInMillis()));
        monthToProcess.setEndDate(new Date(endOfMonth.getTimeInMillis()));

        timeline.add(monthToProcess);

        monthsProcessed++;
        if (start.get(Calendar.YEAR) == end.get(Calendar.YEAR)
            && start.get(Calendar.MONTH) == end.get(Calendar.MONTH)) {
          completed = true;
        }
        if (monthsProcessed > failSafe) {
          completed = true;
        }
        // rolls forward the month and year if necessary
        if (start.get(Calendar.MONTH) == Calendar.DECEMBER) {
          start.set(Calendar.MONTH, Calendar.JANUARY);
          start.roll(Calendar.YEAR, 1);
        } else {
          start.roll(Calendar.MONTH, 1);
        }

      } while (!completed);
      System.out.println("        Timeline:" + timeline.size()
          + " month(s) to process ");
      System.out.println("");

      return timeline;
    } catch (Exception e) {
      System.out.println("        CaseFactProcessTransformImpl:" + e.getMessage());
      throw new SQLException("CaseFactProcessTransformImpl:" + e.getMessage());
    }
  }

  /**
   * This method updates the processed flag for case group data.
   * 
   * @param recipient
   *          the recipient to process
   * 
   * @return the processed indicator
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected String monthlySetToProcessed(Recipient recipient)
      throws SQLException {

    // if an SQL statement failed
    boolean failed = false;

    // the database transaction
    Transaction transaction = null;
    PreparedStatement setProcessed = null;
    int rowsUpdated = 0;
    String processed = "Y";

    if (recipient.getEndDate() == null) {
      processed = "N";
    }
    try {
      // start a transaction
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();

      if (setProcessed == null) {
        setProcessed = connection.prepareStatement(setToProcessed);
      }

      // update the recipient table
      setProcessed.setString(1, processed);
      setProcessed.setLong(2, recipient.getRecipientID());

      rowsUpdated = setProcessed.executeUpdate();
      if (rowsUpdated != 1) {
        System.out
            .println("        monthlySetToProcessed Warning: "
                + rowsUpdated
                + " row(s) updated in dw_casegroups table, failed to set processedFlag="
                + processed + " for DWCASEGROUPID="
                + recipient.getRecipientID());
        System.out.println("        monthlySetToProcessed Warning:SQL"
            + setToProcessed);
      }
    } catch (Exception e) {
      e.printStackTrace();
      System.out.println("        monthlySetToProcessed: caught exception "
          + e.getMessage());
      failed = true;
      // throw new SQLException("linkReciepientToEvidence:" + e.getMessage());
    } finally {

      if (transaction != null) {
        if (failed) {
          transaction.rollback();
          System.out
              .println("        monthlySetToProcessed, transaction rolled back");
        } else {
          // commit the changes
          transaction.commit();
          System.out.println("        monthlySetToProcessed commited, processed ");
        }
      }
    }
    return processed;

  }

  /**
   * Saves federal data to the aggregate table. Saves data to the evidence link
   * tables.
   * 
   * 
   * This is an algorithm based on the rules defined in our requirements
   * specifications for TANF.
   * 
   * @param String
   *          the target table name
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected int monthlySave(Recipient recipient) throws SQLException {

    // if an SQL statement failed
    boolean failedMonth = false;
    boolean failedLink = false;

    // the database transaction
    Transaction transaction = null;
    // statement to update recipient records
    PreparedStatement updateRecipients = null;
    // statement to insert evidence link records
    PreparedStatement insertEvidenceLinks = null;
    PreparedStatement unSetMASIndicator = null;

    PreparedStatement setProcessed = null;
    int evidenLinkRecords = 0;
    int rowsInserted = 0;
    try {
      try {
        // start a transaction
        transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
        final Connection connection = transaction.getConnection();

        // create the statement to update the recipient records
        if (updateRecipients == null) {
          updateRecipients = connection.prepareStatement(insertMonthRecipient);
        }
        if (unSetMASIndicator == null) {
          unSetMASIndicator = connection
              .prepareStatement(unSetPrimaryMASIndicatorThisMonth);
        }
        if (insertEvidenceLinks == null) {
          insertEvidenceLinks = connection.prepareStatement(insertEvidenceLink);
        }
        if (setProcessed == null) {
          setProcessed = connection.prepareStatement(setToProcessed);
        }
        // if the primary indicator is set then we may need to
        // reset a previous record
        if (recipient.isSetMASIndicator()) {
          try {

            unSetMASIndicator.setString(1, kMASNo);
            unSetMASIndicator.setLong(2, recipient.getYear());
            unSetMASIndicator.setLong(3, recipient.getMonth());
            unSetMASIndicator.setLong(4, recipient.getDwParticipantID());
            int masUpdated = unSetMASIndicator.executeUpdate();
            System.out
                .println("        monthlySave unsetting previous primaryMAS: "
                    + masUpdated + " row(s) updated in recipient table.");
          } catch (Exception e) {
            e.printStackTrace();
          }
        }

        // update the recipient table
        updateRecipients.setLong(1, recipient.getDwParticipantID());
        updateRecipients.setLong(2, recipient.getChildEnforcementKey());
        updateRecipients.setLong(3, recipient.getProgramKey());
        updateRecipients.setLong(4, recipient.getPersonHistoryKey());
        updateRecipients.setLong(5, recipient.getSubsizedHousingKeyKey());
        updateRecipients.setLong(6, recipient.getDwCaseID());
        updateRecipients.setLong(7, recipient.getBoe()
            .getMaintenanceAssistenceStatusKey());
        updateRecipients.setLong(8, recipient.getAssistanceStatus()
            .getMaintenanceAssistenceStatusKey());
        updateRecipients.setLong(9, recipient.getEducationalLevelKey());
        updateRecipients.setLong(10, recipient.getRecipientID());
        updateRecipients.setLong(11, recipient.getDualEligible()
            .getMaintenanceAssistenceStatusKey());
        updateRecipients.setLong(12, recipient.getMas()
            .getMaintenanceAssistenceStatusKey());
        updateRecipients.setLong(13, recipient.getEmploymentStatusKey()
            .employmentStatusKey());
        // year
        Calendar start = new GregorianCalendar();
        start.setTime(recipient.getStartDate());
        updateRecipients.setInt(14, start.get(Calendar.YEAR));

        // Month. The value returned is between 0 and 11,
        // increment by one to get a natural key
        updateRecipients.setInt(15, start.get(Calendar.MONTH) + 1);
        // last written
        updateRecipients.setTimestamp(16,
            new Timestamp(System.currentTimeMillis()));
        // start date - first day of the month
        updateRecipients.setDate(17, new Date(start.getTimeInMillis()));
        // end date - last day of the month
        updateRecipients.setDate(18, recipient.getEndDate());
        // adult indicator
        updateRecipients.setString(19, recipient.getAdultIndicator());
        // age
        updateRecipients.setInt(20, recipient.getAge());
        // parent indicator
        updateRecipients.setString(21, recipient.getParentIndicator());
        // alien indicator
        updateRecipients.setString(22, recipient.getQualifiedAlienIndicator());

        // sanctions indicator
        updateRecipients.setString(23, recipient.getSanctionsIndicator());

        // update the federal benefit indicator
        updateRecipients.setString(24, recipient.getFederalBenefitIndicator());

        // set the primary MAS indicator
        updateRecipients.setString(25, recipient.getPrimaryMASIndicator());

        // logical key in source database
        updateRecipients.setLong(26, recipient.getCaseclientgroupid());
        // child support amount
        updateRecipients.setFloat(27, recipient.getTotalChildSupportIncome());

        // case resources amount
        updateRecipients.setFloat(28, recipient.getCashResource());

        // unearned income amount
        updateRecipients.setFloat(29, recipient.getTotalUnearnedIncome());

        // earned income amount
        updateRecipients.setFloat(30, recipient.getTotalearnedIncome());

        // earned income amount
        updateRecipients.setFloat(31, recipient.getCaseStatusHistoryKey());

        rowsInserted = updateRecipients.executeUpdate();

        if (rowsInserted != 1) {
          System.out.println("        monthlySave Warning: " + rowsInserted
              + " row(s) updated in recipient table.");
        }
      } catch (Exception e) {
        System.out.println("        monthlySave: caught exception "
            + e.getMessage());
        System.out.println("        monthlySave: caught exception " + recipient);

        failedMonth = true;
      }
      // update the evidence link table with our best guess as
      // as defined in our requirement specification as
      // to what evidence resulted in an eligible recipient
      List relatedEvidence = recipient.getRelatedEvidence().getAllEvidence();
      int toBeSaved = relatedEvidence.size();
      System.out.println("        monthlySave evidence link :" + toBeSaved
          + " records to be saved, ");
      Evidence evidence;
      for (int i = 0; i < relatedEvidence.size(); i++) {
        evidence = (Evidence) relatedEvidence.get(i);

        insertEvidenceLinks.setLong(1, recipient.recipientID);
        insertEvidenceLinks.setLong(2, evidence.getKey());
        insertEvidenceLinks.setString(3, evidence.getEvidenceType());
        insertEvidenceLinks.setTimestamp(4, recipient.getLastWritten());

        try {
          int rowsUpdated = insertEvidenceLinks.executeUpdate();

          if (rowsUpdated != 1) {
            if (!isSilent) {
              System.out.println("        monthlySave Warning: " + rowsUpdated
                  + " row(s) inserted into evidence link table.");
            }
          } else if (rowsUpdated == 1) {
            evidenLinkRecords++;
          }
        } catch (SQLException e) {
          // if a recipients record processed flag is reset back
          // to unprocessed, some inserts may break the unique
          // constraint
          // that a recipient for a case can only have one
          // evidence
          // record per evidence type (.e.g. alien evidence)

          // e.g if there are 4 evidence records, and 3 have
          // already
          // been inserted, allow the fourth record to be inserted
          // on the second execution of this transform for a recipient
          // record
          failedLink = true;
          System.out.println("            monthlySave evidence link :" + e);
        }
      }

      System.out.print("        monthlySave evidence link :" + evidenLinkRecords
          + " records to be saved, ");
    } finally {

      if (transaction != null) {
        if (updateRecipients != null) {
          updateRecipients.close();
        }
        if (insertEvidenceLinks != null) {
          insertEvidenceLinks.close();
        }
        if (failedMonth && failedLink) {
          transaction.rollback();
          System.out.println("        monthlySave:failed, transaction rolled back");
        } else {
          // commit the changes
          transaction.commit();
          System.out
              .println("        monthlySave:transaction commited, processed ");
        }
      }
    }
    System.out.println("        monthlySave: " + rowsInserted
        + " recipient records updated");
    System.out.println("        monthlySave: " + evidenLinkRecords
        + " evidence link records inserted");
    return rowsInserted;
  }

  /**
   * Returns the record key if a record existed in the period
   * 
   * @param Recipient
   *          contains the product case id and participant id
   * 
   * @return AlienEvidence the record key if a record existed in the period
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected AlienEvidence findAlienRecord(final Recipient inRecipient)
      throws SQLException {

    PreparedStatement statement = null;
    Transaction transaction = null;
    Date inEndDate = null;
    AlienEvidence alienEvidence = null;

    // in order to find a person record if the case groups end date is
    // null then used an end date of now
    if (inRecipient.getEndDate() == null) {
      inEndDate = new Date(System.currentTimeMillis());
    } else {
      inEndDate = inRecipient.getEndDate();
    }

    try {
      // get a new connection
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();

      statement = connection.prepareStatement(readAlienByDate);

      statement.setLong(1, inRecipient.getDwCaseID());
      statement.setLong(2, inRecipient.getDwParticipantID());
      statement.setDate(3, inEndDate);
      statement.setDate(4, inRecipient.getStartDate());
      final ResultSet aliens = statement.executeQuery();

      if (aliens.next()) {
        alienEvidence = new AlienEvidence(aliens.getLong(1),
            aliens.getString(2));
        if (!isSilent) {
          System.out.println("        Found evidence alien record in period "
              + inRecipient.getStartDate() + "," + inEndDate);
        }
      } else {
        if (!isSilent) {
          System.out.println("        Did not find any alien record in period "
              + inRecipient.getStartDate() + "," + inEndDate + " dwcaseid="
              + inRecipient.getDwCaseID() + ", dwparticipantid="
              + inRecipient.getDwParticipantID() + " , recipientid="
              + inRecipient.getRecipientID());
        }
      }
    } catch (Exception e) {
      System.out.println("        findAlienRecord Error: " + e.getMessage()
          + readAlienByDate);
      // throw new SQLException("findAlienRecord Error: " + e.getMessage()
      // + readAlienByDate);
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
    return alienEvidence;

  }

  /**
   * Reads the product to BOE mappings.
   * 
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  protected Map initializeBOECodes() throws SQLException {

    Map boeStatusesByProduct = new HashMap();
    // catch all error and continue
    try {
      // initial data created
      StringBuffer onlyProduct = new StringBuffer();

      PreparedStatement statement = null;
      Transaction transaction = null;
      try {
        // get a new connection
        transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
        final Connection connection = transaction.getConnection();
        statement = connection.prepareStatement(readBOEMappings);
        // set parameters
        final ResultSet statuses = statement.executeQuery();

        while (statuses.next()) {
          // get the primary key for the table
          int key = new Long(statuses.getLong(1)).intValue();
          String code = statuses.getString(2);
          String desc = statuses.getString(3);
          String productCode = statuses.getString(4);
          String isBlindIndicator = statuses.getString(5);
          long age = statuses.getLong(6);
          String isChildIndicator = statuses.getString(7);

          BasisOfEligibilityStatus boe = new BasisOfEligibilityStatus(key,
              code, desc);
          Boolean isBlind = BasisOfEligibilityStatus
              .parsetIndicator(isBlindIndicator);
          Boolean isAged = BasisOfEligibilityStatus.parsetIndicator(age);
          Boolean isChild = BasisOfEligibilityStatus
              .parsetIndicator(isChildIndicator);

          // no dependency on age, child, blind
          if (isAged == null && isBlind == null && isChild == null) {
            boeStatusesByProduct.put(boe.hashKey(productCode), boe);
            onlyProduct.append(productCode);
          }
          // aged with no dependency on age-
          if ((isChild != null && isChild.booleanValue() == false)
              && isAged == null && isBlind == null) {
            boeStatusesByProduct.put(boe.hashKey(productCode), boe);
          }

          // aged only if over 65 with the product types-
          if ((isChild != null && isChild.booleanValue() == false)
              && (isAged != null && isAged.booleanValue() == true)
              && isBlind == null) {
            boe = boe.getOver65Object();
            boeStatusesByProduct.put(boe.hashKey(productCode), boe);
          }
          // blind , check if one of these product types only, no age constraint
          if ((isChild != null && isChild.booleanValue() == false)
              && isAged != null
              && (isBlind != null && isBlind.booleanValue() == true)) {
            boe = boe.getOver65Object();
            boeStatusesByProduct.put(boe.hashKey(productCode), boe);
          }
          // blind only if under 65 with the product types
          if ((isChild != null && isChild.booleanValue() == false)
              && isAged != null
              && (isBlind != null && isBlind.booleanValue() == true)) {
            boe = boe.getUnder65Object();
            boeStatusesByProduct.put(boe.hashKey(productCode), boe);
          }

          // adult with no dependency
          // adult , only check if one of these product types only
          if ((isChild != null) && isAged == null && (isBlind == null)) {
            boeStatusesByProduct.put(boe.hashKey(productCode), boe);
          }

          // adult with adult dependency
          // adult , check if one of these product types plus and adult
          if ((isChild != null && isChild.booleanValue() == false)
              && isAged == null && (isBlind == null)) {
            boeStatusesByProduct.put(boe.hashKey(productCode), boe);
          }

          // child , check if one of these product types plus and child,
          // no age dependency
          if ((isChild != null && isChild.booleanValue() == true)
              && isAged == null && (isBlind == null)) {
            boeStatusesByProduct.put(boe.hashKey(productCode), boe);
          }
          // child , check if one of these product types plus and child,
          // no age dependency
          if ((isChild != null && isChild.booleanValue() == true)
              && isAged == null && isBlind == null) {
            boe = boe.getChildObject();
            boeStatusesByProduct.put(boe.hashKey(productCode), boe);
          }
          // child , check if one of these product types plus and child,
          // with age dependency
          if ((isChild != null && isChild.booleanValue() == true)
              && (isAged != null && isAged.booleanValue() == true)
              && (isBlind == null)) {
            boe = boe.getChildObject();
            boeStatusesByProduct.put(boe.hashKey(productCode), boe);
          }
        }
        // return the key for this code
      } catch (SQLException e) {
        System.out.println("            initializeBOECodes Error: " + e.getMessage()
            + readBOEMappings);
        // throw new SQLException("findLookUpKey Error: " + e.getMessage() +
        // inSQL);
      } finally {
        // release resources
        if (statement != null) {
          statement.close();
        }
      }
    } catch (Exception e) {

    }
    return boeStatusesByProduct;
  }

  /**
   * House hold relationship evidence
   * 
   * 
   */
  class HouseHoldRelationshipEvidence extends Evidence {

    private final String roleType;

    private final boolean isParent;

    public HouseHoldRelationshipEvidence(long key, String type, boolean isParent) {
      super(key, kEvidenceNameHHR);
      roleType = type;
      this.isParent = isParent;
    }

    public boolean isParent() {
      return isParent;
    }

    @Override
    public String getType() {
      return roleType;
    }
  }

  /**
   * RecordExistsEvidence evidence
   * 
   * 
   */
  class RecordExistsEvidence extends Evidence {
    /*
     * a code table item code on the record that further describes the business
     * process or evidence
     */
    private String description = "";

    public RecordExistsEvidence(final long key, final String inEvidenceType) {
      super(key, inEvidenceType);
    }

    public void setType(String inDesc) {
      if (inDesc != null) {
        description = inDesc;
      }
    }

    @Override
    public String getType() {
      return description;
    }

  }

  /**
   * Alien evidence
   * 
   * 
   * 
   */
  class AlienEvidence extends Evidence {

    private final String alienType;

    public AlienEvidence(final long key, final String type) {
      super(key, kEvidenceNameAlien);
      alienType = type;
    }

    @Override
    public String getType() {
      return alienType;
    }
  }

  /**
   * Alien evidence
   * 
   * 
   * 
   */
  class EmploymentStatusEvidence extends Evidence {

    private long employmentStatusKey = -1;

    private String typeCode = "";

    /**
     * 
     * @param inEvidenceName
     *          - default to "NONE" if their is no evidence
     * @param key
     *          - default to -1 if their is no evidence
     * @param inEmploymentStatusKey
     *          - the federal employment status key
     * @param inTypeCode
     *          - not required
     */
    public EmploymentStatusEvidence(
        final String inEvidenceName,
        final long key,
        final long inEmploymentStatusKey,
        final String inTypeCode) {
      super(key, inEvidenceName);

      if (inTypeCode != null) {
        typeCode = inTypeCode;
      }
      employmentStatusKey = inEmploymentStatusKey;
    }

    public long employmentStatusKey() {
      return employmentStatusKey;
    }

    public boolean isSetEmploymentStatus() {
      return employmentStatusKey != -1;
    }

    @Override
    public String getType() {
      return typeCode;
    }
  }

  /**
   * Benefit evidence
   * 
   * 
   * 
   */
  class BenefitEvidence extends Evidence {

    private final String benefitType;

    private final float incomeAmount;

    public BenefitEvidence(final long key, final String type, float inAmount) {
      super(key, kEvidenceNameBenefits);
      benefitType = type;
      incomeAmount = inAmount;
    }

    @Override
    public String getType() {
      return benefitType;
    }

    public float getIncomeAmount() {
      return incomeAmount;
    }
  }

  /**
   * House hold member evidence
   * 
   * 
   * 
   */
  class HHMEvidence extends Evidence {
    private final String citizenStatus;

    public HHMEvidence(long key, String type) {
      super(key, FederalTransforms.kEvidenceNameHHM);
      citizenStatus = type;
    }

    @Override
    public String getType() {
      return citizenStatus;
    }

  }

  /**
   * Data for how the primary MAS indicator should be set
   */
  class PrimaryMASIndicator {

    /**
     * has basic products which provide the basic primary MAS indicator settings
     */
    private boolean basic = false;

    /**
     * has other products which override as the primary MAS indicator settings
     */
    private boolean other = false;

    public PrimaryMASIndicator() {
    }

    public boolean hasBasic() {
      return basic;
    }

    public void setBasic(boolean basic) {
      this.basic = basic;
    }

    public boolean hasOther() {
      return other;
    }

    public void setOther(boolean other) {
      this.other = other;
    }

  }

  /**
   * Income evidence
   * 
   * 
   * 
   */
  class IncomeEvidence extends Evidence {

    private final float incomeAmount;

    private final String unEarnedIncomeType;

    private String frequency;

    public IncomeEvidence(
        final long key,
        final String inType,
        final float inAmount,
        final String inEvidenceName) {
      super(key, inEvidenceName);
      incomeAmount = inAmount;
      unEarnedIncomeType = inType;
    }

    @Override
    public String getType() {
      return unEarnedIncomeType;
    }

    public float getIncomeAmount() {
      return incomeAmount;
    }

    public String getFrequency() {
      return frequency;
    }
  }

  /**
   * the base class for all evidence records
   * 
   * 
   * 
   */
  abstract class Evidence {

    private final long evidenceKey;

    private final String evidenceType;

    /**
     * Every evidence record has a key and an evidence type name
     * 
     * @param inKey
     * @param inName
     */
    public Evidence(final long inKey, final String inName) {
      evidenceKey = inKey;
      evidenceType = inName;
    }

    public String getEvidenceType() {
      return evidenceType;
    }

    public long getKey() {
      return evidenceKey;
    }

    /*
     * all evidence method return a type field, a product type, a citizen status
     * type etc
     */
    abstract public String getType();
  }

  /*
   * A composite class to hold what evidence may have resulted in Eligibility
   */
  class RelatedEvidence {
    // all objects much extend the Evidence class
    List evidence;

    public RelatedEvidence() {
      super();

      evidence = new ArrayList();
      ;
    }

    public void addEvidence(List inEvidence) {
      if (inEvidence != null) {
        evidence.addAll(inEvidence);
      }
    }

    public void addEvidence(Evidence inEvidence) {
      if (inEvidence != null) {
        evidence.add(inEvidence);
      }
    }

    public List getAllEvidence() {
      return evidence;
    }
  }

  /**
   * a Recipient record with links to its associated evidence
   * 
   * 
   * 
   */
  class Recipient {

    /**
     * the month to process
     */
    private int month = 0;

    /**
     * the year to process
     */
    private int year = 0;

    /**
     * total cash resources
     */
    private float cashResources = 0;

    /**
     * total unearned income from benefit and unearned income tables
     */
    private float unearnedIncome = 0;

    /**
     * total unearned income from benefit and unearned income tables
     */
    private float earnedIncome = 0;
    /**
     * total unearned income from benefit and unearned income tables
     */
    private float childSupportIncome = 0;

    /**
     * the product name, e.g. PN3
     */
    private String productCode = "";

    /**
     * the primary key
     */
    private long recipientID = 0;

    /**
     * links the recipient to a case status active record there may be many so
     * one is selected
     */
    long caseStatusHistoryKey = 0;

    /**
     * the logical key
     */
    private long caseclientgroupid = 0;

    /**
     * recipient date of birth
     */
    Date dateOfBirth = null;

    /**
     * the start date on the recipient table
     */
    Date startDate = null;

    /**
     * the end date on the recipient table
     */
    Date endDate = null;

    /**
     * the product case identity
     */
    long dwCaseID = 0;

    /**
     * the product case identity
     */
    long dwParticipantID = 0;

    Timestamp lastWritten;

    private final String programCode;
    private int programKey = -1;
    private long personHistoryKey = -1;

    RelatedEvidence relatedEvidence = null;

    BasisOfEligibilityStatus boe = null;

    MedicalAssistance mas = null;

    MedicalAssistance dualEligible = null;

    MedicalAssistance publicAssistance = null;

    /**
     * the recipients age
     */
    short age = 0;

    /**
     * is the recipient an adult
     */
    boolean adultIndicator = false;

    /**
     * is the recipient a parent
     */
    boolean parentIndicator = false;

    /**
     * is the recipient an alien, check citizen status and alien type
     */
    boolean alienIndicator = false;

    /**
     * is the recipient an fed benefit type, check benefits types
     */
    boolean federalBenefitIndicator = false;

    /**
     * default to true, set to false explicitly
     */
    private boolean primaryMAS = false;

    private EmploymentStatusEvidence employmentStatus;

    private long educationLevelKey = kUndefinedKey;

    private int childEnforcementKey = kUndefinedKey;

    private int subsizedHousingKey = kUndefinedKey;

    private boolean hasSanctions = false;

    public long getPersonHistoryKey() {
      return personHistoryKey;
    }

    public void setProductCode(String inProductCode) {
      productCode = inProductCode;
    }

    public long getCaseclientgroupid() {
      return caseclientgroupid;
    }

    public void setStartDate(Date date) {
      if (date != null) {
        startDate = date;
      }
    }

    public int getMonth() {
      return month;
    }

    public void setMonth(int month) {
      this.month = month;
    }

    public int getYear() {
      return year;
    }

    public void setYear(int year) {
      this.year = year;
    }

    public void setCaseclientgroupid(long caseclientgroupid) {
      this.caseclientgroupid = caseclientgroupid;
    }

    public void setFederalBenefitsIndicator(boolean hasFederalBenefits) {
      federalBenefitIndicator = hasFederalBenefits;
    }

    public void setPersonHistoryKey(long personHistoryKey) {
      this.personHistoryKey = new Long(personHistoryKey).intValue();
    }

    public int getProgramKey() {
      return programKey;
    }

    public void setProgramKey(long programKey) {
      this.programKey = new Long(programKey).intValue();
    }

    /**
     * This object represents a product recipient
     * 
     * @param inRecipientID
     *          the primary key on the case groups table
     * @param inDOB
     *          the date of birth
     * @param inStartDate
     *          the start date from the case groups table
     * @param inEndDate
     *          the end date from the case groups table or null
     * @param inDWCaseID
     *          the case identity
     * @param inDWParticipantID
     *          the participant identity
     * @param inLastWritten
     *          the last written value from case groups table
     * @param inProductCode
     *          the product code
     * @param inProgramCode
     *          the program code
     */
    Recipient(
        final long inRecipientID,
        final Date inDOB,
        final Date inStartDate,
        final Date inEndDate,
        final long inDWCaseID,
        final long inDWParticipantID,
        final Timestamp inLastWritten,
        final String inProductCode,
        final String inProgramCode) {

      recipientID = inRecipientID;
      dateOfBirth = inDOB;
      startDate = inStartDate;
      endDate = inEndDate;
      dwCaseID = inDWCaseID;
      dwParticipantID = inDWParticipantID;
      lastWritten = inLastWritten;
      productCode = inProductCode;
      programCode = inProgramCode;
    }

    public void setEndDate(Date date) {
      if (date != null) {
        endDate = date;
      }

    }

    /**
     * Only a shallow clone of search criteria only If more data is read then
     * modify here
     * 
     * @param inShallowClone
     */
    Recipient(Recipient inShallowClone) {

      recipientID = inShallowClone.recipientID;
      dateOfBirth = inShallowClone.dateOfBirth;
      startDate = inShallowClone.startDate;
      endDate = inShallowClone.endDate;
      dwCaseID = inShallowClone.dwCaseID;
      dwParticipantID = inShallowClone.dwParticipantID;
      lastWritten = inShallowClone.lastWritten;
      productCode = inShallowClone.productCode;
      programCode = inShallowClone.programCode;

      personHistoryKey = inShallowClone.personHistoryKey;
      programKey = inShallowClone.programKey;
      personHistoryKey = inShallowClone.personHistoryKey;
      caseclientgroupid = inShallowClone.caseclientgroupid;
      caseStatusHistoryKey = inShallowClone.caseStatusHistoryKey;
      month = inShallowClone.month;
      year = inShallowClone.year;

      productCode = inShallowClone.productCode;

    }

    @Override
    public String toString() {
      return "[dwcasegroupid=" + getRecipientID() + " startdate="
          + getStartDate() + " enddate=" + getEndDate() + "]" + "[year="
          + getYear() + " month=" + getMonth() + "]";

    }

    public boolean hasSanctions() {
      return hasSanctions;

    }

    public String getSanctionsIndicator() {
      return parentIndicator == true ? kSanctionYes : kSanctionNo;
    }

    public void setSanctions() {
      hasSanctions = true;

    }

    public int getChildEnforcementKey() {
      return childEnforcementKey;

    }

    public void setChildEnforcementKey(int inChildEnforcementKey) {
      childEnforcementKey = inChildEnforcementKey;

    }

    public int getSubsizedHousingKeyKey() {
      return subsizedHousingKey;

    }

    public void setSubsizedHousingKeyKey(int inSubsizedHousingKey) {
      subsizedHousingKey = inSubsizedHousingKey;

    }

    public void setEmploymentStatusKey(
        EmploymentStatusEvidence inEmploymentStatusNoInLabourForce) {
      employmentStatus = inEmploymentStatusNoInLabourForce;

    }

    public EmploymentStatusEvidence getEmploymentStatusKey() {
      return employmentStatus;
    }

    public void setEducationalLevelKey(long inEducationalLevel) {
      educationLevelKey = inEducationalLevel;

    }

    public long getEducationalLevelKey() {
      return educationLevelKey;
    }

    public float getTotalUnearnedIncome() {
      return unearnedIncome;
    }

    public float getTotalearnedIncome() {
      return earnedIncome;
    }

    public float getCashResource() {
      return cashResources;
    }

    public void incrementCashResources(float inTotal) {
      cashResources += inTotal;
    }

    public float getTotalChildSupportIncome() {
      return childSupportIncome;
    }

    public void incrementTotalChildSupportIncome(float inTotal) {
      childSupportIncome += inTotal;
    }

    public void incrementTotalEarnedIncome(float inTotal) {
      earnedIncome += inTotal;
    }

    public void incrementTotalUnearnedIncome(float inTotal) {
      unearnedIncome += inTotal;
    }

    public void setAssistanceStatus(MedicalAssistance InAssistanceStatus) {
      publicAssistance = InAssistanceStatus;

    }

    public MedicalAssistance getAssistanceStatus() {
      return publicAssistance;
    }

    public Timestamp getLastWritten() {
      return lastWritten;
    }

    public String getFederalBenefitIndicator() {
      return federalBenefitIndicator == true ? kFederalBenefitYes
          : kFederalBenefitNo;
    }

    public String getQualifiedAlienIndicator() {
      return alienIndicator == true ? kAlienYes : kAlienNo;
    }

    public String getParentIndicator() {
      return parentIndicator == true ? kParentYes : kParentNo;
    }

    public boolean isAdult() {
      return adultIndicator;
    }

    public String getAdultIndicator() {
      return adultIndicator == true ? kAdultYes : kAdultNo;
    }

    public short getAge() {
      return age;
    }

    public long getCaseStatusHistoryKey() {
      return caseStatusHistoryKey;
    }

    public Date getDateOfBirth() {
      return dateOfBirth;
    }

    public long getDwCaseID() {
      return dwCaseID;
    }

    public long getDwParticipantID() {
      return dwParticipantID;
    }

    public Date getEndDate() {
      return endDate;
    }

    /**
     * returns the primary key from the central case groups table
     * 
     * @return the primary key from the central case groups table
     */
    public long getRecipientID() {
      return recipientID;
    }

    public Date getStartDate() {
      return startDate;
    }

    public void setQualifiedAlienIndicator(boolean alienIndicator) {
      this.alienIndicator = alienIndicator;
    }

    public void setAdultIndicator(boolean adultIndicator) {
      this.adultIndicator = adultIndicator;
    }

    public void setAge(short age) {
      this.age = age;
    }

    public void setCaseStatusHistoryKey(long caseStatusHistoryKey) {
      this.caseStatusHistoryKey = caseStatusHistoryKey;
    }

    public void setParentIndicator(boolean parentIndicator) {
      this.parentIndicator = parentIndicator;
    }

    public void setEvidenceKeys(RelatedEvidence inRelatedEvidence) {
      relatedEvidence = inRelatedEvidence;
    }

    public RelatedEvidence getRelatedEvidence() {
      return relatedEvidence;
    }

    public BasisOfEligibilityStatus getBoe() {
      return boe;
    }

    public void setBoe(BasisOfEligibilityStatus boe) {
      this.boe = boe;
    }

    public MedicalAssistance getMas() {
      return mas;
    }

    public void setMas(MedicalAssistance mas) {
      this.mas = mas;
    }

    public void setPrimaryMAS() {
      this.primaryMAS = true;
    }

    public void unsetPrimaryMAS() {
      this.primaryMAS = false;
      ;
    }

    public boolean isSetMASIndicator() {
      return primaryMAS;
    }

    public String getPrimaryMASIndicator() {
      return primaryMAS == true ? kMASYes : kMASNo;
    }

    public void setDualEligible(MedicalAssistance inDualEligible) {
      dualEligible = inDualEligible;
    }

    public MedicalAssistance getDualEligible() {
      return dualEligible;
    }

    public String getProductCode() {
      return productCode;
    }

    public String getProgramCode() {
      return programCode;
    }

  }

}