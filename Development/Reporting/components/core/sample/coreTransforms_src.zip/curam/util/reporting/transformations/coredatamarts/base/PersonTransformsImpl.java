/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.coredatamarts.base;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.transformations.coredatamarts.intf.PersonTransforms;

/**
 * This module implements any calculations required for person based attributes.
 * 
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
class PersonTransformsImpl extends PersonTransforms {

  private final String kYes = "Y";
  private final String kNo = "N";
  private final String kTanfAdult = "Adult";
  private final String kTanfChild = "Child";

  private final String readAgegroupKey = "select id, busarea from dm_agegroups where startage <=? and endage >=? and programcode=?";

  // ___________________________________________________________________________

  public PersonTransformsImpl() throws SQLException {
  }

  /**
   * Returns the age group key for TANF recipients.
   * 
   * @param inAdultIND
   *          adult indicator, used with business area column in the database
   * @param inAge
   *          Age
   * @param inProgram
   *          business area type
   * 
   * @return int the age group key for the indicator parameters
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  @Override
  public int findAgegroupKey(final String inAdultIND, final int inAge,
      final String inProgram) throws SQLException {

    int agegroupKey = -1;
    Transaction transaction = null;
    PreparedStatement statement = null;
    String program = inProgram;
    if (program == null || program.length() == 0) {
      program = "undefined";
    }
    try {
      // start a transaction, get DAO to read from the control table
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);
      final Connection connection = transaction.getConnection();

      int key;
      String busarea;
      statement = connection.prepareStatement(readAgegroupKey);
      statement.setInt(1, inAge);
      statement.setInt(2, inAge);
      statement.setString(3, program);

      final ResultSet rs = statement.executeQuery();

      while (rs.next()) {
        key = rs.getInt(1);
        busarea = rs.getString(2);
        agegroupKey = key;
        if (inAdultIND.equalsIgnoreCase(kYes)
            && busarea.equalsIgnoreCase(kTanfAdult)) {
          agegroupKey = key;
          break;
        } else if (inAdultIND.equalsIgnoreCase(kNo)
            && busarea.equalsIgnoreCase(kTanfChild)) {
          agegroupKey = key;
          break;
        }
      }
    } catch (Exception e) {
      System.out.println("readAgegroupKey Error: " + e.getMessage()
          + readAgegroupKey);
      throw new SQLException("readAgegroupKey Error: " + e.getMessage()
          + readAgegroupKey);

    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
      if (transaction != null && !transaction.isClientManagedTransaction()) {
        transaction.rollback();
        System.out.println("findAgegroupKey:transaction completed");
      }
    }
    return agegroupKey;
  }
}
