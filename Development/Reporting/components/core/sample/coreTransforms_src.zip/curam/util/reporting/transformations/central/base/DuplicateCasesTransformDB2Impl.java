/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.central.base;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.type.*;

/**
 * Sets a flag for duplicated cases, i.e. case identities that appear more than
 * once.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public abstract class DuplicateCasesTransformDB2Impl {

  /**
   * selects source case data.
   */
  private final String kSQLSelectSourceData;

  /**
   * selects case status source data.
   */
  private final String kSQLSelectCaseSourceData;

  /**
   * SQL insert statement for status history table.
   */
  private final String kSQLUpdate;

  /**
   * SQL insert statement for status status history table.
   */
  private final String kSQLCaseStatusUpdate;

  // ___________________________________________________________________________
  /**
   * Create a new object to update the case table.
   * 
   * @param inTargetTable
   *          the source table name
   */
  public DuplicateCasesTransformDB2Impl(final String inTargetTable) {
    kSQLUpdate = "update " + inTargetTable
        + " set insertind = ? where dwcaseid = ?";

    kSQLCaseStatusUpdate = "update " + inTargetTable
        + " set insertind = ? where dwsurogatekey = ?";

    kSQLSelectSourceData = "select dwcaseid, caseid  from " + inTargetTable
        + " order by caseid";

    kSQLSelectCaseSourceData = "select dwsurogatekey, dwcaseid, dwstatusid, startdate  from "
        + inTargetTable + " order by dwcaseid, dwstatusid, startdate";
  }

  // ___________________________________________________________________________
  /**
   * Set a filter flag on duplicate cases.
   * 
   * @param inTargetTableName
   *          table name where source data resides
   * @exception SQLException
   *              if a database operation fails
   */
  public void executePostProcess(final String inTargetTableName)
      throws SQLException {
    // stored success of SQL statements
    boolean failed = false;
    // the database transaction
    Transaction transaction = null;

    try {
      // start a transaction
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);

      // read source records where registration and received date are valid
      final List<Long> duplicateKeys = readSourceData();

      // insert status records into case status history table
      updateIndicator(kSQLUpdate, duplicateKeys);

    } catch (Exception e) {
      System.out
          .println("DuplicateCasesTransformDB2Impl:execute: caught exception "
              + e.getMessage());
      failed = true;
      throw new SQLException("DuplicateCasesTransformDB2Impl:execute:"
          + e.getMessage());
    } finally {
      if (transaction != null && !transaction.isClientManagedTransaction()) {
        if (failed) {
          transaction.rollback();
          System.out.println("DuplicateCasesTransformDB2Impl:execute:failed");
        } else {
          // commit the changes
          transaction.commit();
          System.out
              .println("DuplicateCasesTransformDB2Impl:execute:successfull");
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Set a filter flag on duplicate cases.
   * 
   * @param inTargetTableName
   *          table name where source data resides
   * @exception SQLException
   *              if a database operation fails
   */
  public void flagCaseStatusDuplicates(final String inTargetTableName)
      throws SQLException {
    // stored success of SQL statements
    boolean failed = false;
    // the database transaction
    Transaction transaction = null;

    try {
      // start a transaction
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);

      // read source records where registration and received date are valid
      final List<Long> duplicateKeys = readCaseStatusSourceData();

      // insert status records into case status history table
      updateIndicator(kSQLCaseStatusUpdate, duplicateKeys);

    } catch (Exception e) {
      System.out
          .println("DuplicateCasesTransformDB2Impl:execute: caught exception "
              + e.getMessage());
      failed = true;
      throw new SQLException("DuplicateCasesTransformDB2Impl:execute:"
          + e.getMessage());
    } finally {
      if (transaction != null && !transaction.isClientManagedTransaction()) {
        if (failed) {
          transaction.rollback();
          System.out.println("DuplicateCasesTransformDB2Impl:execute:failed");
        } else {
          // commit the changes
          transaction.commit();
          System.out
              .println("DuplicateCasesTransformDB2Impl:execute:successfull");
        }
      }
    }
  }

  // __________________________________________________________________________
  /**
   * Reads the list of records to be processed.
   * 
   * @param inDuplicateCases
   *          duplicate case identities
   * 
   * @throws SQLException
   *           is a database operation fails
   */
  private void updateIndicator(String inUpdateSQL,
      final List<Long> inDuplicateCases) throws SQLException {
    PreparedStatement statement = null;
    int rowsUpdated = 0;

    try {
      final Connection connection = TransactionFactory.getTransaction(
          DataWarehouseConstants.kDefaultDatabase).getConnection();

      statement = connection.prepareStatement(inUpdateSQL);

      for (int i = 0; i < inDuplicateCases.size(); i++) {
        statement.setString(1, "N");
        statement.setLong(2, ((Long) inDuplicateCases.get(i)).longValue());
        rowsUpdated += statement.executeUpdate();
      }

    } catch (Exception e) {
      System.out.println("DuplicateCasesTransformDB2Impl:updateIndicator:" + e);

      throw new SQLException("DuplicateCasesTransformDB2Impl:updateIndicator:"
          + e.getMessage());
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
      System.out.println("DuplicateCasesTransformDB2Impl:updateIndicator:"
          + rowsUpdated + " cases filtered out");
    }
  }

  // __________________________________________________________________________
  /**
   * Read the keys for records not to be inserted.
   * 
   * @return List duplicate record keys
   * @throws SQLException
   *           if a database operation fails
   */

  public List<Long> readSourceData() throws SQLException {
    PreparedStatement statement = null;
    final List<Long> keys = new ArrayList<Long>();

    try {
      final Connection connection = TransactionFactory.getTransaction(
          DataWarehouseConstants.kDefaultDatabase).getConnection();

      statement = connection.prepareStatement(kSQLSelectSourceData);

      final ResultSet rs = statement.executeQuery();
      long previousCase = -1;
      long currentCase = 0;
      long currentKey = 0;

      while (rs.next()) {

        currentKey = rs.getLong(1);
        currentCase = rs.getLong(2);

        if (currentCase == previousCase) {
          keys.add(new Long(currentKey));
        }
        previousCase = currentCase;
      }
    } catch (Exception e) {
      System.out.println("readSourceData:" + kSQLSelectSourceData + e);
      throw new SQLException("readSourceData:" + e.getMessage());
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
    return keys;
  }

  // __________________________________________________________________________
  /**
   * Read the keys for records not to be inserted.
   * 
   * @return List duplicate record keys
   * @throws SQLException
   *           if a database operation fails
   */

  public List<Long> readCaseStatusSourceData() throws SQLException {
    PreparedStatement statement = null;
    final List<Long> keys = new ArrayList<Long>();

    try {
      final Connection connection = TransactionFactory.getTransaction(
          DataWarehouseConstants.kDefaultDatabase).getConnection();

      statement = connection.prepareStatement(kSQLSelectCaseSourceData);

      final ResultSet rs = statement.executeQuery();
      long previousCase = -1;
      long currentCase = 0;
      long previousStatus = -1;
      long currentStatus = 0;
      Date previousStartDate = null;
      Date currentStartDate = null;
      long currentKey = 0;

      while (rs.next()) {

        currentKey = rs.getLong(1);
        currentCase = rs.getLong(2);
        currentStatus = rs.getLong(3);
        currentStartDate = rs.getDate(4);

        if (currentCase == previousCase && currentStatus == previousStatus
            && currentStartDate.compareTo(previousStartDate) == 0) {
          keys.add(new Long(currentKey));
        }
        previousCase = currentCase;
        previousStatus = currentStatus;
        previousStartDate = currentStartDate;
      }
    } catch (Exception e) {
      System.out.println("readSourceData:" + kSQLSelectSourceData + e);
      throw new SQLException("readSourceData:" + e.getMessage());
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
    return keys;
  }

}
