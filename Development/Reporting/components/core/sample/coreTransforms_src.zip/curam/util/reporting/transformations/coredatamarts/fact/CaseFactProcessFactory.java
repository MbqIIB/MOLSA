/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.coredatamarts.fact;

import java.sql.SQLException;

import curam.util.reporting.transformations.coredatamarts.base.CaseFactProcessDayTransformBase;
import curam.util.reporting.transformations.coredatamarts.base.CaseFactProcessMonthTransformBase;
import curam.util.reporting.transformations.coredatamarts.base.CaseFactProcessTransformBase;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;

import curam.util.type.*;

/**
 * Factory class to create an instance of data marts case status
 * {@link ETLPostProcess} class, one of its subclasses, a proxy for it or a mock
 * object for it.
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public final class CaseFactProcessFactory {

  // ___________________________________________________________________________
  /**
   * Ensures this class cannot be created.
   */
  private CaseFactProcessFactory() {
  }

  // ___________________________________________________________________________
  /**
   * Returns a new object to post process the case records.
   * 
   * @return ETLPostProcess
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  public static ETLPostProcess newMonthInstance() throws SQLException {
    // returns the base implementation of the data access object
    ETLPostProcess etlPostProcess;

    etlPostProcess = new CaseFactProcessMonthTransformBase();

    return etlPostProcess;
  }

  // ___________________________________________________________________________
  /**
   * Returns a new object to post process the case fact records.
   * 
   * @return ETLPostProcess
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  public static ETLPostProcess newFactInstance() throws SQLException {
    // returns the base implementation of the data access object
    ETLPostProcess etlPostProcess;

    etlPostProcess = new CaseFactProcessTransformBase();

    return etlPostProcess;
  }

  // ___________________________________________________________________________
  /**
   * Returns a new object to post process the case records.
   * 
   * @return ETLPostProcess
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  public static ETLPostProcess newDayInstance() throws SQLException {
    // returns the base implementation of the data access object
    ETLPostProcess etlPostProcess;

    etlPostProcess = new CaseFactProcessDayTransformBase();

    return etlPostProcess;
  }

}
