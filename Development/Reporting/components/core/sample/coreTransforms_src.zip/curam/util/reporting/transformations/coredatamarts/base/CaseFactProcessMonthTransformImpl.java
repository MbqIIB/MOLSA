/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * 
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.coredatamarts.base;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.PropertiesCache;
import curam.util.reporting.internal.config.PropertyReaderFactory;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.dao.control.base.ProcessControl;
import curam.util.reporting.internal.dao.control.fact.ControlTableFactory;
import curam.util.reporting.internal.dao.control.intf.ControlTable;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.base.PostProcessImpl;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;
import curam.util.reporting.transformations.coredatamarts.dbclient.CustomTransforms;
import curam.util.reporting.transformations.prepost.dbclient.PrePostTransforms;

/**
 * This module populates the fact case process month aggregate table.
 * 
 * 
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
abstract class CaseFactProcessMonthTransformImpl extends PostProcessImpl
implements ETLPostProcess {

    /**
     * SQL to insert an aggregate record.
     */
    private final String sqlInsert = "insert into dm_aggcasemonth values(?,(select timeperiodkey from dm_dimtimeperiod where daydate=?),?,?,?,?,?,?,?,?,?,?,?)";

    /**
     * the SQL statement to read fact records.
     */
    private final String sqlSelectAggregateByOrgProductYearMonth = "select NOCASESONHANDEND from dm_aggcasemonth where orgunitkey=? "
        + " and dimproductkey=? and TIMEPERIODKEY = (SELECT TIMEPERIODKEY FROM DM_DIMTIMEPERIOD WHERE DAYDATE=?)";

    /**
     * the SQL statement to read fact records.
     */
    private final String sqlSelectGroupByOrgProduct = "select  ORGUNITKEY, DIMPRODUCTKEY from  DM_FACTCASEHISTORY t1,"
        + " DM_dimtimeperiod t2, DM_dimtimeperiod t3 where   t3.dmyear = ?"
        + " and t3.dmmonth = ?  and t1.startdatekey=t2.timeperiodkey   "
        + " and t2.timeperiodkey = t3.timeperiodkey"
        + " group by  ORGUNITKEY,  DIMPRODUCTKEY"
        + " union"
        + " select ORGUNITKEY, DIMPRODUCTKEY from  DM_AGGCASEMONTH"
        + " where TIMEPERIODKEY = (SELECT TIMEPERIODKEY FROM DM_DIMTIMEPERIOD WHERE DAYDATE=?) and NOCASESONHANDEND <>0";

    /**
     * the SQL statement to count the number of cases for a month and year per
     * product per organization unit.
     */
    private final String sqlSelectClearedByOrgunitProductYearMonth = "select status.STATUSCATEGORY,count(*) from DM_FACTCASEHISTORY fact , "
        + " dm_dimstatus status, dm_dimtimeperiod timeperiod,"
        + " dm_dimtimeperiod timeperiod2  where fact.ORGUNITKEY = ? "
        + " and fact.enddatekey = -1"
        + " and fact.DIMPRODUCTKEY = ?  and fact.STATUSKEY = status.STATUSKEY"
        + " and status.STATUSCATEGORY IN ('ONHAND', 'CLEARED')  "
        + " and fact.startdatekey=timeperiod.timeperiodkey"
        + " and timeperiod2.dmyear=? and timeperiod2.dmmonth=? "
        + " and timeperiod.timeperiodkey=timeperiod2.timeperiodkey "
        + " group by STATUSCATEGORY";

    /**
     * the SQL statement to count the number of received cases for a month and
     * year per product per organization unit.
     */
    private final String sqlSelectReceivedByOrgunitProductYearMonth = "select count(*) from DM_FACTCASEHISTORY fact , "
        + " dm_dimstatus status, dm_dimtimeperiod timeperiod,"
        + " dm_dimtimeperiod timeperiod2  where fact.ORGUNITKEY = ? "
        + " and fact.DIMPRODUCTKEY = ?  and fact.STATUSKEY = status.STATUSKEY"
        + " and status.STATUSNAME IN ('Received')  "
        + " and fact.startdatekey=timeperiod.timeperiodkey"
        + " and timeperiod2.dmyear=? and timeperiod2.dmmonth=? "
        + " and timeperiod.timeperiodkey=timeperiod2.timeperiodkey ";

    /**
     * the SQL statement to count the number of cases prior to a given date per
     * product per organization unit.
     */
    private final String sqlSelectByOrgunitProductDay = "select status.STATUSCATEGORY,count(*) from DM_FACTCASEHISTORY fact , "
        + " dm_dimstatus status, dm_dimtimeperiod timeperiod,"
        + " dm_dimtimeperiod timeperiod2  where fact.ORGUNITKEY = ? "
        + " and fact.enddatekey = -1"
        + " and fact.DIMPRODUCTKEY = ?"
        + " and fact.STATUSKEY = status.STATUSKEY  "
        + " and status.STATUSCATEGORY IN ('ONHAND', 'CLEARED')  "
        + " and fact.startdatekey=timeperiod.timeperiodkey"
        + " and timeperiod2.daydate < ? "
        + " and timeperiod.timeperiodkey=timeperiod2.timeperiodkey "
        + " group by STATUSCATEGORY";

    /**
     * the cleared status.
     */
    private final String kCleared = "CLEARED";

    /**
     * the on hand status.
     */
    private final String kOnhand = "ONHAND";

    static private boolean debugMode = false;

    static Calendar debugStart = null;

    static Calendar debugEnd = null;

    public static void main(final String args[]) throws SQLException {
        System.out
        .println("manually delete data from the table for the months being processed.");
        final String usage = " Usage: now[yyyymmdd] lastETLdate[yyyymmdd] e.g. 20090630 ";
        if (args.length != 2) {
            System.out.println(usage);
        }
        // reads the properties file
        PropertiesCache propertyReader = null;
        try {
            propertyReader = PropertyReaderFactory.getConnectionPropertyReader();
        } catch (final FileNotFoundException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        final String dateFormat = propertyReader
        .getValue(DataWarehouseConstants.kEnvironmentAggregateDateFormat);

        debugMode = true;
        java.util.Date start;
        java.util.Date end;
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
        try {

            start = simpleDateFormat.parse(args[0]);
            final Calendar cal = simpleDateFormat.getCalendar();
            cal.setTime(start);
            System.out.println("reading start date(normally last ETL date)="
                    + simpleDateFormat.format(start));
            // issue here on the month - to be fixed later
            debugStart = new GregorianCalendar(cal.get(Calendar.YEAR),
                    Integer.parseInt(args[0].substring(3, 5)) - 1,
                    cal.get(Calendar.DAY_OF_MONTH));
            System.out.println("converted=" + debugStart.getTime());
        } catch (final Exception e) {
            System.out.println("Invalid parameter start date");
            throw new SQLException(usage);
        }
        try {

            end = simpleDateFormat.parse(args[1]);
            final Calendar cal = simpleDateFormat.getCalendar();

            System.out.println("reading start date(normally last ETL date)="
                    + simpleDateFormat.format(end));
            debugEnd = new GregorianCalendar(cal.get(Calendar.YEAR),
                    Integer.parseInt(args[1].substring(3, 5)) - 1,
                    cal.get(Calendar.DAY_OF_MONTH));
            System.out.println("converted=" + debugEnd.getTime());
        } catch (final Exception e) {
            System.out.println("Invalid parameter end date");
            throw new SQLException(usage);
        }

        TransactionFactory
        .overRideRequestforDefaultTransactions(DataWarehouseConstants.kCoreDataMartDatabase);
        // PrePostTransforms.preProcessETL("DM_AGGCASEMONTH");
        CustomTransforms.caseFactProcessMonthAggregate("DM_AGGCASEMONTH");
    }

    // ___________________________________________________________________________
    /**
     * Populates the aggregate month table using the case fact processes table.
     * 
     * @param inTargetTableName
     *          the target table being populated
     * @throws java.sql.SQLException
     *           if a database operation failed
     */
    @Override
    @SuppressWarnings("deprecation")
    public void executePostProcess(final String inTargetTableName)
    throws SQLException {
        // if an SQL statement failed, initialize to false
        boolean failed = false;
        // the database transaction
        Transaction transaction = null;
        int monthsProcessed = 0;
        int previousmonth = 0;
        int previousyear = 0;

        try {

            Calendar now = new GregorianCalendar();
            if (debugMode) {
                now = debugEnd;
                PrePostTransforms.preProcessETL(inTargetTableName);
            }
            // only run if this is the last day of the month,
            // assumes that the fact case process ETL has completed.
            if (now.get(Calendar.DAY_OF_MONTH) != now
                    .getActualMaximum(Calendar.DAY_OF_MONTH)) {
                System.out.println("month is=" + now.get(Calendar.MONTH)
                        + ", Not last day of month, current day of month="
                        + now.get(Calendar.DAY_OF_MONTH) + "last day of month is="
                        + now.getActualMaximum(Calendar.DAY_OF_MONTH));

                return;
            }

            // start a transaction, get DAO to read from the control table
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);

            final ControlTable controlTable = ControlTableFactory
            .newInstance(new ReportingDBType(inTargetTableName));

            // get the last date the ETL was executed
            final ProcessControl processControl = controlTable
            .read(inTargetTableName);
            Calendar start = new GregorianCalendar(processControl
                    .getLastExtractionDate().getYear() + 1900, processControl
                    .getLastExtractionDate().getMonth(), processControl
                    .getLastExtractionDate().getDate());
            if (debugMode) {
                start = debugStart;
            }
            if (now.before(start)) {
                System.out.println("End date is before start date, check "
                        + " control table and system clock");
                return;
            }
            if (start.get(Calendar.YEAR) == now.get(Calendar.YEAR)
                    && start.get(Calendar.MONTH) == now.get(Calendar.MONTH)) {
                System.out.println("Already executed for date  " + now.getTime());

                return;
            }
            System.out.println("START(last etl date)=" + start.getTime());
            System.out.println("NOW=" + now.getTime());
            boolean completed = false;

            do {
                previousmonth = start.get(Calendar.MONTH);
                previousyear = start.get(Calendar.YEAR);
                // rolls forward the month and year if necessary
                if (start.get(Calendar.MONTH) == Calendar.DECEMBER) {
                    start.set(Calendar.MONTH, Calendar.JANUARY);
                    start.roll(Calendar.YEAR, 1);
                } else {
                    start.roll(Calendar.MONTH, 1);
                }
                // place the aggregate row in the aggregate table
                System.out.println("Processed: " + start.getTime().toString());
                // months start at 0 in calendar and 1 in time period
                processMonth(start.get(Calendar.YEAR), start.get(Calendar.MONTH) + 1,
                        previousmonth + 1, previousyear);
                // reset the previous month and year
                previousmonth = 0;
                previousyear = 0;
                // increase the month
                monthsProcessed++;
                if (start.get(Calendar.YEAR) == now.get(Calendar.YEAR)
                        && start.get(Calendar.MONTH) == now.get(Calendar.MONTH)) {
                    completed = true;
                }

            } while (!completed);

            /*
             * try { //update control table
             * super.executePostProcess(inTargetTableName); } catch (Exception e) {
             * System.out .print (
             * "CaseFactProcessTransformImpl: check that the pre process was executed, the post process moves the extract time(nulls allowed)column value into last_ETL_date (not null"
             * );
             * 
             * throw new Exception(
             * "verify the pre process executed, as the post will fail if the pre did not populate the extract time column"
             * ); }
             */
        } catch (final Exception e) {
            System.out.println("CaseFactProcessTransformImpl:" + e.getMessage());
            failed = true;
            throw new SQLException("CaseFactProcessTransformImpl:" + e.getMessage());
        } finally {

            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                    System.out
                    .println("CaseFactProcessTransformImpl:failed, transaction rolled back");
                } else {
                    // commit the changes
                    transaction.commit();
                    System.out
                    .println("CaseFactProcessTransformImpl:transaction commited, processed "
                            + monthsProcessed + " month(s)");
                }
            }
        }
    }

    // __________________________________________________________________________
    /**
     * Calculates the measures for a aggregate month.
     * 
     * @param inYear
     *          the year to process
     * @param inMonth
     *          the month to process
     * @param inPreviousmonth
     * @param inPreviousyear
     * @throws SQLException
     *           if a database operation fails
     */

    public void processMonth(final int inYear, final int inMonth,
            final int inPreviousmonth, final int inPreviousyear) throws SQLException {
        List<CaseProcessFactAggregate> aggregateRecords = null;
        final int commitLevel = 1000;
        final int commentCurrent = 0;
        PreparedStatement statement = null;

        aggregateRecords = readAggregateSet(inYear, (short) inMonth,
                (short) inPreviousmonth, inPreviousyear);
        try {
            // get a new connection
            Transaction transaction = null;
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();
            statement = connection.prepareStatement(sqlInsert);
            int uncommitted = 0;
            CaseProcessFactAggregate aggregateRecord;

            for (int i = 0; i < aggregateRecords.size(); i++) {

                aggregateRecord = (CaseProcessFactAggregate) aggregateRecords.get(i);

                readClearedCases(aggregateRecord);
                readReceivedCases(aggregateRecord);
                readCasesOnHandAtStartOfMonth(aggregateRecord);
                onHandAtEndOfMonth(aggregateRecord);

                averageDaysToClearCases(aggregateRecord);
                averageDaysOpenToActive(aggregateRecord);
                averageDaysOpenToSubmitted(aggregateRecord);
                averageDaysReceivedToRegistered(aggregateRecord);
                averageDaysRegisteredToActive(aggregateRecord);
                averageDaysSubbmittedToApproved(aggregateRecord);

                insert(aggregateRecord, statement);
                if (uncommitted >= commitLevel) {
                    transaction.executeBatch(statement);
                    uncommitted = 0;
                }
            }
            if (uncommitted >= 0) {
                transaction.executeBatch(statement);
                uncommitted = 0;
            }
        } catch (final Exception e) {

        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
    }

    // __________________________________________________________________________
    /**
     * Generates a list of organizations by products that have case activity in a
     * given month.
     * 
     * @param inYear
     *          the year
     * @param inMonth
     *          the month
     * @param inPreviousmonth
     * @param inPreviousyear
     * @return List the aggregate records
     * @throws SQLException
     *           if a database operation fails
     */

    @SuppressWarnings("deprecation")
    public List<CaseProcessFactAggregate> readAggregateSet(final int inYear,
            final short inMonth, final short inPreviousmonth, final int inPreviousyear)
            throws SQLException {
        // stored the record from the database
        PreparedStatement statement = null;
        final List<CaseProcessFactAggregate> aggregateRecords = new ArrayList<CaseProcessFactAggregate>();

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection.prepareStatement(sqlSelectGroupByOrgProduct);
            statement.setInt(1, inYear);
            statement.setInt(2, inMonth);
            statement.setDate(3, new Date(inPreviousyear - 1900, inPreviousmonth - 1,
                    1));

            final ResultSet rs = statement.executeQuery();

            CaseProcessFactAggregate caseProcessFactAggregate;

            while (rs.next()) {
                caseProcessFactAggregate = new CaseProcessFactAggregate(rs.getLong(1),
                        rs.getLong(2), inYear, inMonth);
                aggregateRecords.add(caseProcessFactAggregate);
            }

            System.out
            .println("CaseFactProcessTransformImpl:number of agg rows to add is :::"
                    + aggregateRecords.size());
        } catch (final Exception e) {
            System.out.println("CaseFactProcessTransformImpl:readAggregateSet:" + e);
            throw new SQLException("CaseFactProcessTransformImpl:readAggregateSet:"
                    + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
        return aggregateRecords;
    }

    // __________________________________________________________________________
    /**
     * Calculates the average number of days between open and active statuses.
     * 
     * @param inCaseProcessFactAggregate
     *          the aggregate record being calculated
     * @throws SQLException
     *           if a database operation fails
     */

    private void averageDaysOpenToActive(
            final CaseProcessFactAggregate inCaseProcessFactAggregate)
    throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            final String sqlOpenAndActiveStatuses = " select caseid, fromdate.daydate as daysToClearCase, status.statusname"
                + " from dm_factcasehistory fact, "
                + " dm_dimtimeperiod fromdate, dm_dimstatus status"
                + " where "
                + " fact.startdatekey=fromdate.timeperiodkey"
                + " and fact.statuskey=status.statuskey and status.statusname "
                + " in ('Open','Active')"
                + " and fromdate.dmmonth = ? and fromdate.dmyear= ?"
                + " and fact.ORGUNITKEY=?"
                + " and fact.DIMPRODUCTKEY= ?"
                + " order by caseid, fromdate.daydate asc, statusname desc";

            statement = connection.prepareStatement(sqlOpenAndActiveStatuses);

            statement.setInt(1, inCaseProcessFactAggregate.getMonth());
            statement.setInt(2, inCaseProcessFactAggregate.getYear());
            statement.setLong(3, inCaseProcessFactAggregate.getOrgKey());
            statement.setLong(4, inCaseProcessFactAggregate.getProductKey());

            final ResultSet rs = statement.executeQuery();

            long previousCaseID = 0;
            long caseID = 0;
            float daysOpenToActive = 0;
            long totalCases = 0;
            long recordsProcessed = 0;
            Date openDate = null;
            Date activeDate = null;
            Date fromDate;
            String statusName;
            final Map<Long, Long> cases = new HashMap<Long, Long>();

            while (rs.next()) {
                caseID = rs.getLong(1);
                fromDate = rs.getDate(2);
                statusName = rs.getString(3);

                /*
                 * if (openDate == null &&
                 * CaseFactProcessDayTransformImpl.kOpenStatus.equalsIgnoreCase(
                 * statusName)) { openDate = fromDate; }
                 */

                // each time a the case changes get the count on earliest status
                // only
                if (caseID != previousCaseID) {
                    previousCaseID = caseID;
                    activeDate = null;
                    if (CaseFactProcessDayTransformImpl.kOpenStatus
                            .equalsIgnoreCase(statusName)) {
                        openDate = fromDate;
                    }
                } else {
                    if (CaseFactProcessDayTransformImpl.kActiveStatus
                            .equalsIgnoreCase(statusName)) {

                        if (!cases.containsKey(new Long(caseID))) {
                            cases.put(new Long(caseID), new Long(caseID));

                            activeDate = fromDate;

                            if (openDate != null && activeDate != null) {
                                final long miliseconds = activeDate.getTime()
                                - openDate.getTime();
                                final long daysToClearCase = (((((miliseconds / 1000) / 60) / 60) / 24)) + 1;

                                daysOpenToActive += daysToClearCase;
                                System.out.println("caseID:" + previousCaseID
                                        + " daysOpenToActive:" + daysOpenToActive
                                        + " daysToClearCase:" + daysToClearCase);

                                totalCases++;
                                // reset for next case
                                openDate = null;
                                activeDate = null;
                            }
                        }
                    }

                }
                recordsProcessed++;
            }

            if (totalCases > 0) {
                inCaseProcessFactAggregate.setAverageDaysOpenToActive(daysOpenToActive
                        / totalCases);
            }

            System.out.println("averageDaysOpenToActive:" + recordsProcessed
                    + " records read for year=" + inCaseProcessFactAggregate.getYear()
                    + ", month=" + inCaseProcessFactAggregate.getMonth());

            System.out.println(totalCases + " cases processed"
                    + System.getProperty("line.separator") + totalCases
                    + " days between statuses" + System.getProperty("line.separator")
                    + +inCaseProcessFactAggregate.getAverageDaysOpenToActive()
                    + " is the average days to clear a case"
                    + System.getProperty("line.separator"));

        } catch (final Exception e) {
            System.out.println("averageDaysOpenToActive:" + e);
            throw new SQLException("averageDaysOpenToActive:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // __________________________________________________________________________
    /**
     * Calculates the average number of days between open and submitted statuses.
     * 
     * @param inCaseProcessFactAggregate
     *          the aggregate record being calculated
     * @throws SQLException
     *           if a database operation fails
     */

    private void averageDaysOpenToSubmitted(
            final CaseProcessFactAggregate inCaseProcessFactAggregate)
    throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            final String sqlOpenAndActiveStatuses = " select caseid, fromdate.daydate as daysToClearCase, status.statusname"
                + " from dm_factcasehistory fact, "
                + " dm_dimtimeperiod fromdate, dm_dimstatus status"
                + " where "
                + " fact.startdatekey=fromdate.timeperiodkey"
                + " and fact.statuskey=status.statuskey and status.statusname "
                + " in ('Open','Submitted')"
                + " and fromdate.dmmonth = ? and fromdate.dmyear= ?"
                + " and fact.ORGUNITKEY=?"
                + " and fact.DIMPRODUCTKEY= ?"
                + " order by caseid, fromdate.daydate asc, statusname asc";

            statement = connection.prepareStatement(sqlOpenAndActiveStatuses);

            statement.setInt(1, inCaseProcessFactAggregate.getMonth());
            statement.setInt(2, inCaseProcessFactAggregate.getYear());
            statement.setLong(3, inCaseProcessFactAggregate.getOrgKey());
            statement.setLong(4, inCaseProcessFactAggregate.getProductKey());

            final ResultSet rs = statement.executeQuery();

            long previousCaseID = 0;
            long caseID = 0;
            float daysOpenToSubmitted = 0;
            long totalCases = 0;
            long recordsProcessed = 0;
            Date openDate = null;
            Date submittedDate = null;
            Date fromDate;
            String statusName;
            final Map<Long, Long> cases = new HashMap<Long, Long>();

            while (rs.next()) {
                caseID = rs.getLong(1);
                fromDate = rs.getDate(2);
                statusName = rs.getString(3);

                /*
                 * if (openDate == null &&
                 * CaseFactProcessDayTransformImpl.kOpenStatus.equalsIgnoreCase(
                 * statusName)) { openDate = fromDate; }
                 */

                // each time a the case changes get the count on earliest status
                // only
                if (caseID != previousCaseID) {
                    submittedDate = null;
                    previousCaseID = caseID;
                    if (CaseFactProcessDayTransformImpl.kOpenStatus
                            .equalsIgnoreCase(statusName)) {
                        openDate = fromDate;
                    }
                } else {
                    if (CaseFactProcessDayTransformImpl.kSubmittedStatus
                            .equalsIgnoreCase(statusName)) {

                        if (!cases.containsKey(new Long(caseID))) {
                            cases.put(new Long(caseID), new Long(caseID));
                            submittedDate = fromDate;
                            if (openDate != null && submittedDate != null) {
                                final long miliseconds = submittedDate.getTime()
                                - openDate.getTime();
                                final long daysToClearCase = (((((miliseconds / 1000) / 60) / 60) / 24)) + 1;

                                daysOpenToSubmitted += daysToClearCase;
                                totalCases++;
                                // reset for next case
                                openDate = null;
                                submittedDate = null;
                            }
                        }
                    }

                }

                recordsProcessed++;
            }

            if (totalCases > 0) {
                inCaseProcessFactAggregate
                .setAverageDaysOpenToSubmitted(daysOpenToSubmitted / totalCases);
            }

            System.out.println("averageDaysOpenToSubmitted:" + recordsProcessed
                    + " records read for year=" + inCaseProcessFactAggregate.getYear()
                    + ", month=" + inCaseProcessFactAggregate.getMonth());

            System.out.println(totalCases + " cases processed"
                    + System.getProperty("line.separator") + totalCases
                    + " days between statuses" + System.getProperty("line.separator")
                    + +inCaseProcessFactAggregate.getAverageDaysOpenToSubmitt()
                    + " is the average days to clear a case"
                    + System.getProperty("line.separator"));

        } catch (final Exception e) {
            System.out.println("averageDaysOpenToSubmitted:" + e);
            throw new SQLException("averageDaysOpenToSubmitted:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // __________________________________________________________________________
    /**
     * Calculates the average number of days between registered and active
     * statuses.
     * 
     * @param inCaseProcessFactAggregate
     *          the aggregate record being calculated
     * @throws SQLException
     *           if a database operation fails
     */

    private void averageDaysRegisteredToActive(
            final CaseProcessFactAggregate inCaseProcessFactAggregate)
    throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            final String sqlOpenAndActiveStatuses = " select caseid, fromdate.daydate as daysToClearCase, status.statusname"
                + " from dm_factcasehistory fact, "
                + " dm_dimtimeperiod fromdate, dm_dimstatus status"
                + " where "
                + " fact.startdatekey=fromdate.timeperiodkey"
                + " and fact.statuskey=status.statuskey and status.statusname "
                + " in ('Active','Registered')"
                + " and fromdate.dmmonth = ? and fromdate.dmyear= ?"
                + " and fact.ORGUNITKEY=?"
                + " and fact.DIMPRODUCTKEY= ?"
                + " order by caseid, fromdate.daydate asc, statusname desc";

            statement = connection.prepareStatement(sqlOpenAndActiveStatuses);

            statement.setInt(1, inCaseProcessFactAggregate.getMonth());
            statement.setInt(2, inCaseProcessFactAggregate.getYear());
            statement.setLong(3, inCaseProcessFactAggregate.getOrgKey());
            statement.setLong(4, inCaseProcessFactAggregate.getProductKey());

            final ResultSet rs = statement.executeQuery();

            long previousCaseID = 0;
            long caseID = 0;
            float daysRegisteredToActive = 0;
            long totalCases = 0;
            long recordsProcessed = 0;
            Date activeDate = null;
            Date registerDate = null;
            Date fromDate;
            String statusName;
            final Map<Long, Long> cases = new HashMap<Long, Long>();

            while (rs.next()) {
                caseID = rs.getLong(1);
                fromDate = rs.getDate(2);
                statusName = rs.getString(3);

                /*
                 * if (registerDate == null &&
                 * CaseFactProcessDayTransformImpl.kRegisteredStatus.equalsIgnoreCase(
                 * statusName)) { registerDate = fromDate; }
                 */
                // each time a the case changes get the count on earliest status
                // only
                if (caseID != previousCaseID) {
                    previousCaseID = caseID;
                    activeDate = null;
                    if (CaseFactProcessDayTransformImpl.kRegisteredStatus
                            .equalsIgnoreCase(statusName)) {
                        registerDate = fromDate;
                    }
                } else {
                    if (CaseFactProcessDayTransformImpl.kActiveStatus
                            .equalsIgnoreCase(statusName)) {

                        if (!cases.containsKey(new Long(caseID))) {
                            cases.put(new Long(caseID), new Long(caseID));

                            activeDate = fromDate;
                            if (registerDate != null && activeDate != null) {
                                final long miliseconds = activeDate.getTime()
                                - registerDate.getTime();
                                final long daysToClearCase = (((((miliseconds / 1000) / 60) / 60) / 24)) + 1;

                                daysRegisteredToActive += daysToClearCase;
                                totalCases++;
                                // reset for next case
                                registerDate = null;
                                activeDate = null;
                            }
                        }
                    }

                }
                recordsProcessed++;
            }

            if (totalCases > 0) {
                inCaseProcessFactAggregate
                .setAverageDaysRegisteredToActive(daysRegisteredToActive
                        / totalCases);
            }

            System.out.println("averageDaysRegisteredToActive:" + recordsProcessed
                    + " records read for year=" + inCaseProcessFactAggregate.getYear()
                    + ", month=" + inCaseProcessFactAggregate.getMonth());
            System.out.println(totalCases + " cases processed"
                    + System.getProperty("line.separator") + totalCases
                    + " days between statuses" + System.getProperty("line.separator")
                    + inCaseProcessFactAggregate.getAverageDaysRegisteredToActive()
                    + " is the average days to clear a case"
                    + System.getProperty("line.separator"));

        } catch (final Exception e) {
            System.out.println("averageDaysRegisteredToActive:" + e);
            throw new SQLException("averageDaysRegisteredToActive:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // __________________________________________________________________________
    /**
     * Calculates the average number of days between received and registered
     * statuses.
     * 
     * @param inCaseProcessFactAggregate
     *          the aggregate record being calculated
     * @throws SQLException
     *           if a database operation fails
     */

    private void averageDaysReceivedToRegistered(
            final CaseProcessFactAggregate inCaseProcessFactAggregate)
    throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            final String sqlOpenAndActiveStatuses = " select caseid, fromdate.daydate as daysToClearCase, status.statusname"
                + " from dm_factcasehistory fact, "
                + " dm_dimtimeperiod fromdate, dm_dimstatus status"
                + " where "
                + " fact.startdatekey=fromdate.timeperiodkey"
                + " and fact.statuskey=status.statuskey and status.statusname "
                + " in ('Received','Registered')"
                + " and fromdate.dmmonth = ? and fromdate.dmyear= ?"
                + " and fact.ORGUNITKEY=?"
                + " and fact.DIMPRODUCTKEY= ?"
                + " order by caseid, fromdate.daydate asc, statusname asc";

            statement = connection.prepareStatement(sqlOpenAndActiveStatuses);

            statement.setInt(1, inCaseProcessFactAggregate.getMonth());
            statement.setInt(2, inCaseProcessFactAggregate.getYear());
            statement.setLong(3, inCaseProcessFactAggregate.getOrgKey());
            statement.setLong(4, inCaseProcessFactAggregate.getProductKey());

            final ResultSet rs = statement.executeQuery();

            long previousCaseID = 0;
            long caseID = 0;
            float daysReceivedToRegistered = 0;
            long totalCases = 0;
            long recordsProcessed = 0;
            Date receivedDate = null;
            Date registeredDate = null;
            Date fromDate;
            String statusName;
            final Map<Long, Long> cases = new HashMap<Long, Long>();

            while (rs.next()) {
                caseID = rs.getLong(1);
                fromDate = rs.getDate(2);
                statusName = rs.getString(3);

                /*
                 * if (receivedDate == null &&
                 * CaseFactProcessDayTransformImpl.kReceivedStatus.equalsIgnoreCase(
                 * statusName)) { receivedDate = fromDate; }
                 */

                // each time a the case changes get the count on earliest status
                // only
                if (caseID != previousCaseID) {
                    registeredDate = null;
                    previousCaseID = caseID;
                    if (CaseFactProcessDayTransformImpl.kReceivedStatus
                            .equalsIgnoreCase(statusName)) {
                        receivedDate = fromDate;
                    }
                } else {
                    if (CaseFactProcessDayTransformImpl.kRegisteredStatus
                            .equalsIgnoreCase(statusName)) {

                        if (!cases.containsKey(new Long(caseID))) {
                            cases.put(new Long(caseID), new Long(caseID));

                            registeredDate = fromDate;
                            if (receivedDate != null && registeredDate != null) {
                                final long miliseconds = registeredDate.getTime()
                                - receivedDate.getTime();
                                final long daysToClearCase = (((((miliseconds / 1000) / 60) / 60) / 24)) + 1;

                                daysReceivedToRegistered += daysToClearCase;
                                totalCases++;
                                // reset for next case
                                receivedDate = null;
                                registeredDate = null;
                            }
                        }
                    }

                }
                recordsProcessed++;
            }

            if (totalCases > 0) {
                inCaseProcessFactAggregate
                .setAverageDaysReceivedToRegistered(daysReceivedToRegistered
                        / totalCases);
            }

            System.out.println("averageDaysReceivedToRegistered:" + recordsProcessed
                    + " records read for year=" + inCaseProcessFactAggregate.getYear()
                    + ", month=" + inCaseProcessFactAggregate.getMonth());
            System.out.println(totalCases + " cases processed"
                    + System.getProperty("line.separator") + totalCases
                    + " days between statuses" + System.getProperty("line.separator")
                    + inCaseProcessFactAggregate.getAverageDaysReceivedToRegistered()
                    + " is the average days to clear a case"
                    + System.getProperty("line.separator"));

        } catch (final Exception e) {
            System.out.println("averageDaysReceivedToRegistered:" + e);
            throw new SQLException("averageDaysReceivedToRegistered:"
                    + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // __________________________________________________________________________
    /**
     * Sets the number of cases on hand prior to a given date.
     * 
     * @param inCaseProcessFactAggregate
     *          the aggregate record being calculated
     * @throws SQLException
     *           if a database operation fails
     */

    private void averageDaysSubbmittedToApproved(
            final CaseProcessFactAggregate inCaseProcessFactAggregate)
    throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            final String sqlOpenAndActiveStatuses = " select caseid, fromdate.daydate as daysToClearCase, status.statusname"
                + " from dm_factcasehistory fact, "
                + " dm_dimtimeperiod fromdate, dm_dimstatus status"
                + " where "
                + " fact.startdatekey=fromdate.timeperiodkey"
                + " and fact.statuskey=status.statuskey and status.statusname "
                + " in ('Submitted','Approved')"
                + " and fromdate.dmmonth = ? and fromdate.dmyear= ?"
                + " and fact.ORGUNITKEY=?"
                + " and fact.DIMPRODUCTKEY= ?"
                + " order by caseid, fromdate.daydate asc, statusname desc";

            statement = connection.prepareStatement(sqlOpenAndActiveStatuses);

            statement.setInt(1, inCaseProcessFactAggregate.getMonth());
            statement.setInt(2, inCaseProcessFactAggregate.getYear());
            statement.setLong(3, inCaseProcessFactAggregate.getOrgKey());
            statement.setLong(4, inCaseProcessFactAggregate.getProductKey());

            final ResultSet rs = statement.executeQuery();

            long previousCaseID = 0;
            long caseID = 0;
            float daysOpenToApproved = 0;
            long totalCases = 0;
            long recordsProcessed = 0;
            Date submittedDate = null;
            Date approvedDate = null;
            Date fromDate;
            String statusName;
            final Map<Long, Long> cases = new HashMap<Long, Long>();

            while (rs.next()) {
                caseID = rs.getLong(1);
                fromDate = rs.getDate(2);
                statusName = rs.getString(3);

                /*
                 * if (submittedDate == null &&
                 * CaseFactProcessDayTransformImpl.kSubmittedStatus.equalsIgnoreCase(
                 * statusName)) { submittedDate = fromDate; }
                 */

                // each time a the case changes get the count on earliest status
                // only
                if (caseID != previousCaseID) {
                    approvedDate = null;
                    previousCaseID = caseID;
                    if (CaseFactProcessDayTransformImpl.kSubmittedStatus
                            .equalsIgnoreCase(statusName)) {
                        submittedDate = fromDate;
                    }
                } else {
                    if (CaseFactProcessDayTransformImpl.kApprovedStatus
                            .equalsIgnoreCase(statusName)) {

                        if (!cases.containsKey(new Long(caseID))) {
                            cases.put(new Long(caseID), new Long(caseID));

                            approvedDate = fromDate;
                            if (submittedDate != null && approvedDate != null) {
                                final long miliseconds = approvedDate.getTime()
                                - submittedDate.getTime();
                                final long daysToClearCase = (((((miliseconds / 1000) / 60) / 60) / 24)) + 1;

                                daysOpenToApproved += daysToClearCase;
                                totalCases++;
                                // reset for next case
                                submittedDate = null;
                                approvedDate = null;
                            }
                        }
                    }

                }
                recordsProcessed++;
            }

            if (totalCases > 0) {
                inCaseProcessFactAggregate
                .setAverageDaysSubmittedToApproved(daysOpenToApproved / totalCases);
            }

            System.out.println("averageDaysOpenToApproved:" + recordsProcessed
                    + " records read for year=" + inCaseProcessFactAggregate.getYear()
                    + ", month=" + inCaseProcessFactAggregate.getMonth());

            System.out.println(totalCases + " cases processed"
                    + System.getProperty("line.separator") + totalCases
                    + " days between statuses" + System.getProperty("line.separator")
                    + inCaseProcessFactAggregate.getAverageDaysSubmittedToApproved()
                    + " is the average days to clear a case"
                    + System.getProperty("line.separator"));

        } catch (final Exception e) {
            System.out.println("averageDaysOpenToApproved:" + e);
            throw new SQLException("averageDaysOpenToApproved:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // __________________________________________________________________________
    /**
     * Calculates the average number of day to clear a case.
     * 
     * @param inCaseProcessFactAggregate
     *          the aggregate record being calculated
     * @throws SQLException
     *           if a database operation fails
     */

    private void averageDaysToClearCases(
            final CaseProcessFactAggregate inCaseProcessFactAggregate)
    throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            final String sqlClearedStatuses = " select caseid, fromdate.daydate as daysToClearCase, status.statusname"
                + " from dm_factcasehistory fact, "
                + " dm_dimtimeperiod fromdate, dm_dimstatus status"
                + " where "
                + " fact.startdatekey=fromdate.timeperiodkey"
                + " and fact.statuskey=status.statuskey and status.statusname "
                + " in ('Approved','Closed','Pending Closure', 'Registered')"
                + " and fromdate.dmmonth = ? and fromdate.dmyear= ?"
                + " and fact.ORGUNITKEY=?"
                + " and fact.DIMPRODUCTKEY= ?"
                + " order by caseid, statusname desc , fromdate.daydate asc";

            statement = connection.prepareStatement(sqlClearedStatuses);

            statement.setInt(1, inCaseProcessFactAggregate.getMonth());
            statement.setInt(2, inCaseProcessFactAggregate.getYear());
            statement.setLong(3, inCaseProcessFactAggregate.getOrgKey());
            statement.setLong(4, inCaseProcessFactAggregate.getProductKey());

            final ResultSet rs = statement.executeQuery();

            long previousCaseID = 0;
            long caseID = 0;
            float daysToClearCases = 0;
            long totalCases = 0;
            long recordsProcessed = 0;
            Date registeredDate = null;
            Date clearedDate = null;
            Date fromDate;
            String statusName;

            while (rs.next()) {
                caseID = rs.getLong(1);
                fromDate = rs.getDate(2);
                statusName = rs.getString(3);

                /*
                 * if (registeredDate == null &&
                 * CaseFactProcessDayTransformImpl.kRegisteredStatus.equalsIgnoreCase(
                 * statusName) ) { registeredDate = fromDate; }
                 */

                // each time a the case changes get the count on earliest status
                // only
                if (caseID != previousCaseID) {
                    if (registeredDate != null && clearedDate != null) {
                        final long miliseconds = clearedDate.getTime()
                        - registeredDate.getTime();
                        final long daysToClearCase = (((((miliseconds / 1000) / 60) / 60) / 24));

                        daysToClearCases += daysToClearCase + 1;
                        totalCases++;
                        // reset for next case
                        // registeredDate = null;
                        clearedDate = null;
                        System.out.println(previousCaseID
                                + " is a cleared caseid, days to clear case is "
                                + daysToClearCase
                                + " Total days to clear case is "
                                + daysToClearCases
                                + " ret "
                                + CaseFactProcessDayTransformImpl.kRegisteredStatus
                                .equalsIgnoreCase(statusName) + " status  " + statusName);
                    }
                    if (CaseFactProcessDayTransformImpl.kRegisteredStatus
                            .equalsIgnoreCase(statusName)) {
                        registeredDate = fromDate;
                    }
                    previousCaseID = caseID;
                } else {
                    if (!CaseFactProcessDayTransformImpl.kRegisteredStatus
                            .equalsIgnoreCase(statusName)) {
                        clearedDate = fromDate;
                    }
                }
                recordsProcessed++;

            }

            if (totalCases > 0) {
                inCaseProcessFactAggregate.setAverageDaysToClearCase(daysToClearCases
                        / totalCases);
            }

            System.out.println("averageDaysToClearCases:" + recordsProcessed
                    + " records read for year=" + inCaseProcessFactAggregate.getYear()
                    + ", month=" + inCaseProcessFactAggregate.getMonth());

            System.out.println(totalCases + " cases processed"
                    + System.getProperty("line.separator") + +daysToClearCases
                    + " days between statuses" + System.getProperty("line.separator")
                    + +inCaseProcessFactAggregate.getAverageDaysToClearCase()
                    + " is the average days to clear a case"
                    + System.getProperty("line.separator"));

        } catch (final Exception e) {
            System.out.println("averageDaysToClearCases:readCasesOnHand:" + e);
            throw new SQLException("averageDaysToClearCases:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // __________________________________________________________________________
    /**
     * Sets the number of cases on hand prior to a given date.
     * 
     * @param inCaseProcessFactAggregate
     *          the aggregate record being calculated
     * @param inEndDay
     *          cases on hand prior to this date
     * @throws SQLException
     *           if a database operation fails
     */

    private void readCasesOnHand(
            final CaseProcessFactAggregate inCaseProcessFactAggregate,
            final Date inEndDay) throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection.prepareStatement(sqlSelectByOrgunitProductDay);

            statement.setLong(1, inCaseProcessFactAggregate.getOrgKey());
            statement.setLong(2, inCaseProcessFactAggregate.getProductKey());
            statement.setDate(3, inEndDay);

            final ResultSet rs = statement.executeQuery();
            int count = 0;
            String status;

            while (rs.next()) {
                status = rs.getString(1);
                count = rs.getInt(2);
                if (kCleared.equalsIgnoreCase(status)) {
                    inCaseProcessFactAggregate.setCleared(count);
                } else if (kOnhand.equalsIgnoreCase(status)) {
                    inCaseProcessFactAggregate.setOnHandStartOfMonth(count);
                } else {
                    System.out.println("Warning:readCasesOnHand:"
                            + "unexpected reporting status found " + status);
                }
            }

            System.out.println("readCasesOnHand:" + inCaseProcessFactAggregate);

        } catch (final Exception e) {
            System.out.println("readCasesOnHand:readCasesOnHand:" + e.getMessage());
            throw new SQLException("readCasesOnHand:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // __________________________________________________________________________
    /**
     * Read a count of the cases cleared during a month.
     * 
     * @param inCaseProcessFactAggregate
     *          the aggregate record being calculated
     * @throws SQLException
     *           if a database operation fails
     */

    private void readClearedCases(
            final CaseProcessFactAggregate inCaseProcessFactAggregate)
    throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection
            .prepareStatement(sqlSelectClearedByOrgunitProductYearMonth);

            statement.setLong(1, inCaseProcessFactAggregate.getOrgKey());
            statement.setLong(2, inCaseProcessFactAggregate.getProductKey());
            statement.setInt(3, inCaseProcessFactAggregate.getYear());
            statement.setInt(4, inCaseProcessFactAggregate.getMonth());

            final ResultSet rs = statement.executeQuery();
            short recordsFound = 0;
            int count = 0;
            String status;

            while (rs.next()) {
                recordsFound++;
                status = rs.getString(1);
                count = rs.getInt(2);
                if (kCleared.equalsIgnoreCase(status)) {
                    inCaseProcessFactAggregate.setCleared(count);
                }
            }

            System.out.println("readClearedCases:" + inCaseProcessFactAggregate);

        } catch (final Exception e) {
            System.out.println("readClearedCases:" + e);
            throw new SQLException("readClearedCases:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // __________________________________________________________________________
    /**
     * Read a count of the cases received during a month.
     * 
     * @param inCaseProcessFactAggregate
     *          the aggregate record being calculated
     * @throws SQLException
     *           if a database operation fails
     */

    private void readReceivedCases(
            final CaseProcessFactAggregate inCaseProcessFactAggregate)
    throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection
            .prepareStatement(sqlSelectReceivedByOrgunitProductYearMonth);

            statement.setLong(1, inCaseProcessFactAggregate.getOrgKey());
            statement.setLong(2, inCaseProcessFactAggregate.getProductKey());
            statement.setInt(3, inCaseProcessFactAggregate.getYear());
            statement.setInt(4, inCaseProcessFactAggregate.getMonth());

            final ResultSet rs = statement.executeQuery();
            short recordsFound = 0;
            int count = 0;

            while (rs.next()) {
                recordsFound++;
                count = rs.getInt(1);
                inCaseProcessFactAggregate.setReceived(count);
            }
            if (recordsFound == 0) {
                throw new Exception("Expected fact records found for "
                        + inCaseProcessFactAggregate.toString());
            }
            System.out.println("readReceivedCases:" + inCaseProcessFactAggregate);

        } catch (final Exception e) {
            System.out.println("readReceivedCases:" + e);
            throw new SQLException("readReceivedCases:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // ___________________________________________________________________________
    /**
     * Calculates the cases on hand at the end of a month (Cases on hand at start
     * of month + received cases) - cleared cases.
     * 
     * @param inAggregate
     *          the aggregate record being calculated
     */

    public void onHandAtEndOfMonth(final CaseProcessFactAggregate inAggregate) {

        inAggregate
        .setOnHandEndOfMonth((inAggregate.getOnHandStartOfMonth() + inAggregate
                .getReceived()) - inAggregate.getCleared());
    }

    // ___________________________________________________________________________
    /**
     * Calculates the cases on hand at the end of a month (Cases on hand at start
     * of month + received cases) - cleared cases.
     * 
     * @param inAggregate
     *          the aggregate record being calculated
     * @throws SQLException
     *           if a database operation fails
     */

    public void readCasesOnHandAtStartOfMonth(
            final CaseProcessFactAggregate inAggregate) throws SQLException {
        System.out.println("=================year=" + inAggregate.year + "month="
                + inAggregate.month);

        // get the last month record from the aggregate table
        // the on hand at the end of last month is the on hand figure
        // for the start of the next month
        int previousYear = inAggregate.getYear();
        short previousMonth = 0;

        if (1 == inAggregate.getMonth()) {
            previousMonth = 12;
            previousYear--;
        } else {
            previousMonth = (short) (inAggregate.getMonth() - 1);
        }

        final CaseProcessFactAggregate previousMonthSearchKey = new CaseProcessFactAggregate(
                inAggregate.getOrgKey(), inAggregate.getProductKey(), previousYear,
                previousMonth);

        final CaseProcessFactAggregate previousMonthAggregate = readAggregateRecord(previousMonthSearchKey);

        // if we have no previous total, calculate the total cases on hand
        // at the start of the month
        if (previousMonthAggregate == null) {
            final Calendar cal = Calendar.getInstance();

            cal.set(inAggregate.getYear(), inAggregate.getMonth() - 1, 1);

            // read count of on hand at end of previous month
            readCasesOnHand(previousMonthSearchKey, new java.sql.Date(cal.getTime()
                    .getTime()));

            // set on hand at start of current month to on hand at end
            // of previous month
            inAggregate.setOnHandStartOfMonth(previousMonthSearchKey
                    .getOnHandStartOfMonth());

        } else {
            inAggregate.setOnHandStartOfMonth(previousMonthAggregate
                    .getOnHandStartOfMonth());
        }
    }

    // ___________________________________________________________________________
    /**
     * Returns a aggregate record keyed by product, organization unit, month and
     * year.
     * 
     * @param inAggregateRecord
     *          the key of the record to search for
     * @return CaseProcessFactAggregate null if no record exists or valid object
     * @throws SQLException
     *           if a database operation fails
     */

    @SuppressWarnings("deprecation")
    private CaseProcessFactAggregate readAggregateRecord(
            final CaseProcessFactAggregate inAggregateRecord) throws SQLException {
        // stored the record from the database
        PreparedStatement statement = null;
        CaseProcessFactAggregate caseProcessFactAggregate = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection
            .prepareStatement(sqlSelectAggregateByOrgProductYearMonth);

            statement.setLong(1, inAggregateRecord.getOrgKey());
            statement.setLong(2, inAggregateRecord.getProductKey());
            statement.setDate(3, new Date(inAggregateRecord.getYear() - 1900,
                    inAggregateRecord.getMonth() - 1, 1));

            final ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                caseProcessFactAggregate = new CaseProcessFactAggregate(
                        inAggregateRecord);
                caseProcessFactAggregate.setOnHandStartOfMonth(rs.getInt(1));
            }

        } catch (final Exception e) {
            System.out.println("CaseFactProcessTransformImpl:readAggregateRecord:"
                    + e);
            throw new SQLException(
                    "CaseFactProcessTransformImpl:readAggregateRecord:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
        return caseProcessFactAggregate;
    }

    // __________________________________________________________________________
    /**
     * Sets the last ETL date time.
     * 
     * @param inAggregate
     *          record data to insert
     * @param statement
     *          the batched statement
     * @throws SQLException
     *           if database operation failed
     */
    @SuppressWarnings("deprecation")
    public void insert(final CaseProcessFactAggregate inAggregate,
            final PreparedStatement statement) throws SQLException {

        try {
            // set organization unit key
            statement.setLong(1, inAggregate.getOrgKey());

            // set day date in the sub select to insert the time period key
            statement
            .setDate(2,
                    new Date(inAggregate.getYear() - 1900,
                            inAggregate.getMonth() - 1, 1));

            // set product key
            statement.setLong(3, inAggregate.getProductKey());

            // set month
            // statement.setInt(4, inAggregate.getMonth());

            // set cases on hand at start of month
            statement.setInt(4, inAggregate.getOnHandStartOfMonth());

            // set cases on hand at end of month
            statement.setInt(5, inAggregate.getOnHandEndOfMonth());

            // set cases cleared
            statement.setFloat(6, inAggregate.getCleared());

            // set cases received
            statement.setFloat(7, inAggregate.getReceived());

            // set avg days cleared
            statement.setFloat(8, inAggregate.getAverageDaysToClearCase());
            // set avg days open to submitted
            statement.setFloat(9, inAggregate.getAverageDaysOpenToSubmitt());
            // set avg days submitted to approved
            statement.setFloat(10, inAggregate.getAverageDaysSubmittedToApproved());
            // set avg days open to active
            statement.setFloat(11, inAggregate.getAverageDaysOpenToActive());
            // set avg days received to registered
            statement.setFloat(12, inAggregate.getAverageDaysReceivedToRegistered());

            // set avg days registered to active
            statement.setFloat(13, inAggregate.getAverageDaysRegisteredToActive());

            statement.addBatch();

        } catch (final Exception e) {
            System.out.println("CaseFactProcessTransformImpl:insert: " + e);
            throw new SQLException("CaseFactProcessTransformImpl:insert: "
                    + e.getMessage());
        }

    }

    /**
     * This module represents a case month aggregate record.
     */
    class CaseProcessFactAggregate {

        /**
         * the product key.
         */
        private final long productKey;

        /**
         * the organization unit key.
         */
        private final long orgKey;

        /**
         * the year.
         */
        private final int year;

        /**
         * the month.
         */
        private final short month;

        /**
         * the number of received cases.
         */
        private int received;

        /**
         * the number of cleared cases.
         */
        private int cleared;

        /**
         * the number of cases on had at start of month.
         */
        private int onHandStartOfMonth;

        /**
         * the number of cases on had at end of month.
         */
        private int onHandEndOfMonth;

        /**
         * the average number of days to clear a case, from date on status is used
         * to decide which month the status is counted in.
         */
        private float averageDaysToClearCase;

        /**
         * the average number of days from open status to active status.
         */
        private float averageDaysOpenToActive;

        /**
         * the average number of days from open status to submitted status.
         */
        private float averageDaysOpenToSubmitted;

        /**
         * the average number of days from open status to approved status.
         */
        private float averageDaysOpenToApproved;

        /**
         * the average number of days from open received to registered status.
         */
        private float averageDaysReceivedToRegistered;

        /**
         * the average number of days from registered to active status .
         */
        private float averageDaysRegisteredToActive;

        /**
         * the average number of days from submitted to active status .
         */
        private float averageDaysSubmittedToApproved;

        /**
         * Creates a new empty aggregate record.
         * 
         * @param inOrgKey
         *          the organization unit key
         * @param inProductKey
         *          the product key
         * @param inYear
         *          the year
         * @param inMonth
         *          the month
         */

        CaseProcessFactAggregate(
                final long inOrgKey,
                final long inProductKey,
                final int inYear,
                final short inMonth) {

            productKey = inProductKey;
            orgKey = inOrgKey;
            year = inYear;
            month = inMonth;
        }

        /**
         * Creates a new empty aggregate record.
         * 
         * @param inAggregate
         *          empty aggregate record
         */
        CaseProcessFactAggregate(final CaseProcessFactAggregate inAggregate) {

            productKey = inAggregate.getProductKey();
            orgKey = inAggregate.getOrgKey();
            year = inAggregate.getYear();
            month = inAggregate.getMonth();
        }

        /**
         * @return Returns the cleared.
         */
        @Override
        public String toString() {
            return "<caseprocessfact " + "productKey=" + productKey + " orgKey="
            + orgKey + " year=" + year + " month=" + month + " received="
            + received + " cleared=" + cleared + " onHandStartOfMonth="
            + onHandStartOfMonth + " onHandEndOfMonth=" + onHandEndOfMonth
            + " />";
        }

        /**
         * @return Returns the cleared.
         */
        public int getCleared() {
            return cleared;
        }

        /**
         * Sets the number of cleared cases.
         * 
         * @param inCleared
         *          number of cleared cases.
         */
        public void setCleared(final int inCleared) {
            this.cleared = inCleared;
        }

        /**
         * @return Returns the received.
         */
        public int getReceived() {
            return received;
        }

        /**
         * @param received
         *          number of cleared cases.
         */
        public void setReceived(final int received) {
            this.received = received;
        }

        /**
         * @return Returns the org key.
         */
        public long getOrgKey() {
            return orgKey;
        }

        /**
         * @return Returns the productKey.
         */
        public long getProductKey() {
            return productKey;
        }

        /**
         * @return Returns the timeKeyMonthLevel.
         */
        public int getYear() {
            return year;
        }

        /**
         * @return Returns the timeKeyMonthLevel.
         */
        public short getMonth() {
            return month;
        }

        /**
         * @param onHandEndOfMonth
         *          The onHandEndOfMonth to set.
         */
        public void setOnHandEndOfMonth(final int onHandEndOfMonth) {
            this.onHandEndOfMonth = onHandEndOfMonth;
        }

        /**
         * @param onHandStartOfMonth
         *          The onHandStartOfMonth to set.
         */
        public void setOnHandStartOfMonth(final int onHandStartOfMonth) {
            this.onHandStartOfMonth = onHandStartOfMonth;
        }

        /**
         * @return Returns the onHandEndOfMonth.
         */
        public int getOnHandEndOfMonth() {
            return onHandEndOfMonth;
        }

        /**
         * @return Returns the onHandStartOfMonth.
         */
        public int getOnHandStartOfMonth() {
            return onHandStartOfMonth;
        }

        /**
         * @return Returns the avg days cleared.
         */
        public float getAverageDaysToClearCase() {
            return averageDaysToClearCase;
        }

        /**
         * sets the avg days cleared.
         * 
         * @param inAverageDaysToClearCase
         *          average days to clear cases
         */
        public void setAverageDaysToClearCase(final float inAverageDaysToClearCase) {
            averageDaysToClearCase = inAverageDaysToClearCase;
        }

        /**
         * Returns the average days to clear a case.
         * 
         * @return Returns the average days to clear a case.
         */
        public float getAverageDaysOpenToSubmitt() {
            return averageDaysOpenToSubmitted;
        }

        /**
         * Returns the average days from open to submitted status.
         * 
         * @param inAverageDaysOpenToSubmitted
         *          the avg days from open to active status
         */
        public void setAverageDaysOpenToSubmitted(
                final float inAverageDaysOpenToSubmitted) {
            averageDaysOpenToSubmitted = inAverageDaysOpenToSubmitted;
        }

        /**
         * Returns the average days from open to active status.
         * 
         * @return Returns the average days to clear a case.
         */
        public float getAverageDaysOpenToActive() {
            return averageDaysOpenToActive;
        }

        /**
         * Returns the avg days from open to active status.
         * 
         * @param inAverageDaysOpenToActive
         *          the avg days from open to active status
         */
        public void setAverageDaysOpenToActive(final float inAverageDaysOpenToActive) {
            averageDaysOpenToActive = inAverageDaysOpenToActive;
        }

        /**
         * Returns the average days from open to approved status.
         * 
         * @return Returns the average days to clear a case.
         */
        public float getAverageDaysOpenToApproved() {
            return averageDaysOpenToApproved;
        }

        /**
         * Returns the average days from open to approved status.
         * 
         * @param inAverageDaysOpenToApproved
         *          the average days from open to approved status
         */
        public void setAverageDaysOpenToApproved(
                final float inAverageDaysOpenToApproved) {
            averageDaysOpenToApproved = inAverageDaysOpenToApproved;
        }

        /**
         * Returns the average days from received to registered status.
         * 
         * @return Returns the average days from received to reg status.
         */
        public float getAverageDaysReceivedToRegistered() {
            return averageDaysReceivedToRegistered;
        }

        /**
         * Returns the average days from received to registered status.
         * 
         * @param inAverageDaysReceivedToRegistered
         *          the average days from open to approved status
         */
        public void setAverageDaysReceivedToRegistered(
                final float inAverageDaysReceivedToRegistered) {
            averageDaysReceivedToRegistered = inAverageDaysReceivedToRegistered;
        }

        /**
         * Returns the average days from received to active status.
         * 
         * @return Returns the average days from registered to active status.
         */
        public float getAverageDaysRegisteredToActive() {
            return averageDaysRegisteredToActive;
        }

        /**
         * Returns the average days from received to registered status.
         * 
         * @param inAverageDaysRegisteredToActive
         *          the average days from registered to active status
         */
        public void setAverageDaysRegisteredToActive(
                final float inAverageDaysRegisteredToActive) {
            averageDaysRegisteredToActive = inAverageDaysRegisteredToActive;
        }

        /**
         * Returns the average days from received to approved status.
         * 
         * @return Returns the average days from registered to active status.
         */
        public float getAverageDaysSubmittedToApproved() {
            return averageDaysSubmittedToApproved;
        }

        /**
         * Returns the average days from received to registered status.
         * 
         * @param inAverageDaysSubmittedToApproved
         *          the average days from registered to active status
         */
        public void setAverageDaysSubmittedToApproved(
                final float inAverageDaysSubmittedToApproved) {
            averageDaysSubmittedToApproved = inAverageDaysSubmittedToApproved;
        }
    }
}
