/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005-2011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.central.base;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.StringTokenizer;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.DateFormatter;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.fact.PostProcessFactory;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;
import curam.util.reporting.transformations.central.dbclient.CustomTransforms;
import curam.util.reporting.transformations.central.intf.StateNameLookup;

/**
 * This module provides functionality to flatten address details, and perform
 * state lookup.
 * 
 * 
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
abstract class AddressTransformImpl implements StateNameLookup, ETLPostProcess {
    /**
     * SQL update statement for the central address table.
     */
    private final String kSQLUpdateAddresses =
        "insert into  S_ADDRESSDETAIL (ADDRESSID,"
        + " ADDRESS1,ADDRESS2,ADDRESS3, CITY,STATE, COUNTY,LASTWRITTEN)"
        + "  values (?, ?,?,?, ?, ?, ?, ?)";

    /**
     * SQL statement to retrieve state key.
     */
    private final String readStateKey =
        "select dwstateid from dw_state where statename=?";

    /**
     * reads source address data.
     */
    private String kSQLSelectSourceData;



    /**
     * logging control
     */
    private final boolean verbose = true;

    @SuppressWarnings ("unused")
    private final int verbosePingThreshold = 20000;

    // ___________________________________________________________________________
    /**
     * Construct a new object.
     * 
     * @throws SQLException
     */
    public AddressTransformImpl() throws SQLException {
    }

    // ___________________________________________________________________________
    /**
     * Creates an object to parse address data strings.
     * 
     * @param inSourceTable
     *          the source table name
     * @throws SQLException
     *           if database error occurs
     */
    public AddressTransformImpl(final String inSourceTable) throws SQLException {
        final TargetDataBaseType targetDataBaseType = TransactionFactory
        .getTargetDatabaseType(DataWarehouseConstants.kDefaultDatabase);
        // SQL to read data from the source table
        if (targetDataBaseType.isORACLE()) {
            kSQLSelectSourceData =
                "SELECT T1.addressid, T1.addressdata, T1.lastwritten from "
                + inSourceTable + " T1";
        } else if (targetDataBaseType.isDB2()) {
            kSQLSelectSourceData =
                "SELECT T1.addressid, T1.addressdata, T1.lastwritten from "
                + inSourceTable + " T1";
        }
    }

    // ___________________________________________________________________________
    /**
     * Update address records with post code, ZIP, country and address line data.
     * 
     * @param inTargetTableName
     *          table name where source data resides
     * @exception SQLException
     *              if a database operation fails
     */
    public void executePostProcess(final String inTargetTableName)
    throws SQLException {
        // stored success of SQL statements
        boolean failed = false;
        // the database transaction
        Transaction transaction = null;
        Date start = null;
        Date end = null;
        try {
            // start a transaction
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            start = new Date(System.currentTimeMillis());
            if (verbose) {
                System.out.println("AddressTransformImpl:execute:start:"
                        + DateFormatter.getDate(start));
            }
            // process the data
            readSourceData(kSQLSelectSourceData);
            end = new Date(System.currentTimeMillis());
            System.out.println("AddressTransformImpl:execute:end:"
                    + DateFormatter.getDate(end));
            // Get time from each, and subtract.
            long diff = 0;
            if (start != null && end != null) {
                diff = end.getTime() - start.getTime();
            }
            if (verbose) {
                System.out.println("AddressTransformImpl:execute duration  "
                        + (diff / (1000)) + " seconds");
            }
            // update the control table
            PostProcessFactory.newInstance().executePostProcess(inTargetTableName);
        } catch (final Exception e) {
            System.out.println("AddressTransformImpl:execute: caught exception "
                    + e.getMessage());
            failed = true;
            throw new SQLException("AddressTransformImpl:execute:" + e.getMessage());
        } finally {
            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    if (verbose) {
                        System.out.print("AddressTransformImpl:failed, rolling back...");
                    }
                    transaction.rollback();
                    if (verbose) {
                        System.out.println(" ...completed.");
                    }
                } else {
                    // commit the changes
                    if (verbose) {
                        System.out.print("AddressTransformImpl:sucess, committing ...");
                    }
                    transaction.commit();
                    if (verbose) {
                        System.out.println(" ...completed.");
                    }
                }
            } else {
                if (verbose) {
                    System.out
                    .println("AddressTransformImpl: not committing as transaction.isClientManagedTransaction()");
                }
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Returns the set of cases that may require status record to be inserted.
     * 
     * @param inSQLSelect
     *          the SQL to read source data
     * @exception SQLException
     *              if a database operation fails
     */
    private void readSourceData(final String inSQLSelect) throws SQLException {
        // stored the record from the database
        PreparedStatement readStatement = null;
        PreparedStatement insertStatement = null;
        final Transaction transaction = TransactionFactory.getTransaction(
                DataWarehouseConstants.kDefaultDatabase);
        int rowsUpdated = 0;
        final int commitLevel = 5000;
        int uncommitted = 0;
        try {
            final Connection connection = transaction.getConnection();
            readStatement = connection.prepareStatement(inSQLSelect);
            insertStatement = connection.prepareStatement(kSQLUpdateAddresses);
            final ResultSet rs = readStatement.executeQuery();
            AddressData addressRecord;
            while (rs.next()) {
                addressRecord = new AddressData(rs.getLong(1), rs.getString(2),
                        rs.getTimestamp(3));
                rowsUpdated += insertAddresses(addressRecord, insertStatement);
                uncommitted++;
                addressRecord = null;
                if (uncommitted >= commitLevel) {
                    transaction.executeBatch(insertStatement);
                    uncommitted = 0;
                }
            }
            if (uncommitted >= 0) {
                transaction.executeBatch(insertStatement);
                uncommitted = 0;
            }
        } catch (final Exception e) {
            System.out.println("AddressTransformImpl:execute:" + e + inSQLSelect);
            throw new SQLException("AddressTransformImpl:execute:" + e.getMessage()
                    + inSQLSelect);
        } finally {
            // release resources
            if (readStatement != null) {
                readStatement.close();
            }
            if (insertStatement != null) {
                insertStatement.close();
            }
            if (verbose) {
                System.out.println("AddressTransformImpl:" + rowsUpdated
                        + " address records processed");
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Returns the state key.
     * 
     * @param inState
     *          the state code
     * @return long state identity
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    public long findStateKey(final String inState) throws SQLException {
        long statekey = -1;
        Transaction transaction = null;
        PreparedStatement statement = null;
        try {
            // start a transaction, get DAO to read from the control table
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();
            statement = connection.prepareStatement(readStateKey);
            statement.setString(1, inState);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                statekey = rs.getLong(1);
            }
            return statekey;
        }
        catch (final Exception e) {
            System.out.println("AddressTransformImpl:readStateKey:" + e);
            throw new SQLException("AddressTransformImpl:readStateKey:"
                    + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Saves an address detail record.
     * 
     * @param addressRecord
     *          record for insertion
     * @param statement
     *          the SQL statement
     * @exception SQLException
     *              if a database operation fails
     */
    private int insertAddresses(final AddressData addressRecord,
            final PreparedStatement statement) throws SQLException {
        // store the record to the database
        readCountry(addressRecord);
        final int i = 1;
        try {
            statement.setLong(1, addressRecord.addressID);
            statement.setString(2, addressRecord.addressLineOne);
            statement.setString(3, addressRecord.addressLineTwo);
            statement.setString(4, addressRecord.addressLineThree);
            statement.setString(5, addressRecord.city);
            statement.setString(6, addressRecord.state);
            statement.setString(7, addressRecord.county);
            statement.setTimestamp(8, addressRecord.lastWritten);
            statement.addBatch();
        } catch (final SQLException e) {
            // ignore unique constraint errors
            // e.printStackTrace();
            // System.out.println(e.getMessage());
        }
        return i;
    }

    // ___________________________________________________________________________
    /**
     * Reads the Country Code.
     * 
     * @param inAddressData
     *          The address data string
     * 
     * @throws SQLException
     *           if the address data is not readable
     */
    private void readCountry(final AddressData inAddressData) throws SQLException {
        int i = 0;
        final StringTokenizer st = new StringTokenizer(inAddressData.addressData,
                System.getProperty("line.separator"));
        String country = null;
        while (st.hasMoreTokens()) {
            final String nextToken = st.nextToken();
            if (i++ == 2) {
                country = nextToken;
                inAddressData.country = country;
            }
            if (nextToken.contains("USCOUNTY")) {
                inAddressData.county = getPropertyValue(nextToken);
            } else if (nextToken.contains("ADD1")) {
                inAddressData.addressLineOne = getPropertyValue(nextToken);
            } else if (nextToken.contains("ADD2")) {
                inAddressData.addressLineTwo = getPropertyValue(nextToken);
            } else if (nextToken.contains("ADD3")) {
                inAddressData.addressLineThree = getPropertyValue(nextToken);
            } else if (nextToken.contains("CITY")) {
                inAddressData.city = getPropertyValue(nextToken);
            } else if (nextToken.contains("STATE")) {
                inAddressData.state = getPropertyValue(nextToken);
            } else if (nextToken.contains("ZIP")) {
                inAddressData.zip = getPropertyValue(nextToken);
            }
        }
    }

    /**
     * Returns a title, if the string is not a Java property, the parameter is
     * returned.
     * 
     * @param inTitle
     *          the title
     * 
     * @return return the title, if the parameter is a java property,e.g. if the
     *         parameter value is <code>chart.title=MyCases</code> then
     *         <code>MyCases</code> will be returned. Otherwise the title is
     *         returned.
     */
    private String getPropertyValue(final String inTitle) {
        // debug statement
        // System.out.println("Axis.getPropertyValue:" +inTitle);
        String title = inTitle;
        int length = 0;
        int equalsIndex = 0;
        int startOfTitle = 0;
        try {
            length = inTitle.length();
            if (length > 0) {
                equalsIndex = inTitle.indexOf('=');
                if (equalsIndex == -1) {
                    ;// do nothing;
                } else {
                    startOfTitle = equalsIndex + 1 > length ? length : equalsIndex + 1;
                    title = inTitle.substring(startOfTitle, length);
                }
            }
        } catch (final Exception e) {
            // we cannot cause critical errors
            // ignore the error and return the title
            System.out.println("Axis.getPropertyValue:" + e.getMessage());
        }
        // debug statement
        // System.out.println("Axis.getPropertyValue:" +title+":" + length + ":" +
        // startOfTitle);
        return title;
    }

    /**
     * Contains the logical key and address data.
     */
    class AddressData {
        /**
         * the changed data time .
         */
        private final Timestamp lastWritten;

        /**
         * the surrogate case identity.
         */
        private final long addressID;

        /**
         * the registered date for a case.
         */
        private final String addressData;

        /**
         * the address line 1.
         */
        private String addressLineOne;

        /**
         * the address line 2.
         */
        private String addressLineTwo;

        /**
         * the address line 3.
         */
        private String addressLineThree;

        /**
         * the city.
         */
        private String city;

        /**
         * the state.
         */
        private String state;

        /**
         * the country.
         */
        private String country;

        /**
         * the country.
         */
        private String county;

        /**
         * the zip.
         */
        private String zip;

        /**
         * Creates data for a new status record.
         * 
         * @param inAddressID
         *          address logical key
         * @param inAddressData
         *          address string
         * @param inChanged
         */
        public AddressData(
                final long inAddressID,
                final String inAddressData,
                final Timestamp inChanged) {
            addressID = inAddressID;
            addressData = inAddressData;
            lastWritten = inChanged;
            country = "";
            zip = "";
        }

        @Override
        public String toString() {
            return "addressid=" + addressID + ",country=" + country + ",zip=" + zip;
        }
    }

    public static void main(final String args[]) throws SQLException {
        System.out
        .println("Executing address transforms, you must ensure that data exists in DW_address and S_address.");
        System.out
        .println("and that preprocess has executed or the extract time column has a non null value.");
        TransactionFactory
        .overRideRequestforDefaultTransactions(DataWarehouseConstants.kStagingDatabase);
        CustomTransforms.setAddressElements("S_ADDRESS", "S_ADDRESSDETAIL");
        // addRegisteredRecievedStatus
    }
}
