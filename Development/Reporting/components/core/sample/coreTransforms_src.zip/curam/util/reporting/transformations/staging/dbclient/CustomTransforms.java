/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.staging.dbclient;

import java.math.BigInteger;
import java.sql.SQLException;

import curam.util.reporting.transformations.staging.base.AddCCSRemovalRecordsBase;
import curam.util.reporting.transformations.staging.base.PropertyReaderBase;
import curam.util.reporting.transformations.staging.fact.CaseStatusFactory;
import curam.util.reporting.transformations.staging.fact.CovertToHexFactory;
import curam.util.type.*;
import curam.util.reporting.transformations.staging.fact.PropertyReaderDBFactory;

/**
 * 
 * This class is the interface or entry point between the database and the
 * staging transformations.
 * 
 * The interface specification is enforced by the Oracle and DB2 call
 * specifications A call spec exposes a Java methods top-level entry point to
 * Oracle..
 * 
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public final class CustomTransforms {

  /**
   * Java application invocation point for debugging and test harness
   * invocation.
   * 
   * @param args
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.RESTRICTED)
  static public void main(String args[]) throws SQLException {

    BigInteger bigInteger = new BigInteger("109");
    byte[] bytes = new BigInteger("109").toByteArray();

    System.out.println("bigInteger.toByteArray()=" + bigInteger.toByteArray());
    System.out.println("bigInteger.toString()=" + bigInteger.toString());
    System.out.println("new BigInteger(bytes).longValue()="
        + new BigInteger(bytes).longValue());

    CustomTransforms.vcToBi(bytes);
  }

  // ___________________________________________________________________________
  /**
   * Ensures this class cannot be created.
   */
  private CustomTransforms() {
  }

  // __________________________________________________________________________
  /**
   * Returns a property value.
   * 
   * @param inPropertyName
   *          table property name
   * 
   * @return String the property value, "not found" is returned if the property
   *         name does not exist
   * 
   * @throws SQLException
   *           if the address cannot be transformed
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static String readPropertyFromDB(final String inPropertyName)
      throws SQLException {
    PropertyReaderBase reader = PropertyReaderDBFactory.newPropertyReader();

    String propertyValue = reader.readPropertyFromDB(inPropertyName);

    return propertyValue;
  }

  // __________________________________________________________________________
  /**
   * Returns the language part of the locale identifier.
   * 
   * 
   * @return String the language part of the locale identifier
   * 
   * @throws SQLException
   *           if the address cannot be transformed
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static String readLanguage() throws SQLException {
    PropertyReaderBase reader = PropertyReaderDBFactory.newPropertyReader();
    String language = reader.getLanguagePart();
    return language;
  }

  // __________________________________________________________________________
  /**
   * Returns the language part of the locale identifier.
   * 
   * @param inMessage
   *          parameter is ignored.
   * @return String the language part of the locale identifier
   * 
   * @throws SQLException
   *           if the address cannot be transformed
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static String readLanguage(String inMessage) throws SQLException {
    PropertyReaderBase reader = PropertyReaderDBFactory.newPropertyReader();
    String language = reader.getLanguagePart();
    return language;
  }

  // __________________________________________________________________________
  /**
   * Returns the language part of the locale identifier.
   * 
   * @param inMessage
   *          parameter is ignored.
   * @return String the language part of the locale identifier
   * 
   * @throws SQLException
   *           if the address cannot be transformed
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static String readLanguageAndDilect(String inMessage)
      throws SQLException {
    PropertyReaderBase reader = PropertyReaderDBFactory.newPropertyReader();
    String languageAndDilect = reader.readLanguage();
    return languageAndDilect;
  }

  // __________________________________________________________________________
  /**
   * Returns a property value for undefined if the data value is null.
   * 
   * @param inColumnValue
   *          the value
   * 
   * @return String the localized property value for undefined if the parameter
   *         is null
   * 
   * @throws SQLException
   *           if the address cannot be transformed
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static String readUndefinedIFNull(final String inColumnValue)
      throws SQLException {
    if (inColumnValue != null) {
      return inColumnValue;
    }
    PropertyReaderBase reader = PropertyReaderDBFactory.newPropertyReader();
    String propertyValue = reader
        .readPropertyFromDB(PropertyReaderBase.kUNDEFINED_PROPERTY_NAME);

    return propertyValue;
  }

  // __________________________________________________________________________
  /**
   * Returns a property value for undefined if the data value is null.
   * 
   * @param inColumnValue
   *          the value
   * @param inPropertyName
   *          the property name
   * 
   * @return String the localized property value if the value is null
   * 
   * @throws SQLException
   *           if the address cannot be transformed
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static String readPropertyIFNull(final String inColumnValue,
      final String inPropertyName) throws SQLException {
    if (inColumnValue != null) {
      return inColumnValue;
    }
    PropertyReaderBase reader = PropertyReaderDBFactory.newPropertyReader();
    String propertyValue = reader.readPropertyFromDB(inPropertyName);

    return propertyValue;
  }

  // ___________________________________________________________________________
  /**
   * Exposes the ZOS byte to long conversion routine.
   * 
   * @param unconvertedID
   *          the ID to convert
   * 
   * @return the converted curam identifier
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static long vcToBi(final byte[] unconvertedID) throws SQLException {

    return CovertToHexFactory.newInstance().vcToBi(unconvertedID);
  }

  // ___________________________________________________________________________
  /**
   * Deletes duplicate records for case status where the enddate is not null and
   * the status description is Active
   * 
   * @param inTargetTable
   *          the target table being populated
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  @AccessLevel(AccessLevelType.RESTRICTED)
  public static void deleteDupCaseStatus(final String inTargetTable)
      throws SQLException {

    CaseStatusFactory.newInstance(inTargetTable).executePostProcess(
        inTargetTable);
  }

  // ___________________________________________________________________________
  /**
   * This transform processes removal records where the list of removal reasons
   * are packed into a single character column.
   * 
   * Each removal reason results in a new removal reason record being inserted
   * into staging which is then pulled into the warehouse via the normal
   * extraction processes.
   * 
   * @param inTargetTable
   *          the target table being populated
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  @AccessLevel(AccessLevelType.RESTRICTED)
  public static void processCCSRemovalReasons(final String inTargetTable)
      throws SQLException {

    new AddCCSRemovalRecordsBase(inTargetTable)
        .executePostProcess(inTargetTable);
  }
}
