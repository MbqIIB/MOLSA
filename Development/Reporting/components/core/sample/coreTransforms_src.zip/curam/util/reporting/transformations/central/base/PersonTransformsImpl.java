/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.central.base;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import java.util.GregorianCalendar;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.transformations.central.intf.PersonTransforms;

/**
 * Associate a recipient to the evidence used in eligibility. This process
 * 
 * executes against the recipient table and any evidence table(s).
 * 
 * Evidence is only associated once to a recipient even through there may be
 * many evidence records that allow eligibility.
 * 
 * This is an algorithm based on the rules defined in our requirements
 * specifications for TANF.
 * 
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
@SuppressWarnings({ "rawtypes", "unchecked" })
class PersonTransformsImpl implements PersonTransforms {

    public static void main(final String args[]) throws SQLException {
        /*
         * Calendar from = Calendar.getInstance(); from.set(Calendar.YEAR, 2005);
         * from.set(Calendar.MONTH, Calendar.FEBRUARY);
         * from.set(Calendar.DAY_OF_MONTH, 2);
         * 
         * Calendar to = Calendar.getInstance(); to.set(Calendar.YEAR, 2007);
         * to.set(Calendar.MONTH, Calendar.JANUARY); to.set(Calendar.DAY_OF_MONTH,
         * 2);
         * 
         * System.out.println("age=" + calculateAge(new
         * Date(from.getTime().getTime()), new Date(to .getTime().getTime())));
         * 
         * findCaseStatusKey(-1,new Date(from.getTime().getTime()), new Date(to
         * .getTime().getTime()));
         */

        // linkReciepientToEvidence("");
        TransactionFactory
        .overRideRequestforDefaultTransactions(DataWarehouseConstants.kCentralDatabase);

        // addRegisteredRecievedStatus("DW_ADDRESS");
        // new PersonTransformsImpl().findPersonHistoryKey(101, new Date(63, 01,
        // 01),
        // new Date(63, 01, 01), 2);
        new PersonTransformsImpl().findCaseStatusKey(64,
                new Date(System.currentTimeMillis()), null);

    }

    /**
     * -1
     */
    private final int kUndefinedKey = -1;

    private final String KEducationLevel[][] = {
            { String.valueOf(kUndefinedKey), "Unknown" }, { "1", "First Grade" },
            { "2", "Second Grade" }, { "3", "Third Grade" }, { "4", "Fourth Grade" },
            { "5", "Fifth Grade" }, { "6", "Sixth Grade" }, { "7", "Seventh Grade" },
            { "8", "Eight Grade" }, { "9", "Ninth Grade" }, { "10", "Thenth Grade" },
            { "11", "Elventh Grade" }, { "12", "Diploma,GED" },
            { "13", "Awarded Associate's Degree" },
            { "14", " Awarded Bachelor's Degree" },
            { "15", "Awarded graduate degree" }, { "16", "Other credentials" },
            { "98", "No formal education" } };

    private final List<MaintenanceAssistenceStatus> educationLevelKeys;

    private final List<MaintenanceAssistenceStatus> employmentStatusKeys;

    private final int kEmploymentStatusEmployed = 1;

    private final int kEmploymentStatusNotEmployed = 2;

    private final int kEmploymentStatusNoInLabourForce = 3;

    private final String kEmploymentStatus[][] = {
            { String.valueOf(kUndefinedKey), "undefined" },
            { String.valueOf(kEmploymentStatusEmployed), "Employed" },
            { String.valueOf(kEmploymentStatusNotEmployed), "Not Employed" },
            { String.valueOf(kEmploymentStatusNoInLabourForce), "Not In Labour Force" } };

    private final int kHousingPublicKey = 1;

    private final int kHousingRentKey = 2;

    private final int KHousingNoSubsidyKey = 3;

    private final String kHousing[][] = {
            { String.valueOf(kUndefinedKey), "undefined" },
            { String.valueOf(kHousingPublicKey), "Public Housing" },
            { String.valueOf(kHousingRentKey), "Rent Subsidy" },
            { String.valueOf(KHousingNoSubsidyKey), "No Housing Subsidy" } };

    @Deprecated
    /**
     * @see FederalProgramsTransformsBase
     */
    private final List housingKeys;

    private final int kSanctionsTOTALDOLLARAMOUNTKey = 1;

    private final int kSanctionsFAMILYADULTSANCTIONKey = 2;

    private final int kSanctionsSANCTIONFORTEENKey = 3;

    private final int kSanctionsNONCOOPERATIONKey = 4;

    private final int kSanctionsWORKREQUIREMENTSSANCTIONKey = 5;

    private final int kSanctionsFAILURETOCOMPLYKey = 6;

    private final int kSanctionsOTHERSANCTIONKey = 7;

    private final String kFederalSanctions[][] = {
            { String.valueOf(kUndefinedKey), "undefined" },
            { String.valueOf(kSanctionsTOTALDOLLARAMOUNTKey),
            "TOTAL DOLLAR AMOUNT FOR REDUCTION DUE TO SANCTIONS" },
            { String.valueOf(kSanctionsFAMILYADULTSANCTIONKey),
            "FAMILY ADULT SANCTION WITH NO HIGH SCHOOL DIPLOMA OR EQUIV" },
            { String.valueOf(kSanctionsSANCTIONFORTEENKey),
            "SANCTION FOR TEEN PARENT NOT ATTENDING SCHOOL" },
            { String.valueOf(kSanctionsNONCOOPERATIONKey),
            "NON-COOPERATION WITH CHILD SUPPORT" },
            { String.valueOf(kSanctionsWORKREQUIREMENTSSANCTIONKey),
            "WORK REQUIREMENTS SANCTION" },
            { String.valueOf(kSanctionsFAILURETOCOMPLYKey),
            "FAILURE TO COMPLY WITH AN INDIVIDUAL RESPONSIBILITY PLAN" },
            { String.valueOf(kSanctionsOTHERSANCTIONKey), "OTHER SANCTION" } };

    @Deprecated
    /**
     * @see FederalProgramsTransformsBase
     */
    private final List federalSanctionsKeys;

    final int kChildEnforcementKeyYes = 1;

    final int kChildEnforcementKeyNo = 2;

    final String kChildEnforcmentStringYes = "Y";

    final String kChildEnforcementStringNo = "N";

    private final String childSupportEnforcementGroups[][] = {
            { String.valueOf(kChildEnforcementKeyYes), "YES" },
            { String.valueOf(kChildEnforcementKeyNo), "NO" },
            { String.valueOf(kUndefinedKey), "undefined" } };

    List<MaintenanceAssistenceStatus> childSupportEnforcementKeys;

    final int kFederalBenefitOASDI = 1;

    final int kFederalBenefitDisability = 2;

    final int kFederalBenefitSSI = 3;

    private final String fedBenefitGroups[][] = {
            { String.valueOf(kUndefinedKey), "undefined" },
            { String.valueOf(kFederalBenefitOASDI), "RECEIVES FEDERAL OASDI" },
            { String.valueOf(kFederalBenefitDisability),
            "RECEIVES BENEFITS BASED ON FEDERAL DISABILITY STATUS" },
            { String.valueOf(kFederalBenefitSSI), "RECEIVES AID UNDER TITLE XVI-SSI" },
            { String.valueOf(kUndefinedKey), "RECEIVES AID UNDER TITLE XIV-APDT" } };

    private final List<MaintenanceAssistenceStatus> fedBenefitGroupKeys;

    /**
     * earned income statuses
     */
    private final String KUnEarnedIncomeStatus[][] = {
            { String.valueOf(kUndefinedKey), "UNDEFINED" },
            { "1", "EARNED INCOME TAX CREDIT" }, { "2", "SOCIAL SECURITY" },
            { "3", "SSI" }, { "4", "WORKER'S COMPENSATION" }, { "5", "OTHER" } };

    @Deprecated
    /**
     * @see FederalProgramsTransformsBase
     */
    private Map unearnedIncomeByProduct;

    private final List unEarnedIncomeKeys;

    private final int kUnEarnedIncomeSocialSecurityKey = 2;

    private final int kUnEarnedIncomeSSIKey = 3;

    private final int kUnEarnedIncomeWorkersCompKey = 4;

    @SuppressWarnings("unused")
    private final int kUnEarnedIncomeOtherKey = 5;

    private final int kUnDefinedStatusIndex = 0;

    private final int kMASUnknown = 1;

    private final int kMASCash = 2;

    private final int kMASMedicallyNeedy = 3;

    private final int kMASPoverty = 4;

    private final int kMASOther = 5;

    private final int kMASWaiver = 6;

    /*
     * the order in the list generates the key values in the tables, do not change
     * as some code depends on this key, mas code, mas description
     */
    private final String kMAStatuses[][] = {
            { String.valueOf(kUndefinedKey), String.valueOf(kUndefinedKey),
            "UNDEFINED" }, { "1", "9", "MAS UNKNOWN" },
            { "2", "1", "RECEIVING CASH" }, { "3", "2", "MEDICALLY NEEDY" },
            { "4", "3", "POVERTY RELATED" }, { "5", "4", "OTHER" },
            { "6", "4", "WAIVER" } };

    @Deprecated
    /**
     * @see FederalProgramsTransformsBase
     */
    private final List masStatusesKeys;

    @Deprecated
    /**
     * @see FederalProgramsTransformsBase
     */
    private Map masStatusesByProduct;

    /*
     * the order in the list generates the key values in the tables, do not change
     * as some code depends on this
     */
    private final String kBOEStatuses[][] = {
            { String.valueOf(kUndefinedKey), String.valueOf(kUndefinedKey),
            "UNDEFINED" }, { "1", "9", "BOE UNKNOWN" }, { "2", "1", "AGED" },
            { "3", "2", "BLIND/DISABLED" }, { "4", "4", "CHILDREN" },
            { "5", "5", "ADULT" }, { "6", "8", "FOSTER CARE CHILDREN" },
            { "7", "A", "BCCA WOMEN" } };

    private final int kBOEUnknown = 1;

    private final int kBOEAged = 2;

    private final int kBOEBlind = 3;

    private final int kBOEChildren = 4;

    private final int kBOEAdult = 5;

    private final int kBOEFosterCare = 6;

    private final int kBOEWomen = 7;

    @Deprecated
    /**
     * @see FederalProgramsTransformsBase
     */
    private final List<BasisOfEligibilityStatus> boeStatusesKeys;

    @Deprecated
    /**
     * @see FederalProgramsTransformsBase
     */
    private Map boeStatusesByProduct;

    /**
     * medicaid dual eligibles
     */
    private final String KDualEligibleStatus[][] = {
            { String.valueOf(kUndefinedKey), "UNDEFINED" },
            { "1", "NOT A DUEL ELIGIBLE PRODUCT" }, { "2", "QMB" }, { "3", "SLMB" },
            { "4", "QDWI" }, { "5", "QI(1)" } };

    @Deprecated
    /**
     * @see FederalProgramsTransformsBase
     */
    private final List dualEligiblesStatusKeys;
    @Deprecated
    /**
     * @see FederalProgramsTransformsBase
     */
    private Map dualEligiblesByProduct;

    /*
     * 1
     */
    @SuppressWarnings("unused")
    private final int kMedicaidISNOTADUELELIGIBLEPRODUCT = 1;

    /**
     * 2
     */
    private final int kMedicaidQMB = 2;

    /**
     * 3
     */
    private final int kMedicaidSLMB = 3;

    /**
     * 4
     */
    private final int kMedicaidQDWI = 4;

    /**
     * 5
     */
    private final int kMedicaidQI1 = 5;

    private static final String kVICTIMS_OF_SEVERE_TRAFFICKING = "Victims of severe Trafficking";

    private static final String kAMERICAN_INDIAN_BORN_IN_CANADA = "American Indian born in Canada";

    private static final String kAMERASIAN_IMMIGRANT = "Amerasian Immigrant";

    private static final String kCUBAN_HAITIAN_ENTRANT = "Cuban/Haitian entrant";

    private static final String kDEPORTATION_WITHHELD = "Deportation Withheld";

    private static final String kPAROLEE = "Parolee";

    private static final String ASYLEE = "Asylee";

    private static final String kCONDITIONAL_ENTRANT = "Conditional Entrant";

    private static final String kREFUGEE = "Refugee";

    private static final String kLPR_WITH_40_QUALIFYING_QUARTERS = "LPR With 40 Qualifying Quarters";

    private static final String kLPR_WITHOUT_40_QUALIFYING_QUARTERS = "LPR Without 40 Qualifying Quarters";

    private final String kYes = "Y";

    private final String kNo = "N";

    private final String kYesNumber = "1";

    private final String kParent = "Parent";

    private final String kCitizenStatus = "Alien";

    /*
     * the order in the list generates the key values in the tables, do not change
     * as some code depends on this key, mas code, mas description
     */
    private final String khouseHoldAssistanceStatus[][] = {
            { String.valueOf(kUndefinedKey), String.valueOf(kUndefinedKey),
            "UNDEFINED" }, { "1", "NON ASSISTANCE", "NON ASSISTANCE" },
            { "2", "PUBLIC ASSISTANCE", "PUBLIC ASSISTANCE" } };

    private final short kPublicAssiatanceKey = 1;

    private final short kNonPublicAssiatanceKey = 2;
    @Deprecated
    /**
     * @see FederalProgramsTransformsBase
     */
    private final List houseHoldAssistanceStatusKeys;

    /**
     * update the age, adult indicator, alien indicator and parent indicator set
     * the processes flag to true
     */
    private final String updateRecipient = "update DW_CASERECIPIENT_MONTH"
        + " set age=?, adultind=?, processedflag=?"
        + " , alienind=?, parentind=?, dwmaskey=?,dwboekey=?, dwdualkey=?, "
        + " DWASSISTANCESTATUSKEY =?," + "totalunearnedincome=?"
        + " TOTALCHILDSUPPORTAMOUNT=?, TOTALCASHRESOURCEAMOUNT=?,"
        + " TOTALEARNEDINCOME=?, SANCTIONIND=?" + "where DWCASERECIPIENTID=?";

    /**
     * Link and recipient to their evidence Evidence is only associated once to a
     * recipient even through there may be many evidence records that allow
     * eligibility.
     * 
     * This is an algorithm based on the rules defined in our requirements
     * specifications for TANF.
     * 
     */
    private final String insertEvidenceLink = "insert into DW_ISPEVIDENCELINK "
        + " (DWCASERECIPIENTID,DWEVIDENCEID, EVIDENCETYPE, LASTWRITTEN)"
        + " values (?,?,?,?)";

    /**
     * returns zero or more person records applicable for a period of time
     */
    private final String readPersonHistoryKeyMostRecentAsOfEventDate = "select dwpersonhistoryid, t1.startdate from dw_personhistory t1, dw_participant t2"
        + " where t2.concernroleid=?"
        + " and t2.dwparticipantid=t1.dwparticipantid"
        + " and t1.startdate <= ?"
        + // startdate<=end date
        " and (t1.enddate is null OR t1.enddate >= ?) " + // enddate>= start date
        " order by t1.startdate desc";

    /*
     * returns zero or more status records applicable for a period of time
     */
    private final String readCaseStatusHistoryKeyByDate = "select t2.dwcasestatushistoryid, t2.fromdate, t2.todate, t3.statusname"
        + " from dw_casestatushistory t2, dw_casestatus t3"
        + " where t2.dwcaseid = ? "
        + " and t2.dwstatusid=t3.dwstatusid "
        + " order by t2.fromdate desc";

    /**
     * returns recipient records not processed yet
     */
    @SuppressWarnings("unused")
    @Deprecated
    private final String readReciepientsToProcess = "select t1.dwcaserecipientid, t2.dateofbirth, t2.startdate, t2.enddate, "
        + " t1.dwcaseid, t1.dwparticipantid, t1.lastwritten,  t4.name, t5.programcd"
        + " from  DW_CASEGROUP t1, dw_personhistory t2, dw_case t3, dw_product t4, dw_program t5 "
        + " where t1.dwpersonhistoryid=t2.dwpersonhistoryid"
        + " and t1.processedflag = 'N'"
        + " and t1.dwcaseid=t3.dwcaseid"
        + " and t3.dwprogramid=t5.dwprogramid"
        + " and t3.dwproductid=t4.dwproductid";

    /**
     * returns zero or more student records applicable for a period of time
     */
    private final String readStudentByDate = "select DWSTUDENTID "
        + " from dw_ispstudent" + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more student records applicable for a period of time
     */
    private final String readBenefitByDate = "select DWBENEFITID, benefittype, amount "
        + " from dw_ispBENEFIT"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more household records applicable for a period of time
     * 
     * is the recipient a parent?, needed for reporting on 2 parent families in
     * future releases if the recipient is a child we need check if he/she has
     * parents, not just if the recipient is a parent
     */
    private final String readHouseholdRoleByDate = "select DWHHRELATIONSHIPID,RELATIONSHIPTYPE "
        + " from dw_isphouseholdrelationship"
        + " where DWCASEID=? and DWRELPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more alien records applicable for a period of time
     */
    private final String readAlienByDate = "select DWALIENID, ALIENTYPE "
        + " from dw_ispALIEN" + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more household member records applicable for a period of
     * time
     */
    private final String readHouseHoldMemberByDate = "select DWHHMEMBERID, CITIZENSTATUS "
        + " from dw_isphouseholdmember"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more unearned income records applicable for a period of
     * time
     */
    private final String readUnEarnedIncomeByDate = "select dwunearnedincomeid as id, frequencycode,amount "
        + " from dw_ispunearnedincome"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more records applicable for a period of time
     */
    private final String readLiquidResourceByDate = "select dwunearnedincomeid as id, frequencycode,VALUE "
        + " from DW_ISPLIQUIDRESOURCES"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more earned income records applicable for a period of time
     */
    private final String readEarnedIncomeByDate = "select dwearnedincomeid as id, frequencycode,amount  "
        + " from dw_ispearnedincome"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more records applicable for a period of time
     */
    private final String readSelfEmployedIncomeByDate = "select dwgrossreceiptid as id, frequencycode,amount "
        + " from dw_ispgrossreceipt"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more records applicable for a period of time
     */
    private final String readAbParChildSupportByDate = "select dwgrossreceiptid as id, CHILDSUPPORTPMTAMOUNT "
        + " from DW_ISPABPARCHILDSUPPORT"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more records applicable for a period of time
     */
    private final String readUnPaidEmploymentByDate = "select DWCASEID "
        + " from DW_ISPUNPAIDEMPLOYMENT"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more gross receivable for a period of time
     */
    private final String readEmploymentStatusPaidEmploymentByDate = "select DWCASEID "
        + " from DW_ISPPAIDEMPLOYMENT"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more records applicable for a period of time
     */
    private final String readEmploymentStatusSelfEmployedByDate = "select DWCASEID "
        + " from DW_ISPSELFEMPLOYMENT"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and ATTRIBUTEDFROMDATE <= ?"
        + " and (ATTRIBUTEDTODATE >= ? or ATTRIBUTEDTODATE is null)";

    /**
     * returns zero or more records applicable for a period of time
     */
    private final String readEmploymentStatusWorkRequirementsByDate = "select DWCASEID "
        + " from DW_ISPWORKREQUIREMENTS"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and ATTRIBUTEDFROMDATE <= ?"
        + " and (ATTRIBUTEDTODATE >= ? or ATTRIBUTEDTODATE is null)";

    /**
     * returns zero or more sanction records applicable for a period of time
     */
    private final String readSanctionsByDate = "select DWCASEID "
        + " from DW_ISPSANCTION" + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and SANCTIONSTARTDATE <= ?"
        + " and (SANCTIONENDDATE >= ? or SANCTIONENDDATE is null)";

    /**
     * returns zero or more records applicable for a period of time
     */
    private final String readChildSupportEnforceByDate = "select DWCASEID, COOPERWITHCSEDIND "
        + " from DW_ISPCHILDSUPPORTENFORCE"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and ATTRIBUTEDFROMDATE <= ?"
        + " and (ATTRIBUTEDTODATE >= ? or ATTRIBUTEDTODATE is null)";

    /**
     * returns zero or more unearned income records applicable for a period of
     * time
     */
    private final String readUnEarnedIncomeTypeByDate = "select dwunearnedincomeid as id, unearnedincometype  "
        + " from dw_ispunearnedincome"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns zero or more records applicable for a period of time
     */
    private final String readRentAllowanceSubHousingByDate = "select dwunearnedincomeid as id, REIMBURSEMENTTYPECODE  "
        + " from DW_ISPSUBSIDIZEDHOUSING"
        + " where DWCASEID=? and DWPARTICIPANTID=?"
        + " and attributedstartdate <= ?"
        + " and (attributedenddate >= ? or attributedenddate is null)";

    /**
     * returns the dual eligibility key for a given product
     */
    final private String readDualKeyForProduct = "select DWDUALKEY as key "
        + " from DW_DUALELIGIBITYBYPRODUCT" + " where PRODUCTCODE=?";

    /**
     * returns the dual eligibility key for a given product
     */
    final private String readDualKeyNotDualProduct = "select DWDUALKEY as dualkey from DW_DUALELIGIBITY where CODE=?";
    final private String readDualKeyNotDualProductCode = "NOT A DUEL ELIGIBLE PRODUCT";

    /**
     * there is a static dependency between these code and the dw_race.csv file if
     * the file changes changed these constants
     */

    final private short kWHITE = 1;

    final private short kAFRICANAMERICAN = 2;

    final private short kNATIVEAMERICAN = 3;

    final private short kASIAN = 4;

    final private short kHAWAIIAN = 5;

    final private short kMULTIRACIAL = 6;

    // ___________________________________________________________________________
    /**
     * Creates an object to generate recipient attributes.
     * 
     * 
     * @throws SQLException
     *           if database error occurs
     */
    public PersonTransformsImpl() throws SQLException {

        MaintenanceAssistenceStatus status;

        educationLevelKeys = new ArrayList();
        for (int i = 0; i < KEducationLevel.length; i++) {
            status = new MaintenanceAssistenceStatus(
                    Integer.parseInt(KEducationLevel[i][0]), KEducationLevel[i][1],
                    KEducationLevel[i][1]);

            educationLevelKeys.add(status);
        }

        employmentStatusKeys = new ArrayList();
        for (int i = 0; i < kEmploymentStatus.length; i++) {
            status = new MaintenanceAssistenceStatus(
                    Integer.parseInt(kEmploymentStatus[i][0]), kEmploymentStatus[i][1],
                    kEmploymentStatus[i][1]);

            employmentStatusKeys.add(status);
        }

        housingKeys = new ArrayList();
        for (int i = 0; i < kHousing.length; i++) {
            status = new MaintenanceAssistenceStatus(
                    Integer.parseInt(kHousing[i][0]), kHousing[i][1], kHousing[i][1]);

            housingKeys.add(status);
        }

        childSupportEnforcementKeys = new ArrayList();
        for (int i = 0; i < childSupportEnforcementGroups.length; i++) {
            status = new MaintenanceAssistenceStatus(
                    Integer.parseInt(childSupportEnforcementGroups[i][0]),
                    childSupportEnforcementGroups[i][1],
                    childSupportEnforcementGroups[i][1]);

            childSupportEnforcementKeys.add(status);
        }

        federalSanctionsKeys = new ArrayList();
        for (int i = 0; i < kFederalSanctions.length; i++) {
            status = new MaintenanceAssistenceStatus(
                    Integer.parseInt(kFederalSanctions[i][0]), kFederalSanctions[i][1],
                    kFederalSanctions[i][1]);

            federalSanctionsKeys.add(status);
        }

        fedBenefitGroupKeys = new ArrayList();
        for (int i = 0; i < fedBenefitGroups.length; i++) {
            status = new MaintenanceAssistenceStatus(
                    Integer.parseInt(fedBenefitGroups[i][0]), fedBenefitGroups[i][1],
                    fedBenefitGroups[i][1]);

            fedBenefitGroupKeys.add(status);
        }

        BasisOfEligibilityStatus boeStatus;

        unEarnedIncomeKeys = new ArrayList();
        for (int i = 0; i < KUnEarnedIncomeStatus.length; i++) {
            status = new MaintenanceAssistenceStatus(
                    Integer.parseInt(KUnEarnedIncomeStatus[i][0]),
                    KUnEarnedIncomeStatus[i][1], KUnEarnedIncomeStatus[i][1]);

            unEarnedIncomeKeys.add(status);
        }

        masStatusesKeys = new ArrayList();
        for (int i = 0; i < kMAStatuses.length; i++) {
            status = new MaintenanceAssistenceStatus(
                    Integer.parseInt(kMAStatuses[i][0]), kMAStatuses[i][1],
                    kMAStatuses[i][2]);

            masStatusesKeys.add(status);
        }

        boeStatusesKeys = new ArrayList();
        for (int i = 0; i < kBOEStatuses.length; i++) {
            boeStatus = new BasisOfEligibilityStatus(
                    Integer.parseInt(kBOEStatuses[i][0]), kBOEStatuses[i][1],
                    kBOEStatuses[i][2]);

            boeStatusesKeys.add(boeStatus);
        }
        dualEligiblesStatusKeys = new ArrayList();
        MedicaidDualEligibles medicaidDualEligibles;
        for (int i = 0; i < KDualEligibleStatus.length; i++) {
            medicaidDualEligibles = new MedicaidDualEligibles(
                    Integer.parseInt(KDualEligibleStatus[i][0]),
                    KDualEligibleStatus[i][1], KDualEligibleStatus[i][1]);

            dualEligiblesStatusKeys.add(medicaidDualEligibles);
        }

        houseHoldAssistanceStatusKeys = new ArrayList();
        for (int i = 0; i < khouseHoldAssistanceStatus.length; i++) {
            status = new MaintenanceAssistenceStatus(
                    Integer.parseInt(khouseHoldAssistanceStatus[i][0]),
                    khouseHoldAssistanceStatus[i][1], khouseHoldAssistanceStatus[i][1]);

            houseHoldAssistanceStatusKeys.add(status);
        }

        initializeMASCodes();
        initializeBOECodes();
        initializeDualEligibleCodes();
        initializeUnEarnedIncomeCodes();

    }

    /**
     * Associates products to federal codes.
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl#linkReciepientToEvidence(String)
     * @since 6.0 SP2
     */

    @Deprecated
    private void initializeBOECodes() {

        boeStatusesByProduct = new HashMap();
        // initial data created
        final BasisOfEligibilityStatus boeStatus = (BasisOfEligibilityStatus) boeStatusesKeys
        .get(kBOEWomen);
        boeStatusesByProduct.put(boeStatus.hashKey("PN73"), boeStatus);
        // initial data created
        boeStatusesByProduct.put("PN50", boeStatusesKeys.get(kBOEUnknown));
        boeStatusesByProduct.put("PN72", boeStatusesKeys.get(kBOEUnknown));
        // initial data created
        boeStatusesByProduct.put("PN72", boeStatusesKeys.get(kBOEFosterCare));

        // aged with no dependency on age
        boeStatusesByProduct.put("PN64", boeStatusesKeys.get(kBOEAged));
        boeStatusesByProduct.put("PN69", boeStatusesKeys.get(kBOEAged));

        // aged only if over 65 with the product types
        BasisOfEligibilityStatus ageConstraint = ((BasisOfEligibilityStatus) boeStatusesKeys
                .get(kBOEAged)).getOver65Object();

        boeStatusesByProduct.put(ageConstraint.hashKey("PN35"), ageConstraint);
        boeStatusesByProduct.put(ageConstraint.hashKey("PN36"), ageConstraint);
        boeStatusesByProduct.put(ageConstraint.hashKey("PN37"), ageConstraint);
        boeStatusesByProduct.put(ageConstraint.hashKey("PN38"), ageConstraint);
        boeStatusesByProduct.put(ageConstraint.hashKey("PN49"), ageConstraint);
        boeStatusesByProduct.put(ageConstraint.hashKey("PN68"), ageConstraint);

        // blind with no dependency on age
        boeStatusesByProduct.put("PN65", boeStatusesKeys.get(kBOEBlind));
        boeStatusesByProduct.put("PN66", boeStatusesKeys.get(kBOEBlind));
        boeStatusesByProduct.put("PN74", boeStatusesKeys.get(kBOEBlind));
        boeStatusesByProduct.put("PN75", boeStatusesKeys.get(kBOEBlind));
        boeStatusesByProduct.put("PN76", boeStatusesKeys.get(kBOEBlind));
        boeStatusesByProduct.put("PN79", boeStatusesKeys.get(kBOEBlind));

        // blind only if under 65 with the product types
        {
            ageConstraint = ((BasisOfEligibilityStatus) boeStatusesKeys
                    .get(kBOEBlind)).getUnder65Object();

            boeStatusesByProduct.put(ageConstraint.hashKey("PN35"), ageConstraint);
            boeStatusesByProduct.put(ageConstraint.hashKey("PN36"), ageConstraint);
            boeStatusesByProduct.put(ageConstraint.hashKey("PN37"), ageConstraint);
            boeStatusesByProduct.put(ageConstraint.hashKey("PN38"), ageConstraint);
            boeStatusesByProduct.put(ageConstraint.hashKey("PN49"), ageConstraint);
            boeStatusesByProduct.put(ageConstraint.hashKey("PN68"), ageConstraint);

            // adult with no dependency
            boeStatusesByProduct.put("PN47", boeStatusesKeys.get(kBOEAdult));
            boeStatusesByProduct.put("PN48", boeStatusesKeys.get(kBOEAdult));
            boeStatusesByProduct.put("PN54", boeStatusesKeys.get(kBOEAdult));
            boeStatusesByProduct.put("PN59", boeStatusesKeys.get(kBOEAdult));
            boeStatusesByProduct.put("PN61", boeStatusesKeys.get(kBOEAdult));
        }

        {
            // adult with no dependency
            final BasisOfEligibilityStatus adultConstraint = ((BasisOfEligibilityStatus) boeStatusesKeys
                    .get(kBOEAdult)).getAdultObject();

            boeStatusesByProduct
            .put(adultConstraint.hashKey("PN34"), adultConstraint);
            boeStatusesByProduct
            .put(adultConstraint.hashKey("PN53"), adultConstraint);
            boeStatusesByProduct
            .put(adultConstraint.hashKey("PN70"), adultConstraint);
            boeStatusesByProduct
            .put(adultConstraint.hashKey("PN71"), adultConstraint);

            // child with no dependency
            boeStatusesByProduct.put("PN41", boeStatusesKeys.get(kBOEChildren));
            boeStatusesByProduct.put("PN42", boeStatusesKeys.get(kBOEChildren));
            boeStatusesByProduct.put("PN43", boeStatusesKeys.get(kBOEChildren));
            boeStatusesByProduct.put("PN45", boeStatusesKeys.get(kBOEChildren));
            boeStatusesByProduct.put("PN46", boeStatusesKeys.get(kBOEChildren));
            boeStatusesByProduct.put("PN55", boeStatusesKeys.get(kBOEChildren));
            boeStatusesByProduct.put("PN56", boeStatusesKeys.get(kBOEChildren));
            boeStatusesByProduct.put("PN57", boeStatusesKeys.get(kBOEChildren));
            boeStatusesByProduct.put("PN58", boeStatusesKeys.get(kBOEChildren));
            boeStatusesByProduct.put("PN60", boeStatusesKeys.get(kBOEChildren));
            boeStatusesByProduct.put("PN62", boeStatusesKeys.get(kBOEChildren));
        }
        {
            final BasisOfEligibilityStatus childConstraint = ((BasisOfEligibilityStatus) boeStatusesKeys
                    .get(kBOEChildren)).getChildObject();

            boeStatusesByProduct
            .put(childConstraint.hashKey("PN34"), childConstraint);
            boeStatusesByProduct
            .put(childConstraint.hashKey("PN53"), childConstraint);
            boeStatusesByProduct
            .put(childConstraint.hashKey("PN70"), childConstraint);
            boeStatusesByProduct
            .put(childConstraint.hashKey("PN71"), childConstraint);
        }

    }

    /**
     * Associates products to federal codes.
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl#linkReciepientToEvidence(String)
     * @since 6.0 SP2
     */

    @Deprecated
    private void initializeMASCodes() {
        masStatusesByProduct = new HashMap();
        // add the unknown mas values

        masStatusesByProduct.put(new String("PN72"),
                masStatusesKeys.get(kMASUnknown));
        masStatusesByProduct.put(new String("PN50"),
                masStatusesKeys.get(kMASUnknown));

        masStatusesByProduct.put(new String("PN34"), masStatusesKeys.get(kMASCash));
        masStatusesByProduct.put(new String("PN35"), masStatusesKeys.get(kMASCash));

        // medically needy
        masStatusesByProduct.put(new String("PN45"),
                masStatusesKeys.get(kMASMedicallyNeedy));
        masStatusesByProduct.put(new String("PN46"),
                masStatusesKeys.get(kMASMedicallyNeedy));
        masStatusesByProduct.put(new String("PN47"),
                masStatusesKeys.get(kMASMedicallyNeedy));
        masStatusesByProduct.put(new String("PN48"),
                masStatusesKeys.get(kMASMedicallyNeedy));

        // poverty related
        masStatusesByProduct.put(new String("PN36"),
                masStatusesKeys.get(kMASPoverty));
        masStatusesByProduct.put(new String("PN37"),
                masStatusesKeys.get(kMASPoverty));
        masStatusesByProduct.put(new String("PN38"),
                masStatusesKeys.get(kMASPoverty));
        masStatusesByProduct.put(new String("PN40"),
                masStatusesKeys.get(kMASPoverty));
        masStatusesByProduct.put(new String("PN41"),
                masStatusesKeys.get(kMASPoverty));
        masStatusesByProduct.put(new String("PN70"),
                masStatusesKeys.get(kMASPoverty));
        masStatusesByProduct.put(new String("PN71"),
                masStatusesKeys.get(kMASPoverty));

        // other
        masStatusesByProduct
        .put(new String("PN44"), masStatusesKeys.get(kMASOther));
        masStatusesByProduct
        .put(new String("PN57"), masStatusesKeys.get(kMASOther));
        masStatusesByProduct
        .put(new String("PN42"), masStatusesKeys.get(kMASOther));
        masStatusesByProduct
        .put(new String("PN55"), masStatusesKeys.get(kMASOther));
        masStatusesByProduct
        .put(new String("PN43"), masStatusesKeys.get(kMASOther));
        masStatusesByProduct
        .put(new String("PN58"), masStatusesKeys.get(kMASOther));
        masStatusesByProduct
        .put(new String("PN73"), masStatusesKeys.get(kMASOther));
        masStatusesByProduct
        .put(new String("PN53"), masStatusesKeys.get(kMASOther));
        masStatusesByProduct
        .put(new String("PN56"), masStatusesKeys.get(kMASOther));
        masStatusesByProduct
        .put(new String("PN60"), masStatusesKeys.get(kMASOther));
        masStatusesByProduct
        .put(new String("PN62"), masStatusesKeys.get(kMASOther));

        // waiver
        masStatusesByProduct.put(new String("PN65"),
                masStatusesKeys.get(kMASWaiver));
        masStatusesByProduct.put(new String("PN74"),
                masStatusesKeys.get(kMASWaiver));
        masStatusesByProduct.put(new String("PN66"),
                masStatusesKeys.get(kMASWaiver));
        masStatusesByProduct.put(new String("PN75"),
                masStatusesKeys.get(kMASWaiver));
        masStatusesByProduct.put(new String("PN79"),
                masStatusesKeys.get(kMASWaiver));
        masStatusesByProduct.put(new String("PN76"),
                masStatusesKeys.get(kMASWaiver));
        masStatusesByProduct.put(new String("PN64"),
                masStatusesKeys.get(kMASWaiver));
        masStatusesByProduct.put(new String("PN69"),
                masStatusesKeys.get(kMASWaiver));
        masStatusesByProduct.put(new String("PN49"),
                masStatusesKeys.get(kMASWaiver));
        masStatusesByProduct.put(new String("PN68"),
                masStatusesKeys.get(kMASWaiver));
    }

    /**
     * Sets federal status values.
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl#linkReciepientToEvidence(String)
     * @since 6.0 SP2
     */

    @Deprecated
    private BenefitEvidence calculateHouseholdAssistanceStatus(
            final Recipient inRecipient) throws SQLException {
        MedicalAssistance assistanceStatus = null;
        BenefitEvidence benefitEvidence = null;

        if (kClassicFoodProgramCode.equalsIgnoreCase(inRecipient.getProgramCode())) {
            final StringBuffer assistanceProductTypes = new StringBuffer(
            "BT12 BT8 BT24 BT6");

            final List benefits = findBenefitRecord(inRecipient);
            final Iterator iterator = benefits.iterator();

            while (iterator.hasNext()) {
                benefitEvidence = (BenefitEvidence) iterator.next();
                if (benefitEvidence != null
                        && assistanceProductTypes.indexOf(benefitEvidence.getType()) == kUndefinedKey) {
                    // public assistance
                    assistanceStatus = (MedicalAssistance) houseHoldAssistanceStatusKeys
                    .get(kPublicAssiatanceKey);
                }
            }

            if (assistanceStatus == null) {
                assistanceStatus = (MedicalAssistance) houseHoldAssistanceStatusKeys
                .get(kNonPublicAssiatanceKey);

            }

            inRecipient.setAssistanceStatus(assistanceStatus);

        } else {
            assistanceStatus = (MedicalAssistance) houseHoldAssistanceStatusKeys
            .get(kUnDefinedStatusIndex);
            inRecipient.setAssistanceStatus(assistanceStatus);
        }
        return benefitEvidence;

    }

    /**
     * Is a recipient a dual eligible.
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl#linkReciepientToEvidence(String)
     * @since 6.0 SP2
     */

    @Deprecated
    private void calculateDualEligibles(final Recipient inRecipient) {

        Long dualKey = new Long(kUndefinedKey);

        if (kClassicMedicalProgramCode.equalsIgnoreCase(inRecipient
                .getProgramCode())) {
            // the dual key
            Long hasDualKey = null;
            try {
                // find the key for this product
                hasDualKey = findLookUpKey(readDualKeyForProduct,
                        inRecipient.getProductCode());
                // if the product is not part of a dual product award
                // then find the right key for the not dual product code value
                if (hasDualKey == null) {
                    hasDualKey = findLookUpKey(readDualKeyNotDualProduct,
                            readDualKeyNotDualProductCode);
                }
            } catch (final SQLException e) {
                // ignore, the SQL is valid
                System.out.println("calculateDualEligibles:" + e.getMessage());
            }

            if (hasDualKey != null) {
                dualKey = hasDualKey;
            }
        }

        final MedicalAssistance dualEligibleKey = new MedicalAssistance(
                dualKey.intValue());
        inRecipient.setDualEligible(dualEligibleKey);

    }

    /**
     * Associates products to federal codes.
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl#linkReciepientToEvidence(String)
     * @since 6.0 SP2
     */

    @Deprecated
    private void initializeDualEligibleCodes() {
        dualEligiblesByProduct = new HashMap();
        MedicaidDualEligibles dualEligibles = (MedicaidDualEligibles) dualEligiblesStatusKeys
        .get(kMedicaidQI1);
        dualEligiblesByProduct.put("PN38", dualEligibles);

        dualEligibles = (MedicaidDualEligibles) dualEligiblesStatusKeys
        .get(kMedicaidQDWI);
        dualEligiblesByProduct.put("PN39", dualEligibles);

        dualEligibles = (MedicaidDualEligibles) dualEligiblesStatusKeys
        .get(kMedicaidSLMB);
        // and no other medicaid product
        dualEligiblesByProduct.put("PN37", dualEligibles);

        dualEligibles = (MedicaidDualEligibles) dualEligiblesStatusKeys
        .get(kMedicaidQMB);
        // and another ?
        dualEligiblesByProduct.put("PN36", dualEligibles);

    }

    /*
     * Federal Status processing.
     * 
     * @deprecated
     * 
     * @see
     * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * 
     * @since 6.0 SP2
     */
    @Deprecated
    private void calculateMASAndBOE(final Recipient inRecipient) {

        final StringBuffer masDualEligibleProductTypes = new StringBuffer("PN36 PN37");
        MedicalAssistance masValue = null;
        BasisOfEligibilityStatus boeValue = null;

        // set the MAS and BOE values
        if (kClassicMedicalProgramCode.equalsIgnoreCase(inRecipient
                .getProgramCode())
                && masDualEligibleProductTypes.indexOf(inRecipient.getProductCode()) == kUndefinedKey) {

            boeValue = (BasisOfEligibilityStatus) boeStatusesByProduct
            .get(inRecipient.getProductCode());

            // if we have not found a basis of eligibility status for a product code
            // without age constraints or adult constraints then
            // try and find a basis of eligibility for aged and blind first
            // and finally for adult/child if not aged of blind
            if (boeValue == null && inRecipient.getAge() >= 65) {
                // if we cant find the by product, check the for aged
                // aged only if over 65 with the product types
                final BasisOfEligibilityStatus ageConstraint = ((BasisOfEligibilityStatus) boeStatusesKeys
                        .get(kBOEAged)).getOver65Object();
                boeValue = (BasisOfEligibilityStatus) boeStatusesByProduct
                .get(ageConstraint.hashKey(inRecipient.getProductCode()));
            } else if (boeValue == null && inRecipient.getAge() < 65) {
                // if we cant find the by product, check the for adult and
                // child based product
                final BasisOfEligibilityStatus ageConstraint = ((BasisOfEligibilityStatus) boeStatusesKeys
                        .get(kBOEBlind)).getOver65Object();
                boeValue = (BasisOfEligibilityStatus) boeStatusesByProduct
                .get(ageConstraint.hashKey(inRecipient.getProductCode()));

            }

            if (boeValue == null && !inRecipient.isAdult()) {
                final BasisOfEligibilityStatus adultConstraint = ((BasisOfEligibilityStatus) boeStatusesKeys
                        .get(kBOEChildren)).getChildObject();
                boeValue = (BasisOfEligibilityStatus) boeStatusesByProduct
                .get(adultConstraint.hashKey(inRecipient.getProductCode()));
            } else if (boeValue == null && inRecipient.isAdult()) {
                final BasisOfEligibilityStatus adultConstraint = ((BasisOfEligibilityStatus) boeStatusesKeys
                        .get(kBOEAdult)).getAdultObject();
                boeValue = (BasisOfEligibilityStatus) boeStatusesByProduct
                .get(adultConstraint.hashKey(inRecipient.getProductCode()));

            }

            masValue = (MedicalAssistance) masStatusesByProduct.get(inRecipient
                    .getProductCode());

        }
        // if a recipient is eligible for one of the dual eligible products
        // they will also receive a further product, only calculate
        // MAS values for non dual eligible product types
        if (masValue == null) {
            masValue = (MedicalAssistance) masStatusesKeys.get(kUnDefinedStatusIndex);
        }
        if (boeValue == null) {
            boeValue = (BasisOfEligibilityStatus) boeStatusesKeys
            .get(kUnDefinedStatusIndex);
        }

        inRecipient.setMas(masValue);
        inRecipient.setBoe(boeValue);
    }

    /*
     * Federal Status processing.
     * 
     * @deprecated
     * 
     * @see
     * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * 
     * @since 6.0 SP2
     */
    public Iterator getChildSupportEnforcementKeys() {
        return childSupportEnforcementKeys.iterator();
    }

    /*
     * Federal Status processing.
     * 
     * @deprecated
     * 
     * @see
     * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * 
     * @since 6.0 SP2
     */
    @Deprecated
    public Iterator getFederalBenefitKeys() {
        return fedBenefitGroupKeys.iterator();
    }

    /*
     * Federal Status processing.
     * 
     * @deprecated
     * 
     * @see
     * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * 
     * @since 6.0 SP2
     */
    @Deprecated
    public Iterator getFederalSanctionsKeys() {
        return federalSanctionsKeys.iterator();
    }

    /*
     * Federal Status processing.
     * 
     * @deprecated
     * 
     * @see
     * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * 
     * @since 6.0 SP2
     */
    @Deprecated
    public Iterator getHousingKeys() {
        return housingKeys.iterator();
    }

    /*
     * Federal Status processing.
     * 
     * @deprecated
     * 
     * @see
     * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * 
     * @since 6.0 SP2
     */
    @Deprecated
    public Iterator getEmploymentStatusKeys() {
        return employmentStatusKeys.iterator();
    }

    /*
     * Federal Status processing.
     * 
     * @deprecated
     * 
     * @see
     * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * 
     * @since 6.0 SP2
     */
    @Deprecated
    public Iterator getEdicationLevelKeys() {
        return educationLevelKeys.iterator();
    }

    /*
     * Federal Status processing.
     * 
     * @deprecated
     * 
     * @see
     * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * 
     * @since 6.0 SP2
     */
    @Deprecated
    public Iterator getMasKeys() {
        return masStatusesKeys.iterator();
    }

    /*
     * Returns BOE keys.
     * 
     * @deprecated
     * 
     * @see
     * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * 
     * @since 6.0 SP2
     */
    public Iterator getBoeKeys() {
        return boeStatusesKeys.iterator();
    }

    /*
     * @deprecated
     * 
     * @see
     * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * 
     * @since 6.0 SP2
     */
    public Iterator getDualEligibleKeys() {
        return dualEligiblesStatusKeys.iterator();
    }

    /*
     * Federal Status processing.
     * 
     * @deprecated
     * 
     * @see
     * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * 
     * @since 6.0 SP2
     */
    @Deprecated
    public Iterator getHouseHoldAssistanceKeys() {
        return houseHoldAssistanceStatusKeys.iterator();
    }

    private void initializeUnEarnedIncomeCodes() {
        unearnedIncomeByProduct = new HashMap();
        MedicalAssistance category = (MedicalAssistance) unEarnedIncomeKeys
        .get(kUnEarnedIncomeSocialSecurityKey);

        unearnedIncomeByProduct.put("BT38", category);
        unearnedIncomeByProduct.put("BT39", category);
        unearnedIncomeByProduct.put("BT340", category);
        unearnedIncomeByProduct.put("BT41", category);
        unearnedIncomeByProduct.put("BT18", category);

        category = (MedicalAssistance) unEarnedIncomeKeys
        .get(kUnEarnedIncomeSSIKey);

        unearnedIncomeByProduct.put("BT6", category);
        unearnedIncomeByProduct.put("BT23", category);

        category = (MedicalAssistance) unEarnedIncomeKeys
        .get(kUnEarnedIncomeWorkersCompKey);
        unearnedIncomeByProduct.put("BT51", category);

        // all other rows from the benefit table go under the Other category
        // if (kUnEarnedIncomeOtherKey == 0) {
        // do nothing
        // }

    }

    /*
     * Federal Status processing.
     * 
     * @deprecated
     * 
     * @see
     * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * 
     * @since 6.0 SP2
     */
    @Deprecated
    public Iterator getUnEarnedIncomeKeys() {
        return unEarnedIncomeKeys.iterator();
    }

    /**
     * Associate a recipient to the evidence used in eligibility. This process
     * executes against the recipient table and any evidence table(s).
     * 
     * Evidence is only associated once to a recipient even through there may be
     * many evidence records that allow eligibility.
     * 
     * This is an algorithm based on the rules defined in our requirements
     * specifications for TANF.
     * 
     * @param table
     *          the target table name
     * 
     * @exception SQLException
     *              if a database operation fails
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl#linkReciepientToEvidence(String)
     * @since 6.0 SP2
     */

    @Deprecated
    public void linkReciepientToEvidence(final String table) throws SQLException {
        Recipient recipient = null;
        // if an SQL statement failed
        boolean failed = false;

        // the database transaction
        Transaction transaction = null;
        // statement to read recipient records
        // statement to update recipient records
        PreparedStatement updateRecipients = null;
        // statement to insert evidence link records
        PreparedStatement insertEvidenceLinks = null;
        int recipientRecordsProcessed = 0;
        int evidenLinkRecords = 0;

        try {
            // start a transaction
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            // create the statement to update the recipient records
            if (updateRecipients == null) {
                updateRecipients = connection.prepareStatement(updateRecipient);
            }

            if (insertEvidenceLinks == null) {
                insertEvidenceLinks = connection.prepareStatement(insertEvidenceLink);
            }

            // calculate data to update case recipient columns
            calculateReciepientDetails(recipient);

            // update the recipient table, this method is depreciated, do not use.
            recipient = new Recipient(null);
            updateRecipients.setLong(1, recipient.getAge());
            updateRecipients.setString(2, recipient.getAdultIndicator());
            // set the processed flag
            updateRecipients.setString(3, kYes);
            updateRecipients.setString(4, recipient.getQualifiedAlienIndicator());
            updateRecipients.setString(5, recipient.getParentIndicator());
            updateRecipients.setLong(6, recipient.getMas()
                    .getMaintenanceAssistenceStatusKey());
            updateRecipients.setLong(7, recipient.getBoe()
                    .getMaintenanceAssistenceStatusKey());
            updateRecipients.setLong(8, recipient.getDualEligible()
                    .getMaintenanceAssistenceStatusKey());
            updateRecipients.setLong(9, recipient.getAssistanceStatus()
                    .getMaintenanceAssistenceStatusKey());

            updateRecipients.setFloat(11, recipient.getTotalUnearnedIncome());
            updateRecipients.setFloat(12, recipient.getTotalChildSupportIncome());
            updateRecipients.setFloat(13, recipient.getCashResource());
            updateRecipients.setFloat(14, recipient.getTotalearnedIncome());

            final String hasSanctions = recipient.hasSanctions() == true ? "Y" : "N";
            updateRecipients.setString(15, hasSanctions);

            updateRecipients.setInt(16, recipient.getSubsizedHousingKeyKey());
            updateRecipients.setInt(17, recipient.getChildEnforcementKey());
            updateRecipients.setInt(18,
                    (int) (recipient.getEmploymentStatusKey() == null ? -1 : recipient
                            .getEmploymentStatusKey().getKey()));
            updateRecipients.setInt(19, recipient.getEducationalLevelKey());

            updateRecipients.setLong(16, recipient.getRecipientID());

            int rowsUpdated = updateRecipients.executeUpdate();
            recipientRecordsProcessed++;
            if (rowsUpdated != 1) {
                System.out.println("Warning: " + rowsUpdated
                        + " row(s) updated in recipient table.");
            }

            // update the evidence link table with our best guess as
            // as defined in our requirement specification as
            // to what evidence resulted in an eligible recipient
            final List relatedEvidence = recipient.getRelatedEvidence().getAllEvidence();
            Evidence evidence;
            for (int i = 0; i < relatedEvidence.size(); i++) {
                evidence = (Evidence) relatedEvidence.get(i);

                insertEvidenceLinks.setLong(1, recipient.recipientID);
                insertEvidenceLinks.setLong(2, evidence.getKey());
                insertEvidenceLinks.setString(3, evidence.getEvidenceType());
                insertEvidenceLinks.setTimestamp(4, recipient.getLastWritten());

                try {
                    rowsUpdated = insertEvidenceLinks.executeUpdate();
                    if (rowsUpdated != 1) {
                        System.out.println("Warning: " + rowsUpdated
                                + " row(s) inserted into evidence link table.");
                    }
                    evidenLinkRecords++;
                } catch (final SQLException e) {
                    // if a recipients record processed flag is reset back
                    // to unprocessed, some inserts may break the unique
                    // constraint
                    // that a recipient for a case can only have one
                    // evidence
                    // record per evidence type (.e.g. alien evidence)

                    // e.g if there are 4 evidence records, and 3 have
                    // already
                    // been inserted, allow the fourth record to be inserted
                    // on the
                    // second execution of this transform for a recipient
                    // record
                    System.out
                    .println("Warning:linkReciepientToEvidence:insert evidence link:"
                            + e);
                }
            }

            if (updateRecipients != null) {
                updateRecipients.close();
            }

            // PostProcessFactory.newInstance().executePostProcess("");

            System.out.println("linkReciepientToEvidence: "
                    + recipientRecordsProcessed + " recipient records updated");
            System.out.println("linkReciepientToEvidence: " + evidenLinkRecords
                    + " evidence link records inserted");
        } catch (final Exception e) {
            e.printStackTrace();
            System.out.println("linkReciepientToEvidence: caught exception "
                    + e.getMessage());
            failed = true;
            throw new SQLException("linkReciepientToEvidence:" + e.getMessage());
        } finally {

            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                    System.out
                    .println("linkReciepientToEvidence:failed, transaction rolled back");
                } else {
                    // commit the changes
                    transaction.commit();
                    System.out
                    .println("linkReciepientToEvidence:transaction commited, processed ");
                }
            }
        }
    }

    /**
     * Returns the first column, a long value, filtering on a CODE column
     * 
     * @param inSQL
     *          the SQL statement which return the primary key column for a given
     *          code value.
     * @param inCode
     *          the code value to search
     * 
     * @return Long null if no record was found or the primary key
     * 
     * @exception SQLException
     *              if a database operation fails
     * 
     */

    public Long findLookUpKey(final String inSQL, final String inCode)
    throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;
        Long key = null;

        try {
            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();
            statement = connection.prepareStatement(inSQL);
            // set parameters
            statement.setString(1, inCode);
            final ResultSet statuses = statement.executeQuery();

            if (statuses.next()) {
                // get the primary key for the table
                key = new Long(statuses.getLong(1));
            }
            // return the key for this code
            return key;
        } catch (final Exception e) {
            System.out.println("findLookUpKey Error: " + e.getMessage() + inSQL);
            throw new SQLException("findLookUpKey Error: " + e.getMessage() + inSQL);
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    /**
     * Returns a person history key. If a persons start date is less than the end
     * date this method returns the most recent record to end date
     * 
     * If the person start date is after the end date, then the most recent person
     * record after the event end date is returned.
     * 
     * @param inConcernRoleID
     *          the concern role identity.
     * @param inStartDate
     *          the start date
     * @param inEndDate
     *          the end date
     * @return long a person key for a point in time
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    public long findPersonHistoryKey(final long inConcernRoleID, final Date inStartDate,
            final Date inEndDate) throws SQLException {
        final int numberOfSearches = 2;
        return findPersonHistoryKey(inConcernRoleID, inStartDate, inEndDate,
                numberOfSearches);
    }

    /**
     * Returns a person history key. If a persons start date is less than the end
     * date this method returns the most recent record to end date
     * 
     * If the person start date is after the end date, then the most recent person
     * record after the event end date is returned.
     * 
     * Two searches are only executed .
     * 
     * @param inConcernRoleID
     *          the concern role identity.
     * @param inStartDate
     *          the start date
     * @param inEndDate
     *          the end date
     * @return long a person key for a point in time
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    private long findPersonHistoryKey(final long inConcernRoleID, Date inStartDate,
            Date inEndDate, int inRecursiveDepth) throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;
        long personHistoryID = kUndefinedKey;

        if (inRecursiveDepth-- <= 0) {
            return personHistoryID;
        }

        // do we have a from date
        if (inStartDate == null) {
            inStartDate = new Date(System.currentTimeMillis());
            System.out
            .println("findPersonHistoryKey:start date is null setting to current date");
        }

        // id we have a to Date
        if (inEndDate == null) {
            inEndDate = new Date(System.currentTimeMillis());
            System.out
            .println("findPersonHistoryKey:start date is null setting to current date");
        }

        try {
            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection
            .prepareStatement(readPersonHistoryKeyMostRecentAsOfEventDate);

            statement.setLong(1, inConcernRoleID);
            statement.setDate(2, inEndDate);
            statement.setDate(3, inStartDate);
            final ResultSet persons = statement.executeQuery();

            if (persons.next()) {
                // the results are ordered by start date descending
                // take the most recent
                personHistoryID = persons.getLong(1);
                System.out.println("Found person history record in window (depth= "
                        + inRecursiveDepth + ")" + personHistoryID);
            }
            if (personHistoryID == kUndefinedKey) {
                // if we cannot find the person in the event window
                // i.e. the person start date is after the event end date
                // then find a person record that existed between the
                // event end date and now.
                System.out
                .println("Did not find any person history record for initial window (depth= "
                        + inRecursiveDepth
                        + ")"
                        + "concernroleid="
                        + inConcernRoleID
                        + " and time window where startdate="
                        + inStartDate
                        + ", endate=" + inEndDate);
                // prepare the parameters for the next search
                final Date newStartDate = new Date(System.currentTimeMillis());
                inStartDate = inEndDate;
                inEndDate = newStartDate;
                System.out.println("Searching for concernroleid =" + inConcernRoleID
                        + " for time window where startdate=" + inStartDate + ", endate="
                        + inEndDate);

                personHistoryID = findPersonHistoryKey(inConcernRoleID, inStartDate,
                        inEndDate, inRecursiveDepth);
                System.out.println("Returning with id=" + personHistoryID);
            }
            return personHistoryID;
        } catch (final Exception e) {
            System.out.println("findPersonHistoryKey Error: " + e.getMessage()
                    + readPersonHistoryKeyMostRecentAsOfEventDate);
            throw new SQLException("findPersonHistoryKey Error: " + e.getMessage()
                    + readPersonHistoryKeyMostRecentAsOfEventDate);
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
            if (transaction != null && !transaction.isClientManagedTransaction()) {
                transaction.commit();
                System.out
                .println("CentralDWStaticDataTransformImpl:transaction commited, processed ");

            }
        }

    }

    /**
     * Returns a sanction description key
     * 
     * @param inSanctionCode
     *          the sanction code. the end date
     * @return long the sanction key
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    public long getSanctionTypeKey(final String inSanctionCode)
    throws SQLException {

        final StringBuffer kWORKREQUIREMENTSSANCTIONS = new StringBuffer("SR12 SR8");
        final StringBuffer kTeenParent = new StringBuffer("SR9");
        final StringBuffer kNoCoop = new StringBuffer("SR1");

        final StringBuffer kFailureToComply = new StringBuffer("SR4 SR6 SR7 SR8");
        final StringBuffer kOther = new StringBuffer(
        "SR2 SR3 SR5 SR10 SR10 SR11 SR13 SR14 SR15");

        int sanctionKey = kUndefinedKey;

        if (kWORKREQUIREMENTSSANCTIONS.indexOf(inSanctionCode) != kUndefinedKey) {
            sanctionKey = kSanctionsWORKREQUIREMENTSSANCTIONKey;
        } else if (kTeenParent.indexOf(inSanctionCode) != kUndefinedKey) {
            sanctionKey = kSanctionsSANCTIONFORTEENKey;
        } else if (kNoCoop.indexOf(inSanctionCode) != kUndefinedKey) {
            sanctionKey = kSanctionsNONCOOPERATIONKey;
        } else if (kFailureToComply.indexOf(inSanctionCode) != kUndefinedKey) {
            sanctionKey = kSanctionsFAILURETOCOMPLYKey;
        } else if (kOther.indexOf(inSanctionCode) != kUndefinedKey) {
            sanctionKey = kSanctionsOTHERSANCTIONKey;
        }

        return sanctionKey;
    }

    /**
     * Returns a federal group description key
     * 
     * @param inBenefitCode
     *          the benefit code
     * @return long the federal status benefit key
     * 
     * @exception SQLException
     *              if a database operation fails
     * @deprecated FederalProgramsTransformsImpl.calculateFederalBenefitTypeStatus
     */
    @Deprecated
    public long getFederalBenefitTypeKey(final String inBenefitCode)
    throws SQLException {

        final StringBuffer kOASDI = new StringBuffer("BT38 BT49   BT40   BT41 BT18");
        final StringBuffer kDisabilityStatus = new StringBuffer(
        "BT51 BT15 BT12 BT51 BT15 BT42 BT43 BT45 BT46 BT47 BT55");
        final StringBuffer kSSI = new StringBuffer("BT6 BT23");

        int fedBenefitKey = kUndefinedKey;

        if (kOASDI.indexOf(inBenefitCode) != kUndefinedKey) {
            fedBenefitKey = kFederalBenefitOASDI;
        } else if (kDisabilityStatus.indexOf(inBenefitCode) != kUndefinedKey) {
            fedBenefitKey = kFederalBenefitDisability;
        } else if (kSSI.indexOf(inBenefitCode) != kUndefinedKey) {
            fedBenefitKey = kFederalBenefitSSI;
        }

        return fedBenefitKey;
    }

    // ___________________________________________________________________________
    /**
     * Calculate a persons age using to dates in time. Calculate the youngest age
     * in a monthly frame
     * 
     * @param inStartDate
     *          typically the date of birth
     * @param inEndDate
     *          a point in time
     * @throws java.sql.SQLException
     *           if a database operation failed
     */
    public int calcuateAgeInMonthlyFrame(final Date inStartDate, Date inEndDate)
    throws SQLException {

        if (inEndDate == null) {
            inEndDate = new Date(System.currentTimeMillis());
        }
        // set the end time to the first day of the month
        // calculate the youngest age in a monthly frame
        final Calendar to = Calendar.getInstance();
        to.setTime(inEndDate);
        to.set(Calendar.DAY_OF_MONTH, 1);

        return calcuateAge(inStartDate, new Date(to.getTime().getTime()));
    }

    // ___________________________________________________________________________
    /**
     * Calculates number of previous maltreatments for the person who is the
     * victim on an allegation the Algorithm is based on the allegation date and
     * concern role id and the 6 month period read from the config table
     * 
     * @param inAllegationID
     *          the allegation id
     * @param inConcernroleID
     *          the concern role id of the victim
     * @param inAllegationDate
     *          the allegation date
     * 
     * @throws SQLException
     *           if the operation fails
     */
    public int calculatePreviousMaltreatments(final long inAllegationID,
            final long inConcernroleID, final Date inAllegationDate)
    throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;

        Date allegationDate = inAllegationDate;
        int previousMaltreatmentCount = 0;
        final String SQL = "select count(ALG.ALLEGATIONID)"
            + "from dw_allegation ALG,"
            + " dw_algfinding ALGFIND,"
            + " dw_algfindingstatus algfindst,"
            + " dw_allegationrole ALGROLE,"
            + " DW_CASEPARTICIPANTrole casepart,"
            + " dw_PERSONHISTORY PERSONHIST,"
            + " dw_configproperties CONFIG"
            + " where   PERSONHIST.CONCERNROLEID = ? AND"
            + " alg.DWALLEGATIONKEY = algrole.DWALLEGATIONKEY AND"
            + " algfind.DWALLEGATIONKEY = alg.DWALLEGATIONKEY AND"
            + " algfind.DWALGFINDINGSTATUSKEY = algfindst.DWALGFINDINGSTATUSKEY AND"
            + " algfindst.CODE in ('FN1','FN3') AND"
            + " ALGROLE.CASEPARTICIPANTROLEID = CASEPART.CASEPARTICIPANTROLEID AND"
            + " CASEPART.DWPERSONHISTORYID = PERSONHIST.DWPERSONHISTORYID AND"
            + " CONFIG.NAME = 'CEF_ALLEGATION_COUNTBACK_WINDOW' AND "
            + " ALG.ALLEGATIONDATETIME between CONFIG.STARTDATE and CONFIG.ENDDATE AND"
            + " ALG.ALLEGATIONDATETIME between ? and ? ";

        // if null then used an end date of now
        if (allegationDate == null) {
            allegationDate = new Date(System.currentTimeMillis());
            System.out
            .println("calculatePreviousMaltreatments:allegation date is null defaulting to current date");
        }

        final Calendar start = new GregorianCalendar(allegationDate.getYear(),
                allegationDate.getMonth(), allegationDate.getDate());

        // roll backward the month and year if necessary, default is
        // 6 months, read this value from the config table in the next version
        start.add(Calendar.MONTH, -6);

        try {
            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.prepareStatement(SQL);

            statement.setLong(1, inConcernroleID);
            statement.setDate(2, allegationDate);
            statement.setDate(3, new java.sql.Date(start.getTime().getTime()));
            final ResultSet previousMaltreatments = statement.executeQuery();

            if (previousMaltreatments.next()) {
                previousMaltreatmentCount = previousMaltreatments.getInt(1);
                System.out.println("calculatePreviousMaltreatments result from SQL="
                        + previousMaltreatmentCount);
            } else {
                System.out
                .println("calculatePreviousMaltreatments SQL return no rows defaulting to 0");
            }

            System.out.println("calculatePreviousMaltreatments="
                    + previousMaltreatmentCount + " for inAllegationID=" + inAllegationID
                    + " for inConcernroleID=" + inConcernroleID
                    + " for inAllegationDate=" + allegationDate);

        } catch (final Exception e) {
            System.out.println("calculatePreviousMaltreatments Error: "
                    + e.getMessage() + SQL);
            // do not throw an exception, allow test process to catch any
            // missing or bad data.

        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
        return previousMaltreatmentCount;

    }

    // ___________________________________________________________________________
    /**
     * Calculates a persons age using two dates in time.
     * 
     * @param inStartDate
     *          typically the date of birth
     * @param inEndDate
     *          a point in time
     * @throws java.sql.SQLException
     *           if a database operation failed
     */
    public int calcuateAge(final Date inStartDate, final Date inEndDate)
    throws SQLException {

        // do we have a from date
        if (inStartDate == null) {
            // do no throw an exception as KPI's are throwing errors
            // throw new SQLException("calculateAge: start date is null");
            return -1;
        }

        // id we have a to Date
        if (inEndDate == null) {
            // do no throw an exception as KPI's are throwing errors
            // throw new SQLException("calculateAge: end date is null");
            return -1;
        }

        // variables for calculating the difference between the 2 dates
        int diffInYears = 0;
        int diffInWholeMonths = 0;

        // if fromDate is later than toDate throw an exception
        if (inStartDate.after(inEndDate)) {
            // do no throw an exception as RDBMS optimizations is passing in bad
            // dates
            return -1;
            // throw new SQLException("calculateAge: start date is after end date");
        }

        // create calendar objects to represent both dates
        final Calendar fromDate = Calendar.getInstance();
        final Calendar toDate = Calendar.getInstance();

        fromDate.setTime(inStartDate);
        toDate.setTime(inEndDate);

        // Determine the difference in years
        diffInYears = toDate.get(Calendar.YEAR) - fromDate.get(Calendar.YEAR);
        // Determine the difference in months
        diffInWholeMonths = (diffInYears * 12);

        // If the toDate month is earlier in the year than the fromDate month
        if (toDate.get(Calendar.MONTH) < fromDate.get(Calendar.MONTH)) {

            // decrement the number of years by one
            diffInYears--;

            // decrement by the appropriate number of months
            diffInWholeMonths = diffInWholeMonths
            - ((fromDate.get(Calendar.MONTH)) - (toDate.get(Calendar.MONTH)));

            // If the toDate day of the month is before the fromDate day of the
            // month
            // decrement the number of months by one
            if (toDate.get(Calendar.DATE) < fromDate.get(Calendar.DATE)) {
                diffInWholeMonths--;
            }

        }
        // If the toDate month is later in the year than the fromDate month
        if (toDate.get(Calendar.MONTH) > fromDate.get(Calendar.MONTH)) {

            // increment by the appropriate number of months
            diffInWholeMonths = diffInWholeMonths
            + ((toDate.get(Calendar.MONTH)) - (fromDate.get(Calendar.MONTH)));

            // If the toDate day of the month is before the fromDate day of the
            // month
            // decrement the number of months by one
            if (toDate.get(Calendar.DATE) < fromDate.get(Calendar.DATE)) {
                diffInWholeMonths--;
            }
        }

        // If the toDate month is equal to the fromDate month, and the toDate
        // day of
        // the month is before the fromDate day of the month
        if ((toDate.get(Calendar.MONTH) == fromDate.get(Calendar.MONTH))
                && (toDate.get(Calendar.DAY_OF_MONTH) < fromDate
                        .get(Calendar.DAY_OF_MONTH))) {

            // decrement the number of years by one
            diffInYears--;

            // decrement the number of months by one
            diffInWholeMonths--;

        }
        // Do not return negative values
        if (diffInYears < 0) {
            diffInYears = 0;
        }
        if (diffInWholeMonths < 0) {
            diffInWholeMonths = 0;
        }

        // return the details
        return diffInYears;
    }

    /**
     * Returns a race key for ethnic origins.
     * 
     * @param inBlackOrAfrAmerIND
     *          race indicator
     * @param inNatAlaskOrAmerIND
     *          race indicator
     * @param inAsianIND
     *          race indicator
     * @param inNatjAwOrPaisIND
     *          race indicator
     * @param inWhiteOrCaucIND
     *          race indicator
     * 
     * @return int the race key for the indicator parameters
     * 
     * @exception SQLException
     *              if a database operation fails
     */

    public int findRaceKey(final String inBlackOrAfrAmerIND,
            final String inNatAlaskOrAmerIND, final String inAsianIND,
            final String inNatjAwOrPaisIND, final String inWhiteOrCaucIND)
    throws SQLException {

        short numberOfIndicators = 0;
        int raceKey = 0;

        if (inBlackOrAfrAmerIND != null
                && inBlackOrAfrAmerIND.equalsIgnoreCase(kYesNumber)) {
            raceKey = kAFRICANAMERICAN;
            numberOfIndicators++;
        }

        if (inNatAlaskOrAmerIND != null
                && inNatAlaskOrAmerIND.equalsIgnoreCase(kYesNumber)) {
            raceKey = kNATIVEAMERICAN;
            numberOfIndicators++;
        }

        if (inAsianIND != null && inAsianIND.equalsIgnoreCase(kYesNumber)) {
            raceKey = kASIAN;
            numberOfIndicators++;
        }

        if (inNatjAwOrPaisIND != null
                && inNatjAwOrPaisIND.equalsIgnoreCase(kYesNumber)) {
            raceKey = kHAWAIIAN;
            numberOfIndicators++;
        }

        if (inWhiteOrCaucIND != null
                && inWhiteOrCaucIND.equalsIgnoreCase(kYesNumber)) {
            raceKey = kWHITE;
            numberOfIndicators++;
        }

        if (numberOfIndicators > 1) {
            raceKey = kMULTIRACIAL;
        }

        return raceKey;
    }

    /**
     * Returns the record key if a student record existed in the period
     * 
     * @param inRecipient
     *          contains the product case id and participant id
     * @param inSQL
     *          the SQL statement to execute
     * @param inEvidenceType
     *          the evidence type code
     * @param inReadCode
     *          to read an extra code from the SQL statement
     * @return StudentEvidence the record key if a student record existed in the
     *         period
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    public RecordExistsEvidence checkSingleRecordExists(
            final Recipient inRecipient, final String inSQL,
            final String inEvidenceType, final boolean inReadCode)
    throws SQLException {

        final List records = checkMultipleRecordsExist(inRecipient, inSQL,
                inEvidenceType, inReadCode);

        if (records.size() == 0) {
            return null;
        } else {
            return (RecordExistsEvidence) records.get(0);
        }
    }

    /**
     * Returns the record key if a student record existed in the period
     * 
     * @param inRecipient
     *          contains the product case id and participant id
     * @param inSQL
     * @param inEvidenceType
     * @param inReadTypeCode
     * 
     * @return StudentEvidence the record key if a student record existed in the
     *         period
     * 
     * @exception SQLException
     *              if a database operation fails
     * 
     */

    public List checkMultipleRecordsExist(final Recipient inRecipient,
            final String inSQL, final String inEvidenceType,
            final boolean inReadTypeCode) throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;
        Date inEndDate = null;
        RecordExistsEvidence evidence = null;
        final List records = new ArrayList();

        // if null then used an end date of now
        if (inRecipient.getEndDate() == null) {
            inEndDate = new Date(System.currentTimeMillis());
        }

        try {
            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.prepareStatement(inSQL);

            statement.setLong(1, inRecipient.getDwCaseID());
            statement.setLong(2, inRecipient.getDwParticipantID());
            statement.setDate(3, inEndDate);
            statement.setDate(4, inRecipient.getStartDate());
            final ResultSet evidenceRecord = statement.executeQuery();

            while (evidenceRecord.next()) {
                evidence = new RecordExistsEvidence(evidenceRecord.getLong(1),
                        inEvidenceType);

                if (inReadTypeCode) {
                    evidence.setType(evidenceRecord.getString(2));
                }
                records.add(evidence);
                System.out.println("Found  record in period "
                        + inRecipient.getStartDate() + "," + inEndDate);
            }
            if (records.size() == 0) {
                System.out.println("Did not find any  record in period "
                        + inRecipient.getStartDate() + "," + inEndDate + " dwcaseid="
                        + inRecipient.getDwCaseID() + ", dwparticipantid="
                        + inRecipient.getDwParticipantID() + " , recipientid="
                        + inRecipient.getRecipientID());
            }

            return records;
        } catch (final Exception e) {
            System.out.println("checkMultipleRecordsExist Error: " + e.getMessage()
                    + inSQL);
            throw new SQLException("checkMultipleRecordsExist Error: "
                    + e.getMessage() + inSQL);
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    /**
     * Returns the record key if a benefit record existed in the period
     * 
     * @param inRecipient
     *          contains the product case id and participant id
     * 
     * @return BenefitEvidence the record key if a student record existed in the
     *         period
     * 
     * @exception SQLException
     *              if a database operation fails
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * @since 6.0 SP2
     */

    @Deprecated
    public List findBenefitRecord(final Recipient inRecipient)
    throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;
        Date inEndDate = null;
        BenefitEvidence benefitEvidence = null;
        final List benefitRecords = new ArrayList();
        // if null then used an end date of now
        if (inRecipient.getEndDate() == null) {
            inEndDate = new Date(System.currentTimeMillis());
        }

        try {
            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.prepareStatement(readBenefitByDate);

            statement.setLong(1, inRecipient.getDwCaseID());
            statement.setLong(2, inRecipient.getDwParticipantID());
            statement.setDate(3, inEndDate);
            statement.setDate(4, inRecipient.getStartDate());
            final ResultSet benefits = statement.executeQuery();

            while (benefits.next()) {
                benefitEvidence = new BenefitEvidence(benefits.getLong(1),
                        benefits.getString(2), benefits.getFloat(3));
                benefitRecords.add(benefitEvidence);
                System.out.println("Found benefit record in period "
                        + inRecipient.getStartDate() + "," + inEndDate);

            }
            if (benefitRecords.size() == 0) {
                System.out.println("Did not find any benefit record in period "
                        + inRecipient.getStartDate() + "," + inEndDate + " dwcaseid="
                        + inRecipient.getDwCaseID() + ", dwparticipantid="
                        + inRecipient.getDwParticipantID() + " , recipientid="
                        + inRecipient.getRecipientID());
            }
            return benefitRecords;
        } catch (final Exception e) {
            System.out.println("findBenefitRecord Error: " + e.getMessage()
                    + readStudentByDate);
            throw new SQLException("findBenefitRecord Error: " + e.getMessage()
                    + readStudentByDate);
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    /**
     * Returns the HHM evidence if a record existed in the period
     * 
     * @param inRecipient
     *          contains the product case id and participant id
     * 
     * @return HHMEvidence a record if a record existed in the period
     * 
     * @exception SQLException
     *              if a database operation fails
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * @since 6.0 SP2
     */

    @Deprecated
    public HHMEvidence findHouseHoldMemberRecord(final Recipient inRecipient)
    throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;
        Date inEndDate = null;
        HHMEvidence evidence = null;

        // if null then used an end date of now
        if (inRecipient.getEndDate() == null) {
            inEndDate = new Date(System.currentTimeMillis());
        }

        try {
            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.prepareStatement(readHouseHoldMemberByDate);

            statement.setLong(1, inRecipient.getDwCaseID());
            statement.setLong(2, inRecipient.getDwParticipantID());
            statement.setDate(3, inEndDate);
            statement.setDate(4, inRecipient.getStartDate());
            final ResultSet householdMembers = statement.executeQuery();

            if (householdMembers.next()) {
                evidence = new HHMEvidence(householdMembers.getLong(1),
                        householdMembers.getString(2));
                System.out.println("Found HHM record in period "
                        + inRecipient.getStartDate() + "," + inEndDate);
            } else {
                System.out.println("Did not find any HHM record in period "
                        + inRecipient.getStartDate() + "," + inEndDate + " dwcaseid="
                        + inRecipient.getDwCaseID() + ", dwparticipantid="
                        + inRecipient.getDwParticipantID() + " , recipientid="
                        + inRecipient.getRecipientID());
            }
            return evidence;
        } catch (final Exception e) {
            System.out.println("findHHMRecord Error: " + e.getMessage()
                    + readHouseHoldMemberByDate);
            throw new SQLException("findHHMRecord Error: " + e.getMessage()
                    + readHouseHoldMemberByDate);
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    /**
     * Returns the record key if a earned income record existed in the period
     * 
     * @param inRecipient
     *          contains the product case id and participant id
     * @param inEvidenceName
     *          the evidence type code
     * @param inSQL
     *          the SQL to execute
     * @return UnEarnedIncomeEvidence the record key if a student record existed
     *         in the period
     * 
     * @exception SQLException
     *              if a database operation fails
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * @since 6.0 SP2
     */

    @Deprecated
    public List findIncomeRecord(final Recipient inRecipient,
            final String inEvidenceName, final String inSQL) throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;
        Date inEndDate = null;
        IncomeEvidence unearnedIncomeEvidence = null;
        final List list = new ArrayList();
        float totalIncome = 0;
        final StringBuffer cashResources = new StringBuffer("LR3 LR4 LR5 LR18 ");

        // in order to find a person record if the case groups end date is
        // null then used an end date of now
        if (inRecipient.getEndDate() == null) {
            inEndDate = new Date(System.currentTimeMillis());
        }

        try {
            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.prepareStatement(inSQL);

            statement.setLong(1, inRecipient.getDwCaseID());
            statement.setLong(2, inRecipient.getDwParticipantID());
            statement.setDate(3, inEndDate);
            statement.setDate(4, inRecipient.getStartDate());
            final ResultSet unearnedIncomeRecords = statement.executeQuery();

            // there may be 0 or more unearned income record in the period
            //
            while (unearnedIncomeRecords.next()) {

                unearnedIncomeEvidence = new IncomeEvidence(
                        unearnedIncomeRecords.getLong(1),
                        unearnedIncomeRecords.getString(2),
                        unearnedIncomeRecords.getFloat(3), inEvidenceName);
                System.out.println("Found IncomeEvidence record in period "
                        + inEvidenceName + ":" + inRecipient.getStartDate() + ","
                        + inEndDate);
                list.add(unearnedIncomeEvidence);

                // total income for a month is the amount times frequency
                // getting clarification on what values frequency can have
                // amend this total when we get frequency data

                if (IncomeEvidence.kLiquidResourceEvidenceName
                        .equalsIgnoreCase(inEvidenceName)) {
                    final String resourceType = unearnedIncomeEvidence.getType();

                    if (resourceType != null && cashResources.indexOf(resourceType) != -1) {
                        totalIncome += unearnedIncomeEvidence.getIncomeAmount();
                    }

                } else {
                    totalIncome += unearnedIncomeEvidence.getIncomeAmount();
                }
            }

            if (IncomeEvidence.kAbParChildSupportEvidenceName
                    .equalsIgnoreCase(inEvidenceName)) {
                inRecipient.incrementTotalChildSupportIncome(totalIncome);
            } else if (IncomeEvidence.kEarnedIncomeEvidenceName
                    .equalsIgnoreCase(inEvidenceName)) {
                inRecipient.incrementTotalEarnedIncome(totalIncome);
            } else if (IncomeEvidence.kUnEarnedIncomeEvidenceName
                    .equalsIgnoreCase(inEvidenceName)) {
                inRecipient.incrementTotalUnearnedIncome(totalIncome);
            } else if (IncomeEvidence.kUnEarnedIncomeEvidenceName
                    .equalsIgnoreCase(inEvidenceName)) {
                inRecipient.incrementTotalUnearnedIncome(totalIncome);
            } else if (IncomeEvidence.kLiquidResourceEvidenceName
                    .equalsIgnoreCase(inEvidenceName)) {
                inRecipient.incrementCashResources(totalIncome);
            }

            if (list.size() == 0) {
                System.out
                .println("Did not find any Found IncomeEvidence record in period "
                        + inEvidenceName + ":" + inRecipient.getStartDate() + ","
                        + inEndDate + " dwcaseid=" + inRecipient.getDwCaseID()
                        + ", dwparticipantid=" + inRecipient.getDwParticipantID()
                        + " , recipientid=" + inRecipient.getRecipientID());
            }

            return list;
        } catch (final Exception e) {
            System.out.println(" IncomeEvidence Error: " + e.getMessage() + inSQL);
            throw new SQLException("IncomeEvidence Error: " + e.getMessage() + inSQL);
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    /**
     * Returns the record key if a student record existed in the period
     * 
     * @param inRecipient
     *          contains the product case id and participant id
     * 
     * @return AlienEvidence the record key if a student record existed in the
     *         period
     * 
     * @exception SQLException
     *              if a database operation fails
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * @since 6.0 SP2
     */

    @Deprecated
    public AlienEvidence findAlienRecord(final Recipient inRecipient)
    throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;
        Date inEndDate = null;
        AlienEvidence alienEvidence = null;

        // in order to find a person record if the case groups end date is
        // null then used an end date of now
        if (inRecipient.getEndDate() == null) {
            inEndDate = new Date(System.currentTimeMillis());
        }

        try {
            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.prepareStatement(readAlienByDate);

            statement.setLong(1, inRecipient.getDwCaseID());
            statement.setLong(2, inRecipient.getDwParticipantID());
            statement.setDate(3, inEndDate);
            statement.setDate(4, inRecipient.getStartDate());
            final ResultSet aliens = statement.executeQuery();

            if (aliens.next()) {
                alienEvidence = new AlienEvidence(aliens.getLong(1),
                        aliens.getString(2));
                System.out.println("Found alien record in period "
                        + inRecipient.getStartDate() + "," + inEndDate);
            } else {
                System.out.println("Did not find any alien record in period "
                        + inRecipient.getStartDate() + "," + inEndDate + " dwcaseid="
                        + inRecipient.getDwCaseID() + ", dwparticipantid="
                        + inRecipient.getDwParticipantID() + " , recipientid="
                        + inRecipient.getRecipientID());
            }
            return alienEvidence;
        } catch (final Exception e) {
            System.out.println("findAlienRecord Error: " + e.getMessage()
                    + readAlienByDate);
            throw new SQLException("findAlienRecord Error: " + e.getMessage()
                    + readAlienByDate);
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    /**
     * returns a relationship object if the recipient was a parent with the period
     * of time.
     * 
     * Is the recipient a parent?, needed for reporting on 2 parent families In
     * future releases if the recipient is a child we need check if he/she has
     * parents, not just if the recipient is a parent
     * 
     * @param inRecipient
     *          contains the product case identity, participant identity and time
     *          frame
     * 
     * @return HouseHoldRelationshipEvidence a record if a recipient was a parent
     *         in the period, null otherwise
     * 
     * @exception SQLException
     *              if a database operation fails
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * @since 6.0 SP2
     */

    @Deprecated
    public HouseHoldRelationshipEvidence isParent(final Recipient inRecipient)
    throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;
        Date inEndDate = null;
        int recordsForConcern = 0;
        HouseHoldRelationshipEvidence houseHoldRelationshipEvidence = null;

        // IF null then use an end date of now
        if (inRecipient.getEndDate() == null) {
            inEndDate = new Date(System.currentTimeMillis());
        }

        try {
            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.prepareStatement(readHouseholdRoleByDate);

            statement.setLong(1, inRecipient.getDwCaseID());
            statement.setLong(2, inRecipient.getDwParticipantID());
            statement.setDate(3, inEndDate);
            statement.setDate(4, inRecipient.getStartDate());
            final ResultSet houseHold = statement.executeQuery();
            long key = 0;
            String role = null;
            boolean isParent = false;
            while (houseHold.next()) {

                key = houseHold.getLong(1);
                role = houseHold.getString(2);
                isParent = false;
                recordsForConcern++;

                /*
                 * if (kParent.compareToIgnoreCase(role) == 0) { isParent = true;
                 * houseHoldRelationshipEvidence = new HouseHoldRelationshipEvidence(
                 * key, role, isParent); break; } else
                 */
                // if the person has a relationship to a child then person is a
                // parent
                if (kParent.compareToIgnoreCase(role) == 0) {
                    isParent = true;
                    houseHoldRelationshipEvidence = new HouseHoldRelationshipEvidence(
                            key, kParent, isParent);
                    break;

                }
            }

            if (houseHoldRelationshipEvidence != null) {
                System.out.println("Found relationship record to a " + role + ","
                        + inRecipient.getStartDate() + "," + inEndDate);
            } else {
                System.out.println(" Did not find " + recordsForConcern
                        + " relationship record(s) in period " + inRecipient.getStartDate()
                        + "," + inEndDate + " dwcaseid=" + inRecipient.getDwCaseID()
                        + ", dwparticipantid=" + inRecipient.getDwParticipantID()
                        + " , recipientid=" + inRecipient.getRecipientID());
            }

            return houseHoldRelationshipEvidence;
        } catch (final Exception e) {
            System.out.println("findStudentRecord Error: " + e.getMessage()
                    + readHouseholdRoleByDate);
            throw new SQLException("findStudentRecord Error: " + e.getMessage()
                    + readHouseholdRoleByDate);
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    /**
     * Associate a recipient to the evidence used in eligibility. This process
     * executes against the recipient table and any evidence table(s).
     * 
     * Evidence is only associated once to a recipient even through there may be
     * many evidence records that allow eligibility.
     * 
     * This is an algorithm based on the rules defined in our requirements
     * specifications for TANF.
     * 
     * @param inRecipient
     *          the person and time line to process
     * 
     * @exception SQLException
     *              if a database operation fails
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * @since 6.0 SP2
     */

    @Deprecated
    public void calculateReciepientDetails(final Recipient inRecipient)
    throws SQLException {

        // calculate age in monthly frame
        inRecipient.setAge((short) calcuateAgeInMonthlyFrame(
                inRecipient.getDateOfBirth(), inRecipient.getStartDate()));

        // is the recipient an adult
        boolean isAdult = true;
        final RecordExistsEvidence studentEvidence = checkSingleRecordExists(inRecipient,
                readStudentByDate, RecordExistsEvidence.kStudentEvidenceName, true);

        setEducationalLevel(inRecipient, studentEvidence);

        if (inRecipient.getAge() < 18) {
            isAdult = false;
        } else if (inRecipient.getAge() < 19 && studentEvidence != null) {
            // if the person is 18 and in education then classify as a child
            isAdult = false;
        }
        inRecipient.setAdultIndicator(isAdult);

        calculateMASAndBOE(inRecipient);
        calculateDualEligibles(inRecipient);
        final BenefitEvidence benefitEvidence = calculateHouseholdAssistanceStatus(inRecipient);

        // is the recipient a parent?, needed for reporting on 2 parent families
        // in future releases if the recipient is a child we need check
        // if he/she has parents, no just if the recipient is a parent
        final HouseHoldRelationshipEvidence houseHoldRelationshipEvidence = isParent(inRecipient);
        if (houseHoldRelationshipEvidence != null) {
            inRecipient.setParentIndicator(houseHoldRelationshipEvidence.isParent());
        }

        // get the alien and citizen status values and keys
        final HHMEvidence householdMemberEvidence = findHouseHoldMemberRecord(inRecipient);
        final AlienEvidence alienEvidence = findAlienRecord(inRecipient);

        if (alienEvidence != null && householdMemberEvidence != null) {
            // citizen status values are the code table category "AlienStatus"
            // alien type values are the code table category
            // "AlienStatusOnEntry"

            if (kCitizenStatus.compareToIgnoreCase(householdMemberEvidence.getType()) == 0
                    && (alienEvidence.alienType
                            .equalsIgnoreCase(kLPR_WITHOUT_40_QUALIFYING_QUARTERS)
                            || alienEvidence.alienType
                            .equalsIgnoreCase(kLPR_WITH_40_QUALIFYING_QUARTERS)
                            || alienEvidence.alienType.equalsIgnoreCase(kREFUGEE)
                            || alienEvidence.alienType.equalsIgnoreCase(kCONDITIONAL_ENTRANT)
                            || alienEvidence.alienType.equalsIgnoreCase(ASYLEE)
                            || alienEvidence.alienType.equalsIgnoreCase(kPAROLEE)
                            || alienEvidence.alienType
                            .equalsIgnoreCase(kDEPORTATION_WITHHELD)
                            || alienEvidence.alienType
                            .equalsIgnoreCase(kCUBAN_HAITIAN_ENTRANT)
                            || alienEvidence.alienType.equalsIgnoreCase(kAMERASIAN_IMMIGRANT)
                            || alienEvidence.alienType
                            .equalsIgnoreCase(kAMERICAN_INDIAN_BORN_IN_CANADA) || alienEvidence.alienType
                            .equalsIgnoreCase(kVICTIMS_OF_SEVERE_TRAFFICKING))) {

                inRecipient.setQualifiedAlienIndicator(true);
            }

        }

        final List unearnedIncomeRecords = findIncomeRecord(inRecipient,
                IncomeEvidence.kUnEarnedIncomeEvidenceName, readUnEarnedIncomeByDate);
        final List paidEmploymentIncomeRecords = findIncomeRecord(inRecipient,
                IncomeEvidence.kEarnedIncomeEvidenceName, readEarnedIncomeByDate);
        final List selfEmploymentIncomeRecords = findIncomeRecord(inRecipient,
                IncomeEvidence.kEarnedIncomeGrossReceiptEvidenceName,
                readSelfEmployedIncomeByDate);
        final List abChildSupportIncomeRecords = findIncomeRecord(inRecipient,
                IncomeEvidence.kAbParChildSupportEvidenceName,
                readAbParChildSupportByDate);
        final List liquidResourceRecords = findIncomeRecord(inRecipient,
                IncomeEvidence.kLiquidResourceEvidenceName, readLiquidResourceByDate);

        final List sanctionEvidence = checkMultipleRecordsExist(inRecipient,
                readSanctionsByDate, RecordExistsEvidence.kSanctions, false);
        // read sanctions
        final List unpaidEmploymentEvidence = checkMultipleRecordsExist(inRecipient,
                readUnPaidEmploymentByDate,
                RecordExistsEvidence.kUnPaidEmploymentEvidenceName, false);

        if (sanctionEvidence.size() > 0) {
            inRecipient.setSanctions();
        }

        // is the recipient co-operating in child support enforcement
        final RecordExistsEvidence childEnforcementEvidence = checkSingleRecordExists(
                inRecipient, readChildSupportEnforceByDate,
                RecordExistsEvidence.kChildSupportEnforcement, true);

        if (childEnforcementEvidence != null) {
            if (kChildEnforcmentStringYes.equalsIgnoreCase(childEnforcementEvidence
                    .getType())) {
                inRecipient.setChildEnforcementKey(kChildEnforcementKeyYes);
            } else {
                inRecipient.setChildEnforcementKey(kChildEnforcementKeyNo);
            }
        } else {
            inRecipient.setChildEnforcementKey(kUndefinedKey);
        }

        // get subsidized housing key
        final RecordExistsEvidence subsizedHouseingKey = setSubsizedHouseingKey(inRecipient);

        // work out the employment status
        setEmploymentStatus(inRecipient);

        // link any benefit evidence
        final List benefits = findBenefitRecord(inRecipient);

        final RelatedEvidence relatedEvidence = new RelatedEvidence();
        relatedEvidence.addEvidence(alienEvidence);
        relatedEvidence.addEvidence(householdMemberEvidence);
        relatedEvidence.addEvidence(houseHoldRelationshipEvidence);
        relatedEvidence.addEvidence(studentEvidence);
        relatedEvidence.addEvidence(benefitEvidence);
        relatedEvidence.addEvidence(unearnedIncomeRecords);
        relatedEvidence.addEvidence(abChildSupportIncomeRecords);
        relatedEvidence.addEvidence(paidEmploymentIncomeRecords);
        relatedEvidence.addEvidence(selfEmploymentIncomeRecords);
        relatedEvidence.addEvidence(liquidResourceRecords);

        relatedEvidence.addEvidence(sanctionEvidence);
        relatedEvidence.addEvidence(childEnforcementEvidence);
        relatedEvidence.addEvidence(subsizedHouseingKey);
        relatedEvidence.addEvidence(benefits);
        relatedEvidence.addEvidence(unpaidEmploymentEvidence);
        inRecipient.setEvidenceKeys(relatedEvidence);
    }

    /**
     * 
     * @param inRecipient
     * @param inEvidence
     * @return key
     * @throws SQLException
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * @since 6.0 SP2
     */
    @Deprecated
    public int setEducationalLevel(final Recipient inRecipient,
            final RecordExistsEvidence inEvidence) throws SQLException {

        return -1;
    }

    /**
     * 
     * @param inRecipient
     * @return RecordExistsEvidence
     * @throws SQLException
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * @since 6.0 SP2
     */
    @Deprecated
    public RecordExistsEvidence setSubsizedHouseingKey(final Recipient inRecipient)
    throws SQLException {

        // work out the employment status
        // if employed
        final RecordExistsEvidence unearnedIncomeEvidence = checkSingleRecordExists(
                inRecipient, readUnEarnedIncomeTypeByDate,
                IncomeEvidence.kUnEarnedIncomeEvidenceName, true);
        if (unearnedIncomeEvidence != null) {
            // then employed
            final StringBuffer rent = new StringBuffer("UT27 UT28  UT29 UT30 UT18");
            if (rent.indexOf(unearnedIncomeEvidence.getType()) != -1) {
                inRecipient.setSubsizedHousingKeyKey(kHousingPublicKey);
            }
            return unearnedIncomeEvidence;
        }
        final RecordExistsEvidence subHousingEvidence = checkSingleRecordExists(
                inRecipient, readRentAllowanceSubHousingByDate,
                RecordExistsEvidence.kSubsizedHousing, true);

        if (subHousingEvidence != null) {
            // then employed
            final StringBuffer rent = new StringBuffer("SET5 SET2");
            if (rent.indexOf(subHousingEvidence.getType()) != -1) {
                inRecipient.setSubsizedHousingKeyKey(kHousingRentKey);
                return subHousingEvidence;
            } else {
                inRecipient.setSubsizedHousingKeyKey(KHousingNoSubsidyKey);

            }
        }
        return null;
    }

    /**
     * 
     * @param inRecipient
     * @throws SQLException
     * 
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
     * @since 6.0 SP2
     */
    @Deprecated
    public void setEmploymentStatus(final Recipient inRecipient)
    throws SQLException {

        EmploymentStatusEvidence employeeStatus = null;
        // work out the employment status
        // if employed
        RecordExistsEvidence paidEmploymentEvidence = checkSingleRecordExists(
                inRecipient, readEmploymentStatusPaidEmploymentByDate,
                RecordExistsEvidence.kPaidEmploymentEvidenceName, false);
        if (paidEmploymentEvidence != null) {
            // then employed
            employeeStatus = new EmploymentStatusEvidence(
                    RecordExistsEvidence.kPaidEmploymentEvidenceName,
                    paidEmploymentEvidence.getKey(), kEmploymentStatusEmployed,
                    paidEmploymentEvidence.getType());

            inRecipient.setEmploymentStatusKey(employeeStatus);

            // else check if the recipient is self employed
            paidEmploymentEvidence = checkSingleRecordExists(inRecipient,
                    readEmploymentStatusSelfEmployedByDate,
                    RecordExistsEvidence.kSelfEmploymentEvidenceName, false);
            if (paidEmploymentEvidence != null) {
                employeeStatus = new EmploymentStatusEvidence(
                        RecordExistsEvidence.kSelfEmploymentEvidenceName,
                        paidEmploymentEvidence.getKey(), kEmploymentStatusEmployed,
                        paidEmploymentEvidence.getType());
            }
            inRecipient.setEmploymentStatusKey(employeeStatus);
        } else if (paidEmploymentEvidence == null) {
            paidEmploymentEvidence = checkSingleRecordExists(inRecipient,
                    readEmploymentStatusWorkRequirementsByDate,
                    RecordExistsEvidence.kWorkRequirementsEvidenceName, false);
            // check if there are not in the labor force
            employeeStatus = new EmploymentStatusEvidence(
                    RecordExistsEvidence.kWorkRequirementsEvidenceName,
                    paidEmploymentEvidence.getKey(), kEmploymentStatusNoInLabourForce,
                    paidEmploymentEvidence.getType());
            inRecipient.setEmploymentStatusKey(employeeStatus);
        }
    }

    /**
     * Associate a recipient to the evidence used in eligibility. This process
     * executes against the recipient table and any evidence table(s).
     * 
     * Evidence is only associated once to a recipient even through there may be
     * many evidence records that allow eligibility.
     * 
     * This is an algorithm based on the rules defined in our requirements
     * specifications for TANF.
     * 
     * @param recipient
     *          the target table name
     * 
     * @exception SQLException
     *              if a database operation fails
     * @deprecated
     * @see curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl#calculateFederalBenefitTypeStatus(String)
     * @since 6.0 SP2
     */

    @Deprecated
    public void calcuateFederalStatuses(final Recipient recipient) throws SQLException {

        // if an SQL statement failed
        boolean failed = false;

        // the database transaction
        Transaction transaction = null;
        // statement to read recipient records
        // statement to update recipient records
        PreparedStatement updateRecipients = null;
        // statement to insert evidence link records
        PreparedStatement insertEvidenceLinks = null;
        int recipientRecordsProcessed = 0;
        int evidenLinkRecords = 0;

        try {
            // start a transaction
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            // create the statement to update the recipient records
            if (updateRecipients == null) {
                updateRecipients = connection.prepareStatement(updateRecipient);
            }

            if (insertEvidenceLinks == null) {
                insertEvidenceLinks = connection.prepareStatement(insertEvidenceLink);
            }

            // calculate data to update case recipient columns
            calculateReciepientDetails(recipient);

            // update the recipient table
            updateRecipients.setLong(1, recipient.getAge());
            updateRecipients.setString(2, recipient.getAdultIndicator());
            // set the processed flag
            updateRecipients.setString(3, kYes);
            updateRecipients.setString(4, recipient.getQualifiedAlienIndicator());
            updateRecipients.setString(5, recipient.getParentIndicator());
            updateRecipients.setLong(6, recipient.getMas()
                    .getMaintenanceAssistenceStatusKey());
            updateRecipients.setLong(7, recipient.getBoe()
                    .getMaintenanceAssistenceStatusKey());
            updateRecipients.setLong(8, recipient.getDualEligible()
                    .getMaintenanceAssistenceStatusKey());
            updateRecipients.setLong(9, recipient.getAssistanceStatus()
                    .getMaintenanceAssistenceStatusKey());

            updateRecipients.setFloat(11, recipient.getTotalUnearnedIncome());
            updateRecipients.setFloat(12, recipient.getTotalChildSupportIncome());
            updateRecipients.setFloat(13, recipient.getCashResource());
            updateRecipients.setFloat(14, recipient.getTotalearnedIncome());

            final String hasSanctions = recipient.hasSanctions() == true ? "Y" : "N";
            updateRecipients.setString(15, hasSanctions);

            updateRecipients.setInt(16, recipient.getSubsizedHousingKeyKey());
            updateRecipients.setInt(17, recipient.getChildEnforcementKey());
            updateRecipients.setInt(18,
                    (int) (recipient.getEmploymentStatusKey() == null ? -1 : recipient
                            .getEmploymentStatusKey().getKey()));
            updateRecipients.setInt(19, recipient.getEducationalLevelKey());

            updateRecipients.setLong(16, recipient.getRecipientID());

            int rowsUpdated = updateRecipients.executeUpdate();
            recipientRecordsProcessed++;
            if (rowsUpdated != 1) {
                System.out.println("Warning: " + rowsUpdated
                        + " row(s) updated in recipient table.");
            }

            // update the evidence link table with our best guess as
            // as defined in our requirement specification as
            // to what evidence resulted in an eligible recipient
            final List relatedEvidence = recipient.getRelatedEvidence().getAllEvidence();
            Evidence evidence;
            for (int i = 0; i < relatedEvidence.size(); i++) {
                evidence = (Evidence) relatedEvidence.get(i);

                insertEvidenceLinks.setLong(1, recipient.recipientID);
                insertEvidenceLinks.setLong(2, evidence.getKey());
                insertEvidenceLinks.setString(3, evidence.getEvidenceType());
                insertEvidenceLinks.setTimestamp(4, recipient.getLastWritten());

                try {
                    rowsUpdated = insertEvidenceLinks.executeUpdate();
                    if (rowsUpdated != 1) {
                        System.out.println("Warning: " + rowsUpdated
                                + " row(s) inserted into evidence link table.");
                    }
                    evidenLinkRecords++;
                } catch (final SQLException e) {
                    // if a recipients record processed flag is reset back
                    // to unprocessed, some inserts may break the unique
                    // constraint
                    // that a recipient for a case can only have one
                    // evidence
                    // record per evidence type (.e.g. alien evidence)

                    // e.g if there are 4 evidence records, and 3 have
                    // already
                    // been inserted, allow the fourth record to be inserted
                    // on the
                    // second execution of this transform for a recipient
                    // record
                    System.out
                    .println("Warning:linkReciepientToEvidence:insert evidence link:"
                            + e);
                }
            }

            if (updateRecipients != null) {
                updateRecipients.close();
            }

            // PostProcessFactory.newInstance().executePostProcess("");

            System.out.println("linkReciepientToEvidence: "
                    + recipientRecordsProcessed + " recipient records updated");
            System.out.println("linkReciepientToEvidence: " + evidenLinkRecords
                    + " evidence link records inserted");
        } catch (final Exception e) {
            e.printStackTrace();
            System.out.println("linkReciepientToEvidence: caught exception "
                    + e.getMessage());
            failed = true;
            throw new SQLException("linkReciepientToEvidence:" + e.getMessage());
        } finally {

            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                    System.out
                    .println("linkReciepientToEvidence:failed, transaction rolled back");
                } else {
                    // commit the changes
                    transaction.commit();
                    System.out
                    .println("linkReciepientToEvidence:transaction commited, processed ");
                }
            }
        }
    }

    /**
     * Returns the nearest case status key for a case recipient
     * 
     * @param inDWCaseID
     *          the product case identity.
     * @param inStartDate
     *          the start date
     * @param inEndDate
     *          the end date
     * @return long the
     * 
     * @exception SQLException
     *              if a database operation fails
     */

    public long findCaseStatusKey(final long inDWCaseID, final Date inStartDate,
            Date inEndDate) throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;
        long activeCaseStatusHistoryID = kUndefinedKey;
        long caseStatusHistoryID = kUndefinedKey;
        long mostRecentStatusHistoryID = kUndefinedKey;

        // set the end date to now if its null
        if (inEndDate == null) {
            inEndDate = new Date(System.currentTimeMillis());
        }

        try {
            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();
            Timestamp caseStatusToDate = null;
            Timestamp caseStatusFromDate = null;

            statement = connection.prepareStatement(readCaseStatusHistoryKeyByDate);

            // set parameters
            statement.setLong(1, inDWCaseID);
            // statement.setDate(2, inEndDate);
            // statement.setDate(3, inStartDate);
            final ResultSet statuses = statement.executeQuery();

            while (statuses.next()) {
                // the results are ordered by end date descending
                // take the most recent
                caseStatusHistoryID = statuses.getLong(1);
                if (mostRecentStatusHistoryID == kUndefinedKey) {
                    mostRecentStatusHistoryID = caseStatusHistoryID;
                }

                caseStatusFromDate = statuses.getTimestamp(2);
                caseStatusToDate = statuses.getTimestamp(3);
                final String caseStatus = statuses.getString(4);

                if (caseStatusFromDate.before(inEndDate)
                        && (caseStatusToDate == null || caseStatusToDate.after(inStartDate))) {
                    if ("Active".equalsIgnoreCase(caseStatus)) {
                        activeCaseStatusHistoryID = caseStatusHistoryID;
                    }
                    break;
                }
                if (caseStatusFromDate.after(inEndDate)) {
                    if ("Active".equalsIgnoreCase(caseStatus)) {
                        activeCaseStatusHistoryID = caseStatusHistoryID;
                    }
                }
            }

            // if we can't find a case status record in the time period
            // use the closest status record available
            if (activeCaseStatusHistoryID == kUndefinedKey) {
                activeCaseStatusHistoryID = mostRecentStatusHistoryID;
                System.out
                .println("no active case status found for (using latest status)concernroleid="
                        + inDWCaseID
                        + ", startdate="
                        + inStartDate
                        + ", endate="
                        + inEndDate);
            } else {
                System.out.println("found active history record for concernroleid="
                        + inDWCaseID + ", startdate=" + inStartDate + ", endate="
                        + inEndDate);
            }

        } catch (final Exception e) {
            System.out.println("readCaseStatusHistoryKeyByDate Error: "
                    + e.getMessage() + readCaseStatusHistoryKeyByDate);
            // throw new SQLException("readCaseStatusHistoryKeyByDate Error: "
            // + e.getMessage() + readCaseStatusHistoryKeyByDate);
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
        return activeCaseStatusHistoryID;

    }

    /**
     * House hold relationship evidence
     * 
     * 
     */
    class HouseHoldRelationshipEvidence extends Evidence {

        static public final String kHHREvidenceName = "Household Relationship";

        private final String roleType;

        private final boolean isParent;

        public HouseHoldRelationshipEvidence(final long key, final String type, final boolean isParent) {
            super(key, kHHREvidenceName);
            roleType = type;
            this.isParent = isParent;
        }

        public boolean isParent() {
            return isParent;
        }

        @Override
        public String getType() {
            return roleType;
        }
    }

    /**
     * Student evidence
     * 
     * 
     */
    class RecordExistsEvidence extends Evidence {
        static public final String kChildSupportEnforcement = "ChildEnforcement";

        static public final String kSanctions = "Sanction";

        static public final String kStudentEvidenceName = "Student";

        static public final String kPaidEmploymentEvidenceName = "PaidEmployment";
        static public final String kUnPaidEmploymentEvidenceName = "UnPaidEmployment";
        static public final String kSelfEmploymentEvidenceName = "SelfEmployment";

        static public final String kWorkRequirementsEvidenceName = "WorkRequirements";

        static public final String kSubsizedHousing = "SubHousing";

        /*
         * a code table item code on the record that further describes the business
         * process or evidence
         */
        private String description;

        public RecordExistsEvidence(final long key, final String inEvidenceType) {
            super(key, inEvidenceType);
        }

        public void setType(final String inDesc) {
            description = inDesc;
        }

        @Override
        public String getType() {
            return description;
        }

    }

    /**
     * Alien evidence
     * 
     * 
     * 
     */
    class AlienEvidence extends Evidence {

        private final String alienType;

        static public final String kAlienEvidenceName = "Alien";

        public AlienEvidence(final long key, final String type) {
            super(key, kAlienEvidenceName);
            alienType = type;
        }

        @Override
        public String getType() {
            return alienType;
        }
    }

    /**
     * Alien evidence
     * 
     * 
     * 
     */
    class EmploymentStatusEvidence extends Evidence {

        private Integer employmentStatusKey;

        private String typeCode = "";

        static public final String kPaidEmploymentEvidenceName = "PaidEmployment";
        static public final String kUnPaidEmployEvidenceName = "UnPaidEmployment";

        public EmploymentStatusEvidence(
                final String inEvidenceName,
                final long key,
                final int inEmploymentStatusKey,
                final String inTypeCode) {
            super(key, inEvidenceName);

            if (inTypeCode != null) {
                typeCode = inTypeCode;
            }
        }

        public int employmentStatusKey() {
            return employmentStatusKey.intValue();
        }

        public boolean isSetEmploymentStatus() {
            return employmentStatusKey == null;
        }

        @Override
        public String getType() {
            return typeCode;
        }
    }

    /**
     * Benefit evidence
     * 
     * 
     * 
     */
    class BenefitEvidence extends Evidence {

        private final String benefitType;

        private final float incomeAmount;

        static public final String kBenefitEvidenceName = "Benefit";

        public BenefitEvidence(final long key, final String type, final float inAmount) {
            super(key, kBenefitEvidenceName);
            benefitType = type;
            incomeAmount = inAmount;
        }

        @Override
        public String getType() {
            return benefitType;
        }

        public float getIncomeAmount() {
            return incomeAmount;
        }
    }

    /**
     * House hold member evidence
     * 
     * 
     * 
     */
    class HHMEvidence extends Evidence {
        static public final String kHHMEvidenceName = "Household Member";

        private final String citizenStatus;

        public HHMEvidence(final long key, final String type) {
            super(key, kHHMEvidenceName);
            citizenStatus = type;
        }

        @Override
        public String getType() {
            return citizenStatus;
        }

    }

    /**
     * Income evidence
     * 
     * 
     * 
     */
    class IncomeEvidence extends Evidence {

        private final float incomeAmount;

        private final String unEarnedIncomeType;

        private String frequency;

        // the three evidence tables need for earned/unearned income

        static public final String kEarnedIncomeGrossReceiptEvidenceName = "EarnedIncomeSelfEmployment";

        static public final String kEarnedIncomeEvidenceName = "EarnedIncomePaidEmployment";

        static public final String kUnEarnedIncomeEvidenceName = "UnEarnedIncome";
        static public final String kAbParChildSupportEvidenceName = "AbParChildSupp";
        static public final String kLiquidResourceEvidenceName = "LiquidResource";

        public IncomeEvidence(
                final long key,
                final String inType,
                final float inAmount,
                final String inEvidenceName) {
            super(key, inEvidenceName);
            incomeAmount = inAmount;
            unEarnedIncomeType = inType;
        }

        @Override
        public String getType() {
            return unEarnedIncomeType;
        }

        public float getIncomeAmount() {
            return incomeAmount;
        }

        public String getFrequency() {
            return frequency;
        }
    }

    /**
     * the base class for all evidence records
     * 
     * 
     * 
     */
    abstract class Evidence {

        private final long evidenceKey;

        private final String evidenceType;

        /**
         * Every evidence record has a key and an evidence type name
         * 
         * @param inKey
         * @param inName
         */
        public Evidence(final long inKey, final String inName) {
            evidenceKey = inKey;
            evidenceType = inName;
        }

        public String getEvidenceType() {
            return evidenceType;
        }

        public long getKey() {
            return evidenceKey;
        }

        /*
         * all evidence method return a type field, a product type, a citizen status
         * type etc
         */
        abstract public String getType();
    }

    /*
     * A composite class to hold what evidence may have resulted in Eligibility
     */
    class RelatedEvidence {
        // all objects much extend the Evidence class
        List evidence;

        public RelatedEvidence() {
            super();

            evidence = new ArrayList();
            ;
        }

        public void addEvidence(final List inEvidence) {
            if (inEvidence != null) {
                evidence.addAll(inEvidence);
            }
        }

        public void addEvidence(final Evidence inEvidence) {
            if (inEvidence != null) {
                evidence.add(inEvidence);
            }
        }

        public List getAllEvidence() {
            return evidence;
        }
    }

    /**
     * a Recipient record with links to its associated evidence
     * 
     * 
     * 
     */
    class Recipient {

        RelatedEvidence relatedEvidence = null;

        BasisOfEligibilityStatus boe = null;

        MedicalAssistance mas = null;

        MedicalAssistance dualEligible = null;

        MedicalAssistance publicAssistance = null;
        /**
         * total cash resources
         */
        private float cashResources = 0;

        /**
         * total unearned income from benefit and unearned income tables
         */
        private float unearnedIncome = 0;

        /**
         * total unearned income from benefit and unearned income tables
         */
        private float earnedIncome = 0;
        /**
         * total unearned income from benefit and unearned income tables
         */
        private float childSupportIncome = 0;

        /**
         * the product name, e.g. PN3
         */
        private String productCode = "";

        /**
         * the primary key
         */
        private long recipientID = 0;

        /**
         * recipient date of birth
         */
        Date dateOfBirth = null;

        /**
         * the start date on the recipient table
         */
        Date startDate = null;

        /**
         * the end date on the recipient table
         */
        Date endDate = null;

        /**
         * the recipients age
         */
        short age = 0;

        /**
         * is the recipient an adult
         */
        boolean adultIndicator = false;

        /**
         * is the recipient a parent
         */
        boolean parentIndicator = false;

        /**
         * is the recipient an alien, check citizen status and alien type
         */
        boolean alienIndicator = false;

        /**
         * links the recipient to a case status active record there may be many so
         * one is selected
         */
        long caseStatusHistoryKey = 0;

        /**
         * the product case identity
         */
        long dwCaseID = 0;

        /**
         * the product case identity
         */
        long dwParticipantID = 0;

        Timestamp lastWritten;

        private final String programCode;

        private EmploymentStatusEvidence employmentStatus;

        private int educationLevelKey = kUndefinedKey;

        private int childEnforcementKey = kUndefinedKey;

        private int subsizedHousingKey = kUndefinedKey;

        private boolean hasSanctions = false;

        Recipient(
                final long inRecipientID,
                final Date inDOB,
                final Date inStartDate,
                final Date inEndDate,
                final long inDWCaseID,
                final long inDWParticipantID,
                final Timestamp inLastWritten,
                final String inProductCode,
                final String inProgramCode) {

            recipientID = inRecipientID;
            dateOfBirth = inDOB;
            startDate = inStartDate;
            endDate = inEndDate;
            dwCaseID = inDWCaseID;
            dwParticipantID = inDWParticipantID;
            lastWritten = inLastWritten;
            productCode = inProductCode;
            programCode = inProgramCode;
        }

        /**
         * only a shallow clone of search criteria only
         * 
         * @param inShallowClone
         */
        Recipient(final Recipient inShallowClone) {

            recipientID = inShallowClone.recipientID;
            dateOfBirth = inShallowClone.dateOfBirth;
            startDate = inShallowClone.startDate;
            endDate = inShallowClone.endDate;
            dwCaseID = inShallowClone.dwCaseID;
            dwParticipantID = inShallowClone.dwParticipantID;
            lastWritten = inShallowClone.lastWritten;
            productCode = inShallowClone.productCode;
            programCode = inShallowClone.programCode;
        }

        public boolean hasSanctions() {
            return hasSanctions;

        }

        public void setSanctions() {
            hasSanctions = true;

        }

        public int getChildEnforcementKey() {
            return childEnforcementKey;

        }

        public void setChildEnforcementKey(final int inChildEnforcementKey) {
            childEnforcementKey = inChildEnforcementKey;

        }

        public int getSubsizedHousingKeyKey() {
            return subsizedHousingKey;

        }

        public void setSubsizedHousingKeyKey(final int inSubsizedHousingKey) {
            subsizedHousingKey = inSubsizedHousingKey;

        }

        public void setEmploymentStatusKey(
                final EmploymentStatusEvidence inEmploymentStatusNoInLabourForce) {
            employmentStatus = inEmploymentStatusNoInLabourForce;

        }

        public EmploymentStatusEvidence getEmploymentStatusKey() {
            return employmentStatus;
        }

        public void setEducationalLevelKey(final int inEducationalLevel) {
            educationLevelKey = inEducationalLevel;

        }

        public int getEducationalLevelKey() {
            return educationLevelKey;
        }

        public float getTotalUnearnedIncome() {
            return unearnedIncome;
        }

        public float getTotalearnedIncome() {
            return earnedIncome;
        }

        public float getCashResource() {
            return cashResources;
        }

        public void incrementCashResources(final float inTotal) {
            cashResources += inTotal;
        }

        public float getTotalChildSupportIncome() {
            return childSupportIncome;
        }

        public void incrementTotalChildSupportIncome(final float inTotal) {
            childSupportIncome += inTotal;
        }

        public void incrementTotalEarnedIncome(final float inTotal) {
            earnedIncome += inTotal;
        }

        public void incrementTotalUnearnedIncome(final float inTotal) {
            unearnedIncome += inTotal;
        }

        public void setAssistanceStatus(final MedicalAssistance InAssistanceStatus) {
            publicAssistance = InAssistanceStatus;

        }

        public MedicalAssistance getAssistanceStatus() {
            return publicAssistance;
        }

        public Timestamp getLastWritten() {
            return lastWritten;
        }

        public String getQualifiedAlienIndicator() {
            return alienIndicator == true ? kYes : kNo;
        }

        public String getParentIndicator() {
            return parentIndicator == true ? kYes : kNo;
        }

        public boolean isAdult() {
            return adultIndicator;
        }

        public String getAdultIndicator() {
            return adultIndicator == true ? kYes : kNo;
        }

        public short getAge() {
            return age;
        }

        public long getCaseStatusHistoryKey() {
            return caseStatusHistoryKey;
        }

        public Date getDateOfBirth() {
            return dateOfBirth;
        }

        public long getDwCaseID() {
            return dwCaseID;
        }

        public long getDwParticipantID() {
            return dwParticipantID;
        }

        public Date getEndDate() {
            return endDate;
        }

        public long getRecipientID() {
            return recipientID;
        }

        public Date getStartDate() {
            return startDate;
        }

        public void setQualifiedAlienIndicator(final boolean alienIndicator) {
            this.alienIndicator = alienIndicator;
        }

        public void setAdultIndicator(final boolean adultIndicator) {
            this.adultIndicator = adultIndicator;
        }

        public void setAge(final short age) {
            this.age = age;
        }

        public void setCaseStatusHistoryKey(final long caseStatusHistoryKey) {
            this.caseStatusHistoryKey = caseStatusHistoryKey;
        }

        public void setParentIndicator(final boolean parentIndicator) {
            this.parentIndicator = parentIndicator;
        }

        public void setEvidenceKeys(final RelatedEvidence inRelatedEvidence) {
            relatedEvidence = inRelatedEvidence;
        }

        public RelatedEvidence getRelatedEvidence() {
            return relatedEvidence;
        }

        public BasisOfEligibilityStatus getBoe() {
            return boe;
        }

        public void setBoe(final BasisOfEligibilityStatus boe) {
            this.boe = boe;
        }

        public MedicalAssistance getMas() {
            return mas;
        }

        public void setMas(final MedicalAssistance mas) {
            this.mas = mas;
        }

        public void setDualEligible(final MedicalAssistance inDualEligible) {
            dualEligible = inDualEligible;
        }

        public MedicalAssistance getDualEligible() {
            return dualEligible;
        }

        public String getProductCode() {
            return productCode;
        }

        public String getProgramCode() {
            return programCode;
        }

    }

}
