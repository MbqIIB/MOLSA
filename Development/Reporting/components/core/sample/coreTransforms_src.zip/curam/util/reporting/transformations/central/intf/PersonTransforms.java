/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.central.intf;

import java.sql.Date;
import java.sql.SQLException;
import java.util.Iterator;

import curam.util.type.*;

/**
 * 
 * This module defines the interface for loading case history records into the
 * case status history table.
 */

@AccessLevel(AccessLevelType.EXTERNAL)
@SuppressWarnings({ "rawtypes" })
public interface PersonTransforms {

  /**
   * the classic food program code, PT16
   */
  public final String kClassicFoodProgramCode = "PT16";

  /**
   * the classic medical assistance program code, PT17
   */
  public final String kClassicMedicalProgramCode = "PT17";
  /**
   * the classic cash assistance program code, PT22
   */
  public final String kClassicCashProgramCode = "PT22";

  // ___________________________________________________________________________
  /**
   * Calculates number of previous maltreatments for the person who is the
   * victim on an allegation the process is based on the allegation date and
   * concern role identity and the 6 month period read from the config table
   * 
   * @param inAllegationID
   *          the allegation id
   * @param inConcernroleID
   *          the concern role id of the victim
   * @param inAllegationDate
   *          the allegation date
   * @return the number of previous maltreatments in the configured window
   * @throws SQLException
   *           if the operation fails
   */
  public int calculatePreviousMaltreatments(final long inAllegationID,
      final long inConcernroleID, final Date inAllegationDate)
      throws SQLException;

  /**
   * Returns a person age in years based on a two dates.
   * 
   * @param inStartDate
   *          the date of birth.
   * @param inEndDate
   *          a reference point in time
   * 
   * @return int the age in years
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  public int calcuateAge(final Date inStartDate, final Date inEndDate)
      throws SQLException;

  /**
   * Returns a race key for ethnic origins.
   * 
   * @param inBlackOrAfrAmerIND
   *          race indicator
   * @param inNatAlaskOrAmerIND
   *          race indicator
   * @param inAsianIND
   *          race indicator
   * @param inNatjawOrPaisIND
   *          race indicator
   * @param inWhiteOrCaucIND
   *          race indicator
   * 
   * @return int the race key for the indicator parameters
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  public int findRaceKey(final String inBlackOrAfrAmerIND,
      final String inNatAlaskOrAmerIND, final String inAsianIND,
      final String inNatjawOrPaisIND, final String inWhiteOrCaucIND)
      throws SQLException;

  // ___________________________________________________________________________
  /**
   * Calculates a persons age using to dates in time. Calculate the youngest age
   * in a monthly frame
   * 
   * @param inStartDate
   *          typically the date of birth
   * @param inEndDate
   *          a point in time
   * @return the person age on the first day of the month
   * @throws java.sql.SQLException
   *           if a database operation failed
   */
  public int calcuateAgeInMonthlyFrame(final Date inStartDate,
      final Date inEndDate) throws SQLException;

  /**
   * Returns a person history key for a point in time
   * 
   * @param inConcernRoleID
   *          the concern role identity.
   * @param inStartDate
   *          the start date
   * @param inEndDate
   *          the end date
   * @return long a person key for a point in time
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  public long findPersonHistoryKey(final long inConcernRoleID,
      final Date inStartDate, final Date inEndDate) throws SQLException;

  /**
   * Returns the nearest case status key for a case recipient
   * 
   * @param inConcernRoleID
   *          the product case identity.
   * @param inStartDate
   *          the start date
   * @param inEndDate
   *          the end date
   * @return long the
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  public long findCaseStatusKey(final long inConcernRoleID,
      final Date inStartDate, final Date inEndDate) throws SQLException;

  /**
   * Associate a recipient to the evidence. This process executes against the
   * recipient table and any evidence table(s).
   * 
   * Evidence is only associated once to a recipient even through there may be
   * many evidence records .
   * 
   * This is an based on the rules defined in our requirements specifications
   * for TANF.
   * 
   * @param inTargetTableName
   *          the target table name
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  public void linkReciepientToEvidence(final String inTargetTableName)
      throws SQLException;

  /*
   * Federal Status processing.
   * 
   * @deprecated
   * 
   * @see
   * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
   * 
   * @since 6.0 SP2
   */
  @Deprecated
  public Iterator getMasKeys();

  /*
   * Federal Status processing.
   * 
   * @deprecated
   * 
   * @see
   * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
   * 
   * @since 6.0 SP2
   */
  @Deprecated
  public Iterator getBoeKeys();

  /*
   * Federal Status processing.
   * 
   * @deprecated
   * 
   * @see
   * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
   * 
   * @since 6.0 SP2
   */
  @Deprecated
  public Iterator getDualEligibleKeys();

  /*
   * Federal Status processing.
   * 
   * @deprecated
   * 
   * @see
   * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
   * 
   * @since 6.0 SP2
   */
  @Deprecated
  public Iterator getHouseHoldAssistanceKeys();

  /*
   * Federal Status processing.
   * 
   * @deprecated
   * 
   * @see
   * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
   * 
   * @since 6.0 SP2
   */
  @Deprecated
  public Iterator getUnEarnedIncomeKeys();

  /*
   * Federal Status processing.
   * 
   * @deprecated
   * 
   * @see
   * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
   * 
   * @since 6.0 SP2
   */
  @Deprecated
  public Iterator getEdicationLevelKeys();

  /*
   * Federal Status processing.
   * 
   * @deprecated
   * 
   * @see
   * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
   * 
   * @since 6.0 SP2
   */
  @Deprecated
  public Iterator getChildSupportEnforcementKeys();

  /*
   * Federal Status processing.
   * 
   * @deprecated
   * 
   * @see
   * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
   * 
   * @since 6.0 SP2
   */
  @Deprecated
  public Iterator getFederalSanctionsKeys();

  /*
   * Federal Status processing.
   * 
   * @deprecated
   * 
   * @see
   * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
   * 
   * @since 6.0 SP2
   */
  @Deprecated
  public Iterator getHousingKeys();

  /*
   * Federal Status processing.
   * 
   * @deprecated
   * 
   * @see
   * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
   * 
   * @since 6.0 SP2
   */
  @Deprecated
  public Iterator getEmploymentStatusKeys();

  /*
   * Federal Status processing.
   * 
   * @deprecated
   * 
   * @see
   * curam.util.reporting.transformations.central.base.FederalProgramsTransformsImpl
   * 
   * @since 6.0 SP2
   */
  @Deprecated
  public Iterator getFederalBenefitKeys();

  /**
   * Returns a sanction description key
   * 
   * @param inSanctionCode
   *          the sanction code. the end date
   * @return long the sanction key
   * 
   * @exception SQLException
   *              if a database operation fails
   */
  public long getSanctionTypeKey(String inSanctionCode) throws SQLException;

  /**
   * Returns a federal benefit key
   * 
   * @param inCode
   *          the sanction code. the end date
   * @return long the sanction key
   * 
   * @exception SQLException
   *              if a database operation fails
   */
  public long getFederalBenefitTypeKey(String inCode) throws SQLException;

}
