/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.central.base;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.base.PostProcessImpl;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;
import curam.util.type.*;

/**
 * This module updates updates the end date for the previous record in a history
 * table.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
abstract class EndDateTransformImpl extends PostProcessImpl implements
ETLPostProcess {

    /**
     * update SQL.
     */
    private String kUodateFactSQL;

    /**
     * SQL to read where to date is null.
     */
    private String sqlSelectLatestFacts;

    /**
     * SQL to read where to date is null.
     */
    private String sqlSelectLatestSCD;

    /**
     * the table to be processed
     */
    private String sourceTableName = "table";
    /**
     * the name of the logical key on the table
     */
    private String sourceLogicalKey = "logicalkey";
    /**
     * the control table for the transform
     */
    private String controlTableEntry;

    private boolean controlTableEntryForDataInd = false;

    // ___________________________________________________________________________
    /**
     * Creates an object to parse address data strings.
     * 
     * @param inSourceTable
     *          the source table name
     * @param inSourceKey
     * @throws SQLException
     *           if database error occurs
     */
    public EndDateTransformImpl(
            final String inSourceTable,
            final String inSourceKey) throws SQLException {

        sourceTableName = inSourceTable;
        sourceLogicalKey = inSourceKey;
        controlTableEntry = "enddatetransform";
    }

    /**
     * Set the processing for end dates to be more robust
     * 
     * @param inControlTableEntry
     *          - the control table entry for data
     */
    public void setUseSCD(final boolean inUseSCD) {
        controlTableEntryForDataInd = inUseSCD;
    }

    // ___________________________________________________________________________
    /**
     * Set the SQL based on private member data.
     */
    private String getSelectSQL() {
        if (controlTableEntryForDataInd == true) {
            return sqlSelectLatestSCD;
        } else {
            return sqlSelectLatestFacts;
        }

    }

    // ___________________________________________________________________________
    /**
     * Set the SQL based on private member data.
     */
    private void initialiseSQL(final String inTargetTableName) {

        controlTableEntry = inTargetTableName;

        // SQL to read data from the source table
        kUodateFactSQL = "update " + sourceTableName + " set enddate=?" + " where "
        + sourceLogicalKey + " =? and startdate=? and lastwritten=?";

        sqlSelectLatestFacts = "select T1." + sourceLogicalKey
        + ", T1.startdate as startdate, T1.lastwritten as lastwritten from "
        + sourceTableName + " T1" + " WHERE t1.lastwritten >= "
        + " (select last_etl_date from DW_ETLCONTROL where targettablename=?) "
        + " and T1.enddate is null" + " order by T1." + sourceLogicalKey
        + ", T1.startdate desc, T1.lastwritten desc";

        sqlSelectLatestSCD = "select T1."
            + sourceLogicalKey
            + ", T1.startdate as startdate, T1.lastwritten as lastwritten from "
            + sourceTableName
            + " T1"
            + " WHERE t1.lastwritten >= "
            + " (select previousETLDate from DW_ETLCONTROL where targettablename=?) "
            + " and T1.enddate is null" + " order by T1." + sourceLogicalKey
            + ", T1.startdate desc, T1.lastwritten desc";

    }

    // ___________________________________________________________________________
    /**
     * This module updates a table end date column.
     * 
     * @param inTargetTableName
     *          the target table being populated
     * @throws java.sql.SQLException
     *           if a database operation failed
     */
    @Override
    public void executePostProcess(final String inTargetTableName)
    throws SQLException {
        // if an SQL statement failed, initialize to false
        boolean failed = false;
        // the database transaction
        Transaction transaction = null;

        try {
            // start a transaction, get DAO to read from the control table
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);

            initialiseSQL(inTargetTableName);

            updateToDateOfPreviousStatuses(controlTableEntry);

            // update the control table
            super.executePostProcess(controlTableEntry);
        } catch (final Exception e) {
            System.out.println("ToDateTransformImpl: caught exception "
                    + e.getMessage());
            System.out.println("ToDateTransformImpl: kUodateFactSQL "
                    + kUodateFactSQL);
            System.out.println("ToDateTransformImpl: sqlSelectLatestFacts "
                    + sqlSelectLatestFacts);
            failed = true;
            // do not throw an exception, allow our test process to
            // pick up on any data quality issues.
        } finally {

            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                    System.out
                    .println("ToDateTransformImpl:failed, transaction rolled back");
                } else {
                    // commit the changes
                    transaction.commit();
                    System.out
                    .println("ToDateTransformImpl:transaction commited, processed ");
                }
            }
        }
    }

    // __________________________________________________________________________
    /**
     * Sets the number of cases on hand prior to a given date.
     * 
     * @param inTargetTableName
     *          the control entry name which controls the volume of records to be
     *          processed
     * @throws SQLException
     *           if a database operation fails
     */

    private void updateToDateOfPreviousStatuses(final String inTargetTableName)
    throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection.prepareStatement(getSelectSQL());
            statement.setString(1, inTargetTableName);

            final ResultSet rs = statement.executeQuery();

            FactKey mostRecentStatus = null;
            FactKey previousstatusForCase = null;

            while (rs.next()) {
                mostRecentStatus = new FactKey(rs.getLong(1), rs.getDate(2),
                        rs.getTimestamp(3));

                if (previousstatusForCase != null
                        && mostRecentStatus.logicalKey == previousstatusForCase.logicalKey) {

                    mostRecentStatus.toDate = previousstatusForCase.fromDate;
                    System.out.println("setting TODATE on case <"
                            + mostRecentStatus.logicalKey + "> with from date<"
                            + mostRecentStatus.fromDate + "> to " + mostRecentStatus.toDate
                            + " with timestamp " + mostRecentStatus.lastwritten);

                    update(mostRecentStatus);
                } else {
                    previousstatusForCase = mostRecentStatus;
                    System.out.println("next case " + mostRecentStatus.logicalKey);
                }
            }

        } catch (final Exception e) {
            System.out.println("ToDateTransformImpl:readCasesOnHand:" + e);
            throw new SQLException("ToDateTransformImpl:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // __________________________________________________________________________
    /**
     * Sets the to date value.
     * 
     * @param inFactKey
     *          the target table being populated
     * @throws SQLException
     *           if database operation failed
     */
    public void update(final FactKey inFactKey) throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;

        try {

            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.prepareStatement(kUodateFactSQL);

            // set month
            statement.setDate(1, inFactKey.toDate);

            // set case
            statement.setLong(2, inFactKey.logicalKey);

            // set cases on hand at start of month

            statement.setDate(3, inFactKey.fromDate);

            statement.setTimestamp(4, inFactKey.lastwritten);

            final int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated != 1) {
                System.out.println("Warning: " + rowsUpdated
                        + " row(s) updated history table.");
            }

        } catch (final Exception e) {
            System.out.println("ToDateTransformImpl:update:" + e.getMessage());
            throw new SQLException("ToDateTransformImpl:update:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    /**
     * This module defines the key to fact records.
     */
    class FactKey {

        /**
         * the from date for a case status record.
         */

        private final Date fromDate;

        /**
         * the last written date for a case status record.
         */

        private final Timestamp lastwritten;

        /**
         * the to date for a case status record.
         */
        private Date toDate;

        /**
         * the case id.
         */
        private final long logicalKey;

        /**
         * Creates a new fact key for latest records.
         * 
         * @param inLogicalKey
         *          the case identity
         * @param inFromDate
         *          the from date
         * @param inLastWritten
         */
        public FactKey(
                final long inLogicalKey,
                final Date inFromDate,
                final Timestamp inLastWritten) {
            fromDate = inFromDate;
            logicalKey = inLogicalKey;
            lastwritten = inLastWritten;
        }

        /**
         * Sets the to date for a case status records.
         * 
         * @param inToDate
         *          the end date for a status
         */
        public void setToDate(final Date inToDate) {
            toDate = inToDate;
        }

    }

    // ___________________________________________________________________________
    /**
     * Private test harness for all methods in this class.
     * 
     * @param args
     */

    public static void main(final String args[]) {
        try {
            TransactionFactory
            .overRideRequestforDefaultTransactions(DataWarehouseConstants.kCentralDatabase);
        } catch (final SQLException e) {
            e.printStackTrace();
        }

        EndDateTransformImpl endDateTransforImpl;
        try {
            endDateTransforImpl = new EndDateTransformImpl("dw_personhistory",
            "dwparticipantid") {
            };
            endDateTransforImpl.executePostProcess("dw_abc");

        } catch (final SQLException e) {
            e.printStackTrace();
        }
    }
}
