/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.coredatamarts.dbclient;

import java.sql.SQLException;

import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;
import curam.util.reporting.transformations.coredatamarts.fact.CaseFactProcessFactory;
import curam.util.reporting.transformations.coredatamarts.fact.ParticipantToDateFactory;
import curam.util.reporting.transformations.coredatamarts.fact.PersonTransformsFactory;
import curam.util.reporting.transformations.coredatamarts.fact.PropertyReaderDBFactory;
import curam.util.reporting.transformations.staging.base.PropertyReaderBase;

import curam.util.type.*;

/**
 * 
 * This class is the interface or entry point between the database and the
 * staging transformations.
 * 
 * The interface specification is enforced by the Oracle and DB2 call
 * specifications A call spec exposes a Java methods top-level entry point to
 * Oracle..
 * 
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public final class CustomTransforms {

  // ___________________________________________________________________________
  /**
   * Ensures this class cannot be created.
   */
  private CustomTransforms() {
  }

  // __________________________________________________________________________
  /**
   * Returns a property value.
   * 
   * @param inPropertyName
   *          table property name
   * 
   * @return String the property value, "not found" is returned if the property
   *         name does not exist
   * 
   * @throws SQLException
   *           if the address cannot be transformed
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static String readPropertyFromDB(final String inPropertyName)
      throws SQLException {
    PropertyReaderBase reader = PropertyReaderDBFactory.newPropertyReader();

    String propertyValue = reader.readPropertyFromDB(inPropertyName);

    return propertyValue;
  }

  // __________________________________________________________________________
  /**
   * Returns a property value for undefined if the data value is null.
   * 
   * @param inColumnValue
   *          the value
   * 
   * @return String the localized property value for undefined if the parameter
   *         is null
   * 
   * @throws SQLException
   *           if the address cannot be transformed
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static String readUndefinedIFNull(final String inColumnValue)
      throws SQLException {
    if (inColumnValue != null) {
      return inColumnValue;
    }
    PropertyReaderBase reader = PropertyReaderDBFactory.newPropertyReader();
    String propertyValue = reader
        .readPropertyFromDB(PropertyReaderBase.kUNDEFINED_PROPERTY_NAME);

    return propertyValue;
  }

  // __________________________________________________________________________
  /**
   * Returns a property value for undefined if the data value is null.
   * 
   * @param inColumnValue
   *          the value
   * @param inPropertyName
   *          the property name
   * 
   * @return String the localized property value if the value is null
   * 
   * @throws SQLException
   *           if the address cannot be transformed
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static String readPropertyIFNull(final String inColumnValue,
      final String inPropertyName) throws SQLException {
    if (inColumnValue != null) {
      return inColumnValue;
    }
    PropertyReaderBase reader = PropertyReaderDBFactory.newPropertyReader();
    String propertyValue = reader.readPropertyFromDB(inPropertyName);

    return propertyValue;
  }

  // ___________________________________________________________________________
  /**
   * Populates the case fact process month aggregate table.
   * 
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static void caseFactProcessAggregateDB2() throws SQLException {

    final ETLPostProcess etlPreProcess = CaseFactProcessFactory
        .newMonthInstance();

    etlPreProcess.executePostProcess("DM_AGGCASEPROCESS");
  }

  // ___________________________________________________________________________
  /**
   * Populates the case fact process month aggregate table.
   * 
   * @param inTargetTableName
   *          the target table being populated
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static void caseFactProcessMonthAggregate(
      final String inTargetTableName) throws SQLException {

    final ETLPostProcess etlPreProcess = CaseFactProcessFactory
        .newMonthInstance();

    etlPreProcess.executePostProcess(inTargetTableName);
  }

  // ___________________________________________________________________________
  /**
   * Populates the case fact process day aggregate table.
   * 
   * @param inTargetTableName
   *          the target table being populated
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static void caseFactProcessDayAggregate(final String inTargetTableName)

  throws SQLException {

    final ETLPostProcess etlPreProcess = CaseFactProcessFactory
        .newDayInstance();

    etlPreProcess.executePostProcess(inTargetTableName);
  }

  // ___________________________________________________________________________
  /**
   * Populates the case fact process day aggregate table.
   * 
   * @param inTargetTableName
   *          the target table being populated
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  public static void caseFactProcess(final String inTargetTableName)
      throws SQLException {

    final ETLPostProcess etlPreProcess = CaseFactProcessFactory
        .newFactInstance();

    etlPreProcess.executePostProcess(inTargetTableName);
  }

  // __________________________________________________________________________
  /**
   * Set the to date for the history table.
   * 
   * @param inETLName
   *          the target table being populated
   * @param inTable
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static void setToDate(final String inETLName, final String inTable)
      throws SQLException {

    final ETLPostProcess etlPreProcess = ParticipantToDateFactory
        .newInstance(inTable);

    etlPreProcess.executePostProcess(inETLName);
  }

  // __________________________________________________________________________
  /**
   * Finds the correct Age group key for a TANF Recipient
   * 
   * @param inAdultIND
   *          Adult Indicator, used with business area column in age groups
   *          entity
   * @param inAge
   *          the age of a recipient
   * @param inProgramCode
   *          determines the business area which the Age group is used for
   * @return the age group primary key for this age and business area
   * @throws SQLException
   *           if a database operation fails
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static int findAgegroupKey(final String inAdultIND, final int inAge,
      final String inProgramCode) throws SQLException {

    return PersonTransformsFactory.newInstance().findAgegroupKey(inAdultIND,
        inAge, inProgramCode);

  }

  // __________________________________________________________________________
  /**
   * test transformation returns a string has one string parameter
   * 
   * @param inString
   *          any string
   * @return String constant
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public static String testtransform(final String inString) throws SQLException {

    return "testtransform";

  }

}
