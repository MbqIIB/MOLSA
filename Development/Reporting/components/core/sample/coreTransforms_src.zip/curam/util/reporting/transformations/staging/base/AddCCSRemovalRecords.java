/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.staging.base;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;

import curam.util.reporting.internal.transformations.prepost.fact.PostProcessFactory;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;

/**
 * 
 * Converts removal reason codes which are packed into a single column into
 * rows.
 * 
 * 
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
abstract class AddCCSRemovalRecords implements ETLPostProcess {

    public static void main(final String args[]) throws SQLException {
        TransactionFactory
        .overRideRequestforDefaultTransactions(DataWarehouseConstants.kStagingDatabase);

        // add in the removal reason ETL name when the ETL is created.
        final ETLPostProcess c = new AddCCSRemovalRecords("S_CCSCHILDREMOVAL") {
        };
        c.executePostProcess("S_CCSCHILDREMOVAL");

    }

    /**
     * SQL statement to read reasons.
     */

    private String readStagingRemovalReasonsSQL;

    /**
     * SQL statement to insert removal reasons
     */
    private String insertStagingRemovalReasonsSQL;

    // ______________________________________________________________________
    /**
     * Public constructor.
     * 
     * @exception SQLException
     *              if a database operation fails
     */

    public AddCCSRemovalRecords() throws SQLException {
    }

    // ______________________________________________________________________
    /**
     * Initialize the internal state of the object.
     * 
     * @param inSourceTableName
     *          table name where source data resides
     * @exception SQLException
     *              if a database operation fails
     */

    public AddCCSRemovalRecords(final String inSourceTableName)
    throws SQLException {

        readStagingRemovalReasonsSQL = "select CHILDREMOVALID, REMOVALREASON, LASTWRITTEN from "
            + " S_CCSCHILDREMOVAL";

        insertStagingRemovalReasonsSQL = "insert into S_CCSREMOVALREASON (REMOVALID, CODE, LASTWRITTEN)"
            + " VALUES (?,?,?)";
    }

    // ______________________________________________________________________
    /**
     * Executes the transformational logic.
     * 
     * @param inTargetTableName
     *          table name where source data resides
     * @exception SQLException
     *              if a database operation fails
     */
    public void executePostProcess(final String inTargetTableName)
    throws SQLException {
        // stored success of SQL statements

        boolean failed = false;
        // the database transaction
        Transaction transaction = null;

        try {
            // start a transaction
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            processSourceData();

            PostProcessFactory.newInstance().executePostProcess(inTargetTableName);

        } catch (final Exception e) {
            System.out.println("Add CCS removal reasons:execute : caught exception "
                    + readStagingRemovalReasonsSQL + e.getMessage());
            failed = true;
            // do not throw an exception, allow our test process to
            // pick up on any data quality issues.

        } finally {
            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                    System.out.println("Add CCS removal reasons::failed");
                } else {
                    // commit the changes
                    transaction.commit();
                    System.out.println("Add CCS removal reasons::successful");
                }
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Processes the removal reasons.
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    /**
     * @throws SQLException
     */
    private void processSourceData() throws SQLException {

        // stored the record from the database
        PreparedStatement read = null;
        final Transaction transaction = TransactionFactory.getTransaction(
                DataWarehouseConstants.kDefaultDatabase);
        PreparedStatement insertStatement = null;
        int numberOfRemovalsProcessed = 0;
        final int commitLevel = 1000;
        int uncommitted = 0;
        try {
            final Connection connection = transaction.getConnection();

            read = connection.prepareStatement(readStagingRemovalReasonsSQL);

            final ResultSet rs = read.executeQuery();
            RemovalReason removalReason;

            while (rs.next()) {
                removalReason = new RemovalReason(rs.getLong(1), rs.getString(2),
                        rs.getTimestamp(3));
                if (numberOfRemovalsProcessed == 0) {
                    insertStatement = connection
                    .prepareStatement(insertStagingRemovalReasonsSQL);
                }
                insertRemovalReasons(removalReason, insertStatement);
                uncommitted++;
                numberOfRemovalsProcessed++;
                if (uncommitted >= commitLevel) {
                    transaction.executeBatch(insertStatement);
                    uncommitted = 0;
                }
            }
            if (uncommitted >= 0) {
                transaction.executeBatch(insertStatement);
                uncommitted = 0;
            }
            System.out.println("Add CCS removal reasons : "
                    + numberOfRemovalsProcessed + "  removal records processed");

        } catch (final Exception e) {
            System.out.println("Add CCS removal reasons: "
                    + readStagingRemovalReasonsSQL + ":" + insertStagingRemovalReasonsSQL
                    + e);
            throw new SQLException("Add CCS removal reasons:execute: "
                    + e.getMessage());
        } finally {
            // release resources
            if (read != null) {
                read.close();
            }
            if (insertStatement != null) {
                insertStatement.close();
            }
        }
    }

    /**
     * inserts removal records into the staging table
     * 
     * @param removalReason
     *          record for possible insertion
     * @param statement
     *          insert SQL statement
     * @exception SQLException
     *              if a database operation fails
     */

    public void insertRemovalReasons(final RemovalReason removalReason,
            final PreparedStatement statement) throws SQLException {

        final String[] reasons = removalReason.getCode().split("\\\t");
        try {
            for (int i = 0; i < reasons.length; i++) {
                statement.setLong(1, removalReason.getRemovalID());
                statement.setString(2, reasons[i]);
                statement.setTimestamp(3, removalReason.getLastwritten());
                statement.addBatch();
            }
        } catch (final Exception e) {

            System.out.println("Add CCS removal reasons::insertRemovalReasons:"
                    + insertStagingRemovalReasonsSQL + e);
            System.err.println("Add CCS removal reasons::insertRemovalReasons:" + e);
        }

    }

    // __________________________________________________________________

    /**
     * value object for reason data.
     */
    class RemovalReason {

        public long getRemovalID() {
            return removalID;
        }

        public Timestamp getLastwritten() {
            return lastwritten;
        }

        public String getCode() {
            return code;
        }

        /**
         * the surrogate identity.
         */
        private final long removalID;

        /**
         * the date .
         */
        private final Timestamp lastwritten;

        /**
         * the status .
         */
        private final String code;

        /**
         * Removal record
         * 
         * @param inRemovalID
         *          the unique key
         * @param inCode
         *          the removal code
         * @param inLastWritten
         *          last update date
         */
        public RemovalReason(
                final long inRemovalID,
                final String inCode,
                final Timestamp inLastWritten) {
            removalID = inRemovalID;
            lastwritten = inLastWritten;
            code = inCode;
        }
    }

}
