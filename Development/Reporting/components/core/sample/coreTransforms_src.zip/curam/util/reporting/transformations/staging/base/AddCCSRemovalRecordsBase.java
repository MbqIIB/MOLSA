/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * * Copyright 2005 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.staging.base;

import java.sql.SQLException;

/**
 *
 * Converts removal reason codes which are packed into a single column into
 * rows.
 *
 *
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
public class AddCCSRemovalRecordsBase extends AddCCSRemovalRecords {

  // ______________________________________________________________________
  /**
   * Initialize the internal state of the object.
   *
   * @param inSourceTableName
   *          table name where source data resides
   * @exception SQLException
   *              if a database operation fails
   */

  public AddCCSRemovalRecordsBase(final String inSourceTableName)
      throws SQLException {
    super(inSourceTableName);
  }

}
