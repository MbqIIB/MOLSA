/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.central.intf;

import java.sql.SQLException;

import curam.util.type.*;

/**
 * 
 * This module defines the interface for loading case history records into the
 * case status history table.
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public interface StateNameLookup {
  /**
   * 
   * @param inState
   * @return the state primary key
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public long findStateKey(final String inState) throws SQLException;

}
