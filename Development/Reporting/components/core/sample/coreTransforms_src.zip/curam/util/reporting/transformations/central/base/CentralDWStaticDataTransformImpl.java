/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.central.base;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;

import curam.util.type.*;

/**
 * This module is a hook point that can be used to update data nightly
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
abstract class CentralDWStaticDataTransformImpl {

  /**
   * SQL to update the person table
   */
  private String insertDummyPersonHistory;

  // ___________________________________________________________________________
  /**
   * Creates an object which executes in batch mode and updates schema data.
   * 
   * @throws SQLException
   *           if database error occurs
   */
  public CentralDWStaticDataTransformImpl() throws SQLException {

    final TargetDataBaseType targetDataBaseType = TransactionFactory
        .getTargetDatabaseType(DataWarehouseConstants.kDefaultDatabase);

    if (targetDataBaseType.isORACLE()) {
      insertDummyPersonHistory = "insert into dw_personhistory ("
          + "DWPERSONHISTORYID,DWNATIONALITYKEY, DWPARTICIPANTSTATUSID,DWINDIGENOUSGROUPKEY,DWRACETYPEKEY, DWPERSONTYPEKEY, DWPARTICIPANTID,STARTDATE,LASTWRITTEN) "
          + " values (" + "-1, -1, -1, -1, -1,-1, -1, sysdate, ?)";

    } else if (targetDataBaseType.isDB2()) {
      insertDummyPersonHistory = "insert into dw_personhistory ("
          + "DWPERSONHISTORYID,DWPARTICIPANTSTATUSID,DWPARTICIPANTID,STARTDATE,LASTWRITTEN) "
          + " values (" + "-1, -1, -1, current_date, ?)";
    }
  }

  // ___________________________________________________________________________
  /**
   * This method sets the data changed capture dates in the control tables
   * 
   * 
   * @throws java.sql.SQLException
   *           if a database operation failed
   */
  public void executePreProcess() throws SQLException {
    // if an SQL statement failed, initialize to false
    boolean failed = false;
    // the database transaction
    Transaction transaction = null;

    try {
      // start a transaction, get DAO to read from the control table
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);

      executeInsertSQL(insertDummyPersonHistory, true);

    } catch (Exception e) {
      System.out.println("CentralDWStaticDataTransformImpl: caught exception "
          + e.getMessage());
      failed = true;
      throw new SQLException("CentralDWStaticDataTransformImpl:"
          + e.getMessage());
    } finally {

      if (transaction != null && !transaction.isClientManagedTransaction()) {
        if (failed) {
          transaction.rollback();
          System.out
              .println("CentralDWStaticDataTransformImpl:failed, transaction rolled back");
        } else {
          // commit the changes
          transaction.commit();
          System.out
              .println("CentralDWStaticDataTransformImpl:transaction commited, processed ");
        }
      }
    }
  }

  // __________________________________________________________________________
  /**
   * Inserts a dummy record if it is not already there.
   */
  private void executeInsertSQL(final String SQLQuery, boolean inSetLastWritten)
      throws SQLException {
    PreparedStatement statement = null;
    Transaction transaction = null;
    try {
      // get a new connection
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);

      final Connection connection = transaction.getConnection();
      statement = connection.prepareStatement(SQLQuery);

      if (inSetLastWritten) {
        statement.setDate(1, new java.sql.Date(System.currentTimeMillis()));
      }

      final int rowsUpdated = statement.executeUpdate();
      System.out.println("Info: " + rowsUpdated + " row(s) added by "
          + System.getProperty("line.separator") + "<" + SQLQuery + ">");
    } catch (Exception e) {
      System.out.println("Warning: The row already exists; " + e.getMessage()
          + System.getProperty("line.separator") + "<" + SQLQuery + ">");
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }

  }

  // __________________________________________________________________________
  /**
   * Inserts a dummy record if it is not already there.
   */
  @SuppressWarnings("unused")
  private void insertStaticData(final String inSQL,
      final Iterator<MedicalAssistance> inValues, final boolean inHasLastwritten)
      throws SQLException {
    PreparedStatement statement = null;
    Transaction transaction = null;
    MedicalAssistance statusKeys;
    try {
      // get a new connection
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);

      final Connection connection = transaction.getConnection();
      statement = connection.prepareStatement(inSQL);

      while (inValues.hasNext()) {
        statusKeys = (MedicalAssistance) inValues.next();
        try {
          statement.setInt(1, statusKeys.getMaintenanceAssistenceStatusKey());

          statement.setString(2,
              statusKeys.getMaintenanceAssistenceStatusCode());
          statement.setString(3, statusKeys.getMasStatusValue());
          if (inHasLastwritten) {
            statement.setDate(4, new java.sql.Date(System.currentTimeMillis()));
          }
          final int rowsUpdated = statement.executeUpdate();
          if (rowsUpdated != 1) {
            System.out.println("Warning: " + rowsUpdated
                + " row(s) added to medicaid statuses.");
          }
        } catch (Exception e) {
          System.out.println("Warning: The row already exists; "
              + e.getMessage() + System.getProperty("line.separator") + "<"
              + inSQL + ">");
        }
      }
      System.out.println("Inserted medicaid statuses");
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }

  }

}
