/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.coredatamarts.fact;

import java.sql.SQLException;

import curam.util.reporting.transformations.coredatamarts.base.ParticipantToDateTransformBase;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;

import curam.util.type.*;

/**
 * Factory class to create an instance of data marts participant time period
 * {@link ETLPostProcess} class, one of its subclasses, a proxy for it or a mock
 * object for it.
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public final class ParticipantToDateFactory {

  // __________________________________________________________________________
  /**
   * Private constructor ensures no instances of this class.
   */
  private ParticipantToDateFactory() {
  }

  // __________________________________________________________________________
  /**
   * Returns a new object to post process history records.
   * 
   * @param inSourceTable
   *          the source table name
   * @return ETLPostProcess
   * @throws SQLException
   *           if the address cannot be transformed
   */
  public static ETLPostProcess newInstance(final String inSourceTable)
      throws SQLException {
    // returns the base implementation of the data access object
    ETLPostProcess etlPostProcess;

    etlPostProcess = new ParticipantToDateTransformBase(inSourceTable);

    return etlPostProcess;
  }

}
