/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.central.base;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.fact.PostProcessFactory;
import curam.util.reporting.transformations.central.dbclient.CustomTransforms;
import curam.util.reporting.transformations.central.intf.CaseStatusHistoryTransfrom;
import curam.util.type.*;

/**
 * Create a new object to add case registered and received statuses.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
abstract class CaseStatusHistoryTransformImpl implements
CaseStatusHistoryTransfrom {
    /**
     * SQL insert statement for status history table.
     */
    private String sqlInsertStatus = "insert into dw_casestatushistory values"
        + " (DWCASESTATUSHISTSEQ.nextval, ?, ?, -1, ?, ?, ?, ?)";

    /**
     * reads status keys for registered and received statuses.
     */
    private final String kSQLSelectStatus = "select dwstatusid from dw_casestatus "
        + " where statusname=?  or statusname=? or statusname=? order by statusname";

    /**
     * reads source case data. to improve performance only select new records.
     */
    private final String kSQLSelectSourceData =
        "SELECT T1.DWCASEID, T1.REGISTRATIONDATE, T1.RECEIVEDDATE, T1.LASTWRITTEN,t1.startdate "
        + " FROM DW_CASE T1, "
        + " (select last_etl_date from DW_ETLCONTROL where targettablename=?) DW_TEMPCONTROL "
        + " WHERE t1.dwcaseid=t1.dwcaseid and t1.lastwritten >= DW_TEMPCONTROL.last_etl_date"
        + " and (t1.registrationdate is not null Or t1.receiveddate is not null or t1.startdate is not null)";

    /**
     * the received status surrogate key.
     */
    private long startDateStatusKey = -1;

    /**
     * the registered status surrogate key.
     */
    private long registeredStatusKey = -1;

    /**
     * the received status surrogate key.
     */
    private long receivedStatusKey = -1;

    /**
     * the received status value.
     */
    private final String kReceivedStatus = "Received";

    /**
     * the registered status value.
     */
    private final String kStartDateStatus = "Case Start";

    /**
     * the registered status value.
     */
    private final String kRegisteredStatus = "Registered";

    /**
     * the registered status value.
     */
    public final String kClosedStatus = "Closed";

    public static void main(final String args[]) throws SQLException {
        System.out
        .println("Executing address transforms, you must ensure that data exists in S_CASEHEADER and DW_CASE.");
        System.out
        .println("and that preprocess has executed or the extract time column has a non null value.");
        TransactionFactory
        .overRideRequestforDefaultTransactions(DataWarehouseConstants.kCentralDatabase);
        CustomTransforms.addRegisteredRecievedStatus("DW_CASE_TRANSFORM");
    }

    // ___________________________________________________________________________
    /**
     * Create a new object to add new case statuses.
     * 
     */
    public CaseStatusHistoryTransformImpl() {
        TargetDataBaseType targetDataBaseType;
        try {
            targetDataBaseType = TransactionFactory
            .getTargetDatabaseType(DataWarehouseConstants.kDefaultDatabase);
            if (targetDataBaseType.isDB2()) {
                sqlInsertStatus = "insert into dw_casestatushistory values"
                    + " (nextval for DWCASESTATUSHISTSEQ, ?, ?, -1, ?, ?, ?, ?)";
            } else {
            }
        } catch (final SQLException e) {
            System.out
            .println("CaseStatusHistoryTransformImpl:failed in constructor");
        }
    }

    // ___________________________________________________________________________
    /**
     * Returns the closure reason where the case status is closed.
     * 
     * @param inCaseStatus
     *          the case status, e.g. open, closed etc.
     * @param inDescription
     *          the case status description
     * 
     * @return String the description
     * 
     * @exception SQLException
     *              if a database operation fails
     */
    public String isClosureReason(final String inCaseStatus,
            final String inDescription) throws SQLException {
        if (kClosedStatus.equalsIgnoreCase(inCaseStatus)) {
            return inDescription;
        } else {
            return null;
        }
    }

    // ___________________________________________________________________________
    /**
     * Inserts registration and received status records into the case status
     * history table.
     * 
     * @param inTargetTableName
     *          table name where source data resides
     * @exception SQLException
     *              if a database operation fails
     */
    public void executePostProcess(final String inTargetTableName)
    throws SQLException {
        // stored success of SQL statements
        boolean failed = false;
        // the database transaction
        Transaction transaction = null;
        try {
            // start a transaction
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            readRegisteredReceivedKeys();
            readSourceData(
                    kSQLSelectSourceData, inTargetTableName);
            PostProcessFactory.newInstance().executePostProcess(inTargetTableName);
        } catch (final Exception e) {
            System.out
            .println("CaseStatusHistoryTransformImpl:execute: caught exception "
                    + e.getMessage());
            failed = true;
            // do not throw an exception, allow our test process to
            // pick up on any data quality issues.
        } finally {
            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                    System.out.println("CaseStatusHistoryTransformImpl:failed");
                } else {
                    // commit the changes
                    transaction.commit();
                    System.out.println("CaseStatusHistoryTransformImpl:successfull");
                }
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Returns the set of cases that may require status record to be inserted.
     * 
     * @param inSQLSelect
     *          the SQL to read source data
     * @param inTargetTableName
     * @return List a null object
     * @exception SQLException
     *              if a database operation fails
     */
    public List<RegisteredRecivedCase> readSourceData(final String inSQLSelect,
            final String inTargetTableName) throws SQLException {
        // stored the record from the database
        PreparedStatement read = null;
        PreparedStatement insertStatement = null;
        try {
            final Transaction transaction = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();
            insertStatement = connection.prepareStatement(sqlInsertStatus);
            read = connection.prepareStatement(inSQLSelect);
            read.setString(1, inTargetTableName);
            final ResultSet rs = read.executeQuery();
            RegisteredRecivedCase caseRecord;
            int recoredProcessed = 0;
            final int commitLevel = 1000;
            int uncommitted = 0;
            while (rs.next()) {
                caseRecord = new RegisteredRecivedCase(rs.getLong(1), rs.getDate(2),
                        rs.getDate(3), rs.getDate(4), rs.getDate(5));

                if (caseRecord != null) {
                    // if the registered date is populated insert registered status
                    if (caseRecord.registrationDate != null) {
                        insertStatement.setLong(1, registeredStatusKey);
                        insertStatement.setLong(2, caseRecord.dwCaseID);
                        insertStatement.setDate(3, caseRecord.registrationDate);
                        insertStatement.setDate(4, caseRecord.registrationDate);
                        insertStatement.setString(5, kRegisteredStatus);
                        insertStatement.setDate(6, caseRecord.lastwritten);
                        try {
                            insertStatement.addBatch();
                            uncommitted++;
                        } catch (final SQLException e) {
                            System.out.println("info: registeredStatusKey already exists-"
                                    + e.getMessage());
                            // ignore constraint violation
                        }
                    }
                    if (caseRecord.receivedDate != null) {
                        // if the received date is populated insert received status
                        // set status identity
                        insertStatement.setLong(1, receivedStatusKey);
                        insertStatement.setLong(2, caseRecord.dwCaseID);
                        insertStatement.setDate(3, caseRecord.receivedDate);
                        insertStatement.setDate(4, caseRecord.receivedDate);
                        insertStatement.setString(5, kReceivedStatus);
                        insertStatement.setDate(6, caseRecord.lastwritten);
                        try {
                            insertStatement.addBatch();
                            uncommitted++;
                        } catch (final SQLException e) {
                            System.out.println("info: receivedStatusKey already exists-"
                                    + e.getMessage());
                            // ignore constraint violation
                        }
                    }
                    if (caseRecord.startDate != null) {
                        // if the start date is populated insert case start
                        // status
                        // set status identity
                        insertStatement.setLong(1, startDateStatusKey);
                        insertStatement.setLong(2, caseRecord.dwCaseID);
                        insertStatement.setDate(3, caseRecord.startDate);
                        insertStatement.setDate(4, caseRecord.startDate);
                        insertStatement.setString(5, kStartDateStatus);
                        insertStatement.setDate(6, caseRecord.lastwritten);
                        try {
                            insertStatement.addBatch();
                            uncommitted++;
                        } catch (final SQLException e) {
                            System.out.println("info: startDateStatusKey already exists-"
                                    + e.getMessage());
                            // ignore constraint violation
                        }
                    }
                }

                recoredProcessed++;
                if (uncommitted >= commitLevel) {
                    transaction.executeBatch(insertStatement);
                    uncommitted = 0;
                }
            }
            if (uncommitted >= 0) {
                transaction.executeBatch(insertStatement);
                uncommitted = 0;
            }
            System.out.println("CaseStatusHistoryTransformImpl:" + recoredProcessed
                    + " caseheader records processed");
        } finally {
            try {
                // release resources
                if (read != null) {
                    read.close();
                }
                if (insertStatement != null) {
                    insertStatement.close();
                }
            } catch (final Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    // ___________________________________________________________________________
    /**
     * Returns the set of cases that may require status record to be inserted.
     * 
     * @param inStatusRecords
     *          record for possible insertion
     * @param inInsertSQL
     *          insert statement
     * @exception SQLException
     *              if a database operation fails
     * @deprecated since 6.0.5.1, requires a list argument, the list may be too
     *                   large and result in a out of memory exception
     */
    @SuppressWarnings ("unused")
    @Deprecated
    private void insertStatusRecords(final RegisteredRecivedCase inStatusRecords,
            final PreparedStatement inInsertSQL) throws SQLException {
        // stored the record from the database
        final PreparedStatement statement = inInsertSQL;
        try {
            RegisteredRecivedCase caseRecord = null;
            int registeredStatusesInserted = 0;
            int receivedStatusesInserted = 0;
            int caseStartDateStatusesInserted = 0;
            if (inStatusRecords != null) {
                caseRecord = inStatusRecords;
                // if the registered date is populated insert registered status
                if (caseRecord.registrationDate != null) {
                    statement.setLong(1, registeredStatusKey);
                    statement.setLong(2, caseRecord.dwCaseID);
                    statement.setDate(3, caseRecord.registrationDate);
                    statement.setDate(4, caseRecord.registrationDate);
                    statement.setDate(5, caseRecord.lastwritten);
                    try {
                        final int rowsUpdated = statement.executeUpdate();
                        registeredStatusesInserted += rowsUpdated;
                    } catch (final SQLException e) {
                        System.out.println("info: registeredStatusKey already exists-"
                                + e.getMessage());
                        // ignore constraint violation
                    }
                }
                if (caseRecord.receivedDate != null) {
                    // if the received date is populated insert received status
                    // set status identity
                    statement.setLong(1, receivedStatusKey);
                    statement.setLong(2, caseRecord.dwCaseID);
                    statement.setDate(3, caseRecord.receivedDate);
                    statement.setDate(4, caseRecord.receivedDate);
                    statement.setDate(5, caseRecord.lastwritten);
                    try {
                        final int rowsUpdated = statement.executeUpdate();
                        receivedStatusesInserted += rowsUpdated;
                    } catch (final SQLException e) {
                        System.out.println("info: receivedStatusKey already exists-"
                                + e.getMessage());
                        // ignore constraint violation
                    }
                }
                if (caseRecord.startDate != null) {
                    // if the start date is populated insert case start
                    // status
                    // set status identity
                    statement.setLong(1, startDateStatusKey);
                    statement.setLong(2, caseRecord.dwCaseID);
                    statement.setDate(3, caseRecord.startDate);
                    statement.setDate(4, caseRecord.startDate);
                    statement.setDate(5, caseRecord.lastwritten);
                    try {
                        final int rowsUpdated = statement.executeUpdate();
                        caseStartDateStatusesInserted += rowsUpdated;
                    } catch (final SQLException e) {
                        System.out.println("info: startDateStatusKey already exists-"
                                + e.getMessage());
                        // ignore constraint violation
                    }
                }
            }
        } catch (final Exception e) {
            throw new SQLException("CaseStatusHistoryTransformImpl:insertStatuses:"
                    + e.getMessage());
        }
    }

    // ___________________________________________________________________________
    /**
     * Returns the set of cases that may require status record to be inserted.
     * 
     * @param inStatusRecords
     *          record for possible insertion
     * @param inInsertSQL
     *          insert statement
     * @exception SQLException
     *              if a database operation fails
     */
    public void insertStatuses(final List<RegisteredRecivedCase> inStatusRecords,
            final String inInsertSQL) throws SQLException {

        if (inStatusRecords == null || inStatusRecords.size() == 0){
            return;
        }
        // stored the record from the database
        PreparedStatement insertStatement = null;
        try {
            RegisteredRecivedCase caseRecord = null;
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();
            insertStatement = connection.prepareStatement(inInsertSQL);
            final Iterator<RegisteredRecivedCase> records = inStatusRecords
            .iterator();
            int registeredStatusesInserted = 0;
            int receivedStatusesInserted = 0;
            int caseStartDateStatusesInserted = 0;
            while (records.hasNext()) {
                caseRecord = (RegisteredRecivedCase) records.next();
                // if the registered date is populated insert registered status
                if (caseRecord.registrationDate != null) {
                    // set status id
                    insertStatement.setLong(1, registeredStatusKey);
                    // set status case identity
                    insertStatement.setLong(2, caseRecord.dwCaseID);
                    // set from date
                    insertStatement.setDate(3, caseRecord.registrationDate);
                    // set to date
                    insertStatement.setDate(4, caseRecord.registrationDate);
                    // set last written
                    insertStatement.setDate(5, caseRecord.lastwritten);
                    try {
                        final int rowsUpdated = insertStatement.executeUpdate();
                        registeredStatusesInserted += rowsUpdated;
                    } catch (final SQLException e) {
                        // to improve performance we execute an insert and fail
                        // rather
                        // than a read to see if the record already exists and
                        // not
                        // attempt the insert
                        //System.out.println("info: registeredStatusKey already exists-"
                        //        + e.getMessage());
                        // ignore constraint violation
                    }
                }
                if (caseRecord.receivedDate != null) {
                    // if the received date is populated insert received status
                    // set status identity
                    insertStatement.setLong(1, receivedStatusKey);
                    // set status case identity
                    insertStatement.setLong(2, caseRecord.dwCaseID);
                    // set from date
                    insertStatement.setDate(3, caseRecord.receivedDate);
                    // set received date
                    insertStatement.setDate(4, caseRecord.receivedDate);
                    // set last written
                    insertStatement.setDate(5, caseRecord.lastwritten);
                    try {
                        final int rowsUpdated = insertStatement.executeUpdate();
                        receivedStatusesInserted += rowsUpdated;
                    } catch (final SQLException e) {
                        // to improve performance we execute an insert and fail
                        // rather
                        // than a read to see if the record already exists and
                        // not
                        // attempt the insert
                        // System.out.println("info: receivedStatusKey already exists-"
                        //        + e.getMessage());
                        // ignore constraint violation
                    }
                }
                if (caseRecord.startDate != null) {
                    // if the start date is populated insert case start
                    // status
                    // set status identity
                    insertStatement.setLong(1, startDateStatusKey);
                    // set status case identity
                    insertStatement.setLong(2, caseRecord.dwCaseID);
                    // set from date
                    insertStatement.setDate(3, caseRecord.startDate);
                    // set received date
                    insertStatement.setDate(4, caseRecord.startDate);
                    // set last written
                    insertStatement.setDate(5, caseRecord.lastwritten);
                    try {
                        final int rowsUpdated = insertStatement.executeUpdate();
                        caseStartDateStatusesInserted += rowsUpdated;
                    } catch (final SQLException e) {
                        // to improve performance we execute an insert and
                        // fail rather
                        // than a read to see if the record already exists
                        // and not
                        // attempt the insert
                        //System.out.println("info: startDateStatusKey already exists-"
                        //        + e.getMessage());
                        // ignore constraint violation
                    }
                }
            }
            // do not log for performance reasons.
        } catch (final Exception e) {
            // do not log for performance reasons.
            // System.out.println("CaseStatusHistoryTransformImpl:insertStatuses:" +
            // e);
            throw new SQLException("CaseStatusHistoryTransformImpl:insertStatuses:"
                    + e.getMessage());
        } finally {
            // release resources
            if (insertStatement != null) {
                insertStatement.close();
            }
        }
    }

    // __________________________________________________________________________
    /**
     * Read the keys for status registered and received.
     * 
     * @throws SQLException
     *           if a database operation fails
     */
    public void readRegisteredReceivedKeys() throws SQLException {
        PreparedStatement statement = null;
        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();
            statement = connection.prepareStatement(kSQLSelectStatus);
            statement.setString(1, kRegisteredStatus);
            statement.setString(2, kReceivedStatus);
            statement.setString(3, kStartDateStatus);
            final ResultSet rs = statement.executeQuery();
            // we are only expecting 3 records, received and registered, and
            // case start in order
            if (rs.next()) {
                startDateStatusKey = rs.getLong(1);
            }
            if (rs.next()) {
                receivedStatusKey = rs.getLong(1);
            }
            if (rs.next()) {
                registeredStatusKey = rs.getLong(1);
            }
        } catch (final Exception e) {
            throw new SQLException("readRegisteredReceivedKeys:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
    }

    /**
     * Case status history key data.
     */
    class RegisteredRecivedCase {
        /**
         * the surrogate case identity.
         */
        private final long dwCaseID;

        /**
         * the registered date for a case.
         */
        private final Date registrationDate;

        /**
         * the received date for a case.
         */
        private final Date receivedDate;

        /**
         * the received date for a case.
         */
        private final Date startDate;

        /**
         * the date the case was last updated.
         */
        private final Date lastwritten;

        /**
         * Creates data for a new status record.
         * 
         * @param inDWCaseID
         *          case surrogate key
         * @param inRegistrationDateDate
         *          registration date
         * @param inReceivedDate
         *          received date
         * @param inLastwritten
         *          date case was last modified
         * @param inCreatedDate
         */
        public RegisteredRecivedCase(
                final long inDWCaseID,
                final Date inRegistrationDateDate,
                final Date inReceivedDate,
                final Date inLastwritten,
                final Date inCreatedDate) {
            dwCaseID = inDWCaseID;
            registrationDate = inRegistrationDateDate;
            receivedDate = inReceivedDate;
            startDate = inCreatedDate;
            lastwritten = inLastwritten;
        }
    }
}
