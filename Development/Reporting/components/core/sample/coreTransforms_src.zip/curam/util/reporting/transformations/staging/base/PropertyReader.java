/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.staging.base;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Hashtable;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import java.sql.Connection;

/**
 * 
 * Reads a property from the database using the default language, if the default
 * language is not available for this property, the fall back of country is
 * tried and then finally no locale is tried.
 * 
 * 
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
abstract class PropertyReader {

  /**
   * SQL statement to read reasons.
   */

  private String readLanguageSQL;

  /**
   * the locale identifier, e.g. en_US
   */

  private String warehouseLanguageIdentifier = "";

  /**
   * SQL statement to insert removal reasons
   */
  private String readPropertySQL;

  static public final String localKey = "BI.BILOCALE";
  static public final String spaceCharReplacement = ".";

  // ______________________________________________________________________
  /**
   * Public constructor.
   * 
   * @exception SQLException
   *              if a database operation fails
   */

  public PropertyReader() throws SQLException {
  }

  // ______________________________________________________________________
  /**
   * Initialize the internal state of the object.
   * 
   * @param inSourceTableName
   *          table name where source data resides
   * @exception SQLException
   *              if a database operation fails
   */

  public PropertyReader(final String inSourceTableName) throws SQLException {

    readLanguageSQL = "select BIPROP_VALUE  from " + inSourceTableName
        + " where BIPROP_NAME=?";

    readPropertySQL = "select BIPROP_VALUE, LOCALE, DEFAULTVALUE from "
        + inSourceTableName + " where BIPROP_NAME=?";

  }

  // ______________________________________________________________________
  /**
   * Executes the transformational logic.
   * 
   * @param inBIPropertyName
   *          the property name
   * @exception SQLException
   *              if a database operation fails
   */
  public String readPropertyFromDB(final String inBIPropertyName)
      throws SQLException {
    // stored success of SQL statements

    boolean failed = false;
    // the database transaction
    Transaction transaction = null;
    // remove any spaces in the property to search for
    String searchFor = "";
    if (inBIPropertyName != null) {
      searchFor = inBIPropertyName.replace(" ", spaceCharReplacement);
    }

    try {
      // start a transaction
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);

      String propertyValue = readPropertyValue(searchFor);
      return propertyValue;
    } catch (Exception e) {
      System.out.println("readPropertyFromDB: " + e.getMessage());
      failed = true;
      throw new SQLException("readPropertyFromDB:" + e.getMessage());
    } finally {
      if (transaction != null && !transaction.isClientManagedTransaction()) {
        if (failed) {
          transaction.rollback();
          System.out.println("readPropertyFromDB:failed");
        } else {
          // commit the changes
          transaction.commit();
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Reads a property value.
   * 
   * @param inBIPropertyName
   *          the property to read
   * @exception SQLException
   *              if a database operation fails
   */
  private String readPropertyValue(String inBIPropertyName) throws SQLException {

    // stored the record from the database
    PreparedStatement readProperty = null;
    boolean propertyStatementClosed = false;
    // remove any spaces in the property to search for
    String searchFor = "";
    String localisedValue = "";
    if (inBIPropertyName != null) {
      searchFor = inBIPropertyName.replace(" ", spaceCharReplacement);
    }

    if (warehouseLanguageIdentifier.length() == 0) {
      readLanguage();
    }
    try {

      final Connection connection = TransactionFactory.getTransaction(
          DataWarehouseConstants.kDefaultDatabase).getConnection();

      readProperty = connection.prepareStatement(readPropertySQL);
      readProperty.setString(1, searchFor);
      ResultSet rs = readProperty.executeQuery();
      // cache for better performance in future releases
      Hashtable<String, String> properties = new Hashtable<String, String>();

      // examples of what values will be present
      // properties.put("test" + "en", "tested en");
      // properties.put("test" + "en_US", "tested en US");
      // properties.put("test" + "", "tested default");
      while (rs.next()) {
        String propertyValue = rs.getString(1);
        String localeIdentifier = rs.getString(2);
        String defaultValue = rs.getString(3);
        String actualValue = propertyValue;
        if (propertyValue == null || propertyValue.length() == 0) {
          actualValue = defaultValue;
        }
        String key = searchFor + "_" + localeIdentifier;
        properties.put(key, actualValue);
      }
      rs.close();
      readProperty.close();
      propertyStatementClosed = true;

      // try and get the key for the defined language, the defined language
      // might be "en_US"
      String defaultKey = searchFor + "_" + warehouseLanguageIdentifier;
      localisedValue = properties.get(defaultKey);
      if (localisedValue == null) {
        // use only the language code, might be "en"
        String languageOnlyLey = searchFor + getLanguagePart();
        localisedValue = properties.get(languageOnlyLey);
        if (localisedValue != null) {
          return localisedValue;
        }
        // if the property has no language and no country
        localisedValue = properties.get(searchFor);
        if (localisedValue != null) {
          return localisedValue;
        }

      }
      if (localisedValue == null) {
        localisedValue = inBIPropertyName.substring(0,
            (inBIPropertyName.length() > 10 ? 10 : inBIPropertyName.length()));
      }
      return localisedValue;

    } catch (Exception e) {
      System.out.println("readPropertyValue: " + readPropertySQL + ":" + e);
      throw new SQLException("readPropertyValue: " + e.getMessage());
    } finally {
      // release resources
      if (propertyStatementClosed == false && readProperty != null) {
        readProperty.close();
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Reads the language code only, does not include the country.
   * 
   * @exception SQLException
   *              if a database operation fails
   */
  public String getLanguagePart() throws SQLException {
    if (warehouseLanguageIdentifier.length() == 0) {
      readLanguage();
    }
    String language = "en";
    if (warehouseLanguageIdentifier.length() >= 2) {
      language = warehouseLanguageIdentifier.substring(0, 2);
    }
    return language;
  }

  // ___________________________________________________________________________
  /**
   * Reads the language and dialect.
   * 
   * @return String language and country code
   * @exception SQLException
   *              if a database operation fails
   */
  public String readLanguage() throws SQLException {

    // stored the record from the database
    PreparedStatement defaultLanguage = null;
    // default language code
    String theLocalIdentifier = "en_US";
    boolean languageStatementClosed = false;
    try {

      final Connection connection = TransactionFactory.getTransaction(
          DataWarehouseConstants.kDefaultDatabase).getConnection();

      defaultLanguage = connection.prepareStatement(readLanguageSQL);
      defaultLanguage.setString(1, localKey);
      ResultSet rs = defaultLanguage.executeQuery();
      while (rs.next()) {
        theLocalIdentifier = rs.getString(1);
      }

      warehouseLanguageIdentifier = theLocalIdentifier;
      rs.close();
      defaultLanguage.close();

    } catch (Exception e) {
      System.out.println("readLanguage: " + readLanguageSQL + ":"
          + readLanguageSQL + e);
      throw new SQLException("readLanguage: " + e.getMessage());
    } finally {
      // release resources
      if (languageStatementClosed == false && defaultLanguage != null) {
        defaultLanguage.close();
      }
    }
    return warehouseLanguageIdentifier;
  }
}
