/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.central.fact;

import java.sql.SQLException;

import curam.util.reporting.transformations.central.base.EndDateTransformBase;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;

import curam.util.type.*;

/**
 * Factory class to create an instance of warehouse end date transformation
 * {@link ETLPostProcess} class, one of its subclasses, a proxy for it or a mock
 * object for it.
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public final class EndDateFactory {

  // __________________________________________________________________________
  /**
   * Private constructor ensures no instances of this class.
   */
  private EndDateFactory() {
  }

  // __________________________________________________________________________
  /**
   * Returns a new object to post process history records.
   * 
   * @param inSourceTable
   *          the source table name
   * 
   * @param inSourceKey
   *          the logical key
   * @return ETLPostProcess
   * @throws SQLException
   *           if the address cannot be transformed
   */
  public static ETLPostProcess newInstance(final String inSourceTable,
      final String inSourceKey) throws SQLException {
    // returns the base implementation of the data access object
    ETLPostProcess etlPostProcess;

    etlPostProcess = new EndDateTransformBase(inSourceTable, inSourceKey);

    return etlPostProcess;
  }

  // __________________________________________________________________________
  /**
   * Returns a new object to post process history records.
   * 
   * @param inSourceTable
   *          the source table name
   * @param inSourceDataETLName
   *          - the name of the control entry that adds the raw data.
   * @param inSourceKey
   *          the logical key
   * @return ETLPostProcess
   * @throws SQLException
   *           if the address cannot be transformed
   */
  public static ETLPostProcess newInstanceSCD(final String inSourceTable,
      final String inSourceKey) throws SQLException {
    // returns the base implementation of the data access object
    ETLPostProcess etlPostProcess;

    EndDateTransformBase endDateTransformBase = new EndDateTransformBase(
        inSourceTable, inSourceKey);
    endDateTransformBase.setUseSCD(true);
    etlPostProcess = endDateTransformBase;
    return etlPostProcess;
  }

}
