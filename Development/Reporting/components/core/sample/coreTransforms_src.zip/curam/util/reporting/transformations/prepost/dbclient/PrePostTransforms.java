/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.prepost.dbclient;

import java.sql.SQLException;

import curam.util.reporting.internal.transformations.prepost.fact.PostProcessFactory;
import curam.util.reporting.internal.transformations.prepost.fact.PreProcessFactory;
import curam.util.reporting.internal.transformations.prepost.fact.UtilitiesFactory;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;
import curam.util.reporting.internal.transformations.prepost.intf.ETLUtility;

import curam.util.type.*;

/**
 * 
 * This class is the interface or entry point between the database and the
 * staging transformations.
 * 
 * The interface specification is enforced by the Oracle and DB2 call
 * specifications A call spec exposes a Java methods top-level entry point to
 * Oracle..
 * 
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public class PrePostTransforms {

  // ___________________________________________________________________________
  /**
   * For Oracle only. Sets the extract start date for an ETL process and clears
   * down the staging target table if required
   * 
   * @param inTargetTableName
   *          the target table being populated
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  static public void preProcessETL(String inTargetTableName)
      throws SQLException {

    PreProcessFactory.newInstance().executePreProcess(inTargetTableName);
  }

  /**
   * for DB2 only
   * 
   * @param inTargetTableName
   * @param out
   *          the last extract date
   * @throws SQLException
   */
  static public void preProcessETL(String inTargetTableName,
      java.sql.Timestamp[] out) throws SQLException {

    out[0] = PreProcessFactory.newInstance().executePreProcess(
        inTargetTableName);

  }

  // ___________________________________________________________________________
  /**
   * Sets the extract start date for an ETL process and clears down the target
   * table
   * 
   * @param inTargetTableName
   *          the target table being populated
   * @param out
   *          the last extract date
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  static public void testProcedureReturnTimestamp(String inTargetTableName,
      java.sql.Timestamp[] out) throws SQLException {

    out[0] = new java.sql.Timestamp(System.currentTimeMillis());
  }

  // ___________________________________________________________________________
  /**
   * Sets the extract start date for an ETL process and clears down the target
   * table
   * 
   * @param inTargetTableName
   *          the target table being populated
   * 
   * @param out
   *          the last extract date
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  static public void testProcedureReturnDate(String inTargetTableName,
      java.sql.Date[] out) throws SQLException {

    out[0] = new java.sql.Date(System.currentTimeMillis());
  }

  // ___________________________________________________________________________
  /**
   * Sets the extract start date for an ETL process and clears down the target
   * table
   * 
   * @param inTargetTableName
   *          the target table being populated
   * 
   * @param out
   *          the last extract date
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  static public void testProcedureReturnString(String inTargetTableName,
      String[] out) throws SQLException {

    out[0] = "returning 1";
  }

  /**
   * A test harness method and example when returning a specific data type
   * 
   * @param inTargetTableName
   *          sample string input parameter
   * @return a string value
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  static public String testReturnString(String inTargetTableName)
      throws SQLException {
    PreProcessFactory.newInstance();
    return inTargetTableName + " version 1";
  }

  /**
   * A test harness method and example when returning a specific data type
   * 
   * @return a int value
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  static public int testReturnInt() throws SQLException {
    PreProcessFactory.newInstance();
    return 1;
  }

  /**
   * A test harness method and example when returning a specific data type
   * 
   * @return a long value
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  static public long testReturnLong() throws SQLException {
    PreProcessFactory.newInstance();
    return 2;
  }

  /**
   * A test harness method and example when returning a specific data type
   * 
   * @return a date value
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  static public java.sql.Date testReturnDate() throws SQLException {
    PreProcessFactory.newInstance();
    java.util.Calendar testDate = java.util.Calendar.getInstance();
    testDate.set(2011, 0, 31);

    return new java.sql.Date(testDate.getTimeInMillis());
  }

  /**
   * A test harness method and example when returning a specific data type
   * 
   * @return a timestamp value
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  static public java.sql.Timestamp testReturnTimestamp() throws SQLException {
    PreProcessFactory.newInstance();
    return new java.sql.Timestamp(System.currentTimeMillis());
  }

  // ___________________________________________________________________________
  /**
   * Set the last ETL date for an ETL process
   * 
   * @param inTargetTableName
   *          the target table being populated
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  static public void postProcessETL(String inTargetTableName)
      throws SQLException {

    ETLPostProcess etlPostProcess = PostProcessFactory.newInstance();

    etlPostProcess.executePostProcess(inTargetTableName);
  }

  // ___________________________________________________________________________
  /**
   * Right pads a string to a given length.
   * 
   * @param inSourceString
   *          String the source string, max of 200 at present
   * @param inLength
   *          the pad length
   * @param inPadChar
   *          the pad character
   * @return the string padded to the specified length
   * @throws SQLException
   *           if a database operation fails
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  static public String rpad(final String inSourceString, final int inLength,
      final String inPadChar) throws SQLException {
    ETLUtility utilities = UtilitiesFactory.newInstance();

    return utilities.rpad(inSourceString, inLength, inPadChar);
  }

}
