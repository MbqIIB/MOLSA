/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.coredatamarts.base;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Hashtable;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.dao.control.base.ProcessControl;
import curam.util.reporting.internal.dao.control.fact.ControlTableFactory;
import curam.util.reporting.internal.dao.control.intf.ControlTable;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.base.PostProcessImpl;
import curam.util.reporting.transformations.coredatamarts.dbclient.CustomTransforms;
import curam.util.reporting.transformations.prepost.dbclient.PrePostTransforms;

/**
 * This module populates the fact case process day aggregate table
 * 
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
abstract class CaseFactProcessDayTransformImpl extends PostProcessImpl {
    Calendar start;

    /**
     * open status.
     */
    public static final String kOpenStatus = "Open";

    /**
     * submitted status.
     */
    public static final String kSubmittedStatus = "Submitted";

    /**
     * approved status.
     */
    public static final String kApprovedStatus = "Approved";

    /**
     * active status.
     */
    public static final String kActiveStatus = "Active";

    /**
     * active status.
     */
    public static final String kRegisteredStatus = "Registered";

    /**
     * active status.
     */
    public static final String kReceivedStatus = "Received";

    /**
     * open status.
     */
    public static final String kPendingClosureStatus = "Pending Closure";

    /**
     * SQL to insert an aggregate record.
     */
    private final String sqlInsert = "insert into dm_aggcaseday values(?,?,?,?,?,?,?,?)";

    /**
     * reads the set of rows to insert into the day table.
     */
    private final String kReadTimeKey = "select t1.timeperiodkey from  DM_dimtimeperiod t1 where t1.daydate=?";

    /**
     * reads the set of rows to insert into the day table.
     */
    private final String kSQLSelectGroupByOrgProduct = "select distinct ORGUNITKEY, DIMPRODUCTKEY"
        + " from  DM_FACTCASEHISTORY t1 where"
        + " t1.startdatekey <= ? and"
        + " (t1.enddatekey = -1 or t1.enddatekey > ?)"
        + " group by  ORGUNITKEY,  DIMPRODUCTKEY";

    /**
     * calculates the set totals required for the date being passed in.
     */
    private final String kSQLSelectByOrgProductCounts = "select t1.orgunitkey, t1.dimproductkey, "
        + " t2.statusname,  count(*)"
        + " from DM_FACTCASEHISTORY t1 , dm_dimstatus t2 where"
        + " t1.startdatekey <= ? and t1.statuskey=t2.statuskey and"
        + " (t1.enddatekey = -1 or t1.enddatekey > ?)"
        + " group by t1.orgunitkey, t1.dimproductkey, t2.statusname";

    public static void main(final String args[]) throws SQLException {
        // main method only used by the build script for debugging purposes
        System.out
        .println("manually delete data from the table for the months being processed.");
        System.out
        .println("Executing for each day from date in control table until now");
        TransactionFactory
        .overRideRequestforDefaultTransactions(DataWarehouseConstants.kCoreDataMartDatabase);
        PrePostTransforms.preProcessETL("DM_AGGCASEDAY");
        CustomTransforms.caseFactProcessDayAggregate("DM_AGGCASEDAY");
    }

    // ___________________________________________________________________________
    /**
     * Populates the aggregate day table using the case fact processes table.
     * 
     * @param inTargetTableName
     *          the target table being populated
     * @throws java.sql.SQLException
     *           if a database operation failed
     */
    @SuppressWarnings("deprecation")
    @Override
    public void executePostProcess(final String inTargetTableName)
    throws SQLException {
        boolean failed = false;
        // the database transaction
        Transaction transaction = null;
        Calendar now = null;
        long timeKey = 0;
        try {
            // final Calendar now = new GregorianCalendar(2004, 11, 31);
            now = new GregorianCalendar();
            // start a transaction, get DAO to read from the control table
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final ControlTable controlTable = ControlTableFactory
            .newInstance(new ReportingDBType(inTargetTableName));
            // get the last date the ETL was executed
            final ProcessControl processControl = controlTable
            .read(inTargetTableName);
            start = new GregorianCalendar(processControl.getLastExtractionDate()
                    .getYear() + 1900, processControl.getLastExtractionDate().getMonth(),
                    processControl.getLastExtractionDate().getDate());
            if (now.before(start)) {
                System.out.println("End date is before start date, check "
                        + " control table and system clock");
                return;
            }
            if (start.get(Calendar.YEAR) == now.get(Calendar.YEAR)
                    && start.get(Calendar.MONTH) == now.get(Calendar.MONTH)
                    && start.get(Calendar.DATE) == now.get(Calendar.DATE)) {
                System.out.println("Already executed for date  " + now.getTime());
                return;
            }
            System.out.println("START=" + start.getTime());
            System.out.println("NOW=" + now.getTime());
            boolean completed = false;
            // Loop through each day since last date it run until current date
            // -1 and process the cases
            do {
                timeKey = readTime(new java.sql.Date(start.getTime().getTime()));
                // months start at 0 in calendar and 1 in time period
                final DayAggregates dayAggregates = readAggregateSet(timeKey);
                processAggregates(dayAggregates, timeKey);
                // increase day by one
                start.add(Calendar.DATE, 1);
                // only process up to and including system date - 1 day
                if (start.get(Calendar.YEAR) == now.get(Calendar.YEAR)
                        && start.get(Calendar.MONTH) == now.get(Calendar.MONTH)
                        && start.get(Calendar.DATE) == now.get(Calendar.DATE)) {
                    completed = true;
                }
            } while (!completed);
            // update the control table
            super.executePostProcess(inTargetTableName);
        } catch (final Exception e) {
            System.out.println("CaseFactProcessTransformImpl: caught exception "
                    + e.getMessage());
            failed = true;
            // do not throw an exception, allow our test process to
            // pick up on any data quality issues.
        } finally {
            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                    System.out
                    .println("CaseFactProcessTransformImpl:failed, transaction rolled back "
                            + now.getTime());
                } else {
                    // commit the changes
                    transaction.commit();
                    System.out
                    .println("CaseFactProcessTransformImpl:transaction commited, processed "
                            + now.getTime());
                }
            }
        }
    }

    // __________________________________________________________________________
    /**
     * Generates a list of organizations by products that have case activity in a
     * given month.
     * 
     * @param inDayDate
     *          to day to be processed
     * 
     * @return List the aggregate records
     * @throws SQLException
     *           if a database operation fails
     */
    public DayAggregates readAggregateSet(final long inDayDate)
    throws SQLException {
        // stored the record from the database
        PreparedStatement statement = null;
        final DayAggregates aggregateRecords = new DayAggregates();
        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();
            statement = connection.prepareStatement(kSQLSelectGroupByOrgProduct);
            statement.setLong(1, inDayDate);
            statement.setLong(2, inDayDate);
            final ResultSet rs = statement.executeQuery();
            CaseProcessFactDayAggregate caseProcessFactDayAggregate;
            while (rs.next()) {
                caseProcessFactDayAggregate = new CaseProcessFactDayAggregate(
                        rs.getLong(1), rs.getLong(2), inDayDate);
                aggregateRecords.addDay(caseProcessFactDayAggregate);
            }
            System.out
            .println("CaseFactProcessDayTransformImpl:number of agg rows to add is "
                    + aggregateRecords.size()
                    + " time key is="
                    + inDayDate
                    + "date is= " + start.getTime());
        } catch (final Exception e) {
            System.out.println("CaseFactProcessDayTransform:readAggregateSet:" + e);
            throw new SQLException("CaseFactProcessDayTransform:readAggregateSet:"
                    + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
        return aggregateRecords;
    }

    // ___________________________________________________________________________
    /**
     * Returns a aggregate record totals by organization unit and product.
     * 
     * @param inDayAggregates
     *          aggregate records requiring totals
     * @throws SQLException
     *           if a database operation fails
     */
    private void processAggregates(final DayAggregates inDayAggregates,
            final long inDayDate) throws SQLException {
        // stored the record from the database
        PreparedStatement readStatement = null;
        CaseProcessFactDayAggregate aggregateRecord = null;
        PreparedStatement insertSatement = null;
        final Transaction transaction  = TransactionFactory.getTransaction(
                DataWarehouseConstants.kDefaultDatabase);
        final int commitLevel = 1000;
        int uncommitted = 0;
        try {
            final Connection connection = transaction.getConnection();

            insertSatement = connection.prepareStatement(sqlInsert);

            readStatement = connection.prepareStatement(kSQLSelectByOrgProductCounts);
            readStatement.setLong(1, inDayDate);
            readStatement.setLong(2, inDayDate);
            final ResultSet rs = readStatement.executeQuery();
            String statusName = null;
            int caseCount = 0;
            while (rs.next()) {
                // build the key
                aggregateRecord = new CaseProcessFactDayAggregate(rs.getLong(1),
                        rs.getLong(2), inDayDate);
                statusName = rs.getString(3);
                caseCount = rs.getInt(4);
                // add the status case count for the aggregate record
                inDayAggregates.updateDay(aggregateRecord, statusName, caseCount);
            }
            final Enumeration<CaseProcessFactDayAggregate> records = inDayAggregates
            .iterator();
            while (records.hasMoreElements()) {
                aggregateRecord = (CaseProcessFactDayAggregate) records.nextElement();
                System.out.println("about to save " + aggregateRecord.toString());
                insert(aggregateRecord, insertSatement);
                if (uncommitted >= commitLevel) {
                    transaction.executeBatch(insertSatement);
                    uncommitted = 0;
                }
            }
            if (uncommitted >= 0) {
                transaction.executeBatch(insertSatement);
                uncommitted = 0;
            }
        } catch (final Exception e) {
            System.out.println("CaseFactProcessTransformImpl:readAggregateRecord:"
                    + e);
            throw new SQLException(
                    "CaseFactProcessTransformImpl:readAggregateRecord:" + e.getMessage());
        } finally {
            // release resources
            if (insertSatement != null) {
                insertSatement.close();
            }
            if (readStatement != null) {
                readStatement.close();
            }
        }
    }

    // __________________________________________________________________________
    /**
     * Sets the last ETL date time.
     * 
     * @param inAggregate
     *          record data to insert
     * @param statement
     *          inserts data into the database
     * @throws SQLException
     *           if database operation failed
     */
    private void insert(final CaseProcessFactDayAggregate inAggregate,
            final PreparedStatement statement) throws SQLException {
        try {
            // set organization unit key
            statement.setLong(1, inAggregate.getOrgKey());
            // set product key
            statement.setLong(2, inAggregate.getProductKey());
            // set day key
            statement.setLong(3, inAggregate.getDayKey());
            statement.setInt(4, inAggregate.getOpenCases());
            statement.setInt(5, inAggregate.getSubmittedCases());
            statement.setInt(6, inAggregate.getApprovedCases());
            statement.setInt(7, inAggregate.getActiveCases());
            statement.setInt(8, inAggregate.getPendingCases());
            statement.addBatch();
        } catch (final Exception e) {
            System.out.println("CaseFactProcessTransformImpl:insert:" + e);
            throw new SQLException("CaseFactProcessTransformImpl:insert:"
                    + e.getMessage());
        }
    }

    // __________________________________________________________________________
    /**
     * Read the keys for status registered and received.
     * 
     * @param inDayDate
     *          the day date
     * @return the day date time period key
     * @throws SQLException
     *           if a database operation fails
     */
    private long readTime(final Date inDayDate) throws SQLException {
        PreparedStatement statement = null;
        long timeKey = 0;
        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();
            statement = connection.prepareStatement(kReadTimeKey);
            statement.setDate(1, inDayDate);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                timeKey = rs.getLong(1);
            } else {
                throw new Exception("cannot find time key for day "
                        + inDayDate.toString());
            }
        } catch (final Exception e) {
            System.out.println("readRegisteredReceivedKeys:" + e);
            throw new SQLException("readRegisteredReceivedKeys:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
        return timeKey;
    }

    /**
     * This module represents a case day aggregate records for one day.
     */
    class DayAggregates {
        /**
         * contains the set of aggregates for a given day.
         */
        private final Hashtable<String, CaseProcessFactDayAggregate> aggregateDayRecords = new Hashtable<String, CaseProcessFactDayAggregate>();

        /**
         * Adds an aggregate record.
         * 
         * @param inDayAggregate
         *          empty aggregate record
         */
        public void addDay(final CaseProcessFactDayAggregate inDayAggregate) {
            aggregateDayRecords.put(inDayAggregate.getKey(), inDayAggregate);
        }

        /**
         * Return the set of records.
         * 
         * @return Enumeration the set of aggregate records
         */
        public Enumeration<CaseProcessFactDayAggregate> iterator() {
            return aggregateDayRecords.elements();
        }

        /**
         * Updates a day aggregate record with one status count.
         * 
         * @param inDayAggregate
         *          the status count for the aggregate
         * @param inStatus
         *          the status
         * @param inNumberOfCases
         *          the number of cases
         * 
         * @throws Exception
         *           if the aggregate record could not be found
         */
        public void updateDay(final CaseProcessFactDayAggregate inDayAggregate,
                final String inStatus, final int inNumberOfCases) throws Exception {
            final CaseProcessFactDayAggregate aggregate = (CaseProcessFactDayAggregate) aggregateDayRecords
            .get(inDayAggregate.getKey());
            if (aggregate == null) {
                throw new Exception("Error: could not find record to update "
                        + inDayAggregate.toString());
            }
            if (kOpenStatus.equalsIgnoreCase(inStatus)) {
                aggregate.setOpenCases(inNumberOfCases);
            } else if (kSubmittedStatus.equalsIgnoreCase(inStatus)) {
                aggregate.setSubmittedCases(inNumberOfCases);
            } else if (kApprovedStatus.equalsIgnoreCase(inStatus)) {
                aggregate.setApprovedCases(inNumberOfCases);
            } else if (kActiveStatus.equalsIgnoreCase(inStatus)) {
                aggregate.setActiveCases(inNumberOfCases);
            } else if (kPendingClosureStatus.equalsIgnoreCase(inStatus)) {
                aggregate.setPendingCases(inNumberOfCases);
            } else {
                System.out.println("Warning: Unknown case status <" + inStatus
                        + "> not being added to database, update transform");
            }
        }

        /**
         * Returns the number of aggregate records.
         * 
         * @return the number of aggregate records
         */
        public int size() {
            return aggregateDayRecords.size();
        }
    }

    /**
     * This module represents a case day aggregate record.
     */
    static class CaseProcessFactDayAggregate {
        /**
         * the product key.
         */
        private final long productKey;

        /**
         * the organization unit key.
         */
        private final long orgKey;

        /**
         * the year.
         */
        private final long dayDateKey;

        /**
         * the number of open cases.
         */
        private int openCases;

        /**
         * the number of submitted cases.
         */
        private int submittedCases;

        /**
         * the approved cases.
         */
        private int approvedCases;

        /**
         * the active cases.
         */
        private int activeCases;

        /**
         * the active cases.
         */
        private int pendingCases;

        /**
         * Creates a new empty aggregate record.
         * 
         * @param inOrgKey
         *          the organization unit key
         * @param inProductKey
         *          the product key
         * @param inDayDateKey
         *          the day key
         */
        CaseProcessFactDayAggregate(
                final long inOrgKey,
                final long inProductKey,
                final long inDayDateKey) {
            productKey = inProductKey;
            orgKey = inOrgKey;
            dayDateKey = inDayDateKey;
        }

        /**
         * returns true if object are equal.
         * 
         * @param inObject
         *          the object to compare to
         * @return boolean true if the object are equal
         */
        @Override
        public boolean equals(final Object inObject) {
            if (inObject instanceof CaseProcessFactDayAggregate) {
                final CaseProcessFactDayAggregate agg = (CaseProcessFactDayAggregate) inObject;
                if (productKey == agg.productKey && orgKey == agg.orgKey
                        && dayDateKey == agg.dayDateKey) {
                    return true;
                }
                return false;
            }
            return false;
        }

        /**
         * returns the hash code.
         * 
         * @return int the hash code
         */
        @Override
        public int hashCode() {
            return (int) (productKey + orgKey + dayDateKey);
        }

        /**
         * returns the key.
         * 
         * @return String the key
         */
        public String getKey() {
            return "#" + productKey + orgKey + dayDateKey;
        }

        /**
         * @return Returns the cleared.
         */
        @Override
        public String toString() {
            return "<caseprocessfact " + "productKey=" + productKey + " orgKey="
            + orgKey + " day=" + dayDateKey + " openCases=" + openCases
            + " submittedCases=" + submittedCases + " approvedCases="
            + approvedCases + " pendingCases=" + pendingCases + " activeCases="
            + activeCases + " />";
        }

        /**
         * Returns the day key.
         * 
         * @return Returns the day key.
         */
        public long getDayKey() {
            return dayDateKey;
        }

        /**
         * Returns the org key.
         * 
         * @return Returns the org key.
         */
        public long getOrgKey() {
            return orgKey;
        }

        /**
         * Returns the product key.
         * 
         * @return Returns the product key.
         */
        public long getProductKey() {
            return productKey;
        }

        /**
         * Returns the number of active cases.
         * 
         * @return Returns pending cases.
         */
        public int getActiveCases() {
            return activeCases;
        }

        /**
         * Set number of active cases.
         * 
         * @param inActiveCases
         *          number of active cases.
         */
        public void setActiveCases(final int inActiveCases) {
            activeCases = inActiveCases;
        }

        /**
         * Returns the number of pending cases.
         * 
         * @return Returns pending cases.
         */
        public int getPendingCases() {
            return pendingCases;
        }

        /**
         * Set number of pending cases.
         * 
         * @param inPendingCases
         *          number of pending cases.
         */
        public void setPendingCases(final int inPendingCases) {
            pendingCases = inPendingCases;
        }

        /**
         * Returns the number of approved cases.
         * 
         * @return Returns approved cases.
         */
        public int getApprovedCases() {
            return approvedCases;
        }

        /**
         * Set number of approved cases.
         * 
         * @param inApprovedCases
         *          number of approved cases.
         */
        public void setApprovedCases(final int inApprovedCases) {
            approvedCases = inApprovedCases;
        }

        /**
         * Returns the number of submitted cases.
         * 
         * @return Returns submitted cases.
         */
        public int getSubmittedCases() {
            return submittedCases;
        }

        /**
         * Set number of submitted cases.
         * 
         * @param inSubmittedCases
         *          number of submitted cases.
         */
        public void setSubmittedCases(final int inSubmittedCases) {
            submittedCases = inSubmittedCases;
        }

        /**
         * Returns the number of open cases.
         * 
         * @return Returns open cases.
         */
        public int getOpenCases() {
            return openCases;
        }

        /**
         * Set number of open cases.
         * 
         * @param inOpenCases
         *          number of open cases.
         */
        public void setOpenCases(final int inOpenCases) {
            openCases = inOpenCases;
        }
    }
}
