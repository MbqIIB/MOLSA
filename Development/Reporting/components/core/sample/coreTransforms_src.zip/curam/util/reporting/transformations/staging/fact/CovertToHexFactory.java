/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.staging.fact;

import java.sql.SQLException;

import curam.util.reporting.transformations.staging.base.ConvertVarcharToBigint;
import curam.util.reporting.transformations.staging.base.ConvertVarcharToBigintBase;

import curam.util.type.*;

/**
 * Factory class to create an instance of staging big integer support
 * {@link ConvertVarcharToBigint} class, one of its subclasses, a proxy for it
 * or a mock object for it.
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public final class CovertToHexFactory {

  // ___________________________________________________________________________
  /**
   * Ensures this class cannot be created.
   */
  private CovertToHexFactory() {
  }

  // ___________________________________________________________________________
  /**
   * Returns an object to convert ZOS unique identifiers to a number value.
   * 
   * @return an object to convert ZOS identifiers to number values
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  public static ConvertVarcharToBigint newInstance() throws SQLException {
    // returns the base implementation of the data access object
    ConvertVarcharToBigint convertVcharToBigint;

    convertVcharToBigint = new ConvertVarcharToBigintBase();

    return convertVcharToBigint;
  }

}
