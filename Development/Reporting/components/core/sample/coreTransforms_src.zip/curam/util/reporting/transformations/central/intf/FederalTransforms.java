/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.central.intf;

import curam.util.type.*;

/**
 * 
 * This module defines the interface for federal transforms.
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public interface FederalTransforms {

  /**
   * benefit evidence name (for any benefits) in the link table, this may also
   * be referenced by ETL processes
   */
  public final String kEvidenceNameBenefits = "Benefit Evidence";

  /**
   * the self employed income gross receipt evidence name in the link table,
   * this may also be referenced by ETL processes (gross receipt)
   */
  public final String kEvidenceNameEarnedIncomeGrossReceipt = "Self Employment Income";

  /**
   * the earned income paid employment name in the link table, this may also be
   * referenced by ETL processes (earned income)
   */
  public final String kEvidenceNameEarnedIncome = "Paid Employment Income";

  /**
   * the paid employment evidence name in the link table, this may also be
   * referenced by ETL processes, DW_ISPPAIDEMPLOYMENT
   */
  public final String kEvidenceNamePaidEmployment = "Paid Employment";

  /**
   * the unearned income evidence name in the link table, this may also be
   * referenced by ETL processes
   */
  public final String kEvidenceNameUnEarnedIncome = "Unearned Income";

  /**
   * the absent parent name in the link table, this may also be referenced by
   * ETL processes
   */
  public final String kEvidenceNameAbParChildSupport = "Absent Parent Child Support";

  /**
   * the liquid resource evidence name in the link table, this may also be
   * referenced by ETL processes
   */
  public final String kEvidenceNameLiquidResource = "Liquid Resource";

  /**
   * the house hold member evidence name in the link table, this may also be
   * referenced by ETL processes
   */
  static public final String kEvidenceNameHHM = "Household Member";

  /**
   * the alien evidence name in the link table, this may also be referenced by
   * ETL processes
   */
  public final String kEvidenceNameAlien = "Alien";

  /**
   * the house hold relationship evidence name in the link table, this may also
   * be referenced by ETL processes
   */
  public final String kEvidenceNameHHR = "Household Relationship";
  /**
   * the child enforcement evidence name in the link table, this may also be
   * referenced by ETL processes
   */
  public final String kEvidenceNameChildSupportEnforcement = "Child Support Enforcement";
  /**
   * the sanction evidence name in the link table, this may also be referenced
   * by ETL processes
   */
  public final String kEvidenceNameSanctions = "Sanction";

  /**
   * the student evidence name in the link table, this may also be referenced by
   * ETL processes
   */
  public final String kEvidenceNameStudent = "Student";

  /**
   * the unpaid employment evidence name in the link table, this may also be
   * referenced by ETL processes, DW_ISPUNPAIDEMPLOYMENT
   */
  public final String kEvidenceNameUnPaidEmployment = "Unpaid Employment";
  /**
   * the self employment evidence name in the link table, this may also be
   * referenced by ETL processes
   */
  public final String kEvidenceNameSelfEmployment = "Self Employment";
  /**
   * the work requirements evidence name in the link table, this may also be
   * referenced by ETL processes
   */
  public final String kEvidenceNameWorkRequirements = "Work Requirements";
  /**
   * the housing evidence name in the link table, this may also be referenced by
   * ETL processes
   */
  public final String kEvidenceNameSubsizedHousing = "SubsidisedHousing";

  /**
   * federal assistance status
   */
  public final String kPublicAssiatanceKey = "PUBLIC ASSISTANCE";
  /**
   * federal assistance status
   */
  public final String kNonPublicAssiatanceKey = "NON ASSISTANCE";

  /**
   * the key for a MAS value of unknown, 1
   */
  public final int kMASUnknownKey = 1;

  /**
   * the classic food program code, PT16
   */
  public final String kClassicFoodProgramCode = "PT16";

  /**
   * the classic medical assistance program code, PT17
   */
  public final String kClassicMedicalProgramCode = "PT17";
  /**
   * the classic cash assistance program code, PT22
   */
  public final String kClassicCashProgramCode = "PT22";

  /**
   * the role of parent, "Parent"
   */
  public final String kParent = "Parent";
  /**
   * the citizen status of alien , "Alien"
   */
  public final String kCitizenStatus = "Alien";

  /**
   * the key value of an undefined record in the database, -1
   */
  public final int kUndefinedKey = -1;

  /**
   * the key value of an undefined record in the database, -1
   */
  public final int kFederalStatusKey = -1;

  /**
   * the employment code to return a warehouse key, Employed
   */
  public final String kEmploymentStatusEmployed = "Employed";
  /**
   * the employment code to return a warehouse key, Not Employed
   */
  public final String kEmploymentStatusNotEmployed = "Not Employed";

  /**
   * the employment code to return a warehouse key, not in work force
   */
  public final String kEmploymentStatusNoInLabourForce = "Not In Labour Force";

  public final String kVICTIMS_OF_SEVERE_TRAFFICKING = "Victims of severe Trafficking";

  public final String kAMERICAN_INDIAN_BORN_IN_CANADA = "American Indian born in Canada";

  public final String kAMERASIAN_IMMIGRANT = "Amerasian Immigrant";

  public final String kCUBAN_HAITIAN_ENTRANT = "Cuban/Haitian entrant";

  public final String kDEPORTATION_WITHHELD = "Deportation Withheld";

  public final String kPAROLEE = "Parolee";

  public final String ASYLEE = "Asylee";

  public final String kCONDITIONAL_ENTRANT = "Conditional Entrant";

  public final String kREFUGEE = "Refugee";

  public final String kLPR_WITH_40_QUALIFYING_QUARTERS = "LPR With 40 Qualifying Quarters";

  public final String kLPR_WITHOUT_40_QUALIFYING_QUARTERS = "LPR Without 40 Qualifying Quarters";

  public final String kAdultYes = "Y";
  public final String kAdultNo = "N";

  public final String kMASYes = "Y";
  public final String kMASNo = "N";

  public final String kParentYes = "Y";
  public final String kParentNo = "N";

  public final String kAlienYes = "Y";
  public final String kAlienNo = "N";

  public final String kSanctionYes = "Y";
  public final String kSanctionNo = "N";

  public final String kFederalBenefitYes = "Y";
  public final String kFederalBenefitNo = "N";

  public final String kChildEnforcmentStringYes = "Y";

  public final String kChildEnforcementStringNo = "N";

  /**
   * returns zero or more household records applicable for a period of time
   * 
   * is the recipient a parent?, needed for reporting on 2 parent families in
   * future releases if the recipient is a child we need check if he/she has
   * parents, not just if the recipient is a parent
   */
  public final String readHouseholdRoleByDate = "select DWHHRELATIONSHIPID,RELATIONSHIPTYPE "
      + " from dw_isphouseholdrelationship"
      + " where DWCASEID=? and DWRELPARTICIPANTID=?"
      + " and attributedstartdate <= ?"
      + " and (attributedenddate >= ? or attributedenddate is null)";

  /**
   * returns zero or more student records applicable for a period of time
   */
  public final String readStudentByDate = "select DWSTUDENTID "
      + " from dw_ispstudent" + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedstartdate <= ?"
      + " and (attributedenddate >= ? or attributedenddate is null)";

  /**
   * returns zero or more student records applicable for a period of time
   */
  public final String readStudentLevelByDate = "select DWSTUDENTID, max (HIGHGRADECOMPLETED) "
      + " from dw_ispstudent"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedstartdate <= ?"
      + " and (attributedenddate >= ? or attributedenddate is null)"
      + " group by dwstudentid";

  /**
   * returns zero or more records applicable for a period of time
   */
  public final String readBenefitByDate = "select DWBENEFITID, benefittype "
      + " from dw_ispBENEFIT" + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedstartdate <= ?"
      + " and (attributedenddate >= ? or attributedenddate is null)";

  /**
   * returns zero or more alien records applicable for a period of time
   */
  public final String readAlienByDate = "select DWALIENID, ALIENTYPE "
      + " from dw_ispALIEN" + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedstartdate <= ?"
      + " and (attributedenddate >= ? or attributedenddate is null)";

  /**
   * returns zero or more household member records applicable for a period of
   * time
   */
  public final String readHouseHoldMemberByDate = "select DWHHMEMBERID, CITIZENSTATUS "
      + " from dw_isphouseholdmember"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedstartdate <= ?"
      + " and (attributedenddate >= ? or attributedenddate is null)";

  /**
   * returns zero or more unearned income records applicable for a period of
   * time
   */
  public final String readUnEarnedIncomeByDate = "select dwunearnedincomeid as id, frequencycode,amount "
      + " from dw_ispunearnedincome"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedfromdate <= ?"
      + " and (attributedtodate >= ? or attributedtodate is null)";

  /**
   * returns zero or more records applicable for a period of time
   */
  public final String readLiquidResourceByDate = "select DWLIQUIDRESOURCEID as id, LIQUIDRESOURCETYPE,VALUE "
      + " from DW_ISPLIQUIDRESOURCES"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedfromdate <= ?"
      + " and (attributedtodate >= ? or attributedtodate is null)";

  /**
   * returns zero or more earned income records applicable for a period of time
   */
  public final String readEarnedIncomeByDate = "select dwearnedincomeid as id, frequencycode,amount  "
      + " from dw_ispearnedincome"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedfromdate <= ?"
      + " and (attributedtodate >= ? or attributedtodate is null)";

  /**
   * returns zero or more records applicable for a period of time
   */
  public final String readSelfEmployedIncomeByDate = "select dwgrossreceiptid as id, frequencycode,amount "
      + " from dw_ispgrossreceipt"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedfromdate <= ?"
      + " and (attributedtodate >= ? or attributedtodate is null)";

  /**
   * returns zero or more records applicable for a period of time
   */
  public final String readAbParChildSupportByDate = "select DWABPARCHILDSUPPORTID as id, CHILDSUPPORTPMTAMOUNT "
      + " from DW_ISPABPARCHILDSUPPORT"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedstartdate <= ?"
      + " and (attributedenddate >= ? or attributedenddate is null)";

  /**
   * returns zero or more records applicable for a period of time
   */
  public final String readUnPaidEmploymentByDate = "select DWCASEID "
      + " from DW_ISPUNPAIDEMPLOYMENT"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedfromdate <= ?"
      + " and (attributedtodate >= ? or attributedtodate is null)";

  /**
   * returns zero or more gross receivable for a period of time
   */
  public final String readEmploymentStatusPaidEmploymentByDate = "select DWCASEID "
      + " from DW_ISPPAIDEMPLOYMENT"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedfromdate <= ?"
      + " and (attributedtodate >= ? or attributedtodate is null)";

  /**
   * returns zero or more records applicable for a period of time
   */
  public final String readEmploymentStatusSelfEmployedByDate = "select DWCASEID "
      + " from DW_ISPSELFEMPLOYMENT"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and ATTRIBUTEDFROMDATE <= ?"
      + " and (ATTRIBUTEDTODATE >= ? or ATTRIBUTEDTODATE is null)";

  /**
   * returns zero or more records applicable for a period of time
   */
  public final String readEmploymentStatusWorkRequirementsByDate = "select DWCASEID "
      + " from DW_ISPWORKREQUIREMENTS"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and ATTRIBUTEDFROMDATE <= ?"
      + " and (ATTRIBUTEDTODATE >= ? or ATTRIBUTEDTODATE is null)";

  /**
   * returns zero or more sanction records applicable for a period of time
   */
  public final String readSanctionsByDate = "select DWCASEID "
      + " from DW_ISPSANCTION" + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and SANCTIONSTARTDATE <= ?"
      + " and (SANCTIONENDDATE >= ? or SANCTIONENDDATE is null)";

  /**
   * returns zero or more records applicable for a period of time
   */
  public final String readChildSupportEnforceByDate = "select DWCASEID, COOPERWITHCSEDIND "
      + " from DW_ISPCHILDSUPPORTENFORCE"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and ATTRIBUTEDFROMDATE <= ?"
      + " and (ATTRIBUTEDTODATE >= ? or ATTRIBUTEDTODATE is null)";

  /**
   * returns zero or more unearned income records applicable for a period of
   * time
   */
  public final String readUnEarnedIncomeTypeByDate = "select dwunearnedincomeid as id, unearnedincometype  "
      + " from dw_ispunearnedincome"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedfromdate <= ?"
      + " and (attributedtodate >= ? or attributedtodate is null)";

  /**
   * returns zero or more records applicable for a period of time
   */
  public final String readRentAllowanceSubHousingByDate = "select DWISPSUBSIDIZEDHOUSINGID as id, REIMBURSEMENTTYPECODE  "
      + " from DW_ISPSUBSIDIZEDHOUSING"
      + " where DWCASEID=? and DWPARTICIPANTID=?"
      + " and attributedfromdate <= ?"
      + " and (attributedtodate >= ? or attributedtodate is null)";

  public final String readMonthProcessed = "select DWCASEGROUPID from  DW_CASERECIPIENT_MONTH "
      + " where " + " DWCASEGROUPID=?" + " and YEAR=?" + " and MONTH=? ";

  /**
   * returns the dual eligibility key for a given product
   */
  public final String readAssistanceStatusKey = "select DWASSISTANCESTATUSKEY as key "
      + " from DW_ASSISTANCESTATUS" + " where CODE=?";

  /**
   * returns the enforcement eligibility key for a given product
   */
  public final String readFChildSupportStatusKey = "select DWCHILDSUPPORTENFORCETYPEKEY as key "
      + " from DW_CHILDSUPPORTENFORCETYPES" + " where CODE=?";
  /**
   * returns the dual eligibility key for a given product
   */
  public final String readDualKeyNotDualProduct = "select DWDUALKEY as dualkey from DW_DUALELIGIBITY where CODE=?";
  /**
   * returns the dual eligibility key for a given product
   */
  public final String readDualKeyForProduct = "select DWDUALKEY as key "
      + " from DW_DUALELIGIBITYBYPRODUCT" + " where PRODUCTCODE=?";

  /**
   * returns the federal benefit key for a given product
   */
  public final String readFederalBenifetTypesStatusKey = "select DWEDUCATIONLEVELKEY as key "
      + " from DW_EDUCATIONLEVELS" + " where CODE=?";

  /**
   * returns the dual eligibility key for a given product
   */
  public final String readHousingStatusKey = "select DWSUBSIDIZEDHOUSINGTYPEKEY as key "
      + " from DW_SUBSIDIZEDHOUSINGTYPES" + " where CODE=?";

  /**
   * returns the dual eligibility key for a given product
   */
  public final String readEmploymentStatusKey = "select DWEMPLOYMENTSTATUSKEY as key "
      + " from DW_EMPLOYMENTSTATUS" + " where CODE=?";
  /**
   * returns recipient records not processed yet
   */
  public final String readReciepientsToProcess = "select t1.DWCASEGROUPID, t2.dateofbirth, t1.startdate, t1.enddate, "
      + " t1.dwcaseid, t1.dwparticipantid, t1.lastwritten,  t4.name, t5.programcd"
      + ", t1.DWPROGRAMID, t1.DWPERSONHISTORYID, t1.CASECLIENTGROUPID, t1.DWCASESTATUSHISTORYID, t4.name "
      + " from  DW_CASEGROUP t1, dw_personhistory t2, dw_case t3, dw_product t4, dw_program t5 "
      + " where t1.dwpersonhistoryid=t2.dwpersonhistoryid"
      + " and t1.processedflag = 'N'"
      + " and t1.dwcaseid=t3.dwcaseid"
      + " and t3.dwprogramid=t5.dwprogramid"
      + " and t3.dwproductid=t4.dwproductid";

  public final String setToProcessed = "update "
      + " DW_CASEGROUP T1 set t1.PROCESSEDFLAG=? "
      + " where t1.DWCASEGROUPID=?";
  /**
   * insert a new record into the monthly aggregate table
   */
  public final String insertMonthRecipient = "insert into DW_CASERECIPIENT_MONTH ("
      + " DWPARTICIPANTID ,"
      + " DWCHILDSUPPORTENFORCETYPEKEY ,"
      + " DWPROGRAMID , "
      + " DWPERSONHISTORYID , "
      + " DWSUBSIDIZEDHOUSINGTYPEKEY ,"
      + " DWCASEID , "
      + " DWBOEKEY , "
      + " DWASSISTANCESTATUSKEY ,"
      + " DWEDUCATIONLEVELKEY ,"
      + " DWCASEGROUPID ,"
      + " DWDUALKEY , "
      + " DWMASKEY ,"
      + " DWEMPLOYMENTSTATUSKEY ,"
      + " YEAR ,"
      + " MONTH ,"
      + " LASTWRITTEN ,"
      + " STARTDATE ,"
      + " ENDDATE,"
      + " ADULTIND ,"
      + " AGE , "
      + " PARENTIND ,"
      + " ALIENIND,"
      + " SANCTIONIND,"
      + " FEDBENEFITIND,"
      + " PRIMARYMASIND,"
      + " CASECLIENTGROUPID , "
      + " TOTALCHILDSUPPORTAMOUNT , "
      + " TOTALCASHRESOURCEAMOUNT ,"
      + " TOTALUNEARNEDINCOME ,"
      + " TOTALEARNEDINCOME,"
      + " DWCASESTATUSHISTORYID)"

      + " values("
      + " ?, ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?,  ?, "
      + " ?, ?, ?,  ?, "
      + " ? , ?,  ?,  ?,  ?,  ?,   ?,   ?,   ?,   ?,  ?,  ?,  ?,  ?)";

  /**
   * Link and recipient to their evidence Evidence is only associated once to a
   * recipient even through there may be many evidence records that allow
   * eligibility.
   * 
   * This is an algorithm based on the rules defined in our requirements
   * specifications for TANF.
   * 
   */
  public final String insertEvidenceLink = "insert into DW_EVIDENCELINK "
      + " (DWCASEGROUPID,DWEVIDENCEID, EVIDENCETYPE, LASTWRITTEN)"
      + " values (?,?,?,?)";

  /**
 * 
 */
  public final String productsThisMonth = "select  t3.name, t1.primarymasind  from DW_CASERECIPIENT_MONTH T1, DW_CASEGROUP T2,  dw_product T3, DW_CASE T4"
      + " where "
      + " T1.DWCASEGROUPID=T2.DWCASEGROUPID"
      + " and t2.dwcaseid=t4.dwcaseid"
      + " and t4.dwproductid=t3.dwproductid"
      + " and t1.year=?" + " and t1.month=?" + " and t1.DWPARTICIPANTID=?";

  /**
   * reset the primary MAS indicator for a recipient for a month
   */
  public final String unSetPrimaryMASIndicatorThisMonth = "update  DW_CASERECIPIENT_MONTH t1 set t1.primarymasind=?"
      + " where t1.year=? and t1.month=? and t1.DWPARTICIPANTID=?";

  /**
   * reset the primary MAS indicator for a recipient for a month
   */
  public final String readBOEMappings = "select t2.DWBOEKEY, t2.CODE as BOECODE, t2.DESCRIPTION as BOEDESCRIPTION, t1.PRODUCTCODE, t1.ISCHILD, t1.AGED,t1.ISBLIND from DW_BOEELIGIBITYBYPRODUCT T1, DW_BOEcodes T2 where t1.DWBOEKEY=t2.DWBOEKEY";

  /**
   * reads the MAS key for a product
   */
  public final String readMASMappings = "select DWMASKEY from DW_MASCodesBYPRODUCT where PRODUCTCODE =?";

}
