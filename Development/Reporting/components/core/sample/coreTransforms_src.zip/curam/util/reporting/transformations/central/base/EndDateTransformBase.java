/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.central.base;

import java.sql.SQLException;
import curam.util.type.*;

/**
 * This module updates updates the end date for the previous record in a history
 * table.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class EndDateTransformBase extends EndDateTransformImpl {

  // ___________________________________________________________________________
  /**
   * Creates an object to parse address data strings.
   * 
   * @param inSourceTable
   *          the source table name
   * @param inSourceKey
   * @throws SQLException
   *           if database error occurs
   */
  public EndDateTransformBase(
      final String inSourceTable,
      final String inSourceKey) throws SQLException {
    super(inSourceTable, inSourceKey);
  }

}
