/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.central.base;

import java.sql.SQLException;
import curam.util.type.*;

/**
 * Associate a recipient to the evidence used in eligibility. This process
 * 
 * executes against the recipient table and any evidence table(s).
 * 
 * Evidence is only associated once to a recipient even through there may be
 * many evidence records that allow eligibility.
 * 
 * This is an algorithm based on the rules defined in our requirements
 * specifications for TANF.
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class PersonTransformsBase extends PersonTransformsImpl {

  // ___________________________________________________________________________
  /**
   * Creates an object to generate recipient attributes.
   * 
   * 
   * @throws SQLException
   *           if database error occurs
   */
  public PersonTransformsBase() throws SQLException {
    super();
  }

}
