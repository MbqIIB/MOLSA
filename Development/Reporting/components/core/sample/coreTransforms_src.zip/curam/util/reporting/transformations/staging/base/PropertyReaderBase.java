/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.staging.base;

import java.sql.SQLException;

/**
 * 
 * Reads a property from the database using the default language, if the default
 * language is not available for this property, the fall back of country is
 * tried and then finally no locale is tried.
 * 
 * 
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
public class PropertyReaderBase extends PropertyReader {

  /**
   * 
   */
  public final static String kUNDEFINED_PROPERTY_NAME = "BI.UNDEFINED";

  // ______________________________________________________________________
  /**
   * Initialize the internal state of the object.
   * 
   * @param inSourceTableName
   *          table name where source data resides
   * @exception SQLException
   *              if a database operation fails
   */

  public PropertyReaderBase(final String inSourceTableName) throws SQLException {
    super(inSourceTableName);
  }

}
