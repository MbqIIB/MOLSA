/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.central.base;

import java.sql.SQLException;
import curam.util.type.*;

/**
 * Calculates the federal status values for products awarded.
 * 
 * For each CGISS recipient
 * 
 * <ol>
 * <li>only process benefit groups members</li>
 * <li>generate a time line to process</li>
 * <li>process each month between in the time line between the start date and
 * end date</li>
 * <li>if the end date is null then set to current month</li>
 * <ol>
 * <li>calculate the age in the monthly frame, age for all the month</li>
 * <li>set the federal adult indicator, based on age and educational levels</li>
 * <li>calculate the federal maintenance assistance status, based on program and
 * benefit type</li>
 * <li>calculate the federal basis of eligibility assistance status</li>
 * <li>calculate the federal basis of dual eligible status, based on products
 * awarded</li>
 * <li>calculate the federal household assistance status, based on benefit types
 * </li>
 * <li>calculate the parent indicator , based on household roles</li>
 * <li>calculate the federal educational status, based on education level</li>
 * <li>calculate the earned, unearned, cash resources amounts, based 4 evidence
 * tables</li>
 * <li>calculate the federal sanction status, based on product and sanction type
 * </li>
 * <li>calculate the federal employment status, based 4 evidence tables</li>
 * </ol>
 * <li>insert a record for each recipient into summary table for each month</li>
 * <li>if the end date is set set processed flag to true.</li> <li>call the
 * standard post process.</li> </ol>
 * 
 * This is an algorithm based on the rules defined in the requirements
 * specifications for Curam 5.2.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class FederalProgramsTransformsBase extends
    FederalProgramsTransformsImpl {

  // ___________________________________________________________________________
  /**
   * Creates an object to generate recipient attributes.
   * 
   * 
   * @throws SQLException
   *           if database error occurs
   */
  public FederalProgramsTransformsBase() throws SQLException {
    super();
  }

}
