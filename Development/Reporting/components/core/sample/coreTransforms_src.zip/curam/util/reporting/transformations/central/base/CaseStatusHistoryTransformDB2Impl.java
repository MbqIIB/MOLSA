/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.central.base;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.type.*;

/**
 * This module defines functions to load case status history values where the
 * new status does not equal the most recent status.
 * 
 * @deprecated - superseded by CaseStatusHistoryTransformImpl.java.
 */
@Deprecated
@AccessLevel(AccessLevelType.INTERNAL)
public class CaseStatusHistoryTransformDB2Impl extends
    CaseStatusHistoryTransformImpl {

  /**
   * the SQL to update the temporary table.
   */
  private final String kSQLUpdateDescription;

  /**
   * reads status keys for registered and received statuses.
   */
  private final String kSQLSelectStatus = "select dwstatusid from dw_casestatus "
      + " where statusname=?";

  /**
   * SQL insert statement for status history table.
   */
  private final String kSQLInsertStatus = "insert into dw_casestatushistory values"
      + " (nextval for DWCASESTATUSHISTSEQ, ?, ?, -1, ?, ?, null, ?)";

  /**
   * reads source case data.
   */
  private final String kSQLSelectSourceData;

  // ___________________________________________________________________________
  /**
   * Create a new object to interface with the ETL control table.
   * 
   * @param inSourceTable
   *          the source table name
   */
  public CaseStatusHistoryTransformDB2Impl(final String inSourceTable) {
    kSQLSelectSourceData = "SELECT T2.DWCASEID, T1.REGISTRATIONDATE, T1.RECEIVEDDATE, T1.LASTWRITTEN"
        + " FROM "
        + inSourceTable
        + " T1, DW_CASE T2"
        + " WHERE T1.CASEID=T2.CASEID and (t1.registrationdate is not null "
        + " or t1.receiveddate is not null or t1.startdate is not null)";

    kSQLUpdateDescription = "update " + inSourceTable
        + " set description=null where dwstatusid <> ?";

  }

  // ___________________________________________________________________________
  /**
   * Returns the closure reason where the case status is closed.
   * 
   * @param inSourceTable
   *          the case status, e.g. open, closed etc.
   * @param inDescription
   *          the case status description
   * 
   * @return String the description
   * 
   * @exception SQLException
   *              if a database operation fails
   */
  @Override
  public String isClosureReason(final String inSourceTable,
      final String inDescription) throws SQLException {
    // stored success of SQL statements
    boolean failed = false;
    // the database transaction
    Transaction transaction = null;

    try {
      // start a transaction
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);

      // read the surrogate keys for the received and registered statuses
      updateDescription(inSourceTable, readClosedKey());

    } catch (Exception e) {
      System.out
          .println("CaseStatusHistoryTransformImpl:execute: caught exception "
              + e.getMessage());
      failed = true;
      throw new SQLException("CaseStatusHistoryTransformImpl:execute:"
          + e.getMessage());
    } finally {
      if (transaction != null && !transaction.isClientManagedTransaction()) {
        if (failed) {
          transaction.rollback();
          System.out.println("CaseStatusHistoryTransformImpl:execute:failed");
        } else {
          // commit the changes
          transaction.commit();
          System.out
              .println("CaseStatusHistoryTransformImpl:execute:successfull");
        }
      }
    }
    return "";
  }

  // ___________________________________________________________________________
  /**
   * Inserts registration and received status records into the case status
   * history table.
   * 
   * @param inTargetTableName
   *          table name where source data resides
   * @exception SQLException
   *              if a database operation fails
   */
  @Override
  public void executePostProcess(final String inTargetTableName)
      throws SQLException {
    // stored success of SQL statements
    boolean failed = false;
    // the database transaction
    Transaction transaction = null;

    try {
      // start a transaction
      transaction = TransactionFactory
          .getTransaction(DataWarehouseConstants.kDefaultDatabase);

      // read the surrogate keys for the received and registered statuses
      super.readRegisteredReceivedKeys();

      // read source records where registration and received date are valid
      final List<RegisteredRecivedCase> records = super.readSourceData(
          kSQLSelectSourceData, inTargetTableName);

      // insert status records into case status history table
      super.insertStatuses(records, kSQLInsertStatus);

    } catch (Exception e) {
      System.out
          .println("CaseStatusHistoryTransformImpl:execute: caught exception "
              + e.getMessage());
      failed = true;
      throw new SQLException("CaseStatusHistoryTransformImpl:execute:"
          + e.getMessage());
    } finally {
      if (transaction != null && !transaction.isClientManagedTransaction()) {
        if (failed) {
          transaction.rollback();
          System.out.println("CaseStatusHistoryTransformImpl:execute:failed");
        } else {
          // commit the changes
          transaction.commit();
          System.out
              .println("CaseStatusHistoryTransformImpl:execute:successfull");
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Reads the list of records to be processes.
   * 
   * @param inSourceTable
   *          the table to update
   * @param inClosedKey
   *          close surrogate key
   * 
   * @throws SQLException
   *           is a database operation fails
   */
  private void updateDescription(final String inSourceTable,
      final int inClosedKey) throws SQLException {
    PreparedStatement statement = null;

    try {
      final Connection connection = TransactionFactory.getTransaction(
          DataWarehouseConstants.kDefaultDatabase).getConnection();

      statement = connection.prepareStatement(kSQLUpdateDescription);
      statement.setInt(1, inClosedKey);

      final int rowsUpdated = statement.executeUpdate();

      System.out.println("CaseStatusTransformDB2Impl:updateDescription:"
          + rowsUpdated + " rows updated");

    } catch (Exception e) {
      System.out.println("CaseStatusTransformDB2Impl:updateDescription:" + e);

      throw new SQLException("CaseStatusTransformDB2Impl:updateDescription:"
          + e.getMessage());
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
  }

  // __________________________________________________________________________
  /**
   * Read the key for closed status.
   * 
   * @return int the close surrogate key
   * @throws SQLException
   *           if a database operation fails
   */

  public int readClosedKey() throws SQLException {
    PreparedStatement statement = null;
    int closedKey = 0;

    try {
      final Connection connection = TransactionFactory.getTransaction(
          DataWarehouseConstants.kDefaultDatabase).getConnection();

      statement = connection.prepareStatement(kSQLSelectStatus);
      statement.setString(1, kClosedStatus);
      final ResultSet rs = statement.executeQuery();

      // we are only expecting 2 records, received and registered
      if (rs.next()) {
        closedKey = rs.getInt(1);
      }

    } catch (Exception e) {
      System.out.println("readRegisteredReceivedKeys:" + e);
      throw new SQLException("readRegisteredReceivedKeys:" + e.getMessage());
    } finally {
      // release resources
      if (statement != null) {
        statement.close();
      }
    }
    return closedKey;
  }

}
