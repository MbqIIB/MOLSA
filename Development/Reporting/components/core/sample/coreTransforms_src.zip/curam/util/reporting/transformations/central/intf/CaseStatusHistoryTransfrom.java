/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.central.intf;

import java.sql.SQLException;

import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;
import curam.util.type.*;

/**
 * 
 * This module defines the interface for loading case history records into the
 * case status history table.
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public interface CaseStatusHistoryTransfrom extends ETLPostProcess {

  // ___________________________________________________________________________
  /**
   * Returns the closure reason where the case status is closed.
   * 
   * @param inCaseStatus
   *          the case status, e.g. open, closed etc.
   * @param inDescription
   *          the case status description
   * 
   * @return String the description
   * 
   * @exception SQLException
   *              if a database operation fails
   */
  String isClosureReason(String inCaseStatus, String inDescription)
      throws SQLException;
}
