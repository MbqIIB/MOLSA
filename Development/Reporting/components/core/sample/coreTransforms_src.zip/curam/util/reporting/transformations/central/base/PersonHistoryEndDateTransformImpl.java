/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.central.base;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.base.PostProcessImpl;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;
import curam.util.type.*;

/**
 * This module updates updates the end date for the previous record in a history
 * table.
 * 
 * @deprecated - superseded by EndDateTransform.java
 * @since 5.2 SP1
 */
@AccessLevel(AccessLevelType.INTERNAL)
@Deprecated
public abstract class PersonHistoryEndDateTransformImpl extends PostProcessImpl
implements ETLPostProcess {

    /**
     * update SQL.
     */
    private final String sqlCount;

    PreparedStatement updatestatement = null;

    /**
     * update SQL.
     */
    private final String kUodateFactSQL;

    /**
     * SQL to read where to date is null.
     */
    private final String sqlSelectLatestFacts;

    // ___________________________________________________________________________
    /**
     * Creates an object to parse address data strings.
     * 
     * @param inSourceTable
     *          the source table name
     * @param inSourceKey
     * @throws SQLException
     *           if database error occurs
     */
    public PersonHistoryEndDateTransformImpl(
            final String inSourceTable,
            final String inSourceKey) throws SQLException {

        // SQL to read data from the source table
        kUodateFactSQL = "update " + inSourceTable + " set enddate=?" + " where "
        + inSourceKey + " =? and startdate=? and lastwritten=?";

        sqlSelectLatestFacts = "select t1." + inSourceKey
        + ", t1.startdate as startdate, t1.lastwritten as lastwritten from "
        + inSourceTable + " t1, dw_participant t2 "
        + " where t1.dwparticipantid=t2.dwparticipantid "
        + " and t2.concernroleid in (select concernroleid from s_person)"
        + " and t1.enddate is null " + " order by t1." + inSourceKey
        + ", t1.startdate desc, t1.lastwritten desc";

        sqlCount = "select count(*) from " + inSourceTable;
    }

    // ___________________________________________________________________________
    /**
     * This module updates a table end date column.
     * 
     * @param inTargetTableName
     *          the target table being populated
     * @throws java.sql.SQLException
     *           if a database operation failed
     */
    @Override
    public void executePostProcess(final String inTargetTableName)
    throws SQLException {
        // if an SQL statement failed, initialize to false
        boolean failed = false;
        // the database transaction
        Transaction transaction = null;

        try {
            // start a transaction, get DAO to read from the control table
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            if (count()) {
                updateToDateOfPreviousStatuses();
            }

            // update the control table
            super.executePostProcess(inTargetTableName);
        } catch (final Exception e) {
            System.out.println("ToDateTransformImpl: caught exception "
                    + e.getMessage());
            failed = true;
            // do not throw an exception, allow our test process to
            // pick up on any data quality issues.
        } finally {

            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                    System.out
                    .println("ToDateTransformImpl:failed, transaction rolled back");
                } else {
                    // commit the changes
                    transaction.commit();
                    System.out
                    .println("ToDateTransformImpl:transaction commited, processed ");
                }
            }
        }
    }

    // __________________________________________________________________________
    /**
     * Sets the number of cases on hand prior to a given date.
     * 
     * @throws SQLException
     *           if a database operation fails
     */

    private void updateToDateOfPreviousStatuses() throws SQLException {

        // stored the record from the database
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection.prepareStatement(sqlSelectLatestFacts);
            final ResultSet rs = statement.executeQuery();

            FactKey currentRecord = null;
            FactKey previousRecord = null;

            // 210806 place prepared statement of update here so it is only executed
            // once
            // get a new connection
            updatestatement = connection.prepareStatement(kUodateFactSQL);

            while (rs.next()) {
                currentRecord = new FactKey(rs.getLong(1), rs.getDate(2),
                        rs.getTimestamp(3));

                if (previousRecord != null
                        && currentRecord.logicalKey == previousRecord.logicalKey) {

                    currentRecord.toDate = previousRecord.fromDate;
                    System.out.println("setting TODATE on case <"
                            + currentRecord.logicalKey + "> with from date<"
                            + currentRecord.fromDate + "> to " + currentRecord.toDate
                            + " with timestamp " + currentRecord.lastwritten);

                    update(currentRecord);

                } else {
                    previousRecord = currentRecord;
                    System.out.println("next case " + currentRecord.logicalKey);
                }
            }

            // 210806 close statement here
            if (updatestatement != null) {
                updatestatement.close();
            }

        } catch (final Exception e) {
            System.out.println("ToDateTransformImpl:readCasesOnHand:" + e);
            throw new SQLException("ToDateTransformImpl:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // __________________________________________________________________________
    /**
     * returns true if there is data in the person history table
     * 
     * @return true if there is data in the table
     * 
     * @throws SQLException
     *           if database operation failed
     */
    public boolean count() throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;

        try {

            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.prepareStatement(sqlCount);

            final ResultSet rs = statement.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                return true;
            }
            return false;

        } catch (final Exception e) {
            System.out.println("ToDateTransformImpl:update:" + e.getMessage());
            throw new SQLException("ToDateTransformImpl:update:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // __________________________________________________________________________
    /**
     * Sets the to date value.
     * 
     * @param inFactKey
     *          the target table being populated
     * @throws SQLException
     *           if database operation failed
     */
    public void update(final FactKey inFactKey) throws SQLException {

        try {

            // 210806 connection info and prepared statement refactored for
            // performance

            // set month
            updatestatement.setDate(1, inFactKey.toDate);

            // set case
            updatestatement.setLong(2, inFactKey.logicalKey);

            // set cases on hand at start of month

            updatestatement.setDate(3, inFactKey.fromDate);

            updatestatement.setTimestamp(4, inFactKey.lastwritten);

            final int rowsUpdated = updatestatement.executeUpdate();

            if (rowsUpdated != 1) {
                System.out.println("Warning: " + rowsUpdated
                        + " row(s) updated history table.");
            }

        } catch (final Exception e) {
            System.out.println("ToDateTransformImpl:update:" + e.getMessage());
            throw new SQLException("ToDateTransformImpl:update:" + e.getMessage());
        } finally {
            // release resources
            // 210806 close statement taken from here
        }

    }

    /**
     * This module defines the key to fact records.
     */
    class FactKey {

        /**
         * the from date for a case status record.
         */

        private final Date fromDate;

        /**
         * the last written date for a case status record.
         */

        private final Timestamp lastwritten;

        /**
         * the to date for a case status record.
         */
        private Date toDate;

        /**
         * the case id.
         */
        private final long logicalKey;

        /**
         * Creates a new fact key for latest records.
         * 
         * @param inLogicalKey
         *          the case identity
         * @param inFromDate
         *          the from date
         * @param inLastWritten
         */
        public FactKey(
                final long inLogicalKey,
                final Date inFromDate,
                final Timestamp inLastWritten) {
            fromDate = inFromDate;
            logicalKey = inLogicalKey;
            lastwritten = inLastWritten;
        }

        /**
         * Sets the to date for a case status records.
         * 
         * @param inToDate
         *          the end date for a status
         */
        public void setToDate(final Date inToDate) {
            toDate = inToDate;
        }

    }
}
