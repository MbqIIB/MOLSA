/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.transformations.central.base;

import curam.util.type.*;

@AccessLevel(AccessLevelType.EXTERNAL)
public class MedicalAssistance {

  /**
   * the
   */
  protected int maintenanceAssistenceStatusKey = 0;
  protected String maintenanceAssistenceStatusCode = "";
  protected String masStatusValue = "";

  public MedicalAssistance(int inKey) {

    this.maintenanceAssistenceStatusKey = inKey;
  }

  public MedicalAssistance(
      int inKey,
      String inMaintenanceAssistenceCode,
      String inMASStatus) {
    super();
    this.maintenanceAssistenceStatusKey = inKey;
    if (inMaintenanceAssistenceCode != null) {
      maintenanceAssistenceStatusCode = inMaintenanceAssistenceCode;
    }
    if (inMASStatus != null) {
      masStatusValue = inMASStatus;
    }
  }

  public int getMaintenanceAssistenceStatusKey() {
    return maintenanceAssistenceStatusKey;
  }

  public String getMaintenanceAssistenceStatusCode() {
    return maintenanceAssistenceStatusCode;
  }

  public String getMasStatusValue() {
    return masStatusValue;
  }

}