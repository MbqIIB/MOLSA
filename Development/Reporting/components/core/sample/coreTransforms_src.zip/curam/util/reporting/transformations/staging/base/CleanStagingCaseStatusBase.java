/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * * Copyright 2005 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.transformations.staging.base;

import java.sql.SQLException;

/**
 * Provides various methods to process case status values.
 *
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
public class CleanStagingCaseStatusBase extends CleanStagingCaseStatus {

  /**
   * Creates and initializes an object to process case status value in the Curam
   * reporting staging schema
   *
   * @param inSourceTableName
   *          the staging case status table name, this is also the target table
   *          name value in the control table
   * @throws SQLException
   */
  public CleanStagingCaseStatusBase(final String inSourceTableName)
      throws SQLException {
    super(inSourceTableName);
  }

}
