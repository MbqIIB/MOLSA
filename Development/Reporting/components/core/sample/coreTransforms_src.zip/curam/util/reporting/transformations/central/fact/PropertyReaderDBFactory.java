/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.central.fact;

import java.sql.SQLException;

import curam.util.reporting.transformations.staging.base.PropertyReaderBase;

import curam.util.type.*;

/**
 * Factory class to create an instance of data marts case status
 * {@link ETLPostProcess} class, one of its subclasses, a proxy for it or a mock
 * object for it.
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public final class PropertyReaderDBFactory {

  // __________________________________________________________________________
  /**
   * Private constructor ensures no instances of this class.
   */
  private PropertyReaderDBFactory() {
  }

  // __________________________________________________________________________
  /**
   * Returns a property value.
   * 
   * @param inPropertyName
   *          table property name
   * 
   * @return String the property value, "not found" is returned if the property
   *         name does not exist
   * 
   * @throws SQLException
   *           if the address cannot be transformed
   */
  public static PropertyReaderBase newPropertyReader() throws SQLException {
    // returns the base implementation of the data access object
    PropertyReaderBase propertyReader;

    propertyReader = new PropertyReaderBase("DW_PROPERTIES");

    return propertyReader;
  }
}
