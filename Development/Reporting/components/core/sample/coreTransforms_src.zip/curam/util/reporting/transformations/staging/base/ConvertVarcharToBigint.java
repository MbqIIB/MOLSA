/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.transformations.staging.base;

import java.sql.SQLException;

/**
 * used for conversion string for bit data(DB2 for Z/OS) in big integer (DB2 for
 * Win)
 *
 */
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
public abstract class ConvertVarcharToBigint {
  private static final char[] kHexArray = { '0', '1', '2', '3', '4', '5', '6',
      '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

  /**
   * conversion string for bit data value to a long number
   *
   * @param unconvertedID
   *          the string value to convert
   * @return the curam unique identifier
   * @throws SQLException
   */
  public long vcToBi(final byte[] unconvertedID) throws SQLException {

    String id = null;
    String temp = null;

    try {
      if (unconvertedID == null) {
        return 0;
      }
      id = unconvertedID.toString();
      int position;
      final StringBuffer returnBuffer = new StringBuffer();

      for (position = 0; position < unconvertedID.length; position++) {
        returnBuffer.append(kHexArray[(unconvertedID[position] >> 4) & 0x0f]);
        returnBuffer.append(kHexArray[unconvertedID[position] & 0x0f]);
      }
      temp = returnBuffer.toString();
      final boolean isNegative = temp.charAt(0) == '8';

      if (isNegative) {
        temp = "0" + temp.substring(1);
      }
      return Long.decode((isNegative ? "-" : "") + "0x" + temp).longValue();

    } catch (NumberFormatException e) {
      throw new SQLException("Format is bad: <" + id + ">" + "<" + temp + ">");
    }
  }
}
