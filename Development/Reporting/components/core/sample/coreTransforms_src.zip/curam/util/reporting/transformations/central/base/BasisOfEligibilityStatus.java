/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * 
 */
package curam.util.reporting.transformations.central.base;

import curam.util.type.*;

@AccessLevel(AccessLevelType.EXTERNAL)
public class BasisOfEligibilityStatus extends MedicalAssistance {

  private boolean isAgeDependant = false;
  private boolean over65 = false;
  private boolean isAgedBlindDOESet = false;
  private boolean isAgedBlindDOE = false;

  private boolean isAdultChildBOE = false;
  private boolean isAdultChildBOESet = true;

  private boolean isChild = false;

  public boolean isOver65Years() {
    return over65;
  }

  public boolean isAgeDependant() {
    return isAgeDependant;
  }

  public boolean isChild() {
    return isChild;
  }

  /**
   * Returns yes, no or not applicable
   * 
   * @param inValue
   *          expects "Y", "N" or "-" for not applicable
   * 
   * @return yes, no or not applicable (null)
   */
  public static Boolean parsetIndicator(final String inValue) {
    Boolean result = null;

    if (inValue != null) {
      if ("Y".equalsIgnoreCase(inValue)) {
        result = Boolean.TRUE;
      } else if ("N".equalsIgnoreCase(inValue)) {
        result = Boolean.FALSE;
      } else if ("-".equalsIgnoreCase(inValue)) {
        // not applicable
        result = null;
      }
    }
    return result;
  }

  /**
   * Returns yes(aged), no(not aged) or not applicable
   * 
   * @param inValue
   *          expects "Y", "N" or "-" for not applicable
   * 
   * @return aged ? yes, no or not applicable (null)
   */
  public static Boolean parsetIndicator(final long inValue) {
    Boolean result = null;

    if (-1 == inValue) {
      // not applicable
      result = null;
    } else if (inValue >= 65) {
      // not applicable
      result = Boolean.TRUE;
    } else if (inValue < 65) {
      // not applicable
      result = Boolean.FALSE;
    }

    return result;
  }

  /*
   * public int compareTo(Object o) {
   * 
   * final BasisOfEligibilityStatus other = (BasisOfEligibilityStatus) o; int
   * compare = -1;
   * 
   * if (maintenanceAssistenceStatusKey == other.maintenanceAssistenceStatusKey)
   * compare = 0; if (maintenanceAssistenceStatusKey >
   * other.maintenanceAssistenceStatusKey) compare = 1; if
   * (maintenanceAssistenceStatusKey < other.maintenanceAssistenceStatusKey)
   * compare = -1; return compare; }
   */

  private BasisOfEligibilityStatus(BasisOfEligibilityStatus inKey) {
    super(inKey.getMaintenanceAssistenceStatusKey(), inKey
        .getMaintenanceAssistenceStatusCode(), inKey.getMasStatusValue());
  }

  public BasisOfEligibilityStatus getOver65Object() {
    BasisOfEligibilityStatus temp = new BasisOfEligibilityStatus(this);
    temp.isAgeDependant = true;
    temp.over65 = true;
    temp.isAgedBlindDOE = true;
    isAgedBlindDOESet = true;
    return temp;
  }

  public BasisOfEligibilityStatus getUnder65Object() {
    BasisOfEligibilityStatus temp = new BasisOfEligibilityStatus(this);
    temp.isAgeDependant = true;
    temp.over65 = false;
    temp.isAgedBlindDOE = true;
    isAgedBlindDOESet = true;

    return temp;
  }

  public BasisOfEligibilityStatus getChildObject() {
    BasisOfEligibilityStatus temp = new BasisOfEligibilityStatus(this);
    temp.isAdultChildBOE = true;
    isAdultChildBOESet = true;
    temp.isChild = true;
    return temp;
  }

  public BasisOfEligibilityStatus getAdultObject() {
    BasisOfEligibilityStatus temp = new BasisOfEligibilityStatus(this);
    temp.isAdultChildBOE = true;
    isAdultChildBOESet = true;
    temp.isChild = false;
    return temp;
  }

  public BasisOfEligibilityStatus(int inKey) {
    super(inKey);

  }

  public BasisOfEligibilityStatus(
      int inKey,
      String inMaintenanceAssistenceCode,
      String inMASStatus) {
    super(inKey, inMaintenanceAssistenceCode, inMASStatus);

  }

  public String hashKey(final String inProductCode) {

    if (isAdultChildBOESet == true || isAgedBlindDOESet == true) {
      if (isAgedBlindDOE) {
        return inProductCode + Boolean.toString(isAgeDependant())
            + (isOver65Years() == true ? "over65" : "under65");
      } else if (isAdultChildBOE) {
        return inProductCode + Boolean.toString(isChild())
            + (isChild() == true ? "child" : "adult");
      }
    } else {
      return inProductCode;
    }
    return inProductCode;
  }

  /*
   * (non-Javadoc)
   * 
   * @see curam.util.reporting.transformations.central.base.MedicaidStatus#
   * getMasStatusValue()
   */
  @Override
  public String getMasStatusValue() {
    return masStatusValue;
  }

}