/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 1999 - 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.persistence.transactions;

import java.sql.SQLException;
import java.util.EmptyStackException;
import java.util.Hashtable;
import java.util.Map;
import java.util.Stack;

import curam.util.reporting.internal.config.ConnectionProperties;
import curam.util.reporting.internal.persistence.connectionpool.DataSourceManagerImpl;

/**
 * This module implements a transaction manager.
 */

class TransactionManagerImpl implements TransactionManager {

    /**
     * the set of active transactions.
     */
    private final Map<String, Transaction> transactions = new Hashtable<String, Transaction>();

    /**
     * a mechanism to allow clients to join to a transaction.
     */
    private final Stack<Transaction> transactionCreationOrder = new Stack<Transaction>();

    /**
     * the transaction manager.
     */
    private static TransactionManagerImpl singleton;

    // ___________________________________________________________________________
    /**
     * Returns a transaction manager implementation.
     * 
     * @return TransactionManager the transaction manager
     */
    static public synchronized TransactionManager getInstance() {

        if (singleton == null) {
            singleton = new TransactionManagerImpl();
        }
        return singleton;
    }

    // ___________________________________________________________________________
    /**
     * Returns the most recently created transaction.
     * 
     * @return Transaction the transaction
     */
    public Transaction getMostRecent() throws SQLException {

        if (transactionCreationOrder.isEmpty()) {
            throw new SQLException(
            "TransactionManagerImpl: no transactions started, start transaction");
        }

        final Transaction transaction = new ManagedTransactionImpl(
                (Transaction) transactionCreationOrder.lastElement());

        return transaction;

    }

    // ___________________________________________________________________________
    /**
     * Returns a transaction object
     * 
     * @param inDataSourceName
     *          the data store to establish a connection with
     * 
     * @return Transaction the transaction to work with
     */
    public Transaction getTransaction(final String inDataSourceName)
    throws SQLException {
        return getTransaction(inDataSourceName, false);
    }

    // ___________________________________________________________________________
    /**
     * Returns a read only transaction object
     * 
     * @param inDataSourceName
     *          the data store to establish a connection with
     * 
     * @return Transaction the transaction to work with
     */
    public Transaction getReadOnlyTransaction(final String inDataSourceName)
    throws SQLException {
        return getTransaction(inDataSourceName, true);
    }

    // ___________________________________________________________________________
    /**
     * Returns a read only transaction object
     * 
     * @param String
     *          the data store to establish a connection with
     * 
     * @return Transaction the transaction to work with
     */
    private Transaction getTransaction(final String inDataStoreName, final boolean inReadOnly)

    throws SQLException {

        Transaction trans = (Transaction) transactions
        .get(getTransactionID(inDataStoreName));

        if (trans != null) {
            final Transaction transaction = new ManagedTransactionImpl(trans);

            return transaction;
        }

        if (inReadOnly) {
            trans = new TransactionImpl(DataSourceManagerImpl.getInstance()
                    .getReadOnlyConnection(inDataStoreName), inDataStoreName);
        } else {
            trans = new TransactionImpl(DataSourceManagerImpl.getInstance()
                    .getConnection(inDataStoreName), inDataStoreName);
        }

        final ConnectionProperties properties = getConnectionProperties(inDataStoreName);
        trans.setSchemaName(properties.toString());
        transactionCreationOrder.push(trans);
        transactions.put(getTransactionID(inDataStoreName), trans);

        // the client who started the transaction will
        // commit/rollback the transaction
        return trans;

    }

    // ___________________________________________________________________________
    /**
     * Terminates the transaction releasing all resources
     * 
     * @param Transaction
     *          the transaction to terminate
     */
    void transactionFinished(final Transaction inTransaction) {
        try {
            transactionCreationOrder.pop();
        } catch (final EmptyStackException e) {
            if (e.getMessage() != null) {
                e.printStackTrace();
            }
        }
        transactions.remove(getTransactionID(inTransaction.getDataSourceName()));

        try {
            DataSourceManagerImpl.getInstance().returnConnection(
                    ((TransactionImpl) inTransaction).dataStoreName,
                    ((TransactionImpl) inTransaction).connection);
        } catch (final SQLException e) {// ignore, assume if we got this far, DB
            // connections are OK
        }

    }

    // ___________________________________________________________________________
    /**
     * Returns true if this data source is configured
     * 
     * @param inDataSourceName
     *          the data store name
     * 
     * @return boolean true if data source is configured, false otherwise
     */
    public boolean supportedDataSource(final String inDataSourceName)
    throws SQLException {
        return DataSourceManagerImpl.getInstance().supportedDataSource(
                inDataSourceName);
    }

    public void releaseResources() {

        try {
            DataSourceManagerImpl.getInstance().releaseResources();
        } catch (final SQLException e) {// log exception
        }
    }

    // ___________________________________________________________________________
    /**
     * Releases any open resources
     */
    private String getTransactionID(final String inDataStoreName) {
        return Thread.currentThread().getName() + "-" + inDataStoreName;
    }

    // ___________________________________________________________________________
    /**
     * Returns the connections properties
     * 
     * @return ConnectionProperties properties
     */
    public ConnectionProperties getConnectionProperties(final String inDataStoreName)
    throws SQLException {
        return DataSourceManagerImpl.getInstance().getConnectionProperties(
                inDataStoreName);
    }

}
