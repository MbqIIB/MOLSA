/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.config;

import java.util.Iterator;

/**
 * Common interface to allow access to application properties. Provides access
 * to environment variables, system properties, file based properties and ant
 * properties are accessed.
 * 
 * Controlled access through a factory enables mock and test cases code to
 * override the default settings.
 * 
 * This is the interface contract for the property reader
 */
public interface PropertiesCache {

  // ___________________________________________________________________________
  /**
   * Allows for an implementation class to be delegated to for some methods on
   * this interface
   * 
   * @param inReader
   *          the reader
   */
  public void initialize(PropertyReader inReader);

  // ___________________________________________________________________________
  /**
   * Returns all application properties
   * 
   * @return Iterator<EnvironmentVariable> all properties defined in application
   *         properties or added at design time. An Iterator of objects of type
   *         SystemProperties
   */
  public Iterator<EnvironmentVariable> getSystemProperties();

  // ___________________________________________________________________________
  /**
   * Returns all environment variables
   * 
   * @return all environment variables defined in application properties or
   *         added at design time. An Iterator of objects of type
   *         EnvironmentVariable
   */
  public Iterator<EnvironmentVariable> getEnvironmentVariables();

  // ___________________________________________________________________________
  /**
   * Adds a property, either read from the properties file or read from the
   * system using System.getProperty
   * 
   * @param inProperty
   *          adds the property to the cache
   * 
   */
  public void add(SystemProperty inProperty);

  // ___________________________________________________________________________
  /**
   * Adds a environment variable
   * 
   * @param inProperty
   *          the environment variable to add to the cache
   */
  public void add(EnvironmentVariable inProperty);

  // ___________________________________________________________________________
  /**
   * Returns an environment variable
   * 
   * @param inName
   *          the name of the variable to search for.
   * @return return the variable from the cache
   */
  public EnvironmentVariable getEnv(String inName);

  // ___________________________________________________________________________
  /**
   * Returns an system property variable configured within the application
   * configuration files, or via System.getProperty
   * 
   * @param inName
   *          searches the cache for the property
   * @return {@link SystemProperty}
   */
  public SystemProperty getProperty(String inName);

  // ___________________________________________________________________________
  /**
   * Returns all connection properties
   * 
   * @return {@link ConnectionProperties}
   * @throws Exception
   */
  public ConnectionProperties[] getConnectionProperties() throws Exception;

  // ___________________________________________________________________________
  /**
   * Returns a data mart connection properties
   * 
   * @param inSchemaName
   * @return {@link ConnectionProperties}
   * @throws Exception
   */

  public ConnectionProperties getConnectionProperties(String inSchemaName)
      throws Exception;

  // ___________________________________________________________________________
  /**
   * Returns a property value
   * 
   * @param inKey
   *          the property key
   * @return String the property value
   */
  public String getValue(String inKey);

  // ___________________________________________________________________________
  /**
   * Return the target database environment
   * 
   * @return TargetDatabaseType the target RDBMS environment
   */
  public TargetDataBaseType getTargetEnvironment();

  // ___________________________________________________________________________
  /**
   * Returns the target technology stack brand
   * 
   * @return TechnologyStackBrand returns InfoSphere or OWB
   */
  public TechnologyStackBrand getTechStackVendor();

}
