/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-3011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.FileNotFoundException;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.PropertiesCache;
import curam.util.reporting.internal.config.PropertyReaderFactory;
import curam.util.reporting.internal.config.TargetDataBaseType;

import curam.util.type.*;

/**
 * 
 * This reads the build file name, the value returned is dependent on the target
 * platform.
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntReadBuildFileName extends Task {
    /**
     * write the build file name to here
     */
    private String buildFilePropertyName = "BUILDSCRIPTNAME";

    /**
     * write the build file name to here
     */
    private String reportingDir;

    // ___________________________________________________________________________
    /**
     * Sets the build file for the appropriate platform
     */
    @Override
    public void execute() throws BuildException {
        final String isSet = getProject().getProperty(buildFilePropertyName);
        final String propertyFile = reportingDir + DataWarehouseConstants.kPropertyFile;
        try {
            final String oracleBuildFileName = "oraclebuild.xml";
            final String db2BuildFileName = "db2build.xml";
            if (oracleBuildFileName.equalsIgnoreCase(isSet)
                    || db2BuildFileName.equalsIgnoreCase(isSet)) {
                return;
            }
            String currentSystem = oracleBuildFileName;
            // reads the properties file
            final PropertiesCache propertyReader = PropertyReaderFactory
            .getConnectionPropertyReader();
            final TargetDataBaseType targetDataBaseType = propertyReader
            .getTargetEnvironment();
            if (propertyReader.getValue(DataWarehouseConstants.kDatabaseType) == null) {
                throw new BuildException(DataWarehouseConstants.kDatabaseType
                        + " is missing  from property file");
            }
            if (targetDataBaseType.isDB2()) {
                currentSystem = db2BuildFileName;
            }
            BILogger.info("Property file read, setting to " + currentSystem);
            getProject().setProperty(buildFilePropertyName, currentSystem);
        } catch (final FileNotFoundException e) {
            throw new BuildException("File not found <" + propertyFile
                    + "> , detailed message= " + e.getMessage());
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the base path
     * 
     * @param inReportingDir
     *          base path
     */
    public void setReportingDir(final String inReportingDir) {
        reportingDir = inReportingDir;
    }

    // ___________________________________________________________________________
    /**
     * Write property to here
     * 
     * @param inPropertyName
     *          property name to create
     */
    public void setBuildFilePropertyName(final String inPropertyName) {
        if (inPropertyName != null && inPropertyName.length() > 0) {
            buildFilePropertyName = inPropertyName;
        }
    }
}
