/*
 * Licensed Materials - Property of IBM Copyright IBM Corporation 2012. All
 * Rights Reserved. US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd. All rights reserved. This software is
 * the confidential and proprietary information of Curam Software, Ltd.
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.OWBFilesSelected;
import curam.util.reporting.internal.tasks.ReportingFileManager.SimpleFilter;
import curam.util.reporting.internal.tasks.model.OWBRunProperties;
import curam.util.reporting.internal.tasks.model.ReportingDataTemplateFile;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.reporting.internal.tasks.model.ReportingOWBFile;
import curam.util.reporting.internal.tasks.model.ReportingProperty;
import curam.util.reporting.internal.tasks.model.ReportingLocalisedProperty;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;

/**
 * Build any files for execution by the Ant environment.
 */
@AccessLevel (AccessLevelType.INTERNAL)
public class ReportingConcatenator {
    public static final String ISO8859_1 = "ISO8859_1";

    public static final String characterSetUTF_8 = "UTF-8";

    public static final String characterSet_8859_1 = "8859_1";

    /**
     * Default constructor
     */
    public ReportingConcatenator() {
    }

    /**
     * Utility to copy files to a destination directory appending all files
     * together
     * 
     * @param inFileExplorer - the files names to be concatenated.
     * @param inDestination - the destination file
     * @throws IOException
     */
    public void concatenateFilesToFile(final FileExplorer inFileExplorer,
            final File inDestination) throws IOException {
        BufferedReader in = null;
        ReportingFile name;
        File sourceFile;
        // save the old version first
        final File destination = inDestination;
        List < ReportingFile > inFiles;
        try {
            inFiles = inFileExplorer.getFiles();
        } catch (final Exception e1) {
            throw new IOException(e1.getMessage());
        }
        final Charset utf = Charset.forName(characterSetUTF_8);
        final BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(destination, true), utf));
        for (int i = 0; i < inFiles.size(); i++) {
            name = (ReportingFile) inFiles.get(i);
            if (name.hasCustom()) {
                sourceFile = new File(name.getCustom().getFileName());
            } else {
                sourceFile = new File(name.getFileName());
            }
            try {
                in = new BufferedReader(new FileReader(sourceFile));
                // Transfer bytes from in to out
                String line;
                while ( (line = in.readLine()) != null) {
                    line = line.trim();
                    if (line.length() > 0) {
                        out.write(line);
                    }
                    out.newLine();
                }
                out.flush();
                if (name.hasCustom()) {
                    sourceFile = new File(name.getCustom().getFileName());
                    in = new BufferedReader(new FileReader(sourceFile));
                    // Transfer bytes from in to out
                    while ( (line = in.readLine()) != null) {
                        line = line.trim();
                        if (line.length() > 0) {
                            out.write(line);
                        }
                        out.newLine();
                    }
                    out.flush();
                }
                out.flush();
                in.close();
            } catch (final FileNotFoundException e) {
                if (name.isCustom()) {
                    BILogger.info("info, no custom file " + name);
                } else {
                    BILogger.info("warning, no file found " + name);
                }
            } finally {
                if (out != null) {
                    out.close();
                }
            }
        }
    }

    /**
     * Prototype method - not for use.
     * 
     * @param inFiles
     * @throws IOException
     */
    public void updateBuildTargetNames(final List < ReportingFile > inFiles)
    throws IOException {
        for (int i = 0; i < inFiles.size(); i++) {
            final String testFileName =
                ((ReportingFile) inFiles.get(i)).getFileName();
            BILogger.info("processing file=" + testFileName);
            final File origionalFile = new File(testFileName);
            final File generatedFile = new File(origionalFile + ".gen");
            //
            generatedFile.delete();
            generatedFile.createNewFile();
            final Charset utf = Charset.forName(characterSetUTF_8);
            final BufferedWriter out =
                new BufferedWriter(new OutputStreamWriter(
                        new FileOutputStream(generatedFile, true), utf));
            final BufferedReader in =
                new BufferedReader(new FileReader(origionalFile));
            // Transfer bytes from in to out
            String line;
            while ( (line = in.readLine()) != null) {
                out.write(line);
                out.newLine();
            }
            out.flush();
            out.close();
            in.close();
            origionalFile.delete();
            generatedFile.renameTo(new File(testFileName));
        }
    }

    /**
     * Create an Oracle script to import reporting meta data
     * 
     * @param inFiles the list of files to process
     * @param inDestinationDir when to write the script
     * @param inLogDirectory log
     * @param inOWBURL the live URL
     * @param inOWBFilesSelected
     * @throws IOException
     */
    public void buildOWBImportScript(final List < ReportingFile > inFiles,
            final String inDestinationDir, final String inLogDirectory,
            final String inOWBURL,
            final OWBFilesSelected inOWBFilesSelected) throws IOException {
        ReportingOWBFile name;
        File sourceFile;
        final File logDir = new File(inLogDirectory);
        if (!logDir.exists()) {
            final String message =
                "OWB log directory does not exist/cannot write "
                + inLogDirectory;
            BILogger.info(message);
            throw new IOException(message);
        }
        final String importFileName = "owbimport.tcl";
        final File generatedFile = new File(inDestinationDir, importFileName);
        // File logFile = new File(inLogDirectory, "owbimport.log");
        generatedFile.delete();
        generatedFile.createNewFile();
        // logFile.delete();
        // logFile.createNewFile();
        final Charset utf = Charset.forName(characterSetUTF_8);
        final BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(generatedFile, true), utf));
        final String strippedOfQuotes =
            inOWBFilesSelected.workSpaceVersion.replace("'",
            "");
        if (strippedOfQuotes == null || strippedOfQuotes.length() == 0) {
            out.write("OMBCONNECT " + inOWBURL);
        } else {
            out.write("OMBCONNECT " + inOWBURL + " USE WORKSPACE "
                    + inOWBFilesSelected.workSpaceVersion);
        }
        out.newLine();
        out.write("puts \"connected\"");
        out.newLine();
        out.write("puts \"   importing all schema files first\" ");
        out.newLine();


        for (int i = 0; i < inFiles.size(); i++) {
            name = (ReportingOWBFile) inFiles.get(i);
            if (name.isOWBSchemaFile()) {
                sourceFile = new File(name.getFileName());
                out.write("puts \"   importing " + name.getComponentName()
                        + " "
                        + sourceFile.getName()
                        + (name.isCustom() == true ? " custom" : "")
                        + "\"");
                out.newLine();
                out.write("OMBIMPORT FROM MDL_FILE '"
                        + sourceFile.getCanonicalPath().replaceAll("\\\\", "/")
                        + "' USE UPDATE_MODE MATCH_BY NAMES");
                out.newLine();
            }
        }
        out.write("OMBCOMMIT");
        out.newLine();
        for (int i = 0; i < inFiles.size(); i++) {
            name = (ReportingOWBFile) inFiles.get(i);
            if (!name.isOWBSchemaFile()) {
                sourceFile = new File(name.getFileName());
                out.write("puts \"   importing " + sourceFile.getName()
                        + (name.isCustom() == true ? " custom" : "") + "\"");
                out.newLine();
                out.write("OMBIMPORT FROM MDL_FILE '"
                        + sourceFile.getCanonicalPath().replaceAll("\\\\", "/")
                        + "' USE UPDATE_MODE MATCH_BY NAMES");
                out.newLine();



                out.newLine();
            }
        }
        out.write("OMBCOMMIT");
        out.newLine();
        out.write("OMBDISCONNECT");
        out.newLine();
        out.write("puts \"disconnected\"");
        out.newLine();
        out.close();
    }

    /**
     * Create an Oracle script to import reporting meta data
     * 
     * @param inFiles the list of files to process
     * @param inDestinationDir when to write the script
     * @param inLogDirectory log
     * @param inOWBURL the live URL
     * @param inOWBFilesSelected
     * @throws IOException
     */
    public void buildOWBExportETLScript(final List < ReportingFile > inFiles,
            final String inDestinationDir, final String inLogDirectory,
            final String inOWBURL,
            final OWBFilesSelected inOWBFilesSelected) throws IOException {
        try {
            BILogger.info("Creating export ombplus script for all ETL processes ");
            BILogger.debug("Files to be processed: " + inFiles.size());
            ReportingOWBFile name;
            File sourceFile;
            final File logDir = new File(inLogDirectory);
            if (!logDir.exists()) {
                final String message =
                    "OWB log directory does not exist/cannot write "
                    + inLogDirectory;
                BILogger.debug("    " + message);
                throw new IOException(message);
            }
            final String exportFileName = "owbexportetl.tcl";
            final File generatedFile =
                new File(inDestinationDir, exportFileName);
            BILogger.debug("     about to delete old file "
                    + generatedFile.getAbsolutePath());
            generatedFile.delete();
            BILogger.debug("     about to create new file "
                    + generatedFile.getAbsolutePath());
            generatedFile.createNewFile();
            BILogger.debug("     created " + generatedFile.getAbsolutePath());
            // logFile.delete();
            // logFile.createNewFile();
            final Charset utf = Charset.forName(characterSetUTF_8);
            final BufferedWriter out =
                new BufferedWriter(new OutputStreamWriter(
                        new FileOutputStream(generatedFile, true), utf));
            final String strippedOfQuotes =
                inOWBFilesSelected.workSpaceVersion.replace(
                        "'", "");
            if (strippedOfQuotes == null || strippedOfQuotes.length() == 0) {
                out.write("OMBCONNECT " + inOWBURL);
            } else {
                out.write("OMBCONNECT " + inOWBURL + " USE WORKSPACE "
                        + inOWBFilesSelected.workSpaceVersion);
            }
            out.newLine();
            out.write("puts \"connected\"");
            out.newLine();
            out.write("puts \"   exporting ETL process only, export schem meta data manually \" ");
            out.newLine();
            final String logPath =
                logDir.getAbsolutePath().replaceAll("\\\\", "/");
            for (int i = 0; i < inFiles.size(); i++) {
                name = (ReportingOWBFile) inFiles.get(i);
                if (!name.isOWBSchemaFile()) {
                    sourceFile = new File(name.getFileName());
                    out.write("puts \"   exporting " + name.getComponentName()
                            + " "
                            + name.getETLName()
                            + (name.isCustom() == true ? " custom" : "")
                            + "\"");
                    out.newLine();
                    try {
                        final ReportingDBType schemaType = new ReportingDBType(
                                sourceFile.getName());
                        final String oracleModuleStaging = "STAGING";
                        final String oracleModuleWarehouse = "CENTRAL";
                        final String oracleModuleDatamarts = "DATAMARTS";
                        String oracleModule = oracleModuleStaging;
                        if (schemaType.isCentralDB()) {
                            oracleModule = oracleModuleWarehouse;
                        } else if (schemaType.isDataMart()) {
                            oracleModule = oracleModuleDatamarts;
                        }
                        out.write("OMBEXPORT MDL_FILE '"
                                + sourceFile.getCanonicalPath().replaceAll(
                                        "\\\\", "/")
                                        + "' PROJECT 'REPORTING' COMPONENTS (ORACLE_MODULE '"
                                        + oracleModule + "', " + " MAPPING "
                                        + " '"
                                        + name.getETLName()
                                        + "') OUTPUT LOG TO '" + logPath + "/"
                                        + name.getETLName()
                                        + ".log'");
                        out.newLine();
                        out.flush();
                    } catch (final Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            out.newLine();
            out.write("OMBDISCONNECT");
            out.newLine();
            out.write("puts \"disconnected\"");
            out.newLine();
            out.flush();
            out.close();
            BILogger.debug("     closing " + generatedFile.getAbsolutePath());
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * build a java source path
     * 
     * @param inJavaPaths
     * @param inSeparator
     * @param inOnlyCustom
     * @return String
     */
    public String buildJavaPaths(final List < ReportingFile > inJavaPaths,
            final String inSeparator, final boolean inOnlyCustom) {
        ReportingFile name;
        File sourceFile;
        final StringBuffer paths = new StringBuffer();
        paths.append(".").append(inSeparator);
        BILogger.debug("Processing paths, adding current directory " + ".");
        for (int i = 0; i < inJavaPaths.size(); i++) {
            name = (ReportingFile) inJavaPaths.get(i);
            sourceFile = new File(name.getFileName());
            BILogger.debug("Processing adding " + name.getFileName());
            if (!sourceFile.exists()) {
                BILogger.debug("Processing directory does not exist "
                        + name.getFileName());
            } else {
                paths.append(sourceFile.getAbsoluteFile()).append(inSeparator);
            }
        }
        return paths.toString();
    }

    /**
     * build a java source path for compilation
     * 
     * @param inJavaPaths
     * @param inSeparator
     * @return String
     */
    public String buildComponentList(final List < ReportingFile > inJavaPaths,
            final String inSeparator) {
        ReportingFile name;
        File sourceFile;
        final StringBuffer paths = new StringBuffer();
        for (int i = 0; i < inJavaPaths.size(); i++) {
            name = (ReportingFile) inJavaPaths.get(i);
            sourceFile = new File(name.getFileName());
            if (!sourceFile.exists()) {
                if (!name.isCustom()) {
                    BILogger.info("info: no source directory"
                            + sourceFile.getAbsolutePath());
                } else {
                    System.out
                    .println("info, no custom java source directory: "
                            + sourceFile.getAbsolutePath());
                }
            } else {
                paths.append(sourceFile.getName()).append(inSeparator);
            }
        }
        return paths.toString();
    }

    /**
     * Utility to copy files to a destination directory appending where the file
     * names exists in more than one directory
     * 
     * @param inStaticDataFiles
     * @param inDataManagerDirectory
     * @param inFilter
     */
    public void concatenateFilesToDirectory(
            final List < ReportingFile > inStaticDataFiles,
            final String inDataManagerDirectory,
            final SimpleFilter inFilter, final String inIssueWarning) {
        BufferedReader in = null;
        ReportingFile name;
        File sourceFile;
        File destinationFile;
        boolean appendFlag = false;
        BufferedWriter out;
        final boolean logged = false;
        for (int i = 0; i < inStaticDataFiles.size(); i++) {
            name = (ReportingFile) inStaticDataFiles.get(i);
            sourceFile = new File(name.getFileName());
            destinationFile = new File(inDataManagerDirectory + File.separator
                    + sourceFile.getName());
            try {
                BILogger.debug("     " + sourceFile.getAbsolutePath()
                        + (name.isCustom() ? "[custom] " : ""));
                BILogger.debug("         " + destinationFile.getAbsolutePath());
                if (!destinationFile.exists()) {
                    destinationFile.createNewFile();
                } else {
                    appendFlag = true;
                }
                final Charset utf = Charset.forName(characterSetUTF_8);
                in =
                    new BufferedReader(new InputStreamReader(
                            new FileInputStream(
                                    sourceFile), utf));
                out =
                    new BufferedWriter(new OutputStreamWriter(
                            new FileOutputStream(
                                    destinationFile, appendFlag), utf));
                // Transfer bytes from in to out
                String line;
                int lineNumber = 0;
                final StringBuffer info = new StringBuffer();
                while ( (line = in.readLine()) != null) {
                    // run any replacement filters required
                    lineNumber++;
                    if (inFilter != null) {
                        line = inFilter.process(line);
                    }
                    if (inIssueWarning != null) {
                        final int notReplaced = line.indexOf(inIssueWarning);
                        if (notReplaced != -1) {
                            info.append("\nInfo, check if property was mising at line "
                                    + lineNumber);
                        }
                    }
                    if (line.trim().length() == 0) {
                        // do nothing do not write empty lines
                    } else {
                        out.write(line);
                        out.newLine();
                    }
                }
                out.flush();
                out.close();
                in.close();
                BILogger.debug("         properties statistics: "
                        + info.toString());
            } catch (final Exception e) {
                BILogger.info("erorr:no file found " + name
                        + e.getMessage());
            }
        }
    }

    /**
     * builds SQL statements to update missing last written values
     * 
     * @param inStaticDataFiles
     * @param inDataManagerDirectory
     * @param inTargetDataBaseType
     */
    public void concatenateUpdateSourceFilesToDirectory(
            final List < ReportingFile > inStaticDataFiles,
            final String inDataManagerDirectory,
            final TargetDataBaseType inTargetDataBaseType) {
        BufferedReader in = null;
        ReportingFile name;
        File sourceFile;
        File destinationFile;
        boolean appendFlag = false;
        BufferedWriter out;
        final String kDB2Template = "CURRENT_TIMESTAMP";
        final String kOracleTemplate = "SYSDATE";
        String now = kDB2Template;
        short tablesEffected = 0;
        boolean logged = false;
        if (inTargetDataBaseType.isORACLE()) {
            now = kOracleTemplate;
        }
        for (int i = 0; i < inStaticDataFiles.size(); i++) {
            name = (ReportingFile) inStaticDataFiles.get(i);
            if (name.hasCustom()) {
                sourceFile = new File(name.getCustom().getFileName());
            } else {
                sourceFile = new File(name.getFileName());
            }
            destinationFile = new File(inDataManagerDirectory + File.separator
                    + sourceFile.getName());
            if (!logged) {
                BILogger.info("Processing " + name.getComponentName());
                logged = true;
            }
            try {
                BILogger.info("     "
                        + new File(name.getFileName()).getName()
                        + (name.isCustom() ? "[custom] " : ""));
                if (!destinationFile.exists()) {
                    destinationFile.createNewFile();
                } else {
                    appendFlag = true;
                }
                in = new BufferedReader(new FileReader(sourceFile));
                final Charset utf = Charset.forName(characterSetUTF_8);
                out =
                    new BufferedWriter(new OutputStreamWriter(
                            new FileOutputStream(
                                    destinationFile, appendFlag), utf));
                // Transfer bytes from in to out
                String line;
                StringBuffer updateStatements = new StringBuffer();
                while ( (line = in.readLine()) != null) {
                    if (line.length() > 0) {
                        updateStatements = new StringBuffer();
                        updateStatements
                        .append("update ")
                        .append(line)
                        .append(" set lastwritten = ")
                        .append(now)
                        .append(
                                " where lastwritten is null;"
                                + System.getProperty("line.separator"));
                        tablesEffected++;
                        out.write(updateStatements.toString());
                    }
                    out.newLine();
                }
                out.flush();
                out.close();
                in.close();
                BILogger.info("Created " + tablesEffected
                        + " update statements");
            } catch (final Exception e) {
                BILogger.info("erorr:no file found " + name
                        + e.getMessage());
            }
        }
    }

    /**
     * builds SQL statements insert platform time stamp values
     * 
     * @param inTemplate
     */
    public void createSourceInitialDataFile(
            final String inTemplate,
            final TargetDataBaseType inTargetDataBaseType) {
        BufferedReader in = null;
        final ReportingFile name;
        final File sourceFile;
        File destinationFile;
        boolean appendFlag = false;
        BufferedWriter out;
        final String kDB2Template = "CURRENT_TIMESTAMP";
        final String kOracleTemplate = "SYSDATE";
        String now = kDB2Template;
        short tablesEffected = 0;
        if (inTargetDataBaseType.isORACLE()) {
            now = kOracleTemplate;
        }
        destinationFile = new File(new File(inTemplate).getParentFile(),
        "curam_initialdata.sql");
        sourceFile = new File(inTemplate);
        if (!sourceFile.exists()) {
            BILogger.error("missing file " + sourceFile.getAbsolutePath());
            return;
        } else {
            BILogger.info("processing file " + sourceFile.getAbsolutePath());
        }
        try {
            if (!destinationFile.exists()) {
                if (destinationFile.createNewFile() == false) {
                    BILogger.error("could not create file "
                            + destinationFile.getAbsolutePath());
                }
            } else {
                if (destinationFile.delete()== false){
                    BILogger.debug("could not delete file "
                            + destinationFile.getAbsolutePath());
                } else {
                    BILogger.debug("Deleted file "
                            + destinationFile.getAbsolutePath());
                }

                appendFlag = false;
            }


            in = new BufferedReader(new FileReader(sourceFile));
            final Charset utf = Charset.forName(characterSetUTF_8);
            out =
                new BufferedWriter(new OutputStreamWriter(
                        new FileOutputStream(
                                destinationFile, appendFlag), utf));
            // Transfer bytes from in to out
            String line;
            String newLine = null;
            while ( (line = in.readLine()) != null) {
                if (line.length() > 0) {
                    newLine= line.replace("BI_DATETIME", now);
                    tablesEffected++;
                    out.write(newLine);
                }
                out.newLine();
                BILogger.debug(newLine);
            }
            out.flush();
            out.close();
            in.close();
            BILogger.info("Processed, initial data file generated "
                    + destinationFile.getName());
        } catch (final Exception e) {
            BILogger.error("erorr: " + e.getMessage());
        }
    }

    /**
     * Appends run files from each component together creating the over all run
     * script Within each component, the custom file will be used instead of the
     * original if it exists.
     * 
     * @param inExplorer the list of base artifacts to process
     * @param inDataManagerDirectory - the target directory
     * @param tokens
     * @throws Exception
     */
    public void concatenateGrantFilesToDirectory(final FileExplorer inExplorer,
            final String inDataManagerDirectory,
            final Vector < ReportingProperty > tokens)
    throws Exception {
        BufferedReader in = null;
        ReportingFile name;
        File sourceFile;
        File destinationFile;
        boolean appendFlag = false;
        BufferedWriter out;
        final List < ReportingFile > inStaticDataFiles = inExplorer.getFiles();
        boolean logged = false;
        for (int i = 0; i < inStaticDataFiles.size(); i++) {
            name = (ReportingFile) inStaticDataFiles.get(i);
            if (name.hasCustom()) {
                sourceFile = new File(name.getCustom().getFileName());
            } else {
                sourceFile = new File(name.getFileName());
            }
            destinationFile = new File(inDataManagerDirectory + File.separator
                    + sourceFile.getName());
            try {
                new File(inDataManagerDirectory).mkdir();
                if (!destinationFile.exists()) {
                    destinationFile.createNewFile();
                } else {
                    appendFlag = true;
                }
                if (!logged) {
                    BILogger.info("Processing " + name.getComponentName());
                    logged = true;
                }
                BILogger.info("     "
                        + new File(name.getFileName()).getName()
                        + (name.isCustom() ? "[custom] " : ""));
                ReportingProperty token = null;
                in = new BufferedReader(new FileReader(sourceFile));
                final Charset utf = Charset.forName(characterSetUTF_8);
                out =
                    new BufferedWriter(new OutputStreamWriter(
                            new FileOutputStream(
                                    destinationFile, appendFlag), utf));
                // Transfer bytes from in to out
                String line;
                while ( (line = in.readLine()) != null) {
                    if (line.trim().length() > 0) {
                        // replace all tokens with values
                        for (final Iterator < ReportingProperty > it =
                            tokens.iterator(); it
                            .hasNext();) {
                            token = it.next();
                            line =
                                line.replace(token.getName(), token
                                        .getValue());
                        }
                        out.write(line);
                        out.newLine();
                    }
                }
                out.flush();
                out.close();
                in.close();
            } catch (final Exception e) {
                System.out
                .println("concatenateGrantFilesToDirectory:erorr:no file found "
                        + name + e.getMessage());
            }
        }
    }

    /**
     * Appends run files from each component together creating the over all run
     * script Within each component, the custom file will be used instead of the
     * original if it exists.
     * 
     * @param inStaticDataFiles the list of base artifacts to process
     * @param inDataManagerDirectory - the target directory
     * @param inPre
     * @param inPost
     */
    public void concatenateRunFilesToDirectory(
            final List < ReportingFile > inRunFiles,
            final String inRunDirectory,
            final OWBRunProperties inRunProperties) {
        BufferedReader in = null;
        ReportingFile name;
        File sourceFile;
        File destinationFile;
        boolean appendFlag = false;
        BufferedWriter out;
        boolean logged = false;
        for (int i = 0; i < inRunFiles.size(); i++) {
            name = (ReportingFile) inRunFiles.get(i);
            if (name.hasCustom()) {
                sourceFile = new File(name.getCustom().getFileName());
            } else {
                sourceFile = new File(name.getFileName());
            }
            ReportingDBType type = null;
            try {
                type = new ReportingDBType(sourceFile.getName());
            } catch (final Exception e1) {
                e1.printStackTrace();
            }
            destinationFile = new File(inRunDirectory + File.separator
                    + sourceFile.getName());
            if (!logged) {
                BILogger.info("Processing " + name.getComponentName());
                logged = true;
            }
            BILogger.info("     " + new File(name.getFileName()).getName()
                    + (name.isCustom() ? "[custom] " : ""));
            try {
                new File(inRunDirectory).mkdir();
                if (!destinationFile.exists()) {
                    destinationFile.createNewFile();
                } else {
                    appendFlag = true;
                }
                in = new BufferedReader(new FileReader(sourceFile));
                final Charset utf = Charset.forName(characterSetUTF_8);
                out =
                    new BufferedWriter(new OutputStreamWriter(
                            new FileOutputStream(
                                    destinationFile, appendFlag), utf));
                // Transfer bytes from in to out
                String line;
                while ( (line = in.readLine()) != null) {
                    if (line.trim().length() > 0) {
                        String runStatement =
                            "@" + inRunProperties.getTemplate() + " '"
                            + inRunProperties.getOwner() + "' ";
                        if (type.isStagingArea()) {
                            runStatement +=
                                inRunProperties.getStagingLocation();
                        } else if (type.isCentralDB()) {
                            runStatement +=
                                inRunProperties.getWarehouseLocation();
                        }
                        if (type.isDataMart()) {
                            runStatement +=
                                inRunProperties.getDatamartLocation();
                        }
                        runStatement += " " + inRunProperties.getJopType();
                        runStatement += " " + line;
                        runStatement += " " + inRunProperties.getSystemParams();
                        runStatement += " " + inRunProperties.getCustomParams();
                        out.write(runStatement);
                        out.newLine();
                    }
                }
                out.flush();
                out.close();
                in.close();
            } catch (final Exception e) {
                BILogger.info("erorr: no file found " + name
                        + e.getMessage());
            }
        }
    }

    /**
     * Replaces tokens with values
     * 
     * @param inStringWithTokens string with tokens
     * @param tokens the token names and values - the target directory
     * @return tokens - the value string
     * @throws Exception
     */
    static public Vector < ReportingProperty > readProperties(
            final File inPropertiesFile,
            final BufferedWriter inLogFile) throws Exception {
        final Vector < ReportingProperty > tokens =
            new Vector < ReportingProperty >();
        if (inPropertiesFile.exists()) {
            final BufferedReader br = new BufferedReader(new InputStreamReader(
                    new FileInputStream(inPropertiesFile), ISO8859_1));
            String strLine;
            // Read File Line By Line
            while ( (strLine = br.readLine()) != null) {
                final boolean comment = strLine.startsWith("#");
                if (!comment || strLine.trim().length() != 0) {
                    String propertyKey = "";
                    String propertyValue = "";
                    if (strLine.contains("=")) {
                        final int equalsIndex = strLine.indexOf("=");
                        propertyKey = strLine.substring(0, equalsIndex);
                        if (propertyKey.contains(" ")) {
                            inLogFile
                            .write("\n        Error: property key cannot have a space characher  "
                                    + propertyKey);
                            inLogFile.newLine();
                        }
                        final int startOfValue =
                            equalsIndex + 1 > strLine.length() ? strLine
                                    .length() : equalsIndex + 1;
                                    propertyValue =
                                        strLine.substring(startOfValue, strLine
                                                .length());
                                    final ReportingLocalisedProperty property =
                                        new ReportingLocalisedProperty();
                                    property.setName(propertyKey);
                                    property.setValue(propertyValue);
                                    if (tokens.contains(property)) {
                                        inLogFile.append("\n        Error: duplicate key  "
                                                + propertyKey);
                                        inLogFile.newLine();
                                    }
                                    tokens.add(property);
                    }
                }
            }
        }
        return tokens;
    }

    /**
     * Replaces tokens with values
     * 
     * @param inStringWithTokens string with tokens
     * @param tokens the token names and values - the target directory
     * @return tokens - the property names and values string
     * @throws Exception
     */
    static public Vector < ReportingProperty > readPropertiesAsUTF8(
            final File inPropertiesFile) throws Exception {
        final Vector < ReportingProperty > tokens =
            new Vector < ReportingProperty >();
        if (inPropertiesFile.exists()) {
            try {
                final FileInputStream in = new FileInputStream(
                        inPropertiesFile.getAbsolutePath());
                final Properties prop = new Properties();
                prop.load(in);
                @SuppressWarnings ("rawtypes")
                final Enumeration keys = prop.keys();
                while (keys.hasMoreElements()) {
                    final String name = (String) keys.nextElement();
                    final String value = prop.getProperty(name);
                    final ReportingProperty property = new ReportingProperty();
                    property.setName(name);
                    // replace all single quotes with two single quotes
                    property.setValue(value);
                    tokens.add(property);
                }
                in.close();
            } catch (final Exception e) {
                e.printStackTrace();
            }
        }
        return tokens;
    }

    /**
     * Replaces tokens with values
     * 
     * @param inStringWithTokens string with tokens
     * @param tokens the token names and values - the target directory
     * @return tokens - the value string
     * @throws Exception
     */
    static public String tokenReplace(final String inStringWithTokens,
            final Vector < ReportingProperty > tokens) throws Exception {
        final StringBuffer result = new StringBuffer();
        try {
            // convert String into InputStream
            final InputStream is =
                new ByteArrayInputStream(inStringWithTokens.getBytes());
            ReportingProperty token = null;
            final BufferedReader in =
                new BufferedReader(new InputStreamReader(is));
            String line;
            while ( (line = in.readLine()) != null) {
                if (line.trim().length() > 0) {
                    // replace all tokens with values
                    for (final Iterator < ReportingProperty > it =
                        tokens.iterator(); it.hasNext();) {
                        token = it.next();
                        final int found = line.indexOf(token.getName());
                        if (found != -1) {
                            line =
                                line.replace(token.getName(), token
                                        .getValue());
                        }
                    }
                }
                result.append(line);
                result.append(System.getProperty("line.separator"));
            }
            in.close();
        } catch (final Exception e) {
            System.out
            .println("concatenateGrantFilesToDirectory:erorr:no file found "
                    + e.getMessage());
        }
        return result.toString();
    }

    /**
     * Replaces tokens with values
     * 
     * @param inStringWithTokens string with tokens
     * @param tokens the token names and values - the target directory
     * @param initialData 0 is initial data, 1 demo data
     * @return tokens - the value string
     * @throws Exception
     */
    static public String tokenReplaceData(final String inStringWithTokens,
            final Vector < ReportingProperty > tokens,
            final String inTokenMarkerCharacter,
            final String inPrefix, final String inSuffix,
            final boolean inVerbose,
            final ComponentName inName) {
        final StringBuffer result = new StringBuffer();
        try {
            // convert String into InputStream
            ReportingProperty token = null;
            String line = inStringWithTokens;
            boolean tokenReplaced = false;
            if (line != null && line.length() > 0 && line.trim().length() > 0) {
                if (line.trim().length() > 0) {
                    // replace all tokens with values
                    tokenReplaced = false;
                    for (final Iterator < ReportingProperty > it =
                        tokens.iterator(); it.hasNext();) {
                        token = it.next();
                        final String toFind =
                            inTokenMarkerCharacter + token.getName()
                            + inSuffix
                            + inTokenMarkerCharacter;
                        final int found = line.indexOf(token.getName());
                        if (found != -1) {
                            tokenReplaced = true;
                            final String quotesReplaced =
                                token.getValue().replace("'", "''");
                            line = line.replace(toFind, inTokenMarkerCharacter
                                    + quotesReplaced + inTokenMarkerCharacter);
                        }
                    }
                    if (tokenReplaced == false && inVerbose == true) {
                        if (inName.isLanguageAndRegion() > 0) {
                        }
                    }
                    result.append(line);
                    result.append(System.getProperty("line.separator"));
                }
            }
        } catch (final Exception e) {
            System.out
            .println("concatenateGrantFilesToDirectory:erorr: no file found "
                    + e.getMessage());
        }
        return result.toString();
    }

    /**
     * Appends run files from each component together creating the over all run
     * script Within each component, the custom file will be used instead of the
     * original if it exists.
     * 
     * @param inExplorer the list of base artifacts to process
     * @param inDataManagerDirectory - the target directory
     * @param initialData 0 is initial data, 1 demo data
     * @throws Exception
     */
    public void generateSQLWithTokeniser(final FileExplorer inExplorer,
            final String inDataManagerDirectory,
            final String inTokenMarkerCharacter,
            final String inPrefixed, final int inInitialData) throws Exception {
        ReportingDataTemplateFile reportingDataTemplateFile;
        final boolean verbose = false;
        final StringBuffer warnings = new StringBuffer();
        BILogger.info("Generating SQL for "
                + inExplorer.getComponentName());
        final List < ReportingFile > templateFiles = inExplorer.getFiles();
        BILogger.info("     " + templateFiles.size()
                + " files to be processed");
        for (int i = 0; i < templateFiles.size(); i++) {
            reportingDataTemplateFile =
                (ReportingDataTemplateFile) templateFiles
                .get(i);
            final File sourceFile =
                new File(reportingDataTemplateFile.getTemplateSQLFile()
                        .getAbsolutePath());
            final File destinationFile =
                new File(reportingDataTemplateFile.getSQLFile()
                        .getAbsolutePath());
            final File propertiesFile =
                reportingDataTemplateFile.getPropertiesFile();
            try {
                copyTemplate(sourceFile, destinationFile, propertiesFile,
                        warnings,
                        verbose, inExplorer.getComponentName(),
                        inTokenMarkerCharacter,
                        inPrefixed);
            } catch (final Exception e) {
                e.printStackTrace();
                BILogger.info("     generateSQLWithTokeniser: Error:  "
                        + e.getMessage());
                System.out
                .println("     generateSQLWithTokeniser: Info: destination file is "
                        + destinationFile.getAbsolutePath());
            }
        }
        if (templateFiles.size() > 0) {
            BILogger.info(warnings.toString());
        }
    }

    public void copyTemplate(final File sourceFile, final File destinationFile,
            final File inProperties, final StringBuffer warnings,
            final boolean verbose,
            final ComponentName inName, final String inTokenMarkerCharacter,
            final String inPrefixed)
    throws Exception {
        BufferedWriter out;
        BufferedReader in = null;
        BILogger.info("     processing file : " + sourceFile.getName());
        // BILogger.info("         using property file "
        // + inProperties.getAbsolutePath() + " exists(" + inProperties.exists()
        // + ")");
        // write to the same directory, the files will be merged later.
        if (destinationFile.exists()) {
            if (!destinationFile.delete()) {
                warnings.append("\n     Info: could not delete "
                        + destinationFile.getAbsolutePath());
            }
        }
        if (!destinationFile.exists()) {
            final boolean created = destinationFile.createNewFile();
            if (!created) {
                BILogger.info("     Could not create "
                        + destinationFile.getAbsolutePath() + ", created="
                        + created);
            }
        }
        final Charset ascii = Charset.forName(characterSet_8859_1);
        final Charset utf = Charset.forName(characterSetUTF_8);
        in = new BufferedReader(new InputStreamReader(new FileInputStream(
                sourceFile), ascii));
        out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(
                destinationFile), utf));
        // Transfer bytes from in to out
        String line;
        final Vector < ReportingProperty > tokens =
            readPropertiesAsUTF8(inProperties);
        // BILogger.info("         number of tokens found is " +
        // tokens.size());
        while ( (line = in.readLine()) != null) {
            if (line.trim().length() > 0) {
                line = tokenReplaceData(line, tokens, inTokenMarkerCharacter,
                        inPrefixed, ".value", true, inName);
                out.write(line);
                out.newLine();
            }
        }
        out.flush();
        out.close();
        BILogger.info("         created "
                + destinationFile.getAbsolutePath());
        in.close();
    }

    /**
     * Utility to copy files to a destination directory appending all files
     * together
     * 
     * @param inFileExplorer - the files names to be concatenated.
     * @param inDestination - the destination file
     * @throws IOException
     */
    public void copyTemplatesToLanguagePacks(final FileExplorer inFileExplorer,
            final String inTokenMarkerCharacter, final String inPrefixed,
            final int inInitialData)
    throws IOException {
        BufferedReader in = null;
        ReportingDataTemplateFile name;
        File sourceFile;
        boolean logged = false;
        List < ReportingFile > inFiles;
        final StringBuffer warnings = new StringBuffer();
        try {
            inFiles = inFileExplorer.getFiles();
        } catch (final Exception e1) {
            throw new IOException(e1.getMessage());
        }
        for (int i = 0; i < inFiles.size(); i++) {
            name = (ReportingDataTemplateFile) inFiles.get(i);
            // if (name.hasCustom()) {
            // sourceFile = new File(name.getCustom().getFileName());
            // } else {
            sourceFile = new File(name.getFileName());
            // }
            final File destination =
                name.getCopyLocation().getTemplateSQLFile();
            final File propertyFile =
                name.getCopyLocation().getPropertiesFile();
            final ComponentName packName =
                name.getCopyLocation().getComponentName();
            if (!logged) {
                BILogger.info("Copying templates for "
                        + packName.getComponentName());
                if (!propertyFile.getParentFile().exists()) {
                    System.out
                    .println("         parent directory does not exist,  "
                            + " not creating templates "
                            + propertyFile.getParentFile()
                            .getAbsolutePath());
                } else {
                    BILogger.info("         using property file "
                            + propertyFile.getAbsolutePath());
                }
                logged = true;
            }
            if (destination.exists()) {
                if (!destination.delete()) {
                    warnings.append("\n         Info: could not delete "
                            + destination.getAbsolutePath());
                }
            }
            // turn off debugging later
            if (true) {
                BILogger.info("     creating "
                        + destination.getAbsolutePath()
                        + ", property file exists(" + propertyFile.exists()
                        + ")");
            }
            if (propertyFile.getParentFile().exists()) {
                final Charset ascii = Charset.forName(characterSet_8859_1);
                in =
                    new BufferedReader(new InputStreamReader(
                            new FileInputStream(
                                    sourceFile), ascii));
                final Charset utf = Charset.forName(characterSetUTF_8);
                final BufferedWriter out =
                    new BufferedWriter(new OutputStreamWriter(
                            new FileOutputStream(destination), utf));
                try {
                    // Transfer bytes from in to out
                    String line;
                    final Vector < ReportingProperty > tokens =
                        new Vector < ReportingProperty >();
                    final ReportingProperty property = new ReportingProperty();
                    property.setName("en");
                    property.setValue(packName.getLanguageAndRegionCode());
                    tokens.add(property);
                    // out.write("--SQL template for " +
                    // packName.getComponentName());
                    out.newLine();
                    while ( (line = in.readLine()) != null) {
                        line = line.trim();
                        if (line.trim().length() > 0) {
                            line =
                                tokenReplaceData(line, tokens,
                                        inTokenMarkerCharacter,
                                        inPrefixed, "", false,
                                        inFileExplorer.getComponentName());
                        }
                        if (line.length() > 0) {
                            out.write(line);
                        }
                        out.newLine();
                    }
                    out.flush();
                    if (name.hasCustom()) {
                        sourceFile = new File(name.getCustom().getFileName());
                        in = new BufferedReader(new FileReader(sourceFile));
                        // Transfer bytes from in to out
                        while ( (line = in.readLine()) != null) {
                            line = line.trim();
                            if (line.length() > 0) {
                                out.write(line);
                            }
                            out.newLine();
                        }
                        out.flush();
                    }
                    out.flush();
                    in.close();
                } catch (final FileNotFoundException e) {
                    if (name.isCustom()) {
                        BILogger.info("info, no custom file " + name);
                    } else {
                        BILogger.info("warning, no file found " + name);
                    }
                } finally {
                    if (out != null) {
                        out.close();
                    }
                }
            }
        }
        if (inFiles.size() > 0) {
            BILogger.info(warnings.toString());
        }
    }

    public void copyInfoSpherefileLayered(final File sourceFile,
            final File destinationFile,
            final Boolean inPoliceOnly, final ComponentName inTargetName)
    throws Exception {
        BILogger.info("copying " + sourceFile.getName() + " to component "
                + inTargetName.getComponentName());
        BufferedWriter out;
        BufferedReader in = null;
        final boolean fileExists = destinationFile.exists();
        if (!fileExists) {
            final File dir = destinationFile.getParentFile();
            if (!dir.exists()) {
                final boolean dirCreated = dir.mkdirs();
                if (dirCreated == false) {
                    BILogger.error("Could not create dir "
                            + dir.getAbsolutePath());
                }
            }
            final boolean created = destinationFile.createNewFile();
            if (!created) {
                BILogger.error("Could not create file "
                        + destinationFile.getAbsolutePath());
            }
            final Charset ascii = Charset.forName(characterSet_8859_1);
            final Charset utf = Charset.forName(characterSetUTF_8);
            in = new BufferedReader(new InputStreamReader(new FileInputStream(
                    sourceFile), ascii));
            out =
                new BufferedWriter(new OutputStreamWriter(
                        new FileOutputStream(
                                destinationFile, false), utf));
            // Transfer bytes from in to out
            String line;
            while ( (line = in.readLine()) != null) {
                if (line.trim().length() > 0) {
                    out.write(line);
                    out.newLine();
                }
            }
            out.flush();
            out.close();
            in.close();
        } else {
            BILogger.error("not copying " + destinationFile.getName()
                    + " use clean down task first.");
        }
    }

    public void copyInfoSpherefile(final File sourceFile,
            final File destinationFile,
            final Boolean inPoliceOnly) throws Exception {
        BILogger.debug("\n source file " + sourceFile.getAbsolutePath()
                + ",policing=" + inPoliceOnly);
        BILogger.debug("\n destination file "
                + destinationFile.getAbsolutePath());
        BufferedWriter out;
        BufferedReader in = null;
        if (inPoliceOnly == true) {
            if (destinationFile.exists()) {
                BILogger
                .error("Infosphere name collision error, destination file name "
                        + destinationFile.getName());
            }
            return;
        }
        if (!destinationFile.exists()) {
            final File dir = destinationFile.getParentFile();
            if (!dir.exists()) {
                final boolean dirCreated = dir.mkdirs();
                if (dirCreated == false) {
                    BILogger.error("Could not create dir "
                            + dir.getAbsolutePath());
                }
            }
            final boolean created = destinationFile.createNewFile();
            if (!created) {
                BILogger.error("Could not create file "
                        + destinationFile.getAbsolutePath());
            }
        }
        if (destinationFile.exists()) {
            final Charset ascii = Charset.forName(characterSet_8859_1);
            final Charset utf = Charset.forName(characterSetUTF_8);
            in = new BufferedReader(new InputStreamReader(new FileInputStream(
                    sourceFile), ascii));
            out =
                new BufferedWriter(new OutputStreamWriter(
                        new FileOutputStream(
                                destinationFile, false), utf));
            // Transfer bytes from in to out
            String line;
            while ( (line = in.readLine()) != null) {
                if (line.trim().length() > 0) {
                    out.write(line);
                    out.newLine();
                }
            }
            out.flush();
            out.close();
            in.close();
            BILogger.debug("copied " + destinationFile.getAbsolutePath());
        } else {
            BILogger.error("Infosphere name collision error, not copying file to "
                    + destinationFile.getName());
        }
    }

    public void cleanInfoSpherefile(final File sourceFile,
            final File destinationFile)
    throws Exception {
        if (!destinationFile.exists()) {
            BILogger.debug(" layered file does not exist, "
                    + destinationFile.getAbsolutePath());
        } else if (destinationFile.exists()) {
            final File deleted =
                new File(destinationFile.getAbsoluteFile() + ".deleted");
            deleted.delete();
            destinationFile.renameTo(deleted);
            BILogger.info("deleting " + destinationFile.getAbsolutePath());
        }
    }

    public void cleanLayeredInfoSpherefile(final File inSourceFile,
            final File inDestinationFile,
            final ComponentName inTargetComponent)
    throws Exception {
        if (!inDestinationFile.exists()) {
            BILogger.debug(" nothing to do, layered file does not exist, "
                    + inDestinationFile.getName());
        } else if (inDestinationFile.exists()) {
            final boolean layeredFile =
                inDestinationFile.getName().toLowerCase()
                .contains(
                        inTargetComponent.getComponentName()
                        .toLowerCase());
            if (!layeredFile) {
                final File deleted =
                    new File(inDestinationFile.getAbsoluteFile()
                            + ".deleted");
                deleted.delete();
                inDestinationFile.renameTo(deleted);
                BILogger.info("deleting " + inDestinationFile.getName());
            } else {
                BILogger.info("not deleting as artifact is not from lower offset "
                        + inDestinationFile.getName());
            }
        }
    }
}
