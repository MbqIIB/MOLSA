/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005-2011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.FilenameFilter;
import java.util.List;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.type.*;

/**
 * The abstract class for all file searches for the build environment.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public abstract class FileExplorer {
  private final ComponentName componentName;

  private final String reportingDir;

  private final TargetDataBaseType targetDataBaseType;

  protected final String kTemplateComponentDirectoryName = "<componentDirName>";

  protected final String kTemplateTargetDB = "<targetDB>";

  // if the file name contains the string then its platform dependent
  protected final String kOracleFile = "oracle";

  protected final String kDB2File = "db2";

  private FilenameFilter fileFilter = null;

  public void setFileFilter(FilenameFilter fileFilter) {
    this.fileFilter = fileFilter;
  }

  /**
   * returns the pre configured file filter
   * 
   * @return
   */
  public FilenameFilter getFileFilter() {
    return fileFilter;
  }

  /**
   * returns a user defined configured file filter
   * 
   * @return
   */
  public FilenameFilter getFileFilter(final String inSourceFileFilter,
      final boolean inExact) {
    return fileFilter;
  }

  public abstract List<ReportingFile> getFiles() throws Exception;

  public FileExplorer(
      ComponentName componentOrder,
      TargetDataBaseType targetDataBaseType,
      final String inReportingDir) {
    super();
    this.componentName = componentOrder;
    this.targetDataBaseType = targetDataBaseType;
    reportingDir = inReportingDir;
  }

  /**
   * @return the componentOrder
   */
  public ComponentName getComponentName() {
    return componentName;
  }

  /**
   * Creates a reporting file reference
   * 
   * @param inFile
   * @param isCustom
   * 
   * @return the ReportingFile
   */
  public ReportingFile createFile(String inFile, boolean isCustom) {
    return new ReportingFile(inFile, isCustom);
  }

  /**
   * @return the targetDataBaseType
   */
  public TargetDataBaseType getTargetDataBaseType() {
    return targetDataBaseType;
  }

  /**
   * @return the reportingDir
   */
  public String getReportingDir() {
    return reportingDir;
  }
}
