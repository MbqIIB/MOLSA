/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * 
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.reporting.internal.tasks.model.ReportingStaticDataFile;

import curam.util.type.*;

/**
 * Returns a list of files to be processed by the BI build environment.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class FileExplorerTestResults extends FileExplorer {
    /**
     * generic path structure for DDL files
     */
    String relativeJavaSourcePath;

    /**
     * Object used to return the set of file that make up the DDL for a schema for
     * a component
     * 
     * @param inComponentName
     * @param targetDataBaseType
     * @param inReportingDir
     * @param inTestDirectory
     */
    public FileExplorerTestResults(
            final ComponentName inComponentName,
            final TargetDataBaseType targetDataBaseType,
            final String inReportingDir,
            final String inTestDirectory) {
        super(inComponentName, targetDataBaseType, inReportingDir);
        /*
         * set up the template for static data files. the items in <> will be
         * replaced at runtime e.g. <Reporting>\components\<core>\data_manager\
         */
        relativeJavaSourcePath = inTestDirectory;
    }

    @Override
    public List<ReportingFile> getFiles() throws Exception {
        final File componentPath = new File(relativeJavaSourcePath);
        final List<ReportingFile> testResultFiles = new ArrayList<ReportingFile>();
        if (!componentPath.exists()) {
            BILogger.info("Info:" + relativeJavaSourcePath
                    + " path does not exist");
        }
        final List<File> componentPaths = new ArrayList<File>();
        componentPaths.add(componentPath);
        BILogger.info("processing file=" + componentPath.getAbsolutePath());
        final FilenameFilter filter = new TestResultsFileFilter();
        // componentPaths.add(customComponentPath);
        for (int j = 0; j < componentPaths.size(); j++) {
            final File files[] = ((File) componentPaths.get(j)).listFiles(filter);
            BILogger.info("processing filter=" + files.length);
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    if (files[i].isFile()) {
                        testResultFiles.add(new ReportingStaticDataFile(files[i]
                                                                              .getCanonicalPath(), false));
                    }
                }
            }
        }
        return testResultFiles;
    }

    static class TestResultsFileFilter implements FilenameFilter {
        public boolean accept(final File dir, final String name) {
            // get the last seven characters of the string.
            final int suffixLength = 3;
            final int start = name.length() - suffixLength > 0 ? name.length()
                    - suffixLength : 0;
            final String suffix = name.substring(start, name.length());
            // return true if this is an ETL tag file
            if (suffix.equalsIgnoreCase("xml")) {
                return true;
            } else {
                return false;
            }
        }
    }
}
