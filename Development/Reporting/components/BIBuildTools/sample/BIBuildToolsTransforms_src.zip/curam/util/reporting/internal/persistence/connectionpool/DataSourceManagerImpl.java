/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 1999-2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.persistence.connectionpool;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;

import curam.util.reporting.internal.config.ConnectionProperties;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.PropertiesCache;
import curam.util.reporting.internal.config.PropertyReaderFactory;
import curam.util.reporting.internal.config.TargetDataBaseType;

import curam.util.type.*;

/**
 * This module persistence class for both the build environment and
 * transformations.
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class DataSourceManagerImpl implements DataSourceManager {

    /**
     * the set of connection pools to manage
     */
    private final Map<String, ConnectionPool> connectionPools;

    /**
     * the data source manager
     */
    static private DataSourceManagerImpl singleton = null;

    // static private Log log = LogFactory
    // .getLog("curam.util.datawarehouse.persistence.connectionpool");;

    // ___________________________________________________________________________
    /**
     * Returns the data source manager.
     * 
     * @return DataSourceManagerImpl
     * @throws SQLException
     */

    static public synchronized DataSourceManagerImpl getInstance()
    throws SQLException {

        if (singleton == null) {
            singleton = new DataSourceManagerImpl();
        }
        return singleton;
    }

    // ___________________________________________________________________________
    /**
     * Creates a data source manager
     */
    protected DataSourceManagerImpl() throws SQLException {
        connectionPools = new Hashtable<String, ConnectionPool>();
        initialize();
    }

    // ___________________________________________________________________________
    /**
     * Creates the connection pool and checks connections can be created.
     */
    private void initialize() throws SQLException {

        PropertiesCache reader = null;

        try {
            DataWarehouseConstants.getBaseDirectory();
            // try to read connection properties file residing on the class path
            // test these connections to ensure they are valid
            try {
                reader = PropertyReaderFactory.getConnectionPropertyReader();
            } catch (final FileNotFoundException e) {
                System.out
                .print("  DBConnectionManager"
                        + ":Warning, property file not found on classpath, trying reporting directory...");

                final String fileName = DataWarehouseConstants.getBaseDirectory()
                + DataWarehouseConstants.kPropertyFile;

                reader = PropertyReaderFactory.getConnectionPropertyReader(fileName);

            }
            final ConnectionProperties[] connectionPoolProperties = reader
            .getConnectionProperties();
            Driver driver;
            String driverName;
            ConnectionPool pool;
            Connection connection;
            @SuppressWarnings("unused")
            final
            TargetDataBaseType targetDB = reader.getTargetEnvironment();
            driverName = reader.getValue(DataWarehouseConstants.kJavaJDBCProp);
            // if driver name is specified register the driver,
            // otherwise
            // the jdbc.drivers property has been used to register
            // drivers
            if (driverName.length() > 0) {
                try {
                    driver = (Driver) Class.forName(driverName).newInstance();
                    DriverManager.registerDriver(driver);
                } catch (final Exception e) {
                    e.printStackTrace();
                }
            }

            for (int i = 0; i < connectionPoolProperties.length; i++) {

                try {
                    if (connectionPoolProperties[i].getTargetDataBaseType().isORACLE()) {
                        ;
                    } else {
                        ;
                    }

                    driverName = connectionPoolProperties[i].getDriverName();

                    pool = new ConnectionPoolImpl(connectionPoolProperties[i]);

                    connectionPools.put(connectionPoolProperties[i].getPoolName(), pool);

                    // ensure the pool can connect to the data store
                    connection = getConnection(connectionPoolProperties[i].getPoolName());
                    returnConnection(connectionPoolProperties[i].getPoolName(),
                            connection);

                    // each pool will contain zero connections as it may not be
                    // used
                    pool.releaseResources();

                } catch (final SQLException e) {

                    connectionPools.remove(connectionPoolProperties[i].getPoolName());
                }
            }
        } catch (final FileNotFoundException e) {
            System.out
            .println("DBConnectionManager"
                    + "Error reading properties, add property file directory to classpath. ");
        } catch (final Exception e) {
            System.out
            .println("DBConnectionManager"
                    + "Error reading properties, add property file directory to classpath. "
                    + e.getMessage());
        }

        // define the connection properties for connections
        // obtained when running JAVA code within the RDBMS's JVM
        // the null value of target database will be overridden when
        // a new connection is initiated (target db can only be gotten when
        // connected to the DB)
        final ConnectionProperties defaultConnectionProperties = new ConnectionProperties(
                DataWarehouseConstants.kDefaultDatabase, "jdbc:default:connection", "",
                "", "", null, 1);

        // create a pool for default connections
        final ConnectionPool pool = new DefaultConnectionsImpl(
                defaultConnectionProperties);

        // place the pool into the list of available pools for data sources
        connectionPools.put(defaultConnectionProperties.getPoolName(), pool);

    }

    // ___________________________________________________________________________
    /**
     * Returns a read only connection
     * 
     * @param inDataSourceName
     *          the data store to establish a connection with
     * 
     * @return Connection the connection
     * @throws SQLException
     */
    public Connection getReadOnlyConnection(final String inDataSourceName)
    throws SQLException {

        final ConnectionPool pool = (ConnectionPool) connectionPools
        .get(inDataSourceName);

        if (pool != null) {
            return pool.getReadOnlyConnection(inDataSourceName);
        }
        throw new SQLException("DBConnectionManager:invalid pool name "
                + inDataSourceName);

    }

    // ___________________________________________________________________________
    /**
     * Returns a database connection
     * 
     * @param inDataStoreName
     *          the data source to connect to
     * @return Connection the connection
     * 
     */
    public Connection getConnection(final String inDataStoreName) throws SQLException {
        final ConnectionPool pool = (ConnectionPool) connectionPools.get(inDataStoreName);

        if (pool != null) {
            return pool.getConnection();
        }
        throw new SQLException("DBConnectionManager:invalid pool name "
                + inDataStoreName);
    }

    // ___________________________________________________________________________
    /**
     * Returns a database connection
     * 
     * @param inDataStoreName
     *          the data source to connect to
     * @param inTimeOut
     *          the time to wait before failing
     * 
     */
    public Connection getConnection(final String inDataStoreName, final long inTimeOut)
    throws SQLException {
        final ConnectionPool pool = (ConnectionPool) connectionPools.get(inDataStoreName);

        if (pool != null) {
            return pool.getConnection(inTimeOut);
        }
        throw new SQLException("DBConnectionManager:invalid pool name "
                + inDataStoreName);
    }

    // ___________________________________________________________________________
    /**
     * Returns a database connection to the pool
     * 
     * @param inDataStoreName
     *          the data source to connect to
     * @param inConnection
     *          the connection
     * 
     */
    public void returnConnection(final String inDataStoreName, final Connection inConnection) {

        final ConnectionPool pool = (ConnectionPool) connectionPools.get(inDataStoreName);

        if (pool != null && inConnection != null) {
            pool.returnConnection(inConnection);
        }

    }

    // ___________________________________________________________________________
    /**
     * Releases any resource held
     */
    public void releaseResources() {

        Iterator<String> iterator = connectionPools.keySet().iterator();
        ConnectionPool connectionPool;
        String key;

        while (iterator.hasNext()) {
            key = (String) iterator.next();
            connectionPool = (ConnectionPool) connectionPools.get(key);
            connectionPool.releaseResources();
            iterator.remove();
        }
        iterator = null;
        singleton = null;
    }

    /**
     * Returns true if this data source is configured
     * 
     * @param inDataSourceName
     *          the data source to connect to
     * @return boolean true if the logical data source name is supported
     * 
     */

    public boolean supportedDataSource(final String inDataSourceName) {
        return connectionPools.containsKey(inDataSourceName);
    }

    /**
     * Returns the connectionProperties.
     * 
     * @param inDataSource
     * 
     * @return ConnectionProperties
     * @throws SQLException
     */
    public ConnectionProperties getConnectionProperties(final String inDataSource)
    throws SQLException {
        final ConnectionPool pool = (ConnectionPool) connectionPools.get(inDataSource);

        if (pool != null) {
            return pool.getConnectionProperties();
        }

        throw new SQLException("DBConnectionManager:invalid data source name "
                + inDataSource);
    }

}
