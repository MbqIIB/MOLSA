/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.util.Vector;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.tasks.model.ReportingProperty;
import curam.util.type.*;

/**
 * 
 * This class copies InfoSphere source artifacts to a higher offset.
 * 
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntInfoSphereLayeredVersion extends Task {
  /**
   * the root reporting directory
   */
  private String reportingDir;

  /**
   * the higher offset
   */
  private String targetComponentName;

  /**
   * check for name collisions only
   */
  private Boolean clean = false;

  // ___________________________________________________________________________
  /**
   * Sets the higher offset name
   * 
   * @param inTargetComponentName
   *          the directory name
   */
  public void setTargetComponentName(final String inTargetComponentName) {
    targetComponentName = inTargetComponentName;
  }

  // ___________________________________________________________________________
  /**
   * Checks for name collisions
   * 
   * @param inPolice
   *          the path to the sample files
   */
  public void setCleanOnly(final String inClean) {
    clean = Boolean.valueOf(inClean);
  }

  // ___________________________________________________________________________
  /**
   * Throws a build exception if OMBplus reported errors for a command
   * 
   * @throws BuildException
   * 
   */
  @Override
  public void execute() throws BuildException {
    try {
      Project antProject = getProject();
      String calledFrom = "";
      if (antProject != null) {
        // if we get a valid ant project object then getBaseDir will
        // return
        // the calling directory, e.g. "components", "core" etc
        // if we are in the "components" directory then build for
        // everything installed on disk.
        // otherwise build for the specific component only
        calledFrom = antProject.getBaseDir().getName();
      } else {
        System.out
            .println("Error:Can't get the ant project:Project ant = getProject");
      }
      ReportingFileManager fileManager = new ReportingFileManager(calledFrom,
          reportingDir);
      fileManager.mergeInfoSphereArtifactsLayered(fileset, targetComponentName,
          clean);
    } catch (BuildException e) {
      throw new BuildException(e.getMessage());
    } catch (Exception e) {
      throw new BuildException(e.getMessage());
    }
  }

  /**
   * filters
   */
  private final Vector<ReportingProperty> fileset =
      new Vector<ReportingProperty>();

  // ___________________________________________________________________________
  /**
   * Adds an error to the list of errors to ignore for.
   * 
   * @return ReportingProperty the error name and error text to ignore.
   * 
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public ReportingProperty createDirectory() {
    ReportingProperty property = new ReportingProperty();
    fileset.add(property);
    return property;
  }

  // ___________________________________________________________________________
  /**
   * Sets the base reporting directory
   * 
   * @param inReportingDir
   *          base reporting directory
   */
  public void setReportingDir(String inReportingDir) {
    reportingDir = inReportingDir;
  }
}
