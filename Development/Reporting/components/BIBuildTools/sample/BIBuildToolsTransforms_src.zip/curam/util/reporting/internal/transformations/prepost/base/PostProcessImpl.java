/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.transformations.prepost.base;

import java.sql.SQLException;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.dao.control.fact.ControlTableFactory;
import curam.util.reporting.internal.dao.control.intf.ControlTable;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPostProcess;
import curam.util.type.*;

/**
 * This module turns a new object to execute ETL post processing
 * 
 * @since Curam 5.2 SP1
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public abstract class PostProcessImpl implements ETLPostProcess {

    // __________________________________________________________________________
    /**
     * Executes tasks required to complete an ETL.
     * 
     * @param inTargetTableName
     *          the target table being populated
     * @throws SQLException
     *           if a database operation fails
     */
    public void executePostProcess(final String inTargetTableName)
    throws SQLException {
        ControlTable controlTable = null;
        boolean failed = false;
        // the database transaction
        Transaction transaction = null;

        try {
            // start a transaction
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            controlTable = ControlTableFactory.newInstance(new ReportingDBType(
                    inTargetTableName));
            // set the extract start time
            controlTable.updateLastETLDate(inTargetTableName);

        } catch (final Exception e) {
            failed = true;
            throw new SQLException("PostProcessImpl:" + e.getMessage());
        } finally {

            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                } else {
                    // commit the changes
                    transaction.commit();
                }
            }
        }
    }

}
