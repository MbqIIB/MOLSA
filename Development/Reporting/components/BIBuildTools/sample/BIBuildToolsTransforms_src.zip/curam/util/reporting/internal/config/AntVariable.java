/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.config;

/**
 * This class is used to store properties defined within Ant scripts.
 *
 *
 */
public class AntVariable extends EnvironmentVariable {

  /**
   * Creates a property name and value pair
   *
   * @param inAntProperty
   *          the property name
   * @param inValue
   *          the property value
   */
  public AntVariable(String inAntProperty, String inValue) {
    super(inAntProperty, inValue);

  }

}
