/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.reporting.internal.security.EncryptionUtil;

/**
 * 
 * Encryption ant task to allow for programmatic encryption of a user password.
 * This is the password used for Curam authentication.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntEncrypt extends Task {
  /**
   * to encrypt
   */
  private String password = "notencrypted";

  /**
   * the plain text value
   */
  private String propertyName = "decrypted.db.password";

  /**
   * is the flag set
   */
  private boolean decrypt = false;

  // ___________________________________________________________________________
  /**
   * Encrypts the passwords,print the result to standard output, and sets the
   * named property to the encrypted values..
   */
  @Override
  public void execute() throws BuildException {
    String clearPassword = password;
    if (decrypt) {
      try {
        clearPassword = EncryptionUtil.decryptDBPasswordDefaulted(password);
      } catch (Exception e) {
        BILogger
            .error("Password error, password not encrypted correctly, could not decrypt");
      }
      Project antProject = getProject();
      antProject.setProperty(propertyName, clearPassword);
    } else {
      try {
        password = EncryptionUtil.encryptDBPassword(password);
        System.out.println("encrypted password is " + password);
      } catch (Exception e) {
        BILogger.error("Password error, could not encrypt");
      }
    }
  }

  /**
   * Tests method call.
   * 
   * @throws Exception
   *           - cannot connect to database
   */
  private String getPhrase(String inPhrase) {
    String result = "na";
    java.lang.reflect.Method method;
    try {
      Class encryptionUtil = Class
          .forName("curam.util.reporting.internal.security.EncryptionUtil");
      method = encryptionUtil.getMethod("decryptDBPasswordDefaulted",
          String.class);
      String temp = (String) method.invoke(encryptionUtil, inPhrase);
      result = temp;
    } catch (IllegalArgumentException e) {
      e.printStackTrace();
    } catch (IllegalAccessException e) {
      e.printStackTrace();
    } catch (ClassNotFoundException e) {
      e.printStackTrace();
    } catch (NoSuchMethodException e) {
      e.printStackTrace();
    } catch (java.lang.reflect.InvocationTargetException e) {
      e.printStackTrace();
    }
    return result;
  }

  // ___________________________________________________________________________
  /**
   * The property to write the encrypted password to.
   * 
   * @param inPropertyName
   *          property to write the encrypted password to.
   */
  public void setTo(String inPropertyName) {
    if (inPropertyName != null && inPropertyName.length() > 0) {
      decrypt = true;
      propertyName = inPropertyName;
    }
  }

  // ___________________________________________________________________________
  /**
   * Sets the text to encrypt
   * 
   * @param inPassword
   *          the clear text password to encrypt
   */
  public void setPassword(String inPassword) {
    if (inPassword != null && inPassword.length() > 0)
      password = inPassword;
  }
}
