/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 1999-2005 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.persistence.connectionpool;

import java.sql.Connection;
import java.sql.SQLException;

import curam.util.type.*;

/**
 * This module persistence class for both the build environment and
 * transformations.
 */
@AccessLevel(AccessLevelType.INTERNAL)
public interface DataSourceManager {

  // ___________________________________________________________________________
  /**
   * Returns a database connection
   *
   * @param inDataStoreName
   *          the data source to connect to
   * @return Connection the connection
   * @throws SQLException
   *
   */
  public Connection getConnection(String inDataStoreName) throws SQLException;

  // ___________________________________________________________________________
  /**
   * Returns a database connection
   *
   * @param inDataStoreName
   *          the data source to connect to
   * @param inTimeOut
   * @return Connection
   * @throws SQLException
   *
   *
   */
  public Connection getConnection(String inDataStoreName, long inTimeOut)
      throws SQLException;

  // ___________________________________________________________________________
  /**
   * Returns true if this data source is configured
   *
   * @param inDataSourceName
   *          the data source to connect to
   * @return boolean true if the data source logical name if supported
   *
   */
  public boolean supportedDataSource(String inDataSourceName);

  // ___________________________________________________________________________
  /**
   * Returns a database connection to the pool
   *
   * @param inDataStoreName
   * @param inConnection
   *
   *
   */
  public void returnConnection(String inDataStoreName, Connection inConnection);

  // ___________________________________________________________________________
  /**
   * Releases any resource held
   */
  public void releaseResources();
}
