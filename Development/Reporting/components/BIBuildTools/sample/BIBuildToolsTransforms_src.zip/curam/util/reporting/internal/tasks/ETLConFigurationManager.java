/*
 * Copyright 2010 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ETLConFigurationManager extends Task {
  private String outFile = null;

  private String startDir = null;

  private static String startsWith = "Reporting";

  private static String startTag = "entity";

  @Override
  public void execute() throws BuildException {
    validateParams();
    // List<File> files = getAllFiles(new File(startDir));
    // createFile(new File(outFile), files);
  }

  public void readETLConfiguration(File inPath) {
    BILogger.info("Starting Combine visio entities tool");
  }

  public void reWriteETLConfiguration(File inOldFileFormat) {
    BILogger.info("Starting Combine visio entities tool");
  }

  private void createFile(final File outputFile, final List<File> files) {
    try {
      DocumentBuilder builder = DocumentBuilderFactory.newInstance()
          .newDocumentBuilder();
      Document doc = builder.newDocument();
      Element root = doc.createElement("root");
      doc.appendChild(root);
      Element entities = doc.createElement("entities");
      root.appendChild(entities);
      for (Iterator<File> iter = files.iterator(); iter.hasNext();) {
        File tablesFile = iter.next();
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbFactory.newDocumentBuilder();
        Document entitiesDoc = db.parse(tablesFile);
        // Get the root element
        Element otherRoot = entitiesDoc.getDocumentElement();
        // Get the codetable element
        NodeList list = otherRoot.getElementsByTagName(startTag);
        for (int i = 0; i < list.getLength(); i++) {
          Element newTable = (Element) list.item(i);
          // Make a copy of the original node
          Node node_copy = doc.importNode(newTable, true);
          // Add the node copy to the final document
          entities.appendChild(node_copy);
        }
        BILogger.info(" merging  " + tablesFile);
      }
      // Prepare the DOM document for writing
      javax.xml.transform.Source source =
          new javax.xml.transform.dom.DOMSource(
              doc);
      // Prepare the output file
      javax.xml.transform.Result result =
          new javax.xml.transform.stream.StreamResult(
              outputFile);
      // Write the DOM document to the file
      javax.xml.transform.Transformer xformer =
          javax.xml.transform.TransformerFactory
              .newInstance().newTransformer();
      xformer.setOutputProperty(javax.xml.transform.OutputKeys.METHOD, "xml");
      xformer.setOutputProperty(
          javax.xml.transform.OutputKeys.OMIT_XML_DECLARATION, "no");
      xformer.setOutputProperty(javax.xml.transform.OutputKeys.VERSION, "1.0");
      xformer.setOutputProperty(javax.xml.transform.OutputKeys.ENCODING,
          "UTF-8");
      xformer.setOutputProperty(javax.xml.transform.OutputKeys.INDENT, "yes");
      xformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount",
          "2");
      xformer.transform(source, result);
      BILogger.info(" output parameter, setOutFile " + outputFile);
    } catch (IOException e) {
      e.printStackTrace();
    } catch (SAXException e) {
      e.printStackTrace();
    } catch (javax.xml.transform.TransformerConfigurationException e) {
      e.printStackTrace();
    } catch (ParserConfigurationException e) {
      e.printStackTrace();
    } catch (javax.xml.transform.TransformerException e) {
      e.printStackTrace();
    }
  }

  private void validateParams() {
    if (outFile == null || startDir == null) {
      getProject().log("All properties are required", Project.MSG_ERR);
    }
  }

  /**
   * @param string
   */
  public void setStartDir(final String string) {
    startDir = string;
  }

  /**
   * @param string
   */
  public void setOutFile(final String string) {
    outFile = string;
  }

  /**
   * @param string
   */
  public void setStartsWith(final String string) {
    startsWith = string;
  }

  /**
   * @param string
   */
  public void setStartTag(final String string) {
    startTag = string;
  }
}
