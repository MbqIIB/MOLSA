/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

/**
 * This module checks an error file for OMBplus error messages throwing a build
 * exception if an error is found.
 * 
 * @deprecated
 * @since 5.2 SP4
 */
@Deprecated
public class AntDB2ValidateMetadata extends Task {
    /**
     * the user identity for the DB2 meta data design repository.
     */
    private boolean isDB2;

    /**
     * the user identity for the DB2 meta data design repository.
     */
    private String userid = "";

    /**
     * the password for the DB2 meta data design repository.
     */
    private String password = "";

    /**
     * the directory where ETL meta-data files reside.
     */
    private String directory = "";

    /**
     * the XTServer port number.
     */
    private final short kServerPort = 11004;

    /**
     * the directory where log files are written.
     */
    private String logDirectory = "";

    /**
     * promotes an ETL from development to test, causes meta data to be validated.
     */
    static final private short kPromoteDevToTest = 2;

    /**
     * demotes and ETL from test to development.
     */
    // static final private short kDomoteTestToDev = 5;
    /**
     * the output log file for the XTClient application.
     */
    private FileWriter log = null;

    /**
     * Flushes any data to server.
     */
    static final private String kStopCommand = "STOPCOMMAND";

    /**
     * either 390 or UDB.
     */
    private String dbSourceType = "";

    // __________________________________________________________________________
    /**
     * Sets the meta data directory location.
     * 
     * @param inDirectory
     *          the meta-data directory path
     */
    public void setDirectory(final String inDirectory) {
        if (inDirectory != null) {
            directory = inDirectory;
        }
    }

    // __________________________________________________________________________
    /**
     * Sets the log directory location.
     * 
     * @param inDirectory
     *          the log directory path
     */
    public void setLogDirectory(final String inDirectory) {
        if (inDirectory != null) {
            logDirectory = inDirectory;
        }
    }

    // __________________________________________________________________________
    /**
     * Sets the repository user identity.
     * 
     * @param inUserid
     *          the repository user identity
     */
    public void setUserid(final String inUserid) {
        if (inUserid != null) {
            userid = inUserid;
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the repository user identity.
     * 
     * @param inPassword
     *          the repository user identity
     */
    public void setPassword(final String inPassword) {
        if (inPassword != null) {
            password = inPassword;
        }
    }

    // __________________________________________________________________________
    /**
     * Exists if the condition is false.
     * 
     * @param isDB2
     *          the repository user identity
     */
    public void setIf(final boolean isDB2) {
        this.isDB2 = isDB2;
    }

    // ___________________________________________________________________________
    /**
     * Sets the source database type.
     * 
     * @param inSourceType
     *          the meta-data directory path
     */
    public void setDbSourceType(final String inSourceType) {
        if (inSourceType != null) {
            dbSourceType = inSourceType;
        }
    }

    // __________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command.
     * 
     * @throws BuildException
     *           if validation fails
     */
    @Override
    public void execute() throws BuildException {
        if (!isDB2) {
            return;
        }
        // the server thread
        Thread thread = null;
        // has the user identity been set
        if (dbSourceType == null || dbSourceType.length() == 0) {
            throw new BuildException("Missing <dbSourceType> property");
        }
        // the directory when ETL meta data files reside
        directory = AntDB2MetaData.getDB2Directory(directory, dbSourceType);
        final File dir = new File(directory);
        BILogger.info("Validating ETL's in directory " + directory);
        // the directory when ETL meta data files reside
        final File logDir = new File(logDirectory);
        // the object which validates the ETL meta data
        final MetaDataClient metaDataClient = new MetaDataClient();
        // the object to start the XTServer
        MetaDataServer server = null;
        File[] results = null;
        // validate the source ETL directory
        if (!dir.exists() || !dir.isDirectory()) {
            throw new BuildException("Meta data directory does not exist <"
                    + directory + ">");
        }
        // validate the source ETL directory
        if (!logDir.exists() || !logDir.isDirectory()) {
            throw new BuildException("Log directory does not exist <" + logDirectory
                    + ">");
        }
        // has the user identity been set
        if (userid.length() == 0) {
            throw new BuildException("Invalid repository user identity <" + userid
                    + ">");
        }
        // has the password been set
        if (password.length() == 0) {
            throw new BuildException("Invalid repository password");
        }
        try {
            // get the set of ETL files to be validated
            results = dir.listFiles(new ETLFileFilter());
            BILogger.info(results.length + " files to be validated");
            if (results.length > 0) {
                // start the XTServer
                server = new MetaDataServer(Thread.currentThread());
                thread = new Thread(server);
                thread.start();
                // date format used in log file name
                final String format = "ddmmyyyymmss";
                final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
                final String now = simpleDateFormat.format(new Date());
                // create the log file for client messages
                log = new FileWriter(logDirectory + File.separator + "XTClient" + now
                        + ".log");
                try {
                    // sleep for 6 seconds to allow the server to start, on
                    // server start we will be notified,
                    // in reality we will only sleep for 1 or 2 seconds
                    Thread.sleep(6000);
                    throw new BuildException("Server failed to start");
                } catch (final InterruptedException e) {
                    log.write("Received Server started notification"
                            + System.getProperty("line.separator"));
                }
                // the meta-data file to validate
                String fileName;
                // the ETL process name
                String etlName;
                // the length of the file suffix, i.e. length of ".tag"
                final short kFileSuffix = 4;
                for (int i = 0; i < results.length; i++) {
                    // get the file name
                    fileName = results[i].getName();
                    // truncate the file extension to get the ETL process name
                    etlName = fileName.substring(0, fileName.length() - kFileSuffix);
                    // write output to ant
                    BILogger.info("Validating <" + etlName + ">");
                    // write output to log file
                    log.write("Validating <" + etlName + ">"
                            + System.getProperty("line.separator"));
                    // validate the ETL, promote the ETL process to test
                    metaDataClient.run(etlName);
                    BILogger.info("Validated <" + etlName + ">");
                    log.write("Validated <" + etlName + ">"
                            + System.getProperty("line.separator"));
                }
                log.write("No more ETL metadata files");
            }
        } catch (final IOException e) {
            try {
                log.write(e.toString());
            } catch (final IOException ioe) {
                // ignore as there is nothing we can do here
                BILogger.info("Client:" + ioe);
            }
        } finally {
            // if there was ETL processes to validate clean up
            if (results != null && results.length > 0) {
                try {
                    server.stopServer();
                    log.write("Client: issued stopServer() command"
                            + System.getProperty("line.separator"));
                    BILogger.info("Client: issued stopServer() command "
                            + System.getProperty("line.separator"));
                    if (server.startedSuccessfully()) {
                        BILogger.info("Client: metadata validation succeeded"
                                + System.getProperty("line.separator"));
                        log.write("Client: metadata validation succeeded"
                                + System.getProperty("line.separator"));
                    }
                    // if the server has blocked waiting for more client input
                    // run a dummy client request to flush data from the server
                    if (!server.isStopped()) {
                        // once the last client has been processed
                        // the server may block and wait indefinitely
                        // change this code to use wait/notify pattern to avoid
                        // this
                        metaDataClient.run(kStopCommand);
                    }
                    // close the log file
                    if (log != null) {
                        log.flush();
                        log.close();
                    }
                } catch (final IOException e) {
                    // ignore as there is nothing we can do here
                    BILogger.info("Client:" + e);
                }
            }
        }
    }

    /**
     * Runs the DB2 XTClient application, this application promotes an ETL process
     * from development to test causing the meta-data to be validated.
     */
    class MetaDataClient {
        public void run(final String inETLName) {
            // run the XTClient to ask the server to promote the task to test
            // promoting an ETL to test causes the meta-data to be validated
            final Runtime runtime = Runtime.getRuntime();
            Process p = null;
            // command to start the client DB2 application
            final String[] args = new String[] { "java", "db2_vw_xt.XTClient", "localhost",
                    new Short(kServerPort).toString(), userid, password, inETLName,
                    new Short(kPromoteDevToTest).toString(), "0" };
            try {
                // start the client
                p = runtime.exec(args);
                // read the output from the client
                final InputStream inputstream = p.getInputStream();
                final InputStreamReader inputstreamreader =
                    new InputStreamReader(inputstream);
                final BufferedReader bufferedreader = new BufferedReader(inputstreamreader);
                // display the server output
                String line;
                log.write("Client:client started"
                        + System.getProperty("line.separator"));
                while ((line = bufferedreader.readLine()) != null) {
                    log.write(line + System.getProperty("line.separator"));
                }
                bufferedreader.close();
                log.write("Client: client completed, server messages read."
                        + System.getProperty("line.separator"));
            } catch (final IOException e) {
                try {
                    // error reading client application output
                    log.write("Client:ioexception " + e);
                } catch (final IOException ioe) {// errors writing log message, ignore
                    // as there is nothing we can do
                }
            } finally {
                if (p != null) {
                    p.destroy();
                }
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Starts the DB2 XTServer to process validation requests from a DB2 XTClient.
     */
    class MetaDataServer implements Runnable {
        Thread client;

        boolean stopRequested;

        boolean started;

        boolean stopped;

        public MetaDataServer(final Thread inClient) {
            client = inClient;
        }

        public boolean startedSuccessfully() {
            return started;
        }

        public void stopServer() {
            stopRequested = true;
        }

        public boolean isStopRequested() {
            return stopRequested == true;
        }

        public boolean isStopped() {
            return stopped == true;
        }

        public void run() {
            final Runtime runtime = Runtime.getRuntime();
            final String[] args = new String[] { "java", "db2_vw_xt.XTServer",
                    new Short(kServerPort).toString() };
            final String format = "ddmmyyyymmss";
            final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
            FileWriter logFile = null;
            final String now = simpleDateFormat.format(new Date());
            Process p = null;
            try {
                logFile = new FileWriter(logDirectory + File.separator + "XTServer"
                        + now + ".log");
                // invoke a shell with the server command
                p = runtime.exec(args);
                // display the server output when processing client requests
                final InputStream inputstream = p.getInputStream();
                final InputStreamReader inputstreamreader =
                    new InputStreamReader(inputstream);
                final BufferedReader bufferedreader = new BufferedReader(inputstreamreader);
                // display the server output
                String line;
                // once the last client has been processed
                // the server may block and wait indefinitely
                // change this code to use wait/notify pattern to avoid this
                while (!isStopRequested()
                        && ((line = bufferedreader.readLine()) != null)) {
                    logFile.write(line + System.getProperty("line.separator"));
                    if (line.indexOf("Failure to create ServerSocket") != -1) {
                        logFile.write("Server:Server failed to start");
                        BILogger.info("Server:Server failed to start"
                                + System.getProperty("line.separator") + line);
                        break;
                    }
                    if (!started) {
                        started = true;
                        BILogger.info("Server: Waiting for clients...");
                        client.interrupt();
                    }
                }
                bufferedreader.close();
            } catch (final IOException e) {
                try {
                    // error reading server output
                    logFile.write("Server: IOError-" + e
                            + System.getProperty("line.separator"));
                } catch (final IOException ioe) {// error writing to log file
                }
            } finally {
                try {
                    BILogger.info("Server:Server stopping.");
                    logFile.write("Server:Server stopping."
                            + System.getProperty("line.separator"));
                    p.destroy();
                    BILogger.info("Server:Server stopped.");
                    logFile.write("Server:Server stopped"
                            + System.getProperty("line.separator"));
                    logFile.flush();
                    logFile.close();
                    stopped = true;
                } catch (final IOException e) {
                    // error writing to log file
                    BILogger.info("Server:" + e);
                }
            }
        }
    }

    // __________________________________________________________________________
    /**
     * Filter allowing only DB2 meta-data tag files.
     */
    static class ETLFileFilter implements FilenameFilter {
        public boolean accept(final File dir, final String name) {
            // get the last seven characters of the string.
            final int suffixLength = 7;
            final int start = name.length() - suffixLength > 0 ? name.length()
                    - suffixLength : 0;
            final String suffix = name.substring(start, name.length());
            // return true if this is an ETL tag file
            if (suffix.equalsIgnoreCase("ETL.tag")) {
                return true;
            } else {
                return false;
            }
        }
    }
}
