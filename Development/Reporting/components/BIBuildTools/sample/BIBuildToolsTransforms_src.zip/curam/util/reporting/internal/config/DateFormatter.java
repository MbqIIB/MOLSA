/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.config;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * converts string to date objects, has a default format which can be overridden
 * by the format in the application property file
 *
 *
 *
 */

public class DateFormatter {

    /**
     * the default date format, the date format in the deployment file will
     * overwrite this format
     */
    private static String theDateFormat = "dd_MMM_yyyy-hh.mm.ss.SSS";

    // ___________________________________________________________________________
    /**
     * This method is used to get a SQL date.
     *
     * @param inDate
     *          the string to parse
     *
     * @return The SQL date object
     * @throws Exception
     */
    static public java.sql.Date getSQLDate(final String inDate) throws Exception {

        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(theDateFormat);
        java.util.Date date = null;

        try {
            date = simpleDateFormat.parse(inDate);
        } catch (final ParseException e) {
            date = null;
        }

        if (date != null) {
            return new java.sql.Date(date.getTime());
        } else {
            throw new Exception();
        }
    }

    // ___________________________________________________________________________
    /**
     * This method is used to get a string value for a java util date.
     *
     * @param inDate
     *          the java util date object to parse
     *
     * @return The string value for a java util date.
     */
    static public String getDate(final java.util.Date inDate) {

        final SimpleDateFormat dateFormat = new SimpleDateFormat(theDateFormat);
        String formattedDate = "null";
        if (inDate != null) {
            formattedDate = dateFormat.format(inDate);
        }
        return formattedDate;
    }
    // ___________________________________________________________________________
    /**
     * This method is used to get a string value for a java util date.
     *
     * @param inDate
     *          the java util date object to parse
     *
     * @return The string value for a java util date.
     */
    static public String getTimeStamp(final java.sql.Timestamp inDate) {

        final SimpleDateFormat dateFormat = new SimpleDateFormat(theDateFormat);
        String formattedDate = "";
        if (inDate != null) {
            formattedDate = dateFormat.format(inDate);
        }
        if (inDate == null) {
            formattedDate = "null";
        }
        return formattedDate;
    }

    // ___________________________________________________________________________
    /**
     * This method is used to get a string value for a java util date.
     *
     * @param inDate
     *          the java util date object to parse
     * @param format
     *          the string format to represent the date
     *
     * @return The string value for a formatted java util date.
     */
    static public String getDate(final java.util.Date inDate, final String format) {

        final SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        String formattedDate = "";

        formattedDate = dateFormat.format(inDate);
        return formattedDate;
    }

    // ___________________________________________________________________________
    /**
     * This method is used to format a date string
     *
     * @param inDateFormat
     *          the string format to represent a date
     */
    public static void setFormat(final String inDateFormat) {
        theDateFormat = inDateFormat;
    }

}
