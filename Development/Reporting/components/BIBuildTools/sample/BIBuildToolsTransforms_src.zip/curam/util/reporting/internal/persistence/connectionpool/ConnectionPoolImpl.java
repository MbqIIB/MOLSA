/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.persistence.connectionpool;

import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import curam.util.reporting.internal.config.*;
import curam.util.reporting.internal.config.TargetDataBaseType;

import curam.util.type.*;

/**
 * This module persistence class for both the build environment and
 * transformations.
 */
@AccessLevel(AccessLevelType.INTERNAL)
class ConnectionPoolImpl implements ConnectionPool {

  /**
   * the connection properties to the database
   */
  private final ConnectionProperties connectionProperties;

  /**
   * the list of available connections
   */
  private final List<Connection> freeConnections = new Vector<Connection>();

  /**
   * the number of connections in use
   */
  private int checkedOut = 0;

  /**
   * the first connection
   */
  private static final int kZero = 0;

  /**
   * Oracle specific statement to make a connection read only
   */
  private static final String kORACLE_SET_TRANSACTION_ONLY_COMMAND = "set transaction read only";

  // ___________________________________________________________________________
  /**
   * Constructor for Connection.
   * 
   * @param inConnectionProperties
   */
  public ConnectionPoolImpl(ConnectionProperties inConnectionProperties) {
    this.connectionProperties = inConnectionProperties;
  }

  // ___________________________________________________________________________
  /**
   * Returns a database connection
   * 
   * @return Connection the connection
   */
  public Connection getConnection() throws SQLException {
    Connection connection = null;

    if (freeConnections.size() > kZero) {
      connection = (Connection) freeConnections.get(kZero);
      freeConnections.remove(kZero);

      try {

        if (connection.isClosed()) {
          connection = getConnection();
        }

      } catch (SQLException e) {
        // log exception
        connection = getConnection();
      }

    } else if (connectionProperties.getMaxConnections() == 0
        || checkedOut < connectionProperties.getMaxConnections()) {
      connection = newConnection();
    }

    if (connection != null) {
      checkedOut++;
    }

    if (connection == null) {
      throw new SQLException("JDBCConnectionPool:getConnection:"
          + "no connections available, max connections="
          + connectionProperties.getMaxConnections() + "checkedout="
          + checkedOut);
    }
    return connection;
  }

  // ___________________________________________________________________________
  /**
   * Returns a database connection
   * 
   * @param inTimeOut
   *          the time to wait before failing
   */
  public Connection getConnection(long inTimeOut) throws SQLException {

    long startTime = new Date().getTime();
    Connection connection = null;

    while (true) {
      try {
        try {
          connection = getConnection();
        } catch (SQLException e) {// ignore and wait for a free
          // connection
        }
        wait(inTimeOut);
      } catch (InterruptedException e) {// ignore and carry on
      }

      if ((new Date().getTime() - startTime) > inTimeOut) {
        break;
      }

    }

    if (connection == null) {
      throw new SQLException(
          "JDBCConnectionPool:getConnection: connection is null");
    }

    return connection;
  }

  // ___________________________________________________________________________
  /**
   * Returns a database connection to the connection pool
   * 
   * @param inConnection
   *          the connection
   */
  public void returnConnection(Connection inConnection) {

    if (inConnection != null) {

      try {
        // the connection may have been in read only mode, etc
        inConnection.rollback();
        freeConnections.add(inConnection);
        try {
          notifyAll();
        } catch (RuntimeException e) {// ignore
        }
      } catch (SQLException e) {
        // try to close the connection
        try {
          inConnection.close();
        } catch (SQLException ex) {// ignore
        }
      }
      checkedOut--;
    }

  }

  // ___________________________________________________________________________
  /**
   * Releases any open resources
   */
  public void releaseResources() {
    Iterator<Connection> iterator = freeConnections.iterator();
    Connection connection;

    while (iterator.hasNext()) {
      connection = (Connection) iterator.next();
      try {
        connection.close();
        iterator.remove();
      } catch (SQLException e) {// log error
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Returns a read only database connection
   * 
   * @param inDataSourceName
   *          the data store to establish a connection with
   * 
   * @return Connection the transaction to work with
   */
  public Connection getReadOnlyConnection(String inDataSourceName)
      throws SQLException {

    Connection con = getConnection();
    // rollback, as we cannot set this in the middle of a transaction
    // con.rollback();

    TargetDataBaseType targetDataBaseType = connectionProperties
        .getTargetDataBaseType();

    try {
      setThisConnectionToReadOnly(con, targetDataBaseType);
    } catch (SQLException e) {
      throw new SQLException("JDBCConnectionPool::getReadOnlyConnection:"
          + "failed to set connection to read only, exception is " + e);
    }

    return con;
  }

  // ___________________________________________________________________________
  /**
   * Returns a new database connection
   * 
   * @return Connection the transaction to work with
   */
  private Connection newConnection() throws SQLException {
    Connection connection = null;

    try {
      connection = DriverManager.getConnection(connectionProperties.getUrl(),
          connectionProperties.getUserid(), connectionProperties.getPassword());

      connection.setAutoCommit(false);
    } catch (SQLException e) {
      throw new SQLException("JDBCConnectionPool:newConnection" + e);
    }
    return connection;
  }

  // ___________________________________________________________________________
  /**
   * Sets this connection to a read only connection
   * 
   * @param String
   *          the data store to establish a connection with
   * 
   * @param TargetDatabaseType
   *          the database vendor
   */
  private void setThisConnectionToReadOnly(Connection inConnection,
      TargetDataBaseType inTargetDataBaseType) throws SQLException {

    // the oracle and db2 setting(s) to support read only transaction
    // semantics
    // should be move out to property files
    if (inTargetDataBaseType.isORACLE()) {
      Statement ps = null;

      try {
        ps = inConnection.createStatement();

        ps.executeUpdate(kORACLE_SET_TRANSACTION_ONLY_COMMAND);
      } catch (SQLException e) {
        throw e;
      } finally {
        try {
          if (ps != null) {
            ps.close();
          }
        } catch (SQLException e) {
          // ignore here as nothing we can do anyway
          throw e;
        }
      }
    } else {
      // its a DB2 connection, the decision on which isolation level
      // to choose will be left to the client organization,

      inConnection.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
    }
  }

  /**
   * Returns the connectionProperties.
   * 
   * @return ConnectionProperties
   */
  public ConnectionProperties getConnectionProperties() {
    return connectionProperties;
  }

}
