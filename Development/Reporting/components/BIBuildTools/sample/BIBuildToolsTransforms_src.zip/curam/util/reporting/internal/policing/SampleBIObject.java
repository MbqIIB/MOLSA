/*
 * Copyright 2010 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.policing;

/**
 * This module stores Reporting configuration data.
 */
public class SampleBIObject {

    private boolean isDeprecated = false;

    private String filename = "";

    private String controltablename = "";

    private String objectname = "";
    private String schema = "";
    private String businesscomponent = "";
    private String objecttype = "";
    private String asof = "";
    private String notes = "";

    public SampleBIObject() {

    }

    public String getObjectname() {
	return objectname;
    }

    public void setObjectname(final String objectname) {
	this.objectname = objectname;
	if (objectname.contains("_ETL") == true) {
	    // default the control table name
	    setControltableEntry(objectname.substring(0,
		    objectname.length() - 4));
	    // default the control table name
	    setFilename(objectname);
	}
    }

    public String getSchema() {
	return schema;
    }

    public void setDeprecated() {
	isDeprecated = true;
    }

    public void setSchema(final String schema) {
	this.schema = schema;
    }

    public String getBusinesscomponent() {
	return businesscomponent;
    }

    public void setBusinesscomponent(final String businesscomponent) {
	this.businesscomponent = businesscomponent;
    }

    public String getObjecttype() {
	return objecttype;
    }

    public void setObjecttype(final String objecttype) {
	this.objecttype = objecttype;
    }

    public String getAsof() {
	return asof;
    }

    public void setAsof(final String asof) {
	this.asof = asof;
    }

    public String getNotes() {
	return notes;
    }

    public void setNotes(final String notes) {
	this.notes = notes;
    }

    public String getFilename() {
	return filename;
    }

    public void setFilename(final String filename) {
	if (filename != null && filename.length() > 0) {
	    this.filename = filename;
	}
    }

    public String getControltableEntry() {
	return controltablename;
    }

    public void setControltableEntry(final String controltablename) {
	if (controltablename != null && controltablename.length() > 0) {
	    this.controltablename = controltablename;
	}
    }
}
