/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

/**
 * This module defines functions to import DB2 meta data.
 * 
 * @deprecated
 * @since 5.2 SP4
 */
@Deprecated
public class AntDB2MetaData extends Task {
    /**
     * the user identity for the DB2 meta data design repository.
     */
    private boolean isDB2;

    /**
     * the user identity for the DB2 meta data design repository.
     */
    private String userid = "";

    /**
     * the name of the meta data repository.
     */
    private String controlDatabaseName = "";

    /**
     * the password for the DB2 meta data design repository.
     */
    private String password = "";

    /**
     * the directory where ETL meta-data file resides.
     */
    private String baseMetaDataDirectory = "";

    /**
     * the directory where import command resides.
     */
    private String commandLocation = "";

    /**
     * the ETL meta-data file.
     */
    private String metaDataFileName = "";

    /**
     * the directory where log files are written.
     */
    private String logDirectory = "";

    /**
     * either 390 or UDB.
     */
    private String dbSourceType = "";

    /**
     * the directory where log files are written.
     */
    static public final String zOS = "390";

    /**
     * the directory where log files are written.
     */
    static public String uDB = "UDB";

    /**
     * the staging directory name.
     */
    static final String kStaging = "staging";

    /**
     * the source directory name.
     */
    static final String kSource = "source";

    // ___________________________________________________________________________
    /**
     * Sets the meta data directory location.
     * 
     * @param inDirectory
     *          the meta-data directory path
     */
    public void setMetaDataDirectory(final String inDirectory) {
        if (inDirectory != null) {
            baseMetaDataDirectory = inDirectory;
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the name for meta data repository.
     * 
     * @param inControlDatabaseName
     *          name for meta data repository
     */
    public void setControlDatabaseName(final String inControlDatabaseName) {
        if (inControlDatabaseName != null) {
            controlDatabaseName = inControlDatabaseName;
        }
    }

    // ___________________________________________________________________________
    /**
     * Exists if the condition is false.
     * 
     * @param isDB2
     *          the repository user identity
     */
    public void setIf(final boolean isDB2) {
        this.isDB2 = isDB2;
    }

    // ___________________________________________________________________________
    /**
     * Sets the command location.
     * 
     * @param inCommandLocation
     *          the meta-data directory path
     */
    public void setCommandLocation(final String inCommandLocation) {
        if (inCommandLocation != null) {
            commandLocation = inCommandLocation;
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the meta data directory location.
     * 
     * @param inMetaDataFile
     *          the meta-data directory path
     */
    public void setMetaDataFileName(final String inMetaDataFile) {
        if (inMetaDataFile != null) {
            metaDataFileName = inMetaDataFile;
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the source database type.
     * 
     * @param inSourceType
     *          the meta-data directory path
     */
    public void setDbSourceType(final String inSourceType) {
        if (inSourceType != null) {
            dbSourceType = inSourceType;
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the log directory location.
     * 
     * @param inDirectory
     *          the log directory path
     */
    public void setLogDirectory(final String inDirectory) {
        if (inDirectory != null) {
            logDirectory = inDirectory;
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the repository user identity.
     * 
     * @param inUserid
     *          the repository user identity
     */
    public void setUserid(final String inUserid) {
        if (inUserid != null) {
            userid = inUserid;
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the repository user identity.
     * 
     * @param inPassword
     *          the repository user identity
     */
    public void setPassword(final String inPassword) {
        if (inPassword != null) {
            password = inPassword;
        }
    }

    // _________________________________________________________________________
    /**
     * Appends 390 or UDB to the directory name if the directory is source or
     * staging.
     * 
     * @param inMetaDataDirectory
     *          the directory to be processed
     * @param inSourceType
     *          if the source 390 or UDB
     * @return String appends 390 or UDB to the directory name if the directory is
     *         source or staging
     */
    public static String getDB2Directory(final String inMetaDataDirectory,
            final String inSourceType) {
        String directory = inMetaDataDirectory;
        if (inMetaDataDirectory.endsWith(kStaging)
                || inMetaDataDirectory.endsWith(kSource)) {
            if (zOS.equalsIgnoreCase(inSourceType)) {
                directory = inMetaDataDirectory + File.separator + "zos";
            } else if (uDB.equalsIgnoreCase(inSourceType)) {
                directory = inMetaDataDirectory + File.separator + "udb";
            }
        }
        final File dir = new File(directory);
        // validate the source ETL directory
        if (!dir.exists() || !dir.isDirectory()) {
            throw new BuildException("Meta data directory does not exist <"
                    + directory + ">");
        }
        return directory;
    }

    // ___________________________________________________________________________
    /**
     * If file name is empty import all ETL's in the directory. If file name is
     * valid, imports the file in the directory. if the database type is valid,
     * appends UDB/ZOS to directory name and imports all ETLs in the directory.
     * 
     * @throws BuildException
     *           if the database meta data import failed
     */
    @Override
    public void execute() throws BuildException {
        // the directory when ETL meta data files reside
        File dir = null;
        // the directory when ETL meta data files reside
        File commonETLDir = null;
        String db2MetaDataDirectory = null;
        // the directory when ETL meta data files reside
        final File logDir = new File(logDirectory);
        File[] results = null;
        if (!isDB2) {
            return;
        }
        // validate the source ETL directory
        if (!logDir.exists() || !logDir.isDirectory()) {
            throw new BuildException("Log directory does not exist <" + logDirectory
                    + ">");
        }
        // has the user identity been set
        if (userid.length() == 0) {
            throw new BuildException("Invalid repository user identity <" + userid
                    + ">");
        }
        // has the password been set
        if (password.length() == 0) {
            throw new BuildException("Invalid repository password");
        }
        // has the password been set
        if (baseMetaDataDirectory.length() == 0) {
            throw new BuildException("Invalid meta data directory");
        }
        // has the user identity been set
        if (!baseMetaDataDirectory.endsWith(kSource)
                && (dbSourceType == null || dbSourceType.length() == 0)) {
            throw new BuildException("Missing <dbSourceType> property");
        }
        db2MetaDataDirectory = getDB2Directory(baseMetaDataDirectory, dbSourceType);
        dir = new File(db2MetaDataDirectory);
        commonETLDir = new File(baseMetaDataDirectory);
        if (metaDataFileName != null && metaDataFileName.length() > 0) {
            File file = null;
            if (metaDataFileName.startsWith(kStaging)) {
                file = new File(commonETLDir + "/" + metaDataFileName);
            } else {
                file = new File(db2MetaDataDirectory + "/" + metaDataFileName);
            }
            if (!file.exists()) {
                BILogger.info(" File not found " + file.getAbsolutePath());
            }
            execute(file.getAbsolutePath());
        } else {
            // if we are importing staging meta data
            // import the ETL processes which
            // read there source data from files on disk
            if (baseMetaDataDirectory.endsWith(kStaging)
                    || baseMetaDataDirectory.endsWith(kSource)) {
                results = commonETLDir
                .listFiles(new AntDB2ValidateMetadata.ETLFileFilter());
                for (int i = 0; i < results.length; i++) {
                    execute(results[i].getAbsolutePath());
                }
            }
            // import the meta data
            results = dir.listFiles(new AntDB2ValidateMetadata.ETLFileFilter());
            for (int i = 0; i < results.length; i++) {
                execute(results[i].getAbsolutePath());
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Throws a build exception if DB2 import command fails.
     * 
     * @param inTagFileName
     *          the meta data file to import
     * @throws BuildException
     *           if the database meta data import failed
     */
    public void execute(final String inTagFileName) throws BuildException {
        // run the XTClient to ask the server to promote the task to test
        // promoting an ETL to test causes the meta-data to be validated
        final Runtime runtime = Runtime.getRuntime();
        Process p = null;
        final String command = commandLocation + File.separator + "iwh2imp2.exe";
        // command to start the client DB2 application
        final String[] args = new String[] { command, inTagFileName, logDirectory,
                controlDatabaseName, userid, password };
        try {
            BILogger.info("importing ");
            BILogger.info(inTagFileName);
            // if (true)
            // return;
            // start the client
            p = runtime.exec(args);
            // read the output from the client
            final InputStream inputstream = p.getInputStream();
            final InputStreamReader inputstreamreader = new InputStreamReader(
                    inputstream);
            final BufferedReader bufferedreader = new BufferedReader(
                    inputstreamreader);
            // display the import messages
            String line;
            while ((line = bufferedreader.readLine()) != null) {
                BILogger.info(line.trim());
            }
            bufferedreader.close();
        } catch (final IOException e) {
            // error reading client application output
            BILogger.info("DB2 meta data import exception:" + e);
            throw new BuildException(e.getMessage());
        } finally {
            if (p != null) {
                p.destroy();
            }
        }
    }
}
