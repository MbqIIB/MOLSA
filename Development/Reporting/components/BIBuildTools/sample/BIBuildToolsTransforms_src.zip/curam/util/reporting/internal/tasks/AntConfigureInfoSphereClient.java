/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.util.List;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import curam.util.reporting.internal.config.ConnectionProperties;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.PropertiesCache;
import curam.util.reporting.internal.config.PropertyReaderFactory;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;

@AccessLevel(AccessLevelType.INTERNAL)
/**
 * Replaces the following properties within the default profiles
 * 

 * <ol>
 * <li>Replaces the attributes values listed as constants on this class</li>
 * <li>Uses a default profile when generating a new profile</li>
 * <li>generate profiles for the curam, staging, warehouse, data mart and demo data schema</li>
 * <ol>
 */
public class AntConfigureInfoSphereClient extends Task {
  private static final String infoSphereDataBaseConnectionsDir =
      "database-connections";

  private static final String infoSphereVariablesDir = "variables";

  private static final String infoSphereScriptsDir = "scripted";

  private static final String flatFileName = "FLATFILES_PATH.varxmi";

  /**
   * the generated profile replaces this value of this attribute
   */
  private static final String ORG_JAR_LIST = "jarList";

  /**
   * the generated profile replaces this value of this attribute
   */
  private static final String ORG_ECLIPSE_DATATOOLS_CONNECTIVITY_DB_URL =
      "org.eclipse.datatools.connectivity.db.URL";

  /**
   * the generated profile replaces this value of this attribute
   */
  /**
   * the generated profile replaces this value of this attribute
   */
  private static final String ORG_ECLIPSE_DATATOOLS_CONNECTIVITY_DB_DATABASE_NAME =
      "org.eclipse.datatools.connectivity.db.databaseName";

  /**
   * the generated profile replaces this value of this attribute
   */
  private static final String ORG_ECLIPSE_DATATOOLS_CONNECTIVITY_DB_DEFAULT_SCHEMA =
      "org.eclipse.datatools.connectivity.db.defaultSchema";

  /**
   * the generated profile replaces this value of this attribute
   */
  private static final String ORG_ECLIPSE_DATATOOLS_CONNECTIVITY_DB_USERNAME =
      "org.eclipse.datatools.connectivity.db.username";

  /**
   * the generated profile replaces this value of this attribute
   */
  private static final String elementBaseProperties = "baseproperties";

  /**
   * the generated profile replaces this value of this attribute
   */
  private static final String elementProfile = "profile";

  /**
   * the generated profile replaces this value of this attribute
   */
  private static final String attributePropertyName = "name";

  /**
   * the attribute value to replace
   */
  private static final String attributePropertyValue = "value";

  /**
   * the directory containing the sample profiles
   */
  private String infoSphereBaseDir = "";

  /**
   * the sample profile file names
   */
  private final String oracleTemplate = "oracleprofile.xml";

  private final String db2Template = "db2profile.xml";

  @SuppressWarnings("unused")
  private final String flatFiles = "FLATFILES_PATH.varxmi";

  public static void main(String[] args) {
    AntConfigureInfoSphereClient power = new AntConfigureInfoSphereClient();
    power.execute();
  }

  // ___________________________________________________________________________
  /**
   * Sets the path to the property file from Ant
   * 
   * @param inSampleProfilesDir
   *          the path to the sample files
   */
  public void setBaseDir(final String inSampleProfilesDir) {
    infoSphereBaseDir = inSampleProfilesDir;
  }

  @Override
  public void execute() throws BuildException {
    connectionProfiles();
    updateFlatFileLocation();
  }

  public void connectionProfiles() throws BuildException {
    PropertiesCache propertyReader;
    try {
      propertyReader = PropertyReaderFactory.getConnectionPropertyReader();
      ConnectionProperties[] schemaDefinitions = propertyReader
          .getConnectionProperties();
      TargetDataBaseType targetDataBaseType = propertyReader
          .getTargetEnvironment();
      File sourceProfile = null;
      File targetProfile = null;
      File databaseConnectionsDir = new File(infoSphereBaseDir,
          infoSphereDataBaseConnectionsDir);
      File databaseScriptsDir = new File(infoSphereBaseDir,
          infoSphereScriptsDir);
      BILogger.debug("IWE connection profiles for database vendor "
          + targetDataBaseType.getProductName());
      if (targetDataBaseType.isORACLE()) {
        sourceProfile = new File(databaseScriptsDir, oracleTemplate);
        BILogger.debug("IWE connection profiles using "
            + sourceProfile.getAbsolutePath());
      }
      if (targetDataBaseType.isDB2()) {
        sourceProfile = new File(databaseScriptsDir, db2Template);
        BILogger.debug("IWE connection profiles using "
            + sourceProfile.getAbsolutePath());
      }
      if (!sourceProfile.exists()) {
        BILogger.debug("verify profileDir directory contains " + oracleTemplate
            + " and " + db2Template);
      }
      for (int i = 0; i < schemaDefinitions.length; i++) {
        ConnectionProperties schema = schemaDefinitions[i];
        targetProfile = new File(databaseConnectionsDir,
            schema.getAppServerDataSourceName() + ".xml");
        createProfile(sourceProfile, targetProfile, schema);
      }
      BILogger.info("IWE connection profiles are available for "
          + propertyReader.getTargetEnvironment().getProductName());
    } catch (Exception e) {
      BILogger.error("creating ..." + e.getMessage());
      e.printStackTrace();
    }
  }

  private void createProfile(final File inInputFile, final File InOutputFile,
      ConnectionProperties inSchemaDefinition) {
    try {
      Document doc = DomFactory.parseXml(inInputFile);
      BILogger.debug("creating ..." + InOutputFile.getName());
      NodeList profiles = doc.getElementsByTagName(elementProfile);
      if (profiles.getLength() > 0) {
        Element theProfile = (Element) profiles.item(0);
        theProfile.setAttribute(attributePropertyName,
            inSchemaDefinition.getAppServerDataSourceName());
      }
      NodeList keyItems = doc.getElementsByTagName(elementBaseProperties);
      if (keyItems.getLength() > 0) {
        Node theParent = keyItems.item(0);
        List<Element> properties = DomUtilities.getChildrenByName(theParent,
            "property");
        for (int i = 0; i < properties.size(); i++) {
          Element property = (Element) properties.get(i);
          String propertyName = property.getAttribute(attributePropertyName);
          if (ORG_ECLIPSE_DATATOOLS_CONNECTIVITY_DB_USERNAME
              .equalsIgnoreCase(propertyName)) {
            String propertyValue = inSchemaDefinition.getUserid();
            property.setAttribute(attributePropertyValue, propertyValue);
          }
          if (ORG_ECLIPSE_DATATOOLS_CONNECTIVITY_DB_DEFAULT_SCHEMA
              .equalsIgnoreCase(propertyName)) {
            String propertyValue = inSchemaDefinition.getUserid();
            property.setAttribute(attributePropertyValue, propertyValue);
          }
          if (ORG_ECLIPSE_DATATOOLS_CONNECTIVITY_DB_DATABASE_NAME
              .equalsIgnoreCase(propertyName)) {
            String propertyValue = inSchemaDefinition.getDatabaseName();
            property.setAttribute(attributePropertyValue, propertyValue);
          }
          if (ORG_ECLIPSE_DATATOOLS_CONNECTIVITY_DB_URL
              .equalsIgnoreCase(propertyName)) {
            String propertyValue = "";
            if (inSchemaDefinition.getTargetDataBaseType().isORACLE()) {
              propertyValue = inSchemaDefinition.getAlternateUrl();
            } else {
              propertyValue = inSchemaDefinition.getUrl();
            }
            property.setAttribute(attributePropertyValue, propertyValue);
          }
          if (ORG_JAR_LIST.equalsIgnoreCase(propertyName)) {
            if (inSchemaDefinition.getTargetDataBaseType().isDB2()) {
              File driversDir = DataWarehouseConstants.getDriversDirectory();
              File db2jcc = new File(driversDir, "db2jcc.jar");
              File db2jcclicensez = new File(driversDir,
                  "db2jcc_license_cuz.jar");
              File db2jcclicense =
                  new File(driversDir, "db2jcc_license_cu.jar");
              StringBuffer path = new StringBuffer();
              if (db2jcc.exists()) {
                path.append(db2jcc.getAbsolutePath());
              }
              if (db2jcclicensez.exists()) {
                path.append(";").append(db2jcclicensez.getAbsolutePath());
              }
              if (db2jcclicense.exists()) {
                path.append(";").append(db2jcclicense.getAbsolutePath());
              }
              property.setAttribute(attributePropertyValue, path.toString());
            } else if (inSchemaDefinition.getTargetDataBaseType().isORACLE()) {
              File driversDir = DataWarehouseConstants.getDriversDirectory();
              File oracleJar = new File(driversDir, "ojdbc.jar");
              StringBuffer path = new StringBuffer();
              if (oracleJar.exists()) {
                path.append(oracleJar.getAbsolutePath());
              }
              property.setAttribute(attributePropertyValue, path.toString());
            }
          }
        }
      }
      // Prepare the DOM document for writing
      javax.xml.transform.Source source =
          new javax.xml.transform.dom.DOMSource(
              doc);
      // Prepare the output file
      javax.xml.transform.Result result =
          new javax.xml.transform.stream.StreamResult(
              InOutputFile);
      // Write the DOM document to the file
      javax.xml.transform.Transformer xformer =
          javax.xml.transform.TransformerFactory
              .newInstance().newTransformer();
      xformer.setOutputProperty(javax.xml.transform.OutputKeys.METHOD, "xml");
      xformer.setOutputProperty(
          javax.xml.transform.OutputKeys.OMIT_XML_DECLARATION, "no");
      xformer.setOutputProperty(javax.xml.transform.OutputKeys.VERSION, "1.0");
      xformer.setOutputProperty(javax.xml.transform.OutputKeys.ENCODING,
          "UTF-8");
      xformer.setOutputProperty(javax.xml.transform.OutputKeys.INDENT, "yes");
      xformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount",
          "2");
      xformer.transform(source, result);
      // BILogger.info("creating " +
      // outputFile.getAbsolutePath());
    } catch (Exception e) {
      BILogger.error("creating ..." + InOutputFile.getName() + e.getMessage());
    }
  }

  private void updateFlatFileLocation() {
    try {
      File databaseScriptsDir = new File(infoSphereBaseDir,
          infoSphereScriptsDir);
      File variablesDir = new File(infoSphereBaseDir, infoSphereVariablesDir);
      File sourceFile = new File(databaseScriptsDir, flatFileName);
      File targetFile = new File(variablesDir, flatFileName);
      BILogger.debug("Creating flat file definitions..."
          + sourceFile.getAbsolutePath());
      Document doc = DomFactory.parseXml(sourceFile);
      NodeList variables = doc.getElementsByTagName("Variable");
      if (variables.getLength() > 0) {
        Element theProfile = (Element) variables.item(0);
        List<Element> properties = DomUtilities.getChildrenByName(theProfile,
            "value");
        for (int i = 0; i < properties.size(); i++) {
          Element property = (Element) properties.get(i);
          List<Element> values = DomUtilities.getChildrenByName(property,
              "defaultValue");
          for (int j = 0; j < values.size(); j++) {
            Element value = (Element) values.get(j);
            File dataFiles = new File(
                DataWarehouseConstants.getBaseDirectory(),
                "components/core/etl/CuramBIWarehouse/package-misc");
            value.setAttribute("fileName", dataFiles.getAbsolutePath());
          }
        }
      } else {
        BILogger.debug("did not find variables" + variables);
      }
      if (true) {
        // Prepare the DOM document for writing
        javax.xml.transform.Source source =
            new javax.xml.transform.dom.DOMSource(
                doc);
        // Prepare the output file
        javax.xml.transform.Result result =
            new javax.xml.transform.stream.StreamResult(
                targetFile);
        // Write the DOM document to the file
        javax.xml.transform.Transformer xformer =
            javax.xml.transform.TransformerFactory
                .newInstance().newTransformer();
        xformer.setOutputProperty(javax.xml.transform.OutputKeys.METHOD, "xml");
        xformer.setOutputProperty(
            javax.xml.transform.OutputKeys.OMIT_XML_DECLARATION, "no");
        xformer
            .setOutputProperty(javax.xml.transform.OutputKeys.VERSION, "1.0");
        xformer.setOutputProperty(javax.xml.transform.OutputKeys.ENCODING,
            "UTF-8");
        xformer.setOutputProperty(javax.xml.transform.OutputKeys.INDENT, "yes");
        xformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount",
            "2");
        xformer.transform(source, result);
      }
    } catch (Exception e) {
      BILogger.error(e.getMessage());
    }
  }
}
