package curam.util.reporting.internal.tasks;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.Enumeration;
import java.util.Properties;

public class CopyFileTest {
  @SuppressWarnings("rawtypes")
  public static void main(String[] args) {
    try {
      Charset cs1 = Charset.forName("UTF-8");
      BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
          new FileOutputStream("c:\\test2.txt"), cs1));
      Properties prop = new Properties();
      prop.load(new FileInputStream("c:\\test1.txt"));
      Enumeration keys = prop.keys();
      while (keys.hasMoreElements()) {
        String next = (String) keys.nextElement();
        String value = prop.getProperty(next);
        out.write(next + "=" + value);
        out.write(System.getProperty("line.separator"));
      }
      out.flush();
      out.close();
    } catch (Exception e) {
    }
  }
}
