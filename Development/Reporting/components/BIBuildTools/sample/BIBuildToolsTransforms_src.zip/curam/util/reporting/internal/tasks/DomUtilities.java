/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import curam.util.type.*;

@AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
public class DomUtilities {
  /**
   * Retrieves one or more direct child elements by name. Only a single level
   * deep is searched.
   * 
   * @param parentElement
   *          The parent element.
   * @param tagName
   *          The tag name to search for.
   * @return An list of elements matching the tag name, or an empty list if none
   *         exists.
   */
  public static List<Element> getChildrenByName(final Node parentElement,
      final String tagName) {
    final List<Element> list = new ArrayList<Element>();
    final NodeList nodeList = parentElement.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      if (nodeList.item(i).getNodeName().equals(tagName)) {
        list.add((Element) nodeList.item(i));
      }
    }
    return list;
  }

  /**
   * Retrieves one or more direct child elements by name. Only a single level
   * deep is searched.
   * 
   * @param parentElement
   *          The parent element.
   * @param tagName
   *          The tag name to search for.
   * @return An list of elements matching the tag name, or an empty list if none
   *         exists.
   */
  public static List<Element> getChildrenByName(final Element parentElement,
      final String tagName) {
    final List<Element> list = new ArrayList<Element>();
    final NodeList nodeList = parentElement.getChildNodes();
    for (int i = 0; i < nodeList.getLength(); i++) {
      if (nodeList.item(i).getNodeName().equals(tagName)) {
        list.add((Element) nodeList.item(i));
      }
    }
    return list;
  }
}
