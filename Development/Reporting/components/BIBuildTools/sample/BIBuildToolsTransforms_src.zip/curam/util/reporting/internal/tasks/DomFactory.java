/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import curam.util.type.AccessLevel;

@AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
public class DomFactory {
  /**
   * Creates an empty DOM document.
   * 
   * @return The DOM document.
   */
  public static Document createNewDocument() {
    final DocumentBuilderFactory factory = DocumentBuilderFactory
        .newInstance();
    DocumentBuilder docBuilder;
    try {
      docBuilder = factory.newDocumentBuilder();
    } catch (final ParserConfigurationException e) {
      throw new RuntimeException(e);
    }
    final Document doc = docBuilder.newDocument();
    return doc;
  }

  /**
   * Parses an XML file to create a DOM document.
   * 
   * @param file
   *          The input file to be parsed.
   * @return The DOM document.
   */
  public static Document parseXml(final File file) {
    try {
      return parseXml(new FileInputStream(file));
    } catch (FileNotFoundException e) {
      BILogger.error(" parse xml failure  " + e.getMessage());
      throw new RuntimeException(e);
    }
  }

  /**
   * Parses XML to create a DOM document.
   * 
   * @param inputStream
   *          The input stream to be parsed.
   * @return The DOM document.
   */
  public static Document parseXml(final InputStream inputStream) {
    Document xmlDoc = null;
    try {
      final DocumentBuilderFactory documentBuilderFactory =
          DocumentBuilderFactory
              .newInstance();
      documentBuilderFactory.setNamespaceAware(true); // never forget
      // this!
      final DocumentBuilder documentBuilder = documentBuilderFactory
          .newDocumentBuilder();
      xmlDoc = documentBuilder.parse(inputStream);
    } catch (final SAXException e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    } catch (final IOException e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    } catch (final ParserConfigurationException e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    }
    return xmlDoc;
  }

  /**
   * Parses XML text to create a DOM document.
   * 
   * @param value
   *          The XML text to be parsed.
   * @return The DOM document.
   */
  public static Document parseXmlText(final String value) {
    Document xmlDoc = null;
    try {
      final DocumentBuilderFactory documentBuilderFactory =
          DocumentBuilderFactory
              .newInstance();
      final DocumentBuilder documentBuilder = documentBuilderFactory
          .newDocumentBuilder();
      final InputSource source = new InputSource();
      source.setCharacterStream(new StringReader(value));
      xmlDoc = documentBuilder.parse(source);
    } catch (final SAXException e) {
      throw new RuntimeException(e);
    } catch (final IOException e) {
      throw new RuntimeException(e);
    } catch (final ParserConfigurationException e) {
      throw new RuntimeException(e);
    }
    return xmlDoc;
  }

  /**
   * Converts a DOM document to plain XML text.
   * 
   * @param doc
   *          The DOM document
   * @return XML text.
   */
  public static String convertDocumentToText(final Document doc) {
    final TransformerFactory transfac = TransformerFactory.newInstance();
    Transformer trans;
    try {
      trans = transfac.newTransformer();
    } catch (final TransformerConfigurationException e) {
      throw new RuntimeException(e);
    }
    trans.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "Yes");
    final StringWriter sw = new StringWriter();
    final StreamResult result = new StreamResult(sw);
    final DOMSource source = new DOMSource(doc);
    try {
      trans.transform(source, result);
    } catch (final TransformerException e) {
      throw new RuntimeException(e);
    }
    final String xmlString = sw.toString();
    return xmlString;
  }

  static public class SimpleNamespaceContext implements NamespaceContext {
    private final Map<String, String> nameSpaceMap =
        new HashMap<String, String>();

    public SimpleNamespaceContext(final Map<String, String> prefMap) {
      nameSpaceMap.putAll(prefMap);
    }

    public String getNamespaceURI(String prefix) {
      String uri = nameSpaceMap.get(prefix);
      return uri;
    }

    public String getPrefix(String uri) {
      throw new UnsupportedOperationException();
    }

    public Iterator getPrefixes(String uri) {
      throw new UnsupportedOperationException();
    }
  }
}
