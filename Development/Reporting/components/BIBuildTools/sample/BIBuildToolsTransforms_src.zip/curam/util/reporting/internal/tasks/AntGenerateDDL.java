/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.SchemaGroup;

import curam.util.type.*;

/**
 * 
 * This class generates SQL data definition statements for the reporting
 * databases.
 * 
 * This build task will include custom directories for client artifacts.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntGenerateDDL extends Task {
  /**
   * the target database type - from the application properties file
   */
  TargetDataBaseType targetDataBaseType;

  /**
   * a full path to the generated DDL file
   */
  private String generatedDDLFile;

  /**
   * the root reporting directory
   */
  private String reportingDir;

  /**
   * the schema begin build
   */
  private final SchemaGroup selectedSchemas = new SchemaGroup();

  /**
   * local test harness for developers
   * 
   * @param inArguments
   * @throws Exception
   */
  public static void main(String[] inArguments) throws Exception {
    if (inArguments.length != 1) {
      throw new Exception(
          " buildFileFullPath , ensure to pass the Reporing dir as a parameter using -DREPORTING_DIR=");
    }
    /*
     * File buildFile = new File(inArguments[0]); Project p = new Project();
     * p.setUserProperty("ant.file", buildFile.getAbsolutePath()); p.init();
     * ProjectHelper helper = ProjectHelper.getProjectHelper();
     * p.addReference("ant.projectHelper", helper); helper.parse(p, buildFile);
     * p.executeTarget("database.staging");
     */
    /*
     * without ant.
     */
    AntGenerateDDL task = new AntGenerateDDL();
    task.reportingDir = System.getProperty("REPORTING_DIR");
    task.generatedDDLFile = task.reportingDir + "\\bin\\ddl\\";
    task.selectedSchemas.setStaging();
    task.selectedSchemas.onlyTransformations();
    task.execute();
  }

  // ___________________________________________________________________________
  /**
   * Throws a build exception if the DDL file cannot be created
   * 
   * @throws BuildException
   */
  @Override
  public void execute() throws BuildException {
    try {
      Project antProject = getProject();
      String calledFrom = "";
      if (antProject != null) {
        // if we get a valid ant project object then getBaseDir will
        // return
        // the calling directory, e.g. "components", "core" etc
        // if we are in the "components" directory then build for
        // everything installed on disk.
        // otherwise build for the specific component only
        calledFrom = antProject.getBaseDir().getName();
      } else {
        System.out
            .println("Error:Can't get the ant project:Project ant = getProject");
        calledFrom = "core";
      }
      /**
       * we also have the ability to run a configuration test if needed
       * 
       * AntConfigTest configTest = new AntConfigTest(reportingDir,
       * kPropertyFileFullPath);
       * 
       * // verify the build file is valid configTest.setProject(getProject());
       * configTest.execute();
       */
      // pass in the calling directory to work out what components to build
      ReportingFileManager fileManager = new ReportingFileManager(calledFrom,
          reportingDir);
      fileManager.mergeDDLFiles(selectedSchemas, generatedDDLFile);
    } catch (BuildException e) {
      e.printStackTrace();
      throw new BuildException(e.getMessage());
    } catch (Exception e) {
      e.printStackTrace();
      throw new BuildException(e.getMessage());
    }
  }

  // ___________________________________________________________________________
  /**
   * Sets the database to build
   * 
   * @param inSchemaName
   *          database to build, staging,central,datamart,all
   */
  public void setStaging(final boolean inSchemaName) {
    if (inSchemaName)
      selectedSchemas.setStaging();
  }

  // ___________________________________________________________________________
  /**
   * Sets the database to build
   * 
   * @param inSchemaName
   *          database to build, staging,central,datamart,all
   */
  public void setDatamarts(final boolean inSchemaName) {
    if (inSchemaName)
      selectedSchemas.setDatamart();
  }

  // ___________________________________________________________________________
  /**
   * Sets the database to build
   * 
   * @param inSchemaName
   *          database to build, staging,central,datamart,all
   */
  public void setCentral(final boolean inSchemaName) {
    if (inSchemaName)
      selectedSchemas.setCentral();
  }

  // ___________________________________________________________________________
  /**
   * Sets the database to build
   * 
   * @param inOnlyBuildTransformations
   *          database to build, staging,central,datamart,all
   */
  public void setTransformsOnly(final boolean inOnlyBuildTransformations) {
    if (inOnlyBuildTransformations)
      selectedSchemas.onlyTransformations();
  }

  // ___________________________________________________________________________
  /**
   * Sets the base reporting directory
   * 
   * @param inReportingDir
   *          base reporting directory
   */
  public void setReportingDir(String inReportingDir) {
    reportingDir = inReportingDir;
  }

  // ___________________________________________________________________________
  /**
   * the location where the file will be written to
   * 
   * @param inBuildDirectory
   * 
   */
  public void setGeneratedDDLFile(String inBuildDirectory) {
    this.generatedDDLFile = inBuildDirectory;
  }
}
