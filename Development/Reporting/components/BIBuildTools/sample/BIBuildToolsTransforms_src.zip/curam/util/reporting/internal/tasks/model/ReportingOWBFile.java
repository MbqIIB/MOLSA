/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * 
 */
package curam.util.reporting.internal.tasks.model;

import java.io.File;

import curam.util.type.*;

@AccessLevel(AccessLevelType.RESTRICTED)
public class ReportingOWBFile extends ReportingFile {
    public ReportingOWBFile(final String inFileName, final boolean inIsCustom) {
        super(inFileName, inIsCustom);
    }

    /**
     * Return true if this file contains OWB schema meta data.
     * 
     * @return true if the file name contains <code>_ETL></code> in the file name
     */
    public boolean isOWBSchemaFile() {
        final int etl = getFileName().toLowerCase().indexOf("_ETL".toLowerCase());
        if (etl == -1) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns the name of the target table
     * 
     * @return String the name of the target table
     */
    public String getTargetTableName() {
        final String name = getFile().getName();
        // remove the file name suffix
        String etlName = name.substring(0, name.length() - 4);

        if (etlName.contains("_ETL")){
            etlName= etlName.substring(0, etlName.length() - 4);
        }

        if (etlName.contains("TRANSFORM")) {
            etlName = etlName.substring(0, etlName.length() -9);
        }
        if (etlName.endsWith("_")) {
            etlName = etlName.substring(0, etlName.length() -1);
        }
        return etlName;
    }

    /**
     * Returns the name of the ETL derived from file name
     * 
     * @return String the name of the ETL derived from file name
     */
    public String getETLName() {
        final String name = getFile().getName();
        final String etl = name.substring(0, name.length() - 4);
        return etl;
    }

    /**
     * Return true if this file is a custom file.
     * 
     * @param inFilePath
     * 
     * @return true if the file name has <code>custom</code> in the file path.
     *         name
     */
    public boolean checkCustom(final String inFilePath) {
        final File file = new File(inFilePath);
        boolean custom = false;
        if (file.exists()) {
            custom = file.getAbsolutePath().toLowerCase()
            .contains("custom" + File.separator);
            if (custom) {
                setThisAsCustom();
            }
        }
        return custom;
    }
}
