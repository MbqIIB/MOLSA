/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 *
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.ReportingDemoDataFile;
import curam.util.reporting.internal.tasks.model.ReportingFile;

import curam.util.type.*;

/**
 * Returns a list of files to be processed by the BI build environment.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class FileExplorerDemoData extends FileExplorer {
    /**
     * generic path structure for DDL files
     */
    private final String relativeDemoDataPath;

    /*
     * build in
     */
    private String fileset = "";

    /**
     * Object used to return the set of file that make up the DDL for a schema for
     * a component
     * 
     * @param inComponentName
     * @param targetDataBaseType
     * @param inReportingDir
     * @param inFileSet
     */
    public FileExplorerDemoData(
            final ComponentName inComponentName,
            final TargetDataBaseType targetDataBaseType,
            final String inReportingDir,
            final String inFileSet) {
        super(inComponentName, targetDataBaseType, inReportingDir);
        if (inFileSet != null) {
            fileset = inFileSet;
        }
        fileset = fileset.replace('/', File.separatorChar);
        /*
         * set up the template for static data files. the items in <> will be
         * replaced at runtime e.g. <Reporting>\components\<core>\data_manager\demo
         * data
         */
        relativeDemoDataPath = getReportingDir() + File.separator
        + DataWarehouseConstants.kComponentsDir + File.separator
        + kTemplateComponentDirectoryName + File.separator + fileset
        + File.separator;
        ;
    }

    @Override
    public List<ReportingFile> getFiles() throws Exception {
        final File customComponentPath = new File(relativeDemoDataPath.replaceAll(
                kTemplateComponentDirectoryName, getComponentName()
                .getCustomDirectoryName()));
        final File componentPath =
            new File(relativeDemoDataPath.replaceAll(
                    kTemplateComponentDirectoryName, getComponentName()
                    .getDirectoryName()));
        final List<ReportingFile> demoDataFiles = new ArrayList<ReportingFile>();
        if (!componentPath.exists()) {
            BILogger.info("Info:" + getComponentName().getComponentName()
                    + " has no files to process.");
        }
        final List<File> componentPaths = new ArrayList<File>();
        String dbDependenTFileName;
        componentPaths.add(componentPath);
        componentPaths.add(customComponentPath);
        int filesFound = 0;
        for (int j = 0; j < componentPaths.size(); j++) {
            final File files[] = ((File) componentPaths.get(j))
            .listFiles(new TemplateSQLFilter(".sql", false));
            boolean custom = false;
            if (j == 1) {
                custom = true;
            }
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    if (files[i].isFile()) {
                        dbDependenTFileName = files[i].getName();
                        filesFound++;
                        ReportingDemoDataFile ddFile = null;
                        if (dbDependenTFileName.indexOf(kOracleFile) != -1
                                && getTargetDataBaseType().isORACLE()) {
                            ddFile = new ReportingDemoDataFile(files[i].getCanonicalPath(),
                                    custom);
                            ddFile.setComponentName(getComponentName());
                            demoDataFiles.add(ddFile);
                            BILogger.info("RDBMS specific file " + dbDependenTFileName);
                        } else if (dbDependenTFileName.indexOf(kDB2File) != -1
                                && getTargetDataBaseType().isDB2()) {
                            ddFile = new ReportingDemoDataFile(files[i].getCanonicalPath(),
                                    custom);
                            ddFile.setComponentName(getComponentName());
                            demoDataFiles.add(ddFile);
                            BILogger.info("RDBMS specific file " + dbDependenTFileName);
                        } else {
                            ddFile = new ReportingDemoDataFile(files[i].getCanonicalPath(),
                                    custom);
                            ddFile.setComponentName(getComponentName());
                            demoDataFiles.add(ddFile);
                        }
                    }
                }
            }
        }
        return demoDataFiles;
    }

    // __________________________________________________________________________
    /**
     * Filter allowing only SQL template files.
     */
    static class TemplateSQLFilter implements FilenameFilter {
        private String filter = ".sql";

        boolean exact = false;

        public TemplateSQLFilter(final String inFilter, final boolean inExactMatch) {
            filter = inFilter;
            exact = inExactMatch;
        }

        public boolean accept(final File dir, final String name) {
            if (exact) {
                int begin = name.length() - filter.length();
                if (begin < 0) {
                    begin = 0;
                }
                // return true if this is an ETL tag file
                if (name.substring(begin).equalsIgnoreCase(filter)) {
                    return true;
                } else {
                    return false;
                }
            } else
                // return true if this is an ETL tag file
                if (name.endsWith(filter)) {
                    return true;
                } else {
                    return false;
                }
        }
    }
}
