/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.transformations.prepost.intf;

import java.sql.SQLException;
import curam.util.type.*;

/**
 * This package provides classes read and write to ETL control tables, and to
 * application tables to perform any tasks .
 *
 * This package contains the classes which provide the interface or entry point
 * between the database and the staging transformations. The interface
 * specification is enforced by the Oracle and DB2 call specifications, a call
 * spec exposes a Java methods top-level entry point to Oracle.
 *
 * @since Curam 5.2 SP1
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public interface ETLPostProcess {

  // ___________________________________________________________________________
  /**
   * Executes tasks required to complete an ETL
   *
   * @param inTargetTableName
   *          the target table being populated
   * @throws SQLException
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public void executePostProcess(String inTargetTableName) throws SQLException;
}
