/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.dao.control.base;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.dao.control.intf.ControlTable;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.type.*;

/**
 * This module provides functions to set the extract start time for and ETL
 * process, to set the last ETL date for an ETL process. Updates are made
 * default database
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public abstract class ControlTableImpl implements ControlTable {

    /**
     * the control table name.
     */
    private final ReportingDBType reportingDBType;

    /**
     * the control table name.
     */
    private final String kControlTableName = "ETLCONTROL";

    /**
     * SQL to get the ETL control table columns.
     */
    private String stSelectSQL;

    /**
     * SQL to get the ETL control table columns.
     */
    private String readAllSQL;

    /**
     * SQL to update the extract date for a target table.
     */
    private final String updateExtractDateSQL;

    /**
     * SQL to update the extract date for a target table.
     */
    private final String updateLastETLDateSQL;

    /**
     * SQL to update the last ETL date on all ETL control table rows.
     */
    private final String updateAllLastETLDateSQL;

    private final String controlTableName;

    /**
     * SQL to insert data into the table
     */
    private String insertSQL = "";



    // ___________________________________________________________________________
    /**
     * Create a new object to interface with the ETL control table.
     * 
     * @param inReportingDBType
     *          staging, central or data mart
     */
    public ControlTableImpl(final ReportingDBType inReportingDBType) {
        reportingDBType = inReportingDBType;
        controlTableName = inReportingDBType.addPrefix(kControlTableName);

        if (inReportingDBType.isStagingArea()) {
            readAllSQL = "select targettablename,last_etl_date,extracttime, truncateflag,extractfinish from "
                + controlTableName + " order by targettablename asc" ;
            stSelectSQL = "select targettablename,last_etl_date,extracttime, truncateflag,extractfinish from "
                + controlTableName  + " where targettablename=? ";
        } else {
            readAllSQL = "select targettablename, last_etl_date, extracttime,extractfinish from "
                + controlTableName + " order by targettablename asc" ;
            stSelectSQL = "select targettablename, last_etl_date, extracttime,extractfinish from "
                + controlTableName + " where targettablename=?" ;
        }

        updateExtractDateSQL = "update " + controlTableName
        + " set extracttime=? where targettablename=?";

        updateLastETLDateSQL = "update "
            + controlTableName
            + " set last_etl_date=extracttime,extractfinish=? where targettablename=?";

        updateAllLastETLDateSQL = "update " + controlTableName
        + " set last_etl_date=?";

        insertSQL = "insert into "
            + controlTableName
            + " (TARGETTABLENAME,LAST_ETL_DATE,EXTRACTTIME,TRUNCATEFLAG,EXTRACTFINISH)"
            + " values (?,?,?,?,?)";

    }

    /**
     * updates all rows in the control table - updates the last ETL date.
     * 
     * @param inDate
     *          the date from which to extract data from
     * @throws SQLException
     *           if database operation failed
     */
    public void setExtractionDate(final Date inDate) throws SQLException {

        PreparedStatement statement = null;
        boolean failed = false;
        Transaction transaction = null;

        try {

            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.prepareStatement(updateAllLastETLDateSQL);

            statement.setTimestamp(1, new Timestamp(inDate.getTime()));
            final int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated == 0) {

            }


        } catch (final Exception e) {
            failed = true;
            throw new SQLException(e.getMessage() + updateAllLastETLDateSQL);
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                } else {
                    transaction.commit();
                }
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Clears all data from a staging table.
     * 
     * @param inTargetTableName
     *          the staging table to be cleared of data
     * @throws SQLException
     *           if database operation failed
     */

    public void clearStagingTable(final String inTargetTableName)

    throws SQLException {
        Statement statement = null;
        Transaction transaction = null;
        boolean failed = false;

        try {
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.createStatement();
            statement.executeUpdate("delete from " + inTargetTableName);

        } catch (final Exception e) {
            failed = true;
            throw new SQLException("ETLControl:clearStagingTable:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                } else {
                    transaction.commit();
                }
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the extract start date time for an ETL process.
     * 
     * @param inTargetTableName
     *          the target table being populated
     * @throws SQLException
     *           if database operation failed
     */
    public Timestamp updateStartTime(final String inTargetTableName)
    throws SQLException {

        PreparedStatement statement = null;
        Transaction transaction = null;
        boolean failed = false;

        try {
            int rowsUpdated;
            final Timestamp now = new java.sql.Timestamp(System.currentTimeMillis());

            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            statement = transaction.getConnection().prepareStatement(
                    updateExtractDateSQL);
            statement.setTimestamp(1, now);
            statement.setString(2, inTargetTableName);
            rowsUpdated = statement.executeUpdate();

            if (rowsUpdated == 1) {

                final ProcessControl processControl = read(inTargetTableName);
                final Timestamp lastETLDate = processControl.getLastExtractionDate();

                return lastETLDate;
            } else {

                throw new Exception("ETLControl:setStartTime:Target table name <"
                        + inTargetTableName + "> not found in ETL control table "
                        + rowsUpdated);
            }

        } catch (final Exception e) {
            failed = true;
            throw new SQLException("Default db"
                    + DataWarehouseConstants.kDefaultDatabase
                    + "ETLControl:setStartTime:" + e.getMessage() + updateExtractDateSQL);
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                } else {
                    transaction.commit();
                }
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the last ETL date time.
     * 
     * @param inTargetTableName
     *          the target table being populated
     * @throws SQLException
     *           if database operation failed
     */

    public void updateLastETLDate(final String inTargetTableName)

    throws SQLException {
        PreparedStatement statement = null;
        boolean failed = false;
        Transaction transaction = null;

        try {

            // get a new connection
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();
            int rowsUpdated;

            final Timestamp finishDate = new java.sql.Timestamp(
                    System.currentTimeMillis());

            statement = connection.prepareStatement(updateLastETLDateSQL);

            statement.setTimestamp(1, finishDate);
            statement.setString(2, inTargetTableName);
            rowsUpdated = statement.executeUpdate();

            if (rowsUpdated == 1) {

            } else {
                throw new Exception("Target table name <" + inTargetTableName
                        + "> not found in ETL control table");
            }

        } catch (final Exception e) {
            failed = true;
            throw new SQLException("ETLControl:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                } else {
                    transaction.commit();
                }
            }
        }

    }

    // ___________________________________________________________________________
    /**
     * Reads all process control records with success indicators
     * 
     * @return List of type ProcessControlState
     * 
     * @throws SQLException
     *           if a database operation fails
     */

    public Map<String, ProcessControlState> readETLResults() throws SQLException {
        final List<ProcessControl> etlRecords = readAll();
        final Map<String, ProcessControlState> results = new Hashtable<String, ProcessControlState>();

        final Iterator<ProcessControl> controlRecords = etlRecords.iterator();
        ProcessControl record;
        ProcessControlState newObject;

        while (controlRecords.hasNext()) {
            record = (ProcessControl) controlRecords.next();
            newObject = new ProcessControlState(record);
            results.put(newObject.getTargetTableName(), newObject);
        }
        return results;
    }

    // ___________________________________________________________________________
    /**
     * Reads all process control records.
     * 
     * @return List control table records
     * 
     * @throws SQLException
     *           if a database operation fails
     */

    public List<ProcessControl> readAll() throws SQLException {

        ProcessControl processControl = null;
        PreparedStatement statement = null;
        final List<ProcessControl> controlRecords = new ArrayList<ProcessControl>();

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection.prepareStatement(readAllSQL);
            final ResultSet rs = statement.executeQuery();
            int nextColumnIndex;
            while (rs.next()) {
                nextColumnIndex = 1;
                String targetTablename;
                Timestamp lastExtractDate;
                Timestamp lastExtractStartDate;
                Timestamp lastExtractFinishDate;
                targetTablename = rs.getString(nextColumnIndex++);
                lastExtractDate = rs.getTimestamp(nextColumnIndex++);
                lastExtractStartDate = rs.getTimestamp(nextColumnIndex++);

                String truncateFlag = null;
                if (reportingDBType.isStagingArea()) {
                    truncateFlag = rs.getString(nextColumnIndex++);
                }
                lastExtractFinishDate = rs.getTimestamp(nextColumnIndex++);
                if (truncateFlag == null) {
                    truncateFlag = "N";
                }

                final boolean truncate = truncateFlag.equalsIgnoreCase("Y") ? true
                        : false;

                processControl = new ProcessControl(targetTablename, lastExtractDate,
                        (lastExtractStartDate == null ? null : lastExtractStartDate),
                        truncate, (lastExtractFinishDate == null ? null
                                : lastExtractFinishDate));

                processControl.setControlTableName(controlTableName);
                controlRecords.add(processControl);
            }

            return controlRecords;

        } catch (final Exception e) {
            throw new SQLException("ControlTableImpl:readAll:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // ___________________________________________________________________________
    /**
     * Returns the number of rows in a table.
     * 
     * @return int number of rows of data
     * 
     * @throws SQLException
     *           if a database operation fails
     */

    public int getRowsInTable(final String inTableName) throws SQLException {

        PreparedStatement statement = null;
        final Transaction transaction = TransactionFactory
        .getTransaction(DataWarehouseConstants.kDefaultDatabase);
        final Connection connection = transaction.getConnection();
        try {
            final String sqlRead = "select count(*) from " + inTableName;

            statement = connection.prepareStatement(sqlRead);

            final ResultSet rs = statement.executeQuery();
            int rowCount = 0;
            if (rs.next()) {
                rowCount = rs.getInt(1);
            }

            if (rowCount == 0) {
            }
            return rowCount;

        } catch (final Exception e) {
            throw new SQLException("ControlTableImpl:getRowsInTable:"
                    + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // ___________________________________________________________________________
    /**
     * Returns the control table name.
     * 
     * @return String
     */
    public String getControlTableName() {
        return controlTableName;
    }

    // ___________________________________________________________________________
    /**
     * Reads a process control record for a given target table name.
     * 
     * @param inTargetTable
     *          the target table name
     * @return ProcessControl the process control data for the target table
     * 
     * @throws SQLException
     *           if a database operation fails
     */

    public ProcessControl read(final String inTargetTable) throws SQLException {

        ProcessControl processControl = null;
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection.prepareStatement(stSelectSQL);
            statement.setString(1, inTargetTable);
            final ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                String targetTablename;
                Timestamp lastExtractDate;
                Timestamp lastExtractStartDate;
                Timestamp lastExtractFinishDate;
                int nextColumnIndex = 1;
                targetTablename = rs.getString(nextColumnIndex++);
                lastExtractDate = rs.getTimestamp(nextColumnIndex++);
                lastExtractStartDate = rs.getTimestamp(nextColumnIndex++);
                String truncateFlag = null;
                if (reportingDBType.isStagingArea()) {
                    truncateFlag = rs.getString(nextColumnIndex++);
                }
                lastExtractFinishDate = rs.getTimestamp(nextColumnIndex++);
                if (truncateFlag == null) {
                    truncateFlag = "false";
                }

                final boolean truncate = truncateFlag.equalsIgnoreCase("Y") ? true
                        : false;

                processControl = new ProcessControl(targetTablename, lastExtractDate,
                        lastExtractStartDate == null ? null : lastExtractStartDate,
                                truncate, lastExtractFinishDate == null ? null
                                        : lastExtractFinishDate);
                processControl.setControlTableName(controlTableName);
                return processControl;
            } else {
                throw new Exception("Target table name <" + inTargetTable
                        + "> not found in ETL control table");
            }

        } catch (final Exception e) {
            throw new SQLException("ControlTableImpl:read:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

    }

    // ___________________________________________________________________________
    /**
     * Inserts a process control record for a given target table name.
     * 
     * @param inProcessControl
     *          the record to insert
     * 
     * @throws SQLException
     *           if a database operation fails
     */
    public void insertData(final ProcessControl inProcessControl) throws SQLException {
        PreparedStatement statement = null;

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            statement = connection.prepareStatement(insertSQL);
            statement.setString(1, inProcessControl.getTargetTableName());
            statement.setTimestamp(2, inProcessControl.getLastExtractionDate());
            if (inProcessControl.getLastExtractStartDate() == null) {
                statement.setNull(3, java.sql.Types.TIMESTAMP);
            } else {
                statement.setTimestamp(3, inProcessControl.getLastExtractStartDate());
            }
            statement.setString(4, "N");
            if (inProcessControl.getLastExtractFinishDate() == null) {
                statement.setNull(5, java.sql.Types.TIMESTAMP);
            } else {
                statement.setTimestamp(5, inProcessControl.getLastExtractFinishDate());
            }

            statement.setNull(5, java.sql.Types.TIMESTAMP);

            final int rowsInserted = statement.executeUpdate();
            if (rowsInserted != 1) {
                throw new Exception(
                        "insertData: failed to insert ETL control test entry:"
                        + inProcessControl);
            } else if (rowsInserted == 1) {
            }

        } catch (final Exception e) {
            throw new SQLException("insertData:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }

        }
    }
}
