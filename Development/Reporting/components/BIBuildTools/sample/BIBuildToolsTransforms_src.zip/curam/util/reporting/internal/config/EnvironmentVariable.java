/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.config;

/**
 *
 * This class is used to get the value of an environment variable, the intention
 * is the limit the use of the API call System.getenv, Please note that "GETENV"
 * is not supported for Java 1.4.
 *
 * All access to environment variables is through this class
 *
 * @see curam.util.reporting.internal.config.PropertiesCache
 *
 *
 */
public class EnvironmentVariable {

    /**
     * does this value represent a file on disk
     */
    private boolean environmentVariableNotFound = false;

    /**
     * does this value represent a file on disk
     */
    private boolean isFile = true;

    /*
     * the environment variable name
     */
    private String name = "";

    /*
     * the environment variable value
     */
    protected String value = "";

    /*
     * has the name and value been validated
     */
    protected boolean validated = false;

    /**
     * This is a copy constructor.
     *
     * @param inValue
     *          the environment to be copied
     */
    public EnvironmentVariable(final EnvironmentVariable inValue) {
        this.environmentVariableNotFound = inValue.environmentVariableNotFound;
        this.isFile = inValue.isFile;
        this.name = inValue.getName();
        setValue(inValue.getValue());
        this.validated = inValue.validated;
    }

    /**
     * Creates and environment variable object given the name and value.
     *
     * @param inName
     *          the environment variable name, must not be null
     * @param inValue
     *          the environment variable value
     */
    public EnvironmentVariable(final String inName, final String inValue) {
        if (inName != null) {
            name = inName;
        }
        if (inName != null) {
            setValue(inValue);
        }
    }

    /**
     * Creates and environment variable object, reads the value from the system
     * environment variables.
     *
     * @param the
     *          environment variable name
     */
    protected EnvironmentVariable(final String inEnvironmentVariable) {
        super();

        this.name = inEnvironmentVariable != null ? inEnvironmentVariable.trim()
                : "";
        try {
            final String version = System.getProperty("java.version");

            // GETENV is not available in 1.4
            // also when running inside the RDBMS JVM we can
            // ignore the exception as there is no loss of feature
            if (version.indexOf("1.4") == -1) {
                // only for java 1.4 for Oracle
                try {
                    final String tempValue = System.getenv(name);
                    if (tempValue == null) {
                        environmentVariableNotFound = true;
                    }
                    setValue(tempValue);
                } catch (final java.lang.RuntimeException e) {

                }
            } else {
                environmentVariableNotFound = true;
                setValue(name);
            }
        } catch (final java.lang.Error e) {
            e.printStackTrace();
            e.printStackTrace();
        } catch (final java.lang.SecurityException e) {
            e.printStackTrace();;
            e.printStackTrace();;
        }

    }

    /**
     * Sets this objects validation status to true
     */
    public void validated() {
        validated = true;
    }

    /**
     * Sets this objects validation status to false
     */
    public void inValidate() {
        validated = false;
    }

    /**
     *
     * @return returns validation status of this object, the objects name and
     *         value attributes have been validate or they have not been
     *         validated.
     */
    public boolean isValidated() {
        return validated;
    }

    /**
     * @return returns true of the name is valid, not null and it has a length
     *         greater than zero.
     */
    public boolean isValidName() {
        if (name == null || name.length() == 0) {
            return false;
        }

        return true;
    }

    /**
     * @return returns true of the value is valid, not null and it has a length
     *         greater than zero.
     */
    public boolean isValidValue() {
        if (value == null || value.length() == 0 || environmentVariableNotFound) {
            return false;
        }

        return true;
    }

    /**
     * @return returns the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return returns the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @return returns the name and value in the format name=value
     */
    @Override
    public String toString() {
        return name + "=" + value;
    }

    /**
     *
     * @param inValue
     *          set the value if the inValue is not null
     */
    protected void setValue(final String inValue) {
        if (inValue != null) {
            value = inValue;
        }
    }

    /**
     * Sets the file attributes to false, the value attribute does not represent a
     * file
     */
    public void notAFile() {
        isFile = false;
    }

    /**
     * @return returns true if the value attribute represents a file
     */
    public boolean isFile() {
        return isFile;
    }

    /**
     * @return returns true if the environment variable defined in the system
     */
    public boolean environmentVariableFound() {
        return environmentVariableNotFound;
    }

    /**
     * hash code implementation
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

    /**
     * Equals implementation, equality is based on the name attribute
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof EnvironmentVariable)) {
            return false;
        }
        final EnvironmentVariable other = (EnvironmentVariable) obj;
        if (name == null) {
            if (other.name != null) {
                return false;
            }
        } else if (!name.equals(other.name)) {
            return false;
        }
        return true;
    }

    /**
     * Returns a Boolean with a value represented by the specified string. The
     * boolean returned represents a true value if the object is not null and is
     * equal, ignoring case, to the string "true".
     *
     * @return true if the value is equal to <code>true</code>, otherwise false
     */
    public boolean asBoolean() {
        return Boolean.valueOf(getValue()).booleanValue();
    }
}
