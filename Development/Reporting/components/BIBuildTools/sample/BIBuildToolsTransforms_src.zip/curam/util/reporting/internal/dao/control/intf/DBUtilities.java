/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.dao.control.intf;

import java.sql.SQLException;
import java.util.List;

import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.dao.control.base.ProcessControlState;

import curam.util.type.*;

/**
 * This module is a interface for class which update ETL infrastructure tables.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public interface DBUtilities {

  // ___________________________________________________________________________
  /**
   * Reads all process control records with success indicators
   * 
   * @return List of type ProcessControlState
   * 
   * @throws SQLException
   *           if a database operation fails
   */

  public List<ProcessControlState> readETLResults() throws SQLException;

  // ___________________________________________________________________________
  /**
   * Returns the number of rows in a table.
   * 
   * @param inTableName
   *          the table name
   * @return int number of rows of data
   * 
   * @throws SQLException
   *           if a database operation fails
   */

  public int getRowsInTable(String inTableName) throws SQLException;

  // ___________________________________________________________________________
  /**
   * Deletes all rows from a table.
   * 
   * @param inTableName
   *          the table name
   * 
   * @throws SQLException
   *           if a database operation fails
   */

  public void truncateTable(String inTableName) throws SQLException;

  // ___________________________________________________________________________
  /**
   * Reads all table names for a reporting schema.
   * 
   * @param inSchema
   *          the logical schema name
   * 
   * @return List of String
   * 
   * @throws SQLException
   *           if a database operation fails
   */

  public List<String> getAllTablesNamesInSchema(ReportingDBType inSchema)
      throws SQLException;
}
