/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.persistence.connectionpool;

import java.sql.Connection;
import java.sql.SQLException;

import curam.util.reporting.internal.config.*;

import curam.util.type.*;

/**
 * This module persistence class for both the build environment and
 * transformations.
 */
@AccessLevel(AccessLevelType.INTERNAL)
public interface ConnectionPool {

  /**
   * the first connection in the pool
   */
  public final int firstElement = 0;

  // ___________________________________________________________________________
  /**
   * Returns the connections properties
   * 
   * @return ConnectionProperties properties
   */
  public ConnectionProperties getConnectionProperties();

  // ___________________________________________________________________________
  /**
   * Returns a database connection
   * 
   * @return Connection the connection
   * @throws SQLException
   */
  public Connection getConnection() throws SQLException;

  // ___________________________________________________________________________
  /**
   * Returns a database connection
   * 
   * @param inTimeOut
   *          the time to wait for the connection
   * 
   * @return Connection the transaction to work with
   * @throws SQLException
   */
  public Connection getConnection(long inTimeOut) throws SQLException;

  // ___________________________________________________________________________
  /**
   * Returns a read only database connection
   * 
   * @param inDataSourceName
   *          the data store to establish a connection with
   * 
   * @return Connection the transaction to work with
   * @throws SQLException
   */
  public Connection getReadOnlyConnection(String inDataSourceName)
      throws SQLException;

  // ___________________________________________________________________________
  /**
   * Returns a connection to the pool
   * 
   * @param inConnection
   *          the connection
   */
  public void returnConnection(Connection inConnection);

  // ___________________________________________________________________________
  /**
   * Releases any open resources
   */
  public void releaseResources();

}
