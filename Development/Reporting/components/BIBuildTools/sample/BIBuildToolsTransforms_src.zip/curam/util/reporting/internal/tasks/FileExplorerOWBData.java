/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.OWBFilesSelected;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.reporting.internal.tasks.model.ReportingOWBFile;

import curam.util.type.*;

/**
 * Returns a list of files to be processed by the BI build environment.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class FileExplorerOWBData extends FileExplorer {
    /**
     * generic path structure for DDL files
     */
    String relativeOWBPath;

    /**
     * the files to be included in the search
     */
    OWBFilesSelected owbFilesSelected;

    /**
     * Object used to return the set of file that make up the DDL for a schema for
     * a component
     * 
     * @param inComponentName
     * @param targetDataBaseType
     * @param inReportingDir
     * @param inOWBFilesSelected
     */
    public FileExplorerOWBData(
            final ComponentName inComponentName,
            final TargetDataBaseType targetDataBaseType,
            final String inReportingDir,
            final OWBFilesSelected inOWBFilesSelected) {
        super(inComponentName, targetDataBaseType, inReportingDir);
        owbFilesSelected = inOWBFilesSelected;
        /*
         * set up the template for static data files. the items in <> will be
         * replaced at runtime e.g. <Reporting>\components\<core>\data_manager\
         */
        relativeOWBPath = getReportingDir() + File.separator
        + DataWarehouseConstants.kComponentsDir + File.separator
        + kTemplateComponentDirectoryName + File.separator + "etl"
        + File.separator + "oracle" + File.separator;
    }

    @Override
    public List<ReportingFile> getFiles() throws Exception {
        final File customComponentPath = new File(relativeOWBPath.replaceAll(
                kTemplateComponentDirectoryName, getComponentName()
                .getCustomDirectoryName()));
        final File componentPath =
            new File(relativeOWBPath.replaceAll(
                    kTemplateComponentDirectoryName, getComponentName()
                    .getDirectoryName()));
        final List<ReportingFile> staticDataFiles = new ArrayList<ReportingFile>();
        if (!componentPath.exists()) {
            BILogger.debug(componentPath + " is not available");
        }
        final List<File> componentPaths = new ArrayList<File>();
        componentPaths.add(componentPath);
        componentPaths.add(customComponentPath);
        for (int j = 0; j < componentPaths.size(); j++) {
            final ReportingOWBFile file = new ReportingOWBFile(componentPaths.get(j)
                    .getAbsolutePath(), false);
            file.checkCustom(componentPaths.get(j).getAbsolutePath());



            if (owbFilesSelected.common) {
                if (!owbFilesSelected.schemasOnly) {
                    staticDataFiles.addAll(getEnvOWBFiles((File) componentPaths.get(j)));
                    BILogger.debug("add file "
                            + file.getFile().getAbsolutePath() + "...");
                }
            }
            if (owbFilesSelected.source) {
                staticDataFiles.addAll(getEnvOWBFiles(new File(((File) componentPaths
                        .get(j)), "source")));
                BILogger.debug("add file "
                        + file.getFile().getAbsolutePath() + "...");

            }
            if (owbFilesSelected.staging) {
                staticDataFiles.addAll(getEnvOWBFiles(new File(((File) componentPaths
                        .get(j)), "staging")));
                BILogger.debug("add file "
                        + file.getFile().getAbsolutePath() + "...");
            }
            if (owbFilesSelected.central) {
                staticDataFiles.addAll(getEnvOWBFiles(new File(((File) componentPaths
                        .get(j)), "central")));
                BILogger.debug("add file "
                        + file.getFile().getAbsolutePath() + "...");

            }
            if (owbFilesSelected.datamart) {
                staticDataFiles.addAll(getEnvOWBFiles(new File(((File) componentPaths
                        .get(j)), "datamarts")));
                BILogger.debug("add file "
                        + file.getFile().getAbsolutePath() + "...");

            }
        }
        return staticDataFiles;
    }

    public List<ReportingFile> getEnvOWBFiles(final File inPath) throws IOException {
        // add schema files for import
        String fileName;
        final List<ReportingFile> metaDataFiles = new ArrayList<ReportingFile>();
        ReportingOWBFile file;
        File files[] = inPath.listFiles();
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                fileName = files[i].getName();
                if (files[i].isFile() && fileName.endsWith("mdo")) {
                    file = new ReportingOWBFile(files[i].getAbsolutePath(), false);
                    file.checkCustom(files[i].getAbsolutePath());
                    file.setComponentName(getComponentName());
                    if (file.isOWBSchemaFile()) {
                        // its a schema file
                        metaDataFiles.add(0, file);
                    } else {
                        if (!owbFilesSelected.schemasOnly) {
                            metaDataFiles.add(file);
                        } else {
                            // only list the OWB meta data files that contain schema data
                        }
                    }
                }
            }
        }
        // look for any files that are version dependent
        files = (new File(inPath, "versions")).listFiles();
        if (files != null) {
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    fileName = files[i].getName();
                    if (files[i].isFile()
                            && fileName.startsWith(owbFilesSelected.owbVersion)
                            && fileName.endsWith("mdo")) {
                        file = new ReportingOWBFile(files[i].getAbsolutePath(), false);
                        file.checkCustom(files[i].getAbsolutePath());
                        file.setComponentName(getComponentName());
                        if (file.isOWBSchemaFile()) {
                            // its a schema file
                            metaDataFiles.add(0, file);
                        } else {
                            if (!owbFilesSelected.schemasOnly) {
                                metaDataFiles.add(file);
                            } else {
                                // only list the OWB meta data files that contain schema data
                            }
                        }
                    } else {
                    }
                }
            }
        }
        return metaDataFiles;
    }
}
