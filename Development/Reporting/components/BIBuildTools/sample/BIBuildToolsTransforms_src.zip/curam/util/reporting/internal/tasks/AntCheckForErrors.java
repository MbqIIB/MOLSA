/*
 * Licensed Materials - Property of IBM Copyright IBM Corporation 2012. All
 * Rights Reserved. US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd. All rights reserved. This software is the
 * confidential and proprietary information of Curam Software, Ltd.
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Vector;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.tasks.model.ReportingProperty;

/**
 * This module checks a log file for errors, throwing a build exception if
 * errors are found. The errors to search for are specified as nested elements
 * within the build file, as are the errors to ignore.
 */
public class AntCheckForErrors extends Task {
  /**
   * errors.
   */
  private final Vector < ReportingProperty > errors =
      new Vector < ReportingProperty >();

  /**
   * filters.
   */
  private final Vector < ReportingProperty > filters =
      new Vector < ReportingProperty >();

  /**
   * a full path to the output directory.
   */
  private String logFile;

  /**
   * build error property name.
   */
  private String errorPropertyName = "build.error.found";

  /**
   * enable quite mode.
   */
  private boolean verbose = false;

  /**
   * ignore all issues.
   */
  private boolean ignore = false;

  /**
   * Add the default errors to the search mechanism, the defaults search errors
   * are.
   * <ul>
   * <li><code>is not recognized as an internal or external command</code>
   * <li><code>build failed</code>
   * <li><code>does not exist in the project</code>
   * <li><code>build failed</code>
   * <li><code>.xml</code>
   * </ul>
   * <p>
   */
  private void addStandardBuildErrors() {
    ReportingProperty error = createError();
    error.setValue("is not recognized as an internal or external command");
    error = createError();
    error.setValue("build failed");
    error = createError();
    error.setValue("does not exist in the project");
    error = createError();
    error.setValue(".xml:");
  }

  // ___________________________________________________________________________
  /**
   * Invocation point for the ant task.
   * 
   * @throws BuildException if the build tasks fails or if critical errors were
   *           found in the log
   */
  @Override
  public void execute() throws BuildException {
    boolean containsErrors = false;
    String firstError = "";
    try {
      if (verbose) {
        System.out.println("log file name " + logFile);
        System.out.println("error property name " + errorPropertyName);
        System.out.println("Filters " + filters);
        System.out.println("Errors " + errors);
        System.out.println("ignore= " + ignore);
      }
      addStandardBuildErrors();
      final File log = new File(logFile);
      final File filteredLog = new File(logFile + ".filtered");
      if (!log.exists()) {
        System.out
            .println("log file does not exist " + log.getAbsolutePath());
        return;
      }
      filteredLog.delete();
      filteredLog.createNewFile();
      if (verbose) {
        System.out.println("Creating  " + filteredLog.getAbsolutePath());
      }
      ReportingProperty token = null;
      BufferedReader in = new BufferedReader(new FileReader(log));
      final Charset utf = Charset.forName("UTF-8");
      final BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
          new FileOutputStream(filteredLog, false), utf));
      // Transfer bytes from in to out
      String line;
      while ( (line = in.readLine()) != null) {
        line = line.toLowerCase();
        boolean isFiltered = false;
        line = line.toLowerCase();
        if (line.trim().length() > 0) {
          // filter out lines we do not care about
          for (final Iterator < ReportingProperty > it = filters.iterator(); it
              .hasNext();) {
            token = it.next();
            try {
              if (line.contains(token.getValue().toLowerCase()) == true) {
                isFiltered = true;
              }
            } catch (final NullPointerException e) {
              // ignore as can only happen if the filter is null
            }
          }
          if (isFiltered == false) {
            out.write(line);
            out.write(System.getProperty("line.separator"));
          }
        }
      }
      out.newLine();
      out.flush();
      out.close();
      in.close();
      in = new BufferedReader(new FileReader(filteredLog));
      while ( (line = in.readLine()) != null) {
        line = line.toLowerCase();
        boolean lineError = false;
        if (line.trim().length() > 0) {
          // filter out lines we do not care about
          for (final Iterator < ReportingProperty > it = errors.iterator(); it
              .hasNext();) {
            token = it.next();
            try {
              if (line.contains(token.getValue().toLowerCase()) == true) {
                lineError = true;
                firstError = line;
                containsErrors = true;
              } else {
              }
            } catch (final NullPointerException e) {
              // ignore as can only happen if the filter is null
            }
          }
          if (lineError == true) {
            System.out.println("Error:" + line);
          }
        }
      }
      in.close();
    } catch (final Exception ex) {
      System.out
          .println("concatenateGrantFilesToDirectory:erorr:no file found "
              + ex.getMessage());
    } finally {
      final Project antProject = getProject();
      if (antProject != null) {
        if (ignore) {
          System.out
              .println("ignore property set," + "not checking for errors");
          ;
          return;
        }
        if (containsErrors == true) {
          throw new BuildException("error:" + firstError);
        } else {
          ;
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Allows the error check to find errors and not throw a build exception.
   * 
   * @param inName ignores errors if the string is equal to <code>true</code>,
   *          case sensitivity is ignored.
   */
  public void setIgnore(final String inName) {
    if (Boolean.parseBoolean(inName) == true) {
      ignore = true;
    }
  }

  // ___________________________________________________________________________
  /**
   * The log file to process for errors.
   * 
   * @param inLogFile - the full path and file name of the log file. This is the
   *          file that will be checked for errors.
   */
  public void setLogFile(final String inLogFile) {
    logFile = inLogFile;
  }

  // ___________________________________________________________________________
  /**
   * Allows the user to define the error property to set in the event of an
   * error being found. This is an option attribute on the task, the default
   * error property is <code>build.error.found</code>, case sensitivity is
   * ignored
   * 
   * @param inName the error property name.
   */
  public void setErrorProperty(final String inName) {
    if (inName != null && inName.length() > 0) {
      errorPropertyName = inName;
    }
  }

  // ___________________________________________________________________________
  /**
   * Sets verbose output to true.
   * 
   * @param inName sets verbose output to true if the string is equal to
   *          <code>true</code>, case sensitivity is ignored.
   */
  public void setVerbose(final String inName) {
    if (Boolean.parseBoolean(inName) == true) {
      verbose = true;
    }
  }

  // ___________________________________________________________________________
  /**
   * Adds an error to the list of errors to ignore for.
   * 
   * @return ReportingProperty the error name and error text to ignore.
   */
  public ReportingProperty createIgnore() {
    final ReportingProperty property = new ReportingProperty();
    filters.add(property);
    return property;
  }

  // ___________________________________________________________________________
  /**
   * Adds an error to the list of errors to check for.
   * 
   * @return ReportingProperty the error name and error text to search for.
   */
  public ReportingProperty createError() {
    final ReportingProperty property = new ReportingProperty();
    errors.add(property);
    return property;
  }
}
