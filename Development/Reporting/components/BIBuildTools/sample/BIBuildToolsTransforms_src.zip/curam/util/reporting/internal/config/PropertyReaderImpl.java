/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2010 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.Properties;

/**
 * A reader to retrieve application properties from disk
 * 
 * 
 */

class PropertyReaderImpl implements PropertyReader {

    /**
     * the application properties read from the property file
     */
    private Properties properties;

    /**
     * was the property file loaded successfully
     */
    private boolean loaded;

    // ___________________________________________________________________________
    /**
     * Creates a new connection property reader and loads any properties
     * 
     * @param String
     *          the path the property file
     */
    PropertyReaderImpl(final String inPropertiesFile) throws FileNotFoundException {
        this.load(inPropertiesFile);
    }

    // ___________________________________________________________________________
    /**
     * Creates a new connection property reader, this constructor locates the
     * property file on the class path, the first one found
     * 
     */
    PropertyReaderImpl() throws FileNotFoundException {
        this.load();
    }

    // ___________________________________________________________________________
    /**
     * Returns all connection properties
     * 
     * @return ConnectionProperties
     */

    public ConnectionProperties[] getProperties() throws Exception {

        final ConnectionProperties[] properties = new ConnectionProperties[6];

        properties[0] = getConnectionProperties(DataWarehouseConstants.kStagingDatabase);
        properties[1] = getConnectionProperties(DataWarehouseConstants.kCentralDatabase);
        properties[2] = getConnectionProperties(DataWarehouseConstants.kCoreDataMartDatabase);
        properties[3] = getConnectionProperties(DataWarehouseConstants.kDataMartDemoDataDatabase);
        properties[4] = getConnectionProperties(DataWarehouseConstants.kCuramSourceDatabase);
        properties[5] = getConnectionProperties(DataWarehouseConstants.kISWExecutionDatabase);
        return properties;
    }

    // ___________________________________________________________________________
    /**
     * Returns a demo data database connection properties
     * 
     * @return ConnectionProperties
     * @throws Exception
     */
    public ConnectionProperties getDataMartDemoDataProperties() throws Exception {

        return getConnectionProperties(DataWarehouseConstants.kDataMartDemoDataDatabase);
    }

    // ___________________________________________________________________________
    /**
     * Returns the connection properties for the a given schema
     * 
     * @return ConnectionProperties the connection properties, property values
     *         will be empty if no entries existed on disk
     */

    public ConnectionProperties getConnectionProperties(final String inDatabase)
    throws Exception {

        // the database name
        final String databaseName = getValue(inDatabase
                + DataWarehouseConstants.kDatabaseName);

        // the database name
        final String appServerDataSourceName = getValue(inDatabase
                + DataWarehouseConstants.kJNDIDataSourceName);

        // the database user identity
        final String userid = getValue(inDatabase + DataWarehouseConstants.kDBUserName);

        // the database password
        String password = getValue(inDatabase + DataWarehouseConstants.kDBPassword);

        // String clearPassword =
        // EncryptionUtil.decryptDBPasswordDefaulted(password);
        final String clearPassword = getPhrase(password);

        password = clearPassword;

        // may be defined via -D JDBC setting
        final String driverName = "";
        // getValue(kJDBCDriversProperty);

        // the RDBMS, ORACLE or DB2
        final String databaseType = getValue(DataWarehouseConstants.kDatabaseType);

        final String databaseTypeOverRide = getValue(inDatabase
                + DataWarehouseConstants.kDatabaseTypeOverride);

        // String serviceName = getValue(DataWarehouseConstants.kServiceName);
        TargetDataBaseType targetDataBaseType = null;

        // the database URL
        String url = "";
        String alternateURL = "";
        targetDataBaseType = new TargetDataBaseType(databaseType);
        try {
            final TargetDataBaseType targetDataBaseTypeOverride = new TargetDataBaseType(
                    databaseTypeOverRide);
            targetDataBaseType = targetDataBaseTypeOverride;

        } catch (final RuntimeException e) {
            ;
        }

        // build the URL based on the database type
        if (targetDataBaseType.isORACLE()) {
            // URL format is for net driver is
            // JDBC is upper case to appease spell checker
            // "JDBC:oracle:thin:@SERVER:PORT:DATABASE"
            final String urlOraclePrefix = "jdbc:oracle:thin:@";
            // not using the service name
            url = urlOraclePrefix
            + getValue(inDatabase + DataWarehouseConstants.kDBServer) + ":"
            + getValue(inDatabase + DataWarehouseConstants.kDBPort) + "/"
            + databaseName;

            alternateURL = urlOraclePrefix
            + getValue(inDatabase + DataWarehouseConstants.kDBServer) + ":"
            + getValue(inDatabase + DataWarehouseConstants.kDBPort) + ":"
            + getValue(inDatabase + DataWarehouseConstants.kOracleSID);

        } else if (targetDataBaseType.isDB2()) {
            // URL format for type 4 driver is
            // JDBC is upper case to appease spell checker
            // "JDBC:db2://SERVER:port/DATABASE"
            final String urlDB2Prefix = "jdbc:db2://";

            url = urlDB2Prefix
            + getValue(inDatabase + DataWarehouseConstants.kDBServer)
            .toUpperCase() + ":"
            + getValue(inDatabase + DataWarehouseConstants.kDBPort) + "/"
            + databaseName.toUpperCase();
        }

        final ConnectionProperties connectionProperties = new ConnectionProperties(
                inDatabase, url, userid, password, driverName, targetDataBaseType, 2);
        connectionProperties.setAlternateURL(alternateURL);
        connectionProperties.setAppServerDataSourceName(appServerDataSourceName);
        connectionProperties.setDatabaseName(databaseName);
        connectionProperties.setDatabaseName(databaseName);
        return connectionProperties;

    }

    // ___________________________________________________________________________
    /**
     * Returns the target database environment
     * 
     * @return TargetDatabaseType returns the target RDBMS environment
     */

    public TargetDataBaseType getTargetEnvironment() {
        return new TargetDataBaseType(
                getValue(DataWarehouseConstants.kDatabaseType));

    }

    // ___________________________________________________________________________
    /**
     * Returns the target technology stack brand
     * 
     * @return TechnologyStackBrand returns InfoSphere or OWB
     */

    public TechnologyStackBrand getTechStackVendor() {
        TechnologyStackBrand brand = TechnologyStackBrand.Infosphere;

        if (DataWarehouseConstants.kTechStackVendorOracle
                .equalsIgnoreCase(getValue(DataWarehouseConstants.kTechStackProductName))) {
            brand = TechnologyStackBrand.Oracle;
        }
        return brand;
    }

    // ___________________________________________________________________________
    /**
     * Returns a property value
     * 
     * @param inKey
     *          the property key
     * 
     * @return the property value, an empty string is returned if the property
     *         cannot be found
     */

    public String getValue(final String inKey) {
        if (loaded) {
            final String value = properties.getProperty(inKey);
            return value == null ? "" : value;
        } else {
            return "";
        }

    }

    // ___________________________________________________________________________
    /**
     * Returns all properties
     * 
     * @return Properties all properties
     */

    public Properties getAll() {
        if (loaded) {
            return properties;
        } else {
            return new Properties();
        }

    }

    // ___________________________________________________________________________
    /**
     * Reads the contents of a properties file
     * 
     * @param String
     *          pathAndFileName, full qualified file name
     */
    private void load(final String inPathAndFileName) throws IllegalArgumentException,
    FileNotFoundException {

        final File bootstrapProperties = new File(inPathAndFileName);

        properties = null;
        properties = new java.util.Properties();

        if (inPathAndFileName == null || inPathAndFileName.length() == 0) {
            final IllegalArgumentException e = new IllegalArgumentException(
            "PropertyReaderImpl:load:pathAndFileName cannot be null or of length zero");
            throw e;
        }

        if (!bootstrapProperties.exists()) {
            final FileNotFoundException e = new FileNotFoundException(inPathAndFileName
                    + " does not exist");
            throw e;
        }
        if (!bootstrapProperties.isFile()) {
            final FileNotFoundException e = new FileNotFoundException(inPathAndFileName
                    + " is a directory not a file");
            throw e;
        }

        if (!bootstrapProperties.canRead()) {
            final FileNotFoundException e = new FileNotFoundException(inPathAndFileName
                    + " is a not a readable file");
            throw e;
        }
        try {
            final FileInputStream fis = new FileInputStream(bootstrapProperties);
            properties.load(fis);

        } catch (final IOException e) {
            final FileNotFoundException ex = new FileNotFoundException(
                    "Error reading bootstrap properties file, " + e.getMessage());
            throw ex;
        }
        try {
            final File applicationProperties = new File(
                    bootstrapProperties.getParentFile(),
                    DataWarehouseConstants.kApplicationPropertyFileName);
            final FileInputStream fis = new FileInputStream(applicationProperties);
            properties.load(fis);
            loaded = true;
        } catch (final IOException e) {
            final FileNotFoundException ex = new FileNotFoundException(
                    "Error reading application properties file, " + e.getMessage());
            throw ex;
        }
    }

    // ___________________________________________________________________________
    /**
     * Locates and reads the contents of a the application properties file
     * 
     */
    private void load() throws IllegalArgumentException, FileNotFoundException {

        properties = null;
        properties = new java.util.Properties();
        try {
            // try the parent class loader
            InputStream fis = ClassLoader
            .getSystemResourceAsStream(DataWarehouseConstants.kBootStrapPropertyFileName);

            if (fis == null) {
                // try the child class loader
                fis = this
                .getClass()
                .getClassLoader()
                .getResourceAsStream(
                        DataWarehouseConstants.kBootStrapPropertyFileName);
            }

            // property file was not found on the class path
            if (fis == null) {
                throw new FileNotFoundException(
                        DataWarehouseConstants.kBootStrapPropertyFileName
                        + " could not be found on classpath, put the property file location on the classpath.");
            }
            properties.load(fis);
            fis.close();
            loaded = true;
        } catch (final IOException e) {
            final FileNotFoundException ex = new FileNotFoundException(
                    "Error reading property file, " + e.getMessage());
            throw ex;
        }
        try {
            InputStream fis = ClassLoader
            .getSystemResourceAsStream(DataWarehouseConstants.kApplicationPropertyFileName);
            // property file was not found on the class path
            if (fis == null) {
                // try the child class loader
                fis = this
                .getClass()
                .getClassLoader()
                .getResourceAsStream(
                        DataWarehouseConstants.kApplicationPropertyFileName);
            }

            if (fis == null) {
                throw new FileNotFoundException(
                        DataWarehouseConstants.kApplicationPropertyFileName
                        + " could not be found on classpath, put the property file location on the classpath.");
            }
            properties.load(fis);
            fis.close();
            loaded = true;
        } catch (final IOException e) {
            final FileNotFoundException ex = new FileNotFoundException(
                    "Error reading property file, " + e.getMessage());
            throw ex;
        }

    }

    // ___________________________________________________________________________
    /**
     * Returns a description of the connection properties
     * 
     * @return String
     */

    public String toString() {
        return properties.toString();
    }

    public Hashtable<String, EnvironmentVariable> getEnvironmentVariables() {
        final String tokens = properties
        .getProperty(DataWarehouseConstants.kEnvironmentVariables);
        final Hashtable<String, EnvironmentVariable> systemProperties = new Hashtable<String, EnvironmentVariable>();
        if (tokens != null) {
            final String allTokens[] = tokens.split(",");

            EnvironmentVariable env;
            for (int i = 0; i < allTokens.length; i++) {
                env = new EnvironmentVariable(allTokens[i]);
                if (env.isValidName()) {
                    systemProperties.put(env.getName(), env);
                }
            }
        }
        return systemProperties;
    }

    /**
     * Uses reflection to get the password.
     * 
     * @throws Exception
     *           - cannot connect to database
     */

    private String getPhrase(final String inPhrase) {
        String result = "na";
        java.lang.reflect.Method method;
        try {
            final Class encryptionUtil = Class
            .forName("curam.util.reporting.internal.security.EncryptionUtil");

            method = encryptionUtil.getMethod("decryptDBPasswordDefaulted",
                    String.class);

            final String temp = (String) method.invoke(null, inPhrase);
            result = temp;
        } catch (final IllegalArgumentException e) {
            e.printStackTrace();
        } catch (final IllegalAccessException e) {
            e.printStackTrace();
        } catch (final ClassNotFoundException e) {
            e.printStackTrace();
        } catch (final NoSuchMethodException e) {
            e.printStackTrace();
        } catch (final java.lang.reflect.InvocationTargetException e) {
            e.printStackTrace();
        }

        return result;
    }
}
