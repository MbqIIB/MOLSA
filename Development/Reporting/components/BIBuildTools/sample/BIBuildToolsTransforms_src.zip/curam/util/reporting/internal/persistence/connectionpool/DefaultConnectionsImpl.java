/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.persistence.connectionpool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import curam.util.reporting.internal.config.ConnectionProperties;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.type.*;

/**
 * This module persistence class for both the build environment and
 * transformations.
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class DefaultConnectionsImpl implements ConnectionPool {

    /**
     * the database connection properties
     */
    private final ConnectionProperties connectionProperties;

    /**
     * the vendors product name
     */
    private String productName;

    /**
     * Creates a new default connection object
     * 
     * @param inConnectionProperties
     *          database connection properties
     */
    public DefaultConnectionsImpl(final ConnectionProperties inConnectionProperties) {
        this.connectionProperties = inConnectionProperties;
    }

    /**
     * Returns connection properties.
     * 
     * @return ConnectionProperties
     */
    public ConnectionProperties getConnectionProperties() {
        // ensure the target database type is set
        if (connectionProperties.getTargetDataBaseType() == null) {
            try {
                // sets the target database type
                newConnection();
            } catch (final SQLException e) {// ignore the error will be caught elsewhere
            }
        }
        return connectionProperties;
    }

    /**
     * Returns a connection
     * 
     * @return Connection
     */
    public Connection getConnection() throws SQLException {
        return newConnection();
    }

    /**
     * Returns a connection if one can be created in the time specified
     * 
     * @param inTimeOut
     *          the time out value
     * @return Connection
     */
    public Connection getConnection(final long inTimeOut) throws SQLException {
        return newConnection();
    }

    /**
     * Returns a read only connection.
     * 
     * @return Connection
     */
    public Connection getReadOnlyConnection(final String inDataSourceName)
    throws SQLException {
        return newConnection();
    }

    /**
     * Returns a connection.
     * 
     * @param inConnection
     */
    public void returnConnection(final Connection inConnection) {// never close the
        // default connection
    }

    /**
     * Release any database resource consumed
     */
    public void releaseResources() {// never close the default connection
    }

    /**
     * Creates a new connection.
     * 
     * @return Connection
     */
    private Connection newConnection() throws SQLException {
        Connection connection = null;

        try {
            connection = DriverManager.getConnection(connectionProperties.getUrl());

            // returns the RDBMS vendor, e.g. Oracle
            if (productName == null) {
                productName = connection.getMetaData().getDatabaseProductName();
                // write the product name to the
            }
            final TargetDataBaseType targetDataBaseType = new TargetDataBaseType(
                    productName);

            // sets the target database type based on vendor name,
            // using this method for default connections where
            // the vendor type cannot be read from the application property file

            connectionProperties.setTargetDataBaseType(targetDataBaseType);

            connection.setAutoCommit(false);
        } catch (final Exception e) {
            throw new SQLException(connectionProperties.getUrl() + e);
        }
        return connection;
    }
}
