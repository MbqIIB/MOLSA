/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.config;

import java.io.FileNotFoundException;

/**
 * Factory class to create an instance of datamart person PropertiesCache class,
 * one of its subclasses, a proxy for it or a mock object for it.
 * 
 */
public class PropertyReaderFactory {

  static private PropertiesCache singletonCache = null;

  // ___________________________________________________________________________
  /**
   * Returns an property reader implementation
   * 
   * @param inPropertyFile
   *          the absolute path to the property file
   * 
   * @return PropertyReader the property reader
   * @throws FileNotFoundException
   */
  static synchronized public PropertiesCache getConnectionPropertyReader(
      String inPropertyFile) throws FileNotFoundException {
    if (singletonCache == null) {
      PropertyReader reader = new PropertyReaderImpl(inPropertyFile);
      PropertiesCacheImpl cache = new PropertiesCacheImpl();
      cache.initialize(reader);
      singletonCache = cache;
    }
    // returns a new property reader
    return singletonCache;

  }

  // ___________________________________________________________________________
  /**
   * Returns an property reader implementation
   * 
   * @return PropertyReader the property reader
   */
  static synchronized public PropertiesCache getDefaultsPropertyReader() {
    if (singletonCache == null) {

      PropertyReader reader;
      PropertiesCacheImpl cache = new PropertiesCacheImpl();
      try {
        reader = new PropertyReaderDefaultsImpl();
        cache.initialize(reader);
      } catch (FileNotFoundException e) {
        e.printStackTrace();
      }
      singletonCache = cache;
    }
    // returns a new property reader
    return singletonCache;
  }

  // ___________________________________________________________________________
  /**
   * Returns an property reader implementation which searches for the property
   * file on class path
   * 
   * @return PropertyReader the property reader
   * @throws FileNotFoundException
   */
  static synchronized public PropertiesCache getConnectionPropertyReader()
      throws FileNotFoundException {
    if (singletonCache == null) {

      PropertyReader reader = new PropertyReaderImpl();
      PropertiesCacheImpl cache = new PropertiesCacheImpl();
      cache.initialize(reader);
      singletonCache = cache;
    }
    // returns a new property reader
    return singletonCache;
  }
}
