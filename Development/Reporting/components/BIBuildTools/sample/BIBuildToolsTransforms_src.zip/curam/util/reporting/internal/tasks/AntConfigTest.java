/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.ComponentOrder;
import curam.util.reporting.internal.config.ConfigTest;
import curam.util.reporting.internal.config.DB2Platform;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.DateFormatter;
import curam.util.reporting.internal.config.EnvironmentVariable;
import curam.util.reporting.internal.config.PropertiesCache;
import curam.util.reporting.internal.config.PropertyReaderFactory;
import curam.util.reporting.internal.config.SystemProperty;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;

/**
 * This module validates the properties with the BI application and BI bootstrap
 * property files.
 * 
 * This is implemented as an Ant task.
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntConfigTest extends Task {
  /**
   * error buffer.
   */
  private final ArrayList<String> errors = new ArrayList<String>();

  /**
   * information messages.
   */
  private final ArrayList<String> informationals = new ArrayList<String>();

  /**
   * error found indicator
   */
  private boolean errorsFound = false;

  private boolean infoFound = false;

  // final String jarDB2 = "jar.db2";
  private final String pathSeparator = "path.separator";

  private SystemProperty pathSeparatorCharacter;

  /*
   * only used in debug mode
   */
  private final boolean debug = false;

  /**
   * ant property - the property file full path.
   */
  private String fileName;

  /**
   * ant property - the property file.
   */
  private PropertiesCache propertyReader;

  /**
   * ant property - ant property - the reporting base directory
   */
  private String baseDirectory;

  /**
   * ant property - only test BIRT database access
   */
  private boolean checkBIRTConnections = false;

  /**
   * ant property - to verify the schema being created in the OWB setup.tcl do
   * not already exist
   */
  @SuppressWarnings("unused")
  private final boolean owbDesignCheck = false;

  private boolean owbTargetSchemasCheck = false;

  @SuppressWarnings("unused")
  private boolean expectedResult = false;

  // _________________________________________________________________________
  /**
   * The java application entry point.
   * 
   * @param args
   *          - one parameter a full path to a build file..
   * 
   * 
   * @throws java.lang.Exception
   */
  public static void main(final String[] args) throws Exception {
    // arg[0] is the build file (full path)
    /*
     * File buildFile = new File(args[0]); Project p = new Project();
     * p.setUserProperty("ant.file", buildFile.getAbsolutePath()); p.init();
     * ProjectHelper helper = ProjectHelper.getProjectHelper();
     * p.addReference("ant.projectHelper", helper); helper.parse(p, buildFile);
     * p.executeTarget("configtest");
     */
    AntConfigTest test = new AntConfigTest(args[0], "appbuild.xml");
    test.execute();
  }

  /**
   * no arg constructor for ant
   * 
   */
  public AntConfigTest() {
  }

  /**
   * constructor when invoked for other java clients
   * 
   * @param inReportingBaseDirectory
   *          - reporting base directory
   * @param inFileName
   *          pull path to the property file
   */
  public AntConfigTest(
      final String inReportingBaseDirectory,
      final String inFileName) {
    setFile(inFileName);
    setReportingDirectory(inReportingBaseDirectory);
  }

  // ___________________________________________________________________________
  /**
   * Sets the path to the property file from Ant
   * 
   * @param inOWBTargetSchemasCheck
   *          the path to the property file
   */
  public void setConnectOWBTargetSchemas(final boolean inOWBTargetSchemasCheck) {
    owbTargetSchemasCheck = inOWBTargetSchemasCheck;
  }

  // ___________________________________________________________________________
  /**
   * fail if not the expected result
   * 
   * @param inExpectedResult
   *          fail if not the expected result
   */
  public void setExpectedResult(final boolean inExpectedResult) {
    expectedResult = inExpectedResult;
  }

  // ___________________________________________________________________________
  /**
   * Sets the path to the property file from Ant
   * 
   * @param inBIRTTestOnly
   *          the path to the property file
   */
  public void setBirtTestOnly(final String inBIRTTestOnly) {
    checkBIRTConnections = Boolean.parseBoolean(inBIRTTestOnly);
  }

  // ___________________________________________________________________________
  /**
   * Sets the path to the property file from Ant
   * 
   * @param inDirectory
   *          the path to the property file
   */
  public void setReportingDirectory(final String inDirectory) {
    baseDirectory = inDirectory;
  }

  // ___________________________________________________________________________
  /**
   * Sets the path to the property file from Ant
   * 
   * @param inFileName
   *          the path to the property file
   */
  public void setFile(final String inFileName) {
    fileName = inFileName;
  }

  // __________________________________________________________________________
  /**
   * If properties are missing an exception is thrown.
   * 
   * @throws BuildException
   *           if properties are missing
   */
  @Override
  public void execute() throws BuildException {
    try {
      if (debug) {
        BILogger.info("Configtest started");
      }
      if (baseDirectory == null) {
        throw new Exception("Missing target attribute ReportingDirectory");
      }
      if (fileName == null) {
        throw new Exception("Missing target attribute FileName");
      }
      DataWarehouseConstants.getBaseDirectory();
      // reads the properties file
      propertyReader = PropertyReaderFactory.getConnectionPropertyReader();
      final TargetDataBaseType targetDataBaseType = propertyReader
          .getTargetEnvironment();
      BILogger.debug("Java: property file location " + fileName);
      // check the database type
      if (propertyReader.getValue(DataWarehouseConstants.kDatabaseType)
          .length() == 0) {
        throw new BuildException(DataWarehouseConstants.kDatabaseType
            + " is missing  from property file");
      }
      if (targetDataBaseType.isDB2()) {
        String sourceType = propertyReader
            .getValue(DataWarehouseConstants.kSourceDatabaseType);
        if (sourceType.length() == 0) {
          throw new BuildException(DataWarehouseConstants.kSourceDatabaseType
              + " property is missing from property file");
        }
        DB2Platform db2Platform = targetDataBaseType.db2Platform(sourceType);
        if (DB2Platform.UDB == db2Platform) {
          BILogger.debug(DataWarehouseConstants.kSourceDatabaseType
              + " is set to " + db2Platform.UDB);
        } else if (DB2Platform.ZOS == db2Platform) {
          BILogger.debug(DataWarehouseConstants.kSourceDatabaseType
              + " is set to " + DB2Platform.ZOS);
        } else {
          addErrorMessage(DataWarehouseConstants.kSourceDatabaseType
              + " is not set correct, use " + DB2Platform.UDB + " or "
              + DB2Platform.ZOS, false);
        }
      }
      String brand = propertyReader
          .getValue(DataWarehouseConstants.kTechStackProductName);
      if (brand.length() == 0) {
        String message =
            DataWarehouseConstants.kTechStackProductName
                + " property is missing, you must set this property, see the sample BIBootstrap properties file";
        addErrorMessage(message, true);
        throw new BuildException(message);
      }
      if (!brand.equalsIgnoreCase(DataWarehouseConstants.kTechStackVendorIBM)
          && !brand
              .equalsIgnoreCase(DataWarehouseConstants.kTechStackVendorOracle)) {
        String message = DataWarehouseConstants.kTechStackProductName
            + " must be set to one of ["
            + DataWarehouseConstants.kTechStackVendorOracle + "|"
            + DataWarehouseConstants.kTechStackVendorIBM + "]";
        addErrorMessage(message, true);
        throw new BuildException(message);
      }
      SystemProperty techStackVendor =
          new SystemProperty(
              DataWarehouseConstants.kTechStackProductName,
              propertyReader
                  .getValue(DataWarehouseConstants.kTechStackProductName));
      techStackVendor.notAFile();
      techStackVendor.inValidate();
      BILogger.info("BIRT KPI access test :" + checkBIRTConnections);
      // check that the date properties values are valid
      checkDateFormats();
      // read the environment variables that are required as defined in
      // the properties file
      ReportingFileManager.verbose = true;
      ReportingFileManager manager = new ReportingFileManager(
          DataWarehouseConstants.kComponentsDir, baseDirectory);
      ComponentOrder componentOrder = manager
          .getComponentsToBuild(DataWarehouseConstants.kComponentsDir);
      // these are the most troublesome variables generally
      // test that the values are valid
      SystemProperty jdbcDrivers = new SystemProperty(
          DataWarehouseConstants.kJavaJDBCProp,
          propertyReader.getValue(DataWarehouseConstants.kJavaJDBCProp));
      jdbcDrivers.notAFile();
      jdbcDrivers.inValidate();
      // read the environment variable to see if Oracle is not installed
      // on this machine
      SystemProperty owbVersion = new SystemProperty(
          DataWarehouseConstants.owbVersion,
          propertyReader.getValue(DataWarehouseConstants.owbVersion));
      owbVersion.notAFile();
      owbVersion.inValidate();
      SystemProperty owbSourceVersion = new SystemProperty(
          DataWarehouseConstants.owbVersionSource,
          propertyReader.getValue(DataWarehouseConstants.owbVersionSource));
      owbSourceVersion.notAFile();
      owbSourceVersion.inValidate();
      SystemProperty owbOracleInstalled = new SystemProperty(
          DataWarehouseConstants.kOracleInstalledOnOWBClientBox,
          propertyReader
              .getValue(DataWarehouseConstants.kOracleInstalledOnOWBClientBox));
      SystemProperty remoteDataManagerDir = new SystemProperty(
          DataWarehouseConstants.kOracleRemoteDataManagerDir,
          propertyReader
              .getValue(DataWarehouseConstants.kOracleRemoteDataManagerDir));
      BILogger.info("    property " + remoteDataManagerDir.getName());
      String sourceGrant = "environment.databases.curam.privilages.autogrant";
      String biGrant = "environment.databases.bi.privilages.autogrant";
      String updateNulls = "environment.databases.curam.updatenulls.autorun";
      String remoteDMDirFail =
          "environment.owbconfig.remotedatamanagerdir.failonwarnings";
      if (targetDataBaseType.isORACLE()) {
        BILogger.info("testing OWB config");
        SystemProperty updateNullsFailProp = new SystemProperty(
            remoteDMDirFail, propertyReader.getValue(remoteDMDirFail));
        updateNullsFailProp.notAFile();
        updateNullsFailProp.inValidate();
        // add the property for testing
        propertyReader.add(updateNullsFailProp);
        remoteDataManagerDir.validated();
        if (remoteDataManagerDir.getValue().length() > 0) {
          File defaultPath = new File(
              DataWarehouseConstants.getDefaultDataManagerDirectory());
          propertyReader.add(remoteDataManagerDir);
          if (defaultPath.compareTo(new File(remoteDataManagerDir.getValue())) == 0) {
            String message = ":error in property "
                + remoteDataManagerDir.getName()
                + "    is set to the default local path "
                + defaultPath.getAbsolutePath() + File.separator
                + " only set this property if the path is remote";
            if (updateNullsFailProp.asBoolean() == true) {
              addErrorMessage(message, false);
            } else {
              addInformationMessage(message, false);
            }
          } else {
            BILogger
                .info("    basic validation succeeded, checking that is it not set to the default location");
          }
          boolean windowsPath = remoteDataManagerDir.getValue().endsWith("\\");
          boolean unixPath = remoteDataManagerDir.getValue().endsWith("/");
          if (windowsPath || unixPath) {
            BILogger
                .info("    path correctly terminated with the path separator character "
                    + "[\\|/]");
          } else {
            String message =
                "error in property "
                    + remoteDataManagerDir.getName()
                    + System.getProperty("line.separator")
                    + "    Oracle Warehouse builder requires the path to be terminated with a"
                    + " path separator character for the remote environment, "
                    + " set to one of [\\|/]" + " the property value is "
                    + remoteDataManagerDir.toString()
                    + System.getProperty("line.separator");
            addErrorMessage(message, false);
          }
          File remoteDataManager = new File(remoteDataManagerDir.getValue());
          if (!remoteDataManager.exists()) {
            addInformationMessage(
                "   remote data manager not visible, to verify its correctly configured check the Reporting Developer Guide",
                false);
          } else {
            addInformationMessage(
                "   remote data manager is  visible, to verify its correctly configured check the Reporting Developer Guide",
                false);
          }
        } else {
          BILogger.info("    remote directory not specified");
        }
      }
      // display the path separator character
      pathSeparatorCharacter = new SystemProperty(pathSeparator,
          System.getProperty(pathSeparator));
      SystemProperty biGrantProp = new SystemProperty(biGrant,
          propertyReader.getValue(biGrant));
      biGrantProp.notAFile();
      biGrantProp.inValidate();
      SystemProperty sourceGrantProp = new SystemProperty(sourceGrant,
          propertyReader.getValue(sourceGrant));
      sourceGrantProp.notAFile();
      sourceGrantProp.inValidate();
      SystemProperty updateNullsProp = new SystemProperty(updateNulls,
          propertyReader.getValue(updateNulls));
      updateNullsProp.notAFile();
      updateNullsProp.inValidate();
      SystemProperty jdbcJars = new SystemProperty(
          DataWarehouseConstants.kJdbcJarFilesProp,
          propertyReader.getValue(DataWarehouseConstants.kJdbcJarFilesProp));
      if (targetDataBaseType.isORACLE()) {
        if (owbVersion.getValue() == null
            || owbVersion.getValue().length() == 0) {
          String message = "error in property " + owbVersion.getName()
              + System.getProperty("line.separator")
              + "    please set this to the verion of Oracle installed "
              + File.separator + " current value is " + owbVersion.toString()
              + System.getProperty("line.separator");
          addErrorMessage(message, false);
        }
        if (owbSourceVersion.getValue() == null
            || owbSourceVersion.getValue().length() == 0) {
          String message =
              "error in property "
                  + owbSourceVersion.getName()
                  + System.getProperty("line.separator")
                  + "    for the source system, please set this to the verion of Oracle installed "
                  + File.separator + " current value is "
                  + owbSourceVersion.toString()
                  + System.getProperty("line.separator");
          addErrorMessage(message, false);
        }
        propertyReader.add(owbSourceVersion);
        propertyReader.add(owbVersion);
        // add the property for testing
        propertyReader.add(updateNullsProp);
        // add the property for testing
        propertyReader.add(sourceGrantProp);
        // add the ant properties for testing
        propertyReader.add(biGrantProp);
        propertyReader.add(techStackVendor);
      }
      // check that the oracle driver jar is available on the classpath
      ConfigTest test = new ConfigTest();
      if (targetDataBaseType.isORACLE()) {
        final String oracleDriverJarName = "ojdbc.jar";
        boolean foundDriver = test.findResource(oracleDriverJarName, false);
        if (foundDriver == true) {
          BILogger.info("found " + oracleDriverJarName + " on the classpath.");
        } else {
          BILogger.error("could not find " + oracleDriverJarName
              + " on the classpath.");
        }
      }
      if (targetDataBaseType.isORACLE()) {
        final String db2DriverJarName = "db2jcc.jar";
        final boolean foundDriver = test.findResource(db2DriverJarName, false);
        if (foundDriver == true) {
          BILogger.info("found " + db2DriverJarName + " on the classpath.");
        } else {
          BILogger.error("could not find " + db2DriverJarName
              + " on the classpath.");
        }
      }
      BILogger.info(jdbcJars.getName() + " " + jdbcJars.getValue());
      jdbcJars.isFile();
      propertyReader.add(jdbcJars);
      propertyReader.add(jdbcDrivers);
      propertyReader.add(pathSeparatorCharacter);
      // only check this property if its DB2
      if (targetDataBaseType.isDB2()) {
        BILogger.info("testing infosphere project directory");
        SystemProperty infoSphereProjectDir = new SystemProperty(
            DataWarehouseConstants.kInfoSphereProjectDir,
            propertyReader
                .getValue(DataWarehouseConstants.kInfoSphereProjectDir));
        propertyReader.add(infoSphereProjectDir);
        infoSphereProjectDir.validated();
        URI infoSphereProjectURI = null;
        try {
          infoSphereProjectURI = new URI(infoSphereProjectDir.getValue());
        } catch (URISyntaxException e) {
          String message =
              "Warning: "
                  + DataWarehouseConstants.kInfoSphereProjectDir
                  + " URL is invalid, check for white space, format is file://<FULLPATH>";
          addErrorMessage(message, false);
        }
        File infoSphereDirName = new File(infoSphereProjectURI.getAuthority()
            + infoSphereProjectURI.getPath());
        if (!infoSphereDirName.exists()) {
          addErrorMessage("could not find directory defined in property "
              + DataWarehouseConstants.kInfoSphereProjectDir, false);
        } else {
          addInformationMessage("found directory defined in property "
              + DataWarehouseConstants.kInfoSphereProjectDir + " "
              + infoSphereDirName.getAbsolutePath(), false);
        }
        File infoSphereDatabaseDirName = new File(
            infoSphereDirName.getAbsoluteFile(), "databases");
        if (!infoSphereDatabaseDirName.exists()) {
          addErrorMessage("directory defined in property "
              + DataWarehouseConstants.kInfoSphereProjectDir
              + " is not a valid InfoSphere project directory "
              + infoSphereDatabaseDirName.getAbsolutePath(), false);
        } else {
          addInformationMessage("directory defined in property "
              + DataWarehouseConstants.kInfoSphereProjectDir
              + " is a valid InfoSphere project directory", false);
        }
      }
      // validate the environment variables
      validateSystemProperties(propertyReader);
      // validate the ant properties
      BILogger.info("Checking BIApplication properties order and language...");
      validateComponentOrder(componentOrder);
      BILogger.info("Checking BIBootstrap properties...");
      checkDatabase(DataWarehouseConstants.kCuramSourceDatabase,
          targetDataBaseType, false, true);
      checkDatabase(DataWarehouseConstants.kStagingDatabase,
          targetDataBaseType, false, true);
      checkDatabase(DataWarehouseConstants.kCentralDatabase,
          targetDataBaseType, false, true);
      checkDatabase(DataWarehouseConstants.kCoreDataMartDatabase,
          targetDataBaseType, false, true);
      checkDatabase(DataWarehouseConstants.kDataMartDemoDataDatabase,
          targetDataBaseType, false, true);
      // only perform a run time check if Oracle
      if (targetDataBaseType.isDB2()) {
        addInformationMessage(
            "Set the design properties to the control database when testing against the Infosphere Administratoion console",
            true);
        addInformationMessage(
            "Set the design properties to the warehouse settings when in development.",
            true);
      }
      checkDatabase(DataWarehouseConstants.kDesignDatabase, targetDataBaseType,
          true, false);
      // only perform a run time check if Oracle
      if (targetDataBaseType.isORACLE()) {
        checkDatabase(DataWarehouseConstants.kRuntimeDatabase,
            targetDataBaseType, true, false);
        if (!owbOracleInstalled.isValidValue()) {
          String message = "Error, please set ant property "
              + owbOracleInstalled.getName()
              + System.getProperty("line.separator");
          addInformationMessage(message, true);
        }
      }
      // only perform an OWB check if Oracle
      if (owbTargetSchemasCheck == true) {
        owbCheckDesignSchema(owbOracleInstalled);
        owbCheckTargetSchemas(owbOracleInstalled);
      } else {
        BILogger.info("Testing database access(jdbc)");
        connectTest(targetDataBaseType, checkBIRTConnections);
        checkExplorerPath(false);
        if (debug) {
          BILogger.debug("Configtest completed");
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new BuildException("ConfigTest:" + e.getMessage() + "<" + fileName
          + ">");
    } finally {
      BILogger.info("  ");
      BILogger.info("---------------------");
      BILogger.info("----Report Start-----");
      BILogger.info("You should review the following:");
      if (infoFound) {
        BILogger.info("  ");
        printInformationalMessages();
      } else {
        BILogger.info("    no informational issues");
      }
      BILogger.info("  ");
      BILogger.info("You MUST review the following issues:"
          + System.getProperty("line.separator"));
      if (errorsFound) {
        printErrorMessages();
      } else {
        BILogger.info("    no errors ");
      }
      BILogger.info("----Report End-----");
      if (errorsFound) {
        throw new BuildException("Build Failed, see errors above");
      }
    }
  }

  /**
   * Verify that each schema exists and is reachable.
   * 
   * @param targetDataBaseType
   * @param inCheckBIRTConnections
   */
  public void connectTest(TargetDataBaseType targetDataBaseType,
      boolean inCheckBIRTConnections) {
    ConfigTest connectTest = new ConfigTest();
    try {
      connectTest.newConnection(DataWarehouseConstants.kCuramSourceDatabase,
          System.out);
    } catch (Exception e) {
      addErrorMessage(DataWarehouseConstants.kCuramSourceDatabase + " "
          + e.getClass().getName() + ":" + e.getMessage(), true);
    }
    try {
      connectTest.newConnection(DataWarehouseConstants.kStagingDatabase,
          System.out);
    } catch (Exception e) {
      addErrorMessage("<" + DataWarehouseConstants.kStagingDatabase + ">"
          + e.getClass().getName() + ":" + e.getMessage(), true);
      errorsFound = true;
    }
    try {
      connectTest.newConnection(DataWarehouseConstants.kCentralDatabase,
          System.out);
    } catch (Exception e) {
      addErrorMessage("<" + DataWarehouseConstants.kCentralDatabase + ">"
          + e.getClass().getName() + ":" + e.getMessage(), true);
      errorsFound = true;
    }
    try {
      connectTest.newConnection(DataWarehouseConstants.kCoreDataMartDatabase,
          System.out);
    } catch (Exception e) {
      addErrorMessage("<" + DataWarehouseConstants.kCoreDataMartDatabase + ">"
          + e.getClass().getName() + ":" + e.getMessage(), true);
      errorsFound = true;
    }
    try {
      connectTest.newConnection(
          DataWarehouseConstants.kDataMartDemoDataDatabase, System.out);
    } catch (Exception e) {
      addInformationMessage("<"
          + DataWarehouseConstants.kDataMartDemoDataDatabase + ">"
          + e.getClass().getName() + ":" + e.getMessage(), true);
      errorsFound = true;
    }
    try {
      connectTest.newConnection(DataWarehouseConstants.kDesignDatabase,
          System.out);
    } catch (Exception e) {
      addInformationMessage("<" + DataWarehouseConstants.kDesignDatabase + ">"
          + e.getClass().getName() + ":" + e.getMessage(), true);
      errorsFound = true;
    }
    if (targetDataBaseType.isORACLE()) {
      try {
        connectTest.newConnection(DataWarehouseConstants.kRuntimeDatabase,
            System.out);
      } catch (Exception e) {
        addInformationMessage("<" + DataWarehouseConstants.kRuntimeDatabase
            + ">" + e.getClass().getName() + ":" + e.getMessage(), true);
        errorsFound = true;
      }
    }
    // ensure pooling - connecting to any schema verifies
    try {
      BILogger.info("testing database access (using pooling)");
      TransactionFactory
          .getTransaction(DataWarehouseConstants.kStagingDatabase);
    } catch (Exception e) {
      addErrorMessage(e.getClass().getName() + ":" + e.getMessage(), true);
      errorsFound = true;
    }
    if (inCheckBIRTConnections == true) {
      BILogger.info("KPI access test.");
      if (targetDataBaseType.isORACLE()) {
        try {
          connectTest.newConnection(
              DataWarehouseConstants.kCoreDataMartDatabase, System.out, true);
        } catch (Exception e) {
          addInformationMessage("<"
              + DataWarehouseConstants.kCoreDataMartDatabase + ">"
              + "checking URL with SID (used in BIRT KPIs):"
              + e.getClass().getName() + ":" + e.getMessage(), false);
          errorsFound = true;
        }
        try {
          connectTest.newConnection(
              DataWarehouseConstants.kDataMartDemoDataDatabase, System.out,
              true);
        } catch (Exception e) {
          addInformationMessage("<"
              + DataWarehouseConstants.kDataMartDemoDataDatabase + ">"
              + "checking URL with SID (used in BIRT KPIs):"
              + e.getClass().getName() + ":" + e.getMessage(), false);
          errorsFound = true;
        }
      }
    } else if (inCheckBIRTConnections == false) {
      BILogger.info("KPI access skipped.");
    }
  }

  /**
   * Ensure that all environment variables are set
   * 
   * @throws Exception
   */
  private void validateComponentOrder(ComponentOrder componentOrder)
      throws Exception {
    BILogger
        .info(DataWarehouseConstants.kComponentOrder + "=" + componentOrder);
    String levelValue = propertyReader
        .getValue(DataWarehouseConstants.kComponentOrderWarningLevel);
    if (componentOrder == null || levelValue == null) {
      String message = DataWarehouseConstants.kComponentOrder + "and/or"
          + DataWarehouseConstants.kComponentOrderWarningLevel + "["
          + DataWarehouseConstants.kComponentOrderError + "|"
          + DataWarehouseConstants.kComponentOrderWarning + "]"
          + " is missing from property file";
      addErrorMessage(message, false);
    } else {
      String componentsDir = baseDirectory + File.separator + "components";
      Iterator<ComponentName> components = componentOrder
          .getComponentsToInstall();
      while (components.hasNext()) {
        String component = componentsDir + File.separator
            + ((ComponentName) components.next()).getComponentName().trim();
        File file = new File(component);
        if (file.exists() == false) {
          String message =
              System.getProperty("line.separator")
                  + "  <"
                  + component
                  + "> is not a valid directory. "
                  + "ensure the componet.order property contains valid directory names";
          BILogger.info("   resource exists check = false=" + levelValue);
          BILogger.info(DataWarehouseConstants.kComponentOrderError + "="
              + levelValue);
          BILogger.info(DataWarehouseConstants.kComponentOrderWarning + "="
              + levelValue);
          if (DataWarehouseConstants.kComponentOrderError
              .equalsIgnoreCase(levelValue)) {
            addErrorMessage(message, false);
          } else if (DataWarehouseConstants.kComponentOrderWarning
              .equalsIgnoreCase(levelValue)) {
            addInformationMessage(message, false);
          }
        } else {
          BILogger
              .info("   resource exists check = true for " + file.getName());
        }
      }
    }
    String installedLanguagePropertyValue = propertyReader
        .getValue(DataWarehouseConstants.kInstalledLanguage);
    if (installedLanguagePropertyValue == null || levelValue == null) {
      String message = DataWarehouseConstants.kInstalledLanguage
          + " property is missing from property file";
      addErrorMessage(message, false);
    }
    String supportedLanguagePropertyValue = propertyReader
        .getValue(DataWarehouseConstants.kLocaleOrder);
    BILogger.info("supportedLanguagePropertyValue="
        + installedLanguagePropertyValue);
    if (supportedLanguagePropertyValue == null
        || supportedLanguagePropertyValue.length() == 0) {
      String message = DataWarehouseConstants.kLocaleOrder
          + " property is missing from property file";
      addErrorMessage(message, false);
    }
  }

  /**
   * Ensure that all environment variables are set
   * 
   * @param systemProperties
   * 
   * @throws Exception
   */
  public void validateSystemProperties(PropertiesCache systemProperties)
      throws Exception {
    BILogger.info("testing system properties, environment variables.");
    // a special check for COGNOS_HOME
    BILogger
        .info("testing COGNOS_HOME (verifying its set to the parent of the webcontent folder");
    EnvironmentVariable cognosHome = systemProperties.getEnv("COGNOS_HOME");
    File file = new File(cognosHome.getValue() + File.separator + "webcontent");
    if (!file.exists()) {
      boolean cognosInstalled = Boolean.valueOf(
          propertyReader
              .getValue(DataWarehouseConstants.EnvironmentCognosInstalled))
          .booleanValue();
      if (cognosInstalled) {
        String message = cognosHome.getName() + " is not set correctly "
            + System.getProperty("line.separator") + ", "
            + cognosHome.getValue()
            + " , it should be set to the parent of the webcontent folder, "
            + "e.g. c://COGNOS//c84//WEBCONTENT "
            + System.getProperty("line.separator");
        addErrorMessage(message, false);
      } else {
        String message =
            cognosHome.getName()
                + " is not set "
                + "<"
                + DataWarehouseConstants.EnvironmentCognosInstalled
                + "> overrides and indicates that Cognos is not accessable from this machine";
        addInformationMessage(message, false);
      }
    } else {
      BILogger.info("   resource exists check = true");
    }
    Iterator<EnvironmentVariable> envVariables = systemProperties
        .getEnvironmentVariables();
    EnvironmentVariable variable;
    // set this to validated so it not validated again.
    cognosHome.validated();
    if (!envVariables.hasNext()) {
      addErrorMessage(DataWarehouseConstants.kEnvironmentVariables
          + " is empty, check " + DataWarehouseConstants.kPropertyFile, false);
    }
    while (envVariables.hasNext()) {
      variable = (EnvironmentVariable) envVariables.next();
      if (!variable.isValidated()) {
        String value = variable.getValue();
        BILogger.info(variable.toString());
        if (!variable.isValidValue()) {
          String message = " please set " + variable
              + System.getProperty("line.separator");
          addErrorMessage(message, false);
        }
        if (variable.isValidValue()) {
          file = new File(value);
          if (variable.isFile() && !file.exists()) {
            String message = "is not a file:" + variable
                + System.getProperty("line.separator");
            addInformationMessage(message, false);
          } else {
            BILogger.info("   resource exists check = true");
          }
        }
      }
    }
    BILogger.info("testing ant properties ");
    envVariables = systemProperties.getSystemProperties();
    while (envVariables.hasNext()) {
      variable = (EnvironmentVariable) envVariables.next();
      String value = variable.getValue();
      if (!variable.isValidated()) {
        BILogger.info("    " + variable);
        if (!variable.isValidValue()) {
          String message = " please set ant property " + variable
              + System.getProperty("line.separator");
          addErrorMessage(message, false);
        }
        if (variable.isValidValue() && variable.isFile()) {
          String files[] = value.split(pathSeparatorCharacter.getValue());
          for (int i = 0; i < files.length; i++) {
            file = new File(files[i]);
            if (!file.exists()) {
              String message = "property <" + variable.getName()
                  + "> can't find file " + file.getAbsolutePath()
                  + System.getProperty("line.separator");
              if (variable.isValidated()) {
                addInformationMessage(message, false);
              } else {
                addErrorMessage(message, false);
              }
            } else {
              BILogger.info("    resource exists check = true. ..."
                  + file.getName());
            }
          }
        }
      }
    }
  }

  /**
   * @param inRaiseExceptionOnFailure
   * @return File the path to the internet explorer executable
   * @throws Exception
   */
  public File checkExplorerPath(final boolean inRaiseExceptionOnFailure)
      throws Exception {
    if (propertyReader == null) {
      // reads the properties file
      propertyReader = PropertyReaderFactory.getConnectionPropertyReader();
    }
    String iexplorerPath = (propertyReader
        .getValue(DataWarehouseConstants.kIExplorerPath));
    if (iexplorerPath == null) {
      String message = DataWarehouseConstants.kIExplorerPath
          + " is missing from property file, e.g. ["
          + DataWarehouseConstants.kIExplorerPath
          + "=file://C:/Program%20Files/Internet%20Explorer/iexplore.exe" + "]";
      // throw new Exception(message);
      addErrorMessage(message, false);
    }
    URI explorerURI = null;
    try {
      explorerURI = new URI(iexplorerPath);
    } catch (URISyntaxException e) {
      String message = "Warning: " + DataWarehouseConstants.kIExplorerPath
          + " URL is invalid, check for white space, a valid path etc ["
          + iexplorerPath + "], format is file://<FULLPATH>";
      addInformationMessage(message, false);
    }
    File explorer =
        new File(explorerURI.getAuthority() + explorerURI.getPath());
    if (!(explorer.exists())) {
      String message = "Warning: " + DataWarehouseConstants.kIExplorerPath
          + " URL is invalid, check for white space, a valid path etc ["
          + iexplorerPath + "], format is file://<FULLPATH>";
      ;
      addInformationMessage(message, false);
    }
    return explorer;
  }

  // ___________________________________________________________________________
  /**
   * ChecDataWarehouseConstants.ks for the existence of properties.
   * 
   * @param inDatabase
   *          the path to the property file
   * @param inTargetDataBaseType
   *          Oracle or DB2
   * @param inCheckServiceName
   *          if true validates the service name
   * @param inCheckSID
   */
  private void checkDatabase(final String inDatabase,
      final TargetDataBaseType inTargetDataBaseType,
      final boolean inCheckServiceName, final boolean inCheckSID) {
    final StringBuffer errorMessage = new StringBuffer();
    final String kReturn = System.getProperty("line.separator");
    boolean foundError = false;
    BILogger.info("    checking ..." + inDatabase);
    errorMessage.append("Check for missing properties ").append(kReturn);
    if (propertyReader.getValue(inDatabase + DataWarehouseConstants.kDBServer)
        .length() == 0) {
      errorMessage.append(inDatabase).append(DataWarehouseConstants.kDBServer)
          .append(kReturn);
      foundError = true;
    }
    if (propertyReader.getValue(inDatabase + DataWarehouseConstants.kDBPort)
        .length() == 0) {
      errorMessage.append(inDatabase).append(DataWarehouseConstants.kDBPort)
          .append(kReturn);
      foundError = true;
    }
    if (propertyReader.getValue(
        inDatabase + DataWarehouseConstants.kDatabaseName).length() == 0) {
      errorMessage.append(inDatabase)
          .append(DataWarehouseConstants.kDatabaseName).append(kReturn);
      foundError = true;
    }
    if (propertyReader
        .getValue(inDatabase + DataWarehouseConstants.kDBUserName).length() == 0) {
      errorMessage.append(inDatabase)
          .append(DataWarehouseConstants.kDBUserName).append(kReturn);
      foundError = true;
    }
    if (propertyReader
        .getValue(inDatabase + DataWarehouseConstants.kDBPassword).length() == 0) {
      errorMessage.append(inDatabase)
          .append(DataWarehouseConstants.kDBPassword).append(kReturn);
      foundError = true;
    }
    if (inTargetDataBaseType.isORACLE()) {
      if (propertyReader.getValue(
          inDatabase + DataWarehouseConstants.kJNDIDataSourceName).length() == 0) {
        errorMessage.append(inDatabase)
            .append(DataWarehouseConstants.kJNDIDataSourceName).append(kReturn);
        foundError = true;
      }
    }
    if (inTargetDataBaseType.isORACLE()
        && inCheckServiceName
        && propertyReader.getValue(
            inDatabase + DataWarehouseConstants.kServiceName).length() == 0) {
      errorMessage.append(inDatabase)
          .append(DataWarehouseConstants.kServiceName).append(kReturn);
      foundError = true;
    }
    if (inTargetDataBaseType.isORACLE()
        && inCheckSID
        && propertyReader.getValue(
            inDatabase + DataWarehouseConstants.kOracleSID).length() == 0) {
      errorMessage.append(inDatabase).append(DataWarehouseConstants.kOracleSID)
          .append(kReturn);
      foundError = true;
    }
    if (foundError) {
      addErrorMessage(errorMessage.toString(), false);
    }
  }

  /**
   * @throws Exception
   */
  public void checkDateFormats() throws Exception {
    BILogger.info("testing date properties");
    if (propertyReader == null) {
      // reads the properties file
      propertyReader = PropertyReaderFactory.getConnectionPropertyReader();
    }
    // check the reset ETL format - get the format
    try {
      String format = propertyReader
          .getValue(DataWarehouseConstants.kEnvironmentResetDateFormat);
      DateFormatter.setFormat(format);
      // get the value
      BILogger.info("    "
          + DataWarehouseConstants.kEnvironmentResetETLDate
          + "="
          + DateFormatter.getSQLDate(propertyReader
              .getValue(DataWarehouseConstants.kEnvironmentResetETLDate)));
    } catch (Exception e) {
      String message = "error "
          + DataWarehouseConstants.kEnvironmentResetDateFormat + "  or "
          + DataWarehouseConstants.kEnvironmentResetETLDate + " is invalid ";
      addErrorMessage(message, false);
    }
    // check the aggregate month format - get the format
    try {
      String format = propertyReader
          .getValue(DataWarehouseConstants.kEnvironmentAggregateDateFormat);
      DateFormatter.setFormat(format);
      // get the value and convert
      BILogger
          .info("    "
              + DataWarehouseConstants.kEnvironmentAggregateStartdate
              + "="
              + DateFormatter
                  .getSQLDate(propertyReader
                      .getValue(DataWarehouseConstants.kEnvironmentAggregateStartdate)));
      BILogger.info("    "
          + DataWarehouseConstants.kEnvironmentAggregateEnddate
          + "="
          + DateFormatter.getSQLDate(propertyReader
              .getValue(DataWarehouseConstants.kEnvironmentAggregateEnddate)));
    } catch (Exception e) {
      String message = "error "
          + DataWarehouseConstants.kEnvironmentAggregateDateFormat + " or "
          + DataWarehouseConstants.kEnvironmentAggregateStartdate + " or "
          + DataWarehouseConstants.kEnvironmentAggregateEnddate
          + " is invalid ";
      addErrorMessage(message, false);
    }
    // check the aggregate month format - get the format
    try {
      propertyReader
          .getValue(DataWarehouseConstants.kEnvironmentDemoDateFormat);
      BILogger.info("    "
          + DataWarehouseConstants.kEnvironmentDemoDateFormat
          + "="
          + propertyReader
              .getValue(DataWarehouseConstants.kEnvironmentDemoDateFormat));
    } catch (Exception e) {
      String message = "error "
          + DataWarehouseConstants.kEnvironmentDemoDateFormat + " is invalid ";
      addErrorMessage(message, false);
    }
  }

  private void addInformationMessage(String inMessage, boolean inSilent) {
    if (!inSilent) {
      BILogger.info("  Info:  " + inMessage);
    }
    informationals.add(inMessage);
    infoFound = true;
  }

  private void addErrorMessage(String inMessage, boolean inSilent) {
    if (!inSilent) {
      BILogger.info("  Error: " + inMessage);
    }
    errors.add(inMessage);
    errorsFound = true;
  }

  private void printInformationalMessages() {
    for (String abc : errors) {
      BILogger.info(abc);
    }
  }

  private void printErrorMessages() {
    for (String abc : errors) {
      BILogger.error(abc);
    }
  }

  /**
   * the following schema must not exist for the OWB create build target to
   * execute successfully
   * 
   * @param oracleInstalled
   * @throws BuildException
   */
  public void owbCheckDesignSchema(SystemProperty oracleInstalled)
      throws BuildException {
    ConfigTest connectTest = new ConfigTest();
    String message = "";
    BILogger.info("OWB pre-setup test:owb design schema test.");
    try {
      connectTest.newConnection(DataWarehouseConstants.kDesignDatabase,
          System.out);
    } catch (Exception e) {
      message = "OWB Design repository must exist for this build "
          + " command to execute: please manually create the design schema "
          + DataWarehouseConstants.kDesignDatabase
          + System.getProperty("line.separator");
      addErrorMessage(message, true);
    }
    if (errorsFound) {
      BILogger.info(message);
    }
  }

  /**
   * the following schema must not exist for the OWB create build target to
   * execute successfully
   * 
   * @param oracleInstalled
   * @throws BuildException
   */
  public void owbCheckTargetSchemas(SystemProperty oracleInstalled)
      throws BuildException {
    ConfigTest connectTest = new ConfigTest();
    BILogger.info("OWB pre-setup test:owb target schema's test.");
    try {
      connectTest.newConnection(DataWarehouseConstants.kDesignDatabase,
          System.out);
    } catch (Exception e) {
      StringBuffer message = new StringBuffer(
          "    OWB Design repository must exist for this build "
              + " command to execute: please create the OWB design schema ");
      message.append(DataWarehouseConstants.kDesignDatabase
          + System.getProperty("line.separator"));
      addErrorMessage(message.toString(), true);
    }
    try {
      connectTest.newConnection(DataWarehouseConstants.kStagingDatabase,
          System.out);
      String message = "Target schema should not exist for this build "
          + " command to execute: please ensure schema does not exist "
          + DataWarehouseConstants.kStagingDatabase
          + System.getProperty("line.separator");
      addErrorMessage(message, true);
    } catch (Exception e) {
    }
    try {
      connectTest.newConnection(DataWarehouseConstants.kCentralDatabase,
          System.out);
      String message = "Target schema should not exist for this build "
          + " command to execute: please ensure schema does not exist "
          + DataWarehouseConstants.kCentralDatabase
          + System.getProperty("line.separator");
      addErrorMessage(message, true);
    } catch (Exception e) {
    }
    try {
      connectTest.newConnection(DataWarehouseConstants.kCoreDataMartDatabase,
          System.out);
      String message = "Target schema should not exist for this build "
          + " command to execute: please ensure schema does not exist "
          + DataWarehouseConstants.kCoreDataMartDatabase
          + System.getProperty("line.separator");
      addErrorMessage(message, true);
    } catch (Exception e) {
    }
    if (errorsFound) {
      System.out
          .println("OWB pre-setup test: testing target schemas must not exist");
    }
  }
}
