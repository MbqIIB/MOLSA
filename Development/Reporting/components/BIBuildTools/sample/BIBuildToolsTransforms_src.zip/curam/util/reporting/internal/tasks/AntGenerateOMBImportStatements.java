/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.config.DataWarehouseConstants;

import curam.util.type.*;

/**
 * 
 * This class generates OMB import statements for the reporting databases.
 * 
 * This build task will include custom directories for client artifacts.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntGenerateOMBImportStatements extends Task {
    /**
     * the OWB meta data to import
     */
    OWBFilesSelected owbFilesSelected = new OWBFilesSelected();

    /**
     * a full path to the datamanager directory
     */
    private String targetDirectory;

    /**
     * the root reporting directory
     */
    private String reportingDir;

    /**
     * connection string to OWB repository
     */
    private String owburl;

    /**
     * the directory for the OBMPLUS commands
     */
    private String logDir;

    /**
     * local test harness for developers
     * 
     * @param inArguments
     * @throws Exception
     */
    public static void main(final String[] inArguments) throws Exception {
        if (inArguments.length != 2) {
            throw new Exception(
            " buildFileFullPath , ensure to pass the Reporing dir as a parameter using -DREPORTING_DIR=");
        }
        // pass in the calling directory to work out what components to build
        final ReportingFileManager fileManager = new ReportingFileManager("components",
                inArguments[0]);
        final AntGenerateOMBImportStatements task = new AntGenerateOMBImportStatements();
        final OWBFilesSelected owbFilesSelected = new OWBFilesSelected();
        owbFilesSelected.exportETL = true;
        owbFilesSelected.staging = true;
        owbFilesSelected.central = true;
        owbFilesSelected.datamart = true;
        fileManager.buildOWBScript(inArguments[1], inArguments[1], "abc",
                owbFilesSelected);
    }

    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     * 
     * @throws BuildException
     */
    @Override
    public void execute() throws BuildException {
        try {
            final Project antProject = getProject();
            String calledFrom = "";
            if (antProject != null) {
                // if we get a valid ant project object then getBaseDir will
                // return
                // the calling directory, e.g. "components", "core" etc
                // if we are in the "components" directory then build for
                // everything installed on disk.
                // otherwise build for the specific component only
                calledFrom = antProject.getBaseDir().getName();
                owbFilesSelected.owbVersion = antProject
                .getProperty(DataWarehouseConstants.owbVersion);
                if (owbFilesSelected.owbVersion == null) {
                    owbFilesSelected.owbVersion = "";
                }
            }

            // pass in the calling directory to work out what components to build
            final ReportingFileManager fileManager = new ReportingFileManager(calledFrom,
                    reportingDir);
            fileManager.buildOWBScript(targetDirectory, this.logDir, this.owburl,
                    owbFilesSelected);
        } catch (final BuildException e) {
            throw new BuildException(e.getMessage());
        } catch (final Exception e) {
            throw new BuildException(e.getMessage());
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the OWB connect string
     * 
     * @param inComnectURL
     *          base reporting directory
     */
    public void setOwbURL(final String inComnectURL) {
        owburl = inComnectURL;
    }

    // ___________________________________________________________________________
    /**
     * Sets the reporting log directory
     * 
     * @param inReportingLogDir
     *          base reporting directory
     */
    public void setLogDir(final String inReportingLogDir) {
        logDir = inReportingLogDir;
    }

    // ___________________________________________________________________________
    /**
     * Sets the base reporting directory
     * 
     * @param inReportingDir
     *          base reporting directory
     */
    public void setReportingDir(final String inReportingDir) {
        reportingDir = inReportingDir;
    }

    // ___________________________________________________________________________
    /**
     * the location where the DDL will be written to
     * 
     * @param inDataManagerDirectory
     * 
     */
    public void setTargetDirectory(final String inDataManagerDirectory) {
        this.targetDirectory = inDataManagerDirectory;
    }

    /**
     * Sets the indicator to import schema objects only
     * 
     * @param inSchemasOnly
     */
    public void setSchemaOnly(final String inSchemasOnly) {
        if (inSchemasOnly != null) {
            final boolean onlySchemas = Boolean.parseBoolean(inSchemasOnly);
            owbFilesSelected.schemasOnly = onlySchemas;
        }
    }

    /**
     * @param central
     *          the central to set
     */
    public void setCentral(final boolean central) {
        owbFilesSelected.central = central;
    }

    /**
     * @param common
     *          the common to set
     */
    public void setCommon(final boolean common) {
        owbFilesSelected.common = common;
    }

    /**
     * @param datamart
     *          the datamart to set
     */
    public void setDatamart(final boolean datamart) {
        owbFilesSelected.datamart = datamart;
    }

    /**
     * @param source
     *          the source to set
     */
    public void setSource(final boolean source) {
        owbFilesSelected.source = source;
    }

    /**
     * @param staging
     *          the staging to set
     */
    public void setStaging(final boolean staging) {
        owbFilesSelected.staging = staging;
    }

    /**
     * @param inExportOnlyETL
     *          export ETL processes
     */
    public void setExport(final boolean inExportOnlyETL) {
        if (inExportOnlyETL == true) {
            owbFilesSelected.importMetaData = false;
            owbFilesSelected.exportETL = true;
        }
    }

    /**
     * @param inWorkSpaceName
     *          the staging to set
     */
    public void setworkSpaceName(final String inWorkSpaceName) {
        owbFilesSelected.workSpaceVersion = inWorkSpaceName;

    }

}
