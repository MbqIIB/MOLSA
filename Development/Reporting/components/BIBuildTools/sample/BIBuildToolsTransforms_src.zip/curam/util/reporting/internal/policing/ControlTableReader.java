/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.policing;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.StringTokenizer;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.EnvironmentVariable;
import curam.util.reporting.internal.config.PropertiesCache;
import curam.util.reporting.internal.config.PropertyReaderFactory;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.dao.control.base.ProcessControl;
import curam.util.reporting.internal.tasks.BILogger;
import curam.util.reporting.internal.tasks.model.SchemaGroup;

/**
 * Executes the build static data command and return the tables names defined in
 * the control tables for a single component.
 */
public class ControlTableReader {
    public ControlTableReader() {
    }

    /**
     * returns null if a control file is not available for a component
     * and warehouse tier.
     * @param inSchemaName the warehouse tier to check, e.g. staging.
     * @param inComponentName the component name, i.e. the directory name
     * @return file null or a valid file handle
     */
    static public File controlFilePresent(final ReportingDBType inSchemaName,
            final ComponentName inComponentName) {
        // calling the same code base as the build environment
        // to merge the static data files for the core component.
        final String dataManagerDir = DataWarehouseConstants.kComponentsDir
        + File.separator + "components" + File.separator + inComponentName.getComponentName()
        + File.separator +"data_manager";
        final String stagingControlFile = inSchemaName.getTablePrefix()
        + "ETLCONTROL.csv";
        final File file = new File(dataManagerDir + File.separator  + stagingControlFile);
        if (file.exists()) {
            return file;
        } else {
            BILogger.info("file missing " + file.getAbsolutePath());
            return null;
        }
    }

    /**
     * Read control records
     * 
     * @param inSchema
     * @param inComponentName
     * @param inControlFile
     * @return all tables
     * @throws Exception
     */
    public ArrayList<String> readTables(final ReportingDBType inSchema,
            final ComponentName inComponentName, final String inControlFile)
            throws Exception {
        // instantiate Digester and disable XML validation
        final ArrayList<String> tableNames = new ArrayList<String>();
        final File inPathAndFileName = new File(inControlFile);
        if (!inPathAndFileName.exists()) {
            final FileNotFoundException e = new FileNotFoundException(inPathAndFileName
                    + " does not exist ");
            throw e;
        }
        if (!inPathAndFileName.isFile()) {
            final FileNotFoundException e = new FileNotFoundException(inPathAndFileName
                    + " is a directory not a file");
            throw e;
        }
        if (!inPathAndFileName.canRead()) {
            final FileNotFoundException e = new FileNotFoundException(inPathAndFileName
                    + " is a not a readable file");
            throw e;
        }
        try {
            StringTokenizer firstColumn = new StringTokenizer(",");
            final BufferedReader in = new BufferedReader(new FileReader(inPathAndFileName));
            String line;

            while ((line = in.readLine()) != null) {
                firstColumn = new StringTokenizer(line, ",");
                if (firstColumn.hasMoreTokens()) {
                    final String name = firstColumn.nextToken();
                    final String nameStipped = name.replace("\"", "");
                    final String nameStripped = nameStipped.replace("\"", "").trim();
                    if (nameStripped != null && nameStripped.length() > 0) {
                        tableNames.add(nameStripped);
                    }
                }
            }
            return tableNames;
        } catch (final IOException e) {
            final FileNotFoundException ex = new FileNotFoundException(
                    "Error schema tables file, " + e.getMessage());
            throw ex;
        }
    }

    /**
     * Read control records
     * 
     * @param inSchema
     * @param inComponentName
     * @param inControlFile
     * @return file
     * @throws Exception
     */
    public ArrayList<String> readETLControl(final ReportingDBType inSchema,
            final ComponentName inComponentName, final String inControlFile)
            throws Exception {
        // instantiate Digester and disable XML validation
        final ArrayList<String> tableNames = new ArrayList<String>();
        final File inPathAndFileName = new File(inControlFile);
        if (!inPathAndFileName.exists()) {
            final FileNotFoundException e = new FileNotFoundException(inPathAndFileName
                    + " does not exist ");
            throw e;
        }
        if (!inPathAndFileName.isFile()) {
            final FileNotFoundException e = new FileNotFoundException(inPathAndFileName
                    + " is a directory not a file");
            throw e;
        }
        if (!inPathAndFileName.canRead()) {
            final FileNotFoundException e = new FileNotFoundException(inPathAndFileName
                    + " is a not a readable file");
            throw e;
        }
        try {
            StringTokenizer firstColumn = new StringTokenizer(",");
            final BufferedReader in = new BufferedReader(new FileReader(inPathAndFileName));
            String line;
            while ((line = in.readLine()) != null) {
                firstColumn = new StringTokenizer(line, ",");
                if (firstColumn.hasMoreTokens()) {
                    final String name = firstColumn.nextToken();
                    final String nameStripped = name.replace("\"", "").trim();
                    if (nameStripped != null && nameStripped.length() > 0) {
                        tableNames.add(nameStripped);
                    }
                }
            }
            return tableNames;
        } catch (final IOException e) {
            final FileNotFoundException ex = new FileNotFoundException(
                    "Error control file, " + e.getMessage());
            throw ex;
        }
    }

    /**
     * Read control records for list of components
     * 
     * @param inComponentNames list is separated by space characters
     * @return a list of <code>ProcessControl</code> control table entries
     * @throws Exception
     */
    public ArrayList<ProcessControl> readETLControl(
            final String inComponentNames)
            throws Exception {
        final ArrayList<ProcessControl> tableNames = new ArrayList<ProcessControl>();
        // calling the same code base as the build environment
        // to merge the static data files for the core component.
        final PropertiesCache propertyReader = PropertyReaderFactory
        .getConnectionPropertyReader();
        // read the reporting directory, expecting as a -D or ant <JVMARG>
        final EnvironmentVariable reportingDir = propertyReader
        .getEnv(DataWarehouseConstants.kProjectDirectory);
        final SchemaGroup selectedSchemas = new SchemaGroup();
        selectedSchemas.setStaging();
        selectedSchemas.setCentral();
        selectedSchemas.setDatamart();
        final List<ReportingDBType> schemas = selectedSchemas.getDataSourcesSelected();
        final StringTokenizer st = new StringTokenizer(inComponentNames);
        ComponentName compName = null;
        while (st.hasMoreTokens()) {
            compName = new ComponentName(st.nextToken());
            BILogger.info("readETLControl:" + compName);
            for (final ReportingDBType schema : schemas) {
                final String controlFile = schema.getTablePrefix()
                + "ETLCONTROL";
                final String dataManagerDir =
                    reportingDir.getValue() + File.separator + "components"
                    + File.separator
                    + compName.getComponentName() + File.separator
                    + "data_manager" + File.separator
                    + controlFile + ".csv";
                final ControlTableReader controlTableReader = new ControlTableReader();
                final ArrayList<String> tables = controlTableReader.readETLControl(
                        schema, compName, dataManagerDir);
                BILogger.info("readETLControl:    "
                        + schema.getSchemaLogicalNameSentenceCase()
                        + " " + tableNames.size()  );

                for (final String table : tables) {
                    final ProcessControl controlEntry =
                        new ProcessControl(table, null, null, false, null);
                    controlEntry.setControlTableName(controlFile);
                    controlEntry.setComponentName(compName);
                    tableNames.add(controlEntry);
                }
            }
        }
        java.util.Collections.sort(tableNames, new ProcessControlNameComparator());
        return tableNames;
    }

    class ProcessControlNameComparator implements Comparator<ProcessControl> {

        public int compare(final ProcessControl table1, final ProcessControl table2) {

            // parameter are of type Object, so we have to downcast it to Employee
            // objects

            final String name1 = ((ProcessControl) table1).getTargetTableName();
            final String name2 = ((ProcessControl) table2).getTargetTableName();

            // uses compareTo method of String class to compare names of the employee
            return name1.compareTo(name2);

        }

    }
}
