/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.dao.control.base;

import curam.util.type.*;

/**
 * The derived status of this process control entry
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class ProcessControlState extends ProcessControl {

    /*
     * the ETL status
     */
    ExecutionState etlState;
    /**
     * addition data
     */
    String message = "";

    /**
     * 
     * @return ETLState the ETL State
     */
    public ExecutionState getETLStatus() {

        if (getLastExtractionDate() == null
                || !getLastExtractionDate().equals(getLastExtractStartDate())) {
            etlState = ExecutionState.FAILED;
        } else if (getLastExtractionDate() != null
                && getLastExtractionDate().equals(getLastExtractStartDate())) {
            etlState = ExecutionState.SUCCESS;
        }

        if (getLastExtractStartDate() == null) {
            etlState = ExecutionState.NEVEREXECUTED;
        }
        return etlState;
    }

    // ___________________________________________________________________________
    /**
     * Create an ETL state object from a ETL control record
     * 
     * @param inProcessControl
     */
    public ProcessControlState(final ProcessControl inProcessControl) {
        super(inProcessControl);
        setControlTableName(inProcessControl.getControlTableName());
    }

    /**
     * @return String the message status value
     */
    public String getETLStatusMessage() {
        final String message = this.toString();

        return message;
    }

    // ___________________________________________________________________________
    /**
     * Returns a string version of the object.
     * 
     * @return String
     */
    @Override
    public String toString() {
        return super.toString() + " ExecutionTimeInSeconds="
        + getExecutionTimeInSeconds();
    }



    // ___________________________________________________________________________
    /**
     * Returns the ETL execution time in seconds.
     * 
     * @return long
     */
    public long getExecutionTimeInSeconds() {
        long seconds = 0;

        if (getLastExtractFinishDate() != null && getLastExtractStartDate() != null) {
            seconds = (getLastExtractFinishDate().getTime() - getLastExtractStartDate()
                    .getTime());
            if (seconds == 0 ) {
                seconds = 1;
            }
        }
        return seconds;
    }

}
