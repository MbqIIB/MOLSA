/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.dao.control.base;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.dao.control.fact.ControlTableFactory;
import curam.util.reporting.internal.dao.control.intf.ControlTable;
import curam.util.reporting.internal.dao.control.intf.DBUtilities;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.type.*;

/**
 * This module provides common DB functions
 */
@AccessLevel(AccessLevelType.INTERNAL)
public abstract class DBUtilitiesImpl implements DBUtilities {

    /**
     * the control table name.
     */
    private final ReportingDBType reportingDBType;

    // ___________________________________________________________________________
    /**
     * Create a new object to interface with the ETL control table.
     * 
     * @param inReportingDBType
     *          staging, central or data mart
     */
    public DBUtilitiesImpl(final ReportingDBType inReportingDBType) {
        reportingDBType = inReportingDBType;
    }

    // ___________________________________________________________________________
    /**
     * Reads all process control records with success indicators
     * 
     * @return List of type ProcessControlState
     * 
     * @throws SQLException
     *           if a database operation fails
     */

    public List<ProcessControlState> readETLResults() throws SQLException {

        final ControlTable controlTable = ControlTableFactory
        .newInstance(reportingDBType);

        final List<ProcessControl> etlRecords = controlTable.readAll();
        final List<ProcessControlState> results = new ArrayList<ProcessControlState>();

        final Iterator<ProcessControl> controlRecords = etlRecords.iterator();
        ProcessControl record;
        ProcessControlState newObject;

        while (controlRecords.hasNext()) {
            record = (ProcessControl) controlRecords.next();
            newObject = new ProcessControlState(record);
            results.add(newObject);
        }
        return results;
    }

    // ___________________________________________________________________________
    /**
     * Returns a list of table names in a schema
     * 
     * @return List control table records
     * 
     * @throws SQLException
     *           if a database operation fails
     */

    public List<String> getAllTablesNamesInSchema(final ReportingDBType inSchema)
    throws SQLException {

        PreparedStatement statement = null;
        final List<String> allTables = new ArrayList<String>();

        try {
            final Connection connection = TransactionFactory.getTransaction(
                    DataWarehouseConstants.kDefaultDatabase).getConnection();

            // build the SQL statement
            String allReportingTables;
            String searchPattern;
            if (TransactionFactory.getTargetDatabaseType(
                    inSchema.getSchemaLogicalName()).isORACLE()) {
                allReportingTables = "select table_name,owner from all_tables where table_name like '?' escape '!'";
                searchPattern = inSchema.getTablePrefix() + "%";
                searchPattern = searchPattern.replace("_", "!_");
            } else {
                allReportingTables = "select tabname from SYSCAT.TABLES where  tabschema = 'DB2ADMIN' and tabname like '?' escape '+' order by tabname";
                searchPattern = inSchema.getTablePrefix() + "%";
            }

            allReportingTables = allReportingTables.replace("?", searchPattern);

            // execute the statement
            statement = connection.prepareStatement(allReportingTables);
            // statement.setString(1, searchPattern);
            final ResultSet rs = statement.executeQuery();
            String tableName = "";
            while (rs.next()) {
                tableName = new String(rs.getString(1));
                allTables.add(tableName);
            }

        } catch (final Exception e) {

            throw new SQLException("ControlTableImpl:getAllTablesNamesInSchema:"
                    + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }

        return allTables;

    }

    // ___________________________________________________________________________
    /**
     * Returns the number of rows in a table.
     * 
     * @return int number of rows of data
     * 
     * @throws SQLException
     *           if a database operation fails
     */

    public int getRowsInTable(final String inTableName) throws SQLException {

        PreparedStatement statement = null;
        final Transaction transaction = TransactionFactory
        .getTransaction(DataWarehouseConstants.kDefaultDatabase);
        final Connection connection = transaction.getConnection();
        final String sqlRead = "select count(*) from " + inTableName;
        int rowCount = 0;

        try {
            statement = connection.prepareStatement(sqlRead);

            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                rowCount = rs.getInt(1);
            }
        } catch (final SQLException e) {

            throw e;
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
        }
        return rowCount;
    }

    // ___________________________________________________________________________
    /**
     * Deletes all rows from a table.
     * 
     * @param inTableName
     *          the table name
     * 
     * @throws SQLException
     *           if a database operation fails
     */

    public void truncateTable(final String inTableName) throws SQLException {
        Statement statement = null;
        Transaction transaction = null;
        boolean failed = false;

        try {
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);
            final Connection connection = transaction.getConnection();

            statement = connection.createStatement();
            statement.executeUpdate("delete from " + inTableName);

        } catch (final Exception e) {
            failed = true;
            throw new SQLException("ETLControl:clearStagingTable:" + e.getMessage());
        } finally {
            // release resources
            if (statement != null) {
                statement.close();
            }
            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                } else {
                    transaction.commit();
                }
            }
        }
    }
}
