/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.persistence.transactions;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * This module implement a user transaction, always returns true when is client
 * managed method is called.
 */
class ManagedTransactionImpl implements Transaction {

    /**
     * the transaction
     */
    private final Transaction transaction;

    // ___________________________________________________________________________
    /**
     * Executes a batch and checks the update counts
     * @param inStatement the statement to process
     */
    public int  executeBatch(final Statement inStatement) throws SQLException {
        return TransactionImpl.executeBatchHelper(inStatement);
    }
    /**
     * Creates a new transaction
     * 
     * @param inTransaction
     *          the transaction being propagated to next client
     */
    public ManagedTransactionImpl(final Transaction inTransaction) {
        transaction = inTransaction;
    }

    // ___________________________________________________________________________
    /**
     * Returns the underlying database connection
     * 
     * @return Connection
     */
    public Connection getConnection() {
        Connection connection = null;

        try {
            connection = transaction.getConnection();
        } catch (final Exception e) {// ignore as interface defines exception but never
            // thrown
        }
        return connection;
    }

    // ___________________________________________________________________________
    /**
     * Commits changes to the database
     */
    public void commit() throws SQLException {
        transaction.commit();
    }

    // ___________________________________________________________________________
    /**
     * Rolls back any changes to the database
     */
    public void rollback() throws SQLException {
        transaction.rollback();
    }

    public void clientManagedTransaction() {
        ;
    }

    // ___________________________________________________________________________
    /**
     * Returns true if this transaction was started else where
     * 
     * @return boolean returns true if client code will commit/rollback
     */
    public boolean isClientManagedTransaction() {
        return true;
    }

    // ___________________________________________________________________________
    /**
     * Starts a transaction
     */
    public void start() throws SQLException {// do nothing here, if the DB
        // connection has auto commit turned
        // off
        // ensure client code leave the DB connections in stable state
    }

    // ___________________________________________________________________________
    /**
     * Returns the data source name
     * 
     * @return String the data source name
     */
    public String getDataSourceName() {
        return transaction.getDataSourceName();
    }

    // ___________________________________________________________________________
    /**
     * Returns the data source name
     * 
     * @return String the schema name
     */
    public String getSchemaName() {
        return transaction.getSchemaName();
    }

    // ___________________________________________________________________________
    /**
     * Returns the data source name
     * 
     * @param inSchemaName
     *          the schema name
     */
    public void setSchemaName(final String inSchemaName) {
        transaction.setSchemaName(inSchemaName);
    }
}
