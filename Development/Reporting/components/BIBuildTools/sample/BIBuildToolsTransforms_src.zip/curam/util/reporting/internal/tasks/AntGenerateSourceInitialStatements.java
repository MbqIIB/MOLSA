/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.config.*;

import curam.util.type.*;

/**
 * 
 * This class processes the source initial data template.
 * 
 * This will not be used by clients
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class AntGenerateSourceInitialStatements extends Task {
    /**
     * a full path to the data manager directory
     */
    private String templateFile;

    /**
     * the root reporting directory
     */
    private String reportingDir;

    private ComponentName debugComponentName;



    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     * 
     * @throws BuildException
     */
    @Override
    public void execute() throws BuildException {
        try {
            final Project antProject = getProject();
            String calledFrom;
            if (antProject != null) {
                // if we get a valid ant project object then getBaseDir will
                // return
                // the calling directory, e.g. "components", "core" etc
                // if we are in the "components" directory then build for
                // everything installed on disk.
                // otherwise build for the specific component only
                calledFrom = antProject.getBaseDir().getName();
            } else {
                // if this is not being called from ant we are in debug mode
                // and being executed from with Eclipse of some other Java
                // environment
                calledFrom = debugComponentName.getComponentName();
            }
            // pass in the calling directory to work out what components to build

            final ReportingFileManager fileManager = new ReportingFileManager(calledFrom,
                    reportingDir);
            fileManager.generateSourceInitialData(templateFile);
        } catch (final BuildException e) {
            throw new BuildException(e.getMessage());
        } catch (final Exception e) {
            throw new BuildException(e.getMessage());
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the base reporting directory
     * 
     * @param inReportingDir
     *          base reporting directory
     */
    public void setReportingDir(final String inReportingDir) {
        reportingDir = inReportingDir;
    }

    // ___________________________________________________________________________
    /**
     * the location where the DDL will be written to
     * 
     * @param inDataManagerDirectory
     * 
     */
    public void setInitialDataFile(final String inTemplate) {
        this.templateFile = inTemplate;
    }
}
