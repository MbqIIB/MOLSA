/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.dao.control.base;

import curam.util.type.*;

/**
 * Define the execution state of an ETL process or another object.
 */
@AccessLevel(AccessLevelType.INTERNAL)
public enum ExecutionState {
  /**
   * failed status
   */
  FAILED(1, "failed"),
  /**
   * success status
   */
  SUCCESS(2, "succeeded"), /**
   *
   */
  NEVEREXECUTED(3, "never executed"),
  /**
   * ignored status
   */
  IGNORED(4, "ignored");

  final String description;
  final int code;

  ExecutionState(int inCode, String inDescription) {
    code = inCode;
    description = inDescription;
  }

}