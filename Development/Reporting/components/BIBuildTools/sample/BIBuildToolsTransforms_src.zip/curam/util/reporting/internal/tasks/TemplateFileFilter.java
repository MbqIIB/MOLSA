/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 *
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.io.FilenameFilter;
import curam.util.type.*;

// __________________________________________________________________________
/**
 * Filter allowing only SQL template files.
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class TemplateFileFilter implements FilenameFilter {
  private String filter = ".sqlt";

  private final boolean exact = false;

  public TemplateFileFilter(final String inFilter, boolean inExactMatch) {
    filter = inFilter;
  }

  public boolean accept(File dir, String name) {
    if (exact) {
      int begin = name.length() - filter.length();
      if (begin < 0) {
        begin = 0;
      }
      // return true if this is an ETL tag file
      if (name.substring(begin).equalsIgnoreCase(filter)) {
        return true;
      } else {
        return false;
      }
    } else
    // return true if this is an ETL tag file
    if (name.endsWith(filter)) {
      return true;
    } else {
      return false;
    }
  }

  @Override
  public String toString() {
    return filter + " " + exact;
  }
}
