/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * 
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.reporting.internal.tasks.model.ReportingStaticDataFile;

import curam.util.type.*;

/**
 * Returns a list of files to be processed by the BI build environment.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class FileExplorerStaticData extends FileExplorer {
    /**
     * generic path structure for DDL files
     */
    String relativeJavaSourcePath;

    /**
     * Object used to return the set of file that make up the DDL for a schema for
     * a component
     * 
     * @param inComponentName
     * @param targetDataBaseType
     * @param inReportingDir
     */
    public FileExplorerStaticData(
            final ComponentName inComponentName,
            final TargetDataBaseType targetDataBaseType,
            final String inReportingDir) {
        super(inComponentName, targetDataBaseType, inReportingDir);
        /*
         * set up the template for static data files. the items in <> will be
         * replaced at runtime e.g. <Reporting>\components\<core>\data_manager\
         */
        relativeJavaSourcePath = getReportingDir() + File.separator
        + DataWarehouseConstants.kComponentsDir + File.separator
        + kTemplateComponentDirectoryName + File.separator + "data_manager"
        + File.separator;
    }

    @Override
    public List<ReportingFile> getFiles() throws Exception {
        final File customComponentPath = new File(relativeJavaSourcePath.replaceAll(
                kTemplateComponentDirectoryName, getComponentName()
                .getCustomDirectoryName()));
        final File componentPath =
            new File(relativeJavaSourcePath.replaceAll(
                    kTemplateComponentDirectoryName, getComponentName()
                    .getDirectoryName()));
        final List<ReportingFile> staticDataFiles = new ArrayList<ReportingFile>();
        if (!componentPath.exists()) {
            BILogger.info("Info:" + componentPath + " has no static data");
        }
        final List<File> componentPaths = new ArrayList<File>();
        componentPaths.add(componentPath);
        componentPaths.add(customComponentPath);
        for (int j = 0; j < componentPaths.size(); j++) {
            final File files[] = ((File) componentPaths.get(j)).listFiles();
            boolean custom = false;
            if (j == 1) {
                custom = true;
            }
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    if (files[i].isFile()) {
                        final ReportingStaticDataFile ddFile = new ReportingStaticDataFile(
                                files[i].getCanonicalPath(), custom);
                        ddFile.setComponentName(getComponentName());
                        staticDataFiles.add(ddFile);
                    }
                }
            }
        }
        return staticDataFiles;
    }
}
