/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * 
 */
package curam.util.reporting.internal.tasks.model;

import java.io.File;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.type.*;

@AccessLevel(AccessLevelType.RESTRICTED)
public class ReportingDataTemplateFile extends ReportingFile {
  /**
   * the filter to process demo data template files
   */
  public static final String kDemoDataPropertiesTemplateExtension = ".sqlt";

  public static final String kInitialDataPropertiesTemplateExtension = ".sqlt";

  /**
   * the filter to process demo data properties files
   */
  public static final String kInitialDataPropertiesExtension = ".properties";

  /**
   * filtering files
   */
  public static final String kInitialDataSQLFileExtension = ".sql";

  /**
   * the filter to properties files
   */
  private ReportingDataTemplateFile copyToLocation = null;

  private ComponentName name;

  @Override
  public ComponentName getComponentName() {
    return name;
  }

  @Override
  public void setComponentName(ComponentName name) {
    this.name = name;
  }

  public ReportingDataTemplateFile(String inFileName, boolean inIsCustom) {
    super(inFileName, inIsCustom);
  }

  public File getPropertiesFile() {
    String nameTemp = super.getFileName();
    int index = nameTemp.lastIndexOf(".");
    String fileName = nameTemp.substring(0, index);
    String fileExtension = kInitialDataPropertiesExtension;
    File properties = new File(fileName + fileExtension);
    return properties;
  }

  public File getSQLFile() {
    String nameTemp = super.getFileName();
    int index = nameTemp.lastIndexOf(".");
    String fileName = nameTemp.substring(0, index);
    String fileExtension = kInitialDataSQLFileExtension;
    File sql = new File(fileName + fileExtension);
    return sql;
  }

  public File getTemplateSQLFile() {
    String nameTemp = super.getFileName();
    int index = nameTemp.lastIndexOf(".");
    String fileName = nameTemp.substring(0, index);
    String fileExtension = kDemoDataPropertiesTemplateExtension;
    File template = new File(fileName + fileExtension);
    return template;
  }

  /**
   * 
   * @param inFileName
   *          e.g. dw_properties.sql
   * @param ComponentName
   * @return a file name with the language code added e.g.
   *         dw_properties_en_US.sql
   */
  public static String injectLanguageRegionCode(String inFileName,
      ComponentName inLanguagePack) {
    String nameTemp = inFileName;
    int index = nameTemp.lastIndexOf(".");
    String fileName = nameTemp.substring(0, index);
    String fileExtension = nameTemp.substring(index);
    String template = fileName + "_"
        + inLanguagePack.getLanguageAndRegionCode() + fileExtension;
    return template;
  }

  public void setCopyLocation(ReportingDataTemplateFile inCopyTo) {
    copyToLocation = inCopyTo;
  }

  public ReportingDataTemplateFile getCopyLocation() {
    return copyToLocation;
  }

  @Override
  public String toString() {
    return "\t"
        + super.getFileName()
        + " \n "
        + getPropertiesFile()
        + "\n"
        + getSQLFile()
        + "\n"
        + getTemplateSQLFile()
        + "\n\t\t"
        + (getCopyLocation() == null ? "" : getCopyLocation()
            .getTemplateSQLFile());
  }
}
