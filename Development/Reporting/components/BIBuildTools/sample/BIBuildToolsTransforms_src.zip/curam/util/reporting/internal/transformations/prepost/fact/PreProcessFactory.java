/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.transformations.prepost.fact;

import java.sql.SQLException;

import curam.util.reporting.internal.transformations.prepost.base.PreProcessImpl;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPreProcess;

import curam.util.type.*;

/**
 * This module turns a new object to execute ETL post processing
 * 
 * @since Curam 5.2 SP1
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public final class PreProcessFactory {

  // ___________________________________________________________________________
  /**
   * Returns a new object to update the ETL control table
   * 
   * @return ETLPostProcess an object that implement the interface {link
   *         {@link ETLPreProcess}
   * @throws SQLException
   */
  public static ETLPreProcess newInstance() throws SQLException {
    // returns the base implementation of the data access object
    return new PreProcessImpl() {
    };
  }

}
