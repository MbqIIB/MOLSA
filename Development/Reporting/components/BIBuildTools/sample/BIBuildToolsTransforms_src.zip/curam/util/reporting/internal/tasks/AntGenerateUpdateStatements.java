/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.File;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.config.*;

import curam.util.type.*;

/**
 * 
 * This class update statement for the source application, only setting the last
 * written column to the current date if the value is null.
 * 
 * This build task will include custom directories for client artifacts.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntGenerateUpdateStatements extends Task {
    /**
     * a full path to the data manager directory
     */
    private String targetDirectory;

    /**
     * the root reporting directory
     */
    private String reportingDir;

    private ComponentName debugComponentName;

    /**
     * local test harness
     * 
     * @param inArguments
     * 
     * @throws Exception
     */
    public static void main(final String[] inArguments) throws Exception {
        if (inArguments.length != 1) {
            throw new Exception(
            " buildFileFullPath , ensure to pass the Reporing dir as a parameter using -DREPORTING_DIR=");
        }
        // arg[0] is the build file (full path)
        final File buildFile = new File(inArguments[0]);
        final Project p = new Project();
        p.setUserProperty("ant.file", buildFile.getAbsolutePath());
        p.init();
        final ProjectHelper helper = ProjectHelper.getProjectHelper();
        p.addReference("ant.projectHelper", helper);
        helper.parse(p, buildFile);
        p.executeTarget("database.source.updatenulls");
    }

    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     * 
     * @throws BuildException
     */
    @Override
    public void execute() throws BuildException {
        try {
            final Project antProject = getProject();
            String calledFrom;
            if (antProject != null) {
                // if we get a valid ant project object then getBaseDir will
                // return
                // the calling directory, e.g. "components", "core" etc
                // if we are in the "components" directory then build for
                // everything installed on disk.
                // otherwise build for the specific component only
                calledFrom = antProject.getBaseDir().getName();
            } else {
                // if this is not being called from ant we are in debug mode
                // and being executed from with Eclipse of some other Java
                // environment
                calledFrom = debugComponentName.getComponentName();
            }
            // pass in the calling directory to work out what components to build
            final ReportingFileManager fileManager = new ReportingFileManager(calledFrom,
                    reportingDir);
            fileManager.mergeUpdateSourceFiles(targetDirectory);
        } catch (final BuildException e) {
            throw new BuildException(e.getMessage());
        } catch (final Exception e) {
            throw new BuildException(e.getMessage());
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the base reporting directory
     * 
     * @param inReportingDir
     *          base reporting directory
     */
    public void setReportingDir(final String inReportingDir) {
        reportingDir = inReportingDir;
    }

    // ___________________________________________________________________________
    /**
     * the location where the DDL will be written to
     * 
     * @param inDataManagerDirectory
     * 
     */
    public void setTargetDirectory(final String inDataManagerDirectory) {
        this.targetDirectory = inDataManagerDirectory;
    }
}
