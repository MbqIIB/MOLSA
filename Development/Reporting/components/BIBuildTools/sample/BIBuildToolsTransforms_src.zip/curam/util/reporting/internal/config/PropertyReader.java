/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.config;

import java.util.Hashtable;
import java.util.Properties;

/**
 * This module defines the interface for the data warehouse property reader,
 * this is the interface contract for the property reader
 */
public interface PropertyReader {

  // ___________________________________________________________________________
  /**
   * Returns all properties, does not include environment variables.
   * 
   * @return all properties loaded from the properties files
   * 
   */
  public Properties getAll();

  // ___________________________________________________________________________
  /**
   * Returns the target technology stack brand
   * 
   * @return TechnologyStackBrand returns InfoSphere or OWB
   */
  public TechnologyStackBrand getTechStackVendor();

  // ___________________________________________________________________________
  /**
   * Returns all environment variables
   * 
   * @return {@link Hashtable} keyed by String, with value of type
   *         EnvironmentVariable
   */
  public Hashtable<String, EnvironmentVariable> getEnvironmentVariables();

  // ___________________________________________________________________________
  /**
   * Returns all connection properties
   * 
   * @return ConnectionProperties
   * @throws Exception
   */
  public ConnectionProperties[] getProperties() throws Exception;

  // ___________________________________________________________________________
  /**
   * Returns a data mart connection properties
   * 
   * @param inSchemaName
   *          the logical name to search for.
   * @return ConnectionProperties
   * @throws Exception
   */

  public ConnectionProperties getConnectionProperties(String inSchemaName)
      throws Exception;

  // ___________________________________________________________________________
  /**
   * Returns a property value
   * 
   * @param inKey
   *          the property key
   * 
   * @return the property value, an empty string is return if the property
   *         cannot be found
   */
  public String getValue(String inKey);

  // ___________________________________________________________________________
  /**
   * Return the target database environment
   * 
   * @return TargetDatabaseType the target RDBMS environment
   */
  public TargetDataBaseType getTargetEnvironment();

  // ___________________________________________________________________________
  /**
   * Return the component order
   * 
   * @return ComponentOrder the target RDBMS environment
   */
  // public ComponentOrder getComponentOrder();

}
