/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import curam.util.type.*;

/**
 * This class annotated test results.
 */
@Deprecated
@AccessLevel(AccessLevelType.INTERNAL)
public class AntUpdateTestResults extends Task {
  // ___________________________________________________________________________
  /**
   * Throws a build exception if OMBplus reported errors for a command
   * 
   * @throws BuildException
   */
  @Override
  public void execute() throws BuildException {
  }

  // ___________________________________________________________________________
  /**
   * Sets the base reporting directory
   * 
   * @param inReportingDir
   *          base reporting directory
   */
  public void setReportingDir(String inReportingDir) {
  }

  // ___________________________________________________________________________
  /**
   * the location where the DDL will be written to
   * 
   * @param inTestResultsDirectory
   * 
   */
  public void setTargetDirectory(String inTestResultsDirectory) {
  }
}
