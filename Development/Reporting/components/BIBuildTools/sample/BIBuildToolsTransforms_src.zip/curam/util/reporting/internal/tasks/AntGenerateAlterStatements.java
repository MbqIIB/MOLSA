/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.config.*;

import curam.util.type.*;

/**
 * 
 * This class update statement for the source application, only setting the last
 * written column to the current date if the value is null.
 * 
 * This build task will include custom directories for client artifacts.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntGenerateAlterStatements extends Task {
    /**
     * a full path to file to create
     */
    private String metaDataFile;

    /**
     * a full path to file to create
     */
    private String sqlFile;

    /**
     * the root reporting directory
     */
    private String reportingDir;

    private final ComponentName debugComponentName = new ComponentName("core");

    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     * 
     * @throws BuildException
     */
    @Override
    public void execute() throws BuildException {
        try {
            final Project antProject = getProject();
            String calledFrom;
            if (antProject != null) {
                calledFrom = antProject.getBaseDir().getName();
            } else {
                calledFrom = debugComponentName.getComponentName();
            }
            // pass in the calling directory to work out what components to build
            final ReportingFileManager fileManager = new ReportingFileManager(calledFrom,
                    reportingDir);
            final DBUpgradeProcessor dbUpgradeProcessor = new DBUpgradeProcessor();
            dbUpgradeProcessor.process(metaDataFile, sqlFile,
                    fileManager.getTargetDataBaseType());
        } catch (final BuildException e) {
            throw new BuildException(e.getMessage());
        } catch (final Exception e) {
            throw new BuildException(e.getMessage());
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the base reporting directory
     * 
     * @param inReportingDir
     *          base reporting directory
     */
    public void setReportingDir(final String inReportingDir) {
        reportingDir = inReportingDir;
    }

    // ___________________________________________________________________________
    /**
     * the destination file
     * 
     * @param inSourceFile
     * 
     */
    public void setTarget(final String inTargetFile) {
        sqlFile = inTargetFile;
    }

    // ___________________________________________________________________________
    /**
     * the upgrade meta data
     * 
     * @param inSourceFile
     * 
     */
    public void setSource(final String inSourceFile) {
        metaDataFile = inSourceFile;
    }
}
