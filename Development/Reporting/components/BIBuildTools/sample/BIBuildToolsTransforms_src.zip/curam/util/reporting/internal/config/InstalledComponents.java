/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * @deprecated not being used , marked for removal
 */
package curam.util.reporting.internal.config;

/**
 * @deprecated this class was create post V6 SP1 and is not used This class will
 *             be removed.
 * 
 */
@Deprecated
public class InstalledComponents extends ComponentOrder {

  /**
   * 
   */
  public InstalledComponents() {

  }
}
