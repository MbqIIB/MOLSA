/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

/**
 * 
 * Filter class to search for processes
 *
 */
public class OWBFilesSelected {
    /**
     * which schema to build
     */
    public String workSpaceVersion = "";

    /**
     * which schema to build
     */
    public String owbVersion = "";

    /**
     * which schema to build
     */
    public boolean schemasOnly = false;

    /**
     * which schema to build
     */
    public boolean central = false;

    /**
     * which schema to build
     */
    public boolean datamart = false;

    /**
     * which schema to build
     */
    public boolean staging = false;

    /**
     * which schema to build
     */
    public boolean source = false;

    /**
     * which schema to build
     */
    public boolean common = false;

    // allow an export to be completed, for ETL processes only.
    public boolean exportETL = false;

    // default to true
    public boolean importMetaData = true;
}