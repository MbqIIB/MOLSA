/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.dao.control.fact;

import java.sql.SQLException;

import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.dao.control.base.DBUtilitiesImpl;
import curam.util.reporting.internal.dao.control.intf.DBUtilities;

import curam.util.type.*;

/**
 * This module is a factory object return instances of class to update ETL
 * infrastructure tables.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public final class DBUtilitieFactory {

  // __________________________________________________________________________
  /**
   * Ensures this class cannot be created.
   */
  private DBUtilitieFactory() {
  }

  // __________________________________________________________________________
  /**
   * Returns a new object to update the ETL control table.
   * 
   * @param inReportingDBType
   *          the database being accessed
   * 
   * @return ControlTable the data access object
   * @throws SQLException
   *           if a database error occurs
   */
  public static DBUtilities newInstance(final ReportingDBType inReportingDBType)
      throws SQLException {

    // return the base implementation of the data access object
    return new DBUtilitiesImpl(inReportingDBType) {
    };
  }

}
