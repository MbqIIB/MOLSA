/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

import curam.util.type.*;

/**
 * 
 * This class generates SQL data definition statements for the reporting
 * databases.
 * 
 * This build task will include custom directories for client artifacts.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntValidatePropertiesFilesData extends Task {
    /**
     * the root reporting directory
     */
    private String reportingDir;

    /**
     * the root reporting directory
     */
    private String logFile;

    /**
     * the the file set to copy
     */
    private String fileset;

    @SuppressWarnings("unused")
    private final String tokenMarkerCharacter = "";

    @SuppressWarnings("unused")
    private final boolean skip = false;

    @SuppressWarnings("unused")
    private final String prefixed = "";

    // ___________________________________________________________________________
    /**
     * local test harness for developers
     * 
     * @param inArguments
     * @throws Exception
     */
    public static void main(final String[] inArguments) throws Exception {
        if (inArguments.length != 1) {
            throw new Exception(
            " buildFileFullPath , ensure to pass the Reporing dir as a parameter using -DREPORTING_DIR=");
        }
        final AntValidatePropertiesFilesData test = new AntValidatePropertiesFilesData();

        test.reportingDir = inArguments[0];
        test.fileset = "data_manager/initialdata";
        test.logFile = test.reportingDir + "\\propertiestest.txt";
        test.execute();

    }

    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     * 
     * @throws BuildException
     * 
     */
    @Override
    public void execute() throws BuildException {
        try {
            final Project antProject = getProject();
            String calledFrom = "";
            if (antProject != null) {
                // if we get a valid ant project object then getBaseDir will
                // return
                // the calling directory, e.g. "components", "core" etc
                // if we are in the "components" directory then build for
                // everything installed on disk.
                // otherwise build for the specific component only
                calledFrom = antProject.getBaseDir().getName();
            } else {
                calledFrom = "components";
                System.out
                .println("Error:Can't get the ant project:Project ant = getProject");
            }
            final ReportingFileManager fileManager = new ReportingFileManager(calledFrom,
                    reportingDir);
            fileManager.validateProperties(fileset, logFile);
        } catch (final BuildException e) {
            e.printStackTrace();
            throw new BuildException(e.getMessage());
        } catch (final Exception e) {
            e.printStackTrace();
            throw new BuildException(e.getMessage());
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the base reporting directory
     * 
     * @param inReportingDir
     *          base reporting directory
     */
    public void setLogFile(final String inLogDir) {
        logFile = inLogDir;
    }

    // ___________________________________________________________________________
    /**
     * Sets the base reporting directory
     * 
     * @param inReportingDir
     *          base reporting directory
     */
    public void setReportingDir(final String inReportingDir) {
        reportingDir = inReportingDir;
    }

    // ___________________________________________________________________________
    /**
     * the file pattern to search for
     * 
     * @param inCopyPattern
     * 
     */
    public void setFileset(final String inCopyPattern) {
        this.fileset = inCopyPattern;
    }
}
