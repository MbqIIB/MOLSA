/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks;

import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;

@AccessLevel(AccessLevelType.EXTERNAL)
public class BILogger {
    static private Logger logger = null;

    private BILogger() {

    }

    /**
     * returns the default context
     * 
     * @return the velocity context with default tools and default initialization
     * @throws Exception
     */
    private static void configureLog4J() {
        try {
            final ResourceHelper resource = new ResourceHelper();
            // set the verbose parameter to true to see if the properties file
            // is
            // found
            final InputStream resourceStream = resource.findResourceAsStream(
                    "log4j.properties", false);
            if (resourceStream != null) {
                final Properties logProps = new Properties();
                logProps.load(resourceStream);
                PropertyConfigurator.configure(logProps);
                logger = Logger.getLogger("curam.util.reporting");

            }
        } catch (final Exception e) {
            System.out.println("configureLog4J:" + e.getMessage());
        }
    }

    private static Logger getInstance() {
        if (logger == null) {
            BILogger.configureLog4J();
        }
        return logger;
    }

    public static void info(final String inMessage) {
        if (getInstance() != null){
            logger.info(inMessage);
        } else {
            System.out.println(inMessage);
        }
    }

    public static void error(final String inMessage) {
        if (getInstance() != null){
            logger.error(inMessage);
        } else {
            System.out.println(inMessage);
        }
    }

    public static void debug(final String inMessage) {
        if (getInstance() != null){
            logger.debug(inMessage);
        } else {
            System.out.println(inMessage);
        }
    }
}
