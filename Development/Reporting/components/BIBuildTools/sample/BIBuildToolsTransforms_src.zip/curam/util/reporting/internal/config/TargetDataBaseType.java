/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.config;

/**
 * This module provides methods describing the target database type
 * 
 * 
 */
public class TargetDataBaseType {

  /**
   * the target database is oracle
   */
  static public final int kORACLE = 1;

  /**
   * the target database is DB2
   */
  static public final int kDB2 = 2;

  /**
   * Oracle database product name
   */
  public final String kOracleProductName = "Oracle".toUpperCase();

  /**
   * Db2 database type
   */
  public final String kDB2ProductName = "DB2".toUpperCase();

  /**
   * the target database
   */
  private int targetDataBase = 0;

  // ___________________________________________________________________________
  /**
   * Create a new target database object
   * 
   * @param inRDBMSProductName
   *          the db.type property value from the bootstrap properties file, or
   *          the return value of the method getDatabaseProductName from a JDBC
   *          connection object is passed in
   */
  public TargetDataBaseType(String inRDBMSProductName) {

    if (inRDBMSProductName.length() == 0) {
      throw new RuntimeException(
          "TargetDataBaseType:constructor: RDBMS type not supported, must be <"
              + kOracleProductName + "," + kDB2ProductName + "> recieved <"
              + inRDBMSProductName + ">");
    }
    if (kOracleProductName.lastIndexOf(inRDBMSProductName.toUpperCase()) != -1) {
      targetDataBase = kORACLE;

    } else if (inRDBMSProductName.toUpperCase().indexOf(
        kDB2ProductName.toUpperCase()) != -1) {
      targetDataBase = kDB2;

    } else {
      throw new RuntimeException(
          "TargetDataBaseType:constructor: RDBMS type not supported, must be <"
              + kOracleProductName + "," + kDB2ProductName + "> recieved <"
              + inRDBMSProductName + ">");
    }

  }

  // ___________________________________________________________________________
  /**
   * Returns true if the target RDBMS is Oracle
   * 
   * @return boolean true if the target RDBMS is Oracle
   */
  public boolean isORACLE() {
    return targetDataBase == kORACLE;
  }

  // ___________________________________________________________________________
  /**
   * Returns true if the target RDBMS is DB2
   * 
   * @return int -1 for invalid entry, 0 for UDB 1 for ZOS
   */
  public DB2Platform db2Platform(final String inDB2System) {
    if (inDB2System == null || inDB2System.length() == 0) {
      return DB2Platform.NA;
    } else if (inDB2System
        .equalsIgnoreCase(DataWarehouseConstants.kDatabaseTypeUDB)) {
      return DB2Platform.UDB;
    } else if (inDB2System
        .equalsIgnoreCase(DataWarehouseConstants.kDatabaseTypeZOS)) {
      return DB2Platform.ZOS;
    } else {
      return DB2Platform.NA;
    }
  }

  // ___________________________________________________________________________
  /**
   * Returns true if the target RDBMS is DB2
   * 
   * @return boolean true if the target RDBMS is DB2
   */
  public boolean isDB2() {
    return targetDataBase == kDB2;
  }

  /**
   * @return the kDB2ProductName
   */
  public String getProductName() {
    return isDB2() ? kDB2ProductName : kOracleProductName;
  }

  /**
   * @return the kDB2ProductName
   */
  @Override
  public String toString() {
    return (isDB2() ? kDB2ProductName : kOracleProductName);
  }
}
