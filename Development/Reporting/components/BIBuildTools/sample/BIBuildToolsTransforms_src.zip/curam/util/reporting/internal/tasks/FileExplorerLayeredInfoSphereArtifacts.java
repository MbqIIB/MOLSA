/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 *
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.reporting.internal.tasks.model.ReportingInfoSphereFile;
import curam.util.reporting.internal.tasks.model.ReportingProperty;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;

/**
 * Returns a list of InfoSphere files to be processed by the BI build
 * environment.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class FileExplorerLayeredInfoSphereArtifacts extends FileExplorer {
  /**
   * generic path structure for DDL files
   */
  private final String relativeDataPath;

  /*
   * build in
   */
  private ReportingProperty fileset = null;

  private ComponentName targetComponent = null;

  /**
   * Object used to return the set of files that make up the meta data for a
   * component
   * 
   * @param inComponentName
   * @param targetDataBaseType
   * @param inReportingDir
   * @param inFileSet
   *          the directory to process e.g. databases
   */
  public FileExplorerLayeredInfoSphereArtifacts(
      final ComponentName inComponentName,
      final TargetDataBaseType targetDataBaseType,
      final String inReportingDir,
      final ReportingProperty inFileSet,
      final ComponentName inTargetComponent) {
    super(inComponentName, targetDataBaseType, inReportingDir);
    targetComponent = inTargetComponent;
    if (inFileSet != null) {
      fileset = inFileSet;
    }
    /*
     * set up the template for static data files. the items in <> will be
     * replaced at runtime e.g. <Reporting>\components\<core>\data_manager\demo
     * data
     */
    relativeDataPath = getReportingDir() + File.separator
        + DataWarehouseConstants.kComponentsDir + File.separator
        + kTemplateComponentDirectoryName + File.separator + "etl"
        + File.separator + "CuramBIWarehouse" + File.separator
        + fileset.getValue();
  }

  @Override
  public List<ReportingFile> getFiles() throws Exception {
    File componentPath =
        new File(relativeDataPath.replaceAll(
            kTemplateComponentDirectoryName, getComponentName()
                .getDirectoryName()));
    List<ReportingFile> dataFiles = new ArrayList<ReportingFile>();
    if (!componentPath.exists()) {
      BILogger.debug("Searching " + getComponentName().getComponentName()
          + " ... no files to process " + relativeDataPath);
    } else {
    }
    deepSearch(componentPath, dataFiles);
    return dataFiles;
  }

  private void deepSearch(File inFile, List<ReportingFile> inDataFiles)
      throws Exception {
    if (inFile.isDirectory()) {
      File files[] = inFile.listFiles();
      for (int i = 0; i < files.length; i++) {
        if (files != null) {
          deepSearch(files[i], inDataFiles);
        }
      }
    }
    if (inFile.isFile()) {
      String searchPattern = getComponentName().getComponentName();
      String destination = inFile.getAbsolutePath().replaceFirst(searchPattern,
          targetComponent.getComponentName());
      ReportingInfoSphereFile ddFile = new ReportingInfoSphereFile(
          inFile.getAbsolutePath(), false);
      ddFile.setComponentName(getComponentName());
      ddFile.setDestination(createFile(destination, false));
      inDataFiles.add(ddFile);
    }
  }
}
