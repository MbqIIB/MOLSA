/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks.model;

/**
 * A data dictionary object for a column type
 * 
 */
import curam.util.type.*;

/**
 * Internal class
 * 
 */
@AccessLevel(AccessLevelType.RESTRICTED)
public class ColumnType {
  /*
   * the generic type read from file
   */
  private final String demoDataType;

  /**
   * the supported generic types
   */
  static final String kText = "text";

  static final String kNumber = "number";

  static final String kDate = "date";

  static final String kDateTime = "datetime";

  /*
   * the SQL type from the java.sql.Types
   */
  private int sqlType;

  /**
   * initialized a column type
   * 
   * @param inType
   *          the column type from xml
   */
  public ColumnType(String inType) {
    demoDataType = inType;
  }

  /**
   * @throws Exception
   */
  public void validate() throws Exception {
    if (kText.equalsIgnoreCase(demoDataType)) {
      sqlType = java.sql.Types.VARCHAR;
    } else if (kNumber.equalsIgnoreCase(demoDataType)) {
      sqlType = java.sql.Types.INTEGER;
    } else if (kDate.equalsIgnoreCase(demoDataType)) {
      sqlType = java.sql.Types.DATE;
    } else if (kDateTime.equalsIgnoreCase(demoDataType)) {
      sqlType = java.sql.Types.TIMESTAMP;
    }
  }

  @Override
  public String toString() {
    return "type=" + demoDataType;
  }

  /**
   * what is the data type in the xml element
   * 
   * @return boolean
   */
  public boolean isDateTime() {
    return kDateTime.equalsIgnoreCase(demoDataType);
  }

  /**
   * what is the data type in the xml element
   * 
   * @return boolean
   */
  public boolean isDate() {
    return kDate.equalsIgnoreCase(demoDataType);
  }

  /**
   * what is the data type in the xml element
   * 
   * @return boolean
   */
  public boolean isText() {
    return kText.equalsIgnoreCase(demoDataType);
  }

  /**
   * what is the data type in the xml element
   * 
   * @return boolean
   */
  public boolean isNumber() {
    return kNumber.equalsIgnoreCase(demoDataType);
  }

  /**
   * returns the data type as defined in the xml element
   * 
   * @return String
   */
  public String getDataType() {
    return demoDataType;
  }

  /**
   * returns the native SQL data type
   * 
   * @return String
   */
  public int getNativeSQLType() {
    return sqlType;
  }
}
