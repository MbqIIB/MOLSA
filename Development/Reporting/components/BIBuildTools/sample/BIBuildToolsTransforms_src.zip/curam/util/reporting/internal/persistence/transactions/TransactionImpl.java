/*
 * Licensed Materials - Property of IBM Copyright IBM Corporation 2012. All
 * Rights Reserved. US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved. This software is the
 * confidential and proprietary information of Curam Software, Ltd.
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.persistence.transactions;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * This module implements a user transaction
 */
class TransactionImpl implements Transaction {
    /**
     * the connection to the database
     */
    Connection connection = null;

    /**
     * the data store we are connected to
     */
    String dataStoreName;

    /**
     * the data store we are connected to
     */
    String schemaName = "unavailable";

    // ___________________________________________________________________________
    /**
     * Creates a transaction
     * 
     * @param inConnection
     * @param inDataStoreName
     */
    public TransactionImpl(
            final Connection inConnection,
            final String inDataStoreName) {
        connection = inConnection;
        dataStoreName = inDataStoreName;
    }

    // ___________________________________________________________________________
    /**
     * Returns the underlying database connection
     * 
     * @return Connection
     */
    public Connection getConnection() {
        return connection;
    }

    // ___________________________________________________________________________
    /**
     * Commits changes to the database
     */
    public void commit() throws SQLException {
        try {
            connection.commit();
            ((TransactionManagerImpl) TransactionManagerImpl.getInstance())
            .transactionFinished(this);
        } catch (final SQLException e) {
            rollback();
        }
    }

    // ___________________________________________________________________________
    /**
     * Rolls back any changes to the database
     */
    public void rollback() throws SQLException {
        try {
            connection.rollback();
            ((TransactionManagerImpl) TransactionManagerImpl.getInstance())
            .transactionFinished(this);
        } catch (final SQLException e) {
            e.printStackTrace();
            // log exception
        }
    }

    // ___________________________________________________________________________
    /**
     * Executes a batch and check the update count
     * @param inStatement the statement to process
     */
    public int executeBatch(final Statement inStatement) throws SQLException {
        return executeBatchHelper(inStatement);
    }
    // ___________________________________________________________________________
    /**
     * Executes a batch and check the update count
     * @param inStatement the statement to process
     * @return the number of records in the batch
     */
    static protected int executeBatchHelper(final Statement inStatement) throws SQLException {
        int confirmedUpdates = 0;

        try {
            return inStatement.executeBatch().length;
        } catch (final java.sql.BatchUpdateException e) {
            final int[] updateCounts = e.getUpdateCounts();

            for (int i = 0; i < updateCounts.length; i++) {
                if (updateCounts[i] == Statement.SUCCESS_NO_INFO) {
                    confirmedUpdates++;
                } else if (updateCounts[i] == Statement.EXECUTE_FAILED) {
                    System.out.println(
                            "Execution error code " + e.getErrorCode()
                            + ", sqlstate " + e.getSQLState()
                            + " update status is " + updateCounts[i]);
                }
            }

        } catch (final SQLException e) {
            e.printStackTrace();
        }
        return confirmedUpdates;
    }

    // ___________________________________________________________________________
    /**
     * Returns true if this transaction was started locally
     * 
     * @return boolean returns true if client code will commit/rollback
     */
    public boolean isClientManagedTransaction() {
        return false;
    }

    // ___________________________________________________________________________
    /**
     * Starts the transaction
     */
    public void start() throws SQLException {// do nothing here, if the DB
        // connection has auto commit turned
        // off
        // ensure client code leaves the DB connections in stable state
    }

    // ___________________________________________________________________________
    /**
     * Returns the data source
     * 
     * @return String the data source name
     */
    public String getDataSourceName() {
        return dataStoreName;
    }

    // ___________________________________________________________________________
    /**
     * Returns the data source name
     * 
     * @return String the schema name
     */
    public String getSchemaName() {
        return schemaName;
    }

    // ___________________________________________________________________________
    /**
     * Returns the data source name
     * 
     * @param inSchemaName the schema name
     */
    public void setSchemaName(final String inSchemaName) {
        if (inSchemaName != null) {
            schemaName = inSchemaName;
        }
    }
}
