/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003-2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.config;

import java.io.FileNotFoundException;
import java.util.Hashtable;
import java.util.Properties;

/**
 * A reader to generate default connection properties for stored procedure use
 * 
 * 
 */
class PropertyReaderDefaultsImpl extends PropertyReaderImpl {

  // ___________________________________________________________________________
  /**
   * Creates a new connection property reader
   * 
   */
  PropertyReaderDefaultsImpl() throws FileNotFoundException {
    super();
  }

  // ___________________________________________________________________________
  /**
   * Returns all properties
   * 
   * @return all properties from properties files
   */
  @Override
  public Properties getAll() {
    return new Properties();
  }

  // ___________________________________________________________________________
  /**
   * Returns all connection properties
   * 
   * @return ConnectionProperties
   */
  @Override
  public ConnectionProperties[] getProperties() throws Exception {

    final short kDatabases = 3;
    ConnectionProperties[] properties = new ConnectionProperties[kDatabases];

    properties[0] = getConnectionProperties(DataWarehouseConstants.kStagingDatabase);
    properties[1] = getConnectionProperties(DataWarehouseConstants.kCentralDatabase);
    properties[2] = getConnectionProperties(DataWarehouseConstants.kCoreDataMartDatabase);
    return properties;
  }

  // ___________________________________________________________________________
  /**
   * Returns the connection properties for the a default connection URL
   * 
   * @return a default connection URL
   */
  @Override
  public ConnectionProperties getConnectionProperties(String inDatabase)
      throws Exception {

    // the database user identity
    String userid = "";

    // the database password
    String password = "";

    // defined via -D JDBC setting
    String driverName = "";

    // the RDBMS, ORACLE or DB2
    TargetDataBaseType targetDataBaseType = null;

    // the database default connection URL for oracle
    String url = "jdbc:default:connection";

    return new ConnectionProperties(inDatabase, url, userid, password,
        driverName, targetDataBaseType, 2);

  }

  // ___________________________________________________________________________
  /**
   * Returns the target database environment
   * 
   * @return returns null
   */
  @Override
  public TargetDataBaseType getTargetEnvironment() {
    return null;
  }

  // ___________________________________________________________________________
  /**
   * Returns a property value
   * 
   * @param inKey
   *          returns null
   */
  @Override
  public String getValue(String inKey) {
    return null;
  }

  /**
   * @return returns an empty property list
   */
  @Override
  public Hashtable<String, EnvironmentVariable> getEnvironmentVariables() {
    Hashtable<String, EnvironmentVariable> systemProperties = new Hashtable<String, EnvironmentVariable>();
    return systemProperties;
  }

}
