/*
 * Copyright 2010 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.policing;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.ComponentOrder;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.BILogger;
import curam.util.reporting.internal.tasks.DomFactory;
import curam.util.reporting.internal.tasks.FileExplorerInfoSphereArtifacts;
import curam.util.reporting.internal.tasks.FileExplorerOWBData;
import curam.util.reporting.internal.tasks.OWBFilesSelected;
import curam.util.reporting.internal.tasks.ReportingFileManager;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.reporting.internal.tasks.model.ReportingInfoSphereFile;

/**
 * This module reads Reporting configuration data.
 */
public class ETLConfigurationManager {

    private static ETLConfigurationManager instance = null;

    private List<SampleBIObject> deprecated = null;
    // for fast searching
    private final Hashtable<String, SampleBIObject> deprecatedControlEntrySearch = new Hashtable<String, SampleBIObject>();

    private List<SampleBIObject> samples = null;

    public static final String rootTag = "biaconfiguration";
    private static final String notesTag = "notes";
    private static final String sampleTag = "sample";
    private static final String deprecatedElementTag = "deprecated";
    private static final String objectNameAttribute = "objectname";
    private static final String objectTagAttribute = "objecttype";
    private static final String schemaAttribute = "schema";
    private static final String asOfAttribute = "asof";
    private static final String businessComponentAttribute = "businesscomponent";
    private static final String filenameAttribute = "filename";
    private static final String controltablenameAttribute = "controltablename";

    public static File combinedConfigurationFile = new File(
	    DataWarehouseConstants.getComponentsDirectory(),
	    "BIAConfiguration.xml");

    private ETLConfigurationManager() {

    }

    static public ETLConfigurationManager getInstance() {
	if (instance == null) {
	    instance = new ETLConfigurationManager();
	    instance.cache();
	}
	return instance;
    }

    private void cache() {
	final Document document = DomFactory
		.parseXml(combinedConfigurationFile);
	final Element root = document.getDocumentElement();
	read(root);
    }

    /**
     * Read sample and deprecated objects from disk.
     * 
     * @param inFile
     *            the configuration file to read
     * @return List of SampleBIObject objects
     */
    public boolean isDeprecatedControlEntry(final String inName) {

	final boolean found = deprecatedControlEntrySearch.containsKey(inName);
	return found;
    }

    /**
     * Read sample and deprecated objects from disk.
     * 
     * @param inFile
     *            the configuration file to read
     * @return List of SampleBIObject objects
     */
    public List<SampleBIObject> readSampleObjects() {
	return samples;
    }

    /**
     * Read sample and deprecated objects from disk.
     * 
     * @param inFile
     *            the configuration file to read
     * @return List of SampleBIObject objects
     */
    public List<SampleBIObject> readDeprecatedObjects() {
	return deprecated;
    }

    /**
     * Read sample and deprecated objects from disk.
     * 
     * @param inFile
     *            the configuration file to read
     * @return List of SampleBIObject objects
     */
    private void read(final Element root) {
	SampleBIObject sample;

	BILogger.info("ETLConfigurationManager. Reading ..."
		+ deprecatedElementTag);
	List<SampleBIObject> all = new ArrayList<SampleBIObject>();
	NodeList allItems = root.getElementsByTagName(deprecatedElementTag);
	for (int j = 0; j < allItems.getLength(); j++) {
	    final Element item = (Element) allItems.item(j);
	    sample = new SampleBIObject();
	    sample.setAsof(item.getAttribute(asOfAttribute));
	    sample.setBusinesscomponent(item
		    .getAttribute(businessComponentAttribute));

	    sample.setNotes(item.getAttribute(notesTag));

	    // setting the object name will also default the file
	    // name and control table name
	    sample.setObjectname(item.getAttribute(objectNameAttribute));
	    sample.setObjecttype(item.getAttribute(objectTagAttribute));
	    sample.setSchema(item.getAttribute(schemaAttribute));
	    sample.setFilename(item.getAttribute(filenameAttribute));
	    sample.setControltableEntry(item
		    .getAttribute(controltablenameAttribute));
	    sample.setDeprecated();
	    all.add(sample);
	    deprecatedControlEntrySearch.put(sample.getControltableEntry(),
		    sample);

	}
	Collections.sort(all, new SampleNameComparator());
	deprecated = all;

	all = new ArrayList<SampleBIObject>();
	allItems = root.getElementsByTagName(sampleTag);
	for (int j = 0; j < allItems.getLength(); j++) {
	    final Element item = (Element) allItems.item(j);
	    sample = new SampleBIObject();
	    sample.setAsof(item.getAttribute(asOfAttribute));
	    sample.setBusinesscomponent(item
		    .getAttribute(businessComponentAttribute));

	    sample.setNotes(item.getAttribute(notesTag));

	    sample.setObjectname(item.getAttribute(objectNameAttribute));
	    sample.setObjecttype(item.getAttribute(objectTagAttribute));
	    sample.setSchema(item.getAttribute(schemaAttribute));
	    sample.setFilename(item.getAttribute(filenameAttribute));
	    sample.setControltableEntry(item
		    .getAttribute(controltablenameAttribute));
	    all.add(sample);

	}

	Collections.sort(all, new SampleNameComparator());
	samples = all;

    }

    // ___________________________________________________________________________
    /**
     * builds an OWB script to import meta data files
     * 
     * @param inDataManagerDirectory
     * @param inLogDirectory
     * @param inOWBURL
     * @param inOWBFilesSelected
     * @throws Exception
     */
    public List<ReportingFile> readETLNames() throws Exception {
	final OWBFilesSelected inOWBFilesSelected = new OWBFilesSelected();

	// use the application property for the list of components
	List<ComponentName> components = null;
	try {
	    final ReportingFileManager manager = new ReportingFileManager(
		    DataWarehouseConstants.kComponentsDir,
		    DataWarehouseConstants.getBaseDirectory());

	    final ComponentOrder componentsToBuild = manager
		    .getComponentsToBuild(DataWarehouseConstants
			    .getBaseDirectory());
	    components = (ArrayList<ComponentName>) componentsToBuild
		    .getComponentOrder();

	} catch (final Exception e) {
	    e.printStackTrace();
	}
	final Iterator<ComponentName> componentsIterator = components
		.iterator();

	ComponentName componentName = null;
	inOWBFilesSelected.staging = true;
	inOWBFilesSelected.central = true;
	inOWBFilesSelected.datamart = true;

	FileExplorerOWBData fileExplorer;
	BILogger.info("ETLConfigurationManager. Creating ETL list for "
		+ components.toString());

	final List<ReportingFile> owbFiles = new ArrayList<ReportingFile>();
	final TargetDataBaseType targetDataBaseType = new TargetDataBaseType(
		"Oracle");

	while (componentsIterator.hasNext()) {
	    componentName = (ComponentName) componentsIterator.next();
	    fileExplorer = new FileExplorerOWBData(componentName,
		    targetDataBaseType,
		    DataWarehouseConstants.getBaseDirectory(),
		    inOWBFilesSelected);
	    final List<ReportingFile> files = fileExplorer.getFiles();
	    BILogger.info("ETLConfigurationManager. Processing "
		    + componentName.getComponentName() + " found "
		    + files.size());
	    owbFiles.addAll(files);
	}
	return owbFiles;
    }

    // ___________________________________________________________________________
    /**
     * builds an OWB script to import meta data files
     * 
     * @param inDataManagerDirectory
     * @param inLogDirectory
     * @param inOWBURL
     * @param inOWBFilesSelected
     * @throws Exception
     */
    public List<ReportingFile> readETLNamesInfoSphere() throws Exception {
	// use the application property for the list of components
	List<ComponentName> components = null;
	try {
	    final ReportingFileManager manager = new ReportingFileManager(
		    DataWarehouseConstants.kComponentsDir,
		    DataWarehouseConstants.getBaseDirectory());

	    final ComponentOrder componentsToBuild = manager
		    .getComponentsToBuild(DataWarehouseConstants
			    .getBaseDirectory());
	    components = (ArrayList<ComponentName>) componentsToBuild
		    .getComponentOrder();

	} catch (final Exception e) {
	    e.printStackTrace();
	}
	final Iterator<ComponentName> componentsIterator = components
		.iterator();
	final TargetDataBaseType targetDataBaseType = new TargetDataBaseType(
		"DB2");
	FileExplorerInfoSphereArtifacts fileExplorer = null;
	BILogger.info("ETLConfigurationManager. Creating ETL list for "
		+ components.toString());
	// which also include the language pack folders
	final Iterator<ComponentName> names = components.iterator();

	final List<ReportingFile> infoSphereFiles = new ArrayList<ReportingFile>();
	ComponentName componentName = null;

	while (names.hasNext()) {
	    componentName = (ComponentName) names.next();
	    fileExplorer = new FileExplorerInfoSphereArtifacts(componentName,
		    targetDataBaseType,
		    DataWarehouseConstants.getBaseDirectory(), "sub-processes");
	    final List<ReportingFile> files = fileExplorer.getFiles();
	    final int index = 0;
	    for (final ReportingFile infoSphere : files) {
		final ReportingInfoSphereFile file = (ReportingInfoSphereFile) infoSphere;
		String subProcess = file.getFile().getAbsolutePath();
		subProcess = subProcess.toLowerCase();

		subProcess = subProcess.replace("sub-processes", "data-flows");
		String dataFlow = subProcess.replace("_sp.sflowxmi",
			"_ETL.etlmetadataxmi");
		dataFlow = dataFlow.toLowerCase();
		final File dataFlowFile = new File(dataFlow);
		if (dataFlowFile.exists() || subProcess.contains("_trans_")
			|| subProcess.contains("dm_agg")
			|| subProcess.contains("postmapping")
			|| subProcess.contains("premapping")
			|| subProcess.contains("template")) {
		    file.setDataFlow(dataFlowFile);
		    infoSphereFiles.add(file);

		} else {
		    BILogger.error("ETLConfigurationManager. Did not find data flow "
			    + dataFlowFile.getName()
			    + " ["
			    + file.getComponentName().getComponentName() + "]");
		}
	    }

	}

	return infoSphereFiles;
    }

    class SampleNameComparator implements Comparator<SampleBIObject> {

	@Override
	public int compare(final SampleBIObject table1,
		final SampleBIObject table2) {

	    // parameter are of type Object, so we have to downcast it to
	    // Employee
	    // objects

	    final String name1 = ((SampleBIObject) table1).getObjectname();
	    final String name2 = ((SampleBIObject) table2).getObjectname();

	    // uses compareTo method of String class to compare names of the
	    // employee
	    return name1.compareTo(name2);

	}

    }

}
