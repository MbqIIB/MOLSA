/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * 
 */
package curam.util.reporting.internal.tasks.model;

import java.util.ArrayList;
import java.util.List;

import curam.util.reporting.internal.config.ReportingDBType;

import curam.util.type.*;

@AccessLevel(AccessLevelType.RESTRICTED)
public class SchemaGroup {
    private boolean onlyTransformations = false;

    /**
     * which schema to build
     */
    private ReportingDBType central;

    /**
     * which schema to build
     */
    private ReportingDBType datamart;

    /**
     * which schema to build
     */
    private ReportingDBType staging;

    public SchemaGroup() {
    }

    /**
     * returns a list of the logical data source names
     * 
     * @return ReportingDBType
     */
    public ReportingDBType getFirstDataSourcesSelected() {
        if (staging != null) {
            return staging;
        }
        if (central != null) {
            return central;
        }
        if (datamart != null) {
            return datamart;
        }
        return null;
    }

    /**
     * returns a list of the logical data source names
     */
    @Override
    public String toString() {
        final StringBuffer value = new StringBuffer();
        if (staging != null) {
            value.append(staging.getSchemaLogicalName());
        }
        if (central != null) {
            value.append("-").append(central.getSchemaLogicalName());
        }
        if (datamart != null) {
            value.append("-").append(datamart.getSchemaLogicalName());
        }
        return "[schemaGroup:" + value.toString() + "]";
    }

    /**
     * returns a list of the logical data source names
     * 
     * @return List
     */
    public List<ReportingDBType> getDataSourcesSelected() {
        final List<ReportingDBType> selected = new ArrayList<ReportingDBType>();
        if (staging != null) {
            selected.add(staging);
        }
        if (central != null) {
            selected.add(central);
        }
        if (datamart != null) {
            selected.add(datamart);
        }
        return selected;
    }

    /**
     * @param inSchema
     *          the central to set
     */
    public void setThisSchema(final ReportingDBType inSchema) {
        if (inSchema.isStagingArea()) {
            staging = ReportingDBType.getStaging();
        } else if (inSchema.isCentralDB()) {
            central = ReportingDBType.getCentral();
        } else if (inSchema.isDataMart()) {
            datamart = ReportingDBType.getDatamart();
        }
    }


    /**
     * Sets the schema to include the warehouse
     */
    public void setCentral() {
        central = ReportingDBType.getCentral();
    }

    /**
     * Sets the schema to include the datamart
     */
    public void setDatamart() {
        datamart = ReportingDBType.getDatamart();
    }

    /**
     * Sets the schema to include the staging area
     */
    public void setStaging() {
        staging = ReportingDBType.getStaging();
    }

    public void onlyTransformations() {
        onlyTransformations = true;
    }

    public boolean isOnlyTransformations() {
        return onlyTransformations;
    }
    /**
     * Returns all 3 schema
     * 
     */
    public void setAllBISchemas() {
        setStaging();
        setCentral();
        setDatamart();
    }
}
