/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 *
 */
package curam.util.reporting.internal.tasks.model;

import java.io.File;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.type.*;

/**
 * Represents a Reporting file
 * 
 */
@AccessLevel(AccessLevelType.RESTRICTED)
public class ReportingFile {
    private final String fileName;

    private ComponentName componentName = null;

    protected boolean isCustom = false;

    /*
     * custom extension support
     */
    private boolean hasCustom = false;

    private ReportingFile customFile = null;

    private ReportingFile destination = null;

    public ReportingFile(final String fileName, final boolean isCustom) {
        super();
        this.fileName = fileName;
        this.isCustom = isCustom;
    }

    public ReportingFile(final ReportingFile inReportingFile) {
        super();
        fileName = inReportingFile.fileName;
        isCustom = inReportingFile.isCustom;
    }

    public void setDestination(final ReportingFile inDestination) {
        destination = inDestination;
    }

    public ReportingFile getDestination() {
        return destination;
    }

    /**
     * @return the fileName, the full path and file name
     */
    public String getFileName() {
        if (fileName == null) {
            return "";
        }
        return fileName;
    }

    /**
     * @return the fileName, the full path and file name
     */
    public String getFileNameWithoutEntension() {
        int dot = getFile().getName().indexOf('.');
        if (dot == -1){
            dot = 0;
        }
        return getFile().getName().substring(0,dot);
    }

    /**
     * @return the fileName, the full path and file name
     */
    public File getFile() {
        if (fileName != null) {
            return new File(getFileName());
        }
        return new java.io.File("");
    }

    /**
     * @param inCustomFile
     * @return the artifact with the custom properties set.
     */
    public ReportingFile setCustomFileName(final ReportingFile inCustomFile) {
        // if this is a custom file it cannot have a further custom file reference
        inCustomFile.hasCustom = false;
        final ReportingFile newObject = new ReportingFile(this.fileName, false);
        newObject.customFile = inCustomFile;
        newObject.hasCustom = true;
        return newObject;
    }

    /**
     * @return the isCustom
     */
    public boolean isCustom() {
        return isCustom;
    }

    /**
     *
     */
    public void setThisAsCustom() {
        isCustom = true;
    }

    /**
     * @return returns the custom extension for the artifact
     */
    public ReportingFile getCustom() {
        return customFile;
    }

    /**
     * @return true if a custom extension for the artifact exists
     */
    public boolean hasCustom() {
        return hasCustom;
    }

    /**
     * @return String
     */
    @Override
    public String toString() {
        return fileName.toString() + (isCustom() == true ? " custom" : "");
    }

    /**
     * Returns the component name
     * 
     * @return the component name
     */
    public ComponentName getComponentName() {
        return componentName;
    }

    /**
     * sets the component name
     * 
     * @param inComponentName
     *          the component name
     */
    public void setComponentName(final ComponentName inComponentName) {
        componentName = inComponentName;
    }
}
