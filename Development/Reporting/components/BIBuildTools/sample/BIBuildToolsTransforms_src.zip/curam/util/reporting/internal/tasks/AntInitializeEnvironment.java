/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

/**
 * This module set the build file name base on the property file
 * 
 * @deprecated Not used within the build environment
 * @since 5.2 SP3
 */
@Deprecated
public class AntInitializeEnvironment extends Task {
  /**
   * @param args
   * @throws Exception
   */
  static public void main(String args[]) throws Exception {
    new AntInitializeEnvironment().execute();
  }

  // ___________________________________________________________________________
  /**
   * Sets the path to the property file.
   * 
   * @param inDirectory
   *          the path to the property file
   */
  public void setReportingDirectory(final String inDirectory) {
  }

  // ___________________________________________________________________________
  /**
   * Throws a build exception if OMBplus reported errors for a command
   */
  @Override
  @Deprecated
  public void execute() throws BuildException {
  }
}
