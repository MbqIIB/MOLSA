/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 *
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.ReportingDataTemplateFile;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;

/**
 * Returns a list of files to be processed by the BI build environment.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class FileExplorerLocalisableData extends FileExplorer {
  /**
   * generic path structure for DDL files
   */
  private final String relativePath;

  /*
   * build in
   */
  private String fileset = "";

  // private String sourceFilter =
  // ReportingDataTemplateFile.kInitialDataPropertiesTemplateExtension;
  /**
   * Object used to return the set of file that make up the DDL for a schema for
   * a component
   * 
   * @param inComponentName
   * @param targetDataBaseType
   * @param inReportingDir
   * @param inFileSet
   * @param inSourceFileFilter
   */
  public FileExplorerLocalisableData(final ComponentName inComponentName,
      TargetDataBaseType targetDataBaseType, String inReportingDir,
      String inFileSet) {
    super(inComponentName, targetDataBaseType, inReportingDir);
    if (inFileSet != null) {
      fileset = inFileSet;
    }
    fileset = fileset.replace('/', File.separatorChar);
    /*
     * set up the template for static data files. the items in <> will be
     * replaced at runtime e.g. <Reporting>\components\<core>\data_manager\demo
     * data
     */
    relativePath = getReportingDir() + File.separator
        + DataWarehouseConstants.kComponentsDir + File.separator
        + kTemplateComponentDirectoryName + File.separator + fileset
        + File.separator;
  }

  @Override
  public List<ReportingFile> getFiles() throws Exception {
    File customComponentPath = new File(relativePath.replaceAll(
        kTemplateComponentDirectoryName, getComponentName()
            .getCustomDirectoryName()));
    File componentPath = new File(relativePath.replaceAll(
        kTemplateComponentDirectoryName, getComponentName()
            .getDirectoryName()));
    List<ReportingFile> demoDataFiles = new ArrayList<ReportingFile>();
    if (!componentPath.exists()) {
      BILogger.debug("No files to process in "
          + componentPath.getAbsolutePath());
    }
    List<File> componentPaths = new ArrayList<File>();
    String dbDependenTFileName;
    componentPaths.add(componentPath);
    componentPaths.add(customComponentPath);
    int filesFound = 0;
    boolean customPath = false;
    for (int j = 0; j < componentPaths.size(); j++) {
      File files[] = ((File) componentPaths.get(j))
          .listFiles(getFileFilter());
      if (j == 0) {
        customPath = false;
      } else {
        customPath = true;
      }
      if (files != null) {
        for (int i = 0; i < files.length; i++) {
          if (files[i].isFile()) {
            dbDependenTFileName = files[i].getCanonicalPath();
            filesFound++;
            ReportingDataTemplateFile template = new ReportingDataTemplateFile(
                dbDependenTFileName, customPath);
            template.setComponentName(getComponentName());
            demoDataFiles.add(template);
          }
        }
      }
    }
    BILogger.debug(filesFound + " files to be processed in "
        + componentPath.getAbsolutePath());
    return demoDataFiles;
  }
}
