/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.Enumeration;
import java.util.Properties;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.config.ComponentName;

/**
 * This module set the build file name base on the property file
 */
public class AntCopyPropertiesToUTFValues extends Task {
    private String sourceFile = "";

    private String targetFile = "";

    // ___________________________________________________________________________
    /**
     * Sets the path to the error file
     * 
     * @param inFile
     *          path to the file
     */
    public void setSource(final String inFile) {
        sourceFile = inFile;
    }

    // ___________________________________________________________________________
    /**
     * Sets the path to the error file
     * 
     * @param inFile
     *          path to the file
     */
    public void settarget(final String inFile) {
        targetFile = inFile;
    }

    public static void main(final String[] args) throws Exception {
        final AntCopyPropertiesToUTFValues test = new AntCopyPropertiesToUTFValues();
        test.testTokenCopy();
    }

    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     */
    @Override
    public void execute() throws BuildException {
        try {
            final Project antProject = getProject();
            if (antProject != null) {
                // if we get a valid ant project object then getBaseDir will
                // return
                // the calling directory, e.g. "components", "core" etc
                // if we are in the "components" directory then build for
                // everything installed on disk.
                // otherwise build for the specific component only
            } else {
                System.out
                .println("Error:Can't get the ant project:Project ant = getProject");
            }
            final Charset cs1 = Charset.forName("UTF-8");
            final BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(targetFile), cs1));
            final Properties prop = new Properties();
            prop.load(new FileInputStream(sourceFile));
            final Enumeration<Object> keys = prop.keys();
            while (keys.hasMoreElements()) {
                final String next = (String) keys.nextElement();
                final String value = prop.getProperty(next);
                out.write(next + "=" + value);
                out.write(System.getProperty("line.separator"));
            }
            out.flush();
            out.close();
        } catch (final Exception e) {
            throw new BuildException(e.getMessage());
        }
        try {
            testTokenCopy();
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }

    public void testTokenCopy() throws Exception {
        final File sourceFile =
            new File(
            "E:/cc/af_ReportingMain/Reporting/components/core_zh_CN/data_manager/demodata/dim_dimensions_zh_CN.sqlt");
        final File destinationFile =
            new File(
            "E:/cc/af_ReportingMain/Reporting/components/core_zh_CN/data_manager/demodata/dim_dimensions_zh_CN.sql");
        final File propertiesFile =
            new File(
            "E:/cc/af_ReportingMain/Reporting/components/core_zh_CN/data_manager/demodata/dm_dimensions_zh_CN.properties");
        final StringBuffer warnings = new StringBuffer();
        new ReportingConcatenator().copyTemplate(sourceFile, destinationFile,
                propertiesFile, warnings, true, new ComponentName("core"), "'", "");
    }
}
