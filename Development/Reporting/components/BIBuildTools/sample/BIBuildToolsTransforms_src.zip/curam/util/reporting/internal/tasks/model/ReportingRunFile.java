/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * 
 */
package curam.util.reporting.internal.tasks.model;

import curam.util.type.*;

@AccessLevel(AccessLevelType.RESTRICTED)
public class ReportingRunFile extends ReportingFile {
  public ReportingRunFile(String inFileName, boolean inIsCustom) {
    super(inFileName, inIsCustom);
  }
}
