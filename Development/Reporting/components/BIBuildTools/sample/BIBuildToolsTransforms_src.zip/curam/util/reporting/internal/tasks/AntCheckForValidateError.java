/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import curam.util.type.*;

/**
 * This module checks an error file for OMBplus validation error messages
 * throwing a build exception if an error is found.
 * 
 * The following message string are search for with, error reporting is based on
 * which of these values are found:-
 * <ul>
 * <li>Validation message code = Warning</li>
 * <li>Validation message code = Error</li>
 * </ul>
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntCheckForValidateError extends Task {
    /**
     * the name of the error file to check
     */
    private String directory;

    /**
     * check for issues, possible values are [error|warning|info] throw an
     * exception if issues are found for this level
     */
    private boolean failOnWarnings = true;

    private final String warningMessage = "Validation message code = Warning";

    private final String errorMessage = "Validation message code = Error";

    /**
     * the name of the Oracle module to validate[staging|central|datamarts ] see
     * the reporting project inside OWB
     */
    private String module = "";

    /**
     * A java application invocation point.
     * 
     * <ul>
     * <li>The environment variable REPORTING_DIR must be set before executing.</li>
     * <li>The build environment writes OMB logs to the directory
     * <code>logs/validate</code>.</li>
     * <li>The environment variable REPORTING_DIR must be set before executing.</li>
     * </ul>
     * 
     * @param args
     *          args the program arguments, no arguments are required.
     */
    public static void main(final String args[]) {
        final String baseDir = System.getenv("REPORTING_DIR");
        final AntCheckForValidateError task = new AntCheckForValidateError();
        task.setDir(baseDir + File.separator + "logs" + File.separator + "validate");
        task.setLevel("true");
        task.execute();
    }

    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     */
    @Override
    public void execute() throws BuildException {
        try {
            if (directory == null) {
                throw new FileNotFoundException();
            }
            final File[] results = new File(directory)
            .listFiles(new ValidateResultFileFilter(module));
            int i = 0;
            int errorsFound = 0;
            int warningsFound = 0;
            boolean failure = false;
            BILogger.info("Validating files in " + directory);
            for (; results != null && i < results.length; i++) {
                final BufferedReader errorFile = new BufferedReader(
                        new FileReader(results[i]));
                String message;
                while ((message = errorFile.readLine()) != null) {
                    if (message.indexOf(errorMessage) > -1) {
                        errorsFound++;
                        // failure = true;
                    }
                    if (message.indexOf(warningMessage) > -1) {
                        warningsFound++;
                        if (failOnWarnings) {
                            failure = true;
                        }
                    }
                }
                errorFile.close();
                BILogger.info(results[i].getName());
                if (errorsFound > 0) {
                    BILogger.info("    " + " oracle warehouse metadata error: "
                            + errorsFound + " errors found in " + results[i].getName());
                }
                if (warningsFound > 0) {
                    BILogger.info("    " + " oracle warehouse metadata error: "
                            + warningsFound + "warnings found in " + results[i].getName());
                }
                if (errorsFound == 0 && warningsFound == 0) {
                    BILogger.info("    "
                            + "info: OWB meta data validated successfully "
                            + results[i].getName());
                }
                errorsFound = 0;
                warningsFound = 0;
            }
            if (failure) {
                throw new BuildException(
                        "Oracle meta-data issues, see valiation logs in  <" + directory
                        + "> for a detailed description of the issues");
            }
            BILogger.info("");
            BILogger.info("Validated " + module + ", for more information see "
                    + directory);
            BILogger.info("  Info, warning found = " + warningsFound);
            BILogger.info("  Info, errors  found = " + errorsFound);
        } catch (final FileNotFoundException e) {
            throw new BuildException("please specify a valid logs directy <"
                    + directory + ">");
        } catch (final IOException e) {
            throw new BuildException("Error reading file <" + e.getMessage() + ">");
        }
    }

    // ___________________________________________________________________________
    /**
     * Set the directory where the OWB validate results are written to.
     * 
     * @param inDirectory
     *          the directory which contains OWB validate warnings.
     */
    public void setDir(final String inDirectory) {
        directory = inDirectory;
    }

    // ___________________________________________________________________________
    /**
     * A flag which controls how failed is reported.
     * 
     * 
     * @param inFailOnWarnings
     *          true will return a build failure exception if warnings are found,
     *          false will write the warnings to standard output and return a
     *          status of build successful.
     */
    public void setLevel(final String inFailOnWarnings) {
        if (inFailOnWarnings != null) {
            failOnWarnings = Boolean.valueOf(inFailOnWarnings).booleanValue();
        }
    }

    // ___________________________________________________________________________
    /**
     * Set the oracle module to validate e.g. source, staging etc
     * 
     * @param inModule
     *          the error the Oracle module name within OWB, e.g. STAGING
     */
    public void setModule(final String inModule) {
        module = inModule;
    }

    // __________________________________________________________________________
    /**
     * Internal class which filters the files to process.
     */
    class ValidateResultFileFilter implements FilenameFilter {
        String prefix = "";

        public ValidateResultFileFilter(final String inPrefix) {
            if (inPrefix != null) {
                prefix = inPrefix;
            }
        }

        public boolean accept(final File dir, final String name) {
            if (prefix.length() == 0) {
                return true;
            }
            if (name.startsWith(prefix)) {
                return true;
            } else {
                return false;
            }
        }
    }
}
