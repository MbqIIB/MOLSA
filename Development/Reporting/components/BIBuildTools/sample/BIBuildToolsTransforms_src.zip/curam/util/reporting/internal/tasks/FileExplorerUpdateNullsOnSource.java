/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 *
 */
package curam.util.reporting.internal.tasks;

import java.io.File;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.reporting.internal.tasks.model.ReportingUpdateNullsFile;

import curam.util.type.*;

/**
 * Returns a list of files to be processed by the BI build environment.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class FileExplorerUpdateNullsOnSource extends FileExplorerRunScripts {
  /**
   * process only these files
   */
  final private String kRunArtifactPath = "run";

  /**
   * process only these files
   */
  private final String fileNameFilter = "_updateLastWritten.sql";

  /**
   * Object used to return the set of grant scripts for a component
   * 
   * @param inComponentName
   * @param targetDataBaseType
   * @param inReportingDir
   */
  public FileExplorerUpdateNullsOnSource(
      final ComponentName inComponentName,
      TargetDataBaseType targetDataBaseType,
      String inReportingDir) {
    super(inComponentName, targetDataBaseType, inReportingDir);
    setFilter(fileNameFilter);
    buildFilePath();
  }

  // __________________________________________________________________________
  /**
   * Creates a reporting file path
   * 
   * 
   */
  @Override
  protected void buildFilePath() {
    /*
     * set up the template for static data files. the items in <> will be there
     * are no run scripts for db2 replaced at runtime e.g.
     * <Reporting>\components\<core>\run\oracle
     */
    setBuildPath(getReportingDir() + File.separator
        + DataWarehouseConstants.kComponentsDir + File.separator
        + kTemplateComponentDirectoryName + File.separator + kRunArtifactPath
        + File.separator + "oracle" + File.separator);
  }

  // __________________________________________________________________________
  /**
   * Creates a reporting file reference
   * 
   * @return the ReportingFile
   * 
   */
  @Override
  public ReportingFile createFile(String inFile, boolean isCustom) {
    return new ReportingUpdateNullsFile(inFile, isCustom);
  }
}
