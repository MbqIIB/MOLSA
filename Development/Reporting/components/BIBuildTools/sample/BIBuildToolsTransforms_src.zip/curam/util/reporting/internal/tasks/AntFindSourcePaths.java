/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.util.List;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.tasks.model.ReportingFile;

/**
 * This module set the build file name base on the property file
 */
public class AntFindSourcePaths extends Task {
    /**
     * write the build file name to here
     */
    private boolean verbose;

    /**
     * compile all directories, or just custom directories
     */
    private boolean onlyCustomDirs = true;

    /**
     * write the build file name to here
     */
    private String javaSourceComponentName;

    /**
     * write the build file name to here
     */
    private String javaSourcePropertyName;

    /**
     * write the build file name to here
     */
    private String reportingDir;

    /**
     * local test harness for developers
     * 
     * @param inArguments
     * 
     * @throws Exception
     */
    public static void main(final String[] inArguments) throws Exception {
        if (inArguments.length != 1) {
            throw new Exception(
            " buildFileFullPath , ensure to pass the Reporing dir as a parameter using -DREPORTING_DIR=");
        }
        // arg[0] is the build file (full path)
        final File buildFile = new File(inArguments[0]);
        final Project p = new Project();
        p.setUserProperty("ant.file", buildFile.getAbsolutePath());
        p.init();
        final ProjectHelper helper = ProjectHelper.getProjectHelper();
        p.addReference("ant.projectHelper", helper);
        helper.parse(p, buildFile);
        p.executeTarget("compile");
    }

    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     */
    @Override
    public void execute() throws BuildException {
        try {
            final Project antProject = getProject();
            String calledFrom = "";
            if (antProject != null) {
                // if we get a valid ant project object then getBaseDir will
                // return
                // the calling directory, e.g. "components", "core" etc
                // if we are in the "components" directory then build for
                // everything installed on disk.
                // otherwise build for the specific component only
                calledFrom = antProject.getBaseDir().getName();
            } else {
                BILogger.error("Error:Can't get the ant project:Project ant = getProject");
            }
            if (javaSourcePropertyName == null
                    && javaSourcePropertyName.length() == 0
                    && javaSourceComponentName == null
                    && javaSourceComponentName.length() == 0) {
                throw new BuildException(
                "javaSourcePropertyName atrribute or javaSourceComponentName attribute must be set");
            }

            // pass in the calling directory to work out what components to build
            final ReportingFileManager fileManager = new ReportingFileManager(calledFrom,
                    reportingDir);
            // first get the list of directories that can contain Java source code
            final List<ReportingFile> javaSourcePaths = fileManager
            .getJavaSourcePaths(verbose);
            // using the variable javaSourcePaths build two properties
            // 1. to contain a list of component names
            // 2. to build a classpath like string with directory paths
            final ReportingConcatenator cat = new ReportingConcatenator();

            final String paths = cat.buildJavaPaths(javaSourcePaths, File.pathSeparator,
                    onlyCustomDirs);
            if (javaSourcePropertyName != null && javaSourcePropertyName.length() > 0) {
                if (verbose) {

                    BILogger.info("Setting property " + javaSourcePropertyName
                            + "=" + paths);
                }
                getProject().setProperty(javaSourcePropertyName, paths);
            }

            if (javaSourceComponentName != null
                    && javaSourceComponentName.length() > 0) {
                final String list = fileManager.getJavaSourceComponents();
                if (verbose) {
                    BILogger.info("Info, setting " + javaSourceComponentName + "="
                            + list);
                }
                getProject().setProperty(javaSourceComponentName, list);
            } else {
                if (verbose) {
                    BILogger.info("Info, property javaSourceComponentName ["
                            + javaSourceComponentName + "] is empty");
                }
            }
        } catch (final Exception e) {
            throw new BuildException(e.getMessage());
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the path to the error file
     * 
     * @param inReportingDir
     *          path to the error file
     */
    public void setReportingDir(final String inReportingDir) {
        reportingDir = inReportingDir;
    }

    // ___________________________________________________________________________
    /**
     * Sets a classpath like property with the source paths to be used when
     * compiling java files, it will return e.g.
     * 
     * @param inPropertyName
     *          The property name to create.
     */
    public void setJavaSourcePropertyName(final String inPropertyName) {
        javaSourcePropertyName = inPropertyName;
    }

    // ___________________________________________________________________________
    /**
     * Enables verbose output
     * 
     * @param inValue
     *          must be set to <code>true</code>, not case sensitive.
     * 
     */
    public void setVerbose(final String inValue) {
        verbose = Boolean.parseBoolean(inValue);
    }

    // ___________________________________________________________________________
    /**
     * Enables verbose output
     * 
     * @param inValue
     *          must be set to <code>true</code>, not case sensitive.
     * 
     */
    public void setOnlyCustomDirs(final String inValue) {
        onlyCustomDirs = Boolean.parseBoolean(inValue);
    }

    // ___________________________________________________________________________
    /**
     * Sets a property with the component names to be used when compiling java
     * files, it will return <code>core;income support</code>
     * 
     * @param inPropertyName
     *          The property name to create.
     */
    public void setJavaSourceComponentName(final String inPropertyName) {
        if (inPropertyName != null && inPropertyName.length() > 0) {
            javaSourceComponentName = inPropertyName;
        }
    }
}
