/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.transformations.prepost.intf;

import java.sql.SQLException;
import curam.util.type.*;

/**
 * This package provides classes read and write to ETL control tables, and to
 * perform any task that are required before an ETL process is executed.
 *
 *
 *
 * @since Curam 5.2 SP1
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public interface ETLUtility {

  // ___________________________________________________________________________
  /**
   * Right pads a string to a given length.
   *
   * @param inSourceString
   *          String the source string, max of 200 at present
   * @param inLength
   *          the pad length
   * @param inPadChar
   *          the pad character
   * @return the integer value
   * @throws SQLException
   *           if a database operation fails
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public String rpad(final String inSourceString, final int inLength,
      final String inPadChar) throws SQLException;

}
