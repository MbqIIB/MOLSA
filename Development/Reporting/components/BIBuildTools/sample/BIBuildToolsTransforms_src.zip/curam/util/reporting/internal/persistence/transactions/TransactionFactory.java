/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 1999-2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.persistence.transactions;

import java.sql.SQLException;

import curam.util.reporting.internal.config.ConnectionProperties;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.persistence.connectionpool.DataSourceManagerImpl;

import curam.util.type.*;

/**
 * This module provides database transaction handling functionality
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public class TransactionFactory {

    static private String overRideDataSource = null;

    // ___________________________________________________________________________
    /**
     * Returns a transaction object
     * 
     * @param inDataSourceName
     *          the transaction to work with
     * @throws SQLException
     */
    public static void overRideRequestforDefaultTransactions(
            final String inDataSourceName) throws SQLException {
        TransactionManagerImpl.getInstance();
        if (!supportedDataSource(inDataSourceName)) {
            throw new SQLException("DataSource " + inDataSourceName
                    + " is not configured");
        }

        overRideDataSource = inDataSourceName;
    }

    // ___________________________________________________________________________
    /**
     * Returns a transaction object
     * 
     * @return Transaction the transaction to work with
     * @throws SQLException
     */
    public static Transaction getMostRecent() throws SQLException {

        Transaction transaction = null;
        final TransactionManager tm = TransactionManagerImpl.getInstance();

        transaction = tm.getMostRecent();
        return transaction;
    }

    // ___________________________________________________________________________
    /**
     * Returns true if this data source is configured
     * 
     * @param inDataSourceName
     *          the data store name
     * 
     * @return boolean true if data source is configured, false otherwise
     * @throws SQLException
     */
    public static boolean supportedDataSource(final String inDataSourceName)
    throws SQLException {
        return DataSourceManagerImpl.getInstance().supportedDataSource(
                inDataSourceName);
    }

    // ___________________________________________________________________________
    /**
     * Returns a read only transaction object
     * 
     * @param inDataSourceName
     * 
     * 
     * @return Transaction
     * @throws SQLException
     */
    public static Transaction getReadOnlyTransaction(final String inDataSourceName)
    throws SQLException {

        Transaction transaction = null;
        final TransactionManager tm = TransactionManagerImpl.getInstance();

        if (tm.supportedDataSource(inDataSourceName)) {
            transaction = tm.getReadOnlyTransaction(inDataSourceName);
        }
        return transaction;
    }

    // ___________________________________________________________________________
    /**
     * Returns a transaction object
     * 
     * @param inDataSourceName
     *          the data source
     * 
     * @return Transaction
     * @throws SQLException
     */
    public static Transaction getTransaction(String inDataSourceName)
    throws SQLException {
        Transaction transaction = null;

        // when testing outside the RDBMS JVM intercept the call for a
        // default connection and replace it with a call to a database
        // defined in the application.properties file on the class path
        if (inDataSourceName
                .equalsIgnoreCase(DataWarehouseConstants.kDefaultDatabase)
                && overRideDataSource != null) {
            inDataSourceName = overRideDataSource;
        }

        final TransactionManager tm = TransactionManagerImpl.getInstance();

        if (tm.supportedDataSource(inDataSourceName)) {
            transaction = tm.getTransaction(inDataSourceName);
        }

        if (transaction == null) {
            throw new SQLException("DataSource " + inDataSourceName
                    + " is not configured");
        }
        return transaction;
    }

    // ___________________________________________________________________________
    /**
     * Releases any database resources
     */
    static public void releaseResources() {
        ((TransactionManagerImpl) TransactionManagerImpl.getInstance())
        .releaseResources();
    }

    // ___________________________________________________________________________
    /**
     * Returns the target database type for the data source
     * 
     * @param inDataSourceName
     *          the data source name
     * 
     * @return TargetDataBaseType the target database type
     * @throws SQLException
     */
    static public TargetDataBaseType getTargetDatabaseType(String inDataSourceName)
    throws SQLException {

        TargetDataBaseType targetDataBaseType = null;
        final TransactionManager tm = TransactionManagerImpl.getInstance();
        // when testing outside the RDBMS JVM intercept the call for a
        // default connection and replace it with a call to a database
        // defined in the bootstrap.properties file on the class path
        if (inDataSourceName
                .equalsIgnoreCase(DataWarehouseConstants.kDefaultDatabase)
                && overRideDataSource != null) {
            inDataSourceName = overRideDataSource;
        }
        if (tm.supportedDataSource(inDataSourceName)) {
            final ConnectionProperties properties = tm
            .getConnectionProperties(inDataSourceName);

            targetDataBaseType = properties.getTargetDataBaseType();
        }

        if (targetDataBaseType == null) {
            throw new SQLException("DataSource " + inDataSourceName
                    + " is not configured");
        }
        return targetDataBaseType;
    }

}
