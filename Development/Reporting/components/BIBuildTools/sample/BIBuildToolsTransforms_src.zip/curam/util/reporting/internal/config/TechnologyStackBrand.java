/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.util.reporting.internal.config;

/**
 * This class is used enumerate the technology stack vendors.
 * 
 * 
 */

public enum TechnologyStackBrand {
  Infosphere(1, "infosphere"), Oracle(2, "owb");

  private final int code;
  private final String vendor;

  private TechnologyStackBrand(final int inCode, final String inVendor) {
    code = inCode;
    vendor = inVendor;
  }

  /**
   * Returns the technology stack vendor code
   * 
   * @return returns 1 for InfoSphere, 2 for oracle
   */
  public int getCode() {
    return code;
  }

  /**
   * Returns the technology stack vendor
   * 
   * @return returns InfoSphere or oracle
   */
  public String getVendor() {
    return vendor;
  }
}
