/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

import curam.util.type.*;

/**
 * 
 * This Ant task convert a value to upper case.
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntToUpperCase extends Task {
    /**
     * write the build file name to here
     */
    private String propertyName;

    /**
     * write the build file name to here
     */
    private String value;

    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     */
    @Override
    public void execute() throws BuildException {
        try {
            final Project antProject = getProject();
            if (propertyName == null || propertyName.length() == 0) {
                throw new BuildException("javaSourcePropertyName atrribute not set");
            }
            antProject.setProperty(propertyName, value.toUpperCase());
            BILogger.info(propertyName + "=" + value);
        } catch (final Exception e) {
            throw new BuildException(e.getMessage());
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the path to the error file
     * 
     * @param inValue
     *          path to the error file
     */
    public void setValue(final String inValue) {
        value = inValue;
    }

    // ___________________________________________________________________________
    /**
     * Write the drop statements to here
     * 
     * @param inPropertyName
     *          drop statements property name
     */
    public void setPropertyName(final String inPropertyName) {
        propertyName = inPropertyName;
    }
}
