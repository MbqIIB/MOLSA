/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.util.reporting.internal.config;

/**
 * This class is used enumerate the DB2 database platform.
 * 
 * 
 */

public enum DB2Platform {
  UDB(1, "udb"), ZOS(2, "zos"), NA(3, "not available");

  private final int code;
  private final String platform;

  private DB2Platform(final int inCode, final String inVendor) {
    code = inCode;
    platform = inVendor;
  }

  /**
   * Returns the DB2 database platform
   * 
   * @return returns 1 for UDB, 2 for ZOS
   */
  public int getCode() {
    return code;
  }

  /**
   * Returns the DB2 database platform
   * 
   * @return returns 1 for UDB, 2 for ZOS
   */
  public String getPlatform() {
    return platform;
  }

  public String toString() {
    return getPlatform();
  }
}
