/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.config;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;

/**
 * 
 * This package contains classes and interfaces to read application
 * configuration. All access to configuration properties will be made through
 * the interface that this class implements.
 * 
 * This facilitates test and mock object when overriding properties for test
 * purposes
 * 
 * 
 */
class PropertiesCacheImpl implements PropertiesCache {

  /*
   * all environment variables
   */
  private final Hashtable<String, EnvironmentVariable> environmentVariables = new Hashtable<String, EnvironmentVariable>();

  /*
   * all properties, via system or file based
   */
  private final Hashtable<String, EnvironmentVariable> antVariables = new Hashtable<String, EnvironmentVariable>();

  /**
   * This class provides access to the application configuration
   */
  protected PropertiesCacheImpl() {

  }

  /**
   * 
   * the connection details
   */
  PropertyReader reader = null;

  public void initialize(PropertyReader inReader) {
    reader = inReader;
    if (inReader != null) {
      Hashtable<String, EnvironmentVariable> envVariables = inReader
          .getEnvironmentVariables();
      environmentVariables.putAll(envVariables);

      Properties properties = inReader.getAll();
      Enumeration<?> keys = properties.keys();
      String key;
      SystemProperty value;
      while (keys.hasMoreElements()) {
        key = (String) keys.nextElement();
        value = new SystemProperty(key, properties.getProperty(key));
        antVariables.put(key, value);
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Returns the target technology stack brand
   * 
   * @return TechnologyStackBrand returns InfoSphere or OWB
   */
  public TechnologyStackBrand getTechStackVendor() {
    return reader.getTechStackVendor();
  }

  // ___________________________________________________________________________
  /**
   * Returns all properties ant, system or file based
   * 
   * @return Iterator Of type EnvironmentVariable
   */
  public Iterator<EnvironmentVariable> getSystemProperties() {
    return antVariables.values().iterator();
  }

  // ___________________________________________________________________________
  /**
   * Returns all global variables that are defined environment variables, i.e.
   * return via a call to System.getenv
   * 
   * @return Iterator Of type EnvironmentVariable
   */
  public Iterator<EnvironmentVariable> getEnvironmentVariables() {
    return environmentVariables.values().iterator();
  }

  // ___________________________________________________________________________
  /**
   * Adds a property
   * 
   */
  public void add(SystemProperty inProperty) {
    antVariables.put(inProperty.getName(), inProperty);
  }

  // ___________________________________________________________________________
  /**
   * Adds a environment variable
   * 
   */
  public void add(EnvironmentVariable inProperty) {
    environmentVariables.put(inProperty.getName(), inProperty);
  }

  // ___________________________________________________________________________
  /**
   * Returns an environment variable configured within the application
   * configuration files
   * 
   */
  public EnvironmentVariable getEnv(String inName) {
    EnvironmentVariable env = environmentVariables.get(inName);
    if (env == null) {
      env = new EnvironmentVariable(inName);
    }
    return env;
  }

  // ___________________________________________________________________________
  /**
   * Returns an system property variable configured within the application
   * configuration files, or via System.getProperty
   * 
   */
  public SystemProperty getProperty(String inName) {
    SystemProperty property = (SystemProperty) antVariables.get(inName);
    if (property == null) {
      property = new SystemProperty(inName);
    }
    return property;
  }

  @Override
  public String toString() {
    environmentVariables.toString();
    StringBuffer order = new StringBuffer();
    order.append("[env:");
    order.append(environmentVariables.toString());

    order.append("]");
    order.append("[ant:");
    order.append(antVariables.toString());
    order.append("]");
    return order.toString();
  }

  // ___________________________________________________________________________
  /**
   * Returns all connection properties
   * 
   * @return ConnectionProperties
   * @throws Exception
   */
  public ConnectionProperties[] getConnectionProperties() throws Exception {
    return reader.getProperties();
  }

  // ___________________________________________________________________________
  /**
   * Returns a data mart connection properties
   * 
   * @return ConnectionProperties
   */

  public ConnectionProperties getConnectionProperties(String inSchemaName)
      throws Exception {
    return reader.getConnectionProperties(inSchemaName);
  }

  // ___________________________________________________________________________
  /**
   * Returns a property value from the property file
   * 
   * @param inKey
   *          the property key
   * @return the property value, an empty string is return if the property
   *         cannot be found
   */
  public String getValue(String inKey) {
    return reader.getValue(inKey);
  }

  // ___________________________________________________________________________
  /**
   * Return the target database environment
   * 
   * @return TargetDatabaseType the target RDBMS environment
   */
  public TargetDataBaseType getTargetEnvironment() {
    return reader.getTargetEnvironment();
  }

}
