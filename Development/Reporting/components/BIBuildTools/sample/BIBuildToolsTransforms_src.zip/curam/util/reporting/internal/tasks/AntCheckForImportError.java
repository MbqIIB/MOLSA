/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

import curam.util.type.*;

/**
 * This module checks a log file for OWB import errors, throwing a build
 * exception if errors are found. The errors to search for are specified as
 * nested elements within the build file, as are the errors to ignore. For
 * following text values represent an error.
 * 
 * <ul>
 * <li><code>OMB</code></li>
 * <li><code>API</code></li>
 * <li><code>Error</code></li>
 * </ul>
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntCheckForImportError extends Task {
    /**
     * the path to the error file
     */
    private String file;

    // ___________________________________________________________________________
    /**
     * The task entry point.
     */
    @Override
    public void execute() throws BuildException {
        BufferedReader errorFile = null;
        try {
            // a line from the error file
            String message;
            final String kOMB = "OMB";
            final String kAPI = "API";
            final String kERROR = "Error";
            // open the error file
            errorFile = new BufferedReader(new FileReader(file));
            while ((message = errorFile.readLine()) != null) {
                if (message.indexOf(kOMB) > -1 || message.indexOf(kAPI) > -1
                        || message.indexOf(kERROR) > -1) {
                    BILogger.info("oracle warehouse metadata error:" + message);
                    throw new BuildException("Oracle meta-data error, see file <" + file
                            + "> for further details");
                }
            }
        } catch (final FileNotFoundException e) {
            throw new BuildException("File not found <" + file + ">");
        } catch (final IOException e) {
            throw new BuildException("Error reading file <" + file + ">");
        } finally {
            if (errorFile != null) {
                try {
                    errorFile.close();
                } catch (final IOException e) {
                    // nothing we can do here only log the message
                    BILogger.info(e.getMessage());
                }
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the path to the error log file.
     * 
     * @param inFileName
     *          path to the error file, the full path and file name.
     */
    public void setFile(final String inFileName) {
        file = inFileName;
    }
}
