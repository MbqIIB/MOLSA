/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.config;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @deprecated
 *
 */
@Deprecated
public class SystemProperties {
    @SuppressWarnings("rawtypes")
    static private List environmentVariablesOverride = new ArrayList();

    @SuppressWarnings("rawtypes")
    private final List environmentVariables = new ArrayList();
    @SuppressWarnings("rawtypes")
    private final List antVariables = new ArrayList();

    /**
     *
     * @return Iterator a list of {@link EnvironmentVariable}
     */
    @SuppressWarnings("rawtypes")
    public Iterator getProperties() {
        return antVariables.iterator();
    }

    /**
     *
     * @return an Iterator of environment variables.
     */
    @SuppressWarnings("rawtypes")
    public Iterator getEnvironmentVariables() {
        return environmentVariables.iterator();
    }

    /**
     * Adds a property to the cache
     *
     * @param inProperty
     */
    @SuppressWarnings("unchecked")
    public void addProperty(final AntVariable inProperty) {
        antVariables.add(inProperty);
    }

    /**
     * Adds a variable to the cache
     *
     * @param inProperty
     */
    @SuppressWarnings("unchecked")
    public void add(final EnvironmentVariable inProperty) {
        if (inProperty.getClass().getName()
                .equalsIgnoreCase(AntVariable.class.getName())) {
            antVariables.add(inProperty);

        } else {
            environmentVariables.add(inProperty);
        }
    }

    /**
     * Allows writers of test harnesses to override a variables value.
     *
     * @param inProperty
     *          the overridden property
     */
    @SuppressWarnings("unchecked")
    static public void addEnvOverride(final EnvironmentVariable inProperty) {
        environmentVariablesOverride.add(inProperty);
    }

    /**
     * Flushes any variable overrides
     */
    static public void flushEnvOverride() {
        environmentVariablesOverride.clear();
    }

    /**
     * Returns a variable from the cache
     *
     * @param inName
     * @return EnvironmentVariable the EnvironmentVariable if found, otherwise an
     *         empty value is return such that the name and value are set to
     *         <code>NOT_FOUND</code>
     */
    public EnvironmentVariable get(final String inName) {

        EnvironmentVariable envVar;
        envVar = getOverride(inName);

        if (envVar != null) {
            return envVar;
        }
        for (int i = 0; i < environmentVariables.size(); i++) {
            envVar = (EnvironmentVariable) environmentVariables.get(i);
            if (envVar.getName().equalsIgnoreCase(inName)) {
                return envVar;
            }
        }
        return new EnvironmentVariable("NOT_FOUND", "NOT_FOUND");
    }

    /**
     * Returns an over ridden variable is one exists, null otherwise.
     *
     * @param inName
     *          the name of the variable.
     * @return {@link EnvironmentVariable} null if the variable is not over ridden,
     *         otherwise the over ridden variable.
     */
    public EnvironmentVariable getOverride(final String inName) {
        EnvironmentVariable envVar;
        for (int i = 0; i < environmentVariablesOverride.size(); i++) {
            envVar = (EnvironmentVariable) environmentVariablesOverride.get(i);
            if (envVar.getName().equalsIgnoreCase(inName)) {
                return envVar;
            }
        }
        return null;
    }

    @Override
    @SuppressWarnings("rawtypes")
    public String toString() {
        final Iterator envIterator = environmentVariables.listIterator();
        final StringBuffer order = new StringBuffer();
        EnvironmentVariable name;
        order.append("<");
        while (envIterator.hasNext()) {
            name = (EnvironmentVariable) envIterator.next();
            order.append(name);
            if (envIterator.hasNext()) {
                order.append(",");
            }
        }
        final Iterator antIterator = antVariables.iterator();
        order.append(">");
        order.append("<");
        while (antIterator.hasNext()) {
            name = (AntVariable) antIterator.next();
            order.append(name);
            if (antIterator.hasNext()) {
                order.append(",");
            }
        }
        order.append(">");
        return order.toString();
    }
}
