/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks.model;

import java.util.ArrayList;
import java.util.Iterator;

import curam.util.reporting.internal.persistence.transactions.TransactionFactory;

/**
 * A data dictionary object for a data file
 * 
 * This object is populated from an xml file using digester
 * 
 */
import curam.util.type.*;

@AccessLevel(AccessLevelType.RESTRICTED)
public class DemoDataFile {
  /**
   * the data source name, it must be one of the data sources defined in the
   * application property file
   */
  private String dataSource;

  /**
   * a description of the table meta data
   */
  private Table dictionary;

  /**
   * the rows to be inserted
   */
  ArrayList<Row> rows = new ArrayList<Row>();

  public DemoDataFile() {
  }

  public void validate() throws Exception {
    if (!TransactionFactory.supportedDataSource(dataSource)) {
      throw new Exception("database=" + dataSource
          + " is invalid, check application property file");
    }
    if (dictionary != null) {
      dictionary.validate();
    } else {
      throw new Exception("Missing <table> element");
    }
  }

  /**
   * returns the data source name
   * 
   * @return String
   * 
   */
  public String getDatabase() {
    return dataSource;
  }

  /**
   * sets the data source name
   * 
   * @param inDatabase
   *          the data source name
   */
  public void setDatabase(String inDatabase) {
    this.dataSource = inDatabase;
  }

  /**
   * returns the number of rows to be inserted
   * 
   * @return Iterator<Row>
   */
  public Iterator<Row> getRows() {
    return rows.iterator();
  }

  /**
   * adds a row
   * 
   * @param row
   */
  public void addRow(Row row) {
    row.setDictionary(this);
    this.rows.add(row);
  }

  /**
   * returns the dictionary object describing the table meta data
   * 
   * @return Table
   */
  public Table getTable() {
    return dictionary;
  }

  /**
   * sets the dictionary object describing the table meta data
   * 
   * @param table
   * 
   */
  public void addTableMetaData(Table table) {
    this.dictionary = table;
  }

  @Override
  public String toString() {
    StringBuffer out = new StringBuffer();
    out.append("<ProcessControl database=").append(dataSource)
        .append(">" + System.getProperty("line.separator"))
        .append(dictionary.toString());
    out.append("Rows" + System.getProperty("line.separator"));
    Iterator<Row> iterator = rows.iterator();
    Row row;
    while (iterator.hasNext()) {
      row = (Row) iterator.next();
      out.append("\t").append(row.toString());
    }
    out.append("</ProcessControl>");
    return out.toString();
  }
}
