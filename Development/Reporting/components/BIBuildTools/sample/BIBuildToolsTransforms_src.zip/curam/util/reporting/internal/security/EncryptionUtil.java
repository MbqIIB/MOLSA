/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.security;

public final class EncryptionUtil {
  public static String encryptDBPassword(String password) throws Exception {
    String encryptedPassword = encryptPassword(password);
    return encryptedPassword;
  }

  public static String encryptPassword(String password) throws Exception {
    Encryption encryption = new EncryptionConfiguration();
    char[] tmp = password == null ? new char[0] : password.toCharArray();
    return encryption.encrypt(tmp);
  }

  public static String decryptDBPassword(String encryptedPsw) throws Exception {
    String decryptedPassword = decryptPassword(encryptedPsw);
    return decryptedPassword;
  }

  public static String decryptPassword(String encryptedPsw) throws Exception {
    Encryption encryption = new EncryptionConfiguration();
    return encryption.decrypt(encryptedPsw);
  }

  public static String decryptSupersededPassword(String encryptedPsw)
      throws Exception {
    Encryption encryption = new EncryptionConfiguration(6);
    return encryption.decrypt(encryptedPsw);
  }

  /**
   * If the password is not encrypted the password is return.
   * 
   * @param encryptedPsw
   *          the encrypted password to decrypt
   * @return the password as clear text
   * @throws Exception
   */
  public static String decryptDBPasswordDefaulted(String encryptedPsw)
      throws Exception {
    String clearPassword = "na";
    try {
      clearPassword = EncryptionUtil.decryptDBPassword(encryptedPsw);
    } catch (Exception e) {
      // do nothing, the password is already in clear text
      // pass the clear password back.
      throw e;
      // if (clearPassword == null || clearPassword.length() == 0) {
      // clearPassword = encryptedPsw;
      // }
    }
    return clearPassword;
  }
}
