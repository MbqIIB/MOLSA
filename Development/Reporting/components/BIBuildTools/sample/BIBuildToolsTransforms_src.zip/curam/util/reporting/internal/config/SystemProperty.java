/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.config;

/**
 *
 * This class is used to store the result of a system property, a property from
 * a configuration file or a hard coded property with code.
 *
 * All access to properties is through the PropertyCache class, this allows
 * property overrides to be applied for use by mock or test classes.
 *
 *
 */
public class SystemProperty extends EnvironmentVariable {

  /**
   *
   * @param inPropertyName
   *          the property name, it must be unique or it will overwrite a
   *          previous value
   * @param inValue
   *          the property value
   */
  public SystemProperty(String inPropertyName, String inValue) {
    super(inPropertyName, inValue);
    super.validated();
  }

  /**
   * Creates a system property.
   *
   * @param inPropertyName
   *          the property name, it must be unique or it will overwrite a
   *          previous value
   */
  public SystemProperty(String inPropertyName) {
    super(inPropertyName, "");
    super.setValue(System.getProperty(inPropertyName));
    super.validated();
  }

  /**
   * This is a copy constructor.
   *
   * @param inProperty
   *          the environment to be copied
   */
  public SystemProperty(EnvironmentVariable inProperty) {
    super(inProperty);
  }

}
