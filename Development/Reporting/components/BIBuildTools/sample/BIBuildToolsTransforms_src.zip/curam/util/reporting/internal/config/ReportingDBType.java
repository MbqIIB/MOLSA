/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.config;

import curam.util.reporting.internal.persistence.transactions.Transaction;

/**
 * This module defines the database or schema supported by the reporting
 * project.
 * 
 * The supported entity prefixes are:
 * <ul>
 * <li>S_</li>
 * <li>DW_</li>
 * <li>DM_</li>
 * </ul>
 * 
 * The supported schema are:
 * <ul>
 * <li>staging</li>
 * <li>warehouse</li>
 * <li>datamarts</li>
 * </ul>
 */
public final class ReportingDBType {
    /**
     * true if this is an infrastructure table
     */
    public boolean infrastructure = false;

    /**
     * identifies the tier .
     */
    private String tierName;

    /**
     * central data warehouse database prefix.
     */
    static public final String kTierWarehouse = "Warehouse";

    /**
     * staging database prefix.
     */
    static public final String kTierStaging = "Staging";

    /**
     * central data warehouse database prefix
     */
    static public final String kTierDataMart = "Datamart";

    /**
     * prefix for staging tables.
     */
    static private final String kStagingPrefix = "S_";

    /**
     * prefix for central tables.
     */
    static private final String kCentralPrefix = "DW_";

    /**
     * prefix for data mart tables.
     */
    static private final String kDatamartPrefix = "DM_";

    final String dataSourceNames[] = new String[] {
            DataWarehouseConstants.kStagingDatabase,
            DataWarehouseConstants.kCentralDatabase,
            DataWarehouseConstants.kCoreDataMartDatabase };

    /**
     * identifies the schema name.
     */
    private String directoryName;

    /**
     * identifies the schema name.
     */
    private String schemaName;

    /**
     * identifies which database a table resides in.
     */
    private String tablePrefix;

    /**
     * the oracle configuration file for the data warehouse.
     */
    private final int kMinimumTableNameLength = 3;

    // __________________________________________________________________________
    /**
     * Return the reporting database type the table resides in , staging, central
     * or data mart.
     * 
     * @param inDataSource
     *          a table name
     * @throws Exception
     *           if bad table name
     */
    public ReportingDBType(final Transaction inDataSource) throws Exception {
        final ReportingDBType error =
            validateSchemaName(inDataSource.getDataSourceName());
        if (error == null) {
            throw new Exception(inDataSource + " is not a valid data source name");
        }
        init(error.getTablePrefix());
    }

    // __________________________________________________________________________
    /**
     * Return the reporting database type the table resides in , staging, central
     * or data mart.
     * 
     * @param inDataSource
     *          a table name
     * @throws Exception
     *           if bad table name
     */
    public ReportingDBType(final ConnectionProperties poolName) throws Exception {
        final ReportingDBType error = validateSchemaName(poolName.getPoolName());
        if (error == null) {
            throw new Exception(poolName.getPoolName()
                    + " is not a valid data source name");
        }
        init(error.getTablePrefix());
    }

    // __________________________________________________________________________
    /**
     * Return the reporting database type the table resides in , staging, central
     * or data mart.
     * 
     * @param inTableName
     *          a table name
     * @throws Exception
     *           if bad table name
     */
    public ReportingDBType(final String inTableName) throws Exception {
        final String tableName = inTableName.toUpperCase();
        if (tableName == null || tableName.length() <= kMinimumTableNameLength) {
            throw new Exception("<" + tableName
                    + "> is an invalid table name, table name format expected is "
                    + " X_tablename, where X_ is [S_|DW_|DM_]");
        }
        init(tableName);
    }

    // __________________________________________________________________________
    /**
     * Checks if the data source name does not match the logical name for either
     * staging, central or data-marts.
     * 
     * The entity prefixes are:
     * <ul>
     * <li>S_</li>
     * <li>DW_</li>
     * <li>DM_</li>
     * </ul>
     * 
     * @param inTableName
     *          the table name to verify, table names are prefixed and from the
     *          prefix the schema can be derived
     */
    private void init(final String inTableName) throws Exception {
        if (inTableName != null && inTableName.contains("control".toUpperCase())) {
            infrastructure = true;
        }
        if (inTableName.startsWith(kStagingPrefix)) {
            tablePrefix = kStagingPrefix;
            schemaName = DataWarehouseConstants.kStagingDatabase;
            directoryName = schemaName;
            tierName = kTierStaging;
        } else if (inTableName.startsWith(kCentralPrefix)) {
            tablePrefix = kCentralPrefix;
            schemaName = DataWarehouseConstants.kCentralDatabase;
            directoryName = schemaName;
            tierName = kTierWarehouse;
        } else if (inTableName.startsWith(kDatamartPrefix)) {
            tablePrefix = kDatamartPrefix;
            directoryName = "datamarts";
            schemaName = DataWarehouseConstants.kCoreDataMartDatabase;
            tierName = kTierDataMart;
        } else {
            throw new Exception("Invalid table name  " + inTableName);
        }
    }

    // __________________________________________________________________________
    /**
     * Checks if the data source name is valid for either staging, central or
     * data-marts.
     * 
     * @param inSchemaName
     *          the logical schema name.
     * @return ReportingDBType null if invalid schema name, a valid object
     *         otherwise
     * @throws Exception
     */
    public ReportingDBType validateSchemaName(final String inSchemaName)
    throws Exception {
        if (DataWarehouseConstants.kStagingDatabase.equalsIgnoreCase(inSchemaName)) {
            return ReportingDBType.getStaging();
        } else if (DataWarehouseConstants.kCentralDatabase
                .equalsIgnoreCase(inSchemaName)) {
            return ReportingDBType.getCentral();
        } else if (DataWarehouseConstants.kCoreDataMartDatabase
                .equalsIgnoreCase(inSchemaName)) {
            return ReportingDBType.getDatamart();
        } else {
            return null;
        }
    }

    /**
     * 
     * @return the directory name for DDL associated with this schema
     */
    public String getDirectoryName() {
        return directoryName;
    }

    /**
     * 
     * @return the logical schema name associated with this schema, for display
     *         purposes.
     */
    public String getSchemaLogicalNameSentenceCase() {
        return Character.toUpperCase(schemaName.charAt(0))
        + schemaName.substring(1);
    }

    /**
     * 
     * @return the logical schema name associated with this schema.
     */
    public String getSchemaLogicalName() {
        return schemaName;
    }

    /**
     * 
     * @return the logical schema name associated with this schema.
     */
    public String getTierName() {
        return tierName;
    }

    /**
     * 
     * @return the table prefix for this schema.
     */
    public String getTablePrefix() {
        return tablePrefix;
    }

    // __________________________________________________________________________
    /**
     * Returns true if the table resides in the staging database.
     * 
     * @return boolean
     */
    public boolean isStagingArea() {
        return tablePrefix.startsWith(kStagingPrefix);
    }

    // __________________________________________________________________________
    /**
     * Returns true if the table resides in the central database.
     * 
     * @return boolean
     */
    public boolean isCentralDB() {
        return tablePrefix.startsWith(kCentralPrefix);
    }

    // __________________________________________________________________________
    /**
     * Returns true if the table resides in a data mart.
     * 
     * @return boolean
     */
    public boolean isDataMart() {
        return tablePrefix.startsWith(kDatamartPrefix);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result
        + ((tablePrefix == null) ? 0 : tablePrefix.hashCode());
        return result;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ReportingDBType other = (ReportingDBType) obj;
        if (tablePrefix == null) {
            if (other.tablePrefix != null) {
                return false;
            }
        } else if (!tablePrefix.equals(other.tablePrefix)) {
            return false;
        }
        return true;
    }

    // __________________________________________________________________________
    /**
     * Returns the data mart table name.
     * 
     * @param inTableName
     *          a table name
     * @return boolean
     */
    public String addPrefix(final String inTableName) {
        String prefix = kStagingPrefix;
        if (isCentralDB()) {
            prefix = kCentralPrefix;
        } else if (isDataMart()) {
            prefix = kDatamartPrefix;
        }
        return prefix + inTableName;
    }

    /**
     * 
     * @return the database target platform type
     */
    static public ReportingDBType getDatamart() {
        ReportingDBType type = null;
        try {
            type = new ReportingDBType(kDatamartPrefix + "test");
        } catch (final Exception e) {
            //
            e.printStackTrace();
        }
        return type;
    }

    /**
     * 
     * @return the database target platform type
     */
    static public ReportingDBType getCentral() {
        ReportingDBType type = null;
        try {
            type = new ReportingDBType(kCentralPrefix + "test");
        } catch (final Exception e) {
            //
            e.printStackTrace();
        }
        return type;
    }

    /**
     * 
     * @return the database target platform type
     */
    static public ReportingDBType getStaging() {
        ReportingDBType type = null;
        try {
            type = new ReportingDBType(kStagingPrefix + "test");
        } catch (final Exception e) {
            //
            e.printStackTrace();
        }
        return type;
    }

    @Override
    public String toString() {
        return schemaName;
    }

    // __________________________________________________________________________
    /**
     * Returns true if the table is infrastructure.
     * 
     * @return boolean
     */
    public boolean isInfrastructure() {
        return infrastructure;
    }

    /**
     * 
     * @return returns infrastructure table types
     */
    static public ReportingDBType getInfrastructure() {
        ReportingDBType type = null;
        try {
            type = new ReportingDBType(kStagingPrefix + "ETLControl");
        } catch (final Exception e) {
            //
            e.printStackTrace();
        }
        return type;
    }
}
