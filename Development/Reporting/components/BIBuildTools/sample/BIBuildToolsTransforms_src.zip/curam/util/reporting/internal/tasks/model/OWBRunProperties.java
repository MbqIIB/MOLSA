/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks.model;

/**
 * External properties for Oracle mapping execution
 * 
 */
import curam.util.type.*;

@AccessLevel(AccessLevelType.RESTRICTED)
public class OWBRunProperties {
  @Override
  public String toString() {
    return "OWBRunProperties [userName=" + userName + ", stagingLocation="
        + stagingLocation + ", warehouseLocation=" + warehouseLocation
        + ", datamartLocation=" + datamartLocation + ", sourceLocation="
        + sourceLocation + ", staticLocation=" + staticLocation
        + ", systemParams=" + systemParams + ", customParams=" + customParams
        + ",jobtype=" + jopType + "]";
  }

  private String userName = "not set";

  private String stagingLocation = "not set";

  private String warehouseLocation = "not set";

  private String datamartLocation = "not set";

  private String sourceLocation = "not set";

  private String staticLocation = "not set";

  private String systemParams = "not set";

  private String customParams = "not set";

  private String jopType = "not set";

  private String owner = "not set";

  private String template = "not set";

  public String getTemplate() {
    return template;
  }

  public void setTemplate(String template) {
    this.template = template;
  }

  public String getJopType() {
    return jopType;
  }

  public void setJopType(String jopType) {
    this.jopType = jopType;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String inUserName) {
    userName = inUserName;
  }

  public String getStagingLocation() {
    return stagingLocation;
  }

  public void setStagingLocation(String inStagingLocation) {
    stagingLocation = inStagingLocation;
  }

  public String getWarehouseLocation() {
    return warehouseLocation;
  }

  public void setWarehouseLocation(String inWarehouseLocation) {
    warehouseLocation = inWarehouseLocation;
  }

  public String getDatamartLocation() {
    return datamartLocation;
  }

  public void setDatamartLocation(String inDatamartLocation) {
    datamartLocation = inDatamartLocation;
  }

  public String getSourceLocation() {
    return sourceLocation;
  }

  public void setSourceLocation(String inSourceLocation) {
    sourceLocation = inSourceLocation;
  }

  public String getStaticLocation() {
    return staticLocation;
  }

  public void setStaticLocation(String staticLocation) {
    this.staticLocation = staticLocation;
  }

  public String getSystemParams() {
    return systemParams;
  }

  public void setSystemParams(String systemParams) {
    this.systemParams = systemParams;
  }

  public String getCustomParams() {
    return customParams;
  }

  public void setCustomParams(String customParams) {
    this.customParams = customParams;
  }

  public void setOwner(String inOwner) {
    owner = inOwner;
  }

  public String getOwner() {
    return owner;
  }
}
