/*
 * Licensed Materials - Property of IBM Copyright IBM Corporation 2012. All
 * Rights Reserved. US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd. All rights reserved. This software is the
 * confidential and proprietary information of Curam Software, Ltd.
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.xml.sax.SAXException;

/**
 * This module checks a log file for errors, throwing a build exception if
 * errors are found. The errors to search for are specified as nested elements
 * within the build file, as are the errors to ignore. For example:
 */
public class AntCheckXMLWellFormed extends Task {
  /**
   * the file to check.
   */
  private String xmlFile;

  // ___________________________________________________________________________
  /**
   * Invocation point for the ant task.
   * 
   * @throws BuildException if the build tasks fails or if critical errors were
   *           found
   */
  @Override
  public void execute() throws BuildException {
    final java.io.File fileToParse = new File(xmlFile);
    if (!fileToParse.exists()) {
      throw new BuildException("Cannot file file "
          + fileToParse.getAbsolutePath());
    }
    try {
      final DocumentBuilderFactory documentBuilderFactory =
          DocumentBuilderFactory
              .newInstance();
      documentBuilderFactory.setNamespaceAware(true); // never forget this
      final DocumentBuilder documentBuilder = documentBuilderFactory
          .newDocumentBuilder();
      documentBuilder.parse(fileToParse);
      System.out.println("File is well formed " + fileToParse);
    } catch (final SAXException e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    } catch (final IOException e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    } catch (final ParserConfigurationException e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    }
  }

  // ___________________________________________________________________________
  /**
   * The log file to process for errors.
   * 
   * @param inXMLFile - the file to check
   */
  public void setFile(final String inXMLFile) {
    xmlFile = inXMLFile;
  }
}
