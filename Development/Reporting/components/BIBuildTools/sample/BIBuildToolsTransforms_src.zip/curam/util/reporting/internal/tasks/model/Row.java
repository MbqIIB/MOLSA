/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks.model;

import java.util.ArrayList;
import java.util.Iterator;

import curam.util.type.*;

@AccessLevel(AccessLevelType.RESTRICTED)
public class Row {
  /**
   * the rows of data
   */
  ArrayList<Column> attributes = new ArrayList<Column>();

  /**
   * the table meta data, i.e. column names/types
   */
  Table dictionary;

  public Row() {
    super();
  }

  /**
   * not currently being invoked
   * 
   * @param inDictionary
   */
  public void setDictionary(DemoDataFile inDictionary) {
    dictionary = inDictionary.getTable();
  }

  /**
   * returns a named column value from a row of data
   * 
   * @param inColumn
   * @return null or the column object if found
   */
  public Column getColumn(Column inColumn) {
    Iterator<Column> iterator = attributes.iterator();
    Column column = null;
    while (iterator.hasNext()) {
      column = (Column) iterator.next();
      if (column.equals(inColumn)) {
        return column;
      }
    }
    return null;
  }

  /**
   * adds a data value for a column to this row
   * 
   * @param inColumn
   */
  public void addColumn(Column inColumn) {
    this.attributes.add(inColumn);
  }

  @Override
  public String toString() {
    StringBuffer out = new StringBuffer();
    out.append("<row>");
    Iterator<Column> iterator = attributes.iterator();
    Column column;
    while (iterator.hasNext()) {
      column = (Column) iterator.next();
      out.append(" <attribute name=").append(column.getName())
          .append("<value>").append(column.getValue()).append("</value>");
    }
    out.append("</row>");
    return out.toString();
  }
}
