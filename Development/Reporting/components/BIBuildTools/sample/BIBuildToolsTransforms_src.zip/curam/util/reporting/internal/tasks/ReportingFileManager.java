/*
 * Licensed Materials - Property of IBM Copyright IBM Corporation 2012. All
 * Rights Reserved. US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005-2011 Curam Software Ltd. All rights reserved. This software is
 * the confidential and proprietary information of Curam Software, Ltd.
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.LineNumberReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.ComponentOrder;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.PropertiesCache;
import curam.util.reporting.internal.config.PropertyReaderFactory;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.OWBFilesSelected;
import curam.util.reporting.internal.tasks.model.OWBRunProperties;
import curam.util.reporting.internal.tasks.model.ReportingDataTemplateFile;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.reporting.internal.tasks.model.ReportingProperty;

import curam.util.reporting.internal.tasks.model.SchemaGroup;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;

/**
 * This class performs the identification of the files sets to be included by
 * the various build commands.
 */
@AccessLevel (AccessLevelType.INTERNAL)
public class ReportingFileManager {
    private static final String UTF_8 = "UTF-8";

    static public boolean verbose = false;

    /*
     * the components to build
     */
    private ComponentOrder componentsToBuild;

    /*
     * the RDBMS vendor
     */
    private TargetDataBaseType targetDataBaseType;

    /**
     * Returns the target database platform
     * 
     * @return TargetDataBaseType For example, DB2 or Oracle
     */
    public TargetDataBaseType getTargetDataBaseType() {
        return targetDataBaseType;
    }

    /*
     * the base directory
     */
    final String reportingDir;

    /**
     * generic path structure for static data files
     */
    String relativeStaticDataPath;

    /**
     * you are property reader
     */
    PropertiesCache propertyReader;

    public ReportingFileManager(
            final String inCallingDirectory,
            final String inReportingDir) {
        // ensure quite mode
        reportingDir = inReportingDir;
        try {
            componentsToBuild = getComponentsToBuild(inCallingDirectory);
        } catch (final Exception e) {
            e.printStackTrace();
            componentsToBuild = new ComponentOrder();
        }
        targetDataBaseType = propertyReader.getTargetEnvironment();
    }

    // ___________________________________________________________________________
    /**
     * builds a CreateAppTables.sql file
     * 
     * @param inSchemaGroup
     * @param inDestinationDir
     * @throws Exception
     */
    public void mergeDDLFiles(final SchemaGroup inSchemaGroup,
            final String inDestinationDir)
    throws Exception {
        final Iterator < ComponentName > componentsIterator = componentsToBuild
        .getComponentsToInstall();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        final ReportingDBType schema =
            inSchemaGroup.getFirstDataSourcesSelected();
        final String schemaName = schema.getSchemaLogicalNameSentenceCase();
        final String suffixTables = schemaName + "Tables" + ".sql";
        final String suffixTrans = schemaName + "Transformations" + ".sql";
        final File createTables =
            new File(inDestinationDir, "Create" + suffixTables);
        final File dropTables =
            new File(inDestinationDir, "Drop" + suffixTables);
        final File createTrans =
            new File(inDestinationDir, "Create" + suffixTrans);
        final File dropTrans = new File(inDestinationDir, "Drop" + suffixTrans);
        final ReportingConcatenator cat = new ReportingConcatenator();
        if (!inSchemaGroup.isOnlyTransformations()) {
            createNewAndBackupOriginal(createTables);
            createNewAndBackupOriginal(dropTables);
        } else {
            createNewAndBackupOriginal(createTrans);
            createNewAndBackupOriginal(dropTrans);
        }
        while (componentsIterator.hasNext()) {
            componentName = (ComponentName) componentsIterator.next();
            if (!inSchemaGroup.isOnlyTransformations()) {
                fileExplorer = new FileExplorerDBTables(schema, componentName,
                        targetDataBaseType, reportingDir, true);
                cat.concatenateFilesToFile(fileExplorer, createTables);
                fileExplorer = new FileExplorerDBTables(schema, componentName,
                        targetDataBaseType, reportingDir, false);
                cat.concatenateFilesToFile(fileExplorer, dropTables);
            } else {
                fileExplorer =
                    new FileExplorerDBTRansforms(schema, componentName,
                            targetDataBaseType, reportingDir, true);
                cat.concatenateFilesToFile(fileExplorer, createTrans);
                fileExplorer =
                    new FileExplorerDBTRansforms(schema, componentName,
                            targetDataBaseType, reportingDir, false);
                cat.concatenateFilesToFile(fileExplorer, dropTrans);
            }
        }
    }

    public File createNewAndBackupOriginal(final File inFileNameWithFullPath)
    throws Exception {
        try {
            // save the old version first
            final File rename =
                new File(inFileNameWithFullPath.getAbsolutePath());
            final File destination =
                new File(inFileNameWithFullPath.getAbsolutePath());
            if (rename.exists() && !rename.isDirectory()) {
                final File oldFileName =
                    new File(rename.getCanonicalFile() + ".old");
                oldFileName.delete();
                rename.renameTo(oldFileName);
            }
            destination.createNewFile();
            BILogger.info("  created "
                    + inFileNameWithFullPath.getAbsolutePath());
            return destination;
        } catch (final Exception e) {
            BILogger.info("Error:"
                    + inFileNameWithFullPath.getAbsolutePath());
            throw e;
        }
    }

    // ___________________________________________________________________________
    /**
     * Merges static data files
     * 
     * @param inDataManagerDirectory
     * @throws Exception
     */
    public void mergeStaticDataFiles(final String inDataManagerDirectory)
    throws Exception {
        final File outputDirectory = new File(inDataManagerDirectory);
        deleteFilesInDirectory(outputDirectory, null);
        final Iterator < ComponentName > componentsIterator = componentsToBuild
        .getComponentsToInstall();
        List < ReportingFile > ddlFiles = new ArrayList < ReportingFile >();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        while (componentsIterator.hasNext()) {
            componentName = (ComponentName) componentsIterator.next();
            BILogger.info("Processing static files for "
                    + componentName.getComponentName());
            fileExplorer = new FileExplorerStaticData(componentName,
                    targetDataBaseType, reportingDir);
            ddlFiles = fileExplorer.getFiles();
            final ReportingConcatenator cat = new ReportingConcatenator();
            // place all static data files in one data manager directory
            // working by component order, merge any files that already
            // exist on the target directory.
            // null filter required
            cat.concatenateFilesToDirectory(ddlFiles, inDataManagerDirectory,
                    null,
                    null);
        }
    }

    // ___________________________________________________________________________
    /**
     * Merges update nulls utilities
     * 
     * @param inDataManagerDirectory
     * @throws Exception
     */
    public void mergeUpdateSourceFiles(final String inDataManagerDirectory)
    throws Exception {
        final File outputDirectory = new File(inDataManagerDirectory);
        deleteFilesInDirectory(outputDirectory, null);
        final Iterator < ComponentName > componentsIterator = componentsToBuild
        .getComponentsToInstall();
        List < ReportingFile > sqlFiles = new ArrayList < ReportingFile >();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        while (componentsIterator.hasNext()) {
            componentName = (ComponentName) componentsIterator.next();
            fileExplorer = new FileExplorerUpdateNullsOnSource(componentName,
                    targetDataBaseType, reportingDir);
            sqlFiles = fileExplorer.getFiles();
            final ReportingConcatenator cat = new ReportingConcatenator();
            // place all static data files in one data manager directory
            // working by component order, merge any files that already
            // exist on the target directory.
            cat.concatenateUpdateSourceFilesToDirectory(sqlFiles,
                    inDataManagerDirectory, targetDataBaseType);
        }
    }

    // ___________________________________________________________________________
    /**
     * Merges update nulls utilities
     * 
     * @param inDataManagerDirectory
     * @throws Exception
     */
    public void generateSourceInitialData(final String inTemplate)
    throws Exception {
        final ReportingConcatenator cat = new ReportingConcatenator();
        cat.createSourceInitialDataFile(inTemplate, targetDataBaseType);
    }

    // ___________________________________________________________________________
    /**
     * Prototype method at present
     * 
     * @param inTestResultsDirecory
     * @throws Exception
     */
    public void updateBuildTargetNames(final String inTestResultsDirecory)
    throws Exception {
        final Iterator < ComponentName > componentsIterator = componentsToBuild
        .getComponentsToInstall();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        final List < ReportingFile > testResultFiles =
            new ArrayList < ReportingFile >();
        while (componentsIterator.hasNext()) {
            componentName = (ComponentName) componentsIterator.next();
            fileExplorer = new FileExplorerTestResults(componentName,
                    targetDataBaseType, reportingDir, inTestResultsDirecory);
            testResultFiles.addAll(fileExplorer.getFiles());
        }
        final ReportingConcatenator cat = new ReportingConcatenator();
        // place all static data files in one data manager directory
        // working by component order, merge any files that already
        // exist on the target directory.
        cat.updateBuildTargetNames(testResultFiles);
    }

    // ___________________________________________________________________________
    /**
     * builds an OWB script to import meta data files
     * 
     * @param inDataManagerDirectory
     * @param inLogDirectory
     * @param inOWBURL
     * @param inOWBFilesSelected
     * @throws Exception
     */
    public void buildOWBScript(final String inDataManagerDirectory,
            final String inLogDirectory, final String inOWBURL,
            final OWBFilesSelected inOWBFilesSelected) throws Exception {
        final File outputDirectory = new File(inDataManagerDirectory);
        final Iterator < ComponentName > componentsIterator = componentsToBuild
        .getComponentsToInstall();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        if (inOWBFilesSelected.exportETL == true) {
            BILogger.info("Creating export command file");
        } else {
            BILogger.info("Creating import command file");
        }
        final List < ReportingFile > owbFiles =
            new ArrayList < ReportingFile >();
        while (componentsIterator.hasNext()) {
            componentName = (ComponentName) componentsIterator.next();
            BILogger.info("Processing " + componentName.getComponentName());
            fileExplorer =
                new FileExplorerOWBData(componentName, targetDataBaseType,
                        reportingDir, inOWBFilesSelected);
            owbFiles.addAll(fileExplorer.getFiles());
        }
        final ReportingConcatenator cat = new ReportingConcatenator();
        // place all static data files in one data manager directory
        // working by component order, merge any files that already
        // exist on the target directory.
        if (inOWBFilesSelected.exportETL) {
            cat.buildOWBExportETLScript(owbFiles, inDataManagerDirectory,
                    inLogDirectory, inOWBURL, inOWBFilesSelected);
        } else if (inOWBFilesSelected.importMetaData) {
            cat.buildOWBImportScript(owbFiles, inDataManagerDirectory,
                    inLogDirectory, inOWBURL, inOWBFilesSelected);
        }
    }

    // ___________________________________________________________________________
    /**
     * merges Oracle run files
     * 
     * @param inOutputDirectory
     * @param tokens - ETL SQL run syntax
     * @throws Exception
     */
    public void mergeGrantFiles(final String inOutputDirectory,
            final Vector < ReportingProperty > tokens) throws Exception {
        final File outputDirectory = new File(inOutputDirectory);
        deleteFilesInDirectory(outputDirectory, null);
        final Iterator < ComponentName > componentsIterator = componentsToBuild
        .getComponentsToInstall();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        while (componentsIterator.hasNext()) {
            componentName = (ComponentName) componentsIterator.next();
            fileExplorer = new FileExplorerGrantScripts(componentName,
                    targetDataBaseType, reportingDir);
            final ReportingConcatenator cat = new ReportingConcatenator();
            // place all grant files in one manager directory
            // working by component order, merge any files that already
            // exist on the target directory.
            cat.concatenateGrantFilesToDirectory(fileExplorer,
                    inOutputDirectory,
                    tokens);
        }
    }

    // ___________________________________________________________________________
    /**
     * merges Oracle run files
     * 
     * @param inDataManagerDirectory
     * @param inRunProperties - execution properties
     * @param inPost - ETL SQL run syntax
     * @throws Exception
     */
    public void mergeRunFiles(final String inDataManagerDirectory,
            final OWBRunProperties inRunProperties) throws Exception {
        final File outputDirectory = new File(inDataManagerDirectory);
        deleteFilesInDirectory(outputDirectory, null);
        final Iterator < ComponentName > componentsIterator = componentsToBuild
        .getComponentsToInstall();
        List < ReportingFile > runFiles = new ArrayList < ReportingFile >();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        while (componentsIterator.hasNext()) {
            componentName = (ComponentName) componentsIterator.next();
            fileExplorer = new FileExplorerRunScripts(componentName,
                    targetDataBaseType, reportingDir);
            runFiles = fileExplorer.getFiles();
            final ReportingConcatenator cat = new ReportingConcatenator();
            // place all static data files in one data manager directory
            // working by component order, merge any files that already
            // exist on the target directory.
            cat.concatenateRunFilesToDirectory(runFiles,
                    inDataManagerDirectory,
                    inRunProperties);
        }
    }

    // ___________________________________________________________________________
    /**
     * Merges demo data files
     * 
     * @param inDataManagerDirectory
     * @param inFileSet
     * @throws Exception
     */
    public void mergeDemoDataFilesPrint() throws Exception {
        // overriding the standard method of getting components, using a new
        // method
        // which also include the language pack folders
        final List < ComponentName > languagePacks = componentsToBuild
        .getComponentsDemoDataPackToInstall();
        BILogger.info("mergeDemoDataFilesPrint:" + languagePacks);
    }

    // ___________________________________________________________________________
    /**
     * Merges demo data files
     * 
     * @param inDataManagerDirectory
     * @param inFileSet
     * @throws Exception
     */
    public void mergeDemoDataFiles(final String inDataManagerDirectory,
            final String inFileSet)
    throws Exception {
        final File outputDirectory = new File(inDataManagerDirectory);
        deleteFilesInDirectory(outputDirectory, null);
        // overriding the standard method of getting components, using a new
        // method
        // which also include the language pack folders
        final List < ComponentName > languagePacks = componentsToBuild
        .getComponentsDemoDataPackToInstall();
        BILogger.info("installing demo data pack for :" + languagePacks);
        final Iterator < ComponentName > componentsToBeProcessed =
            languagePacks.iterator();
        List < ReportingFile > ddlFiles = new ArrayList < ReportingFile >();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        final SimpleFilter simpleFilter = new SimpleFilter(targetDataBaseType);
        while (componentsToBeProcessed.hasNext()) {
            componentName = (ComponentName) componentsToBeProcessed.next();
            fileExplorer = new FileExplorerDemoData(componentName,
                    targetDataBaseType, reportingDir, inFileSet);
            ddlFiles = fileExplorer.getFiles();
            final ReportingConcatenator cat = new ReportingConcatenator();
            // place all demo data files in one demo data directory
            // working by component order, merge any files that already
            // exist on the target directory.
            final String issueWarningIf = ".value";
            cat.concatenateFilesToDirectory(ddlFiles, inDataManagerDirectory,
                    simpleFilter, issueWarningIf);
        }
    }

    // ___________________________________________________________________________
    /**
     * Merges meta data files
     * 
     * @param inDirectory the base directory
     * @param inPoliceOnly only report name collisions
     * @throws Exception
     */
    public void mergeInfoSphereArtifactsLayered(
            final Vector < ReportingProperty > inDirectories,
            final String inTargetComponent, final Boolean inCleanOnly)
    throws Exception {
        try {
            BILogger.info("Merging up to " + inTargetComponent);
            BILogger.info("Processing " + inDirectories.toString());
            // overriding the standard method of getting components, using a new
            // method
            // which also include the language pack folders
            final ComponentName targetComponent =
                new ComponentName(inTargetComponent);
            final ArrayList < ComponentName > targetComponents =
                new ArrayList < ComponentName >();
            targetComponents.add(targetComponent);
            List < ReportingFile > infoSphereFiles;
            final ComponentName baseComponentName = new ComponentName("core");
            ComponentName theTargetComponent;
            FileExplorer fileExplorer;
            final ReportingConcatenator cat = new ReportingConcatenator();
            final Iterator < ComponentName > names =
                targetComponents.iterator();
            while (names.hasNext()) {
                theTargetComponent = (ComponentName) names.next();
                for (final ReportingProperty reportingProperty : inDirectories) {
                    fileExplorer =
                        new FileExplorerLayeredInfoSphereArtifacts(
                                baseComponentName, targetDataBaseType,
                                reportingDir,
                                reportingProperty, targetComponent);
                    infoSphereFiles = fileExplorer.getFiles();
                    // place all demo data files in one demo data directory
                    // working by component order, merge any files that already
                    // exist on the target directory.
                    if (inCleanOnly) {
                        BILogger.info("Cleaning "
                                + targetComponent.getComponentName()
                                + ", " + infoSphereFiles.size() + " "
                                + reportingProperty.getValue()
                                + " files to be processed");
                    } else {
                        BILogger.info("Processing "
                                + targetComponent.getComponentName()
                                + ", " + infoSphereFiles.size() + " "
                                + reportingProperty.getValue()
                                + " files to be processed");
                    }
                    for (final ReportingFile reportingFile : infoSphereFiles) {
                        if (inCleanOnly) {
                            cat.cleanLayeredInfoSpherefile(reportingFile
                                    .getFile(),
                                    reportingFile.getDestination().getFile(),
                                    theTargetComponent);
                        } else {
                            // no policing is available
                            cat.copyInfoSpherefileLayered(reportingFile
                                    .getFile(),
                                    reportingFile.getDestination().getFile(),
                                    false,
                                    targetComponent);
                        }
                    }
                }
            }
        } catch (final RuntimeException e) {
            e.printStackTrace();
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }

    // ___________________________________________________________________________
    /**
     * Merges demo data files
     * 
     * @param inDataManagerDirectory
     * @param inFileSet
     * @throws Exception
     */
    public void mergeInitialDataFiles(final String inDataManagerDirectory,
            final String inFileSet) throws Exception {
        final File outputDirectory = new File(inDataManagerDirectory);
        deleteFilesInDirectory(outputDirectory, null);
        // overriding the standard method of getting components, using a new
        // method
        // which also include the language pack folders
        final List < ComponentName > languagePacks = componentsToBuild
        .getComponentsToInstallWithLanguagPacks();
        BILogger.info("installing initial data  for :" + languagePacks);
        final Iterator < ComponentName > componentsToBeProcessed =
            languagePacks.iterator();
        List < ReportingFile > ddlFiles = new ArrayList < ReportingFile >();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        final SimpleFilter simpleFilter = new SimpleFilter(targetDataBaseType);
        while (componentsToBeProcessed.hasNext()) {
            componentName = (ComponentName) componentsToBeProcessed.next();
            fileExplorer = new FileExplorerDemoData(componentName,
                    targetDataBaseType, reportingDir, inFileSet);
            ddlFiles = fileExplorer.getFiles();
            final ReportingConcatenator cat = new ReportingConcatenator();
            // place all demo data files in one demo data directory
            // working by component order, merge any files that already
            // exist on the target directory.
            final String issueWarningIf = ".value";
            cat.concatenateFilesToDirectory(ddlFiles, inDataManagerDirectory,
                    simpleFilter, issueWarningIf);
        }
    }

    // ___________________________________________________________________________
    /**
     * Merges demo data files
     * 
     * @param inDataManagerDirectory
     * @param inFileSet
     * @param inReverse
     * @param inTokenMarkerCharacter
     * @throws Exception
     */
    public void localizeDataFiles(final String inDataManagerDirectory,
            final String inFileSet, final String inTokenMarkerCharacter,
            final String inPrefixed)
    throws Exception {
        // overriding the standard method of getting components, using a new
        // method
        // which also include the language pack folders
        final List < ComponentName > languagePacks = componentsToBuild
        .getComponentsToInstallWithLanguagPacks();
        BILogger.info("Processing " + languagePacks);
        final Iterator < ComponentName > componentsToBeProcessed =
            languagePacks.iterator();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        while (componentsToBeProcessed.hasNext()) {
            componentName = (ComponentName) componentsToBeProcessed.next();
            FilenameFilter filter = null;
            int initialData = 0;
            // if initial data then the only files for processing are properties
            if (inFileSet.indexOf("initialdata") != -1) {
                if (componentName.isLanguageAndRegion() < 0) {
                    filter =
                        new TemplateFileFilter(
                                ReportingDataTemplateFile.kInitialDataPropertiesTemplateExtension,
                                false);
                } else {
                    filter =
                        new TemplateFileFilter(
                                componentName.getLanguageAndRegionCode()
                                + ReportingDataTemplateFile.kInitialDataPropertiesTemplateExtension,
                                false);
                }
                initialData = 0;
            } else if (inFileSet.indexOf("demodata") != -1) {
                filter =
                    new TemplateFileFilter(
                            ReportingDataTemplateFile.kDemoDataPropertiesTemplateExtension,
                            false);
                initialData = 1;
            }
            fileExplorer = new FileExplorerLocalisableData(componentName,
                    targetDataBaseType, reportingDir, inFileSet);
            fileExplorer.setFileFilter(filter);
            // deleteFilesInDirectory(outputDirectory, deleteFilter);
            final ReportingConcatenator cat = new ReportingConcatenator();
            cat.generateSQLWithTokeniser(fileExplorer, inDataManagerDirectory,
                    inTokenMarkerCharacter, inPrefixed, initialData);
        }
    }

    // ___________________________________________________________________________
    /**
     * Merges demo data files
     * 
     * @param inDataManagerDirectory
     * @param inFileSet
     * @param inReverse
     * @param inTokenMarkerCharacter
     * @throws Exception
     */
    public void copyTemplateDataFiles(final String inDataManagerDirectory,
            final String inFileSet, final String inTokenMarkerCharacter,
            final String inPrefixed)
    throws Exception {
        // overriding the standard method of getting components, using a new
        // method
        // which also include the language pack folders
        final List < ComponentName > languagePacks = componentsToBuild
        .getComponentsToInstallWithLanguagPacks();
        BILogger.info("Processing " + languagePacks);
        final Iterator < ComponentName > componentsToBeProcessed =
            componentsToBuild
            .getComponentsToInstall();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        while (componentsToBeProcessed.hasNext()) {
            componentName = (ComponentName) componentsToBeProcessed.next();
            FilenameFilter filter = null;
            int initialData = 0;
            // if initial data then the only files for processing are properties
            if (inFileSet.indexOf("initialdata") != -1) {
                filter =
                    new TemplateFileFilter(
                            ReportingDataTemplateFile.kInitialDataPropertiesTemplateExtension,
                            false);
                initialData = 0;
            } else if (inFileSet.indexOf("demodata") != -1) {
                filter =
                    new TemplateFileFilter(
                            ReportingDataTemplateFile.kDemoDataPropertiesTemplateExtension,
                            false);
                initialData = 1;
            }
            fileExplorer = new FileExplorerTemplateData(componentName,
                    targetDataBaseType, reportingDir, inFileSet, languagePacks,
                    initialData);
            fileExplorer.setFileFilter(filter);
            final ReportingConcatenator cat = new ReportingConcatenator();
            cat.copyTemplatesToLanguagePacks(fileExplorer,
                    inTokenMarkerCharacter,
                    inPrefixed, initialData);
        }
    }

    // ___________________________________________________________________________
    /**
     * Builds path for java sources files
     * 
     * @param inVerbose
     * @return List
     * @throws Exception
     */
    public List < ReportingFile > getJavaSourcePaths(final boolean inVerbose)
    throws Exception {
        final Iterator < ComponentName > componentsIterator = componentsToBuild
        .getComponentsToInstall();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        final List < ReportingFile > javaSourcePaths =
            new ArrayList < ReportingFile >();
        List < ReportingFile > paths;
        while (componentsIterator.hasNext()) {
            componentName = (ComponentName) componentsIterator.next();
            fileExplorer = new FileExplorerJavaSource(componentName,
                    targetDataBaseType, reportingDir);
            paths = fileExplorer.getFiles();
            javaSourcePaths.addAll(paths);
        }
        return javaSourcePaths;
    }

    /**
     * build a comma separated list of component names
     * 
     * @return ddlFiles
     */
    public String getJavaSourceComponents() {
        ComponentName name;
        File sourceFile;
        final StringBuffer paths = new StringBuffer();
        final Iterator < ComponentName > componentsIterator = componentsToBuild
        .getComponentsToInstall();
        BILogger.info(componentsToBuild.toString());
        while (componentsIterator.hasNext()) {
            name = componentsIterator.next();
            sourceFile = new File(name.getDirectoryName());
            if (!sourceFile.exists()) {
                BILogger.info("info: no directory"
                        + sourceFile.getAbsolutePath());
            } else {
                paths.append(sourceFile.getName());
                if (componentsIterator.hasNext()) {
                    paths.append(",");
                }
            }
        }
        return paths.toString();
    }

    // ___________________________________________________________________________
    /**
     * Searches for this text on any line
     * 
     * @param inFileToSearch the file to read
     * @param inToken token to search for
     * @return return true if the token was found in the file
     * @throws Exception
     */
    public boolean searchFileForToken(final File inFileToSearch,
            final String inToken)
    throws Exception {
        BufferedReader in = null;
        String line;
        boolean found = false;
        {
            try {
                in = new BufferedReader(new FileReader(inFileToSearch));
                // Transfer bytes from in to out
                while (!found && ( (line = in.readLine()) != null)) {
                    found = line.contains(inToken);
                }
                in.close();
            } finally {
                if (in != null) {
                    in.close();
                }
            }
            return found;
        }
    }

    public int countLines(final String filename) throws Exception {
        final LineNumberReader reader =
            new LineNumberReader(new FileReader(filename));
        int cnt = 0;
        @SuppressWarnings ("unused")
        String lineRead = "";
        while ( (lineRead = reader.readLine()) != null) {
        }
        cnt = reader.getLineNumber();
        reader.close();
        return cnt;
    }

    // ___________________________________________________________________________
    /**
     * @param inCallingDirectoryName
     * @param inCached
     * @throws Exception a build exception if OMBplus reported errors for a
     *             command
     * @return BuildException
     */
    public ComponentOrder getComponentsToBuild(
            final String inCallingDirectoryName,
            final boolean inCached) throws Exception {
        if (this.componentsToBuild != null) {
            return componentsToBuild;
        } else {
            return getComponentsToBuild(inCallingDirectoryName);
        }
    }

    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     * 
     * @param inCallingDirectoryName
     * @return ComponentOrder
     * @throws Exception
     */
    public ComponentOrder getComponentsToBuild(
            final String inCallingDirectoryName)
    throws Exception {
        ComponentOrder toInstall = new ComponentOrder();
        final String propertyFile =
            reportingDir + DataWarehouseConstants.kPropertyFile;
        try {
            // reads the properties file
            propertyReader =
                PropertyReaderFactory.getConnectionPropertyReader();
            targetDataBaseType = propertyReader.getTargetEnvironment();
            toInstall = toInstall.getComponentsToBuild(inCallingDirectoryName,
                    verbose, propertyReader, reportingDir);
            return toInstall;
        } catch (final FileNotFoundException e) {
            throw new Exception("Property File not found <" + propertyFile
                    + ">");
        } catch (final Exception e) {
            e.printStackTrace();
            throw new Exception(e.getMessage());
        }
    }

    // ___________________________________________________________________________
    /**
     * clean up utility method
     * 
     * @param inDirectory
     * @throws Exception
     */
    public void deleteFilesInDirectory(final File inDirectory,
            final FilenameFilter inFilter)
    throws Exception {
        if (!inDirectory.exists() || !inDirectory.canWrite()) {
            try {
                inDirectory.mkdir();
            } catch (final Exception e) {
                throw new Exception("deleteFilesInDirectory: " + inDirectory
                        + " does not exist or is not writable.");
            }
        } else {
            BILogger.info("Cleaning " + inDirectory + ", filter is ");
            if (inFilter != null) {
                BILogger.info(inFilter.toString());
            } else {
                BILogger.info("");
            }
            // clean the output directory
            File[] files = inDirectory.listFiles();
            if (inFilter == null) {
                files = inDirectory.listFiles();
            } else {
                files = inDirectory.listFiles(inFilter);
            }
            if (files != null) {
                for (int i = 0; i < files.length; i++) {
                    if (files[i].isFile()) {
                        if (!files[i].delete()) {
                            BILogger.info("delete files:"
                                    + "could not delete file "
                                    + files[i].getAbsolutePath());
                        }
                    }
                }
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Merges demo data files
     * 
     * @param inDataManagerDirectory
     * @param inFileSet
     * @param inReverse
     * @param inTokenMarkerCharacter
     * @throws Exception
     */
    public void validateProperties(final String inFileSet,
            final String inLogFileName)
    throws Exception {
        // overriding the standard method of getting components, using a new
        // method
        // which also include the language pack folders
        final Iterator < ComponentName > languagePacks = componentsToBuild
        .getComponentsToInstall();
        final File logger =
            new File(inLogFileName.replace("/", File.separator));
        if (logger.exists()) {
            logger.delete();
        }
        if (!logger.createNewFile()) {
            BILogger.error("Error, could not create log file "
                    + logger.getAbsolutePath());
        }
        final Charset utf = Charset.forName(UTF_8);
        final BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(inLogFileName, true), utf));
        out.write("Validating all properties files");
        out.newLine();
        ComponentName componentName = null;
        FileExplorer fileExplorer;
        while (languagePacks.hasNext()) {
            componentName = (ComponentName) languagePacks.next();
            BILogger.info("Processing " + componentName.getComponentName()
                    + " component files " + inFileSet);
            FilenameFilter filter = null;
            @SuppressWarnings ("unused")
            int initialData = 0;
            // if initial data then the only files for processing are properties
            if (inFileSet.indexOf("initialdata") != -1) {
                filter =
                    new TemplateFileFilter(
                            ReportingDataTemplateFile.kInitialDataPropertiesExtension,
                            false);
                initialData = 0;
            } else if (inFileSet.indexOf("demodata") != -1) {
                filter =
                    new TemplateFileFilter(
                            ReportingDataTemplateFile.kInitialDataPropertiesExtension,
                            false);
                initialData = 1;
            }
            fileExplorer = new FileExplorerLocalisableData(componentName,
                    targetDataBaseType, reportingDir, inFileSet);
            fileExplorer.setFileFilter(filter);
            // save the old version first
            ReportingFile name;
            List < ReportingFile > inFiles;
            out.newLine();
            try {
                inFiles = fileExplorer.getFiles();
                for (int i = 0; i < inFiles.size(); i++) {
                    name = (ReportingFile) inFiles.get(i);
                    final File fileName = new File(name.getFileName());
                    BILogger.debug("processing  "
                            + componentName.getComponentName()
                            + " " + fileName.getName());
                    out.write("processing  " + componentName.getComponentName()
                            + " "
                            + fileName.getAbsolutePath());
                    out.newLine();
                    out.write("    validating " + name.getFileName());
                    out.newLine();
                    StringBuffer log = new StringBuffer();
                    ReportingConcatenator.readProperties(fileName, out);
                    out.write(log.toString());
                    out.newLine();
                    out.flush();
                    log = null;
                }
                out.flush();
            } catch (final Exception e1) {
                e1.printStackTrace();
            }
        }
        out.flush();
    }

    // ___________________________________________________________________________
    /**
     * Merges meta data files
     * 
     * @param inDirectory the base directory
     * @param inPoliceOnly only report name collisions
     * @throws Exception
     */
    public void mergeInfoSphereArtifacts(
            final Vector < ReportingProperty > inDirectories,
            final Boolean inPoliceOnly, final Boolean inCleanOnly)
    throws Exception {
        try {
            BILogger.info("Processing " + inDirectories.toString());
            // overriding the standard method of getting components, using a new
            // method
            // which also include the language pack folders
            final Iterator < ComponentName > names = componentsToBuild
            .getComponentsToInstallWithoutCore();
            List < ReportingFile > infoSphereFiles =
                new ArrayList < ReportingFile >();
            ComponentName componentName = null;
            FileExplorer fileExplorer;
            String dirName;
            final ReportingConcatenator cat = new ReportingConcatenator();
            while (names.hasNext()) {
                componentName = (ComponentName) names.next();
                for (final ReportingProperty reportingProperty : inDirectories) {
                    dirName = reportingProperty.getValue();
                    fileExplorer =
                        new FileExplorerInfoSphereArtifacts(componentName,
                                targetDataBaseType, reportingDir, dirName);
                    infoSphereFiles = fileExplorer.getFiles();
                    // place all demo data files in one demo data directory
                    // working by component order, merge any files that already
                    // exist on the target directory.
                    if (inCleanOnly) {
                        BILogger.info("Cleaning "
                                + componentName.getComponentName() + ", "
                                + infoSphereFiles.size() + " " + dirName
                                + " files to be processed");
                    } else {
                        BILogger.info("Processing "
                                + componentName.getComponentName()
                                + ", " + infoSphereFiles.size() + " " + dirName
                                + " files to be processed, policing is set to "
                                + inPoliceOnly);
                    }
                    for (final ReportingFile reportingFile : infoSphereFiles) {
                        if (inCleanOnly) {
                            cat.cleanInfoSpherefile(reportingFile.getFile(),
                                    reportingFile
                                    .getDestination().getFile());
                        } else {
                            cat.copyInfoSpherefile(reportingFile.getFile(),
                                    reportingFile
                                    .getDestination().getFile(),
                                    inPoliceOnly);
                        }
                    }
                }
            }
        } catch (final RuntimeException e) {
            e.printStackTrace();
        } catch (final Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Basic Copy filer
     */
    class SimpleFilter {
        @SuppressWarnings ("unused")
        private final TargetDataBaseType targetDataBaseType;

        public SimpleFilter(final TargetDataBaseType inTargetDataBaseType) {
            targetDataBaseType = inTargetDataBaseType;
        }

        public String process(final String inLine) {
            /*
             * if (targetDataBaseType.isORACLE()) { inLine =
             * inLine.replaceFirst(DataWarehouseConstants.KDemoDataDateTime,
             * DataWarehouseConstants.KDemoDataDateTimeReplacementOracle);
             * inLine = inLine.replace(DataWarehouseConstants.KDemoDataDate,
             * DataWarehouseConstants.KDemoDataDateReplacementOracle); } else if
             * (targetDataBaseType.isDB2()) { inLine =
             * inLine.replace(DataWarehouseConstants.KDemoDataDateTime,
             * DataWarehouseConstants.KDemoDataDateTimeReplacementDB2); inLine =
             * inLine.replace(DataWarehouseConstants.KDemoDataDate,
             * DataWarehouseConstants.KDemoDataDateReplacementDB2); }
             */
            return inLine;
        }
    }
}
