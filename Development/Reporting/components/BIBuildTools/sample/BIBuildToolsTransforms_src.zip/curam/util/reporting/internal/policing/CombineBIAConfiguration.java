/*
 * Copyright 2010 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.policing;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.tasks.BILogger;


public class CombineBIAConfiguration extends Task {

    private String outFile = null;
    private final List<File> files = new ArrayList<File>();
    private final String fileNamePattern = "BIAConfiguration.xml";


    @Override
    public void execute() throws BuildException {
        validateParams();
        final File mergedFile = new File(outFile);
        try {
            BILogger.info("Starting BIA configuration combination tool");
            if( mergedFile.delete() == false) {
                BILogger.info(" could not delete file " + mergedFile.getAbsolutePath());
            }

            getAllFiles(new File (DataWarehouseConstants.getComponentsDirectory()),
                    0);

            createFile(mergedFile, files);
        } catch (final Exception e) {
            BILogger.error("BIA configuration combination tool error:" + e.getMessage());
        }
    }

    private void getAllFiles(final File inDirectory, final int inDepth) {


        final File[] dirFiles = inDirectory.listFiles();
        int depth = 0;
        BILogger.debug(
                "checking " + inDirectory.getName());
        for (int i = 0; i < dirFiles.length; i++) {
            if (dirFiles[i].isDirectory()) {
                if ( inDepth > 1){
                    return;
                } else {
                    getAllFiles(dirFiles[i], depth++);
                }

            } else if (dirFiles[i].getName().equalsIgnoreCase(fileNamePattern)) {
                files.add(dirFiles[i]);
                BILogger.info("found  " + dirFiles[i]);
            }
        }
    }

    private void createFile(final File outputFile, final List<File> files) {

        try {
            final DocumentBuilder builder = DocumentBuilderFactory.newInstance()
            .newDocumentBuilder();
            final Document doc = builder.newDocument();

            final Element root = doc.createElement(ETLConfigurationManager.rootTag );
            doc.appendChild(root);

            for (final Iterator<File> iter = files.iterator(); iter.hasNext();) {

                final File tablesFile = iter.next();
                BILogger.info("merging  " + tablesFile.getAbsolutePath());

                final DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                final DocumentBuilder db = dbFactory.newDocumentBuilder();
                final Document entitiesDoc = db.parse(tablesFile);

                // Get the root element
                final Element otherRoot = entitiesDoc.getDocumentElement();

                final List<Element> allChildren = new ArrayList<Element>();
                final NodeList nodeList = otherRoot.getChildNodes();
                for (int i = 0; i < nodeList.getLength(); i++) {
                    final Node item = nodeList.item(i);
                    if (item instanceof Element) {
                        allChildren.add((Element) item);
                    }
                }

                BILogger.debug ("copying " + allChildren.size() + " child nodes");
                for (int i = 0; i < allChildren.size(); i++) {
                    final Element newTable = (Element) allChildren.get(i);
                    // Make a copy of the original node
                    final Node node_copy = doc.importNode(newTable, true);
                    // Add the node copy to the final document
                    root.appendChild(node_copy);

                }


            }

            // Prepare the DOM document for writing
            final javax.xml.transform.Source source = new javax.xml.transform.dom.DOMSource(
                    doc);
            // Prepare the output file
            final javax.xml.transform.Result result = new javax.xml.transform.stream.StreamResult(
                    outputFile);

            // Write the DOM document to the file
            final javax.xml.transform.Transformer xformer = javax.xml.transform.TransformerFactory
            .newInstance().newTransformer();
            xformer.setOutputProperty(javax.xml.transform.OutputKeys.METHOD, "xml");
            xformer.setOutputProperty(
                    javax.xml.transform.OutputKeys.OMIT_XML_DECLARATION, "no");
            xformer.setOutputProperty(javax.xml.transform.OutputKeys.VERSION, "1.0");
            xformer.setOutputProperty(javax.xml.transform.OutputKeys.ENCODING,
            "UTF-8");
            xformer.setOutputProperty(javax.xml.transform.OutputKeys.INDENT, "yes");
            xformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount",
            "2");

            xformer.transform(source, result);
            BILogger.info("Creating file " + outputFile);

        } catch (final IOException e) {
            e.printStackTrace();
        } catch (final SAXException e) {
            e.printStackTrace();
        } catch (final javax.xml.transform.TransformerConfigurationException e) {
            e.printStackTrace();
        } catch (final ParserConfigurationException e) {
            e.printStackTrace();
        } catch (final javax.xml.transform.TransformerException e) {
            e.printStackTrace();
        }
    }

    private void validateParams() {
        if (outFile == null ) {
            getProject().log("All properties are required", Project.MSG_ERR);
        }
    }



    /**
     * @param string
     */
    public void setCombinedFile(final String string) {
        outFile = string;
    }

}
