/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

/**
 * This module provides a java application which can be used to check database
 * connections to the Reporting schema, the argument to the application must be
 * the schema logical name, e.g. staging, central.
 * 
 * The connection details are read from the bootstrap properties file and a
 * connection is attempted using these properties.
 * 
 * 
 */
public class ResourceHelper {
    // _________________________________________________________________________
    /**
     * Using bootstrap properties tests the connection properties are valid and
     * result is a valid database connection.
     * 
     * @param args
     *          the schema logical name, only 1 argument is expected
     * 
     * @throws java.lang.Exception
     */
    public static void main(final String[] args) throws Exception {
        if (args.length != 1) {
            throw new Exception(
            "Target database expected staging, cdw or datamart.");
        }
    }

    /**
     * return true if the resource is found on the class path
     * 
     * @param inName
     *          the resource name
     * @param verbose
     *          if set to true trace is sent to standard output
     * @return returns true if the resource was found on the class path
     */
    public boolean findResource(final String inName, final boolean verbose) {
        final InputStream stream = findResourceOnClasspath(inName, verbose);
        final boolean found = (stream == null ? false : true);
        try {
            stream.close();
        } catch (final IOException e) {
            e.printStackTrace();
        }
        return found;
    }

    /**
     * return an input stream if the resource is found on the class path
     * 
     * @param inName
     *          the resource name
     * @param verbose
     *          if set to true trace is sent to standard output
     * @return input stream if found on the class path, null otherwise
     */
    public InputStream findResourceAsStream(final String inName, final boolean verbose) {
        return findResourceOnClasspath(inName, verbose);
    }

    /**
     * return an input stream if the resource is found on the class path
     * 
     * @param inName
     *          the resource name
     * @param verbose
     *          if set to true trace is sent to standard output
     * @return input stream if found on the class path, null otherwise
     */
    private InputStream findResourceOnClasspath(final String inName, final boolean verbose) {
        final StringBuffer message = new StringBuffer();
        InputStream fis = null;
        URL fisURL = null;
        try {
            // try the parent class loader
            fis = ClassLoader.getSystemResourceAsStream(inName);
            if (fis == null) {
                // try the child class loader
                fis = this.getClass().getClassLoader()
                .getResourceAsStream(inName);
                if (fis != null) {
                    message
                    .append("\n    ")
                    .append(
                    "found using this.getClass().getClassLoader().getResourceAsStream");
                }
            } else {
                message.append("\n    ").append(
                "found using ClassLoader.getSystemResourceAsStream()");
            }
            // try the parent class loader
            fisURL = ClassLoader.getSystemResource(inName);
            if (fisURL == null) {
                // try the child class loader
                fisURL = this.getClass().getClassLoader().getResource(inName);
                if (fisURL != null) {
                    message.append("\n    ").append(
                    "this.getClass().getClassLoader().getResource()");
                }
            } else {
                message.append("\n    ").append(
                "found using ClassLoader.getSystemResource(inName)");
            }
        } catch (final Exception e) {
            BILogger.error(e.getMessage());
        }
        if (verbose) {
            if (fis != null || fisURL != null) {
                System.out.println("found " + inName + message.toString());
            } else {
                System.out.println("did not find " + inName
                        + message.toString());
            }
        }
        if (fis != null) {
            return fis;
        }
        if (fisURL != null) {
            InputStream stream = null;
            try {
                stream = fisURL.openStream();
            } catch (final IOException e) {
                e.printStackTrace();
            }
            return stream;
        }
        return null;
    }
}
