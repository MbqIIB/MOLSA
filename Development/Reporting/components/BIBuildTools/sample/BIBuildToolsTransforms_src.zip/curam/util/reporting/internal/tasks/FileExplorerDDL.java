/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 *
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.ReportingDDLFile;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.reporting.internal.tasks.model.SchemaGroup;

import curam.util.type.*;

/**
 * Returns a list of files to be processed by the BI build environment.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class FileExplorerDDL extends FileExplorer {
  /**
   * generic path structure for DDL files
   */
  String relativeDDLPath;

  /**
   * staging,central, datamarts
   */
  SchemaGroup schemaGroup;

  /*
   * the name of the oracle directory
   */
  final String oracleDir = "oracle";

  /*
   * the name of the db2 directory
   */
  final String db2Dir = "db2";

  /*
   * the name of the ddl directory
   */
  final String ddlDir = "ddl";

  /**
   * Object used to return the set of file that make up the DDL for a schema for
   * a component
   * 
   * @param inSchemaGroup
   * @param inComponentName
   * @param targetDataBaseType
   * @param inReportingDir
   */
  public FileExplorerDDL(
      final SchemaGroup inSchemaGroup,
      final ComponentName inComponentName,
      TargetDataBaseType targetDataBaseType,
      String inReportingDir) {
    super(inComponentName, targetDataBaseType, inReportingDir);
    schemaGroup = inSchemaGroup;
    /*
     * setup the template for DDL files the items in <> will be replaced at
     * runtime e.g. <Reporting>\components\<core>\ddl\<db2>\staging
     */
    relativeDDLPath = getReportingDir() + File.separator
        + DataWarehouseConstants.kComponentsDir + File.separator
        + kTemplateComponentDirectoryName + File.separator + "ddl"
        + File.separator + kTemplateTargetDB + File.separator;
    if (targetDataBaseType.isORACLE()) {
      relativeDDLPath = relativeDDLPath
          .replaceAll(kTemplateTargetDB, oracleDir);
    } else if (targetDataBaseType.isDB2()) {
      relativeDDLPath = relativeDDLPath.replaceAll(kTemplateTargetDB, db2Dir);
    }
  }

  @Override
  public List<ReportingFile> getFiles() throws Exception {
    final String createDDL = "CreateAppTables.sql";
    final String transformsDDL = "transformations.ddl";
    final String commonTransforms = "preAndPostETLProcesses.ddl";
    String componentPath = relativeDDLPath.replaceAll(
        kTemplateComponentDirectoryName, getComponentName().getDirectoryName());
    String customComponentPath = relativeDDLPath.replaceAll(
        kTemplateComponentDirectoryName, getComponentName()
            .getCustomDirectoryName());
    List<ReportingFile> ddlFiles = new ArrayList<ReportingFile>();
    Iterator<ReportingDBType> selectedSchemas = schemaGroup
        .getDataSourcesSelected().iterator();
    String schemaName = null;
    while (selectedSchemas.hasNext()) {
      schemaName = selectedSchemas.next().getDirectoryName();
      // the set of files which make up the DDL for a component
      ddlFiles
          .add(new ReportingDDLFile(componentPath + commonTransforms, false));
      ddlFiles.add(new ReportingDDLFile(componentPath + schemaName
          + File.separator + transformsDDL, false));
      if (!schemaGroup.isOnlyTransformations()) {
        ddlFiles.add(new ReportingDDLFile(componentPath + schemaName
            + File.separator + createDDL, false));
      }
      // append any ddl in the custom directories
      ddlFiles.add(new ReportingDDLFile(customComponentPath + commonTransforms,
          true));
      ddlFiles.add(new ReportingDDLFile(customComponentPath + schemaName
          + File.separator + transformsDDL, true));
      if (!schemaGroup.isOnlyTransformations()) {
        ddlFiles.add(new ReportingDDLFile(customComponentPath + schemaName
            + File.separator + createDDL, true));
      }
    }
    return ddlFiles;
  }
}
