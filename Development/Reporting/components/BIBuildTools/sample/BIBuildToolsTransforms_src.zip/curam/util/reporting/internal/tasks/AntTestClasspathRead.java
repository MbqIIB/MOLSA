/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-3011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.FileNotFoundException;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.PropertiesCache;
import curam.util.reporting.internal.config.PropertyReaderFactory;
import curam.util.reporting.internal.config.TargetDataBaseType;

import curam.util.type.*;

/**
 * 
 * This class tests that the BI bootstrap and application properties files can
 * be read through ANT when the project properties directory is placed on the
 * classpath. This build task is and will include custom directories for client
 * artifacts.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntTestClasspathRead extends Task {
    // ___________________________________________________________________________
    /**
     * Sets the build file for the appropriate platform
     */
    @Override
    public void execute() throws BuildException {
        PropertiesCache reader = null;
        DataWarehouseConstants.getBaseDirectory();
        // try to read connection properties file residing on the class path
        // test these connections to ensure they are valid
        try {
            reader = PropertyReaderFactory.getConnectionPropertyReader();
            final TargetDataBaseType type = reader.getTargetEnvironment();
            final String versionBootstrapIDProperty = "bi.bootstrap.id";
            final String versionApplicationIDProperty = "bi.application.id";
            final String biBootstrapPropertyVersionNumber = reader
            .getValue(versionBootstrapIDProperty);
            final String biApplicationPropertyVersionNumber = reader
            .getValue(versionApplicationIDProperty);
            BILogger.info("*****found file on classpath, db type is "
                    + type.getProductName() + " [" + versionBootstrapIDProperty + "="
                    + biBootstrapPropertyVersionNumber + ","
                    + versionApplicationIDProperty + "="
                    + biApplicationPropertyVersionNumber + "]");
        } catch (final FileNotFoundException e) {
            System.out
            .print("  DBConnectionManager"
                    + ":Warning, property file not found on classpath, trying reporting directory...");
            final String fileName = DataWarehouseConstants.getBaseDirectory()
            + DataWarehouseConstants.kPropertyFile;
            try {
                reader = PropertyReaderFactory.getConnectionPropertyReader(fileName);
            } catch (final FileNotFoundException e1) {
                e1.printStackTrace();
            }
            final TargetDataBaseType type = reader.getTargetEnvironment();
            System.out
            .print("*****should not be here, found file on classpath, db type is "
                    + type.getProductName());
        }
    }
}
