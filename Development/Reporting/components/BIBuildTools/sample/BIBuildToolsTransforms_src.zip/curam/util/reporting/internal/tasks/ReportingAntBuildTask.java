/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

/**
 * This is not longer recommended for use, please do not use.
 * 
 * @deprecated
 */
@Deprecated
public class ReportingAntBuildTask {
    class Target extends Object {
        final String name;

        public Target(final String inName) {
            if (inName == null) {
                throw new RuntimeException("Target cannot be null");
            }
            final int taskGroup = inName.lastIndexOf('.');
            name = inName.substring(0,
                    (taskGroup == -1 ? inName.length() : taskGroup));
        }

        @Override
        public boolean equals(final Object obj) {
            if (this == obj) {
                return true;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final Target other = (Target) obj;
            if (name.startsWith(other.name)) {
                return true;
            } else {
                return false;
            }
        }

        @Override
        public int hashCode() {
            return name.length();
        }
    }

    public static void main(final String[] args) {
        new ReportingAntBuildTask().runTask(args);
    }

    public void runTask(final String[] args) {
        final Set<Target> targets = new HashSet<Target>();
        // add targets that should not be executed twice
        targets.add(new Target("configtest"));
        targets.add(new Target("compile"));
        targets.add(new Target("jar"));
        targets.add(new Target("clean"));
        // targets.add(new Target("run.staging"));
        targets.add(new Target("database.source.lastwritten"));
        targets.add(new Target("export.control"));
        targets.add(new Target("grant.all"));
        targets.add(new Target("initial_setup"));
        targets.add(new Target("md.deploy"));
        targets.add(new Target("owbsetup"));
        targets.add(new Target("resetetl.staging"));
        final String kChildServicesName = "ChildServices";
        final StringBuffer componentsDir = new StringBuffer();
        final String kBaseDirNameProperty = "-DREPORTING_DIR=";
        final String componentNameProperty = "-DCOMPONENT_NAME=";
        final String componentDirProperty = "-DCOMPONENT_DIR=";
        final String taskNameProperty = "-DTASKNAME=";
        String targetName = null;
        final String[] newArgs = new String[args.length + 2];
        int i = 0;
        for (; i < args.length; i++) {
            if (args[i].startsWith(kBaseDirNameProperty)) {
                componentsDir.append(args[i].substring(kBaseDirNameProperty.length()));
            }
            if (args[i].startsWith(taskNameProperty)) {
                targetName = args[i].substring(taskNameProperty.length());
                newArgs[i] = targetName;
            } else {
                newArgs[i] = args[i];
            }
        }
        if (targetName == null || targetName.length() == 0) {
            throw new RuntimeException(taskNameProperty + "must be specified");
        }
        if (targets.contains(new Target(targetName))) {
            return;
        } else
            if (!new File(componentsDir.toString()).isDirectory()) {
                throw new RuntimeException(kBaseDirNameProperty + "is invalid directory");
            }
        newArgs[i++] = componentNameProperty + kChildServicesName;
        final String componentDirName = componentsDir.append(
                File.separator + "components" + File.separator).toString();
        newArgs[i] = componentDirProperty + componentDirName + kChildServicesName;
        final File dir = new File(componentDirName + kChildServicesName);
        // validate the source ETL directory
        if (!dir.exists() || !dir.isDirectory()) {
        } else {
            // org.apache.tools.ant.launch.Launcher.main(newArgs);
        }
    }
}
