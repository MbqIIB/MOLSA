/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.transformations.prepost.base;

import java.sql.SQLException;
import java.sql.Timestamp;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.dao.control.base.ProcessControl;
import curam.util.reporting.internal.dao.control.fact.ControlTableFactory;
import curam.util.reporting.internal.dao.control.intf.ControlTable;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.transformations.prepost.intf.ETLPreProcess;

import curam.util.type.*;

/**
 * This module turns a new object to execute ETL post processing
 * 
 * @since Curam 5.2 SP1
 */

@AccessLevel(AccessLevelType.EXTERNAL)
public abstract class PreProcessImpl implements ETLPreProcess {

    // ___________________________________________________________________________
    /**
     * Executes tasks required to initialize an ETL.
     * 
     * @param inTargetTableName
     *          the target table being populated
     * @throws SQLException
     *           if a database operation fails
     */
    public Timestamp executePreProcess(final String inTargetTableName)
    throws SQLException {
        ControlTable controlTable = null;
        boolean failed = false;
        // the database transaction
        Transaction transaction = null;
        Timestamp extractTime = null;
        try {
            // get the location of the target table
            final ReportingDBType database = new ReportingDBType(inTargetTableName);

            controlTable = ControlTableFactory.newInstance(database);
            // start a transaction
            transaction = TransactionFactory
            .getTransaction(DataWarehouseConstants.kDefaultDatabase);

            // set the extract start time
            extractTime = controlTable.updateStartTime(inTargetTableName);
            final ProcessControl processControl = controlTable
            .read(inTargetTableName);

            // clear the staging area table
            if (database.isStagingArea() && processControl.isTruncateTable()) {
                controlTable.clearStagingTable(inTargetTableName);

            } else {

            }
            return extractTime;
        } catch (final Exception e) {
            failed = true;
            throw new SQLException(e.getMessage());
        } finally {

            if (transaction != null && !transaction.isClientManagedTransaction()) {
                if (failed) {
                    transaction.rollback();
                } else {
                    // commit the changes
                    transaction.commit();
                }
            }

        }
    }

}
