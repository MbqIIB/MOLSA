/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 *
 */
package curam.util.reporting.internal.tasks;

import java.io.File;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.reporting.internal.tasks.model.ReportingGrantFile;
import curam.util.type.*;

/**
 * Returns a list of files with grant statements
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class FileExplorerDBTables extends FileExplorerRunScripts {
  /**
   * process only these files
   */
  final private String kRunArtifactPath = "ddl";

  /**
   * process only these files
   */
  private final String fileNameFilterCreate = "CreateAppTables.sql";

  /**
   * process only these files
   */
  private final String fileNameFilterDrop = "DropAppTables.sql";

  /**
   * Object used to return the set of grant scripts for a component
   * 
   * @param inSchema
   * @param inComponentName
   * @param targetDataBaseType
   * @param inReportingDir
   * @param inCreate
   */
  public FileExplorerDBTables(
      final ReportingDBType inSchema,
      final ComponentName inComponentName,
      final TargetDataBaseType targetDataBaseType,
      final String inReportingDir,
      final boolean inCreate) {
    super(inSchema, inComponentName, targetDataBaseType, inReportingDir);
    if (inCreate == true) {
      setFilter(fileNameFilterCreate);
    } else {
      setFilter(fileNameFilterDrop);
    }
    this.buildFilePath();
  }

  // __________________________________________________________________________
  /**
   * Creates a reporting file path
   * 
   * 
   */
  @Override
  protected void buildFilePath() {
    /*
     * set up the template for static data files. the items in <> will be there
     * are no run scripts for db2 replaced at runtime e.g.
     * <Reporting>\components\<core>\run\oracle
     */
    String buildPath = getReportingDir() + File.separator
        + DataWarehouseConstants.kComponentsDir + File.separator
        + kTemplateComponentDirectoryName + File.separator + kRunArtifactPath
        + File.separator + kTemplateTargetDB + File.separator
        + schema.getDirectoryName() + File.separator;
    if (super.getTargetDataBaseType().isORACLE()) {
      buildPath = buildPath.replaceAll(kTemplateTargetDB,
          DataWarehouseConstants.oracleDir);
    } else if (super.getTargetDataBaseType().isDB2()) {
      buildPath = buildPath.replaceAll(kTemplateTargetDB,
          DataWarehouseConstants.db2Dir);
    }
    setBuildPath(buildPath);
  }

  // __________________________________________________________________________
  /**
   * Creates a reporting file reference
   * 
   * @return the ReportingFile
   * 
   */
  @Override
  public ReportingFile createFile(String inFile, boolean isCustom) {
    return new ReportingGrantFile(inFile, isCustom);
  }
}
