/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.reset;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.PropertiesCache;
import curam.util.reporting.internal.config.PropertyReaderFactory;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.dao.control.fact.ControlTableFactory;
import curam.util.reporting.internal.dao.control.intf.ControlTable;
import curam.util.reporting.internal.persistence.transactions.Transaction;
import curam.util.reporting.internal.persistence.transactions.TransactionFactory;
import curam.util.reporting.internal.tasks.BILogger;

/**
 * This utility application resets the Reporting changed data-capture dates.
 * 
 * Executing this command ensures the reporting batch jobs will extract data
 * based on the updated changed data-capture date.
 * 
 * The LAST_ETL_DATE column in the control table is updated with the date value
 * specified in the application properties file. The property names and sample
 * values are below.
 * 
 * <ul>
 * <li>environment.resetetl.date=01/01/1934:00:00:00</li>
 * <li>environment.resetetl.dateformat=dd/mm/yyyy:hh:mm:ss</li>
 * </ul>
 * 
 * The control table for each schema can be updated individually if required.
 */
public class ResetDatabase {
    /**
     * Public Constructor.
     */
    public ResetDatabase() {
    }

    /**
     * Changes the changed-data-capture date for ETL batch processes. The new date
     * to be applied is read from the application properties table. For example:
     * 
     * <ul>
     * <li>environment.resetetl.date=01/01/1934:00:00:00</li>
     * <li>environment.resetetl.dateformat=dd/mm/yyyy:hh:mm:ss</li>
     * </ul>
     * 
     * The BI schema can be updated individually by using the one of the following
     * parameters. The parameter to be used is the first portion of the property
     * listed in bold below.
     * 
     * <ul>
     * <li><b>staging</b>.db.server</li>
     * <li><b>central</b>.db.server</li>
     * <li><b>centraldm</b>.db.server</li>
     * </ul>
     * 
     * @param inSchemas
     *          a list of reporting schema data source logical names
     * @throws Exception
     *           if the database operation failed
     */
    public void resetControlTableDates(final String[] inSchemas) throws Exception {
        // reads the properties file
        final PropertiesCache propertyReader = PropertyReaderFactory
        .getConnectionPropertyReader();
        final String dateFormat = propertyReader
        .getValue(DataWarehouseConstants.kEnvironmentResetDateFormat);
        final String resetETLDate = propertyReader
        .getValue(DataWarehouseConstants.kEnvironmentResetETLDate);
        final String usage = System.getProperty("line.separator")
        + "Usage: ResetDatabase [" + DataWarehouseConstants.kStagingDatabase
        + "|" + DataWarehouseConstants.kCentralDatabase + "|"
        + DataWarehouseConstants.kCoreDataMartDatabase + "] "
        + "resetdate [is read from property file " + resetETLDate
        + "] dateformat[ is read from property file " + dateFormat + "]";
        if (dateFormat == null | resetETLDate == null) {
            throw new IllegalArgumentException(
                    "run appbuild configtest, and ensure these are present in the property file <"
                    + DataWarehouseConstants.kEnvironmentResetDateFormat + "> and <"
                    + DataWarehouseConstants.kEnvironmentResetETLDate + ">");
        }
        Date extractDate;
        try {
            final SimpleDateFormat simpleDateFormat =
                new SimpleDateFormat(dateFormat);
            extractDate = simpleDateFormat.parse(resetETLDate);
        } catch (final Exception e) {
            throw new Exception(dateFormat + "date=" + resetETLDate + ",format"
                    + usage);
        }
        TransactionFactory.overRideRequestforDefaultTransactions(inSchemas[0]);
        TransactionFactory.getTransaction(inSchemas[0]);
        for (int i = 0; i < inSchemas.length; i++) {
            final String dataSource = inSchemas[i];
            BILogger.info(" ");
            BILogger.info("Executing for <" + dataSource
                    + "> setting to last ETL date to  " + resetETLDate);
            if (!TransactionFactory.supportedDataSource(dataSource)) {
                BILogger.info("    Invalid data source name  " + dataSource);
            } else {
                Transaction transaction = null;
                boolean failed = false;
                try {
                    TransactionFactory.overRideRequestforDefaultTransactions(dataSource);
                    transaction = TransactionFactory.getTransaction(dataSource);
                    ControlTable controlTable;
                    final ReportingDBType reportingDBType = new ReportingDBType(
                            transaction);
                    controlTable = ControlTableFactory.newInstance(reportingDBType);
                    controlTable.setExtractionDate(new java.sql.Date(extractDate
                            .getTime()));
                } catch (final SQLException e) {
                    failed = true;
                    throw new Exception(
                            "Error:Control table not updated with new start date,"
                            + e.getMessage());
                } finally {
                    if (transaction != null) {
                        if (failed) {
                            transaction.rollback();
                        } else {
                            transaction.commit();
                        }
                    }
                }
            }
        }
    }

    /**
     * Changes the changed-data-capture date for ETL batch processes. The new date
     * to be applied is read from the application properties table. For example:
     * 
     * <ul>
     * <li>environment.resetetl.date=01/01/1934:00:00:00</li>
     * <li>environment.resetetl.dateformat=dd/mm/yyyy:hh:mm:ss</li>
     * </ul>
     * 
     * The BI schema can be updated individually by using the one of the following
     * parameters. The parameter to be used is the first portion of the property
     * listed in bold below.
     * 
     * <ul>
     * <li><b>staging</b>.db.server</li>
     * <li><b>central</b>.db.server</li>
     * <li><b>centraldm</b>.db.server</li>
     * </ul>
     * 
     * @param inArguments
     *          a list of reporting schema data source logical names
     * @throws Exception
     *           if the database operation failed
     */
    public static void main(final String[] inArguments) throws Exception {
        final String usage = System.getProperty("line.separator")
        + "Usage: ResetDatabase [" + DataWarehouseConstants.kStagingDatabase
        + "|" + DataWarehouseConstants.kCentralDatabase + "|"
        + DataWarehouseConstants.kCoreDataMartDatabase + "] ";
        if (inArguments.length < 1) {
            throw new IllegalArgumentException(usage);
        }
        final ResetDatabase reset = new ResetDatabase();
        reset.resetControlTableDates(inArguments);
    }
}
