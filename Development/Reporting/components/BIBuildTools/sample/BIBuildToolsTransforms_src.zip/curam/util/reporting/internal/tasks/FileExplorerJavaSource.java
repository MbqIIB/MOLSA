/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * 
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.ReportingFile;

import curam.util.type.*;

/**
 * Returns a list of files to be processed by the BI build environment.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class FileExplorerJavaSource extends FileExplorer {
    /**
     * generic path structure for DDL files
     */
    String relativeStaticDataPath;

    /**
     * Object used to return the set of file that make up the DDL for a schema for
     * a component
     * 
     * @param inComponentName
     * @param targetDataBaseType
     * @param inReportingDir
     */
    public FileExplorerJavaSource(
            final ComponentName inComponentName,
            final TargetDataBaseType targetDataBaseType,
            final String inReportingDir) {
        super(inComponentName, targetDataBaseType, inReportingDir);
        /*
         * set up the template for static data files. the items in <> will be
         * replaced at runtime e.g. <Reporting>\components\<core>\data_manager\
         */
        relativeStaticDataPath = getReportingDir() + File.separator
        + DataWarehouseConstants.kComponentsDir + File.separator
        + kTemplateComponentDirectoryName + File.separator + "source"
        + File.separator;
    }

    /**
     * Build a list of paths to be used when compiling java code.
     * 
     * @return List<ReportingFile> a list of ReportingFile standard and custom
     *         path entries
     * @throws Exception
     */
    @Override
    public List<ReportingFile> getFiles() throws Exception {
        //final File customComponentPath = new File(relativeStaticDataPath.replaceAll(
        //        kTemplateComponentDirectoryName, getComponentName()
        //        .getCustomDirectoryName()));

        final File componentPath =
            new File(relativeStaticDataPath.replaceAll(
                    kTemplateComponentDirectoryName, getComponentName()
                    .getDirectoryName()));
        if (!componentPath.exists()) {
            BILogger.debug("JavaSourcePaths " + componentPath + " does not exist");

        }
        final List<ReportingFile> componentPaths = new ArrayList<ReportingFile>();
        final ReportingFile reportingPath = new ReportingFile(
                componentPath.getAbsolutePath(), false);
        reportingPath.setComponentName(getComponentName());
        componentPaths.add(reportingPath);
        // the custom folder is now at the same level at all other components
        //ReportingFile reportingCustom = new ReportingFile(
        //    customComponentPath.getAbsolutePath(), true);
        //reportingCustom.setComponentName(getComponentName());
        //componentPaths.add(reportingCustom);
        //
        return componentPaths;
    }
}
