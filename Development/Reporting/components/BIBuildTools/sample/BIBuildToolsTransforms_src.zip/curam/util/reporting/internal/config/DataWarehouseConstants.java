/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005-2011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.config;

import java.io.File;

/**
 * This module defines environment constants.
 * 
 * 
 * 
 */
public class DataWarehouseConstants {

    /**
     * the name of the db2 directory
     */
    static public final String kCore = "core";

    /**
     * the name of the db2 directory
     */
    static public final String db2Dir = "db2";

    /**
     * the name of the oracle directory
     */
    static public final String oracleDir = "oracle";

    /**
     * the oracle location names used by warehouse builder.
     */
    static public final String owbConfigSourceLocation = "environment.owbconfig.source.location";

    /**
     * the oracle location names used by warehouse builder.
     */
    static public final String owbConfigStaticLocation = "environment.owbconfig.static.location";
    /**
     * the oracle location names used by warehouse builder.
     */
    static public final String owbConfigStagingLocation = "environment.owbconfig.staging.location";
    static public final String owbConfigWarehouseLocation = "environment.owbconfig.warehouse.location";
    static public final String owbConfigDatamartsLocation = "environment.owbconfig.datamarts.location";
    static public final String owbConfigSystemParams = "environment.owbconfig.system.params";
    static public final String owbConfigCustomLocation = "environment.owbconfig.custom.params";
    static public final String owbConfigJobType = "environment.owbconfig.jobtype";

    /**
     * the BI target OWB version.
     */
    static public final String owbVersion = "environment.owbconfig.version";

    /**
     * the source system Oracle version.
     */
    static public final String owbVersionSource = "environment.owbconfig.version.sourceDB";

    /**
     * staging database prefix.
     */
    static public final String EnvironmentCognosInstalled = "environment.cognos.installed";

    /**
     * staging database prefix.
     */
    static public final String kDefaultDatabase = "default";

    /**
     * supported components
     */
    static public final String kComponentOrder = "component.order";

    /**
     * the property to control what components are build, it must be a subset of
     * the components listed in the component order property listed with the
     * application properties file
     */
    static public final String kBIComponentsToInstall = "BI_COMPONENT_ORDER";

    /**
     * supported languages and regions
     */
    static public final String kLocaleOrder = "component.locale.order";

    /**
     * installed language/region
     */
    static public final String kInstalledLanguage = "component.locale.order.installedLanguage";

    /**
     * the property to control what languages are build, it must be a subset of
     * the components listed in the component order property listed with the
     * application properties file
     */
    static public final String kBILocalesToInstall = "BI_COMPONENT_LOCALE_ORDER";

    /**
     * is oracle installed on the OWB client box.
     */
    static public final String kOracleRemoteDataManagerDir = "environment.owbconfig.remotedatamanagerdir";

    /**
     * is oracle installed on the OWB client box.
     */
    static public final String kOracleDataManagerDir = "owbconfig.remotedatamanagerdir";

    /**
     * is oracle installed on the OWB client box.
     */
    static public final String kInfoSphereProjectDir = "environment.infosphere.projectdir";

    /**
     * is oracle installed on the OWB client box.
     */
    static public final String kOracleInstalledOnOWBClientBox = "environment.owb.oracleinstalled";

    /**
     * curam source database prefix.
     */
    static public final String kJdbcJarFilesProp = "environment.jdbc.jars";

    /**
     * curam source database prefix.
     */
    static public final String kJavaJDBCProp = "environment.jdbc.drivers";

    /**
     * curam source database prefix.
     */
    static public final String kEnvironmentVariables = "environment.variables";

    /**
     * curam source database prefix.
     */
    static public final String kEnvironmentResetDateFormat = "environment.resetetl.dateformat";

    /**
     * demo data date format.
     */
    static public final String kEnvironmentDemoDateFormat = "environment.demodata.dateformat";

    /**
     * replacement identity for a date time value.
     */
    static public final String KDemoDataDateTime = "#TIMESTAMP";

    /**
     * replacement identity for a date time value for Oracle.
     */
    static public final String KDemoDataDateTimeReplacementOracle = "sysdate";

    /**
     * replacement identity for a date time value for Oracle.
     */
    static public final String KDemoDataDateTimeReplacementDB2 = "current_timestamp";

    /**
     * replacement identity for a date time value.
     */
    static public final String KDemoDataDate = "#DATE";

    /**
     * replacement identity for a date time value for Oracle.
     */
    static public final String KDemoDataDateReplacementOracle = "sysdate";

    /**
     * replacement identity for a date time value for Oracle.
     */
    static public final String KDemoDataDateReplacementDB2 = "current_date";

    /**
     * curam source database prefix.
     */
    static public final String kEnvironmentAggregateDateFormat = "environment.datamart.aggmonth.dateformat";

    /**
     * curam source database prefix.
     */
    static public final String kEnvironmentAggregateStartdate = "environment.datamart.aggmonth.start";

    /**
     * curam source database prefix.
     */
    static public final String kEnvironmentAggregateEnddate = "environment.datamart.aggmonth.end";

    /**
     * curam source database prefix.
     */
    static public final String kEnvironmentResetETLDate = "environment.resetetl.date";

    /**
     * curam source database prefix.
     */
    static public final String kIExplorerPath = "environment.iexplorer.url";

    /**
     * curam source database prefix.
     */
    static public final String kComponentOrderWarningLevel = "component.order.warninglevel";

    /**
     * curam source database prefix.
     */
    static public final String kComponentOrderWarning = "warning";

    /**
     * curam source database prefix.
     */
    static public final String kComponentOrderError = "error";

    /**
     * curam source database prefix.
     */
    static public final String kCuramSourceDatabase = "curamsource";

    /**
     * staging database prefix
     * <p>
     * From your BIBootstrap properties files <code>staging</code>
     * .db.server=servername, this is the first word.
     */
    static public final String kStagingDatabase = "staging";

    /**
     * central data warehouse database prefix.
     */
    static public final String kCentralDatabase = "central";

    /**
     * central data warehouse database prefix
     */
    static public final String kCoreDataMartDatabase = "centraldm";

    /**
     * central data warehouse database prefix.
     */
    static public final String kDataMartDemoDataDatabase = "dmdemodata";

    /**
     * design data warehouse database prefix.
     */
    static public final String kDesignDatabase = "design";

    /**
     * design data warehouse database prefix.
     */
    static public final String kISWExecutionDatabase = "design";

    /**
     * runtime data warehouse database prefix.
     */
    static public final String kRuntimeDatabase = "runtime";

    /**
     * the database type key.
     */
    static public final String kDatabaseType = "db.type";

    /**
     * the database type key.
     */
    static public final String kDatabaseTypeZOS = "zos";
    static public final String kDatabaseTypeUDB = "udb";

    /**
     * the database type key.
     */
    static public final String kDatabaseTypeOverride = ".db.type";

    /**
     * the database source type key.
     */
    static public final String kSourceDatabaseType = "db2.source.type";

    /**
     * SID only required for BIRT infrastructure and KPI development.
     */
    static public final String kOracleSID = ".db.SID";

    /**
     * the database source type key.
     */
    static public final String kServiceName = ".db.servicename";

    /**
     * database user name.
     */
    static public final String kDBUserName = ".db.username";

    /**
     * database user name.
     */
    static public final String kDBPassword = ".db.password";

    /**
     * the application server data source name
     */
    static public final String kJNDIDataSourceName = ".db.appserver.datasource";

    /**
     * database user name
     */
    static public final String kDatabaseName = ".db.name";

    /**
     * database server name.
     */
    static public final String kDBServer = ".db.server";

    /**
     * database port number.
     */
    static public final String kDBPort = ".db.port";

    /**
     * the base directory for this component.
     */
    public static final String kProjectDirectory = "REPORTING_DIR";

    /**
     * the oracle configuration base directory.
     */

    public static String kBaseDirectory;

    public static String kTechStackProductName = "technologystack.productname";
    public static String kTechStackVendorIBM = "infosphere";
    public static String kTechStackVendorOracle = "owb";

    static {
        kBaseDirectory = new EnvironmentVariable(kProjectDirectory).getValue();
    }

    /**
     * 
     * @return returns the base directory
     */
    static public String getBaseDirectory() {
        return kBaseDirectory;
    }

    /**
     * 
     * @return returns the data manager directory
     */
    static public String getDefaultDataManagerDirectory() {
        return DataWarehouseConstants.getBaseDirectory() + File.separator + "bin"
        + File.separator + "data_manager" + File.separator;
    }

    /**
     * the components directory name
     */
    public static final String kComponentsDir = "components";

    /**
     * 
     * @return returns the full path to the components
     *         directory
     */
    static public String getComponentsDirectory() {
        return DataWarehouseConstants.getBaseDirectory() + File.separator
        + kComponentsDir + File.separator;
    }

    /**
     * 
     * @return returns the full path to the components
     *         directory
     */
    static public File getDriversDirectory() {
        return new File(DataWarehouseConstants.getBaseDirectory() + File.separator
                + kComponentsDir + File.separator + "BIBuildTools" + File.separator
                + "drivers" + File.separator);
    }

    /**
     * the bootstrap property file relative to the base directory.
     */
    public static final String kApplicationPropertyFileName = "BIApplication.properties";
    /**
     * the bootstrap property file relative to the base directory.
     */
    public static final String kBootStrapPropertyFileName = "BIBootstrap.properties";
    /**
     * the bootstrap property file relative to the base directory.
     */
    public static final String kPropertyFile = File.separator + "project"
    + File.separator + "properties" + File.separator
    + kBootStrapPropertyFileName;

    /**
     * the property file relative to the base directory.
     */
    public static final String kApplicationPropertiesFile = File.separator
    + "project" + File.separator + "properties" + File.separator
    + kApplicationPropertyFileName;

    /**
     * the property file relative to the base directory.
     */
    public static final String kPropertyFileFullPath = kBaseDirectory
    + kPropertyFile;

    /**
     * the oracle configuration file for the data warehouse.
     */
    public static final String kDateFormat = "dateformat.in";

}
