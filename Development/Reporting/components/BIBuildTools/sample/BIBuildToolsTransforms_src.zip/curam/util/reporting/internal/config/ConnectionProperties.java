/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.config;

/**
 * This module defines functions to return database connection properties
 * 
 * 
 */

public class ConnectionProperties {

  /**
   * the pool name
   */
  private final String poolName;

  /**
   * primary URL
   */
  private String url = "";

  /**
   * alternate URL it the case of Oracle it contains a SID
   */
  private String alternateURL = "";

  /**
   * alternate URL - true if it is available
   */
  private boolean useAlternateURL = false;

  /**
   * the database user identity
   */
  private final String userid;

  /**
   * the database password
   */
  private final String password;

  /**
   * the max number of connections in the pool
   */
  private final int maxConnections;

  /**
   * the driver name, may be empty if -Djdbc.driver is used
   */
  private String driverName = "";

  /**
   * the service name.
   */
  private String serviceName;

  /**
   * the application server data source name.
   */
  private String appServerDataSourceName = "";

  /**
   * the target RDBMS vendor
   */
  private TargetDataBaseType targetDataBaseType;

  /**
   * the BI schema, one of staging, warehouse or datamart. See the prefixes used
   * with the bootstrap properties file.
   */
  private ReportingDBType biSchemaType;

  /**
   * the BI schema, one of staging, warehouse or datamart. See the prefixes used
   * with the bootstrap properties file.
   */
  private String databaseName = "";

  // ___________________________________________________________________________
  /**
   * Creates a database connection object
   * 
   * Note, the jdbc.drivers property may be set, if so as part of its
   * initialization, the <code>DriverManager</code> class will attempt to load
   * the driver classes referenced in the "jdbc.drivers" system property. In
   * this case the driver name parameter will be empty
   * 
   * @param poolName
   *          the pool name
   * @param url
   *          the URL
   * @param userIdentity
   *          the user identity
   * @param password
   *          the password
   * @param driver
   *          the driver, may be empty if the jdbc.drivers property is set
   * @param inTargetDataBaseType
   *          the target database type, i.e. DB2 or Oracle
   * @param maxConnections
   *          int maximum number of connection in the pool
   */
  public ConnectionProperties(
      String poolName,
      String url,
      String userIdentity,
      String password,
      String driver,
      TargetDataBaseType inTargetDataBaseType,
      int maxConnections) {

    this.poolName = poolName;
    if (url != null) {
      this.url = url;
    }

    this.userid = userIdentity;
    this.password = password;
    this.maxConnections = maxConnections;
    if (driver != null) {
      driverName = driver;
    }

    targetDataBaseType = inTargetDataBaseType;
    try {
      biSchemaType = new ReportingDBType(this);
    } catch (Exception e) {
    }

  }

  // ___________________________________________________________________________
  /**
   * Returns the max number of connections.
   * 
   * @return the max number of connections
   */
  public int getMaxConnections() {
    return maxConnections;
  }

  // ___________________________________________________________________________
  /**
   * Returns the password.
   * 
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  // ___________________________________________________________________________
  /**
   * Returns the alternate URL. For Oracle it contains a SID, no alternate for
   * DB2
   * 
   * @return the url
   */
  public String getAlternateUrl() {
    return alternateURL;
  }

  // ___________________________________________________________________________
  /**
   * Returns the URL. For Oracle it contains a service name for the thin JDBC
   * driver
   * 
   * @return the url
   */
  public String getUrl() {
    if (useAlternateURL == false) {
      return url;
    } else {
      return alternateURL;
    }
  }

  // ___________________________________________________________________________
  /**
   * Returns the user identity
   * 
   * @return the user identity
   */
  public String getUserid() {
    return userid;
  }

  // ___________________________________________________________________________
  /**
   * Returns the driver name
   * 
   * Note, the jdbc.drivers property may be set, if so as part of its
   * initialization, the <code>DriverManager</code> class will attempt to load
   * the driver classes referenced in the "jdbc.drivers" system property.
   * 
   * @return String a fully qualified class name for the driver
   */
  public String getDriverName() {
    return driverName;
  }

  // ___________________________________________________________________________
  /**
   * Returns the poolName.
   * 
   * @return String
   */
  public String getPoolName() {
    return poolName;
  }

  @Override
  public String toString() {
    return poolName + "," + url + "," + userid + "," + "???" + ","
        + maxConnections + "," + driverName + "alternateURL=" + alternateURL;
  }

  // ___________________________________________________________________________
  /**
   * Sets the alternate URL
   * 
   * @param inURL
   *          the URL
   */
  public void setAlternateURL(String inURL) {
    if (inURL != null) {
      alternateURL = inURL;
    }
  }

  // ___________________________________________________________________________
  /**
   * return true if alternate URL is set
   * 
   * @return if an alternate URL is set for this connection
   */
  public boolean usingAlternateURL() {
    return useAlternateURL;
  }

  // ___________________________________________________________________________
  /**
   * Sets the alternate URL indicator to true
   * 
   */
  public void useAlternateURL() {
    useAlternateURL = true;
  }

  // ___________________________________________________________________________
  /**
   * Sets the target database type if not already set
   * 
   * @param inTargetDataBaseType
   *          the database type
   */
  public void setTargetDataBaseType(TargetDataBaseType inTargetDataBaseType) {
    // only set if database type was not known when
    // creating the properties and pool, e.g. if using
    // default JVM connections
    if (targetDataBaseType == null) {
      targetDataBaseType = inTargetDataBaseType;
    }
  }

  // ___________________________________________________________________________
  /**
   * Returns the targetDataBaseType.
   * 
   * @return return the target database type
   */
  public TargetDataBaseType getTargetDataBaseType() {
    return targetDataBaseType;
  }

  // ___________________________________________________________________________
  /**
   * Returns the targetDataBaseType.
   * 
   * @return the target database type
   */
  public ReportingDBType getReportingSchema() {
    return biSchemaType;
  }

  // __________________________________________________________________________
  /**
   * Returns the service name.
   * 
   * @return the service name
   */
  public String getServiceName() {
    return serviceName;
  }

  // __________________________________________________________________________
  /**
   * Returns the service name.
   * 
   * @param inServiceName
   *          the service name
   */
  public void setServiceName(final String inServiceName) {
    serviceName = inServiceName;
  }

  /**
   * Returns the application server data source name for this schema.
   * 
   * @return A new <code>String</code> representing the application server data
   *         source name
   */
  public String getAppServerDataSourceName() {
    return appServerDataSourceName;
  }

  // __________________________________________________________________________
  /**
   * Sets the application server data source name.
   * 
   * @param inAppServerDataSourceName
   *          the name
   */
  public void setAppServerDataSourceName(String inAppServerDataSourceName) {
    appServerDataSourceName = inAppServerDataSourceName;
  }

  /**
   * Returns the database name, for DB2 it is the database name, for Oracle it
   * is the instance name
   * 
   * @return A new <code>String</code> representing the application database
   *         name
   */
  public String getDatabaseName() {
    return databaseName;
  }

  // __________________________________________________________________________
  /**
   * Sets the database name, for DB2 it is the database name, for Oracle it is
   * the instance name
   * 
   * @param inDatabaseName
   *          the name
   */

  public void setDatabaseName(String inDatabaseName) {
    databaseName = inDatabaseName;
  }

}
