/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.config;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import curam.util.type.*;

/**
 * 
 * The class calculates the component order for a Reporting installation.
 * 
 * The order that components must be built in is read from the application
 * properties file, component.order=ab,c
 * 
 * The actual components to build is also calculated, the environment variable
 * BI_COMPONENT_ORDER defines what is to be installed. If this variable is not
 * defined then all subdirectories of the component directory are used.
 * 
 * Components to be installed must be defined within the component order or the
 * component marked for installation will not be installed.
 * 
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class ComponentOrder {

    /*
     * the order in which to build
     */
    private List<ComponentName> componentOrder = new ArrayList<ComponentName>();
    public List < ComponentName > getComponentOrder( ) {
        return componentOrder ;
    }

    /*
     * the list to install
     */
    private List<ComponentName> toInstall = new ArrayList<ComponentName>();

    /*
     * not in the component order but available on disk
     */
    private List<ComponentName> notInstall = new ArrayList<ComponentName>();

    private  EnvironmentVariable localesToInstall = null;

    private EnvironmentVariable localesSupported = null;

    private boolean verbose = false;

    /**
     * Allows methods to print verbose debug output
     * 
     * @param verbose
     */
    public void setVerbose(final boolean verbose) {
        this.verbose = verbose;
    }

    /**
     * Public no argument constructor.
     */
    public ComponentOrder() {

    }

    /**
     * 
     * @return
     */
    private EnvironmentVariable getLocalesToInstall() {
        return localesToInstall;
    }

    private void setLocalesToInstall(final EnvironmentVariable inLocalesToInstall) {

        if (inLocalesToInstall.isValidValue()) {
            localesToInstall = inLocalesToInstall;
        } else {
            ;
        }
    }

    /**
     * returns a list of locales to be installed
     * 
     * @return an List of the elements in this locale list
     */
    @SuppressWarnings("unused")
    private List<ComponentName> getLocalesToInstallAsList() {
        return create(getLocalesToInstall());
    }

    /**
     * Builds a list of components to install based on the calling directory.
     * 
     * @return the components to install, a list of ComponentName for the
     *         installed language
     */
    public boolean checkInstalledLanguageIsSupported() {
        boolean supported = false;
        final String inSupportedLocales = getLocalesSupported().getValue();
        final String inInstalledLanauge = getLocalesToInstall().getValue();
        if (inSupportedLocales != null && inInstalledLanauge != null) {
            final String allTokens[] = inSupportedLocales.split(",");
            for (final String token : allTokens) {

                if (token.equalsIgnoreCase(inInstalledLanauge)) {
                    supported = true;
                }
            }
        }
        return supported;
    }

    /**
     * returns a list of component names to be installed, where each locale to be
     * installed is included
     * 
     * @return an List of the elements in this locale list, core_en_GB, core_en_US
     */
    private List<ComponentName> getLocalesToInstall(final ComponentName inName) {
        return create(getLocalesToInstall(), inName);
    }

    /**
     * returns a list of component names to be installed, where each locale to be
     * installed is included
     * 
     * @return an List of the elements in this locale list, core_en_GB, core_en_US
     */
    private boolean isFirstInstalledLanguageEnglish() {

        // there are no language packs for "en" as this english is included in
        // whats shipped OOTB
        // this may change in the future as we may provide support to allow
        // overridden
        // demo data for the UAS or GB.
        final List<ComponentName> locales = create(getLocalesToInstall());
        ComponentName first = null;

        if (locales.size() > 0) {
            first = locales.get(0);
        }
        if (first == null || first.getComponentName().indexOf("en") == -1) {
            return false;
        } else {
            return true;
        }
    }



    private EnvironmentVariable getLocalesSupported() {
        return localesSupported;
    }

    @SuppressWarnings("unused")
    private List<ComponentName> getLocalesSupportedAsList() {
        return create(getLocalesSupported());
    }

    private void setLocalesSupported(final EnvironmentVariable inLocalesSupported) {
        localesSupported = inLocalesSupported;
        localesSupported.validated();
    }

    /**
     * 
     * @param inPossibleComponents
     */
    private void installMultipleComponents(
            final EnvironmentVariable inPossibleComponents) {
        // default to this
        final List<ComponentName> possibleComponents = create(inPossibleComponents);
        {
            // build the list of components not installed
            final List<ComponentName> result = new ArrayList<ComponentName>();
            result.addAll(possibleComponents);
            result.removeAll(componentOrder);
            notInstall = result;
        }

        if (possibleComponents.size() > 0) {
            final List<ComponentName> componentOrderCopy = new ArrayList<ComponentName>();
            componentOrderCopy.addAll(componentOrder);
            final Iterator<ComponentName> componentOrderCopyIterator = componentOrderCopy
            .listIterator();

            // using the order remove the components not to be installed
            ComponentName name;
            ComponentName exists;

            while (componentOrderCopyIterator.hasNext()) {
                name = (ComponentName) componentOrderCopyIterator.next();
                exists = exists(name.getComponentName(), possibleComponents);
                if (exists != null) {
                    // do nothing , it will be installed
                } else {
                    notInstall.add(name);
                    componentOrderCopyIterator.remove();
                }

            }
            this.toInstall = componentOrderCopy;
        }
    }

    /**
     * Initialized this object with a single component.
     * 
     * @param inSingleComponent
     */
    private void installSingleComponent(final EnvironmentVariable inSingleComponent) {
        installMultipleComponents(inSingleComponent);
    }

    /**
     * Sets the list of components that are available to be installed,the install
     * may install a subset of these.
     * 
     * @param inInstallOrder
     *          the list of available components, the install may install a subset
     *          of these.
     */
    private void setComponentOrder(final EnvironmentVariable inInstallOrder) {
        componentOrder = create(inInstallOrder);
        if (toInstall.size() == 0) {
            toInstall.addAll(componentOrder);
            if (inInstallOrder.getValue().contains("custom") == false) {
                toInstall.add(new ComponentName ("custom"));
            } else {

            }
        }

    }

    /**
     * Creates a list of component name object from an environment variable with
     * values separated by a comma
     * 
     * @param inInstallOrder
     * @return List<ComponentName>
     */
    private List<ComponentName> create(final EnvironmentVariable inInstallOrder) {
        final List<ComponentName> order = new ArrayList<ComponentName>();
        final String tokens = inInstallOrder.getValue();
        if (tokens != null) {
            final String allTokens[] = tokens.split(",");
            ComponentName env;
            for (final String token : allTokens) {
                env = new ComponentName(token);
                order.add(env);
            }
        }

        if (tokens.contains("custom") == false) {
            order.add(new ComponentName ("custom"));
        } else {

        }
        return order;
    }

    /**
     * Creates a list of component name language objects from an locale
     * environment variable and a component name
     * 
     * @param inLocalesToInstall a list of languages to install
     * @return List<ComponentName>
     */
    private List<ComponentName> create(final EnvironmentVariable inLocalesToInstall,
            final ComponentName inName) {
        final List<ComponentName> order = new ArrayList<ComponentName>();
        final String tokens = inLocalesToInstall.getValue();
        if (tokens != null) {
            final String allTokens[] = tokens.split(",");
            ComponentName env;
            for (String token : allTokens) {
                token = token.trim();
                if (token != null && token.length()>0) {
                    env = new ComponentName(inName.getComponentName() + "_" + token);
                } else {
                    env = new ComponentName(inName.getComponentName());
                }
                order.add(env);
                // for now only install one language
                break;
            }
        }
        return order;
    }

    /**
     * Builds a list of components to install based on the calling directory.
     * 
     * @return the components to install, a list of ComponentName objects
     */
    public Iterator<ComponentName> getComponentsToInstall() {
        return toInstall.iterator();
    }

    /**
     * Builds a list of components to install based on the calling directory, the
     * core component is removed from this list.
     * 
     * @return the components to install, a list of ComponentName objects, without
     *         core
     */
    public Iterator<ComponentName> getComponentsToInstallWithoutCore() {
        final Iterator<ComponentName> toInstallTemp = getComponentsToInstall();
        ComponentName componentName = null;
        final List<ComponentName> exceptCore = new ArrayList<ComponentName>();

        while (toInstallTemp.hasNext()) {
            componentName = (ComponentName) toInstallTemp.next();
            if (componentName.getComponentName().equalsIgnoreCase(
                    DataWarehouseConstants.kCore)) {

            } else {
                exceptCore.add(componentName);
            }
        }
        if (verbose) {
            System.out.println("getComponentsToInstallWithoutCore "
                    + exceptCore.size());
        }
        return exceptCore.iterator();
    }

    /**
     * Builds a list of components to install based on the calling directory.
     * 
     * @return the components to install, a list of ComponentName for the
     *         installed language
     */
    public List<ComponentName> getComponentsToInstallWithLanguagPacks() {
        final List<ComponentName> toInstallTemp = new ArrayList<ComponentName>();
        final Iterator<ComponentName> componentsIterator = getComponentsToInstall();
        ComponentName componentName = null;

        while (componentsIterator.hasNext()) {
            componentName = (ComponentName) componentsIterator.next();
            toInstallTemp.add(componentName);

            final List<ComponentName> componentLanguagePacks = getLocalesToInstall(componentName);

            toInstallTemp.addAll(componentLanguagePacks);
        }
        if (verbose) {
            System.out.println("getComponentsToInstallWithLanguagPacks:"
                    + toInstallTemp);
        }
        return toInstallTemp;
    }

    /**
     * Builds a list of components to install based on the calling directory.
     * 
     * @return the components to install, a list of ComponentName for the
     *         installed language
     */
    public List<ComponentName> getComponentsDemoDataPackToInstall() {
        final List<ComponentName> toInstallTemp = new ArrayList<ComponentName>();
        final Iterator<ComponentName> componentsIterator = getComponentsToInstall();
        ComponentName componentName = null;

        final boolean installingEnglish = isFirstInstalledLanguageEnglish();
        // there are no language packs for "en" as this english is included in
        // whats shipped OOTB
        // this may change in the future as we may provide support to allow
        // overridden
        // demo data for the USA or GB.

        while (componentsIterator.hasNext()) {
            componentName = (ComponentName) componentsIterator.next();
            if (installingEnglish == true) {
                toInstallTemp.add(componentName);
            }
            if (installingEnglish == false) {
                final List<ComponentName> componentLanguagePacks =
                    getLocalesToInstall(componentName);

                toInstallTemp.addAll(componentLanguagePacks);
            }
        }
        if (verbose) {
            System.out.println("getComponentsDemoDataPackToInstall:" + toInstallTemp);
        }
        return toInstallTemp;
    }

    private ComponentName exists(final String inName, final List<ComponentName> order) {

        for (final ComponentName name : order) {
            if (name.getComponentName().equalsIgnoreCase(inName)) {
                return name;
            }
        }
        return null;
    }

    /**
     * Returns the component name if its to be installed.
     * 
     * @param inName
     *          - is this component to be installed
     * @return null if the component is not to be installed
     */
    public ComponentName toBeInstalled(final ComponentName inName) {

        for (final ComponentName name : toInstall) {
            if (name.equals(inName)) {
                return name;
            }
        }
        return null;
    }

    @Override
    public String toString() {

        final StringBuffer message = new StringBuffer();
        message.append(" installing ").append(toInstall);
        message.append(" componentorder ").append(componentOrder);
        message.append(" ...,ignoring ").append(notInstall);

        message.append(" language [").append(getLocalesToInstall());
        message.append("] localeorder [").append(getLocalesSupported()).append("]");
        return message.toString();

    }

    // ___________________________________________________________________________
    /**
     * Builds a list of components to install based on the calling directory.
     * 
     * @param inDirectory
     * @return an environment variable with a comma separated list of components
     *         to install.
     * @throws Exception
     */
    private EnvironmentVariable buildComponetOrderFromComponentDir(
            final File inDirectory) throws Exception {

        if (!inDirectory.exists() || !inDirectory.canWrite()) {
            throw new Exception("Directory does not exist"
                    + inDirectory.getAbsolutePath());
        }
        final File files[] = inDirectory.listFiles();
        EnvironmentVariable environmentVariable = null;

        final Set<String> envVariable = new HashSet<String>();
        if (files != null) {
            for (final File i : files) {
                if (i.isDirectory()) {
                    envVariable.add(i.getName());
                }
            }
        }

        final StringBuffer directories = new StringBuffer();
        final Iterator<String> iterator = envVariable.iterator();
        while (iterator.hasNext()) {
            directories.append(((String) iterator.next()));
            if (iterator.hasNext()) {
                directories.append(",");
            }
        }
        environmentVariable = new EnvironmentVariable(
                DataWarehouseConstants.kBIComponentsToInstall, directories.toString());
        return environmentVariable;
    }

    // ___________________________________________________________________________
    /**
     * Builds a list of languages to install based on the calling directory.
     * 
     * @param inDirectory
     * @return an environment variable with a comma separated list of components
     *         to install.
     * @throws Exception
     */
    private EnvironmentVariable buildLanguagesFromComponentDir(final File inDirectory)
    throws Exception {

        if (getLocalesToInstall().isValidated()) {
            return getLocalesToInstall();
        }

        if (!inDirectory.exists() || !inDirectory.canWrite()) {
            throw new Exception("Directory does not exist"
                    + inDirectory.getAbsolutePath());
        }
        final File files[] = inDirectory.listFiles();
        EnvironmentVariable environmentVariable = null;

        final Set<ComponentName> envVariable = new HashSet<ComponentName>();
        if (files != null) {
            for (final File i : files) {
                final ComponentName name = new ComponentName(i.getName());

                if (i.isDirectory()) {
                    if (name.isLanguageAndRegion() > 0) {
                        envVariable.add(name);
                    }
                }
            }
        }

        final StringBuffer directories = new StringBuffer();
        final Iterator<ComponentName> iterator = envVariable.iterator();
        ComponentName name = null;
        while (iterator.hasNext()) {
            name = iterator.next();
            directories.append(name.getLanguageAndRegionCode());
            if (iterator.hasNext()) {
                directories.append(",");
            }
        }
        environmentVariable = new EnvironmentVariable(
                DataWarehouseConstants.kInstalledLanguage, directories.toString());
        return environmentVariable;
    }

    // ___________________________________________________________________________
    /**
     * Sets the locales supported and the installed language
     * 
     * @param inCallingDirectoryName
     * @return ComponentOrder
     * 
     * @throws BuildException
     */
    private void setLanguagePacksToInstall(final String inCallingDirectoryName,
            final boolean verbose, final PropertiesCache propertyReader,
            final String reportingDir) throws Exception {
        // read the list of languages supported
        final EnvironmentVariable languageToInstallEnv = new EnvironmentVariable(
                DataWarehouseConstants.kBILocalesToInstall);

        if (languageToInstallEnv.isValidValue()) {
            setLocalesToInstall(languageToInstallEnv);

        } else {
            final EnvironmentVariable languageToInstallProp = new EnvironmentVariable(
                    DataWarehouseConstants.kInstalledLanguage,
                    propertyReader.getValue(DataWarehouseConstants.kInstalledLanguage));
            if (!languageToInstallProp.isValidValue()) {
                languageToInstallProp.setValue("en");
            }
            setLocalesToInstall(languageToInstallProp);
        }

        final EnvironmentVariable theLocalesSupported = new EnvironmentVariable(
                DataWarehouseConstants.kLocaleOrder,
                propertyReader.getValue(DataWarehouseConstants.kLocaleOrder));

        setLocalesSupported(theLocalesSupported);

    }

    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     * 
     * @param inCallingDirectoryName
     * @return ComponentOrder
     * 
     * @throws BuildException
     */
    public ComponentOrder getComponentsToBuild(final String inCallingDirectoryName,
            final boolean verbose, final PropertiesCache propertyReader, final String reportingDir)
    throws Exception {
        final ComponentOrder toInstall = new ComponentOrder();
        try {

            // build for all components if the build commands are executed from
            // the component parent directory
            // or only build for one component if the build commands are expected
            // from with a component directory
            // read the component order
            final EnvironmentVariable componentOrder = new EnvironmentVariable(
                    DataWarehouseConstants.kComponentOrder,
                    propertyReader.getValue(DataWarehouseConstants.kComponentOrder));

            toInstall.setComponentOrder(componentOrder);

            // read the list of languages supported
            toInstall.setLanguagePacksToInstall(inCallingDirectoryName, verbose,
                    propertyReader, reportingDir);

            final File componentsDir = new File(reportingDir + File.separator
                    + DataWarehouseConstants.kComponentsDir);

            if (inCallingDirectoryName == null) {
                if (verbose) {
                    System.out.println("inCallingDirectoryName= "
                            + inCallingDirectoryName);
                }
                return toInstall;
            }

            if (DataWarehouseConstants.kComponentsDir
                    .equalsIgnoreCase(inCallingDirectoryName)) {
                if (verbose) {
                    System.out.println("    called from... "
                            + DataWarehouseConstants.kComponentsDir);
                }
                // read the component order
                final EnvironmentVariable installThese = propertyReader
                .getEnv(DataWarehouseConstants.kBIComponentsToInstall);
                if (verbose) {
                    System.out.println("     environment variable value is " + installThese);
                }
                if (installThese.isValidValue()) {

                    // replace with the explicitly listed components
                    toInstall.installMultipleComponents(installThese);
                } else {
                    if (verbose) {
                        System.out
                        .println("     environment variable not found, searching on disk...");
                    }
                    final EnvironmentVariable all = toInstall
                    .buildComponetOrderFromComponentDir(componentsDir);
                    toInstall.installMultipleComponents(all);
                    // read the list of languages supported

                    toInstall
                    .setLocalesToInstall(
                            toInstall.buildLanguagesFromComponentDir(componentsDir));

                }

            } else {
                if (verbose) {
                    System.out.println("called from specific component... "
                            + inCallingDirectoryName);
                }
                toInstall.installSingleComponent(new EnvironmentVariable(
                        DataWarehouseConstants.kBIComponentsToInstall,
                        inCallingDirectoryName));
                ;
            }
            if (verbose) {
                System.out.println("getComponentsDemoDataPackToInstall: "
                        + toInstall.getComponentsDemoDataPackToInstall());
            }
            return toInstall;

        } catch (final Exception e) {
            e.printStackTrace();
            throw new Exception(e.getMessage());
        }

    }
}
