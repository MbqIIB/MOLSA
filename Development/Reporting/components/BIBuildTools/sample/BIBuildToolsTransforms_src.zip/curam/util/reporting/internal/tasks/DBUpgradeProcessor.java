/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;

import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.type.*;

/**
 * Generates update statements
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class DBUpgradeProcessor {
    /**
     * generates alter statements from meta data
     * 
     */
    public void process(final String inMetaData, final String inSQLFile,
            final TargetDataBaseType inTargetDataBaseType) {
        try {
            BufferedReader in = null;
            final ReportingFile name;
            File sourceFile;
            File destinationFile;
            boolean appendFlag = false;
            BufferedWriter out;
            final String kDB2Template = "CURRENT_TIMESTAMP";
            final String kOracleTemplate = "SYSDATE";
            String now = kDB2Template;
            short tablesEffected = 0;
            destinationFile = new File(inSQLFile);
            sourceFile = new File(inMetaData);
            if (!sourceFile.exists()) {
                throw new Exception("file does not exist "
                        + sourceFile.getAbsolutePath());
            }
            if (inTargetDataBaseType.isORACLE()) {
                now = kOracleTemplate;
            }
            if (!destinationFile.exists()) {
                destinationFile.createNewFile();
            } else {
                appendFlag = false;
            }
            BILogger.info("Processing, sourceFile file "
                    + sourceFile.getAbsolutePath());
            BILogger.info("Processing, destination file "
                    + destinationFile.getAbsolutePath());
            in = new BufferedReader(new FileReader(sourceFile));
            final Charset utf = Charset.forName(ReportingConcatenator.characterSetUTF_8);
            out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(
                    destinationFile, appendFlag), utf));
            // Transfer bytes from in to out
            String line;
            StringBuffer alterStatements = new StringBuffer();
            while ((line = in.readLine()) != null) {
                if (line.length() > 0) {
                    try {
                        final java.util.StringTokenizer parts = new java.util.StringTokenizer(
                                line, ",");
                        alterStatements = new StringBuffer();
                        alterStatements.append("alter table ").append(parts.nextToken())
                        .append(" modify  (").append(parts.nextToken()).append(" ")
                        .append(parts.nextToken()).append(" );");
                        tablesEffected++;
                        out.write(alterStatements.toString());
                        out.flush();
                        out.newLine();
                    } catch (final java.util.NoSuchElementException e) {
                        BILogger.info("line is badly formed: " + line);
                    }
                }
            }
            out.flush();
            out.close();
            in.close();
            BILogger.info("Created " + tablesEffected + " update statements");
        } catch (final Exception ioe) {
            ioe.printStackTrace();
            BILogger.info("DBUpgradeProcessor:" + ioe.getMessage());
        }
    }
}
