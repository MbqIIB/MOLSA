/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.apidoc;

import com.sun.javadoc.AnnotationDesc;
import com.sun.javadoc.Doc;
import com.sun.javadoc.LanguageVersion;
import com.sun.javadoc.ProgramElementDoc;
import com.sun.javadoc.RootDoc;
import com.sun.tools.doclets.standard.Standard;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import curam.util.type.*;

/**
 * 
 * This class ensures that external Java API documentation is only created for
 * Java classes that have been identified as part of the public API for Curam
 * Reporting.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
@SuppressWarnings({ "unchecked", "rawtypes" })
public class BIAPIDoclet extends Standard {
    private static Map<Object, Object> proxies = new WeakHashMap();

    public static boolean start(final RootDoc root) {
        return Standard.start((RootDoc) process(root, RootDoc.class));
    }

    public static LanguageVersion languageVersion() {
        return LanguageVersion.JAVA_1_5;
    }

    private static Object getProxy(final Object obj) {
        Object proxy = proxies.get(obj);
        if (proxy == null) {
            proxy = Proxy.newProxyInstance(obj.getClass().getClassLoader(), obj
                    .getClass().getInterfaces(), new ExcludeHandler(obj));
            proxies.put(obj, proxy);
        }
        return proxy;
    }

    static Object process(final Object obj, final Class<?> expect) {
        if (obj == null) {
            return null;
        }
        final Class cls = obj.getClass();
        if (cls.getName().startsWith("com.sun.")) {
            return getProxy(obj);
        }
        if ((obj instanceof Object[])) {
            Class componentType = expect.getComponentType();
            if (componentType == null) {
                componentType = Object.class;
            }
            final Object[] array = (Object[]) (Object[]) obj;
            final List list = new ArrayList(array.length);
            for (final Object entry : array) {
                if (((entry instanceof Doc)) && (exclude((Doc) entry))) {
                    continue;
                }
                list.add(process(entry, componentType));
            }
            return list.toArray((Object[]) (Object[]) Array.newInstance(
                    componentType, list.size()));
        }
        return obj;
    }

    static boolean exclude(final Doc doc) {
        if ((doc instanceof ProgramElementDoc)) {
            final ProgramElementDoc programElementDoc = (ProgramElementDoc) doc;
            for (final AnnotationDesc annotationDesc : programElementDoc.annotations()) {
                if (!"curam.util.type.AccessLevel".equals(annotationDesc
                        .annotationType().toString())) {
                    continue;
                }
                final String annotationValue = annotationDesc.elementValues()[0].value()
                .toString();
                if (("curam.util.type.AccessLevelType.INTERNAL".equals(annotationValue))
                        || ("curam.util.type.AccessLevelType.RESTRICTED"
                                .equals(annotationValue))) {
                    return true;
                }
            }
        }
        return false;
    }

    private static class ExcludeHandler implements InvocationHandler {
        private final Object target;

        public ExcludeHandler(final Object target) {
            this.target = target;
        }


        public Object invoke(final Object proxy, final Method method, final Object[] args)
        throws Throwable {
            if (args != null) {
                final String methodName = method.getName();
                if (("compareTo".equals(methodName)) || ("equals".equals(methodName))
                        || ("overrides".equals(methodName))
                        || ("subclassOf".equals(methodName))) {
                    args[0] = unwrap(args[0]);
                }
            }
            try {
                return BIAPIDoclet.process(method.invoke(this.target, args),
                        method.getReturnType());
            } catch (final InvocationTargetException e) {
                throw e.getTargetException();
            }
        }

        private Object unwrap(final Object proxy) {
            if ((proxy instanceof Proxy)) {
                return ((ExcludeHandler) Proxy.getInvocationHandler(proxy)).target;
            }
            return proxy;
        }
    }
}
