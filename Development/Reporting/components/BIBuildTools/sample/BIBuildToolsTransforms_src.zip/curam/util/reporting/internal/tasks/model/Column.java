/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks.model;

import curam.util.type.*;

/**
 * A data dictionary object for a column
 * 
 */
@AccessLevel(AccessLevelType.RESTRICTED)
public class Column {
  /**
   * the name of the column/element
   * 
   */
  protected String name;

  /**
   * the data type of the column, generic and SQL type
   * 
   */
  protected ColumnType reportingType;

  /**
   * the value of the column/element only set for row objects and not for data
   * dictionary objects
   * 
   */
  protected String value;

  /**
   * returns the value of a row from an xml element
   * 
   * @return String the field value read from the xml file
   */
  public String getValue() {
    return value;
  }

  /**
   * set the value from disk
   * 
   * @param value
   *          the value from an xml elements
   */
  public void setValue(String value) {
    this.value = value;
  }

  /**
   * Column
   * 
   */
  public Column() {
  }

  /**
   * @throws Exception
   */
  public void validate() throws Exception {
    if (name == null || name.length() == 0) {
      throw new Exception("invalid column name " + name);
    }
    reportingType.validate();
  }

  /**
   * returns the column name
   * 
   * @return String - column name
   * 
   */
  public String getName() {
    return name;
  }

  /**
   * returns the demo data type
   * 
   * 
   * @return String
   * @see ColumnType
   */
  public String getReportingType() {
    return reportingType.getDataType();
  }

  /**
   * returns the demo data type with SQL type
   * 
   * 
   * @return ColumnType
   * @see ColumnType
   */
  public ColumnType getColumnType() {
    return reportingType;
  }

  /**
   * if the column names are the same
   */
  @Override
  public boolean equals(Object obj) {
    if (obj instanceof Column) {
      Column columnData = (Column) obj;
      if (this.name.equals(columnData.name)) {
        return true;
      }
    }
    return false;
  }

  /**
   * set the column name
   * 
   * @param name
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * sets the data type
   * 
   * @param type
   */
  public void setReportingType(String type) {
    this.reportingType = new ColumnType(type);
  }

  /**
   * return the name value pair
   */
  @Override
  public String toString() {
    return "<column name=" + name + "=" + name + " " + this.reportingType + ">";
  }
}
