/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

/**
 * This module checks an error file for OMBplus import error messages throwing a
 * build exception
 * 
 * @deprecated
 * @since 5.2 SP4
 */
@Deprecated
public class AntDropSchemaObjects extends Task {
    /**
     * the path to the error file
     */
    private String createTableSQLFileName;

    /**
     * write the drop statements to here
     */
    private String dropStatements;

    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     */
    @Override
    public void execute() throws BuildException {
        BufferedReader sqlFile = null;
        try {
            // a line from the error file
            String message;
            final String kDrop = "drop";
            final StringBuffer drops = new StringBuffer();
            short objectsDropped = 0;
            // open the error file
            sqlFile = new BufferedReader(new FileReader(createTableSQLFileName));
            while ((message = sqlFile.readLine()) != null) {
                if (message.startsWith(kDrop)) {
                    drops.append(message + System.getProperty("line.separator"));
                    objectsDropped++;
                }
            }
            getProject().setProperty(dropStatements,
                    (drops.toString() + System.getProperty("line.separator")).trim());
        } catch (final FileNotFoundException e) {
            throw new BuildException("File not found <" + createTableSQLFileName
                    + ">");
        } catch (final IOException e) {
            throw new BuildException("Error reading file <" + createTableSQLFileName
                    + ">");
        } finally {
            if (sqlFile != null) {
                try {
                    sqlFile.close();
                } catch (final IOException e) {
                    // nothing we can do here only log the message
                    BILogger.error(e.getMessage());
                }
            }
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the path to the error file
     * 
     * @param inCreateTablesSQLFileName
     *          path to the error file
     */
    public void setFile(final String inCreateTablesSQLFileName) {
        createTableSQLFileName = inCreateTablesSQLFileName;
    }

    // ___________________________________________________________________________
    /**
     * Write the drop statements to here
     * 
     * @param inPropertyName
     *          drop statements property name
     */
    public void setDropStatements(final String inPropertyName) {
        dropStatements = inPropertyName;
    }
}
