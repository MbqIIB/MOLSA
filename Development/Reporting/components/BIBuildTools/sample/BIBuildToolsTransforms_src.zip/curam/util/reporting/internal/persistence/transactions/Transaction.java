/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 1999-2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.persistence.transactions;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * This module defines the transaction interface
 */
public interface Transaction {

    // ___________________________________________________________________________
    /**
     * Executes a batch and checks the update counts 
     * @param inStatement the statement to process
     */
    public int executeBatch(final Statement inStatement) throws SQLException ;
    // ___________________________________________________________________________
    /**
     * Commits changes to the database
     * 
     * @throws SQLException
     */
    public void commit() throws SQLException;

    // ___________________________________________________________________________
    /**
     * Rolls back any changes to the database
     * 
     * @throws SQLException
     */
    public void rollback() throws SQLException;

    // ___________________________________________________________________________
    /**
     * Starts the transaction
     * 
     * @throws SQLException
     */
    public void start() throws SQLException;

    // ___________________________________________________________________________
    /**
     * Returns the underlying database connection
     * 
     * @return Connection
     * @throws SQLException
     */
    public Connection getConnection() throws SQLException;

    // ___________________________________________________________________________
    /**
     * Returns true if this transaction was started locally
     * 
     * @return boolean returns true if client managed
     */
    public boolean isClientManagedTransaction();

    // ___________________________________________________________________________
    /**
     * Returns the data source name
     * 
     * @return String the data source name
     */
    public String getDataSourceName();

    // ___________________________________________________________________________
    /**
     * Returns the data source name
     * 
     * @return String the schema name
     */
    public String getSchemaName();

    // ___________________________________________________________________________
    /**
     * Returns the data source name
     * 
     * @param inSchemaName
     *          the logical schema name
     */
    public void setSchemaName(String inSchemaName);

}
