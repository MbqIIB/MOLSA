/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 1999-2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.config;

import java.io.PrintStream;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;

/**
 * This module tests if a connection to a database can be established
 * 
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
class JDBCConnectTest {

  /**
   * the Oracle driver to be used for transformations
   */
  static private final String kOracleDirver = "oracle.jdbc.driver.OracleDriver";

  /**
   * the DB2 driver to be used for transformations
   */

  static private final String kDB2Dirver = "com.ibm.db2.jcc.DB2Driver";

  /**
   * have the database drivers been loaded
   */
  private boolean driversLoaded = false;

  // ___________________________________________________________________________
  /**
   * Creates a connection to a database using connection properties
   * 
   * @param inConnectionProperties
   *            the database connection properties
   * @param inLog
   *            write log messages to this stream
   * @throws Exception
   *             if a connection to the RDBMS could not be made
   */
  public void newConnection(ConnectionProperties inConnectionProperties,
      PrintStream inLog) throws Exception {

    // the database connection
    Connection connection = null;
    Driver driver = null;
    boolean success = true;

    if (!driversLoaded) {
      if (inConnectionProperties.getTargetDataBaseType().isORACLE()) {
        driver = (Driver) Class.forName(kOracleDirver).newInstance();
      } else {
        driver = (Driver) Class.forName(kDB2Dirver).newInstance();
      }
      DriverManager.registerDriver(driver);
      driversLoaded = true;
    }

    try {
      // get a new connection
      connection = DriverManager.getConnection(
          inConnectionProperties.getUrl(),
          inConnectionProperties.getUserid(),
          inConnectionProperties.getPassword());

    } catch (SQLException e) {
      success = false;
      throw new Exception("Failed to connect, " + e.getMessage()
          + System.getProperty("line.separator")
          + inConnectionProperties.toString());
    } finally {

      if (inConnectionProperties.getTargetDataBaseType().isORACLE()) {
        String KPIDevelopment = (inConnectionProperties
            .usingAlternateURL() == true ? "(checking SID for KPI's)"
            : "");
        System.out.println("  jdbc connect= " + success + " for "
            + inConnectionProperties.getUserid() + KPIDevelopment);
      } else {
        System.out.println("  jdbc connect= " + success + " for "
            + inConnectionProperties.getPoolName() + " - "
            + inConnectionProperties.getUrl());
      }

      // close the connection
      if (connection != null) {
        connection.close();
      }
    }

  }
}
