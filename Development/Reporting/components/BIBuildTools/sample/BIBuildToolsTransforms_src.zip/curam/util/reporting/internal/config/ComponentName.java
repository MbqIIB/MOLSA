/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.config;

import java.io.File;

/**
 * 
 * This class represents a component within Curam Reporting, it models the
 * actual name of the component and the name of the directory on disk.
 * 
 * This is used by the build environment when building and deploying.
 * 
 * 
 */
public class ComponentName {

    /*
     * a component name, generally corresponds to a directory name
     */
    private final String componentName;

    /**
     * Test for equality
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ComponentName other = (ComponentName) obj;
        if (componentName == null) {
            if (other.componentName != null) {
                return false;
            }
        } else if (!componentName.equalsIgnoreCase(other.componentName)) {
            return false;
        }
        return true;
    }

    /**
     * Returns the component name or directory name,
     * includes language and dialect
     * @param componentName
     *          the component name, generally corresponds to a directory name
     */
    public ComponentName(final String componentName) {
        super();
        this.componentName = componentName.trim();
    }

    /**
     * @return the component name, generally corresponds to a directory name
     */
    public String getComponentName() {
        return componentName;
    }

    /**
     * @return the component name, generally corresponds to a directory name
     */
    public String getDirectoryName() {
        return getComponentName();
    }

    /**
     * @return String the custom directory name, for example core custom
     */
    public String getCustomDirectoryName() {
        return File.separator + getComponentName() + File.separator
        + File.separator + "custom";
    }

    /**
     * @return String the custom directory name, for example en_US
     */
    public String getLanguageAndRegionCode() {
        final int languageAndRegion = getComponentName().indexOf("_");
        String code = "";
        if (languageAndRegion != -1) {
            code = getComponentName().substring(languageAndRegion + 1,
                    getComponentName().length());
        }
        return code;
    }

    /**
     * @return String the custom directory name, for example core custom
     */
    public String getComponentNameWithoutLanguageAndRegionCode() {
        final int languageAndRegion = getComponentName().indexOf("_");
        String code = getComponentName();
        if (languageAndRegion != -1) {
            code = getComponentName().substring(0, languageAndRegion);
        }
        return code;
    }

    /**
     * @return return less than 0 if this is not a language pack, 1 if only a
     *         language, 2 if a language and region
     */
    public int isLanguageAndRegion() {
        final int languageAndRegion = getComponentName().indexOf("_");
        if (languageAndRegion == -1) {
            return -1;
        }
        final String languageCode = getComponentName().substring(languageAndRegion,
                getComponentName().length());

        // just a language
        if (languageCode.length() >= 4) {
            return 2;
        }

        // just a language, e.g. en
        return 1;
    }

    /**
     * @param inName
     * @return return true if the parameter is a language pack of the current
     *         component, e.g. returns true if parameter is german and this
     *         objects component name is "core"
     */
    public boolean isLanguageOf(final ComponentName inName) {

        if (this.componentName.equalsIgnoreCase(inName
                .getComponentNameWithoutLanguageAndRegionCode())) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @return the component name
     */
    @Override
    public String toString() {
        return getComponentName();
    }

}
