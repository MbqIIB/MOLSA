/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.File;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;
import org.apache.tools.ant.Task;

import curam.util.type.*;

/**
 * 
 * This class generates SQL data definition statements for the reporting
 * databases.
 * 
 * This build task will include custom directories for client artifacts.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntGenerateInitialData extends Task {
    /**
     * a full path to the data manager directory
     */
    private String demoDataDirectory;

    /**
     * the root reporting directory
     */
    private String reportingDir;

    /**
     * the the file set to copy
     */
    private String fileset;

    // ___________________________________________________________________________
    /**
     * local test harness for developers
     * 
     * @param inArguments
     * @throws Exception
     */
    public static void main(final String[] inArguments) throws Exception {
        if (inArguments.length != 1) {
            throw new Exception(
            " buildFileFullPath , ensure to pass the Reporing dir as a parameter using -DREPORTING_DIR=");
        }
        // arg[0] is the build file (full path)
        final File buildFile = new File(inArguments[0]);
        final Project p = new Project();
        p.setUserProperty("ant.file", buildFile.getAbsolutePath());
        p.init();
        final ProjectHelper helper = ProjectHelper.getProjectHelper();
        p.addReference("ant.projectHelper", helper);
        helper.parse(p, buildFile);
        p.executeTarget("database.initialdata");
        // test one or the other
        // p.executeTarget("database.demodata");
    }

    // ___________________________________________________________________________
    /**
     * Throws a build exception if OMBplus reported errors for a command
     * 
     * @throws BuildException
     * 
     */
    @Override
    public void execute() throws BuildException {
        try {
            final Project antProject = getProject();
            String calledFrom = "";
            if (antProject != null) {
                // if we get a valid ant project object then getBaseDir will
                // return
                // the calling directory, e.g. "components", "core" etc
                // if we are in the "components" directory then build for
                // everything installed on disk.
                // otherwise build for the specific component only
                calledFrom = antProject.getBaseDir().getName();
            } else {
                System.out
                .println("Error:Can't get the ant project:Project ant = getProject");
            }
            BILogger.info("Processing file set " + fileset);
            final ReportingFileManager fileManager = new ReportingFileManager(calledFrom,
                    reportingDir);
            fileManager.mergeInitialDataFiles(demoDataDirectory, fileset);
        } catch (final BuildException e) {
            throw new BuildException(e.getMessage());
        } catch (final Exception e) {
            throw new BuildException(e.getMessage());
        }
    }

    // ___________________________________________________________________________
    /**
     * Sets the base reporting directory
     * 
     * @param inReportingDir
     *          base reporting directory
     */
    public void setReportingDir(final String inReportingDir) {
        reportingDir = inReportingDir;
    }

    // ___________________________________________________________________________
    /**
     * the location where the DDL will be written to
     * 
     * @param inDemoDataDirectory
     * 
     */
    public void setDemoDataDirectory(final String inDemoDataDirectory) {
        this.demoDataDirectory = inDemoDataDirectory;
    }

    // ___________________________________________________________________________
    /**
     * the location where the DDL will be written to
     * 
     * @param inCopyPattern
     * 
     */
    public void setFileset(final String inCopyPattern) {
        this.fileset = inCopyPattern;
    }
}
