/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.apidoc;

import com.sun.javadoc.Tag;
import com.sun.tools.doclets.Taglet;
import java.util.Map;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;

/**
 *
 * This class provides a tag that can be ready by a Java Documentation Taglet.
 *
 * Java classes can be identified as part of the public API for Curam Reporting
 * and categorized by using the tag below.
 *
 */
@AccessLevel(AccessLevelType.INTERNAL)
@SuppressWarnings({ "unchecked", "rawtypes" })
public class BIBusinessProcessing implements Taglet {

  /**
   * the tag name, this is the name to using in Java documentation comments.
   */
  private static final String kName = "bowrite";
  /**
   * This is the label applied to the HTML output from the Java documentation
   * tasks.
   */
  private static final String kHeaderName = "Business Object Write:";

  /**
   * Registers the tag.
   *
   * @param tagletMap
   *          the tag to register
   */
  public static void register(Map tagletMap) {
    BIBusinessProcessing tag = new BIBusinessProcessing();
    Taglet t = (Taglet) tagletMap.get(tag.getName());
    if (t != null) {
      tagletMap.remove(tag.getName());
    }
    tagletMap.put(tag.getName(), tag);
  }

  public String getName() {
    return kName;
  }

  public boolean inConstructor() {
    return false;
  }

  public boolean inField() {
    return false;
  }

  public boolean inMethod() {
    return true;
  }

  public boolean inOverview() {
    return false;
  }

  public boolean inPackage() {
    return false;
  }

  public boolean inType() {
    return false;
  }

  public boolean isInlineTag() {
    return false;
  }

  /**
   * Returns the HTML representation of the tag.
   *
   * @return returns the output for this tag in HTML format.
   */
  public String toString(Tag tag) {
    return "<DT><B>"
        + kHeaderName
        + ":</B><DD><table cellpadding=2 cellspacing=0><tr><td bgcolor=\"Aquamarine\">"
        + tag.text() + "</td></tr></table></DD>\n";
  }

  /**
   * Returns the HTML representation of the tags if there are more than one.
   *
   * @return returns the output for the tag(s) in HTML format.
   */
  public String toString(Tag[] tags) {
    if (tags.length == 0) {
      return null;
    }
    String result = "\n<DT><B>" + kHeaderName + ":</B><DD>";
    result = result
        + "<table cellpadding=2 cellspacing=0><tr><td bgcolor=\"Aquamarine\">";

    for (int i = 0; i < tags.length; i++) {
      if (i > 0) {
        result = result + ", ";
      }
      result = result + tags[i].text();
    }
    return result + "</td></tr></table></DD>\n";
  }
}
