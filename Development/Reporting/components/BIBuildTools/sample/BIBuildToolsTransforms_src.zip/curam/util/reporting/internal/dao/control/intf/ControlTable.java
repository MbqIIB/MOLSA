/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */

package curam.util.reporting.internal.dao.control.intf;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import curam.util.reporting.internal.dao.control.base.ProcessControl;
import curam.util.reporting.internal.dao.control.base.ProcessControlState;

import curam.util.type.*;

/**
 * This module is a interface for class which update ETL infrastructure tables.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ControlTable {

  // ___________________________________________________________________________
  /**
   * Returns the number of rows in a table.
   * 
   * @param inTableName
   *          the target table name
   * 
   * @return int number of rows of data
   * 
   * @throws SQLException
   *           if a database operation fails
   */

  public int getRowsInTable(String inTableName) throws SQLException;

  /**
   * 
   * @return a list of object of type ProcessControl
   * @throws SQLException
   */
  public List<ProcessControl> readAll() throws SQLException;

  // ___________________________________________________________________________
  /**
   * Reads all process control records with success indicators
   * 
   * @return List of type ProcessControlState
   * 
   * @throws SQLException
   *           if a database operation fails
   */

  public Map<String, ProcessControlState> readETLResults() throws SQLException;

  // ___________________________________________________________________________
  /**
   * Reads a process control record for a given target table name.
   * 
   * @param inTargetTable
   *          the target table name
   * @return ProcessControl the process control data for the target table
   * 
   * @throws SQLException
   *           if a database operation fails
   */

  public ProcessControl read(final String inTargetTable) throws SQLException;

  // ___________________________________________________________________________
  /**
   * Sets the date from which to extract data from.
   * 
   * @param inDate
   *          the date from which to extract data from
   * @throws SQLException
   *           if database operation failed
   */
  void setExtractionDate(Date inDate) throws SQLException;

  // ___________________________________________________________________________
  /**
   * Sets the last ETL date time.
   * 
   * 
   * @param inTargetTableName
   *          the target table being populated
   * @throws SQLException
   *           if database operation failed
   */
  void updateLastETLDate(String inTargetTableName) throws SQLException;

  // ___________________________________________________________________________
  /**
   * Clears all data from a staging table.
   * 
   * @param inTargetTableName
   *          the staging table to be cleared of data
   * @throws SQLException
   *           if database operation failed
   */
  void clearStagingTable(String inTargetTableName) throws SQLException;

  // ___________________________________________________________________________
  /**
   * Sets the extract start date time for an ETL process.
   * 
   * @param inTargetTableName
   *          the target table being populated
   * @return {@link Timestamp} the ETL start time
   * @throws SQLException
   *           if database operation failed
   */
  Timestamp updateStartTime(String inTargetTableName) throws SQLException;

  // ___________________________________________________________________________
  /**
   * Returns the control table name.
   * 
   * @return String
   */
  public String getControlTableName();

  // ___________________________________________________________________________
  /**
   * Inserts a process control record for a given target table name.
   * 
   * 
   * @param inProcessControl
   *          the record to insert
   * 
   * @throws SQLException
   *           if a database operation fails
   */
  public void insertData(ProcessControl inProcessControl) throws SQLException;
}
