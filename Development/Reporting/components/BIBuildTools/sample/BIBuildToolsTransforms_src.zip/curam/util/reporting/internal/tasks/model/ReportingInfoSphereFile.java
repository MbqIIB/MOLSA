/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * 
 */
package curam.util.reporting.internal.tasks.model;

import java.io.File;

import curam.util.type.*;

@AccessLevel(AccessLevelType.RESTRICTED)
public class ReportingInfoSphereFile extends ReportingFile {

    private boolean dataFlowExists = true;
    private ReportingFile dataFlow = null;


    public boolean doesDataFlowExist() {
        return dataFlowExists;
    }

    public ReportingFile getDataFlow() {
        return dataFlow;
    }


    public void setDataFlow(final File inFile) {
        this.dataFlow = new ReportingFile (inFile.getAbsolutePath(), false);
        if (inFile.exists()) {
            dataFlowExists = true;
        } else {
            dataFlowExists = false;
        }
    }


    public ReportingInfoSphereFile(final String inFileName, final boolean inIsCustom) {
        super(inFileName, inIsCustom);
    }
}
