/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.security;

import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.Signature;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import javax.crypto.Cipher;

public final class SecurityProviderUtil {
  private static final String kFIPSEnabled = "curam.enabledFIPS";

  private static final String kSecurityPRoviderProp =
      "curam.security.crypto.cipher.provider.class";

  private static final String kBootstrap = "Bootstrap";

  private static final String kCryptoConfig = "CryptoConfig";

  static Signature getSignature(String algName, String customjceProvider)
      throws Exception {
    if (!isNullOrEmpty(customjceProvider)) {
      return Signature.getInstance(algName, customjceProvider);
    }
    return Signature.getInstance(algName);
  }

  static
      MessageDigest getMessageDigest(String algName, String customjceProvider)
          throws Exception {
    if (!isNullOrEmpty(customjceProvider)) {
      return MessageDigest.getInstance(algName, customjceProvider);
    }
    return MessageDigest.getInstance(algName);
  }

  static Cipher getCipher(String algName, String customjceProvider)
      throws Exception {
    if (!isNullOrEmpty(customjceProvider)) {
      return Cipher.getInstance(algName, customjceProvider);
    }
    return Cipher.getInstance(algName);
  }

  static
      KeyStore getKeyStoreInstance(String storeType, String customjceProvider)
          throws Exception {
    if (!isNullOrEmpty(customjceProvider)) {
      return KeyStore.getInstance(storeType, customjceProvider);
    }
    return KeyStore.getInstance(storeType);
  }

  static String getProperty(String key) throws Exception {
    String value = null;
    try {
      ResourceBundle resourceBundle = ResourceBundle.getBundle("Bootstrap");
      value = resourceBundle.getString(key);
    } catch (MissingResourceException e) {
    }
    if (value == null) {
      try {
        ResourceBundle resourceBundle = ResourceBundle
            .getBundle("CryptoConfig");
        value = resourceBundle.getString(key);
      } catch (MissingResourceException e) {
      }
    }
    return value;
  }

  static MessageDigest getMessageDigest(String algName) throws Exception {
    String customjceProvider =
        getProperty("curam.security.crypto.cipher.provider.class");
    return getMessageDigest(algName, customjceProvider);
  }

  static Cipher getCipher(String algName) throws Exception {
    String customjceProvider =
        getProperty("curam.security.crypto.cipher.provider.class");
    return getCipher(algName, customjceProvider);
  }

  static Signature getSignature(String algName) throws Exception {
    String customjceProvider =
        getProperty("curam.security.crypto.cipher.provider.class");
    return getSignature(algName, customjceProvider);
  }

  static KeyStore getKeyStoreInstance(String storeType) throws Exception {
    String customjceProvider =
        getProperty("curam.security.crypto.cipher.provider.class");
    return getKeyStoreInstance(storeType, customjceProvider);
  }

  static boolean isNullOrEmpty(String theString) {
    if (theString == null) {
      return true;
    }
    return theString.equals("");
  }
}
