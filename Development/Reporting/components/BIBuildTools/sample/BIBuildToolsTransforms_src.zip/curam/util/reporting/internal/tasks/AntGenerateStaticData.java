/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.config.*;

import curam.util.type.*;

/**
 * 
 * This class generated OWB run scripts for the reporting databases.
 * 
 * This build task will include custom directories for client artifacts.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntGenerateStaticData extends Task {
  /**
   * a full path to the datamanager directory
   */
  private String dataManagerDirectory;

  /**
   * the root reporting directory
   */
  private String reportingDir;

  /**
   * the component name directory
   */
  private ComponentName debugComponentName;

  /**
   * local test harness for developers
   * 
   * @param inArguments
   * @throws Exception
   */
  public static void main(String[] inArguments) throws Exception {
    if (inArguments.length != 1) {
      throw new Exception(
          " buildFileFullPath , ensure to pass the Reporing dir as a parameter using -DREPORTING_DIR=");
    }
    String baseDir = System.getenv("REPORTING_DIR");
    String workingDir = baseDir + File.separator + "components"
        + File.separator + "core";
    // arg[0] is the build file (full path)
    File buildFile = new File(inArguments[0]);
    Project p = new Project();
    p.setUserProperty("ant.file", buildFile.getAbsolutePath());
    p.setUserProperty("dir", workingDir);
    p.init();
    ProjectHelper helper = ProjectHelper.getProjectHelper();
    p.addReference("ant.projectHelper", helper);
    helper.parse(p, buildFile);
    p.executeTarget("staticdata");
  }

  // ___________________________________________________________________________
  /**
   * Throws a build exception if OMBplus reported errors for a command
   * 
   * @throws BuildException
   *           a build exception
   */
  @Override
  public void execute() throws BuildException {
    try {
      Project antProject = getProject();
      String calledFrom;
      if (antProject != null) {
        // if we get a valid ant project object then getBaseDir will
        // return
        // the calling directory, e.g. "components", "core"
        // if we are in the "components" directory then build for
        // everything installed on disk.
        // otherwise build for the specific component only
        calledFrom = antProject.getBaseDir().getName();
      } else {
        // if this is not being called from ant we are in debug mode
        // and being executed from with Eclipse of some other Java
        // environment
        calledFrom = debugComponentName.getComponentName();
      }
      // pass in the calling directory to work out what components to build
      ReportingFileManager fileManager = new ReportingFileManager(calledFrom,
          reportingDir);
      fileManager.mergeStaticDataFiles(dataManagerDirectory);
    } catch (BuildException e) {
      throw new BuildException(e.getMessage());
    } catch (Exception e) {
      throw new BuildException(e.getMessage());
    }
  }

  // ___________________________________________________________________________
  /**
   * Sets the base reporting directory
   * 
   * @param inReportingDir
   *          base reporting directory
   */
  public void setReportingDir(String inReportingDir) {
    reportingDir = inReportingDir;
  }

  // ___________________________________________________________________________
  /**
   * Generates to this location
   * 
   * @param inDataManagerDirectory
   * 
   */
  public void setDataManagerDirectory(String inDataManagerDirectory) {
    this.dataManagerDirectory = inDataManagerDirectory;
  }
}
