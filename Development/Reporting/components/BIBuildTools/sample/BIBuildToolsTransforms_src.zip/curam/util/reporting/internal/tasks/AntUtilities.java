/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2011 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;
import org.apache.tools.ant.Task;

import curam.util.reporting.internal.config.AntVariable;
import curam.util.reporting.internal.config.ComponentOrder;
import curam.util.reporting.internal.config.DataWarehouseConstants;

import curam.util.type.*;

/**
 * 
 * This class provides a set of utilities to support the Ant build environment.
 * The set of operation types supported are listed below:
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntUtilities extends Task {
    /**
     * verbose
     */
    private Boolean verbose = null;

    private Boolean localVerboseOverRide = null;

    /**
     * a source property name
     */
    private String sourceproperty = "";

    /**
     * write the result to this property
     */
    private String propertyName;

    /**
     * using this as the input operand
     */
    private String value;

    /**
     * using this as the input operand
     */
    private String replace;

    /**
     * perform the following operation values currently supported are
     * 
     */
    private String operation;

    /**
     * returns the path to the component relative to the reporting dir, e.g.
     * "C:\REPORTING50\REPORTING\COMPONENTS\CORE" - will return components\core
     * e.g. "C:\REPORTING50\REPORTING\DEVENVIRONMENT" - will return DEVENVIRONMENT
     * return test1
     */
    private final String relativeComponentPathOperation = "componentpath";

    /**
     * returns the directory name in the path (e.g. c:\test\test1. This will
     * return test1
     */
    private final String componentOrderOperation = "component.order";

    /**
     * returns the directory name in the path (e.g. c:\test\test1. This will
     * return test1
     */
    private final String dirNameOperation = "dirname";

    /**
     * converts a string to upper case
     */
    private final String toUpperOperation = "toupper";

    /**
     * converts a string to upper case
     */
    private final String etlownername = "etlowner";

    /**
     * converts a string to upper case
     */
    private final String workspacename = "workspacename";

    /**
     * converts a file path to OWB format
     */
    private final String toOWBPathOperation = "toOWBpathformat";

    /**
     * is this an OWB client or server or both
     */
    private final String installowbrepository = "installowbrepository";

    /**
     * if the remote directory is not set default to the local directory
     */
    private final String dataManagerDir = "datamanagerdir";

    /**
     * if the remote directory is not set default to the local directory
     */
    private final String replaceOp = "replace";

    /**
     * if the remote directory is not set default to the local directory
     */
    private final String fileExists = "fileexists";

    /**
     * if the remote directory is not set default to the local directory
     */
    private final String fileName = "filename";

    /**
     * add the operation types to the list for validation
     */
    final String validOperations[] = { etlownername, installowbrepository,
            toOWBPathOperation, workspacename, toUpperOperation, dirNameOperation,
            relativeComponentPathOperation, dataManagerDir, componentOrderOperation,
            replaceOp, fileExists, fileName };

    // _________________________________________________________________________
    /**
     * start routine when debugging
     * 
     * @param args
     * 
     * @throws java.lang.Exception
     */
    public static void main(final String[] args) throws Exception {
        // arg[0] is the build file (full path)
        final File buildFile = new File(args[0]);
        final Project p = new Project();
        p.setUserProperty("ant.file", buildFile.getAbsolutePath());
        p.init();
        final ProjectHelper helper = ProjectHelper.getProjectHelper();
        p.addReference("ant.projectHelper", helper);
        helper.parse(p, buildFile);
        p.executeTarget("test.order");
    }

    // ___________________________________________________________________________
    /**
     * Throws a build exception the target operation is invalid
     */
    @Override
    public void execute() throws BuildException {
        final Project antProject = getProject();
        final String quiteProperty = antProject
        .getProperty("environment.buildproperties.antutilities.verbose");
        if (quiteProperty != null) {
            verbose = new Boolean(Boolean.parseBoolean(quiteProperty));
        } else {
            verbose = Boolean.FALSE;
        }
        if (propertyName == null || propertyName.length() == 0) {
            throw new BuildException("javaSourcePropertyName atrribute not set");
        }
        if (operation == null) {
            operation = "";
        }
        final String example =
            "<AntUtilities propertyName=\"newpropertyname\" operation=\"toupper\" value=\"string to convert\"/>";
        final String errorMessage = "unsupported operation attribute use ["
            + toUpperOperation + "|" + toOWBPathOperation + "|"
            + "|dirname|componentname|workspacename]" + ", e.g " + example;
        try {
            boolean validOperation = false;
            for (int i = 0; i < validOperations.length; i++) {
                if (operation.equalsIgnoreCase(validOperations[i])) {
                    validOperation = true;
                }
            }
            if (validOperation == false) {
                BILogger.error(operation + ", the supported operation are:");
                for (int i = 0; i < validOperations.length; i++) {
                    BILogger.info("\t " + validOperations[i]);
                }
                throw new BuildException(errorMessage);
            }
            if (dataManagerDir.equalsIgnoreCase(operation)) {
                final String remoteDir = antProject.getProperty(DataWarehouseConstants.kOracleRemoteDataManagerDir);
                final String defaultPath = DataWarehouseConstants
                .getDefaultDataManagerDirectory();
                if (remoteDir == null || remoteDir.length() == 0) {
                    value = defaultPath;
                } else {
                    value = remoteDir;
                }
                antProject.setProperty(propertyName, value);
            } else if (componentOrderOperation.equalsIgnoreCase(operation)) {
                final String reportingDir = antProject.getProperty(sourceproperty);
                if (localVerboseOverRide != null) {
                    ReportingFileManager.verbose = localVerboseOverRide.booleanValue();
                } else {
                    ReportingFileManager.verbose = false;
                }
                final ReportingFileManager fileManager = new ReportingFileManager(value,
                        reportingDir);
                final ComponentOrder order = fileManager.getComponentsToBuild(value);
                order.setVerbose(ReportingFileManager.verbose);
                order.getComponentsToInstallWithLanguagPacks();
                order.getComponentsDemoDataPackToInstall();
                value = order.toString();
            } else if (replaceOp.equalsIgnoreCase(operation)) {
                final String text = antProject.getProperty(sourceproperty);
                String temp = "sourceproperty";
                if (text != null) {
                    temp = text.replace(value, replace);
                    temp = temp.replace("\\\\", replace);
                    temp = temp.replace("//", replace);
                }
                value = temp;
                antProject.setProperty(propertyName, value);
            } else if (installowbrepository.equalsIgnoreCase(operation)) {
                final String owb = antProject
                .getProperty(DataWarehouseConstants.kOracleInstalledOnOWBClientBox);
                final String message = antProject
                .getProperty("environment.owb.oracleinstalled.errormessage");
                final AntVariable owbOracleInstalled = new AntVariable(
                        DataWarehouseConstants.kOracleInstalledOnOWBClientBox, owb);
                if (owbOracleInstalled.asBoolean()) {
                    ;
                } else {
                    value = message;
                }
                antProject.setProperty(propertyName, value);
            } else if (etlownername.equalsIgnoreCase(operation)) {
                if (value == null || value.length() == 0
                        || value.equalsIgnoreCase("${" + sourceproperty + "}")) {
                    value = "";
                } else {
                    String oracleVersion = antProject
                    .getProperty("environment.owbconfig.version");
                    if (oracleVersion == null) {
                        oracleVersion = "";
                    }
                    final String user = antProject.getProperty("design.db.username");
                    final String workspace = antProject.getProperty("design.db.workspacename");
                    if (oracleVersion.startsWith("11")) {
                        value = user + "." + workspace;
                    } else if (oracleVersion.startsWith("10")) {
                        value = user;
                    } else {
                        value = "";
                    }
                }
                antProject.setProperty(propertyName, value.toUpperCase());
            } else if (workspacename.equalsIgnoreCase(operation)) {
                if (value == null || value.length() == 0
                        || value.equalsIgnoreCase("${" + sourceproperty + "}")) {
                    value = "";
                } else {
                    String oracleVersion = antProject
                    .getProperty("environment.owbconfig.version");
                    if (oracleVersion == null) {
                        oracleVersion = "";
                    }
                    if (oracleVersion.startsWith("11")) {
                        final String user = antProject.getProperty("design.db.username");
                        final String workspace = antProject
                        .getProperty("design.db.workspacename");
                        value = user + "." + workspace;
                    } else {
                        value = "";
                    }
                }
                antProject.setProperty(propertyName, value.toUpperCase());
            } else if (toUpperOperation.equalsIgnoreCase(operation)) {
                value = value.toUpperCase();
                antProject.setProperty(propertyName, value);
            } else if (toOWBPathOperation.equalsIgnoreCase(operation)) {
                // replace any double back slashes
                final String tmp1 = value.replaceAll("\\\\\\\\", "/");
                // replace any single back slashes
                final String tmp = tmp1.replaceAll("\\\\", "/");
                antProject.setProperty(propertyName, tmp);
                value = tmp;
            } else if (fileName.equalsIgnoreCase(operation)) {
                final File file = new File(value);
                if (!file.exists()) {
                    value = "nosuchfile";
                }
                value = file.getName().trim();
                antProject.setProperty(propertyName, value);
            } else if (dirNameOperation.equalsIgnoreCase(operation)) {
                final File dir = new File(value);
                if (!dir.exists()) {
                    throw new BuildException(value + " is not a directory.");
                }
                value = dir.getName().trim();
                antProject.setProperty(propertyName, value);
            } else if (fileExists.equalsIgnoreCase(operation)) {
                final File file = new File(value);
                if (!file.exists()) {
                    value = "nosuchfile";
                } else {
                    value = file.getAbsolutePath();
                }
                antProject.setProperty(propertyName, value);
            } else if (relativeComponentPathOperation.equalsIgnoreCase(operation)) {
                final File directory = new File(value);
                if (!directory.exists()) {
                    throw new BuildException(value + " is not a directory.");
                }
                final String name = directory.getName().trim();
                final File parentDir = directory.getParentFile();
                String parentName = "";
                if (parentDir != null) {
                    parentName = parentDir.getName();
                }
                if ("components".compareToIgnoreCase(parentName) == 0) {
                    value = "components\\" + name;
                } else {
                    value = name;
                }
                antProject.setProperty(propertyName, value);
            } else {
                throw new BuildException(errorMessage);
            }
            if (localVerboseOverRide != null) {
                if (localVerboseOverRide.booleanValue() == true) {
                    BILogger.info(operation + "=[" + value + "]");
                } else {
                    ;
                }
            } else {
                if (verbose == true) {
                    BILogger.info(operation + " result is:\n" + "[" + value + "]");
                } else {
                    ;
                }
            }
        } catch (final Exception e) {
            e.printStackTrace();
            throw new BuildException(e.getMessage() + errorMessage);
        }
    }

    // ___________________________________________________________________________
    /**
     * Set the source property name
     * 
     * @param inValue
     *          source property name
     */
    public void setSourceproperty(final String inValue) {
        sourceproperty = inValue;
    }

    // ___________________________________________________________________________
    /**
     * The value of the property, the search character
     * 
     * @param inValue
     *          of the property
     */
    public void setValue(final String inValue) {
        value = inValue;
    }

    // ___________________________________________________________________________
    /**
     * The replace character
     * 
     * @param inValue
     *          of the property
     */
    public void setReplace(final String inValue) {
        replace = inValue;
    }

    // ___________________________________________________________________________
    /**
     * Sets the operation to execute
     * 
     * @param inOperationValue
     *          operation to execute
     */
    public void setOperation(final String inOperationValue) {
        operation = inOperationValue;
    }

    // ___________________________________________________________________________
    /**
     * The new property to create
     * 
     * @param inPropertyName
     *          new property to create
     */
    public void setPropertyName(final String inPropertyName) {
        propertyName = inPropertyName;
    }

    // ___________________________________________________________________________
    /**
     * The new property to create
     * 
     * @param inVerbose
     *          new property to create
     */
    public void setVerbose(final String inVerbose) {
        if (inVerbose != null && inVerbose.length() > 0) {
            final Boolean temp = new Boolean(Boolean.parseBoolean(inVerbose));
            localVerboseOverRide = temp.booleanValue();
        }
    }
}
