/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.tasks;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;

import curam.util.type.*;

/**
 * 
 * This class update statement for the source application, only setting the last
 * written column to the current date if the value is null.
 * 
 * This build task will include custom directories for client artifacts.
 * 
 * @deprecated since 6.0 SP2
 */
@Deprecated
@AccessLevel(AccessLevelType.EXTERNAL)
public class AntSourceLastWritten extends Task {
  /**
   * the path to the error file
   */
  @SuppressWarnings("unused")
  private String createTableSQLFileName;

  /**
   * write the drop statements to here
   */
  @SuppressWarnings("unused")
  private String updateProperty;

  /**
   * the db type string from the application property file
   */
  @SuppressWarnings("unused")
  private String dbType;

  // ___________________________________________________________________________
  /**
   * Throws a build exception if OMBplus reported errors for a command
   */
  @Override
  public void execute() throws BuildException {
  }

  // ___________________________________________________________________________
  /**
   * Sets the path to the error file
   * 
   * @param inCreateTablesSQLFileName
   *          path to the error file
   */
  public void setFile(String inCreateTablesSQLFileName) {
    createTableSQLFileName = inCreateTablesSQLFileName;
  }

  // ___________________________________________________________________________
  /**
   * the db type string from the application property file
   * 
   * @param inDBType
   *          drop statements property name
   */
  public void setSource(String inDBType) {
    dbType = inDBType;
  }

  // ___________________________________________________________________________
  /**
   * Write the drop statements to here
   * 
   * @param inPropertyName
   *          drop statements property name
   */
  public void setCreateNewProperty(String inPropertyName) {
    updateProperty = inPropertyName;
  }
}
