/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 *
 */
package curam.util.reporting.internal.tasks;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.DataWarehouseConstants;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.reporting.internal.config.TargetDataBaseType;
import curam.util.reporting.internal.tasks.model.ReportingFile;
import curam.util.reporting.internal.tasks.model.ReportingRunFile;

import curam.util.type.*;

/**
 * Returns a list of files to be processed by the BI build environment.
 * 
 */
@AccessLevel(AccessLevelType.INTERNAL)
public class FileExplorerRunScripts extends FileExplorer {
    /**
     * process only these files
     */
    final private String kRunArtifactPath = "run";

    /**
     * process only files with this suffix
     */
    private String fileNameFilter = ".bat";

    /**
     * process only files with this suffix
     */
    private boolean exactMatch = false;

    /**
     * generic path structure for run files
     */
    protected String relativePath;

    /**
     * staging or central or data-marts
     */
    ReportingDBType schema;

    /**
     * Object used to return the set of run scripts for a component
     * 
     * @param inComponentName
     * @param targetDataBaseType
     * @param inReportingDir
     */
    public FileExplorerRunScripts(
            final ComponentName inComponentName,
            final TargetDataBaseType targetDataBaseType,
            final String inReportingDir) {
        super(inComponentName, targetDataBaseType, inReportingDir);
        buildFilePath();
    }

    /**
     * Object used to return the set of run scripts for a component
     * 
     * @param inSchema
     * 
     * @param inComponentName
     * @param targetDataBaseType
     * @param inReportingDir
     */
    public FileExplorerRunScripts(
            final ReportingDBType inSchema,
            final ComponentName inComponentName,
            final TargetDataBaseType targetDataBaseType,
            final String inReportingDir) {
        super(inComponentName, targetDataBaseType, inReportingDir);
        schema = inSchema;
        buildFilePath();
    }

    protected void buildFilePath() {
        /*
         * set up the template for static data files. the items in <> will be there
         * are no run scripts for db2 replaced at runtime e.g.
         * <Reporting>\components\<core>\run\oracle
         */
        relativePath = getReportingDir() + File.separator
        + DataWarehouseConstants.kComponentsDir + File.separator
        + kTemplateComponentDirectoryName + File.separator + kRunArtifactPath
        + File.separator + "oracle" + File.separator;
    }

    public void setFilterExactMatch() {
        exactMatch = true;
    }

    public void setFilter(final String inFilter) {
        fileNameFilter = inFilter;
    }

    public void setBuildPath(final String inPath) {
        relativePath = inPath;
    }

    public ReportingDBType getSchema() {
        return schema;
    }

    public String getBuildPath() {
        return relativePath;
    }

    /**
     * Object used to return the set of run scripts for a component
     * 
     * @return List the list of files original or custom to be included in a build
     */
    @Override
    public List<ReportingFile> getFiles() throws Exception {
        final File customComponentPath = new File(relativePath.replaceAll(
                kTemplateComponentDirectoryName, getComponentName()
                .getCustomDirectoryName()));
        final File componentPath =
            new File(relativePath.replaceAll(
                    kTemplateComponentDirectoryName, getComponentName()
                    .getDirectoryName()));
        final List<ReportingFile> runFiles = new ArrayList<ReportingFile>();
        if (!componentPath.exists()) {
            BILogger.info("  info: no  files for  " + componentPath);
        }
        final FilenameFilter runFilter = new RunFileFilter(fileNameFilter, exactMatch);
        final File files[] = componentPath.listFiles(runFilter);
        File customFileAvailable = null;
        ReportingFile runFile = null;
        ReportingFile customRunFile = null;
        if (files != null) {
            for (int i = 0; i < files.length; i++) {
                if (files[i].isFile()) {
                    runFile = createFile(files[i].getCanonicalPath(), false);
                    customFileAvailable = new File(customComponentPath,
                            files[i].getName());
                    if (customFileAvailable.exists()) {
                        customRunFile = createFile(customFileAvailable.getCanonicalPath(),
                                true);
                        runFile = runFile.setCustomFileName(customRunFile);
                    }
                    runFiles.add(runFile);
                }
            }
        }
        return runFiles;
    }

    // __________________________________________________________________________
    /**
     * Creates a reporting file reference
     * 
     * @return the ReportingFile
     * 
     */
    @Override
    public ReportingFile createFile(final String inFile, final boolean isCustom) {
        return new ReportingRunFile(inFile, isCustom);
    }

    // __________________________________________________________________________
    /**
     * Filter allowing only DB2 meta-data tag files.
     */
    static class RunFileFilter implements FilenameFilter {
        private String filter = "";

        private boolean exact = false;

        public RunFileFilter(final String inFilter, final boolean inExactMatch) {
            filter = inFilter;
            exact = inExactMatch;
        }

        public boolean accept(final File dir, final String name) {
            // get the last seven characters of the string.
            final int suffixLength = filter.length();
            final int start = name.length() - suffixLength > 0 ? name.length()
                    - suffixLength : 0;
            final String suffix = name.substring(start, name.length());
            // return true if this is an ETL tag file
            if (suffix.equalsIgnoreCase(filter)) {
                if (exact) {
                    // the file name must be exactly the same not just the suffix
                    if (name.length() > filter.length()) {
                        return false;
                    }
                }
                return true;
            } else {
                return false;
            }
        }
    }
}
