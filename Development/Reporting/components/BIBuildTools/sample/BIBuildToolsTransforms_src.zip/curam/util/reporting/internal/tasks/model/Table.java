/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks.model;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * A data dictionary object table
 * 
 * This object is populated from an xml file using digester
 * 
 */
public class Table {
  /**
   * the table name from the xml file (excludes schema name at present)
   */
  private String name;

  /**
   * the columns that are present on the table
   */
  ArrayList<Column> columns = new ArrayList<Column>();

  public Table() {
    super();
  }

  public void validate() throws Exception {
    if (name == null || name.length() == 0) {
      throw new Exception("invalid table name " + name);
    }
    Iterator<Column> columns = getColumns();
    while (columns.hasNext()) {
      ((Column) columns.next()).validate();
    }
  }

  /**
   * the number of columns on the table
   * 
   * @return int
   */
  public int getNumberOfColumns() {
    return columns.size();
  }

  /**
   * returns the list of columns on the tables
   * 
   * @return Iterator
   */
  public Iterator<Column> getColumns() {
    return columns.iterator();
  }

  /**
   * adds column meta data to the table
   * 
   * @param column
   */
  public void addColumn(Column column) {
    this.columns.add(column);
  }

  /**
   * returns the table name
   * 
   * @return String
   */
  public String getName() {
    return name;
  }

  /**
   * sets the table name
   * 
   * @param name
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * returns a column given a name
   * 
   * @param inName
   * @return Column
   */
  public Column getColumn(String inName) {
    Iterator<Column> iterator = columns.iterator();
    Column column;
    while (iterator.hasNext()) {
      column = (Column) iterator.next();
      if (column.getName().equalsIgnoreCase(inName)) {
        return column;
      }
    }
    return null;
  }

  @Override
  public String toString() {
    StringBuffer out = new StringBuffer();
    out.append("<table name=").append(name).append(">");
    Iterator<Column> iterator = columns.iterator();
    Column column;
    while (iterator.hasNext()) {
      column = (Column) iterator.next();
      out.append(System.getProperty("line.separator")).append(column);
    }
    out.append("</table>");
    return out.toString();
  }
}
