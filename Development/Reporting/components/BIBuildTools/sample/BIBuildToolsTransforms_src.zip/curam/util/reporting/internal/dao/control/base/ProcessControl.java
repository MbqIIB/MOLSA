/*
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.dao.control.base;

import java.sql.Timestamp;

import curam.util.reporting.internal.config.ComponentName;
import curam.util.reporting.internal.config.DateFormatter;
import curam.util.reporting.internal.config.ReportingDBType;
import curam.util.type.*;

/**
 * This module defines functions to read ETL process data.
 * 
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public class ProcessControl {
    /**
     * the ETL control table name
     */
    private ComponentName component = null;

    /**
     * the ETL control table name
     */
    private String etlControlTable = "";

    /**
     * the target table name.
     */
    private final String targetTableName;

    /**
     * the date data was last extracted, LAST_ETL_DATE in the database.
     */
    private final Timestamp lastExtractDate;

    /**
     * the date the ETL started, note the ETL may not finish if an error occurs
     */
    private final Timestamp extractStartDate;

    /**
     * the date the ETL finished, used in determining the ETL duration
     */
    private Timestamp extractFinishDate;

    /**
     * the date the ETL was last executed.
     */
    private final boolean truncateTable;

    // ___________________________________________________________________________
    /**
     * Ensures this class cannot be created.
     * 
     * @param inTargetTableName
     *          the target table name
     * 
     * @param inLastExtractDate
     *          time the ETL started to execute
     * @param inExtractStartDate
     * @param inTruncateTable
     *          true if table is to be truncated
     * @param inExtractFinishDate
     */
    public ProcessControl(
            final String inTargetTableName,
            final Timestamp inLastExtractDate,
            final Timestamp inExtractStartDate,
            final boolean inTruncateTable,
            final Timestamp inExtractFinishDate) {
        targetTableName = inTargetTableName;
        extractStartDate = inExtractStartDate;
        lastExtractDate = inLastExtractDate;
        truncateTable = inTruncateTable;
    }

    // ___________________________________________________________________________
    /**
     * Ensures this class cannot be created.
     * 
     * @param inETLControl
     *          the control record
     */
    public ProcessControl(final ProcessControl inETLControl) {
        targetTableName = inETLControl.targetTableName;
        extractStartDate = inETLControl.extractStartDate;
        lastExtractDate = inETLControl.lastExtractDate;
        truncateTable = inETLControl.truncateTable;
    }

    // __________________________________________________________________________
    /**
     * Sets the control table name, e.g. S_ETLCONTROL.
     * 
     * @param inControlTableName
     *          the control table name
     */
    public void setControlTableName(final String inControlTableName) {
        if (inControlTableName != null) {
            etlControlTable = inControlTableName;
        }
    }

    // __________________________________________________________________________
    /**
     * Returns the control table name, e.g. S_ETLCONTROL.
     * 
     * @return the control table name
     */
    public String getControlTableName() {
        return etlControlTable;
    }

    // __________________________________________________________________________
    /**
     * Returns the control table name, e.g. S_ETLCONTROL.
     * 
     * @return the control table name
     */
    public ReportingDBType getSchemaType() {
        ReportingDBType schema = null;
        try {
            schema = new ReportingDBType(etlControlTable);
        } catch (final Exception e) {
            e.printStackTrace();
        }
        return schema;
    }

    // __________________________________________________________________________
    /**
     * Returns true if the table is to be truncated.
     * 
     * @return boolean true if the table is to be truncated
     */
    public boolean isTruncateTable() {
        return truncateTable;
    }

    // __________________________________________________________________________
    /**
     * Returns the date and time the ETL last started, used to calculate the
     * duration. Do not assume the ETL completes.
     * 
     * @return Date the last execution date or null
     */
    public Timestamp getLastExtractStartDate() {
        return extractStartDate;
    }

    // __________________________________________________________________________
    /**
     * Returns the date and time the ETL finished at.
     * 
     * @return Date the last execution date or null
     */
    public Timestamp getLastExtractFinishDate() {
        return extractFinishDate;
    }

    // ___________________________________________________________________________
    /**
     * Returns the date up to which data has been processed, all data after this
     * date must be processed
     * 
     * @return Date
     */
    public Timestamp getLastExtractionDate() {
        return lastExtractDate;
    }

    // ___________________________________________________________________________
    /**
     * Returns the target table name.
     * 
     * @return String
     */
    public String getTargetTableName() {
        return targetTableName;
    }

    // ___________________________________________________________________________
    /**
     * Returns the component name.
     * 
     * @return ComponentName
     */
    public ComponentName getComponentName() {
        return component;
    }

    // ___________________________________________________________________________
    /**
     * Sets the component name.
     * 
     * @return ComponentName
     */
    public void setComponentName(final ComponentName inName) {
        component = inName;
    }

    // ___________________________________________________________________________
    /**
     * Returns the objects state.
     * 
     * @return String
     */
    @Override
    public String toString() {
        final StringBuffer state = new StringBuffer();
        state.append(" [");
        state.append(targetTableName).append("]");
        state.append("lastETLDate=").append(DateFormatter.getDate(lastExtractDate))
        .append(",");
        state.append("extracttime=")
        .append(DateFormatter.getDate(extractStartDate)).append(",");
        state.append("extractFinishDate=")
        .append(DateFormatter.getDate(extractFinishDate)).append(",");
        return state.toString();
    }

    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + targetTableName.hashCode();
        return result;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ProcessControl other = (ProcessControl) obj;
        if (!targetTableName.equalsIgnoreCase(other.targetTableName)) {
            return false;
        }
        return true;
    }
}
