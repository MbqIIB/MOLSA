/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 1999 - 2005 Curam Software Ltd. All rights reserved.
 * 
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.util.reporting.internal.persistence.transactions;

import java.sql.SQLException;

import curam.util.reporting.internal.config.ConnectionProperties;

/**
 * This module defines the interface for a transaction manager
 */
public interface TransactionManager {

  // ___________________________________________________________________________
  /**
   * Returns the most recently created transaction.
   * 
   * @return Transaction the transaction
   * @throws SQLException
   */
  public Transaction getMostRecent() throws SQLException;

  // ___________________________________________________________________________
  /**
   * Returns a transaction object
   * 
   * @param inDataStoreName
   *          the data store to establish a connection with
   * 
   * @return Transaction the transaction to work with
   * @throws SQLException
   */
  public Transaction getTransaction(String inDataStoreName) throws SQLException;;

  // ___________________________________________________________________________
  /**
   * Returns a read only transaction object
   * 
   * @param inDataSourceName
   *          the data store to establish a connection with
   * 
   * @return Transaction the transaction to work with
   * @throws SQLException
   */
  public Transaction getReadOnlyTransaction(String inDataSourceName)
      throws SQLException;

  // ___________________________________________________________________________
  /**
   * Returns true if this data source is configured
   * 
   * @param inDataSourceName
   *          the data store to establish a connection with
   * 
   * @return boolean true if data source is configured, false otherwise
   * @throws SQLException
   */
  public boolean supportedDataSource(String inDataSourceName)
      throws SQLException;

  // ___________________________________________________________________________
  /**
   * Returns the connection properties for a data source name
   * 
   * @param inDataSourceName
   *          data source
   * @return ConnectionProperties properties
   * @throws SQLException
   */
  public ConnectionProperties getConnectionProperties(String inDataSourceName)
      throws SQLException;
}
