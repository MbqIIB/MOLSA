/*
 * Licensed Materials - Property of IBM Copyright IBM Corporation 2012. All
 * Rights Reserved. US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.util.reporting.internal.tasks.model;

/**
 * A name value object used by the BI build environment.
 */
public class ReportingProperty {
    /**
     * The name of the element in a <code>name=value</code> pair.
     */
    private String name;

    /**
     * The value of the element in a <code>name=value</code> pair.
     */
    private String value;

    /**
     * Creates a new property object.
     */
    public ReportingProperty() {
        init();
    }

    /**
     * Sets member variables to empty strings.
     */
    protected void init() {
        name = "";
        value = "";
    }

    /**
     * Returns the value of the element.
     * 
     * @return String the element value
     */
    public String getValue() {
        return value;
    }

    /**
     * Set the value of the property.
     * 
     * @param value the value of the property
     */
    public void setValue(final String value) {
        this.value = value;
    }

    /**
     * Returns the property name.
     * 
     * @return String the property name
     */
    public String getName() {
        return name;
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((value == null) ? 0 : value.hashCode());
        return result;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ReportingProperty other = (ReportingProperty) obj;
        if (value == null) {
            if (other.value != null) {
                return false;
            }
        } else if (!value.startsWith(other.value)) {
            return false;
        }
        return true;
    }


    /**
     * Sets the property name.
     * 
     * @param name the property name.
     */
    public void setName(final String name) {
        this.name = name;
    }

    /**
     * Returns the property in property format, e.g. <code>name=value</code>.
     * 
     * @return String returns the property name and value.
     */
    @Override
    public String toString() {
        return name + "=" + value;
    }
}
